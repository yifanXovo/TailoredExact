* Signature: 0xc042444f3b9f7d70
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 E  onehot_9_4
 E  normalized_mass_9_5
 E  normalized_ratio_9_6
 G  product_lb_7
 L  product_ub_8
 G  product_lb_9
 L  product_ub_10
 G  product_lb_11
 L  product_ub_12
 G  product_lb_13
 L  product_ub_14
 G  product_lb_15
 L  product_ub_16
 G  product_lb_17
 L  product_ub_18
 G  product_lb_19
 L  product_ub_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_11_39
 E  normalized_mass_11_40
 E  normalized_ratio_11_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_18_74
 E  normalized_mass_18_75
 E  normalized_ratio_18_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 E  onehot_7_99
 E  normalized_mass_7_100
 E  normalized_ratio_7_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 E  onehot_17_136
 E  normalized_mass_17_137
 E  normalized_ratio_17_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 E  onehot_10_143
 E  normalized_mass_10_144
 E  normalized_ratio_10_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 E  onehot_20_178
 E  normalized_mass_20_179
 E  normalized_ratio_20_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 E  onehot_6_185
 E  normalized_mass_6_186
 E  normalized_ratio_6_187
 G  stock_lb_188
 L  stock_ub_189
 L  parent_nonstrict_scope_190
 G  block_pair_pos_191
 G  block_pair_neg_192
 G  block_pair_pos_193
 G  block_pair_neg_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 E  normalization_247
 G  full_original_Gini_248
 E  unique_nonzero_owner_249
 E  unique_nonzero_owner_250
 E  unique_nonzero_owner_251
 E  unique_nonzero_owner_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 L  arc_capacity_323
 L  arc_capacity_324
 L  arc_capacity_325
 L  arc_capacity_326
 L  arc_capacity_327
 L  arc_capacity_328
 L  arc_capacity_329
 L  arc_capacity_330
 L  arc_capacity_331
 L  arc_capacity_332
 L  arc_capacity_333
 L  arc_capacity_334
 L  arc_capacity_335
 L  arc_capacity_336
 L  arc_capacity_337
 L  arc_capacity_338
 L  arc_capacity_339
 G  connected_order_arc_340
 L  arc_capacity_341
 G  connected_order_arc_342
 L  arc_capacity_343
 G  connected_order_arc_344
 L  arc_capacity_345
 G  connected_order_arc_346
 L  arc_capacity_347
 G  connected_order_arc_348
 L  arc_capacity_349
 G  connected_order_arc_350
 L  arc_capacity_351
 G  connected_order_arc_352
 L  arc_capacity_353
 G  connected_order_arc_354
 L  arc_capacity_355
 G  connected_order_arc_356
 L  arc_capacity_357
 G  connected_order_arc_358
 L  arc_capacity_359
 G  connected_order_arc_360
 L  arc_capacity_361
 G  connected_order_arc_362
 L  arc_capacity_363
 G  connected_order_arc_364
 L  arc_capacity_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 G  connected_order_arc_385
 L  arc_capacity_386
 G  connected_order_arc_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 E  depot_departure_or_bypass_716
 E  depot_return_or_bypass_717
 E  out_degree_718
 E  in_degree_719
 G  order_active_lb_720
 L  order_active_ub_721
 E  segment_load_conservation_722
 G  segment_prefix_lb_723
 L  segment_prefix_ub_724
 E  out_degree_725
 E  in_degree_726
 G  order_active_lb_727
 L  order_active_ub_728
 E  segment_load_conservation_729
 G  segment_prefix_lb_730
 L  segment_prefix_ub_731
 E  out_degree_732
 E  in_degree_733
 G  order_active_lb_734
 L  order_active_ub_735
 E  segment_load_conservation_736
 G  segment_prefix_lb_737
 L  segment_prefix_ub_738
 E  out_degree_739
 E  in_degree_740
 G  order_active_lb_741
 L  order_active_ub_742
 E  segment_load_conservation_743
 G  segment_prefix_lb_744
 L  segment_prefix_ub_745
 E  out_degree_746
 E  in_degree_747
 G  order_active_lb_748
 L  order_active_ub_749
 E  segment_load_conservation_750
 G  segment_prefix_lb_751
 L  segment_prefix_ub_752
 E  out_degree_753
 E  in_degree_754
 G  order_active_lb_755
 L  order_active_ub_756
 E  segment_load_conservation_757
 G  segment_prefix_lb_758
 L  segment_prefix_ub_759
 E  out_degree_760
 E  in_degree_761
 G  order_active_lb_762
 L  order_active_ub_763
 E  service_visit_def_764
 E  free_load_conservation_765
 E  out_degree_766
 E  in_degree_767
 G  order_active_lb_768
 L  order_active_ub_769
 E  service_visit_def_770
 E  free_load_conservation_771
 E  out_degree_772
 E  in_degree_773
 G  order_active_lb_774
 L  order_active_ub_775
 E  service_visit_def_776
 E  free_load_conservation_777
 E  out_degree_778
 E  in_degree_779
 G  order_active_lb_780
 L  order_active_ub_781
 E  service_visit_def_782
 E  free_load_conservation_783
 E  out_degree_784
 E  in_degree_785
 G  order_active_lb_786
 L  order_active_ub_787
 E  service_visit_def_788
 E  free_load_conservation_789
 E  out_degree_790
 E  in_degree_791
 G  order_active_lb_792
 L  order_active_ub_793
 E  service_visit_def_794
 E  free_load_conservation_795
 E  out_degree_796
 E  in_degree_797
 G  order_active_lb_798
 L  order_active_ub_799
 E  service_visit_def_800
 E  free_load_conservation_801
 E  out_degree_802
 E  in_degree_803
 G  order_active_lb_804
 L  order_active_ub_805
 E  service_visit_def_806
 E  free_load_conservation_807
 G  fixed_segment_relative_order_808
 G  fixed_segment_relative_order_809
 G  fixed_segment_relative_order_810
 G  fixed_segment_relative_order_811
 G  fixed_segment_relative_order_812
 L  original_T_including_depot_unload_813
 L  arc_capacity_814
 L  arc_capacity_815
 L  arc_capacity_816
 L  arc_capacity_817
 L  arc_capacity_818
 L  arc_capacity_819
 L  arc_capacity_820
 L  arc_capacity_821
 L  arc_capacity_822
 L  arc_capacity_823
 L  arc_capacity_824
 L  arc_capacity_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 E  depot_departure_or_bypass_1015
 E  depot_return_or_bypass_1016
 E  out_degree_1017
 E  in_degree_1018
 G  order_active_lb_1019
 L  order_active_ub_1020
 E  segment_load_conservation_1021
 G  segment_prefix_lb_1022
 L  segment_prefix_ub_1023
 E  out_degree_1024
 E  in_degree_1025
 G  order_active_lb_1026
 L  order_active_ub_1027
 E  segment_load_conservation_1028
 G  segment_prefix_lb_1029
 L  segment_prefix_ub_1030
 E  out_degree_1031
 E  in_degree_1032
 G  order_active_lb_1033
 L  order_active_ub_1034
 E  service_visit_def_1035
 E  free_load_conservation_1036
 E  out_degree_1037
 E  in_degree_1038
 G  order_active_lb_1039
 L  order_active_ub_1040
 E  service_visit_def_1041
 E  free_load_conservation_1042
 E  out_degree_1043
 E  in_degree_1044
 G  order_active_lb_1045
 L  order_active_ub_1046
 E  service_visit_def_1047
 E  free_load_conservation_1048
 E  out_degree_1049
 E  in_degree_1050
 G  order_active_lb_1051
 L  order_active_ub_1052
 E  service_visit_def_1053
 E  free_load_conservation_1054
 E  out_degree_1055
 E  in_degree_1056
 G  order_active_lb_1057
 L  order_active_ub_1058
 E  service_visit_def_1059
 E  free_load_conservation_1060
 E  out_degree_1061
 E  in_degree_1062
 G  order_active_lb_1063
 L  order_active_ub_1064
 E  service_visit_def_1065
 E  free_load_conservation_1066
 E  out_degree_1067
 E  in_degree_1068
 G  order_active_lb_1069
 L  order_active_ub_1070
 E  service_visit_def_1071
 E  free_load_conservation_1072
 E  out_degree_1073
 E  in_degree_1074
 G  order_active_lb_1075
 L  order_active_ub_1076
 E  service_visit_def_1077
 E  free_load_conservation_1078
 G  fixed_segment_relative_order_1079
 L  original_T_including_depot_unload_1080
COLUMNS
    t         normalized_mass_9_5  -1
    t         normalized_mass_11_40  -1
    t         normalized_mass_18_75  -1
    t         normalized_mass_7_100  -1
    t         normalized_mass_17_137  -1
    t         normalized_mass_10_144  -1
    t         normalized_mass_20_179  -1
    t         normalized_mass_6_186  -1
    t         normalization_247  8.6964285714285712e+00
    t         full_original_Gini_248  -3.2553571428571423e+01
    q         OBJ       1
    q         parent_nonstrict_scope_190  1
    q         full_original_Gini_248  20
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       6.3380304899829966e-03
    x_9_0     product_lb_0  -4.6801002878586309e-02
    x_9_0     product_ub_1  -1.1498973305966327e-01
    x_9_0     onehot_9_4  1
    x_9_0     parent_nonstrict_scope_190  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_0  1
    w_9_0     product_ub_1  1
    w_9_0     normalized_mass_9_5  1
    w_9_0     full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       -6.3380304899829966e-03
    x_9_1     product_lb_2  -4.6801002878586309e-02
    x_9_1     product_ub_3  -1.1498973305966327e-01
    x_9_1     onehot_9_4  1
    x_9_1     stock_lb_188  1
    x_9_1     stock_ub_189  1
    x_9_1     unique_nonzero_owner_249  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_2  1
    w_9_1     product_ub_3  1
    w_9_1     normalized_mass_9_5  1
    w_9_1     normalized_ratio_9_6  -1
    w_9_1     full_original_Gini_248  -3.8392857142857144e+00
    rho_9     normalized_ratio_9_6  1
    rho_9     block_pair_pos_199  -1
    rho_9     block_pair_neg_200  1
    rho_9     block_pair_pos_201  -1
    rho_9     block_pair_neg_202  1
    rho_9     block_pair_pos_203  -1
    rho_9     block_pair_neg_204  1
    rho_9     block_pair_pos_205  -1
    rho_9     block_pair_neg_206  1
    rho_9     block_pair_pos_207  -1
    rho_9     block_pair_neg_208  1
    rho_9     block_pair_pos_209  -1
    rho_9     block_pair_neg_210  1
    rho_9     block_pair_pos_211  -1
    rho_9     block_pair_neg_212  1
    rho_9     normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_7  -4.6801002878586309e-02
    x_11_0    product_ub_8  -1.1498973305966327e-01
    x_11_0    onehot_11_39  1
    x_11_0    parent_nonstrict_scope_190  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_250  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_7  1
    w_11_0    product_ub_8  1
    w_11_0    normalized_mass_11_40  1
    w_11_0    full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_9  -4.6801002878586309e-02
    x_11_1    product_ub_10  -1.1498973305966327e-01
    x_11_1    onehot_11_39  1
    x_11_1    stock_lb_188  1
    x_11_1    stock_ub_189  1
    x_11_1    parent_nonstrict_scope_190  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_9  1
    w_11_1    product_ub_10  1
    w_11_1    normalized_mass_11_40  1
    w_11_1    normalized_ratio_11_41  -0.125
    w_11_1    full_original_Gini_248  -7.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_11  -4.6801002878586309e-02
    x_11_2    product_ub_12  -1.1498973305966327e-01
    x_11_2    onehot_11_39  1
    x_11_2    stock_lb_188  2
    x_11_2    stock_ub_189  2
    x_11_2    parent_nonstrict_scope_190  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_251  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_11  1
    w_11_2    product_ub_12  1
    w_11_2    normalized_mass_11_40  1
    w_11_2    normalized_ratio_11_41  -0.25
    w_11_2    full_original_Gini_248  -7.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_13  -4.6801002878586309e-02
    x_11_3    product_ub_14  -1.1498973305966327e-01
    x_11_3    onehot_11_39  1
    x_11_3    stock_lb_188  3
    x_11_3    stock_ub_189  3
    x_11_3    parent_nonstrict_scope_190  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_252  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_13  1
    w_11_3    product_ub_14  1
    w_11_3    normalized_mass_11_40  1
    w_11_3    normalized_ratio_11_41  -0.375
    w_11_3    full_original_Gini_248  -6.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_15  -4.6801002878586309e-02
    x_11_4    product_ub_16  -1.1498973305966327e-01
    x_11_4    onehot_11_39  1
    x_11_4    stock_lb_188  4
    x_11_4    stock_ub_189  4
    x_11_4    parent_nonstrict_scope_190  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_15  1
    w_11_4    product_ub_16  1
    w_11_4    normalized_mass_11_40  1
    w_11_4    normalized_ratio_11_41  -0.5
    w_11_4    full_original_Gini_248  -5.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_17  -4.6801002878586309e-02
    x_11_5    product_ub_18  -1.1498973305966327e-01
    x_11_5    onehot_11_39  1
    x_11_5    stock_lb_188  5
    x_11_5    stock_ub_189  5
    x_11_5    parent_nonstrict_scope_190  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_17  1
    w_11_5    product_ub_18  1
    w_11_5    normalized_mass_11_40  1
    w_11_5    normalized_ratio_11_41  -0.625
    w_11_5    full_original_Gini_248  -5.3392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_19  -4.6801002878586309e-02
    x_11_6    product_ub_20  -1.1498973305966327e-01
    x_11_6    onehot_11_39  1
    x_11_6    stock_lb_188  6
    x_11_6    stock_ub_189  6
    x_11_6    parent_nonstrict_scope_190  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_19  1
    w_11_6    product_ub_20  1
    w_11_6    normalized_mass_11_40  1
    w_11_6    normalized_ratio_11_41  -0.75
    w_11_6    full_original_Gini_248  -4.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_21  -4.6801002878586309e-02
    x_11_7    product_ub_22  -1.1498973305966327e-01
    x_11_7    onehot_11_39  1
    x_11_7    stock_lb_188  7
    x_11_7    stock_ub_189  7
    x_11_7    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_21  1
    w_11_7    product_ub_22  1
    w_11_7    normalized_mass_11_40  1
    w_11_7    normalized_ratio_11_41  -0.875
    w_11_7    full_original_Gini_248  -4.3392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_23  -4.6801002878586309e-02
    x_11_8    product_ub_24  -1.1498973305966327e-01
    x_11_8    onehot_11_39  1
    x_11_8    stock_lb_188  8
    x_11_8    stock_ub_189  8
    x_11_8    unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_23  1
    w_11_8    product_ub_24  1
    w_11_8    normalized_mass_11_40  1
    w_11_8    normalized_ratio_11_41  -1
    w_11_8    full_original_Gini_248  -3.8392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_25  -4.6801002878586309e-02
    x_11_9    product_ub_26  -1.1498973305966327e-01
    x_11_9    onehot_11_39  1
    x_11_9    stock_lb_188  9
    x_11_9    stock_ub_189  9
    x_11_9    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_25  1
    w_11_9    product_ub_26  1
    w_11_9    normalized_mass_11_40  1
    w_11_9    normalized_ratio_11_41  -1.125
    w_11_9    full_original_Gini_248  -4.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_27  -4.6801002878586309e-02
    x_11_10   product_ub_28  -1.1498973305966327e-01
    x_11_10   onehot_11_39  1
    x_11_10   stock_lb_188  10
    x_11_10   stock_ub_189  10
    x_11_10   parent_nonstrict_scope_190  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_27  1
    w_11_10   product_ub_28  1
    w_11_10   normalized_mass_11_40  1
    w_11_10   normalized_ratio_11_41  -1.25
    w_11_10   full_original_Gini_248  -6.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_29  -4.6801002878586309e-02
    x_11_11   product_ub_30  -1.1498973305966327e-01
    x_11_11   onehot_11_39  1
    x_11_11   stock_lb_188  11
    x_11_11   stock_ub_189  11
    x_11_11   parent_nonstrict_scope_190  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_29  1
    w_11_11   product_ub_30  1
    w_11_11   normalized_mass_11_40  1
    w_11_11   normalized_ratio_11_41  -1.375
    w_11_11   full_original_Gini_248  -7.8035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_31  -4.6801002878586309e-02
    x_11_12   product_ub_32  -1.1498973305966327e-01
    x_11_12   onehot_11_39  1
    x_11_12   stock_lb_188  12
    x_11_12   stock_ub_189  12
    x_11_12   parent_nonstrict_scope_190  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_31  1
    w_11_12   product_ub_32  1
    w_11_12   normalized_mass_11_40  1
    w_11_12   normalized_ratio_11_41  -1.5
    w_11_12   full_original_Gini_248  -9.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_33  -4.6801002878586309e-02
    x_11_13   product_ub_34  -1.1498973305966327e-01
    x_11_13   onehot_11_39  1
    x_11_13   stock_lb_188  13
    x_11_13   stock_ub_189  13
    x_11_13   parent_nonstrict_scope_190  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_33  1
    w_11_13   product_ub_34  1
    w_11_13   normalized_mass_11_40  1
    w_11_13   normalized_ratio_11_41  -1.625
    w_11_13   full_original_Gini_248  -1.0803571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_35  -4.6801002878586309e-02
    x_11_14   product_ub_36  -1.1498973305966327e-01
    x_11_14   onehot_11_39  1
    x_11_14   stock_lb_188  14
    x_11_14   stock_ub_189  14
    x_11_14   parent_nonstrict_scope_190  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_35  1
    w_11_14   product_ub_36  1
    w_11_14   normalized_mass_11_40  1
    w_11_14   normalized_ratio_11_41  -1.75
    w_11_14   full_original_Gini_248  -1.2303571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_37  -4.6801002878586309e-02
    x_11_15   product_ub_38  -1.1498973305966327e-01
    x_11_15   onehot_11_39  1
    x_11_15   stock_lb_188  15
    x_11_15   stock_ub_189  15
    x_11_15   parent_nonstrict_scope_190  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_37  1
    w_11_15   product_ub_38  1
    w_11_15   normalized_mass_11_40  1
    w_11_15   normalized_ratio_11_41  -1.875
    w_11_15   full_original_Gini_248  -1.3803571428571429e+01
    rho_11    normalized_ratio_11_41  1
    rho_11    block_pair_pos_205  1
    rho_11    block_pair_neg_206  -1
    rho_11    block_pair_pos_217  -1
    rho_11    block_pair_neg_218  1
    rho_11    block_pair_pos_219  -1
    rho_11    block_pair_neg_220  1
    rho_11    block_pair_pos_221  -1
    rho_11    block_pair_neg_222  1
    rho_11    block_pair_pos_223  -1
    rho_11    block_pair_neg_224  1
    rho_11    block_pair_pos_225  -1
    rho_11    block_pair_neg_226  1
    rho_11    block_pair_pos_227  -1
    rho_11    block_pair_neg_228  1
    rho_11    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_42  -4.6801002878586309e-02
    x_18_0    product_ub_43  -1.1498973305966327e-01
    x_18_0    onehot_18_74  1
    x_18_0    parent_nonstrict_scope_190  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_42  1
    w_18_0    product_ub_43  1
    w_18_0    normalized_mass_18_75  1
    w_18_0    full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_44  -4.6801002878586309e-02
    x_18_1    product_ub_45  -1.1498973305966327e-01
    x_18_1    onehot_18_74  1
    x_18_1    stock_lb_188  1
    x_18_1    stock_ub_189  1
    x_18_1    parent_nonstrict_scope_190  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_44  1
    w_18_1    product_ub_45  1
    w_18_1    normalized_mass_18_75  1
    w_18_1    normalized_ratio_18_76  -1.4285714285714285e-01
    w_18_1    full_original_Gini_248  -7.8392857142857162e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_46  -4.6801002878586309e-02
    x_18_2    product_ub_47  -1.1498973305966327e-01
    x_18_2    onehot_18_74  1
    x_18_2    stock_lb_188  2
    x_18_2    stock_ub_189  2
    x_18_2    parent_nonstrict_scope_190  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_46  1
    w_18_2    product_ub_47  1
    w_18_2    normalized_mass_18_75  1
    w_18_2    normalized_ratio_18_76  -2.8571428571428570e-01
    w_18_2    full_original_Gini_248  -6.9821428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_48  -4.6801002878586309e-02
    x_18_3    product_ub_49  -1.1498973305966327e-01
    x_18_3    onehot_18_74  1
    x_18_3    stock_lb_188  3
    x_18_3    stock_ub_189  3
    x_18_3    parent_nonstrict_scope_190  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_48  1
    w_18_3    product_ub_49  1
    w_18_3    normalized_mass_18_75  1
    w_18_3    normalized_ratio_18_76  -4.2857142857142855e-01
    w_18_3    full_original_Gini_248  -6.1249999999999991e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_50  -4.6801002878586309e-02
    x_18_4    product_ub_51  -1.1498973305966327e-01
    x_18_4    onehot_18_74  1
    x_18_4    stock_lb_188  4
    x_18_4    stock_ub_189  4
    x_18_4    parent_nonstrict_scope_190  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_50  1
    w_18_4    product_ub_51  1
    w_18_4    normalized_mass_18_75  1
    w_18_4    normalized_ratio_18_76  -5.7142857142857140e-01
    w_18_4    full_original_Gini_248  -5.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_52  -4.6801002878586309e-02
    x_18_5    product_ub_53  -1.1498973305966327e-01
    x_18_5    onehot_18_74  1
    x_18_5    stock_lb_188  5
    x_18_5    stock_ub_189  5
    x_18_5    parent_nonstrict_scope_190  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_52  1
    w_18_5    product_ub_53  1
    w_18_5    normalized_mass_18_75  1
    w_18_5    normalized_ratio_18_76  -7.1428571428571419e-01
    w_18_5    full_original_Gini_248  -4.9821428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_54  -4.6801002878586309e-02
    x_18_6    product_ub_55  -1.1498973305966327e-01
    x_18_6    onehot_18_74  1
    x_18_6    stock_lb_188  6
    x_18_6    stock_ub_189  6
    x_18_6    parent_nonstrict_scope_190  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_54  1
    w_18_6    product_ub_55  1
    w_18_6    normalized_mass_18_75  1
    w_18_6    normalized_ratio_18_76  -8.5714285714285710e-01
    w_18_6    full_original_Gini_248  -4.4107142857142856e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_56  -4.6801002878586309e-02
    x_18_7    product_ub_57  -1.1498973305966327e-01
    x_18_7    onehot_18_74  1
    x_18_7    stock_lb_188  7
    x_18_7    stock_ub_189  7
    x_18_7    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_56  1
    w_18_7    product_ub_57  1
    w_18_7    normalized_mass_18_75  1
    w_18_7    normalized_ratio_18_76  -1
    w_18_7    full_original_Gini_248  -3.8392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_58  -4.6801002878586309e-02
    x_18_8    product_ub_59  -1.1498973305966327e-01
    x_18_8    onehot_18_74  1
    x_18_8    stock_lb_188  8
    x_18_8    stock_ub_189  8
    x_18_8    parent_nonstrict_scope_190  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_58  1
    w_18_8    product_ub_59  1
    w_18_8    normalized_mass_18_75  1
    w_18_8    normalized_ratio_18_76  -1.1428571428571428e+00
    w_18_8    full_original_Gini_248  -5.0178571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_60  -4.6801002878586309e-02
    x_18_9    product_ub_61  -1.1498973305966327e-01
    x_18_9    onehot_18_74  1
    x_18_9    stock_lb_188  9
    x_18_9    stock_ub_189  9
    x_18_9    parent_nonstrict_scope_190  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_60  1
    w_18_9    product_ub_61  1
    w_18_9    normalized_mass_18_75  1
    w_18_9    normalized_ratio_18_76  -1.2857142857142856e+00
    w_18_9    full_original_Gini_248  -6.7321428571428559e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_62  -4.6801002878586309e-02
    x_18_10   product_ub_63  -1.1498973305966327e-01
    x_18_10   onehot_18_74  1
    x_18_10   stock_lb_188  10
    x_18_10   stock_ub_189  10
    x_18_10   parent_nonstrict_scope_190  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_62  1
    w_18_10   product_ub_63  1
    w_18_10   normalized_mass_18_75  1
    w_18_10   normalized_ratio_18_76  -1.4285714285714284e+00
    w_18_10   full_original_Gini_248  -8.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_64  -4.6801002878586309e-02
    x_18_11   product_ub_65  -1.1498973305966327e-01
    x_18_11   onehot_18_74  1
    x_18_11   stock_lb_188  11
    x_18_11   stock_ub_189  11
    x_18_11   parent_nonstrict_scope_190  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_64  1
    w_18_11   product_ub_65  1
    w_18_11   normalized_mass_18_75  1
    w_18_11   normalized_ratio_18_76  -1.5714285714285714e+00
    w_18_11   full_original_Gini_248  -1.0160714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_66  -4.6801002878586309e-02
    x_18_12   product_ub_67  -1.1498973305966327e-01
    x_18_12   onehot_18_74  1
    x_18_12   stock_lb_188  12
    x_18_12   stock_ub_189  12
    x_18_12   parent_nonstrict_scope_190  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_66  1
    w_18_12   product_ub_67  1
    w_18_12   normalized_mass_18_75  1
    w_18_12   normalized_ratio_18_76  -1.7142857142857142e+00
    w_18_12   full_original_Gini_248  -1.1874999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_68  -4.6801002878586309e-02
    x_18_13   product_ub_69  -1.1498973305966327e-01
    x_18_13   onehot_18_74  1
    x_18_13   stock_lb_188  13
    x_18_13   stock_ub_189  13
    x_18_13   parent_nonstrict_scope_190  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_68  1
    w_18_13   product_ub_69  1
    w_18_13   normalized_mass_18_75  1
    w_18_13   normalized_ratio_18_76  -1.8571428571428570e+00
    w_18_13   full_original_Gini_248  -1.3589285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_70  -4.6801002878586309e-02
    x_18_14   product_ub_71  -1.1498973305966327e-01
    x_18_14   onehot_18_74  1
    x_18_14   stock_lb_188  14
    x_18_14   stock_ub_189  14
    x_18_14   parent_nonstrict_scope_190  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_70  1
    w_18_14   product_ub_71  1
    w_18_14   normalized_mass_18_75  1
    w_18_14   normalized_ratio_18_76  -2
    w_18_14   full_original_Gini_248  -1.5303571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_72  -4.6801002878586309e-02
    x_18_15   product_ub_73  -1.1498973305966327e-01
    x_18_15   onehot_18_74  1
    x_18_15   stock_lb_188  15
    x_18_15   stock_ub_189  15
    x_18_15   parent_nonstrict_scope_190  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_72  1
    w_18_15   product_ub_73  1
    w_18_15   normalized_mass_18_75  1
    w_18_15   normalized_ratio_18_76  -2.1428571428571428e+00
    w_18_15   full_original_Gini_248  -1.7017857142857139e+01
    rho_18    normalized_ratio_18_76  1
    rho_18    block_pair_pos_209  1
    rho_18    block_pair_neg_210  -1
    rho_18    block_pair_pos_225  1
    rho_18    block_pair_neg_226  -1
    rho_18    block_pair_pos_235  -1
    rho_18    block_pair_neg_236  1
    rho_18    block_pair_pos_237  -1
    rho_18    block_pair_neg_238  1
    rho_18    block_pair_pos_239  -1
    rho_18    block_pair_neg_240  1
    rho_18    block_pair_pos_241  -1
    rho_18    block_pair_neg_242  1
    rho_18    block_pair_pos_243  -1
    rho_18    block_pair_neg_244  1
    rho_18    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       1.9561824064893318e-02
    x_7_0     product_lb_77  -4.6801002878586309e-02
    x_7_0     product_ub_78  -1.1498973305966327e-01
    x_7_0     onehot_7_99  1
    x_7_0     parent_nonstrict_scope_190  3.9123648129786637e-02
    x_7_0     unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_77  1
    w_7_0     product_ub_78  1
    w_7_0     normalized_mass_7_100  1
    w_7_0     full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       1.1737094438935995e-02
    x_7_1     product_lb_79  -4.6801002878586309e-02
    x_7_1     product_ub_80  -1.1498973305966327e-01
    x_7_1     onehot_7_99  1
    x_7_1     stock_lb_188  1
    x_7_1     stock_ub_189  1
    x_7_1     parent_nonstrict_scope_190  3.1298918503829314e-02
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_79  1
    w_7_1     product_ub_80  1
    w_7_1     normalized_mass_7_100  1
    w_7_1     normalized_ratio_7_101  -0.2
    w_7_1     full_original_Gini_248  -7.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       3.9123648129786616e-03
    x_7_2     product_lb_81  -4.6801002878586309e-02
    x_7_2     product_ub_82  -1.1498973305966327e-01
    x_7_2     onehot_7_99  1
    x_7_2     stock_lb_188  2
    x_7_2     stock_ub_189  2
    x_7_2     parent_nonstrict_scope_190  2.3474188877871980e-02
    x_7_2     unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_81  1
    w_7_2     product_ub_82  1
    w_7_2     normalized_mass_7_100  1
    w_7_2     normalized_ratio_7_101  -0.4
    w_7_2     full_original_Gini_248  -6.2964285714285717e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       -3.9123648129786685e-03
    x_7_3     product_lb_83  -4.6801002878586309e-02
    x_7_3     product_ub_84  -1.1498973305966327e-01
    x_7_3     onehot_7_99  1
    x_7_3     stock_lb_188  3
    x_7_3     stock_ub_189  3
    x_7_3     parent_nonstrict_scope_190  1.5649459251914650e-02
    x_7_3     unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_83  1
    w_7_3     product_ub_84  1
    w_7_3     normalized_mass_7_100  1
    w_7_3     normalized_ratio_7_101  -6.0000000000000009e-01
    w_7_3     full_original_Gini_248  -5.4392857142857132e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -1.1737094438935993e-02
    x_7_4     product_lb_85  -4.6801002878586309e-02
    x_7_4     product_ub_86  -1.1498973305966327e-01
    x_7_4     onehot_7_99  1
    x_7_4     stock_lb_188  4
    x_7_4     stock_ub_189  4
    x_7_4     parent_nonstrict_scope_190  7.8247296259573249e-03
    x_7_4     unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_85  1
    w_7_4     product_ub_86  1
    w_7_4     normalized_mass_7_100  1
    w_7_4     normalized_ratio_7_101  -0.8
    w_7_4     full_original_Gini_248  -4.6392857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.9561824064893318e-02
    x_7_5     product_lb_87  -4.6801002878586309e-02
    x_7_5     product_ub_88  -1.1498973305966327e-01
    x_7_5     onehot_7_99  1
    x_7_5     stock_lb_188  5
    x_7_5     stock_ub_189  5
    x_7_5     unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_87  1
    w_7_5     product_ub_88  1
    w_7_5     normalized_mass_7_100  1
    w_7_5     normalized_ratio_7_101  -1
    w_7_5     full_original_Gini_248  -3.8392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -1.1737094438935985e-02
    x_7_6     product_lb_89  -4.6801002878586309e-02
    x_7_6     product_ub_90  -1.1498973305966327e-01
    x_7_6     onehot_7_99  1
    x_7_6     stock_lb_188  6
    x_7_6     stock_ub_189  6
    x_7_6     parent_nonstrict_scope_190  7.8247296259573336e-03
    x_7_6     unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_89  1
    w_7_6     product_ub_90  1
    w_7_6     normalized_mass_7_100  1
    w_7_6     normalized_ratio_7_101  -1.2000000000000002e+00
    w_7_6     full_original_Gini_248  -5.7035714285714310e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -3.9123648129786581e-03
    x_7_7     product_lb_91  -4.6801002878586309e-02
    x_7_7     product_ub_92  -1.1498973305966327e-01
    x_7_7     onehot_7_99  1
    x_7_7     stock_lb_188  7
    x_7_7     stock_ub_189  7
    x_7_7     parent_nonstrict_scope_190  1.5649459251914660e-02
    x_7_7     unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_91  1
    w_7_7     product_ub_92  1
    w_7_7     normalized_mass_7_100  1
    w_7_7     normalized_ratio_7_101  -1.4000000000000001e+00
    w_7_7     full_original_Gini_248  -8.1035714285714313e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       3.9123648129786685e-03
    x_7_8     product_lb_93  -4.6801002878586309e-02
    x_7_8     product_ub_94  -1.1498973305966327e-01
    x_7_8     onehot_7_99  1
    x_7_8     stock_lb_188  8
    x_7_8     stock_ub_189  8
    x_7_8     parent_nonstrict_scope_190  2.3474188877871987e-02
    x_7_8     unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_93  1
    w_7_8     product_ub_94  1
    w_7_8     normalized_mass_7_100  1
    w_7_8     normalized_ratio_7_101  -1.6
    w_7_8     full_original_Gini_248  -1.0503571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       1.1737094438935995e-02
    x_7_9     product_lb_95  -4.6801002878586309e-02
    x_7_9     product_ub_96  -1.1498973305966327e-01
    x_7_9     onehot_7_99  1
    x_7_9     stock_lb_188  9
    x_7_9     stock_ub_189  9
    x_7_9     parent_nonstrict_scope_190  3.1298918503829314e-02
    x_7_9     unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_95  1
    w_7_9     product_ub_96  1
    w_7_9     normalized_mass_7_100  1
    w_7_9     normalized_ratio_7_101  -1.8
    w_7_9     full_original_Gini_248  -1.2903571428571430e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       1.9561824064893318e-02
    x_7_10    product_lb_97  -4.6801002878586309e-02
    x_7_10    product_ub_98  -1.1498973305966327e-01
    x_7_10    onehot_7_99  1
    x_7_10    stock_lb_188  10
    x_7_10    stock_ub_189  10
    x_7_10    parent_nonstrict_scope_190  3.9123648129786637e-02
    x_7_10    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_97  1
    w_7_10    product_ub_98  1
    w_7_10    normalized_mass_7_100  1
    w_7_10    normalized_ratio_7_101  -2
    w_7_10    full_original_Gini_248  -1.5303571428571429e+01
    rho_7     normalized_ratio_7_101  1
    rho_7     block_pair_pos_191  -1
    rho_7     block_pair_neg_192  1
    rho_7     block_pair_pos_193  -1
    rho_7     block_pair_neg_194  1
    rho_7     block_pair_pos_195  -1
    rho_7     block_pair_neg_196  1
    rho_7     block_pair_pos_197  -1
    rho_7     block_pair_neg_198  1
    rho_7     block_pair_pos_201  1
    rho_7     block_pair_neg_202  -1
    rho_7     block_pair_pos_219  1
    rho_7     block_pair_neg_220  -1
    rho_7     block_pair_pos_237  1
    rho_7     block_pair_neg_238  -1
    rho_7     normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_102  -4.6801002878586309e-02
    x_17_0    product_ub_103  -1.1498973305966327e-01
    x_17_0    onehot_17_136  1
    x_17_0    parent_nonstrict_scope_190  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_102  1
    w_17_0    product_ub_103  1
    w_17_0    normalized_mass_17_137  1
    w_17_0    full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_104  -4.6801002878586309e-02
    x_17_1    product_ub_105  -1.1498973305966327e-01
    x_17_1    onehot_17_136  1
    x_17_1    stock_lb_188  1
    x_17_1    stock_ub_189  1
    x_17_1    parent_nonstrict_scope_190  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_104  1
    w_17_1    product_ub_105  1
    w_17_1    normalized_mass_17_137  1
    w_17_1    normalized_ratio_17_138  -1.1111111111111110e-01
    w_17_1    full_original_Gini_248  -8.0297619047619033e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_106  -4.6801002878586309e-02
    x_17_2    product_ub_107  -1.1498973305966327e-01
    x_17_2    onehot_17_136  1
    x_17_2    stock_lb_188  2
    x_17_2    stock_ub_189  2
    x_17_2    parent_nonstrict_scope_190  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_106  1
    w_17_2    product_ub_107  1
    w_17_2    normalized_mass_17_137  1
    w_17_2    normalized_ratio_17_138  -2.2222222222222221e-01
    w_17_2    full_original_Gini_248  -7.3630952380952381e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_108  -4.6801002878586309e-02
    x_17_3    product_ub_109  -1.1498973305966327e-01
    x_17_3    onehot_17_136  1
    x_17_3    stock_lb_188  3
    x_17_3    stock_ub_189  3
    x_17_3    parent_nonstrict_scope_190  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_108  1
    w_17_3    product_ub_109  1
    w_17_3    normalized_mass_17_137  1
    w_17_3    normalized_ratio_17_138  -3.3333333333333331e-01
    w_17_3    full_original_Gini_248  -6.6964285714285730e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_110  -4.6801002878586309e-02
    x_17_4    product_ub_111  -1.1498973305966327e-01
    x_17_4    onehot_17_136  1
    x_17_4    stock_lb_188  4
    x_17_4    stock_ub_189  4
    x_17_4    parent_nonstrict_scope_190  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_110  1
    w_17_4    product_ub_111  1
    w_17_4    normalized_mass_17_137  1
    w_17_4    normalized_ratio_17_138  -4.4444444444444442e-01
    w_17_4    full_original_Gini_248  -6.0615079365079367e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_112  -4.6801002878586309e-02
    x_17_5    product_ub_113  -1.1498973305966327e-01
    x_17_5    onehot_17_136  1
    x_17_5    stock_lb_188  5
    x_17_5    stock_ub_189  5
    x_17_5    parent_nonstrict_scope_190  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_112  1
    w_17_5    product_ub_113  1
    w_17_5    normalized_mass_17_137  1
    w_17_5    normalized_ratio_17_138  -5.5555555555555558e-01
    w_17_5    full_original_Gini_248  -5.6170634920634921e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_114  -4.6801002878586309e-02
    x_17_6    product_ub_115  -1.1498973305966327e-01
    x_17_6    onehot_17_136  1
    x_17_6    stock_lb_188  6
    x_17_6    stock_ub_189  6
    x_17_6    parent_nonstrict_scope_190  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_114  1
    w_17_6    product_ub_115  1
    w_17_6    normalized_mass_17_137  1
    w_17_6    normalized_ratio_17_138  -6.6666666666666663e-01
    w_17_6    full_original_Gini_248  -5.1726190476190483e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_116  -4.6801002878586309e-02
    x_17_7    product_ub_117  -1.1498973305966327e-01
    x_17_7    onehot_17_136  1
    x_17_7    stock_lb_188  7
    x_17_7    stock_ub_189  7
    x_17_7    parent_nonstrict_scope_190  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_116  1
    w_17_7    product_ub_117  1
    w_17_7    normalized_mass_17_137  1
    w_17_7    normalized_ratio_17_138  -7.7777777777777768e-01
    w_17_7    full_original_Gini_248  -4.7281746031746028e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_118  -4.6801002878586309e-02
    x_17_8    product_ub_119  -1.1498973305966327e-01
    x_17_8    onehot_17_136  1
    x_17_8    stock_lb_188  8
    x_17_8    stock_ub_189  8
    x_17_8    parent_nonstrict_scope_190  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_118  1
    w_17_8    product_ub_119  1
    w_17_8    normalized_mass_17_137  1
    w_17_8    normalized_ratio_17_138  -8.8888888888888884e-01
    w_17_8    full_original_Gini_248  -4.2837301587301582e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_120  -4.6801002878586309e-02
    x_17_9    product_ub_121  -1.1498973305966327e-01
    x_17_9    onehot_17_136  1
    x_17_9    stock_lb_188  9
    x_17_9    stock_ub_189  9
    x_17_9    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_120  1
    w_17_9    product_ub_121  1
    w_17_9    normalized_mass_17_137  1
    w_17_9    normalized_ratio_17_138  -1
    w_17_9    full_original_Gini_248  -3.8392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_122  -4.6801002878586309e-02
    x_17_10   product_ub_123  -1.1498973305966327e-01
    x_17_10   onehot_17_136  1
    x_17_10   stock_lb_188  10
    x_17_10   stock_ub_189  10
    x_17_10   parent_nonstrict_scope_190  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_122  1
    w_17_10   product_ub_123  1
    w_17_10   normalized_mass_17_137  1
    w_17_10   normalized_ratio_17_138  -1.1111111111111112e+00
    w_17_10   full_original_Gini_248  -4.7281746031746028e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_124  -4.6801002878586309e-02
    x_17_11   product_ub_125  -1.1498973305966327e-01
    x_17_11   onehot_17_136  1
    x_17_11   stock_lb_188  11
    x_17_11   stock_ub_189  11
    x_17_11   parent_nonstrict_scope_190  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_124  1
    w_17_11   product_ub_125  1
    w_17_11   normalized_mass_17_137  1
    w_17_11   normalized_ratio_17_138  -1.2222222222222221e+00
    w_17_11   full_original_Gini_248  -5.9702380952380949e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_126  -4.6801002878586309e-02
    x_17_12   product_ub_127  -1.1498973305966327e-01
    x_17_12   onehot_17_136  1
    x_17_12   stock_lb_188  12
    x_17_12   stock_ub_189  12
    x_17_12   parent_nonstrict_scope_190  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_126  1
    w_17_12   product_ub_127  1
    w_17_12   normalized_mass_17_137  1
    w_17_12   normalized_ratio_17_138  -1.3333333333333333e+00
    w_17_12   full_original_Gini_248  -7.3035714285714270e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_128  -4.6801002878586309e-02
    x_17_13   product_ub_129  -1.1498973305966327e-01
    x_17_13   onehot_17_136  1
    x_17_13   stock_lb_188  13
    x_17_13   stock_ub_189  13
    x_17_13   parent_nonstrict_scope_190  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_128  1
    w_17_13   product_ub_129  1
    w_17_13   normalized_mass_17_137  1
    w_17_13   normalized_ratio_17_138  -1.4444444444444444e+00
    w_17_13   full_original_Gini_248  -8.6369047619047628e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_130  -4.6801002878586309e-02
    x_17_14   product_ub_131  -1.1498973305966327e-01
    x_17_14   onehot_17_136  1
    x_17_14   stock_lb_188  14
    x_17_14   stock_ub_189  14
    x_17_14   parent_nonstrict_scope_190  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_130  1
    w_17_14   product_ub_131  1
    w_17_14   normalized_mass_17_137  1
    w_17_14   normalized_ratio_17_138  -1.5555555555555554e+00
    w_17_14   full_original_Gini_248  -9.9702380952380931e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_132  -4.6801002878586309e-02
    x_17_15   product_ub_133  -1.1498973305966327e-01
    x_17_15   onehot_17_136  1
    x_17_15   stock_lb_188  15
    x_17_15   stock_ub_189  15
    x_17_15   parent_nonstrict_scope_190  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_132  1
    w_17_15   product_ub_133  1
    w_17_15   normalized_mass_17_137  1
    w_17_15   normalized_ratio_17_138  -1.6666666666666665e+00
    w_17_15   full_original_Gini_248  -1.1303571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_134  -4.6801002878586309e-02
    x_17_16   product_ub_135  -1.1498973305966327e-01
    x_17_16   onehot_17_136  1
    x_17_16   stock_lb_188  16
    x_17_16   stock_ub_189  16
    x_17_16   parent_nonstrict_scope_190  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_134  1
    w_17_16   product_ub_135  1
    w_17_16   normalized_mass_17_137  1
    w_17_16   normalized_ratio_17_138  -1.7777777777777777e+00
    w_17_16   full_original_Gini_248  -1.2636904761904763e+01
    rho_17    normalized_ratio_17_138  1
    rho_17    block_pair_pos_195  1
    rho_17    block_pair_neg_196  -1
    rho_17    block_pair_pos_207  1
    rho_17    block_pair_neg_208  -1
    rho_17    block_pair_pos_223  1
    rho_17    block_pair_neg_224  -1
    rho_17    block_pair_pos_229  -1
    rho_17    block_pair_neg_230  1
    rho_17    block_pair_pos_231  -1
    rho_17    block_pair_neg_232  1
    rho_17    block_pair_pos_233  -1
    rho_17    block_pair_neg_234  1
    rho_17    block_pair_pos_241  1
    rho_17    block_pair_neg_242  -1
    rho_17    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       6.3380304899829966e-03
    x_10_0    product_lb_139  -4.6801002878586309e-02
    x_10_0    product_ub_140  -1.1498973305966327e-01
    x_10_0    onehot_10_143  1
    x_10_0    parent_nonstrict_scope_190  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_139  1
    w_10_0    product_ub_140  1
    w_10_0    normalized_mass_10_144  1
    w_10_0    full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       -6.3380304899829966e-03
    x_10_1    product_lb_141  -4.6801002878586309e-02
    x_10_1    product_ub_142  -1.1498973305966327e-01
    x_10_1    onehot_10_143  1
    x_10_1    stock_lb_188  1
    x_10_1    stock_ub_189  1
    x_10_1    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_141  1
    w_10_1    product_ub_142  1
    w_10_1    normalized_mass_10_144  1
    w_10_1    normalized_ratio_10_145  -1
    w_10_1    full_original_Gini_248  -3.8392857142857144e+00
    rho_10    normalized_ratio_10_145  1
    rho_10    block_pair_pos_193  1
    rho_10    block_pair_neg_194  -1
    rho_10    block_pair_pos_203  1
    rho_10    block_pair_neg_204  -1
    rho_10    block_pair_pos_213  -1
    rho_10    block_pair_neg_214  1
    rho_10    block_pair_pos_215  -1
    rho_10    block_pair_neg_216  1
    rho_10    block_pair_pos_221  1
    rho_10    block_pair_neg_222  -1
    rho_10    block_pair_pos_231  1
    rho_10    block_pair_neg_232  -1
    rho_10    block_pair_pos_239  1
    rho_10    block_pair_neg_240  -1
    rho_10    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_146  -4.6801002878586309e-02
    x_20_0    product_ub_147  -1.1498973305966327e-01
    x_20_0    onehot_20_178  1
    x_20_0    parent_nonstrict_scope_190  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_146  1
    w_20_0    product_ub_147  1
    w_20_0    normalized_mass_20_179  1
    w_20_0    full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_148  -4.6801002878586309e-02
    x_20_1    product_ub_149  -1.1498973305966327e-01
    x_20_1    onehot_20_178  1
    x_20_1    stock_lb_188  1
    x_20_1    stock_ub_189  1
    x_20_1    parent_nonstrict_scope_190  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_148  1
    w_20_1    product_ub_149  1
    w_20_1    normalized_mass_20_179  1
    w_20_1    normalized_ratio_20_180  -0.125
    w_20_1    full_original_Gini_248  -7.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_150  -4.6801002878586309e-02
    x_20_2    product_ub_151  -1.1498973305966327e-01
    x_20_2    onehot_20_178  1
    x_20_2    stock_lb_188  2
    x_20_2    stock_ub_189  2
    x_20_2    parent_nonstrict_scope_190  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_150  1
    w_20_2    product_ub_151  1
    w_20_2    normalized_mass_20_179  1
    w_20_2    normalized_ratio_20_180  -0.25
    w_20_2    full_original_Gini_248  -7.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_152  -4.6801002878586309e-02
    x_20_3    product_ub_153  -1.1498973305966327e-01
    x_20_3    onehot_20_178  1
    x_20_3    stock_lb_188  3
    x_20_3    stock_ub_189  3
    x_20_3    parent_nonstrict_scope_190  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_152  1
    w_20_3    product_ub_153  1
    w_20_3    normalized_mass_20_179  1
    w_20_3    normalized_ratio_20_180  -0.375
    w_20_3    full_original_Gini_248  -6.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_154  -4.6801002878586309e-02
    x_20_4    product_ub_155  -1.1498973305966327e-01
    x_20_4    onehot_20_178  1
    x_20_4    stock_lb_188  4
    x_20_4    stock_ub_189  4
    x_20_4    parent_nonstrict_scope_190  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_154  1
    w_20_4    product_ub_155  1
    w_20_4    normalized_mass_20_179  1
    w_20_4    normalized_ratio_20_180  -0.5
    w_20_4    full_original_Gini_248  -5.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_156  -4.6801002878586309e-02
    x_20_5    product_ub_157  -1.1498973305966327e-01
    x_20_5    onehot_20_178  1
    x_20_5    stock_lb_188  5
    x_20_5    stock_ub_189  5
    x_20_5    parent_nonstrict_scope_190  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_156  1
    w_20_5    product_ub_157  1
    w_20_5    normalized_mass_20_179  1
    w_20_5    normalized_ratio_20_180  -0.625
    w_20_5    full_original_Gini_248  -5.3392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_158  -4.6801002878586309e-02
    x_20_6    product_ub_159  -1.1498973305966327e-01
    x_20_6    onehot_20_178  1
    x_20_6    stock_lb_188  6
    x_20_6    stock_ub_189  6
    x_20_6    parent_nonstrict_scope_190  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_158  1
    w_20_6    product_ub_159  1
    w_20_6    normalized_mass_20_179  1
    w_20_6    normalized_ratio_20_180  -0.75
    w_20_6    full_original_Gini_248  -4.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_160  -4.6801002878586309e-02
    x_20_7    product_ub_161  -1.1498973305966327e-01
    x_20_7    onehot_20_178  1
    x_20_7    stock_lb_188  7
    x_20_7    stock_ub_189  7
    x_20_7    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_160  1
    w_20_7    product_ub_161  1
    w_20_7    normalized_mass_20_179  1
    w_20_7    normalized_ratio_20_180  -0.875
    w_20_7    full_original_Gini_248  -4.3392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_162  -4.6801002878586309e-02
    x_20_8    product_ub_163  -1.1498973305966327e-01
    x_20_8    onehot_20_178  1
    x_20_8    stock_lb_188  8
    x_20_8    stock_ub_189  8
    x_20_8    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_162  1
    w_20_8    product_ub_163  1
    w_20_8    normalized_mass_20_179  1
    w_20_8    normalized_ratio_20_180  -1
    w_20_8    full_original_Gini_248  -3.8392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_164  -4.6801002878586309e-02
    x_20_9    product_ub_165  -1.1498973305966327e-01
    x_20_9    onehot_20_178  1
    x_20_9    stock_lb_188  9
    x_20_9    stock_ub_189  9
    x_20_9    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_164  1
    w_20_9    product_ub_165  1
    w_20_9    normalized_mass_20_179  1
    w_20_9    normalized_ratio_20_180  -1.125
    w_20_9    full_original_Gini_248  -4.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_166  -4.6801002878586309e-02
    x_20_10   product_ub_167  -1.1498973305966327e-01
    x_20_10   onehot_20_178  1
    x_20_10   stock_lb_188  10
    x_20_10   stock_ub_189  10
    x_20_10   parent_nonstrict_scope_190  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_166  1
    w_20_10   product_ub_167  1
    w_20_10   normalized_mass_20_179  1
    w_20_10   normalized_ratio_20_180  -1.25
    w_20_10   full_original_Gini_248  -6.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_168  -4.6801002878586309e-02
    x_20_11   product_ub_169  -1.1498973305966327e-01
    x_20_11   onehot_20_178  1
    x_20_11   stock_lb_188  11
    x_20_11   stock_ub_189  11
    x_20_11   parent_nonstrict_scope_190  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_168  1
    w_20_11   product_ub_169  1
    w_20_11   normalized_mass_20_179  1
    w_20_11   normalized_ratio_20_180  -1.375
    w_20_11   full_original_Gini_248  -7.8035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_170  -4.6801002878586309e-02
    x_20_12   product_ub_171  -1.1498973305966327e-01
    x_20_12   onehot_20_178  1
    x_20_12   stock_lb_188  12
    x_20_12   stock_ub_189  12
    x_20_12   parent_nonstrict_scope_190  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_170  1
    w_20_12   product_ub_171  1
    w_20_12   normalized_mass_20_179  1
    w_20_12   normalized_ratio_20_180  -1.5
    w_20_12   full_original_Gini_248  -9.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_172  -4.6801002878586309e-02
    x_20_13   product_ub_173  -1.1498973305966327e-01
    x_20_13   onehot_20_178  1
    x_20_13   stock_lb_188  13
    x_20_13   stock_ub_189  13
    x_20_13   parent_nonstrict_scope_190  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_172  1
    w_20_13   product_ub_173  1
    w_20_13   normalized_mass_20_179  1
    w_20_13   normalized_ratio_20_180  -1.625
    w_20_13   full_original_Gini_248  -1.0803571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_174  -4.6801002878586309e-02
    x_20_14   product_ub_175  -1.1498973305966327e-01
    x_20_14   onehot_20_178  1
    x_20_14   stock_lb_188  14
    x_20_14   stock_ub_189  14
    x_20_14   parent_nonstrict_scope_190  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_174  1
    w_20_14   product_ub_175  1
    w_20_14   normalized_mass_20_179  1
    w_20_14   normalized_ratio_20_180  -1.75
    w_20_14   full_original_Gini_248  -1.2303571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_176  -4.6801002878586309e-02
    x_20_15   product_ub_177  -1.1498973305966327e-01
    x_20_15   onehot_20_178  1
    x_20_15   stock_lb_188  15
    x_20_15   stock_ub_189  15
    x_20_15   parent_nonstrict_scope_190  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_176  1
    w_20_15   product_ub_177  1
    w_20_15   normalized_mass_20_179  1
    w_20_15   normalized_ratio_20_180  -1.875
    w_20_15   full_original_Gini_248  -1.3803571428571429e+01
    rho_20    normalized_ratio_20_180  1
    rho_20    block_pair_pos_197  1
    rho_20    block_pair_neg_198  -1
    rho_20    block_pair_pos_211  1
    rho_20    block_pair_neg_212  -1
    rho_20    block_pair_pos_215  1
    rho_20    block_pair_neg_216  -1
    rho_20    block_pair_pos_227  1
    rho_20    block_pair_neg_228  -1
    rho_20    block_pair_pos_233  1
    rho_20    block_pair_neg_234  -1
    rho_20    block_pair_pos_243  1
    rho_20    block_pair_neg_244  -1
    rho_20    block_pair_pos_245  -1
    rho_20    block_pair_neg_246  1
    rho_20    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       6.3380304899829966e-03
    x_6_0     product_lb_181  -4.6801002878586309e-02
    x_6_0     product_ub_182  -1.1498973305966327e-01
    x_6_0     onehot_6_185  1
    x_6_0     parent_nonstrict_scope_190  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_181  1
    w_6_0     product_ub_182  1
    w_6_0     normalized_mass_6_186  1
    w_6_0     full_original_Gini_248  -8.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       -6.3380304899829966e-03
    x_6_1     product_lb_183  -4.6801002878586309e-02
    x_6_1     product_ub_184  -1.1498973305966327e-01
    x_6_1     onehot_6_185  1
    x_6_1     stock_lb_188  1
    x_6_1     stock_ub_189  1
    x_6_1     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_183  1
    w_6_1     product_ub_184  1
    w_6_1     normalized_mass_6_186  1
    w_6_1     normalized_ratio_6_187  -1
    w_6_1     full_original_Gini_248  -3.8392857142857144e+00
    rho_6     normalized_ratio_6_187  1
    rho_6     block_pair_pos_191  1
    rho_6     block_pair_neg_192  -1
    rho_6     block_pair_pos_199  1
    rho_6     block_pair_neg_200  -1
    rho_6     block_pair_pos_213  1
    rho_6     block_pair_neg_214  -1
    rho_6     block_pair_pos_217  1
    rho_6     block_pair_neg_218  -1
    rho_6     block_pair_pos_229  1
    rho_6     block_pair_neg_230  -1
    rho_6     block_pair_pos_235  1
    rho_6     block_pair_neg_236  -1
    rho_6     block_pair_pos_245  1
    rho_6     block_pair_neg_246  -1
    rho_6     normalization_247  1
    a_9_11    block_pair_pos_205  1
    a_9_11    block_pair_neg_206  1
    a_9_11    full_original_Gini_248  -1
    a_9_18    block_pair_pos_209  1
    a_9_18    block_pair_neg_210  1
    a_9_18    full_original_Gini_248  -1
    a_9_7     block_pair_pos_201  1
    a_9_7     block_pair_neg_202  1
    a_9_7     full_original_Gini_248  -1
    a_9_17    block_pair_pos_207  1
    a_9_17    block_pair_neg_208  1
    a_9_17    full_original_Gini_248  -1
    a_9_10    block_pair_pos_203  1
    a_9_10    block_pair_neg_204  1
    a_9_10    full_original_Gini_248  -1
    a_9_20    block_pair_pos_211  1
    a_9_20    block_pair_neg_212  1
    a_9_20    full_original_Gini_248  -1
    a_9_6     block_pair_pos_199  1
    a_9_6     block_pair_neg_200  1
    a_9_6     full_original_Gini_248  -1
    a_11_18   block_pair_pos_225  1
    a_11_18   block_pair_neg_226  1
    a_11_18   full_original_Gini_248  -1
    a_11_7    block_pair_pos_219  1
    a_11_7    block_pair_neg_220  1
    a_11_7    full_original_Gini_248  -1
    a_11_17   block_pair_pos_223  1
    a_11_17   block_pair_neg_224  1
    a_11_17   full_original_Gini_248  -1
    a_11_10   block_pair_pos_221  1
    a_11_10   block_pair_neg_222  1
    a_11_10   full_original_Gini_248  -1
    a_11_20   block_pair_pos_227  1
    a_11_20   block_pair_neg_228  1
    a_11_20   full_original_Gini_248  -1
    a_11_6    block_pair_pos_217  1
    a_11_6    block_pair_neg_218  1
    a_11_6    full_original_Gini_248  -1
    a_18_7    block_pair_pos_237  1
    a_18_7    block_pair_neg_238  1
    a_18_7    full_original_Gini_248  -1
    a_18_17   block_pair_pos_241  1
    a_18_17   block_pair_neg_242  1
    a_18_17   full_original_Gini_248  -1
    a_18_10   block_pair_pos_239  1
    a_18_10   block_pair_neg_240  1
    a_18_10   full_original_Gini_248  -1
    a_18_20   block_pair_pos_243  1
    a_18_20   block_pair_neg_244  1
    a_18_20   full_original_Gini_248  -1
    a_18_6    block_pair_pos_235  1
    a_18_6    block_pair_neg_236  1
    a_18_6    full_original_Gini_248  -1
    a_7_17    block_pair_pos_195  1
    a_7_17    block_pair_neg_196  1
    a_7_17    full_original_Gini_248  -1
    a_7_10    block_pair_pos_193  1
    a_7_10    block_pair_neg_194  1
    a_7_10    full_original_Gini_248  -1
    a_7_20    block_pair_pos_197  1
    a_7_20    block_pair_neg_198  1
    a_7_20    full_original_Gini_248  -1
    a_7_6     block_pair_pos_191  1
    a_7_6     block_pair_neg_192  1
    a_7_6     full_original_Gini_248  -1
    a_17_10   block_pair_pos_231  1
    a_17_10   block_pair_neg_232  1
    a_17_10   full_original_Gini_248  -1
    a_17_20   block_pair_pos_233  1
    a_17_20   block_pair_neg_234  1
    a_17_20   full_original_Gini_248  -1
    a_17_6    block_pair_pos_229  1
    a_17_6    block_pair_neg_230  1
    a_17_6    full_original_Gini_248  -1
    a_10_20   block_pair_pos_215  1
    a_10_20   block_pair_neg_216  1
    a_10_20   full_original_Gini_248  -1
    a_10_6    block_pair_pos_213  1
    a_10_6    block_pair_neg_214  1
    a_10_6    full_original_Gini_248  -1
    a_20_6    block_pair_pos_245  1
    a_20_6    block_pair_neg_246  1
    a_20_6    full_original_Gini_248  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_9_1  unique_nonzero_owner_249  1
    service_0_9_1  service_visit_def_764  1
    service_0_9_1  free_load_conservation_765  1
    service_1_9_1  unique_nonzero_owner_249  1
    service_1_9_1  service_visit_def_1035  1
    service_1_9_1  free_load_conservation_1036  1
    service_0_11_0  unique_nonzero_owner_250  1
    service_0_11_0  service_visit_def_770  1
    service_0_11_0  free_load_conservation_771  -1
    service_0_11_0  original_T_including_depot_unload_813  120
    service_0_11_2  unique_nonzero_owner_251  1
    service_0_11_2  service_visit_def_770  1
    service_0_11_2  free_load_conservation_771  1
    service_0_11_3  unique_nonzero_owner_252  1
    service_0_11_3  service_visit_def_770  1
    service_0_11_3  free_load_conservation_771  2
    service_0_11_4  unique_nonzero_owner_253  1
    service_0_11_4  service_visit_def_770  1
    service_0_11_4  free_load_conservation_771  3
    service_0_11_5  unique_nonzero_owner_254  1
    service_0_11_5  service_visit_def_770  1
    service_0_11_5  free_load_conservation_771  4
    service_0_11_6  unique_nonzero_owner_255  1
    service_0_11_6  service_visit_def_770  1
    service_0_11_6  free_load_conservation_771  5
    service_0_11_7  unique_nonzero_owner_256  1
    service_0_11_7  service_visit_def_770  1
    service_0_11_7  free_load_conservation_771  6
    service_0_11_8  unique_nonzero_owner_257  1
    service_0_11_8  service_visit_def_770  1
    service_0_11_8  free_load_conservation_771  7
    service_0_11_9  unique_nonzero_owner_258  1
    service_0_11_9  service_visit_def_770  1
    service_0_11_9  free_load_conservation_771  8
    service_0_11_10  unique_nonzero_owner_259  1
    service_0_11_10  service_visit_def_770  1
    service_0_11_10  free_load_conservation_771  9
    service_0_11_11  unique_nonzero_owner_260  1
    service_0_11_11  service_visit_def_770  1
    service_0_11_11  free_load_conservation_771  10
    service_0_11_12  unique_nonzero_owner_261  1
    service_0_11_12  service_visit_def_770  1
    service_0_11_12  free_load_conservation_771  11
    service_0_11_13  unique_nonzero_owner_262  1
    service_0_11_13  service_visit_def_770  1
    service_0_11_13  free_load_conservation_771  12
    service_0_11_14  unique_nonzero_owner_263  1
    service_0_11_14  service_visit_def_770  1
    service_0_11_14  free_load_conservation_771  13
    service_0_11_15  unique_nonzero_owner_264  1
    service_0_11_15  service_visit_def_770  1
    service_0_11_15  free_load_conservation_771  14
    service_1_11_0  unique_nonzero_owner_250  1
    service_1_11_0  service_visit_def_1041  1
    service_1_11_0  free_load_conservation_1042  -1
    service_1_11_0  original_T_including_depot_unload_1080  120
    service_1_11_2  unique_nonzero_owner_251  1
    service_1_11_2  service_visit_def_1041  1
    service_1_11_2  free_load_conservation_1042  1
    service_1_11_3  unique_nonzero_owner_252  1
    service_1_11_3  service_visit_def_1041  1
    service_1_11_3  free_load_conservation_1042  2
    service_1_11_4  unique_nonzero_owner_253  1
    service_1_11_4  service_visit_def_1041  1
    service_1_11_4  free_load_conservation_1042  3
    service_1_11_5  unique_nonzero_owner_254  1
    service_1_11_5  service_visit_def_1041  1
    service_1_11_5  free_load_conservation_1042  4
    service_1_11_6  unique_nonzero_owner_255  1
    service_1_11_6  service_visit_def_1041  1
    service_1_11_6  free_load_conservation_1042  5
    service_1_11_7  unique_nonzero_owner_256  1
    service_1_11_7  service_visit_def_1041  1
    service_1_11_7  free_load_conservation_1042  6
    service_1_11_8  unique_nonzero_owner_257  1
    service_1_11_8  service_visit_def_1041  1
    service_1_11_8  free_load_conservation_1042  7
    service_1_11_9  unique_nonzero_owner_258  1
    service_1_11_9  service_visit_def_1041  1
    service_1_11_9  free_load_conservation_1042  8
    service_1_11_10  unique_nonzero_owner_259  1
    service_1_11_10  service_visit_def_1041  1
    service_1_11_10  free_load_conservation_1042  9
    service_1_11_11  unique_nonzero_owner_260  1
    service_1_11_11  service_visit_def_1041  1
    service_1_11_11  free_load_conservation_1042  10
    service_1_11_12  unique_nonzero_owner_261  1
    service_1_11_12  service_visit_def_1041  1
    service_1_11_12  free_load_conservation_1042  11
    service_1_11_13  unique_nonzero_owner_262  1
    service_1_11_13  service_visit_def_1041  1
    service_1_11_13  free_load_conservation_1042  12
    service_1_11_14  unique_nonzero_owner_263  1
    service_1_11_14  service_visit_def_1041  1
    service_1_11_14  free_load_conservation_1042  13
    service_1_11_15  unique_nonzero_owner_264  1
    service_1_11_15  service_visit_def_1041  1
    service_1_11_15  free_load_conservation_1042  14
    service_0_18_1  unique_nonzero_owner_265  1
    service_0_18_1  service_visit_def_776  1
    service_0_18_1  free_load_conservation_777  1
    service_0_18_2  unique_nonzero_owner_266  1
    service_0_18_2  service_visit_def_776  1
    service_0_18_2  free_load_conservation_777  2
    service_0_18_3  unique_nonzero_owner_267  1
    service_0_18_3  service_visit_def_776  1
    service_0_18_3  free_load_conservation_777  3
    service_0_18_4  unique_nonzero_owner_268  1
    service_0_18_4  service_visit_def_776  1
    service_0_18_4  free_load_conservation_777  4
    service_0_18_5  unique_nonzero_owner_269  1
    service_0_18_5  service_visit_def_776  1
    service_0_18_5  free_load_conservation_777  5
    service_0_18_6  unique_nonzero_owner_270  1
    service_0_18_6  service_visit_def_776  1
    service_0_18_6  free_load_conservation_777  6
    service_0_18_7  unique_nonzero_owner_271  1
    service_0_18_7  service_visit_def_776  1
    service_0_18_7  free_load_conservation_777  7
    service_0_18_8  unique_nonzero_owner_272  1
    service_0_18_8  service_visit_def_776  1
    service_0_18_8  free_load_conservation_777  8
    service_0_18_9  unique_nonzero_owner_273  1
    service_0_18_9  service_visit_def_776  1
    service_0_18_9  free_load_conservation_777  9
    service_0_18_10  unique_nonzero_owner_274  1
    service_0_18_10  service_visit_def_776  1
    service_0_18_10  free_load_conservation_777  10
    service_0_18_11  unique_nonzero_owner_275  1
    service_0_18_11  service_visit_def_776  1
    service_0_18_11  free_load_conservation_777  11
    service_0_18_12  unique_nonzero_owner_276  1
    service_0_18_12  service_visit_def_776  1
    service_0_18_12  free_load_conservation_777  12
    service_0_18_13  unique_nonzero_owner_277  1
    service_0_18_13  service_visit_def_776  1
    service_0_18_13  free_load_conservation_777  13
    service_0_18_14  unique_nonzero_owner_278  1
    service_0_18_14  service_visit_def_776  1
    service_0_18_14  free_load_conservation_777  14
    service_0_18_15  unique_nonzero_owner_279  1
    service_0_18_15  service_visit_def_776  1
    service_0_18_15  free_load_conservation_777  15
    service_1_18_1  unique_nonzero_owner_265  1
    service_1_18_1  service_visit_def_1047  1
    service_1_18_1  free_load_conservation_1048  1
    service_1_18_2  unique_nonzero_owner_266  1
    service_1_18_2  service_visit_def_1047  1
    service_1_18_2  free_load_conservation_1048  2
    service_1_18_3  unique_nonzero_owner_267  1
    service_1_18_3  service_visit_def_1047  1
    service_1_18_3  free_load_conservation_1048  3
    service_1_18_4  unique_nonzero_owner_268  1
    service_1_18_4  service_visit_def_1047  1
    service_1_18_4  free_load_conservation_1048  4
    service_1_18_5  unique_nonzero_owner_269  1
    service_1_18_5  service_visit_def_1047  1
    service_1_18_5  free_load_conservation_1048  5
    service_1_18_6  unique_nonzero_owner_270  1
    service_1_18_6  service_visit_def_1047  1
    service_1_18_6  free_load_conservation_1048  6
    service_1_18_7  unique_nonzero_owner_271  1
    service_1_18_7  service_visit_def_1047  1
    service_1_18_7  free_load_conservation_1048  7
    service_1_18_8  unique_nonzero_owner_272  1
    service_1_18_8  service_visit_def_1047  1
    service_1_18_8  free_load_conservation_1048  8
    service_1_18_9  unique_nonzero_owner_273  1
    service_1_18_9  service_visit_def_1047  1
    service_1_18_9  free_load_conservation_1048  9
    service_1_18_10  unique_nonzero_owner_274  1
    service_1_18_10  service_visit_def_1047  1
    service_1_18_10  free_load_conservation_1048  10
    service_1_18_11  unique_nonzero_owner_275  1
    service_1_18_11  service_visit_def_1047  1
    service_1_18_11  free_load_conservation_1048  11
    service_1_18_12  unique_nonzero_owner_276  1
    service_1_18_12  service_visit_def_1047  1
    service_1_18_12  free_load_conservation_1048  12
    service_1_18_13  unique_nonzero_owner_277  1
    service_1_18_13  service_visit_def_1047  1
    service_1_18_13  free_load_conservation_1048  13
    service_1_18_14  unique_nonzero_owner_278  1
    service_1_18_14  service_visit_def_1047  1
    service_1_18_14  free_load_conservation_1048  14
    service_1_18_15  unique_nonzero_owner_279  1
    service_1_18_15  service_visit_def_1047  1
    service_1_18_15  free_load_conservation_1048  15
    service_0_7_0  unique_nonzero_owner_280  1
    service_0_7_0  service_visit_def_782  1
    service_0_7_0  free_load_conservation_783  -1
    service_0_7_0  original_T_including_depot_unload_813  120
    service_0_7_2  unique_nonzero_owner_281  1
    service_0_7_2  service_visit_def_782  1
    service_0_7_2  free_load_conservation_783  1
    service_0_7_3  unique_nonzero_owner_282  1
    service_0_7_3  service_visit_def_782  1
    service_0_7_3  free_load_conservation_783  2
    service_0_7_4  unique_nonzero_owner_283  1
    service_0_7_4  service_visit_def_782  1
    service_0_7_4  free_load_conservation_783  3
    service_0_7_5  unique_nonzero_owner_284  1
    service_0_7_5  service_visit_def_782  1
    service_0_7_5  free_load_conservation_783  4
    service_0_7_6  unique_nonzero_owner_285  1
    service_0_7_6  service_visit_def_782  1
    service_0_7_6  free_load_conservation_783  5
    service_0_7_7  unique_nonzero_owner_286  1
    service_0_7_7  service_visit_def_782  1
    service_0_7_7  free_load_conservation_783  6
    service_0_7_8  unique_nonzero_owner_287  1
    service_0_7_8  service_visit_def_782  1
    service_0_7_8  free_load_conservation_783  7
    service_0_7_9  unique_nonzero_owner_288  1
    service_0_7_9  service_visit_def_782  1
    service_0_7_9  free_load_conservation_783  8
    service_0_7_10  unique_nonzero_owner_289  1
    service_0_7_10  service_visit_def_782  1
    service_0_7_10  free_load_conservation_783  9
    service_1_7_0  unique_nonzero_owner_280  1
    service_1_7_0  service_visit_def_1053  1
    service_1_7_0  free_load_conservation_1054  -1
    service_1_7_0  original_T_including_depot_unload_1080  120
    service_1_7_2  unique_nonzero_owner_281  1
    service_1_7_2  service_visit_def_1053  1
    service_1_7_2  free_load_conservation_1054  1
    service_1_7_3  unique_nonzero_owner_282  1
    service_1_7_3  service_visit_def_1053  1
    service_1_7_3  free_load_conservation_1054  2
    service_1_7_4  unique_nonzero_owner_283  1
    service_1_7_4  service_visit_def_1053  1
    service_1_7_4  free_load_conservation_1054  3
    service_1_7_5  unique_nonzero_owner_284  1
    service_1_7_5  service_visit_def_1053  1
    service_1_7_5  free_load_conservation_1054  4
    service_1_7_6  unique_nonzero_owner_285  1
    service_1_7_6  service_visit_def_1053  1
    service_1_7_6  free_load_conservation_1054  5
    service_1_7_7  unique_nonzero_owner_286  1
    service_1_7_7  service_visit_def_1053  1
    service_1_7_7  free_load_conservation_1054  6
    service_1_7_8  unique_nonzero_owner_287  1
    service_1_7_8  service_visit_def_1053  1
    service_1_7_8  free_load_conservation_1054  7
    service_1_7_9  unique_nonzero_owner_288  1
    service_1_7_9  service_visit_def_1053  1
    service_1_7_9  free_load_conservation_1054  8
    service_1_7_10  unique_nonzero_owner_289  1
    service_1_7_10  service_visit_def_1053  1
    service_1_7_10  free_load_conservation_1054  9
    service_0_17_0  unique_nonzero_owner_290  1
    service_0_17_0  service_visit_def_788  1
    service_0_17_0  free_load_conservation_789  -3
    service_0_17_0  original_T_including_depot_unload_813  360
    service_0_17_1  unique_nonzero_owner_291  1
    service_0_17_1  service_visit_def_788  1
    service_0_17_1  free_load_conservation_789  -2
    service_0_17_1  original_T_including_depot_unload_813  240
    service_0_17_2  unique_nonzero_owner_292  1
    service_0_17_2  service_visit_def_788  1
    service_0_17_2  free_load_conservation_789  -1
    service_0_17_2  original_T_including_depot_unload_813  120
    service_0_17_4  unique_nonzero_owner_293  1
    service_0_17_4  service_visit_def_788  1
    service_0_17_4  free_load_conservation_789  1
    service_0_17_5  unique_nonzero_owner_294  1
    service_0_17_5  service_visit_def_788  1
    service_0_17_5  free_load_conservation_789  2
    service_0_17_6  unique_nonzero_owner_295  1
    service_0_17_6  service_visit_def_788  1
    service_0_17_6  free_load_conservation_789  3
    service_0_17_7  unique_nonzero_owner_296  1
    service_0_17_7  service_visit_def_788  1
    service_0_17_7  free_load_conservation_789  4
    service_0_17_8  unique_nonzero_owner_297  1
    service_0_17_8  service_visit_def_788  1
    service_0_17_8  free_load_conservation_789  5
    service_0_17_9  unique_nonzero_owner_298  1
    service_0_17_9  service_visit_def_788  1
    service_0_17_9  free_load_conservation_789  6
    service_0_17_10  unique_nonzero_owner_299  1
    service_0_17_10  service_visit_def_788  1
    service_0_17_10  free_load_conservation_789  7
    service_0_17_11  unique_nonzero_owner_300  1
    service_0_17_11  service_visit_def_788  1
    service_0_17_11  free_load_conservation_789  8
    service_0_17_12  unique_nonzero_owner_301  1
    service_0_17_12  service_visit_def_788  1
    service_0_17_12  free_load_conservation_789  9
    service_0_17_13  unique_nonzero_owner_302  1
    service_0_17_13  service_visit_def_788  1
    service_0_17_13  free_load_conservation_789  10
    service_0_17_14  unique_nonzero_owner_303  1
    service_0_17_14  service_visit_def_788  1
    service_0_17_14  free_load_conservation_789  11
    service_0_17_15  unique_nonzero_owner_304  1
    service_0_17_15  service_visit_def_788  1
    service_0_17_15  free_load_conservation_789  12
    service_0_17_16  unique_nonzero_owner_305  1
    service_0_17_16  service_visit_def_788  1
    service_0_17_16  free_load_conservation_789  13
    service_1_17_0  unique_nonzero_owner_290  1
    service_1_17_0  service_visit_def_1059  1
    service_1_17_0  free_load_conservation_1060  -3
    service_1_17_0  original_T_including_depot_unload_1080  360
    service_1_17_1  unique_nonzero_owner_291  1
    service_1_17_1  service_visit_def_1059  1
    service_1_17_1  free_load_conservation_1060  -2
    service_1_17_1  original_T_including_depot_unload_1080  240
    service_1_17_2  unique_nonzero_owner_292  1
    service_1_17_2  service_visit_def_1059  1
    service_1_17_2  free_load_conservation_1060  -1
    service_1_17_2  original_T_including_depot_unload_1080  120
    service_1_17_4  unique_nonzero_owner_293  1
    service_1_17_4  service_visit_def_1059  1
    service_1_17_4  free_load_conservation_1060  1
    service_1_17_5  unique_nonzero_owner_294  1
    service_1_17_5  service_visit_def_1059  1
    service_1_17_5  free_load_conservation_1060  2
    service_1_17_6  unique_nonzero_owner_295  1
    service_1_17_6  service_visit_def_1059  1
    service_1_17_6  free_load_conservation_1060  3
    service_1_17_7  unique_nonzero_owner_296  1
    service_1_17_7  service_visit_def_1059  1
    service_1_17_7  free_load_conservation_1060  4
    service_1_17_8  unique_nonzero_owner_297  1
    service_1_17_8  service_visit_def_1059  1
    service_1_17_8  free_load_conservation_1060  5
    service_1_17_9  unique_nonzero_owner_298  1
    service_1_17_9  service_visit_def_1059  1
    service_1_17_9  free_load_conservation_1060  6
    service_1_17_10  unique_nonzero_owner_299  1
    service_1_17_10  service_visit_def_1059  1
    service_1_17_10  free_load_conservation_1060  7
    service_1_17_11  unique_nonzero_owner_300  1
    service_1_17_11  service_visit_def_1059  1
    service_1_17_11  free_load_conservation_1060  8
    service_1_17_12  unique_nonzero_owner_301  1
    service_1_17_12  service_visit_def_1059  1
    service_1_17_12  free_load_conservation_1060  9
    service_1_17_13  unique_nonzero_owner_302  1
    service_1_17_13  service_visit_def_1059  1
    service_1_17_13  free_load_conservation_1060  10
    service_1_17_14  unique_nonzero_owner_303  1
    service_1_17_14  service_visit_def_1059  1
    service_1_17_14  free_load_conservation_1060  11
    service_1_17_15  unique_nonzero_owner_304  1
    service_1_17_15  service_visit_def_1059  1
    service_1_17_15  free_load_conservation_1060  12
    service_1_17_16  unique_nonzero_owner_305  1
    service_1_17_16  service_visit_def_1059  1
    service_1_17_16  free_load_conservation_1060  13
    service_0_10_1  unique_nonzero_owner_306  1
    service_0_10_1  service_visit_def_794  1
    service_0_10_1  free_load_conservation_795  1
    service_1_10_1  unique_nonzero_owner_306  1
    service_1_10_1  service_visit_def_1065  1
    service_1_10_1  free_load_conservation_1066  1
    service_0_20_0  unique_nonzero_owner_307  1
    service_0_20_0  service_visit_def_800  1
    service_0_20_0  free_load_conservation_801  -12
    service_0_20_0  original_T_including_depot_unload_813  1440
    service_0_20_1  unique_nonzero_owner_308  1
    service_0_20_1  service_visit_def_800  1
    service_0_20_1  free_load_conservation_801  -11
    service_0_20_1  original_T_including_depot_unload_813  1320
    service_0_20_2  unique_nonzero_owner_309  1
    service_0_20_2  service_visit_def_800  1
    service_0_20_2  free_load_conservation_801  -10
    service_0_20_2  original_T_including_depot_unload_813  1200
    service_0_20_3  unique_nonzero_owner_310  1
    service_0_20_3  service_visit_def_800  1
    service_0_20_3  free_load_conservation_801  -9
    service_0_20_3  original_T_including_depot_unload_813  1080
    service_0_20_4  unique_nonzero_owner_311  1
    service_0_20_4  service_visit_def_800  1
    service_0_20_4  free_load_conservation_801  -8
    service_0_20_4  original_T_including_depot_unload_813  960
    service_0_20_5  unique_nonzero_owner_312  1
    service_0_20_5  service_visit_def_800  1
    service_0_20_5  free_load_conservation_801  -7
    service_0_20_5  original_T_including_depot_unload_813  840
    service_0_20_6  unique_nonzero_owner_313  1
    service_0_20_6  service_visit_def_800  1
    service_0_20_6  free_load_conservation_801  -6
    service_0_20_6  original_T_including_depot_unload_813  720
    service_0_20_7  unique_nonzero_owner_314  1
    service_0_20_7  service_visit_def_800  1
    service_0_20_7  free_load_conservation_801  -5
    service_0_20_7  original_T_including_depot_unload_813  600
    service_0_20_8  unique_nonzero_owner_315  1
    service_0_20_8  service_visit_def_800  1
    service_0_20_8  free_load_conservation_801  -4
    service_0_20_8  original_T_including_depot_unload_813  480
    service_0_20_9  unique_nonzero_owner_316  1
    service_0_20_9  service_visit_def_800  1
    service_0_20_9  free_load_conservation_801  -3
    service_0_20_9  original_T_including_depot_unload_813  360
    service_0_20_10  unique_nonzero_owner_317  1
    service_0_20_10  service_visit_def_800  1
    service_0_20_10  free_load_conservation_801  -2
    service_0_20_10  original_T_including_depot_unload_813  240
    service_0_20_11  unique_nonzero_owner_318  1
    service_0_20_11  service_visit_def_800  1
    service_0_20_11  free_load_conservation_801  -1
    service_0_20_11  original_T_including_depot_unload_813  120
    service_0_20_13  unique_nonzero_owner_319  1
    service_0_20_13  service_visit_def_800  1
    service_0_20_13  free_load_conservation_801  1
    service_0_20_14  unique_nonzero_owner_320  1
    service_0_20_14  service_visit_def_800  1
    service_0_20_14  free_load_conservation_801  2
    service_0_20_15  unique_nonzero_owner_321  1
    service_0_20_15  service_visit_def_800  1
    service_0_20_15  free_load_conservation_801  3
    service_1_20_0  unique_nonzero_owner_307  1
    service_1_20_0  service_visit_def_1071  1
    service_1_20_0  free_load_conservation_1072  -12
    service_1_20_0  original_T_including_depot_unload_1080  1440
    service_1_20_1  unique_nonzero_owner_308  1
    service_1_20_1  service_visit_def_1071  1
    service_1_20_1  free_load_conservation_1072  -11
    service_1_20_1  original_T_including_depot_unload_1080  1320
    service_1_20_2  unique_nonzero_owner_309  1
    service_1_20_2  service_visit_def_1071  1
    service_1_20_2  free_load_conservation_1072  -10
    service_1_20_2  original_T_including_depot_unload_1080  1200
    service_1_20_3  unique_nonzero_owner_310  1
    service_1_20_3  service_visit_def_1071  1
    service_1_20_3  free_load_conservation_1072  -9
    service_1_20_3  original_T_including_depot_unload_1080  1080
    service_1_20_4  unique_nonzero_owner_311  1
    service_1_20_4  service_visit_def_1071  1
    service_1_20_4  free_load_conservation_1072  -8
    service_1_20_4  original_T_including_depot_unload_1080  960
    service_1_20_5  unique_nonzero_owner_312  1
    service_1_20_5  service_visit_def_1071  1
    service_1_20_5  free_load_conservation_1072  -7
    service_1_20_5  original_T_including_depot_unload_1080  840
    service_1_20_6  unique_nonzero_owner_313  1
    service_1_20_6  service_visit_def_1071  1
    service_1_20_6  free_load_conservation_1072  -6
    service_1_20_6  original_T_including_depot_unload_1080  720
    service_1_20_7  unique_nonzero_owner_314  1
    service_1_20_7  service_visit_def_1071  1
    service_1_20_7  free_load_conservation_1072  -5
    service_1_20_7  original_T_including_depot_unload_1080  600
    service_1_20_8  unique_nonzero_owner_315  1
    service_1_20_8  service_visit_def_1071  1
    service_1_20_8  free_load_conservation_1072  -4
    service_1_20_8  original_T_including_depot_unload_1080  480
    service_1_20_9  unique_nonzero_owner_316  1
    service_1_20_9  service_visit_def_1071  1
    service_1_20_9  free_load_conservation_1072  -3
    service_1_20_9  original_T_including_depot_unload_1080  360
    service_1_20_10  unique_nonzero_owner_317  1
    service_1_20_10  service_visit_def_1071  1
    service_1_20_10  free_load_conservation_1072  -2
    service_1_20_10  original_T_including_depot_unload_1080  240
    service_1_20_11  unique_nonzero_owner_318  1
    service_1_20_11  service_visit_def_1071  1
    service_1_20_11  free_load_conservation_1072  -1
    service_1_20_11  original_T_including_depot_unload_1080  120
    service_1_20_13  unique_nonzero_owner_319  1
    service_1_20_13  service_visit_def_1071  1
    service_1_20_13  free_load_conservation_1072  1
    service_1_20_14  unique_nonzero_owner_320  1
    service_1_20_14  service_visit_def_1071  1
    service_1_20_14  free_load_conservation_1072  2
    service_1_20_15  unique_nonzero_owner_321  1
    service_1_20_15  service_visit_def_1071  1
    service_1_20_15  free_load_conservation_1072  3
    service_0_6_1  unique_nonzero_owner_322  1
    service_0_6_1  service_visit_def_806  1
    service_0_6_1  free_load_conservation_807  1
    service_1_6_1  unique_nonzero_owner_322  1
    service_1_6_1  service_visit_def_1077  1
    service_1_6_1  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_718  -1
    visit_0_1  in_degree_719  -1
    visit_0_1  order_active_lb_720  -1
    visit_0_1  order_active_ub_721  -14
    order_0_1  connected_order_arc_340  -1
    order_0_1  connected_order_arc_342  -1
    order_0_1  connected_order_arc_344  -1
    order_0_1  connected_order_arc_346  -1
    order_0_1  connected_order_arc_348  -1
    order_0_1  connected_order_arc_350  -1
    order_0_1  connected_order_arc_352  -1
    order_0_1  connected_order_arc_354  -1
    order_0_1  connected_order_arc_356  -1
    order_0_1  connected_order_arc_358  -1
    order_0_1  connected_order_arc_360  -1
    order_0_1  connected_order_arc_362  -1
    order_0_1  connected_order_arc_364  -1
    order_0_1  connected_order_arc_367  1
    order_0_1  connected_order_arc_394  1
    order_0_1  connected_order_arc_421  1
    order_0_1  connected_order_arc_448  1
    order_0_1  connected_order_arc_475  1
    order_0_1  connected_order_arc_502  1
    order_0_1  connected_order_arc_529  1
    order_0_1  connected_order_arc_556  1
    order_0_1  connected_order_arc_583  1
    order_0_1  connected_order_arc_610  1
    order_0_1  connected_order_arc_637  1
    order_0_1  connected_order_arc_664  1
    order_0_1  connected_order_arc_691  1
    order_0_1  order_active_lb_720  1
    order_0_1  order_active_ub_721  1
    order_0_1  fixed_segment_relative_order_808  -1
    visit_0_2  out_degree_725  -1
    visit_0_2  in_degree_726  -1
    visit_0_2  order_active_lb_727  -1
    visit_0_2  order_active_ub_728  -14
    order_0_2  connected_order_arc_340  1
    order_0_2  connected_order_arc_367  -1
    order_0_2  connected_order_arc_369  -1
    order_0_2  connected_order_arc_371  -1
    order_0_2  connected_order_arc_373  -1
    order_0_2  connected_order_arc_375  -1
    order_0_2  connected_order_arc_377  -1
    order_0_2  connected_order_arc_379  -1
    order_0_2  connected_order_arc_381  -1
    order_0_2  connected_order_arc_383  -1
    order_0_2  connected_order_arc_385  -1
    order_0_2  connected_order_arc_387  -1
    order_0_2  connected_order_arc_389  -1
    order_0_2  connected_order_arc_391  -1
    order_0_2  connected_order_arc_396  1
    order_0_2  connected_order_arc_423  1
    order_0_2  connected_order_arc_450  1
    order_0_2  connected_order_arc_477  1
    order_0_2  connected_order_arc_504  1
    order_0_2  connected_order_arc_531  1
    order_0_2  connected_order_arc_558  1
    order_0_2  connected_order_arc_585  1
    order_0_2  connected_order_arc_612  1
    order_0_2  connected_order_arc_639  1
    order_0_2  connected_order_arc_666  1
    order_0_2  connected_order_arc_693  1
    order_0_2  order_active_lb_727  1
    order_0_2  order_active_ub_728  1
    order_0_2  fixed_segment_relative_order_808  1
    order_0_2  fixed_segment_relative_order_809  -1
    visit_0_3  out_degree_732  -1
    visit_0_3  in_degree_733  -1
    visit_0_3  order_active_lb_734  -1
    visit_0_3  order_active_ub_735  -14
    order_0_3  connected_order_arc_342  1
    order_0_3  connected_order_arc_369  1
    order_0_3  connected_order_arc_394  -1
    order_0_3  connected_order_arc_396  -1
    order_0_3  connected_order_arc_398  -1
    order_0_3  connected_order_arc_400  -1
    order_0_3  connected_order_arc_402  -1
    order_0_3  connected_order_arc_404  -1
    order_0_3  connected_order_arc_406  -1
    order_0_3  connected_order_arc_408  -1
    order_0_3  connected_order_arc_410  -1
    order_0_3  connected_order_arc_412  -1
    order_0_3  connected_order_arc_414  -1
    order_0_3  connected_order_arc_416  -1
    order_0_3  connected_order_arc_418  -1
    order_0_3  connected_order_arc_425  1
    order_0_3  connected_order_arc_452  1
    order_0_3  connected_order_arc_479  1
    order_0_3  connected_order_arc_506  1
    order_0_3  connected_order_arc_533  1
    order_0_3  connected_order_arc_560  1
    order_0_3  connected_order_arc_587  1
    order_0_3  connected_order_arc_614  1
    order_0_3  connected_order_arc_641  1
    order_0_3  connected_order_arc_668  1
    order_0_3  connected_order_arc_695  1
    order_0_3  order_active_lb_734  1
    order_0_3  order_active_ub_735  1
    order_0_3  fixed_segment_relative_order_809  1
    order_0_3  fixed_segment_relative_order_810  -1
    visit_0_4  out_degree_739  -1
    visit_0_4  in_degree_740  -1
    visit_0_4  order_active_lb_741  -1
    visit_0_4  order_active_ub_742  -14
    order_0_4  connected_order_arc_344  1
    order_0_4  connected_order_arc_371  1
    order_0_4  connected_order_arc_398  1
    order_0_4  connected_order_arc_421  -1
    order_0_4  connected_order_arc_423  -1
    order_0_4  connected_order_arc_425  -1
    order_0_4  connected_order_arc_427  -1
    order_0_4  connected_order_arc_429  -1
    order_0_4  connected_order_arc_431  -1
    order_0_4  connected_order_arc_433  -1
    order_0_4  connected_order_arc_435  -1
    order_0_4  connected_order_arc_437  -1
    order_0_4  connected_order_arc_439  -1
    order_0_4  connected_order_arc_441  -1
    order_0_4  connected_order_arc_443  -1
    order_0_4  connected_order_arc_445  -1
    order_0_4  connected_order_arc_454  1
    order_0_4  connected_order_arc_481  1
    order_0_4  connected_order_arc_508  1
    order_0_4  connected_order_arc_535  1
    order_0_4  connected_order_arc_562  1
    order_0_4  connected_order_arc_589  1
    order_0_4  connected_order_arc_616  1
    order_0_4  connected_order_arc_643  1
    order_0_4  connected_order_arc_670  1
    order_0_4  connected_order_arc_697  1
    order_0_4  order_active_lb_741  1
    order_0_4  order_active_ub_742  1
    order_0_4  fixed_segment_relative_order_810  1
    order_0_4  fixed_segment_relative_order_811  -1
    visit_0_5  out_degree_746  -1
    visit_0_5  in_degree_747  -1
    visit_0_5  order_active_lb_748  -1
    visit_0_5  order_active_ub_749  -14
    order_0_5  connected_order_arc_346  1
    order_0_5  connected_order_arc_373  1
    order_0_5  connected_order_arc_400  1
    order_0_5  connected_order_arc_427  1
    order_0_5  connected_order_arc_448  -1
    order_0_5  connected_order_arc_450  -1
    order_0_5  connected_order_arc_452  -1
    order_0_5  connected_order_arc_454  -1
    order_0_5  connected_order_arc_456  -1
    order_0_5  connected_order_arc_458  -1
    order_0_5  connected_order_arc_460  -1
    order_0_5  connected_order_arc_462  -1
    order_0_5  connected_order_arc_464  -1
    order_0_5  connected_order_arc_466  -1
    order_0_5  connected_order_arc_468  -1
    order_0_5  connected_order_arc_470  -1
    order_0_5  connected_order_arc_472  -1
    order_0_5  connected_order_arc_483  1
    order_0_5  connected_order_arc_510  1
    order_0_5  connected_order_arc_537  1
    order_0_5  connected_order_arc_564  1
    order_0_5  connected_order_arc_591  1
    order_0_5  connected_order_arc_618  1
    order_0_5  connected_order_arc_645  1
    order_0_5  connected_order_arc_672  1
    order_0_5  connected_order_arc_699  1
    order_0_5  order_active_lb_748  1
    order_0_5  order_active_ub_749  1
    order_0_5  fixed_segment_relative_order_811  1
    order_0_5  fixed_segment_relative_order_812  -1
    visit_0_6  out_degree_753  -1
    visit_0_6  in_degree_754  -1
    visit_0_6  order_active_lb_755  -1
    visit_0_6  order_active_ub_756  -14
    order_0_6  connected_order_arc_348  1
    order_0_6  connected_order_arc_375  1
    order_0_6  connected_order_arc_402  1
    order_0_6  connected_order_arc_429  1
    order_0_6  connected_order_arc_456  1
    order_0_6  connected_order_arc_475  -1
    order_0_6  connected_order_arc_477  -1
    order_0_6  connected_order_arc_479  -1
    order_0_6  connected_order_arc_481  -1
    order_0_6  connected_order_arc_483  -1
    order_0_6  connected_order_arc_485  -1
    order_0_6  connected_order_arc_487  -1
    order_0_6  connected_order_arc_489  -1
    order_0_6  connected_order_arc_491  -1
    order_0_6  connected_order_arc_493  -1
    order_0_6  connected_order_arc_495  -1
    order_0_6  connected_order_arc_497  -1
    order_0_6  connected_order_arc_499  -1
    order_0_6  connected_order_arc_512  1
    order_0_6  connected_order_arc_539  1
    order_0_6  connected_order_arc_566  1
    order_0_6  connected_order_arc_593  1
    order_0_6  connected_order_arc_620  1
    order_0_6  connected_order_arc_647  1
    order_0_6  connected_order_arc_674  1
    order_0_6  connected_order_arc_701  1
    order_0_6  order_active_lb_755  1
    order_0_6  order_active_ub_756  1
    order_0_6  fixed_segment_relative_order_812  1
    visit_0_9  out_degree_760  -1
    visit_0_9  in_degree_761  -1
    visit_0_9  order_active_lb_762  -1
    visit_0_9  order_active_ub_763  -14
    visit_0_9  service_visit_def_764  -1
    order_0_9  connected_order_arc_350  1
    order_0_9  connected_order_arc_377  1
    order_0_9  connected_order_arc_404  1
    order_0_9  connected_order_arc_431  1
    order_0_9  connected_order_arc_458  1
    order_0_9  connected_order_arc_485  1
    order_0_9  connected_order_arc_502  -1
    order_0_9  connected_order_arc_504  -1
    order_0_9  connected_order_arc_506  -1
    order_0_9  connected_order_arc_508  -1
    order_0_9  connected_order_arc_510  -1
    order_0_9  connected_order_arc_512  -1
    order_0_9  connected_order_arc_514  -1
    order_0_9  connected_order_arc_516  -1
    order_0_9  connected_order_arc_518  -1
    order_0_9  connected_order_arc_520  -1
    order_0_9  connected_order_arc_522  -1
    order_0_9  connected_order_arc_524  -1
    order_0_9  connected_order_arc_526  -1
    order_0_9  connected_order_arc_541  1
    order_0_9  connected_order_arc_568  1
    order_0_9  connected_order_arc_595  1
    order_0_9  connected_order_arc_622  1
    order_0_9  connected_order_arc_649  1
    order_0_9  connected_order_arc_676  1
    order_0_9  connected_order_arc_703  1
    order_0_9  order_active_lb_762  1
    order_0_9  order_active_ub_763  1
    visit_0_10  out_degree_766  -1
    visit_0_10  in_degree_767  -1
    visit_0_10  order_active_lb_768  -1
    visit_0_10  order_active_ub_769  -14
    visit_0_10  service_visit_def_770  -1
    order_0_10  connected_order_arc_352  1
    order_0_10  connected_order_arc_379  1
    order_0_10  connected_order_arc_406  1
    order_0_10  connected_order_arc_433  1
    order_0_10  connected_order_arc_460  1
    order_0_10  connected_order_arc_487  1
    order_0_10  connected_order_arc_514  1
    order_0_10  connected_order_arc_529  -1
    order_0_10  connected_order_arc_531  -1
    order_0_10  connected_order_arc_533  -1
    order_0_10  connected_order_arc_535  -1
    order_0_10  connected_order_arc_537  -1
    order_0_10  connected_order_arc_539  -1
    order_0_10  connected_order_arc_541  -1
    order_0_10  connected_order_arc_543  -1
    order_0_10  connected_order_arc_545  -1
    order_0_10  connected_order_arc_547  -1
    order_0_10  connected_order_arc_549  -1
    order_0_10  connected_order_arc_551  -1
    order_0_10  connected_order_arc_553  -1
    order_0_10  connected_order_arc_570  1
    order_0_10  connected_order_arc_597  1
    order_0_10  connected_order_arc_624  1
    order_0_10  connected_order_arc_651  1
    order_0_10  connected_order_arc_678  1
    order_0_10  connected_order_arc_705  1
    order_0_10  order_active_lb_768  1
    order_0_10  order_active_ub_769  1
    visit_0_11  out_degree_772  -1
    visit_0_11  in_degree_773  -1
    visit_0_11  order_active_lb_774  -1
    visit_0_11  order_active_ub_775  -14
    visit_0_11  service_visit_def_776  -1
    order_0_11  connected_order_arc_354  1
    order_0_11  connected_order_arc_381  1
    order_0_11  connected_order_arc_408  1
    order_0_11  connected_order_arc_435  1
    order_0_11  connected_order_arc_462  1
    order_0_11  connected_order_arc_489  1
    order_0_11  connected_order_arc_516  1
    order_0_11  connected_order_arc_543  1
    order_0_11  connected_order_arc_556  -1
    order_0_11  connected_order_arc_558  -1
    order_0_11  connected_order_arc_560  -1
    order_0_11  connected_order_arc_562  -1
    order_0_11  connected_order_arc_564  -1
    order_0_11  connected_order_arc_566  -1
    order_0_11  connected_order_arc_568  -1
    order_0_11  connected_order_arc_570  -1
    order_0_11  connected_order_arc_572  -1
    order_0_11  connected_order_arc_574  -1
    order_0_11  connected_order_arc_576  -1
    order_0_11  connected_order_arc_578  -1
    order_0_11  connected_order_arc_580  -1
    order_0_11  connected_order_arc_599  1
    order_0_11  connected_order_arc_626  1
    order_0_11  connected_order_arc_653  1
    order_0_11  connected_order_arc_680  1
    order_0_11  connected_order_arc_707  1
    order_0_11  order_active_lb_774  1
    order_0_11  order_active_ub_775  1
    visit_0_12  out_degree_778  -1
    visit_0_12  in_degree_779  -1
    visit_0_12  order_active_lb_780  -1
    visit_0_12  order_active_ub_781  -14
    visit_0_12  service_visit_def_782  -1
    order_0_12  connected_order_arc_356  1
    order_0_12  connected_order_arc_383  1
    order_0_12  connected_order_arc_410  1
    order_0_12  connected_order_arc_437  1
    order_0_12  connected_order_arc_464  1
    order_0_12  connected_order_arc_491  1
    order_0_12  connected_order_arc_518  1
    order_0_12  connected_order_arc_545  1
    order_0_12  connected_order_arc_572  1
    order_0_12  connected_order_arc_583  -1
    order_0_12  connected_order_arc_585  -1
    order_0_12  connected_order_arc_587  -1
    order_0_12  connected_order_arc_589  -1
    order_0_12  connected_order_arc_591  -1
    order_0_12  connected_order_arc_593  -1
    order_0_12  connected_order_arc_595  -1
    order_0_12  connected_order_arc_597  -1
    order_0_12  connected_order_arc_599  -1
    order_0_12  connected_order_arc_601  -1
    order_0_12  connected_order_arc_603  -1
    order_0_12  connected_order_arc_605  -1
    order_0_12  connected_order_arc_607  -1
    order_0_12  connected_order_arc_628  1
    order_0_12  connected_order_arc_655  1
    order_0_12  connected_order_arc_682  1
    order_0_12  connected_order_arc_709  1
    order_0_12  order_active_lb_780  1
    order_0_12  order_active_ub_781  1
    visit_0_13  out_degree_784  -1
    visit_0_13  in_degree_785  -1
    visit_0_13  order_active_lb_786  -1
    visit_0_13  order_active_ub_787  -14
    visit_0_13  service_visit_def_788  -1
    order_0_13  connected_order_arc_358  1
    order_0_13  connected_order_arc_385  1
    order_0_13  connected_order_arc_412  1
    order_0_13  connected_order_arc_439  1
    order_0_13  connected_order_arc_466  1
    order_0_13  connected_order_arc_493  1
    order_0_13  connected_order_arc_520  1
    order_0_13  connected_order_arc_547  1
    order_0_13  connected_order_arc_574  1
    order_0_13  connected_order_arc_601  1
    order_0_13  connected_order_arc_610  -1
    order_0_13  connected_order_arc_612  -1
    order_0_13  connected_order_arc_614  -1
    order_0_13  connected_order_arc_616  -1
    order_0_13  connected_order_arc_618  -1
    order_0_13  connected_order_arc_620  -1
    order_0_13  connected_order_arc_622  -1
    order_0_13  connected_order_arc_624  -1
    order_0_13  connected_order_arc_626  -1
    order_0_13  connected_order_arc_628  -1
    order_0_13  connected_order_arc_630  -1
    order_0_13  connected_order_arc_632  -1
    order_0_13  connected_order_arc_634  -1
    order_0_13  connected_order_arc_657  1
    order_0_13  connected_order_arc_684  1
    order_0_13  connected_order_arc_711  1
    order_0_13  order_active_lb_786  1
    order_0_13  order_active_ub_787  1
    visit_0_14  out_degree_790  -1
    visit_0_14  in_degree_791  -1
    visit_0_14  order_active_lb_792  -1
    visit_0_14  order_active_ub_793  -14
    visit_0_14  service_visit_def_794  -1
    order_0_14  connected_order_arc_360  1
    order_0_14  connected_order_arc_387  1
    order_0_14  connected_order_arc_414  1
    order_0_14  connected_order_arc_441  1
    order_0_14  connected_order_arc_468  1
    order_0_14  connected_order_arc_495  1
    order_0_14  connected_order_arc_522  1
    order_0_14  connected_order_arc_549  1
    order_0_14  connected_order_arc_576  1
    order_0_14  connected_order_arc_603  1
    order_0_14  connected_order_arc_630  1
    order_0_14  connected_order_arc_637  -1
    order_0_14  connected_order_arc_639  -1
    order_0_14  connected_order_arc_641  -1
    order_0_14  connected_order_arc_643  -1
    order_0_14  connected_order_arc_645  -1
    order_0_14  connected_order_arc_647  -1
    order_0_14  connected_order_arc_649  -1
    order_0_14  connected_order_arc_651  -1
    order_0_14  connected_order_arc_653  -1
    order_0_14  connected_order_arc_655  -1
    order_0_14  connected_order_arc_657  -1
    order_0_14  connected_order_arc_659  -1
    order_0_14  connected_order_arc_661  -1
    order_0_14  connected_order_arc_686  1
    order_0_14  connected_order_arc_713  1
    order_0_14  order_active_lb_792  1
    order_0_14  order_active_ub_793  1
    visit_0_15  out_degree_796  -1
    visit_0_15  in_degree_797  -1
    visit_0_15  order_active_lb_798  -1
    visit_0_15  order_active_ub_799  -14
    visit_0_15  service_visit_def_800  -1
    order_0_15  connected_order_arc_362  1
    order_0_15  connected_order_arc_389  1
    order_0_15  connected_order_arc_416  1
    order_0_15  connected_order_arc_443  1
    order_0_15  connected_order_arc_470  1
    order_0_15  connected_order_arc_497  1
    order_0_15  connected_order_arc_524  1
    order_0_15  connected_order_arc_551  1
    order_0_15  connected_order_arc_578  1
    order_0_15  connected_order_arc_605  1
    order_0_15  connected_order_arc_632  1
    order_0_15  connected_order_arc_659  1
    order_0_15  connected_order_arc_664  -1
    order_0_15  connected_order_arc_666  -1
    order_0_15  connected_order_arc_668  -1
    order_0_15  connected_order_arc_670  -1
    order_0_15  connected_order_arc_672  -1
    order_0_15  connected_order_arc_674  -1
    order_0_15  connected_order_arc_676  -1
    order_0_15  connected_order_arc_678  -1
    order_0_15  connected_order_arc_680  -1
    order_0_15  connected_order_arc_682  -1
    order_0_15  connected_order_arc_684  -1
    order_0_15  connected_order_arc_686  -1
    order_0_15  connected_order_arc_688  -1
    order_0_15  connected_order_arc_715  1
    order_0_15  order_active_lb_798  1
    order_0_15  order_active_ub_799  1
    visit_0_16  out_degree_802  -1
    visit_0_16  in_degree_803  -1
    visit_0_16  order_active_lb_804  -1
    visit_0_16  order_active_ub_805  -14
    visit_0_16  service_visit_def_806  -1
    order_0_16  connected_order_arc_364  1
    order_0_16  connected_order_arc_391  1
    order_0_16  connected_order_arc_418  1
    order_0_16  connected_order_arc_445  1
    order_0_16  connected_order_arc_472  1
    order_0_16  connected_order_arc_499  1
    order_0_16  connected_order_arc_526  1
    order_0_16  connected_order_arc_553  1
    order_0_16  connected_order_arc_580  1
    order_0_16  connected_order_arc_607  1
    order_0_16  connected_order_arc_634  1
    order_0_16  connected_order_arc_661  1
    order_0_16  connected_order_arc_688  1
    order_0_16  connected_order_arc_691  -1
    order_0_16  connected_order_arc_693  -1
    order_0_16  connected_order_arc_695  -1
    order_0_16  connected_order_arc_697  -1
    order_0_16  connected_order_arc_699  -1
    order_0_16  connected_order_arc_701  -1
    order_0_16  connected_order_arc_703  -1
    order_0_16  connected_order_arc_705  -1
    order_0_16  connected_order_arc_707  -1
    order_0_16  connected_order_arc_709  -1
    order_0_16  connected_order_arc_711  -1
    order_0_16  connected_order_arc_713  -1
    order_0_16  connected_order_arc_715  -1
    order_0_16  order_active_lb_804  1
    order_0_16  order_active_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_323  -30
    arc_0_0_0  depot_departure_or_bypass_716  1
    arc_0_0_0  depot_return_or_bypass_717  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_323  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_324  -30
    arc_0_0_1  depot_departure_or_bypass_716  1
    arc_0_0_1  in_degree_719  1
    arc_0_0_1  original_T_including_depot_unload_813  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_324  1
    load_0_0_1  segment_load_conservation_722  -1
    load_0_0_1  segment_prefix_lb_723  1
    load_0_0_1  segment_prefix_ub_724  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_325  -30
    arc_0_0_2  depot_departure_or_bypass_716  1
    arc_0_0_2  in_degree_726  1
    arc_0_0_2  original_T_including_depot_unload_813  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_325  1
    load_0_0_2  segment_load_conservation_729  -1
    load_0_0_2  segment_prefix_lb_730  1
    load_0_0_2  segment_prefix_ub_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_326  -30
    arc_0_0_3  depot_departure_or_bypass_716  1
    arc_0_0_3  in_degree_733  1
    arc_0_0_3  original_T_including_depot_unload_813  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_326  1
    load_0_0_3  segment_load_conservation_736  -1
    load_0_0_3  segment_prefix_lb_737  1
    load_0_0_3  segment_prefix_ub_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_327  -30
    arc_0_0_4  depot_departure_or_bypass_716  1
    arc_0_0_4  in_degree_740  1
    arc_0_0_4  original_T_including_depot_unload_813  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_327  1
    load_0_0_4  segment_load_conservation_743  -1
    load_0_0_4  segment_prefix_lb_744  1
    load_0_0_4  segment_prefix_ub_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_328  -30
    arc_0_0_5  depot_departure_or_bypass_716  1
    arc_0_0_5  in_degree_747  1
    arc_0_0_5  original_T_including_depot_unload_813  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_328  1
    load_0_0_5  segment_load_conservation_750  -1
    load_0_0_5  segment_prefix_lb_751  1
    load_0_0_5  segment_prefix_ub_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_329  -30
    arc_0_0_6  depot_departure_or_bypass_716  1
    arc_0_0_6  in_degree_754  1
    arc_0_0_6  original_T_including_depot_unload_813  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_329  1
    load_0_0_6  segment_load_conservation_757  -1
    load_0_0_6  segment_prefix_lb_758  1
    load_0_0_6  segment_prefix_ub_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_330  -30
    arc_0_0_9  depot_departure_or_bypass_716  1
    arc_0_0_9  in_degree_761  1
    arc_0_0_9  original_T_including_depot_unload_813  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_330  1
    load_0_0_9  free_load_conservation_765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_331  -30
    arc_0_0_10  depot_departure_or_bypass_716  1
    arc_0_0_10  in_degree_767  1
    arc_0_0_10  original_T_including_depot_unload_813  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_331  1
    load_0_0_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_332  -30
    arc_0_0_11  depot_departure_or_bypass_716  1
    arc_0_0_11  in_degree_773  1
    arc_0_0_11  original_T_including_depot_unload_813  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_332  1
    load_0_0_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_333  -30
    arc_0_0_12  depot_departure_or_bypass_716  1
    arc_0_0_12  in_degree_779  1
    arc_0_0_12  original_T_including_depot_unload_813  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_333  1
    load_0_0_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_334  -30
    arc_0_0_13  depot_departure_or_bypass_716  1
    arc_0_0_13  in_degree_785  1
    arc_0_0_13  original_T_including_depot_unload_813  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_334  1
    load_0_0_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_335  -30
    arc_0_0_14  depot_departure_or_bypass_716  1
    arc_0_0_14  in_degree_791  1
    arc_0_0_14  original_T_including_depot_unload_813  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_335  1
    load_0_0_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_336  -30
    arc_0_0_15  depot_departure_or_bypass_716  1
    arc_0_0_15  in_degree_797  1
    arc_0_0_15  original_T_including_depot_unload_813  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_336  1
    load_0_0_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_337  -30
    arc_0_0_16  depot_departure_or_bypass_716  1
    arc_0_0_16  in_degree_803  1
    arc_0_0_16  original_T_including_depot_unload_813  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_337  1
    load_0_0_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_338  -30
    arc_0_1_0  depot_return_or_bypass_717  1
    arc_0_1_0  out_degree_718  1
    arc_0_1_0  original_T_including_depot_unload_813  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_338  1
    load_0_1_0  segment_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_339  -30
    arc_0_1_2  connected_order_arc_340  -15
    arc_0_1_2  out_degree_718  1
    arc_0_1_2  in_degree_726  1
    arc_0_1_2  original_T_including_depot_unload_813  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_339  1
    load_0_1_2  segment_load_conservation_722  1
    load_0_1_2  segment_load_conservation_729  -1
    load_0_1_2  segment_prefix_lb_730  1
    load_0_1_2  segment_prefix_ub_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_341  -30
    arc_0_1_3  connected_order_arc_342  -15
    arc_0_1_3  out_degree_718  1
    arc_0_1_3  in_degree_733  1
    arc_0_1_3  original_T_including_depot_unload_813  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_341  1
    load_0_1_3  segment_load_conservation_722  1
    load_0_1_3  segment_load_conservation_736  -1
    load_0_1_3  segment_prefix_lb_737  1
    load_0_1_3  segment_prefix_ub_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_343  -30
    arc_0_1_4  connected_order_arc_344  -15
    arc_0_1_4  out_degree_718  1
    arc_0_1_4  in_degree_740  1
    arc_0_1_4  original_T_including_depot_unload_813  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_343  1
    load_0_1_4  segment_load_conservation_722  1
    load_0_1_4  segment_load_conservation_743  -1
    load_0_1_4  segment_prefix_lb_744  1
    load_0_1_4  segment_prefix_ub_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_345  -30
    arc_0_1_5  connected_order_arc_346  -15
    arc_0_1_5  out_degree_718  1
    arc_0_1_5  in_degree_747  1
    arc_0_1_5  original_T_including_depot_unload_813  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_345  1
    load_0_1_5  segment_load_conservation_722  1
    load_0_1_5  segment_load_conservation_750  -1
    load_0_1_5  segment_prefix_lb_751  1
    load_0_1_5  segment_prefix_ub_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_347  -30
    arc_0_1_6  connected_order_arc_348  -15
    arc_0_1_6  out_degree_718  1
    arc_0_1_6  in_degree_754  1
    arc_0_1_6  original_T_including_depot_unload_813  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_347  1
    load_0_1_6  segment_load_conservation_722  1
    load_0_1_6  segment_load_conservation_757  -1
    load_0_1_6  segment_prefix_lb_758  1
    load_0_1_6  segment_prefix_ub_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_349  -30
    arc_0_1_9  connected_order_arc_350  -15
    arc_0_1_9  out_degree_718  1
    arc_0_1_9  in_degree_761  1
    arc_0_1_9  original_T_including_depot_unload_813  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_349  1
    load_0_1_9  segment_load_conservation_722  1
    load_0_1_9  free_load_conservation_765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_351  -30
    arc_0_1_10  connected_order_arc_352  -15
    arc_0_1_10  out_degree_718  1
    arc_0_1_10  in_degree_767  1
    arc_0_1_10  original_T_including_depot_unload_813  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_351  1
    load_0_1_10  segment_load_conservation_722  1
    load_0_1_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_353  -30
    arc_0_1_11  connected_order_arc_354  -15
    arc_0_1_11  out_degree_718  1
    arc_0_1_11  in_degree_773  1
    arc_0_1_11  original_T_including_depot_unload_813  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_353  1
    load_0_1_11  segment_load_conservation_722  1
    load_0_1_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_355  -30
    arc_0_1_12  connected_order_arc_356  -15
    arc_0_1_12  out_degree_718  1
    arc_0_1_12  in_degree_779  1
    arc_0_1_12  original_T_including_depot_unload_813  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_355  1
    load_0_1_12  segment_load_conservation_722  1
    load_0_1_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_357  -30
    arc_0_1_13  connected_order_arc_358  -15
    arc_0_1_13  out_degree_718  1
    arc_0_1_13  in_degree_785  1
    arc_0_1_13  original_T_including_depot_unload_813  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_357  1
    load_0_1_13  segment_load_conservation_722  1
    load_0_1_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_359  -30
    arc_0_1_14  connected_order_arc_360  -15
    arc_0_1_14  out_degree_718  1
    arc_0_1_14  in_degree_791  1
    arc_0_1_14  original_T_including_depot_unload_813  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_359  1
    load_0_1_14  segment_load_conservation_722  1
    load_0_1_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_361  -30
    arc_0_1_15  connected_order_arc_362  -15
    arc_0_1_15  out_degree_718  1
    arc_0_1_15  in_degree_797  1
    arc_0_1_15  original_T_including_depot_unload_813  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_361  1
    load_0_1_15  segment_load_conservation_722  1
    load_0_1_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_363  -30
    arc_0_1_16  connected_order_arc_364  -15
    arc_0_1_16  out_degree_718  1
    arc_0_1_16  in_degree_803  1
    arc_0_1_16  original_T_including_depot_unload_813  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_363  1
    load_0_1_16  segment_load_conservation_722  1
    load_0_1_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_365  -30
    arc_0_2_0  depot_return_or_bypass_717  1
    arc_0_2_0  out_degree_725  1
    arc_0_2_0  original_T_including_depot_unload_813  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_365  1
    load_0_2_0  segment_load_conservation_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_366  -30
    arc_0_2_1  connected_order_arc_367  -15
    arc_0_2_1  in_degree_719  1
    arc_0_2_1  out_degree_725  1
    arc_0_2_1  original_T_including_depot_unload_813  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_366  1
    load_0_2_1  segment_load_conservation_722  -1
    load_0_2_1  segment_prefix_lb_723  1
    load_0_2_1  segment_prefix_ub_724  1
    load_0_2_1  segment_load_conservation_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_368  -30
    arc_0_2_3  connected_order_arc_369  -15
    arc_0_2_3  out_degree_725  1
    arc_0_2_3  in_degree_733  1
    arc_0_2_3  original_T_including_depot_unload_813  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_368  1
    load_0_2_3  segment_load_conservation_729  1
    load_0_2_3  segment_load_conservation_736  -1
    load_0_2_3  segment_prefix_lb_737  1
    load_0_2_3  segment_prefix_ub_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_370  -30
    arc_0_2_4  connected_order_arc_371  -15
    arc_0_2_4  out_degree_725  1
    arc_0_2_4  in_degree_740  1
    arc_0_2_4  original_T_including_depot_unload_813  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_370  1
    load_0_2_4  segment_load_conservation_729  1
    load_0_2_4  segment_load_conservation_743  -1
    load_0_2_4  segment_prefix_lb_744  1
    load_0_2_4  segment_prefix_ub_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_372  -30
    arc_0_2_5  connected_order_arc_373  -15
    arc_0_2_5  out_degree_725  1
    arc_0_2_5  in_degree_747  1
    arc_0_2_5  original_T_including_depot_unload_813  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_372  1
    load_0_2_5  segment_load_conservation_729  1
    load_0_2_5  segment_load_conservation_750  -1
    load_0_2_5  segment_prefix_lb_751  1
    load_0_2_5  segment_prefix_ub_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_374  -30
    arc_0_2_6  connected_order_arc_375  -15
    arc_0_2_6  out_degree_725  1
    arc_0_2_6  in_degree_754  1
    arc_0_2_6  original_T_including_depot_unload_813  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_374  1
    load_0_2_6  segment_load_conservation_729  1
    load_0_2_6  segment_load_conservation_757  -1
    load_0_2_6  segment_prefix_lb_758  1
    load_0_2_6  segment_prefix_ub_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_376  -30
    arc_0_2_9  connected_order_arc_377  -15
    arc_0_2_9  out_degree_725  1
    arc_0_2_9  in_degree_761  1
    arc_0_2_9  original_T_including_depot_unload_813  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_376  1
    load_0_2_9  segment_load_conservation_729  1
    load_0_2_9  free_load_conservation_765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_378  -30
    arc_0_2_10  connected_order_arc_379  -15
    arc_0_2_10  out_degree_725  1
    arc_0_2_10  in_degree_767  1
    arc_0_2_10  original_T_including_depot_unload_813  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_378  1
    load_0_2_10  segment_load_conservation_729  1
    load_0_2_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_380  -30
    arc_0_2_11  connected_order_arc_381  -15
    arc_0_2_11  out_degree_725  1
    arc_0_2_11  in_degree_773  1
    arc_0_2_11  original_T_including_depot_unload_813  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_380  1
    load_0_2_11  segment_load_conservation_729  1
    load_0_2_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_382  -30
    arc_0_2_12  connected_order_arc_383  -15
    arc_0_2_12  out_degree_725  1
    arc_0_2_12  in_degree_779  1
    arc_0_2_12  original_T_including_depot_unload_813  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_382  1
    load_0_2_12  segment_load_conservation_729  1
    load_0_2_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_384  -30
    arc_0_2_13  connected_order_arc_385  -15
    arc_0_2_13  out_degree_725  1
    arc_0_2_13  in_degree_785  1
    arc_0_2_13  original_T_including_depot_unload_813  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_384  1
    load_0_2_13  segment_load_conservation_729  1
    load_0_2_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_386  -30
    arc_0_2_14  connected_order_arc_387  -15
    arc_0_2_14  out_degree_725  1
    arc_0_2_14  in_degree_791  1
    arc_0_2_14  original_T_including_depot_unload_813  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_386  1
    load_0_2_14  segment_load_conservation_729  1
    load_0_2_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_388  -30
    arc_0_2_15  connected_order_arc_389  -15
    arc_0_2_15  out_degree_725  1
    arc_0_2_15  in_degree_797  1
    arc_0_2_15  original_T_including_depot_unload_813  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_388  1
    load_0_2_15  segment_load_conservation_729  1
    load_0_2_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_390  -30
    arc_0_2_16  connected_order_arc_391  -15
    arc_0_2_16  out_degree_725  1
    arc_0_2_16  in_degree_803  1
    arc_0_2_16  original_T_including_depot_unload_813  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_390  1
    load_0_2_16  segment_load_conservation_729  1
    load_0_2_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_392  -30
    arc_0_3_0  depot_return_or_bypass_717  1
    arc_0_3_0  out_degree_732  1
    arc_0_3_0  original_T_including_depot_unload_813  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_392  1
    load_0_3_0  segment_load_conservation_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_393  -30
    arc_0_3_1  connected_order_arc_394  -15
    arc_0_3_1  in_degree_719  1
    arc_0_3_1  out_degree_732  1
    arc_0_3_1  original_T_including_depot_unload_813  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_393  1
    load_0_3_1  segment_load_conservation_722  -1
    load_0_3_1  segment_prefix_lb_723  1
    load_0_3_1  segment_prefix_ub_724  1
    load_0_3_1  segment_load_conservation_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_395  -30
    arc_0_3_2  connected_order_arc_396  -15
    arc_0_3_2  in_degree_726  1
    arc_0_3_2  out_degree_732  1
    arc_0_3_2  original_T_including_depot_unload_813  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_395  1
    load_0_3_2  segment_load_conservation_729  -1
    load_0_3_2  segment_prefix_lb_730  1
    load_0_3_2  segment_prefix_ub_731  1
    load_0_3_2  segment_load_conservation_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_397  -30
    arc_0_3_4  connected_order_arc_398  -15
    arc_0_3_4  out_degree_732  1
    arc_0_3_4  in_degree_740  1
    arc_0_3_4  original_T_including_depot_unload_813  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_397  1
    load_0_3_4  segment_load_conservation_736  1
    load_0_3_4  segment_load_conservation_743  -1
    load_0_3_4  segment_prefix_lb_744  1
    load_0_3_4  segment_prefix_ub_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_399  -30
    arc_0_3_5  connected_order_arc_400  -15
    arc_0_3_5  out_degree_732  1
    arc_0_3_5  in_degree_747  1
    arc_0_3_5  original_T_including_depot_unload_813  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_399  1
    load_0_3_5  segment_load_conservation_736  1
    load_0_3_5  segment_load_conservation_750  -1
    load_0_3_5  segment_prefix_lb_751  1
    load_0_3_5  segment_prefix_ub_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_401  -30
    arc_0_3_6  connected_order_arc_402  -15
    arc_0_3_6  out_degree_732  1
    arc_0_3_6  in_degree_754  1
    arc_0_3_6  original_T_including_depot_unload_813  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_401  1
    load_0_3_6  segment_load_conservation_736  1
    load_0_3_6  segment_load_conservation_757  -1
    load_0_3_6  segment_prefix_lb_758  1
    load_0_3_6  segment_prefix_ub_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_403  -30
    arc_0_3_9  connected_order_arc_404  -15
    arc_0_3_9  out_degree_732  1
    arc_0_3_9  in_degree_761  1
    arc_0_3_9  original_T_including_depot_unload_813  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_403  1
    load_0_3_9  segment_load_conservation_736  1
    load_0_3_9  free_load_conservation_765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_405  -30
    arc_0_3_10  connected_order_arc_406  -15
    arc_0_3_10  out_degree_732  1
    arc_0_3_10  in_degree_767  1
    arc_0_3_10  original_T_including_depot_unload_813  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_405  1
    load_0_3_10  segment_load_conservation_736  1
    load_0_3_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_407  -30
    arc_0_3_11  connected_order_arc_408  -15
    arc_0_3_11  out_degree_732  1
    arc_0_3_11  in_degree_773  1
    arc_0_3_11  original_T_including_depot_unload_813  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_407  1
    load_0_3_11  segment_load_conservation_736  1
    load_0_3_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_409  -30
    arc_0_3_12  connected_order_arc_410  -15
    arc_0_3_12  out_degree_732  1
    arc_0_3_12  in_degree_779  1
    arc_0_3_12  original_T_including_depot_unload_813  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_409  1
    load_0_3_12  segment_load_conservation_736  1
    load_0_3_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_411  -30
    arc_0_3_13  connected_order_arc_412  -15
    arc_0_3_13  out_degree_732  1
    arc_0_3_13  in_degree_785  1
    arc_0_3_13  original_T_including_depot_unload_813  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_411  1
    load_0_3_13  segment_load_conservation_736  1
    load_0_3_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_413  -30
    arc_0_3_14  connected_order_arc_414  -15
    arc_0_3_14  out_degree_732  1
    arc_0_3_14  in_degree_791  1
    arc_0_3_14  original_T_including_depot_unload_813  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_413  1
    load_0_3_14  segment_load_conservation_736  1
    load_0_3_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_415  -30
    arc_0_3_15  connected_order_arc_416  -15
    arc_0_3_15  out_degree_732  1
    arc_0_3_15  in_degree_797  1
    arc_0_3_15  original_T_including_depot_unload_813  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_415  1
    load_0_3_15  segment_load_conservation_736  1
    load_0_3_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_417  -30
    arc_0_3_16  connected_order_arc_418  -15
    arc_0_3_16  out_degree_732  1
    arc_0_3_16  in_degree_803  1
    arc_0_3_16  original_T_including_depot_unload_813  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_417  1
    load_0_3_16  segment_load_conservation_736  1
    load_0_3_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_419  -30
    arc_0_4_0  depot_return_or_bypass_717  1
    arc_0_4_0  out_degree_739  1
    arc_0_4_0  original_T_including_depot_unload_813  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_419  1
    load_0_4_0  segment_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_420  -30
    arc_0_4_1  connected_order_arc_421  -15
    arc_0_4_1  in_degree_719  1
    arc_0_4_1  out_degree_739  1
    arc_0_4_1  original_T_including_depot_unload_813  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_420  1
    load_0_4_1  segment_load_conservation_722  -1
    load_0_4_1  segment_prefix_lb_723  1
    load_0_4_1  segment_prefix_ub_724  1
    load_0_4_1  segment_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_422  -30
    arc_0_4_2  connected_order_arc_423  -15
    arc_0_4_2  in_degree_726  1
    arc_0_4_2  out_degree_739  1
    arc_0_4_2  original_T_including_depot_unload_813  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_422  1
    load_0_4_2  segment_load_conservation_729  -1
    load_0_4_2  segment_prefix_lb_730  1
    load_0_4_2  segment_prefix_ub_731  1
    load_0_4_2  segment_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_424  -30
    arc_0_4_3  connected_order_arc_425  -15
    arc_0_4_3  in_degree_733  1
    arc_0_4_3  out_degree_739  1
    arc_0_4_3  original_T_including_depot_unload_813  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_424  1
    load_0_4_3  segment_load_conservation_736  -1
    load_0_4_3  segment_prefix_lb_737  1
    load_0_4_3  segment_prefix_ub_738  1
    load_0_4_3  segment_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_426  -30
    arc_0_4_5  connected_order_arc_427  -15
    arc_0_4_5  out_degree_739  1
    arc_0_4_5  in_degree_747  1
    arc_0_4_5  original_T_including_depot_unload_813  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_426  1
    load_0_4_5  segment_load_conservation_743  1
    load_0_4_5  segment_load_conservation_750  -1
    load_0_4_5  segment_prefix_lb_751  1
    load_0_4_5  segment_prefix_ub_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_428  -30
    arc_0_4_6  connected_order_arc_429  -15
    arc_0_4_6  out_degree_739  1
    arc_0_4_6  in_degree_754  1
    arc_0_4_6  original_T_including_depot_unload_813  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_428  1
    load_0_4_6  segment_load_conservation_743  1
    load_0_4_6  segment_load_conservation_757  -1
    load_0_4_6  segment_prefix_lb_758  1
    load_0_4_6  segment_prefix_ub_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_430  -30
    arc_0_4_9  connected_order_arc_431  -15
    arc_0_4_9  out_degree_739  1
    arc_0_4_9  in_degree_761  1
    arc_0_4_9  original_T_including_depot_unload_813  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_430  1
    load_0_4_9  segment_load_conservation_743  1
    load_0_4_9  free_load_conservation_765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_432  -30
    arc_0_4_10  connected_order_arc_433  -15
    arc_0_4_10  out_degree_739  1
    arc_0_4_10  in_degree_767  1
    arc_0_4_10  original_T_including_depot_unload_813  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_432  1
    load_0_4_10  segment_load_conservation_743  1
    load_0_4_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_434  -30
    arc_0_4_11  connected_order_arc_435  -15
    arc_0_4_11  out_degree_739  1
    arc_0_4_11  in_degree_773  1
    arc_0_4_11  original_T_including_depot_unload_813  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_434  1
    load_0_4_11  segment_load_conservation_743  1
    load_0_4_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_436  -30
    arc_0_4_12  connected_order_arc_437  -15
    arc_0_4_12  out_degree_739  1
    arc_0_4_12  in_degree_779  1
    arc_0_4_12  original_T_including_depot_unload_813  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_436  1
    load_0_4_12  segment_load_conservation_743  1
    load_0_4_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_438  -30
    arc_0_4_13  connected_order_arc_439  -15
    arc_0_4_13  out_degree_739  1
    arc_0_4_13  in_degree_785  1
    arc_0_4_13  original_T_including_depot_unload_813  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_438  1
    load_0_4_13  segment_load_conservation_743  1
    load_0_4_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_440  -30
    arc_0_4_14  connected_order_arc_441  -15
    arc_0_4_14  out_degree_739  1
    arc_0_4_14  in_degree_791  1
    arc_0_4_14  original_T_including_depot_unload_813  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_440  1
    load_0_4_14  segment_load_conservation_743  1
    load_0_4_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_442  -30
    arc_0_4_15  connected_order_arc_443  -15
    arc_0_4_15  out_degree_739  1
    arc_0_4_15  in_degree_797  1
    arc_0_4_15  original_T_including_depot_unload_813  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_442  1
    load_0_4_15  segment_load_conservation_743  1
    load_0_4_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_444  -30
    arc_0_4_16  connected_order_arc_445  -15
    arc_0_4_16  out_degree_739  1
    arc_0_4_16  in_degree_803  1
    arc_0_4_16  original_T_including_depot_unload_813  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_444  1
    load_0_4_16  segment_load_conservation_743  1
    load_0_4_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_446  -30
    arc_0_5_0  depot_return_or_bypass_717  1
    arc_0_5_0  out_degree_746  1
    arc_0_5_0  original_T_including_depot_unload_813  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_446  1
    load_0_5_0  segment_load_conservation_750  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_447  -30
    arc_0_5_1  connected_order_arc_448  -15
    arc_0_5_1  in_degree_719  1
    arc_0_5_1  out_degree_746  1
    arc_0_5_1  original_T_including_depot_unload_813  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_447  1
    load_0_5_1  segment_load_conservation_722  -1
    load_0_5_1  segment_prefix_lb_723  1
    load_0_5_1  segment_prefix_ub_724  1
    load_0_5_1  segment_load_conservation_750  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_449  -30
    arc_0_5_2  connected_order_arc_450  -15
    arc_0_5_2  in_degree_726  1
    arc_0_5_2  out_degree_746  1
    arc_0_5_2  original_T_including_depot_unload_813  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_449  1
    load_0_5_2  segment_load_conservation_729  -1
    load_0_5_2  segment_prefix_lb_730  1
    load_0_5_2  segment_prefix_ub_731  1
    load_0_5_2  segment_load_conservation_750  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_451  -30
    arc_0_5_3  connected_order_arc_452  -15
    arc_0_5_3  in_degree_733  1
    arc_0_5_3  out_degree_746  1
    arc_0_5_3  original_T_including_depot_unload_813  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_451  1
    load_0_5_3  segment_load_conservation_736  -1
    load_0_5_3  segment_prefix_lb_737  1
    load_0_5_3  segment_prefix_ub_738  1
    load_0_5_3  segment_load_conservation_750  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_453  -30
    arc_0_5_4  connected_order_arc_454  -15
    arc_0_5_4  in_degree_740  1
    arc_0_5_4  out_degree_746  1
    arc_0_5_4  original_T_including_depot_unload_813  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_453  1
    load_0_5_4  segment_load_conservation_743  -1
    load_0_5_4  segment_prefix_lb_744  1
    load_0_5_4  segment_prefix_ub_745  1
    load_0_5_4  segment_load_conservation_750  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_455  -30
    arc_0_5_6  connected_order_arc_456  -15
    arc_0_5_6  out_degree_746  1
    arc_0_5_6  in_degree_754  1
    arc_0_5_6  original_T_including_depot_unload_813  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_455  1
    load_0_5_6  segment_load_conservation_750  1
    load_0_5_6  segment_load_conservation_757  -1
    load_0_5_6  segment_prefix_lb_758  1
    load_0_5_6  segment_prefix_ub_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_457  -30
    arc_0_5_9  connected_order_arc_458  -15
    arc_0_5_9  out_degree_746  1
    arc_0_5_9  in_degree_761  1
    arc_0_5_9  original_T_including_depot_unload_813  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_457  1
    load_0_5_9  segment_load_conservation_750  1
    load_0_5_9  free_load_conservation_765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_459  -30
    arc_0_5_10  connected_order_arc_460  -15
    arc_0_5_10  out_degree_746  1
    arc_0_5_10  in_degree_767  1
    arc_0_5_10  original_T_including_depot_unload_813  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_459  1
    load_0_5_10  segment_load_conservation_750  1
    load_0_5_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_461  -30
    arc_0_5_11  connected_order_arc_462  -15
    arc_0_5_11  out_degree_746  1
    arc_0_5_11  in_degree_773  1
    arc_0_5_11  original_T_including_depot_unload_813  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_461  1
    load_0_5_11  segment_load_conservation_750  1
    load_0_5_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_463  -30
    arc_0_5_12  connected_order_arc_464  -15
    arc_0_5_12  out_degree_746  1
    arc_0_5_12  in_degree_779  1
    arc_0_5_12  original_T_including_depot_unload_813  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_463  1
    load_0_5_12  segment_load_conservation_750  1
    load_0_5_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_465  -30
    arc_0_5_13  connected_order_arc_466  -15
    arc_0_5_13  out_degree_746  1
    arc_0_5_13  in_degree_785  1
    arc_0_5_13  original_T_including_depot_unload_813  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_465  1
    load_0_5_13  segment_load_conservation_750  1
    load_0_5_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_467  -30
    arc_0_5_14  connected_order_arc_468  -15
    arc_0_5_14  out_degree_746  1
    arc_0_5_14  in_degree_791  1
    arc_0_5_14  original_T_including_depot_unload_813  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_467  1
    load_0_5_14  segment_load_conservation_750  1
    load_0_5_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_469  -30
    arc_0_5_15  connected_order_arc_470  -15
    arc_0_5_15  out_degree_746  1
    arc_0_5_15  in_degree_797  1
    arc_0_5_15  original_T_including_depot_unload_813  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_469  1
    load_0_5_15  segment_load_conservation_750  1
    load_0_5_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_471  -30
    arc_0_5_16  connected_order_arc_472  -15
    arc_0_5_16  out_degree_746  1
    arc_0_5_16  in_degree_803  1
    arc_0_5_16  original_T_including_depot_unload_813  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_471  1
    load_0_5_16  segment_load_conservation_750  1
    load_0_5_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_473  -30
    arc_0_6_0  depot_return_or_bypass_717  1
    arc_0_6_0  out_degree_753  1
    arc_0_6_0  original_T_including_depot_unload_813  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_473  1
    load_0_6_0  segment_load_conservation_757  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_474  -30
    arc_0_6_1  connected_order_arc_475  -15
    arc_0_6_1  in_degree_719  1
    arc_0_6_1  out_degree_753  1
    arc_0_6_1  original_T_including_depot_unload_813  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_474  1
    load_0_6_1  segment_load_conservation_722  -1
    load_0_6_1  segment_prefix_lb_723  1
    load_0_6_1  segment_prefix_ub_724  1
    load_0_6_1  segment_load_conservation_757  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_476  -30
    arc_0_6_2  connected_order_arc_477  -15
    arc_0_6_2  in_degree_726  1
    arc_0_6_2  out_degree_753  1
    arc_0_6_2  original_T_including_depot_unload_813  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_476  1
    load_0_6_2  segment_load_conservation_729  -1
    load_0_6_2  segment_prefix_lb_730  1
    load_0_6_2  segment_prefix_ub_731  1
    load_0_6_2  segment_load_conservation_757  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_478  -30
    arc_0_6_3  connected_order_arc_479  -15
    arc_0_6_3  in_degree_733  1
    arc_0_6_3  out_degree_753  1
    arc_0_6_3  original_T_including_depot_unload_813  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_478  1
    load_0_6_3  segment_load_conservation_736  -1
    load_0_6_3  segment_prefix_lb_737  1
    load_0_6_3  segment_prefix_ub_738  1
    load_0_6_3  segment_load_conservation_757  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_480  -30
    arc_0_6_4  connected_order_arc_481  -15
    arc_0_6_4  in_degree_740  1
    arc_0_6_4  out_degree_753  1
    arc_0_6_4  original_T_including_depot_unload_813  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_480  1
    load_0_6_4  segment_load_conservation_743  -1
    load_0_6_4  segment_prefix_lb_744  1
    load_0_6_4  segment_prefix_ub_745  1
    load_0_6_4  segment_load_conservation_757  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_482  -30
    arc_0_6_5  connected_order_arc_483  -15
    arc_0_6_5  in_degree_747  1
    arc_0_6_5  out_degree_753  1
    arc_0_6_5  original_T_including_depot_unload_813  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_482  1
    load_0_6_5  segment_load_conservation_750  -1
    load_0_6_5  segment_prefix_lb_751  1
    load_0_6_5  segment_prefix_ub_752  1
    load_0_6_5  segment_load_conservation_757  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_9  arc_capacity_484  -30
    arc_0_6_9  connected_order_arc_485  -15
    arc_0_6_9  out_degree_753  1
    arc_0_6_9  in_degree_761  1
    arc_0_6_9  original_T_including_depot_unload_813  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_9  arc_capacity_484  1
    load_0_6_9  segment_load_conservation_757  1
    load_0_6_9  free_load_conservation_765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_10  arc_capacity_486  -30
    arc_0_6_10  connected_order_arc_487  -15
    arc_0_6_10  out_degree_753  1
    arc_0_6_10  in_degree_767  1
    arc_0_6_10  original_T_including_depot_unload_813  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_10  arc_capacity_486  1
    load_0_6_10  segment_load_conservation_757  1
    load_0_6_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_488  -30
    arc_0_6_11  connected_order_arc_489  -15
    arc_0_6_11  out_degree_753  1
    arc_0_6_11  in_degree_773  1
    arc_0_6_11  original_T_including_depot_unload_813  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_488  1
    load_0_6_11  segment_load_conservation_757  1
    load_0_6_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_490  -30
    arc_0_6_12  connected_order_arc_491  -15
    arc_0_6_12  out_degree_753  1
    arc_0_6_12  in_degree_779  1
    arc_0_6_12  original_T_including_depot_unload_813  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_490  1
    load_0_6_12  segment_load_conservation_757  1
    load_0_6_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_492  -30
    arc_0_6_13  connected_order_arc_493  -15
    arc_0_6_13  out_degree_753  1
    arc_0_6_13  in_degree_785  1
    arc_0_6_13  original_T_including_depot_unload_813  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_492  1
    load_0_6_13  segment_load_conservation_757  1
    load_0_6_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_494  -30
    arc_0_6_14  connected_order_arc_495  -15
    arc_0_6_14  out_degree_753  1
    arc_0_6_14  in_degree_791  1
    arc_0_6_14  original_T_including_depot_unload_813  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_494  1
    load_0_6_14  segment_load_conservation_757  1
    load_0_6_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_496  -30
    arc_0_6_15  connected_order_arc_497  -15
    arc_0_6_15  out_degree_753  1
    arc_0_6_15  in_degree_797  1
    arc_0_6_15  original_T_including_depot_unload_813  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_496  1
    load_0_6_15  segment_load_conservation_757  1
    load_0_6_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_498  -30
    arc_0_6_16  connected_order_arc_499  -15
    arc_0_6_16  out_degree_753  1
    arc_0_6_16  in_degree_803  1
    arc_0_6_16  original_T_including_depot_unload_813  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_498  1
    load_0_6_16  segment_load_conservation_757  1
    load_0_6_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_500  -30
    arc_0_9_0  depot_return_or_bypass_717  1
    arc_0_9_0  out_degree_760  1
    arc_0_9_0  original_T_including_depot_unload_813  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_500  1
    load_0_9_0  free_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_501  -30
    arc_0_9_1  connected_order_arc_502  -15
    arc_0_9_1  in_degree_719  1
    arc_0_9_1  out_degree_760  1
    arc_0_9_1  original_T_including_depot_unload_813  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_501  1
    load_0_9_1  segment_load_conservation_722  -1
    load_0_9_1  segment_prefix_lb_723  1
    load_0_9_1  segment_prefix_ub_724  1
    load_0_9_1  free_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_503  -30
    arc_0_9_2  connected_order_arc_504  -15
    arc_0_9_2  in_degree_726  1
    arc_0_9_2  out_degree_760  1
    arc_0_9_2  original_T_including_depot_unload_813  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_503  1
    load_0_9_2  segment_load_conservation_729  -1
    load_0_9_2  segment_prefix_lb_730  1
    load_0_9_2  segment_prefix_ub_731  1
    load_0_9_2  free_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_505  -30
    arc_0_9_3  connected_order_arc_506  -15
    arc_0_9_3  in_degree_733  1
    arc_0_9_3  out_degree_760  1
    arc_0_9_3  original_T_including_depot_unload_813  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_505  1
    load_0_9_3  segment_load_conservation_736  -1
    load_0_9_3  segment_prefix_lb_737  1
    load_0_9_3  segment_prefix_ub_738  1
    load_0_9_3  free_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_507  -30
    arc_0_9_4  connected_order_arc_508  -15
    arc_0_9_4  in_degree_740  1
    arc_0_9_4  out_degree_760  1
    arc_0_9_4  original_T_including_depot_unload_813  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_507  1
    load_0_9_4  segment_load_conservation_743  -1
    load_0_9_4  segment_prefix_lb_744  1
    load_0_9_4  segment_prefix_ub_745  1
    load_0_9_4  free_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_509  -30
    arc_0_9_5  connected_order_arc_510  -15
    arc_0_9_5  in_degree_747  1
    arc_0_9_5  out_degree_760  1
    arc_0_9_5  original_T_including_depot_unload_813  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_509  1
    load_0_9_5  segment_load_conservation_750  -1
    load_0_9_5  segment_prefix_lb_751  1
    load_0_9_5  segment_prefix_ub_752  1
    load_0_9_5  free_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_6  arc_capacity_511  -30
    arc_0_9_6  connected_order_arc_512  -15
    arc_0_9_6  in_degree_754  1
    arc_0_9_6  out_degree_760  1
    arc_0_9_6  original_T_including_depot_unload_813  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_6  arc_capacity_511  1
    load_0_9_6  segment_load_conservation_757  -1
    load_0_9_6  segment_prefix_lb_758  1
    load_0_9_6  segment_prefix_ub_759  1
    load_0_9_6  free_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_513  -30
    arc_0_9_10  connected_order_arc_514  -15
    arc_0_9_10  out_degree_760  1
    arc_0_9_10  in_degree_767  1
    arc_0_9_10  original_T_including_depot_unload_813  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_513  1
    load_0_9_10  free_load_conservation_765  1
    load_0_9_10  free_load_conservation_771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_515  -30
    arc_0_9_11  connected_order_arc_516  -15
    arc_0_9_11  out_degree_760  1
    arc_0_9_11  in_degree_773  1
    arc_0_9_11  original_T_including_depot_unload_813  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_515  1
    load_0_9_11  free_load_conservation_765  1
    load_0_9_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_517  -30
    arc_0_9_12  connected_order_arc_518  -15
    arc_0_9_12  out_degree_760  1
    arc_0_9_12  in_degree_779  1
    arc_0_9_12  original_T_including_depot_unload_813  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_517  1
    load_0_9_12  free_load_conservation_765  1
    load_0_9_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_519  -30
    arc_0_9_13  connected_order_arc_520  -15
    arc_0_9_13  out_degree_760  1
    arc_0_9_13  in_degree_785  1
    arc_0_9_13  original_T_including_depot_unload_813  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_519  1
    load_0_9_13  free_load_conservation_765  1
    load_0_9_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_521  -30
    arc_0_9_14  connected_order_arc_522  -15
    arc_0_9_14  out_degree_760  1
    arc_0_9_14  in_degree_791  1
    arc_0_9_14  original_T_including_depot_unload_813  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_521  1
    load_0_9_14  free_load_conservation_765  1
    load_0_9_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_523  -30
    arc_0_9_15  connected_order_arc_524  -15
    arc_0_9_15  out_degree_760  1
    arc_0_9_15  in_degree_797  1
    arc_0_9_15  original_T_including_depot_unload_813  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_523  1
    load_0_9_15  free_load_conservation_765  1
    load_0_9_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_16  arc_capacity_525  -30
    arc_0_9_16  connected_order_arc_526  -15
    arc_0_9_16  out_degree_760  1
    arc_0_9_16  in_degree_803  1
    arc_0_9_16  original_T_including_depot_unload_813  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_16  arc_capacity_525  1
    load_0_9_16  free_load_conservation_765  1
    load_0_9_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_527  -30
    arc_0_10_0  depot_return_or_bypass_717  1
    arc_0_10_0  out_degree_766  1
    arc_0_10_0  original_T_including_depot_unload_813  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_527  1
    load_0_10_0  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_528  -30
    arc_0_10_1  connected_order_arc_529  -15
    arc_0_10_1  in_degree_719  1
    arc_0_10_1  out_degree_766  1
    arc_0_10_1  original_T_including_depot_unload_813  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_528  1
    load_0_10_1  segment_load_conservation_722  -1
    load_0_10_1  segment_prefix_lb_723  1
    load_0_10_1  segment_prefix_ub_724  1
    load_0_10_1  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_530  -30
    arc_0_10_2  connected_order_arc_531  -15
    arc_0_10_2  in_degree_726  1
    arc_0_10_2  out_degree_766  1
    arc_0_10_2  original_T_including_depot_unload_813  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_530  1
    load_0_10_2  segment_load_conservation_729  -1
    load_0_10_2  segment_prefix_lb_730  1
    load_0_10_2  segment_prefix_ub_731  1
    load_0_10_2  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_532  -30
    arc_0_10_3  connected_order_arc_533  -15
    arc_0_10_3  in_degree_733  1
    arc_0_10_3  out_degree_766  1
    arc_0_10_3  original_T_including_depot_unload_813  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_532  1
    load_0_10_3  segment_load_conservation_736  -1
    load_0_10_3  segment_prefix_lb_737  1
    load_0_10_3  segment_prefix_ub_738  1
    load_0_10_3  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_534  -30
    arc_0_10_4  connected_order_arc_535  -15
    arc_0_10_4  in_degree_740  1
    arc_0_10_4  out_degree_766  1
    arc_0_10_4  original_T_including_depot_unload_813  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_534  1
    load_0_10_4  segment_load_conservation_743  -1
    load_0_10_4  segment_prefix_lb_744  1
    load_0_10_4  segment_prefix_ub_745  1
    load_0_10_4  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_536  -30
    arc_0_10_5  connected_order_arc_537  -15
    arc_0_10_5  in_degree_747  1
    arc_0_10_5  out_degree_766  1
    arc_0_10_5  original_T_including_depot_unload_813  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_536  1
    load_0_10_5  segment_load_conservation_750  -1
    load_0_10_5  segment_prefix_lb_751  1
    load_0_10_5  segment_prefix_ub_752  1
    load_0_10_5  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_6  arc_capacity_538  -30
    arc_0_10_6  connected_order_arc_539  -15
    arc_0_10_6  in_degree_754  1
    arc_0_10_6  out_degree_766  1
    arc_0_10_6  original_T_including_depot_unload_813  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_6  arc_capacity_538  1
    load_0_10_6  segment_load_conservation_757  -1
    load_0_10_6  segment_prefix_lb_758  1
    load_0_10_6  segment_prefix_ub_759  1
    load_0_10_6  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_540  -30
    arc_0_10_9  connected_order_arc_541  -15
    arc_0_10_9  in_degree_761  1
    arc_0_10_9  out_degree_766  1
    arc_0_10_9  original_T_including_depot_unload_813  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_540  1
    load_0_10_9  free_load_conservation_765  -1
    load_0_10_9  free_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_542  -30
    arc_0_10_11  connected_order_arc_543  -15
    arc_0_10_11  out_degree_766  1
    arc_0_10_11  in_degree_773  1
    arc_0_10_11  original_T_including_depot_unload_813  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_542  1
    load_0_10_11  free_load_conservation_771  1
    load_0_10_11  free_load_conservation_777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_544  -30
    arc_0_10_12  connected_order_arc_545  -15
    arc_0_10_12  out_degree_766  1
    arc_0_10_12  in_degree_779  1
    arc_0_10_12  original_T_including_depot_unload_813  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_544  1
    load_0_10_12  free_load_conservation_771  1
    load_0_10_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_546  -30
    arc_0_10_13  connected_order_arc_547  -15
    arc_0_10_13  out_degree_766  1
    arc_0_10_13  in_degree_785  1
    arc_0_10_13  original_T_including_depot_unload_813  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_546  1
    load_0_10_13  free_load_conservation_771  1
    load_0_10_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_548  -30
    arc_0_10_14  connected_order_arc_549  -15
    arc_0_10_14  out_degree_766  1
    arc_0_10_14  in_degree_791  1
    arc_0_10_14  original_T_including_depot_unload_813  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_548  1
    load_0_10_14  free_load_conservation_771  1
    load_0_10_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_550  -30
    arc_0_10_15  connected_order_arc_551  -15
    arc_0_10_15  out_degree_766  1
    arc_0_10_15  in_degree_797  1
    arc_0_10_15  original_T_including_depot_unload_813  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_550  1
    load_0_10_15  free_load_conservation_771  1
    load_0_10_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_16  arc_capacity_552  -30
    arc_0_10_16  connected_order_arc_553  -15
    arc_0_10_16  out_degree_766  1
    arc_0_10_16  in_degree_803  1
    arc_0_10_16  original_T_including_depot_unload_813  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_16  arc_capacity_552  1
    load_0_10_16  free_load_conservation_771  1
    load_0_10_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_554  -30
    arc_0_11_0  depot_return_or_bypass_717  1
    arc_0_11_0  out_degree_772  1
    arc_0_11_0  original_T_including_depot_unload_813  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_554  1
    load_0_11_0  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_555  -30
    arc_0_11_1  connected_order_arc_556  -15
    arc_0_11_1  in_degree_719  1
    arc_0_11_1  out_degree_772  1
    arc_0_11_1  original_T_including_depot_unload_813  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_555  1
    load_0_11_1  segment_load_conservation_722  -1
    load_0_11_1  segment_prefix_lb_723  1
    load_0_11_1  segment_prefix_ub_724  1
    load_0_11_1  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_557  -30
    arc_0_11_2  connected_order_arc_558  -15
    arc_0_11_2  in_degree_726  1
    arc_0_11_2  out_degree_772  1
    arc_0_11_2  original_T_including_depot_unload_813  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_557  1
    load_0_11_2  segment_load_conservation_729  -1
    load_0_11_2  segment_prefix_lb_730  1
    load_0_11_2  segment_prefix_ub_731  1
    load_0_11_2  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_559  -30
    arc_0_11_3  connected_order_arc_560  -15
    arc_0_11_3  in_degree_733  1
    arc_0_11_3  out_degree_772  1
    arc_0_11_3  original_T_including_depot_unload_813  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_559  1
    load_0_11_3  segment_load_conservation_736  -1
    load_0_11_3  segment_prefix_lb_737  1
    load_0_11_3  segment_prefix_ub_738  1
    load_0_11_3  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_561  -30
    arc_0_11_4  connected_order_arc_562  -15
    arc_0_11_4  in_degree_740  1
    arc_0_11_4  out_degree_772  1
    arc_0_11_4  original_T_including_depot_unload_813  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_561  1
    load_0_11_4  segment_load_conservation_743  -1
    load_0_11_4  segment_prefix_lb_744  1
    load_0_11_4  segment_prefix_ub_745  1
    load_0_11_4  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_563  -30
    arc_0_11_5  connected_order_arc_564  -15
    arc_0_11_5  in_degree_747  1
    arc_0_11_5  out_degree_772  1
    arc_0_11_5  original_T_including_depot_unload_813  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_563  1
    load_0_11_5  segment_load_conservation_750  -1
    load_0_11_5  segment_prefix_lb_751  1
    load_0_11_5  segment_prefix_ub_752  1
    load_0_11_5  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_565  -30
    arc_0_11_6  connected_order_arc_566  -15
    arc_0_11_6  in_degree_754  1
    arc_0_11_6  out_degree_772  1
    arc_0_11_6  original_T_including_depot_unload_813  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_565  1
    load_0_11_6  segment_load_conservation_757  -1
    load_0_11_6  segment_prefix_lb_758  1
    load_0_11_6  segment_prefix_ub_759  1
    load_0_11_6  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_567  -30
    arc_0_11_9  connected_order_arc_568  -15
    arc_0_11_9  in_degree_761  1
    arc_0_11_9  out_degree_772  1
    arc_0_11_9  original_T_including_depot_unload_813  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_567  1
    load_0_11_9  free_load_conservation_765  -1
    load_0_11_9  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_569  -30
    arc_0_11_10  connected_order_arc_570  -15
    arc_0_11_10  in_degree_767  1
    arc_0_11_10  out_degree_772  1
    arc_0_11_10  original_T_including_depot_unload_813  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_569  1
    load_0_11_10  free_load_conservation_771  -1
    load_0_11_10  free_load_conservation_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_571  -30
    arc_0_11_12  connected_order_arc_572  -15
    arc_0_11_12  out_degree_772  1
    arc_0_11_12  in_degree_779  1
    arc_0_11_12  original_T_including_depot_unload_813  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_571  1
    load_0_11_12  free_load_conservation_777  1
    load_0_11_12  free_load_conservation_783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_573  -30
    arc_0_11_13  connected_order_arc_574  -15
    arc_0_11_13  out_degree_772  1
    arc_0_11_13  in_degree_785  1
    arc_0_11_13  original_T_including_depot_unload_813  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_573  1
    load_0_11_13  free_load_conservation_777  1
    load_0_11_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_575  -30
    arc_0_11_14  connected_order_arc_576  -15
    arc_0_11_14  out_degree_772  1
    arc_0_11_14  in_degree_791  1
    arc_0_11_14  original_T_including_depot_unload_813  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_575  1
    load_0_11_14  free_load_conservation_777  1
    load_0_11_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_577  -30
    arc_0_11_15  connected_order_arc_578  -15
    arc_0_11_15  out_degree_772  1
    arc_0_11_15  in_degree_797  1
    arc_0_11_15  original_T_including_depot_unload_813  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_577  1
    load_0_11_15  free_load_conservation_777  1
    load_0_11_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_579  -30
    arc_0_11_16  connected_order_arc_580  -15
    arc_0_11_16  out_degree_772  1
    arc_0_11_16  in_degree_803  1
    arc_0_11_16  original_T_including_depot_unload_813  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_579  1
    load_0_11_16  free_load_conservation_777  1
    load_0_11_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_581  -30
    arc_0_12_0  depot_return_or_bypass_717  1
    arc_0_12_0  out_degree_778  1
    arc_0_12_0  original_T_including_depot_unload_813  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_581  1
    load_0_12_0  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_582  -30
    arc_0_12_1  connected_order_arc_583  -15
    arc_0_12_1  in_degree_719  1
    arc_0_12_1  out_degree_778  1
    arc_0_12_1  original_T_including_depot_unload_813  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_582  1
    load_0_12_1  segment_load_conservation_722  -1
    load_0_12_1  segment_prefix_lb_723  1
    load_0_12_1  segment_prefix_ub_724  1
    load_0_12_1  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_584  -30
    arc_0_12_2  connected_order_arc_585  -15
    arc_0_12_2  in_degree_726  1
    arc_0_12_2  out_degree_778  1
    arc_0_12_2  original_T_including_depot_unload_813  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_584  1
    load_0_12_2  segment_load_conservation_729  -1
    load_0_12_2  segment_prefix_lb_730  1
    load_0_12_2  segment_prefix_ub_731  1
    load_0_12_2  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_586  -30
    arc_0_12_3  connected_order_arc_587  -15
    arc_0_12_3  in_degree_733  1
    arc_0_12_3  out_degree_778  1
    arc_0_12_3  original_T_including_depot_unload_813  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_586  1
    load_0_12_3  segment_load_conservation_736  -1
    load_0_12_3  segment_prefix_lb_737  1
    load_0_12_3  segment_prefix_ub_738  1
    load_0_12_3  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_588  -30
    arc_0_12_4  connected_order_arc_589  -15
    arc_0_12_4  in_degree_740  1
    arc_0_12_4  out_degree_778  1
    arc_0_12_4  original_T_including_depot_unload_813  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_588  1
    load_0_12_4  segment_load_conservation_743  -1
    load_0_12_4  segment_prefix_lb_744  1
    load_0_12_4  segment_prefix_ub_745  1
    load_0_12_4  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_590  -30
    arc_0_12_5  connected_order_arc_591  -15
    arc_0_12_5  in_degree_747  1
    arc_0_12_5  out_degree_778  1
    arc_0_12_5  original_T_including_depot_unload_813  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_590  1
    load_0_12_5  segment_load_conservation_750  -1
    load_0_12_5  segment_prefix_lb_751  1
    load_0_12_5  segment_prefix_ub_752  1
    load_0_12_5  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_592  -30
    arc_0_12_6  connected_order_arc_593  -15
    arc_0_12_6  in_degree_754  1
    arc_0_12_6  out_degree_778  1
    arc_0_12_6  original_T_including_depot_unload_813  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_592  1
    load_0_12_6  segment_load_conservation_757  -1
    load_0_12_6  segment_prefix_lb_758  1
    load_0_12_6  segment_prefix_ub_759  1
    load_0_12_6  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_594  -30
    arc_0_12_9  connected_order_arc_595  -15
    arc_0_12_9  in_degree_761  1
    arc_0_12_9  out_degree_778  1
    arc_0_12_9  original_T_including_depot_unload_813  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_594  1
    load_0_12_9  free_load_conservation_765  -1
    load_0_12_9  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_596  -30
    arc_0_12_10  connected_order_arc_597  -15
    arc_0_12_10  in_degree_767  1
    arc_0_12_10  out_degree_778  1
    arc_0_12_10  original_T_including_depot_unload_813  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_596  1
    load_0_12_10  free_load_conservation_771  -1
    load_0_12_10  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_598  -30
    arc_0_12_11  connected_order_arc_599  -15
    arc_0_12_11  in_degree_773  1
    arc_0_12_11  out_degree_778  1
    arc_0_12_11  original_T_including_depot_unload_813  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_598  1
    load_0_12_11  free_load_conservation_777  -1
    load_0_12_11  free_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_600  -30
    arc_0_12_13  connected_order_arc_601  -15
    arc_0_12_13  out_degree_778  1
    arc_0_12_13  in_degree_785  1
    arc_0_12_13  original_T_including_depot_unload_813  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_600  1
    load_0_12_13  free_load_conservation_783  1
    load_0_12_13  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_602  -30
    arc_0_12_14  connected_order_arc_603  -15
    arc_0_12_14  out_degree_778  1
    arc_0_12_14  in_degree_791  1
    arc_0_12_14  original_T_including_depot_unload_813  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_602  1
    load_0_12_14  free_load_conservation_783  1
    load_0_12_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_604  -30
    arc_0_12_15  connected_order_arc_605  -15
    arc_0_12_15  out_degree_778  1
    arc_0_12_15  in_degree_797  1
    arc_0_12_15  original_T_including_depot_unload_813  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_604  1
    load_0_12_15  free_load_conservation_783  1
    load_0_12_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_606  -30
    arc_0_12_16  connected_order_arc_607  -15
    arc_0_12_16  out_degree_778  1
    arc_0_12_16  in_degree_803  1
    arc_0_12_16  original_T_including_depot_unload_813  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_606  1
    load_0_12_16  free_load_conservation_783  1
    load_0_12_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_608  -30
    arc_0_13_0  depot_return_or_bypass_717  1
    arc_0_13_0  out_degree_784  1
    arc_0_13_0  original_T_including_depot_unload_813  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_608  1
    load_0_13_0  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_609  -30
    arc_0_13_1  connected_order_arc_610  -15
    arc_0_13_1  in_degree_719  1
    arc_0_13_1  out_degree_784  1
    arc_0_13_1  original_T_including_depot_unload_813  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_609  1
    load_0_13_1  segment_load_conservation_722  -1
    load_0_13_1  segment_prefix_lb_723  1
    load_0_13_1  segment_prefix_ub_724  1
    load_0_13_1  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_611  -30
    arc_0_13_2  connected_order_arc_612  -15
    arc_0_13_2  in_degree_726  1
    arc_0_13_2  out_degree_784  1
    arc_0_13_2  original_T_including_depot_unload_813  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_611  1
    load_0_13_2  segment_load_conservation_729  -1
    load_0_13_2  segment_prefix_lb_730  1
    load_0_13_2  segment_prefix_ub_731  1
    load_0_13_2  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_613  -30
    arc_0_13_3  connected_order_arc_614  -15
    arc_0_13_3  in_degree_733  1
    arc_0_13_3  out_degree_784  1
    arc_0_13_3  original_T_including_depot_unload_813  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_613  1
    load_0_13_3  segment_load_conservation_736  -1
    load_0_13_3  segment_prefix_lb_737  1
    load_0_13_3  segment_prefix_ub_738  1
    load_0_13_3  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_615  -30
    arc_0_13_4  connected_order_arc_616  -15
    arc_0_13_4  in_degree_740  1
    arc_0_13_4  out_degree_784  1
    arc_0_13_4  original_T_including_depot_unload_813  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_615  1
    load_0_13_4  segment_load_conservation_743  -1
    load_0_13_4  segment_prefix_lb_744  1
    load_0_13_4  segment_prefix_ub_745  1
    load_0_13_4  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_617  -30
    arc_0_13_5  connected_order_arc_618  -15
    arc_0_13_5  in_degree_747  1
    arc_0_13_5  out_degree_784  1
    arc_0_13_5  original_T_including_depot_unload_813  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_617  1
    load_0_13_5  segment_load_conservation_750  -1
    load_0_13_5  segment_prefix_lb_751  1
    load_0_13_5  segment_prefix_ub_752  1
    load_0_13_5  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_619  -30
    arc_0_13_6  connected_order_arc_620  -15
    arc_0_13_6  in_degree_754  1
    arc_0_13_6  out_degree_784  1
    arc_0_13_6  original_T_including_depot_unload_813  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_619  1
    load_0_13_6  segment_load_conservation_757  -1
    load_0_13_6  segment_prefix_lb_758  1
    load_0_13_6  segment_prefix_ub_759  1
    load_0_13_6  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_621  -30
    arc_0_13_9  connected_order_arc_622  -15
    arc_0_13_9  in_degree_761  1
    arc_0_13_9  out_degree_784  1
    arc_0_13_9  original_T_including_depot_unload_813  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_621  1
    load_0_13_9  free_load_conservation_765  -1
    load_0_13_9  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_623  -30
    arc_0_13_10  connected_order_arc_624  -15
    arc_0_13_10  in_degree_767  1
    arc_0_13_10  out_degree_784  1
    arc_0_13_10  original_T_including_depot_unload_813  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_623  1
    load_0_13_10  free_load_conservation_771  -1
    load_0_13_10  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_625  -30
    arc_0_13_11  connected_order_arc_626  -15
    arc_0_13_11  in_degree_773  1
    arc_0_13_11  out_degree_784  1
    arc_0_13_11  original_T_including_depot_unload_813  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_625  1
    load_0_13_11  free_load_conservation_777  -1
    load_0_13_11  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_627  -30
    arc_0_13_12  connected_order_arc_628  -15
    arc_0_13_12  in_degree_779  1
    arc_0_13_12  out_degree_784  1
    arc_0_13_12  original_T_including_depot_unload_813  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_627  1
    load_0_13_12  free_load_conservation_783  -1
    load_0_13_12  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_629  -30
    arc_0_13_14  connected_order_arc_630  -15
    arc_0_13_14  out_degree_784  1
    arc_0_13_14  in_degree_791  1
    arc_0_13_14  original_T_including_depot_unload_813  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_629  1
    load_0_13_14  free_load_conservation_789  1
    load_0_13_14  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_631  -30
    arc_0_13_15  connected_order_arc_632  -15
    arc_0_13_15  out_degree_784  1
    arc_0_13_15  in_degree_797  1
    arc_0_13_15  original_T_including_depot_unload_813  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_631  1
    load_0_13_15  free_load_conservation_789  1
    load_0_13_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_633  -30
    arc_0_13_16  connected_order_arc_634  -15
    arc_0_13_16  out_degree_784  1
    arc_0_13_16  in_degree_803  1
    arc_0_13_16  original_T_including_depot_unload_813  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_633  1
    load_0_13_16  free_load_conservation_789  1
    load_0_13_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_635  -30
    arc_0_14_0  depot_return_or_bypass_717  1
    arc_0_14_0  out_degree_790  1
    arc_0_14_0  original_T_including_depot_unload_813  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_635  1
    load_0_14_0  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_636  -30
    arc_0_14_1  connected_order_arc_637  -15
    arc_0_14_1  in_degree_719  1
    arc_0_14_1  out_degree_790  1
    arc_0_14_1  original_T_including_depot_unload_813  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_636  1
    load_0_14_1  segment_load_conservation_722  -1
    load_0_14_1  segment_prefix_lb_723  1
    load_0_14_1  segment_prefix_ub_724  1
    load_0_14_1  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_638  -30
    arc_0_14_2  connected_order_arc_639  -15
    arc_0_14_2  in_degree_726  1
    arc_0_14_2  out_degree_790  1
    arc_0_14_2  original_T_including_depot_unload_813  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_638  1
    load_0_14_2  segment_load_conservation_729  -1
    load_0_14_2  segment_prefix_lb_730  1
    load_0_14_2  segment_prefix_ub_731  1
    load_0_14_2  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_640  -30
    arc_0_14_3  connected_order_arc_641  -15
    arc_0_14_3  in_degree_733  1
    arc_0_14_3  out_degree_790  1
    arc_0_14_3  original_T_including_depot_unload_813  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_640  1
    load_0_14_3  segment_load_conservation_736  -1
    load_0_14_3  segment_prefix_lb_737  1
    load_0_14_3  segment_prefix_ub_738  1
    load_0_14_3  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_642  -30
    arc_0_14_4  connected_order_arc_643  -15
    arc_0_14_4  in_degree_740  1
    arc_0_14_4  out_degree_790  1
    arc_0_14_4  original_T_including_depot_unload_813  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_642  1
    load_0_14_4  segment_load_conservation_743  -1
    load_0_14_4  segment_prefix_lb_744  1
    load_0_14_4  segment_prefix_ub_745  1
    load_0_14_4  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_644  -30
    arc_0_14_5  connected_order_arc_645  -15
    arc_0_14_5  in_degree_747  1
    arc_0_14_5  out_degree_790  1
    arc_0_14_5  original_T_including_depot_unload_813  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_644  1
    load_0_14_5  segment_load_conservation_750  -1
    load_0_14_5  segment_prefix_lb_751  1
    load_0_14_5  segment_prefix_ub_752  1
    load_0_14_5  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_646  -30
    arc_0_14_6  connected_order_arc_647  -15
    arc_0_14_6  in_degree_754  1
    arc_0_14_6  out_degree_790  1
    arc_0_14_6  original_T_including_depot_unload_813  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_646  1
    load_0_14_6  segment_load_conservation_757  -1
    load_0_14_6  segment_prefix_lb_758  1
    load_0_14_6  segment_prefix_ub_759  1
    load_0_14_6  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_648  -30
    arc_0_14_9  connected_order_arc_649  -15
    arc_0_14_9  in_degree_761  1
    arc_0_14_9  out_degree_790  1
    arc_0_14_9  original_T_including_depot_unload_813  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_648  1
    load_0_14_9  free_load_conservation_765  -1
    load_0_14_9  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_650  -30
    arc_0_14_10  connected_order_arc_651  -15
    arc_0_14_10  in_degree_767  1
    arc_0_14_10  out_degree_790  1
    arc_0_14_10  original_T_including_depot_unload_813  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_650  1
    load_0_14_10  free_load_conservation_771  -1
    load_0_14_10  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_652  -30
    arc_0_14_11  connected_order_arc_653  -15
    arc_0_14_11  in_degree_773  1
    arc_0_14_11  out_degree_790  1
    arc_0_14_11  original_T_including_depot_unload_813  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_652  1
    load_0_14_11  free_load_conservation_777  -1
    load_0_14_11  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_654  -30
    arc_0_14_12  connected_order_arc_655  -15
    arc_0_14_12  in_degree_779  1
    arc_0_14_12  out_degree_790  1
    arc_0_14_12  original_T_including_depot_unload_813  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_654  1
    load_0_14_12  free_load_conservation_783  -1
    load_0_14_12  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_656  -30
    arc_0_14_13  connected_order_arc_657  -15
    arc_0_14_13  in_degree_785  1
    arc_0_14_13  out_degree_790  1
    arc_0_14_13  original_T_including_depot_unload_813  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_656  1
    load_0_14_13  free_load_conservation_789  -1
    load_0_14_13  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_658  -30
    arc_0_14_15  connected_order_arc_659  -15
    arc_0_14_15  out_degree_790  1
    arc_0_14_15  in_degree_797  1
    arc_0_14_15  original_T_including_depot_unload_813  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_658  1
    load_0_14_15  free_load_conservation_795  1
    load_0_14_15  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_660  -30
    arc_0_14_16  connected_order_arc_661  -15
    arc_0_14_16  out_degree_790  1
    arc_0_14_16  in_degree_803  1
    arc_0_14_16  original_T_including_depot_unload_813  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_660  1
    load_0_14_16  free_load_conservation_795  1
    load_0_14_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_662  -30
    arc_0_15_0  depot_return_or_bypass_717  1
    arc_0_15_0  out_degree_796  1
    arc_0_15_0  original_T_including_depot_unload_813  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_662  1
    load_0_15_0  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_663  -30
    arc_0_15_1  connected_order_arc_664  -15
    arc_0_15_1  in_degree_719  1
    arc_0_15_1  out_degree_796  1
    arc_0_15_1  original_T_including_depot_unload_813  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_663  1
    load_0_15_1  segment_load_conservation_722  -1
    load_0_15_1  segment_prefix_lb_723  1
    load_0_15_1  segment_prefix_ub_724  1
    load_0_15_1  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_665  -30
    arc_0_15_2  connected_order_arc_666  -15
    arc_0_15_2  in_degree_726  1
    arc_0_15_2  out_degree_796  1
    arc_0_15_2  original_T_including_depot_unload_813  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_665  1
    load_0_15_2  segment_load_conservation_729  -1
    load_0_15_2  segment_prefix_lb_730  1
    load_0_15_2  segment_prefix_ub_731  1
    load_0_15_2  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_667  -30
    arc_0_15_3  connected_order_arc_668  -15
    arc_0_15_3  in_degree_733  1
    arc_0_15_3  out_degree_796  1
    arc_0_15_3  original_T_including_depot_unload_813  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_667  1
    load_0_15_3  segment_load_conservation_736  -1
    load_0_15_3  segment_prefix_lb_737  1
    load_0_15_3  segment_prefix_ub_738  1
    load_0_15_3  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_669  -30
    arc_0_15_4  connected_order_arc_670  -15
    arc_0_15_4  in_degree_740  1
    arc_0_15_4  out_degree_796  1
    arc_0_15_4  original_T_including_depot_unload_813  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_669  1
    load_0_15_4  segment_load_conservation_743  -1
    load_0_15_4  segment_prefix_lb_744  1
    load_0_15_4  segment_prefix_ub_745  1
    load_0_15_4  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_671  -30
    arc_0_15_5  connected_order_arc_672  -15
    arc_0_15_5  in_degree_747  1
    arc_0_15_5  out_degree_796  1
    arc_0_15_5  original_T_including_depot_unload_813  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_671  1
    load_0_15_5  segment_load_conservation_750  -1
    load_0_15_5  segment_prefix_lb_751  1
    load_0_15_5  segment_prefix_ub_752  1
    load_0_15_5  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_673  -30
    arc_0_15_6  connected_order_arc_674  -15
    arc_0_15_6  in_degree_754  1
    arc_0_15_6  out_degree_796  1
    arc_0_15_6  original_T_including_depot_unload_813  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_673  1
    load_0_15_6  segment_load_conservation_757  -1
    load_0_15_6  segment_prefix_lb_758  1
    load_0_15_6  segment_prefix_ub_759  1
    load_0_15_6  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_675  -30
    arc_0_15_9  connected_order_arc_676  -15
    arc_0_15_9  in_degree_761  1
    arc_0_15_9  out_degree_796  1
    arc_0_15_9  original_T_including_depot_unload_813  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_675  1
    load_0_15_9  free_load_conservation_765  -1
    load_0_15_9  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_677  -30
    arc_0_15_10  connected_order_arc_678  -15
    arc_0_15_10  in_degree_767  1
    arc_0_15_10  out_degree_796  1
    arc_0_15_10  original_T_including_depot_unload_813  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_677  1
    load_0_15_10  free_load_conservation_771  -1
    load_0_15_10  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_679  -30
    arc_0_15_11  connected_order_arc_680  -15
    arc_0_15_11  in_degree_773  1
    arc_0_15_11  out_degree_796  1
    arc_0_15_11  original_T_including_depot_unload_813  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_679  1
    load_0_15_11  free_load_conservation_777  -1
    load_0_15_11  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_681  -30
    arc_0_15_12  connected_order_arc_682  -15
    arc_0_15_12  in_degree_779  1
    arc_0_15_12  out_degree_796  1
    arc_0_15_12  original_T_including_depot_unload_813  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_681  1
    load_0_15_12  free_load_conservation_783  -1
    load_0_15_12  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_683  -30
    arc_0_15_13  connected_order_arc_684  -15
    arc_0_15_13  in_degree_785  1
    arc_0_15_13  out_degree_796  1
    arc_0_15_13  original_T_including_depot_unload_813  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_683  1
    load_0_15_13  free_load_conservation_789  -1
    load_0_15_13  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_685  -30
    arc_0_15_14  connected_order_arc_686  -15
    arc_0_15_14  in_degree_791  1
    arc_0_15_14  out_degree_796  1
    arc_0_15_14  original_T_including_depot_unload_813  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_685  1
    load_0_15_14  free_load_conservation_795  -1
    load_0_15_14  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_687  -30
    arc_0_15_16  connected_order_arc_688  -15
    arc_0_15_16  out_degree_796  1
    arc_0_15_16  in_degree_803  1
    arc_0_15_16  original_T_including_depot_unload_813  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_687  1
    load_0_15_16  free_load_conservation_801  1
    load_0_15_16  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_689  -30
    arc_0_16_0  depot_return_or_bypass_717  1
    arc_0_16_0  out_degree_802  1
    arc_0_16_0  original_T_including_depot_unload_813  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_689  1
    load_0_16_0  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_690  -30
    arc_0_16_1  connected_order_arc_691  -15
    arc_0_16_1  in_degree_719  1
    arc_0_16_1  out_degree_802  1
    arc_0_16_1  original_T_including_depot_unload_813  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_690  1
    load_0_16_1  segment_load_conservation_722  -1
    load_0_16_1  segment_prefix_lb_723  1
    load_0_16_1  segment_prefix_ub_724  1
    load_0_16_1  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_692  -30
    arc_0_16_2  connected_order_arc_693  -15
    arc_0_16_2  in_degree_726  1
    arc_0_16_2  out_degree_802  1
    arc_0_16_2  original_T_including_depot_unload_813  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_692  1
    load_0_16_2  segment_load_conservation_729  -1
    load_0_16_2  segment_prefix_lb_730  1
    load_0_16_2  segment_prefix_ub_731  1
    load_0_16_2  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_694  -30
    arc_0_16_3  connected_order_arc_695  -15
    arc_0_16_3  in_degree_733  1
    arc_0_16_3  out_degree_802  1
    arc_0_16_3  original_T_including_depot_unload_813  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_694  1
    load_0_16_3  segment_load_conservation_736  -1
    load_0_16_3  segment_prefix_lb_737  1
    load_0_16_3  segment_prefix_ub_738  1
    load_0_16_3  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_696  -30
    arc_0_16_4  connected_order_arc_697  -15
    arc_0_16_4  in_degree_740  1
    arc_0_16_4  out_degree_802  1
    arc_0_16_4  original_T_including_depot_unload_813  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_696  1
    load_0_16_4  segment_load_conservation_743  -1
    load_0_16_4  segment_prefix_lb_744  1
    load_0_16_4  segment_prefix_ub_745  1
    load_0_16_4  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_698  -30
    arc_0_16_5  connected_order_arc_699  -15
    arc_0_16_5  in_degree_747  1
    arc_0_16_5  out_degree_802  1
    arc_0_16_5  original_T_including_depot_unload_813  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_698  1
    load_0_16_5  segment_load_conservation_750  -1
    load_0_16_5  segment_prefix_lb_751  1
    load_0_16_5  segment_prefix_ub_752  1
    load_0_16_5  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_700  -30
    arc_0_16_6  connected_order_arc_701  -15
    arc_0_16_6  in_degree_754  1
    arc_0_16_6  out_degree_802  1
    arc_0_16_6  original_T_including_depot_unload_813  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_700  1
    load_0_16_6  segment_load_conservation_757  -1
    load_0_16_6  segment_prefix_lb_758  1
    load_0_16_6  segment_prefix_ub_759  1
    load_0_16_6  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_9  arc_capacity_702  -30
    arc_0_16_9  connected_order_arc_703  -15
    arc_0_16_9  in_degree_761  1
    arc_0_16_9  out_degree_802  1
    arc_0_16_9  original_T_including_depot_unload_813  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_9  arc_capacity_702  1
    load_0_16_9  free_load_conservation_765  -1
    load_0_16_9  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_10  arc_capacity_704  -30
    arc_0_16_10  connected_order_arc_705  -15
    arc_0_16_10  in_degree_767  1
    arc_0_16_10  out_degree_802  1
    arc_0_16_10  original_T_including_depot_unload_813  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_10  arc_capacity_704  1
    load_0_16_10  free_load_conservation_771  -1
    load_0_16_10  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_706  -30
    arc_0_16_11  connected_order_arc_707  -15
    arc_0_16_11  in_degree_773  1
    arc_0_16_11  out_degree_802  1
    arc_0_16_11  original_T_including_depot_unload_813  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_706  1
    load_0_16_11  free_load_conservation_777  -1
    load_0_16_11  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_708  -30
    arc_0_16_12  connected_order_arc_709  -15
    arc_0_16_12  in_degree_779  1
    arc_0_16_12  out_degree_802  1
    arc_0_16_12  original_T_including_depot_unload_813  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_708  1
    load_0_16_12  free_load_conservation_783  -1
    load_0_16_12  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_710  -30
    arc_0_16_13  connected_order_arc_711  -15
    arc_0_16_13  in_degree_785  1
    arc_0_16_13  out_degree_802  1
    arc_0_16_13  original_T_including_depot_unload_813  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_710  1
    load_0_16_13  free_load_conservation_789  -1
    load_0_16_13  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_712  -30
    arc_0_16_14  connected_order_arc_713  -15
    arc_0_16_14  in_degree_791  1
    arc_0_16_14  out_degree_802  1
    arc_0_16_14  original_T_including_depot_unload_813  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_712  1
    load_0_16_14  free_load_conservation_795  -1
    load_0_16_14  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_714  -30
    arc_0_16_15  connected_order_arc_715  -15
    arc_0_16_15  in_degree_797  1
    arc_0_16_15  out_degree_802  1
    arc_0_16_15  original_T_including_depot_unload_813  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_714  1
    load_0_16_15  free_load_conservation_801  -1
    load_0_16_15  free_load_conservation_807  1
    visit_1_7  out_degree_1017  -1
    visit_1_7  in_degree_1018  -1
    visit_1_7  order_active_lb_1019  -1
    visit_1_7  order_active_ub_1020  -10
    order_1_7  connected_order_arc_827  -1
    order_1_7  connected_order_arc_829  -1
    order_1_7  connected_order_arc_831  -1
    order_1_7  connected_order_arc_833  -1
    order_1_7  connected_order_arc_835  -1
    order_1_7  connected_order_arc_837  -1
    order_1_7  connected_order_arc_839  -1
    order_1_7  connected_order_arc_841  -1
    order_1_7  connected_order_arc_843  -1
    order_1_7  connected_order_arc_846  1
    order_1_7  connected_order_arc_865  1
    order_1_7  connected_order_arc_884  1
    order_1_7  connected_order_arc_903  1
    order_1_7  connected_order_arc_922  1
    order_1_7  connected_order_arc_941  1
    order_1_7  connected_order_arc_960  1
    order_1_7  connected_order_arc_979  1
    order_1_7  connected_order_arc_998  1
    order_1_7  order_active_lb_1019  1
    order_1_7  order_active_ub_1020  1
    order_1_7  fixed_segment_relative_order_1079  -1
    visit_1_8  out_degree_1024  -1
    visit_1_8  in_degree_1025  -1
    visit_1_8  order_active_lb_1026  -1
    visit_1_8  order_active_ub_1027  -10
    order_1_8  connected_order_arc_827  1
    order_1_8  connected_order_arc_846  -1
    order_1_8  connected_order_arc_848  -1
    order_1_8  connected_order_arc_850  -1
    order_1_8  connected_order_arc_852  -1
    order_1_8  connected_order_arc_854  -1
    order_1_8  connected_order_arc_856  -1
    order_1_8  connected_order_arc_858  -1
    order_1_8  connected_order_arc_860  -1
    order_1_8  connected_order_arc_862  -1
    order_1_8  connected_order_arc_867  1
    order_1_8  connected_order_arc_886  1
    order_1_8  connected_order_arc_905  1
    order_1_8  connected_order_arc_924  1
    order_1_8  connected_order_arc_943  1
    order_1_8  connected_order_arc_962  1
    order_1_8  connected_order_arc_981  1
    order_1_8  connected_order_arc_1000  1
    order_1_8  order_active_lb_1026  1
    order_1_8  order_active_ub_1027  1
    order_1_8  fixed_segment_relative_order_1079  1
    visit_1_9  out_degree_1031  -1
    visit_1_9  in_degree_1032  -1
    visit_1_9  order_active_lb_1033  -1
    visit_1_9  order_active_ub_1034  -10
    visit_1_9  service_visit_def_1035  -1
    order_1_9  connected_order_arc_829  1
    order_1_9  connected_order_arc_848  1
    order_1_9  connected_order_arc_865  -1
    order_1_9  connected_order_arc_867  -1
    order_1_9  connected_order_arc_869  -1
    order_1_9  connected_order_arc_871  -1
    order_1_9  connected_order_arc_873  -1
    order_1_9  connected_order_arc_875  -1
    order_1_9  connected_order_arc_877  -1
    order_1_9  connected_order_arc_879  -1
    order_1_9  connected_order_arc_881  -1
    order_1_9  connected_order_arc_888  1
    order_1_9  connected_order_arc_907  1
    order_1_9  connected_order_arc_926  1
    order_1_9  connected_order_arc_945  1
    order_1_9  connected_order_arc_964  1
    order_1_9  connected_order_arc_983  1
    order_1_9  connected_order_arc_1002  1
    order_1_9  order_active_lb_1033  1
    order_1_9  order_active_ub_1034  1
    visit_1_10  out_degree_1037  -1
    visit_1_10  in_degree_1038  -1
    visit_1_10  order_active_lb_1039  -1
    visit_1_10  order_active_ub_1040  -10
    visit_1_10  service_visit_def_1041  -1
    order_1_10  connected_order_arc_831  1
    order_1_10  connected_order_arc_850  1
    order_1_10  connected_order_arc_869  1
    order_1_10  connected_order_arc_884  -1
    order_1_10  connected_order_arc_886  -1
    order_1_10  connected_order_arc_888  -1
    order_1_10  connected_order_arc_890  -1
    order_1_10  connected_order_arc_892  -1
    order_1_10  connected_order_arc_894  -1
    order_1_10  connected_order_arc_896  -1
    order_1_10  connected_order_arc_898  -1
    order_1_10  connected_order_arc_900  -1
    order_1_10  connected_order_arc_909  1
    order_1_10  connected_order_arc_928  1
    order_1_10  connected_order_arc_947  1
    order_1_10  connected_order_arc_966  1
    order_1_10  connected_order_arc_985  1
    order_1_10  connected_order_arc_1004  1
    order_1_10  order_active_lb_1039  1
    order_1_10  order_active_ub_1040  1
    visit_1_11  out_degree_1043  -1
    visit_1_11  in_degree_1044  -1
    visit_1_11  order_active_lb_1045  -1
    visit_1_11  order_active_ub_1046  -10
    visit_1_11  service_visit_def_1047  -1
    order_1_11  connected_order_arc_833  1
    order_1_11  connected_order_arc_852  1
    order_1_11  connected_order_arc_871  1
    order_1_11  connected_order_arc_890  1
    order_1_11  connected_order_arc_903  -1
    order_1_11  connected_order_arc_905  -1
    order_1_11  connected_order_arc_907  -1
    order_1_11  connected_order_arc_909  -1
    order_1_11  connected_order_arc_911  -1
    order_1_11  connected_order_arc_913  -1
    order_1_11  connected_order_arc_915  -1
    order_1_11  connected_order_arc_917  -1
    order_1_11  connected_order_arc_919  -1
    order_1_11  connected_order_arc_930  1
    order_1_11  connected_order_arc_949  1
    order_1_11  connected_order_arc_968  1
    order_1_11  connected_order_arc_987  1
    order_1_11  connected_order_arc_1006  1
    order_1_11  order_active_lb_1045  1
    order_1_11  order_active_ub_1046  1
    visit_1_12  out_degree_1049  -1
    visit_1_12  in_degree_1050  -1
    visit_1_12  order_active_lb_1051  -1
    visit_1_12  order_active_ub_1052  -10
    visit_1_12  service_visit_def_1053  -1
    order_1_12  connected_order_arc_835  1
    order_1_12  connected_order_arc_854  1
    order_1_12  connected_order_arc_873  1
    order_1_12  connected_order_arc_892  1
    order_1_12  connected_order_arc_911  1
    order_1_12  connected_order_arc_922  -1
    order_1_12  connected_order_arc_924  -1
    order_1_12  connected_order_arc_926  -1
    order_1_12  connected_order_arc_928  -1
    order_1_12  connected_order_arc_930  -1
    order_1_12  connected_order_arc_932  -1
    order_1_12  connected_order_arc_934  -1
    order_1_12  connected_order_arc_936  -1
    order_1_12  connected_order_arc_938  -1
    order_1_12  connected_order_arc_951  1
    order_1_12  connected_order_arc_970  1
    order_1_12  connected_order_arc_989  1
    order_1_12  connected_order_arc_1008  1
    order_1_12  order_active_lb_1051  1
    order_1_12  order_active_ub_1052  1
    visit_1_13  out_degree_1055  -1
    visit_1_13  in_degree_1056  -1
    visit_1_13  order_active_lb_1057  -1
    visit_1_13  order_active_ub_1058  -10
    visit_1_13  service_visit_def_1059  -1
    order_1_13  connected_order_arc_837  1
    order_1_13  connected_order_arc_856  1
    order_1_13  connected_order_arc_875  1
    order_1_13  connected_order_arc_894  1
    order_1_13  connected_order_arc_913  1
    order_1_13  connected_order_arc_932  1
    order_1_13  connected_order_arc_941  -1
    order_1_13  connected_order_arc_943  -1
    order_1_13  connected_order_arc_945  -1
    order_1_13  connected_order_arc_947  -1
    order_1_13  connected_order_arc_949  -1
    order_1_13  connected_order_arc_951  -1
    order_1_13  connected_order_arc_953  -1
    order_1_13  connected_order_arc_955  -1
    order_1_13  connected_order_arc_957  -1
    order_1_13  connected_order_arc_972  1
    order_1_13  connected_order_arc_991  1
    order_1_13  connected_order_arc_1010  1
    order_1_13  order_active_lb_1057  1
    order_1_13  order_active_ub_1058  1
    visit_1_14  out_degree_1061  -1
    visit_1_14  in_degree_1062  -1
    visit_1_14  order_active_lb_1063  -1
    visit_1_14  order_active_ub_1064  -10
    visit_1_14  service_visit_def_1065  -1
    order_1_14  connected_order_arc_839  1
    order_1_14  connected_order_arc_858  1
    order_1_14  connected_order_arc_877  1
    order_1_14  connected_order_arc_896  1
    order_1_14  connected_order_arc_915  1
    order_1_14  connected_order_arc_934  1
    order_1_14  connected_order_arc_953  1
    order_1_14  connected_order_arc_960  -1
    order_1_14  connected_order_arc_962  -1
    order_1_14  connected_order_arc_964  -1
    order_1_14  connected_order_arc_966  -1
    order_1_14  connected_order_arc_968  -1
    order_1_14  connected_order_arc_970  -1
    order_1_14  connected_order_arc_972  -1
    order_1_14  connected_order_arc_974  -1
    order_1_14  connected_order_arc_976  -1
    order_1_14  connected_order_arc_993  1
    order_1_14  connected_order_arc_1012  1
    order_1_14  order_active_lb_1063  1
    order_1_14  order_active_ub_1064  1
    visit_1_15  out_degree_1067  -1
    visit_1_15  in_degree_1068  -1
    visit_1_15  order_active_lb_1069  -1
    visit_1_15  order_active_ub_1070  -10
    visit_1_15  service_visit_def_1071  -1
    order_1_15  connected_order_arc_841  1
    order_1_15  connected_order_arc_860  1
    order_1_15  connected_order_arc_879  1
    order_1_15  connected_order_arc_898  1
    order_1_15  connected_order_arc_917  1
    order_1_15  connected_order_arc_936  1
    order_1_15  connected_order_arc_955  1
    order_1_15  connected_order_arc_974  1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_987  -1
    order_1_15  connected_order_arc_989  -1
    order_1_15  connected_order_arc_991  -1
    order_1_15  connected_order_arc_993  -1
    order_1_15  connected_order_arc_995  -1
    order_1_15  connected_order_arc_1014  1
    order_1_15  order_active_lb_1069  1
    order_1_15  order_active_ub_1070  1
    visit_1_16  out_degree_1073  -1
    visit_1_16  in_degree_1074  -1
    visit_1_16  order_active_lb_1075  -1
    visit_1_16  order_active_ub_1076  -10
    visit_1_16  service_visit_def_1077  -1
    order_1_16  connected_order_arc_843  1
    order_1_16  connected_order_arc_862  1
    order_1_16  connected_order_arc_881  1
    order_1_16  connected_order_arc_900  1
    order_1_16  connected_order_arc_919  1
    order_1_16  connected_order_arc_938  1
    order_1_16  connected_order_arc_957  1
    order_1_16  connected_order_arc_976  1
    order_1_16  connected_order_arc_995  1
    order_1_16  connected_order_arc_998  -1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1014  -1
    order_1_16  order_active_lb_1075  1
    order_1_16  order_active_ub_1076  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_814  -30
    arc_1_0_0  depot_departure_or_bypass_1015  1
    arc_1_0_0  depot_return_or_bypass_1016  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_815  -30
    arc_1_0_7  depot_departure_or_bypass_1015  1
    arc_1_0_7  in_degree_1018  1
    arc_1_0_7  original_T_including_depot_unload_1080  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_815  1
    load_1_0_7  segment_load_conservation_1021  -1
    load_1_0_7  segment_prefix_lb_1022  1
    load_1_0_7  segment_prefix_ub_1023  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_816  -30
    arc_1_0_8  depot_departure_or_bypass_1015  1
    arc_1_0_8  in_degree_1025  1
    arc_1_0_8  original_T_including_depot_unload_1080  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_816  1
    load_1_0_8  segment_load_conservation_1028  -1
    load_1_0_8  segment_prefix_lb_1029  1
    load_1_0_8  segment_prefix_ub_1030  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_817  -30
    arc_1_0_9  depot_departure_or_bypass_1015  1
    arc_1_0_9  in_degree_1032  1
    arc_1_0_9  original_T_including_depot_unload_1080  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_817  1
    load_1_0_9  free_load_conservation_1036  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_818  -30
    arc_1_0_10  depot_departure_or_bypass_1015  1
    arc_1_0_10  in_degree_1038  1
    arc_1_0_10  original_T_including_depot_unload_1080  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_818  1
    load_1_0_10  free_load_conservation_1042  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_819  -30
    arc_1_0_11  depot_departure_or_bypass_1015  1
    arc_1_0_11  in_degree_1044  1
    arc_1_0_11  original_T_including_depot_unload_1080  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_819  1
    load_1_0_11  free_load_conservation_1048  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_820  -30
    arc_1_0_12  depot_departure_or_bypass_1015  1
    arc_1_0_12  in_degree_1050  1
    arc_1_0_12  original_T_including_depot_unload_1080  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_820  1
    load_1_0_12  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_821  -30
    arc_1_0_13  depot_departure_or_bypass_1015  1
    arc_1_0_13  in_degree_1056  1
    arc_1_0_13  original_T_including_depot_unload_1080  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_821  1
    load_1_0_13  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_822  -30
    arc_1_0_14  depot_departure_or_bypass_1015  1
    arc_1_0_14  in_degree_1062  1
    arc_1_0_14  original_T_including_depot_unload_1080  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_822  1
    load_1_0_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_823  -30
    arc_1_0_15  depot_departure_or_bypass_1015  1
    arc_1_0_15  in_degree_1068  1
    arc_1_0_15  original_T_including_depot_unload_1080  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_823  1
    load_1_0_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_824  -30
    arc_1_0_16  depot_departure_or_bypass_1015  1
    arc_1_0_16  in_degree_1074  1
    arc_1_0_16  original_T_including_depot_unload_1080  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_824  1
    load_1_0_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_825  -30
    arc_1_7_0  depot_return_or_bypass_1016  1
    arc_1_7_0  out_degree_1017  1
    arc_1_7_0  original_T_including_depot_unload_1080  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_825  1
    load_1_7_0  segment_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_826  -30
    arc_1_7_8  connected_order_arc_827  -11
    arc_1_7_8  out_degree_1017  1
    arc_1_7_8  in_degree_1025  1
    arc_1_7_8  original_T_including_depot_unload_1080  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_826  1
    load_1_7_8  segment_load_conservation_1021  1
    load_1_7_8  segment_load_conservation_1028  -1
    load_1_7_8  segment_prefix_lb_1029  1
    load_1_7_8  segment_prefix_ub_1030  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_828  -30
    arc_1_7_9  connected_order_arc_829  -11
    arc_1_7_9  out_degree_1017  1
    arc_1_7_9  in_degree_1032  1
    arc_1_7_9  original_T_including_depot_unload_1080  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_828  1
    load_1_7_9  segment_load_conservation_1021  1
    load_1_7_9  free_load_conservation_1036  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_830  -30
    arc_1_7_10  connected_order_arc_831  -11
    arc_1_7_10  out_degree_1017  1
    arc_1_7_10  in_degree_1038  1
    arc_1_7_10  original_T_including_depot_unload_1080  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_830  1
    load_1_7_10  segment_load_conservation_1021  1
    load_1_7_10  free_load_conservation_1042  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_832  -30
    arc_1_7_11  connected_order_arc_833  -11
    arc_1_7_11  out_degree_1017  1
    arc_1_7_11  in_degree_1044  1
    arc_1_7_11  original_T_including_depot_unload_1080  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_832  1
    load_1_7_11  segment_load_conservation_1021  1
    load_1_7_11  free_load_conservation_1048  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_834  -30
    arc_1_7_12  connected_order_arc_835  -11
    arc_1_7_12  out_degree_1017  1
    arc_1_7_12  in_degree_1050  1
    arc_1_7_12  original_T_including_depot_unload_1080  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_834  1
    load_1_7_12  segment_load_conservation_1021  1
    load_1_7_12  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_836  -30
    arc_1_7_13  connected_order_arc_837  -11
    arc_1_7_13  out_degree_1017  1
    arc_1_7_13  in_degree_1056  1
    arc_1_7_13  original_T_including_depot_unload_1080  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_836  1
    load_1_7_13  segment_load_conservation_1021  1
    load_1_7_13  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_838  -30
    arc_1_7_14  connected_order_arc_839  -11
    arc_1_7_14  out_degree_1017  1
    arc_1_7_14  in_degree_1062  1
    arc_1_7_14  original_T_including_depot_unload_1080  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_838  1
    load_1_7_14  segment_load_conservation_1021  1
    load_1_7_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_840  -30
    arc_1_7_15  connected_order_arc_841  -11
    arc_1_7_15  out_degree_1017  1
    arc_1_7_15  in_degree_1068  1
    arc_1_7_15  original_T_including_depot_unload_1080  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_840  1
    load_1_7_15  segment_load_conservation_1021  1
    load_1_7_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_842  -30
    arc_1_7_16  connected_order_arc_843  -11
    arc_1_7_16  out_degree_1017  1
    arc_1_7_16  in_degree_1074  1
    arc_1_7_16  original_T_including_depot_unload_1080  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_842  1
    load_1_7_16  segment_load_conservation_1021  1
    load_1_7_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_844  -30
    arc_1_8_0  depot_return_or_bypass_1016  1
    arc_1_8_0  out_degree_1024  1
    arc_1_8_0  original_T_including_depot_unload_1080  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_844  1
    load_1_8_0  segment_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_845  -30
    arc_1_8_7  connected_order_arc_846  -11
    arc_1_8_7  in_degree_1018  1
    arc_1_8_7  out_degree_1024  1
    arc_1_8_7  original_T_including_depot_unload_1080  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_845  1
    load_1_8_7  segment_load_conservation_1021  -1
    load_1_8_7  segment_prefix_lb_1022  1
    load_1_8_7  segment_prefix_ub_1023  1
    load_1_8_7  segment_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_847  -30
    arc_1_8_9  connected_order_arc_848  -11
    arc_1_8_9  out_degree_1024  1
    arc_1_8_9  in_degree_1032  1
    arc_1_8_9  original_T_including_depot_unload_1080  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_847  1
    load_1_8_9  segment_load_conservation_1028  1
    load_1_8_9  free_load_conservation_1036  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_849  -30
    arc_1_8_10  connected_order_arc_850  -11
    arc_1_8_10  out_degree_1024  1
    arc_1_8_10  in_degree_1038  1
    arc_1_8_10  original_T_including_depot_unload_1080  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_849  1
    load_1_8_10  segment_load_conservation_1028  1
    load_1_8_10  free_load_conservation_1042  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_851  -30
    arc_1_8_11  connected_order_arc_852  -11
    arc_1_8_11  out_degree_1024  1
    arc_1_8_11  in_degree_1044  1
    arc_1_8_11  original_T_including_depot_unload_1080  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_851  1
    load_1_8_11  segment_load_conservation_1028  1
    load_1_8_11  free_load_conservation_1048  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_853  -30
    arc_1_8_12  connected_order_arc_854  -11
    arc_1_8_12  out_degree_1024  1
    arc_1_8_12  in_degree_1050  1
    arc_1_8_12  original_T_including_depot_unload_1080  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_853  1
    load_1_8_12  segment_load_conservation_1028  1
    load_1_8_12  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_855  -30
    arc_1_8_13  connected_order_arc_856  -11
    arc_1_8_13  out_degree_1024  1
    arc_1_8_13  in_degree_1056  1
    arc_1_8_13  original_T_including_depot_unload_1080  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_855  1
    load_1_8_13  segment_load_conservation_1028  1
    load_1_8_13  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_857  -30
    arc_1_8_14  connected_order_arc_858  -11
    arc_1_8_14  out_degree_1024  1
    arc_1_8_14  in_degree_1062  1
    arc_1_8_14  original_T_including_depot_unload_1080  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_857  1
    load_1_8_14  segment_load_conservation_1028  1
    load_1_8_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_859  -30
    arc_1_8_15  connected_order_arc_860  -11
    arc_1_8_15  out_degree_1024  1
    arc_1_8_15  in_degree_1068  1
    arc_1_8_15  original_T_including_depot_unload_1080  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_859  1
    load_1_8_15  segment_load_conservation_1028  1
    load_1_8_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_861  -30
    arc_1_8_16  connected_order_arc_862  -11
    arc_1_8_16  out_degree_1024  1
    arc_1_8_16  in_degree_1074  1
    arc_1_8_16  original_T_including_depot_unload_1080  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_861  1
    load_1_8_16  segment_load_conservation_1028  1
    load_1_8_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_863  -30
    arc_1_9_0  depot_return_or_bypass_1016  1
    arc_1_9_0  out_degree_1031  1
    arc_1_9_0  original_T_including_depot_unload_1080  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_863  1
    load_1_9_0  free_load_conservation_1036  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_864  -30
    arc_1_9_7  connected_order_arc_865  -11
    arc_1_9_7  in_degree_1018  1
    arc_1_9_7  out_degree_1031  1
    arc_1_9_7  original_T_including_depot_unload_1080  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_864  1
    load_1_9_7  segment_load_conservation_1021  -1
    load_1_9_7  segment_prefix_lb_1022  1
    load_1_9_7  segment_prefix_ub_1023  1
    load_1_9_7  free_load_conservation_1036  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_866  -30
    arc_1_9_8  connected_order_arc_867  -11
    arc_1_9_8  in_degree_1025  1
    arc_1_9_8  out_degree_1031  1
    arc_1_9_8  original_T_including_depot_unload_1080  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_866  1
    load_1_9_8  segment_load_conservation_1028  -1
    load_1_9_8  segment_prefix_lb_1029  1
    load_1_9_8  segment_prefix_ub_1030  1
    load_1_9_8  free_load_conservation_1036  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_868  -30
    arc_1_9_10  connected_order_arc_869  -11
    arc_1_9_10  out_degree_1031  1
    arc_1_9_10  in_degree_1038  1
    arc_1_9_10  original_T_including_depot_unload_1080  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_868  1
    load_1_9_10  free_load_conservation_1036  1
    load_1_9_10  free_load_conservation_1042  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_870  -30
    arc_1_9_11  connected_order_arc_871  -11
    arc_1_9_11  out_degree_1031  1
    arc_1_9_11  in_degree_1044  1
    arc_1_9_11  original_T_including_depot_unload_1080  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_870  1
    load_1_9_11  free_load_conservation_1036  1
    load_1_9_11  free_load_conservation_1048  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_872  -30
    arc_1_9_12  connected_order_arc_873  -11
    arc_1_9_12  out_degree_1031  1
    arc_1_9_12  in_degree_1050  1
    arc_1_9_12  original_T_including_depot_unload_1080  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_872  1
    load_1_9_12  free_load_conservation_1036  1
    load_1_9_12  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_874  -30
    arc_1_9_13  connected_order_arc_875  -11
    arc_1_9_13  out_degree_1031  1
    arc_1_9_13  in_degree_1056  1
    arc_1_9_13  original_T_including_depot_unload_1080  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_874  1
    load_1_9_13  free_load_conservation_1036  1
    load_1_9_13  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_876  -30
    arc_1_9_14  connected_order_arc_877  -11
    arc_1_9_14  out_degree_1031  1
    arc_1_9_14  in_degree_1062  1
    arc_1_9_14  original_T_including_depot_unload_1080  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_876  1
    load_1_9_14  free_load_conservation_1036  1
    load_1_9_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_878  -30
    arc_1_9_15  connected_order_arc_879  -11
    arc_1_9_15  out_degree_1031  1
    arc_1_9_15  in_degree_1068  1
    arc_1_9_15  original_T_including_depot_unload_1080  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_878  1
    load_1_9_15  free_load_conservation_1036  1
    load_1_9_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_880  -30
    arc_1_9_16  connected_order_arc_881  -11
    arc_1_9_16  out_degree_1031  1
    arc_1_9_16  in_degree_1074  1
    arc_1_9_16  original_T_including_depot_unload_1080  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_880  1
    load_1_9_16  free_load_conservation_1036  1
    load_1_9_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_882  -30
    arc_1_10_0  depot_return_or_bypass_1016  1
    arc_1_10_0  out_degree_1037  1
    arc_1_10_0  original_T_including_depot_unload_1080  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_882  1
    load_1_10_0  free_load_conservation_1042  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_883  -30
    arc_1_10_7  connected_order_arc_884  -11
    arc_1_10_7  in_degree_1018  1
    arc_1_10_7  out_degree_1037  1
    arc_1_10_7  original_T_including_depot_unload_1080  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_883  1
    load_1_10_7  segment_load_conservation_1021  -1
    load_1_10_7  segment_prefix_lb_1022  1
    load_1_10_7  segment_prefix_ub_1023  1
    load_1_10_7  free_load_conservation_1042  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_885  -30
    arc_1_10_8  connected_order_arc_886  -11
    arc_1_10_8  in_degree_1025  1
    arc_1_10_8  out_degree_1037  1
    arc_1_10_8  original_T_including_depot_unload_1080  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_885  1
    load_1_10_8  segment_load_conservation_1028  -1
    load_1_10_8  segment_prefix_lb_1029  1
    load_1_10_8  segment_prefix_ub_1030  1
    load_1_10_8  free_load_conservation_1042  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_887  -30
    arc_1_10_9  connected_order_arc_888  -11
    arc_1_10_9  in_degree_1032  1
    arc_1_10_9  out_degree_1037  1
    arc_1_10_9  original_T_including_depot_unload_1080  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_887  1
    load_1_10_9  free_load_conservation_1036  -1
    load_1_10_9  free_load_conservation_1042  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_889  -30
    arc_1_10_11  connected_order_arc_890  -11
    arc_1_10_11  out_degree_1037  1
    arc_1_10_11  in_degree_1044  1
    arc_1_10_11  original_T_including_depot_unload_1080  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_889  1
    load_1_10_11  free_load_conservation_1042  1
    load_1_10_11  free_load_conservation_1048  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_891  -30
    arc_1_10_12  connected_order_arc_892  -11
    arc_1_10_12  out_degree_1037  1
    arc_1_10_12  in_degree_1050  1
    arc_1_10_12  original_T_including_depot_unload_1080  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_891  1
    load_1_10_12  free_load_conservation_1042  1
    load_1_10_12  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_893  -30
    arc_1_10_13  connected_order_arc_894  -11
    arc_1_10_13  out_degree_1037  1
    arc_1_10_13  in_degree_1056  1
    arc_1_10_13  original_T_including_depot_unload_1080  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_893  1
    load_1_10_13  free_load_conservation_1042  1
    load_1_10_13  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_895  -30
    arc_1_10_14  connected_order_arc_896  -11
    arc_1_10_14  out_degree_1037  1
    arc_1_10_14  in_degree_1062  1
    arc_1_10_14  original_T_including_depot_unload_1080  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_895  1
    load_1_10_14  free_load_conservation_1042  1
    load_1_10_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_897  -30
    arc_1_10_15  connected_order_arc_898  -11
    arc_1_10_15  out_degree_1037  1
    arc_1_10_15  in_degree_1068  1
    arc_1_10_15  original_T_including_depot_unload_1080  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_897  1
    load_1_10_15  free_load_conservation_1042  1
    load_1_10_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_899  -30
    arc_1_10_16  connected_order_arc_900  -11
    arc_1_10_16  out_degree_1037  1
    arc_1_10_16  in_degree_1074  1
    arc_1_10_16  original_T_including_depot_unload_1080  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_899  1
    load_1_10_16  free_load_conservation_1042  1
    load_1_10_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_901  -30
    arc_1_11_0  depot_return_or_bypass_1016  1
    arc_1_11_0  out_degree_1043  1
    arc_1_11_0  original_T_including_depot_unload_1080  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_901  1
    load_1_11_0  free_load_conservation_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_902  -30
    arc_1_11_7  connected_order_arc_903  -11
    arc_1_11_7  in_degree_1018  1
    arc_1_11_7  out_degree_1043  1
    arc_1_11_7  original_T_including_depot_unload_1080  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_902  1
    load_1_11_7  segment_load_conservation_1021  -1
    load_1_11_7  segment_prefix_lb_1022  1
    load_1_11_7  segment_prefix_ub_1023  1
    load_1_11_7  free_load_conservation_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_904  -30
    arc_1_11_8  connected_order_arc_905  -11
    arc_1_11_8  in_degree_1025  1
    arc_1_11_8  out_degree_1043  1
    arc_1_11_8  original_T_including_depot_unload_1080  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_904  1
    load_1_11_8  segment_load_conservation_1028  -1
    load_1_11_8  segment_prefix_lb_1029  1
    load_1_11_8  segment_prefix_ub_1030  1
    load_1_11_8  free_load_conservation_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_906  -30
    arc_1_11_9  connected_order_arc_907  -11
    arc_1_11_9  in_degree_1032  1
    arc_1_11_9  out_degree_1043  1
    arc_1_11_9  original_T_including_depot_unload_1080  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_906  1
    load_1_11_9  free_load_conservation_1036  -1
    load_1_11_9  free_load_conservation_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_908  -30
    arc_1_11_10  connected_order_arc_909  -11
    arc_1_11_10  in_degree_1038  1
    arc_1_11_10  out_degree_1043  1
    arc_1_11_10  original_T_including_depot_unload_1080  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_908  1
    load_1_11_10  free_load_conservation_1042  -1
    load_1_11_10  free_load_conservation_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_910  -30
    arc_1_11_12  connected_order_arc_911  -11
    arc_1_11_12  out_degree_1043  1
    arc_1_11_12  in_degree_1050  1
    arc_1_11_12  original_T_including_depot_unload_1080  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_910  1
    load_1_11_12  free_load_conservation_1048  1
    load_1_11_12  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_912  -30
    arc_1_11_13  connected_order_arc_913  -11
    arc_1_11_13  out_degree_1043  1
    arc_1_11_13  in_degree_1056  1
    arc_1_11_13  original_T_including_depot_unload_1080  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_912  1
    load_1_11_13  free_load_conservation_1048  1
    load_1_11_13  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_914  -30
    arc_1_11_14  connected_order_arc_915  -11
    arc_1_11_14  out_degree_1043  1
    arc_1_11_14  in_degree_1062  1
    arc_1_11_14  original_T_including_depot_unload_1080  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_914  1
    load_1_11_14  free_load_conservation_1048  1
    load_1_11_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_916  -30
    arc_1_11_15  connected_order_arc_917  -11
    arc_1_11_15  out_degree_1043  1
    arc_1_11_15  in_degree_1068  1
    arc_1_11_15  original_T_including_depot_unload_1080  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_916  1
    load_1_11_15  free_load_conservation_1048  1
    load_1_11_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_918  -30
    arc_1_11_16  connected_order_arc_919  -11
    arc_1_11_16  out_degree_1043  1
    arc_1_11_16  in_degree_1074  1
    arc_1_11_16  original_T_including_depot_unload_1080  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_918  1
    load_1_11_16  free_load_conservation_1048  1
    load_1_11_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_920  -30
    arc_1_12_0  depot_return_or_bypass_1016  1
    arc_1_12_0  out_degree_1049  1
    arc_1_12_0  original_T_including_depot_unload_1080  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_920  1
    load_1_12_0  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_921  -30
    arc_1_12_7  connected_order_arc_922  -11
    arc_1_12_7  in_degree_1018  1
    arc_1_12_7  out_degree_1049  1
    arc_1_12_7  original_T_including_depot_unload_1080  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_921  1
    load_1_12_7  segment_load_conservation_1021  -1
    load_1_12_7  segment_prefix_lb_1022  1
    load_1_12_7  segment_prefix_ub_1023  1
    load_1_12_7  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_923  -30
    arc_1_12_8  connected_order_arc_924  -11
    arc_1_12_8  in_degree_1025  1
    arc_1_12_8  out_degree_1049  1
    arc_1_12_8  original_T_including_depot_unload_1080  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_923  1
    load_1_12_8  segment_load_conservation_1028  -1
    load_1_12_8  segment_prefix_lb_1029  1
    load_1_12_8  segment_prefix_ub_1030  1
    load_1_12_8  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_925  -30
    arc_1_12_9  connected_order_arc_926  -11
    arc_1_12_9  in_degree_1032  1
    arc_1_12_9  out_degree_1049  1
    arc_1_12_9  original_T_including_depot_unload_1080  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_925  1
    load_1_12_9  free_load_conservation_1036  -1
    load_1_12_9  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_927  -30
    arc_1_12_10  connected_order_arc_928  -11
    arc_1_12_10  in_degree_1038  1
    arc_1_12_10  out_degree_1049  1
    arc_1_12_10  original_T_including_depot_unload_1080  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_927  1
    load_1_12_10  free_load_conservation_1042  -1
    load_1_12_10  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_929  -30
    arc_1_12_11  connected_order_arc_930  -11
    arc_1_12_11  in_degree_1044  1
    arc_1_12_11  out_degree_1049  1
    arc_1_12_11  original_T_including_depot_unload_1080  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_929  1
    load_1_12_11  free_load_conservation_1048  -1
    load_1_12_11  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_931  -30
    arc_1_12_13  connected_order_arc_932  -11
    arc_1_12_13  out_degree_1049  1
    arc_1_12_13  in_degree_1056  1
    arc_1_12_13  original_T_including_depot_unload_1080  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_931  1
    load_1_12_13  free_load_conservation_1054  1
    load_1_12_13  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_933  -30
    arc_1_12_14  connected_order_arc_934  -11
    arc_1_12_14  out_degree_1049  1
    arc_1_12_14  in_degree_1062  1
    arc_1_12_14  original_T_including_depot_unload_1080  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_933  1
    load_1_12_14  free_load_conservation_1054  1
    load_1_12_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_935  -30
    arc_1_12_15  connected_order_arc_936  -11
    arc_1_12_15  out_degree_1049  1
    arc_1_12_15  in_degree_1068  1
    arc_1_12_15  original_T_including_depot_unload_1080  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_935  1
    load_1_12_15  free_load_conservation_1054  1
    load_1_12_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_937  -30
    arc_1_12_16  connected_order_arc_938  -11
    arc_1_12_16  out_degree_1049  1
    arc_1_12_16  in_degree_1074  1
    arc_1_12_16  original_T_including_depot_unload_1080  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_937  1
    load_1_12_16  free_load_conservation_1054  1
    load_1_12_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_939  -30
    arc_1_13_0  depot_return_or_bypass_1016  1
    arc_1_13_0  out_degree_1055  1
    arc_1_13_0  original_T_including_depot_unload_1080  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_939  1
    load_1_13_0  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_940  -30
    arc_1_13_7  connected_order_arc_941  -11
    arc_1_13_7  in_degree_1018  1
    arc_1_13_7  out_degree_1055  1
    arc_1_13_7  original_T_including_depot_unload_1080  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_940  1
    load_1_13_7  segment_load_conservation_1021  -1
    load_1_13_7  segment_prefix_lb_1022  1
    load_1_13_7  segment_prefix_ub_1023  1
    load_1_13_7  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_942  -30
    arc_1_13_8  connected_order_arc_943  -11
    arc_1_13_8  in_degree_1025  1
    arc_1_13_8  out_degree_1055  1
    arc_1_13_8  original_T_including_depot_unload_1080  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_942  1
    load_1_13_8  segment_load_conservation_1028  -1
    load_1_13_8  segment_prefix_lb_1029  1
    load_1_13_8  segment_prefix_ub_1030  1
    load_1_13_8  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_944  -30
    arc_1_13_9  connected_order_arc_945  -11
    arc_1_13_9  in_degree_1032  1
    arc_1_13_9  out_degree_1055  1
    arc_1_13_9  original_T_including_depot_unload_1080  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_944  1
    load_1_13_9  free_load_conservation_1036  -1
    load_1_13_9  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_946  -30
    arc_1_13_10  connected_order_arc_947  -11
    arc_1_13_10  in_degree_1038  1
    arc_1_13_10  out_degree_1055  1
    arc_1_13_10  original_T_including_depot_unload_1080  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_946  1
    load_1_13_10  free_load_conservation_1042  -1
    load_1_13_10  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_948  -30
    arc_1_13_11  connected_order_arc_949  -11
    arc_1_13_11  in_degree_1044  1
    arc_1_13_11  out_degree_1055  1
    arc_1_13_11  original_T_including_depot_unload_1080  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_948  1
    load_1_13_11  free_load_conservation_1048  -1
    load_1_13_11  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_950  -30
    arc_1_13_12  connected_order_arc_951  -11
    arc_1_13_12  in_degree_1050  1
    arc_1_13_12  out_degree_1055  1
    arc_1_13_12  original_T_including_depot_unload_1080  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_950  1
    load_1_13_12  free_load_conservation_1054  -1
    load_1_13_12  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_952  -30
    arc_1_13_14  connected_order_arc_953  -11
    arc_1_13_14  out_degree_1055  1
    arc_1_13_14  in_degree_1062  1
    arc_1_13_14  original_T_including_depot_unload_1080  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_952  1
    load_1_13_14  free_load_conservation_1060  1
    load_1_13_14  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_954  -30
    arc_1_13_15  connected_order_arc_955  -11
    arc_1_13_15  out_degree_1055  1
    arc_1_13_15  in_degree_1068  1
    arc_1_13_15  original_T_including_depot_unload_1080  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_954  1
    load_1_13_15  free_load_conservation_1060  1
    load_1_13_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_956  -30
    arc_1_13_16  connected_order_arc_957  -11
    arc_1_13_16  out_degree_1055  1
    arc_1_13_16  in_degree_1074  1
    arc_1_13_16  original_T_including_depot_unload_1080  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_956  1
    load_1_13_16  free_load_conservation_1060  1
    load_1_13_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_958  -30
    arc_1_14_0  depot_return_or_bypass_1016  1
    arc_1_14_0  out_degree_1061  1
    arc_1_14_0  original_T_including_depot_unload_1080  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_958  1
    load_1_14_0  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_959  -30
    arc_1_14_7  connected_order_arc_960  -11
    arc_1_14_7  in_degree_1018  1
    arc_1_14_7  out_degree_1061  1
    arc_1_14_7  original_T_including_depot_unload_1080  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_959  1
    load_1_14_7  segment_load_conservation_1021  -1
    load_1_14_7  segment_prefix_lb_1022  1
    load_1_14_7  segment_prefix_ub_1023  1
    load_1_14_7  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_961  -30
    arc_1_14_8  connected_order_arc_962  -11
    arc_1_14_8  in_degree_1025  1
    arc_1_14_8  out_degree_1061  1
    arc_1_14_8  original_T_including_depot_unload_1080  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_961  1
    load_1_14_8  segment_load_conservation_1028  -1
    load_1_14_8  segment_prefix_lb_1029  1
    load_1_14_8  segment_prefix_ub_1030  1
    load_1_14_8  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_963  -30
    arc_1_14_9  connected_order_arc_964  -11
    arc_1_14_9  in_degree_1032  1
    arc_1_14_9  out_degree_1061  1
    arc_1_14_9  original_T_including_depot_unload_1080  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_963  1
    load_1_14_9  free_load_conservation_1036  -1
    load_1_14_9  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_965  -30
    arc_1_14_10  connected_order_arc_966  -11
    arc_1_14_10  in_degree_1038  1
    arc_1_14_10  out_degree_1061  1
    arc_1_14_10  original_T_including_depot_unload_1080  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_965  1
    load_1_14_10  free_load_conservation_1042  -1
    load_1_14_10  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_967  -30
    arc_1_14_11  connected_order_arc_968  -11
    arc_1_14_11  in_degree_1044  1
    arc_1_14_11  out_degree_1061  1
    arc_1_14_11  original_T_including_depot_unload_1080  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_967  1
    load_1_14_11  free_load_conservation_1048  -1
    load_1_14_11  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_969  -30
    arc_1_14_12  connected_order_arc_970  -11
    arc_1_14_12  in_degree_1050  1
    arc_1_14_12  out_degree_1061  1
    arc_1_14_12  original_T_including_depot_unload_1080  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_969  1
    load_1_14_12  free_load_conservation_1054  -1
    load_1_14_12  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_971  -30
    arc_1_14_13  connected_order_arc_972  -11
    arc_1_14_13  in_degree_1056  1
    arc_1_14_13  out_degree_1061  1
    arc_1_14_13  original_T_including_depot_unload_1080  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_971  1
    load_1_14_13  free_load_conservation_1060  -1
    load_1_14_13  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_973  -30
    arc_1_14_15  connected_order_arc_974  -11
    arc_1_14_15  out_degree_1061  1
    arc_1_14_15  in_degree_1068  1
    arc_1_14_15  original_T_including_depot_unload_1080  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_973  1
    load_1_14_15  free_load_conservation_1066  1
    load_1_14_15  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_975  -30
    arc_1_14_16  connected_order_arc_976  -11
    arc_1_14_16  out_degree_1061  1
    arc_1_14_16  in_degree_1074  1
    arc_1_14_16  original_T_including_depot_unload_1080  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_975  1
    load_1_14_16  free_load_conservation_1066  1
    load_1_14_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_977  -30
    arc_1_15_0  depot_return_or_bypass_1016  1
    arc_1_15_0  out_degree_1067  1
    arc_1_15_0  original_T_including_depot_unload_1080  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_977  1
    load_1_15_0  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_978  -30
    arc_1_15_7  connected_order_arc_979  -11
    arc_1_15_7  in_degree_1018  1
    arc_1_15_7  out_degree_1067  1
    arc_1_15_7  original_T_including_depot_unload_1080  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_978  1
    load_1_15_7  segment_load_conservation_1021  -1
    load_1_15_7  segment_prefix_lb_1022  1
    load_1_15_7  segment_prefix_ub_1023  1
    load_1_15_7  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_980  -30
    arc_1_15_8  connected_order_arc_981  -11
    arc_1_15_8  in_degree_1025  1
    arc_1_15_8  out_degree_1067  1
    arc_1_15_8  original_T_including_depot_unload_1080  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_980  1
    load_1_15_8  segment_load_conservation_1028  -1
    load_1_15_8  segment_prefix_lb_1029  1
    load_1_15_8  segment_prefix_ub_1030  1
    load_1_15_8  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_982  -30
    arc_1_15_9  connected_order_arc_983  -11
    arc_1_15_9  in_degree_1032  1
    arc_1_15_9  out_degree_1067  1
    arc_1_15_9  original_T_including_depot_unload_1080  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_982  1
    load_1_15_9  free_load_conservation_1036  -1
    load_1_15_9  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_984  -30
    arc_1_15_10  connected_order_arc_985  -11
    arc_1_15_10  in_degree_1038  1
    arc_1_15_10  out_degree_1067  1
    arc_1_15_10  original_T_including_depot_unload_1080  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_984  1
    load_1_15_10  free_load_conservation_1042  -1
    load_1_15_10  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_986  -30
    arc_1_15_11  connected_order_arc_987  -11
    arc_1_15_11  in_degree_1044  1
    arc_1_15_11  out_degree_1067  1
    arc_1_15_11  original_T_including_depot_unload_1080  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_986  1
    load_1_15_11  free_load_conservation_1048  -1
    load_1_15_11  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_988  -30
    arc_1_15_12  connected_order_arc_989  -11
    arc_1_15_12  in_degree_1050  1
    arc_1_15_12  out_degree_1067  1
    arc_1_15_12  original_T_including_depot_unload_1080  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_988  1
    load_1_15_12  free_load_conservation_1054  -1
    load_1_15_12  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_990  -30
    arc_1_15_13  connected_order_arc_991  -11
    arc_1_15_13  in_degree_1056  1
    arc_1_15_13  out_degree_1067  1
    arc_1_15_13  original_T_including_depot_unload_1080  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_990  1
    load_1_15_13  free_load_conservation_1060  -1
    load_1_15_13  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_992  -30
    arc_1_15_14  connected_order_arc_993  -11
    arc_1_15_14  in_degree_1062  1
    arc_1_15_14  out_degree_1067  1
    arc_1_15_14  original_T_including_depot_unload_1080  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_992  1
    load_1_15_14  free_load_conservation_1066  -1
    load_1_15_14  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_994  -30
    arc_1_15_16  connected_order_arc_995  -11
    arc_1_15_16  out_degree_1067  1
    arc_1_15_16  in_degree_1074  1
    arc_1_15_16  original_T_including_depot_unload_1080  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_994  1
    load_1_15_16  free_load_conservation_1072  1
    load_1_15_16  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_996  -30
    arc_1_16_0  depot_return_or_bypass_1016  1
    arc_1_16_0  out_degree_1073  1
    arc_1_16_0  original_T_including_depot_unload_1080  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_996  1
    load_1_16_0  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_997  -30
    arc_1_16_7  connected_order_arc_998  -11
    arc_1_16_7  in_degree_1018  1
    arc_1_16_7  out_degree_1073  1
    arc_1_16_7  original_T_including_depot_unload_1080  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_997  1
    load_1_16_7  segment_load_conservation_1021  -1
    load_1_16_7  segment_prefix_lb_1022  1
    load_1_16_7  segment_prefix_ub_1023  1
    load_1_16_7  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_999  -30
    arc_1_16_8  connected_order_arc_1000  -11
    arc_1_16_8  in_degree_1025  1
    arc_1_16_8  out_degree_1073  1
    arc_1_16_8  original_T_including_depot_unload_1080  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_999  1
    load_1_16_8  segment_load_conservation_1028  -1
    load_1_16_8  segment_prefix_lb_1029  1
    load_1_16_8  segment_prefix_ub_1030  1
    load_1_16_8  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1001  -30
    arc_1_16_9  connected_order_arc_1002  -11
    arc_1_16_9  in_degree_1032  1
    arc_1_16_9  out_degree_1073  1
    arc_1_16_9  original_T_including_depot_unload_1080  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1001  1
    load_1_16_9  free_load_conservation_1036  -1
    load_1_16_9  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1003  -30
    arc_1_16_10  connected_order_arc_1004  -11
    arc_1_16_10  in_degree_1038  1
    arc_1_16_10  out_degree_1073  1
    arc_1_16_10  original_T_including_depot_unload_1080  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1003  1
    load_1_16_10  free_load_conservation_1042  -1
    load_1_16_10  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1005  -30
    arc_1_16_11  connected_order_arc_1006  -11
    arc_1_16_11  in_degree_1044  1
    arc_1_16_11  out_degree_1073  1
    arc_1_16_11  original_T_including_depot_unload_1080  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1005  1
    load_1_16_11  free_load_conservation_1048  -1
    load_1_16_11  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1007  -30
    arc_1_16_12  connected_order_arc_1008  -11
    arc_1_16_12  in_degree_1050  1
    arc_1_16_12  out_degree_1073  1
    arc_1_16_12  original_T_including_depot_unload_1080  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1007  1
    load_1_16_12  free_load_conservation_1054  -1
    load_1_16_12  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1009  -30
    arc_1_16_13  connected_order_arc_1010  -11
    arc_1_16_13  in_degree_1056  1
    arc_1_16_13  out_degree_1073  1
    arc_1_16_13  original_T_including_depot_unload_1080  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1009  1
    load_1_16_13  free_load_conservation_1060  -1
    load_1_16_13  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1011  -30
    arc_1_16_14  connected_order_arc_1012  -11
    arc_1_16_14  in_degree_1062  1
    arc_1_16_14  out_degree_1073  1
    arc_1_16_14  original_T_including_depot_unload_1080  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1011  1
    load_1_16_14  free_load_conservation_1066  -1
    load_1_16_14  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1013  -30
    arc_1_16_15  connected_order_arc_1014  -11
    arc_1_16_15  in_degree_1068  1
    arc_1_16_15  out_degree_1073  1
    arc_1_16_15  original_T_including_depot_unload_1080  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1013  1
    load_1_16_15  free_load_conservation_1072  -1
    load_1_16_15  free_load_conservation_1078  1
RHS
    RHS1      OBJ       -3.5125197696752475e-01
    RHS1      onehot_9_4  1
    RHS1      onehot_11_39  1
    RHS1      onehot_18_74  1
    RHS1      onehot_7_99  1
    RHS1      onehot_17_136  1
    RHS1      onehot_10_143  1
    RHS1      onehot_20_178  1
    RHS1      onehot_6_185  1
    RHS1      stock_ub_189  26
    RHS1      parent_nonstrict_scope_190  5.8872987983019642e-01
    RHS1      normalization_247  1
    RHS1      connected_order_arc_340  -14
    RHS1      connected_order_arc_342  -14
    RHS1      connected_order_arc_344  -14
    RHS1      connected_order_arc_346  -14
    RHS1      connected_order_arc_348  -14
    RHS1      connected_order_arc_350  -14
    RHS1      connected_order_arc_352  -14
    RHS1      connected_order_arc_354  -14
    RHS1      connected_order_arc_356  -14
    RHS1      connected_order_arc_358  -14
    RHS1      connected_order_arc_360  -14
    RHS1      connected_order_arc_362  -14
    RHS1      connected_order_arc_364  -14
    RHS1      connected_order_arc_367  -14
    RHS1      connected_order_arc_369  -14
    RHS1      connected_order_arc_371  -14
    RHS1      connected_order_arc_373  -14
    RHS1      connected_order_arc_375  -14
    RHS1      connected_order_arc_377  -14
    RHS1      connected_order_arc_379  -14
    RHS1      connected_order_arc_381  -14
    RHS1      connected_order_arc_383  -14
    RHS1      connected_order_arc_385  -14
    RHS1      connected_order_arc_387  -14
    RHS1      connected_order_arc_389  -14
    RHS1      connected_order_arc_391  -14
    RHS1      connected_order_arc_394  -14
    RHS1      connected_order_arc_396  -14
    RHS1      connected_order_arc_398  -14
    RHS1      connected_order_arc_400  -14
    RHS1      connected_order_arc_402  -14
    RHS1      connected_order_arc_404  -14
    RHS1      connected_order_arc_406  -14
    RHS1      connected_order_arc_408  -14
    RHS1      connected_order_arc_410  -14
    RHS1      connected_order_arc_412  -14
    RHS1      connected_order_arc_414  -14
    RHS1      connected_order_arc_416  -14
    RHS1      connected_order_arc_418  -14
    RHS1      connected_order_arc_421  -14
    RHS1      connected_order_arc_423  -14
    RHS1      connected_order_arc_425  -14
    RHS1      connected_order_arc_427  -14
    RHS1      connected_order_arc_429  -14
    RHS1      connected_order_arc_431  -14
    RHS1      connected_order_arc_433  -14
    RHS1      connected_order_arc_435  -14
    RHS1      connected_order_arc_437  -14
    RHS1      connected_order_arc_439  -14
    RHS1      connected_order_arc_441  -14
    RHS1      connected_order_arc_443  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_448  -14
    RHS1      connected_order_arc_450  -14
    RHS1      connected_order_arc_452  -14
    RHS1      connected_order_arc_454  -14
    RHS1      connected_order_arc_456  -14
    RHS1      connected_order_arc_458  -14
    RHS1      connected_order_arc_460  -14
    RHS1      connected_order_arc_462  -14
    RHS1      connected_order_arc_464  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_483  -14
    RHS1      connected_order_arc_485  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_489  -14
    RHS1      connected_order_arc_491  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_510  -14
    RHS1      connected_order_arc_512  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_516  -14
    RHS1      connected_order_arc_518  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_537  -14
    RHS1      connected_order_arc_539  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_543  -14
    RHS1      connected_order_arc_545  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_564  -14
    RHS1      connected_order_arc_566  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_570  -14
    RHS1      connected_order_arc_572  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_591  -14
    RHS1      connected_order_arc_593  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_597  -14
    RHS1      connected_order_arc_599  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_618  -14
    RHS1      connected_order_arc_620  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_624  -14
    RHS1      connected_order_arc_626  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_645  -14
    RHS1      connected_order_arc_647  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_651  -14
    RHS1      connected_order_arc_653  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_672  -14
    RHS1      connected_order_arc_674  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_678  -14
    RHS1      connected_order_arc_680  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_699  -14
    RHS1      connected_order_arc_701  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_705  -14
    RHS1      connected_order_arc_707  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      depot_departure_or_bypass_716  1
    RHS1      depot_return_or_bypass_717  1
    RHS1      segment_load_conservation_722  3
    RHS1      segment_prefix_ub_724  27
    RHS1      segment_load_conservation_729  -1
    RHS1      segment_prefix_lb_730  1
    RHS1      segment_prefix_ub_731  30
    RHS1      segment_load_conservation_736  4
    RHS1      segment_prefix_ub_738  26
    RHS1      segment_load_conservation_743  -2
    RHS1      segment_prefix_lb_744  2
    RHS1      segment_prefix_ub_745  30
    RHS1      segment_load_conservation_750  -1
    RHS1      segment_prefix_lb_751  1
    RHS1      segment_prefix_ub_752  30
    RHS1      segment_load_conservation_757  3
    RHS1      segment_prefix_ub_759  27
    RHS1      fixed_segment_relative_order_808  1
    RHS1      fixed_segment_relative_order_809  1
    RHS1      fixed_segment_relative_order_810  1
    RHS1      fixed_segment_relative_order_811  1
    RHS1      fixed_segment_relative_order_812  1
    RHS1      original_T_including_depot_unload_813  3600
    RHS1      connected_order_arc_827  -10
    RHS1      connected_order_arc_829  -10
    RHS1      connected_order_arc_831  -10
    RHS1      connected_order_arc_833  -10
    RHS1      connected_order_arc_835  -10
    RHS1      connected_order_arc_837  -10
    RHS1      connected_order_arc_839  -10
    RHS1      connected_order_arc_841  -10
    RHS1      connected_order_arc_843  -10
    RHS1      connected_order_arc_846  -10
    RHS1      connected_order_arc_848  -10
    RHS1      connected_order_arc_850  -10
    RHS1      connected_order_arc_852  -10
    RHS1      connected_order_arc_854  -10
    RHS1      connected_order_arc_856  -10
    RHS1      connected_order_arc_858  -10
    RHS1      connected_order_arc_860  -10
    RHS1      connected_order_arc_862  -10
    RHS1      connected_order_arc_865  -10
    RHS1      connected_order_arc_867  -10
    RHS1      connected_order_arc_869  -10
    RHS1      connected_order_arc_871  -10
    RHS1      connected_order_arc_873  -10
    RHS1      connected_order_arc_875  -10
    RHS1      connected_order_arc_877  -10
    RHS1      connected_order_arc_879  -10
    RHS1      connected_order_arc_881  -10
    RHS1      connected_order_arc_884  -10
    RHS1      connected_order_arc_886  -10
    RHS1      connected_order_arc_888  -10
    RHS1      connected_order_arc_890  -10
    RHS1      connected_order_arc_892  -10
    RHS1      connected_order_arc_894  -10
    RHS1      connected_order_arc_896  -10
    RHS1      connected_order_arc_898  -10
    RHS1      connected_order_arc_900  -10
    RHS1      connected_order_arc_903  -10
    RHS1      connected_order_arc_905  -10
    RHS1      connected_order_arc_907  -10
    RHS1      connected_order_arc_909  -10
    RHS1      connected_order_arc_911  -10
    RHS1      connected_order_arc_913  -10
    RHS1      connected_order_arc_915  -10
    RHS1      connected_order_arc_917  -10
    RHS1      connected_order_arc_919  -10
    RHS1      connected_order_arc_922  -10
    RHS1      connected_order_arc_924  -10
    RHS1      connected_order_arc_926  -10
    RHS1      connected_order_arc_928  -10
    RHS1      connected_order_arc_930  -10
    RHS1      connected_order_arc_932  -10
    RHS1      connected_order_arc_934  -10
    RHS1      connected_order_arc_936  -10
    RHS1      connected_order_arc_938  -10
    RHS1      connected_order_arc_941  -10
    RHS1      connected_order_arc_943  -10
    RHS1      connected_order_arc_945  -10
    RHS1      connected_order_arc_947  -10
    RHS1      connected_order_arc_949  -10
    RHS1      connected_order_arc_951  -10
    RHS1      connected_order_arc_953  -10
    RHS1      connected_order_arc_955  -10
    RHS1      connected_order_arc_957  -10
    RHS1      connected_order_arc_960  -10
    RHS1      connected_order_arc_962  -10
    RHS1      connected_order_arc_964  -10
    RHS1      connected_order_arc_966  -10
    RHS1      connected_order_arc_968  -10
    RHS1      connected_order_arc_970  -10
    RHS1      connected_order_arc_972  -10
    RHS1      connected_order_arc_974  -10
    RHS1      connected_order_arc_976  -10
    RHS1      connected_order_arc_979  -10
    RHS1      connected_order_arc_981  -10
    RHS1      connected_order_arc_983  -10
    RHS1      connected_order_arc_985  -10
    RHS1      connected_order_arc_987  -10
    RHS1      connected_order_arc_989  -10
    RHS1      connected_order_arc_991  -10
    RHS1      connected_order_arc_993  -10
    RHS1      connected_order_arc_995  -10
    RHS1      connected_order_arc_998  -10
    RHS1      connected_order_arc_1000  -10
    RHS1      connected_order_arc_1002  -10
    RHS1      connected_order_arc_1004  -10
    RHS1      connected_order_arc_1006  -10
    RHS1      connected_order_arc_1008  -10
    RHS1      connected_order_arc_1010  -10
    RHS1      connected_order_arc_1012  -10
    RHS1      connected_order_arc_1014  -10
    RHS1      depot_departure_or_bypass_1015  1
    RHS1      depot_return_or_bypass_1016  1
    RHS1      segment_load_conservation_1021  4
    RHS1      segment_prefix_ub_1023  26
    RHS1      segment_load_conservation_1028  -1
    RHS1      segment_prefix_lb_1029  1
    RHS1      segment_prefix_ub_1030  30
    RHS1      fixed_segment_relative_order_1079  1
    RHS1      original_T_including_depot_unload_1080  4320
BOUNDS
 LO BND1      t         4.6801002878586309e-02
 UP BND1      t         1.1498973305966327e-01
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_9_0   
 UP BND1      w_9_0     1.1498973305966327e-01
 BV BND1      x_9_1   
 UP BND1      w_9_1     1.1498973305966327e-01
 UP BND1      rho_9     1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.1498973305966327e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.1498973305966327e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.1498973305966327e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.1498973305966327e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.1498973305966327e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.1498973305966327e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.1498973305966327e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.1498973305966327e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.1498973305966327e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.1498973305966327e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.1498973305966327e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.1498973305966327e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.1498973305966327e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.1498973305966327e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.1498973305966327e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.1498973305966327e-01
 UP BND1      rho_11    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.1498973305966327e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.1498973305966327e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.1498973305966327e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.1498973305966327e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.1498973305966327e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.1498973305966327e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.1498973305966327e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.1498973305966327e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.1498973305966327e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.1498973305966327e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.1498973305966327e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.1498973305966327e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.1498973305966327e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.1498973305966327e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.1498973305966327e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.1498973305966327e-01
 UP BND1      rho_18    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     1.1498973305966327e-01
 BV BND1      x_7_1   
 UP BND1      w_7_1     1.1498973305966327e-01
 BV BND1      x_7_2   
 UP BND1      w_7_2     1.1498973305966327e-01
 BV BND1      x_7_3   
 UP BND1      w_7_3     1.1498973305966327e-01
 BV BND1      x_7_4   
 UP BND1      w_7_4     1.1498973305966327e-01
 BV BND1      x_7_5   
 UP BND1      w_7_5     1.1498973305966327e-01
 BV BND1      x_7_6   
 UP BND1      w_7_6     1.1498973305966327e-01
 BV BND1      x_7_7   
 UP BND1      w_7_7     1.1498973305966327e-01
 BV BND1      x_7_8   
 UP BND1      w_7_8     1.1498973305966327e-01
 BV BND1      x_7_9   
 UP BND1      w_7_9     1.1498973305966327e-01
 BV BND1      x_7_10  
 UP BND1      w_7_10    1.1498973305966327e-01
 UP BND1      rho_7     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.1498973305966327e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.1498973305966327e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.1498973305966327e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.1498973305966327e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.1498973305966327e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.1498973305966327e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.1498973305966327e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.1498973305966327e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.1498973305966327e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.1498973305966327e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.1498973305966327e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.1498973305966327e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.1498973305966327e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.1498973305966327e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.1498973305966327e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.1498973305966327e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.1498973305966327e-01
 UP BND1      rho_17    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    1.1498973305966327e-01
 BV BND1      x_10_1  
 UP BND1      w_10_1    1.1498973305966327e-01
 UP BND1      rho_10    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.1498973305966327e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.1498973305966327e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.1498973305966327e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.1498973305966327e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.1498973305966327e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.1498973305966327e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.1498973305966327e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.1498973305966327e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.1498973305966327e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.1498973305966327e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.1498973305966327e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.1498973305966327e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.1498973305966327e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.1498973305966327e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.1498973305966327e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.1498973305966327e-01
 UP BND1      rho_20    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     1.1498973305966327e-01
 BV BND1      x_6_1   
 UP BND1      w_6_1     1.1498973305966327e-01
 UP BND1      rho_6     1
 UP BND1      a_9_11    1
 UP BND1      a_9_18    1
 UP BND1      a_9_7     1
 UP BND1      a_9_17    1
 UP BND1      a_9_10    1
 UP BND1      a_9_20    1
 UP BND1      a_9_6     1
 UP BND1      a_11_18   1
 UP BND1      a_11_7    1
 UP BND1      a_11_17   1
 UP BND1      a_11_10   1
 UP BND1      a_11_20   1
 UP BND1      a_11_6    1
 UP BND1      a_18_7    1
 UP BND1      a_18_17   1
 UP BND1      a_18_10   1
 UP BND1      a_18_20   1
 UP BND1      a_18_6    1
 UP BND1      a_7_17    1
 UP BND1      a_7_10    1
 UP BND1      a_7_20    1
 UP BND1      a_7_6     1
 UP BND1      a_17_10   1
 UP BND1      a_17_20   1
 UP BND1      a_17_6    1
 UP BND1      a_10_20   1
 UP BND1      a_10_6    1
 UP BND1      a_20_6    1
 BV BND1      service_0_9_1
 BV BND1      service_1_9_1
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_1_7_0
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_10_1
 BV BND1      service_1_10_1
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_6_1
 BV BND1      service_1_6_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  14
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  14
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  14
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  14
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_9
 UP BND1      load_0_6_9  30
 BV BND1      arc_0_6_10
 UP BND1      load_0_6_10  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_6
 UP BND1      load_0_9_6  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_9_16
 UP BND1      load_0_9_16  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_6
 UP BND1      load_0_10_6  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_10_16
 UP BND1      load_0_10_16  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_9
 UP BND1      load_0_16_9  30
 BV BND1      arc_0_16_10
 UP BND1      load_0_16_10  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  30
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
ENDATA
