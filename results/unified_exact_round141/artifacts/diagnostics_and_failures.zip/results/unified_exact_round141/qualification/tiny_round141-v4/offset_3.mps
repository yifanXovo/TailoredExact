* Signature: 0x833cd2eb383adb15
NAME 
ROWS
 N  OBJ
 G  floor   
COLUMNS
    F_linear  OBJ       1
    F_linear  floor     1
    MARKER    'MARKER'                 'INTORG'
    r141_b    floor     -2.9999999999999988e-01
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      OBJ       -0.25
    RHS1      floor     -1.5000000000000002e-01
BOUNDS
 BV BND1      r141_b  
ENDATA
