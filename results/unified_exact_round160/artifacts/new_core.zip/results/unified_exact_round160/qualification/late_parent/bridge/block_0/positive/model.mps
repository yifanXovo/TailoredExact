* Signature: 0x68ffeb1cc2e7be5a
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_16_26
 E  normalized_mass_16_27
 E  normalized_ratio_16_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 E  onehot_11_55
 E  normalized_mass_11_56
 E  normalized_ratio_11_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 E  onehot_31_84
 E  normalized_mass_31_85
 E  normalized_ratio_31_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 E  onehot_20_113
 E  normalized_mass_20_114
 E  normalized_ratio_20_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 E  onehot_2_148
 E  normalized_mass_2_149
 E  normalized_ratio_2_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 E  onehot_21_183
 E  normalized_mass_21_184
 E  normalized_ratio_21_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 E  onehot_12_218
 E  normalized_mass_12_219
 E  normalized_ratio_12_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 E  onehot_7_257
 E  normalized_mass_7_258
 E  normalized_ratio_7_259
 G  stock_lb_260
 L  stock_ub_261
 L  parent_nonstrict_scope_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 E  normalization_319
 G  full_original_Gini_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 L  arc_capacity_437
 L  arc_capacity_438
 L  arc_capacity_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 E  depot_departure_or_bypass_770
 E  depot_return_or_bypass_771
 E  out_degree_772
 E  in_degree_773
 G  order_active_lb_774
 L  order_active_ub_775
 E  segment_load_conservation_776
 G  segment_prefix_lb_777
 L  segment_prefix_ub_778
 E  out_degree_779
 E  in_degree_780
 G  order_active_lb_781
 L  order_active_ub_782
 E  segment_load_conservation_783
 G  segment_prefix_lb_784
 L  segment_prefix_ub_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  segment_load_conservation_790
 G  segment_prefix_lb_791
 L  segment_prefix_ub_792
 E  out_degree_793
 E  in_degree_794
 G  order_active_lb_795
 L  order_active_ub_796
 E  segment_load_conservation_797
 G  segment_prefix_lb_798
 L  segment_prefix_ub_799
 E  out_degree_800
 E  in_degree_801
 G  order_active_lb_802
 L  order_active_ub_803
 E  segment_load_conservation_804
 G  segment_prefix_lb_805
 L  segment_prefix_ub_806
 E  out_degree_807
 E  in_degree_808
 G  order_active_lb_809
 L  order_active_ub_810
 E  service_visit_def_811
 E  free_load_conservation_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  service_visit_def_817
 E  free_load_conservation_818
 E  out_degree_819
 E  in_degree_820
 G  order_active_lb_821
 L  order_active_ub_822
 E  service_visit_def_823
 E  free_load_conservation_824
 E  out_degree_825
 E  in_degree_826
 G  order_active_lb_827
 L  order_active_ub_828
 E  service_visit_def_829
 E  free_load_conservation_830
 E  out_degree_831
 E  in_degree_832
 G  order_active_lb_833
 L  order_active_ub_834
 E  service_visit_def_835
 E  free_load_conservation_836
 E  out_degree_837
 E  in_degree_838
 G  order_active_lb_839
 L  order_active_ub_840
 E  service_visit_def_841
 E  free_load_conservation_842
 E  out_degree_843
 E  in_degree_844
 G  order_active_lb_845
 L  order_active_ub_846
 E  service_visit_def_847
 E  free_load_conservation_848
 E  out_degree_849
 E  in_degree_850
 G  order_active_lb_851
 L  order_active_ub_852
 E  service_visit_def_853
 E  free_load_conservation_854
 G  fixed_segment_relative_order_855
 G  fixed_segment_relative_order_856
 G  fixed_segment_relative_order_857
 G  fixed_segment_relative_order_858
 L  original_T_including_depot_unload_859
 L  arc_capacity_860
 L  arc_capacity_861
 L  arc_capacity_862
 L  arc_capacity_863
 L  arc_capacity_864
 L  arc_capacity_865
 L  arc_capacity_866
 L  arc_capacity_867
 L  arc_capacity_868
 L  arc_capacity_869
 L  arc_capacity_870
 L  arc_capacity_871
 L  arc_capacity_872
 L  arc_capacity_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 E  depot_departure_or_bypass_1149
 E  depot_return_or_bypass_1150
 E  out_degree_1151
 E  in_degree_1152
 G  order_active_lb_1153
 L  order_active_ub_1154
 E  segment_load_conservation_1155
 G  segment_prefix_lb_1156
 L  segment_prefix_ub_1157
 E  out_degree_1158
 E  in_degree_1159
 G  order_active_lb_1160
 L  order_active_ub_1161
 E  segment_load_conservation_1162
 G  segment_prefix_lb_1163
 L  segment_prefix_ub_1164
 E  out_degree_1165
 E  in_degree_1166
 G  order_active_lb_1167
 L  order_active_ub_1168
 E  segment_load_conservation_1169
 G  segment_prefix_lb_1170
 L  segment_prefix_ub_1171
 E  out_degree_1172
 E  in_degree_1173
 G  order_active_lb_1174
 L  order_active_ub_1175
 E  segment_load_conservation_1176
 G  segment_prefix_lb_1177
 L  segment_prefix_ub_1178
 E  out_degree_1179
 E  in_degree_1180
 G  order_active_lb_1181
 L  order_active_ub_1182
 E  service_visit_def_1183
 E  free_load_conservation_1184
 E  out_degree_1185
 E  in_degree_1186
 G  order_active_lb_1187
 L  order_active_ub_1188
 E  service_visit_def_1189
 E  free_load_conservation_1190
 E  out_degree_1191
 E  in_degree_1192
 G  order_active_lb_1193
 L  order_active_ub_1194
 E  service_visit_def_1195
 E  free_load_conservation_1196
 E  out_degree_1197
 E  in_degree_1198
 G  order_active_lb_1199
 L  order_active_ub_1200
 E  service_visit_def_1201
 E  free_load_conservation_1202
 E  out_degree_1203
 E  in_degree_1204
 G  order_active_lb_1205
 L  order_active_ub_1206
 E  service_visit_def_1207
 E  free_load_conservation_1208
 E  out_degree_1209
 E  in_degree_1210
 G  order_active_lb_1211
 L  order_active_ub_1212
 E  service_visit_def_1213
 E  free_load_conservation_1214
 E  out_degree_1215
 E  in_degree_1216
 G  order_active_lb_1217
 L  order_active_ub_1218
 E  service_visit_def_1219
 E  free_load_conservation_1220
 E  out_degree_1221
 E  in_degree_1222
 G  order_active_lb_1223
 L  order_active_ub_1224
 E  service_visit_def_1225
 E  free_load_conservation_1226
 G  fixed_segment_relative_order_1227
 G  fixed_segment_relative_order_1228
 G  fixed_segment_relative_order_1229
 L  original_T_including_depot_unload_1230
 L  arc_capacity_1231
 L  arc_capacity_1232
 L  arc_capacity_1233
 L  arc_capacity_1234
 L  arc_capacity_1235
 L  arc_capacity_1236
 L  arc_capacity_1237
 L  arc_capacity_1238
 L  arc_capacity_1239
 L  arc_capacity_1240
 L  arc_capacity_1241
 L  arc_capacity_1242
 L  arc_capacity_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 E  depot_departure_or_bypass_1474
 E  depot_return_or_bypass_1475
 E  out_degree_1476
 E  in_degree_1477
 G  order_active_lb_1478
 L  order_active_ub_1479
 E  segment_load_conservation_1480
 G  segment_prefix_lb_1481
 L  segment_prefix_ub_1482
 E  out_degree_1483
 E  in_degree_1484
 G  order_active_lb_1485
 L  order_active_ub_1486
 E  segment_load_conservation_1487
 G  segment_prefix_lb_1488
 L  segment_prefix_ub_1489
 E  out_degree_1490
 E  in_degree_1491
 G  order_active_lb_1492
 L  order_active_ub_1493
 E  segment_load_conservation_1494
 G  segment_prefix_lb_1495
 L  segment_prefix_ub_1496
 E  out_degree_1497
 E  in_degree_1498
 G  order_active_lb_1499
 L  order_active_ub_1500
 E  service_visit_def_1501
 E  free_load_conservation_1502
 E  out_degree_1503
 E  in_degree_1504
 G  order_active_lb_1505
 L  order_active_ub_1506
 E  service_visit_def_1507
 E  free_load_conservation_1508
 E  out_degree_1509
 E  in_degree_1510
 G  order_active_lb_1511
 L  order_active_ub_1512
 E  service_visit_def_1513
 E  free_load_conservation_1514
 E  out_degree_1515
 E  in_degree_1516
 G  order_active_lb_1517
 L  order_active_ub_1518
 E  service_visit_def_1519
 E  free_load_conservation_1520
 E  out_degree_1521
 E  in_degree_1522
 G  order_active_lb_1523
 L  order_active_ub_1524
 E  service_visit_def_1525
 E  free_load_conservation_1526
 E  out_degree_1527
 E  in_degree_1528
 G  order_active_lb_1529
 L  order_active_ub_1530
 E  service_visit_def_1531
 E  free_load_conservation_1532
 E  out_degree_1533
 E  in_degree_1534
 G  order_active_lb_1535
 L  order_active_ub_1536
 E  service_visit_def_1537
 E  free_load_conservation_1538
 E  out_degree_1539
 E  in_degree_1540
 G  order_active_lb_1541
 L  order_active_ub_1542
 E  service_visit_def_1543
 E  free_load_conservation_1544
 G  fixed_segment_relative_order_1545
 G  fixed_segment_relative_order_1546
 L  original_T_including_depot_unload_1547
COLUMNS
    t         normalized_mass_16_27  -1
    t         normalized_mass_11_56  -1
    t         normalized_mass_31_85  -1
    t         normalized_mass_20_114  -1
    t         normalized_mass_2_149  -1
    t         normalized_mass_21_184  -1
    t         normalized_mass_12_219  -1
    t         normalized_mass_7_258  -1
    t         normalization_319  2.3146428571428572e+01
    t         full_original_Gini_320  -1.0903571428571429e+02
    q         OBJ       1
    q         parent_nonstrict_scope_262  1
    q         full_original_Gini_320  35
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_0  -2.5286733495865618e-02
    x_16_0    product_ub_1  -4.3203209381311537e-02
    x_16_0    onehot_16_26  1
    x_16_0    parent_nonstrict_scope_262  0.054
    x_16_0    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_0  1
    w_16_0    product_ub_1  1
    w_16_0    normalized_mass_16_27  1
    w_16_0    full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_2  -2.5286733495865618e-02
    x_16_1    product_ub_3  -4.3203209381311537e-02
    x_16_1    onehot_16_26  1
    x_16_1    stock_lb_260  1
    x_16_1    stock_ub_261  1
    x_16_1    parent_nonstrict_scope_262  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_2  1
    w_16_1    product_ub_3  1
    w_16_1    normalized_mass_16_27  1
    w_16_1    normalized_ratio_16_28  -1.6666666666666666e-01
    w_16_1    full_original_Gini_320  -1.8646428571428576e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_4  -2.5286733495865618e-02
    x_16_2    product_ub_5  -4.3203209381311537e-02
    x_16_2    onehot_16_26  1
    x_16_2    stock_lb_260  2
    x_16_2    stock_ub_261  2
    x_16_2    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_4  1
    w_16_2    product_ub_5  1
    w_16_2    normalized_mass_16_27  1
    w_16_2    normalized_ratio_16_28  -3.3333333333333331e-01
    w_16_2    full_original_Gini_320  -1.5013095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_6  -2.5286733495865618e-02
    x_16_3    product_ub_7  -4.3203209381311537e-02
    x_16_3    onehot_16_26  1
    x_16_3    stock_lb_260  3
    x_16_3    stock_ub_261  3
    x_16_3    parent_nonstrict_scope_262  0.027
    x_16_3    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_6  1
    w_16_3    product_ub_7  1
    w_16_3    normalized_mass_16_27  1
    w_16_3    normalized_ratio_16_28  -0.5
    w_16_3    full_original_Gini_320  -1.2046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_8  -2.5286733495865618e-02
    x_16_4    product_ub_9  -4.3203209381311537e-02
    x_16_4    onehot_16_26  1
    x_16_4    stock_lb_260  4
    x_16_4    stock_ub_261  4
    x_16_4    parent_nonstrict_scope_262  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_8  1
    w_16_4    product_ub_9  1
    w_16_4    normalized_mass_16_27  1
    w_16_4    normalized_ratio_16_28  -6.6666666666666663e-01
    w_16_4    full_original_Gini_320  -9.2130952380952369e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_10  -2.5286733495865618e-02
    x_16_5    product_ub_11  -4.3203209381311537e-02
    x_16_5    onehot_16_26  1
    x_16_5    stock_lb_260  5
    x_16_5    stock_ub_261  5
    x_16_5    parent_nonstrict_scope_262  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_10  1
    w_16_5    product_ub_11  1
    w_16_5    normalized_mass_16_27  1
    w_16_5    normalized_ratio_16_28  -8.3333333333333326e-01
    w_16_5    full_original_Gini_320  -6.7845238095238143e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_12  -2.5286733495865618e-02
    x_16_6    product_ub_13  -4.3203209381311537e-02
    x_16_6    onehot_16_26  1
    x_16_6    stock_lb_260  6
    x_16_6    stock_ub_261  6
    x_16_6    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_12  1
    w_16_6    product_ub_13  1
    w_16_6    normalized_mass_16_27  1
    w_16_6    normalized_ratio_16_28  -1
    w_16_6    full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_14  -2.5286733495865618e-02
    x_16_7    product_ub_15  -4.3203209381311537e-02
    x_16_7    onehot_16_26  1
    x_16_7    stock_lb_260  7
    x_16_7    stock_ub_261  7
    x_16_7    parent_nonstrict_scope_262  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_14  1
    w_16_7    product_ub_15  1
    w_16_7    normalized_mass_16_27  1
    w_16_7    normalized_ratio_16_28  -1.1666666666666665e+00
    w_16_7    full_original_Gini_320  -8.6535714285714231e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_16  -2.5286733495865618e-02
    x_16_8    product_ub_17  -4.3203209381311537e-02
    x_16_8    onehot_16_26  1
    x_16_8    stock_lb_260  8
    x_16_8    stock_ub_261  8
    x_16_8    parent_nonstrict_scope_262  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_16  1
    w_16_8    product_ub_17  1
    w_16_8    normalized_mass_16_27  1
    w_16_8    normalized_ratio_16_28  -1.3333333333333333e+00
    w_16_8    full_original_Gini_320  -1.2853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_18  -2.5286733495865618e-02
    x_16_9    product_ub_19  -4.3203209381311537e-02
    x_16_9    onehot_16_26  1
    x_16_9    stock_lb_260  9
    x_16_9    stock_ub_261  9
    x_16_9    parent_nonstrict_scope_262  0.027
    x_16_9    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_18  1
    w_16_9    product_ub_19  1
    w_16_9    normalized_mass_16_27  1
    w_16_9    normalized_ratio_16_28  -1.5
    w_16_9    full_original_Gini_320  -1.7353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_20  -2.5286733495865618e-02
    x_16_10   product_ub_21  -4.3203209381311537e-02
    x_16_10   onehot_16_26  1
    x_16_10   stock_lb_260  10
    x_16_10   stock_ub_261  10
    x_16_10   parent_nonstrict_scope_262  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_20  1
    w_16_10   product_ub_21  1
    w_16_10   normalized_mass_16_27  1
    w_16_10   normalized_ratio_16_28  -1.6666666666666665e+00
    w_16_10   full_original_Gini_320  -2.1853571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_22  -2.5286733495865618e-02
    x_16_11   product_ub_23  -4.3203209381311537e-02
    x_16_11   onehot_16_26  1
    x_16_11   stock_lb_260  11
    x_16_11   stock_ub_261  11
    x_16_11   parent_nonstrict_scope_262  0.045
    x_16_11   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_22  1
    w_16_11   product_ub_23  1
    w_16_11   normalized_mass_16_27  1
    w_16_11   normalized_ratio_16_28  -1.8333333333333333e+00
    w_16_11   full_original_Gini_320  -2.6353571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_24  -2.5286733495865618e-02
    x_16_12   product_ub_25  -4.3203209381311537e-02
    x_16_12   onehot_16_26  1
    x_16_12   stock_lb_260  12
    x_16_12   stock_ub_261  12
    x_16_12   parent_nonstrict_scope_262  0.054
    x_16_12   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_24  1
    w_16_12   product_ub_25  1
    w_16_12   normalized_mass_16_27  1
    w_16_12   normalized_ratio_16_28  -2
    w_16_12   full_original_Gini_320  -3.0853571428571431e+01
    rho_16    normalized_ratio_16_28  1
    rho_16    block_pair_pos_283  -1
    rho_16    block_pair_neg_284  1
    rho_16    block_pair_pos_285  -1
    rho_16    block_pair_neg_286  1
    rho_16    block_pair_pos_287  -1
    rho_16    block_pair_neg_288  1
    rho_16    block_pair_pos_289  -1
    rho_16    block_pair_neg_290  1
    rho_16    block_pair_pos_291  -1
    rho_16    block_pair_neg_292  1
    rho_16    block_pair_pos_293  -1
    rho_16    block_pair_neg_294  1
    rho_16    block_pair_pos_295  -1
    rho_16    block_pair_neg_296  1
    rho_16    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1249999999999993e-02
    x_11_0    product_lb_29  -2.5286733495865618e-02
    x_11_0    product_ub_30  -4.3203209381311537e-02
    x_11_0    onehot_11_55  1
    x_11_0    parent_nonstrict_scope_262  0.0375
    x_11_0    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_29  1
    w_11_0    product_ub_30  1
    w_11_0    normalized_mass_11_56  1
    w_11_0    full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7499999999999929e-03
    x_11_1    product_lb_31  -2.5286733495865618e-02
    x_11_1    product_ub_32  -4.3203209381311537e-02
    x_11_1    onehot_11_55  1
    x_11_1    stock_lb_260  1
    x_11_1    stock_ub_261  1
    x_11_1    parent_nonstrict_scope_262  0.03
    x_11_1    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_31  1
    w_11_1    product_ub_32  1
    w_11_1    normalized_mass_11_56  1
    w_11_1    normalized_ratio_11_57  -0.2
    w_11_1    full_original_Gini_320  -1.7746428571428577e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       -3.7500000000000068e-03
    x_11_2    product_lb_33  -2.5286733495865618e-02
    x_11_2    product_ub_34  -4.3203209381311537e-02
    x_11_2    onehot_11_55  1
    x_11_2    stock_lb_260  2
    x_11_2    stock_ub_261  2
    x_11_2    parent_nonstrict_scope_262  0.0225
    x_11_2    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_33  1
    w_11_2    product_ub_34  1
    w_11_2    normalized_mass_11_56  1
    w_11_2    normalized_ratio_11_57  -0.4
    w_11_2    full_original_Gini_320  -1.3746428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -1.1250000000000010e-02
    x_11_3    product_lb_35  -2.5286733495865618e-02
    x_11_3    product_ub_36  -4.3203209381311537e-02
    x_11_3    onehot_11_55  1
    x_11_3    stock_lb_260  3
    x_11_3    stock_ub_261  3
    x_11_3    parent_nonstrict_scope_262  1.4999999999999996e-02
    x_11_3    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_35  1
    w_11_3    product_ub_36  1
    w_11_3    normalized_mass_11_56  1
    w_11_3    normalized_ratio_11_57  -6.0000000000000009e-01
    w_11_3    full_original_Gini_320  -1.0346428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -1.8750000000000010e-02
    x_11_4    product_lb_37  -2.5286733495865618e-02
    x_11_4    product_ub_38  -4.3203209381311537e-02
    x_11_4    onehot_11_55  1
    x_11_4    stock_lb_260  4
    x_11_4    stock_ub_261  4
    x_11_4    parent_nonstrict_scope_262  7.4999999999999980e-03
    x_11_4    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_37  1
    w_11_4    product_ub_38  1
    w_11_4    normalized_mass_11_56  1
    w_11_4    normalized_ratio_11_57  -0.8
    w_11_4    full_original_Gini_320  -7.2178571428571461e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -2.6250000000000006e-02
    x_11_5    product_lb_39  -2.5286733495865618e-02
    x_11_5    product_ub_40  -4.3203209381311537e-02
    x_11_5    onehot_11_55  1
    x_11_5    stock_lb_260  5
    x_11_5    stock_ub_261  5
    x_11_5    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_39  1
    w_11_5    product_ub_40  1
    w_11_5    normalized_mass_11_56  1
    w_11_5    normalized_ratio_11_57  -1
    w_11_5    full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -0.01875
    x_11_6    product_lb_41  -2.5286733495865618e-02
    x_11_6    product_ub_42  -4.3203209381311537e-02
    x_11_6    onehot_11_55  1
    x_11_6    stock_lb_260  6
    x_11_6    stock_ub_261  6
    x_11_6    parent_nonstrict_scope_262  7.5000000000000067e-03
    x_11_6    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_41  1
    w_11_6    product_ub_42  1
    w_11_6    normalized_mass_11_56  1
    w_11_6    normalized_ratio_11_57  -1.2000000000000002e+00
    w_11_6    full_original_Gini_320  -9.3535714285714349e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -1.1250000000000001e-02
    x_11_7    product_lb_43  -2.5286733495865618e-02
    x_11_7    product_ub_44  -4.3203209381311537e-02
    x_11_7    onehot_11_55  1
    x_11_7    stock_lb_260  7
    x_11_7    stock_ub_261  7
    x_11_7    parent_nonstrict_scope_262  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_43  1
    w_11_7    product_ub_44  1
    w_11_7    normalized_mass_11_56  1
    w_11_7    normalized_ratio_11_57  -1.4000000000000001e+00
    w_11_7    full_original_Gini_320  -1.4653571428571436e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -3.7500000000000033e-03
    x_11_8    product_lb_45  -2.5286733495865618e-02
    x_11_8    product_ub_46  -4.3203209381311537e-02
    x_11_8    onehot_11_55  1
    x_11_8    stock_lb_260  8
    x_11_8    stock_ub_261  8
    x_11_8    parent_nonstrict_scope_262  2.2500000000000003e-02
    x_11_8    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_45  1
    w_11_8    product_ub_46  1
    w_11_8    normalized_mass_11_56  1
    w_11_8    normalized_ratio_11_57  -1.6
    w_11_8    full_original_Gini_320  -2.0053571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       3.7499999999999929e-03
    x_11_9    product_lb_47  -2.5286733495865618e-02
    x_11_9    product_ub_48  -4.3203209381311537e-02
    x_11_9    onehot_11_55  1
    x_11_9    stock_lb_260  9
    x_11_9    stock_ub_261  9
    x_11_9    parent_nonstrict_scope_262  0.03
    x_11_9    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_47  1
    w_11_9    product_ub_48  1
    w_11_9    normalized_mass_11_56  1
    w_11_9    normalized_ratio_11_57  -1.8
    w_11_9    full_original_Gini_320  -2.5453571428571440e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1249999999999993e-02
    x_11_10   product_lb_49  -2.5286733495865618e-02
    x_11_10   product_ub_50  -4.3203209381311537e-02
    x_11_10   onehot_11_55  1
    x_11_10   stock_lb_260  10
    x_11_10   stock_ub_261  10
    x_11_10   parent_nonstrict_scope_262  0.0375
    x_11_10   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_49  1
    w_11_10   product_ub_50  1
    w_11_10   normalized_mass_11_56  1
    w_11_10   normalized_ratio_11_57  -2
    w_11_10   full_original_Gini_320  -3.0853571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       0.01875
    x_11_11   product_lb_51  -2.5286733495865618e-02
    x_11_11   product_ub_52  -4.3203209381311537e-02
    x_11_11   onehot_11_55  1
    x_11_11   stock_lb_260  11
    x_11_11   stock_ub_261  11
    x_11_11   parent_nonstrict_scope_262  4.5000000000000005e-02
    x_11_11   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_51  1
    w_11_11   product_ub_52  1
    w_11_11   normalized_mass_11_56  1
    w_11_11   normalized_ratio_11_57  -2.2
    w_11_11   full_original_Gini_320  -3.6253571428571419e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_12   OBJ       2.6250000000000006e-02
    x_11_12   product_lb_53  -2.5286733495865618e-02
    x_11_12   product_ub_54  -4.3203209381311537e-02
    x_11_12   onehot_11_55  1
    x_11_12   stock_lb_260  12
    x_11_12   stock_ub_261  12
    x_11_12   parent_nonstrict_scope_262  5.2500000000000012e-02
    x_11_12   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_53  1
    w_11_12   product_ub_54  1
    w_11_12   normalized_mass_11_56  1
    w_11_12   normalized_ratio_11_57  -2.4000000000000004e+00
    w_11_12   full_original_Gini_320  -4.1653571428571432e+01
    rho_11    normalized_ratio_11_57  1
    rho_11    block_pair_pos_269  -1
    rho_11    block_pair_neg_270  1
    rho_11    block_pair_pos_271  -1
    rho_11    block_pair_neg_272  1
    rho_11    block_pair_pos_273  -1
    rho_11    block_pair_neg_274  1
    rho_11    block_pair_pos_275  -1
    rho_11    block_pair_neg_276  1
    rho_11    block_pair_pos_277  -1
    rho_11    block_pair_neg_278  1
    rho_11    block_pair_pos_279  -1
    rho_11    block_pair_neg_280  1
    rho_11    block_pair_pos_287  1
    rho_11    block_pair_neg_288  -1
    rho_11    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_58  -2.5286733495865618e-02
    x_31_0    product_ub_59  -4.3203209381311537e-02
    x_31_0    onehot_31_84  1
    x_31_0    parent_nonstrict_scope_262  0.0735
    x_31_0    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_58  1
    w_31_0    product_ub_59  1
    w_31_0    normalized_mass_31_85  1
    w_31_0    full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_60  -2.5286733495865618e-02
    x_31_1    product_ub_61  -4.3203209381311537e-02
    x_31_1    onehot_31_84  1
    x_31_1    stock_lb_260  1
    x_31_1    stock_ub_261  1
    x_31_1    parent_nonstrict_scope_262  0.063
    x_31_1    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_60  1
    w_31_1    product_ub_61  1
    w_31_1    normalized_mass_31_85  1
    w_31_1    normalized_ratio_31_86  -1.4285714285714285e-01
    w_31_1    full_original_Gini_320  -1.9289285714285722e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_62  -2.5286733495865618e-02
    x_31_2    product_ub_63  -4.3203209381311537e-02
    x_31_2    onehot_31_84  1
    x_31_2    stock_lb_260  2
    x_31_2    stock_ub_261  2
    x_31_2    parent_nonstrict_scope_262  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_62  1
    w_31_2    product_ub_63  1
    w_31_2    normalized_mass_31_85  1
    w_31_2    normalized_ratio_31_86  -2.8571428571428570e-01
    w_31_2    full_original_Gini_320  -1.5917857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_64  -2.5286733495865618e-02
    x_31_3    product_ub_65  -4.3203209381311537e-02
    x_31_3    onehot_31_84  1
    x_31_3    stock_lb_260  3
    x_31_3    stock_ub_261  3
    x_31_3    parent_nonstrict_scope_262  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_64  1
    w_31_3    product_ub_65  1
    w_31_3    normalized_mass_31_85  1
    w_31_3    normalized_ratio_31_86  -4.2857142857142855e-01
    w_31_3    full_original_Gini_320  -1.3260714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_66  -2.5286733495865618e-02
    x_31_4    product_ub_67  -4.3203209381311537e-02
    x_31_4    onehot_31_84  1
    x_31_4    stock_lb_260  4
    x_31_4    stock_ub_261  4
    x_31_4    parent_nonstrict_scope_262  0.0315
    x_31_4    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_66  1
    w_31_4    product_ub_67  1
    w_31_4    normalized_mass_31_85  1
    w_31_4    normalized_ratio_31_86  -5.7142857142857140e-01
    w_31_4    full_original_Gini_320  -1.0832142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_68  -2.5286733495865618e-02
    x_31_5    product_ub_69  -4.3203209381311537e-02
    x_31_5    onehot_31_84  1
    x_31_5    stock_lb_260  5
    x_31_5    stock_ub_261  5
    x_31_5    parent_nonstrict_scope_262  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_68  1
    w_31_5    product_ub_69  1
    w_31_5    normalized_mass_31_85  1
    w_31_5    normalized_ratio_31_86  -7.1428571428571419e-01
    w_31_5    full_original_Gini_320  -8.40357142857143
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_70  -2.5286733495865618e-02
    x_31_6    product_ub_71  -4.3203209381311537e-02
    x_31_6    onehot_31_84  1
    x_31_6    stock_lb_260  6
    x_31_6    stock_ub_261  6
    x_31_6    parent_nonstrict_scope_262  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_70  1
    w_31_6    product_ub_71  1
    w_31_6    normalized_mass_31_85  1
    w_31_6    normalized_ratio_31_86  -8.5714285714285710e-01
    w_31_6    full_original_Gini_320  -6.4750000000000023e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_72  -2.5286733495865618e-02
    x_31_7    product_ub_73  -4.3203209381311537e-02
    x_31_7    onehot_31_84  1
    x_31_7    stock_lb_260  7
    x_31_7    stock_ub_261  7
    x_31_7    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_72  1
    w_31_7    product_ub_73  1
    w_31_7    normalized_mass_31_85  1
    w_31_7    normalized_ratio_31_86  -1
    w_31_7    full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_74  -2.5286733495865618e-02
    x_31_8    product_ub_75  -4.3203209381311537e-02
    x_31_8    onehot_31_84  1
    x_31_8    stock_lb_260  8
    x_31_8    stock_ub_261  8
    x_31_8    parent_nonstrict_scope_262  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_74  1
    w_31_8    product_ub_75  1
    w_31_8    normalized_mass_31_85  1
    w_31_8    normalized_ratio_31_86  -1.1428571428571428e+00
    w_31_8    full_original_Gini_320  -8.1535714285714267e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_76  -2.5286733495865618e-02
    x_31_9    product_ub_77  -4.3203209381311537e-02
    x_31_9    onehot_31_84  1
    x_31_9    stock_lb_260  9
    x_31_9    stock_ub_261  9
    x_31_9    parent_nonstrict_scope_262  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_76  1
    w_31_9    product_ub_77  1
    w_31_9    normalized_mass_31_85  1
    w_31_9    normalized_ratio_31_86  -1.2857142857142856e+00
    w_31_9    full_original_Gini_320  -1.1567857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_78  -2.5286733495865618e-02
    x_31_10   product_ub_79  -4.3203209381311537e-02
    x_31_10   onehot_31_84  1
    x_31_10   stock_lb_260  10
    x_31_10   stock_ub_261  10
    x_31_10   parent_nonstrict_scope_262  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_78  1
    w_31_10   product_ub_79  1
    w_31_10   normalized_mass_31_85  1
    w_31_10   normalized_ratio_31_86  -1.4285714285714284e+00
    w_31_10   full_original_Gini_320  -1.5424999999999999e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_80  -2.5286733495865618e-02
    x_31_11   product_ub_81  -4.3203209381311537e-02
    x_31_11   onehot_31_84  1
    x_31_11   stock_lb_260  11
    x_31_11   stock_ub_261  11
    x_31_11   parent_nonstrict_scope_262  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_80  1
    w_31_11   product_ub_81  1
    w_31_11   normalized_mass_31_85  1
    w_31_11   normalized_ratio_31_86  -1.5714285714285714e+00
    w_31_11   full_original_Gini_320  -1.9282142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_82  -2.5286733495865618e-02
    x_31_12   product_ub_83  -4.3203209381311537e-02
    x_31_12   onehot_31_84  1
    x_31_12   stock_lb_260  12
    x_31_12   stock_ub_261  12
    x_31_12   parent_nonstrict_scope_262  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_82  1
    w_31_12   product_ub_83  1
    w_31_12   normalized_mass_31_85  1
    w_31_12   normalized_ratio_31_86  -1.7142857142857142e+00
    w_31_12   full_original_Gini_320  -2.3139285714285712e+01
    rho_31    normalized_ratio_31_86  1
    rho_31    block_pair_pos_279  1
    rho_31    block_pair_neg_280  -1
    rho_31    block_pair_pos_295  1
    rho_31    block_pair_neg_296  -1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       0.027
    x_20_0    product_lb_87  -2.5286733495865618e-02
    x_20_0    product_ub_88  -4.3203209381311537e-02
    x_20_0    onehot_20_113  1
    x_20_0    parent_nonstrict_scope_262  0.054
    x_20_0    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_87  1
    w_20_0    product_ub_88  1
    w_20_0    normalized_mass_20_114  1
    w_20_0    full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       0.018
    x_20_1    product_lb_89  -2.5286733495865618e-02
    x_20_1    product_ub_90  -4.3203209381311537e-02
    x_20_1    onehot_20_113  1
    x_20_1    stock_lb_260  1
    x_20_1    stock_ub_261  1
    x_20_1    parent_nonstrict_scope_262  0.045
    x_20_1    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_89  1
    w_20_1    product_ub_90  1
    w_20_1    normalized_mass_20_114  1
    w_20_1    normalized_ratio_20_115  -1.6666666666666666e-01
    w_20_1    full_original_Gini_320  -1.8646428571428576e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       9.0000000000000045e-03
    x_20_2    product_lb_91  -2.5286733495865618e-02
    x_20_2    product_ub_92  -4.3203209381311537e-02
    x_20_2    onehot_20_113  1
    x_20_2    stock_lb_260  2
    x_20_2    stock_ub_261  2
    x_20_2    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_20_2    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_91  1
    w_20_2    product_ub_92  1
    w_20_2    normalized_mass_20_114  1
    w_20_2    normalized_ratio_20_115  -3.3333333333333331e-01
    w_20_2    full_original_Gini_320  -1.5013095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_3    product_lb_93  -2.5286733495865618e-02
    x_20_3    product_ub_94  -4.3203209381311537e-02
    x_20_3    onehot_20_113  1
    x_20_3    stock_lb_260  3
    x_20_3    stock_ub_261  3
    x_20_3    parent_nonstrict_scope_262  0.027
    x_20_3    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_93  1
    w_20_3    product_ub_94  1
    w_20_3    normalized_mass_20_114  1
    w_20_3    normalized_ratio_20_115  -0.5
    w_20_3    full_original_Gini_320  -1.2046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_4    OBJ       -8.9999999999999976e-03
    x_20_4    product_lb_95  -2.5286733495865618e-02
    x_20_4    product_ub_96  -4.3203209381311537e-02
    x_20_4    onehot_20_113  1
    x_20_4    stock_lb_260  4
    x_20_4    stock_ub_261  4
    x_20_4    parent_nonstrict_scope_262  1.8000000000000002e-02
    x_20_4    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_95  1
    w_20_4    product_ub_96  1
    w_20_4    normalized_mass_20_114  1
    w_20_4    normalized_ratio_20_115  -6.6666666666666663e-01
    w_20_4    full_original_Gini_320  -9.2130952380952369e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.7999999999999995e-02
    x_20_5    product_lb_97  -2.5286733495865618e-02
    x_20_5    product_ub_98  -4.3203209381311537e-02
    x_20_5    onehot_20_113  1
    x_20_5    stock_lb_260  5
    x_20_5    stock_ub_261  5
    x_20_5    parent_nonstrict_scope_262  9.0000000000000045e-03
    x_20_5    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_97  1
    w_20_5    product_ub_98  1
    w_20_5    normalized_mass_20_114  1
    w_20_5    normalized_ratio_20_115  -8.3333333333333326e-01
    w_20_5    full_original_Gini_320  -6.7845238095238143e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -0.027
    x_20_6    product_lb_99  -2.5286733495865618e-02
    x_20_6    product_ub_100  -4.3203209381311537e-02
    x_20_6    onehot_20_113  1
    x_20_6    stock_lb_260  6
    x_20_6    stock_ub_261  6
    x_20_6    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_99  1
    w_20_6    product_ub_100  1
    w_20_6    normalized_mass_20_114  1
    w_20_6    normalized_ratio_20_115  -1
    w_20_6    full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -1.8000000000000009e-02
    x_20_7    product_lb_101  -2.5286733495865618e-02
    x_20_7    product_ub_102  -4.3203209381311537e-02
    x_20_7    onehot_20_113  1
    x_20_7    stock_lb_260  7
    x_20_7    stock_ub_261  7
    x_20_7    parent_nonstrict_scope_262  8.9999999999999924e-03
    x_20_7    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_101  1
    w_20_7    product_ub_102  1
    w_20_7    normalized_mass_20_114  1
    w_20_7    normalized_ratio_20_115  -1.1666666666666665e+00
    w_20_7    full_original_Gini_320  -8.6535714285714231e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -9.0000000000000045e-03
    x_20_8    product_lb_103  -2.5286733495865618e-02
    x_20_8    product_ub_104  -4.3203209381311537e-02
    x_20_8    onehot_20_113  1
    x_20_8    stock_lb_260  8
    x_20_8    stock_ub_261  8
    x_20_8    parent_nonstrict_scope_262  1.7999999999999995e-02
    x_20_8    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_103  1
    w_20_8    product_ub_104  1
    w_20_8    normalized_mass_20_114  1
    w_20_8    normalized_ratio_20_115  -1.3333333333333333e+00
    w_20_8    full_original_Gini_320  -1.2853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_9    product_lb_105  -2.5286733495865618e-02
    x_20_9    product_ub_106  -4.3203209381311537e-02
    x_20_9    onehot_20_113  1
    x_20_9    stock_lb_260  9
    x_20_9    stock_ub_261  9
    x_20_9    parent_nonstrict_scope_262  0.027
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_105  1
    w_20_9    product_ub_106  1
    w_20_9    normalized_mass_20_114  1
    w_20_9    normalized_ratio_20_115  -1.5
    w_20_9    full_original_Gini_320  -1.7353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       0.00899999999999999
    x_20_10   product_lb_107  -2.5286733495865618e-02
    x_20_10   product_ub_108  -4.3203209381311537e-02
    x_20_10   onehot_20_113  1
    x_20_10   stock_lb_260  10
    x_20_10   stock_ub_261  10
    x_20_10   parent_nonstrict_scope_262  3.5999999999999990e-02
    x_20_10   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_107  1
    w_20_10   product_ub_108  1
    w_20_10   normalized_mass_20_114  1
    w_20_10   normalized_ratio_20_115  -1.6666666666666665e+00
    w_20_10   full_original_Gini_320  -2.1853571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       0.018
    x_20_11   product_lb_109  -2.5286733495865618e-02
    x_20_11   product_ub_110  -4.3203209381311537e-02
    x_20_11   onehot_20_113  1
    x_20_11   stock_lb_260  11
    x_20_11   stock_ub_261  11
    x_20_11   parent_nonstrict_scope_262  0.045
    x_20_11   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_109  1
    w_20_11   product_ub_110  1
    w_20_11   normalized_mass_20_114  1
    w_20_11   normalized_ratio_20_115  -1.8333333333333333e+00
    w_20_11   full_original_Gini_320  -2.6353571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_12   OBJ       0.027
    x_20_12   product_lb_111  -2.5286733495865618e-02
    x_20_12   product_ub_112  -4.3203209381311537e-02
    x_20_12   onehot_20_113  1
    x_20_12   stock_lb_260  12
    x_20_12   stock_ub_261  12
    x_20_12   parent_nonstrict_scope_262  0.054
    x_20_12   unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_111  1
    w_20_12   product_ub_112  1
    w_20_12   normalized_mass_20_114  1
    w_20_12   normalized_ratio_20_115  -2
    w_20_12   full_original_Gini_320  -3.0853571428571431e+01
    rho_20    normalized_ratio_20_115  1
    rho_20    block_pair_pos_275  1
    rho_20    block_pair_neg_276  -1
    rho_20    block_pair_pos_291  1
    rho_20    block_pair_neg_292  -1
    rho_20    block_pair_pos_297  -1
    rho_20    block_pair_neg_298  1
    rho_20    block_pair_pos_299  -1
    rho_20    block_pair_neg_300  1
    rho_20    block_pair_pos_301  -1
    rho_20    block_pair_neg_302  1
    rho_20    block_pair_pos_303  -1
    rho_20    block_pair_neg_304  1
    rho_20    block_pair_pos_315  1
    rho_20    block_pair_neg_316  -1
    rho_20    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_116  -2.5286733495865618e-02
    x_2_0     product_ub_117  -4.3203209381311537e-02
    x_2_0     onehot_2_148  1
    x_2_0     parent_nonstrict_scope_262  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_116  1
    w_2_0     product_ub_117  1
    w_2_0     normalized_mass_2_149  1
    w_2_0     full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_118  -2.5286733495865618e-02
    x_2_1     product_ub_119  -4.3203209381311537e-02
    x_2_1     onehot_2_148  1
    x_2_1     stock_lb_260  1
    x_2_1     stock_ub_261  1
    x_2_1     parent_nonstrict_scope_262  0.063
    x_2_1     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_118  1
    w_2_1     product_ub_119  1
    w_2_1     normalized_mass_2_149  1
    w_2_1     normalized_ratio_2_150  -1.4285714285714285e-01
    w_2_1     full_original_Gini_320  -1.9289285714285722e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_120  -2.5286733495865618e-02
    x_2_2     product_ub_121  -4.3203209381311537e-02
    x_2_2     onehot_2_148  1
    x_2_2     stock_lb_260  2
    x_2_2     stock_ub_261  2
    x_2_2     parent_nonstrict_scope_262  0.0525
    x_2_2     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_120  1
    w_2_2     product_ub_121  1
    w_2_2     normalized_mass_2_149  1
    w_2_2     normalized_ratio_2_150  -2.8571428571428570e-01
    w_2_2     full_original_Gini_320  -1.5917857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_122  -2.5286733495865618e-02
    x_2_3     product_ub_123  -4.3203209381311537e-02
    x_2_3     onehot_2_148  1
    x_2_3     stock_lb_260  3
    x_2_3     stock_ub_261  3
    x_2_3     parent_nonstrict_scope_262  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_122  1
    w_2_3     product_ub_123  1
    w_2_3     normalized_mass_2_149  1
    w_2_3     normalized_ratio_2_150  -4.2857142857142855e-01
    w_2_3     full_original_Gini_320  -1.3260714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_124  -2.5286733495865618e-02
    x_2_4     product_ub_125  -4.3203209381311537e-02
    x_2_4     onehot_2_148  1
    x_2_4     stock_lb_260  4
    x_2_4     stock_ub_261  4
    x_2_4     parent_nonstrict_scope_262  0.0315
    x_2_4     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_124  1
    w_2_4     product_ub_125  1
    w_2_4     normalized_mass_2_149  1
    w_2_4     normalized_ratio_2_150  -5.7142857142857140e-01
    w_2_4     full_original_Gini_320  -1.0832142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_126  -2.5286733495865618e-02
    x_2_5     product_ub_127  -4.3203209381311537e-02
    x_2_5     onehot_2_148  1
    x_2_5     stock_lb_260  5
    x_2_5     stock_ub_261  5
    x_2_5     parent_nonstrict_scope_262  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_126  1
    w_2_5     product_ub_127  1
    w_2_5     normalized_mass_2_149  1
    w_2_5     normalized_ratio_2_150  -7.1428571428571419e-01
    w_2_5     full_original_Gini_320  -8.40357142857143
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_128  -2.5286733495865618e-02
    x_2_6     product_ub_129  -4.3203209381311537e-02
    x_2_6     onehot_2_148  1
    x_2_6     stock_lb_260  6
    x_2_6     stock_ub_261  6
    x_2_6     parent_nonstrict_scope_262  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_128  1
    w_2_6     product_ub_129  1
    w_2_6     normalized_mass_2_149  1
    w_2_6     normalized_ratio_2_150  -8.5714285714285710e-01
    w_2_6     full_original_Gini_320  -6.4750000000000023e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_130  -2.5286733495865618e-02
    x_2_7     product_ub_131  -4.3203209381311537e-02
    x_2_7     onehot_2_148  1
    x_2_7     stock_lb_260  7
    x_2_7     stock_ub_261  7
    x_2_7     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_130  1
    w_2_7     product_ub_131  1
    w_2_7     normalized_mass_2_149  1
    w_2_7     normalized_ratio_2_150  -1
    w_2_7     full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_132  -2.5286733495865618e-02
    x_2_8     product_ub_133  -4.3203209381311537e-02
    x_2_8     onehot_2_148  1
    x_2_8     stock_lb_260  8
    x_2_8     stock_ub_261  8
    x_2_8     parent_nonstrict_scope_262  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_132  1
    w_2_8     product_ub_133  1
    w_2_8     normalized_mass_2_149  1
    w_2_8     normalized_ratio_2_150  -1.1428571428571428e+00
    w_2_8     full_original_Gini_320  -8.1535714285714267e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_134  -2.5286733495865618e-02
    x_2_9     product_ub_135  -4.3203209381311537e-02
    x_2_9     onehot_2_148  1
    x_2_9     stock_lb_260  9
    x_2_9     stock_ub_261  9
    x_2_9     parent_nonstrict_scope_262  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_134  1
    w_2_9     product_ub_135  1
    w_2_9     normalized_mass_2_149  1
    w_2_9     normalized_ratio_2_150  -1.2857142857142856e+00
    w_2_9     full_original_Gini_320  -1.1567857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_136  -2.5286733495865618e-02
    x_2_10    product_ub_137  -4.3203209381311537e-02
    x_2_10    onehot_2_148  1
    x_2_10    stock_lb_260  10
    x_2_10    stock_ub_261  10
    x_2_10    parent_nonstrict_scope_262  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_136  1
    w_2_10    product_ub_137  1
    w_2_10    normalized_mass_2_149  1
    w_2_10    normalized_ratio_2_150  -1.4285714285714284e+00
    w_2_10    full_original_Gini_320  -1.5424999999999999e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_138  -2.5286733495865618e-02
    x_2_11    product_ub_139  -4.3203209381311537e-02
    x_2_11    onehot_2_148  1
    x_2_11    stock_lb_260  11
    x_2_11    stock_ub_261  11
    x_2_11    parent_nonstrict_scope_262  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_138  1
    w_2_11    product_ub_139  1
    w_2_11    normalized_mass_2_149  1
    w_2_11    normalized_ratio_2_150  -1.5714285714285714e+00
    w_2_11    full_original_Gini_320  -1.9282142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_140  -2.5286733495865618e-02
    x_2_12    product_ub_141  -4.3203209381311537e-02
    x_2_12    onehot_2_148  1
    x_2_12    stock_lb_260  12
    x_2_12    stock_ub_261  12
    x_2_12    parent_nonstrict_scope_262  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_140  1
    w_2_12    product_ub_141  1
    w_2_12    normalized_mass_2_149  1
    w_2_12    normalized_ratio_2_150  -1.7142857142857142e+00
    w_2_12    full_original_Gini_320  -2.3139285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_142  -2.5286733495865618e-02
    x_2_13    product_ub_143  -4.3203209381311537e-02
    x_2_13    onehot_2_148  1
    x_2_13    stock_lb_260  13
    x_2_13    stock_ub_261  13
    x_2_13    parent_nonstrict_scope_262  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_142  1
    w_2_13    product_ub_143  1
    w_2_13    normalized_mass_2_149  1
    w_2_13    normalized_ratio_2_150  -1.8571428571428570e+00
    w_2_13    full_original_Gini_320  -2.6996428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_144  -2.5286733495865618e-02
    x_2_14    product_ub_145  -4.3203209381311537e-02
    x_2_14    onehot_2_148  1
    x_2_14    stock_lb_260  14
    x_2_14    stock_ub_261  14
    x_2_14    parent_nonstrict_scope_262  0.0735
    x_2_14    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_144  1
    w_2_14    product_ub_145  1
    w_2_14    normalized_mass_2_149  1
    w_2_14    normalized_ratio_2_150  -2
    w_2_14    full_original_Gini_320  -3.0853571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_146  -2.5286733495865618e-02
    x_2_15    product_ub_147  -4.3203209381311537e-02
    x_2_15    onehot_2_148  1
    x_2_15    stock_lb_260  15
    x_2_15    stock_ub_261  15
    x_2_15    parent_nonstrict_scope_262  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_146  1
    w_2_15    product_ub_147  1
    w_2_15    normalized_mass_2_149  1
    w_2_15    normalized_ratio_2_150  -2.1428571428571428e+00
    w_2_15    full_original_Gini_320  -3.4710714285714282e+01
    rho_2     normalized_ratio_2_150  1
    rho_2     block_pair_pos_263  -1
    rho_2     block_pair_neg_264  1
    rho_2     block_pair_pos_265  -1
    rho_2     block_pair_neg_266  1
    rho_2     block_pair_pos_267  -1
    rho_2     block_pair_neg_268  1
    rho_2     block_pair_pos_269  1
    rho_2     block_pair_neg_270  -1
    rho_2     block_pair_pos_283  1
    rho_2     block_pair_neg_284  -1
    rho_2     block_pair_pos_297  1
    rho_2     block_pair_neg_298  -1
    rho_2     block_pair_pos_309  1
    rho_2     block_pair_neg_310  -1
    rho_2     normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_21_0    OBJ       0.048
    x_21_0    product_lb_151  -2.5286733495865618e-02
    x_21_0    product_ub_152  -4.3203209381311537e-02
    x_21_0    onehot_21_183  1
    x_21_0    parent_nonstrict_scope_262  0.096
    x_21_0    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_0    product_lb_151  1
    w_21_0    product_ub_152  1
    w_21_0    normalized_mass_21_184  1
    w_21_0    full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_1    OBJ       3.6000000000000004e-02
    x_21_1    product_lb_153  -2.5286733495865618e-02
    x_21_1    product_ub_154  -4.3203209381311537e-02
    x_21_1    onehot_21_183  1
    x_21_1    stock_lb_260  1
    x_21_1    stock_ub_261  1
    x_21_1    parent_nonstrict_scope_262  0.084
    MARKER    'MARKER'                 'INTEND'
    w_21_1    product_lb_153  1
    w_21_1    product_ub_154  1
    w_21_1    normalized_mass_21_184  1
    w_21_1    normalized_ratio_21_185  -0.125
    w_21_1    full_original_Gini_320  -1.9771428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_2    OBJ       2.4000000000000007e-02
    x_21_2    product_lb_155  -2.5286733495865618e-02
    x_21_2    product_ub_156  -4.3203209381311537e-02
    x_21_2    onehot_21_183  1
    x_21_2    stock_lb_260  2
    x_21_2    stock_ub_261  2
    x_21_2    parent_nonstrict_scope_262  7.2000000000000008e-02
    x_21_2    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_2    product_lb_155  1
    w_21_2    product_ub_156  1
    w_21_2    normalized_mass_21_184  1
    w_21_2    normalized_ratio_21_185  -0.25
    w_21_2    full_original_Gini_320  -1.6596428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_3    OBJ       1.1999999999999997e-02
    x_21_3    product_lb_157  -2.5286733495865618e-02
    x_21_3    product_ub_158  -4.3203209381311537e-02
    x_21_3    onehot_21_183  1
    x_21_3    stock_lb_260  3
    x_21_3    stock_ub_261  3
    x_21_3    parent_nonstrict_scope_262  0.06
    x_21_3    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_3    product_lb_157  1
    w_21_3    product_ub_158  1
    w_21_3    normalized_mass_21_184  1
    w_21_3    normalized_ratio_21_185  -0.375
    w_21_3    full_original_Gini_320  -1.4221428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_4    product_lb_159  -2.5286733495865618e-02
    x_21_4    product_ub_160  -4.3203209381311537e-02
    x_21_4    onehot_21_183  1
    x_21_4    stock_lb_260  4
    x_21_4    stock_ub_261  4
    x_21_4    parent_nonstrict_scope_262  0.048
    x_21_4    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_4    product_lb_159  1
    w_21_4    product_ub_160  1
    w_21_4    normalized_mass_21_184  1
    w_21_4    normalized_ratio_21_185  -0.5
    w_21_4    full_original_Gini_320  -1.2046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_5    OBJ       -1.1999999999999997e-02
    x_21_5    product_lb_161  -2.5286733495865618e-02
    x_21_5    product_ub_162  -4.3203209381311537e-02
    x_21_5    onehot_21_183  1
    x_21_5    stock_lb_260  5
    x_21_5    stock_ub_261  5
    x_21_5    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_21_5    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_5    product_lb_161  1
    w_21_5    product_ub_162  1
    w_21_5    normalized_mass_21_184  1
    w_21_5    normalized_ratio_21_185  -0.625
    w_21_5    full_original_Gini_320  -9.9214285714285726e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_6    OBJ       -0.024
    x_21_6    product_lb_163  -2.5286733495865618e-02
    x_21_6    product_ub_164  -4.3203209381311537e-02
    x_21_6    onehot_21_183  1
    x_21_6    stock_lb_260  6
    x_21_6    stock_ub_261  6
    x_21_6    parent_nonstrict_scope_262  0.024
    x_21_6    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_6    product_lb_163  1
    w_21_6    product_ub_164  1
    w_21_6    normalized_mass_21_184  1
    w_21_6    normalized_ratio_21_185  -0.75
    w_21_6    full_original_Gini_320  -7.8678571428571420e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_7    OBJ       -3.6000000000000004e-02
    x_21_7    product_lb_165  -2.5286733495865618e-02
    x_21_7    product_ub_166  -4.3203209381311537e-02
    x_21_7    onehot_21_183  1
    x_21_7    stock_lb_260  7
    x_21_7    stock_ub_261  7
    x_21_7    parent_nonstrict_scope_262  0.012
    x_21_7    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_7    product_lb_165  1
    w_21_7    product_ub_166  1
    w_21_7    normalized_mass_21_184  1
    w_21_7    normalized_ratio_21_185  -0.875
    w_21_7    full_original_Gini_320  -6.2785714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_8    OBJ       -0.048
    x_21_8    product_lb_167  -2.5286733495865618e-02
    x_21_8    product_ub_168  -4.3203209381311537e-02
    x_21_8    onehot_21_183  1
    x_21_8    stock_lb_260  8
    x_21_8    stock_ub_261  8
    x_21_8    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_8    product_lb_167  1
    w_21_8    product_ub_168  1
    w_21_8    normalized_mass_21_184  1
    w_21_8    normalized_ratio_21_185  -1
    w_21_8    full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_9    OBJ       -3.6000000000000004e-02
    x_21_9    product_lb_169  -2.5286733495865618e-02
    x_21_9    product_ub_170  -4.3203209381311537e-02
    x_21_9    onehot_21_183  1
    x_21_9    stock_lb_260  9
    x_21_9    stock_ub_261  9
    x_21_9    parent_nonstrict_scope_262  0.012
    x_21_9    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_9    product_lb_169  1
    w_21_9    product_ub_170  1
    w_21_9    normalized_mass_21_184  1
    w_21_9    normalized_ratio_21_185  -1.125
    w_21_9    full_original_Gini_320  -7.7785714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_10   OBJ       -0.024
    x_21_10   product_lb_171  -2.5286733495865618e-02
    x_21_10   product_ub_172  -4.3203209381311537e-02
    x_21_10   onehot_21_183  1
    x_21_10   stock_lb_260  10
    x_21_10   stock_ub_261  10
    x_21_10   parent_nonstrict_scope_262  0.024
    x_21_10   unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_10   product_lb_171  1
    w_21_10   product_ub_172  1
    w_21_10   normalized_mass_21_184  1
    w_21_10   normalized_ratio_21_185  -1.25
    w_21_10   full_original_Gini_320  -1.0603571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_11   OBJ       -1.1999999999999997e-02
    x_21_11   product_lb_173  -2.5286733495865618e-02
    x_21_11   product_ub_174  -4.3203209381311537e-02
    x_21_11   onehot_21_183  1
    x_21_11   stock_lb_260  11
    x_21_11   stock_ub_261  11
    x_21_11   parent_nonstrict_scope_262  3.6000000000000004e-02
    x_21_11   unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_11   product_lb_173  1
    w_21_11   product_ub_174  1
    w_21_11   normalized_mass_21_184  1
    w_21_11   normalized_ratio_21_185  -1.375
    w_21_11   full_original_Gini_320  -1.3978571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_12   product_lb_175  -2.5286733495865618e-02
    x_21_12   product_ub_176  -4.3203209381311537e-02
    x_21_12   onehot_21_183  1
    x_21_12   stock_lb_260  12
    x_21_12   stock_ub_261  12
    x_21_12   parent_nonstrict_scope_262  0.048
    x_21_12   unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_12   product_lb_175  1
    w_21_12   product_ub_176  1
    w_21_12   normalized_mass_21_184  1
    w_21_12   normalized_ratio_21_185  -1.5
    w_21_12   full_original_Gini_320  -1.7353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_13   OBJ       1.1999999999999997e-02
    x_21_13   product_lb_177  -2.5286733495865618e-02
    x_21_13   product_ub_178  -4.3203209381311537e-02
    x_21_13   onehot_21_183  1
    x_21_13   stock_lb_260  13
    x_21_13   stock_ub_261  13
    x_21_13   parent_nonstrict_scope_262  0.06
    x_21_13   unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_13   product_lb_177  1
    w_21_13   product_ub_178  1
    w_21_13   normalized_mass_21_184  1
    w_21_13   normalized_ratio_21_185  -1.625
    w_21_13   full_original_Gini_320  -2.0728571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_14   OBJ       2.4000000000000007e-02
    x_21_14   product_lb_179  -2.5286733495865618e-02
    x_21_14   product_ub_180  -4.3203209381311537e-02
    x_21_14   onehot_21_183  1
    x_21_14   stock_lb_260  14
    x_21_14   stock_ub_261  14
    x_21_14   parent_nonstrict_scope_262  7.2000000000000008e-02
    x_21_14   unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_14   product_lb_179  1
    w_21_14   product_ub_180  1
    w_21_14   normalized_mass_21_184  1
    w_21_14   normalized_ratio_21_185  -1.75
    w_21_14   full_original_Gini_320  -2.4103571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_15   OBJ       3.6000000000000004e-02
    x_21_15   product_lb_181  -2.5286733495865618e-02
    x_21_15   product_ub_182  -4.3203209381311537e-02
    x_21_15   onehot_21_183  1
    x_21_15   stock_lb_260  15
    x_21_15   stock_ub_261  15
    x_21_15   parent_nonstrict_scope_262  0.084
    x_21_15   unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_15   product_lb_181  1
    w_21_15   product_ub_182  1
    w_21_15   normalized_mass_21_184  1
    w_21_15   normalized_ratio_21_185  -1.875
    w_21_15   full_original_Gini_320  -2.7478571428571428e+01
    rho_21    normalized_ratio_21_185  1
    rho_21    block_pair_pos_267  1
    rho_21    block_pair_neg_268  -1
    rho_21    block_pair_pos_277  1
    rho_21    block_pair_neg_278  -1
    rho_21    block_pair_pos_293  1
    rho_21    block_pair_neg_294  -1
    rho_21    block_pair_pos_303  1
    rho_21    block_pair_neg_304  -1
    rho_21    block_pair_pos_305  -1
    rho_21    block_pair_neg_306  1
    rho_21    block_pair_pos_307  -1
    rho_21    block_pair_neg_308  1
    rho_21    block_pair_pos_317  1
    rho_21    block_pair_neg_318  -1
    rho_21    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       0.0315
    x_12_0    product_lb_186  -2.5286733495865618e-02
    x_12_0    product_ub_187  -4.3203209381311537e-02
    x_12_0    onehot_12_218  1
    x_12_0    parent_nonstrict_scope_262  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_186  1
    w_12_0    product_ub_187  1
    w_12_0    normalized_mass_12_219  1
    w_12_0    full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1000000000000005e-02
    x_12_1    product_lb_188  -2.5286733495865618e-02
    x_12_1    product_ub_189  -4.3203209381311537e-02
    x_12_1    onehot_12_218  1
    x_12_1    stock_lb_260  1
    x_12_1    stock_ub_261  1
    x_12_1    parent_nonstrict_scope_262  0.063
    x_12_1    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_188  1
    w_12_1    product_ub_189  1
    w_12_1    normalized_mass_12_219  1
    w_12_1    normalized_ratio_12_220  -1.4285714285714285e-01
    w_12_1    full_original_Gini_320  -1.9289285714285722e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0500000000000002e-02
    x_12_2    product_lb_190  -2.5286733495865618e-02
    x_12_2    product_ub_191  -4.3203209381311537e-02
    x_12_2    onehot_12_218  1
    x_12_2    stock_lb_260  2
    x_12_2    stock_ub_261  2
    x_12_2    parent_nonstrict_scope_262  0.0525
    x_12_2    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_190  1
    w_12_2    product_ub_191  1
    w_12_2    normalized_mass_12_219  1
    w_12_2    normalized_ratio_12_220  -2.8571428571428570e-01
    w_12_2    full_original_Gini_320  -1.5917857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_192  -2.5286733495865618e-02
    x_12_3    product_ub_193  -4.3203209381311537e-02
    x_12_3    onehot_12_218  1
    x_12_3    stock_lb_260  3
    x_12_3    stock_ub_261  3
    x_12_3    parent_nonstrict_scope_262  4.1999999999999996e-02
    x_12_3    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_192  1
    w_12_3    product_ub_193  1
    w_12_3    normalized_mass_12_219  1
    w_12_3    normalized_ratio_12_220  -4.2857142857142855e-01
    w_12_3    full_original_Gini_320  -1.3260714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0499999999999995e-02
    x_12_4    product_lb_194  -2.5286733495865618e-02
    x_12_4    product_ub_195  -4.3203209381311537e-02
    x_12_4    onehot_12_218  1
    x_12_4    stock_lb_260  4
    x_12_4    stock_ub_261  4
    x_12_4    parent_nonstrict_scope_262  0.0315
    x_12_4    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_194  1
    w_12_4    product_ub_195  1
    w_12_4    normalized_mass_12_219  1
    w_12_4    normalized_ratio_12_220  -5.7142857142857140e-01
    w_12_4    full_original_Gini_320  -1.0832142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.0999999999999991e-02
    x_12_5    product_lb_196  -2.5286733495865618e-02
    x_12_5    product_ub_197  -4.3203209381311537e-02
    x_12_5    onehot_12_218  1
    x_12_5    stock_lb_260  5
    x_12_5    stock_ub_261  5
    x_12_5    parent_nonstrict_scope_262  2.1000000000000005e-02
    x_12_5    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_196  1
    w_12_5    product_ub_197  1
    w_12_5    normalized_mass_12_219  1
    w_12_5    normalized_ratio_12_220  -7.1428571428571419e-01
    w_12_5    full_original_Gini_320  -8.40357142857143
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.1499999999999993e-02
    x_12_6    product_lb_198  -2.5286733495865618e-02
    x_12_6    product_ub_199  -4.3203209381311537e-02
    x_12_6    onehot_12_218  1
    x_12_6    stock_lb_260  6
    x_12_6    stock_ub_261  6
    x_12_6    parent_nonstrict_scope_262  1.0500000000000002e-02
    x_12_6    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_198  1
    w_12_6    product_ub_199  1
    w_12_6    normalized_mass_12_219  1
    w_12_6    normalized_ratio_12_220  -8.5714285714285710e-01
    w_12_6    full_original_Gini_320  -6.4750000000000023e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.1999999999999996e-02
    x_12_7    product_lb_200  -2.5286733495865618e-02
    x_12_7    product_ub_201  -4.3203209381311537e-02
    x_12_7    onehot_12_218  1
    x_12_7    stock_lb_260  7
    x_12_7    stock_ub_261  7
    x_12_7    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_200  1
    w_12_7    product_ub_201  1
    w_12_7    normalized_mass_12_219  1
    w_12_7    normalized_ratio_12_220  -1
    w_12_7    full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -0.0315
    x_12_8    product_lb_202  -2.5286733495865618e-02
    x_12_8    product_ub_203  -4.3203209381311537e-02
    x_12_8    onehot_12_218  1
    x_12_8    stock_lb_260  8
    x_12_8    stock_ub_261  8
    x_12_8    parent_nonstrict_scope_262  1.0499999999999995e-02
    x_12_8    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_202  1
    w_12_8    product_ub_203  1
    w_12_8    normalized_mass_12_219  1
    w_12_8    normalized_ratio_12_220  -1.1428571428571428e+00
    w_12_8    full_original_Gini_320  -8.1535714285714267e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1000000000000005e-02
    x_12_9    product_lb_204  -2.5286733495865618e-02
    x_12_9    product_ub_205  -4.3203209381311537e-02
    x_12_9    onehot_12_218  1
    x_12_9    stock_lb_260  9
    x_12_9    stock_ub_261  9
    x_12_9    parent_nonstrict_scope_262  2.0999999999999991e-02
    x_12_9    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_204  1
    w_12_9    product_ub_205  1
    w_12_9    normalized_mass_12_219  1
    w_12_9    normalized_ratio_12_220  -1.2857142857142856e+00
    w_12_9    full_original_Gini_320  -1.1567857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0500000000000009e-02
    x_12_10   product_lb_206  -2.5286733495865618e-02
    x_12_10   product_ub_207  -4.3203209381311537e-02
    x_12_10   onehot_12_218  1
    x_12_10   stock_lb_260  10
    x_12_10   stock_ub_261  10
    x_12_10   parent_nonstrict_scope_262  3.1499999999999986e-02
    x_12_10   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_206  1
    w_12_10   product_ub_207  1
    w_12_10   normalized_mass_12_219  1
    w_12_10   normalized_ratio_12_220  -1.4285714285714284e+00
    w_12_10   full_original_Gini_320  -1.5424999999999999e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_208  -2.5286733495865618e-02
    x_12_11   product_ub_209  -4.3203209381311537e-02
    x_12_11   onehot_12_218  1
    x_12_11   stock_lb_260  11
    x_12_11   stock_ub_261  11
    x_12_11   parent_nonstrict_scope_262  4.1999999999999996e-02
    x_12_11   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_208  1
    w_12_11   product_ub_209  1
    w_12_11   normalized_mass_12_219  1
    w_12_11   normalized_ratio_12_220  -1.5714285714285714e+00
    w_12_11   full_original_Gini_320  -1.9282142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0499999999999995e-02
    x_12_12   product_lb_210  -2.5286733495865618e-02
    x_12_12   product_ub_211  -4.3203209381311537e-02
    x_12_12   onehot_12_218  1
    x_12_12   stock_lb_260  12
    x_12_12   stock_ub_261  12
    x_12_12   parent_nonstrict_scope_262  5.2499999999999991e-02
    x_12_12   unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_210  1
    w_12_12   product_ub_211  1
    w_12_12   normalized_mass_12_219  1
    w_12_12   normalized_ratio_12_220  -1.7142857142857142e+00
    w_12_12   full_original_Gini_320  -2.3139285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.0999999999999991e-02
    x_12_13   product_lb_212  -2.5286733495865618e-02
    x_12_13   product_ub_213  -4.3203209381311537e-02
    x_12_13   onehot_12_218  1
    x_12_13   stock_lb_260  13
    x_12_13   stock_ub_261  13
    x_12_13   parent_nonstrict_scope_262  6.2999999999999987e-02
    x_12_13   unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_212  1
    w_12_13   product_ub_213  1
    w_12_13   normalized_mass_12_219  1
    w_12_13   normalized_ratio_12_220  -1.8571428571428570e+00
    w_12_13   full_original_Gini_320  -2.6996428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       0.0315
    x_12_14   product_lb_214  -2.5286733495865618e-02
    x_12_14   product_ub_215  -4.3203209381311537e-02
    x_12_14   onehot_12_218  1
    x_12_14   stock_lb_260  14
    x_12_14   stock_ub_261  14
    x_12_14   parent_nonstrict_scope_262  0.0735
    x_12_14   unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_214  1
    w_12_14   product_ub_215  1
    w_12_14   normalized_mass_12_219  1
    w_12_14   normalized_ratio_12_220  -2
    w_12_14   full_original_Gini_320  -3.0853571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.1999999999999996e-02
    x_12_15   product_lb_216  -2.5286733495865618e-02
    x_12_15   product_ub_217  -4.3203209381311537e-02
    x_12_15   onehot_12_218  1
    x_12_15   stock_lb_260  15
    x_12_15   stock_ub_261  15
    x_12_15   parent_nonstrict_scope_262  8.3999999999999991e-02
    x_12_15   unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_216  1
    w_12_15   product_ub_217  1
    w_12_15   normalized_mass_12_219  1
    w_12_15   normalized_ratio_12_220  -2.1428571428571428e+00
    w_12_15   full_original_Gini_320  -3.4710714285714282e+01
    rho_12    normalized_ratio_12_220  1
    rho_12    block_pair_pos_265  1
    rho_12    block_pair_neg_266  -1
    rho_12    block_pair_pos_273  1
    rho_12    block_pair_neg_274  -1
    rho_12    block_pair_pos_281  -1
    rho_12    block_pair_neg_282  1
    rho_12    block_pair_pos_289  1
    rho_12    block_pair_neg_290  -1
    rho_12    block_pair_pos_301  1
    rho_12    block_pair_neg_302  -1
    rho_12    block_pair_pos_307  1
    rho_12    block_pair_neg_308  -1
    rho_12    block_pair_pos_313  1
    rho_12    block_pair_neg_314  -1
    rho_12    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       0.042
    x_7_0     product_lb_221  -2.5286733495865618e-02
    x_7_0     product_ub_222  -4.3203209381311537e-02
    x_7_0     onehot_7_257  1
    x_7_0     parent_nonstrict_scope_262  0.096
    x_7_0     unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_221  1
    w_7_0     product_ub_222  1
    w_7_0     normalized_mass_7_258  1
    w_7_0     full_original_Gini_320  -2.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       3.0000000000000006e-02
    x_7_1     product_lb_223  -2.5286733495865618e-02
    x_7_1     product_ub_224  -4.3203209381311537e-02
    x_7_1     onehot_7_257  1
    x_7_1     stock_lb_260  1
    x_7_1     stock_ub_261  1
    x_7_1     parent_nonstrict_scope_262  0.084
    x_7_1     unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_223  1
    w_7_1     product_ub_224  1
    w_7_1     normalized_mass_7_258  1
    w_7_1     normalized_ratio_7_259  -0.125
    w_7_1     full_original_Gini_320  -1.9771428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       1.8000000000000009e-02
    x_7_2     product_lb_225  -2.5286733495865618e-02
    x_7_2     product_ub_226  -4.3203209381311537e-02
    x_7_2     onehot_7_257  1
    x_7_2     stock_lb_260  2
    x_7_2     stock_ub_261  2
    x_7_2     parent_nonstrict_scope_262  7.2000000000000008e-02
    x_7_2     unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_225  1
    w_7_2     product_ub_226  1
    w_7_2     normalized_mass_7_258  1
    w_7_2     normalized_ratio_7_259  -0.25
    w_7_2     full_original_Gini_320  -1.6596428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       5.9999999999999984e-03
    x_7_3     product_lb_227  -2.5286733495865618e-02
    x_7_3     product_ub_228  -4.3203209381311537e-02
    x_7_3     onehot_7_257  1
    x_7_3     stock_lb_260  3
    x_7_3     stock_ub_261  3
    x_7_3     parent_nonstrict_scope_262  0.06
    x_7_3     unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_227  1
    w_7_3     product_ub_228  1
    w_7_3     normalized_mass_7_258  1
    w_7_3     normalized_ratio_7_259  -0.375
    w_7_3     full_original_Gini_320  -1.4221428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -5.9999999999999984e-03
    x_7_4     product_lb_229  -2.5286733495865618e-02
    x_7_4     product_ub_230  -4.3203209381311537e-02
    x_7_4     onehot_7_257  1
    x_7_4     stock_lb_260  4
    x_7_4     stock_ub_261  4
    x_7_4     parent_nonstrict_scope_262  0.048
    x_7_4     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_229  1
    w_7_4     product_ub_230  1
    w_7_4     normalized_mass_7_258  1
    w_7_4     normalized_ratio_7_259  -0.5
    w_7_4     full_original_Gini_320  -1.2046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.7999999999999995e-02
    x_7_5     product_lb_231  -2.5286733495865618e-02
    x_7_5     product_ub_232  -4.3203209381311537e-02
    x_7_5     onehot_7_257  1
    x_7_5     stock_lb_260  5
    x_7_5     stock_ub_261  5
    x_7_5     parent_nonstrict_scope_262  3.6000000000000004e-02
    x_7_5     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_231  1
    w_7_5     product_ub_232  1
    w_7_5     normalized_mass_7_258  1
    w_7_5     normalized_ratio_7_259  -0.625
    w_7_5     full_original_Gini_320  -9.9214285714285726e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -0.03
    x_7_6     product_lb_233  -2.5286733495865618e-02
    x_7_6     product_ub_234  -4.3203209381311537e-02
    x_7_6     onehot_7_257  1
    x_7_6     stock_lb_260  6
    x_7_6     stock_ub_261  6
    x_7_6     parent_nonstrict_scope_262  0.024
    x_7_6     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_233  1
    w_7_6     product_ub_234  1
    w_7_6     normalized_mass_7_258  1
    w_7_6     normalized_ratio_7_259  -0.75
    w_7_6     full_original_Gini_320  -7.8678571428571420e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -4.1999999999999996e-02
    x_7_7     product_lb_235  -2.5286733495865618e-02
    x_7_7     product_ub_236  -4.3203209381311537e-02
    x_7_7     onehot_7_257  1
    x_7_7     stock_lb_260  7
    x_7_7     stock_ub_261  7
    x_7_7     parent_nonstrict_scope_262  0.012
    x_7_7     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_235  1
    w_7_7     product_ub_236  1
    w_7_7     normalized_mass_7_258  1
    w_7_7     normalized_ratio_7_259  -0.875
    w_7_7     full_original_Gini_320  -6.2785714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -0.054
    x_7_8     product_lb_237  -2.5286733495865618e-02
    x_7_8     product_ub_238  -4.3203209381311537e-02
    x_7_8     onehot_7_257  1
    x_7_8     stock_lb_260  8
    x_7_8     stock_ub_261  8
    x_7_8     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_237  1
    w_7_8     product_ub_238  1
    w_7_8     normalized_mass_7_258  1
    w_7_8     normalized_ratio_7_259  -1
    w_7_8     full_original_Gini_320  -5.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -4.1999999999999996e-02
    x_7_9     product_lb_239  -2.5286733495865618e-02
    x_7_9     product_ub_240  -4.3203209381311537e-02
    x_7_9     onehot_7_257  1
    x_7_9     stock_lb_260  9
    x_7_9     stock_ub_261  9
    x_7_9     parent_nonstrict_scope_262  0.012
    x_7_9     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_239  1
    w_7_9     product_ub_240  1
    w_7_9     normalized_mass_7_258  1
    w_7_9     normalized_ratio_7_259  -1.125
    w_7_9     full_original_Gini_320  -7.7785714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -0.03
    x_7_10    product_lb_241  -2.5286733495865618e-02
    x_7_10    product_ub_242  -4.3203209381311537e-02
    x_7_10    onehot_7_257  1
    x_7_10    stock_lb_260  10
    x_7_10    stock_ub_261  10
    x_7_10    parent_nonstrict_scope_262  0.024
    x_7_10    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_241  1
    w_7_10    product_ub_242  1
    w_7_10    normalized_mass_7_258  1
    w_7_10    normalized_ratio_7_259  -1.25
    w_7_10    full_original_Gini_320  -1.0603571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    OBJ       -1.7999999999999995e-02
    x_7_11    product_lb_243  -2.5286733495865618e-02
    x_7_11    product_ub_244  -4.3203209381311537e-02
    x_7_11    onehot_7_257  1
    x_7_11    stock_lb_260  11
    x_7_11    stock_ub_261  11
    x_7_11    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_7_11    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_243  1
    w_7_11    product_ub_244  1
    w_7_11    normalized_mass_7_258  1
    w_7_11    normalized_ratio_7_259  -1.375
    w_7_11    full_original_Gini_320  -1.3978571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       -5.9999999999999984e-03
    x_7_12    product_lb_245  -2.5286733495865618e-02
    x_7_12    product_ub_246  -4.3203209381311537e-02
    x_7_12    onehot_7_257  1
    x_7_12    stock_lb_260  12
    x_7_12    stock_ub_261  12
    x_7_12    parent_nonstrict_scope_262  0.048
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_245  1
    w_7_12    product_ub_246  1
    w_7_12    normalized_mass_7_258  1
    w_7_12    normalized_ratio_7_259  -1.5
    w_7_12    full_original_Gini_320  -1.7353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       5.9999999999999984e-03
    x_7_13    product_lb_247  -2.5286733495865618e-02
    x_7_13    product_ub_248  -4.3203209381311537e-02
    x_7_13    onehot_7_257  1
    x_7_13    stock_lb_260  13
    x_7_13    stock_ub_261  13
    x_7_13    parent_nonstrict_scope_262  0.06
    x_7_13    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_247  1
    w_7_13    product_ub_248  1
    w_7_13    normalized_mass_7_258  1
    w_7_13    normalized_ratio_7_259  -1.625
    w_7_13    full_original_Gini_320  -2.0728571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.8000000000000009e-02
    x_7_14    product_lb_249  -2.5286733495865618e-02
    x_7_14    product_ub_250  -4.3203209381311537e-02
    x_7_14    onehot_7_257  1
    x_7_14    stock_lb_260  14
    x_7_14    stock_ub_261  14
    x_7_14    parent_nonstrict_scope_262  7.2000000000000008e-02
    x_7_14    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_249  1
    w_7_14    product_ub_250  1
    w_7_14    normalized_mass_7_258  1
    w_7_14    normalized_ratio_7_259  -1.75
    w_7_14    full_original_Gini_320  -2.4103571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       3.0000000000000006e-02
    x_7_15    product_lb_251  -2.5286733495865618e-02
    x_7_15    product_ub_252  -4.3203209381311537e-02
    x_7_15    onehot_7_257  1
    x_7_15    stock_lb_260  15
    x_7_15    stock_ub_261  15
    x_7_15    parent_nonstrict_scope_262  0.084
    x_7_15    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_251  1
    w_7_15    product_ub_252  1
    w_7_15    normalized_mass_7_258  1
    w_7_15    normalized_ratio_7_259  -1.875
    w_7_15    full_original_Gini_320  -2.7478571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_16    OBJ       0.042
    x_7_16    product_lb_253  -2.5286733495865618e-02
    x_7_16    product_ub_254  -4.3203209381311537e-02
    x_7_16    onehot_7_257  1
    x_7_16    stock_lb_260  16
    x_7_16    stock_ub_261  16
    x_7_16    parent_nonstrict_scope_262  0.096
    x_7_16    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_16    product_lb_253  1
    w_7_16    product_ub_254  1
    w_7_16    normalized_mass_7_258  1
    w_7_16    normalized_ratio_7_259  -2
    w_7_16    full_original_Gini_320  -3.0853571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_17    OBJ       0.054
    x_7_17    product_lb_255  -2.5286733495865618e-02
    x_7_17    product_ub_256  -4.3203209381311537e-02
    x_7_17    onehot_7_257  1
    x_7_17    stock_lb_260  17
    x_7_17    stock_ub_261  17
    x_7_17    parent_nonstrict_scope_262  0.108
    x_7_17    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_17    product_lb_255  1
    w_7_17    product_ub_256  1
    w_7_17    normalized_mass_7_258  1
    w_7_17    normalized_ratio_7_259  -2.125
    w_7_17    full_original_Gini_320  -3.4228571428571428e+01
    rho_7     normalized_ratio_7_259  1
    rho_7     block_pair_pos_263  1
    rho_7     block_pair_neg_264  -1
    rho_7     block_pair_pos_271  1
    rho_7     block_pair_neg_272  -1
    rho_7     block_pair_pos_281  1
    rho_7     block_pair_neg_282  -1
    rho_7     block_pair_pos_285  1
    rho_7     block_pair_neg_286  -1
    rho_7     block_pair_pos_299  1
    rho_7     block_pair_neg_300  -1
    rho_7     block_pair_pos_305  1
    rho_7     block_pair_neg_306  -1
    rho_7     block_pair_pos_311  1
    rho_7     block_pair_neg_312  -1
    rho_7     normalization_319  1
    a_16_11   block_pair_pos_287  1
    a_16_11   block_pair_neg_288  1
    a_16_11   full_original_Gini_320  -1
    a_16_31   block_pair_pos_295  1
    a_16_31   block_pair_neg_296  1
    a_16_31   full_original_Gini_320  -1
    a_16_20   block_pair_pos_291  1
    a_16_20   block_pair_neg_292  1
    a_16_20   full_original_Gini_320  -1
    a_16_2    block_pair_pos_283  1
    a_16_2    block_pair_neg_284  1
    a_16_2    full_original_Gini_320  -1
    a_16_21   block_pair_pos_293  1
    a_16_21   block_pair_neg_294  1
    a_16_21   full_original_Gini_320  -1
    a_16_12   block_pair_pos_289  1
    a_16_12   block_pair_neg_290  1
    a_16_12   full_original_Gini_320  -1
    a_16_7    block_pair_pos_285  1
    a_16_7    block_pair_neg_286  1
    a_16_7    full_original_Gini_320  -1
    a_11_31   block_pair_pos_279  1
    a_11_31   block_pair_neg_280  1
    a_11_31   full_original_Gini_320  -1
    a_11_20   block_pair_pos_275  1
    a_11_20   block_pair_neg_276  1
    a_11_20   full_original_Gini_320  -1
    a_11_2    block_pair_pos_269  1
    a_11_2    block_pair_neg_270  1
    a_11_2    full_original_Gini_320  -1
    a_11_21   block_pair_pos_277  1
    a_11_21   block_pair_neg_278  1
    a_11_21   full_original_Gini_320  -1
    a_11_12   block_pair_pos_273  1
    a_11_12   block_pair_neg_274  1
    a_11_12   full_original_Gini_320  -1
    a_11_7    block_pair_pos_271  1
    a_11_7    block_pair_neg_272  1
    a_11_7    full_original_Gini_320  -1
    a_31_20   block_pair_pos_315  1
    a_31_20   block_pair_neg_316  1
    a_31_20   full_original_Gini_320  -1
    a_31_2    block_pair_pos_309  1
    a_31_2    block_pair_neg_310  1
    a_31_2    full_original_Gini_320  -1
    a_31_21   block_pair_pos_317  1
    a_31_21   block_pair_neg_318  1
    a_31_21   full_original_Gini_320  -1
    a_31_12   block_pair_pos_313  1
    a_31_12   block_pair_neg_314  1
    a_31_12   full_original_Gini_320  -1
    a_31_7    block_pair_pos_311  1
    a_31_7    block_pair_neg_312  1
    a_31_7    full_original_Gini_320  -1
    a_20_2    block_pair_pos_297  1
    a_20_2    block_pair_neg_298  1
    a_20_2    full_original_Gini_320  -1
    a_20_21   block_pair_pos_303  1
    a_20_21   block_pair_neg_304  1
    a_20_21   full_original_Gini_320  -1
    a_20_12   block_pair_pos_301  1
    a_20_12   block_pair_neg_302  1
    a_20_12   full_original_Gini_320  -1
    a_20_7    block_pair_pos_299  1
    a_20_7    block_pair_neg_300  1
    a_20_7    full_original_Gini_320  -1
    a_2_21    block_pair_pos_267  1
    a_2_21    block_pair_neg_268  1
    a_2_21    full_original_Gini_320  -1
    a_2_12    block_pair_pos_265  1
    a_2_12    block_pair_neg_266  1
    a_2_12    full_original_Gini_320  -1
    a_2_7     block_pair_pos_263  1
    a_2_7     block_pair_neg_264  1
    a_2_7     full_original_Gini_320  -1
    a_21_12   block_pair_pos_307  1
    a_21_12   block_pair_neg_308  1
    a_21_12   full_original_Gini_320  -1
    a_21_7    block_pair_pos_305  1
    a_21_7    block_pair_neg_306  1
    a_21_7    full_original_Gini_320  -1
    a_12_7    block_pair_pos_281  1
    a_12_7    block_pair_neg_282  1
    a_12_7    full_original_Gini_320  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_16_0  unique_nonzero_owner_321  1
    service_0_16_0  service_visit_def_811  1
    service_0_16_0  free_load_conservation_812  -1
    service_0_16_0  original_T_including_depot_unload_859  120
    service_0_16_2  unique_nonzero_owner_322  1
    service_0_16_2  service_visit_def_811  1
    service_0_16_2  free_load_conservation_812  1
    service_0_16_3  unique_nonzero_owner_323  1
    service_0_16_3  service_visit_def_811  1
    service_0_16_3  free_load_conservation_812  2
    service_0_16_4  unique_nonzero_owner_324  1
    service_0_16_4  service_visit_def_811  1
    service_0_16_4  free_load_conservation_812  3
    service_0_16_5  unique_nonzero_owner_325  1
    service_0_16_5  service_visit_def_811  1
    service_0_16_5  free_load_conservation_812  4
    service_0_16_6  unique_nonzero_owner_326  1
    service_0_16_6  service_visit_def_811  1
    service_0_16_6  free_load_conservation_812  5
    service_0_16_7  unique_nonzero_owner_327  1
    service_0_16_7  service_visit_def_811  1
    service_0_16_7  free_load_conservation_812  6
    service_0_16_8  unique_nonzero_owner_328  1
    service_0_16_8  service_visit_def_811  1
    service_0_16_8  free_load_conservation_812  7
    service_0_16_9  unique_nonzero_owner_329  1
    service_0_16_9  service_visit_def_811  1
    service_0_16_9  free_load_conservation_812  8
    service_0_16_10  unique_nonzero_owner_330  1
    service_0_16_10  service_visit_def_811  1
    service_0_16_10  free_load_conservation_812  9
    service_0_16_11  unique_nonzero_owner_331  1
    service_0_16_11  service_visit_def_811  1
    service_0_16_11  free_load_conservation_812  10
    service_0_16_12  unique_nonzero_owner_332  1
    service_0_16_12  service_visit_def_811  1
    service_0_16_12  free_load_conservation_812  11
    service_1_16_0  unique_nonzero_owner_321  1
    service_1_16_0  service_visit_def_1183  1
    service_1_16_0  free_load_conservation_1184  -1
    service_1_16_0  original_T_including_depot_unload_1230  120
    service_1_16_2  unique_nonzero_owner_322  1
    service_1_16_2  service_visit_def_1183  1
    service_1_16_2  free_load_conservation_1184  1
    service_1_16_3  unique_nonzero_owner_323  1
    service_1_16_3  service_visit_def_1183  1
    service_1_16_3  free_load_conservation_1184  2
    service_1_16_4  unique_nonzero_owner_324  1
    service_1_16_4  service_visit_def_1183  1
    service_1_16_4  free_load_conservation_1184  3
    service_1_16_5  unique_nonzero_owner_325  1
    service_1_16_5  service_visit_def_1183  1
    service_1_16_5  free_load_conservation_1184  4
    service_1_16_6  unique_nonzero_owner_326  1
    service_1_16_6  service_visit_def_1183  1
    service_1_16_6  free_load_conservation_1184  5
    service_1_16_7  unique_nonzero_owner_327  1
    service_1_16_7  service_visit_def_1183  1
    service_1_16_7  free_load_conservation_1184  6
    service_1_16_8  unique_nonzero_owner_328  1
    service_1_16_8  service_visit_def_1183  1
    service_1_16_8  free_load_conservation_1184  7
    service_1_16_9  unique_nonzero_owner_329  1
    service_1_16_9  service_visit_def_1183  1
    service_1_16_9  free_load_conservation_1184  8
    service_1_16_10  unique_nonzero_owner_330  1
    service_1_16_10  service_visit_def_1183  1
    service_1_16_10  free_load_conservation_1184  9
    service_1_16_11  unique_nonzero_owner_331  1
    service_1_16_11  service_visit_def_1183  1
    service_1_16_11  free_load_conservation_1184  10
    service_1_16_12  unique_nonzero_owner_332  1
    service_1_16_12  service_visit_def_1183  1
    service_1_16_12  free_load_conservation_1184  11
    service_2_16_0  unique_nonzero_owner_321  1
    service_2_16_0  service_visit_def_1501  1
    service_2_16_0  free_load_conservation_1502  -1
    service_2_16_0  original_T_including_depot_unload_1547  120
    service_2_16_2  unique_nonzero_owner_322  1
    service_2_16_2  service_visit_def_1501  1
    service_2_16_2  free_load_conservation_1502  1
    service_2_16_3  unique_nonzero_owner_323  1
    service_2_16_3  service_visit_def_1501  1
    service_2_16_3  free_load_conservation_1502  2
    service_2_16_4  unique_nonzero_owner_324  1
    service_2_16_4  service_visit_def_1501  1
    service_2_16_4  free_load_conservation_1502  3
    service_2_16_5  unique_nonzero_owner_325  1
    service_2_16_5  service_visit_def_1501  1
    service_2_16_5  free_load_conservation_1502  4
    service_2_16_6  unique_nonzero_owner_326  1
    service_2_16_6  service_visit_def_1501  1
    service_2_16_6  free_load_conservation_1502  5
    service_2_16_7  unique_nonzero_owner_327  1
    service_2_16_7  service_visit_def_1501  1
    service_2_16_7  free_load_conservation_1502  6
    service_2_16_8  unique_nonzero_owner_328  1
    service_2_16_8  service_visit_def_1501  1
    service_2_16_8  free_load_conservation_1502  7
    service_2_16_9  unique_nonzero_owner_329  1
    service_2_16_9  service_visit_def_1501  1
    service_2_16_9  free_load_conservation_1502  8
    service_2_16_10  unique_nonzero_owner_330  1
    service_2_16_10  service_visit_def_1501  1
    service_2_16_10  free_load_conservation_1502  9
    service_2_16_11  unique_nonzero_owner_331  1
    service_2_16_11  service_visit_def_1501  1
    service_2_16_11  free_load_conservation_1502  10
    service_2_16_12  unique_nonzero_owner_332  1
    service_2_16_12  service_visit_def_1501  1
    service_2_16_12  free_load_conservation_1502  11
    service_0_11_0  unique_nonzero_owner_333  1
    service_0_11_0  service_visit_def_817  1
    service_0_11_0  free_load_conservation_818  -7
    service_0_11_0  original_T_including_depot_unload_859  840
    service_0_11_1  unique_nonzero_owner_334  1
    service_0_11_1  service_visit_def_817  1
    service_0_11_1  free_load_conservation_818  -6
    service_0_11_1  original_T_including_depot_unload_859  720
    service_0_11_2  unique_nonzero_owner_335  1
    service_0_11_2  service_visit_def_817  1
    service_0_11_2  free_load_conservation_818  -5
    service_0_11_2  original_T_including_depot_unload_859  600
    service_0_11_3  unique_nonzero_owner_336  1
    service_0_11_3  service_visit_def_817  1
    service_0_11_3  free_load_conservation_818  -4
    service_0_11_3  original_T_including_depot_unload_859  480
    service_0_11_4  unique_nonzero_owner_337  1
    service_0_11_4  service_visit_def_817  1
    service_0_11_4  free_load_conservation_818  -3
    service_0_11_4  original_T_including_depot_unload_859  360
    service_0_11_5  unique_nonzero_owner_338  1
    service_0_11_5  service_visit_def_817  1
    service_0_11_5  free_load_conservation_818  -2
    service_0_11_5  original_T_including_depot_unload_859  240
    service_0_11_6  unique_nonzero_owner_339  1
    service_0_11_6  service_visit_def_817  1
    service_0_11_6  free_load_conservation_818  -1
    service_0_11_6  original_T_including_depot_unload_859  120
    service_0_11_8  unique_nonzero_owner_340  1
    service_0_11_8  service_visit_def_817  1
    service_0_11_8  free_load_conservation_818  1
    service_0_11_9  unique_nonzero_owner_341  1
    service_0_11_9  service_visit_def_817  1
    service_0_11_9  free_load_conservation_818  2
    service_0_11_10  unique_nonzero_owner_342  1
    service_0_11_10  service_visit_def_817  1
    service_0_11_10  free_load_conservation_818  3
    service_0_11_11  unique_nonzero_owner_343  1
    service_0_11_11  service_visit_def_817  1
    service_0_11_11  free_load_conservation_818  4
    service_0_11_12  unique_nonzero_owner_344  1
    service_0_11_12  service_visit_def_817  1
    service_0_11_12  free_load_conservation_818  5
    service_1_11_0  unique_nonzero_owner_333  1
    service_1_11_0  service_visit_def_1189  1
    service_1_11_0  free_load_conservation_1190  -7
    service_1_11_0  original_T_including_depot_unload_1230  840
    service_1_11_1  unique_nonzero_owner_334  1
    service_1_11_1  service_visit_def_1189  1
    service_1_11_1  free_load_conservation_1190  -6
    service_1_11_1  original_T_including_depot_unload_1230  720
    service_1_11_2  unique_nonzero_owner_335  1
    service_1_11_2  service_visit_def_1189  1
    service_1_11_2  free_load_conservation_1190  -5
    service_1_11_2  original_T_including_depot_unload_1230  600
    service_1_11_3  unique_nonzero_owner_336  1
    service_1_11_3  service_visit_def_1189  1
    service_1_11_3  free_load_conservation_1190  -4
    service_1_11_3  original_T_including_depot_unload_1230  480
    service_1_11_4  unique_nonzero_owner_337  1
    service_1_11_4  service_visit_def_1189  1
    service_1_11_4  free_load_conservation_1190  -3
    service_1_11_4  original_T_including_depot_unload_1230  360
    service_1_11_5  unique_nonzero_owner_338  1
    service_1_11_5  service_visit_def_1189  1
    service_1_11_5  free_load_conservation_1190  -2
    service_1_11_5  original_T_including_depot_unload_1230  240
    service_1_11_6  unique_nonzero_owner_339  1
    service_1_11_6  service_visit_def_1189  1
    service_1_11_6  free_load_conservation_1190  -1
    service_1_11_6  original_T_including_depot_unload_1230  120
    service_1_11_8  unique_nonzero_owner_340  1
    service_1_11_8  service_visit_def_1189  1
    service_1_11_8  free_load_conservation_1190  1
    service_1_11_9  unique_nonzero_owner_341  1
    service_1_11_9  service_visit_def_1189  1
    service_1_11_9  free_load_conservation_1190  2
    service_1_11_10  unique_nonzero_owner_342  1
    service_1_11_10  service_visit_def_1189  1
    service_1_11_10  free_load_conservation_1190  3
    service_1_11_11  unique_nonzero_owner_343  1
    service_1_11_11  service_visit_def_1189  1
    service_1_11_11  free_load_conservation_1190  4
    service_1_11_12  unique_nonzero_owner_344  1
    service_1_11_12  service_visit_def_1189  1
    service_1_11_12  free_load_conservation_1190  5
    service_2_11_0  unique_nonzero_owner_333  1
    service_2_11_0  service_visit_def_1507  1
    service_2_11_0  free_load_conservation_1508  -7
    service_2_11_0  original_T_including_depot_unload_1547  840
    service_2_11_1  unique_nonzero_owner_334  1
    service_2_11_1  service_visit_def_1507  1
    service_2_11_1  free_load_conservation_1508  -6
    service_2_11_1  original_T_including_depot_unload_1547  720
    service_2_11_2  unique_nonzero_owner_335  1
    service_2_11_2  service_visit_def_1507  1
    service_2_11_2  free_load_conservation_1508  -5
    service_2_11_2  original_T_including_depot_unload_1547  600
    service_2_11_3  unique_nonzero_owner_336  1
    service_2_11_3  service_visit_def_1507  1
    service_2_11_3  free_load_conservation_1508  -4
    service_2_11_3  original_T_including_depot_unload_1547  480
    service_2_11_4  unique_nonzero_owner_337  1
    service_2_11_4  service_visit_def_1507  1
    service_2_11_4  free_load_conservation_1508  -3
    service_2_11_4  original_T_including_depot_unload_1547  360
    service_2_11_5  unique_nonzero_owner_338  1
    service_2_11_5  service_visit_def_1507  1
    service_2_11_5  free_load_conservation_1508  -2
    service_2_11_5  original_T_including_depot_unload_1547  240
    service_2_11_6  unique_nonzero_owner_339  1
    service_2_11_6  service_visit_def_1507  1
    service_2_11_6  free_load_conservation_1508  -1
    service_2_11_6  original_T_including_depot_unload_1547  120
    service_2_11_8  unique_nonzero_owner_340  1
    service_2_11_8  service_visit_def_1507  1
    service_2_11_8  free_load_conservation_1508  1
    service_2_11_9  unique_nonzero_owner_341  1
    service_2_11_9  service_visit_def_1507  1
    service_2_11_9  free_load_conservation_1508  2
    service_2_11_10  unique_nonzero_owner_342  1
    service_2_11_10  service_visit_def_1507  1
    service_2_11_10  free_load_conservation_1508  3
    service_2_11_11  unique_nonzero_owner_343  1
    service_2_11_11  service_visit_def_1507  1
    service_2_11_11  free_load_conservation_1508  4
    service_2_11_12  unique_nonzero_owner_344  1
    service_2_11_12  service_visit_def_1507  1
    service_2_11_12  free_load_conservation_1508  5
    service_0_31_0  unique_nonzero_owner_345  1
    service_0_31_0  service_visit_def_823  1
    service_0_31_0  free_load_conservation_824  -2
    service_0_31_0  original_T_including_depot_unload_859  240
    service_0_31_1  unique_nonzero_owner_346  1
    service_0_31_1  service_visit_def_823  1
    service_0_31_1  free_load_conservation_824  -1
    service_0_31_1  original_T_including_depot_unload_859  120
    service_0_31_3  unique_nonzero_owner_347  1
    service_0_31_3  service_visit_def_823  1
    service_0_31_3  free_load_conservation_824  1
    service_0_31_4  unique_nonzero_owner_348  1
    service_0_31_4  service_visit_def_823  1
    service_0_31_4  free_load_conservation_824  2
    service_0_31_5  unique_nonzero_owner_349  1
    service_0_31_5  service_visit_def_823  1
    service_0_31_5  free_load_conservation_824  3
    service_0_31_6  unique_nonzero_owner_350  1
    service_0_31_6  service_visit_def_823  1
    service_0_31_6  free_load_conservation_824  4
    service_0_31_7  unique_nonzero_owner_351  1
    service_0_31_7  service_visit_def_823  1
    service_0_31_7  free_load_conservation_824  5
    service_0_31_8  unique_nonzero_owner_352  1
    service_0_31_8  service_visit_def_823  1
    service_0_31_8  free_load_conservation_824  6
    service_0_31_9  unique_nonzero_owner_353  1
    service_0_31_9  service_visit_def_823  1
    service_0_31_9  free_load_conservation_824  7
    service_0_31_10  unique_nonzero_owner_354  1
    service_0_31_10  service_visit_def_823  1
    service_0_31_10  free_load_conservation_824  8
    service_0_31_11  unique_nonzero_owner_355  1
    service_0_31_11  service_visit_def_823  1
    service_0_31_11  free_load_conservation_824  9
    service_0_31_12  unique_nonzero_owner_356  1
    service_0_31_12  service_visit_def_823  1
    service_0_31_12  free_load_conservation_824  10
    service_1_31_0  unique_nonzero_owner_345  1
    service_1_31_0  service_visit_def_1195  1
    service_1_31_0  free_load_conservation_1196  -2
    service_1_31_0  original_T_including_depot_unload_1230  240
    service_1_31_1  unique_nonzero_owner_346  1
    service_1_31_1  service_visit_def_1195  1
    service_1_31_1  free_load_conservation_1196  -1
    service_1_31_1  original_T_including_depot_unload_1230  120
    service_1_31_3  unique_nonzero_owner_347  1
    service_1_31_3  service_visit_def_1195  1
    service_1_31_3  free_load_conservation_1196  1
    service_1_31_4  unique_nonzero_owner_348  1
    service_1_31_4  service_visit_def_1195  1
    service_1_31_4  free_load_conservation_1196  2
    service_1_31_5  unique_nonzero_owner_349  1
    service_1_31_5  service_visit_def_1195  1
    service_1_31_5  free_load_conservation_1196  3
    service_1_31_6  unique_nonzero_owner_350  1
    service_1_31_6  service_visit_def_1195  1
    service_1_31_6  free_load_conservation_1196  4
    service_1_31_7  unique_nonzero_owner_351  1
    service_1_31_7  service_visit_def_1195  1
    service_1_31_7  free_load_conservation_1196  5
    service_1_31_8  unique_nonzero_owner_352  1
    service_1_31_8  service_visit_def_1195  1
    service_1_31_8  free_load_conservation_1196  6
    service_1_31_9  unique_nonzero_owner_353  1
    service_1_31_9  service_visit_def_1195  1
    service_1_31_9  free_load_conservation_1196  7
    service_1_31_10  unique_nonzero_owner_354  1
    service_1_31_10  service_visit_def_1195  1
    service_1_31_10  free_load_conservation_1196  8
    service_1_31_11  unique_nonzero_owner_355  1
    service_1_31_11  service_visit_def_1195  1
    service_1_31_11  free_load_conservation_1196  9
    service_1_31_12  unique_nonzero_owner_356  1
    service_1_31_12  service_visit_def_1195  1
    service_1_31_12  free_load_conservation_1196  10
    service_2_31_0  unique_nonzero_owner_345  1
    service_2_31_0  service_visit_def_1513  1
    service_2_31_0  free_load_conservation_1514  -2
    service_2_31_0  original_T_including_depot_unload_1547  240
    service_2_31_1  unique_nonzero_owner_346  1
    service_2_31_1  service_visit_def_1513  1
    service_2_31_1  free_load_conservation_1514  -1
    service_2_31_1  original_T_including_depot_unload_1547  120
    service_2_31_3  unique_nonzero_owner_347  1
    service_2_31_3  service_visit_def_1513  1
    service_2_31_3  free_load_conservation_1514  1
    service_2_31_4  unique_nonzero_owner_348  1
    service_2_31_4  service_visit_def_1513  1
    service_2_31_4  free_load_conservation_1514  2
    service_2_31_5  unique_nonzero_owner_349  1
    service_2_31_5  service_visit_def_1513  1
    service_2_31_5  free_load_conservation_1514  3
    service_2_31_6  unique_nonzero_owner_350  1
    service_2_31_6  service_visit_def_1513  1
    service_2_31_6  free_load_conservation_1514  4
    service_2_31_7  unique_nonzero_owner_351  1
    service_2_31_7  service_visit_def_1513  1
    service_2_31_7  free_load_conservation_1514  5
    service_2_31_8  unique_nonzero_owner_352  1
    service_2_31_8  service_visit_def_1513  1
    service_2_31_8  free_load_conservation_1514  6
    service_2_31_9  unique_nonzero_owner_353  1
    service_2_31_9  service_visit_def_1513  1
    service_2_31_9  free_load_conservation_1514  7
    service_2_31_10  unique_nonzero_owner_354  1
    service_2_31_10  service_visit_def_1513  1
    service_2_31_10  free_load_conservation_1514  8
    service_2_31_11  unique_nonzero_owner_355  1
    service_2_31_11  service_visit_def_1513  1
    service_2_31_11  free_load_conservation_1514  9
    service_2_31_12  unique_nonzero_owner_356  1
    service_2_31_12  service_visit_def_1513  1
    service_2_31_12  free_load_conservation_1514  10
    service_0_20_0  unique_nonzero_owner_357  1
    service_0_20_0  service_visit_def_829  1
    service_0_20_0  free_load_conservation_830  -9
    service_0_20_0  original_T_including_depot_unload_859  1080
    service_0_20_1  unique_nonzero_owner_358  1
    service_0_20_1  service_visit_def_829  1
    service_0_20_1  free_load_conservation_830  -8
    service_0_20_1  original_T_including_depot_unload_859  960
    service_0_20_2  unique_nonzero_owner_359  1
    service_0_20_2  service_visit_def_829  1
    service_0_20_2  free_load_conservation_830  -7
    service_0_20_2  original_T_including_depot_unload_859  840
    service_0_20_3  unique_nonzero_owner_360  1
    service_0_20_3  service_visit_def_829  1
    service_0_20_3  free_load_conservation_830  -6
    service_0_20_3  original_T_including_depot_unload_859  720
    service_0_20_4  unique_nonzero_owner_361  1
    service_0_20_4  service_visit_def_829  1
    service_0_20_4  free_load_conservation_830  -5
    service_0_20_4  original_T_including_depot_unload_859  600
    service_0_20_5  unique_nonzero_owner_362  1
    service_0_20_5  service_visit_def_829  1
    service_0_20_5  free_load_conservation_830  -4
    service_0_20_5  original_T_including_depot_unload_859  480
    service_0_20_6  unique_nonzero_owner_363  1
    service_0_20_6  service_visit_def_829  1
    service_0_20_6  free_load_conservation_830  -3
    service_0_20_6  original_T_including_depot_unload_859  360
    service_0_20_7  unique_nonzero_owner_364  1
    service_0_20_7  service_visit_def_829  1
    service_0_20_7  free_load_conservation_830  -2
    service_0_20_7  original_T_including_depot_unload_859  240
    service_0_20_8  unique_nonzero_owner_365  1
    service_0_20_8  service_visit_def_829  1
    service_0_20_8  free_load_conservation_830  -1
    service_0_20_8  original_T_including_depot_unload_859  120
    service_0_20_10  unique_nonzero_owner_366  1
    service_0_20_10  service_visit_def_829  1
    service_0_20_10  free_load_conservation_830  1
    service_0_20_11  unique_nonzero_owner_367  1
    service_0_20_11  service_visit_def_829  1
    service_0_20_11  free_load_conservation_830  2
    service_0_20_12  unique_nonzero_owner_368  1
    service_0_20_12  service_visit_def_829  1
    service_0_20_12  free_load_conservation_830  3
    service_1_20_0  unique_nonzero_owner_357  1
    service_1_20_0  service_visit_def_1201  1
    service_1_20_0  free_load_conservation_1202  -9
    service_1_20_0  original_T_including_depot_unload_1230  1080
    service_1_20_1  unique_nonzero_owner_358  1
    service_1_20_1  service_visit_def_1201  1
    service_1_20_1  free_load_conservation_1202  -8
    service_1_20_1  original_T_including_depot_unload_1230  960
    service_1_20_2  unique_nonzero_owner_359  1
    service_1_20_2  service_visit_def_1201  1
    service_1_20_2  free_load_conservation_1202  -7
    service_1_20_2  original_T_including_depot_unload_1230  840
    service_1_20_3  unique_nonzero_owner_360  1
    service_1_20_3  service_visit_def_1201  1
    service_1_20_3  free_load_conservation_1202  -6
    service_1_20_3  original_T_including_depot_unload_1230  720
    service_1_20_4  unique_nonzero_owner_361  1
    service_1_20_4  service_visit_def_1201  1
    service_1_20_4  free_load_conservation_1202  -5
    service_1_20_4  original_T_including_depot_unload_1230  600
    service_1_20_5  unique_nonzero_owner_362  1
    service_1_20_5  service_visit_def_1201  1
    service_1_20_5  free_load_conservation_1202  -4
    service_1_20_5  original_T_including_depot_unload_1230  480
    service_1_20_6  unique_nonzero_owner_363  1
    service_1_20_6  service_visit_def_1201  1
    service_1_20_6  free_load_conservation_1202  -3
    service_1_20_6  original_T_including_depot_unload_1230  360
    service_1_20_7  unique_nonzero_owner_364  1
    service_1_20_7  service_visit_def_1201  1
    service_1_20_7  free_load_conservation_1202  -2
    service_1_20_7  original_T_including_depot_unload_1230  240
    service_1_20_8  unique_nonzero_owner_365  1
    service_1_20_8  service_visit_def_1201  1
    service_1_20_8  free_load_conservation_1202  -1
    service_1_20_8  original_T_including_depot_unload_1230  120
    service_1_20_10  unique_nonzero_owner_366  1
    service_1_20_10  service_visit_def_1201  1
    service_1_20_10  free_load_conservation_1202  1
    service_1_20_11  unique_nonzero_owner_367  1
    service_1_20_11  service_visit_def_1201  1
    service_1_20_11  free_load_conservation_1202  2
    service_1_20_12  unique_nonzero_owner_368  1
    service_1_20_12  service_visit_def_1201  1
    service_1_20_12  free_load_conservation_1202  3
    service_2_20_0  unique_nonzero_owner_357  1
    service_2_20_0  service_visit_def_1519  1
    service_2_20_0  free_load_conservation_1520  -9
    service_2_20_0  original_T_including_depot_unload_1547  1080
    service_2_20_1  unique_nonzero_owner_358  1
    service_2_20_1  service_visit_def_1519  1
    service_2_20_1  free_load_conservation_1520  -8
    service_2_20_1  original_T_including_depot_unload_1547  960
    service_2_20_2  unique_nonzero_owner_359  1
    service_2_20_2  service_visit_def_1519  1
    service_2_20_2  free_load_conservation_1520  -7
    service_2_20_2  original_T_including_depot_unload_1547  840
    service_2_20_3  unique_nonzero_owner_360  1
    service_2_20_3  service_visit_def_1519  1
    service_2_20_3  free_load_conservation_1520  -6
    service_2_20_3  original_T_including_depot_unload_1547  720
    service_2_20_4  unique_nonzero_owner_361  1
    service_2_20_4  service_visit_def_1519  1
    service_2_20_4  free_load_conservation_1520  -5
    service_2_20_4  original_T_including_depot_unload_1547  600
    service_2_20_5  unique_nonzero_owner_362  1
    service_2_20_5  service_visit_def_1519  1
    service_2_20_5  free_load_conservation_1520  -4
    service_2_20_5  original_T_including_depot_unload_1547  480
    service_2_20_6  unique_nonzero_owner_363  1
    service_2_20_6  service_visit_def_1519  1
    service_2_20_6  free_load_conservation_1520  -3
    service_2_20_6  original_T_including_depot_unload_1547  360
    service_2_20_7  unique_nonzero_owner_364  1
    service_2_20_7  service_visit_def_1519  1
    service_2_20_7  free_load_conservation_1520  -2
    service_2_20_7  original_T_including_depot_unload_1547  240
    service_2_20_8  unique_nonzero_owner_365  1
    service_2_20_8  service_visit_def_1519  1
    service_2_20_8  free_load_conservation_1520  -1
    service_2_20_8  original_T_including_depot_unload_1547  120
    service_2_20_10  unique_nonzero_owner_366  1
    service_2_20_10  service_visit_def_1519  1
    service_2_20_10  free_load_conservation_1520  1
    service_2_20_11  unique_nonzero_owner_367  1
    service_2_20_11  service_visit_def_1519  1
    service_2_20_11  free_load_conservation_1520  2
    service_2_20_12  unique_nonzero_owner_368  1
    service_2_20_12  service_visit_def_1519  1
    service_2_20_12  free_load_conservation_1520  3
    service_0_2_1  unique_nonzero_owner_369  1
    service_0_2_1  service_visit_def_835  1
    service_0_2_1  free_load_conservation_836  1
    service_0_2_2  unique_nonzero_owner_370  1
    service_0_2_2  service_visit_def_835  1
    service_0_2_2  free_load_conservation_836  2
    service_0_2_3  unique_nonzero_owner_371  1
    service_0_2_3  service_visit_def_835  1
    service_0_2_3  free_load_conservation_836  3
    service_0_2_4  unique_nonzero_owner_372  1
    service_0_2_4  service_visit_def_835  1
    service_0_2_4  free_load_conservation_836  4
    service_0_2_5  unique_nonzero_owner_373  1
    service_0_2_5  service_visit_def_835  1
    service_0_2_5  free_load_conservation_836  5
    service_0_2_6  unique_nonzero_owner_374  1
    service_0_2_6  service_visit_def_835  1
    service_0_2_6  free_load_conservation_836  6
    service_0_2_7  unique_nonzero_owner_375  1
    service_0_2_7  service_visit_def_835  1
    service_0_2_7  free_load_conservation_836  7
    service_0_2_8  unique_nonzero_owner_376  1
    service_0_2_8  service_visit_def_835  1
    service_0_2_8  free_load_conservation_836  8
    service_0_2_9  unique_nonzero_owner_377  1
    service_0_2_9  service_visit_def_835  1
    service_0_2_9  free_load_conservation_836  9
    service_0_2_10  unique_nonzero_owner_378  1
    service_0_2_10  service_visit_def_835  1
    service_0_2_10  free_load_conservation_836  10
    service_0_2_11  unique_nonzero_owner_379  1
    service_0_2_11  service_visit_def_835  1
    service_0_2_11  free_load_conservation_836  11
    service_0_2_12  unique_nonzero_owner_380  1
    service_0_2_12  service_visit_def_835  1
    service_0_2_12  free_load_conservation_836  12
    service_0_2_13  unique_nonzero_owner_381  1
    service_0_2_13  service_visit_def_835  1
    service_0_2_13  free_load_conservation_836  13
    service_0_2_14  unique_nonzero_owner_382  1
    service_0_2_14  service_visit_def_835  1
    service_0_2_14  free_load_conservation_836  14
    service_0_2_15  unique_nonzero_owner_383  1
    service_0_2_15  service_visit_def_835  1
    service_0_2_15  free_load_conservation_836  15
    service_1_2_1  unique_nonzero_owner_369  1
    service_1_2_1  service_visit_def_1207  1
    service_1_2_1  free_load_conservation_1208  1
    service_1_2_2  unique_nonzero_owner_370  1
    service_1_2_2  service_visit_def_1207  1
    service_1_2_2  free_load_conservation_1208  2
    service_1_2_3  unique_nonzero_owner_371  1
    service_1_2_3  service_visit_def_1207  1
    service_1_2_3  free_load_conservation_1208  3
    service_1_2_4  unique_nonzero_owner_372  1
    service_1_2_4  service_visit_def_1207  1
    service_1_2_4  free_load_conservation_1208  4
    service_1_2_5  unique_nonzero_owner_373  1
    service_1_2_5  service_visit_def_1207  1
    service_1_2_5  free_load_conservation_1208  5
    service_1_2_6  unique_nonzero_owner_374  1
    service_1_2_6  service_visit_def_1207  1
    service_1_2_6  free_load_conservation_1208  6
    service_1_2_7  unique_nonzero_owner_375  1
    service_1_2_7  service_visit_def_1207  1
    service_1_2_7  free_load_conservation_1208  7
    service_1_2_8  unique_nonzero_owner_376  1
    service_1_2_8  service_visit_def_1207  1
    service_1_2_8  free_load_conservation_1208  8
    service_1_2_9  unique_nonzero_owner_377  1
    service_1_2_9  service_visit_def_1207  1
    service_1_2_9  free_load_conservation_1208  9
    service_1_2_10  unique_nonzero_owner_378  1
    service_1_2_10  service_visit_def_1207  1
    service_1_2_10  free_load_conservation_1208  10
    service_1_2_11  unique_nonzero_owner_379  1
    service_1_2_11  service_visit_def_1207  1
    service_1_2_11  free_load_conservation_1208  11
    service_1_2_12  unique_nonzero_owner_380  1
    service_1_2_12  service_visit_def_1207  1
    service_1_2_12  free_load_conservation_1208  12
    service_1_2_13  unique_nonzero_owner_381  1
    service_1_2_13  service_visit_def_1207  1
    service_1_2_13  free_load_conservation_1208  13
    service_1_2_14  unique_nonzero_owner_382  1
    service_1_2_14  service_visit_def_1207  1
    service_1_2_14  free_load_conservation_1208  14
    service_1_2_15  unique_nonzero_owner_383  1
    service_1_2_15  service_visit_def_1207  1
    service_1_2_15  free_load_conservation_1208  15
    service_2_2_1  unique_nonzero_owner_369  1
    service_2_2_1  service_visit_def_1525  1
    service_2_2_1  free_load_conservation_1526  1
    service_2_2_2  unique_nonzero_owner_370  1
    service_2_2_2  service_visit_def_1525  1
    service_2_2_2  free_load_conservation_1526  2
    service_2_2_3  unique_nonzero_owner_371  1
    service_2_2_3  service_visit_def_1525  1
    service_2_2_3  free_load_conservation_1526  3
    service_2_2_4  unique_nonzero_owner_372  1
    service_2_2_4  service_visit_def_1525  1
    service_2_2_4  free_load_conservation_1526  4
    service_2_2_5  unique_nonzero_owner_373  1
    service_2_2_5  service_visit_def_1525  1
    service_2_2_5  free_load_conservation_1526  5
    service_2_2_6  unique_nonzero_owner_374  1
    service_2_2_6  service_visit_def_1525  1
    service_2_2_6  free_load_conservation_1526  6
    service_2_2_7  unique_nonzero_owner_375  1
    service_2_2_7  service_visit_def_1525  1
    service_2_2_7  free_load_conservation_1526  7
    service_2_2_8  unique_nonzero_owner_376  1
    service_2_2_8  service_visit_def_1525  1
    service_2_2_8  free_load_conservation_1526  8
    service_2_2_9  unique_nonzero_owner_377  1
    service_2_2_9  service_visit_def_1525  1
    service_2_2_9  free_load_conservation_1526  9
    service_2_2_10  unique_nonzero_owner_378  1
    service_2_2_10  service_visit_def_1525  1
    service_2_2_10  free_load_conservation_1526  10
    service_2_2_11  unique_nonzero_owner_379  1
    service_2_2_11  service_visit_def_1525  1
    service_2_2_11  free_load_conservation_1526  11
    service_2_2_12  unique_nonzero_owner_380  1
    service_2_2_12  service_visit_def_1525  1
    service_2_2_12  free_load_conservation_1526  12
    service_2_2_13  unique_nonzero_owner_381  1
    service_2_2_13  service_visit_def_1525  1
    service_2_2_13  free_load_conservation_1526  13
    service_2_2_14  unique_nonzero_owner_382  1
    service_2_2_14  service_visit_def_1525  1
    service_2_2_14  free_load_conservation_1526  14
    service_2_2_15  unique_nonzero_owner_383  1
    service_2_2_15  service_visit_def_1525  1
    service_2_2_15  free_load_conservation_1526  15
    service_0_21_0  unique_nonzero_owner_384  1
    service_0_21_0  service_visit_def_841  1
    service_0_21_0  free_load_conservation_842  -1
    service_0_21_0  original_T_including_depot_unload_859  120
    service_0_21_2  unique_nonzero_owner_385  1
    service_0_21_2  service_visit_def_841  1
    service_0_21_2  free_load_conservation_842  1
    service_0_21_3  unique_nonzero_owner_386  1
    service_0_21_3  service_visit_def_841  1
    service_0_21_3  free_load_conservation_842  2
    service_0_21_4  unique_nonzero_owner_387  1
    service_0_21_4  service_visit_def_841  1
    service_0_21_4  free_load_conservation_842  3
    service_0_21_5  unique_nonzero_owner_388  1
    service_0_21_5  service_visit_def_841  1
    service_0_21_5  free_load_conservation_842  4
    service_0_21_6  unique_nonzero_owner_389  1
    service_0_21_6  service_visit_def_841  1
    service_0_21_6  free_load_conservation_842  5
    service_0_21_7  unique_nonzero_owner_390  1
    service_0_21_7  service_visit_def_841  1
    service_0_21_7  free_load_conservation_842  6
    service_0_21_8  unique_nonzero_owner_391  1
    service_0_21_8  service_visit_def_841  1
    service_0_21_8  free_load_conservation_842  7
    service_0_21_9  unique_nonzero_owner_392  1
    service_0_21_9  service_visit_def_841  1
    service_0_21_9  free_load_conservation_842  8
    service_0_21_10  unique_nonzero_owner_393  1
    service_0_21_10  service_visit_def_841  1
    service_0_21_10  free_load_conservation_842  9
    service_0_21_11  unique_nonzero_owner_394  1
    service_0_21_11  service_visit_def_841  1
    service_0_21_11  free_load_conservation_842  10
    service_0_21_12  unique_nonzero_owner_395  1
    service_0_21_12  service_visit_def_841  1
    service_0_21_12  free_load_conservation_842  11
    service_0_21_13  unique_nonzero_owner_396  1
    service_0_21_13  service_visit_def_841  1
    service_0_21_13  free_load_conservation_842  12
    service_0_21_14  unique_nonzero_owner_397  1
    service_0_21_14  service_visit_def_841  1
    service_0_21_14  free_load_conservation_842  13
    service_0_21_15  unique_nonzero_owner_398  1
    service_0_21_15  service_visit_def_841  1
    service_0_21_15  free_load_conservation_842  14
    service_1_21_0  unique_nonzero_owner_384  1
    service_1_21_0  service_visit_def_1213  1
    service_1_21_0  free_load_conservation_1214  -1
    service_1_21_0  original_T_including_depot_unload_1230  120
    service_1_21_2  unique_nonzero_owner_385  1
    service_1_21_2  service_visit_def_1213  1
    service_1_21_2  free_load_conservation_1214  1
    service_1_21_3  unique_nonzero_owner_386  1
    service_1_21_3  service_visit_def_1213  1
    service_1_21_3  free_load_conservation_1214  2
    service_1_21_4  unique_nonzero_owner_387  1
    service_1_21_4  service_visit_def_1213  1
    service_1_21_4  free_load_conservation_1214  3
    service_1_21_5  unique_nonzero_owner_388  1
    service_1_21_5  service_visit_def_1213  1
    service_1_21_5  free_load_conservation_1214  4
    service_1_21_6  unique_nonzero_owner_389  1
    service_1_21_6  service_visit_def_1213  1
    service_1_21_6  free_load_conservation_1214  5
    service_1_21_7  unique_nonzero_owner_390  1
    service_1_21_7  service_visit_def_1213  1
    service_1_21_7  free_load_conservation_1214  6
    service_1_21_8  unique_nonzero_owner_391  1
    service_1_21_8  service_visit_def_1213  1
    service_1_21_8  free_load_conservation_1214  7
    service_1_21_9  unique_nonzero_owner_392  1
    service_1_21_9  service_visit_def_1213  1
    service_1_21_9  free_load_conservation_1214  8
    service_1_21_10  unique_nonzero_owner_393  1
    service_1_21_10  service_visit_def_1213  1
    service_1_21_10  free_load_conservation_1214  9
    service_1_21_11  unique_nonzero_owner_394  1
    service_1_21_11  service_visit_def_1213  1
    service_1_21_11  free_load_conservation_1214  10
    service_1_21_12  unique_nonzero_owner_395  1
    service_1_21_12  service_visit_def_1213  1
    service_1_21_12  free_load_conservation_1214  11
    service_1_21_13  unique_nonzero_owner_396  1
    service_1_21_13  service_visit_def_1213  1
    service_1_21_13  free_load_conservation_1214  12
    service_1_21_14  unique_nonzero_owner_397  1
    service_1_21_14  service_visit_def_1213  1
    service_1_21_14  free_load_conservation_1214  13
    service_1_21_15  unique_nonzero_owner_398  1
    service_1_21_15  service_visit_def_1213  1
    service_1_21_15  free_load_conservation_1214  14
    service_2_21_0  unique_nonzero_owner_384  1
    service_2_21_0  service_visit_def_1531  1
    service_2_21_0  free_load_conservation_1532  -1
    service_2_21_0  original_T_including_depot_unload_1547  120
    service_2_21_2  unique_nonzero_owner_385  1
    service_2_21_2  service_visit_def_1531  1
    service_2_21_2  free_load_conservation_1532  1
    service_2_21_3  unique_nonzero_owner_386  1
    service_2_21_3  service_visit_def_1531  1
    service_2_21_3  free_load_conservation_1532  2
    service_2_21_4  unique_nonzero_owner_387  1
    service_2_21_4  service_visit_def_1531  1
    service_2_21_4  free_load_conservation_1532  3
    service_2_21_5  unique_nonzero_owner_388  1
    service_2_21_5  service_visit_def_1531  1
    service_2_21_5  free_load_conservation_1532  4
    service_2_21_6  unique_nonzero_owner_389  1
    service_2_21_6  service_visit_def_1531  1
    service_2_21_6  free_load_conservation_1532  5
    service_2_21_7  unique_nonzero_owner_390  1
    service_2_21_7  service_visit_def_1531  1
    service_2_21_7  free_load_conservation_1532  6
    service_2_21_8  unique_nonzero_owner_391  1
    service_2_21_8  service_visit_def_1531  1
    service_2_21_8  free_load_conservation_1532  7
    service_2_21_9  unique_nonzero_owner_392  1
    service_2_21_9  service_visit_def_1531  1
    service_2_21_9  free_load_conservation_1532  8
    service_2_21_10  unique_nonzero_owner_393  1
    service_2_21_10  service_visit_def_1531  1
    service_2_21_10  free_load_conservation_1532  9
    service_2_21_11  unique_nonzero_owner_394  1
    service_2_21_11  service_visit_def_1531  1
    service_2_21_11  free_load_conservation_1532  10
    service_2_21_12  unique_nonzero_owner_395  1
    service_2_21_12  service_visit_def_1531  1
    service_2_21_12  free_load_conservation_1532  11
    service_2_21_13  unique_nonzero_owner_396  1
    service_2_21_13  service_visit_def_1531  1
    service_2_21_13  free_load_conservation_1532  12
    service_2_21_14  unique_nonzero_owner_397  1
    service_2_21_14  service_visit_def_1531  1
    service_2_21_14  free_load_conservation_1532  13
    service_2_21_15  unique_nonzero_owner_398  1
    service_2_21_15  service_visit_def_1531  1
    service_2_21_15  free_load_conservation_1532  14
    service_0_12_1  unique_nonzero_owner_399  1
    service_0_12_1  service_visit_def_847  1
    service_0_12_1  free_load_conservation_848  1
    service_0_12_2  unique_nonzero_owner_400  1
    service_0_12_2  service_visit_def_847  1
    service_0_12_2  free_load_conservation_848  2
    service_0_12_3  unique_nonzero_owner_401  1
    service_0_12_3  service_visit_def_847  1
    service_0_12_3  free_load_conservation_848  3
    service_0_12_4  unique_nonzero_owner_402  1
    service_0_12_4  service_visit_def_847  1
    service_0_12_4  free_load_conservation_848  4
    service_0_12_5  unique_nonzero_owner_403  1
    service_0_12_5  service_visit_def_847  1
    service_0_12_5  free_load_conservation_848  5
    service_0_12_6  unique_nonzero_owner_404  1
    service_0_12_6  service_visit_def_847  1
    service_0_12_6  free_load_conservation_848  6
    service_0_12_7  unique_nonzero_owner_405  1
    service_0_12_7  service_visit_def_847  1
    service_0_12_7  free_load_conservation_848  7
    service_0_12_8  unique_nonzero_owner_406  1
    service_0_12_8  service_visit_def_847  1
    service_0_12_8  free_load_conservation_848  8
    service_0_12_9  unique_nonzero_owner_407  1
    service_0_12_9  service_visit_def_847  1
    service_0_12_9  free_load_conservation_848  9
    service_0_12_10  unique_nonzero_owner_408  1
    service_0_12_10  service_visit_def_847  1
    service_0_12_10  free_load_conservation_848  10
    service_0_12_11  unique_nonzero_owner_409  1
    service_0_12_11  service_visit_def_847  1
    service_0_12_11  free_load_conservation_848  11
    service_0_12_12  unique_nonzero_owner_410  1
    service_0_12_12  service_visit_def_847  1
    service_0_12_12  free_load_conservation_848  12
    service_0_12_13  unique_nonzero_owner_411  1
    service_0_12_13  service_visit_def_847  1
    service_0_12_13  free_load_conservation_848  13
    service_0_12_14  unique_nonzero_owner_412  1
    service_0_12_14  service_visit_def_847  1
    service_0_12_14  free_load_conservation_848  14
    service_0_12_15  unique_nonzero_owner_413  1
    service_0_12_15  service_visit_def_847  1
    service_0_12_15  free_load_conservation_848  15
    service_1_12_1  unique_nonzero_owner_399  1
    service_1_12_1  service_visit_def_1219  1
    service_1_12_1  free_load_conservation_1220  1
    service_1_12_2  unique_nonzero_owner_400  1
    service_1_12_2  service_visit_def_1219  1
    service_1_12_2  free_load_conservation_1220  2
    service_1_12_3  unique_nonzero_owner_401  1
    service_1_12_3  service_visit_def_1219  1
    service_1_12_3  free_load_conservation_1220  3
    service_1_12_4  unique_nonzero_owner_402  1
    service_1_12_4  service_visit_def_1219  1
    service_1_12_4  free_load_conservation_1220  4
    service_1_12_5  unique_nonzero_owner_403  1
    service_1_12_5  service_visit_def_1219  1
    service_1_12_5  free_load_conservation_1220  5
    service_1_12_6  unique_nonzero_owner_404  1
    service_1_12_6  service_visit_def_1219  1
    service_1_12_6  free_load_conservation_1220  6
    service_1_12_7  unique_nonzero_owner_405  1
    service_1_12_7  service_visit_def_1219  1
    service_1_12_7  free_load_conservation_1220  7
    service_1_12_8  unique_nonzero_owner_406  1
    service_1_12_8  service_visit_def_1219  1
    service_1_12_8  free_load_conservation_1220  8
    service_1_12_9  unique_nonzero_owner_407  1
    service_1_12_9  service_visit_def_1219  1
    service_1_12_9  free_load_conservation_1220  9
    service_1_12_10  unique_nonzero_owner_408  1
    service_1_12_10  service_visit_def_1219  1
    service_1_12_10  free_load_conservation_1220  10
    service_1_12_11  unique_nonzero_owner_409  1
    service_1_12_11  service_visit_def_1219  1
    service_1_12_11  free_load_conservation_1220  11
    service_1_12_12  unique_nonzero_owner_410  1
    service_1_12_12  service_visit_def_1219  1
    service_1_12_12  free_load_conservation_1220  12
    service_1_12_13  unique_nonzero_owner_411  1
    service_1_12_13  service_visit_def_1219  1
    service_1_12_13  free_load_conservation_1220  13
    service_1_12_14  unique_nonzero_owner_412  1
    service_1_12_14  service_visit_def_1219  1
    service_1_12_14  free_load_conservation_1220  14
    service_1_12_15  unique_nonzero_owner_413  1
    service_1_12_15  service_visit_def_1219  1
    service_1_12_15  free_load_conservation_1220  15
    service_2_12_1  unique_nonzero_owner_399  1
    service_2_12_1  service_visit_def_1537  1
    service_2_12_1  free_load_conservation_1538  1
    service_2_12_2  unique_nonzero_owner_400  1
    service_2_12_2  service_visit_def_1537  1
    service_2_12_2  free_load_conservation_1538  2
    service_2_12_3  unique_nonzero_owner_401  1
    service_2_12_3  service_visit_def_1537  1
    service_2_12_3  free_load_conservation_1538  3
    service_2_12_4  unique_nonzero_owner_402  1
    service_2_12_4  service_visit_def_1537  1
    service_2_12_4  free_load_conservation_1538  4
    service_2_12_5  unique_nonzero_owner_403  1
    service_2_12_5  service_visit_def_1537  1
    service_2_12_5  free_load_conservation_1538  5
    service_2_12_6  unique_nonzero_owner_404  1
    service_2_12_6  service_visit_def_1537  1
    service_2_12_6  free_load_conservation_1538  6
    service_2_12_7  unique_nonzero_owner_405  1
    service_2_12_7  service_visit_def_1537  1
    service_2_12_7  free_load_conservation_1538  7
    service_2_12_8  unique_nonzero_owner_406  1
    service_2_12_8  service_visit_def_1537  1
    service_2_12_8  free_load_conservation_1538  8
    service_2_12_9  unique_nonzero_owner_407  1
    service_2_12_9  service_visit_def_1537  1
    service_2_12_9  free_load_conservation_1538  9
    service_2_12_10  unique_nonzero_owner_408  1
    service_2_12_10  service_visit_def_1537  1
    service_2_12_10  free_load_conservation_1538  10
    service_2_12_11  unique_nonzero_owner_409  1
    service_2_12_11  service_visit_def_1537  1
    service_2_12_11  free_load_conservation_1538  11
    service_2_12_12  unique_nonzero_owner_410  1
    service_2_12_12  service_visit_def_1537  1
    service_2_12_12  free_load_conservation_1538  12
    service_2_12_13  unique_nonzero_owner_411  1
    service_2_12_13  service_visit_def_1537  1
    service_2_12_13  free_load_conservation_1538  13
    service_2_12_14  unique_nonzero_owner_412  1
    service_2_12_14  service_visit_def_1537  1
    service_2_12_14  free_load_conservation_1538  14
    service_2_12_15  unique_nonzero_owner_413  1
    service_2_12_15  service_visit_def_1537  1
    service_2_12_15  free_load_conservation_1538  15
    service_0_7_0  unique_nonzero_owner_414  1
    service_0_7_0  service_visit_def_853  1
    service_0_7_0  free_load_conservation_854  -12
    service_0_7_0  original_T_including_depot_unload_859  1440
    service_0_7_1  unique_nonzero_owner_415  1
    service_0_7_1  service_visit_def_853  1
    service_0_7_1  free_load_conservation_854  -11
    service_0_7_1  original_T_including_depot_unload_859  1320
    service_0_7_2  unique_nonzero_owner_416  1
    service_0_7_2  service_visit_def_853  1
    service_0_7_2  free_load_conservation_854  -10
    service_0_7_2  original_T_including_depot_unload_859  1200
    service_0_7_3  unique_nonzero_owner_417  1
    service_0_7_3  service_visit_def_853  1
    service_0_7_3  free_load_conservation_854  -9
    service_0_7_3  original_T_including_depot_unload_859  1080
    service_0_7_4  unique_nonzero_owner_418  1
    service_0_7_4  service_visit_def_853  1
    service_0_7_4  free_load_conservation_854  -8
    service_0_7_4  original_T_including_depot_unload_859  960
    service_0_7_5  unique_nonzero_owner_419  1
    service_0_7_5  service_visit_def_853  1
    service_0_7_5  free_load_conservation_854  -7
    service_0_7_5  original_T_including_depot_unload_859  840
    service_0_7_6  unique_nonzero_owner_420  1
    service_0_7_6  service_visit_def_853  1
    service_0_7_6  free_load_conservation_854  -6
    service_0_7_6  original_T_including_depot_unload_859  720
    service_0_7_7  unique_nonzero_owner_421  1
    service_0_7_7  service_visit_def_853  1
    service_0_7_7  free_load_conservation_854  -5
    service_0_7_7  original_T_including_depot_unload_859  600
    service_0_7_8  unique_nonzero_owner_422  1
    service_0_7_8  service_visit_def_853  1
    service_0_7_8  free_load_conservation_854  -4
    service_0_7_8  original_T_including_depot_unload_859  480
    service_0_7_9  unique_nonzero_owner_423  1
    service_0_7_9  service_visit_def_853  1
    service_0_7_9  free_load_conservation_854  -3
    service_0_7_9  original_T_including_depot_unload_859  360
    service_0_7_10  unique_nonzero_owner_424  1
    service_0_7_10  service_visit_def_853  1
    service_0_7_10  free_load_conservation_854  -2
    service_0_7_10  original_T_including_depot_unload_859  240
    service_0_7_11  unique_nonzero_owner_425  1
    service_0_7_11  service_visit_def_853  1
    service_0_7_11  free_load_conservation_854  -1
    service_0_7_11  original_T_including_depot_unload_859  120
    service_0_7_13  unique_nonzero_owner_426  1
    service_0_7_13  service_visit_def_853  1
    service_0_7_13  free_load_conservation_854  1
    service_0_7_14  unique_nonzero_owner_427  1
    service_0_7_14  service_visit_def_853  1
    service_0_7_14  free_load_conservation_854  2
    service_0_7_15  unique_nonzero_owner_428  1
    service_0_7_15  service_visit_def_853  1
    service_0_7_15  free_load_conservation_854  3
    service_0_7_16  unique_nonzero_owner_429  1
    service_0_7_16  service_visit_def_853  1
    service_0_7_16  free_load_conservation_854  4
    service_0_7_17  unique_nonzero_owner_430  1
    service_0_7_17  service_visit_def_853  1
    service_0_7_17  free_load_conservation_854  5
    service_1_7_0  unique_nonzero_owner_414  1
    service_1_7_0  service_visit_def_1225  1
    service_1_7_0  free_load_conservation_1226  -12
    service_1_7_0  original_T_including_depot_unload_1230  1440
    service_1_7_1  unique_nonzero_owner_415  1
    service_1_7_1  service_visit_def_1225  1
    service_1_7_1  free_load_conservation_1226  -11
    service_1_7_1  original_T_including_depot_unload_1230  1320
    service_1_7_2  unique_nonzero_owner_416  1
    service_1_7_2  service_visit_def_1225  1
    service_1_7_2  free_load_conservation_1226  -10
    service_1_7_2  original_T_including_depot_unload_1230  1200
    service_1_7_3  unique_nonzero_owner_417  1
    service_1_7_3  service_visit_def_1225  1
    service_1_7_3  free_load_conservation_1226  -9
    service_1_7_3  original_T_including_depot_unload_1230  1080
    service_1_7_4  unique_nonzero_owner_418  1
    service_1_7_4  service_visit_def_1225  1
    service_1_7_4  free_load_conservation_1226  -8
    service_1_7_4  original_T_including_depot_unload_1230  960
    service_1_7_5  unique_nonzero_owner_419  1
    service_1_7_5  service_visit_def_1225  1
    service_1_7_5  free_load_conservation_1226  -7
    service_1_7_5  original_T_including_depot_unload_1230  840
    service_1_7_6  unique_nonzero_owner_420  1
    service_1_7_6  service_visit_def_1225  1
    service_1_7_6  free_load_conservation_1226  -6
    service_1_7_6  original_T_including_depot_unload_1230  720
    service_1_7_7  unique_nonzero_owner_421  1
    service_1_7_7  service_visit_def_1225  1
    service_1_7_7  free_load_conservation_1226  -5
    service_1_7_7  original_T_including_depot_unload_1230  600
    service_1_7_8  unique_nonzero_owner_422  1
    service_1_7_8  service_visit_def_1225  1
    service_1_7_8  free_load_conservation_1226  -4
    service_1_7_8  original_T_including_depot_unload_1230  480
    service_1_7_9  unique_nonzero_owner_423  1
    service_1_7_9  service_visit_def_1225  1
    service_1_7_9  free_load_conservation_1226  -3
    service_1_7_9  original_T_including_depot_unload_1230  360
    service_1_7_10  unique_nonzero_owner_424  1
    service_1_7_10  service_visit_def_1225  1
    service_1_7_10  free_load_conservation_1226  -2
    service_1_7_10  original_T_including_depot_unload_1230  240
    service_1_7_11  unique_nonzero_owner_425  1
    service_1_7_11  service_visit_def_1225  1
    service_1_7_11  free_load_conservation_1226  -1
    service_1_7_11  original_T_including_depot_unload_1230  120
    service_1_7_13  unique_nonzero_owner_426  1
    service_1_7_13  service_visit_def_1225  1
    service_1_7_13  free_load_conservation_1226  1
    service_1_7_14  unique_nonzero_owner_427  1
    service_1_7_14  service_visit_def_1225  1
    service_1_7_14  free_load_conservation_1226  2
    service_1_7_15  unique_nonzero_owner_428  1
    service_1_7_15  service_visit_def_1225  1
    service_1_7_15  free_load_conservation_1226  3
    service_1_7_16  unique_nonzero_owner_429  1
    service_1_7_16  service_visit_def_1225  1
    service_1_7_16  free_load_conservation_1226  4
    service_1_7_17  unique_nonzero_owner_430  1
    service_1_7_17  service_visit_def_1225  1
    service_1_7_17  free_load_conservation_1226  5
    service_2_7_0  unique_nonzero_owner_414  1
    service_2_7_0  service_visit_def_1543  1
    service_2_7_0  free_load_conservation_1544  -12
    service_2_7_0  original_T_including_depot_unload_1547  1440
    service_2_7_1  unique_nonzero_owner_415  1
    service_2_7_1  service_visit_def_1543  1
    service_2_7_1  free_load_conservation_1544  -11
    service_2_7_1  original_T_including_depot_unload_1547  1320
    service_2_7_2  unique_nonzero_owner_416  1
    service_2_7_2  service_visit_def_1543  1
    service_2_7_2  free_load_conservation_1544  -10
    service_2_7_2  original_T_including_depot_unload_1547  1200
    service_2_7_3  unique_nonzero_owner_417  1
    service_2_7_3  service_visit_def_1543  1
    service_2_7_3  free_load_conservation_1544  -9
    service_2_7_3  original_T_including_depot_unload_1547  1080
    service_2_7_4  unique_nonzero_owner_418  1
    service_2_7_4  service_visit_def_1543  1
    service_2_7_4  free_load_conservation_1544  -8
    service_2_7_4  original_T_including_depot_unload_1547  960
    service_2_7_5  unique_nonzero_owner_419  1
    service_2_7_5  service_visit_def_1543  1
    service_2_7_5  free_load_conservation_1544  -7
    service_2_7_5  original_T_including_depot_unload_1547  840
    service_2_7_6  unique_nonzero_owner_420  1
    service_2_7_6  service_visit_def_1543  1
    service_2_7_6  free_load_conservation_1544  -6
    service_2_7_6  original_T_including_depot_unload_1547  720
    service_2_7_7  unique_nonzero_owner_421  1
    service_2_7_7  service_visit_def_1543  1
    service_2_7_7  free_load_conservation_1544  -5
    service_2_7_7  original_T_including_depot_unload_1547  600
    service_2_7_8  unique_nonzero_owner_422  1
    service_2_7_8  service_visit_def_1543  1
    service_2_7_8  free_load_conservation_1544  -4
    service_2_7_8  original_T_including_depot_unload_1547  480
    service_2_7_9  unique_nonzero_owner_423  1
    service_2_7_9  service_visit_def_1543  1
    service_2_7_9  free_load_conservation_1544  -3
    service_2_7_9  original_T_including_depot_unload_1547  360
    service_2_7_10  unique_nonzero_owner_424  1
    service_2_7_10  service_visit_def_1543  1
    service_2_7_10  free_load_conservation_1544  -2
    service_2_7_10  original_T_including_depot_unload_1547  240
    service_2_7_11  unique_nonzero_owner_425  1
    service_2_7_11  service_visit_def_1543  1
    service_2_7_11  free_load_conservation_1544  -1
    service_2_7_11  original_T_including_depot_unload_1547  120
    service_2_7_13  unique_nonzero_owner_426  1
    service_2_7_13  service_visit_def_1543  1
    service_2_7_13  free_load_conservation_1544  1
    service_2_7_14  unique_nonzero_owner_427  1
    service_2_7_14  service_visit_def_1543  1
    service_2_7_14  free_load_conservation_1544  2
    service_2_7_15  unique_nonzero_owner_428  1
    service_2_7_15  service_visit_def_1543  1
    service_2_7_15  free_load_conservation_1544  3
    service_2_7_16  unique_nonzero_owner_429  1
    service_2_7_16  service_visit_def_1543  1
    service_2_7_16  free_load_conservation_1544  4
    service_2_7_17  unique_nonzero_owner_430  1
    service_2_7_17  service_visit_def_1543  1
    service_2_7_17  free_load_conservation_1544  5
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_772  -1
    visit_0_1  in_degree_773  -1
    visit_0_1  order_active_lb_774  -1
    visit_0_1  order_active_ub_775  -13
    order_0_1  connected_order_arc_447  -1
    order_0_1  connected_order_arc_449  -1
    order_0_1  connected_order_arc_451  -1
    order_0_1  connected_order_arc_453  -1
    order_0_1  connected_order_arc_455  -1
    order_0_1  connected_order_arc_457  -1
    order_0_1  connected_order_arc_459  -1
    order_0_1  connected_order_arc_461  -1
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_465  -1
    order_0_1  connected_order_arc_467  -1
    order_0_1  connected_order_arc_469  -1
    order_0_1  connected_order_arc_472  1
    order_0_1  connected_order_arc_497  1
    order_0_1  connected_order_arc_522  1
    order_0_1  connected_order_arc_547  1
    order_0_1  connected_order_arc_572  1
    order_0_1  connected_order_arc_597  1
    order_0_1  connected_order_arc_622  1
    order_0_1  connected_order_arc_647  1
    order_0_1  connected_order_arc_672  1
    order_0_1  connected_order_arc_697  1
    order_0_1  connected_order_arc_722  1
    order_0_1  connected_order_arc_747  1
    order_0_1  order_active_lb_774  1
    order_0_1  order_active_ub_775  1
    order_0_1  fixed_segment_relative_order_855  -1
    visit_0_2  out_degree_779  -1
    visit_0_2  in_degree_780  -1
    visit_0_2  order_active_lb_781  -1
    visit_0_2  order_active_ub_782  -13
    order_0_2  connected_order_arc_447  1
    order_0_2  connected_order_arc_472  -1
    order_0_2  connected_order_arc_474  -1
    order_0_2  connected_order_arc_476  -1
    order_0_2  connected_order_arc_478  -1
    order_0_2  connected_order_arc_480  -1
    order_0_2  connected_order_arc_482  -1
    order_0_2  connected_order_arc_484  -1
    order_0_2  connected_order_arc_486  -1
    order_0_2  connected_order_arc_488  -1
    order_0_2  connected_order_arc_490  -1
    order_0_2  connected_order_arc_492  -1
    order_0_2  connected_order_arc_494  -1
    order_0_2  connected_order_arc_499  1
    order_0_2  connected_order_arc_524  1
    order_0_2  connected_order_arc_549  1
    order_0_2  connected_order_arc_574  1
    order_0_2  connected_order_arc_599  1
    order_0_2  connected_order_arc_624  1
    order_0_2  connected_order_arc_649  1
    order_0_2  connected_order_arc_674  1
    order_0_2  connected_order_arc_699  1
    order_0_2  connected_order_arc_724  1
    order_0_2  connected_order_arc_749  1
    order_0_2  order_active_lb_781  1
    order_0_2  order_active_ub_782  1
    order_0_2  fixed_segment_relative_order_855  1
    order_0_2  fixed_segment_relative_order_856  -1
    visit_0_3  out_degree_786  -1
    visit_0_3  in_degree_787  -1
    visit_0_3  order_active_lb_788  -1
    visit_0_3  order_active_ub_789  -13
    order_0_3  connected_order_arc_449  1
    order_0_3  connected_order_arc_474  1
    order_0_3  connected_order_arc_497  -1
    order_0_3  connected_order_arc_499  -1
    order_0_3  connected_order_arc_501  -1
    order_0_3  connected_order_arc_503  -1
    order_0_3  connected_order_arc_505  -1
    order_0_3  connected_order_arc_507  -1
    order_0_3  connected_order_arc_509  -1
    order_0_3  connected_order_arc_511  -1
    order_0_3  connected_order_arc_513  -1
    order_0_3  connected_order_arc_515  -1
    order_0_3  connected_order_arc_517  -1
    order_0_3  connected_order_arc_519  -1
    order_0_3  connected_order_arc_526  1
    order_0_3  connected_order_arc_551  1
    order_0_3  connected_order_arc_576  1
    order_0_3  connected_order_arc_601  1
    order_0_3  connected_order_arc_626  1
    order_0_3  connected_order_arc_651  1
    order_0_3  connected_order_arc_676  1
    order_0_3  connected_order_arc_701  1
    order_0_3  connected_order_arc_726  1
    order_0_3  connected_order_arc_751  1
    order_0_3  order_active_lb_788  1
    order_0_3  order_active_ub_789  1
    order_0_3  fixed_segment_relative_order_856  1
    order_0_3  fixed_segment_relative_order_857  -1
    visit_0_4  out_degree_793  -1
    visit_0_4  in_degree_794  -1
    visit_0_4  order_active_lb_795  -1
    visit_0_4  order_active_ub_796  -13
    order_0_4  connected_order_arc_451  1
    order_0_4  connected_order_arc_476  1
    order_0_4  connected_order_arc_501  1
    order_0_4  connected_order_arc_522  -1
    order_0_4  connected_order_arc_524  -1
    order_0_4  connected_order_arc_526  -1
    order_0_4  connected_order_arc_528  -1
    order_0_4  connected_order_arc_530  -1
    order_0_4  connected_order_arc_532  -1
    order_0_4  connected_order_arc_534  -1
    order_0_4  connected_order_arc_536  -1
    order_0_4  connected_order_arc_538  -1
    order_0_4  connected_order_arc_540  -1
    order_0_4  connected_order_arc_542  -1
    order_0_4  connected_order_arc_544  -1
    order_0_4  connected_order_arc_553  1
    order_0_4  connected_order_arc_578  1
    order_0_4  connected_order_arc_603  1
    order_0_4  connected_order_arc_628  1
    order_0_4  connected_order_arc_653  1
    order_0_4  connected_order_arc_678  1
    order_0_4  connected_order_arc_703  1
    order_0_4  connected_order_arc_728  1
    order_0_4  connected_order_arc_753  1
    order_0_4  order_active_lb_795  1
    order_0_4  order_active_ub_796  1
    order_0_4  fixed_segment_relative_order_857  1
    order_0_4  fixed_segment_relative_order_858  -1
    visit_0_5  out_degree_800  -1
    visit_0_5  in_degree_801  -1
    visit_0_5  order_active_lb_802  -1
    visit_0_5  order_active_ub_803  -13
    order_0_5  connected_order_arc_453  1
    order_0_5  connected_order_arc_478  1
    order_0_5  connected_order_arc_503  1
    order_0_5  connected_order_arc_528  1
    order_0_5  connected_order_arc_547  -1
    order_0_5  connected_order_arc_549  -1
    order_0_5  connected_order_arc_551  -1
    order_0_5  connected_order_arc_553  -1
    order_0_5  connected_order_arc_555  -1
    order_0_5  connected_order_arc_557  -1
    order_0_5  connected_order_arc_559  -1
    order_0_5  connected_order_arc_561  -1
    order_0_5  connected_order_arc_563  -1
    order_0_5  connected_order_arc_565  -1
    order_0_5  connected_order_arc_567  -1
    order_0_5  connected_order_arc_569  -1
    order_0_5  connected_order_arc_580  1
    order_0_5  connected_order_arc_605  1
    order_0_5  connected_order_arc_630  1
    order_0_5  connected_order_arc_655  1
    order_0_5  connected_order_arc_680  1
    order_0_5  connected_order_arc_705  1
    order_0_5  connected_order_arc_730  1
    order_0_5  connected_order_arc_755  1
    order_0_5  order_active_lb_802  1
    order_0_5  order_active_ub_803  1
    order_0_5  fixed_segment_relative_order_858  1
    visit_0_13  out_degree_807  -1
    visit_0_13  in_degree_808  -1
    visit_0_13  order_active_lb_809  -1
    visit_0_13  order_active_ub_810  -13
    visit_0_13  service_visit_def_811  -1
    order_0_13  connected_order_arc_455  1
    order_0_13  connected_order_arc_480  1
    order_0_13  connected_order_arc_505  1
    order_0_13  connected_order_arc_530  1
    order_0_13  connected_order_arc_555  1
    order_0_13  connected_order_arc_572  -1
    order_0_13  connected_order_arc_574  -1
    order_0_13  connected_order_arc_576  -1
    order_0_13  connected_order_arc_578  -1
    order_0_13  connected_order_arc_580  -1
    order_0_13  connected_order_arc_582  -1
    order_0_13  connected_order_arc_584  -1
    order_0_13  connected_order_arc_586  -1
    order_0_13  connected_order_arc_588  -1
    order_0_13  connected_order_arc_590  -1
    order_0_13  connected_order_arc_592  -1
    order_0_13  connected_order_arc_594  -1
    order_0_13  connected_order_arc_607  1
    order_0_13  connected_order_arc_632  1
    order_0_13  connected_order_arc_657  1
    order_0_13  connected_order_arc_682  1
    order_0_13  connected_order_arc_707  1
    order_0_13  connected_order_arc_732  1
    order_0_13  connected_order_arc_757  1
    order_0_13  order_active_lb_809  1
    order_0_13  order_active_ub_810  1
    visit_0_14  out_degree_813  -1
    visit_0_14  in_degree_814  -1
    visit_0_14  order_active_lb_815  -1
    visit_0_14  order_active_ub_816  -13
    visit_0_14  service_visit_def_817  -1
    order_0_14  connected_order_arc_457  1
    order_0_14  connected_order_arc_482  1
    order_0_14  connected_order_arc_507  1
    order_0_14  connected_order_arc_532  1
    order_0_14  connected_order_arc_557  1
    order_0_14  connected_order_arc_582  1
    order_0_14  connected_order_arc_597  -1
    order_0_14  connected_order_arc_599  -1
    order_0_14  connected_order_arc_601  -1
    order_0_14  connected_order_arc_603  -1
    order_0_14  connected_order_arc_605  -1
    order_0_14  connected_order_arc_607  -1
    order_0_14  connected_order_arc_609  -1
    order_0_14  connected_order_arc_611  -1
    order_0_14  connected_order_arc_613  -1
    order_0_14  connected_order_arc_615  -1
    order_0_14  connected_order_arc_617  -1
    order_0_14  connected_order_arc_619  -1
    order_0_14  connected_order_arc_634  1
    order_0_14  connected_order_arc_659  1
    order_0_14  connected_order_arc_684  1
    order_0_14  connected_order_arc_709  1
    order_0_14  connected_order_arc_734  1
    order_0_14  connected_order_arc_759  1
    order_0_14  order_active_lb_815  1
    order_0_14  order_active_ub_816  1
    visit_0_15  out_degree_819  -1
    visit_0_15  in_degree_820  -1
    visit_0_15  order_active_lb_821  -1
    visit_0_15  order_active_ub_822  -13
    visit_0_15  service_visit_def_823  -1
    order_0_15  connected_order_arc_459  1
    order_0_15  connected_order_arc_484  1
    order_0_15  connected_order_arc_509  1
    order_0_15  connected_order_arc_534  1
    order_0_15  connected_order_arc_559  1
    order_0_15  connected_order_arc_584  1
    order_0_15  connected_order_arc_609  1
    order_0_15  connected_order_arc_622  -1
    order_0_15  connected_order_arc_624  -1
    order_0_15  connected_order_arc_626  -1
    order_0_15  connected_order_arc_628  -1
    order_0_15  connected_order_arc_630  -1
    order_0_15  connected_order_arc_632  -1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_636  -1
    order_0_15  connected_order_arc_638  -1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_642  -1
    order_0_15  connected_order_arc_644  -1
    order_0_15  connected_order_arc_661  1
    order_0_15  connected_order_arc_686  1
    order_0_15  connected_order_arc_711  1
    order_0_15  connected_order_arc_736  1
    order_0_15  connected_order_arc_761  1
    order_0_15  order_active_lb_821  1
    order_0_15  order_active_ub_822  1
    visit_0_16  out_degree_825  -1
    visit_0_16  in_degree_826  -1
    visit_0_16  order_active_lb_827  -1
    visit_0_16  order_active_ub_828  -13
    visit_0_16  service_visit_def_829  -1
    order_0_16  connected_order_arc_461  1
    order_0_16  connected_order_arc_486  1
    order_0_16  connected_order_arc_511  1
    order_0_16  connected_order_arc_536  1
    order_0_16  connected_order_arc_561  1
    order_0_16  connected_order_arc_586  1
    order_0_16  connected_order_arc_611  1
    order_0_16  connected_order_arc_636  1
    order_0_16  connected_order_arc_647  -1
    order_0_16  connected_order_arc_649  -1
    order_0_16  connected_order_arc_651  -1
    order_0_16  connected_order_arc_653  -1
    order_0_16  connected_order_arc_655  -1
    order_0_16  connected_order_arc_657  -1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_663  -1
    order_0_16  connected_order_arc_665  -1
    order_0_16  connected_order_arc_667  -1
    order_0_16  connected_order_arc_669  -1
    order_0_16  connected_order_arc_688  1
    order_0_16  connected_order_arc_713  1
    order_0_16  connected_order_arc_738  1
    order_0_16  connected_order_arc_763  1
    order_0_16  order_active_lb_827  1
    order_0_16  order_active_ub_828  1
    visit_0_17  out_degree_831  -1
    visit_0_17  in_degree_832  -1
    visit_0_17  order_active_lb_833  -1
    visit_0_17  order_active_ub_834  -13
    visit_0_17  service_visit_def_835  -1
    order_0_17  connected_order_arc_463  1
    order_0_17  connected_order_arc_488  1
    order_0_17  connected_order_arc_513  1
    order_0_17  connected_order_arc_538  1
    order_0_17  connected_order_arc_563  1
    order_0_17  connected_order_arc_588  1
    order_0_17  connected_order_arc_613  1
    order_0_17  connected_order_arc_638  1
    order_0_17  connected_order_arc_663  1
    order_0_17  connected_order_arc_672  -1
    order_0_17  connected_order_arc_674  -1
    order_0_17  connected_order_arc_676  -1
    order_0_17  connected_order_arc_678  -1
    order_0_17  connected_order_arc_680  -1
    order_0_17  connected_order_arc_682  -1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_688  -1
    order_0_17  connected_order_arc_690  -1
    order_0_17  connected_order_arc_692  -1
    order_0_17  connected_order_arc_694  -1
    order_0_17  connected_order_arc_715  1
    order_0_17  connected_order_arc_740  1
    order_0_17  connected_order_arc_765  1
    order_0_17  order_active_lb_833  1
    order_0_17  order_active_ub_834  1
    visit_0_18  out_degree_837  -1
    visit_0_18  in_degree_838  -1
    visit_0_18  order_active_lb_839  -1
    visit_0_18  order_active_ub_840  -13
    visit_0_18  service_visit_def_841  -1
    order_0_18  connected_order_arc_465  1
    order_0_18  connected_order_arc_490  1
    order_0_18  connected_order_arc_515  1
    order_0_18  connected_order_arc_540  1
    order_0_18  connected_order_arc_565  1
    order_0_18  connected_order_arc_590  1
    order_0_18  connected_order_arc_615  1
    order_0_18  connected_order_arc_640  1
    order_0_18  connected_order_arc_665  1
    order_0_18  connected_order_arc_690  1
    order_0_18  connected_order_arc_697  -1
    order_0_18  connected_order_arc_699  -1
    order_0_18  connected_order_arc_701  -1
    order_0_18  connected_order_arc_703  -1
    order_0_18  connected_order_arc_705  -1
    order_0_18  connected_order_arc_707  -1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_711  -1
    order_0_18  connected_order_arc_713  -1
    order_0_18  connected_order_arc_715  -1
    order_0_18  connected_order_arc_717  -1
    order_0_18  connected_order_arc_719  -1
    order_0_18  connected_order_arc_742  1
    order_0_18  connected_order_arc_767  1
    order_0_18  order_active_lb_839  1
    order_0_18  order_active_ub_840  1
    visit_0_19  out_degree_843  -1
    visit_0_19  in_degree_844  -1
    visit_0_19  order_active_lb_845  -1
    visit_0_19  order_active_ub_846  -13
    visit_0_19  service_visit_def_847  -1
    order_0_19  connected_order_arc_467  1
    order_0_19  connected_order_arc_492  1
    order_0_19  connected_order_arc_517  1
    order_0_19  connected_order_arc_542  1
    order_0_19  connected_order_arc_567  1
    order_0_19  connected_order_arc_592  1
    order_0_19  connected_order_arc_617  1
    order_0_19  connected_order_arc_642  1
    order_0_19  connected_order_arc_667  1
    order_0_19  connected_order_arc_692  1
    order_0_19  connected_order_arc_717  1
    order_0_19  connected_order_arc_722  -1
    order_0_19  connected_order_arc_724  -1
    order_0_19  connected_order_arc_726  -1
    order_0_19  connected_order_arc_728  -1
    order_0_19  connected_order_arc_730  -1
    order_0_19  connected_order_arc_732  -1
    order_0_19  connected_order_arc_734  -1
    order_0_19  connected_order_arc_736  -1
    order_0_19  connected_order_arc_738  -1
    order_0_19  connected_order_arc_740  -1
    order_0_19  connected_order_arc_742  -1
    order_0_19  connected_order_arc_744  -1
    order_0_19  connected_order_arc_769  1
    order_0_19  order_active_lb_845  1
    order_0_19  order_active_ub_846  1
    visit_0_20  out_degree_849  -1
    visit_0_20  in_degree_850  -1
    visit_0_20  order_active_lb_851  -1
    visit_0_20  order_active_ub_852  -13
    visit_0_20  service_visit_def_853  -1
    order_0_20  connected_order_arc_469  1
    order_0_20  connected_order_arc_494  1
    order_0_20  connected_order_arc_519  1
    order_0_20  connected_order_arc_544  1
    order_0_20  connected_order_arc_569  1
    order_0_20  connected_order_arc_594  1
    order_0_20  connected_order_arc_619  1
    order_0_20  connected_order_arc_644  1
    order_0_20  connected_order_arc_669  1
    order_0_20  connected_order_arc_694  1
    order_0_20  connected_order_arc_719  1
    order_0_20  connected_order_arc_744  1
    order_0_20  connected_order_arc_747  -1
    order_0_20  connected_order_arc_749  -1
    order_0_20  connected_order_arc_751  -1
    order_0_20  connected_order_arc_753  -1
    order_0_20  connected_order_arc_755  -1
    order_0_20  connected_order_arc_757  -1
    order_0_20  connected_order_arc_759  -1
    order_0_20  connected_order_arc_761  -1
    order_0_20  connected_order_arc_763  -1
    order_0_20  connected_order_arc_765  -1
    order_0_20  connected_order_arc_767  -1
    order_0_20  connected_order_arc_769  -1
    order_0_20  order_active_lb_851  1
    order_0_20  order_active_ub_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_431  -20
    arc_0_0_0  depot_departure_or_bypass_770  1
    arc_0_0_0  depot_return_or_bypass_771  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_431  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_432  -20
    arc_0_0_1  depot_departure_or_bypass_770  1
    arc_0_0_1  in_degree_773  1
    arc_0_0_1  original_T_including_depot_unload_859  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_432  1
    load_0_0_1  segment_load_conservation_776  -1
    load_0_0_1  segment_prefix_lb_777  1
    load_0_0_1  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_433  -20
    arc_0_0_2  depot_departure_or_bypass_770  1
    arc_0_0_2  in_degree_780  1
    arc_0_0_2  original_T_including_depot_unload_859  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_433  1
    load_0_0_2  segment_load_conservation_783  -1
    load_0_0_2  segment_prefix_lb_784  1
    load_0_0_2  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_434  -20
    arc_0_0_3  depot_departure_or_bypass_770  1
    arc_0_0_3  in_degree_787  1
    arc_0_0_3  original_T_including_depot_unload_859  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_434  1
    load_0_0_3  segment_load_conservation_790  -1
    load_0_0_3  segment_prefix_lb_791  1
    load_0_0_3  segment_prefix_ub_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_435  -20
    arc_0_0_4  depot_departure_or_bypass_770  1
    arc_0_0_4  in_degree_794  1
    arc_0_0_4  original_T_including_depot_unload_859  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_435  1
    load_0_0_4  segment_load_conservation_797  -1
    load_0_0_4  segment_prefix_lb_798  1
    load_0_0_4  segment_prefix_ub_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_436  -20
    arc_0_0_5  depot_departure_or_bypass_770  1
    arc_0_0_5  in_degree_801  1
    arc_0_0_5  original_T_including_depot_unload_859  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_436  1
    load_0_0_5  segment_load_conservation_804  -1
    load_0_0_5  segment_prefix_lb_805  1
    load_0_0_5  segment_prefix_ub_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_437  -20
    arc_0_0_13  depot_departure_or_bypass_770  1
    arc_0_0_13  in_degree_808  1
    arc_0_0_13  original_T_including_depot_unload_859  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_437  1
    load_0_0_13  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_438  -20
    arc_0_0_14  depot_departure_or_bypass_770  1
    arc_0_0_14  in_degree_814  1
    arc_0_0_14  original_T_including_depot_unload_859  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_438  1
    load_0_0_14  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_439  -20
    arc_0_0_15  depot_departure_or_bypass_770  1
    arc_0_0_15  in_degree_820  1
    arc_0_0_15  original_T_including_depot_unload_859  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_439  1
    load_0_0_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_440  -20
    arc_0_0_16  depot_departure_or_bypass_770  1
    arc_0_0_16  in_degree_826  1
    arc_0_0_16  original_T_including_depot_unload_859  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_440  1
    load_0_0_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_441  -20
    arc_0_0_17  depot_departure_or_bypass_770  1
    arc_0_0_17  in_degree_832  1
    arc_0_0_17  original_T_including_depot_unload_859  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_441  1
    load_0_0_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_442  -20
    arc_0_0_18  depot_departure_or_bypass_770  1
    arc_0_0_18  in_degree_838  1
    arc_0_0_18  original_T_including_depot_unload_859  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_442  1
    load_0_0_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_443  -20
    arc_0_0_19  depot_departure_or_bypass_770  1
    arc_0_0_19  in_degree_844  1
    arc_0_0_19  original_T_including_depot_unload_859  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_443  1
    load_0_0_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_444  -20
    arc_0_0_20  depot_departure_or_bypass_770  1
    arc_0_0_20  in_degree_850  1
    arc_0_0_20  original_T_including_depot_unload_859  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_444  1
    load_0_0_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_445  -20
    arc_0_1_0  depot_return_or_bypass_771  1
    arc_0_1_0  out_degree_772  1
    arc_0_1_0  original_T_including_depot_unload_859  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_445  1
    load_0_1_0  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_446  -20
    arc_0_1_2  connected_order_arc_447  -14
    arc_0_1_2  out_degree_772  1
    arc_0_1_2  in_degree_780  1
    arc_0_1_2  original_T_including_depot_unload_859  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_446  1
    load_0_1_2  segment_load_conservation_776  1
    load_0_1_2  segment_load_conservation_783  -1
    load_0_1_2  segment_prefix_lb_784  1
    load_0_1_2  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_448  -20
    arc_0_1_3  connected_order_arc_449  -14
    arc_0_1_3  out_degree_772  1
    arc_0_1_3  in_degree_787  1
    arc_0_1_3  original_T_including_depot_unload_859  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_448  1
    load_0_1_3  segment_load_conservation_776  1
    load_0_1_3  segment_load_conservation_790  -1
    load_0_1_3  segment_prefix_lb_791  1
    load_0_1_3  segment_prefix_ub_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_450  -20
    arc_0_1_4  connected_order_arc_451  -14
    arc_0_1_4  out_degree_772  1
    arc_0_1_4  in_degree_794  1
    arc_0_1_4  original_T_including_depot_unload_859  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_450  1
    load_0_1_4  segment_load_conservation_776  1
    load_0_1_4  segment_load_conservation_797  -1
    load_0_1_4  segment_prefix_lb_798  1
    load_0_1_4  segment_prefix_ub_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_452  -20
    arc_0_1_5  connected_order_arc_453  -14
    arc_0_1_5  out_degree_772  1
    arc_0_1_5  in_degree_801  1
    arc_0_1_5  original_T_including_depot_unload_859  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_452  1
    load_0_1_5  segment_load_conservation_776  1
    load_0_1_5  segment_load_conservation_804  -1
    load_0_1_5  segment_prefix_lb_805  1
    load_0_1_5  segment_prefix_ub_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_454  -20
    arc_0_1_13  connected_order_arc_455  -14
    arc_0_1_13  out_degree_772  1
    arc_0_1_13  in_degree_808  1
    arc_0_1_13  original_T_including_depot_unload_859  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_454  1
    load_0_1_13  segment_load_conservation_776  1
    load_0_1_13  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_456  -20
    arc_0_1_14  connected_order_arc_457  -14
    arc_0_1_14  out_degree_772  1
    arc_0_1_14  in_degree_814  1
    arc_0_1_14  original_T_including_depot_unload_859  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_456  1
    load_0_1_14  segment_load_conservation_776  1
    load_0_1_14  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_458  -20
    arc_0_1_15  connected_order_arc_459  -14
    arc_0_1_15  out_degree_772  1
    arc_0_1_15  in_degree_820  1
    arc_0_1_15  original_T_including_depot_unload_859  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_458  1
    load_0_1_15  segment_load_conservation_776  1
    load_0_1_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_460  -20
    arc_0_1_16  connected_order_arc_461  -14
    arc_0_1_16  out_degree_772  1
    arc_0_1_16  in_degree_826  1
    arc_0_1_16  original_T_including_depot_unload_859  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_460  1
    load_0_1_16  segment_load_conservation_776  1
    load_0_1_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_462  -20
    arc_0_1_17  connected_order_arc_463  -14
    arc_0_1_17  out_degree_772  1
    arc_0_1_17  in_degree_832  1
    arc_0_1_17  original_T_including_depot_unload_859  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_462  1
    load_0_1_17  segment_load_conservation_776  1
    load_0_1_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_464  -20
    arc_0_1_18  connected_order_arc_465  -14
    arc_0_1_18  out_degree_772  1
    arc_0_1_18  in_degree_838  1
    arc_0_1_18  original_T_including_depot_unload_859  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_464  1
    load_0_1_18  segment_load_conservation_776  1
    load_0_1_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_466  -20
    arc_0_1_19  connected_order_arc_467  -14
    arc_0_1_19  out_degree_772  1
    arc_0_1_19  in_degree_844  1
    arc_0_1_19  original_T_including_depot_unload_859  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_466  1
    load_0_1_19  segment_load_conservation_776  1
    load_0_1_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_468  -20
    arc_0_1_20  connected_order_arc_469  -14
    arc_0_1_20  out_degree_772  1
    arc_0_1_20  in_degree_850  1
    arc_0_1_20  original_T_including_depot_unload_859  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_468  1
    load_0_1_20  segment_load_conservation_776  1
    load_0_1_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_470  -20
    arc_0_2_0  depot_return_or_bypass_771  1
    arc_0_2_0  out_degree_779  1
    arc_0_2_0  original_T_including_depot_unload_859  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_470  1
    load_0_2_0  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_471  -20
    arc_0_2_1  connected_order_arc_472  -14
    arc_0_2_1  in_degree_773  1
    arc_0_2_1  out_degree_779  1
    arc_0_2_1  original_T_including_depot_unload_859  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_471  1
    load_0_2_1  segment_load_conservation_776  -1
    load_0_2_1  segment_prefix_lb_777  1
    load_0_2_1  segment_prefix_ub_778  1
    load_0_2_1  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_473  -20
    arc_0_2_3  connected_order_arc_474  -14
    arc_0_2_3  out_degree_779  1
    arc_0_2_3  in_degree_787  1
    arc_0_2_3  original_T_including_depot_unload_859  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_473  1
    load_0_2_3  segment_load_conservation_783  1
    load_0_2_3  segment_load_conservation_790  -1
    load_0_2_3  segment_prefix_lb_791  1
    load_0_2_3  segment_prefix_ub_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_475  -20
    arc_0_2_4  connected_order_arc_476  -14
    arc_0_2_4  out_degree_779  1
    arc_0_2_4  in_degree_794  1
    arc_0_2_4  original_T_including_depot_unload_859  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_475  1
    load_0_2_4  segment_load_conservation_783  1
    load_0_2_4  segment_load_conservation_797  -1
    load_0_2_4  segment_prefix_lb_798  1
    load_0_2_4  segment_prefix_ub_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_477  -20
    arc_0_2_5  connected_order_arc_478  -14
    arc_0_2_5  out_degree_779  1
    arc_0_2_5  in_degree_801  1
    arc_0_2_5  original_T_including_depot_unload_859  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_477  1
    load_0_2_5  segment_load_conservation_783  1
    load_0_2_5  segment_load_conservation_804  -1
    load_0_2_5  segment_prefix_lb_805  1
    load_0_2_5  segment_prefix_ub_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_479  -20
    arc_0_2_13  connected_order_arc_480  -14
    arc_0_2_13  out_degree_779  1
    arc_0_2_13  in_degree_808  1
    arc_0_2_13  original_T_including_depot_unload_859  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_479  1
    load_0_2_13  segment_load_conservation_783  1
    load_0_2_13  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_481  -20
    arc_0_2_14  connected_order_arc_482  -14
    arc_0_2_14  out_degree_779  1
    arc_0_2_14  in_degree_814  1
    arc_0_2_14  original_T_including_depot_unload_859  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_481  1
    load_0_2_14  segment_load_conservation_783  1
    load_0_2_14  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_483  -20
    arc_0_2_15  connected_order_arc_484  -14
    arc_0_2_15  out_degree_779  1
    arc_0_2_15  in_degree_820  1
    arc_0_2_15  original_T_including_depot_unload_859  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_483  1
    load_0_2_15  segment_load_conservation_783  1
    load_0_2_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_485  -20
    arc_0_2_16  connected_order_arc_486  -14
    arc_0_2_16  out_degree_779  1
    arc_0_2_16  in_degree_826  1
    arc_0_2_16  original_T_including_depot_unload_859  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_485  1
    load_0_2_16  segment_load_conservation_783  1
    load_0_2_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_487  -20
    arc_0_2_17  connected_order_arc_488  -14
    arc_0_2_17  out_degree_779  1
    arc_0_2_17  in_degree_832  1
    arc_0_2_17  original_T_including_depot_unload_859  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_487  1
    load_0_2_17  segment_load_conservation_783  1
    load_0_2_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_489  -20
    arc_0_2_18  connected_order_arc_490  -14
    arc_0_2_18  out_degree_779  1
    arc_0_2_18  in_degree_838  1
    arc_0_2_18  original_T_including_depot_unload_859  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_489  1
    load_0_2_18  segment_load_conservation_783  1
    load_0_2_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_491  -20
    arc_0_2_19  connected_order_arc_492  -14
    arc_0_2_19  out_degree_779  1
    arc_0_2_19  in_degree_844  1
    arc_0_2_19  original_T_including_depot_unload_859  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_491  1
    load_0_2_19  segment_load_conservation_783  1
    load_0_2_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_493  -20
    arc_0_2_20  connected_order_arc_494  -14
    arc_0_2_20  out_degree_779  1
    arc_0_2_20  in_degree_850  1
    arc_0_2_20  original_T_including_depot_unload_859  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_493  1
    load_0_2_20  segment_load_conservation_783  1
    load_0_2_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_495  -20
    arc_0_3_0  depot_return_or_bypass_771  1
    arc_0_3_0  out_degree_786  1
    arc_0_3_0  original_T_including_depot_unload_859  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_495  1
    load_0_3_0  segment_load_conservation_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_496  -20
    arc_0_3_1  connected_order_arc_497  -14
    arc_0_3_1  in_degree_773  1
    arc_0_3_1  out_degree_786  1
    arc_0_3_1  original_T_including_depot_unload_859  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_496  1
    load_0_3_1  segment_load_conservation_776  -1
    load_0_3_1  segment_prefix_lb_777  1
    load_0_3_1  segment_prefix_ub_778  1
    load_0_3_1  segment_load_conservation_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_498  -20
    arc_0_3_2  connected_order_arc_499  -14
    arc_0_3_2  in_degree_780  1
    arc_0_3_2  out_degree_786  1
    arc_0_3_2  original_T_including_depot_unload_859  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_498  1
    load_0_3_2  segment_load_conservation_783  -1
    load_0_3_2  segment_prefix_lb_784  1
    load_0_3_2  segment_prefix_ub_785  1
    load_0_3_2  segment_load_conservation_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_500  -20
    arc_0_3_4  connected_order_arc_501  -14
    arc_0_3_4  out_degree_786  1
    arc_0_3_4  in_degree_794  1
    arc_0_3_4  original_T_including_depot_unload_859  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_500  1
    load_0_3_4  segment_load_conservation_790  1
    load_0_3_4  segment_load_conservation_797  -1
    load_0_3_4  segment_prefix_lb_798  1
    load_0_3_4  segment_prefix_ub_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_502  -20
    arc_0_3_5  connected_order_arc_503  -14
    arc_0_3_5  out_degree_786  1
    arc_0_3_5  in_degree_801  1
    arc_0_3_5  original_T_including_depot_unload_859  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_502  1
    load_0_3_5  segment_load_conservation_790  1
    load_0_3_5  segment_load_conservation_804  -1
    load_0_3_5  segment_prefix_lb_805  1
    load_0_3_5  segment_prefix_ub_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_504  -20
    arc_0_3_13  connected_order_arc_505  -14
    arc_0_3_13  out_degree_786  1
    arc_0_3_13  in_degree_808  1
    arc_0_3_13  original_T_including_depot_unload_859  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_504  1
    load_0_3_13  segment_load_conservation_790  1
    load_0_3_13  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_506  -20
    arc_0_3_14  connected_order_arc_507  -14
    arc_0_3_14  out_degree_786  1
    arc_0_3_14  in_degree_814  1
    arc_0_3_14  original_T_including_depot_unload_859  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_506  1
    load_0_3_14  segment_load_conservation_790  1
    load_0_3_14  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_508  -20
    arc_0_3_15  connected_order_arc_509  -14
    arc_0_3_15  out_degree_786  1
    arc_0_3_15  in_degree_820  1
    arc_0_3_15  original_T_including_depot_unload_859  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_508  1
    load_0_3_15  segment_load_conservation_790  1
    load_0_3_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_510  -20
    arc_0_3_16  connected_order_arc_511  -14
    arc_0_3_16  out_degree_786  1
    arc_0_3_16  in_degree_826  1
    arc_0_3_16  original_T_including_depot_unload_859  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_510  1
    load_0_3_16  segment_load_conservation_790  1
    load_0_3_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_512  -20
    arc_0_3_17  connected_order_arc_513  -14
    arc_0_3_17  out_degree_786  1
    arc_0_3_17  in_degree_832  1
    arc_0_3_17  original_T_including_depot_unload_859  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_512  1
    load_0_3_17  segment_load_conservation_790  1
    load_0_3_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_514  -20
    arc_0_3_18  connected_order_arc_515  -14
    arc_0_3_18  out_degree_786  1
    arc_0_3_18  in_degree_838  1
    arc_0_3_18  original_T_including_depot_unload_859  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_514  1
    load_0_3_18  segment_load_conservation_790  1
    load_0_3_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_516  -20
    arc_0_3_19  connected_order_arc_517  -14
    arc_0_3_19  out_degree_786  1
    arc_0_3_19  in_degree_844  1
    arc_0_3_19  original_T_including_depot_unload_859  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_516  1
    load_0_3_19  segment_load_conservation_790  1
    load_0_3_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_518  -20
    arc_0_3_20  connected_order_arc_519  -14
    arc_0_3_20  out_degree_786  1
    arc_0_3_20  in_degree_850  1
    arc_0_3_20  original_T_including_depot_unload_859  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_518  1
    load_0_3_20  segment_load_conservation_790  1
    load_0_3_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_520  -20
    arc_0_4_0  depot_return_or_bypass_771  1
    arc_0_4_0  out_degree_793  1
    arc_0_4_0  original_T_including_depot_unload_859  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_520  1
    load_0_4_0  segment_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_521  -20
    arc_0_4_1  connected_order_arc_522  -14
    arc_0_4_1  in_degree_773  1
    arc_0_4_1  out_degree_793  1
    arc_0_4_1  original_T_including_depot_unload_859  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_521  1
    load_0_4_1  segment_load_conservation_776  -1
    load_0_4_1  segment_prefix_lb_777  1
    load_0_4_1  segment_prefix_ub_778  1
    load_0_4_1  segment_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_523  -20
    arc_0_4_2  connected_order_arc_524  -14
    arc_0_4_2  in_degree_780  1
    arc_0_4_2  out_degree_793  1
    arc_0_4_2  original_T_including_depot_unload_859  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_523  1
    load_0_4_2  segment_load_conservation_783  -1
    load_0_4_2  segment_prefix_lb_784  1
    load_0_4_2  segment_prefix_ub_785  1
    load_0_4_2  segment_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_525  -20
    arc_0_4_3  connected_order_arc_526  -14
    arc_0_4_3  in_degree_787  1
    arc_0_4_3  out_degree_793  1
    arc_0_4_3  original_T_including_depot_unload_859  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_525  1
    load_0_4_3  segment_load_conservation_790  -1
    load_0_4_3  segment_prefix_lb_791  1
    load_0_4_3  segment_prefix_ub_792  1
    load_0_4_3  segment_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_527  -20
    arc_0_4_5  connected_order_arc_528  -14
    arc_0_4_5  out_degree_793  1
    arc_0_4_5  in_degree_801  1
    arc_0_4_5  original_T_including_depot_unload_859  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_527  1
    load_0_4_5  segment_load_conservation_797  1
    load_0_4_5  segment_load_conservation_804  -1
    load_0_4_5  segment_prefix_lb_805  1
    load_0_4_5  segment_prefix_ub_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_529  -20
    arc_0_4_13  connected_order_arc_530  -14
    arc_0_4_13  out_degree_793  1
    arc_0_4_13  in_degree_808  1
    arc_0_4_13  original_T_including_depot_unload_859  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_529  1
    load_0_4_13  segment_load_conservation_797  1
    load_0_4_13  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_531  -20
    arc_0_4_14  connected_order_arc_532  -14
    arc_0_4_14  out_degree_793  1
    arc_0_4_14  in_degree_814  1
    arc_0_4_14  original_T_including_depot_unload_859  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_531  1
    load_0_4_14  segment_load_conservation_797  1
    load_0_4_14  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_533  -20
    arc_0_4_15  connected_order_arc_534  -14
    arc_0_4_15  out_degree_793  1
    arc_0_4_15  in_degree_820  1
    arc_0_4_15  original_T_including_depot_unload_859  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_533  1
    load_0_4_15  segment_load_conservation_797  1
    load_0_4_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_535  -20
    arc_0_4_16  connected_order_arc_536  -14
    arc_0_4_16  out_degree_793  1
    arc_0_4_16  in_degree_826  1
    arc_0_4_16  original_T_including_depot_unload_859  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_535  1
    load_0_4_16  segment_load_conservation_797  1
    load_0_4_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_537  -20
    arc_0_4_17  connected_order_arc_538  -14
    arc_0_4_17  out_degree_793  1
    arc_0_4_17  in_degree_832  1
    arc_0_4_17  original_T_including_depot_unload_859  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_537  1
    load_0_4_17  segment_load_conservation_797  1
    load_0_4_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_539  -20
    arc_0_4_18  connected_order_arc_540  -14
    arc_0_4_18  out_degree_793  1
    arc_0_4_18  in_degree_838  1
    arc_0_4_18  original_T_including_depot_unload_859  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_539  1
    load_0_4_18  segment_load_conservation_797  1
    load_0_4_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_541  -20
    arc_0_4_19  connected_order_arc_542  -14
    arc_0_4_19  out_degree_793  1
    arc_0_4_19  in_degree_844  1
    arc_0_4_19  original_T_including_depot_unload_859  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_541  1
    load_0_4_19  segment_load_conservation_797  1
    load_0_4_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_543  -20
    arc_0_4_20  connected_order_arc_544  -14
    arc_0_4_20  out_degree_793  1
    arc_0_4_20  in_degree_850  1
    arc_0_4_20  original_T_including_depot_unload_859  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_543  1
    load_0_4_20  segment_load_conservation_797  1
    load_0_4_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_545  -20
    arc_0_5_0  depot_return_or_bypass_771  1
    arc_0_5_0  out_degree_800  1
    arc_0_5_0  original_T_including_depot_unload_859  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_545  1
    load_0_5_0  segment_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_546  -20
    arc_0_5_1  connected_order_arc_547  -14
    arc_0_5_1  in_degree_773  1
    arc_0_5_1  out_degree_800  1
    arc_0_5_1  original_T_including_depot_unload_859  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_546  1
    load_0_5_1  segment_load_conservation_776  -1
    load_0_5_1  segment_prefix_lb_777  1
    load_0_5_1  segment_prefix_ub_778  1
    load_0_5_1  segment_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_548  -20
    arc_0_5_2  connected_order_arc_549  -14
    arc_0_5_2  in_degree_780  1
    arc_0_5_2  out_degree_800  1
    arc_0_5_2  original_T_including_depot_unload_859  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_548  1
    load_0_5_2  segment_load_conservation_783  -1
    load_0_5_2  segment_prefix_lb_784  1
    load_0_5_2  segment_prefix_ub_785  1
    load_0_5_2  segment_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_550  -20
    arc_0_5_3  connected_order_arc_551  -14
    arc_0_5_3  in_degree_787  1
    arc_0_5_3  out_degree_800  1
    arc_0_5_3  original_T_including_depot_unload_859  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_550  1
    load_0_5_3  segment_load_conservation_790  -1
    load_0_5_3  segment_prefix_lb_791  1
    load_0_5_3  segment_prefix_ub_792  1
    load_0_5_3  segment_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_552  -20
    arc_0_5_4  connected_order_arc_553  -14
    arc_0_5_4  in_degree_794  1
    arc_0_5_4  out_degree_800  1
    arc_0_5_4  original_T_including_depot_unload_859  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_552  1
    load_0_5_4  segment_load_conservation_797  -1
    load_0_5_4  segment_prefix_lb_798  1
    load_0_5_4  segment_prefix_ub_799  1
    load_0_5_4  segment_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_554  -20
    arc_0_5_13  connected_order_arc_555  -14
    arc_0_5_13  out_degree_800  1
    arc_0_5_13  in_degree_808  1
    arc_0_5_13  original_T_including_depot_unload_859  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_554  1
    load_0_5_13  segment_load_conservation_804  1
    load_0_5_13  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_556  -20
    arc_0_5_14  connected_order_arc_557  -14
    arc_0_5_14  out_degree_800  1
    arc_0_5_14  in_degree_814  1
    arc_0_5_14  original_T_including_depot_unload_859  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_556  1
    load_0_5_14  segment_load_conservation_804  1
    load_0_5_14  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_558  -20
    arc_0_5_15  connected_order_arc_559  -14
    arc_0_5_15  out_degree_800  1
    arc_0_5_15  in_degree_820  1
    arc_0_5_15  original_T_including_depot_unload_859  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_558  1
    load_0_5_15  segment_load_conservation_804  1
    load_0_5_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_560  -20
    arc_0_5_16  connected_order_arc_561  -14
    arc_0_5_16  out_degree_800  1
    arc_0_5_16  in_degree_826  1
    arc_0_5_16  original_T_including_depot_unload_859  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_560  1
    load_0_5_16  segment_load_conservation_804  1
    load_0_5_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_562  -20
    arc_0_5_17  connected_order_arc_563  -14
    arc_0_5_17  out_degree_800  1
    arc_0_5_17  in_degree_832  1
    arc_0_5_17  original_T_including_depot_unload_859  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_562  1
    load_0_5_17  segment_load_conservation_804  1
    load_0_5_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_564  -20
    arc_0_5_18  connected_order_arc_565  -14
    arc_0_5_18  out_degree_800  1
    arc_0_5_18  in_degree_838  1
    arc_0_5_18  original_T_including_depot_unload_859  1.3473492742338772e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_564  1
    load_0_5_18  segment_load_conservation_804  1
    load_0_5_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_566  -20
    arc_0_5_19  connected_order_arc_567  -14
    arc_0_5_19  out_degree_800  1
    arc_0_5_19  in_degree_844  1
    arc_0_5_19  original_T_including_depot_unload_859  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_566  1
    load_0_5_19  segment_load_conservation_804  1
    load_0_5_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_568  -20
    arc_0_5_20  connected_order_arc_569  -14
    arc_0_5_20  out_degree_800  1
    arc_0_5_20  in_degree_850  1
    arc_0_5_20  original_T_including_depot_unload_859  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_568  1
    load_0_5_20  segment_load_conservation_804  1
    load_0_5_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_570  -20
    arc_0_13_0  depot_return_or_bypass_771  1
    arc_0_13_0  out_degree_807  1
    arc_0_13_0  original_T_including_depot_unload_859  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_570  1
    load_0_13_0  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_571  -20
    arc_0_13_1  connected_order_arc_572  -14
    arc_0_13_1  in_degree_773  1
    arc_0_13_1  out_degree_807  1
    arc_0_13_1  original_T_including_depot_unload_859  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_571  1
    load_0_13_1  segment_load_conservation_776  -1
    load_0_13_1  segment_prefix_lb_777  1
    load_0_13_1  segment_prefix_ub_778  1
    load_0_13_1  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_573  -20
    arc_0_13_2  connected_order_arc_574  -14
    arc_0_13_2  in_degree_780  1
    arc_0_13_2  out_degree_807  1
    arc_0_13_2  original_T_including_depot_unload_859  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_573  1
    load_0_13_2  segment_load_conservation_783  -1
    load_0_13_2  segment_prefix_lb_784  1
    load_0_13_2  segment_prefix_ub_785  1
    load_0_13_2  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_575  -20
    arc_0_13_3  connected_order_arc_576  -14
    arc_0_13_3  in_degree_787  1
    arc_0_13_3  out_degree_807  1
    arc_0_13_3  original_T_including_depot_unload_859  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_575  1
    load_0_13_3  segment_load_conservation_790  -1
    load_0_13_3  segment_prefix_lb_791  1
    load_0_13_3  segment_prefix_ub_792  1
    load_0_13_3  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_577  -20
    arc_0_13_4  connected_order_arc_578  -14
    arc_0_13_4  in_degree_794  1
    arc_0_13_4  out_degree_807  1
    arc_0_13_4  original_T_including_depot_unload_859  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_577  1
    load_0_13_4  segment_load_conservation_797  -1
    load_0_13_4  segment_prefix_lb_798  1
    load_0_13_4  segment_prefix_ub_799  1
    load_0_13_4  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_579  -20
    arc_0_13_5  connected_order_arc_580  -14
    arc_0_13_5  in_degree_801  1
    arc_0_13_5  out_degree_807  1
    arc_0_13_5  original_T_including_depot_unload_859  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_579  1
    load_0_13_5  segment_load_conservation_804  -1
    load_0_13_5  segment_prefix_lb_805  1
    load_0_13_5  segment_prefix_ub_806  1
    load_0_13_5  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_581  -20
    arc_0_13_14  connected_order_arc_582  -14
    arc_0_13_14  out_degree_807  1
    arc_0_13_14  in_degree_814  1
    arc_0_13_14  original_T_including_depot_unload_859  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_581  1
    load_0_13_14  free_load_conservation_812  1
    load_0_13_14  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_583  -20
    arc_0_13_15  connected_order_arc_584  -14
    arc_0_13_15  out_degree_807  1
    arc_0_13_15  in_degree_820  1
    arc_0_13_15  original_T_including_depot_unload_859  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_583  1
    load_0_13_15  free_load_conservation_812  1
    load_0_13_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_585  -20
    arc_0_13_16  connected_order_arc_586  -14
    arc_0_13_16  out_degree_807  1
    arc_0_13_16  in_degree_826  1
    arc_0_13_16  original_T_including_depot_unload_859  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_585  1
    load_0_13_16  free_load_conservation_812  1
    load_0_13_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_587  -20
    arc_0_13_17  connected_order_arc_588  -14
    arc_0_13_17  out_degree_807  1
    arc_0_13_17  in_degree_832  1
    arc_0_13_17  original_T_including_depot_unload_859  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_587  1
    load_0_13_17  free_load_conservation_812  1
    load_0_13_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_589  -20
    arc_0_13_18  connected_order_arc_590  -14
    arc_0_13_18  out_degree_807  1
    arc_0_13_18  in_degree_838  1
    arc_0_13_18  original_T_including_depot_unload_859  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_589  1
    load_0_13_18  free_load_conservation_812  1
    load_0_13_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_591  -20
    arc_0_13_19  connected_order_arc_592  -14
    arc_0_13_19  out_degree_807  1
    arc_0_13_19  in_degree_844  1
    arc_0_13_19  original_T_including_depot_unload_859  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_591  1
    load_0_13_19  free_load_conservation_812  1
    load_0_13_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_593  -20
    arc_0_13_20  connected_order_arc_594  -14
    arc_0_13_20  out_degree_807  1
    arc_0_13_20  in_degree_850  1
    arc_0_13_20  original_T_including_depot_unload_859  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_593  1
    load_0_13_20  free_load_conservation_812  1
    load_0_13_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_595  -20
    arc_0_14_0  depot_return_or_bypass_771  1
    arc_0_14_0  out_degree_813  1
    arc_0_14_0  original_T_including_depot_unload_859  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_595  1
    load_0_14_0  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_596  -20
    arc_0_14_1  connected_order_arc_597  -14
    arc_0_14_1  in_degree_773  1
    arc_0_14_1  out_degree_813  1
    arc_0_14_1  original_T_including_depot_unload_859  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_596  1
    load_0_14_1  segment_load_conservation_776  -1
    load_0_14_1  segment_prefix_lb_777  1
    load_0_14_1  segment_prefix_ub_778  1
    load_0_14_1  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_598  -20
    arc_0_14_2  connected_order_arc_599  -14
    arc_0_14_2  in_degree_780  1
    arc_0_14_2  out_degree_813  1
    arc_0_14_2  original_T_including_depot_unload_859  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_598  1
    load_0_14_2  segment_load_conservation_783  -1
    load_0_14_2  segment_prefix_lb_784  1
    load_0_14_2  segment_prefix_ub_785  1
    load_0_14_2  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_600  -20
    arc_0_14_3  connected_order_arc_601  -14
    arc_0_14_3  in_degree_787  1
    arc_0_14_3  out_degree_813  1
    arc_0_14_3  original_T_including_depot_unload_859  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_600  1
    load_0_14_3  segment_load_conservation_790  -1
    load_0_14_3  segment_prefix_lb_791  1
    load_0_14_3  segment_prefix_ub_792  1
    load_0_14_3  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_602  -20
    arc_0_14_4  connected_order_arc_603  -14
    arc_0_14_4  in_degree_794  1
    arc_0_14_4  out_degree_813  1
    arc_0_14_4  original_T_including_depot_unload_859  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_602  1
    load_0_14_4  segment_load_conservation_797  -1
    load_0_14_4  segment_prefix_lb_798  1
    load_0_14_4  segment_prefix_ub_799  1
    load_0_14_4  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_604  -20
    arc_0_14_5  connected_order_arc_605  -14
    arc_0_14_5  in_degree_801  1
    arc_0_14_5  out_degree_813  1
    arc_0_14_5  original_T_including_depot_unload_859  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_604  1
    load_0_14_5  segment_load_conservation_804  -1
    load_0_14_5  segment_prefix_lb_805  1
    load_0_14_5  segment_prefix_ub_806  1
    load_0_14_5  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_606  -20
    arc_0_14_13  connected_order_arc_607  -14
    arc_0_14_13  in_degree_808  1
    arc_0_14_13  out_degree_813  1
    arc_0_14_13  original_T_including_depot_unload_859  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_606  1
    load_0_14_13  free_load_conservation_812  -1
    load_0_14_13  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_608  -20
    arc_0_14_15  connected_order_arc_609  -14
    arc_0_14_15  out_degree_813  1
    arc_0_14_15  in_degree_820  1
    arc_0_14_15  original_T_including_depot_unload_859  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_608  1
    load_0_14_15  free_load_conservation_818  1
    load_0_14_15  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_610  -20
    arc_0_14_16  connected_order_arc_611  -14
    arc_0_14_16  out_degree_813  1
    arc_0_14_16  in_degree_826  1
    arc_0_14_16  original_T_including_depot_unload_859  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_610  1
    load_0_14_16  free_load_conservation_818  1
    load_0_14_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_612  -20
    arc_0_14_17  connected_order_arc_613  -14
    arc_0_14_17  out_degree_813  1
    arc_0_14_17  in_degree_832  1
    arc_0_14_17  original_T_including_depot_unload_859  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_612  1
    load_0_14_17  free_load_conservation_818  1
    load_0_14_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_614  -20
    arc_0_14_18  connected_order_arc_615  -14
    arc_0_14_18  out_degree_813  1
    arc_0_14_18  in_degree_838  1
    arc_0_14_18  original_T_including_depot_unload_859  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_614  1
    load_0_14_18  free_load_conservation_818  1
    load_0_14_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_616  -20
    arc_0_14_19  connected_order_arc_617  -14
    arc_0_14_19  out_degree_813  1
    arc_0_14_19  in_degree_844  1
    arc_0_14_19  original_T_including_depot_unload_859  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_616  1
    load_0_14_19  free_load_conservation_818  1
    load_0_14_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_618  -20
    arc_0_14_20  connected_order_arc_619  -14
    arc_0_14_20  out_degree_813  1
    arc_0_14_20  in_degree_850  1
    arc_0_14_20  original_T_including_depot_unload_859  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_618  1
    load_0_14_20  free_load_conservation_818  1
    load_0_14_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_620  -20
    arc_0_15_0  depot_return_or_bypass_771  1
    arc_0_15_0  out_degree_819  1
    arc_0_15_0  original_T_including_depot_unload_859  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_620  1
    load_0_15_0  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_621  -20
    arc_0_15_1  connected_order_arc_622  -14
    arc_0_15_1  in_degree_773  1
    arc_0_15_1  out_degree_819  1
    arc_0_15_1  original_T_including_depot_unload_859  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_621  1
    load_0_15_1  segment_load_conservation_776  -1
    load_0_15_1  segment_prefix_lb_777  1
    load_0_15_1  segment_prefix_ub_778  1
    load_0_15_1  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_623  -20
    arc_0_15_2  connected_order_arc_624  -14
    arc_0_15_2  in_degree_780  1
    arc_0_15_2  out_degree_819  1
    arc_0_15_2  original_T_including_depot_unload_859  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_623  1
    load_0_15_2  segment_load_conservation_783  -1
    load_0_15_2  segment_prefix_lb_784  1
    load_0_15_2  segment_prefix_ub_785  1
    load_0_15_2  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_625  -20
    arc_0_15_3  connected_order_arc_626  -14
    arc_0_15_3  in_degree_787  1
    arc_0_15_3  out_degree_819  1
    arc_0_15_3  original_T_including_depot_unload_859  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_625  1
    load_0_15_3  segment_load_conservation_790  -1
    load_0_15_3  segment_prefix_lb_791  1
    load_0_15_3  segment_prefix_ub_792  1
    load_0_15_3  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_627  -20
    arc_0_15_4  connected_order_arc_628  -14
    arc_0_15_4  in_degree_794  1
    arc_0_15_4  out_degree_819  1
    arc_0_15_4  original_T_including_depot_unload_859  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_627  1
    load_0_15_4  segment_load_conservation_797  -1
    load_0_15_4  segment_prefix_lb_798  1
    load_0_15_4  segment_prefix_ub_799  1
    load_0_15_4  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_629  -20
    arc_0_15_5  connected_order_arc_630  -14
    arc_0_15_5  in_degree_801  1
    arc_0_15_5  out_degree_819  1
    arc_0_15_5  original_T_including_depot_unload_859  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_629  1
    load_0_15_5  segment_load_conservation_804  -1
    load_0_15_5  segment_prefix_lb_805  1
    load_0_15_5  segment_prefix_ub_806  1
    load_0_15_5  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_631  -20
    arc_0_15_13  connected_order_arc_632  -14
    arc_0_15_13  in_degree_808  1
    arc_0_15_13  out_degree_819  1
    arc_0_15_13  original_T_including_depot_unload_859  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_631  1
    load_0_15_13  free_load_conservation_812  -1
    load_0_15_13  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_633  -20
    arc_0_15_14  connected_order_arc_634  -14
    arc_0_15_14  in_degree_814  1
    arc_0_15_14  out_degree_819  1
    arc_0_15_14  original_T_including_depot_unload_859  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_633  1
    load_0_15_14  free_load_conservation_818  -1
    load_0_15_14  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_635  -20
    arc_0_15_16  connected_order_arc_636  -14
    arc_0_15_16  out_degree_819  1
    arc_0_15_16  in_degree_826  1
    arc_0_15_16  original_T_including_depot_unload_859  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_635  1
    load_0_15_16  free_load_conservation_824  1
    load_0_15_16  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_637  -20
    arc_0_15_17  connected_order_arc_638  -14
    arc_0_15_17  out_degree_819  1
    arc_0_15_17  in_degree_832  1
    arc_0_15_17  original_T_including_depot_unload_859  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_637  1
    load_0_15_17  free_load_conservation_824  1
    load_0_15_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_639  -20
    arc_0_15_18  connected_order_arc_640  -14
    arc_0_15_18  out_degree_819  1
    arc_0_15_18  in_degree_838  1
    arc_0_15_18  original_T_including_depot_unload_859  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_639  1
    load_0_15_18  free_load_conservation_824  1
    load_0_15_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_641  -20
    arc_0_15_19  connected_order_arc_642  -14
    arc_0_15_19  out_degree_819  1
    arc_0_15_19  in_degree_844  1
    arc_0_15_19  original_T_including_depot_unload_859  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_641  1
    load_0_15_19  free_load_conservation_824  1
    load_0_15_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_643  -20
    arc_0_15_20  connected_order_arc_644  -14
    arc_0_15_20  out_degree_819  1
    arc_0_15_20  in_degree_850  1
    arc_0_15_20  original_T_including_depot_unload_859  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_643  1
    load_0_15_20  free_load_conservation_824  1
    load_0_15_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_645  -20
    arc_0_16_0  depot_return_or_bypass_771  1
    arc_0_16_0  out_degree_825  1
    arc_0_16_0  original_T_including_depot_unload_859  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_645  1
    load_0_16_0  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_646  -20
    arc_0_16_1  connected_order_arc_647  -14
    arc_0_16_1  in_degree_773  1
    arc_0_16_1  out_degree_825  1
    arc_0_16_1  original_T_including_depot_unload_859  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_646  1
    load_0_16_1  segment_load_conservation_776  -1
    load_0_16_1  segment_prefix_lb_777  1
    load_0_16_1  segment_prefix_ub_778  1
    load_0_16_1  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_648  -20
    arc_0_16_2  connected_order_arc_649  -14
    arc_0_16_2  in_degree_780  1
    arc_0_16_2  out_degree_825  1
    arc_0_16_2  original_T_including_depot_unload_859  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_648  1
    load_0_16_2  segment_load_conservation_783  -1
    load_0_16_2  segment_prefix_lb_784  1
    load_0_16_2  segment_prefix_ub_785  1
    load_0_16_2  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_650  -20
    arc_0_16_3  connected_order_arc_651  -14
    arc_0_16_3  in_degree_787  1
    arc_0_16_3  out_degree_825  1
    arc_0_16_3  original_T_including_depot_unload_859  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_650  1
    load_0_16_3  segment_load_conservation_790  -1
    load_0_16_3  segment_prefix_lb_791  1
    load_0_16_3  segment_prefix_ub_792  1
    load_0_16_3  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_652  -20
    arc_0_16_4  connected_order_arc_653  -14
    arc_0_16_4  in_degree_794  1
    arc_0_16_4  out_degree_825  1
    arc_0_16_4  original_T_including_depot_unload_859  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_652  1
    load_0_16_4  segment_load_conservation_797  -1
    load_0_16_4  segment_prefix_lb_798  1
    load_0_16_4  segment_prefix_ub_799  1
    load_0_16_4  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_654  -20
    arc_0_16_5  connected_order_arc_655  -14
    arc_0_16_5  in_degree_801  1
    arc_0_16_5  out_degree_825  1
    arc_0_16_5  original_T_including_depot_unload_859  1.3251252487627862e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_654  1
    load_0_16_5  segment_load_conservation_804  -1
    load_0_16_5  segment_prefix_lb_805  1
    load_0_16_5  segment_prefix_ub_806  1
    load_0_16_5  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_656  -20
    arc_0_16_13  connected_order_arc_657  -14
    arc_0_16_13  in_degree_808  1
    arc_0_16_13  out_degree_825  1
    arc_0_16_13  original_T_including_depot_unload_859  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_656  1
    load_0_16_13  free_load_conservation_812  -1
    load_0_16_13  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_658  -20
    arc_0_16_14  connected_order_arc_659  -14
    arc_0_16_14  in_degree_814  1
    arc_0_16_14  out_degree_825  1
    arc_0_16_14  original_T_including_depot_unload_859  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_658  1
    load_0_16_14  free_load_conservation_818  -1
    load_0_16_14  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_660  -20
    arc_0_16_15  connected_order_arc_661  -14
    arc_0_16_15  in_degree_820  1
    arc_0_16_15  out_degree_825  1
    arc_0_16_15  original_T_including_depot_unload_859  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_660  1
    load_0_16_15  free_load_conservation_824  -1
    load_0_16_15  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_662  -20
    arc_0_16_17  connected_order_arc_663  -14
    arc_0_16_17  out_degree_825  1
    arc_0_16_17  in_degree_832  1
    arc_0_16_17  original_T_including_depot_unload_859  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_662  1
    load_0_16_17  free_load_conservation_830  1
    load_0_16_17  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_664  -20
    arc_0_16_18  connected_order_arc_665  -14
    arc_0_16_18  out_degree_825  1
    arc_0_16_18  in_degree_838  1
    arc_0_16_18  original_T_including_depot_unload_859  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_664  1
    load_0_16_18  free_load_conservation_830  1
    load_0_16_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_666  -20
    arc_0_16_19  connected_order_arc_667  -14
    arc_0_16_19  out_degree_825  1
    arc_0_16_19  in_degree_844  1
    arc_0_16_19  original_T_including_depot_unload_859  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_666  1
    load_0_16_19  free_load_conservation_830  1
    load_0_16_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_668  -20
    arc_0_16_20  connected_order_arc_669  -14
    arc_0_16_20  out_degree_825  1
    arc_0_16_20  in_degree_850  1
    arc_0_16_20  original_T_including_depot_unload_859  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_668  1
    load_0_16_20  free_load_conservation_830  1
    load_0_16_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_670  -20
    arc_0_17_0  depot_return_or_bypass_771  1
    arc_0_17_0  out_degree_831  1
    arc_0_17_0  original_T_including_depot_unload_859  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_670  1
    load_0_17_0  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_671  -20
    arc_0_17_1  connected_order_arc_672  -14
    arc_0_17_1  in_degree_773  1
    arc_0_17_1  out_degree_831  1
    arc_0_17_1  original_T_including_depot_unload_859  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_671  1
    load_0_17_1  segment_load_conservation_776  -1
    load_0_17_1  segment_prefix_lb_777  1
    load_0_17_1  segment_prefix_ub_778  1
    load_0_17_1  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_673  -20
    arc_0_17_2  connected_order_arc_674  -14
    arc_0_17_2  in_degree_780  1
    arc_0_17_2  out_degree_831  1
    arc_0_17_2  original_T_including_depot_unload_859  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_673  1
    load_0_17_2  segment_load_conservation_783  -1
    load_0_17_2  segment_prefix_lb_784  1
    load_0_17_2  segment_prefix_ub_785  1
    load_0_17_2  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_675  -20
    arc_0_17_3  connected_order_arc_676  -14
    arc_0_17_3  in_degree_787  1
    arc_0_17_3  out_degree_831  1
    arc_0_17_3  original_T_including_depot_unload_859  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_675  1
    load_0_17_3  segment_load_conservation_790  -1
    load_0_17_3  segment_prefix_lb_791  1
    load_0_17_3  segment_prefix_ub_792  1
    load_0_17_3  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_677  -20
    arc_0_17_4  connected_order_arc_678  -14
    arc_0_17_4  in_degree_794  1
    arc_0_17_4  out_degree_831  1
    arc_0_17_4  original_T_including_depot_unload_859  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_677  1
    load_0_17_4  segment_load_conservation_797  -1
    load_0_17_4  segment_prefix_lb_798  1
    load_0_17_4  segment_prefix_ub_799  1
    load_0_17_4  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_679  -20
    arc_0_17_5  connected_order_arc_680  -14
    arc_0_17_5  in_degree_801  1
    arc_0_17_5  out_degree_831  1
    arc_0_17_5  original_T_including_depot_unload_859  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_679  1
    load_0_17_5  segment_load_conservation_804  -1
    load_0_17_5  segment_prefix_lb_805  1
    load_0_17_5  segment_prefix_ub_806  1
    load_0_17_5  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_681  -20
    arc_0_17_13  connected_order_arc_682  -14
    arc_0_17_13  in_degree_808  1
    arc_0_17_13  out_degree_831  1
    arc_0_17_13  original_T_including_depot_unload_859  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_681  1
    load_0_17_13  free_load_conservation_812  -1
    load_0_17_13  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_683  -20
    arc_0_17_14  connected_order_arc_684  -14
    arc_0_17_14  in_degree_814  1
    arc_0_17_14  out_degree_831  1
    arc_0_17_14  original_T_including_depot_unload_859  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_683  1
    load_0_17_14  free_load_conservation_818  -1
    load_0_17_14  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_685  -20
    arc_0_17_15  connected_order_arc_686  -14
    arc_0_17_15  in_degree_820  1
    arc_0_17_15  out_degree_831  1
    arc_0_17_15  original_T_including_depot_unload_859  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_685  1
    load_0_17_15  free_load_conservation_824  -1
    load_0_17_15  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_687  -20
    arc_0_17_16  connected_order_arc_688  -14
    arc_0_17_16  in_degree_826  1
    arc_0_17_16  out_degree_831  1
    arc_0_17_16  original_T_including_depot_unload_859  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_687  1
    load_0_17_16  free_load_conservation_830  -1
    load_0_17_16  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_689  -20
    arc_0_17_18  connected_order_arc_690  -14
    arc_0_17_18  out_degree_831  1
    arc_0_17_18  in_degree_838  1
    arc_0_17_18  original_T_including_depot_unload_859  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_689  1
    load_0_17_18  free_load_conservation_836  1
    load_0_17_18  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_691  -20
    arc_0_17_19  connected_order_arc_692  -14
    arc_0_17_19  out_degree_831  1
    arc_0_17_19  in_degree_844  1
    arc_0_17_19  original_T_including_depot_unload_859  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_691  1
    load_0_17_19  free_load_conservation_836  1
    load_0_17_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_693  -20
    arc_0_17_20  connected_order_arc_694  -14
    arc_0_17_20  out_degree_831  1
    arc_0_17_20  in_degree_850  1
    arc_0_17_20  original_T_including_depot_unload_859  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_693  1
    load_0_17_20  free_load_conservation_836  1
    load_0_17_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_695  -20
    arc_0_18_0  depot_return_or_bypass_771  1
    arc_0_18_0  out_degree_837  1
    arc_0_18_0  original_T_including_depot_unload_859  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_695  1
    load_0_18_0  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_696  -20
    arc_0_18_1  connected_order_arc_697  -14
    arc_0_18_1  in_degree_773  1
    arc_0_18_1  out_degree_837  1
    arc_0_18_1  original_T_including_depot_unload_859  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_696  1
    load_0_18_1  segment_load_conservation_776  -1
    load_0_18_1  segment_prefix_lb_777  1
    load_0_18_1  segment_prefix_ub_778  1
    load_0_18_1  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_698  -20
    arc_0_18_2  connected_order_arc_699  -14
    arc_0_18_2  in_degree_780  1
    arc_0_18_2  out_degree_837  1
    arc_0_18_2  original_T_including_depot_unload_859  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_698  1
    load_0_18_2  segment_load_conservation_783  -1
    load_0_18_2  segment_prefix_lb_784  1
    load_0_18_2  segment_prefix_ub_785  1
    load_0_18_2  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_700  -20
    arc_0_18_3  connected_order_arc_701  -14
    arc_0_18_3  in_degree_787  1
    arc_0_18_3  out_degree_837  1
    arc_0_18_3  original_T_including_depot_unload_859  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_700  1
    load_0_18_3  segment_load_conservation_790  -1
    load_0_18_3  segment_prefix_lb_791  1
    load_0_18_3  segment_prefix_ub_792  1
    load_0_18_3  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_702  -20
    arc_0_18_4  connected_order_arc_703  -14
    arc_0_18_4  in_degree_794  1
    arc_0_18_4  out_degree_837  1
    arc_0_18_4  original_T_including_depot_unload_859  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_702  1
    load_0_18_4  segment_load_conservation_797  -1
    load_0_18_4  segment_prefix_lb_798  1
    load_0_18_4  segment_prefix_ub_799  1
    load_0_18_4  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_704  -20
    arc_0_18_5  connected_order_arc_705  -14
    arc_0_18_5  in_degree_801  1
    arc_0_18_5  out_degree_837  1
    arc_0_18_5  original_T_including_depot_unload_859  1.4099802576911704e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_704  1
    load_0_18_5  segment_load_conservation_804  -1
    load_0_18_5  segment_prefix_lb_805  1
    load_0_18_5  segment_prefix_ub_806  1
    load_0_18_5  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_706  -20
    arc_0_18_13  connected_order_arc_707  -14
    arc_0_18_13  in_degree_808  1
    arc_0_18_13  out_degree_837  1
    arc_0_18_13  original_T_including_depot_unload_859  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_706  1
    load_0_18_13  free_load_conservation_812  -1
    load_0_18_13  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_708  -20
    arc_0_18_14  connected_order_arc_709  -14
    arc_0_18_14  in_degree_814  1
    arc_0_18_14  out_degree_837  1
    arc_0_18_14  original_T_including_depot_unload_859  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_708  1
    load_0_18_14  free_load_conservation_818  -1
    load_0_18_14  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_710  -20
    arc_0_18_15  connected_order_arc_711  -14
    arc_0_18_15  in_degree_820  1
    arc_0_18_15  out_degree_837  1
    arc_0_18_15  original_T_including_depot_unload_859  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_710  1
    load_0_18_15  free_load_conservation_824  -1
    load_0_18_15  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_712  -20
    arc_0_18_16  connected_order_arc_713  -14
    arc_0_18_16  in_degree_826  1
    arc_0_18_16  out_degree_837  1
    arc_0_18_16  original_T_including_depot_unload_859  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_712  1
    load_0_18_16  free_load_conservation_830  -1
    load_0_18_16  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_714  -20
    arc_0_18_17  connected_order_arc_715  -14
    arc_0_18_17  in_degree_832  1
    arc_0_18_17  out_degree_837  1
    arc_0_18_17  original_T_including_depot_unload_859  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_714  1
    load_0_18_17  free_load_conservation_836  -1
    load_0_18_17  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_716  -20
    arc_0_18_19  connected_order_arc_717  -14
    arc_0_18_19  out_degree_837  1
    arc_0_18_19  in_degree_844  1
    arc_0_18_19  original_T_including_depot_unload_859  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_716  1
    load_0_18_19  free_load_conservation_842  1
    load_0_18_19  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_718  -20
    arc_0_18_20  connected_order_arc_719  -14
    arc_0_18_20  out_degree_837  1
    arc_0_18_20  in_degree_850  1
    arc_0_18_20  original_T_including_depot_unload_859  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_718  1
    load_0_18_20  free_load_conservation_842  1
    load_0_18_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_720  -20
    arc_0_19_0  depot_return_or_bypass_771  1
    arc_0_19_0  out_degree_843  1
    arc_0_19_0  original_T_including_depot_unload_859  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_720  1
    load_0_19_0  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_721  -20
    arc_0_19_1  connected_order_arc_722  -14
    arc_0_19_1  in_degree_773  1
    arc_0_19_1  out_degree_843  1
    arc_0_19_1  original_T_including_depot_unload_859  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_721  1
    load_0_19_1  segment_load_conservation_776  -1
    load_0_19_1  segment_prefix_lb_777  1
    load_0_19_1  segment_prefix_ub_778  1
    load_0_19_1  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_723  -20
    arc_0_19_2  connected_order_arc_724  -14
    arc_0_19_2  in_degree_780  1
    arc_0_19_2  out_degree_843  1
    arc_0_19_2  original_T_including_depot_unload_859  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_723  1
    load_0_19_2  segment_load_conservation_783  -1
    load_0_19_2  segment_prefix_lb_784  1
    load_0_19_2  segment_prefix_ub_785  1
    load_0_19_2  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_725  -20
    arc_0_19_3  connected_order_arc_726  -14
    arc_0_19_3  in_degree_787  1
    arc_0_19_3  out_degree_843  1
    arc_0_19_3  original_T_including_depot_unload_859  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_725  1
    load_0_19_3  segment_load_conservation_790  -1
    load_0_19_3  segment_prefix_lb_791  1
    load_0_19_3  segment_prefix_ub_792  1
    load_0_19_3  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_727  -20
    arc_0_19_4  connected_order_arc_728  -14
    arc_0_19_4  in_degree_794  1
    arc_0_19_4  out_degree_843  1
    arc_0_19_4  original_T_including_depot_unload_859  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_727  1
    load_0_19_4  segment_load_conservation_797  -1
    load_0_19_4  segment_prefix_lb_798  1
    load_0_19_4  segment_prefix_ub_799  1
    load_0_19_4  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_729  -20
    arc_0_19_5  connected_order_arc_730  -14
    arc_0_19_5  in_degree_801  1
    arc_0_19_5  out_degree_843  1
    arc_0_19_5  original_T_including_depot_unload_859  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_729  1
    load_0_19_5  segment_load_conservation_804  -1
    load_0_19_5  segment_prefix_lb_805  1
    load_0_19_5  segment_prefix_ub_806  1
    load_0_19_5  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_731  -20
    arc_0_19_13  connected_order_arc_732  -14
    arc_0_19_13  in_degree_808  1
    arc_0_19_13  out_degree_843  1
    arc_0_19_13  original_T_including_depot_unload_859  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_731  1
    load_0_19_13  free_load_conservation_812  -1
    load_0_19_13  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_733  -20
    arc_0_19_14  connected_order_arc_734  -14
    arc_0_19_14  in_degree_814  1
    arc_0_19_14  out_degree_843  1
    arc_0_19_14  original_T_including_depot_unload_859  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_733  1
    load_0_19_14  free_load_conservation_818  -1
    load_0_19_14  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_735  -20
    arc_0_19_15  connected_order_arc_736  -14
    arc_0_19_15  in_degree_820  1
    arc_0_19_15  out_degree_843  1
    arc_0_19_15  original_T_including_depot_unload_859  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_735  1
    load_0_19_15  free_load_conservation_824  -1
    load_0_19_15  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_737  -20
    arc_0_19_16  connected_order_arc_738  -14
    arc_0_19_16  in_degree_826  1
    arc_0_19_16  out_degree_843  1
    arc_0_19_16  original_T_including_depot_unload_859  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_737  1
    load_0_19_16  free_load_conservation_830  -1
    load_0_19_16  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_739  -20
    arc_0_19_17  connected_order_arc_740  -14
    arc_0_19_17  in_degree_832  1
    arc_0_19_17  out_degree_843  1
    arc_0_19_17  original_T_including_depot_unload_859  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_739  1
    load_0_19_17  free_load_conservation_836  -1
    load_0_19_17  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_741  -20
    arc_0_19_18  connected_order_arc_742  -14
    arc_0_19_18  in_degree_838  1
    arc_0_19_18  out_degree_843  1
    arc_0_19_18  original_T_including_depot_unload_859  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_741  1
    load_0_19_18  free_load_conservation_842  -1
    load_0_19_18  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_743  -20
    arc_0_19_20  connected_order_arc_744  -14
    arc_0_19_20  out_degree_843  1
    arc_0_19_20  in_degree_850  1
    arc_0_19_20  original_T_including_depot_unload_859  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_743  1
    load_0_19_20  free_load_conservation_848  1
    load_0_19_20  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_745  -20
    arc_0_20_0  depot_return_or_bypass_771  1
    arc_0_20_0  out_degree_849  1
    arc_0_20_0  original_T_including_depot_unload_859  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_745  1
    load_0_20_0  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_746  -20
    arc_0_20_1  connected_order_arc_747  -14
    arc_0_20_1  in_degree_773  1
    arc_0_20_1  out_degree_849  1
    arc_0_20_1  original_T_including_depot_unload_859  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_746  1
    load_0_20_1  segment_load_conservation_776  -1
    load_0_20_1  segment_prefix_lb_777  1
    load_0_20_1  segment_prefix_ub_778  1
    load_0_20_1  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_748  -20
    arc_0_20_2  connected_order_arc_749  -14
    arc_0_20_2  in_degree_780  1
    arc_0_20_2  out_degree_849  1
    arc_0_20_2  original_T_including_depot_unload_859  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_748  1
    load_0_20_2  segment_load_conservation_783  -1
    load_0_20_2  segment_prefix_lb_784  1
    load_0_20_2  segment_prefix_ub_785  1
    load_0_20_2  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_750  -20
    arc_0_20_3  connected_order_arc_751  -14
    arc_0_20_3  in_degree_787  1
    arc_0_20_3  out_degree_849  1
    arc_0_20_3  original_T_including_depot_unload_859  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_750  1
    load_0_20_3  segment_load_conservation_790  -1
    load_0_20_3  segment_prefix_lb_791  1
    load_0_20_3  segment_prefix_ub_792  1
    load_0_20_3  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_752  -20
    arc_0_20_4  connected_order_arc_753  -14
    arc_0_20_4  in_degree_794  1
    arc_0_20_4  out_degree_849  1
    arc_0_20_4  original_T_including_depot_unload_859  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_752  1
    load_0_20_4  segment_load_conservation_797  -1
    load_0_20_4  segment_prefix_lb_798  1
    load_0_20_4  segment_prefix_ub_799  1
    load_0_20_4  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_754  -20
    arc_0_20_5  connected_order_arc_755  -14
    arc_0_20_5  in_degree_801  1
    arc_0_20_5  out_degree_849  1
    arc_0_20_5  original_T_including_depot_unload_859  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_754  1
    load_0_20_5  segment_load_conservation_804  -1
    load_0_20_5  segment_prefix_lb_805  1
    load_0_20_5  segment_prefix_ub_806  1
    load_0_20_5  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_756  -20
    arc_0_20_13  connected_order_arc_757  -14
    arc_0_20_13  in_degree_808  1
    arc_0_20_13  out_degree_849  1
    arc_0_20_13  original_T_including_depot_unload_859  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_756  1
    load_0_20_13  free_load_conservation_812  -1
    load_0_20_13  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_758  -20
    arc_0_20_14  connected_order_arc_759  -14
    arc_0_20_14  in_degree_814  1
    arc_0_20_14  out_degree_849  1
    arc_0_20_14  original_T_including_depot_unload_859  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_758  1
    load_0_20_14  free_load_conservation_818  -1
    load_0_20_14  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_760  -20
    arc_0_20_15  connected_order_arc_761  -14
    arc_0_20_15  in_degree_820  1
    arc_0_20_15  out_degree_849  1
    arc_0_20_15  original_T_including_depot_unload_859  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_760  1
    load_0_20_15  free_load_conservation_824  -1
    load_0_20_15  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_762  -20
    arc_0_20_16  connected_order_arc_763  -14
    arc_0_20_16  in_degree_826  1
    arc_0_20_16  out_degree_849  1
    arc_0_20_16  original_T_including_depot_unload_859  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_762  1
    load_0_20_16  free_load_conservation_830  -1
    load_0_20_16  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_764  -20
    arc_0_20_17  connected_order_arc_765  -14
    arc_0_20_17  in_degree_832  1
    arc_0_20_17  out_degree_849  1
    arc_0_20_17  original_T_including_depot_unload_859  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_764  1
    load_0_20_17  free_load_conservation_836  -1
    load_0_20_17  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_766  -20
    arc_0_20_18  connected_order_arc_767  -14
    arc_0_20_18  in_degree_838  1
    arc_0_20_18  out_degree_849  1
    arc_0_20_18  original_T_including_depot_unload_859  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_766  1
    load_0_20_18  free_load_conservation_842  -1
    load_0_20_18  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_768  -20
    arc_0_20_19  connected_order_arc_769  -14
    arc_0_20_19  in_degree_844  1
    arc_0_20_19  out_degree_849  1
    arc_0_20_19  original_T_including_depot_unload_859  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_768  1
    load_0_20_19  free_load_conservation_848  -1
    load_0_20_19  free_load_conservation_854  1
    visit_1_6  out_degree_1151  -1
    visit_1_6  in_degree_1152  -1
    visit_1_6  order_active_lb_1153  -1
    visit_1_6  order_active_ub_1154  -12
    order_1_6  connected_order_arc_875  -1
    order_1_6  connected_order_arc_877  -1
    order_1_6  connected_order_arc_879  -1
    order_1_6  connected_order_arc_881  -1
    order_1_6  connected_order_arc_883  -1
    order_1_6  connected_order_arc_885  -1
    order_1_6  connected_order_arc_887  -1
    order_1_6  connected_order_arc_889  -1
    order_1_6  connected_order_arc_891  -1
    order_1_6  connected_order_arc_893  -1
    order_1_6  connected_order_arc_895  -1
    order_1_6  connected_order_arc_898  1
    order_1_6  connected_order_arc_921  1
    order_1_6  connected_order_arc_944  1
    order_1_6  connected_order_arc_967  1
    order_1_6  connected_order_arc_990  1
    order_1_6  connected_order_arc_1013  1
    order_1_6  connected_order_arc_1036  1
    order_1_6  connected_order_arc_1059  1
    order_1_6  connected_order_arc_1082  1
    order_1_6  connected_order_arc_1105  1
    order_1_6  connected_order_arc_1128  1
    order_1_6  order_active_lb_1153  1
    order_1_6  order_active_ub_1154  1
    order_1_6  fixed_segment_relative_order_1227  -1
    visit_1_7  out_degree_1158  -1
    visit_1_7  in_degree_1159  -1
    visit_1_7  order_active_lb_1160  -1
    visit_1_7  order_active_ub_1161  -12
    order_1_7  connected_order_arc_875  1
    order_1_7  connected_order_arc_898  -1
    order_1_7  connected_order_arc_900  -1
    order_1_7  connected_order_arc_902  -1
    order_1_7  connected_order_arc_904  -1
    order_1_7  connected_order_arc_906  -1
    order_1_7  connected_order_arc_908  -1
    order_1_7  connected_order_arc_910  -1
    order_1_7  connected_order_arc_912  -1
    order_1_7  connected_order_arc_914  -1
    order_1_7  connected_order_arc_916  -1
    order_1_7  connected_order_arc_918  -1
    order_1_7  connected_order_arc_923  1
    order_1_7  connected_order_arc_946  1
    order_1_7  connected_order_arc_969  1
    order_1_7  connected_order_arc_992  1
    order_1_7  connected_order_arc_1015  1
    order_1_7  connected_order_arc_1038  1
    order_1_7  connected_order_arc_1061  1
    order_1_7  connected_order_arc_1084  1
    order_1_7  connected_order_arc_1107  1
    order_1_7  connected_order_arc_1130  1
    order_1_7  order_active_lb_1160  1
    order_1_7  order_active_ub_1161  1
    order_1_7  fixed_segment_relative_order_1227  1
    order_1_7  fixed_segment_relative_order_1228  -1
    visit_1_8  out_degree_1165  -1
    visit_1_8  in_degree_1166  -1
    visit_1_8  order_active_lb_1167  -1
    visit_1_8  order_active_ub_1168  -12
    order_1_8  connected_order_arc_877  1
    order_1_8  connected_order_arc_900  1
    order_1_8  connected_order_arc_921  -1
    order_1_8  connected_order_arc_923  -1
    order_1_8  connected_order_arc_925  -1
    order_1_8  connected_order_arc_927  -1
    order_1_8  connected_order_arc_929  -1
    order_1_8  connected_order_arc_931  -1
    order_1_8  connected_order_arc_933  -1
    order_1_8  connected_order_arc_935  -1
    order_1_8  connected_order_arc_937  -1
    order_1_8  connected_order_arc_939  -1
    order_1_8  connected_order_arc_941  -1
    order_1_8  connected_order_arc_948  1
    order_1_8  connected_order_arc_971  1
    order_1_8  connected_order_arc_994  1
    order_1_8  connected_order_arc_1017  1
    order_1_8  connected_order_arc_1040  1
    order_1_8  connected_order_arc_1063  1
    order_1_8  connected_order_arc_1086  1
    order_1_8  connected_order_arc_1109  1
    order_1_8  connected_order_arc_1132  1
    order_1_8  order_active_lb_1167  1
    order_1_8  order_active_ub_1168  1
    order_1_8  fixed_segment_relative_order_1228  1
    order_1_8  fixed_segment_relative_order_1229  -1
    visit_1_9  out_degree_1172  -1
    visit_1_9  in_degree_1173  -1
    visit_1_9  order_active_lb_1174  -1
    visit_1_9  order_active_ub_1175  -12
    order_1_9  connected_order_arc_879  1
    order_1_9  connected_order_arc_902  1
    order_1_9  connected_order_arc_925  1
    order_1_9  connected_order_arc_944  -1
    order_1_9  connected_order_arc_946  -1
    order_1_9  connected_order_arc_948  -1
    order_1_9  connected_order_arc_950  -1
    order_1_9  connected_order_arc_952  -1
    order_1_9  connected_order_arc_954  -1
    order_1_9  connected_order_arc_956  -1
    order_1_9  connected_order_arc_958  -1
    order_1_9  connected_order_arc_960  -1
    order_1_9  connected_order_arc_962  -1
    order_1_9  connected_order_arc_964  -1
    order_1_9  connected_order_arc_973  1
    order_1_9  connected_order_arc_996  1
    order_1_9  connected_order_arc_1019  1
    order_1_9  connected_order_arc_1042  1
    order_1_9  connected_order_arc_1065  1
    order_1_9  connected_order_arc_1088  1
    order_1_9  connected_order_arc_1111  1
    order_1_9  connected_order_arc_1134  1
    order_1_9  order_active_lb_1174  1
    order_1_9  order_active_ub_1175  1
    order_1_9  fixed_segment_relative_order_1229  1
    visit_1_13  out_degree_1179  -1
    visit_1_13  in_degree_1180  -1
    visit_1_13  order_active_lb_1181  -1
    visit_1_13  order_active_ub_1182  -12
    visit_1_13  service_visit_def_1183  -1
    order_1_13  connected_order_arc_881  1
    order_1_13  connected_order_arc_904  1
    order_1_13  connected_order_arc_927  1
    order_1_13  connected_order_arc_950  1
    order_1_13  connected_order_arc_967  -1
    order_1_13  connected_order_arc_969  -1
    order_1_13  connected_order_arc_971  -1
    order_1_13  connected_order_arc_973  -1
    order_1_13  connected_order_arc_975  -1
    order_1_13  connected_order_arc_977  -1
    order_1_13  connected_order_arc_979  -1
    order_1_13  connected_order_arc_981  -1
    order_1_13  connected_order_arc_983  -1
    order_1_13  connected_order_arc_985  -1
    order_1_13  connected_order_arc_987  -1
    order_1_13  connected_order_arc_998  1
    order_1_13  connected_order_arc_1021  1
    order_1_13  connected_order_arc_1044  1
    order_1_13  connected_order_arc_1067  1
    order_1_13  connected_order_arc_1090  1
    order_1_13  connected_order_arc_1113  1
    order_1_13  connected_order_arc_1136  1
    order_1_13  order_active_lb_1181  1
    order_1_13  order_active_ub_1182  1
    visit_1_14  out_degree_1185  -1
    visit_1_14  in_degree_1186  -1
    visit_1_14  order_active_lb_1187  -1
    visit_1_14  order_active_ub_1188  -12
    visit_1_14  service_visit_def_1189  -1
    order_1_14  connected_order_arc_883  1
    order_1_14  connected_order_arc_906  1
    order_1_14  connected_order_arc_929  1
    order_1_14  connected_order_arc_952  1
    order_1_14  connected_order_arc_975  1
    order_1_14  connected_order_arc_990  -1
    order_1_14  connected_order_arc_992  -1
    order_1_14  connected_order_arc_994  -1
    order_1_14  connected_order_arc_996  -1
    order_1_14  connected_order_arc_998  -1
    order_1_14  connected_order_arc_1000  -1
    order_1_14  connected_order_arc_1002  -1
    order_1_14  connected_order_arc_1004  -1
    order_1_14  connected_order_arc_1006  -1
    order_1_14  connected_order_arc_1008  -1
    order_1_14  connected_order_arc_1010  -1
    order_1_14  connected_order_arc_1023  1
    order_1_14  connected_order_arc_1046  1
    order_1_14  connected_order_arc_1069  1
    order_1_14  connected_order_arc_1092  1
    order_1_14  connected_order_arc_1115  1
    order_1_14  connected_order_arc_1138  1
    order_1_14  order_active_lb_1187  1
    order_1_14  order_active_ub_1188  1
    visit_1_15  out_degree_1191  -1
    visit_1_15  in_degree_1192  -1
    visit_1_15  order_active_lb_1193  -1
    visit_1_15  order_active_ub_1194  -12
    visit_1_15  service_visit_def_1195  -1
    order_1_15  connected_order_arc_885  1
    order_1_15  connected_order_arc_908  1
    order_1_15  connected_order_arc_931  1
    order_1_15  connected_order_arc_954  1
    order_1_15  connected_order_arc_977  1
    order_1_15  connected_order_arc_1000  1
    order_1_15  connected_order_arc_1013  -1
    order_1_15  connected_order_arc_1015  -1
    order_1_15  connected_order_arc_1017  -1
    order_1_15  connected_order_arc_1019  -1
    order_1_15  connected_order_arc_1021  -1
    order_1_15  connected_order_arc_1023  -1
    order_1_15  connected_order_arc_1025  -1
    order_1_15  connected_order_arc_1027  -1
    order_1_15  connected_order_arc_1029  -1
    order_1_15  connected_order_arc_1031  -1
    order_1_15  connected_order_arc_1033  -1
    order_1_15  connected_order_arc_1048  1
    order_1_15  connected_order_arc_1071  1
    order_1_15  connected_order_arc_1094  1
    order_1_15  connected_order_arc_1117  1
    order_1_15  connected_order_arc_1140  1
    order_1_15  order_active_lb_1193  1
    order_1_15  order_active_ub_1194  1
    visit_1_16  out_degree_1197  -1
    visit_1_16  in_degree_1198  -1
    visit_1_16  order_active_lb_1199  -1
    visit_1_16  order_active_ub_1200  -12
    visit_1_16  service_visit_def_1201  -1
    order_1_16  connected_order_arc_887  1
    order_1_16  connected_order_arc_910  1
    order_1_16  connected_order_arc_933  1
    order_1_16  connected_order_arc_956  1
    order_1_16  connected_order_arc_979  1
    order_1_16  connected_order_arc_1002  1
    order_1_16  connected_order_arc_1025  1
    order_1_16  connected_order_arc_1036  -1
    order_1_16  connected_order_arc_1038  -1
    order_1_16  connected_order_arc_1040  -1
    order_1_16  connected_order_arc_1042  -1
    order_1_16  connected_order_arc_1044  -1
    order_1_16  connected_order_arc_1046  -1
    order_1_16  connected_order_arc_1048  -1
    order_1_16  connected_order_arc_1050  -1
    order_1_16  connected_order_arc_1052  -1
    order_1_16  connected_order_arc_1054  -1
    order_1_16  connected_order_arc_1056  -1
    order_1_16  connected_order_arc_1073  1
    order_1_16  connected_order_arc_1096  1
    order_1_16  connected_order_arc_1119  1
    order_1_16  connected_order_arc_1142  1
    order_1_16  order_active_lb_1199  1
    order_1_16  order_active_ub_1200  1
    visit_1_17  out_degree_1203  -1
    visit_1_17  in_degree_1204  -1
    visit_1_17  order_active_lb_1205  -1
    visit_1_17  order_active_ub_1206  -12
    visit_1_17  service_visit_def_1207  -1
    order_1_17  connected_order_arc_889  1
    order_1_17  connected_order_arc_912  1
    order_1_17  connected_order_arc_935  1
    order_1_17  connected_order_arc_958  1
    order_1_17  connected_order_arc_981  1
    order_1_17  connected_order_arc_1004  1
    order_1_17  connected_order_arc_1027  1
    order_1_17  connected_order_arc_1050  1
    order_1_17  connected_order_arc_1059  -1
    order_1_17  connected_order_arc_1061  -1
    order_1_17  connected_order_arc_1063  -1
    order_1_17  connected_order_arc_1065  -1
    order_1_17  connected_order_arc_1067  -1
    order_1_17  connected_order_arc_1069  -1
    order_1_17  connected_order_arc_1071  -1
    order_1_17  connected_order_arc_1073  -1
    order_1_17  connected_order_arc_1075  -1
    order_1_17  connected_order_arc_1077  -1
    order_1_17  connected_order_arc_1079  -1
    order_1_17  connected_order_arc_1098  1
    order_1_17  connected_order_arc_1121  1
    order_1_17  connected_order_arc_1144  1
    order_1_17  order_active_lb_1205  1
    order_1_17  order_active_ub_1206  1
    visit_1_18  out_degree_1209  -1
    visit_1_18  in_degree_1210  -1
    visit_1_18  order_active_lb_1211  -1
    visit_1_18  order_active_ub_1212  -12
    visit_1_18  service_visit_def_1213  -1
    order_1_18  connected_order_arc_891  1
    order_1_18  connected_order_arc_914  1
    order_1_18  connected_order_arc_937  1
    order_1_18  connected_order_arc_960  1
    order_1_18  connected_order_arc_983  1
    order_1_18  connected_order_arc_1006  1
    order_1_18  connected_order_arc_1029  1
    order_1_18  connected_order_arc_1052  1
    order_1_18  connected_order_arc_1075  1
    order_1_18  connected_order_arc_1082  -1
    order_1_18  connected_order_arc_1084  -1
    order_1_18  connected_order_arc_1086  -1
    order_1_18  connected_order_arc_1088  -1
    order_1_18  connected_order_arc_1090  -1
    order_1_18  connected_order_arc_1092  -1
    order_1_18  connected_order_arc_1094  -1
    order_1_18  connected_order_arc_1096  -1
    order_1_18  connected_order_arc_1098  -1
    order_1_18  connected_order_arc_1100  -1
    order_1_18  connected_order_arc_1102  -1
    order_1_18  connected_order_arc_1123  1
    order_1_18  connected_order_arc_1146  1
    order_1_18  order_active_lb_1211  1
    order_1_18  order_active_ub_1212  1
    visit_1_19  out_degree_1215  -1
    visit_1_19  in_degree_1216  -1
    visit_1_19  order_active_lb_1217  -1
    visit_1_19  order_active_ub_1218  -12
    visit_1_19  service_visit_def_1219  -1
    order_1_19  connected_order_arc_893  1
    order_1_19  connected_order_arc_916  1
    order_1_19  connected_order_arc_939  1
    order_1_19  connected_order_arc_962  1
    order_1_19  connected_order_arc_985  1
    order_1_19  connected_order_arc_1008  1
    order_1_19  connected_order_arc_1031  1
    order_1_19  connected_order_arc_1054  1
    order_1_19  connected_order_arc_1077  1
    order_1_19  connected_order_arc_1100  1
    order_1_19  connected_order_arc_1105  -1
    order_1_19  connected_order_arc_1107  -1
    order_1_19  connected_order_arc_1109  -1
    order_1_19  connected_order_arc_1111  -1
    order_1_19  connected_order_arc_1113  -1
    order_1_19  connected_order_arc_1115  -1
    order_1_19  connected_order_arc_1117  -1
    order_1_19  connected_order_arc_1119  -1
    order_1_19  connected_order_arc_1121  -1
    order_1_19  connected_order_arc_1123  -1
    order_1_19  connected_order_arc_1125  -1
    order_1_19  connected_order_arc_1148  1
    order_1_19  order_active_lb_1217  1
    order_1_19  order_active_ub_1218  1
    visit_1_20  out_degree_1221  -1
    visit_1_20  in_degree_1222  -1
    visit_1_20  order_active_lb_1223  -1
    visit_1_20  order_active_ub_1224  -12
    visit_1_20  service_visit_def_1225  -1
    order_1_20  connected_order_arc_895  1
    order_1_20  connected_order_arc_918  1
    order_1_20  connected_order_arc_941  1
    order_1_20  connected_order_arc_964  1
    order_1_20  connected_order_arc_987  1
    order_1_20  connected_order_arc_1010  1
    order_1_20  connected_order_arc_1033  1
    order_1_20  connected_order_arc_1056  1
    order_1_20  connected_order_arc_1079  1
    order_1_20  connected_order_arc_1102  1
    order_1_20  connected_order_arc_1125  1
    order_1_20  connected_order_arc_1128  -1
    order_1_20  connected_order_arc_1130  -1
    order_1_20  connected_order_arc_1132  -1
    order_1_20  connected_order_arc_1134  -1
    order_1_20  connected_order_arc_1136  -1
    order_1_20  connected_order_arc_1138  -1
    order_1_20  connected_order_arc_1140  -1
    order_1_20  connected_order_arc_1142  -1
    order_1_20  connected_order_arc_1144  -1
    order_1_20  connected_order_arc_1146  -1
    order_1_20  connected_order_arc_1148  -1
    order_1_20  order_active_lb_1223  1
    order_1_20  order_active_ub_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_860  -25
    arc_1_0_0  depot_departure_or_bypass_1149  1
    arc_1_0_0  depot_return_or_bypass_1150  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_861  -25
    arc_1_0_6  depot_departure_or_bypass_1149  1
    arc_1_0_6  in_degree_1152  1
    arc_1_0_6  original_T_including_depot_unload_1230  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_861  1
    load_1_0_6  segment_load_conservation_1155  -1
    load_1_0_6  segment_prefix_lb_1156  1
    load_1_0_6  segment_prefix_ub_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_862  -25
    arc_1_0_7  depot_departure_or_bypass_1149  1
    arc_1_0_7  in_degree_1159  1
    arc_1_0_7  original_T_including_depot_unload_1230  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_862  1
    load_1_0_7  segment_load_conservation_1162  -1
    load_1_0_7  segment_prefix_lb_1163  1
    load_1_0_7  segment_prefix_ub_1164  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_863  -25
    arc_1_0_8  depot_departure_or_bypass_1149  1
    arc_1_0_8  in_degree_1166  1
    arc_1_0_8  original_T_including_depot_unload_1230  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_863  1
    load_1_0_8  segment_load_conservation_1169  -1
    load_1_0_8  segment_prefix_lb_1170  1
    load_1_0_8  segment_prefix_ub_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_864  -25
    arc_1_0_9  depot_departure_or_bypass_1149  1
    arc_1_0_9  in_degree_1173  1
    arc_1_0_9  original_T_including_depot_unload_1230  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_864  1
    load_1_0_9  segment_load_conservation_1176  -1
    load_1_0_9  segment_prefix_lb_1177  1
    load_1_0_9  segment_prefix_ub_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_865  -25
    arc_1_0_13  depot_departure_or_bypass_1149  1
    arc_1_0_13  in_degree_1180  1
    arc_1_0_13  original_T_including_depot_unload_1230  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_865  1
    load_1_0_13  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_866  -25
    arc_1_0_14  depot_departure_or_bypass_1149  1
    arc_1_0_14  in_degree_1186  1
    arc_1_0_14  original_T_including_depot_unload_1230  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_866  1
    load_1_0_14  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_867  -25
    arc_1_0_15  depot_departure_or_bypass_1149  1
    arc_1_0_15  in_degree_1192  1
    arc_1_0_15  original_T_including_depot_unload_1230  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_867  1
    load_1_0_15  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_868  -25
    arc_1_0_16  depot_departure_or_bypass_1149  1
    arc_1_0_16  in_degree_1198  1
    arc_1_0_16  original_T_including_depot_unload_1230  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_868  1
    load_1_0_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_869  -25
    arc_1_0_17  depot_departure_or_bypass_1149  1
    arc_1_0_17  in_degree_1204  1
    arc_1_0_17  original_T_including_depot_unload_1230  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_869  1
    load_1_0_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_870  -25
    arc_1_0_18  depot_departure_or_bypass_1149  1
    arc_1_0_18  in_degree_1210  1
    arc_1_0_18  original_T_including_depot_unload_1230  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_870  1
    load_1_0_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_871  -25
    arc_1_0_19  depot_departure_or_bypass_1149  1
    arc_1_0_19  in_degree_1216  1
    arc_1_0_19  original_T_including_depot_unload_1230  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_871  1
    load_1_0_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_872  -25
    arc_1_0_20  depot_departure_or_bypass_1149  1
    arc_1_0_20  in_degree_1222  1
    arc_1_0_20  original_T_including_depot_unload_1230  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_872  1
    load_1_0_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_873  -25
    arc_1_6_0  depot_return_or_bypass_1150  1
    arc_1_6_0  out_degree_1151  1
    arc_1_6_0  original_T_including_depot_unload_1230  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_873  1
    load_1_6_0  segment_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_874  -25
    arc_1_6_7  connected_order_arc_875  -13
    arc_1_6_7  out_degree_1151  1
    arc_1_6_7  in_degree_1159  1
    arc_1_6_7  original_T_including_depot_unload_1230  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_874  1
    load_1_6_7  segment_load_conservation_1155  1
    load_1_6_7  segment_load_conservation_1162  -1
    load_1_6_7  segment_prefix_lb_1163  1
    load_1_6_7  segment_prefix_ub_1164  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_876  -25
    arc_1_6_8  connected_order_arc_877  -13
    arc_1_6_8  out_degree_1151  1
    arc_1_6_8  in_degree_1166  1
    arc_1_6_8  original_T_including_depot_unload_1230  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_876  1
    load_1_6_8  segment_load_conservation_1155  1
    load_1_6_8  segment_load_conservation_1169  -1
    load_1_6_8  segment_prefix_lb_1170  1
    load_1_6_8  segment_prefix_ub_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_878  -25
    arc_1_6_9  connected_order_arc_879  -13
    arc_1_6_9  out_degree_1151  1
    arc_1_6_9  in_degree_1173  1
    arc_1_6_9  original_T_including_depot_unload_1230  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_878  1
    load_1_6_9  segment_load_conservation_1155  1
    load_1_6_9  segment_load_conservation_1176  -1
    load_1_6_9  segment_prefix_lb_1177  1
    load_1_6_9  segment_prefix_ub_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_880  -25
    arc_1_6_13  connected_order_arc_881  -13
    arc_1_6_13  out_degree_1151  1
    arc_1_6_13  in_degree_1180  1
    arc_1_6_13  original_T_including_depot_unload_1230  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_880  1
    load_1_6_13  segment_load_conservation_1155  1
    load_1_6_13  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_882  -25
    arc_1_6_14  connected_order_arc_883  -13
    arc_1_6_14  out_degree_1151  1
    arc_1_6_14  in_degree_1186  1
    arc_1_6_14  original_T_including_depot_unload_1230  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_882  1
    load_1_6_14  segment_load_conservation_1155  1
    load_1_6_14  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_884  -25
    arc_1_6_15  connected_order_arc_885  -13
    arc_1_6_15  out_degree_1151  1
    arc_1_6_15  in_degree_1192  1
    arc_1_6_15  original_T_including_depot_unload_1230  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_884  1
    load_1_6_15  segment_load_conservation_1155  1
    load_1_6_15  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_886  -25
    arc_1_6_16  connected_order_arc_887  -13
    arc_1_6_16  out_degree_1151  1
    arc_1_6_16  in_degree_1198  1
    arc_1_6_16  original_T_including_depot_unload_1230  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_886  1
    load_1_6_16  segment_load_conservation_1155  1
    load_1_6_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_888  -25
    arc_1_6_17  connected_order_arc_889  -13
    arc_1_6_17  out_degree_1151  1
    arc_1_6_17  in_degree_1204  1
    arc_1_6_17  original_T_including_depot_unload_1230  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_888  1
    load_1_6_17  segment_load_conservation_1155  1
    load_1_6_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_890  -25
    arc_1_6_18  connected_order_arc_891  -13
    arc_1_6_18  out_degree_1151  1
    arc_1_6_18  in_degree_1210  1
    arc_1_6_18  original_T_including_depot_unload_1230  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_890  1
    load_1_6_18  segment_load_conservation_1155  1
    load_1_6_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_892  -25
    arc_1_6_19  connected_order_arc_893  -13
    arc_1_6_19  out_degree_1151  1
    arc_1_6_19  in_degree_1216  1
    arc_1_6_19  original_T_including_depot_unload_1230  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_892  1
    load_1_6_19  segment_load_conservation_1155  1
    load_1_6_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_894  -25
    arc_1_6_20  connected_order_arc_895  -13
    arc_1_6_20  out_degree_1151  1
    arc_1_6_20  in_degree_1222  1
    arc_1_6_20  original_T_including_depot_unload_1230  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_894  1
    load_1_6_20  segment_load_conservation_1155  1
    load_1_6_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_896  -25
    arc_1_7_0  depot_return_or_bypass_1150  1
    arc_1_7_0  out_degree_1158  1
    arc_1_7_0  original_T_including_depot_unload_1230  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_896  1
    load_1_7_0  segment_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_897  -25
    arc_1_7_6  connected_order_arc_898  -13
    arc_1_7_6  in_degree_1152  1
    arc_1_7_6  out_degree_1158  1
    arc_1_7_6  original_T_including_depot_unload_1230  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_897  1
    load_1_7_6  segment_load_conservation_1155  -1
    load_1_7_6  segment_prefix_lb_1156  1
    load_1_7_6  segment_prefix_ub_1157  1
    load_1_7_6  segment_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_899  -25
    arc_1_7_8  connected_order_arc_900  -13
    arc_1_7_8  out_degree_1158  1
    arc_1_7_8  in_degree_1166  1
    arc_1_7_8  original_T_including_depot_unload_1230  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_899  1
    load_1_7_8  segment_load_conservation_1162  1
    load_1_7_8  segment_load_conservation_1169  -1
    load_1_7_8  segment_prefix_lb_1170  1
    load_1_7_8  segment_prefix_ub_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_901  -25
    arc_1_7_9  connected_order_arc_902  -13
    arc_1_7_9  out_degree_1158  1
    arc_1_7_9  in_degree_1173  1
    arc_1_7_9  original_T_including_depot_unload_1230  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_901  1
    load_1_7_9  segment_load_conservation_1162  1
    load_1_7_9  segment_load_conservation_1176  -1
    load_1_7_9  segment_prefix_lb_1177  1
    load_1_7_9  segment_prefix_ub_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_903  -25
    arc_1_7_13  connected_order_arc_904  -13
    arc_1_7_13  out_degree_1158  1
    arc_1_7_13  in_degree_1180  1
    arc_1_7_13  original_T_including_depot_unload_1230  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_903  1
    load_1_7_13  segment_load_conservation_1162  1
    load_1_7_13  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_905  -25
    arc_1_7_14  connected_order_arc_906  -13
    arc_1_7_14  out_degree_1158  1
    arc_1_7_14  in_degree_1186  1
    arc_1_7_14  original_T_including_depot_unload_1230  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_905  1
    load_1_7_14  segment_load_conservation_1162  1
    load_1_7_14  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_907  -25
    arc_1_7_15  connected_order_arc_908  -13
    arc_1_7_15  out_degree_1158  1
    arc_1_7_15  in_degree_1192  1
    arc_1_7_15  original_T_including_depot_unload_1230  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_907  1
    load_1_7_15  segment_load_conservation_1162  1
    load_1_7_15  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_909  -25
    arc_1_7_16  connected_order_arc_910  -13
    arc_1_7_16  out_degree_1158  1
    arc_1_7_16  in_degree_1198  1
    arc_1_7_16  original_T_including_depot_unload_1230  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_909  1
    load_1_7_16  segment_load_conservation_1162  1
    load_1_7_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_911  -25
    arc_1_7_17  connected_order_arc_912  -13
    arc_1_7_17  out_degree_1158  1
    arc_1_7_17  in_degree_1204  1
    arc_1_7_17  original_T_including_depot_unload_1230  1.7225744515697754e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_911  1
    load_1_7_17  segment_load_conservation_1162  1
    load_1_7_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_913  -25
    arc_1_7_18  connected_order_arc_914  -13
    arc_1_7_18  out_degree_1158  1
    arc_1_7_18  in_degree_1210  1
    arc_1_7_18  original_T_including_depot_unload_1230  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_913  1
    load_1_7_18  segment_load_conservation_1162  1
    load_1_7_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_915  -25
    arc_1_7_19  connected_order_arc_916  -13
    arc_1_7_19  out_degree_1158  1
    arc_1_7_19  in_degree_1216  1
    arc_1_7_19  original_T_including_depot_unload_1230  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_915  1
    load_1_7_19  segment_load_conservation_1162  1
    load_1_7_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_917  -25
    arc_1_7_20  connected_order_arc_918  -13
    arc_1_7_20  out_degree_1158  1
    arc_1_7_20  in_degree_1222  1
    arc_1_7_20  original_T_including_depot_unload_1230  1.3082661182285894e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_917  1
    load_1_7_20  segment_load_conservation_1162  1
    load_1_7_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_919  -25
    arc_1_8_0  depot_return_or_bypass_1150  1
    arc_1_8_0  out_degree_1165  1
    arc_1_8_0  original_T_including_depot_unload_1230  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_919  1
    load_1_8_0  segment_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_920  -25
    arc_1_8_6  connected_order_arc_921  -13
    arc_1_8_6  in_degree_1152  1
    arc_1_8_6  out_degree_1165  1
    arc_1_8_6  original_T_including_depot_unload_1230  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_920  1
    load_1_8_6  segment_load_conservation_1155  -1
    load_1_8_6  segment_prefix_lb_1156  1
    load_1_8_6  segment_prefix_ub_1157  1
    load_1_8_6  segment_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_922  -25
    arc_1_8_7  connected_order_arc_923  -13
    arc_1_8_7  in_degree_1159  1
    arc_1_8_7  out_degree_1165  1
    arc_1_8_7  original_T_including_depot_unload_1230  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_922  1
    load_1_8_7  segment_load_conservation_1162  -1
    load_1_8_7  segment_prefix_lb_1163  1
    load_1_8_7  segment_prefix_ub_1164  1
    load_1_8_7  segment_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_924  -25
    arc_1_8_9  connected_order_arc_925  -13
    arc_1_8_9  out_degree_1165  1
    arc_1_8_9  in_degree_1173  1
    arc_1_8_9  original_T_including_depot_unload_1230  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_924  1
    load_1_8_9  segment_load_conservation_1169  1
    load_1_8_9  segment_load_conservation_1176  -1
    load_1_8_9  segment_prefix_lb_1177  1
    load_1_8_9  segment_prefix_ub_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_926  -25
    arc_1_8_13  connected_order_arc_927  -13
    arc_1_8_13  out_degree_1165  1
    arc_1_8_13  in_degree_1180  1
    arc_1_8_13  original_T_including_depot_unload_1230  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_926  1
    load_1_8_13  segment_load_conservation_1169  1
    load_1_8_13  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_928  -25
    arc_1_8_14  connected_order_arc_929  -13
    arc_1_8_14  out_degree_1165  1
    arc_1_8_14  in_degree_1186  1
    arc_1_8_14  original_T_including_depot_unload_1230  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_928  1
    load_1_8_14  segment_load_conservation_1169  1
    load_1_8_14  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_930  -25
    arc_1_8_15  connected_order_arc_931  -13
    arc_1_8_15  out_degree_1165  1
    arc_1_8_15  in_degree_1192  1
    arc_1_8_15  original_T_including_depot_unload_1230  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_930  1
    load_1_8_15  segment_load_conservation_1169  1
    load_1_8_15  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_932  -25
    arc_1_8_16  connected_order_arc_933  -13
    arc_1_8_16  out_degree_1165  1
    arc_1_8_16  in_degree_1198  1
    arc_1_8_16  original_T_including_depot_unload_1230  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_932  1
    load_1_8_16  segment_load_conservation_1169  1
    load_1_8_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_934  -25
    arc_1_8_17  connected_order_arc_935  -13
    arc_1_8_17  out_degree_1165  1
    arc_1_8_17  in_degree_1204  1
    arc_1_8_17  original_T_including_depot_unload_1230  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_934  1
    load_1_8_17  segment_load_conservation_1169  1
    load_1_8_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_936  -25
    arc_1_8_18  connected_order_arc_937  -13
    arc_1_8_18  out_degree_1165  1
    arc_1_8_18  in_degree_1210  1
    arc_1_8_18  original_T_including_depot_unload_1230  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_936  1
    load_1_8_18  segment_load_conservation_1169  1
    load_1_8_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_938  -25
    arc_1_8_19  connected_order_arc_939  -13
    arc_1_8_19  out_degree_1165  1
    arc_1_8_19  in_degree_1216  1
    arc_1_8_19  original_T_including_depot_unload_1230  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_938  1
    load_1_8_19  segment_load_conservation_1169  1
    load_1_8_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_940  -25
    arc_1_8_20  connected_order_arc_941  -13
    arc_1_8_20  out_degree_1165  1
    arc_1_8_20  in_degree_1222  1
    arc_1_8_20  original_T_including_depot_unload_1230  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_940  1
    load_1_8_20  segment_load_conservation_1169  1
    load_1_8_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_942  -25
    arc_1_9_0  depot_return_or_bypass_1150  1
    arc_1_9_0  out_degree_1172  1
    arc_1_9_0  original_T_including_depot_unload_1230  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_942  1
    load_1_9_0  segment_load_conservation_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_943  -25
    arc_1_9_6  connected_order_arc_944  -13
    arc_1_9_6  in_degree_1152  1
    arc_1_9_6  out_degree_1172  1
    arc_1_9_6  original_T_including_depot_unload_1230  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_943  1
    load_1_9_6  segment_load_conservation_1155  -1
    load_1_9_6  segment_prefix_lb_1156  1
    load_1_9_6  segment_prefix_ub_1157  1
    load_1_9_6  segment_load_conservation_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_945  -25
    arc_1_9_7  connected_order_arc_946  -13
    arc_1_9_7  in_degree_1159  1
    arc_1_9_7  out_degree_1172  1
    arc_1_9_7  original_T_including_depot_unload_1230  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_945  1
    load_1_9_7  segment_load_conservation_1162  -1
    load_1_9_7  segment_prefix_lb_1163  1
    load_1_9_7  segment_prefix_ub_1164  1
    load_1_9_7  segment_load_conservation_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_947  -25
    arc_1_9_8  connected_order_arc_948  -13
    arc_1_9_8  in_degree_1166  1
    arc_1_9_8  out_degree_1172  1
    arc_1_9_8  original_T_including_depot_unload_1230  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_947  1
    load_1_9_8  segment_load_conservation_1169  -1
    load_1_9_8  segment_prefix_lb_1170  1
    load_1_9_8  segment_prefix_ub_1171  1
    load_1_9_8  segment_load_conservation_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_949  -25
    arc_1_9_13  connected_order_arc_950  -13
    arc_1_9_13  out_degree_1172  1
    arc_1_9_13  in_degree_1180  1
    arc_1_9_13  original_T_including_depot_unload_1230  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_949  1
    load_1_9_13  segment_load_conservation_1176  1
    load_1_9_13  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_951  -25
    arc_1_9_14  connected_order_arc_952  -13
    arc_1_9_14  out_degree_1172  1
    arc_1_9_14  in_degree_1186  1
    arc_1_9_14  original_T_including_depot_unload_1230  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_951  1
    load_1_9_14  segment_load_conservation_1176  1
    load_1_9_14  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_953  -25
    arc_1_9_15  connected_order_arc_954  -13
    arc_1_9_15  out_degree_1172  1
    arc_1_9_15  in_degree_1192  1
    arc_1_9_15  original_T_including_depot_unload_1230  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_953  1
    load_1_9_15  segment_load_conservation_1176  1
    load_1_9_15  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_955  -25
    arc_1_9_16  connected_order_arc_956  -13
    arc_1_9_16  out_degree_1172  1
    arc_1_9_16  in_degree_1198  1
    arc_1_9_16  original_T_including_depot_unload_1230  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_955  1
    load_1_9_16  segment_load_conservation_1176  1
    load_1_9_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_957  -25
    arc_1_9_17  connected_order_arc_958  -13
    arc_1_9_17  out_degree_1172  1
    arc_1_9_17  in_degree_1204  1
    arc_1_9_17  original_T_including_depot_unload_1230  1.2814005706654932e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_957  1
    load_1_9_17  segment_load_conservation_1176  1
    load_1_9_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_959  -25
    arc_1_9_18  connected_order_arc_960  -13
    arc_1_9_18  out_degree_1172  1
    arc_1_9_18  in_degree_1210  1
    arc_1_9_18  original_T_including_depot_unload_1230  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_959  1
    load_1_9_18  segment_load_conservation_1176  1
    load_1_9_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_961  -25
    arc_1_9_19  connected_order_arc_962  -13
    arc_1_9_19  out_degree_1172  1
    arc_1_9_19  in_degree_1216  1
    arc_1_9_19  original_T_including_depot_unload_1230  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_961  1
    load_1_9_19  segment_load_conservation_1176  1
    load_1_9_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_963  -25
    arc_1_9_20  connected_order_arc_964  -13
    arc_1_9_20  out_degree_1172  1
    arc_1_9_20  in_degree_1222  1
    arc_1_9_20  original_T_including_depot_unload_1230  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_963  1
    load_1_9_20  segment_load_conservation_1176  1
    load_1_9_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_965  -25
    arc_1_13_0  depot_return_or_bypass_1150  1
    arc_1_13_0  out_degree_1179  1
    arc_1_13_0  original_T_including_depot_unload_1230  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_965  1
    load_1_13_0  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_966  -25
    arc_1_13_6  connected_order_arc_967  -13
    arc_1_13_6  in_degree_1152  1
    arc_1_13_6  out_degree_1179  1
    arc_1_13_6  original_T_including_depot_unload_1230  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_966  1
    load_1_13_6  segment_load_conservation_1155  -1
    load_1_13_6  segment_prefix_lb_1156  1
    load_1_13_6  segment_prefix_ub_1157  1
    load_1_13_6  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_968  -25
    arc_1_13_7  connected_order_arc_969  -13
    arc_1_13_7  in_degree_1159  1
    arc_1_13_7  out_degree_1179  1
    arc_1_13_7  original_T_including_depot_unload_1230  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_968  1
    load_1_13_7  segment_load_conservation_1162  -1
    load_1_13_7  segment_prefix_lb_1163  1
    load_1_13_7  segment_prefix_ub_1164  1
    load_1_13_7  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_970  -25
    arc_1_13_8  connected_order_arc_971  -13
    arc_1_13_8  in_degree_1166  1
    arc_1_13_8  out_degree_1179  1
    arc_1_13_8  original_T_including_depot_unload_1230  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_970  1
    load_1_13_8  segment_load_conservation_1169  -1
    load_1_13_8  segment_prefix_lb_1170  1
    load_1_13_8  segment_prefix_ub_1171  1
    load_1_13_8  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_972  -25
    arc_1_13_9  connected_order_arc_973  -13
    arc_1_13_9  in_degree_1173  1
    arc_1_13_9  out_degree_1179  1
    arc_1_13_9  original_T_including_depot_unload_1230  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_972  1
    load_1_13_9  segment_load_conservation_1176  -1
    load_1_13_9  segment_prefix_lb_1177  1
    load_1_13_9  segment_prefix_ub_1178  1
    load_1_13_9  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_974  -25
    arc_1_13_14  connected_order_arc_975  -13
    arc_1_13_14  out_degree_1179  1
    arc_1_13_14  in_degree_1186  1
    arc_1_13_14  original_T_including_depot_unload_1230  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_974  1
    load_1_13_14  free_load_conservation_1184  1
    load_1_13_14  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_976  -25
    arc_1_13_15  connected_order_arc_977  -13
    arc_1_13_15  out_degree_1179  1
    arc_1_13_15  in_degree_1192  1
    arc_1_13_15  original_T_including_depot_unload_1230  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_976  1
    load_1_13_15  free_load_conservation_1184  1
    load_1_13_15  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_978  -25
    arc_1_13_16  connected_order_arc_979  -13
    arc_1_13_16  out_degree_1179  1
    arc_1_13_16  in_degree_1198  1
    arc_1_13_16  original_T_including_depot_unload_1230  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_978  1
    load_1_13_16  free_load_conservation_1184  1
    load_1_13_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_980  -25
    arc_1_13_17  connected_order_arc_981  -13
    arc_1_13_17  out_degree_1179  1
    arc_1_13_17  in_degree_1204  1
    arc_1_13_17  original_T_including_depot_unload_1230  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_980  1
    load_1_13_17  free_load_conservation_1184  1
    load_1_13_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_982  -25
    arc_1_13_18  connected_order_arc_983  -13
    arc_1_13_18  out_degree_1179  1
    arc_1_13_18  in_degree_1210  1
    arc_1_13_18  original_T_including_depot_unload_1230  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_982  1
    load_1_13_18  free_load_conservation_1184  1
    load_1_13_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_984  -25
    arc_1_13_19  connected_order_arc_985  -13
    arc_1_13_19  out_degree_1179  1
    arc_1_13_19  in_degree_1216  1
    arc_1_13_19  original_T_including_depot_unload_1230  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_984  1
    load_1_13_19  free_load_conservation_1184  1
    load_1_13_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_986  -25
    arc_1_13_20  connected_order_arc_987  -13
    arc_1_13_20  out_degree_1179  1
    arc_1_13_20  in_degree_1222  1
    arc_1_13_20  original_T_including_depot_unload_1230  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_986  1
    load_1_13_20  free_load_conservation_1184  1
    load_1_13_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_988  -25
    arc_1_14_0  depot_return_or_bypass_1150  1
    arc_1_14_0  out_degree_1185  1
    arc_1_14_0  original_T_including_depot_unload_1230  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_988  1
    load_1_14_0  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_989  -25
    arc_1_14_6  connected_order_arc_990  -13
    arc_1_14_6  in_degree_1152  1
    arc_1_14_6  out_degree_1185  1
    arc_1_14_6  original_T_including_depot_unload_1230  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_989  1
    load_1_14_6  segment_load_conservation_1155  -1
    load_1_14_6  segment_prefix_lb_1156  1
    load_1_14_6  segment_prefix_ub_1157  1
    load_1_14_6  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_991  -25
    arc_1_14_7  connected_order_arc_992  -13
    arc_1_14_7  in_degree_1159  1
    arc_1_14_7  out_degree_1185  1
    arc_1_14_7  original_T_including_depot_unload_1230  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_991  1
    load_1_14_7  segment_load_conservation_1162  -1
    load_1_14_7  segment_prefix_lb_1163  1
    load_1_14_7  segment_prefix_ub_1164  1
    load_1_14_7  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_993  -25
    arc_1_14_8  connected_order_arc_994  -13
    arc_1_14_8  in_degree_1166  1
    arc_1_14_8  out_degree_1185  1
    arc_1_14_8  original_T_including_depot_unload_1230  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_993  1
    load_1_14_8  segment_load_conservation_1169  -1
    load_1_14_8  segment_prefix_lb_1170  1
    load_1_14_8  segment_prefix_ub_1171  1
    load_1_14_8  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_995  -25
    arc_1_14_9  connected_order_arc_996  -13
    arc_1_14_9  in_degree_1173  1
    arc_1_14_9  out_degree_1185  1
    arc_1_14_9  original_T_including_depot_unload_1230  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_995  1
    load_1_14_9  segment_load_conservation_1176  -1
    load_1_14_9  segment_prefix_lb_1177  1
    load_1_14_9  segment_prefix_ub_1178  1
    load_1_14_9  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_997  -25
    arc_1_14_13  connected_order_arc_998  -13
    arc_1_14_13  in_degree_1180  1
    arc_1_14_13  out_degree_1185  1
    arc_1_14_13  original_T_including_depot_unload_1230  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_997  1
    load_1_14_13  free_load_conservation_1184  -1
    load_1_14_13  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_999  -25
    arc_1_14_15  connected_order_arc_1000  -13
    arc_1_14_15  out_degree_1185  1
    arc_1_14_15  in_degree_1192  1
    arc_1_14_15  original_T_including_depot_unload_1230  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_999  1
    load_1_14_15  free_load_conservation_1190  1
    load_1_14_15  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1001  -25
    arc_1_14_16  connected_order_arc_1002  -13
    arc_1_14_16  out_degree_1185  1
    arc_1_14_16  in_degree_1198  1
    arc_1_14_16  original_T_including_depot_unload_1230  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1001  1
    load_1_14_16  free_load_conservation_1190  1
    load_1_14_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1003  -25
    arc_1_14_17  connected_order_arc_1004  -13
    arc_1_14_17  out_degree_1185  1
    arc_1_14_17  in_degree_1204  1
    arc_1_14_17  original_T_including_depot_unload_1230  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1003  1
    load_1_14_17  free_load_conservation_1190  1
    load_1_14_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1005  -25
    arc_1_14_18  connected_order_arc_1006  -13
    arc_1_14_18  out_degree_1185  1
    arc_1_14_18  in_degree_1210  1
    arc_1_14_18  original_T_including_depot_unload_1230  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1005  1
    load_1_14_18  free_load_conservation_1190  1
    load_1_14_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1007  -25
    arc_1_14_19  connected_order_arc_1008  -13
    arc_1_14_19  out_degree_1185  1
    arc_1_14_19  in_degree_1216  1
    arc_1_14_19  original_T_including_depot_unload_1230  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1007  1
    load_1_14_19  free_load_conservation_1190  1
    load_1_14_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1009  -25
    arc_1_14_20  connected_order_arc_1010  -13
    arc_1_14_20  out_degree_1185  1
    arc_1_14_20  in_degree_1222  1
    arc_1_14_20  original_T_including_depot_unload_1230  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1009  1
    load_1_14_20  free_load_conservation_1190  1
    load_1_14_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1011  -25
    arc_1_15_0  depot_return_or_bypass_1150  1
    arc_1_15_0  out_degree_1191  1
    arc_1_15_0  original_T_including_depot_unload_1230  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1011  1
    load_1_15_0  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1012  -25
    arc_1_15_6  connected_order_arc_1013  -13
    arc_1_15_6  in_degree_1152  1
    arc_1_15_6  out_degree_1191  1
    arc_1_15_6  original_T_including_depot_unload_1230  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1012  1
    load_1_15_6  segment_load_conservation_1155  -1
    load_1_15_6  segment_prefix_lb_1156  1
    load_1_15_6  segment_prefix_ub_1157  1
    load_1_15_6  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1014  -25
    arc_1_15_7  connected_order_arc_1015  -13
    arc_1_15_7  in_degree_1159  1
    arc_1_15_7  out_degree_1191  1
    arc_1_15_7  original_T_including_depot_unload_1230  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1014  1
    load_1_15_7  segment_load_conservation_1162  -1
    load_1_15_7  segment_prefix_lb_1163  1
    load_1_15_7  segment_prefix_ub_1164  1
    load_1_15_7  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1016  -25
    arc_1_15_8  connected_order_arc_1017  -13
    arc_1_15_8  in_degree_1166  1
    arc_1_15_8  out_degree_1191  1
    arc_1_15_8  original_T_including_depot_unload_1230  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1016  1
    load_1_15_8  segment_load_conservation_1169  -1
    load_1_15_8  segment_prefix_lb_1170  1
    load_1_15_8  segment_prefix_ub_1171  1
    load_1_15_8  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1018  -25
    arc_1_15_9  connected_order_arc_1019  -13
    arc_1_15_9  in_degree_1173  1
    arc_1_15_9  out_degree_1191  1
    arc_1_15_9  original_T_including_depot_unload_1230  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1018  1
    load_1_15_9  segment_load_conservation_1176  -1
    load_1_15_9  segment_prefix_lb_1177  1
    load_1_15_9  segment_prefix_ub_1178  1
    load_1_15_9  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1020  -25
    arc_1_15_13  connected_order_arc_1021  -13
    arc_1_15_13  in_degree_1180  1
    arc_1_15_13  out_degree_1191  1
    arc_1_15_13  original_T_including_depot_unload_1230  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1020  1
    load_1_15_13  free_load_conservation_1184  -1
    load_1_15_13  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1022  -25
    arc_1_15_14  connected_order_arc_1023  -13
    arc_1_15_14  in_degree_1186  1
    arc_1_15_14  out_degree_1191  1
    arc_1_15_14  original_T_including_depot_unload_1230  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1022  1
    load_1_15_14  free_load_conservation_1190  -1
    load_1_15_14  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1024  -25
    arc_1_15_16  connected_order_arc_1025  -13
    arc_1_15_16  out_degree_1191  1
    arc_1_15_16  in_degree_1198  1
    arc_1_15_16  original_T_including_depot_unload_1230  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1024  1
    load_1_15_16  free_load_conservation_1196  1
    load_1_15_16  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1026  -25
    arc_1_15_17  connected_order_arc_1027  -13
    arc_1_15_17  out_degree_1191  1
    arc_1_15_17  in_degree_1204  1
    arc_1_15_17  original_T_including_depot_unload_1230  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1026  1
    load_1_15_17  free_load_conservation_1196  1
    load_1_15_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1028  -25
    arc_1_15_18  connected_order_arc_1029  -13
    arc_1_15_18  out_degree_1191  1
    arc_1_15_18  in_degree_1210  1
    arc_1_15_18  original_T_including_depot_unload_1230  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1028  1
    load_1_15_18  free_load_conservation_1196  1
    load_1_15_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1030  -25
    arc_1_15_19  connected_order_arc_1031  -13
    arc_1_15_19  out_degree_1191  1
    arc_1_15_19  in_degree_1216  1
    arc_1_15_19  original_T_including_depot_unload_1230  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1030  1
    load_1_15_19  free_load_conservation_1196  1
    load_1_15_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1032  -25
    arc_1_15_20  connected_order_arc_1033  -13
    arc_1_15_20  out_degree_1191  1
    arc_1_15_20  in_degree_1222  1
    arc_1_15_20  original_T_including_depot_unload_1230  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1032  1
    load_1_15_20  free_load_conservation_1196  1
    load_1_15_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1034  -25
    arc_1_16_0  depot_return_or_bypass_1150  1
    arc_1_16_0  out_degree_1197  1
    arc_1_16_0  original_T_including_depot_unload_1230  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1034  1
    load_1_16_0  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1035  -25
    arc_1_16_6  connected_order_arc_1036  -13
    arc_1_16_6  in_degree_1152  1
    arc_1_16_6  out_degree_1197  1
    arc_1_16_6  original_T_including_depot_unload_1230  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1035  1
    load_1_16_6  segment_load_conservation_1155  -1
    load_1_16_6  segment_prefix_lb_1156  1
    load_1_16_6  segment_prefix_ub_1157  1
    load_1_16_6  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1037  -25
    arc_1_16_7  connected_order_arc_1038  -13
    arc_1_16_7  in_degree_1159  1
    arc_1_16_7  out_degree_1197  1
    arc_1_16_7  original_T_including_depot_unload_1230  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1037  1
    load_1_16_7  segment_load_conservation_1162  -1
    load_1_16_7  segment_prefix_lb_1163  1
    load_1_16_7  segment_prefix_ub_1164  1
    load_1_16_7  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1039  -25
    arc_1_16_8  connected_order_arc_1040  -13
    arc_1_16_8  in_degree_1166  1
    arc_1_16_8  out_degree_1197  1
    arc_1_16_8  original_T_including_depot_unload_1230  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1039  1
    load_1_16_8  segment_load_conservation_1169  -1
    load_1_16_8  segment_prefix_lb_1170  1
    load_1_16_8  segment_prefix_ub_1171  1
    load_1_16_8  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1041  -25
    arc_1_16_9  connected_order_arc_1042  -13
    arc_1_16_9  in_degree_1173  1
    arc_1_16_9  out_degree_1197  1
    arc_1_16_9  original_T_including_depot_unload_1230  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1041  1
    load_1_16_9  segment_load_conservation_1176  -1
    load_1_16_9  segment_prefix_lb_1177  1
    load_1_16_9  segment_prefix_ub_1178  1
    load_1_16_9  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1043  -25
    arc_1_16_13  connected_order_arc_1044  -13
    arc_1_16_13  in_degree_1180  1
    arc_1_16_13  out_degree_1197  1
    arc_1_16_13  original_T_including_depot_unload_1230  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1043  1
    load_1_16_13  free_load_conservation_1184  -1
    load_1_16_13  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1045  -25
    arc_1_16_14  connected_order_arc_1046  -13
    arc_1_16_14  in_degree_1186  1
    arc_1_16_14  out_degree_1197  1
    arc_1_16_14  original_T_including_depot_unload_1230  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1045  1
    load_1_16_14  free_load_conservation_1190  -1
    load_1_16_14  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1047  -25
    arc_1_16_15  connected_order_arc_1048  -13
    arc_1_16_15  in_degree_1192  1
    arc_1_16_15  out_degree_1197  1
    arc_1_16_15  original_T_including_depot_unload_1230  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1047  1
    load_1_16_15  free_load_conservation_1196  -1
    load_1_16_15  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1049  -25
    arc_1_16_17  connected_order_arc_1050  -13
    arc_1_16_17  out_degree_1197  1
    arc_1_16_17  in_degree_1204  1
    arc_1_16_17  original_T_including_depot_unload_1230  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1049  1
    load_1_16_17  free_load_conservation_1202  1
    load_1_16_17  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1051  -25
    arc_1_16_18  connected_order_arc_1052  -13
    arc_1_16_18  out_degree_1197  1
    arc_1_16_18  in_degree_1210  1
    arc_1_16_18  original_T_including_depot_unload_1230  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1051  1
    load_1_16_18  free_load_conservation_1202  1
    load_1_16_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1053  -25
    arc_1_16_19  connected_order_arc_1054  -13
    arc_1_16_19  out_degree_1197  1
    arc_1_16_19  in_degree_1216  1
    arc_1_16_19  original_T_including_depot_unload_1230  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1053  1
    load_1_16_19  free_load_conservation_1202  1
    load_1_16_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1055  -25
    arc_1_16_20  connected_order_arc_1056  -13
    arc_1_16_20  out_degree_1197  1
    arc_1_16_20  in_degree_1222  1
    arc_1_16_20  original_T_including_depot_unload_1230  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1055  1
    load_1_16_20  free_load_conservation_1202  1
    load_1_16_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1057  -25
    arc_1_17_0  depot_return_or_bypass_1150  1
    arc_1_17_0  out_degree_1203  1
    arc_1_17_0  original_T_including_depot_unload_1230  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1057  1
    load_1_17_0  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1058  -25
    arc_1_17_6  connected_order_arc_1059  -13
    arc_1_17_6  in_degree_1152  1
    arc_1_17_6  out_degree_1203  1
    arc_1_17_6  original_T_including_depot_unload_1230  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1058  1
    load_1_17_6  segment_load_conservation_1155  -1
    load_1_17_6  segment_prefix_lb_1156  1
    load_1_17_6  segment_prefix_ub_1157  1
    load_1_17_6  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1060  -25
    arc_1_17_7  connected_order_arc_1061  -13
    arc_1_17_7  in_degree_1159  1
    arc_1_17_7  out_degree_1203  1
    arc_1_17_7  original_T_including_depot_unload_1230  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1060  1
    load_1_17_7  segment_load_conservation_1162  -1
    load_1_17_7  segment_prefix_lb_1163  1
    load_1_17_7  segment_prefix_ub_1164  1
    load_1_17_7  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1062  -25
    arc_1_17_8  connected_order_arc_1063  -13
    arc_1_17_8  in_degree_1166  1
    arc_1_17_8  out_degree_1203  1
    arc_1_17_8  original_T_including_depot_unload_1230  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1062  1
    load_1_17_8  segment_load_conservation_1169  -1
    load_1_17_8  segment_prefix_lb_1170  1
    load_1_17_8  segment_prefix_ub_1171  1
    load_1_17_8  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1064  -25
    arc_1_17_9  connected_order_arc_1065  -13
    arc_1_17_9  in_degree_1173  1
    arc_1_17_9  out_degree_1203  1
    arc_1_17_9  original_T_including_depot_unload_1230  1.2814005706654932e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1064  1
    load_1_17_9  segment_load_conservation_1176  -1
    load_1_17_9  segment_prefix_lb_1177  1
    load_1_17_9  segment_prefix_ub_1178  1
    load_1_17_9  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1066  -25
    arc_1_17_13  connected_order_arc_1067  -13
    arc_1_17_13  in_degree_1180  1
    arc_1_17_13  out_degree_1203  1
    arc_1_17_13  original_T_including_depot_unload_1230  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1066  1
    load_1_17_13  free_load_conservation_1184  -1
    load_1_17_13  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1068  -25
    arc_1_17_14  connected_order_arc_1069  -13
    arc_1_17_14  in_degree_1186  1
    arc_1_17_14  out_degree_1203  1
    arc_1_17_14  original_T_including_depot_unload_1230  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1068  1
    load_1_17_14  free_load_conservation_1190  -1
    load_1_17_14  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1070  -25
    arc_1_17_15  connected_order_arc_1071  -13
    arc_1_17_15  in_degree_1192  1
    arc_1_17_15  out_degree_1203  1
    arc_1_17_15  original_T_including_depot_unload_1230  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1070  1
    load_1_17_15  free_load_conservation_1196  -1
    load_1_17_15  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1072  -25
    arc_1_17_16  connected_order_arc_1073  -13
    arc_1_17_16  in_degree_1198  1
    arc_1_17_16  out_degree_1203  1
    arc_1_17_16  original_T_including_depot_unload_1230  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1072  1
    load_1_17_16  free_load_conservation_1202  -1
    load_1_17_16  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1074  -25
    arc_1_17_18  connected_order_arc_1075  -13
    arc_1_17_18  out_degree_1203  1
    arc_1_17_18  in_degree_1210  1
    arc_1_17_18  original_T_including_depot_unload_1230  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1074  1
    load_1_17_18  free_load_conservation_1208  1
    load_1_17_18  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1076  -25
    arc_1_17_19  connected_order_arc_1077  -13
    arc_1_17_19  out_degree_1203  1
    arc_1_17_19  in_degree_1216  1
    arc_1_17_19  original_T_including_depot_unload_1230  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1076  1
    load_1_17_19  free_load_conservation_1208  1
    load_1_17_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1078  -25
    arc_1_17_20  connected_order_arc_1079  -13
    arc_1_17_20  out_degree_1203  1
    arc_1_17_20  in_degree_1222  1
    arc_1_17_20  original_T_including_depot_unload_1230  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1078  1
    load_1_17_20  free_load_conservation_1208  1
    load_1_17_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1080  -25
    arc_1_18_0  depot_return_or_bypass_1150  1
    arc_1_18_0  out_degree_1209  1
    arc_1_18_0  original_T_including_depot_unload_1230  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1080  1
    load_1_18_0  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1081  -25
    arc_1_18_6  connected_order_arc_1082  -13
    arc_1_18_6  in_degree_1152  1
    arc_1_18_6  out_degree_1209  1
    arc_1_18_6  original_T_including_depot_unload_1230  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1081  1
    load_1_18_6  segment_load_conservation_1155  -1
    load_1_18_6  segment_prefix_lb_1156  1
    load_1_18_6  segment_prefix_ub_1157  1
    load_1_18_6  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1083  -25
    arc_1_18_7  connected_order_arc_1084  -13
    arc_1_18_7  in_degree_1159  1
    arc_1_18_7  out_degree_1209  1
    arc_1_18_7  original_T_including_depot_unload_1230  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1083  1
    load_1_18_7  segment_load_conservation_1162  -1
    load_1_18_7  segment_prefix_lb_1163  1
    load_1_18_7  segment_prefix_ub_1164  1
    load_1_18_7  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1085  -25
    arc_1_18_8  connected_order_arc_1086  -13
    arc_1_18_8  in_degree_1166  1
    arc_1_18_8  out_degree_1209  1
    arc_1_18_8  original_T_including_depot_unload_1230  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1085  1
    load_1_18_8  segment_load_conservation_1169  -1
    load_1_18_8  segment_prefix_lb_1170  1
    load_1_18_8  segment_prefix_ub_1171  1
    load_1_18_8  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1087  -25
    arc_1_18_9  connected_order_arc_1088  -13
    arc_1_18_9  in_degree_1173  1
    arc_1_18_9  out_degree_1209  1
    arc_1_18_9  original_T_including_depot_unload_1230  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1087  1
    load_1_18_9  segment_load_conservation_1176  -1
    load_1_18_9  segment_prefix_lb_1177  1
    load_1_18_9  segment_prefix_ub_1178  1
    load_1_18_9  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1089  -25
    arc_1_18_13  connected_order_arc_1090  -13
    arc_1_18_13  in_degree_1180  1
    arc_1_18_13  out_degree_1209  1
    arc_1_18_13  original_T_including_depot_unload_1230  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1089  1
    load_1_18_13  free_load_conservation_1184  -1
    load_1_18_13  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1091  -25
    arc_1_18_14  connected_order_arc_1092  -13
    arc_1_18_14  in_degree_1186  1
    arc_1_18_14  out_degree_1209  1
    arc_1_18_14  original_T_including_depot_unload_1230  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1091  1
    load_1_18_14  free_load_conservation_1190  -1
    load_1_18_14  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1093  -25
    arc_1_18_15  connected_order_arc_1094  -13
    arc_1_18_15  in_degree_1192  1
    arc_1_18_15  out_degree_1209  1
    arc_1_18_15  original_T_including_depot_unload_1230  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1093  1
    load_1_18_15  free_load_conservation_1196  -1
    load_1_18_15  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1095  -25
    arc_1_18_16  connected_order_arc_1096  -13
    arc_1_18_16  in_degree_1198  1
    arc_1_18_16  out_degree_1209  1
    arc_1_18_16  original_T_including_depot_unload_1230  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1095  1
    load_1_18_16  free_load_conservation_1202  -1
    load_1_18_16  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1097  -25
    arc_1_18_17  connected_order_arc_1098  -13
    arc_1_18_17  in_degree_1204  1
    arc_1_18_17  out_degree_1209  1
    arc_1_18_17  original_T_including_depot_unload_1230  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1097  1
    load_1_18_17  free_load_conservation_1208  -1
    load_1_18_17  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1099  -25
    arc_1_18_19  connected_order_arc_1100  -13
    arc_1_18_19  out_degree_1209  1
    arc_1_18_19  in_degree_1216  1
    arc_1_18_19  original_T_including_depot_unload_1230  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1099  1
    load_1_18_19  free_load_conservation_1214  1
    load_1_18_19  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1101  -25
    arc_1_18_20  connected_order_arc_1102  -13
    arc_1_18_20  out_degree_1209  1
    arc_1_18_20  in_degree_1222  1
    arc_1_18_20  original_T_including_depot_unload_1230  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1101  1
    load_1_18_20  free_load_conservation_1214  1
    load_1_18_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1103  -25
    arc_1_19_0  depot_return_or_bypass_1150  1
    arc_1_19_0  out_degree_1215  1
    arc_1_19_0  original_T_including_depot_unload_1230  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1103  1
    load_1_19_0  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1104  -25
    arc_1_19_6  connected_order_arc_1105  -13
    arc_1_19_6  in_degree_1152  1
    arc_1_19_6  out_degree_1215  1
    arc_1_19_6  original_T_including_depot_unload_1230  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1104  1
    load_1_19_6  segment_load_conservation_1155  -1
    load_1_19_6  segment_prefix_lb_1156  1
    load_1_19_6  segment_prefix_ub_1157  1
    load_1_19_6  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1106  -25
    arc_1_19_7  connected_order_arc_1107  -13
    arc_1_19_7  in_degree_1159  1
    arc_1_19_7  out_degree_1215  1
    arc_1_19_7  original_T_including_depot_unload_1230  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1106  1
    load_1_19_7  segment_load_conservation_1162  -1
    load_1_19_7  segment_prefix_lb_1163  1
    load_1_19_7  segment_prefix_ub_1164  1
    load_1_19_7  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1108  -25
    arc_1_19_8  connected_order_arc_1109  -13
    arc_1_19_8  in_degree_1166  1
    arc_1_19_8  out_degree_1215  1
    arc_1_19_8  original_T_including_depot_unload_1230  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1108  1
    load_1_19_8  segment_load_conservation_1169  -1
    load_1_19_8  segment_prefix_lb_1170  1
    load_1_19_8  segment_prefix_ub_1171  1
    load_1_19_8  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1110  -25
    arc_1_19_9  connected_order_arc_1111  -13
    arc_1_19_9  in_degree_1173  1
    arc_1_19_9  out_degree_1215  1
    arc_1_19_9  original_T_including_depot_unload_1230  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1110  1
    load_1_19_9  segment_load_conservation_1176  -1
    load_1_19_9  segment_prefix_lb_1177  1
    load_1_19_9  segment_prefix_ub_1178  1
    load_1_19_9  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1112  -25
    arc_1_19_13  connected_order_arc_1113  -13
    arc_1_19_13  in_degree_1180  1
    arc_1_19_13  out_degree_1215  1
    arc_1_19_13  original_T_including_depot_unload_1230  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1112  1
    load_1_19_13  free_load_conservation_1184  -1
    load_1_19_13  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1114  -25
    arc_1_19_14  connected_order_arc_1115  -13
    arc_1_19_14  in_degree_1186  1
    arc_1_19_14  out_degree_1215  1
    arc_1_19_14  original_T_including_depot_unload_1230  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1114  1
    load_1_19_14  free_load_conservation_1190  -1
    load_1_19_14  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1116  -25
    arc_1_19_15  connected_order_arc_1117  -13
    arc_1_19_15  in_degree_1192  1
    arc_1_19_15  out_degree_1215  1
    arc_1_19_15  original_T_including_depot_unload_1230  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1116  1
    load_1_19_15  free_load_conservation_1196  -1
    load_1_19_15  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1118  -25
    arc_1_19_16  connected_order_arc_1119  -13
    arc_1_19_16  in_degree_1198  1
    arc_1_19_16  out_degree_1215  1
    arc_1_19_16  original_T_including_depot_unload_1230  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1118  1
    load_1_19_16  free_load_conservation_1202  -1
    load_1_19_16  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1120  -25
    arc_1_19_17  connected_order_arc_1121  -13
    arc_1_19_17  in_degree_1204  1
    arc_1_19_17  out_degree_1215  1
    arc_1_19_17  original_T_including_depot_unload_1230  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1120  1
    load_1_19_17  free_load_conservation_1208  -1
    load_1_19_17  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1122  -25
    arc_1_19_18  connected_order_arc_1123  -13
    arc_1_19_18  in_degree_1210  1
    arc_1_19_18  out_degree_1215  1
    arc_1_19_18  original_T_including_depot_unload_1230  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1122  1
    load_1_19_18  free_load_conservation_1214  -1
    load_1_19_18  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1124  -25
    arc_1_19_20  connected_order_arc_1125  -13
    arc_1_19_20  out_degree_1215  1
    arc_1_19_20  in_degree_1222  1
    arc_1_19_20  original_T_including_depot_unload_1230  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1124  1
    load_1_19_20  free_load_conservation_1220  1
    load_1_19_20  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1126  -25
    arc_1_20_0  depot_return_or_bypass_1150  1
    arc_1_20_0  out_degree_1221  1
    arc_1_20_0  original_T_including_depot_unload_1230  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1126  1
    load_1_20_0  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1127  -25
    arc_1_20_6  connected_order_arc_1128  -13
    arc_1_20_6  in_degree_1152  1
    arc_1_20_6  out_degree_1221  1
    arc_1_20_6  original_T_including_depot_unload_1230  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1127  1
    load_1_20_6  segment_load_conservation_1155  -1
    load_1_20_6  segment_prefix_lb_1156  1
    load_1_20_6  segment_prefix_ub_1157  1
    load_1_20_6  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1129  -25
    arc_1_20_7  connected_order_arc_1130  -13
    arc_1_20_7  in_degree_1159  1
    arc_1_20_7  out_degree_1221  1
    arc_1_20_7  original_T_including_depot_unload_1230  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1129  1
    load_1_20_7  segment_load_conservation_1162  -1
    load_1_20_7  segment_prefix_lb_1163  1
    load_1_20_7  segment_prefix_ub_1164  1
    load_1_20_7  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1131  -25
    arc_1_20_8  connected_order_arc_1132  -13
    arc_1_20_8  in_degree_1166  1
    arc_1_20_8  out_degree_1221  1
    arc_1_20_8  original_T_including_depot_unload_1230  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1131  1
    load_1_20_8  segment_load_conservation_1169  -1
    load_1_20_8  segment_prefix_lb_1170  1
    load_1_20_8  segment_prefix_ub_1171  1
    load_1_20_8  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1133  -25
    arc_1_20_9  connected_order_arc_1134  -13
    arc_1_20_9  in_degree_1173  1
    arc_1_20_9  out_degree_1221  1
    arc_1_20_9  original_T_including_depot_unload_1230  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1133  1
    load_1_20_9  segment_load_conservation_1176  -1
    load_1_20_9  segment_prefix_lb_1177  1
    load_1_20_9  segment_prefix_ub_1178  1
    load_1_20_9  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1135  -25
    arc_1_20_13  connected_order_arc_1136  -13
    arc_1_20_13  in_degree_1180  1
    arc_1_20_13  out_degree_1221  1
    arc_1_20_13  original_T_including_depot_unload_1230  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1135  1
    load_1_20_13  free_load_conservation_1184  -1
    load_1_20_13  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1137  -25
    arc_1_20_14  connected_order_arc_1138  -13
    arc_1_20_14  in_degree_1186  1
    arc_1_20_14  out_degree_1221  1
    arc_1_20_14  original_T_including_depot_unload_1230  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1137  1
    load_1_20_14  free_load_conservation_1190  -1
    load_1_20_14  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1139  -25
    arc_1_20_15  connected_order_arc_1140  -13
    arc_1_20_15  in_degree_1192  1
    arc_1_20_15  out_degree_1221  1
    arc_1_20_15  original_T_including_depot_unload_1230  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1139  1
    load_1_20_15  free_load_conservation_1196  -1
    load_1_20_15  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1141  -25
    arc_1_20_16  connected_order_arc_1142  -13
    arc_1_20_16  in_degree_1198  1
    arc_1_20_16  out_degree_1221  1
    arc_1_20_16  original_T_including_depot_unload_1230  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1141  1
    load_1_20_16  free_load_conservation_1202  -1
    load_1_20_16  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1143  -25
    arc_1_20_17  connected_order_arc_1144  -13
    arc_1_20_17  in_degree_1204  1
    arc_1_20_17  out_degree_1221  1
    arc_1_20_17  original_T_including_depot_unload_1230  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1143  1
    load_1_20_17  free_load_conservation_1208  -1
    load_1_20_17  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1145  -25
    arc_1_20_18  connected_order_arc_1146  -13
    arc_1_20_18  in_degree_1210  1
    arc_1_20_18  out_degree_1221  1
    arc_1_20_18  original_T_including_depot_unload_1230  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1145  1
    load_1_20_18  free_load_conservation_1214  -1
    load_1_20_18  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1147  -25
    arc_1_20_19  connected_order_arc_1148  -13
    arc_1_20_19  in_degree_1216  1
    arc_1_20_19  out_degree_1221  1
    arc_1_20_19  original_T_including_depot_unload_1230  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1147  1
    load_1_20_19  free_load_conservation_1220  -1
    load_1_20_19  free_load_conservation_1226  1
    visit_2_10  out_degree_1476  -1
    visit_2_10  in_degree_1477  -1
    visit_2_10  order_active_lb_1478  -1
    visit_2_10  order_active_ub_1479  -11
    order_2_10  connected_order_arc_1245  -1
    order_2_10  connected_order_arc_1247  -1
    order_2_10  connected_order_arc_1249  -1
    order_2_10  connected_order_arc_1251  -1
    order_2_10  connected_order_arc_1253  -1
    order_2_10  connected_order_arc_1255  -1
    order_2_10  connected_order_arc_1257  -1
    order_2_10  connected_order_arc_1259  -1
    order_2_10  connected_order_arc_1261  -1
    order_2_10  connected_order_arc_1263  -1
    order_2_10  connected_order_arc_1266  1
    order_2_10  connected_order_arc_1287  1
    order_2_10  connected_order_arc_1308  1
    order_2_10  connected_order_arc_1329  1
    order_2_10  connected_order_arc_1350  1
    order_2_10  connected_order_arc_1371  1
    order_2_10  connected_order_arc_1392  1
    order_2_10  connected_order_arc_1413  1
    order_2_10  connected_order_arc_1434  1
    order_2_10  connected_order_arc_1455  1
    order_2_10  order_active_lb_1478  1
    order_2_10  order_active_ub_1479  1
    order_2_10  fixed_segment_relative_order_1545  -1
    visit_2_11  out_degree_1483  -1
    visit_2_11  in_degree_1484  -1
    visit_2_11  order_active_lb_1485  -1
    visit_2_11  order_active_ub_1486  -11
    order_2_11  connected_order_arc_1245  1
    order_2_11  connected_order_arc_1266  -1
    order_2_11  connected_order_arc_1268  -1
    order_2_11  connected_order_arc_1270  -1
    order_2_11  connected_order_arc_1272  -1
    order_2_11  connected_order_arc_1274  -1
    order_2_11  connected_order_arc_1276  -1
    order_2_11  connected_order_arc_1278  -1
    order_2_11  connected_order_arc_1280  -1
    order_2_11  connected_order_arc_1282  -1
    order_2_11  connected_order_arc_1284  -1
    order_2_11  connected_order_arc_1289  1
    order_2_11  connected_order_arc_1310  1
    order_2_11  connected_order_arc_1331  1
    order_2_11  connected_order_arc_1352  1
    order_2_11  connected_order_arc_1373  1
    order_2_11  connected_order_arc_1394  1
    order_2_11  connected_order_arc_1415  1
    order_2_11  connected_order_arc_1436  1
    order_2_11  connected_order_arc_1457  1
    order_2_11  order_active_lb_1485  1
    order_2_11  order_active_ub_1486  1
    order_2_11  fixed_segment_relative_order_1545  1
    order_2_11  fixed_segment_relative_order_1546  -1
    visit_2_12  out_degree_1490  -1
    visit_2_12  in_degree_1491  -1
    visit_2_12  order_active_lb_1492  -1
    visit_2_12  order_active_ub_1493  -11
    order_2_12  connected_order_arc_1247  1
    order_2_12  connected_order_arc_1268  1
    order_2_12  connected_order_arc_1287  -1
    order_2_12  connected_order_arc_1289  -1
    order_2_12  connected_order_arc_1291  -1
    order_2_12  connected_order_arc_1293  -1
    order_2_12  connected_order_arc_1295  -1
    order_2_12  connected_order_arc_1297  -1
    order_2_12  connected_order_arc_1299  -1
    order_2_12  connected_order_arc_1301  -1
    order_2_12  connected_order_arc_1303  -1
    order_2_12  connected_order_arc_1305  -1
    order_2_12  connected_order_arc_1312  1
    order_2_12  connected_order_arc_1333  1
    order_2_12  connected_order_arc_1354  1
    order_2_12  connected_order_arc_1375  1
    order_2_12  connected_order_arc_1396  1
    order_2_12  connected_order_arc_1417  1
    order_2_12  connected_order_arc_1438  1
    order_2_12  connected_order_arc_1459  1
    order_2_12  order_active_lb_1492  1
    order_2_12  order_active_ub_1493  1
    order_2_12  fixed_segment_relative_order_1546  1
    visit_2_13  out_degree_1497  -1
    visit_2_13  in_degree_1498  -1
    visit_2_13  order_active_lb_1499  -1
    visit_2_13  order_active_ub_1500  -11
    visit_2_13  service_visit_def_1501  -1
    order_2_13  connected_order_arc_1249  1
    order_2_13  connected_order_arc_1270  1
    order_2_13  connected_order_arc_1291  1
    order_2_13  connected_order_arc_1308  -1
    order_2_13  connected_order_arc_1310  -1
    order_2_13  connected_order_arc_1312  -1
    order_2_13  connected_order_arc_1314  -1
    order_2_13  connected_order_arc_1316  -1
    order_2_13  connected_order_arc_1318  -1
    order_2_13  connected_order_arc_1320  -1
    order_2_13  connected_order_arc_1322  -1
    order_2_13  connected_order_arc_1324  -1
    order_2_13  connected_order_arc_1326  -1
    order_2_13  connected_order_arc_1335  1
    order_2_13  connected_order_arc_1356  1
    order_2_13  connected_order_arc_1377  1
    order_2_13  connected_order_arc_1398  1
    order_2_13  connected_order_arc_1419  1
    order_2_13  connected_order_arc_1440  1
    order_2_13  connected_order_arc_1461  1
    order_2_13  order_active_lb_1499  1
    order_2_13  order_active_ub_1500  1
    visit_2_14  out_degree_1503  -1
    visit_2_14  in_degree_1504  -1
    visit_2_14  order_active_lb_1505  -1
    visit_2_14  order_active_ub_1506  -11
    visit_2_14  service_visit_def_1507  -1
    order_2_14  connected_order_arc_1251  1
    order_2_14  connected_order_arc_1272  1
    order_2_14  connected_order_arc_1293  1
    order_2_14  connected_order_arc_1314  1
    order_2_14  connected_order_arc_1329  -1
    order_2_14  connected_order_arc_1331  -1
    order_2_14  connected_order_arc_1333  -1
    order_2_14  connected_order_arc_1335  -1
    order_2_14  connected_order_arc_1337  -1
    order_2_14  connected_order_arc_1339  -1
    order_2_14  connected_order_arc_1341  -1
    order_2_14  connected_order_arc_1343  -1
    order_2_14  connected_order_arc_1345  -1
    order_2_14  connected_order_arc_1347  -1
    order_2_14  connected_order_arc_1358  1
    order_2_14  connected_order_arc_1379  1
    order_2_14  connected_order_arc_1400  1
    order_2_14  connected_order_arc_1421  1
    order_2_14  connected_order_arc_1442  1
    order_2_14  connected_order_arc_1463  1
    order_2_14  order_active_lb_1505  1
    order_2_14  order_active_ub_1506  1
    visit_2_15  out_degree_1509  -1
    visit_2_15  in_degree_1510  -1
    visit_2_15  order_active_lb_1511  -1
    visit_2_15  order_active_ub_1512  -11
    visit_2_15  service_visit_def_1513  -1
    order_2_15  connected_order_arc_1253  1
    order_2_15  connected_order_arc_1274  1
    order_2_15  connected_order_arc_1295  1
    order_2_15  connected_order_arc_1316  1
    order_2_15  connected_order_arc_1337  1
    order_2_15  connected_order_arc_1350  -1
    order_2_15  connected_order_arc_1352  -1
    order_2_15  connected_order_arc_1354  -1
    order_2_15  connected_order_arc_1356  -1
    order_2_15  connected_order_arc_1358  -1
    order_2_15  connected_order_arc_1360  -1
    order_2_15  connected_order_arc_1362  -1
    order_2_15  connected_order_arc_1364  -1
    order_2_15  connected_order_arc_1366  -1
    order_2_15  connected_order_arc_1368  -1
    order_2_15  connected_order_arc_1381  1
    order_2_15  connected_order_arc_1402  1
    order_2_15  connected_order_arc_1423  1
    order_2_15  connected_order_arc_1444  1
    order_2_15  connected_order_arc_1465  1
    order_2_15  order_active_lb_1511  1
    order_2_15  order_active_ub_1512  1
    visit_2_16  out_degree_1515  -1
    visit_2_16  in_degree_1516  -1
    visit_2_16  order_active_lb_1517  -1
    visit_2_16  order_active_ub_1518  -11
    visit_2_16  service_visit_def_1519  -1
    order_2_16  connected_order_arc_1255  1
    order_2_16  connected_order_arc_1276  1
    order_2_16  connected_order_arc_1297  1
    order_2_16  connected_order_arc_1318  1
    order_2_16  connected_order_arc_1339  1
    order_2_16  connected_order_arc_1360  1
    order_2_16  connected_order_arc_1371  -1
    order_2_16  connected_order_arc_1373  -1
    order_2_16  connected_order_arc_1375  -1
    order_2_16  connected_order_arc_1377  -1
    order_2_16  connected_order_arc_1379  -1
    order_2_16  connected_order_arc_1381  -1
    order_2_16  connected_order_arc_1383  -1
    order_2_16  connected_order_arc_1385  -1
    order_2_16  connected_order_arc_1387  -1
    order_2_16  connected_order_arc_1389  -1
    order_2_16  connected_order_arc_1404  1
    order_2_16  connected_order_arc_1425  1
    order_2_16  connected_order_arc_1446  1
    order_2_16  connected_order_arc_1467  1
    order_2_16  order_active_lb_1517  1
    order_2_16  order_active_ub_1518  1
    visit_2_17  out_degree_1521  -1
    visit_2_17  in_degree_1522  -1
    visit_2_17  order_active_lb_1523  -1
    visit_2_17  order_active_ub_1524  -11
    visit_2_17  service_visit_def_1525  -1
    order_2_17  connected_order_arc_1257  1
    order_2_17  connected_order_arc_1278  1
    order_2_17  connected_order_arc_1299  1
    order_2_17  connected_order_arc_1320  1
    order_2_17  connected_order_arc_1341  1
    order_2_17  connected_order_arc_1362  1
    order_2_17  connected_order_arc_1383  1
    order_2_17  connected_order_arc_1392  -1
    order_2_17  connected_order_arc_1394  -1
    order_2_17  connected_order_arc_1396  -1
    order_2_17  connected_order_arc_1398  -1
    order_2_17  connected_order_arc_1400  -1
    order_2_17  connected_order_arc_1402  -1
    order_2_17  connected_order_arc_1404  -1
    order_2_17  connected_order_arc_1406  -1
    order_2_17  connected_order_arc_1408  -1
    order_2_17  connected_order_arc_1410  -1
    order_2_17  connected_order_arc_1427  1
    order_2_17  connected_order_arc_1448  1
    order_2_17  connected_order_arc_1469  1
    order_2_17  order_active_lb_1523  1
    order_2_17  order_active_ub_1524  1
    visit_2_18  out_degree_1527  -1
    visit_2_18  in_degree_1528  -1
    visit_2_18  order_active_lb_1529  -1
    visit_2_18  order_active_ub_1530  -11
    visit_2_18  service_visit_def_1531  -1
    order_2_18  connected_order_arc_1259  1
    order_2_18  connected_order_arc_1280  1
    order_2_18  connected_order_arc_1301  1
    order_2_18  connected_order_arc_1322  1
    order_2_18  connected_order_arc_1343  1
    order_2_18  connected_order_arc_1364  1
    order_2_18  connected_order_arc_1385  1
    order_2_18  connected_order_arc_1406  1
    order_2_18  connected_order_arc_1413  -1
    order_2_18  connected_order_arc_1415  -1
    order_2_18  connected_order_arc_1417  -1
    order_2_18  connected_order_arc_1419  -1
    order_2_18  connected_order_arc_1421  -1
    order_2_18  connected_order_arc_1423  -1
    order_2_18  connected_order_arc_1425  -1
    order_2_18  connected_order_arc_1427  -1
    order_2_18  connected_order_arc_1429  -1
    order_2_18  connected_order_arc_1431  -1
    order_2_18  connected_order_arc_1450  1
    order_2_18  connected_order_arc_1471  1
    order_2_18  order_active_lb_1529  1
    order_2_18  order_active_ub_1530  1
    visit_2_19  out_degree_1533  -1
    visit_2_19  in_degree_1534  -1
    visit_2_19  order_active_lb_1535  -1
    visit_2_19  order_active_ub_1536  -11
    visit_2_19  service_visit_def_1537  -1
    order_2_19  connected_order_arc_1261  1
    order_2_19  connected_order_arc_1282  1
    order_2_19  connected_order_arc_1303  1
    order_2_19  connected_order_arc_1324  1
    order_2_19  connected_order_arc_1345  1
    order_2_19  connected_order_arc_1366  1
    order_2_19  connected_order_arc_1387  1
    order_2_19  connected_order_arc_1408  1
    order_2_19  connected_order_arc_1429  1
    order_2_19  connected_order_arc_1434  -1
    order_2_19  connected_order_arc_1436  -1
    order_2_19  connected_order_arc_1438  -1
    order_2_19  connected_order_arc_1440  -1
    order_2_19  connected_order_arc_1442  -1
    order_2_19  connected_order_arc_1444  -1
    order_2_19  connected_order_arc_1446  -1
    order_2_19  connected_order_arc_1448  -1
    order_2_19  connected_order_arc_1450  -1
    order_2_19  connected_order_arc_1452  -1
    order_2_19  connected_order_arc_1473  1
    order_2_19  order_active_lb_1535  1
    order_2_19  order_active_ub_1536  1
    visit_2_20  out_degree_1539  -1
    visit_2_20  in_degree_1540  -1
    visit_2_20  order_active_lb_1541  -1
    visit_2_20  order_active_ub_1542  -11
    visit_2_20  service_visit_def_1543  -1
    order_2_20  connected_order_arc_1263  1
    order_2_20  connected_order_arc_1284  1
    order_2_20  connected_order_arc_1305  1
    order_2_20  connected_order_arc_1326  1
    order_2_20  connected_order_arc_1347  1
    order_2_20  connected_order_arc_1368  1
    order_2_20  connected_order_arc_1389  1
    order_2_20  connected_order_arc_1410  1
    order_2_20  connected_order_arc_1431  1
    order_2_20  connected_order_arc_1452  1
    order_2_20  connected_order_arc_1455  -1
    order_2_20  connected_order_arc_1457  -1
    order_2_20  connected_order_arc_1459  -1
    order_2_20  connected_order_arc_1461  -1
    order_2_20  connected_order_arc_1463  -1
    order_2_20  connected_order_arc_1465  -1
    order_2_20  connected_order_arc_1467  -1
    order_2_20  connected_order_arc_1469  -1
    order_2_20  connected_order_arc_1471  -1
    order_2_20  connected_order_arc_1473  -1
    order_2_20  order_active_lb_1541  1
    order_2_20  order_active_ub_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1231  -30
    arc_2_0_0  depot_departure_or_bypass_1474  1
    arc_2_0_0  depot_return_or_bypass_1475  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1232  -30
    arc_2_0_10  depot_departure_or_bypass_1474  1
    arc_2_0_10  in_degree_1477  1
    arc_2_0_10  original_T_including_depot_unload_1547  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1232  1
    load_2_0_10  segment_load_conservation_1480  -1
    load_2_0_10  segment_prefix_lb_1481  1
    load_2_0_10  segment_prefix_ub_1482  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1233  -30
    arc_2_0_11  depot_departure_or_bypass_1474  1
    arc_2_0_11  in_degree_1484  1
    arc_2_0_11  original_T_including_depot_unload_1547  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1233  1
    load_2_0_11  segment_load_conservation_1487  -1
    load_2_0_11  segment_prefix_lb_1488  1
    load_2_0_11  segment_prefix_ub_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1234  -30
    arc_2_0_12  depot_departure_or_bypass_1474  1
    arc_2_0_12  in_degree_1491  1
    arc_2_0_12  original_T_including_depot_unload_1547  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1234  1
    load_2_0_12  segment_load_conservation_1494  -1
    load_2_0_12  segment_prefix_lb_1495  1
    load_2_0_12  segment_prefix_ub_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1235  -30
    arc_2_0_13  depot_departure_or_bypass_1474  1
    arc_2_0_13  in_degree_1498  1
    arc_2_0_13  original_T_including_depot_unload_1547  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1235  1
    load_2_0_13  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1236  -30
    arc_2_0_14  depot_departure_or_bypass_1474  1
    arc_2_0_14  in_degree_1504  1
    arc_2_0_14  original_T_including_depot_unload_1547  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1236  1
    load_2_0_14  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1237  -30
    arc_2_0_15  depot_departure_or_bypass_1474  1
    arc_2_0_15  in_degree_1510  1
    arc_2_0_15  original_T_including_depot_unload_1547  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1237  1
    load_2_0_15  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1238  -30
    arc_2_0_16  depot_departure_or_bypass_1474  1
    arc_2_0_16  in_degree_1516  1
    arc_2_0_16  original_T_including_depot_unload_1547  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1238  1
    load_2_0_16  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1239  -30
    arc_2_0_17  depot_departure_or_bypass_1474  1
    arc_2_0_17  in_degree_1522  1
    arc_2_0_17  original_T_including_depot_unload_1547  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1239  1
    load_2_0_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1240  -30
    arc_2_0_18  depot_departure_or_bypass_1474  1
    arc_2_0_18  in_degree_1528  1
    arc_2_0_18  original_T_including_depot_unload_1547  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1240  1
    load_2_0_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1241  -30
    arc_2_0_19  depot_departure_or_bypass_1474  1
    arc_2_0_19  in_degree_1534  1
    arc_2_0_19  original_T_including_depot_unload_1547  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1241  1
    load_2_0_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1242  -30
    arc_2_0_20  depot_departure_or_bypass_1474  1
    arc_2_0_20  in_degree_1540  1
    arc_2_0_20  original_T_including_depot_unload_1547  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1242  1
    load_2_0_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1243  -30
    arc_2_10_0  depot_return_or_bypass_1475  1
    arc_2_10_0  out_degree_1476  1
    arc_2_10_0  original_T_including_depot_unload_1547  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1243  1
    load_2_10_0  segment_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1244  -30
    arc_2_10_11  connected_order_arc_1245  -12
    arc_2_10_11  out_degree_1476  1
    arc_2_10_11  in_degree_1484  1
    arc_2_10_11  original_T_including_depot_unload_1547  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1244  1
    load_2_10_11  segment_load_conservation_1480  1
    load_2_10_11  segment_load_conservation_1487  -1
    load_2_10_11  segment_prefix_lb_1488  1
    load_2_10_11  segment_prefix_ub_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1246  -30
    arc_2_10_12  connected_order_arc_1247  -12
    arc_2_10_12  out_degree_1476  1
    arc_2_10_12  in_degree_1491  1
    arc_2_10_12  original_T_including_depot_unload_1547  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1246  1
    load_2_10_12  segment_load_conservation_1480  1
    load_2_10_12  segment_load_conservation_1494  -1
    load_2_10_12  segment_prefix_lb_1495  1
    load_2_10_12  segment_prefix_ub_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1248  -30
    arc_2_10_13  connected_order_arc_1249  -12
    arc_2_10_13  out_degree_1476  1
    arc_2_10_13  in_degree_1498  1
    arc_2_10_13  original_T_including_depot_unload_1547  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1248  1
    load_2_10_13  segment_load_conservation_1480  1
    load_2_10_13  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1250  -30
    arc_2_10_14  connected_order_arc_1251  -12
    arc_2_10_14  out_degree_1476  1
    arc_2_10_14  in_degree_1504  1
    arc_2_10_14  original_T_including_depot_unload_1547  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1250  1
    load_2_10_14  segment_load_conservation_1480  1
    load_2_10_14  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1252  -30
    arc_2_10_15  connected_order_arc_1253  -12
    arc_2_10_15  out_degree_1476  1
    arc_2_10_15  in_degree_1510  1
    arc_2_10_15  original_T_including_depot_unload_1547  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1252  1
    load_2_10_15  segment_load_conservation_1480  1
    load_2_10_15  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1254  -30
    arc_2_10_16  connected_order_arc_1255  -12
    arc_2_10_16  out_degree_1476  1
    arc_2_10_16  in_degree_1516  1
    arc_2_10_16  original_T_including_depot_unload_1547  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1254  1
    load_2_10_16  segment_load_conservation_1480  1
    load_2_10_16  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1256  -30
    arc_2_10_17  connected_order_arc_1257  -12
    arc_2_10_17  out_degree_1476  1
    arc_2_10_17  in_degree_1522  1
    arc_2_10_17  original_T_including_depot_unload_1547  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1256  1
    load_2_10_17  segment_load_conservation_1480  1
    load_2_10_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1258  -30
    arc_2_10_18  connected_order_arc_1259  -12
    arc_2_10_18  out_degree_1476  1
    arc_2_10_18  in_degree_1528  1
    arc_2_10_18  original_T_including_depot_unload_1547  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1258  1
    load_2_10_18  segment_load_conservation_1480  1
    load_2_10_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1260  -30
    arc_2_10_19  connected_order_arc_1261  -12
    arc_2_10_19  out_degree_1476  1
    arc_2_10_19  in_degree_1534  1
    arc_2_10_19  original_T_including_depot_unload_1547  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1260  1
    load_2_10_19  segment_load_conservation_1480  1
    load_2_10_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1262  -30
    arc_2_10_20  connected_order_arc_1263  -12
    arc_2_10_20  out_degree_1476  1
    arc_2_10_20  in_degree_1540  1
    arc_2_10_20  original_T_including_depot_unload_1547  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1262  1
    load_2_10_20  segment_load_conservation_1480  1
    load_2_10_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1264  -30
    arc_2_11_0  depot_return_or_bypass_1475  1
    arc_2_11_0  out_degree_1483  1
    arc_2_11_0  original_T_including_depot_unload_1547  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1264  1
    load_2_11_0  segment_load_conservation_1487  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1265  -30
    arc_2_11_10  connected_order_arc_1266  -12
    arc_2_11_10  in_degree_1477  1
    arc_2_11_10  out_degree_1483  1
    arc_2_11_10  original_T_including_depot_unload_1547  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1265  1
    load_2_11_10  segment_load_conservation_1480  -1
    load_2_11_10  segment_prefix_lb_1481  1
    load_2_11_10  segment_prefix_ub_1482  1
    load_2_11_10  segment_load_conservation_1487  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1267  -30
    arc_2_11_12  connected_order_arc_1268  -12
    arc_2_11_12  out_degree_1483  1
    arc_2_11_12  in_degree_1491  1
    arc_2_11_12  original_T_including_depot_unload_1547  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1267  1
    load_2_11_12  segment_load_conservation_1487  1
    load_2_11_12  segment_load_conservation_1494  -1
    load_2_11_12  segment_prefix_lb_1495  1
    load_2_11_12  segment_prefix_ub_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1269  -30
    arc_2_11_13  connected_order_arc_1270  -12
    arc_2_11_13  out_degree_1483  1
    arc_2_11_13  in_degree_1498  1
    arc_2_11_13  original_T_including_depot_unload_1547  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1269  1
    load_2_11_13  segment_load_conservation_1487  1
    load_2_11_13  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1271  -30
    arc_2_11_14  connected_order_arc_1272  -12
    arc_2_11_14  out_degree_1483  1
    arc_2_11_14  in_degree_1504  1
    arc_2_11_14  original_T_including_depot_unload_1547  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1271  1
    load_2_11_14  segment_load_conservation_1487  1
    load_2_11_14  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1273  -30
    arc_2_11_15  connected_order_arc_1274  -12
    arc_2_11_15  out_degree_1483  1
    arc_2_11_15  in_degree_1510  1
    arc_2_11_15  original_T_including_depot_unload_1547  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1273  1
    load_2_11_15  segment_load_conservation_1487  1
    load_2_11_15  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1275  -30
    arc_2_11_16  connected_order_arc_1276  -12
    arc_2_11_16  out_degree_1483  1
    arc_2_11_16  in_degree_1516  1
    arc_2_11_16  original_T_including_depot_unload_1547  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1275  1
    load_2_11_16  segment_load_conservation_1487  1
    load_2_11_16  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1277  -30
    arc_2_11_17  connected_order_arc_1278  -12
    arc_2_11_17  out_degree_1483  1
    arc_2_11_17  in_degree_1522  1
    arc_2_11_17  original_T_including_depot_unload_1547  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1277  1
    load_2_11_17  segment_load_conservation_1487  1
    load_2_11_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1279  -30
    arc_2_11_18  connected_order_arc_1280  -12
    arc_2_11_18  out_degree_1483  1
    arc_2_11_18  in_degree_1528  1
    arc_2_11_18  original_T_including_depot_unload_1547  2.1293186465553604e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1279  1
    load_2_11_18  segment_load_conservation_1487  1
    load_2_11_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1281  -30
    arc_2_11_19  connected_order_arc_1282  -12
    arc_2_11_19  out_degree_1483  1
    arc_2_11_19  in_degree_1534  1
    arc_2_11_19  original_T_including_depot_unload_1547  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1281  1
    load_2_11_19  segment_load_conservation_1487  1
    load_2_11_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1283  -30
    arc_2_11_20  connected_order_arc_1284  -12
    arc_2_11_20  out_degree_1483  1
    arc_2_11_20  in_degree_1540  1
    arc_2_11_20  original_T_including_depot_unload_1547  1.6583475127728254e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1283  1
    load_2_11_20  segment_load_conservation_1487  1
    load_2_11_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1285  -30
    arc_2_12_0  depot_return_or_bypass_1475  1
    arc_2_12_0  out_degree_1490  1
    arc_2_12_0  original_T_including_depot_unload_1547  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1285  1
    load_2_12_0  segment_load_conservation_1494  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1286  -30
    arc_2_12_10  connected_order_arc_1287  -12
    arc_2_12_10  in_degree_1477  1
    arc_2_12_10  out_degree_1490  1
    arc_2_12_10  original_T_including_depot_unload_1547  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1286  1
    load_2_12_10  segment_load_conservation_1480  -1
    load_2_12_10  segment_prefix_lb_1481  1
    load_2_12_10  segment_prefix_ub_1482  1
    load_2_12_10  segment_load_conservation_1494  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1288  -30
    arc_2_12_11  connected_order_arc_1289  -12
    arc_2_12_11  in_degree_1484  1
    arc_2_12_11  out_degree_1490  1
    arc_2_12_11  original_T_including_depot_unload_1547  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1288  1
    load_2_12_11  segment_load_conservation_1487  -1
    load_2_12_11  segment_prefix_lb_1488  1
    load_2_12_11  segment_prefix_ub_1489  1
    load_2_12_11  segment_load_conservation_1494  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1290  -30
    arc_2_12_13  connected_order_arc_1291  -12
    arc_2_12_13  out_degree_1490  1
    arc_2_12_13  in_degree_1498  1
    arc_2_12_13  original_T_including_depot_unload_1547  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1290  1
    load_2_12_13  segment_load_conservation_1494  1
    load_2_12_13  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1292  -30
    arc_2_12_14  connected_order_arc_1293  -12
    arc_2_12_14  out_degree_1490  1
    arc_2_12_14  in_degree_1504  1
    arc_2_12_14  original_T_including_depot_unload_1547  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1292  1
    load_2_12_14  segment_load_conservation_1494  1
    load_2_12_14  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1294  -30
    arc_2_12_15  connected_order_arc_1295  -12
    arc_2_12_15  out_degree_1490  1
    arc_2_12_15  in_degree_1510  1
    arc_2_12_15  original_T_including_depot_unload_1547  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1294  1
    load_2_12_15  segment_load_conservation_1494  1
    load_2_12_15  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1296  -30
    arc_2_12_16  connected_order_arc_1297  -12
    arc_2_12_16  out_degree_1490  1
    arc_2_12_16  in_degree_1516  1
    arc_2_12_16  original_T_including_depot_unload_1547  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1296  1
    load_2_12_16  segment_load_conservation_1494  1
    load_2_12_16  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1298  -30
    arc_2_12_17  connected_order_arc_1299  -12
    arc_2_12_17  out_degree_1490  1
    arc_2_12_17  in_degree_1522  1
    arc_2_12_17  original_T_including_depot_unload_1547  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1298  1
    load_2_12_17  segment_load_conservation_1494  1
    load_2_12_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1300  -30
    arc_2_12_18  connected_order_arc_1301  -12
    arc_2_12_18  out_degree_1490  1
    arc_2_12_18  in_degree_1528  1
    arc_2_12_18  original_T_including_depot_unload_1547  1.5942479163822793e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1300  1
    load_2_12_18  segment_load_conservation_1494  1
    load_2_12_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1302  -30
    arc_2_12_19  connected_order_arc_1303  -12
    arc_2_12_19  out_degree_1490  1
    arc_2_12_19  in_degree_1534  1
    arc_2_12_19  original_T_including_depot_unload_1547  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1302  1
    load_2_12_19  segment_load_conservation_1494  1
    load_2_12_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1304  -30
    arc_2_12_20  connected_order_arc_1305  -12
    arc_2_12_20  out_degree_1490  1
    arc_2_12_20  in_degree_1540  1
    arc_2_12_20  original_T_including_depot_unload_1547  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1304  1
    load_2_12_20  segment_load_conservation_1494  1
    load_2_12_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1306  -30
    arc_2_13_0  depot_return_or_bypass_1475  1
    arc_2_13_0  out_degree_1497  1
    arc_2_13_0  original_T_including_depot_unload_1547  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1306  1
    load_2_13_0  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1307  -30
    arc_2_13_10  connected_order_arc_1308  -12
    arc_2_13_10  in_degree_1477  1
    arc_2_13_10  out_degree_1497  1
    arc_2_13_10  original_T_including_depot_unload_1547  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1307  1
    load_2_13_10  segment_load_conservation_1480  -1
    load_2_13_10  segment_prefix_lb_1481  1
    load_2_13_10  segment_prefix_ub_1482  1
    load_2_13_10  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1309  -30
    arc_2_13_11  connected_order_arc_1310  -12
    arc_2_13_11  in_degree_1484  1
    arc_2_13_11  out_degree_1497  1
    arc_2_13_11  original_T_including_depot_unload_1547  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1309  1
    load_2_13_11  segment_load_conservation_1487  -1
    load_2_13_11  segment_prefix_lb_1488  1
    load_2_13_11  segment_prefix_ub_1489  1
    load_2_13_11  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1311  -30
    arc_2_13_12  connected_order_arc_1312  -12
    arc_2_13_12  in_degree_1491  1
    arc_2_13_12  out_degree_1497  1
    arc_2_13_12  original_T_including_depot_unload_1547  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1311  1
    load_2_13_12  segment_load_conservation_1494  -1
    load_2_13_12  segment_prefix_lb_1495  1
    load_2_13_12  segment_prefix_ub_1496  1
    load_2_13_12  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1313  -30
    arc_2_13_14  connected_order_arc_1314  -12
    arc_2_13_14  out_degree_1497  1
    arc_2_13_14  in_degree_1504  1
    arc_2_13_14  original_T_including_depot_unload_1547  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1313  1
    load_2_13_14  free_load_conservation_1502  1
    load_2_13_14  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1315  -30
    arc_2_13_15  connected_order_arc_1316  -12
    arc_2_13_15  out_degree_1497  1
    arc_2_13_15  in_degree_1510  1
    arc_2_13_15  original_T_including_depot_unload_1547  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1315  1
    load_2_13_15  free_load_conservation_1502  1
    load_2_13_15  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1317  -30
    arc_2_13_16  connected_order_arc_1318  -12
    arc_2_13_16  out_degree_1497  1
    arc_2_13_16  in_degree_1516  1
    arc_2_13_16  original_T_including_depot_unload_1547  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1317  1
    load_2_13_16  free_load_conservation_1502  1
    load_2_13_16  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1319  -30
    arc_2_13_17  connected_order_arc_1320  -12
    arc_2_13_17  out_degree_1497  1
    arc_2_13_17  in_degree_1522  1
    arc_2_13_17  original_T_including_depot_unload_1547  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1319  1
    load_2_13_17  free_load_conservation_1502  1
    load_2_13_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1321  -30
    arc_2_13_18  connected_order_arc_1322  -12
    arc_2_13_18  out_degree_1497  1
    arc_2_13_18  in_degree_1528  1
    arc_2_13_18  original_T_including_depot_unload_1547  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1321  1
    load_2_13_18  free_load_conservation_1502  1
    load_2_13_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1323  -30
    arc_2_13_19  connected_order_arc_1324  -12
    arc_2_13_19  out_degree_1497  1
    arc_2_13_19  in_degree_1534  1
    arc_2_13_19  original_T_including_depot_unload_1547  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1323  1
    load_2_13_19  free_load_conservation_1502  1
    load_2_13_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1325  -30
    arc_2_13_20  connected_order_arc_1326  -12
    arc_2_13_20  out_degree_1497  1
    arc_2_13_20  in_degree_1540  1
    arc_2_13_20  original_T_including_depot_unload_1547  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1325  1
    load_2_13_20  free_load_conservation_1502  1
    load_2_13_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1327  -30
    arc_2_14_0  depot_return_or_bypass_1475  1
    arc_2_14_0  out_degree_1503  1
    arc_2_14_0  original_T_including_depot_unload_1547  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1327  1
    load_2_14_0  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1328  -30
    arc_2_14_10  connected_order_arc_1329  -12
    arc_2_14_10  in_degree_1477  1
    arc_2_14_10  out_degree_1503  1
    arc_2_14_10  original_T_including_depot_unload_1547  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1328  1
    load_2_14_10  segment_load_conservation_1480  -1
    load_2_14_10  segment_prefix_lb_1481  1
    load_2_14_10  segment_prefix_ub_1482  1
    load_2_14_10  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1330  -30
    arc_2_14_11  connected_order_arc_1331  -12
    arc_2_14_11  in_degree_1484  1
    arc_2_14_11  out_degree_1503  1
    arc_2_14_11  original_T_including_depot_unload_1547  1.9296708118526319e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1330  1
    load_2_14_11  segment_load_conservation_1487  -1
    load_2_14_11  segment_prefix_lb_1488  1
    load_2_14_11  segment_prefix_ub_1489  1
    load_2_14_11  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1332  -30
    arc_2_14_12  connected_order_arc_1333  -12
    arc_2_14_12  in_degree_1491  1
    arc_2_14_12  out_degree_1503  1
    arc_2_14_12  original_T_including_depot_unload_1547  1.2686001679750689e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1332  1
    load_2_14_12  segment_load_conservation_1494  -1
    load_2_14_12  segment_prefix_lb_1495  1
    load_2_14_12  segment_prefix_ub_1496  1
    load_2_14_12  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1334  -30
    arc_2_14_13  connected_order_arc_1335  -12
    arc_2_14_13  in_degree_1498  1
    arc_2_14_13  out_degree_1503  1
    arc_2_14_13  original_T_including_depot_unload_1547  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1334  1
    load_2_14_13  free_load_conservation_1502  -1
    load_2_14_13  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1336  -30
    arc_2_14_15  connected_order_arc_1337  -12
    arc_2_14_15  out_degree_1503  1
    arc_2_14_15  in_degree_1510  1
    arc_2_14_15  original_T_including_depot_unload_1547  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1336  1
    load_2_14_15  free_load_conservation_1508  1
    load_2_14_15  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1338  -30
    arc_2_14_16  connected_order_arc_1339  -12
    arc_2_14_16  out_degree_1503  1
    arc_2_14_16  in_degree_1516  1
    arc_2_14_16  original_T_including_depot_unload_1547  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1338  1
    load_2_14_16  free_load_conservation_1508  1
    load_2_14_16  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1340  -30
    arc_2_14_17  connected_order_arc_1341  -12
    arc_2_14_17  out_degree_1503  1
    arc_2_14_17  in_degree_1522  1
    arc_2_14_17  original_T_including_depot_unload_1547  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1340  1
    load_2_14_17  free_load_conservation_1508  1
    load_2_14_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1342  -30
    arc_2_14_18  connected_order_arc_1343  -12
    arc_2_14_18  out_degree_1503  1
    arc_2_14_18  in_degree_1528  1
    arc_2_14_18  original_T_including_depot_unload_1547  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1342  1
    load_2_14_18  free_load_conservation_1508  1
    load_2_14_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1344  -30
    arc_2_14_19  connected_order_arc_1345  -12
    arc_2_14_19  out_degree_1503  1
    arc_2_14_19  in_degree_1534  1
    arc_2_14_19  original_T_including_depot_unload_1547  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1344  1
    load_2_14_19  free_load_conservation_1508  1
    load_2_14_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1346  -30
    arc_2_14_20  connected_order_arc_1347  -12
    arc_2_14_20  out_degree_1503  1
    arc_2_14_20  in_degree_1540  1
    arc_2_14_20  original_T_including_depot_unload_1547  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1346  1
    load_2_14_20  free_load_conservation_1508  1
    load_2_14_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1348  -30
    arc_2_15_0  depot_return_or_bypass_1475  1
    arc_2_15_0  out_degree_1509  1
    arc_2_15_0  original_T_including_depot_unload_1547  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1348  1
    load_2_15_0  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1349  -30
    arc_2_15_10  connected_order_arc_1350  -12
    arc_2_15_10  in_degree_1477  1
    arc_2_15_10  out_degree_1509  1
    arc_2_15_10  original_T_including_depot_unload_1547  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1349  1
    load_2_15_10  segment_load_conservation_1480  -1
    load_2_15_10  segment_prefix_lb_1481  1
    load_2_15_10  segment_prefix_ub_1482  1
    load_2_15_10  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1351  -30
    arc_2_15_11  connected_order_arc_1352  -12
    arc_2_15_11  in_degree_1484  1
    arc_2_15_11  out_degree_1509  1
    arc_2_15_11  original_T_including_depot_unload_1547  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1351  1
    load_2_15_11  segment_load_conservation_1487  -1
    load_2_15_11  segment_prefix_lb_1488  1
    load_2_15_11  segment_prefix_ub_1489  1
    load_2_15_11  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1353  -30
    arc_2_15_12  connected_order_arc_1354  -12
    arc_2_15_12  in_degree_1491  1
    arc_2_15_12  out_degree_1509  1
    arc_2_15_12  original_T_including_depot_unload_1547  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1353  1
    load_2_15_12  segment_load_conservation_1494  -1
    load_2_15_12  segment_prefix_lb_1495  1
    load_2_15_12  segment_prefix_ub_1496  1
    load_2_15_12  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1355  -30
    arc_2_15_13  connected_order_arc_1356  -12
    arc_2_15_13  in_degree_1498  1
    arc_2_15_13  out_degree_1509  1
    arc_2_15_13  original_T_including_depot_unload_1547  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1355  1
    load_2_15_13  free_load_conservation_1502  -1
    load_2_15_13  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1357  -30
    arc_2_15_14  connected_order_arc_1358  -12
    arc_2_15_14  in_degree_1504  1
    arc_2_15_14  out_degree_1509  1
    arc_2_15_14  original_T_including_depot_unload_1547  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1357  1
    load_2_15_14  free_load_conservation_1508  -1
    load_2_15_14  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1359  -30
    arc_2_15_16  connected_order_arc_1360  -12
    arc_2_15_16  out_degree_1509  1
    arc_2_15_16  in_degree_1516  1
    arc_2_15_16  original_T_including_depot_unload_1547  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1359  1
    load_2_15_16  free_load_conservation_1514  1
    load_2_15_16  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1361  -30
    arc_2_15_17  connected_order_arc_1362  -12
    arc_2_15_17  out_degree_1509  1
    arc_2_15_17  in_degree_1522  1
    arc_2_15_17  original_T_including_depot_unload_1547  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1361  1
    load_2_15_17  free_load_conservation_1514  1
    load_2_15_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1363  -30
    arc_2_15_18  connected_order_arc_1364  -12
    arc_2_15_18  out_degree_1509  1
    arc_2_15_18  in_degree_1528  1
    arc_2_15_18  original_T_including_depot_unload_1547  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1363  1
    load_2_15_18  free_load_conservation_1514  1
    load_2_15_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1365  -30
    arc_2_15_19  connected_order_arc_1366  -12
    arc_2_15_19  out_degree_1509  1
    arc_2_15_19  in_degree_1534  1
    arc_2_15_19  original_T_including_depot_unload_1547  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1365  1
    load_2_15_19  free_load_conservation_1514  1
    load_2_15_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1367  -30
    arc_2_15_20  connected_order_arc_1368  -12
    arc_2_15_20  out_degree_1509  1
    arc_2_15_20  in_degree_1540  1
    arc_2_15_20  original_T_including_depot_unload_1547  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1367  1
    load_2_15_20  free_load_conservation_1514  1
    load_2_15_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1369  -30
    arc_2_16_0  depot_return_or_bypass_1475  1
    arc_2_16_0  out_degree_1515  1
    arc_2_16_0  original_T_including_depot_unload_1547  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1369  1
    load_2_16_0  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1370  -30
    arc_2_16_10  connected_order_arc_1371  -12
    arc_2_16_10  in_degree_1477  1
    arc_2_16_10  out_degree_1515  1
    arc_2_16_10  original_T_including_depot_unload_1547  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1370  1
    load_2_16_10  segment_load_conservation_1480  -1
    load_2_16_10  segment_prefix_lb_1481  1
    load_2_16_10  segment_prefix_ub_1482  1
    load_2_16_10  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1372  -30
    arc_2_16_11  connected_order_arc_1373  -12
    arc_2_16_11  in_degree_1484  1
    arc_2_16_11  out_degree_1515  1
    arc_2_16_11  original_T_including_depot_unload_1547  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1372  1
    load_2_16_11  segment_load_conservation_1487  -1
    load_2_16_11  segment_prefix_lb_1488  1
    load_2_16_11  segment_prefix_ub_1489  1
    load_2_16_11  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1374  -30
    arc_2_16_12  connected_order_arc_1375  -12
    arc_2_16_12  in_degree_1491  1
    arc_2_16_12  out_degree_1515  1
    arc_2_16_12  original_T_including_depot_unload_1547  1.6461188122693993e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1374  1
    load_2_16_12  segment_load_conservation_1494  -1
    load_2_16_12  segment_prefix_lb_1495  1
    load_2_16_12  segment_prefix_ub_1496  1
    load_2_16_12  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1376  -30
    arc_2_16_13  connected_order_arc_1377  -12
    arc_2_16_13  in_degree_1498  1
    arc_2_16_13  out_degree_1515  1
    arc_2_16_13  original_T_including_depot_unload_1547  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1376  1
    load_2_16_13  free_load_conservation_1502  -1
    load_2_16_13  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1378  -30
    arc_2_16_14  connected_order_arc_1379  -12
    arc_2_16_14  in_degree_1504  1
    arc_2_16_14  out_degree_1515  1
    arc_2_16_14  original_T_including_depot_unload_1547  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1378  1
    load_2_16_14  free_load_conservation_1508  -1
    load_2_16_14  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1380  -30
    arc_2_16_15  connected_order_arc_1381  -12
    arc_2_16_15  in_degree_1510  1
    arc_2_16_15  out_degree_1515  1
    arc_2_16_15  original_T_including_depot_unload_1547  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1380  1
    load_2_16_15  free_load_conservation_1514  -1
    load_2_16_15  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1382  -30
    arc_2_16_17  connected_order_arc_1383  -12
    arc_2_16_17  out_degree_1515  1
    arc_2_16_17  in_degree_1522  1
    arc_2_16_17  original_T_including_depot_unload_1547  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1382  1
    load_2_16_17  free_load_conservation_1520  1
    load_2_16_17  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1384  -30
    arc_2_16_18  connected_order_arc_1385  -12
    arc_2_16_18  out_degree_1515  1
    arc_2_16_18  in_degree_1528  1
    arc_2_16_18  original_T_including_depot_unload_1547  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1384  1
    load_2_16_18  free_load_conservation_1520  1
    load_2_16_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1386  -30
    arc_2_16_19  connected_order_arc_1387  -12
    arc_2_16_19  out_degree_1515  1
    arc_2_16_19  in_degree_1534  1
    arc_2_16_19  original_T_including_depot_unload_1547  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1386  1
    load_2_16_19  free_load_conservation_1520  1
    load_2_16_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1388  -30
    arc_2_16_20  connected_order_arc_1389  -12
    arc_2_16_20  out_degree_1515  1
    arc_2_16_20  in_degree_1540  1
    arc_2_16_20  original_T_including_depot_unload_1547  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1388  1
    load_2_16_20  free_load_conservation_1520  1
    load_2_16_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1390  -30
    arc_2_17_0  depot_return_or_bypass_1475  1
    arc_2_17_0  out_degree_1521  1
    arc_2_17_0  original_T_including_depot_unload_1547  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1390  1
    load_2_17_0  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1391  -30
    arc_2_17_10  connected_order_arc_1392  -12
    arc_2_17_10  in_degree_1477  1
    arc_2_17_10  out_degree_1521  1
    arc_2_17_10  original_T_including_depot_unload_1547  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1391  1
    load_2_17_10  segment_load_conservation_1480  -1
    load_2_17_10  segment_prefix_lb_1481  1
    load_2_17_10  segment_prefix_ub_1482  1
    load_2_17_10  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1393  -30
    arc_2_17_11  connected_order_arc_1394  -12
    arc_2_17_11  in_degree_1484  1
    arc_2_17_11  out_degree_1521  1
    arc_2_17_11  original_T_including_depot_unload_1547  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1393  1
    load_2_17_11  segment_load_conservation_1487  -1
    load_2_17_11  segment_prefix_lb_1488  1
    load_2_17_11  segment_prefix_ub_1489  1
    load_2_17_11  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1395  -30
    arc_2_17_12  connected_order_arc_1396  -12
    arc_2_17_12  in_degree_1491  1
    arc_2_17_12  out_degree_1521  1
    arc_2_17_12  original_T_including_depot_unload_1547  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1395  1
    load_2_17_12  segment_load_conservation_1494  -1
    load_2_17_12  segment_prefix_lb_1495  1
    load_2_17_12  segment_prefix_ub_1496  1
    load_2_17_12  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1397  -30
    arc_2_17_13  connected_order_arc_1398  -12
    arc_2_17_13  in_degree_1498  1
    arc_2_17_13  out_degree_1521  1
    arc_2_17_13  original_T_including_depot_unload_1547  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1397  1
    load_2_17_13  free_load_conservation_1502  -1
    load_2_17_13  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1399  -30
    arc_2_17_14  connected_order_arc_1400  -12
    arc_2_17_14  in_degree_1504  1
    arc_2_17_14  out_degree_1521  1
    arc_2_17_14  original_T_including_depot_unload_1547  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1399  1
    load_2_17_14  free_load_conservation_1508  -1
    load_2_17_14  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1401  -30
    arc_2_17_15  connected_order_arc_1402  -12
    arc_2_17_15  in_degree_1510  1
    arc_2_17_15  out_degree_1521  1
    arc_2_17_15  original_T_including_depot_unload_1547  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1401  1
    load_2_17_15  free_load_conservation_1514  -1
    load_2_17_15  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1403  -30
    arc_2_17_16  connected_order_arc_1404  -12
    arc_2_17_16  in_degree_1516  1
    arc_2_17_16  out_degree_1521  1
    arc_2_17_16  original_T_including_depot_unload_1547  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1403  1
    load_2_17_16  free_load_conservation_1520  -1
    load_2_17_16  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1405  -30
    arc_2_17_18  connected_order_arc_1406  -12
    arc_2_17_18  out_degree_1521  1
    arc_2_17_18  in_degree_1528  1
    arc_2_17_18  original_T_including_depot_unload_1547  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1405  1
    load_2_17_18  free_load_conservation_1526  1
    load_2_17_18  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1407  -30
    arc_2_17_19  connected_order_arc_1408  -12
    arc_2_17_19  out_degree_1521  1
    arc_2_17_19  in_degree_1534  1
    arc_2_17_19  original_T_including_depot_unload_1547  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1407  1
    load_2_17_19  free_load_conservation_1526  1
    load_2_17_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1409  -30
    arc_2_17_20  connected_order_arc_1410  -12
    arc_2_17_20  out_degree_1521  1
    arc_2_17_20  in_degree_1540  1
    arc_2_17_20  original_T_including_depot_unload_1547  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1409  1
    load_2_17_20  free_load_conservation_1526  1
    load_2_17_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1411  -30
    arc_2_18_0  depot_return_or_bypass_1475  1
    arc_2_18_0  out_degree_1527  1
    arc_2_18_0  original_T_including_depot_unload_1547  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1411  1
    load_2_18_0  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1412  -30
    arc_2_18_10  connected_order_arc_1413  -12
    arc_2_18_10  in_degree_1477  1
    arc_2_18_10  out_degree_1527  1
    arc_2_18_10  original_T_including_depot_unload_1547  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1412  1
    load_2_18_10  segment_load_conservation_1480  -1
    load_2_18_10  segment_prefix_lb_1481  1
    load_2_18_10  segment_prefix_ub_1482  1
    load_2_18_10  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1414  -30
    arc_2_18_11  connected_order_arc_1415  -12
    arc_2_18_11  in_degree_1484  1
    arc_2_18_11  out_degree_1527  1
    arc_2_18_11  original_T_including_depot_unload_1547  2.2630748095713293e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1414  1
    load_2_18_11  segment_load_conservation_1487  -1
    load_2_18_11  segment_prefix_lb_1488  1
    load_2_18_11  segment_prefix_ub_1489  1
    load_2_18_11  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1416  -30
    arc_2_18_12  connected_order_arc_1417  -12
    arc_2_18_12  in_degree_1491  1
    arc_2_18_12  out_degree_1527  1
    arc_2_18_12  original_T_including_depot_unload_1547  1.6809955292555005e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1416  1
    load_2_18_12  segment_load_conservation_1494  -1
    load_2_18_12  segment_prefix_lb_1495  1
    load_2_18_12  segment_prefix_ub_1496  1
    load_2_18_12  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1418  -30
    arc_2_18_13  connected_order_arc_1419  -12
    arc_2_18_13  in_degree_1498  1
    arc_2_18_13  out_degree_1527  1
    arc_2_18_13  original_T_including_depot_unload_1547  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1418  1
    load_2_18_13  free_load_conservation_1502  -1
    load_2_18_13  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1420  -30
    arc_2_18_14  connected_order_arc_1421  -12
    arc_2_18_14  in_degree_1504  1
    arc_2_18_14  out_degree_1527  1
    arc_2_18_14  original_T_including_depot_unload_1547  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1420  1
    load_2_18_14  free_load_conservation_1508  -1
    load_2_18_14  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1422  -30
    arc_2_18_15  connected_order_arc_1423  -12
    arc_2_18_15  in_degree_1510  1
    arc_2_18_15  out_degree_1527  1
    arc_2_18_15  original_T_including_depot_unload_1547  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1422  1
    load_2_18_15  free_load_conservation_1514  -1
    load_2_18_15  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1424  -30
    arc_2_18_16  connected_order_arc_1425  -12
    arc_2_18_16  in_degree_1516  1
    arc_2_18_16  out_degree_1527  1
    arc_2_18_16  original_T_including_depot_unload_1547  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1424  1
    load_2_18_16  free_load_conservation_1520  -1
    load_2_18_16  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1426  -30
    arc_2_18_17  connected_order_arc_1427  -12
    arc_2_18_17  in_degree_1522  1
    arc_2_18_17  out_degree_1527  1
    arc_2_18_17  original_T_including_depot_unload_1547  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1426  1
    load_2_18_17  free_load_conservation_1526  -1
    load_2_18_17  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1428  -30
    arc_2_18_19  connected_order_arc_1429  -12
    arc_2_18_19  out_degree_1527  1
    arc_2_18_19  in_degree_1534  1
    arc_2_18_19  original_T_including_depot_unload_1547  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1428  1
    load_2_18_19  free_load_conservation_1532  1
    load_2_18_19  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1430  -30
    arc_2_18_20  connected_order_arc_1431  -12
    arc_2_18_20  out_degree_1527  1
    arc_2_18_20  in_degree_1540  1
    arc_2_18_20  original_T_including_depot_unload_1547  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1430  1
    load_2_18_20  free_load_conservation_1532  1
    load_2_18_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1432  -30
    arc_2_19_0  depot_return_or_bypass_1475  1
    arc_2_19_0  out_degree_1533  1
    arc_2_19_0  original_T_including_depot_unload_1547  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1432  1
    load_2_19_0  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1433  -30
    arc_2_19_10  connected_order_arc_1434  -12
    arc_2_19_10  in_degree_1477  1
    arc_2_19_10  out_degree_1533  1
    arc_2_19_10  original_T_including_depot_unload_1547  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1433  1
    load_2_19_10  segment_load_conservation_1480  -1
    load_2_19_10  segment_prefix_lb_1481  1
    load_2_19_10  segment_prefix_ub_1482  1
    load_2_19_10  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1435  -30
    arc_2_19_11  connected_order_arc_1436  -12
    arc_2_19_11  in_degree_1484  1
    arc_2_19_11  out_degree_1533  1
    arc_2_19_11  original_T_including_depot_unload_1547  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1435  1
    load_2_19_11  segment_load_conservation_1487  -1
    load_2_19_11  segment_prefix_lb_1488  1
    load_2_19_11  segment_prefix_ub_1489  1
    load_2_19_11  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1437  -30
    arc_2_19_12  connected_order_arc_1438  -12
    arc_2_19_12  in_degree_1491  1
    arc_2_19_12  out_degree_1533  1
    arc_2_19_12  original_T_including_depot_unload_1547  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1437  1
    load_2_19_12  segment_load_conservation_1494  -1
    load_2_19_12  segment_prefix_lb_1495  1
    load_2_19_12  segment_prefix_ub_1496  1
    load_2_19_12  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1439  -30
    arc_2_19_13  connected_order_arc_1440  -12
    arc_2_19_13  in_degree_1498  1
    arc_2_19_13  out_degree_1533  1
    arc_2_19_13  original_T_including_depot_unload_1547  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1439  1
    load_2_19_13  free_load_conservation_1502  -1
    load_2_19_13  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1441  -30
    arc_2_19_14  connected_order_arc_1442  -12
    arc_2_19_14  in_degree_1504  1
    arc_2_19_14  out_degree_1533  1
    arc_2_19_14  original_T_including_depot_unload_1547  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1441  1
    load_2_19_14  free_load_conservation_1508  -1
    load_2_19_14  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1443  -30
    arc_2_19_15  connected_order_arc_1444  -12
    arc_2_19_15  in_degree_1510  1
    arc_2_19_15  out_degree_1533  1
    arc_2_19_15  original_T_including_depot_unload_1547  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1443  1
    load_2_19_15  free_load_conservation_1514  -1
    load_2_19_15  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1445  -30
    arc_2_19_16  connected_order_arc_1446  -12
    arc_2_19_16  in_degree_1516  1
    arc_2_19_16  out_degree_1533  1
    arc_2_19_16  original_T_including_depot_unload_1547  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1445  1
    load_2_19_16  free_load_conservation_1520  -1
    load_2_19_16  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1447  -30
    arc_2_19_17  connected_order_arc_1448  -12
    arc_2_19_17  in_degree_1522  1
    arc_2_19_17  out_degree_1533  1
    arc_2_19_17  original_T_including_depot_unload_1547  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1447  1
    load_2_19_17  free_load_conservation_1526  -1
    load_2_19_17  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1449  -30
    arc_2_19_18  connected_order_arc_1450  -12
    arc_2_19_18  in_degree_1528  1
    arc_2_19_18  out_degree_1533  1
    arc_2_19_18  original_T_including_depot_unload_1547  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1449  1
    load_2_19_18  free_load_conservation_1532  -1
    load_2_19_18  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1451  -30
    arc_2_19_20  connected_order_arc_1452  -12
    arc_2_19_20  out_degree_1533  1
    arc_2_19_20  in_degree_1540  1
    arc_2_19_20  original_T_including_depot_unload_1547  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1451  1
    load_2_19_20  free_load_conservation_1538  1
    load_2_19_20  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1453  -30
    arc_2_20_0  depot_return_or_bypass_1475  1
    arc_2_20_0  out_degree_1539  1
    arc_2_20_0  original_T_including_depot_unload_1547  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1453  1
    load_2_20_0  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1454  -30
    arc_2_20_10  connected_order_arc_1455  -12
    arc_2_20_10  in_degree_1477  1
    arc_2_20_10  out_degree_1539  1
    arc_2_20_10  original_T_including_depot_unload_1547  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1454  1
    load_2_20_10  segment_load_conservation_1480  -1
    load_2_20_10  segment_prefix_lb_1481  1
    load_2_20_10  segment_prefix_ub_1482  1
    load_2_20_10  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1456  -30
    arc_2_20_11  connected_order_arc_1457  -12
    arc_2_20_11  in_degree_1484  1
    arc_2_20_11  out_degree_1539  1
    arc_2_20_11  original_T_including_depot_unload_1547  1.9292357601859349e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1456  1
    load_2_20_11  segment_load_conservation_1487  -1
    load_2_20_11  segment_prefix_lb_1488  1
    load_2_20_11  segment_prefix_ub_1489  1
    load_2_20_11  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1458  -30
    arc_2_20_12  connected_order_arc_1459  -12
    arc_2_20_12  in_degree_1491  1
    arc_2_20_12  out_degree_1539  1
    arc_2_20_12  original_T_including_depot_unload_1547  1.0510800781097112e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1458  1
    load_2_20_12  segment_load_conservation_1494  -1
    load_2_20_12  segment_prefix_lb_1495  1
    load_2_20_12  segment_prefix_ub_1496  1
    load_2_20_12  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1460  -30
    arc_2_20_13  connected_order_arc_1461  -12
    arc_2_20_13  in_degree_1498  1
    arc_2_20_13  out_degree_1539  1
    arc_2_20_13  original_T_including_depot_unload_1547  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1460  1
    load_2_20_13  free_load_conservation_1502  -1
    load_2_20_13  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1462  -30
    arc_2_20_14  connected_order_arc_1463  -12
    arc_2_20_14  in_degree_1504  1
    arc_2_20_14  out_degree_1539  1
    arc_2_20_14  original_T_including_depot_unload_1547  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1462  1
    load_2_20_14  free_load_conservation_1508  -1
    load_2_20_14  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1464  -30
    arc_2_20_15  connected_order_arc_1465  -12
    arc_2_20_15  in_degree_1510  1
    arc_2_20_15  out_degree_1539  1
    arc_2_20_15  original_T_including_depot_unload_1547  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1464  1
    load_2_20_15  free_load_conservation_1514  -1
    load_2_20_15  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1466  -30
    arc_2_20_16  connected_order_arc_1467  -12
    arc_2_20_16  in_degree_1516  1
    arc_2_20_16  out_degree_1539  1
    arc_2_20_16  original_T_including_depot_unload_1547  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1466  1
    load_2_20_16  free_load_conservation_1520  -1
    load_2_20_16  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1468  -30
    arc_2_20_17  connected_order_arc_1469  -12
    arc_2_20_17  in_degree_1522  1
    arc_2_20_17  out_degree_1539  1
    arc_2_20_17  original_T_including_depot_unload_1547  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1468  1
    load_2_20_17  free_load_conservation_1526  -1
    load_2_20_17  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1470  -30
    arc_2_20_18  connected_order_arc_1471  -12
    arc_2_20_18  in_degree_1528  1
    arc_2_20_18  out_degree_1539  1
    arc_2_20_18  original_T_including_depot_unload_1547  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1470  1
    load_2_20_18  free_load_conservation_1532  -1
    load_2_20_18  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1472  -30
    arc_2_20_19  connected_order_arc_1473  -12
    arc_2_20_19  in_degree_1534  1
    arc_2_20_19  out_degree_1539  1
    arc_2_20_19  original_T_including_depot_unload_1547  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1472  1
    load_2_20_19  free_load_conservation_1538  -1
    load_2_20_19  free_load_conservation_1544  1
RHS
    RHS1      OBJ       -0.51
    RHS1      onehot_16_26  1
    RHS1      onehot_11_55  1
    RHS1      onehot_31_84  1
    RHS1      onehot_20_113  1
    RHS1      onehot_2_148  1
    RHS1      onehot_21_183  1
    RHS1      onehot_12_218  1
    RHS1      onehot_7_257  1
    RHS1      stock_ub_261  39
    RHS1      parent_nonstrict_scope_262  3.6792709424998687e-01
    RHS1      normalization_319  1
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_453  -13
    RHS1      connected_order_arc_455  -13
    RHS1      connected_order_arc_457  -13
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_680  -13
    RHS1      connected_order_arc_682  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_697  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_703  -13
    RHS1      connected_order_arc_705  -13
    RHS1      connected_order_arc_707  -13
    RHS1      connected_order_arc_709  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_722  -13
    RHS1      connected_order_arc_724  -13
    RHS1      connected_order_arc_726  -13
    RHS1      connected_order_arc_728  -13
    RHS1      connected_order_arc_730  -13
    RHS1      connected_order_arc_732  -13
    RHS1      connected_order_arc_734  -13
    RHS1      connected_order_arc_736  -13
    RHS1      connected_order_arc_738  -13
    RHS1      connected_order_arc_740  -13
    RHS1      connected_order_arc_742  -13
    RHS1      connected_order_arc_744  -13
    RHS1      connected_order_arc_747  -13
    RHS1      connected_order_arc_749  -13
    RHS1      connected_order_arc_751  -13
    RHS1      connected_order_arc_753  -13
    RHS1      connected_order_arc_755  -13
    RHS1      connected_order_arc_757  -13
    RHS1      connected_order_arc_759  -13
    RHS1      connected_order_arc_761  -13
    RHS1      connected_order_arc_763  -13
    RHS1      connected_order_arc_765  -13
    RHS1      connected_order_arc_767  -13
    RHS1      connected_order_arc_769  -13
    RHS1      depot_departure_or_bypass_770  1
    RHS1      depot_return_or_bypass_771  1
    RHS1      segment_load_conservation_776  4
    RHS1      segment_prefix_ub_778  16
    RHS1      segment_load_conservation_783  5
    RHS1      segment_prefix_ub_785  15
    RHS1      segment_load_conservation_790  -4
    RHS1      segment_prefix_lb_791  4
    RHS1      segment_prefix_ub_792  16
    RHS1      segment_load_conservation_797  -4
    RHS1      segment_prefix_lb_798  4
    RHS1      segment_prefix_ub_799  20
    RHS1      segment_load_conservation_804  -3
    RHS1      segment_prefix_lb_805  3
    RHS1      segment_prefix_ub_806  10
    RHS1      fixed_segment_relative_order_855  1
    RHS1      fixed_segment_relative_order_856  1
    RHS1      fixed_segment_relative_order_857  1
    RHS1      fixed_segment_relative_order_858  1
    RHS1      original_T_including_depot_unload_859  3.2240920200793707e+03
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1111  -12
    RHS1      connected_order_arc_1113  -12
    RHS1      connected_order_arc_1115  -12
    RHS1      connected_order_arc_1117  -12
    RHS1      connected_order_arc_1119  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1134  -12
    RHS1      connected_order_arc_1136  -12
    RHS1      connected_order_arc_1138  -12
    RHS1      connected_order_arc_1140  -12
    RHS1      connected_order_arc_1142  -12
    RHS1      connected_order_arc_1144  -12
    RHS1      connected_order_arc_1146  -12
    RHS1      connected_order_arc_1148  -12
    RHS1      depot_departure_or_bypass_1149  1
    RHS1      depot_return_or_bypass_1150  1
    RHS1      segment_load_conservation_1155  6
    RHS1      segment_prefix_ub_1157  19
    RHS1      segment_load_conservation_1162  -6
    RHS1      segment_prefix_lb_1163  6
    RHS1      segment_prefix_ub_1164  25
    RHS1      segment_load_conservation_1169  5
    RHS1      segment_prefix_ub_1171  20
    RHS1      segment_load_conservation_1176  1
    RHS1      segment_prefix_ub_1178  24
    RHS1      fixed_segment_relative_order_1227  1
    RHS1      fixed_segment_relative_order_1228  1
    RHS1      fixed_segment_relative_order_1229  1
    RHS1      original_T_including_depot_unload_1230  3.9607220700993348e+03
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1261  -11
    RHS1      connected_order_arc_1263  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1291  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1375  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1381  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1396  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1402  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1406  -11
    RHS1      connected_order_arc_1408  -11
    RHS1      connected_order_arc_1410  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1417  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1423  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      connected_order_arc_1427  -11
    RHS1      connected_order_arc_1429  -11
    RHS1      connected_order_arc_1431  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1436  -11
    RHS1      connected_order_arc_1438  -11
    RHS1      connected_order_arc_1440  -11
    RHS1      connected_order_arc_1442  -11
    RHS1      connected_order_arc_1444  -11
    RHS1      connected_order_arc_1446  -11
    RHS1      connected_order_arc_1448  -11
    RHS1      connected_order_arc_1450  -11
    RHS1      connected_order_arc_1452  -11
    RHS1      connected_order_arc_1455  -11
    RHS1      connected_order_arc_1457  -11
    RHS1      connected_order_arc_1459  -11
    RHS1      connected_order_arc_1461  -11
    RHS1      connected_order_arc_1463  -11
    RHS1      connected_order_arc_1465  -11
    RHS1      connected_order_arc_1467  -11
    RHS1      connected_order_arc_1469  -11
    RHS1      connected_order_arc_1471  -11
    RHS1      connected_order_arc_1473  -11
    RHS1      depot_departure_or_bypass_1474  1
    RHS1      depot_return_or_bypass_1475  1
    RHS1      segment_load_conservation_1480  2
    RHS1      segment_prefix_ub_1482  28
    RHS1      segment_load_conservation_1487  1
    RHS1      segment_prefix_ub_1489  27
    RHS1      segment_prefix_ub_1496  25
    RHS1      fixed_segment_relative_order_1545  1
    RHS1      fixed_segment_relative_order_1546  1
    RHS1      original_T_including_depot_unload_1547  4.4670949882505547e+03
BOUNDS
 LO BND1      t         2.5286733495865618e-02
 UP BND1      t         4.3203209381311537e-02
 UP BND1      q         5.7492709424998689e-01
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.3203209381311537e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.3203209381311537e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.3203209381311537e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.3203209381311537e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.3203209381311537e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.3203209381311537e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.3203209381311537e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.3203209381311537e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.3203209381311537e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.3203209381311537e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.3203209381311537e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.3203209381311537e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.3203209381311537e-02
 UP BND1      rho_16    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.3203209381311537e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.3203209381311537e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.3203209381311537e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.3203209381311537e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.3203209381311537e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.3203209381311537e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.3203209381311537e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.3203209381311537e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.3203209381311537e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.3203209381311537e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.3203209381311537e-02
 BV BND1      x_11_11 
 UP BND1      w_11_11   4.3203209381311537e-02
 BV BND1      x_11_12 
 UP BND1      w_11_12   4.3203209381311537e-02
 UP BND1      rho_11    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.3203209381311537e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.3203209381311537e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.3203209381311537e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.3203209381311537e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.3203209381311537e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.3203209381311537e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.3203209381311537e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.3203209381311537e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.3203209381311537e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.3203209381311537e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.3203209381311537e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.3203209381311537e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.3203209381311537e-02
 UP BND1      rho_31    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    4.3203209381311537e-02
 BV BND1      x_20_1  
 UP BND1      w_20_1    4.3203209381311537e-02
 BV BND1      x_20_2  
 UP BND1      w_20_2    4.3203209381311537e-02
 BV BND1      x_20_3  
 UP BND1      w_20_3    4.3203209381311537e-02
 BV BND1      x_20_4  
 UP BND1      w_20_4    4.3203209381311537e-02
 BV BND1      x_20_5  
 UP BND1      w_20_5    4.3203209381311537e-02
 BV BND1      x_20_6  
 UP BND1      w_20_6    4.3203209381311537e-02
 BV BND1      x_20_7  
 UP BND1      w_20_7    4.3203209381311537e-02
 BV BND1      x_20_8  
 UP BND1      w_20_8    4.3203209381311537e-02
 BV BND1      x_20_9  
 UP BND1      w_20_9    4.3203209381311537e-02
 BV BND1      x_20_10 
 UP BND1      w_20_10   4.3203209381311537e-02
 BV BND1      x_20_11 
 UP BND1      w_20_11   4.3203209381311537e-02
 BV BND1      x_20_12 
 UP BND1      w_20_12   4.3203209381311537e-02
 UP BND1      rho_20    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.3203209381311537e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.3203209381311537e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.3203209381311537e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.3203209381311537e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.3203209381311537e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.3203209381311537e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.3203209381311537e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.3203209381311537e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.3203209381311537e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.3203209381311537e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.3203209381311537e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.3203209381311537e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.3203209381311537e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.3203209381311537e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.3203209381311537e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.3203209381311537e-02
 UP BND1      rho_2     1
 BV BND1      x_21_0  
 UP BND1      w_21_0    4.3203209381311537e-02
 BV BND1      x_21_1  
 UP BND1      w_21_1    4.3203209381311537e-02
 BV BND1      x_21_2  
 UP BND1      w_21_2    4.3203209381311537e-02
 BV BND1      x_21_3  
 UP BND1      w_21_3    4.3203209381311537e-02
 BV BND1      x_21_4  
 UP BND1      w_21_4    4.3203209381311537e-02
 BV BND1      x_21_5  
 UP BND1      w_21_5    4.3203209381311537e-02
 BV BND1      x_21_6  
 UP BND1      w_21_6    4.3203209381311537e-02
 BV BND1      x_21_7  
 UP BND1      w_21_7    4.3203209381311537e-02
 BV BND1      x_21_8  
 UP BND1      w_21_8    4.3203209381311537e-02
 BV BND1      x_21_9  
 UP BND1      w_21_9    4.3203209381311537e-02
 BV BND1      x_21_10 
 UP BND1      w_21_10   4.3203209381311537e-02
 BV BND1      x_21_11 
 UP BND1      w_21_11   4.3203209381311537e-02
 BV BND1      x_21_12 
 UP BND1      w_21_12   4.3203209381311537e-02
 BV BND1      x_21_13 
 UP BND1      w_21_13   4.3203209381311537e-02
 BV BND1      x_21_14 
 UP BND1      w_21_14   4.3203209381311537e-02
 BV BND1      x_21_15 
 UP BND1      w_21_15   4.3203209381311537e-02
 UP BND1      rho_21    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.3203209381311537e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.3203209381311537e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.3203209381311537e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.3203209381311537e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.3203209381311537e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.3203209381311537e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.3203209381311537e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.3203209381311537e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.3203209381311537e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.3203209381311537e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.3203209381311537e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.3203209381311537e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.3203209381311537e-02
 BV BND1      x_12_13 
 UP BND1      w_12_13   4.3203209381311537e-02
 BV BND1      x_12_14 
 UP BND1      w_12_14   4.3203209381311537e-02
 BV BND1      x_12_15 
 UP BND1      w_12_15   4.3203209381311537e-02
 UP BND1      rho_12    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.3203209381311537e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.3203209381311537e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.3203209381311537e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.3203209381311537e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.3203209381311537e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.3203209381311537e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.3203209381311537e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.3203209381311537e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.3203209381311537e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.3203209381311537e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.3203209381311537e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.3203209381311537e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.3203209381311537e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.3203209381311537e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.3203209381311537e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.3203209381311537e-02
 BV BND1      x_7_16  
 UP BND1      w_7_16    4.3203209381311537e-02
 BV BND1      x_7_17  
 UP BND1      w_7_17    4.3203209381311537e-02
 UP BND1      rho_7     1
 UP BND1      a_16_11   1
 UP BND1      a_16_31   1
 UP BND1      a_16_20   1
 UP BND1      a_16_2    1
 UP BND1      a_16_21   1
 UP BND1      a_16_12   1
 UP BND1      a_16_7    1
 UP BND1      a_11_31   1
 UP BND1      a_11_20   1
 UP BND1      a_11_2    1
 UP BND1      a_11_21   1
 UP BND1      a_11_12   1
 UP BND1      a_11_7    1
 UP BND1      a_31_20   1
 UP BND1      a_31_2    1
 UP BND1      a_31_21   1
 UP BND1      a_31_12   1
 UP BND1      a_31_7    1
 UP BND1      a_20_2    1
 UP BND1      a_20_21   1
 UP BND1      a_20_12   1
 UP BND1      a_20_7    1
 UP BND1      a_2_21    1
 UP BND1      a_2_12    1
 UP BND1      a_2_7     1
 UP BND1      a_21_12   1
 UP BND1      a_21_7    1
 UP BND1      a_12_7    1
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_8
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 BV BND1      service_2_11_11
 BV BND1      service_2_11_12
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_12
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_12
 BV BND1      service_2_20_0
 BV BND1      service_2_20_1
 BV BND1      service_2_20_2
 BV BND1      service_2_20_3
 BV BND1      service_2_20_4
 BV BND1      service_2_20_5
 BV BND1      service_2_20_6
 BV BND1      service_2_20_7
 BV BND1      service_2_20_8
 BV BND1      service_2_20_10
 BV BND1      service_2_20_11
 BV BND1      service_2_20_12
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_21_0
 BV BND1      service_0_21_2
 BV BND1      service_0_21_3
 BV BND1      service_0_21_4
 BV BND1      service_0_21_5
 BV BND1      service_0_21_6
 BV BND1      service_0_21_7
 BV BND1      service_0_21_8
 BV BND1      service_0_21_9
 BV BND1      service_0_21_10
 BV BND1      service_0_21_11
 BV BND1      service_0_21_12
 BV BND1      service_0_21_13
 BV BND1      service_0_21_14
 BV BND1      service_0_21_15
 BV BND1      service_1_21_0
 BV BND1      service_1_21_2
 BV BND1      service_1_21_3
 BV BND1      service_1_21_4
 BV BND1      service_1_21_5
 BV BND1      service_1_21_6
 BV BND1      service_1_21_7
 BV BND1      service_1_21_8
 BV BND1      service_1_21_9
 BV BND1      service_1_21_10
 BV BND1      service_1_21_11
 BV BND1      service_1_21_12
 BV BND1      service_1_21_13
 BV BND1      service_1_21_14
 BV BND1      service_1_21_15
 BV BND1      service_2_21_0
 BV BND1      service_2_21_2
 BV BND1      service_2_21_3
 BV BND1      service_2_21_4
 BV BND1      service_2_21_5
 BV BND1      service_2_21_6
 BV BND1      service_2_21_7
 BV BND1      service_2_21_8
 BV BND1      service_2_21_9
 BV BND1      service_2_21_10
 BV BND1      service_2_21_11
 BV BND1      service_2_21_12
 BV BND1      service_2_21_13
 BV BND1      service_2_21_14
 BV BND1      service_2_21_15
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_2_12_1
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_2_12_13
 BV BND1      service_2_12_14
 BV BND1      service_2_12_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_1
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_0_7_16
 BV BND1      service_0_7_17
 BV BND1      service_1_7_0
 BV BND1      service_1_7_1
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_1_7_16
 BV BND1      service_1_7_17
 BV BND1      service_2_7_0
 BV BND1      service_2_7_1
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_2_7_16
 BV BND1      service_2_7_17
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
