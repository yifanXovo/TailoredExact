* Signature: 0x9d44b7267d167171
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_15_18
 E  normalized_mass_15_19
 E  normalized_ratio_15_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_13_39
 E  normalized_mass_13_40
 E  normalized_ratio_13_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_34_74
 E  normalized_mass_34_75
 E  normalized_ratio_34_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 E  onehot_17_91
 E  normalized_mass_17_92
 E  normalized_ratio_17_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 E  onehot_29_116
 E  normalized_mass_29_117
 E  normalized_ratio_29_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 E  onehot_18_141
 E  normalized_mass_18_142
 E  normalized_ratio_18_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 E  onehot_27_158
 E  normalized_mass_27_159
 E  normalized_ratio_27_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 E  onehot_19_183
 E  normalized_mass_19_184
 E  normalized_ratio_19_185
 G  stock_lb_186
 L  stock_ub_187
 L  parent_nonstrict_scope_188
 G  block_pair_pos_189
 G  block_pair_neg_190
 G  block_pair_pos_191
 G  block_pair_neg_192
 G  block_pair_pos_193
 G  block_pair_neg_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 E  normalization_245
 G  full_original_Gini_246
 E  unique_nonzero_owner_247
 E  unique_nonzero_owner_248
 E  unique_nonzero_owner_249
 E  unique_nonzero_owner_250
 E  unique_nonzero_owner_251
 E  unique_nonzero_owner_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 L  arc_capacity_320
 L  arc_capacity_321
 L  arc_capacity_322
 L  arc_capacity_323
 L  arc_capacity_324
 L  arc_capacity_325
 L  arc_capacity_326
 L  arc_capacity_327
 L  arc_capacity_328
 L  arc_capacity_329
 L  arc_capacity_330
 L  arc_capacity_331
 L  arc_capacity_332
 L  arc_capacity_333
 L  arc_capacity_334
 L  arc_capacity_335
 G  connected_order_arc_336
 L  arc_capacity_337
 G  connected_order_arc_338
 L  arc_capacity_339
 G  connected_order_arc_340
 L  arc_capacity_341
 G  connected_order_arc_342
 L  arc_capacity_343
 G  connected_order_arc_344
 L  arc_capacity_345
 G  connected_order_arc_346
 L  arc_capacity_347
 G  connected_order_arc_348
 L  arc_capacity_349
 G  connected_order_arc_350
 L  arc_capacity_351
 G  connected_order_arc_352
 L  arc_capacity_353
 G  connected_order_arc_354
 L  arc_capacity_355
 G  connected_order_arc_356
 L  arc_capacity_357
 G  connected_order_arc_358
 L  arc_capacity_359
 L  arc_capacity_360
 G  connected_order_arc_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 E  depot_departure_or_bypass_659
 E  depot_return_or_bypass_660
 E  out_degree_661
 E  in_degree_662
 G  order_active_lb_663
 L  order_active_ub_664
 E  segment_load_conservation_665
 G  segment_prefix_lb_666
 L  segment_prefix_ub_667
 E  out_degree_668
 E  in_degree_669
 G  order_active_lb_670
 L  order_active_ub_671
 E  segment_load_conservation_672
 G  segment_prefix_lb_673
 L  segment_prefix_ub_674
 E  out_degree_675
 E  in_degree_676
 G  order_active_lb_677
 L  order_active_ub_678
 E  segment_load_conservation_679
 G  segment_prefix_lb_680
 L  segment_prefix_ub_681
 E  out_degree_682
 E  in_degree_683
 G  order_active_lb_684
 L  order_active_ub_685
 E  segment_load_conservation_686
 G  segment_prefix_lb_687
 L  segment_prefix_ub_688
 E  out_degree_689
 E  in_degree_690
 G  order_active_lb_691
 L  order_active_ub_692
 E  segment_load_conservation_693
 G  segment_prefix_lb_694
 L  segment_prefix_ub_695
 E  out_degree_696
 E  in_degree_697
 G  order_active_lb_698
 L  order_active_ub_699
 E  service_visit_def_700
 E  free_load_conservation_701
 E  out_degree_702
 E  in_degree_703
 G  order_active_lb_704
 L  order_active_ub_705
 E  service_visit_def_706
 E  free_load_conservation_707
 E  out_degree_708
 E  in_degree_709
 G  order_active_lb_710
 L  order_active_ub_711
 E  service_visit_def_712
 E  free_load_conservation_713
 E  out_degree_714
 E  in_degree_715
 G  order_active_lb_716
 L  order_active_ub_717
 E  service_visit_def_718
 E  free_load_conservation_719
 E  out_degree_720
 E  in_degree_721
 G  order_active_lb_722
 L  order_active_ub_723
 E  service_visit_def_724
 E  free_load_conservation_725
 E  out_degree_726
 E  in_degree_727
 G  order_active_lb_728
 L  order_active_ub_729
 E  service_visit_def_730
 E  free_load_conservation_731
 E  out_degree_732
 E  in_degree_733
 G  order_active_lb_734
 L  order_active_ub_735
 E  service_visit_def_736
 E  free_load_conservation_737
 E  out_degree_738
 E  in_degree_739
 G  order_active_lb_740
 L  order_active_ub_741
 E  service_visit_def_742
 E  free_load_conservation_743
 G  fixed_segment_relative_order_744
 G  fixed_segment_relative_order_745
 G  fixed_segment_relative_order_746
 G  fixed_segment_relative_order_747
 L  original_T_including_depot_unload_748
 L  arc_capacity_749
 L  arc_capacity_750
 L  arc_capacity_751
 L  arc_capacity_752
 L  arc_capacity_753
 L  arc_capacity_754
 L  arc_capacity_755
 L  arc_capacity_756
 L  arc_capacity_757
 L  arc_capacity_758
 L  arc_capacity_759
 L  arc_capacity_760
 L  arc_capacity_761
 L  arc_capacity_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 E  depot_departure_or_bypass_1038
 E  depot_return_or_bypass_1039
 E  out_degree_1040
 E  in_degree_1041
 G  order_active_lb_1042
 L  order_active_ub_1043
 E  segment_load_conservation_1044
 G  segment_prefix_lb_1045
 L  segment_prefix_ub_1046
 E  out_degree_1047
 E  in_degree_1048
 G  order_active_lb_1049
 L  order_active_ub_1050
 E  segment_load_conservation_1051
 G  segment_prefix_lb_1052
 L  segment_prefix_ub_1053
 E  out_degree_1054
 E  in_degree_1055
 G  order_active_lb_1056
 L  order_active_ub_1057
 E  segment_load_conservation_1058
 G  segment_prefix_lb_1059
 L  segment_prefix_ub_1060
 E  out_degree_1061
 E  in_degree_1062
 G  order_active_lb_1063
 L  order_active_ub_1064
 E  segment_load_conservation_1065
 G  segment_prefix_lb_1066
 L  segment_prefix_ub_1067
 E  out_degree_1068
 E  in_degree_1069
 G  order_active_lb_1070
 L  order_active_ub_1071
 E  service_visit_def_1072
 E  free_load_conservation_1073
 E  out_degree_1074
 E  in_degree_1075
 G  order_active_lb_1076
 L  order_active_ub_1077
 E  service_visit_def_1078
 E  free_load_conservation_1079
 E  out_degree_1080
 E  in_degree_1081
 G  order_active_lb_1082
 L  order_active_ub_1083
 E  service_visit_def_1084
 E  free_load_conservation_1085
 E  out_degree_1086
 E  in_degree_1087
 G  order_active_lb_1088
 L  order_active_ub_1089
 E  service_visit_def_1090
 E  free_load_conservation_1091
 E  out_degree_1092
 E  in_degree_1093
 G  order_active_lb_1094
 L  order_active_ub_1095
 E  service_visit_def_1096
 E  free_load_conservation_1097
 E  out_degree_1098
 E  in_degree_1099
 G  order_active_lb_1100
 L  order_active_ub_1101
 E  service_visit_def_1102
 E  free_load_conservation_1103
 E  out_degree_1104
 E  in_degree_1105
 G  order_active_lb_1106
 L  order_active_ub_1107
 E  service_visit_def_1108
 E  free_load_conservation_1109
 E  out_degree_1110
 E  in_degree_1111
 G  order_active_lb_1112
 L  order_active_ub_1113
 E  service_visit_def_1114
 E  free_load_conservation_1115
 G  fixed_segment_relative_order_1116
 G  fixed_segment_relative_order_1117
 G  fixed_segment_relative_order_1118
 L  original_T_including_depot_unload_1119
 L  arc_capacity_1120
 L  arc_capacity_1121
 L  arc_capacity_1122
 L  arc_capacity_1123
 L  arc_capacity_1124
 L  arc_capacity_1125
 L  arc_capacity_1126
 L  arc_capacity_1127
 L  arc_capacity_1128
 L  arc_capacity_1129
 L  arc_capacity_1130
 L  arc_capacity_1131
 L  arc_capacity_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 E  depot_departure_or_bypass_1363
 E  depot_return_or_bypass_1364
 E  out_degree_1365
 E  in_degree_1366
 G  order_active_lb_1367
 L  order_active_ub_1368
 E  segment_load_conservation_1369
 G  segment_prefix_lb_1370
 L  segment_prefix_ub_1371
 E  out_degree_1372
 E  in_degree_1373
 G  order_active_lb_1374
 L  order_active_ub_1375
 E  segment_load_conservation_1376
 G  segment_prefix_lb_1377
 L  segment_prefix_ub_1378
 E  out_degree_1379
 E  in_degree_1380
 G  order_active_lb_1381
 L  order_active_ub_1382
 E  segment_load_conservation_1383
 G  segment_prefix_lb_1384
 L  segment_prefix_ub_1385
 E  out_degree_1386
 E  in_degree_1387
 G  order_active_lb_1388
 L  order_active_ub_1389
 E  service_visit_def_1390
 E  free_load_conservation_1391
 E  out_degree_1392
 E  in_degree_1393
 G  order_active_lb_1394
 L  order_active_ub_1395
 E  service_visit_def_1396
 E  free_load_conservation_1397
 E  out_degree_1398
 E  in_degree_1399
 G  order_active_lb_1400
 L  order_active_ub_1401
 E  service_visit_def_1402
 E  free_load_conservation_1403
 E  out_degree_1404
 E  in_degree_1405
 G  order_active_lb_1406
 L  order_active_ub_1407
 E  service_visit_def_1408
 E  free_load_conservation_1409
 E  out_degree_1410
 E  in_degree_1411
 G  order_active_lb_1412
 L  order_active_ub_1413
 E  service_visit_def_1414
 E  free_load_conservation_1415
 E  out_degree_1416
 E  in_degree_1417
 G  order_active_lb_1418
 L  order_active_ub_1419
 E  service_visit_def_1420
 E  free_load_conservation_1421
 E  out_degree_1422
 E  in_degree_1423
 G  order_active_lb_1424
 L  order_active_ub_1425
 E  service_visit_def_1426
 E  free_load_conservation_1427
 E  out_degree_1428
 E  in_degree_1429
 G  order_active_lb_1430
 L  order_active_ub_1431
 E  service_visit_def_1432
 E  free_load_conservation_1433
 G  fixed_segment_relative_order_1434
 G  fixed_segment_relative_order_1435
 L  original_T_including_depot_unload_1436
COLUMNS
    t         normalized_mass_15_19  -1
    t         normalized_mass_13_40  -1
    t         normalized_mass_34_75  -1
    t         normalized_mass_17_92  -1
    t         normalized_mass_29_117  -1
    t         normalized_mass_18_142  -1
    t         normalized_mass_27_159  -1
    t         normalized_mass_19_184  -1
    t         normalization_245  2.2534523809523808e+01
    t         full_original_Gini_246  -8.6633333333333411e+01
    q         OBJ       1
    q         parent_nonstrict_scope_188  1
    q         full_original_Gini_246  35
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       7.4474103065332977e-03
    x_15_0    product_lb_0  -2.6035209521422013e-02
    x_15_0    product_ub_1  -4.4376353742978512e-02
    x_15_0    onehot_15_18  1
    x_15_0    parent_nonstrict_scope_188  1.4894820613066595e-02
    x_15_0    unique_nonzero_owner_247  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_0  1
    w_15_0    product_ub_1  1
    w_15_0    normalized_mass_15_19  1
    w_15_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       3.7237051532666493e-03
    x_15_1    product_lb_2  -2.6035209521422013e-02
    x_15_1    product_ub_3  -4.4376353742978512e-02
    x_15_1    onehot_15_18  1
    x_15_1    stock_lb_186  1
    x_15_1    stock_ub_187  1
    x_15_1    parent_nonstrict_scope_188  1.1171115459799947e-02
    x_15_1    unique_nonzero_owner_248  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_2  1
    w_15_1    product_ub_3  1
    w_15_1    normalized_mass_15_19  1
    w_15_1    normalized_ratio_15_20  -0.25
    w_15_1    full_original_Gini_246  -1.6284523809523812e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_2    product_lb_4  -2.6035209521422013e-02
    x_15_2    product_ub_5  -4.4376353742978512e-02
    x_15_2    onehot_15_18  1
    x_15_2    stock_lb_186  2
    x_15_2    stock_ub_187  2
    x_15_2    parent_nonstrict_scope_188  7.4474103065332977e-03
    x_15_2    unique_nonzero_owner_249  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_2    product_lb_4  1
    w_15_2    product_ub_5  1
    w_15_2    normalized_mass_15_19  1
    w_15_2    normalized_ratio_15_20  -0.5
    w_15_2    full_original_Gini_246  -1.0367857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_3    OBJ       -3.7237051532666488e-03
    x_15_3    product_lb_6  -2.6035209521422013e-02
    x_15_3    product_ub_7  -4.4376353742978512e-02
    x_15_3    onehot_15_18  1
    x_15_3    stock_lb_186  3
    x_15_3    stock_ub_187  3
    x_15_3    parent_nonstrict_scope_188  3.7237051532666488e-03
    x_15_3    unique_nonzero_owner_250  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_3    product_lb_6  1
    w_15_3    product_ub_7  1
    w_15_3    normalized_mass_15_19  1
    w_15_3    normalized_ratio_15_20  -0.75
    w_15_3    full_original_Gini_246  -4.85595238095238
    MARKER    'MARKER'                 'INTORG'
    x_15_4    OBJ       -7.4474103065332977e-03
    x_15_4    product_lb_8  -2.6035209521422013e-02
    x_15_4    product_ub_9  -4.4376353742978512e-02
    x_15_4    onehot_15_18  1
    x_15_4    stock_lb_186  4
    x_15_4    stock_ub_187  4
    x_15_4    unique_nonzero_owner_251  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_4    product_lb_8  1
    w_15_4    product_ub_9  1
    w_15_4    normalized_mass_15_19  1
    w_15_4    normalized_ratio_15_20  -1
    w_15_4    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_5    OBJ       -3.7237051532666488e-03
    x_15_5    product_lb_10  -2.6035209521422013e-02
    x_15_5    product_ub_11  -4.4376353742978512e-02
    x_15_5    onehot_15_18  1
    x_15_5    stock_lb_186  5
    x_15_5    stock_ub_187  5
    x_15_5    parent_nonstrict_scope_188  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_15_5    product_lb_10  1
    w_15_5    product_ub_11  1
    w_15_5    normalized_mass_15_19  1
    w_15_5    normalized_ratio_15_20  -1.25
    w_15_5    full_original_Gini_246  -1.1715476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_6    product_lb_12  -2.6035209521422013e-02
    x_15_6    product_ub_13  -4.4376353742978512e-02
    x_15_6    onehot_15_18  1
    x_15_6    stock_lb_186  6
    x_15_6    stock_ub_187  6
    x_15_6    parent_nonstrict_scope_188  7.4474103065332977e-03
    x_15_6    unique_nonzero_owner_252  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_6    product_lb_12  1
    w_15_6    product_ub_13  1
    w_15_6    normalized_mass_15_19  1
    w_15_6    normalized_ratio_15_20  -1.5
    w_15_6    full_original_Gini_246  -1.7965476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_7    OBJ       3.7237051532666493e-03
    x_15_7    product_lb_14  -2.6035209521422013e-02
    x_15_7    product_ub_15  -4.4376353742978512e-02
    x_15_7    onehot_15_18  1
    x_15_7    stock_lb_186  7
    x_15_7    stock_ub_187  7
    x_15_7    parent_nonstrict_scope_188  1.1171115459799947e-02
    x_15_7    unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_7    product_lb_14  1
    w_15_7    product_ub_15  1
    w_15_7    normalized_mass_15_19  1
    w_15_7    normalized_ratio_15_20  -1.75
    w_15_7    full_original_Gini_246  -2.4715476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_8    OBJ       7.4474103065332977e-03
    x_15_8    product_lb_16  -2.6035209521422013e-02
    x_15_8    product_ub_17  -4.4376353742978512e-02
    x_15_8    onehot_15_18  1
    x_15_8    stock_lb_186  8
    x_15_8    stock_ub_187  8
    x_15_8    parent_nonstrict_scope_188  1.4894820613066595e-02
    x_15_8    unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_8    product_lb_16  1
    w_15_8    product_ub_17  1
    w_15_8    normalized_mass_15_19  1
    w_15_8    normalized_ratio_15_20  -2
    w_15_8    full_original_Gini_246  -3.1465476190476185e+01
    rho_15    normalized_ratio_15_20  1
    rho_15    block_pair_pos_201  -1
    rho_15    block_pair_neg_202  1
    rho_15    block_pair_pos_203  -1
    rho_15    block_pair_neg_204  1
    rho_15    block_pair_pos_205  -1
    rho_15    block_pair_neg_206  1
    rho_15    block_pair_pos_207  -1
    rho_15    block_pair_neg_208  1
    rho_15    block_pair_pos_209  -1
    rho_15    block_pair_neg_210  1
    rho_15    block_pair_pos_211  -1
    rho_15    block_pair_neg_212  1
    rho_15    block_pair_pos_213  -1
    rho_15    block_pair_neg_214  1
    rho_15    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       7.4474103065332977e-03
    x_13_0    product_lb_21  -2.6035209521422013e-02
    x_13_0    product_ub_22  -4.4376353742978512e-02
    x_13_0    onehot_13_39  1
    x_13_0    parent_nonstrict_scope_188  1.4894820613066595e-02
    x_13_0    unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_21  1
    w_13_0    product_ub_22  1
    w_13_0    normalized_mass_13_40  1
    w_13_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       3.7237051532666493e-03
    x_13_1    product_lb_23  -2.6035209521422013e-02
    x_13_1    product_ub_24  -4.4376353742978512e-02
    x_13_1    onehot_13_39  1
    x_13_1    stock_lb_186  1
    x_13_1    stock_ub_187  1
    x_13_1    parent_nonstrict_scope_188  1.1171115459799947e-02
    x_13_1    unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_23  1
    w_13_1    product_ub_24  1
    w_13_1    normalized_mass_13_40  1
    w_13_1    normalized_ratio_13_41  -0.25
    w_13_1    full_original_Gini_246  -1.6284523809523812e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    product_lb_25  -2.6035209521422013e-02
    x_13_2    product_ub_26  -4.4376353742978512e-02
    x_13_2    onehot_13_39  1
    x_13_2    stock_lb_186  2
    x_13_2    stock_ub_187  2
    x_13_2    parent_nonstrict_scope_188  7.4474103065332977e-03
    x_13_2    unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_25  1
    w_13_2    product_ub_26  1
    w_13_2    normalized_mass_13_40  1
    w_13_2    normalized_ratio_13_41  -0.5
    w_13_2    full_original_Gini_246  -1.0367857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -3.7237051532666488e-03
    x_13_3    product_lb_27  -2.6035209521422013e-02
    x_13_3    product_ub_28  -4.4376353742978512e-02
    x_13_3    onehot_13_39  1
    x_13_3    stock_lb_186  3
    x_13_3    stock_ub_187  3
    x_13_3    parent_nonstrict_scope_188  3.7237051532666488e-03
    x_13_3    unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_27  1
    w_13_3    product_ub_28  1
    w_13_3    normalized_mass_13_40  1
    w_13_3    normalized_ratio_13_41  -0.75
    w_13_3    full_original_Gini_246  -4.85595238095238
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -7.4474103065332977e-03
    x_13_4    product_lb_29  -2.6035209521422013e-02
    x_13_4    product_ub_30  -4.4376353742978512e-02
    x_13_4    onehot_13_39  1
    x_13_4    stock_lb_186  4
    x_13_4    stock_ub_187  4
    x_13_4    unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_29  1
    w_13_4    product_ub_30  1
    w_13_4    normalized_mass_13_40  1
    w_13_4    normalized_ratio_13_41  -1
    w_13_4    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -3.7237051532666488e-03
    x_13_5    product_lb_31  -2.6035209521422013e-02
    x_13_5    product_ub_32  -4.4376353742978512e-02
    x_13_5    onehot_13_39  1
    x_13_5    stock_lb_186  5
    x_13_5    stock_ub_187  5
    x_13_5    parent_nonstrict_scope_188  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_31  1
    w_13_5    product_ub_32  1
    w_13_5    normalized_mass_13_40  1
    w_13_5    normalized_ratio_13_41  -1.25
    w_13_5    full_original_Gini_246  -1.1715476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_6    product_lb_33  -2.6035209521422013e-02
    x_13_6    product_ub_34  -4.4376353742978512e-02
    x_13_6    onehot_13_39  1
    x_13_6    stock_lb_186  6
    x_13_6    stock_ub_187  6
    x_13_6    parent_nonstrict_scope_188  7.4474103065332977e-03
    x_13_6    unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_33  1
    w_13_6    product_ub_34  1
    w_13_6    normalized_mass_13_40  1
    w_13_6    normalized_ratio_13_41  -1.5
    w_13_6    full_original_Gini_246  -1.7965476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       3.7237051532666493e-03
    x_13_7    product_lb_35  -2.6035209521422013e-02
    x_13_7    product_ub_36  -4.4376353742978512e-02
    x_13_7    onehot_13_39  1
    x_13_7    stock_lb_186  7
    x_13_7    stock_ub_187  7
    x_13_7    parent_nonstrict_scope_188  1.1171115459799947e-02
    x_13_7    unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_35  1
    w_13_7    product_ub_36  1
    w_13_7    normalized_mass_13_40  1
    w_13_7    normalized_ratio_13_41  -1.75
    w_13_7    full_original_Gini_246  -2.4715476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       7.4474103065332977e-03
    x_13_8    product_lb_37  -2.6035209521422013e-02
    x_13_8    product_ub_38  -4.4376353742978512e-02
    x_13_8    onehot_13_39  1
    x_13_8    stock_lb_186  8
    x_13_8    stock_ub_187  8
    x_13_8    parent_nonstrict_scope_188  1.4894820613066595e-02
    x_13_8    unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_37  1
    w_13_8    product_ub_38  1
    w_13_8    normalized_mass_13_40  1
    w_13_8    normalized_ratio_13_41  -2
    w_13_8    full_original_Gini_246  -3.1465476190476185e+01
    rho_13    normalized_ratio_13_41  1
    rho_13    block_pair_pos_189  -1
    rho_13    block_pair_neg_190  1
    rho_13    block_pair_pos_191  -1
    rho_13    block_pair_neg_192  1
    rho_13    block_pair_pos_193  -1
    rho_13    block_pair_neg_194  1
    rho_13    block_pair_pos_195  -1
    rho_13    block_pair_neg_196  1
    rho_13    block_pair_pos_197  -1
    rho_13    block_pair_neg_198  1
    rho_13    block_pair_pos_199  -1
    rho_13    block_pair_neg_200  1
    rho_13    block_pair_pos_201  1
    rho_13    block_pair_neg_202  -1
    rho_13    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_42  -2.6035209521422013e-02
    x_34_0    product_ub_43  -4.4376353742978512e-02
    x_34_0    onehot_34_74  1
    x_34_0    parent_nonstrict_scope_188  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_42  1
    w_34_0    product_ub_43  1
    w_34_0    normalized_mass_34_75  1
    w_34_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_44  -2.6035209521422013e-02
    x_34_1    product_ub_45  -4.4376353742978512e-02
    x_34_1    onehot_34_74  1
    x_34_1    stock_lb_186  1
    x_34_1    stock_ub_187  1
    x_34_1    parent_nonstrict_scope_188  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_44  1
    w_34_1    product_ub_45  1
    w_34_1    normalized_mass_34_75  1
    w_34_1    normalized_ratio_34_76  -0.125
    w_34_1    full_original_Gini_246  -1.9409523809523812e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_46  -2.6035209521422013e-02
    x_34_2    product_ub_47  -4.4376353742978512e-02
    x_34_2    onehot_34_74  1
    x_34_2    stock_lb_186  2
    x_34_2    stock_ub_187  2
    x_34_2    parent_nonstrict_scope_188  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_46  1
    w_34_2    product_ub_47  1
    w_34_2    normalized_mass_34_75  1
    w_34_2    normalized_ratio_34_76  -0.25
    w_34_2    full_original_Gini_246  -1.6284523809523812e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_48  -2.6035209521422013e-02
    x_34_3    product_ub_49  -4.4376353742978512e-02
    x_34_3    onehot_34_74  1
    x_34_3    stock_lb_186  3
    x_34_3    stock_ub_187  3
    x_34_3    parent_nonstrict_scope_188  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_48  1
    w_34_3    product_ub_49  1
    w_34_3    normalized_mass_34_75  1
    w_34_3    normalized_ratio_34_76  -0.375
    w_34_3    full_original_Gini_246  -1.3242857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_50  -2.6035209521422013e-02
    x_34_4    product_ub_51  -4.4376353742978512e-02
    x_34_4    onehot_34_74  1
    x_34_4    stock_lb_186  4
    x_34_4    stock_ub_187  4
    x_34_4    parent_nonstrict_scope_188  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_50  1
    w_34_4    product_ub_51  1
    w_34_4    normalized_mass_34_75  1
    w_34_4    normalized_ratio_34_76  -0.5
    w_34_4    full_original_Gini_246  -1.0367857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_52  -2.6035209521422013e-02
    x_34_5    product_ub_53  -4.4376353742978512e-02
    x_34_5    onehot_34_74  1
    x_34_5    stock_lb_186  5
    x_34_5    stock_ub_187  5
    x_34_5    parent_nonstrict_scope_188  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_52  1
    w_34_5    product_ub_53  1
    w_34_5    normalized_mass_34_75  1
    w_34_5    normalized_ratio_34_76  -0.625
    w_34_5    full_original_Gini_246  -7.4928571428571429e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_54  -2.6035209521422013e-02
    x_34_6    product_ub_55  -4.4376353742978512e-02
    x_34_6    onehot_34_74  1
    x_34_6    stock_lb_186  6
    x_34_6    stock_ub_187  6
    x_34_6    parent_nonstrict_scope_188  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_54  1
    w_34_6    product_ub_55  1
    w_34_6    normalized_mass_34_75  1
    w_34_6    normalized_ratio_34_76  -0.75
    w_34_6    full_original_Gini_246  -4.85595238095238
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_56  -2.6035209521422013e-02
    x_34_7    product_ub_57  -4.4376353742978512e-02
    x_34_7    onehot_34_74  1
    x_34_7    stock_lb_186  7
    x_34_7    stock_ub_187  7
    x_34_7    parent_nonstrict_scope_188  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_56  1
    w_34_7    product_ub_57  1
    w_34_7    normalized_mass_34_75  1
    w_34_7    normalized_ratio_34_76  -0.875
    w_34_7    full_original_Gini_246  -4.3404761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_58  -2.6035209521422013e-02
    x_34_8    product_ub_59  -4.4376353742978512e-02
    x_34_8    onehot_34_74  1
    x_34_8    stock_lb_186  8
    x_34_8    stock_ub_187  8
    x_34_8    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_58  1
    w_34_8    product_ub_59  1
    w_34_8    normalized_mass_34_75  1
    w_34_8    normalized_ratio_34_76  -1
    w_34_8    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_60  -2.6035209521422013e-02
    x_34_9    product_ub_61  -4.4376353742978512e-02
    x_34_9    onehot_34_74  1
    x_34_9    stock_lb_186  9
    x_34_9    stock_ub_187  9
    x_34_9    parent_nonstrict_scope_188  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_60  1
    w_34_9    product_ub_61  1
    w_34_9    normalized_mass_34_75  1
    w_34_9    normalized_ratio_34_76  -1.125
    w_34_9    full_original_Gini_246  -8.59047619047619
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_62  -2.6035209521422013e-02
    x_34_10   product_ub_63  -4.4376353742978512e-02
    x_34_10   onehot_34_74  1
    x_34_10   stock_lb_186  10
    x_34_10   stock_ub_187  10
    x_34_10   parent_nonstrict_scope_188  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_62  1
    w_34_10   product_ub_63  1
    w_34_10   normalized_mass_34_75  1
    w_34_10   normalized_ratio_34_76  -1.25
    w_34_10   full_original_Gini_246  -1.1715476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_64  -2.6035209521422013e-02
    x_34_11   product_ub_65  -4.4376353742978512e-02
    x_34_11   onehot_34_74  1
    x_34_11   stock_lb_186  11
    x_34_11   stock_ub_187  11
    x_34_11   parent_nonstrict_scope_188  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_64  1
    w_34_11   product_ub_65  1
    w_34_11   normalized_mass_34_75  1
    w_34_11   normalized_ratio_34_76  -1.375
    w_34_11   full_original_Gini_246  -1.4840476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_66  -2.6035209521422013e-02
    x_34_12   product_ub_67  -4.4376353742978512e-02
    x_34_12   onehot_34_74  1
    x_34_12   stock_lb_186  12
    x_34_12   stock_ub_187  12
    x_34_12   parent_nonstrict_scope_188  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_66  1
    w_34_12   product_ub_67  1
    w_34_12   normalized_mass_34_75  1
    w_34_12   normalized_ratio_34_76  -1.5
    w_34_12   full_original_Gini_246  -1.7965476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_68  -2.6035209521422013e-02
    x_34_13   product_ub_69  -4.4376353742978512e-02
    x_34_13   onehot_34_74  1
    x_34_13   stock_lb_186  13
    x_34_13   stock_ub_187  13
    x_34_13   parent_nonstrict_scope_188  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_68  1
    w_34_13   product_ub_69  1
    w_34_13   normalized_mass_34_75  1
    w_34_13   normalized_ratio_34_76  -1.625
    w_34_13   full_original_Gini_246  -2.1340476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_70  -2.6035209521422013e-02
    x_34_14   product_ub_71  -4.4376353742978512e-02
    x_34_14   onehot_34_74  1
    x_34_14   stock_lb_186  14
    x_34_14   stock_ub_187  14
    x_34_14   parent_nonstrict_scope_188  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_70  1
    w_34_14   product_ub_71  1
    w_34_14   normalized_mass_34_75  1
    w_34_14   normalized_ratio_34_76  -1.75
    w_34_14   full_original_Gini_246  -2.4715476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_72  -2.6035209521422013e-02
    x_34_15   product_ub_73  -4.4376353742978512e-02
    x_34_15   onehot_34_74  1
    x_34_15   stock_lb_186  15
    x_34_15   stock_ub_187  15
    x_34_15   parent_nonstrict_scope_188  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_72  1
    w_34_15   product_ub_73  1
    w_34_15   normalized_mass_34_75  1
    w_34_15   normalized_ratio_34_76  -1.875
    w_34_15   full_original_Gini_246  -2.8090476190476188e+01
    rho_34    normalized_ratio_34_76  1
    rho_34    block_pair_pos_199  1
    rho_34    block_pair_neg_200  -1
    rho_34    block_pair_pos_213  1
    rho_34    block_pair_neg_214  -1
    rho_34    block_pair_pos_235  -1
    rho_34    block_pair_neg_236  1
    rho_34    block_pair_pos_237  -1
    rho_34    block_pair_neg_238  1
    rho_34    block_pair_pos_239  -1
    rho_34    block_pair_neg_240  1
    rho_34    block_pair_pos_241  -1
    rho_34    block_pair_neg_242  1
    rho_34    block_pair_pos_243  -1
    rho_34    block_pair_neg_244  1
    rho_34    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       4.1891612282083379e-03
    x_17_0    product_lb_77  -2.6035209521422013e-02
    x_17_0    product_ub_78  -4.4376353742978512e-02
    x_17_0    onehot_17_91  1
    x_17_0    parent_nonstrict_scope_188  8.3783224564166758e-03
    x_17_0    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_77  1
    w_17_0    product_ub_78  1
    w_17_0    normalized_mass_17_92  1
    w_17_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       1.3963870760694466e-03
    x_17_1    product_lb_79  -2.6035209521422013e-02
    x_17_1    product_ub_80  -4.4376353742978512e-02
    x_17_1    onehot_17_91  1
    x_17_1    stock_lb_186  1
    x_17_1    stock_ub_187  1
    x_17_1    parent_nonstrict_scope_188  5.5855483042777845e-03
    x_17_1    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_79  1
    w_17_1    product_ub_80  1
    w_17_1    normalized_mass_17_92  1
    w_17_1    normalized_ratio_17_93  -3.3333333333333331e-01
    w_17_1    full_original_Gini_246  -1.4201190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       -1.3963870760694457e-03
    x_17_2    product_lb_81  -2.6035209521422013e-02
    x_17_2    product_ub_82  -4.4376353742978512e-02
    x_17_2    onehot_17_91  1
    x_17_2    stock_lb_186  2
    x_17_2    stock_ub_187  2
    x_17_2    parent_nonstrict_scope_188  2.7927741521388922e-03
    x_17_2    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_81  1
    w_17_2    product_ub_82  1
    w_17_2    normalized_mass_17_92  1
    w_17_2    normalized_ratio_17_93  -6.6666666666666663e-01
    w_17_2    full_original_Gini_246  -6.5345238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       -4.1891612282083379e-03
    x_17_3    product_lb_83  -2.6035209521422013e-02
    x_17_3    product_ub_84  -4.4376353742978512e-02
    x_17_3    onehot_17_91  1
    x_17_3    stock_lb_186  3
    x_17_3    stock_ub_187  3
    x_17_3    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_83  1
    w_17_3    product_ub_84  1
    w_17_3    normalized_mass_17_92  1
    w_17_3    normalized_ratio_17_93  -1
    w_17_3    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       -1.3963870760694466e-03
    x_17_4    product_lb_85  -2.6035209521422013e-02
    x_17_4    product_ub_86  -4.4376353742978512e-02
    x_17_4    onehot_17_91  1
    x_17_4    stock_lb_186  4
    x_17_4    stock_ub_187  4
    x_17_4    parent_nonstrict_scope_188  2.7927741521388914e-03
    x_17_4    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_85  1
    w_17_4    product_ub_86  1
    w_17_4    normalized_mass_17_92  1
    w_17_4    normalized_ratio_17_93  -1.3333333333333333e+00
    w_17_4    full_original_Gini_246  -1.3798809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       1.3963870760694448e-03
    x_17_5    product_lb_87  -2.6035209521422013e-02
    x_17_5    product_ub_88  -4.4376353742978512e-02
    x_17_5    onehot_17_91  1
    x_17_5    stock_lb_186  5
    x_17_5    stock_ub_187  5
    x_17_5    parent_nonstrict_scope_188  5.5855483042777827e-03
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_87  1
    w_17_5    product_ub_88  1
    w_17_5    normalized_mass_17_92  1
    w_17_5    normalized_ratio_17_93  -1.6666666666666665e+00
    w_17_5    full_original_Gini_246  -2.2465476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       4.1891612282083379e-03
    x_17_6    product_lb_89  -2.6035209521422013e-02
    x_17_6    product_ub_90  -4.4376353742978512e-02
    x_17_6    onehot_17_91  1
    x_17_6    stock_lb_186  6
    x_17_6    stock_ub_187  6
    x_17_6    parent_nonstrict_scope_188  8.3783224564166758e-03
    x_17_6    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_89  1
    w_17_6    product_ub_90  1
    w_17_6    normalized_mass_17_92  1
    w_17_6    normalized_ratio_17_93  -2
    w_17_6    full_original_Gini_246  -3.1465476190476185e+01
    rho_17    normalized_ratio_17_93  1
    rho_17    block_pair_pos_189  1
    rho_17    block_pair_neg_190  -1
    rho_17    block_pair_pos_203  1
    rho_17    block_pair_neg_204  -1
    rho_17    block_pair_pos_215  -1
    rho_17    block_pair_neg_216  1
    rho_17    block_pair_pos_217  -1
    rho_17    block_pair_neg_218  1
    rho_17    block_pair_pos_219  -1
    rho_17    block_pair_neg_220  1
    rho_17    block_pair_pos_221  -1
    rho_17    block_pair_neg_222  1
    rho_17    block_pair_pos_235  1
    rho_17    block_pair_neg_236  -1
    rho_17    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_94  -2.6035209521422013e-02
    x_29_0    product_ub_95  -4.4376353742978512e-02
    x_29_0    onehot_29_116  1
    x_29_0    parent_nonstrict_scope_188  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_94  1
    w_29_0    product_ub_95  1
    w_29_0    normalized_mass_29_117  1
    w_29_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_96  -2.6035209521422013e-02
    x_29_1    product_ub_97  -4.4376353742978512e-02
    x_29_1    onehot_29_116  1
    x_29_1    stock_lb_186  1
    x_29_1    stock_ub_187  1
    x_29_1    parent_nonstrict_scope_188  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_96  1
    w_29_1    product_ub_97  1
    w_29_1    normalized_mass_29_117  1
    w_29_1    normalized_ratio_29_118  -0.2
    w_29_1    full_original_Gini_246  -1.7534523809523815e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_98  -2.6035209521422013e-02
    x_29_2    product_ub_99  -4.4376353742978512e-02
    x_29_2    onehot_29_116  1
    x_29_2    stock_lb_186  2
    x_29_2    stock_ub_187  2
    x_29_2    parent_nonstrict_scope_188  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_98  1
    w_29_2    product_ub_99  1
    w_29_2    normalized_mass_29_117  1
    w_29_2    normalized_ratio_29_118  -0.4
    w_29_2    full_original_Gini_246  -1.2667857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_100  -2.6035209521422013e-02
    x_29_3    product_ub_101  -4.4376353742978512e-02
    x_29_3    onehot_29_116  1
    x_29_3    stock_lb_186  3
    x_29_3    stock_ub_187  3
    x_29_3    parent_nonstrict_scope_188  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_100  1
    w_29_3    product_ub_101  1
    w_29_3    normalized_mass_29_117  1
    w_29_3    normalized_ratio_29_118  -6.0000000000000009e-01
    w_29_3    full_original_Gini_246  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_102  -2.6035209521422013e-02
    x_29_4    product_ub_103  -4.4376353742978512e-02
    x_29_4    onehot_29_116  1
    x_29_4    stock_lb_186  4
    x_29_4    stock_ub_187  4
    x_29_4    parent_nonstrict_scope_188  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_102  1
    w_29_4    product_ub_103  1
    w_29_4    normalized_mass_29_117  1
    w_29_4    normalized_ratio_29_118  -0.8
    w_29_4    full_original_Gini_246  -4.40595238095238
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_104  -2.6035209521422013e-02
    x_29_5    product_ub_105  -4.4376353742978512e-02
    x_29_5    onehot_29_116  1
    x_29_5    stock_lb_186  5
    x_29_5    stock_ub_187  5
    x_29_5    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_104  1
    w_29_5    product_ub_105  1
    w_29_5    normalized_mass_29_117  1
    w_29_5    normalized_ratio_29_118  -1
    w_29_5    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_106  -2.6035209521422013e-02
    x_29_6    product_ub_107  -4.4376353742978512e-02
    x_29_6    onehot_29_116  1
    x_29_6    stock_lb_186  6
    x_29_6    stock_ub_187  6
    x_29_6    parent_nonstrict_scope_188  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_106  1
    w_29_6    product_ub_107  1
    w_29_6    normalized_mass_29_117  1
    w_29_6    normalized_ratio_29_118  -1.2000000000000002e+00
    w_29_6    full_original_Gini_246  -1.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_108  -2.6035209521422013e-02
    x_29_7    product_ub_109  -4.4376353742978512e-02
    x_29_7    onehot_29_116  1
    x_29_7    stock_lb_186  7
    x_29_7    stock_ub_187  7
    x_29_7    parent_nonstrict_scope_188  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_108  1
    w_29_7    product_ub_109  1
    w_29_7    normalized_mass_29_117  1
    w_29_7    normalized_ratio_29_118  -1.4000000000000001e+00
    w_29_7    full_original_Gini_246  -1.5465476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_110  -2.6035209521422013e-02
    x_29_8    product_ub_111  -4.4376353742978512e-02
    x_29_8    onehot_29_116  1
    x_29_8    stock_lb_186  8
    x_29_8    stock_ub_187  8
    x_29_8    parent_nonstrict_scope_188  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_110  1
    w_29_8    product_ub_111  1
    w_29_8    normalized_mass_29_117  1
    w_29_8    normalized_ratio_29_118  -1.6
    w_29_8    full_original_Gini_246  -2.0665476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_112  -2.6035209521422013e-02
    x_29_9    product_ub_113  -4.4376353742978512e-02
    x_29_9    onehot_29_116  1
    x_29_9    stock_lb_186  9
    x_29_9    stock_ub_187  9
    x_29_9    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_112  1
    w_29_9    product_ub_113  1
    w_29_9    normalized_mass_29_117  1
    w_29_9    normalized_ratio_29_118  -1.8
    w_29_9    full_original_Gini_246  -26.0654761904762
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_114  -2.6035209521422013e-02
    x_29_10   product_ub_115  -4.4376353742978512e-02
    x_29_10   onehot_29_116  1
    x_29_10   stock_lb_186  10
    x_29_10   stock_ub_187  10
    x_29_10   parent_nonstrict_scope_188  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_114  1
    w_29_10   product_ub_115  1
    w_29_10   normalized_mass_29_117  1
    w_29_10   normalized_ratio_29_118  -2
    w_29_10   full_original_Gini_246  -3.1465476190476185e+01
    rho_29    normalized_ratio_29_118  1
    rho_29    block_pair_pos_197  1
    rho_29    block_pair_neg_198  -1
    rho_29    block_pair_pos_211  1
    rho_29    block_pair_neg_212  -1
    rho_29    block_pair_pos_221  1
    rho_29    block_pair_neg_222  -1
    rho_29    block_pair_pos_229  -1
    rho_29    block_pair_neg_230  1
    rho_29    block_pair_pos_231  -1
    rho_29    block_pair_neg_232  1
    rho_29    block_pair_pos_233  -1
    rho_29    block_pair_neg_234  1
    rho_29    block_pair_pos_243  1
    rho_29    block_pair_neg_244  -1
    rho_29    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       1.1636571534741636e-02
    x_18_0    product_lb_119  -2.6035209521422013e-02
    x_18_0    product_ub_120  -4.4376353742978512e-02
    x_18_0    onehot_18_141  1
    x_18_0    parent_nonstrict_scope_188  2.3273143069483273e-02
    x_18_0    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_119  1
    w_18_0    product_ub_120  1
    w_18_0    normalized_mass_18_142  1
    w_18_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       6.9819429208449833e-03
    x_18_1    product_lb_121  -2.6035209521422013e-02
    x_18_1    product_ub_122  -4.4376353742978512e-02
    x_18_1    onehot_18_141  1
    x_18_1    stock_lb_186  1
    x_18_1    stock_ub_187  1
    x_18_1    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_18_1    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_121  1
    w_18_1    product_ub_122  1
    w_18_1    normalized_mass_18_142  1
    w_18_1    normalized_ratio_18_143  -0.2
    w_18_1    full_original_Gini_246  -1.7534523809523815e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       2.3273143069483266e-03
    x_18_2    product_lb_123  -2.6035209521422013e-02
    x_18_2    product_ub_124  -4.4376353742978512e-02
    x_18_2    onehot_18_141  1
    x_18_2    stock_lb_186  2
    x_18_2    stock_ub_187  2
    x_18_2    parent_nonstrict_scope_188  1.3963885841689963e-02
    x_18_2    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_123  1
    w_18_2    product_ub_124  1
    w_18_2    normalized_mass_18_142  1
    w_18_2    normalized_ratio_18_143  -0.4
    w_18_2    full_original_Gini_246  -1.2667857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_3    OBJ       -0.00232731430694833
    x_18_3    product_lb_125  -2.6035209521422013e-02
    x_18_3    product_ub_126  -4.4376353742978512e-02
    x_18_3    onehot_18_141  1
    x_18_3    stock_lb_186  3
    x_18_3    stock_ub_187  3
    x_18_3    parent_nonstrict_scope_188  9.3092572277933064e-03
    x_18_3    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_125  1
    w_18_3    product_ub_126  1
    w_18_3    normalized_mass_18_142  1
    w_18_3    normalized_ratio_18_143  -6.0000000000000009e-01
    w_18_3    full_original_Gini_246  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -6.9819429208449833e-03
    x_18_4    product_lb_127  -2.6035209521422013e-02
    x_18_4    product_ub_128  -4.4376353742978512e-02
    x_18_4    onehot_18_141  1
    x_18_4    stock_lb_186  4
    x_18_4    stock_ub_187  4
    x_18_4    parent_nonstrict_scope_188  4.6546286138966532e-03
    x_18_4    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_127  1
    w_18_4    product_ub_128  1
    w_18_4    normalized_mass_18_142  1
    w_18_4    normalized_ratio_18_143  -0.8
    w_18_4    full_original_Gini_246  -4.40595238095238
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -1.1636571534741636e-02
    x_18_5    product_lb_129  -2.6035209521422013e-02
    x_18_5    product_ub_130  -4.4376353742978512e-02
    x_18_5    onehot_18_141  1
    x_18_5    stock_lb_186  5
    x_18_5    stock_ub_187  5
    x_18_5    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_129  1
    w_18_5    product_ub_130  1
    w_18_5    normalized_mass_18_142  1
    w_18_5    normalized_ratio_18_143  -1
    w_18_5    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -6.9819429208449781e-03
    x_18_6    product_lb_131  -2.6035209521422013e-02
    x_18_6    product_ub_132  -4.4376353742978512e-02
    x_18_6    onehot_18_141  1
    x_18_6    stock_lb_186  6
    x_18_6    stock_ub_187  6
    x_18_6    parent_nonstrict_scope_188  4.6546286138966584e-03
    x_18_6    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_131  1
    w_18_6    product_ub_132  1
    w_18_6    normalized_mass_18_142  1
    w_18_6    normalized_ratio_18_143  -1.2000000000000002e+00
    w_18_6    full_original_Gini_246  -1.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -2.3273143069483249e-03
    x_18_7    product_lb_133  -2.6035209521422013e-02
    x_18_7    product_ub_134  -4.4376353742978512e-02
    x_18_7    onehot_18_141  1
    x_18_7    stock_lb_186  7
    x_18_7    stock_ub_187  7
    x_18_7    parent_nonstrict_scope_188  9.3092572277933116e-03
    x_18_7    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_133  1
    w_18_7    product_ub_134  1
    w_18_7    normalized_mass_18_142  1
    w_18_7    normalized_ratio_18_143  -1.4000000000000001e+00
    w_18_7    full_original_Gini_246  -1.5465476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       0.00232731430694833
    x_18_8    product_lb_135  -2.6035209521422013e-02
    x_18_8    product_ub_136  -4.4376353742978512e-02
    x_18_8    onehot_18_141  1
    x_18_8    stock_lb_186  8
    x_18_8    stock_ub_187  8
    x_18_8    parent_nonstrict_scope_188  1.3963885841689967e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_135  1
    w_18_8    product_ub_136  1
    w_18_8    normalized_mass_18_142  1
    w_18_8    normalized_ratio_18_143  -1.6
    w_18_8    full_original_Gini_246  -2.0665476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       6.9819429208449833e-03
    x_18_9    product_lb_137  -2.6035209521422013e-02
    x_18_9    product_ub_138  -4.4376353742978512e-02
    x_18_9    onehot_18_141  1
    x_18_9    stock_lb_186  9
    x_18_9    stock_ub_187  9
    x_18_9    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_18_9    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_137  1
    w_18_9    product_ub_138  1
    w_18_9    normalized_mass_18_142  1
    w_18_9    normalized_ratio_18_143  -1.8
    w_18_9    full_original_Gini_246  -26.0654761904762
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       1.1636571534741636e-02
    x_18_10   product_lb_139  -2.6035209521422013e-02
    x_18_10   product_ub_140  -4.4376353742978512e-02
    x_18_10   onehot_18_141  1
    x_18_10   stock_lb_186  10
    x_18_10   stock_ub_187  10
    x_18_10   parent_nonstrict_scope_188  2.3273143069483273e-02
    x_18_10   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_139  1
    w_18_10   product_ub_140  1
    w_18_10   normalized_mass_18_142  1
    w_18_10   normalized_ratio_18_143  -2
    w_18_10   full_original_Gini_246  -3.1465476190476185e+01
    rho_18    normalized_ratio_18_143  1
    rho_18    block_pair_pos_191  1
    rho_18    block_pair_neg_192  -1
    rho_18    block_pair_pos_205  1
    rho_18    block_pair_neg_206  -1
    rho_18    block_pair_pos_215  1
    rho_18    block_pair_neg_216  -1
    rho_18    block_pair_pos_223  -1
    rho_18    block_pair_neg_224  1
    rho_18    block_pair_pos_225  -1
    rho_18    block_pair_neg_226  1
    rho_18    block_pair_pos_229  1
    rho_18    block_pair_neg_230  -1
    rho_18    block_pair_pos_237  1
    rho_18    block_pair_neg_238  -1
    rho_18    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_144  -2.6035209521422013e-02
    x_27_0    product_ub_145  -4.4376353742978512e-02
    x_27_0    onehot_27_158  1
    x_27_0    parent_nonstrict_scope_188  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_144  1
    w_27_0    product_ub_145  1
    w_27_0    normalized_mass_27_159  1
    w_27_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_146  -2.6035209521422013e-02
    x_27_1    product_ub_147  -4.4376353742978512e-02
    x_27_1    onehot_27_158  1
    x_27_1    stock_lb_186  1
    x_27_1    stock_ub_187  1
    x_27_1    parent_nonstrict_scope_188  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_146  1
    w_27_1    product_ub_147  1
    w_27_1    normalized_mass_27_159  1
    w_27_1    normalized_ratio_27_160  -3.3333333333333331e-01
    w_27_1    full_original_Gini_246  -1.4201190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_148  -2.6035209521422013e-02
    x_27_2    product_ub_149  -4.4376353742978512e-02
    x_27_2    onehot_27_158  1
    x_27_2    stock_lb_186  2
    x_27_2    stock_ub_187  2
    x_27_2    parent_nonstrict_scope_188  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_148  1
    w_27_2    product_ub_149  1
    w_27_2    normalized_mass_27_159  1
    w_27_2    normalized_ratio_27_160  -6.6666666666666663e-01
    w_27_2    full_original_Gini_246  -6.5345238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_150  -2.6035209521422013e-02
    x_27_3    product_ub_151  -4.4376353742978512e-02
    x_27_3    onehot_27_158  1
    x_27_3    stock_lb_186  3
    x_27_3    stock_ub_187  3
    x_27_3    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_150  1
    w_27_3    product_ub_151  1
    w_27_3    normalized_mass_27_159  1
    w_27_3    normalized_ratio_27_160  -1
    w_27_3    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_152  -2.6035209521422013e-02
    x_27_4    product_ub_153  -4.4376353742978512e-02
    x_27_4    onehot_27_158  1
    x_27_4    stock_lb_186  4
    x_27_4    stock_ub_187  4
    x_27_4    parent_nonstrict_scope_188  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_152  1
    w_27_4    product_ub_153  1
    w_27_4    normalized_mass_27_159  1
    w_27_4    normalized_ratio_27_160  -1.3333333333333333e+00
    w_27_4    full_original_Gini_246  -1.3798809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_154  -2.6035209521422013e-02
    x_27_5    product_ub_155  -4.4376353742978512e-02
    x_27_5    onehot_27_158  1
    x_27_5    stock_lb_186  5
    x_27_5    stock_ub_187  5
    x_27_5    parent_nonstrict_scope_188  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_154  1
    w_27_5    product_ub_155  1
    w_27_5    normalized_mass_27_159  1
    w_27_5    normalized_ratio_27_160  -1.6666666666666665e+00
    w_27_5    full_original_Gini_246  -2.2465476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_156  -2.6035209521422013e-02
    x_27_6    product_ub_157  -4.4376353742978512e-02
    x_27_6    onehot_27_158  1
    x_27_6    stock_lb_186  6
    x_27_6    stock_ub_187  6
    x_27_6    parent_nonstrict_scope_188  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_156  1
    w_27_6    product_ub_157  1
    w_27_6    normalized_mass_27_159  1
    w_27_6    normalized_ratio_27_160  -2
    w_27_6    full_original_Gini_246  -3.1465476190476185e+01
    rho_27    normalized_ratio_27_160  1
    rho_27    block_pair_pos_195  1
    rho_27    block_pair_neg_196  -1
    rho_27    block_pair_pos_209  1
    rho_27    block_pair_neg_210  -1
    rho_27    block_pair_pos_219  1
    rho_27    block_pair_neg_220  -1
    rho_27    block_pair_pos_225  1
    rho_27    block_pair_neg_226  -1
    rho_27    block_pair_pos_227  -1
    rho_27    block_pair_neg_228  1
    rho_27    block_pair_pos_233  1
    rho_27    block_pair_neg_234  -1
    rho_27    block_pair_pos_241  1
    rho_27    block_pair_neg_242  -1
    rho_27    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       1.1636571534741636e-02
    x_19_0    product_lb_161  -2.6035209521422013e-02
    x_19_0    product_ub_162  -4.4376353742978512e-02
    x_19_0    onehot_19_183  1
    x_19_0    parent_nonstrict_scope_188  2.3273143069483273e-02
    x_19_0    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_161  1
    w_19_0    product_ub_162  1
    w_19_0    normalized_mass_19_184  1
    w_19_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.9819429208449833e-03
    x_19_1    product_lb_163  -2.6035209521422013e-02
    x_19_1    product_ub_164  -4.4376353742978512e-02
    x_19_1    onehot_19_183  1
    x_19_1    stock_lb_186  1
    x_19_1    stock_ub_187  1
    x_19_1    parent_nonstrict_scope_188  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_163  1
    w_19_1    product_ub_164  1
    w_19_1    normalized_mass_19_184  1
    w_19_1    normalized_ratio_19_185  -0.2
    w_19_1    full_original_Gini_246  -1.7534523809523815e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    OBJ       2.3273143069483266e-03
    x_19_2    product_lb_165  -2.6035209521422013e-02
    x_19_2    product_ub_166  -4.4376353742978512e-02
    x_19_2    onehot_19_183  1
    x_19_2    stock_lb_186  2
    x_19_2    stock_ub_187  2
    x_19_2    parent_nonstrict_scope_188  1.3963885841689963e-02
    x_19_2    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_165  1
    w_19_2    product_ub_166  1
    w_19_2    normalized_mass_19_184  1
    w_19_2    normalized_ratio_19_185  -0.4
    w_19_2    full_original_Gini_246  -1.2667857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.00232731430694833
    x_19_3    product_lb_167  -2.6035209521422013e-02
    x_19_3    product_ub_168  -4.4376353742978512e-02
    x_19_3    onehot_19_183  1
    x_19_3    stock_lb_186  3
    x_19_3    stock_ub_187  3
    x_19_3    parent_nonstrict_scope_188  9.3092572277933064e-03
    x_19_3    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_167  1
    w_19_3    product_ub_168  1
    w_19_3    normalized_mass_19_184  1
    w_19_3    normalized_ratio_19_185  -6.0000000000000009e-01
    w_19_3    full_original_Gini_246  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -6.9819429208449833e-03
    x_19_4    product_lb_169  -2.6035209521422013e-02
    x_19_4    product_ub_170  -4.4376353742978512e-02
    x_19_4    onehot_19_183  1
    x_19_4    stock_lb_186  4
    x_19_4    stock_ub_187  4
    x_19_4    parent_nonstrict_scope_188  4.6546286138966532e-03
    x_19_4    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_169  1
    w_19_4    product_ub_170  1
    w_19_4    normalized_mass_19_184  1
    w_19_4    normalized_ratio_19_185  -0.8
    w_19_4    full_original_Gini_246  -4.40595238095238
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -1.1636571534741636e-02
    x_19_5    product_lb_171  -2.6035209521422013e-02
    x_19_5    product_ub_172  -4.4376353742978512e-02
    x_19_5    onehot_19_183  1
    x_19_5    stock_lb_186  5
    x_19_5    stock_ub_187  5
    x_19_5    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_171  1
    w_19_5    product_ub_172  1
    w_19_5    normalized_mass_19_184  1
    w_19_5    normalized_ratio_19_185  -1
    w_19_5    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    OBJ       -6.9819429208449781e-03
    x_19_6    product_lb_173  -2.6035209521422013e-02
    x_19_6    product_ub_174  -4.4376353742978512e-02
    x_19_6    onehot_19_183  1
    x_19_6    stock_lb_186  6
    x_19_6    stock_ub_187  6
    x_19_6    parent_nonstrict_scope_188  4.6546286138966584e-03
    x_19_6    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_173  1
    w_19_6    product_ub_174  1
    w_19_6    normalized_mass_19_184  1
    w_19_6    normalized_ratio_19_185  -1.2000000000000002e+00
    w_19_6    full_original_Gini_246  -1.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       -2.3273143069483249e-03
    x_19_7    product_lb_175  -2.6035209521422013e-02
    x_19_7    product_ub_176  -4.4376353742978512e-02
    x_19_7    onehot_19_183  1
    x_19_7    stock_lb_186  7
    x_19_7    stock_ub_187  7
    x_19_7    parent_nonstrict_scope_188  9.3092572277933116e-03
    x_19_7    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_175  1
    w_19_7    product_ub_176  1
    w_19_7    normalized_mass_19_184  1
    w_19_7    normalized_ratio_19_185  -1.4000000000000001e+00
    w_19_7    full_original_Gini_246  -1.5465476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.00232731430694833
    x_19_8    product_lb_177  -2.6035209521422013e-02
    x_19_8    product_ub_178  -4.4376353742978512e-02
    x_19_8    onehot_19_183  1
    x_19_8    stock_lb_186  8
    x_19_8    stock_ub_187  8
    x_19_8    parent_nonstrict_scope_188  1.3963885841689967e-02
    x_19_8    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_177  1
    w_19_8    product_ub_178  1
    w_19_8    normalized_mass_19_184  1
    w_19_8    normalized_ratio_19_185  -1.6
    w_19_8    full_original_Gini_246  -2.0665476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_9    OBJ       6.9819429208449833e-03
    x_19_9    product_lb_179  -2.6035209521422013e-02
    x_19_9    product_ub_180  -4.4376353742978512e-02
    x_19_9    onehot_19_183  1
    x_19_9    stock_lb_186  9
    x_19_9    stock_ub_187  9
    x_19_9    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_19_9    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_9    product_lb_179  1
    w_19_9    product_ub_180  1
    w_19_9    normalized_mass_19_184  1
    w_19_9    normalized_ratio_19_185  -1.8
    w_19_9    full_original_Gini_246  -26.0654761904762
    MARKER    'MARKER'                 'INTORG'
    x_19_10   OBJ       1.1636571534741636e-02
    x_19_10   product_lb_181  -2.6035209521422013e-02
    x_19_10   product_ub_182  -4.4376353742978512e-02
    x_19_10   onehot_19_183  1
    x_19_10   stock_lb_186  10
    x_19_10   stock_ub_187  10
    x_19_10   parent_nonstrict_scope_188  2.3273143069483273e-02
    x_19_10   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_10   product_lb_181  1
    w_19_10   product_ub_182  1
    w_19_10   normalized_mass_19_184  1
    w_19_10   normalized_ratio_19_185  -2
    w_19_10   full_original_Gini_246  -3.1465476190476185e+01
    rho_19    normalized_ratio_19_185  1
    rho_19    block_pair_pos_193  1
    rho_19    block_pair_neg_194  -1
    rho_19    block_pair_pos_207  1
    rho_19    block_pair_neg_208  -1
    rho_19    block_pair_pos_217  1
    rho_19    block_pair_neg_218  -1
    rho_19    block_pair_pos_223  1
    rho_19    block_pair_neg_224  -1
    rho_19    block_pair_pos_227  1
    rho_19    block_pair_neg_228  -1
    rho_19    block_pair_pos_231  1
    rho_19    block_pair_neg_232  -1
    rho_19    block_pair_pos_239  1
    rho_19    block_pair_neg_240  -1
    rho_19    normalization_245  1
    a_15_13   block_pair_pos_201  1
    a_15_13   block_pair_neg_202  1
    a_15_13   full_original_Gini_246  -1
    a_15_34   block_pair_pos_213  1
    a_15_34   block_pair_neg_214  1
    a_15_34   full_original_Gini_246  -1
    a_15_17   block_pair_pos_203  1
    a_15_17   block_pair_neg_204  1
    a_15_17   full_original_Gini_246  -1
    a_15_29   block_pair_pos_211  1
    a_15_29   block_pair_neg_212  1
    a_15_29   full_original_Gini_246  -1
    a_15_18   block_pair_pos_205  1
    a_15_18   block_pair_neg_206  1
    a_15_18   full_original_Gini_246  -1
    a_15_27   block_pair_pos_209  1
    a_15_27   block_pair_neg_210  1
    a_15_27   full_original_Gini_246  -1
    a_15_19   block_pair_pos_207  1
    a_15_19   block_pair_neg_208  1
    a_15_19   full_original_Gini_246  -1
    a_13_34   block_pair_pos_199  1
    a_13_34   block_pair_neg_200  1
    a_13_34   full_original_Gini_246  -1
    a_13_17   block_pair_pos_189  1
    a_13_17   block_pair_neg_190  1
    a_13_17   full_original_Gini_246  -1
    a_13_29   block_pair_pos_197  1
    a_13_29   block_pair_neg_198  1
    a_13_29   full_original_Gini_246  -1
    a_13_18   block_pair_pos_191  1
    a_13_18   block_pair_neg_192  1
    a_13_18   full_original_Gini_246  -1
    a_13_27   block_pair_pos_195  1
    a_13_27   block_pair_neg_196  1
    a_13_27   full_original_Gini_246  -1
    a_13_19   block_pair_pos_193  1
    a_13_19   block_pair_neg_194  1
    a_13_19   full_original_Gini_246  -1
    a_34_17   block_pair_pos_235  1
    a_34_17   block_pair_neg_236  1
    a_34_17   full_original_Gini_246  -1
    a_34_29   block_pair_pos_243  1
    a_34_29   block_pair_neg_244  1
    a_34_29   full_original_Gini_246  -1
    a_34_18   block_pair_pos_237  1
    a_34_18   block_pair_neg_238  1
    a_34_18   full_original_Gini_246  -1
    a_34_27   block_pair_pos_241  1
    a_34_27   block_pair_neg_242  1
    a_34_27   full_original_Gini_246  -1
    a_34_19   block_pair_pos_239  1
    a_34_19   block_pair_neg_240  1
    a_34_19   full_original_Gini_246  -1
    a_17_29   block_pair_pos_221  1
    a_17_29   block_pair_neg_222  1
    a_17_29   full_original_Gini_246  -1
    a_17_18   block_pair_pos_215  1
    a_17_18   block_pair_neg_216  1
    a_17_18   full_original_Gini_246  -1
    a_17_27   block_pair_pos_219  1
    a_17_27   block_pair_neg_220  1
    a_17_27   full_original_Gini_246  -1
    a_17_19   block_pair_pos_217  1
    a_17_19   block_pair_neg_218  1
    a_17_19   full_original_Gini_246  -1
    a_29_18   block_pair_pos_229  1
    a_29_18   block_pair_neg_230  1
    a_29_18   full_original_Gini_246  -1
    a_29_27   block_pair_pos_233  1
    a_29_27   block_pair_neg_234  1
    a_29_27   full_original_Gini_246  -1
    a_29_19   block_pair_pos_231  1
    a_29_19   block_pair_neg_232  1
    a_29_19   full_original_Gini_246  -1
    a_18_27   block_pair_pos_225  1
    a_18_27   block_pair_neg_226  1
    a_18_27   full_original_Gini_246  -1
    a_18_19   block_pair_pos_223  1
    a_18_19   block_pair_neg_224  1
    a_18_19   full_original_Gini_246  -1
    a_27_19   block_pair_pos_227  1
    a_27_19   block_pair_neg_228  1
    a_27_19   full_original_Gini_246  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_15_0  unique_nonzero_owner_247  1
    service_0_15_0  service_visit_def_700  1
    service_0_15_0  free_load_conservation_701  -5
    service_0_15_0  original_T_including_depot_unload_748  600
    service_0_15_1  unique_nonzero_owner_248  1
    service_0_15_1  service_visit_def_700  1
    service_0_15_1  free_load_conservation_701  -4
    service_0_15_1  original_T_including_depot_unload_748  480
    service_0_15_2  unique_nonzero_owner_249  1
    service_0_15_2  service_visit_def_700  1
    service_0_15_2  free_load_conservation_701  -3
    service_0_15_2  original_T_including_depot_unload_748  360
    service_0_15_3  unique_nonzero_owner_250  1
    service_0_15_3  service_visit_def_700  1
    service_0_15_3  free_load_conservation_701  -2
    service_0_15_3  original_T_including_depot_unload_748  240
    service_0_15_4  unique_nonzero_owner_251  1
    service_0_15_4  service_visit_def_700  1
    service_0_15_4  free_load_conservation_701  -1
    service_0_15_4  original_T_including_depot_unload_748  120
    service_0_15_6  unique_nonzero_owner_252  1
    service_0_15_6  service_visit_def_700  1
    service_0_15_6  free_load_conservation_701  1
    service_0_15_7  unique_nonzero_owner_253  1
    service_0_15_7  service_visit_def_700  1
    service_0_15_7  free_load_conservation_701  2
    service_0_15_8  unique_nonzero_owner_254  1
    service_0_15_8  service_visit_def_700  1
    service_0_15_8  free_load_conservation_701  3
    service_1_15_0  unique_nonzero_owner_247  1
    service_1_15_0  service_visit_def_1072  1
    service_1_15_0  free_load_conservation_1073  -5
    service_1_15_0  original_T_including_depot_unload_1119  600
    service_1_15_1  unique_nonzero_owner_248  1
    service_1_15_1  service_visit_def_1072  1
    service_1_15_1  free_load_conservation_1073  -4
    service_1_15_1  original_T_including_depot_unload_1119  480
    service_1_15_2  unique_nonzero_owner_249  1
    service_1_15_2  service_visit_def_1072  1
    service_1_15_2  free_load_conservation_1073  -3
    service_1_15_2  original_T_including_depot_unload_1119  360
    service_1_15_3  unique_nonzero_owner_250  1
    service_1_15_3  service_visit_def_1072  1
    service_1_15_3  free_load_conservation_1073  -2
    service_1_15_3  original_T_including_depot_unload_1119  240
    service_1_15_4  unique_nonzero_owner_251  1
    service_1_15_4  service_visit_def_1072  1
    service_1_15_4  free_load_conservation_1073  -1
    service_1_15_4  original_T_including_depot_unload_1119  120
    service_1_15_6  unique_nonzero_owner_252  1
    service_1_15_6  service_visit_def_1072  1
    service_1_15_6  free_load_conservation_1073  1
    service_1_15_7  unique_nonzero_owner_253  1
    service_1_15_7  service_visit_def_1072  1
    service_1_15_7  free_load_conservation_1073  2
    service_1_15_8  unique_nonzero_owner_254  1
    service_1_15_8  service_visit_def_1072  1
    service_1_15_8  free_load_conservation_1073  3
    service_2_15_0  unique_nonzero_owner_247  1
    service_2_15_0  service_visit_def_1390  1
    service_2_15_0  free_load_conservation_1391  -5
    service_2_15_0  original_T_including_depot_unload_1436  600
    service_2_15_1  unique_nonzero_owner_248  1
    service_2_15_1  service_visit_def_1390  1
    service_2_15_1  free_load_conservation_1391  -4
    service_2_15_1  original_T_including_depot_unload_1436  480
    service_2_15_2  unique_nonzero_owner_249  1
    service_2_15_2  service_visit_def_1390  1
    service_2_15_2  free_load_conservation_1391  -3
    service_2_15_2  original_T_including_depot_unload_1436  360
    service_2_15_3  unique_nonzero_owner_250  1
    service_2_15_3  service_visit_def_1390  1
    service_2_15_3  free_load_conservation_1391  -2
    service_2_15_3  original_T_including_depot_unload_1436  240
    service_2_15_4  unique_nonzero_owner_251  1
    service_2_15_4  service_visit_def_1390  1
    service_2_15_4  free_load_conservation_1391  -1
    service_2_15_4  original_T_including_depot_unload_1436  120
    service_2_15_6  unique_nonzero_owner_252  1
    service_2_15_6  service_visit_def_1390  1
    service_2_15_6  free_load_conservation_1391  1
    service_2_15_7  unique_nonzero_owner_253  1
    service_2_15_7  service_visit_def_1390  1
    service_2_15_7  free_load_conservation_1391  2
    service_2_15_8  unique_nonzero_owner_254  1
    service_2_15_8  service_visit_def_1390  1
    service_2_15_8  free_load_conservation_1391  3
    service_0_13_0  unique_nonzero_owner_255  1
    service_0_13_0  service_visit_def_706  1
    service_0_13_0  free_load_conservation_707  -5
    service_0_13_0  original_T_including_depot_unload_748  600
    service_0_13_1  unique_nonzero_owner_256  1
    service_0_13_1  service_visit_def_706  1
    service_0_13_1  free_load_conservation_707  -4
    service_0_13_1  original_T_including_depot_unload_748  480
    service_0_13_2  unique_nonzero_owner_257  1
    service_0_13_2  service_visit_def_706  1
    service_0_13_2  free_load_conservation_707  -3
    service_0_13_2  original_T_including_depot_unload_748  360
    service_0_13_3  unique_nonzero_owner_258  1
    service_0_13_3  service_visit_def_706  1
    service_0_13_3  free_load_conservation_707  -2
    service_0_13_3  original_T_including_depot_unload_748  240
    service_0_13_4  unique_nonzero_owner_259  1
    service_0_13_4  service_visit_def_706  1
    service_0_13_4  free_load_conservation_707  -1
    service_0_13_4  original_T_including_depot_unload_748  120
    service_0_13_6  unique_nonzero_owner_260  1
    service_0_13_6  service_visit_def_706  1
    service_0_13_6  free_load_conservation_707  1
    service_0_13_7  unique_nonzero_owner_261  1
    service_0_13_7  service_visit_def_706  1
    service_0_13_7  free_load_conservation_707  2
    service_0_13_8  unique_nonzero_owner_262  1
    service_0_13_8  service_visit_def_706  1
    service_0_13_8  free_load_conservation_707  3
    service_1_13_0  unique_nonzero_owner_255  1
    service_1_13_0  service_visit_def_1078  1
    service_1_13_0  free_load_conservation_1079  -5
    service_1_13_0  original_T_including_depot_unload_1119  600
    service_1_13_1  unique_nonzero_owner_256  1
    service_1_13_1  service_visit_def_1078  1
    service_1_13_1  free_load_conservation_1079  -4
    service_1_13_1  original_T_including_depot_unload_1119  480
    service_1_13_2  unique_nonzero_owner_257  1
    service_1_13_2  service_visit_def_1078  1
    service_1_13_2  free_load_conservation_1079  -3
    service_1_13_2  original_T_including_depot_unload_1119  360
    service_1_13_3  unique_nonzero_owner_258  1
    service_1_13_3  service_visit_def_1078  1
    service_1_13_3  free_load_conservation_1079  -2
    service_1_13_3  original_T_including_depot_unload_1119  240
    service_1_13_4  unique_nonzero_owner_259  1
    service_1_13_4  service_visit_def_1078  1
    service_1_13_4  free_load_conservation_1079  -1
    service_1_13_4  original_T_including_depot_unload_1119  120
    service_1_13_6  unique_nonzero_owner_260  1
    service_1_13_6  service_visit_def_1078  1
    service_1_13_6  free_load_conservation_1079  1
    service_1_13_7  unique_nonzero_owner_261  1
    service_1_13_7  service_visit_def_1078  1
    service_1_13_7  free_load_conservation_1079  2
    service_1_13_8  unique_nonzero_owner_262  1
    service_1_13_8  service_visit_def_1078  1
    service_1_13_8  free_load_conservation_1079  3
    service_2_13_0  unique_nonzero_owner_255  1
    service_2_13_0  service_visit_def_1396  1
    service_2_13_0  free_load_conservation_1397  -5
    service_2_13_0  original_T_including_depot_unload_1436  600
    service_2_13_1  unique_nonzero_owner_256  1
    service_2_13_1  service_visit_def_1396  1
    service_2_13_1  free_load_conservation_1397  -4
    service_2_13_1  original_T_including_depot_unload_1436  480
    service_2_13_2  unique_nonzero_owner_257  1
    service_2_13_2  service_visit_def_1396  1
    service_2_13_2  free_load_conservation_1397  -3
    service_2_13_2  original_T_including_depot_unload_1436  360
    service_2_13_3  unique_nonzero_owner_258  1
    service_2_13_3  service_visit_def_1396  1
    service_2_13_3  free_load_conservation_1397  -2
    service_2_13_3  original_T_including_depot_unload_1436  240
    service_2_13_4  unique_nonzero_owner_259  1
    service_2_13_4  service_visit_def_1396  1
    service_2_13_4  free_load_conservation_1397  -1
    service_2_13_4  original_T_including_depot_unload_1436  120
    service_2_13_6  unique_nonzero_owner_260  1
    service_2_13_6  service_visit_def_1396  1
    service_2_13_6  free_load_conservation_1397  1
    service_2_13_7  unique_nonzero_owner_261  1
    service_2_13_7  service_visit_def_1396  1
    service_2_13_7  free_load_conservation_1397  2
    service_2_13_8  unique_nonzero_owner_262  1
    service_2_13_8  service_visit_def_1396  1
    service_2_13_8  free_load_conservation_1397  3
    service_0_34_0  unique_nonzero_owner_263  1
    service_0_34_0  service_visit_def_712  1
    service_0_34_0  free_load_conservation_713  -2
    service_0_34_0  original_T_including_depot_unload_748  240
    service_0_34_1  unique_nonzero_owner_264  1
    service_0_34_1  service_visit_def_712  1
    service_0_34_1  free_load_conservation_713  -1
    service_0_34_1  original_T_including_depot_unload_748  120
    service_0_34_3  unique_nonzero_owner_265  1
    service_0_34_3  service_visit_def_712  1
    service_0_34_3  free_load_conservation_713  1
    service_0_34_4  unique_nonzero_owner_266  1
    service_0_34_4  service_visit_def_712  1
    service_0_34_4  free_load_conservation_713  2
    service_0_34_5  unique_nonzero_owner_267  1
    service_0_34_5  service_visit_def_712  1
    service_0_34_5  free_load_conservation_713  3
    service_0_34_6  unique_nonzero_owner_268  1
    service_0_34_6  service_visit_def_712  1
    service_0_34_6  free_load_conservation_713  4
    service_0_34_7  unique_nonzero_owner_269  1
    service_0_34_7  service_visit_def_712  1
    service_0_34_7  free_load_conservation_713  5
    service_0_34_8  unique_nonzero_owner_270  1
    service_0_34_8  service_visit_def_712  1
    service_0_34_8  free_load_conservation_713  6
    service_0_34_9  unique_nonzero_owner_271  1
    service_0_34_9  service_visit_def_712  1
    service_0_34_9  free_load_conservation_713  7
    service_0_34_10  unique_nonzero_owner_272  1
    service_0_34_10  service_visit_def_712  1
    service_0_34_10  free_load_conservation_713  8
    service_0_34_11  unique_nonzero_owner_273  1
    service_0_34_11  service_visit_def_712  1
    service_0_34_11  free_load_conservation_713  9
    service_0_34_12  unique_nonzero_owner_274  1
    service_0_34_12  service_visit_def_712  1
    service_0_34_12  free_load_conservation_713  10
    service_0_34_13  unique_nonzero_owner_275  1
    service_0_34_13  service_visit_def_712  1
    service_0_34_13  free_load_conservation_713  11
    service_0_34_14  unique_nonzero_owner_276  1
    service_0_34_14  service_visit_def_712  1
    service_0_34_14  free_load_conservation_713  12
    service_0_34_15  unique_nonzero_owner_277  1
    service_0_34_15  service_visit_def_712  1
    service_0_34_15  free_load_conservation_713  13
    service_1_34_0  unique_nonzero_owner_263  1
    service_1_34_0  service_visit_def_1084  1
    service_1_34_0  free_load_conservation_1085  -2
    service_1_34_0  original_T_including_depot_unload_1119  240
    service_1_34_1  unique_nonzero_owner_264  1
    service_1_34_1  service_visit_def_1084  1
    service_1_34_1  free_load_conservation_1085  -1
    service_1_34_1  original_T_including_depot_unload_1119  120
    service_1_34_3  unique_nonzero_owner_265  1
    service_1_34_3  service_visit_def_1084  1
    service_1_34_3  free_load_conservation_1085  1
    service_1_34_4  unique_nonzero_owner_266  1
    service_1_34_4  service_visit_def_1084  1
    service_1_34_4  free_load_conservation_1085  2
    service_1_34_5  unique_nonzero_owner_267  1
    service_1_34_5  service_visit_def_1084  1
    service_1_34_5  free_load_conservation_1085  3
    service_1_34_6  unique_nonzero_owner_268  1
    service_1_34_6  service_visit_def_1084  1
    service_1_34_6  free_load_conservation_1085  4
    service_1_34_7  unique_nonzero_owner_269  1
    service_1_34_7  service_visit_def_1084  1
    service_1_34_7  free_load_conservation_1085  5
    service_1_34_8  unique_nonzero_owner_270  1
    service_1_34_8  service_visit_def_1084  1
    service_1_34_8  free_load_conservation_1085  6
    service_1_34_9  unique_nonzero_owner_271  1
    service_1_34_9  service_visit_def_1084  1
    service_1_34_9  free_load_conservation_1085  7
    service_1_34_10  unique_nonzero_owner_272  1
    service_1_34_10  service_visit_def_1084  1
    service_1_34_10  free_load_conservation_1085  8
    service_1_34_11  unique_nonzero_owner_273  1
    service_1_34_11  service_visit_def_1084  1
    service_1_34_11  free_load_conservation_1085  9
    service_1_34_12  unique_nonzero_owner_274  1
    service_1_34_12  service_visit_def_1084  1
    service_1_34_12  free_load_conservation_1085  10
    service_1_34_13  unique_nonzero_owner_275  1
    service_1_34_13  service_visit_def_1084  1
    service_1_34_13  free_load_conservation_1085  11
    service_1_34_14  unique_nonzero_owner_276  1
    service_1_34_14  service_visit_def_1084  1
    service_1_34_14  free_load_conservation_1085  12
    service_1_34_15  unique_nonzero_owner_277  1
    service_1_34_15  service_visit_def_1084  1
    service_1_34_15  free_load_conservation_1085  13
    service_2_34_0  unique_nonzero_owner_263  1
    service_2_34_0  service_visit_def_1402  1
    service_2_34_0  free_load_conservation_1403  -2
    service_2_34_0  original_T_including_depot_unload_1436  240
    service_2_34_1  unique_nonzero_owner_264  1
    service_2_34_1  service_visit_def_1402  1
    service_2_34_1  free_load_conservation_1403  -1
    service_2_34_1  original_T_including_depot_unload_1436  120
    service_2_34_3  unique_nonzero_owner_265  1
    service_2_34_3  service_visit_def_1402  1
    service_2_34_3  free_load_conservation_1403  1
    service_2_34_4  unique_nonzero_owner_266  1
    service_2_34_4  service_visit_def_1402  1
    service_2_34_4  free_load_conservation_1403  2
    service_2_34_5  unique_nonzero_owner_267  1
    service_2_34_5  service_visit_def_1402  1
    service_2_34_5  free_load_conservation_1403  3
    service_2_34_6  unique_nonzero_owner_268  1
    service_2_34_6  service_visit_def_1402  1
    service_2_34_6  free_load_conservation_1403  4
    service_2_34_7  unique_nonzero_owner_269  1
    service_2_34_7  service_visit_def_1402  1
    service_2_34_7  free_load_conservation_1403  5
    service_2_34_8  unique_nonzero_owner_270  1
    service_2_34_8  service_visit_def_1402  1
    service_2_34_8  free_load_conservation_1403  6
    service_2_34_9  unique_nonzero_owner_271  1
    service_2_34_9  service_visit_def_1402  1
    service_2_34_9  free_load_conservation_1403  7
    service_2_34_10  unique_nonzero_owner_272  1
    service_2_34_10  service_visit_def_1402  1
    service_2_34_10  free_load_conservation_1403  8
    service_2_34_11  unique_nonzero_owner_273  1
    service_2_34_11  service_visit_def_1402  1
    service_2_34_11  free_load_conservation_1403  9
    service_2_34_12  unique_nonzero_owner_274  1
    service_2_34_12  service_visit_def_1402  1
    service_2_34_12  free_load_conservation_1403  10
    service_2_34_13  unique_nonzero_owner_275  1
    service_2_34_13  service_visit_def_1402  1
    service_2_34_13  free_load_conservation_1403  11
    service_2_34_14  unique_nonzero_owner_276  1
    service_2_34_14  service_visit_def_1402  1
    service_2_34_14  free_load_conservation_1403  12
    service_2_34_15  unique_nonzero_owner_277  1
    service_2_34_15  service_visit_def_1402  1
    service_2_34_15  free_load_conservation_1403  13
    service_0_17_0  unique_nonzero_owner_278  1
    service_0_17_0  service_visit_def_718  1
    service_0_17_0  free_load_conservation_719  -5
    service_0_17_0  original_T_including_depot_unload_748  600
    service_0_17_1  unique_nonzero_owner_279  1
    service_0_17_1  service_visit_def_718  1
    service_0_17_1  free_load_conservation_719  -4
    service_0_17_1  original_T_including_depot_unload_748  480
    service_0_17_2  unique_nonzero_owner_280  1
    service_0_17_2  service_visit_def_718  1
    service_0_17_2  free_load_conservation_719  -3
    service_0_17_2  original_T_including_depot_unload_748  360
    service_0_17_3  unique_nonzero_owner_281  1
    service_0_17_3  service_visit_def_718  1
    service_0_17_3  free_load_conservation_719  -2
    service_0_17_3  original_T_including_depot_unload_748  240
    service_0_17_4  unique_nonzero_owner_282  1
    service_0_17_4  service_visit_def_718  1
    service_0_17_4  free_load_conservation_719  -1
    service_0_17_4  original_T_including_depot_unload_748  120
    service_0_17_6  unique_nonzero_owner_283  1
    service_0_17_6  service_visit_def_718  1
    service_0_17_6  free_load_conservation_719  1
    service_1_17_0  unique_nonzero_owner_278  1
    service_1_17_0  service_visit_def_1090  1
    service_1_17_0  free_load_conservation_1091  -5
    service_1_17_0  original_T_including_depot_unload_1119  600
    service_1_17_1  unique_nonzero_owner_279  1
    service_1_17_1  service_visit_def_1090  1
    service_1_17_1  free_load_conservation_1091  -4
    service_1_17_1  original_T_including_depot_unload_1119  480
    service_1_17_2  unique_nonzero_owner_280  1
    service_1_17_2  service_visit_def_1090  1
    service_1_17_2  free_load_conservation_1091  -3
    service_1_17_2  original_T_including_depot_unload_1119  360
    service_1_17_3  unique_nonzero_owner_281  1
    service_1_17_3  service_visit_def_1090  1
    service_1_17_3  free_load_conservation_1091  -2
    service_1_17_3  original_T_including_depot_unload_1119  240
    service_1_17_4  unique_nonzero_owner_282  1
    service_1_17_4  service_visit_def_1090  1
    service_1_17_4  free_load_conservation_1091  -1
    service_1_17_4  original_T_including_depot_unload_1119  120
    service_1_17_6  unique_nonzero_owner_283  1
    service_1_17_6  service_visit_def_1090  1
    service_1_17_6  free_load_conservation_1091  1
    service_2_17_0  unique_nonzero_owner_278  1
    service_2_17_0  service_visit_def_1408  1
    service_2_17_0  free_load_conservation_1409  -5
    service_2_17_0  original_T_including_depot_unload_1436  600
    service_2_17_1  unique_nonzero_owner_279  1
    service_2_17_1  service_visit_def_1408  1
    service_2_17_1  free_load_conservation_1409  -4
    service_2_17_1  original_T_including_depot_unload_1436  480
    service_2_17_2  unique_nonzero_owner_280  1
    service_2_17_2  service_visit_def_1408  1
    service_2_17_2  free_load_conservation_1409  -3
    service_2_17_2  original_T_including_depot_unload_1436  360
    service_2_17_3  unique_nonzero_owner_281  1
    service_2_17_3  service_visit_def_1408  1
    service_2_17_3  free_load_conservation_1409  -2
    service_2_17_3  original_T_including_depot_unload_1436  240
    service_2_17_4  unique_nonzero_owner_282  1
    service_2_17_4  service_visit_def_1408  1
    service_2_17_4  free_load_conservation_1409  -1
    service_2_17_4  original_T_including_depot_unload_1436  120
    service_2_17_6  unique_nonzero_owner_283  1
    service_2_17_6  service_visit_def_1408  1
    service_2_17_6  free_load_conservation_1409  1
    service_0_29_0  unique_nonzero_owner_284  1
    service_0_29_0  service_visit_def_724  1
    service_0_29_0  free_load_conservation_725  -1
    service_0_29_0  original_T_including_depot_unload_748  120
    service_0_29_2  unique_nonzero_owner_285  1
    service_0_29_2  service_visit_def_724  1
    service_0_29_2  free_load_conservation_725  1
    service_0_29_3  unique_nonzero_owner_286  1
    service_0_29_3  service_visit_def_724  1
    service_0_29_3  free_load_conservation_725  2
    service_0_29_4  unique_nonzero_owner_287  1
    service_0_29_4  service_visit_def_724  1
    service_0_29_4  free_load_conservation_725  3
    service_0_29_5  unique_nonzero_owner_288  1
    service_0_29_5  service_visit_def_724  1
    service_0_29_5  free_load_conservation_725  4
    service_0_29_6  unique_nonzero_owner_289  1
    service_0_29_6  service_visit_def_724  1
    service_0_29_6  free_load_conservation_725  5
    service_0_29_7  unique_nonzero_owner_290  1
    service_0_29_7  service_visit_def_724  1
    service_0_29_7  free_load_conservation_725  6
    service_0_29_8  unique_nonzero_owner_291  1
    service_0_29_8  service_visit_def_724  1
    service_0_29_8  free_load_conservation_725  7
    service_0_29_9  unique_nonzero_owner_292  1
    service_0_29_9  service_visit_def_724  1
    service_0_29_9  free_load_conservation_725  8
    service_0_29_10  unique_nonzero_owner_293  1
    service_0_29_10  service_visit_def_724  1
    service_0_29_10  free_load_conservation_725  9
    service_1_29_0  unique_nonzero_owner_284  1
    service_1_29_0  service_visit_def_1096  1
    service_1_29_0  free_load_conservation_1097  -1
    service_1_29_0  original_T_including_depot_unload_1119  120
    service_1_29_2  unique_nonzero_owner_285  1
    service_1_29_2  service_visit_def_1096  1
    service_1_29_2  free_load_conservation_1097  1
    service_1_29_3  unique_nonzero_owner_286  1
    service_1_29_3  service_visit_def_1096  1
    service_1_29_3  free_load_conservation_1097  2
    service_1_29_4  unique_nonzero_owner_287  1
    service_1_29_4  service_visit_def_1096  1
    service_1_29_4  free_load_conservation_1097  3
    service_1_29_5  unique_nonzero_owner_288  1
    service_1_29_5  service_visit_def_1096  1
    service_1_29_5  free_load_conservation_1097  4
    service_1_29_6  unique_nonzero_owner_289  1
    service_1_29_6  service_visit_def_1096  1
    service_1_29_6  free_load_conservation_1097  5
    service_1_29_7  unique_nonzero_owner_290  1
    service_1_29_7  service_visit_def_1096  1
    service_1_29_7  free_load_conservation_1097  6
    service_1_29_8  unique_nonzero_owner_291  1
    service_1_29_8  service_visit_def_1096  1
    service_1_29_8  free_load_conservation_1097  7
    service_1_29_9  unique_nonzero_owner_292  1
    service_1_29_9  service_visit_def_1096  1
    service_1_29_9  free_load_conservation_1097  8
    service_1_29_10  unique_nonzero_owner_293  1
    service_1_29_10  service_visit_def_1096  1
    service_1_29_10  free_load_conservation_1097  9
    service_2_29_0  unique_nonzero_owner_284  1
    service_2_29_0  service_visit_def_1414  1
    service_2_29_0  free_load_conservation_1415  -1
    service_2_29_0  original_T_including_depot_unload_1436  120
    service_2_29_2  unique_nonzero_owner_285  1
    service_2_29_2  service_visit_def_1414  1
    service_2_29_2  free_load_conservation_1415  1
    service_2_29_3  unique_nonzero_owner_286  1
    service_2_29_3  service_visit_def_1414  1
    service_2_29_3  free_load_conservation_1415  2
    service_2_29_4  unique_nonzero_owner_287  1
    service_2_29_4  service_visit_def_1414  1
    service_2_29_4  free_load_conservation_1415  3
    service_2_29_5  unique_nonzero_owner_288  1
    service_2_29_5  service_visit_def_1414  1
    service_2_29_5  free_load_conservation_1415  4
    service_2_29_6  unique_nonzero_owner_289  1
    service_2_29_6  service_visit_def_1414  1
    service_2_29_6  free_load_conservation_1415  5
    service_2_29_7  unique_nonzero_owner_290  1
    service_2_29_7  service_visit_def_1414  1
    service_2_29_7  free_load_conservation_1415  6
    service_2_29_8  unique_nonzero_owner_291  1
    service_2_29_8  service_visit_def_1414  1
    service_2_29_8  free_load_conservation_1415  7
    service_2_29_9  unique_nonzero_owner_292  1
    service_2_29_9  service_visit_def_1414  1
    service_2_29_9  free_load_conservation_1415  8
    service_2_29_10  unique_nonzero_owner_293  1
    service_2_29_10  service_visit_def_1414  1
    service_2_29_10  free_load_conservation_1415  9
    service_0_18_0  unique_nonzero_owner_294  1
    service_0_18_0  service_visit_def_730  1
    service_0_18_0  free_load_conservation_731  -8
    service_0_18_0  original_T_including_depot_unload_748  960
    service_0_18_1  unique_nonzero_owner_295  1
    service_0_18_1  service_visit_def_730  1
    service_0_18_1  free_load_conservation_731  -7
    service_0_18_1  original_T_including_depot_unload_748  840
    service_0_18_2  unique_nonzero_owner_296  1
    service_0_18_2  service_visit_def_730  1
    service_0_18_2  free_load_conservation_731  -6
    service_0_18_2  original_T_including_depot_unload_748  720
    service_0_18_3  unique_nonzero_owner_297  1
    service_0_18_3  service_visit_def_730  1
    service_0_18_3  free_load_conservation_731  -5
    service_0_18_3  original_T_including_depot_unload_748  600
    service_0_18_4  unique_nonzero_owner_298  1
    service_0_18_4  service_visit_def_730  1
    service_0_18_4  free_load_conservation_731  -4
    service_0_18_4  original_T_including_depot_unload_748  480
    service_0_18_5  unique_nonzero_owner_299  1
    service_0_18_5  service_visit_def_730  1
    service_0_18_5  free_load_conservation_731  -3
    service_0_18_5  original_T_including_depot_unload_748  360
    service_0_18_6  unique_nonzero_owner_300  1
    service_0_18_6  service_visit_def_730  1
    service_0_18_6  free_load_conservation_731  -2
    service_0_18_6  original_T_including_depot_unload_748  240
    service_0_18_7  unique_nonzero_owner_301  1
    service_0_18_7  service_visit_def_730  1
    service_0_18_7  free_load_conservation_731  -1
    service_0_18_7  original_T_including_depot_unload_748  120
    service_0_18_9  unique_nonzero_owner_302  1
    service_0_18_9  service_visit_def_730  1
    service_0_18_9  free_load_conservation_731  1
    service_0_18_10  unique_nonzero_owner_303  1
    service_0_18_10  service_visit_def_730  1
    service_0_18_10  free_load_conservation_731  2
    service_1_18_0  unique_nonzero_owner_294  1
    service_1_18_0  service_visit_def_1102  1
    service_1_18_0  free_load_conservation_1103  -8
    service_1_18_0  original_T_including_depot_unload_1119  960
    service_1_18_1  unique_nonzero_owner_295  1
    service_1_18_1  service_visit_def_1102  1
    service_1_18_1  free_load_conservation_1103  -7
    service_1_18_1  original_T_including_depot_unload_1119  840
    service_1_18_2  unique_nonzero_owner_296  1
    service_1_18_2  service_visit_def_1102  1
    service_1_18_2  free_load_conservation_1103  -6
    service_1_18_2  original_T_including_depot_unload_1119  720
    service_1_18_3  unique_nonzero_owner_297  1
    service_1_18_3  service_visit_def_1102  1
    service_1_18_3  free_load_conservation_1103  -5
    service_1_18_3  original_T_including_depot_unload_1119  600
    service_1_18_4  unique_nonzero_owner_298  1
    service_1_18_4  service_visit_def_1102  1
    service_1_18_4  free_load_conservation_1103  -4
    service_1_18_4  original_T_including_depot_unload_1119  480
    service_1_18_5  unique_nonzero_owner_299  1
    service_1_18_5  service_visit_def_1102  1
    service_1_18_5  free_load_conservation_1103  -3
    service_1_18_5  original_T_including_depot_unload_1119  360
    service_1_18_6  unique_nonzero_owner_300  1
    service_1_18_6  service_visit_def_1102  1
    service_1_18_6  free_load_conservation_1103  -2
    service_1_18_6  original_T_including_depot_unload_1119  240
    service_1_18_7  unique_nonzero_owner_301  1
    service_1_18_7  service_visit_def_1102  1
    service_1_18_7  free_load_conservation_1103  -1
    service_1_18_7  original_T_including_depot_unload_1119  120
    service_1_18_9  unique_nonzero_owner_302  1
    service_1_18_9  service_visit_def_1102  1
    service_1_18_9  free_load_conservation_1103  1
    service_1_18_10  unique_nonzero_owner_303  1
    service_1_18_10  service_visit_def_1102  1
    service_1_18_10  free_load_conservation_1103  2
    service_2_18_0  unique_nonzero_owner_294  1
    service_2_18_0  service_visit_def_1420  1
    service_2_18_0  free_load_conservation_1421  -8
    service_2_18_0  original_T_including_depot_unload_1436  960
    service_2_18_1  unique_nonzero_owner_295  1
    service_2_18_1  service_visit_def_1420  1
    service_2_18_1  free_load_conservation_1421  -7
    service_2_18_1  original_T_including_depot_unload_1436  840
    service_2_18_2  unique_nonzero_owner_296  1
    service_2_18_2  service_visit_def_1420  1
    service_2_18_2  free_load_conservation_1421  -6
    service_2_18_2  original_T_including_depot_unload_1436  720
    service_2_18_3  unique_nonzero_owner_297  1
    service_2_18_3  service_visit_def_1420  1
    service_2_18_3  free_load_conservation_1421  -5
    service_2_18_3  original_T_including_depot_unload_1436  600
    service_2_18_4  unique_nonzero_owner_298  1
    service_2_18_4  service_visit_def_1420  1
    service_2_18_4  free_load_conservation_1421  -4
    service_2_18_4  original_T_including_depot_unload_1436  480
    service_2_18_5  unique_nonzero_owner_299  1
    service_2_18_5  service_visit_def_1420  1
    service_2_18_5  free_load_conservation_1421  -3
    service_2_18_5  original_T_including_depot_unload_1436  360
    service_2_18_6  unique_nonzero_owner_300  1
    service_2_18_6  service_visit_def_1420  1
    service_2_18_6  free_load_conservation_1421  -2
    service_2_18_6  original_T_including_depot_unload_1436  240
    service_2_18_7  unique_nonzero_owner_301  1
    service_2_18_7  service_visit_def_1420  1
    service_2_18_7  free_load_conservation_1421  -1
    service_2_18_7  original_T_including_depot_unload_1436  120
    service_2_18_9  unique_nonzero_owner_302  1
    service_2_18_9  service_visit_def_1420  1
    service_2_18_9  free_load_conservation_1421  1
    service_2_18_10  unique_nonzero_owner_303  1
    service_2_18_10  service_visit_def_1420  1
    service_2_18_10  free_load_conservation_1421  2
    service_0_27_1  unique_nonzero_owner_304  1
    service_0_27_1  service_visit_def_736  1
    service_0_27_1  free_load_conservation_737  1
    service_0_27_2  unique_nonzero_owner_305  1
    service_0_27_2  service_visit_def_736  1
    service_0_27_2  free_load_conservation_737  2
    service_0_27_3  unique_nonzero_owner_306  1
    service_0_27_3  service_visit_def_736  1
    service_0_27_3  free_load_conservation_737  3
    service_0_27_4  unique_nonzero_owner_307  1
    service_0_27_4  service_visit_def_736  1
    service_0_27_4  free_load_conservation_737  4
    service_0_27_5  unique_nonzero_owner_308  1
    service_0_27_5  service_visit_def_736  1
    service_0_27_5  free_load_conservation_737  5
    service_0_27_6  unique_nonzero_owner_309  1
    service_0_27_6  service_visit_def_736  1
    service_0_27_6  free_load_conservation_737  6
    service_1_27_1  unique_nonzero_owner_304  1
    service_1_27_1  service_visit_def_1108  1
    service_1_27_1  free_load_conservation_1109  1
    service_1_27_2  unique_nonzero_owner_305  1
    service_1_27_2  service_visit_def_1108  1
    service_1_27_2  free_load_conservation_1109  2
    service_1_27_3  unique_nonzero_owner_306  1
    service_1_27_3  service_visit_def_1108  1
    service_1_27_3  free_load_conservation_1109  3
    service_1_27_4  unique_nonzero_owner_307  1
    service_1_27_4  service_visit_def_1108  1
    service_1_27_4  free_load_conservation_1109  4
    service_1_27_5  unique_nonzero_owner_308  1
    service_1_27_5  service_visit_def_1108  1
    service_1_27_5  free_load_conservation_1109  5
    service_1_27_6  unique_nonzero_owner_309  1
    service_1_27_6  service_visit_def_1108  1
    service_1_27_6  free_load_conservation_1109  6
    service_2_27_1  unique_nonzero_owner_304  1
    service_2_27_1  service_visit_def_1426  1
    service_2_27_1  free_load_conservation_1427  1
    service_2_27_2  unique_nonzero_owner_305  1
    service_2_27_2  service_visit_def_1426  1
    service_2_27_2  free_load_conservation_1427  2
    service_2_27_3  unique_nonzero_owner_306  1
    service_2_27_3  service_visit_def_1426  1
    service_2_27_3  free_load_conservation_1427  3
    service_2_27_4  unique_nonzero_owner_307  1
    service_2_27_4  service_visit_def_1426  1
    service_2_27_4  free_load_conservation_1427  4
    service_2_27_5  unique_nonzero_owner_308  1
    service_2_27_5  service_visit_def_1426  1
    service_2_27_5  free_load_conservation_1427  5
    service_2_27_6  unique_nonzero_owner_309  1
    service_2_27_6  service_visit_def_1426  1
    service_2_27_6  free_load_conservation_1427  6
    service_0_19_0  unique_nonzero_owner_310  1
    service_0_19_0  service_visit_def_742  1
    service_0_19_0  free_load_conservation_743  -1
    service_0_19_0  original_T_including_depot_unload_748  120
    service_0_19_2  unique_nonzero_owner_311  1
    service_0_19_2  service_visit_def_742  1
    service_0_19_2  free_load_conservation_743  1
    service_0_19_3  unique_nonzero_owner_312  1
    service_0_19_3  service_visit_def_742  1
    service_0_19_3  free_load_conservation_743  2
    service_0_19_4  unique_nonzero_owner_313  1
    service_0_19_4  service_visit_def_742  1
    service_0_19_4  free_load_conservation_743  3
    service_0_19_5  unique_nonzero_owner_314  1
    service_0_19_5  service_visit_def_742  1
    service_0_19_5  free_load_conservation_743  4
    service_0_19_6  unique_nonzero_owner_315  1
    service_0_19_6  service_visit_def_742  1
    service_0_19_6  free_load_conservation_743  5
    service_0_19_7  unique_nonzero_owner_316  1
    service_0_19_7  service_visit_def_742  1
    service_0_19_7  free_load_conservation_743  6
    service_0_19_8  unique_nonzero_owner_317  1
    service_0_19_8  service_visit_def_742  1
    service_0_19_8  free_load_conservation_743  7
    service_0_19_9  unique_nonzero_owner_318  1
    service_0_19_9  service_visit_def_742  1
    service_0_19_9  free_load_conservation_743  8
    service_0_19_10  unique_nonzero_owner_319  1
    service_0_19_10  service_visit_def_742  1
    service_0_19_10  free_load_conservation_743  9
    service_1_19_0  unique_nonzero_owner_310  1
    service_1_19_0  service_visit_def_1114  1
    service_1_19_0  free_load_conservation_1115  -1
    service_1_19_0  original_T_including_depot_unload_1119  120
    service_1_19_2  unique_nonzero_owner_311  1
    service_1_19_2  service_visit_def_1114  1
    service_1_19_2  free_load_conservation_1115  1
    service_1_19_3  unique_nonzero_owner_312  1
    service_1_19_3  service_visit_def_1114  1
    service_1_19_3  free_load_conservation_1115  2
    service_1_19_4  unique_nonzero_owner_313  1
    service_1_19_4  service_visit_def_1114  1
    service_1_19_4  free_load_conservation_1115  3
    service_1_19_5  unique_nonzero_owner_314  1
    service_1_19_5  service_visit_def_1114  1
    service_1_19_5  free_load_conservation_1115  4
    service_1_19_6  unique_nonzero_owner_315  1
    service_1_19_6  service_visit_def_1114  1
    service_1_19_6  free_load_conservation_1115  5
    service_1_19_7  unique_nonzero_owner_316  1
    service_1_19_7  service_visit_def_1114  1
    service_1_19_7  free_load_conservation_1115  6
    service_1_19_8  unique_nonzero_owner_317  1
    service_1_19_8  service_visit_def_1114  1
    service_1_19_8  free_load_conservation_1115  7
    service_1_19_9  unique_nonzero_owner_318  1
    service_1_19_9  service_visit_def_1114  1
    service_1_19_9  free_load_conservation_1115  8
    service_1_19_10  unique_nonzero_owner_319  1
    service_1_19_10  service_visit_def_1114  1
    service_1_19_10  free_load_conservation_1115  9
    service_2_19_0  unique_nonzero_owner_310  1
    service_2_19_0  service_visit_def_1432  1
    service_2_19_0  free_load_conservation_1433  -1
    service_2_19_0  original_T_including_depot_unload_1436  120
    service_2_19_2  unique_nonzero_owner_311  1
    service_2_19_2  service_visit_def_1432  1
    service_2_19_2  free_load_conservation_1433  1
    service_2_19_3  unique_nonzero_owner_312  1
    service_2_19_3  service_visit_def_1432  1
    service_2_19_3  free_load_conservation_1433  2
    service_2_19_4  unique_nonzero_owner_313  1
    service_2_19_4  service_visit_def_1432  1
    service_2_19_4  free_load_conservation_1433  3
    service_2_19_5  unique_nonzero_owner_314  1
    service_2_19_5  service_visit_def_1432  1
    service_2_19_5  free_load_conservation_1433  4
    service_2_19_6  unique_nonzero_owner_315  1
    service_2_19_6  service_visit_def_1432  1
    service_2_19_6  free_load_conservation_1433  5
    service_2_19_7  unique_nonzero_owner_316  1
    service_2_19_7  service_visit_def_1432  1
    service_2_19_7  free_load_conservation_1433  6
    service_2_19_8  unique_nonzero_owner_317  1
    service_2_19_8  service_visit_def_1432  1
    service_2_19_8  free_load_conservation_1433  7
    service_2_19_9  unique_nonzero_owner_318  1
    service_2_19_9  service_visit_def_1432  1
    service_2_19_9  free_load_conservation_1433  8
    service_2_19_10  unique_nonzero_owner_319  1
    service_2_19_10  service_visit_def_1432  1
    service_2_19_10  free_load_conservation_1433  9
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_661  -1
    visit_0_1  in_degree_662  -1
    visit_0_1  order_active_lb_663  -1
    visit_0_1  order_active_ub_664  -13
    order_0_1  connected_order_arc_336  -1
    order_0_1  connected_order_arc_338  -1
    order_0_1  connected_order_arc_340  -1
    order_0_1  connected_order_arc_342  -1
    order_0_1  connected_order_arc_344  -1
    order_0_1  connected_order_arc_346  -1
    order_0_1  connected_order_arc_348  -1
    order_0_1  connected_order_arc_350  -1
    order_0_1  connected_order_arc_352  -1
    order_0_1  connected_order_arc_354  -1
    order_0_1  connected_order_arc_356  -1
    order_0_1  connected_order_arc_358  -1
    order_0_1  connected_order_arc_361  1
    order_0_1  connected_order_arc_386  1
    order_0_1  connected_order_arc_411  1
    order_0_1  connected_order_arc_436  1
    order_0_1  connected_order_arc_461  1
    order_0_1  connected_order_arc_486  1
    order_0_1  connected_order_arc_511  1
    order_0_1  connected_order_arc_536  1
    order_0_1  connected_order_arc_561  1
    order_0_1  connected_order_arc_586  1
    order_0_1  connected_order_arc_611  1
    order_0_1  connected_order_arc_636  1
    order_0_1  order_active_lb_663  1
    order_0_1  order_active_ub_664  1
    order_0_1  fixed_segment_relative_order_744  -1
    visit_0_2  out_degree_668  -1
    visit_0_2  in_degree_669  -1
    visit_0_2  order_active_lb_670  -1
    visit_0_2  order_active_ub_671  -13
    order_0_2  connected_order_arc_336  1
    order_0_2  connected_order_arc_361  -1
    order_0_2  connected_order_arc_363  -1
    order_0_2  connected_order_arc_365  -1
    order_0_2  connected_order_arc_367  -1
    order_0_2  connected_order_arc_369  -1
    order_0_2  connected_order_arc_371  -1
    order_0_2  connected_order_arc_373  -1
    order_0_2  connected_order_arc_375  -1
    order_0_2  connected_order_arc_377  -1
    order_0_2  connected_order_arc_379  -1
    order_0_2  connected_order_arc_381  -1
    order_0_2  connected_order_arc_383  -1
    order_0_2  connected_order_arc_388  1
    order_0_2  connected_order_arc_413  1
    order_0_2  connected_order_arc_438  1
    order_0_2  connected_order_arc_463  1
    order_0_2  connected_order_arc_488  1
    order_0_2  connected_order_arc_513  1
    order_0_2  connected_order_arc_538  1
    order_0_2  connected_order_arc_563  1
    order_0_2  connected_order_arc_588  1
    order_0_2  connected_order_arc_613  1
    order_0_2  connected_order_arc_638  1
    order_0_2  order_active_lb_670  1
    order_0_2  order_active_ub_671  1
    order_0_2  fixed_segment_relative_order_744  1
    order_0_2  fixed_segment_relative_order_745  -1
    visit_0_3  out_degree_675  -1
    visit_0_3  in_degree_676  -1
    visit_0_3  order_active_lb_677  -1
    visit_0_3  order_active_ub_678  -13
    order_0_3  connected_order_arc_338  1
    order_0_3  connected_order_arc_363  1
    order_0_3  connected_order_arc_386  -1
    order_0_3  connected_order_arc_388  -1
    order_0_3  connected_order_arc_390  -1
    order_0_3  connected_order_arc_392  -1
    order_0_3  connected_order_arc_394  -1
    order_0_3  connected_order_arc_396  -1
    order_0_3  connected_order_arc_398  -1
    order_0_3  connected_order_arc_400  -1
    order_0_3  connected_order_arc_402  -1
    order_0_3  connected_order_arc_404  -1
    order_0_3  connected_order_arc_406  -1
    order_0_3  connected_order_arc_408  -1
    order_0_3  connected_order_arc_415  1
    order_0_3  connected_order_arc_440  1
    order_0_3  connected_order_arc_465  1
    order_0_3  connected_order_arc_490  1
    order_0_3  connected_order_arc_515  1
    order_0_3  connected_order_arc_540  1
    order_0_3  connected_order_arc_565  1
    order_0_3  connected_order_arc_590  1
    order_0_3  connected_order_arc_615  1
    order_0_3  connected_order_arc_640  1
    order_0_3  order_active_lb_677  1
    order_0_3  order_active_ub_678  1
    order_0_3  fixed_segment_relative_order_745  1
    order_0_3  fixed_segment_relative_order_746  -1
    visit_0_4  out_degree_682  -1
    visit_0_4  in_degree_683  -1
    visit_0_4  order_active_lb_684  -1
    visit_0_4  order_active_ub_685  -13
    order_0_4  connected_order_arc_340  1
    order_0_4  connected_order_arc_365  1
    order_0_4  connected_order_arc_390  1
    order_0_4  connected_order_arc_411  -1
    order_0_4  connected_order_arc_413  -1
    order_0_4  connected_order_arc_415  -1
    order_0_4  connected_order_arc_417  -1
    order_0_4  connected_order_arc_419  -1
    order_0_4  connected_order_arc_421  -1
    order_0_4  connected_order_arc_423  -1
    order_0_4  connected_order_arc_425  -1
    order_0_4  connected_order_arc_427  -1
    order_0_4  connected_order_arc_429  -1
    order_0_4  connected_order_arc_431  -1
    order_0_4  connected_order_arc_433  -1
    order_0_4  connected_order_arc_442  1
    order_0_4  connected_order_arc_467  1
    order_0_4  connected_order_arc_492  1
    order_0_4  connected_order_arc_517  1
    order_0_4  connected_order_arc_542  1
    order_0_4  connected_order_arc_567  1
    order_0_4  connected_order_arc_592  1
    order_0_4  connected_order_arc_617  1
    order_0_4  connected_order_arc_642  1
    order_0_4  order_active_lb_684  1
    order_0_4  order_active_ub_685  1
    order_0_4  fixed_segment_relative_order_746  1
    order_0_4  fixed_segment_relative_order_747  -1
    visit_0_5  out_degree_689  -1
    visit_0_5  in_degree_690  -1
    visit_0_5  order_active_lb_691  -1
    visit_0_5  order_active_ub_692  -13
    order_0_5  connected_order_arc_342  1
    order_0_5  connected_order_arc_367  1
    order_0_5  connected_order_arc_392  1
    order_0_5  connected_order_arc_417  1
    order_0_5  connected_order_arc_436  -1
    order_0_5  connected_order_arc_438  -1
    order_0_5  connected_order_arc_440  -1
    order_0_5  connected_order_arc_442  -1
    order_0_5  connected_order_arc_444  -1
    order_0_5  connected_order_arc_446  -1
    order_0_5  connected_order_arc_448  -1
    order_0_5  connected_order_arc_450  -1
    order_0_5  connected_order_arc_452  -1
    order_0_5  connected_order_arc_454  -1
    order_0_5  connected_order_arc_456  -1
    order_0_5  connected_order_arc_458  -1
    order_0_5  connected_order_arc_469  1
    order_0_5  connected_order_arc_494  1
    order_0_5  connected_order_arc_519  1
    order_0_5  connected_order_arc_544  1
    order_0_5  connected_order_arc_569  1
    order_0_5  connected_order_arc_594  1
    order_0_5  connected_order_arc_619  1
    order_0_5  connected_order_arc_644  1
    order_0_5  order_active_lb_691  1
    order_0_5  order_active_ub_692  1
    order_0_5  fixed_segment_relative_order_747  1
    visit_0_13  out_degree_696  -1
    visit_0_13  in_degree_697  -1
    visit_0_13  order_active_lb_698  -1
    visit_0_13  order_active_ub_699  -13
    visit_0_13  service_visit_def_700  -1
    order_0_13  connected_order_arc_344  1
    order_0_13  connected_order_arc_369  1
    order_0_13  connected_order_arc_394  1
    order_0_13  connected_order_arc_419  1
    order_0_13  connected_order_arc_444  1
    order_0_13  connected_order_arc_461  -1
    order_0_13  connected_order_arc_463  -1
    order_0_13  connected_order_arc_465  -1
    order_0_13  connected_order_arc_467  -1
    order_0_13  connected_order_arc_469  -1
    order_0_13  connected_order_arc_471  -1
    order_0_13  connected_order_arc_473  -1
    order_0_13  connected_order_arc_475  -1
    order_0_13  connected_order_arc_477  -1
    order_0_13  connected_order_arc_479  -1
    order_0_13  connected_order_arc_481  -1
    order_0_13  connected_order_arc_483  -1
    order_0_13  connected_order_arc_496  1
    order_0_13  connected_order_arc_521  1
    order_0_13  connected_order_arc_546  1
    order_0_13  connected_order_arc_571  1
    order_0_13  connected_order_arc_596  1
    order_0_13  connected_order_arc_621  1
    order_0_13  connected_order_arc_646  1
    order_0_13  order_active_lb_698  1
    order_0_13  order_active_ub_699  1
    visit_0_14  out_degree_702  -1
    visit_0_14  in_degree_703  -1
    visit_0_14  order_active_lb_704  -1
    visit_0_14  order_active_ub_705  -13
    visit_0_14  service_visit_def_706  -1
    order_0_14  connected_order_arc_346  1
    order_0_14  connected_order_arc_371  1
    order_0_14  connected_order_arc_396  1
    order_0_14  connected_order_arc_421  1
    order_0_14  connected_order_arc_446  1
    order_0_14  connected_order_arc_471  1
    order_0_14  connected_order_arc_486  -1
    order_0_14  connected_order_arc_488  -1
    order_0_14  connected_order_arc_490  -1
    order_0_14  connected_order_arc_492  -1
    order_0_14  connected_order_arc_494  -1
    order_0_14  connected_order_arc_496  -1
    order_0_14  connected_order_arc_498  -1
    order_0_14  connected_order_arc_500  -1
    order_0_14  connected_order_arc_502  -1
    order_0_14  connected_order_arc_504  -1
    order_0_14  connected_order_arc_506  -1
    order_0_14  connected_order_arc_508  -1
    order_0_14  connected_order_arc_523  1
    order_0_14  connected_order_arc_548  1
    order_0_14  connected_order_arc_573  1
    order_0_14  connected_order_arc_598  1
    order_0_14  connected_order_arc_623  1
    order_0_14  connected_order_arc_648  1
    order_0_14  order_active_lb_704  1
    order_0_14  order_active_ub_705  1
    visit_0_15  out_degree_708  -1
    visit_0_15  in_degree_709  -1
    visit_0_15  order_active_lb_710  -1
    visit_0_15  order_active_ub_711  -13
    visit_0_15  service_visit_def_712  -1
    order_0_15  connected_order_arc_348  1
    order_0_15  connected_order_arc_373  1
    order_0_15  connected_order_arc_398  1
    order_0_15  connected_order_arc_423  1
    order_0_15  connected_order_arc_448  1
    order_0_15  connected_order_arc_473  1
    order_0_15  connected_order_arc_498  1
    order_0_15  connected_order_arc_511  -1
    order_0_15  connected_order_arc_513  -1
    order_0_15  connected_order_arc_515  -1
    order_0_15  connected_order_arc_517  -1
    order_0_15  connected_order_arc_519  -1
    order_0_15  connected_order_arc_521  -1
    order_0_15  connected_order_arc_523  -1
    order_0_15  connected_order_arc_525  -1
    order_0_15  connected_order_arc_527  -1
    order_0_15  connected_order_arc_529  -1
    order_0_15  connected_order_arc_531  -1
    order_0_15  connected_order_arc_533  -1
    order_0_15  connected_order_arc_550  1
    order_0_15  connected_order_arc_575  1
    order_0_15  connected_order_arc_600  1
    order_0_15  connected_order_arc_625  1
    order_0_15  connected_order_arc_650  1
    order_0_15  order_active_lb_710  1
    order_0_15  order_active_ub_711  1
    visit_0_16  out_degree_714  -1
    visit_0_16  in_degree_715  -1
    visit_0_16  order_active_lb_716  -1
    visit_0_16  order_active_ub_717  -13
    visit_0_16  service_visit_def_718  -1
    order_0_16  connected_order_arc_350  1
    order_0_16  connected_order_arc_375  1
    order_0_16  connected_order_arc_400  1
    order_0_16  connected_order_arc_425  1
    order_0_16  connected_order_arc_450  1
    order_0_16  connected_order_arc_475  1
    order_0_16  connected_order_arc_500  1
    order_0_16  connected_order_arc_525  1
    order_0_16  connected_order_arc_536  -1
    order_0_16  connected_order_arc_538  -1
    order_0_16  connected_order_arc_540  -1
    order_0_16  connected_order_arc_542  -1
    order_0_16  connected_order_arc_544  -1
    order_0_16  connected_order_arc_546  -1
    order_0_16  connected_order_arc_548  -1
    order_0_16  connected_order_arc_550  -1
    order_0_16  connected_order_arc_552  -1
    order_0_16  connected_order_arc_554  -1
    order_0_16  connected_order_arc_556  -1
    order_0_16  connected_order_arc_558  -1
    order_0_16  connected_order_arc_577  1
    order_0_16  connected_order_arc_602  1
    order_0_16  connected_order_arc_627  1
    order_0_16  connected_order_arc_652  1
    order_0_16  order_active_lb_716  1
    order_0_16  order_active_ub_717  1
    visit_0_17  out_degree_720  -1
    visit_0_17  in_degree_721  -1
    visit_0_17  order_active_lb_722  -1
    visit_0_17  order_active_ub_723  -13
    visit_0_17  service_visit_def_724  -1
    order_0_17  connected_order_arc_352  1
    order_0_17  connected_order_arc_377  1
    order_0_17  connected_order_arc_402  1
    order_0_17  connected_order_arc_427  1
    order_0_17  connected_order_arc_452  1
    order_0_17  connected_order_arc_477  1
    order_0_17  connected_order_arc_502  1
    order_0_17  connected_order_arc_527  1
    order_0_17  connected_order_arc_552  1
    order_0_17  connected_order_arc_561  -1
    order_0_17  connected_order_arc_563  -1
    order_0_17  connected_order_arc_565  -1
    order_0_17  connected_order_arc_567  -1
    order_0_17  connected_order_arc_569  -1
    order_0_17  connected_order_arc_571  -1
    order_0_17  connected_order_arc_573  -1
    order_0_17  connected_order_arc_575  -1
    order_0_17  connected_order_arc_577  -1
    order_0_17  connected_order_arc_579  -1
    order_0_17  connected_order_arc_581  -1
    order_0_17  connected_order_arc_583  -1
    order_0_17  connected_order_arc_604  1
    order_0_17  connected_order_arc_629  1
    order_0_17  connected_order_arc_654  1
    order_0_17  order_active_lb_722  1
    order_0_17  order_active_ub_723  1
    visit_0_18  out_degree_726  -1
    visit_0_18  in_degree_727  -1
    visit_0_18  order_active_lb_728  -1
    visit_0_18  order_active_ub_729  -13
    visit_0_18  service_visit_def_730  -1
    order_0_18  connected_order_arc_354  1
    order_0_18  connected_order_arc_379  1
    order_0_18  connected_order_arc_404  1
    order_0_18  connected_order_arc_429  1
    order_0_18  connected_order_arc_454  1
    order_0_18  connected_order_arc_479  1
    order_0_18  connected_order_arc_504  1
    order_0_18  connected_order_arc_529  1
    order_0_18  connected_order_arc_554  1
    order_0_18  connected_order_arc_579  1
    order_0_18  connected_order_arc_586  -1
    order_0_18  connected_order_arc_588  -1
    order_0_18  connected_order_arc_590  -1
    order_0_18  connected_order_arc_592  -1
    order_0_18  connected_order_arc_594  -1
    order_0_18  connected_order_arc_596  -1
    order_0_18  connected_order_arc_598  -1
    order_0_18  connected_order_arc_600  -1
    order_0_18  connected_order_arc_602  -1
    order_0_18  connected_order_arc_604  -1
    order_0_18  connected_order_arc_606  -1
    order_0_18  connected_order_arc_608  -1
    order_0_18  connected_order_arc_631  1
    order_0_18  connected_order_arc_656  1
    order_0_18  order_active_lb_728  1
    order_0_18  order_active_ub_729  1
    visit_0_19  out_degree_732  -1
    visit_0_19  in_degree_733  -1
    visit_0_19  order_active_lb_734  -1
    visit_0_19  order_active_ub_735  -13
    visit_0_19  service_visit_def_736  -1
    order_0_19  connected_order_arc_356  1
    order_0_19  connected_order_arc_381  1
    order_0_19  connected_order_arc_406  1
    order_0_19  connected_order_arc_431  1
    order_0_19  connected_order_arc_456  1
    order_0_19  connected_order_arc_481  1
    order_0_19  connected_order_arc_506  1
    order_0_19  connected_order_arc_531  1
    order_0_19  connected_order_arc_556  1
    order_0_19  connected_order_arc_581  1
    order_0_19  connected_order_arc_606  1
    order_0_19  connected_order_arc_611  -1
    order_0_19  connected_order_arc_613  -1
    order_0_19  connected_order_arc_615  -1
    order_0_19  connected_order_arc_617  -1
    order_0_19  connected_order_arc_619  -1
    order_0_19  connected_order_arc_621  -1
    order_0_19  connected_order_arc_623  -1
    order_0_19  connected_order_arc_625  -1
    order_0_19  connected_order_arc_627  -1
    order_0_19  connected_order_arc_629  -1
    order_0_19  connected_order_arc_631  -1
    order_0_19  connected_order_arc_633  -1
    order_0_19  connected_order_arc_658  1
    order_0_19  order_active_lb_734  1
    order_0_19  order_active_ub_735  1
    visit_0_20  out_degree_738  -1
    visit_0_20  in_degree_739  -1
    visit_0_20  order_active_lb_740  -1
    visit_0_20  order_active_ub_741  -13
    visit_0_20  service_visit_def_742  -1
    order_0_20  connected_order_arc_358  1
    order_0_20  connected_order_arc_383  1
    order_0_20  connected_order_arc_408  1
    order_0_20  connected_order_arc_433  1
    order_0_20  connected_order_arc_458  1
    order_0_20  connected_order_arc_483  1
    order_0_20  connected_order_arc_508  1
    order_0_20  connected_order_arc_533  1
    order_0_20  connected_order_arc_558  1
    order_0_20  connected_order_arc_583  1
    order_0_20  connected_order_arc_608  1
    order_0_20  connected_order_arc_633  1
    order_0_20  connected_order_arc_636  -1
    order_0_20  connected_order_arc_638  -1
    order_0_20  connected_order_arc_640  -1
    order_0_20  connected_order_arc_642  -1
    order_0_20  connected_order_arc_644  -1
    order_0_20  connected_order_arc_646  -1
    order_0_20  connected_order_arc_648  -1
    order_0_20  connected_order_arc_650  -1
    order_0_20  connected_order_arc_652  -1
    order_0_20  connected_order_arc_654  -1
    order_0_20  connected_order_arc_656  -1
    order_0_20  connected_order_arc_658  -1
    order_0_20  order_active_lb_740  1
    order_0_20  order_active_ub_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_320  -20
    arc_0_0_0  depot_departure_or_bypass_659  1
    arc_0_0_0  depot_return_or_bypass_660  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_320  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_321  -20
    arc_0_0_1  depot_departure_or_bypass_659  1
    arc_0_0_1  in_degree_662  1
    arc_0_0_1  original_T_including_depot_unload_748  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_321  1
    load_0_0_1  segment_load_conservation_665  -1
    load_0_0_1  segment_prefix_lb_666  1
    load_0_0_1  segment_prefix_ub_667  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_322  -20
    arc_0_0_2  depot_departure_or_bypass_659  1
    arc_0_0_2  in_degree_669  1
    arc_0_0_2  original_T_including_depot_unload_748  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_322  1
    load_0_0_2  segment_load_conservation_672  -1
    load_0_0_2  segment_prefix_lb_673  1
    load_0_0_2  segment_prefix_ub_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_323  -20
    arc_0_0_3  depot_departure_or_bypass_659  1
    arc_0_0_3  in_degree_676  1
    arc_0_0_3  original_T_including_depot_unload_748  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_323  1
    load_0_0_3  segment_load_conservation_679  -1
    load_0_0_3  segment_prefix_lb_680  1
    load_0_0_3  segment_prefix_ub_681  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_324  -20
    arc_0_0_4  depot_departure_or_bypass_659  1
    arc_0_0_4  in_degree_683  1
    arc_0_0_4  original_T_including_depot_unload_748  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_324  1
    load_0_0_4  segment_load_conservation_686  -1
    load_0_0_4  segment_prefix_lb_687  1
    load_0_0_4  segment_prefix_ub_688  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_325  -20
    arc_0_0_5  depot_departure_or_bypass_659  1
    arc_0_0_5  in_degree_690  1
    arc_0_0_5  original_T_including_depot_unload_748  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_325  1
    load_0_0_5  segment_load_conservation_693  -1
    load_0_0_5  segment_prefix_lb_694  1
    load_0_0_5  segment_prefix_ub_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_326  -20
    arc_0_0_13  depot_departure_or_bypass_659  1
    arc_0_0_13  in_degree_697  1
    arc_0_0_13  original_T_including_depot_unload_748  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_326  1
    load_0_0_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_327  -20
    arc_0_0_14  depot_departure_or_bypass_659  1
    arc_0_0_14  in_degree_703  1
    arc_0_0_14  original_T_including_depot_unload_748  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_327  1
    load_0_0_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_328  -20
    arc_0_0_15  depot_departure_or_bypass_659  1
    arc_0_0_15  in_degree_709  1
    arc_0_0_15  original_T_including_depot_unload_748  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_328  1
    load_0_0_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_329  -20
    arc_0_0_16  depot_departure_or_bypass_659  1
    arc_0_0_16  in_degree_715  1
    arc_0_0_16  original_T_including_depot_unload_748  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_329  1
    load_0_0_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_330  -20
    arc_0_0_17  depot_departure_or_bypass_659  1
    arc_0_0_17  in_degree_721  1
    arc_0_0_17  original_T_including_depot_unload_748  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_330  1
    load_0_0_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_331  -20
    arc_0_0_18  depot_departure_or_bypass_659  1
    arc_0_0_18  in_degree_727  1
    arc_0_0_18  original_T_including_depot_unload_748  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_331  1
    load_0_0_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_332  -20
    arc_0_0_19  depot_departure_or_bypass_659  1
    arc_0_0_19  in_degree_733  1
    arc_0_0_19  original_T_including_depot_unload_748  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_332  1
    load_0_0_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_333  -20
    arc_0_0_20  depot_departure_or_bypass_659  1
    arc_0_0_20  in_degree_739  1
    arc_0_0_20  original_T_including_depot_unload_748  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_333  1
    load_0_0_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_334  -20
    arc_0_1_0  depot_return_or_bypass_660  1
    arc_0_1_0  out_degree_661  1
    arc_0_1_0  original_T_including_depot_unload_748  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_334  1
    load_0_1_0  segment_load_conservation_665  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_335  -20
    arc_0_1_2  connected_order_arc_336  -14
    arc_0_1_2  out_degree_661  1
    arc_0_1_2  in_degree_669  1
    arc_0_1_2  original_T_including_depot_unload_748  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_335  1
    load_0_1_2  segment_load_conservation_665  1
    load_0_1_2  segment_load_conservation_672  -1
    load_0_1_2  segment_prefix_lb_673  1
    load_0_1_2  segment_prefix_ub_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_337  -20
    arc_0_1_3  connected_order_arc_338  -14
    arc_0_1_3  out_degree_661  1
    arc_0_1_3  in_degree_676  1
    arc_0_1_3  original_T_including_depot_unload_748  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_337  1
    load_0_1_3  segment_load_conservation_665  1
    load_0_1_3  segment_load_conservation_679  -1
    load_0_1_3  segment_prefix_lb_680  1
    load_0_1_3  segment_prefix_ub_681  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_339  -20
    arc_0_1_4  connected_order_arc_340  -14
    arc_0_1_4  out_degree_661  1
    arc_0_1_4  in_degree_683  1
    arc_0_1_4  original_T_including_depot_unload_748  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_339  1
    load_0_1_4  segment_load_conservation_665  1
    load_0_1_4  segment_load_conservation_686  -1
    load_0_1_4  segment_prefix_lb_687  1
    load_0_1_4  segment_prefix_ub_688  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_341  -20
    arc_0_1_5  connected_order_arc_342  -14
    arc_0_1_5  out_degree_661  1
    arc_0_1_5  in_degree_690  1
    arc_0_1_5  original_T_including_depot_unload_748  6.7262401684980023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_341  1
    load_0_1_5  segment_load_conservation_665  1
    load_0_1_5  segment_load_conservation_693  -1
    load_0_1_5  segment_prefix_lb_694  1
    load_0_1_5  segment_prefix_ub_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_343  -20
    arc_0_1_13  connected_order_arc_344  -14
    arc_0_1_13  out_degree_661  1
    arc_0_1_13  in_degree_697  1
    arc_0_1_13  original_T_including_depot_unload_748  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_343  1
    load_0_1_13  segment_load_conservation_665  1
    load_0_1_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_345  -20
    arc_0_1_14  connected_order_arc_346  -14
    arc_0_1_14  out_degree_661  1
    arc_0_1_14  in_degree_703  1
    arc_0_1_14  original_T_including_depot_unload_748  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_345  1
    load_0_1_14  segment_load_conservation_665  1
    load_0_1_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_347  -20
    arc_0_1_15  connected_order_arc_348  -14
    arc_0_1_15  out_degree_661  1
    arc_0_1_15  in_degree_709  1
    arc_0_1_15  original_T_including_depot_unload_748  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_347  1
    load_0_1_15  segment_load_conservation_665  1
    load_0_1_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_349  -20
    arc_0_1_16  connected_order_arc_350  -14
    arc_0_1_16  out_degree_661  1
    arc_0_1_16  in_degree_715  1
    arc_0_1_16  original_T_including_depot_unload_748  4.8384395388802926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_349  1
    load_0_1_16  segment_load_conservation_665  1
    load_0_1_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_351  -20
    arc_0_1_17  connected_order_arc_352  -14
    arc_0_1_17  out_degree_661  1
    arc_0_1_17  in_degree_721  1
    arc_0_1_17  original_T_including_depot_unload_748  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_351  1
    load_0_1_17  segment_load_conservation_665  1
    load_0_1_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_353  -20
    arc_0_1_18  connected_order_arc_354  -14
    arc_0_1_18  out_degree_661  1
    arc_0_1_18  in_degree_727  1
    arc_0_1_18  original_T_including_depot_unload_748  4.8549019843957007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_353  1
    load_0_1_18  segment_load_conservation_665  1
    load_0_1_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_355  -20
    arc_0_1_19  connected_order_arc_356  -14
    arc_0_1_19  out_degree_661  1
    arc_0_1_19  in_degree_733  1
    arc_0_1_19  original_T_including_depot_unload_748  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_355  1
    load_0_1_19  segment_load_conservation_665  1
    load_0_1_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_357  -20
    arc_0_1_20  connected_order_arc_358  -14
    arc_0_1_20  out_degree_661  1
    arc_0_1_20  in_degree_739  1
    arc_0_1_20  original_T_including_depot_unload_748  4.8605919276499873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_357  1
    load_0_1_20  segment_load_conservation_665  1
    load_0_1_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_359  -20
    arc_0_2_0  depot_return_or_bypass_660  1
    arc_0_2_0  out_degree_668  1
    arc_0_2_0  original_T_including_depot_unload_748  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_359  1
    load_0_2_0  segment_load_conservation_672  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_360  -20
    arc_0_2_1  connected_order_arc_361  -14
    arc_0_2_1  in_degree_662  1
    arc_0_2_1  out_degree_668  1
    arc_0_2_1  original_T_including_depot_unload_748  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_360  1
    load_0_2_1  segment_load_conservation_665  -1
    load_0_2_1  segment_prefix_lb_666  1
    load_0_2_1  segment_prefix_ub_667  1
    load_0_2_1  segment_load_conservation_672  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_362  -20
    arc_0_2_3  connected_order_arc_363  -14
    arc_0_2_3  out_degree_668  1
    arc_0_2_3  in_degree_676  1
    arc_0_2_3  original_T_including_depot_unload_748  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_362  1
    load_0_2_3  segment_load_conservation_672  1
    load_0_2_3  segment_load_conservation_679  -1
    load_0_2_3  segment_prefix_lb_680  1
    load_0_2_3  segment_prefix_ub_681  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_364  -20
    arc_0_2_4  connected_order_arc_365  -14
    arc_0_2_4  out_degree_668  1
    arc_0_2_4  in_degree_683  1
    arc_0_2_4  original_T_including_depot_unload_748  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_364  1
    load_0_2_4  segment_load_conservation_672  1
    load_0_2_4  segment_load_conservation_686  -1
    load_0_2_4  segment_prefix_lb_687  1
    load_0_2_4  segment_prefix_ub_688  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_366  -20
    arc_0_2_5  connected_order_arc_367  -14
    arc_0_2_5  out_degree_668  1
    arc_0_2_5  in_degree_690  1
    arc_0_2_5  original_T_including_depot_unload_748  6.7868847915924835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_366  1
    load_0_2_5  segment_load_conservation_672  1
    load_0_2_5  segment_load_conservation_693  -1
    load_0_2_5  segment_prefix_lb_694  1
    load_0_2_5  segment_prefix_ub_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_368  -20
    arc_0_2_13  connected_order_arc_369  -14
    arc_0_2_13  out_degree_668  1
    arc_0_2_13  in_degree_697  1
    arc_0_2_13  original_T_including_depot_unload_748  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_368  1
    load_0_2_13  segment_load_conservation_672  1
    load_0_2_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_370  -20
    arc_0_2_14  connected_order_arc_371  -14
    arc_0_2_14  out_degree_668  1
    arc_0_2_14  in_degree_703  1
    arc_0_2_14  original_T_including_depot_unload_748  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_370  1
    load_0_2_14  segment_load_conservation_672  1
    load_0_2_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_372  -20
    arc_0_2_15  connected_order_arc_373  -14
    arc_0_2_15  out_degree_668  1
    arc_0_2_15  in_degree_709  1
    arc_0_2_15  original_T_including_depot_unload_748  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_372  1
    load_0_2_15  segment_load_conservation_672  1
    load_0_2_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_374  -20
    arc_0_2_16  connected_order_arc_375  -14
    arc_0_2_16  out_degree_668  1
    arc_0_2_16  in_degree_715  1
    arc_0_2_16  original_T_including_depot_unload_748  4.9345054001313224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_374  1
    load_0_2_16  segment_load_conservation_672  1
    load_0_2_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_376  -20
    arc_0_2_17  connected_order_arc_377  -14
    arc_0_2_17  out_degree_668  1
    arc_0_2_17  in_degree_721  1
    arc_0_2_17  original_T_including_depot_unload_748  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_376  1
    load_0_2_17  segment_load_conservation_672  1
    load_0_2_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_378  -20
    arc_0_2_18  connected_order_arc_379  -14
    arc_0_2_18  out_degree_668  1
    arc_0_2_18  in_degree_727  1
    arc_0_2_18  original_T_including_depot_unload_748  4.9507442307813227e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_378  1
    load_0_2_18  segment_load_conservation_672  1
    load_0_2_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_380  -20
    arc_0_2_19  connected_order_arc_381  -14
    arc_0_2_19  out_degree_668  1
    arc_0_2_19  in_degree_733  1
    arc_0_2_19  original_T_including_depot_unload_748  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_380  1
    load_0_2_19  segment_load_conservation_672  1
    load_0_2_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_382  -20
    arc_0_2_20  connected_order_arc_383  -14
    arc_0_2_20  out_degree_668  1
    arc_0_2_20  in_degree_739  1
    arc_0_2_20  original_T_including_depot_unload_748  4.9556592834383019e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_382  1
    load_0_2_20  segment_load_conservation_672  1
    load_0_2_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_384  -20
    arc_0_3_0  depot_return_or_bypass_660  1
    arc_0_3_0  out_degree_675  1
    arc_0_3_0  original_T_including_depot_unload_748  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_384  1
    load_0_3_0  segment_load_conservation_679  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_385  -20
    arc_0_3_1  connected_order_arc_386  -14
    arc_0_3_1  in_degree_662  1
    arc_0_3_1  out_degree_675  1
    arc_0_3_1  original_T_including_depot_unload_748  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_385  1
    load_0_3_1  segment_load_conservation_665  -1
    load_0_3_1  segment_prefix_lb_666  1
    load_0_3_1  segment_prefix_ub_667  1
    load_0_3_1  segment_load_conservation_679  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_387  -20
    arc_0_3_2  connected_order_arc_388  -14
    arc_0_3_2  in_degree_669  1
    arc_0_3_2  out_degree_675  1
    arc_0_3_2  original_T_including_depot_unload_748  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_387  1
    load_0_3_2  segment_load_conservation_672  -1
    load_0_3_2  segment_prefix_lb_673  1
    load_0_3_2  segment_prefix_ub_674  1
    load_0_3_2  segment_load_conservation_679  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_389  -20
    arc_0_3_4  connected_order_arc_390  -14
    arc_0_3_4  out_degree_675  1
    arc_0_3_4  in_degree_683  1
    arc_0_3_4  original_T_including_depot_unload_748  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_389  1
    load_0_3_4  segment_load_conservation_679  1
    load_0_3_4  segment_load_conservation_686  -1
    load_0_3_4  segment_prefix_lb_687  1
    load_0_3_4  segment_prefix_ub_688  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_391  -20
    arc_0_3_5  connected_order_arc_392  -14
    arc_0_3_5  out_degree_675  1
    arc_0_3_5  in_degree_690  1
    arc_0_3_5  original_T_including_depot_unload_748  6.7806925965469873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_391  1
    load_0_3_5  segment_load_conservation_679  1
    load_0_3_5  segment_load_conservation_693  -1
    load_0_3_5  segment_prefix_lb_694  1
    load_0_3_5  segment_prefix_ub_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_393  -20
    arc_0_3_13  connected_order_arc_394  -14
    arc_0_3_13  out_degree_675  1
    arc_0_3_13  in_degree_697  1
    arc_0_3_13  original_T_including_depot_unload_748  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_393  1
    load_0_3_13  segment_load_conservation_679  1
    load_0_3_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_395  -20
    arc_0_3_14  connected_order_arc_396  -14
    arc_0_3_14  out_degree_675  1
    arc_0_3_14  in_degree_703  1
    arc_0_3_14  original_T_including_depot_unload_748  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_395  1
    load_0_3_14  segment_load_conservation_679  1
    load_0_3_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_397  -20
    arc_0_3_15  connected_order_arc_398  -14
    arc_0_3_15  out_degree_675  1
    arc_0_3_15  in_degree_709  1
    arc_0_3_15  original_T_including_depot_unload_748  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_397  1
    load_0_3_15  segment_load_conservation_679  1
    load_0_3_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_399  -20
    arc_0_3_16  connected_order_arc_400  -14
    arc_0_3_16  out_degree_675  1
    arc_0_3_16  in_degree_715  1
    arc_0_3_16  original_T_including_depot_unload_748  4.9283602644772810e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_399  1
    load_0_3_16  segment_load_conservation_679  1
    load_0_3_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_401  -20
    arc_0_3_17  connected_order_arc_402  -14
    arc_0_3_17  out_degree_675  1
    arc_0_3_17  in_degree_721  1
    arc_0_3_17  original_T_including_depot_unload_748  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_401  1
    load_0_3_17  segment_load_conservation_679  1
    load_0_3_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_403  -20
    arc_0_3_18  connected_order_arc_404  -14
    arc_0_3_18  out_degree_675  1
    arc_0_3_18  in_degree_727  1
    arc_0_3_18  original_T_including_depot_unload_748  4.9445985110995662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_403  1
    load_0_3_18  segment_load_conservation_679  1
    load_0_3_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_405  -20
    arc_0_3_19  connected_order_arc_406  -14
    arc_0_3_19  out_degree_675  1
    arc_0_3_19  in_degree_733  1
    arc_0_3_19  original_T_including_depot_unload_748  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_405  1
    load_0_3_19  segment_load_conservation_679  1
    load_0_3_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_407  -20
    arc_0_3_20  connected_order_arc_408  -14
    arc_0_3_20  out_degree_675  1
    arc_0_3_20  in_degree_739  1
    arc_0_3_20  original_T_including_depot_unload_748  4.9495118393852869e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_407  1
    load_0_3_20  segment_load_conservation_679  1
    load_0_3_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_409  -20
    arc_0_4_0  depot_return_or_bypass_660  1
    arc_0_4_0  out_degree_682  1
    arc_0_4_0  original_T_including_depot_unload_748  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_409  1
    load_0_4_0  segment_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_410  -20
    arc_0_4_1  connected_order_arc_411  -14
    arc_0_4_1  in_degree_662  1
    arc_0_4_1  out_degree_682  1
    arc_0_4_1  original_T_including_depot_unload_748  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_410  1
    load_0_4_1  segment_load_conservation_665  -1
    load_0_4_1  segment_prefix_lb_666  1
    load_0_4_1  segment_prefix_ub_667  1
    load_0_4_1  segment_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_412  -20
    arc_0_4_2  connected_order_arc_413  -14
    arc_0_4_2  in_degree_669  1
    arc_0_4_2  out_degree_682  1
    arc_0_4_2  original_T_including_depot_unload_748  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_412  1
    load_0_4_2  segment_load_conservation_672  -1
    load_0_4_2  segment_prefix_lb_673  1
    load_0_4_2  segment_prefix_ub_674  1
    load_0_4_2  segment_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_414  -20
    arc_0_4_3  connected_order_arc_415  -14
    arc_0_4_3  in_degree_676  1
    arc_0_4_3  out_degree_682  1
    arc_0_4_3  original_T_including_depot_unload_748  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_414  1
    load_0_4_3  segment_load_conservation_679  -1
    load_0_4_3  segment_prefix_lb_680  1
    load_0_4_3  segment_prefix_ub_681  1
    load_0_4_3  segment_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_416  -20
    arc_0_4_5  connected_order_arc_417  -14
    arc_0_4_5  out_degree_682  1
    arc_0_4_5  in_degree_690  1
    arc_0_4_5  original_T_including_depot_unload_748  1.0652346416428543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_416  1
    load_0_4_5  segment_load_conservation_686  1
    load_0_4_5  segment_load_conservation_693  -1
    load_0_4_5  segment_prefix_lb_694  1
    load_0_4_5  segment_prefix_ub_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_418  -20
    arc_0_4_13  connected_order_arc_419  -14
    arc_0_4_13  out_degree_682  1
    arc_0_4_13  in_degree_697  1
    arc_0_4_13  original_T_including_depot_unload_748  7.0663858580683063e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_418  1
    load_0_4_13  segment_load_conservation_686  1
    load_0_4_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_420  -20
    arc_0_4_14  connected_order_arc_421  -14
    arc_0_4_14  out_degree_682  1
    arc_0_4_14  in_degree_703  1
    arc_0_4_14  original_T_including_depot_unload_748  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_420  1
    load_0_4_14  segment_load_conservation_686  1
    load_0_4_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_422  -20
    arc_0_4_15  connected_order_arc_423  -14
    arc_0_4_15  out_degree_682  1
    arc_0_4_15  in_degree_709  1
    arc_0_4_15  original_T_including_depot_unload_748  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_422  1
    load_0_4_15  segment_load_conservation_686  1
    load_0_4_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_424  -20
    arc_0_4_16  connected_order_arc_425  -14
    arc_0_4_16  out_degree_682  1
    arc_0_4_16  in_degree_715  1
    arc_0_4_16  original_T_including_depot_unload_748  8.9891387855174980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_424  1
    load_0_4_16  segment_load_conservation_686  1
    load_0_4_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_426  -20
    arc_0_4_17  connected_order_arc_427  -14
    arc_0_4_17  out_degree_682  1
    arc_0_4_17  in_degree_721  1
    arc_0_4_17  original_T_including_depot_unload_748  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_426  1
    load_0_4_17  segment_load_conservation_686  1
    load_0_4_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_428  -20
    arc_0_4_18  connected_order_arc_429  -14
    arc_0_4_18  out_degree_682  1
    arc_0_4_18  in_degree_727  1
    arc_0_4_18  original_T_including_depot_unload_748  9.0041705227827231e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_428  1
    load_0_4_18  segment_load_conservation_686  1
    load_0_4_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_430  -20
    arc_0_4_19  connected_order_arc_431  -14
    arc_0_4_19  out_degree_682  1
    arc_0_4_19  in_degree_733  1
    arc_0_4_19  original_T_including_depot_unload_748  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_430  1
    load_0_4_19  segment_load_conservation_686  1
    load_0_4_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_432  -20
    arc_0_4_20  connected_order_arc_433  -14
    arc_0_4_20  out_degree_682  1
    arc_0_4_20  in_degree_739  1
    arc_0_4_20  original_T_including_depot_unload_748  900.650596089206
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_432  1
    load_0_4_20  segment_load_conservation_686  1
    load_0_4_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_434  -20
    arc_0_5_0  depot_return_or_bypass_660  1
    arc_0_5_0  out_degree_689  1
    arc_0_5_0  original_T_including_depot_unload_748  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_434  1
    load_0_5_0  segment_load_conservation_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_435  -20
    arc_0_5_1  connected_order_arc_436  -14
    arc_0_5_1  in_degree_662  1
    arc_0_5_1  out_degree_689  1
    arc_0_5_1  original_T_including_depot_unload_748  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_435  1
    load_0_5_1  segment_load_conservation_665  -1
    load_0_5_1  segment_prefix_lb_666  1
    load_0_5_1  segment_prefix_ub_667  1
    load_0_5_1  segment_load_conservation_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_437  -20
    arc_0_5_2  connected_order_arc_438  -14
    arc_0_5_2  in_degree_669  1
    arc_0_5_2  out_degree_689  1
    arc_0_5_2  original_T_including_depot_unload_748  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_437  1
    load_0_5_2  segment_load_conservation_672  -1
    load_0_5_2  segment_prefix_lb_673  1
    load_0_5_2  segment_prefix_ub_674  1
    load_0_5_2  segment_load_conservation_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_439  -20
    arc_0_5_3  connected_order_arc_440  -14
    arc_0_5_3  in_degree_676  1
    arc_0_5_3  out_degree_689  1
    arc_0_5_3  original_T_including_depot_unload_748  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_439  1
    load_0_5_3  segment_load_conservation_679  -1
    load_0_5_3  segment_prefix_lb_680  1
    load_0_5_3  segment_prefix_ub_681  1
    load_0_5_3  segment_load_conservation_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_441  -20
    arc_0_5_4  connected_order_arc_442  -14
    arc_0_5_4  in_degree_683  1
    arc_0_5_4  out_degree_689  1
    arc_0_5_4  original_T_including_depot_unload_748  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_441  1
    load_0_5_4  segment_load_conservation_686  -1
    load_0_5_4  segment_prefix_lb_687  1
    load_0_5_4  segment_prefix_ub_688  1
    load_0_5_4  segment_load_conservation_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_443  -20
    arc_0_5_13  connected_order_arc_444  -14
    arc_0_5_13  out_degree_689  1
    arc_0_5_13  in_degree_697  1
    arc_0_5_13  original_T_including_depot_unload_748  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_443  1
    load_0_5_13  segment_load_conservation_693  1
    load_0_5_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_445  -20
    arc_0_5_14  connected_order_arc_446  -14
    arc_0_5_14  out_degree_689  1
    arc_0_5_14  in_degree_703  1
    arc_0_5_14  original_T_including_depot_unload_748  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_445  1
    load_0_5_14  segment_load_conservation_693  1
    load_0_5_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_447  -20
    arc_0_5_15  connected_order_arc_448  -14
    arc_0_5_15  out_degree_689  1
    arc_0_5_15  in_degree_709  1
    arc_0_5_15  original_T_including_depot_unload_748  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_447  1
    load_0_5_15  segment_load_conservation_693  1
    load_0_5_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_449  -20
    arc_0_5_16  connected_order_arc_450  -14
    arc_0_5_16  out_degree_689  1
    arc_0_5_16  in_degree_715  1
    arc_0_5_16  original_T_including_depot_unload_748  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_449  1
    load_0_5_16  segment_load_conservation_693  1
    load_0_5_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_451  -20
    arc_0_5_17  connected_order_arc_452  -14
    arc_0_5_17  out_degree_689  1
    arc_0_5_17  in_degree_721  1
    arc_0_5_17  original_T_including_depot_unload_748  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_451  1
    load_0_5_17  segment_load_conservation_693  1
    load_0_5_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_453  -20
    arc_0_5_18  connected_order_arc_454  -14
    arc_0_5_18  out_degree_689  1
    arc_0_5_18  in_degree_727  1
    arc_0_5_18  original_T_including_depot_unload_748  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_453  1
    load_0_5_18  segment_load_conservation_693  1
    load_0_5_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_455  -20
    arc_0_5_19  connected_order_arc_456  -14
    arc_0_5_19  out_degree_689  1
    arc_0_5_19  in_degree_733  1
    arc_0_5_19  original_T_including_depot_unload_748  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_455  1
    load_0_5_19  segment_load_conservation_693  1
    load_0_5_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_457  -20
    arc_0_5_20  connected_order_arc_458  -14
    arc_0_5_20  out_degree_689  1
    arc_0_5_20  in_degree_739  1
    arc_0_5_20  original_T_including_depot_unload_748  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_457  1
    load_0_5_20  segment_load_conservation_693  1
    load_0_5_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_459  -20
    arc_0_13_0  depot_return_or_bypass_660  1
    arc_0_13_0  out_degree_696  1
    arc_0_13_0  original_T_including_depot_unload_748  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_459  1
    load_0_13_0  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_460  -20
    arc_0_13_1  connected_order_arc_461  -14
    arc_0_13_1  in_degree_662  1
    arc_0_13_1  out_degree_696  1
    arc_0_13_1  original_T_including_depot_unload_748  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_460  1
    load_0_13_1  segment_load_conservation_665  -1
    load_0_13_1  segment_prefix_lb_666  1
    load_0_13_1  segment_prefix_ub_667  1
    load_0_13_1  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_462  -20
    arc_0_13_2  connected_order_arc_463  -14
    arc_0_13_2  in_degree_669  1
    arc_0_13_2  out_degree_696  1
    arc_0_13_2  original_T_including_depot_unload_748  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_462  1
    load_0_13_2  segment_load_conservation_672  -1
    load_0_13_2  segment_prefix_lb_673  1
    load_0_13_2  segment_prefix_ub_674  1
    load_0_13_2  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_464  -20
    arc_0_13_3  connected_order_arc_465  -14
    arc_0_13_3  in_degree_676  1
    arc_0_13_3  out_degree_696  1
    arc_0_13_3  original_T_including_depot_unload_748  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_464  1
    load_0_13_3  segment_load_conservation_679  -1
    load_0_13_3  segment_prefix_lb_680  1
    load_0_13_3  segment_prefix_ub_681  1
    load_0_13_3  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_466  -20
    arc_0_13_4  connected_order_arc_467  -14
    arc_0_13_4  in_degree_683  1
    arc_0_13_4  out_degree_696  1
    arc_0_13_4  original_T_including_depot_unload_748  4.3907641772187384e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_466  1
    load_0_13_4  segment_load_conservation_686  -1
    load_0_13_4  segment_prefix_lb_687  1
    load_0_13_4  segment_prefix_ub_688  1
    load_0_13_4  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_468  -20
    arc_0_13_5  connected_order_arc_469  -14
    arc_0_13_5  in_degree_690  1
    arc_0_13_5  out_degree_696  1
    arc_0_13_5  original_T_including_depot_unload_748  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_468  1
    load_0_13_5  segment_load_conservation_693  -1
    load_0_13_5  segment_prefix_lb_694  1
    load_0_13_5  segment_prefix_ub_695  1
    load_0_13_5  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_470  -20
    arc_0_13_14  connected_order_arc_471  -14
    arc_0_13_14  out_degree_696  1
    arc_0_13_14  in_degree_703  1
    arc_0_13_14  original_T_including_depot_unload_748  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_470  1
    load_0_13_14  free_load_conservation_701  1
    load_0_13_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_472  -20
    arc_0_13_15  connected_order_arc_473  -14
    arc_0_13_15  out_degree_696  1
    arc_0_13_15  in_degree_709  1
    arc_0_13_15  original_T_including_depot_unload_748  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_472  1
    load_0_13_15  free_load_conservation_701  1
    load_0_13_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_474  -20
    arc_0_13_16  connected_order_arc_475  -14
    arc_0_13_16  out_degree_696  1
    arc_0_13_16  in_degree_715  1
    arc_0_13_16  original_T_including_depot_unload_748  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_474  1
    load_0_13_16  free_load_conservation_701  1
    load_0_13_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_476  -20
    arc_0_13_17  connected_order_arc_477  -14
    arc_0_13_17  out_degree_696  1
    arc_0_13_17  in_degree_721  1
    arc_0_13_17  original_T_including_depot_unload_748  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_476  1
    load_0_13_17  free_load_conservation_701  1
    load_0_13_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_478  -20
    arc_0_13_18  connected_order_arc_479  -14
    arc_0_13_18  out_degree_696  1
    arc_0_13_18  in_degree_727  1
    arc_0_13_18  original_T_including_depot_unload_748  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_478  1
    load_0_13_18  free_load_conservation_701  1
    load_0_13_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_480  -20
    arc_0_13_19  connected_order_arc_481  -14
    arc_0_13_19  out_degree_696  1
    arc_0_13_19  in_degree_733  1
    arc_0_13_19  original_T_including_depot_unload_748  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_480  1
    load_0_13_19  free_load_conservation_701  1
    load_0_13_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_482  -20
    arc_0_13_20  connected_order_arc_483  -14
    arc_0_13_20  out_degree_696  1
    arc_0_13_20  in_degree_739  1
    arc_0_13_20  original_T_including_depot_unload_748  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_482  1
    load_0_13_20  free_load_conservation_701  1
    load_0_13_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_484  -20
    arc_0_14_0  depot_return_or_bypass_660  1
    arc_0_14_0  out_degree_702  1
    arc_0_14_0  original_T_including_depot_unload_748  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_484  1
    load_0_14_0  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_485  -20
    arc_0_14_1  connected_order_arc_486  -14
    arc_0_14_1  in_degree_662  1
    arc_0_14_1  out_degree_702  1
    arc_0_14_1  original_T_including_depot_unload_748  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_485  1
    load_0_14_1  segment_load_conservation_665  -1
    load_0_14_1  segment_prefix_lb_666  1
    load_0_14_1  segment_prefix_ub_667  1
    load_0_14_1  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_487  -20
    arc_0_14_2  connected_order_arc_488  -14
    arc_0_14_2  in_degree_669  1
    arc_0_14_2  out_degree_702  1
    arc_0_14_2  original_T_including_depot_unload_748  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_487  1
    load_0_14_2  segment_load_conservation_672  -1
    load_0_14_2  segment_prefix_lb_673  1
    load_0_14_2  segment_prefix_ub_674  1
    load_0_14_2  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_489  -20
    arc_0_14_3  connected_order_arc_490  -14
    arc_0_14_3  in_degree_676  1
    arc_0_14_3  out_degree_702  1
    arc_0_14_3  original_T_including_depot_unload_748  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_489  1
    load_0_14_3  segment_load_conservation_679  -1
    load_0_14_3  segment_prefix_lb_680  1
    load_0_14_3  segment_prefix_ub_681  1
    load_0_14_3  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_491  -20
    arc_0_14_4  connected_order_arc_492  -14
    arc_0_14_4  in_degree_683  1
    arc_0_14_4  out_degree_702  1
    arc_0_14_4  original_T_including_depot_unload_748  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_491  1
    load_0_14_4  segment_load_conservation_686  -1
    load_0_14_4  segment_prefix_lb_687  1
    load_0_14_4  segment_prefix_ub_688  1
    load_0_14_4  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_493  -20
    arc_0_14_5  connected_order_arc_494  -14
    arc_0_14_5  in_degree_690  1
    arc_0_14_5  out_degree_702  1
    arc_0_14_5  original_T_including_depot_unload_748  5.4660309215526388e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_493  1
    load_0_14_5  segment_load_conservation_693  -1
    load_0_14_5  segment_prefix_lb_694  1
    load_0_14_5  segment_prefix_ub_695  1
    load_0_14_5  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_495  -20
    arc_0_14_13  connected_order_arc_496  -14
    arc_0_14_13  in_degree_697  1
    arc_0_14_13  out_degree_702  1
    arc_0_14_13  original_T_including_depot_unload_748  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_495  1
    load_0_14_13  free_load_conservation_701  -1
    load_0_14_13  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_497  -20
    arc_0_14_15  connected_order_arc_498  -14
    arc_0_14_15  out_degree_702  1
    arc_0_14_15  in_degree_709  1
    arc_0_14_15  original_T_including_depot_unload_748  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_497  1
    load_0_14_15  free_load_conservation_707  1
    load_0_14_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_499  -20
    arc_0_14_16  connected_order_arc_500  -14
    arc_0_14_16  out_degree_702  1
    arc_0_14_16  in_degree_715  1
    arc_0_14_16  original_T_including_depot_unload_748  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_499  1
    load_0_14_16  free_load_conservation_707  1
    load_0_14_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_501  -20
    arc_0_14_17  connected_order_arc_502  -14
    arc_0_14_17  out_degree_702  1
    arc_0_14_17  in_degree_721  1
    arc_0_14_17  original_T_including_depot_unload_748  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_501  1
    load_0_14_17  free_load_conservation_707  1
    load_0_14_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_503  -20
    arc_0_14_18  connected_order_arc_504  -14
    arc_0_14_18  out_degree_702  1
    arc_0_14_18  in_degree_727  1
    arc_0_14_18  original_T_including_depot_unload_748  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_503  1
    load_0_14_18  free_load_conservation_707  1
    load_0_14_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_505  -20
    arc_0_14_19  connected_order_arc_506  -14
    arc_0_14_19  out_degree_702  1
    arc_0_14_19  in_degree_733  1
    arc_0_14_19  original_T_including_depot_unload_748  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_505  1
    load_0_14_19  free_load_conservation_707  1
    load_0_14_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_507  -20
    arc_0_14_20  connected_order_arc_508  -14
    arc_0_14_20  out_degree_702  1
    arc_0_14_20  in_degree_739  1
    arc_0_14_20  original_T_including_depot_unload_748  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_507  1
    load_0_14_20  free_load_conservation_707  1
    load_0_14_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_509  -20
    arc_0_15_0  depot_return_or_bypass_660  1
    arc_0_15_0  out_degree_708  1
    arc_0_15_0  original_T_including_depot_unload_748  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_509  1
    load_0_15_0  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_510  -20
    arc_0_15_1  connected_order_arc_511  -14
    arc_0_15_1  in_degree_662  1
    arc_0_15_1  out_degree_708  1
    arc_0_15_1  original_T_including_depot_unload_748  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_510  1
    load_0_15_1  segment_load_conservation_665  -1
    load_0_15_1  segment_prefix_lb_666  1
    load_0_15_1  segment_prefix_ub_667  1
    load_0_15_1  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_512  -20
    arc_0_15_2  connected_order_arc_513  -14
    arc_0_15_2  in_degree_669  1
    arc_0_15_2  out_degree_708  1
    arc_0_15_2  original_T_including_depot_unload_748  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_512  1
    load_0_15_2  segment_load_conservation_672  -1
    load_0_15_2  segment_prefix_lb_673  1
    load_0_15_2  segment_prefix_ub_674  1
    load_0_15_2  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_514  -20
    arc_0_15_3  connected_order_arc_515  -14
    arc_0_15_3  in_degree_676  1
    arc_0_15_3  out_degree_708  1
    arc_0_15_3  original_T_including_depot_unload_748  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_514  1
    load_0_15_3  segment_load_conservation_679  -1
    load_0_15_3  segment_prefix_lb_680  1
    load_0_15_3  segment_prefix_ub_681  1
    load_0_15_3  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_516  -20
    arc_0_15_4  connected_order_arc_517  -14
    arc_0_15_4  in_degree_683  1
    arc_0_15_4  out_degree_708  1
    arc_0_15_4  original_T_including_depot_unload_748  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_516  1
    load_0_15_4  segment_load_conservation_686  -1
    load_0_15_4  segment_prefix_lb_687  1
    load_0_15_4  segment_prefix_ub_688  1
    load_0_15_4  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_518  -20
    arc_0_15_5  connected_order_arc_519  -14
    arc_0_15_5  in_degree_690  1
    arc_0_15_5  out_degree_708  1
    arc_0_15_5  original_T_including_depot_unload_748  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_518  1
    load_0_15_5  segment_load_conservation_693  -1
    load_0_15_5  segment_prefix_lb_694  1
    load_0_15_5  segment_prefix_ub_695  1
    load_0_15_5  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_520  -20
    arc_0_15_13  connected_order_arc_521  -14
    arc_0_15_13  in_degree_697  1
    arc_0_15_13  out_degree_708  1
    arc_0_15_13  original_T_including_depot_unload_748  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_520  1
    load_0_15_13  free_load_conservation_701  -1
    load_0_15_13  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_522  -20
    arc_0_15_14  connected_order_arc_523  -14
    arc_0_15_14  in_degree_703  1
    arc_0_15_14  out_degree_708  1
    arc_0_15_14  original_T_including_depot_unload_748  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_522  1
    load_0_15_14  free_load_conservation_707  -1
    load_0_15_14  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_524  -20
    arc_0_15_16  connected_order_arc_525  -14
    arc_0_15_16  out_degree_708  1
    arc_0_15_16  in_degree_715  1
    arc_0_15_16  original_T_including_depot_unload_748  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_524  1
    load_0_15_16  free_load_conservation_713  1
    load_0_15_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_526  -20
    arc_0_15_17  connected_order_arc_527  -14
    arc_0_15_17  out_degree_708  1
    arc_0_15_17  in_degree_721  1
    arc_0_15_17  original_T_including_depot_unload_748  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_526  1
    load_0_15_17  free_load_conservation_713  1
    load_0_15_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_528  -20
    arc_0_15_18  connected_order_arc_529  -14
    arc_0_15_18  out_degree_708  1
    arc_0_15_18  in_degree_727  1
    arc_0_15_18  original_T_including_depot_unload_748  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_528  1
    load_0_15_18  free_load_conservation_713  1
    load_0_15_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_530  -20
    arc_0_15_19  connected_order_arc_531  -14
    arc_0_15_19  out_degree_708  1
    arc_0_15_19  in_degree_733  1
    arc_0_15_19  original_T_including_depot_unload_748  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_530  1
    load_0_15_19  free_load_conservation_713  1
    load_0_15_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_532  -20
    arc_0_15_20  connected_order_arc_533  -14
    arc_0_15_20  out_degree_708  1
    arc_0_15_20  in_degree_739  1
    arc_0_15_20  original_T_including_depot_unload_748  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_532  1
    load_0_15_20  free_load_conservation_713  1
    load_0_15_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_534  -20
    arc_0_16_0  depot_return_or_bypass_660  1
    arc_0_16_0  out_degree_714  1
    arc_0_16_0  original_T_including_depot_unload_748  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_534  1
    load_0_16_0  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_535  -20
    arc_0_16_1  connected_order_arc_536  -14
    arc_0_16_1  in_degree_662  1
    arc_0_16_1  out_degree_714  1
    arc_0_16_1  original_T_including_depot_unload_748  4.8384395388802926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_535  1
    load_0_16_1  segment_load_conservation_665  -1
    load_0_16_1  segment_prefix_lb_666  1
    load_0_16_1  segment_prefix_ub_667  1
    load_0_16_1  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_537  -20
    arc_0_16_2  connected_order_arc_538  -14
    arc_0_16_2  in_degree_669  1
    arc_0_16_2  out_degree_714  1
    arc_0_16_2  original_T_including_depot_unload_748  4.9345054001313224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_537  1
    load_0_16_2  segment_load_conservation_672  -1
    load_0_16_2  segment_prefix_lb_673  1
    load_0_16_2  segment_prefix_ub_674  1
    load_0_16_2  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_539  -20
    arc_0_16_3  connected_order_arc_540  -14
    arc_0_16_3  in_degree_676  1
    arc_0_16_3  out_degree_714  1
    arc_0_16_3  original_T_including_depot_unload_748  4.9283602644772810e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_539  1
    load_0_16_3  segment_load_conservation_679  -1
    load_0_16_3  segment_prefix_lb_680  1
    load_0_16_3  segment_prefix_ub_681  1
    load_0_16_3  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_541  -20
    arc_0_16_4  connected_order_arc_542  -14
    arc_0_16_4  in_degree_683  1
    arc_0_16_4  out_degree_714  1
    arc_0_16_4  original_T_including_depot_unload_748  6.3283307285749891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_541  1
    load_0_16_4  segment_load_conservation_686  -1
    load_0_16_4  segment_prefix_lb_687  1
    load_0_16_4  segment_prefix_ub_688  1
    load_0_16_4  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_543  -20
    arc_0_16_5  connected_order_arc_544  -14
    arc_0_16_5  in_degree_690  1
    arc_0_16_5  out_degree_714  1
    arc_0_16_5  original_T_including_depot_unload_748  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_543  1
    load_0_16_5  segment_load_conservation_693  -1
    load_0_16_5  segment_prefix_lb_694  1
    load_0_16_5  segment_prefix_ub_695  1
    load_0_16_5  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_545  -20
    arc_0_16_13  connected_order_arc_546  -14
    arc_0_16_13  in_degree_697  1
    arc_0_16_13  out_degree_714  1
    arc_0_16_13  original_T_including_depot_unload_748  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_545  1
    load_0_16_13  free_load_conservation_701  -1
    load_0_16_13  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_547  -20
    arc_0_16_14  connected_order_arc_548  -14
    arc_0_16_14  in_degree_703  1
    arc_0_16_14  out_degree_714  1
    arc_0_16_14  original_T_including_depot_unload_748  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_547  1
    load_0_16_14  free_load_conservation_707  -1
    load_0_16_14  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_549  -20
    arc_0_16_15  connected_order_arc_550  -14
    arc_0_16_15  in_degree_709  1
    arc_0_16_15  out_degree_714  1
    arc_0_16_15  original_T_including_depot_unload_748  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_549  1
    load_0_16_15  free_load_conservation_713  -1
    load_0_16_15  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_551  -20
    arc_0_16_17  connected_order_arc_552  -14
    arc_0_16_17  out_degree_714  1
    arc_0_16_17  in_degree_721  1
    arc_0_16_17  original_T_including_depot_unload_748  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_551  1
    load_0_16_17  free_load_conservation_719  1
    load_0_16_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_553  -20
    arc_0_16_18  connected_order_arc_554  -14
    arc_0_16_18  out_degree_714  1
    arc_0_16_18  in_degree_727  1
    arc_0_16_18  original_T_including_depot_unload_748  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_553  1
    load_0_16_18  free_load_conservation_719  1
    load_0_16_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_555  -20
    arc_0_16_19  connected_order_arc_556  -14
    arc_0_16_19  out_degree_714  1
    arc_0_16_19  in_degree_733  1
    arc_0_16_19  original_T_including_depot_unload_748  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_555  1
    load_0_16_19  free_load_conservation_719  1
    load_0_16_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_557  -20
    arc_0_16_20  connected_order_arc_558  -14
    arc_0_16_20  out_degree_714  1
    arc_0_16_20  in_degree_739  1
    arc_0_16_20  original_T_including_depot_unload_748  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_557  1
    load_0_16_20  free_load_conservation_719  1
    load_0_16_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_559  -20
    arc_0_17_0  depot_return_or_bypass_660  1
    arc_0_17_0  out_degree_720  1
    arc_0_17_0  original_T_including_depot_unload_748  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_559  1
    load_0_17_0  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_560  -20
    arc_0_17_1  connected_order_arc_561  -14
    arc_0_17_1  in_degree_662  1
    arc_0_17_1  out_degree_720  1
    arc_0_17_1  original_T_including_depot_unload_748  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_560  1
    load_0_17_1  segment_load_conservation_665  -1
    load_0_17_1  segment_prefix_lb_666  1
    load_0_17_1  segment_prefix_ub_667  1
    load_0_17_1  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_562  -20
    arc_0_17_2  connected_order_arc_563  -14
    arc_0_17_2  in_degree_669  1
    arc_0_17_2  out_degree_720  1
    arc_0_17_2  original_T_including_depot_unload_748  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_562  1
    load_0_17_2  segment_load_conservation_672  -1
    load_0_17_2  segment_prefix_lb_673  1
    load_0_17_2  segment_prefix_ub_674  1
    load_0_17_2  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_564  -20
    arc_0_17_3  connected_order_arc_565  -14
    arc_0_17_3  in_degree_676  1
    arc_0_17_3  out_degree_720  1
    arc_0_17_3  original_T_including_depot_unload_748  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_564  1
    load_0_17_3  segment_load_conservation_679  -1
    load_0_17_3  segment_prefix_lb_680  1
    load_0_17_3  segment_prefix_ub_681  1
    load_0_17_3  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_566  -20
    arc_0_17_4  connected_order_arc_567  -14
    arc_0_17_4  in_degree_683  1
    arc_0_17_4  out_degree_720  1
    arc_0_17_4  original_T_including_depot_unload_748  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_566  1
    load_0_17_4  segment_load_conservation_686  -1
    load_0_17_4  segment_prefix_lb_687  1
    load_0_17_4  segment_prefix_ub_688  1
    load_0_17_4  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_568  -20
    arc_0_17_5  connected_order_arc_569  -14
    arc_0_17_5  in_degree_690  1
    arc_0_17_5  out_degree_720  1
    arc_0_17_5  original_T_including_depot_unload_748  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_568  1
    load_0_17_5  segment_load_conservation_693  -1
    load_0_17_5  segment_prefix_lb_694  1
    load_0_17_5  segment_prefix_ub_695  1
    load_0_17_5  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_570  -20
    arc_0_17_13  connected_order_arc_571  -14
    arc_0_17_13  in_degree_697  1
    arc_0_17_13  out_degree_720  1
    arc_0_17_13  original_T_including_depot_unload_748  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_570  1
    load_0_17_13  free_load_conservation_701  -1
    load_0_17_13  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_572  -20
    arc_0_17_14  connected_order_arc_573  -14
    arc_0_17_14  in_degree_703  1
    arc_0_17_14  out_degree_720  1
    arc_0_17_14  original_T_including_depot_unload_748  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_572  1
    load_0_17_14  free_load_conservation_707  -1
    load_0_17_14  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_574  -20
    arc_0_17_15  connected_order_arc_575  -14
    arc_0_17_15  in_degree_709  1
    arc_0_17_15  out_degree_720  1
    arc_0_17_15  original_T_including_depot_unload_748  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_574  1
    load_0_17_15  free_load_conservation_713  -1
    load_0_17_15  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_576  -20
    arc_0_17_16  connected_order_arc_577  -14
    arc_0_17_16  in_degree_715  1
    arc_0_17_16  out_degree_720  1
    arc_0_17_16  original_T_including_depot_unload_748  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_576  1
    load_0_17_16  free_load_conservation_719  -1
    load_0_17_16  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_578  -20
    arc_0_17_18  connected_order_arc_579  -14
    arc_0_17_18  out_degree_720  1
    arc_0_17_18  in_degree_727  1
    arc_0_17_18  original_T_including_depot_unload_748  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_578  1
    load_0_17_18  free_load_conservation_725  1
    load_0_17_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_580  -20
    arc_0_17_19  connected_order_arc_581  -14
    arc_0_17_19  out_degree_720  1
    arc_0_17_19  in_degree_733  1
    arc_0_17_19  original_T_including_depot_unload_748  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_580  1
    load_0_17_19  free_load_conservation_725  1
    load_0_17_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_582  -20
    arc_0_17_20  connected_order_arc_583  -14
    arc_0_17_20  out_degree_720  1
    arc_0_17_20  in_degree_739  1
    arc_0_17_20  original_T_including_depot_unload_748  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_582  1
    load_0_17_20  free_load_conservation_725  1
    load_0_17_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_584  -20
    arc_0_18_0  depot_return_or_bypass_660  1
    arc_0_18_0  out_degree_726  1
    arc_0_18_0  original_T_including_depot_unload_748  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_584  1
    load_0_18_0  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_585  -20
    arc_0_18_1  connected_order_arc_586  -14
    arc_0_18_1  in_degree_662  1
    arc_0_18_1  out_degree_726  1
    arc_0_18_1  original_T_including_depot_unload_748  4.8549019843957007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_585  1
    load_0_18_1  segment_load_conservation_665  -1
    load_0_18_1  segment_prefix_lb_666  1
    load_0_18_1  segment_prefix_ub_667  1
    load_0_18_1  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_587  -20
    arc_0_18_2  connected_order_arc_588  -14
    arc_0_18_2  in_degree_669  1
    arc_0_18_2  out_degree_726  1
    arc_0_18_2  original_T_including_depot_unload_748  4.9507442307813227e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_587  1
    load_0_18_2  segment_load_conservation_672  -1
    load_0_18_2  segment_prefix_lb_673  1
    load_0_18_2  segment_prefix_ub_674  1
    load_0_18_2  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_589  -20
    arc_0_18_3  connected_order_arc_590  -14
    arc_0_18_3  in_degree_676  1
    arc_0_18_3  out_degree_726  1
    arc_0_18_3  original_T_including_depot_unload_748  4.9445985110995662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_589  1
    load_0_18_3  segment_load_conservation_679  -1
    load_0_18_3  segment_prefix_lb_680  1
    load_0_18_3  segment_prefix_ub_681  1
    load_0_18_3  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_591  -20
    arc_0_18_4  connected_order_arc_592  -14
    arc_0_18_4  in_degree_683  1
    arc_0_18_4  out_degree_726  1
    arc_0_18_4  original_T_including_depot_unload_748  6.3449041775530861e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_591  1
    load_0_18_4  segment_load_conservation_686  -1
    load_0_18_4  segment_prefix_lb_687  1
    load_0_18_4  segment_prefix_ub_688  1
    load_0_18_4  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_593  -20
    arc_0_18_5  connected_order_arc_594  -14
    arc_0_18_5  in_degree_690  1
    arc_0_18_5  out_degree_726  1
    arc_0_18_5  original_T_including_depot_unload_748  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_593  1
    load_0_18_5  segment_load_conservation_693  -1
    load_0_18_5  segment_prefix_lb_694  1
    load_0_18_5  segment_prefix_ub_695  1
    load_0_18_5  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_595  -20
    arc_0_18_13  connected_order_arc_596  -14
    arc_0_18_13  in_degree_697  1
    arc_0_18_13  out_degree_726  1
    arc_0_18_13  original_T_including_depot_unload_748  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_595  1
    load_0_18_13  free_load_conservation_701  -1
    load_0_18_13  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_597  -20
    arc_0_18_14  connected_order_arc_598  -14
    arc_0_18_14  in_degree_703  1
    arc_0_18_14  out_degree_726  1
    arc_0_18_14  original_T_including_depot_unload_748  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_597  1
    load_0_18_14  free_load_conservation_707  -1
    load_0_18_14  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_599  -20
    arc_0_18_15  connected_order_arc_600  -14
    arc_0_18_15  in_degree_709  1
    arc_0_18_15  out_degree_726  1
    arc_0_18_15  original_T_including_depot_unload_748  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_599  1
    load_0_18_15  free_load_conservation_713  -1
    load_0_18_15  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_601  -20
    arc_0_18_16  connected_order_arc_602  -14
    arc_0_18_16  in_degree_715  1
    arc_0_18_16  out_degree_726  1
    arc_0_18_16  original_T_including_depot_unload_748  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_601  1
    load_0_18_16  free_load_conservation_719  -1
    load_0_18_16  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_603  -20
    arc_0_18_17  connected_order_arc_604  -14
    arc_0_18_17  in_degree_721  1
    arc_0_18_17  out_degree_726  1
    arc_0_18_17  original_T_including_depot_unload_748  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_603  1
    load_0_18_17  free_load_conservation_725  -1
    load_0_18_17  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_605  -20
    arc_0_18_19  connected_order_arc_606  -14
    arc_0_18_19  out_degree_726  1
    arc_0_18_19  in_degree_733  1
    arc_0_18_19  original_T_including_depot_unload_748  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_605  1
    load_0_18_19  free_load_conservation_731  1
    load_0_18_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_607  -20
    arc_0_18_20  connected_order_arc_608  -14
    arc_0_18_20  out_degree_726  1
    arc_0_18_20  in_degree_739  1
    arc_0_18_20  original_T_including_depot_unload_748  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_607  1
    load_0_18_20  free_load_conservation_731  1
    load_0_18_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_609  -20
    arc_0_19_0  depot_return_or_bypass_660  1
    arc_0_19_0  out_degree_732  1
    arc_0_19_0  original_T_including_depot_unload_748  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_609  1
    load_0_19_0  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_610  -20
    arc_0_19_1  connected_order_arc_611  -14
    arc_0_19_1  in_degree_662  1
    arc_0_19_1  out_degree_732  1
    arc_0_19_1  original_T_including_depot_unload_748  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_610  1
    load_0_19_1  segment_load_conservation_665  -1
    load_0_19_1  segment_prefix_lb_666  1
    load_0_19_1  segment_prefix_ub_667  1
    load_0_19_1  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_612  -20
    arc_0_19_2  connected_order_arc_613  -14
    arc_0_19_2  in_degree_669  1
    arc_0_19_2  out_degree_732  1
    arc_0_19_2  original_T_including_depot_unload_748  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_612  1
    load_0_19_2  segment_load_conservation_672  -1
    load_0_19_2  segment_prefix_lb_673  1
    load_0_19_2  segment_prefix_ub_674  1
    load_0_19_2  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_614  -20
    arc_0_19_3  connected_order_arc_615  -14
    arc_0_19_3  in_degree_676  1
    arc_0_19_3  out_degree_732  1
    arc_0_19_3  original_T_including_depot_unload_748  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_614  1
    load_0_19_3  segment_load_conservation_679  -1
    load_0_19_3  segment_prefix_lb_680  1
    load_0_19_3  segment_prefix_ub_681  1
    load_0_19_3  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_616  -20
    arc_0_19_4  connected_order_arc_617  -14
    arc_0_19_4  in_degree_683  1
    arc_0_19_4  out_degree_732  1
    arc_0_19_4  original_T_including_depot_unload_748  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_616  1
    load_0_19_4  segment_load_conservation_686  -1
    load_0_19_4  segment_prefix_lb_687  1
    load_0_19_4  segment_prefix_ub_688  1
    load_0_19_4  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_618  -20
    arc_0_19_5  connected_order_arc_619  -14
    arc_0_19_5  in_degree_690  1
    arc_0_19_5  out_degree_732  1
    arc_0_19_5  original_T_including_depot_unload_748  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_618  1
    load_0_19_5  segment_load_conservation_693  -1
    load_0_19_5  segment_prefix_lb_694  1
    load_0_19_5  segment_prefix_ub_695  1
    load_0_19_5  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_620  -20
    arc_0_19_13  connected_order_arc_621  -14
    arc_0_19_13  in_degree_697  1
    arc_0_19_13  out_degree_732  1
    arc_0_19_13  original_T_including_depot_unload_748  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_620  1
    load_0_19_13  free_load_conservation_701  -1
    load_0_19_13  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_622  -20
    arc_0_19_14  connected_order_arc_623  -14
    arc_0_19_14  in_degree_703  1
    arc_0_19_14  out_degree_732  1
    arc_0_19_14  original_T_including_depot_unload_748  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_622  1
    load_0_19_14  free_load_conservation_707  -1
    load_0_19_14  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_624  -20
    arc_0_19_15  connected_order_arc_625  -14
    arc_0_19_15  in_degree_709  1
    arc_0_19_15  out_degree_732  1
    arc_0_19_15  original_T_including_depot_unload_748  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_624  1
    load_0_19_15  free_load_conservation_713  -1
    load_0_19_15  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_626  -20
    arc_0_19_16  connected_order_arc_627  -14
    arc_0_19_16  in_degree_715  1
    arc_0_19_16  out_degree_732  1
    arc_0_19_16  original_T_including_depot_unload_748  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_626  1
    load_0_19_16  free_load_conservation_719  -1
    load_0_19_16  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_628  -20
    arc_0_19_17  connected_order_arc_629  -14
    arc_0_19_17  in_degree_721  1
    arc_0_19_17  out_degree_732  1
    arc_0_19_17  original_T_including_depot_unload_748  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_628  1
    load_0_19_17  free_load_conservation_725  -1
    load_0_19_17  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_630  -20
    arc_0_19_18  connected_order_arc_631  -14
    arc_0_19_18  in_degree_727  1
    arc_0_19_18  out_degree_732  1
    arc_0_19_18  original_T_including_depot_unload_748  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_630  1
    load_0_19_18  free_load_conservation_731  -1
    load_0_19_18  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_632  -20
    arc_0_19_20  connected_order_arc_633  -14
    arc_0_19_20  out_degree_732  1
    arc_0_19_20  in_degree_739  1
    arc_0_19_20  original_T_including_depot_unload_748  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_632  1
    load_0_19_20  free_load_conservation_737  1
    load_0_19_20  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_634  -20
    arc_0_20_0  depot_return_or_bypass_660  1
    arc_0_20_0  out_degree_738  1
    arc_0_20_0  original_T_including_depot_unload_748  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_634  1
    load_0_20_0  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_635  -20
    arc_0_20_1  connected_order_arc_636  -14
    arc_0_20_1  in_degree_662  1
    arc_0_20_1  out_degree_738  1
    arc_0_20_1  original_T_including_depot_unload_748  4.8605919276499873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_635  1
    load_0_20_1  segment_load_conservation_665  -1
    load_0_20_1  segment_prefix_lb_666  1
    load_0_20_1  segment_prefix_ub_667  1
    load_0_20_1  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_637  -20
    arc_0_20_2  connected_order_arc_638  -14
    arc_0_20_2  in_degree_669  1
    arc_0_20_2  out_degree_738  1
    arc_0_20_2  original_T_including_depot_unload_748  4.9556592834383019e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_637  1
    load_0_20_2  segment_load_conservation_672  -1
    load_0_20_2  segment_prefix_lb_673  1
    load_0_20_2  segment_prefix_ub_674  1
    load_0_20_2  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_639  -20
    arc_0_20_3  connected_order_arc_640  -14
    arc_0_20_3  in_degree_676  1
    arc_0_20_3  out_degree_738  1
    arc_0_20_3  original_T_including_depot_unload_748  4.9495118393852869e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_639  1
    load_0_20_3  segment_load_conservation_679  -1
    load_0_20_3  segment_prefix_lb_680  1
    load_0_20_3  segment_prefix_ub_681  1
    load_0_20_3  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_641  -20
    arc_0_20_4  connected_order_arc_642  -14
    arc_0_20_4  in_degree_683  1
    arc_0_20_4  out_degree_738  1
    arc_0_20_4  original_T_including_depot_unload_748  6.3511284389813568e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_641  1
    load_0_20_4  segment_load_conservation_686  -1
    load_0_20_4  segment_prefix_lb_687  1
    load_0_20_4  segment_prefix_ub_688  1
    load_0_20_4  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_643  -20
    arc_0_20_5  connected_order_arc_644  -14
    arc_0_20_5  in_degree_690  1
    arc_0_20_5  out_degree_738  1
    arc_0_20_5  original_T_including_depot_unload_748  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_643  1
    load_0_20_5  segment_load_conservation_693  -1
    load_0_20_5  segment_prefix_lb_694  1
    load_0_20_5  segment_prefix_ub_695  1
    load_0_20_5  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_645  -20
    arc_0_20_13  connected_order_arc_646  -14
    arc_0_20_13  in_degree_697  1
    arc_0_20_13  out_degree_738  1
    arc_0_20_13  original_T_including_depot_unload_748  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_645  1
    load_0_20_13  free_load_conservation_701  -1
    load_0_20_13  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_647  -20
    arc_0_20_14  connected_order_arc_648  -14
    arc_0_20_14  in_degree_703  1
    arc_0_20_14  out_degree_738  1
    arc_0_20_14  original_T_including_depot_unload_748  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_647  1
    load_0_20_14  free_load_conservation_707  -1
    load_0_20_14  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_649  -20
    arc_0_20_15  connected_order_arc_650  -14
    arc_0_20_15  in_degree_709  1
    arc_0_20_15  out_degree_738  1
    arc_0_20_15  original_T_including_depot_unload_748  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_649  1
    load_0_20_15  free_load_conservation_713  -1
    load_0_20_15  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_651  -20
    arc_0_20_16  connected_order_arc_652  -14
    arc_0_20_16  in_degree_715  1
    arc_0_20_16  out_degree_738  1
    arc_0_20_16  original_T_including_depot_unload_748  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_651  1
    load_0_20_16  free_load_conservation_719  -1
    load_0_20_16  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_653  -20
    arc_0_20_17  connected_order_arc_654  -14
    arc_0_20_17  in_degree_721  1
    arc_0_20_17  out_degree_738  1
    arc_0_20_17  original_T_including_depot_unload_748  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_653  1
    load_0_20_17  free_load_conservation_725  -1
    load_0_20_17  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_655  -20
    arc_0_20_18  connected_order_arc_656  -14
    arc_0_20_18  in_degree_727  1
    arc_0_20_18  out_degree_738  1
    arc_0_20_18  original_T_including_depot_unload_748  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_655  1
    load_0_20_18  free_load_conservation_731  -1
    load_0_20_18  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_657  -20
    arc_0_20_19  connected_order_arc_658  -14
    arc_0_20_19  in_degree_733  1
    arc_0_20_19  out_degree_738  1
    arc_0_20_19  original_T_including_depot_unload_748  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_657  1
    load_0_20_19  free_load_conservation_737  -1
    load_0_20_19  free_load_conservation_743  1
    visit_1_6  out_degree_1040  -1
    visit_1_6  in_degree_1041  -1
    visit_1_6  order_active_lb_1042  -1
    visit_1_6  order_active_ub_1043  -12
    order_1_6  connected_order_arc_764  -1
    order_1_6  connected_order_arc_766  -1
    order_1_6  connected_order_arc_768  -1
    order_1_6  connected_order_arc_770  -1
    order_1_6  connected_order_arc_772  -1
    order_1_6  connected_order_arc_774  -1
    order_1_6  connected_order_arc_776  -1
    order_1_6  connected_order_arc_778  -1
    order_1_6  connected_order_arc_780  -1
    order_1_6  connected_order_arc_782  -1
    order_1_6  connected_order_arc_784  -1
    order_1_6  connected_order_arc_787  1
    order_1_6  connected_order_arc_810  1
    order_1_6  connected_order_arc_833  1
    order_1_6  connected_order_arc_856  1
    order_1_6  connected_order_arc_879  1
    order_1_6  connected_order_arc_902  1
    order_1_6  connected_order_arc_925  1
    order_1_6  connected_order_arc_948  1
    order_1_6  connected_order_arc_971  1
    order_1_6  connected_order_arc_994  1
    order_1_6  connected_order_arc_1017  1
    order_1_6  order_active_lb_1042  1
    order_1_6  order_active_ub_1043  1
    order_1_6  fixed_segment_relative_order_1116  -1
    visit_1_7  out_degree_1047  -1
    visit_1_7  in_degree_1048  -1
    visit_1_7  order_active_lb_1049  -1
    visit_1_7  order_active_ub_1050  -12
    order_1_7  connected_order_arc_764  1
    order_1_7  connected_order_arc_787  -1
    order_1_7  connected_order_arc_789  -1
    order_1_7  connected_order_arc_791  -1
    order_1_7  connected_order_arc_793  -1
    order_1_7  connected_order_arc_795  -1
    order_1_7  connected_order_arc_797  -1
    order_1_7  connected_order_arc_799  -1
    order_1_7  connected_order_arc_801  -1
    order_1_7  connected_order_arc_803  -1
    order_1_7  connected_order_arc_805  -1
    order_1_7  connected_order_arc_807  -1
    order_1_7  connected_order_arc_812  1
    order_1_7  connected_order_arc_835  1
    order_1_7  connected_order_arc_858  1
    order_1_7  connected_order_arc_881  1
    order_1_7  connected_order_arc_904  1
    order_1_7  connected_order_arc_927  1
    order_1_7  connected_order_arc_950  1
    order_1_7  connected_order_arc_973  1
    order_1_7  connected_order_arc_996  1
    order_1_7  connected_order_arc_1019  1
    order_1_7  order_active_lb_1049  1
    order_1_7  order_active_ub_1050  1
    order_1_7  fixed_segment_relative_order_1116  1
    order_1_7  fixed_segment_relative_order_1117  -1
    visit_1_8  out_degree_1054  -1
    visit_1_8  in_degree_1055  -1
    visit_1_8  order_active_lb_1056  -1
    visit_1_8  order_active_ub_1057  -12
    order_1_8  connected_order_arc_766  1
    order_1_8  connected_order_arc_789  1
    order_1_8  connected_order_arc_810  -1
    order_1_8  connected_order_arc_812  -1
    order_1_8  connected_order_arc_814  -1
    order_1_8  connected_order_arc_816  -1
    order_1_8  connected_order_arc_818  -1
    order_1_8  connected_order_arc_820  -1
    order_1_8  connected_order_arc_822  -1
    order_1_8  connected_order_arc_824  -1
    order_1_8  connected_order_arc_826  -1
    order_1_8  connected_order_arc_828  -1
    order_1_8  connected_order_arc_830  -1
    order_1_8  connected_order_arc_837  1
    order_1_8  connected_order_arc_860  1
    order_1_8  connected_order_arc_883  1
    order_1_8  connected_order_arc_906  1
    order_1_8  connected_order_arc_929  1
    order_1_8  connected_order_arc_952  1
    order_1_8  connected_order_arc_975  1
    order_1_8  connected_order_arc_998  1
    order_1_8  connected_order_arc_1021  1
    order_1_8  order_active_lb_1056  1
    order_1_8  order_active_ub_1057  1
    order_1_8  fixed_segment_relative_order_1117  1
    order_1_8  fixed_segment_relative_order_1118  -1
    visit_1_9  out_degree_1061  -1
    visit_1_9  in_degree_1062  -1
    visit_1_9  order_active_lb_1063  -1
    visit_1_9  order_active_ub_1064  -12
    order_1_9  connected_order_arc_768  1
    order_1_9  connected_order_arc_791  1
    order_1_9  connected_order_arc_814  1
    order_1_9  connected_order_arc_833  -1
    order_1_9  connected_order_arc_835  -1
    order_1_9  connected_order_arc_837  -1
    order_1_9  connected_order_arc_839  -1
    order_1_9  connected_order_arc_841  -1
    order_1_9  connected_order_arc_843  -1
    order_1_9  connected_order_arc_845  -1
    order_1_9  connected_order_arc_847  -1
    order_1_9  connected_order_arc_849  -1
    order_1_9  connected_order_arc_851  -1
    order_1_9  connected_order_arc_853  -1
    order_1_9  connected_order_arc_862  1
    order_1_9  connected_order_arc_885  1
    order_1_9  connected_order_arc_908  1
    order_1_9  connected_order_arc_931  1
    order_1_9  connected_order_arc_954  1
    order_1_9  connected_order_arc_977  1
    order_1_9  connected_order_arc_1000  1
    order_1_9  connected_order_arc_1023  1
    order_1_9  order_active_lb_1063  1
    order_1_9  order_active_ub_1064  1
    order_1_9  fixed_segment_relative_order_1118  1
    visit_1_13  out_degree_1068  -1
    visit_1_13  in_degree_1069  -1
    visit_1_13  order_active_lb_1070  -1
    visit_1_13  order_active_ub_1071  -12
    visit_1_13  service_visit_def_1072  -1
    order_1_13  connected_order_arc_770  1
    order_1_13  connected_order_arc_793  1
    order_1_13  connected_order_arc_816  1
    order_1_13  connected_order_arc_839  1
    order_1_13  connected_order_arc_856  -1
    order_1_13  connected_order_arc_858  -1
    order_1_13  connected_order_arc_860  -1
    order_1_13  connected_order_arc_862  -1
    order_1_13  connected_order_arc_864  -1
    order_1_13  connected_order_arc_866  -1
    order_1_13  connected_order_arc_868  -1
    order_1_13  connected_order_arc_870  -1
    order_1_13  connected_order_arc_872  -1
    order_1_13  connected_order_arc_874  -1
    order_1_13  connected_order_arc_876  -1
    order_1_13  connected_order_arc_887  1
    order_1_13  connected_order_arc_910  1
    order_1_13  connected_order_arc_933  1
    order_1_13  connected_order_arc_956  1
    order_1_13  connected_order_arc_979  1
    order_1_13  connected_order_arc_1002  1
    order_1_13  connected_order_arc_1025  1
    order_1_13  order_active_lb_1070  1
    order_1_13  order_active_ub_1071  1
    visit_1_14  out_degree_1074  -1
    visit_1_14  in_degree_1075  -1
    visit_1_14  order_active_lb_1076  -1
    visit_1_14  order_active_ub_1077  -12
    visit_1_14  service_visit_def_1078  -1
    order_1_14  connected_order_arc_772  1
    order_1_14  connected_order_arc_795  1
    order_1_14  connected_order_arc_818  1
    order_1_14  connected_order_arc_841  1
    order_1_14  connected_order_arc_864  1
    order_1_14  connected_order_arc_879  -1
    order_1_14  connected_order_arc_881  -1
    order_1_14  connected_order_arc_883  -1
    order_1_14  connected_order_arc_885  -1
    order_1_14  connected_order_arc_887  -1
    order_1_14  connected_order_arc_889  -1
    order_1_14  connected_order_arc_891  -1
    order_1_14  connected_order_arc_893  -1
    order_1_14  connected_order_arc_895  -1
    order_1_14  connected_order_arc_897  -1
    order_1_14  connected_order_arc_899  -1
    order_1_14  connected_order_arc_912  1
    order_1_14  connected_order_arc_935  1
    order_1_14  connected_order_arc_958  1
    order_1_14  connected_order_arc_981  1
    order_1_14  connected_order_arc_1004  1
    order_1_14  connected_order_arc_1027  1
    order_1_14  order_active_lb_1076  1
    order_1_14  order_active_ub_1077  1
    visit_1_15  out_degree_1080  -1
    visit_1_15  in_degree_1081  -1
    visit_1_15  order_active_lb_1082  -1
    visit_1_15  order_active_ub_1083  -12
    visit_1_15  service_visit_def_1084  -1
    order_1_15  connected_order_arc_774  1
    order_1_15  connected_order_arc_797  1
    order_1_15  connected_order_arc_820  1
    order_1_15  connected_order_arc_843  1
    order_1_15  connected_order_arc_866  1
    order_1_15  connected_order_arc_889  1
    order_1_15  connected_order_arc_902  -1
    order_1_15  connected_order_arc_904  -1
    order_1_15  connected_order_arc_906  -1
    order_1_15  connected_order_arc_908  -1
    order_1_15  connected_order_arc_910  -1
    order_1_15  connected_order_arc_912  -1
    order_1_15  connected_order_arc_914  -1
    order_1_15  connected_order_arc_916  -1
    order_1_15  connected_order_arc_918  -1
    order_1_15  connected_order_arc_920  -1
    order_1_15  connected_order_arc_922  -1
    order_1_15  connected_order_arc_937  1
    order_1_15  connected_order_arc_960  1
    order_1_15  connected_order_arc_983  1
    order_1_15  connected_order_arc_1006  1
    order_1_15  connected_order_arc_1029  1
    order_1_15  order_active_lb_1082  1
    order_1_15  order_active_ub_1083  1
    visit_1_16  out_degree_1086  -1
    visit_1_16  in_degree_1087  -1
    visit_1_16  order_active_lb_1088  -1
    visit_1_16  order_active_ub_1089  -12
    visit_1_16  service_visit_def_1090  -1
    order_1_16  connected_order_arc_776  1
    order_1_16  connected_order_arc_799  1
    order_1_16  connected_order_arc_822  1
    order_1_16  connected_order_arc_845  1
    order_1_16  connected_order_arc_868  1
    order_1_16  connected_order_arc_891  1
    order_1_16  connected_order_arc_914  1
    order_1_16  connected_order_arc_925  -1
    order_1_16  connected_order_arc_927  -1
    order_1_16  connected_order_arc_929  -1
    order_1_16  connected_order_arc_931  -1
    order_1_16  connected_order_arc_933  -1
    order_1_16  connected_order_arc_935  -1
    order_1_16  connected_order_arc_937  -1
    order_1_16  connected_order_arc_939  -1
    order_1_16  connected_order_arc_941  -1
    order_1_16  connected_order_arc_943  -1
    order_1_16  connected_order_arc_945  -1
    order_1_16  connected_order_arc_962  1
    order_1_16  connected_order_arc_985  1
    order_1_16  connected_order_arc_1008  1
    order_1_16  connected_order_arc_1031  1
    order_1_16  order_active_lb_1088  1
    order_1_16  order_active_ub_1089  1
    visit_1_17  out_degree_1092  -1
    visit_1_17  in_degree_1093  -1
    visit_1_17  order_active_lb_1094  -1
    visit_1_17  order_active_ub_1095  -12
    visit_1_17  service_visit_def_1096  -1
    order_1_17  connected_order_arc_778  1
    order_1_17  connected_order_arc_801  1
    order_1_17  connected_order_arc_824  1
    order_1_17  connected_order_arc_847  1
    order_1_17  connected_order_arc_870  1
    order_1_17  connected_order_arc_893  1
    order_1_17  connected_order_arc_916  1
    order_1_17  connected_order_arc_939  1
    order_1_17  connected_order_arc_948  -1
    order_1_17  connected_order_arc_950  -1
    order_1_17  connected_order_arc_952  -1
    order_1_17  connected_order_arc_954  -1
    order_1_17  connected_order_arc_956  -1
    order_1_17  connected_order_arc_958  -1
    order_1_17  connected_order_arc_960  -1
    order_1_17  connected_order_arc_962  -1
    order_1_17  connected_order_arc_964  -1
    order_1_17  connected_order_arc_966  -1
    order_1_17  connected_order_arc_968  -1
    order_1_17  connected_order_arc_987  1
    order_1_17  connected_order_arc_1010  1
    order_1_17  connected_order_arc_1033  1
    order_1_17  order_active_lb_1094  1
    order_1_17  order_active_ub_1095  1
    visit_1_18  out_degree_1098  -1
    visit_1_18  in_degree_1099  -1
    visit_1_18  order_active_lb_1100  -1
    visit_1_18  order_active_ub_1101  -12
    visit_1_18  service_visit_def_1102  -1
    order_1_18  connected_order_arc_780  1
    order_1_18  connected_order_arc_803  1
    order_1_18  connected_order_arc_826  1
    order_1_18  connected_order_arc_849  1
    order_1_18  connected_order_arc_872  1
    order_1_18  connected_order_arc_895  1
    order_1_18  connected_order_arc_918  1
    order_1_18  connected_order_arc_941  1
    order_1_18  connected_order_arc_964  1
    order_1_18  connected_order_arc_971  -1
    order_1_18  connected_order_arc_973  -1
    order_1_18  connected_order_arc_975  -1
    order_1_18  connected_order_arc_977  -1
    order_1_18  connected_order_arc_979  -1
    order_1_18  connected_order_arc_981  -1
    order_1_18  connected_order_arc_983  -1
    order_1_18  connected_order_arc_985  -1
    order_1_18  connected_order_arc_987  -1
    order_1_18  connected_order_arc_989  -1
    order_1_18  connected_order_arc_991  -1
    order_1_18  connected_order_arc_1012  1
    order_1_18  connected_order_arc_1035  1
    order_1_18  order_active_lb_1100  1
    order_1_18  order_active_ub_1101  1
    visit_1_19  out_degree_1104  -1
    visit_1_19  in_degree_1105  -1
    visit_1_19  order_active_lb_1106  -1
    visit_1_19  order_active_ub_1107  -12
    visit_1_19  service_visit_def_1108  -1
    order_1_19  connected_order_arc_782  1
    order_1_19  connected_order_arc_805  1
    order_1_19  connected_order_arc_828  1
    order_1_19  connected_order_arc_851  1
    order_1_19  connected_order_arc_874  1
    order_1_19  connected_order_arc_897  1
    order_1_19  connected_order_arc_920  1
    order_1_19  connected_order_arc_943  1
    order_1_19  connected_order_arc_966  1
    order_1_19  connected_order_arc_989  1
    order_1_19  connected_order_arc_994  -1
    order_1_19  connected_order_arc_996  -1
    order_1_19  connected_order_arc_998  -1
    order_1_19  connected_order_arc_1000  -1
    order_1_19  connected_order_arc_1002  -1
    order_1_19  connected_order_arc_1004  -1
    order_1_19  connected_order_arc_1006  -1
    order_1_19  connected_order_arc_1008  -1
    order_1_19  connected_order_arc_1010  -1
    order_1_19  connected_order_arc_1012  -1
    order_1_19  connected_order_arc_1014  -1
    order_1_19  connected_order_arc_1037  1
    order_1_19  order_active_lb_1106  1
    order_1_19  order_active_ub_1107  1
    visit_1_20  out_degree_1110  -1
    visit_1_20  in_degree_1111  -1
    visit_1_20  order_active_lb_1112  -1
    visit_1_20  order_active_ub_1113  -12
    visit_1_20  service_visit_def_1114  -1
    order_1_20  connected_order_arc_784  1
    order_1_20  connected_order_arc_807  1
    order_1_20  connected_order_arc_830  1
    order_1_20  connected_order_arc_853  1
    order_1_20  connected_order_arc_876  1
    order_1_20  connected_order_arc_899  1
    order_1_20  connected_order_arc_922  1
    order_1_20  connected_order_arc_945  1
    order_1_20  connected_order_arc_968  1
    order_1_20  connected_order_arc_991  1
    order_1_20  connected_order_arc_1014  1
    order_1_20  connected_order_arc_1017  -1
    order_1_20  connected_order_arc_1019  -1
    order_1_20  connected_order_arc_1021  -1
    order_1_20  connected_order_arc_1023  -1
    order_1_20  connected_order_arc_1025  -1
    order_1_20  connected_order_arc_1027  -1
    order_1_20  connected_order_arc_1029  -1
    order_1_20  connected_order_arc_1031  -1
    order_1_20  connected_order_arc_1033  -1
    order_1_20  connected_order_arc_1035  -1
    order_1_20  connected_order_arc_1037  -1
    order_1_20  order_active_lb_1112  1
    order_1_20  order_active_ub_1113  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_749  -25
    arc_1_0_0  depot_departure_or_bypass_1038  1
    arc_1_0_0  depot_return_or_bypass_1039  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_750  -25
    arc_1_0_6  depot_departure_or_bypass_1038  1
    arc_1_0_6  in_degree_1041  1
    arc_1_0_6  original_T_including_depot_unload_1119  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_750  1
    load_1_0_6  segment_load_conservation_1044  -1
    load_1_0_6  segment_prefix_lb_1045  1
    load_1_0_6  segment_prefix_ub_1046  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_751  -25
    arc_1_0_7  depot_departure_or_bypass_1038  1
    arc_1_0_7  in_degree_1048  1
    arc_1_0_7  original_T_including_depot_unload_1119  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_751  1
    load_1_0_7  segment_load_conservation_1051  -1
    load_1_0_7  segment_prefix_lb_1052  1
    load_1_0_7  segment_prefix_ub_1053  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_752  -25
    arc_1_0_8  depot_departure_or_bypass_1038  1
    arc_1_0_8  in_degree_1055  1
    arc_1_0_8  original_T_including_depot_unload_1119  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_752  1
    load_1_0_8  segment_load_conservation_1058  -1
    load_1_0_8  segment_prefix_lb_1059  1
    load_1_0_8  segment_prefix_ub_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_753  -25
    arc_1_0_9  depot_departure_or_bypass_1038  1
    arc_1_0_9  in_degree_1062  1
    arc_1_0_9  original_T_including_depot_unload_1119  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_753  1
    load_1_0_9  segment_load_conservation_1065  -1
    load_1_0_9  segment_prefix_lb_1066  1
    load_1_0_9  segment_prefix_ub_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_754  -25
    arc_1_0_13  depot_departure_or_bypass_1038  1
    arc_1_0_13  in_degree_1069  1
    arc_1_0_13  original_T_including_depot_unload_1119  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_754  1
    load_1_0_13  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_755  -25
    arc_1_0_14  depot_departure_or_bypass_1038  1
    arc_1_0_14  in_degree_1075  1
    arc_1_0_14  original_T_including_depot_unload_1119  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_755  1
    load_1_0_14  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_756  -25
    arc_1_0_15  depot_departure_or_bypass_1038  1
    arc_1_0_15  in_degree_1081  1
    arc_1_0_15  original_T_including_depot_unload_1119  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_756  1
    load_1_0_15  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_757  -25
    arc_1_0_16  depot_departure_or_bypass_1038  1
    arc_1_0_16  in_degree_1087  1
    arc_1_0_16  original_T_including_depot_unload_1119  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_757  1
    load_1_0_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_758  -25
    arc_1_0_17  depot_departure_or_bypass_1038  1
    arc_1_0_17  in_degree_1093  1
    arc_1_0_17  original_T_including_depot_unload_1119  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_758  1
    load_1_0_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_759  -25
    arc_1_0_18  depot_departure_or_bypass_1038  1
    arc_1_0_18  in_degree_1099  1
    arc_1_0_18  original_T_including_depot_unload_1119  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_759  1
    load_1_0_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_760  -25
    arc_1_0_19  depot_departure_or_bypass_1038  1
    arc_1_0_19  in_degree_1105  1
    arc_1_0_19  original_T_including_depot_unload_1119  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_760  1
    load_1_0_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_761  -25
    arc_1_0_20  depot_departure_or_bypass_1038  1
    arc_1_0_20  in_degree_1111  1
    arc_1_0_20  original_T_including_depot_unload_1119  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_761  1
    load_1_0_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_762  -25
    arc_1_6_0  depot_return_or_bypass_1039  1
    arc_1_6_0  out_degree_1040  1
    arc_1_6_0  original_T_including_depot_unload_1119  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_762  1
    load_1_6_0  segment_load_conservation_1044  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_763  -25
    arc_1_6_7  connected_order_arc_764  -13
    arc_1_6_7  out_degree_1040  1
    arc_1_6_7  in_degree_1048  1
    arc_1_6_7  original_T_including_depot_unload_1119  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_763  1
    load_1_6_7  segment_load_conservation_1044  1
    load_1_6_7  segment_load_conservation_1051  -1
    load_1_6_7  segment_prefix_lb_1052  1
    load_1_6_7  segment_prefix_ub_1053  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_765  -25
    arc_1_6_8  connected_order_arc_766  -13
    arc_1_6_8  out_degree_1040  1
    arc_1_6_8  in_degree_1055  1
    arc_1_6_8  original_T_including_depot_unload_1119  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_765  1
    load_1_6_8  segment_load_conservation_1044  1
    load_1_6_8  segment_load_conservation_1058  -1
    load_1_6_8  segment_prefix_lb_1059  1
    load_1_6_8  segment_prefix_ub_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_767  -25
    arc_1_6_9  connected_order_arc_768  -13
    arc_1_6_9  out_degree_1040  1
    arc_1_6_9  in_degree_1062  1
    arc_1_6_9  original_T_including_depot_unload_1119  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_767  1
    load_1_6_9  segment_load_conservation_1044  1
    load_1_6_9  segment_load_conservation_1065  -1
    load_1_6_9  segment_prefix_lb_1066  1
    load_1_6_9  segment_prefix_ub_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_769  -25
    arc_1_6_13  connected_order_arc_770  -13
    arc_1_6_13  out_degree_1040  1
    arc_1_6_13  in_degree_1069  1
    arc_1_6_13  original_T_including_depot_unload_1119  7.7576476069541832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_769  1
    load_1_6_13  segment_load_conservation_1044  1
    load_1_6_13  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_771  -25
    arc_1_6_14  connected_order_arc_772  -13
    arc_1_6_14  out_degree_1040  1
    arc_1_6_14  in_degree_1075  1
    arc_1_6_14  original_T_including_depot_unload_1119  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_771  1
    load_1_6_14  segment_load_conservation_1044  1
    load_1_6_14  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_773  -25
    arc_1_6_15  connected_order_arc_774  -13
    arc_1_6_15  out_degree_1040  1
    arc_1_6_15  in_degree_1081  1
    arc_1_6_15  original_T_including_depot_unload_1119  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_773  1
    load_1_6_15  segment_load_conservation_1044  1
    load_1_6_15  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_775  -25
    arc_1_6_16  connected_order_arc_776  -13
    arc_1_6_16  out_degree_1040  1
    arc_1_6_16  in_degree_1087  1
    arc_1_6_16  original_T_including_depot_unload_1119  9.1749781390727367e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_775  1
    load_1_6_16  segment_load_conservation_1044  1
    load_1_6_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_777  -25
    arc_1_6_17  connected_order_arc_778  -13
    arc_1_6_17  out_degree_1040  1
    arc_1_6_17  in_degree_1093  1
    arc_1_6_17  original_T_including_depot_unload_1119  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_777  1
    load_1_6_17  segment_load_conservation_1044  1
    load_1_6_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_779  -25
    arc_1_6_18  connected_order_arc_780  -13
    arc_1_6_18  out_degree_1040  1
    arc_1_6_18  in_degree_1099  1
    arc_1_6_18  original_T_including_depot_unload_1119  9.1847405672984632e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_779  1
    load_1_6_18  segment_load_conservation_1044  1
    load_1_6_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_781  -25
    arc_1_6_19  connected_order_arc_782  -13
    arc_1_6_19  out_degree_1040  1
    arc_1_6_19  in_degree_1105  1
    arc_1_6_19  original_T_including_depot_unload_1119  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_781  1
    load_1_6_19  segment_load_conservation_1044  1
    load_1_6_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_783  -25
    arc_1_6_20  connected_order_arc_784  -13
    arc_1_6_20  out_degree_1040  1
    arc_1_6_20  in_degree_1111  1
    arc_1_6_20  original_T_including_depot_unload_1119  9.1810091557460953e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_783  1
    load_1_6_20  segment_load_conservation_1044  1
    load_1_6_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_785  -25
    arc_1_7_0  depot_return_or_bypass_1039  1
    arc_1_7_0  out_degree_1047  1
    arc_1_7_0  original_T_including_depot_unload_1119  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_785  1
    load_1_7_0  segment_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_786  -25
    arc_1_7_6  connected_order_arc_787  -13
    arc_1_7_6  in_degree_1041  1
    arc_1_7_6  out_degree_1047  1
    arc_1_7_6  original_T_including_depot_unload_1119  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_786  1
    load_1_7_6  segment_load_conservation_1044  -1
    load_1_7_6  segment_prefix_lb_1045  1
    load_1_7_6  segment_prefix_ub_1046  1
    load_1_7_6  segment_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_788  -25
    arc_1_7_8  connected_order_arc_789  -13
    arc_1_7_8  out_degree_1047  1
    arc_1_7_8  in_degree_1055  1
    arc_1_7_8  original_T_including_depot_unload_1119  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_788  1
    load_1_7_8  segment_load_conservation_1051  1
    load_1_7_8  segment_load_conservation_1058  -1
    load_1_7_8  segment_prefix_lb_1059  1
    load_1_7_8  segment_prefix_ub_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_790  -25
    arc_1_7_9  connected_order_arc_791  -13
    arc_1_7_9  out_degree_1047  1
    arc_1_7_9  in_degree_1062  1
    arc_1_7_9  original_T_including_depot_unload_1119  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_790  1
    load_1_7_9  segment_load_conservation_1051  1
    load_1_7_9  segment_load_conservation_1065  -1
    load_1_7_9  segment_prefix_lb_1066  1
    load_1_7_9  segment_prefix_ub_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_792  -25
    arc_1_7_13  connected_order_arc_793  -13
    arc_1_7_13  out_degree_1047  1
    arc_1_7_13  in_degree_1069  1
    arc_1_7_13  original_T_including_depot_unload_1119  1.1885707701696851e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_792  1
    load_1_7_13  segment_load_conservation_1051  1
    load_1_7_13  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_794  -25
    arc_1_7_14  connected_order_arc_795  -13
    arc_1_7_14  out_degree_1047  1
    arc_1_7_14  in_degree_1075  1
    arc_1_7_14  original_T_including_depot_unload_1119  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_794  1
    load_1_7_14  segment_load_conservation_1051  1
    load_1_7_14  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_796  -25
    arc_1_7_15  connected_order_arc_797  -13
    arc_1_7_15  out_degree_1047  1
    arc_1_7_15  in_degree_1081  1
    arc_1_7_15  original_T_including_depot_unload_1119  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_796  1
    load_1_7_15  segment_load_conservation_1051  1
    load_1_7_15  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_798  -25
    arc_1_7_16  connected_order_arc_799  -13
    arc_1_7_16  out_degree_1047  1
    arc_1_7_16  in_degree_1087  1
    arc_1_7_16  original_T_including_depot_unload_1119  1.3825747156698872e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_798  1
    load_1_7_16  segment_load_conservation_1051  1
    load_1_7_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_800  -25
    arc_1_7_17  connected_order_arc_801  -13
    arc_1_7_17  out_degree_1047  1
    arc_1_7_17  in_degree_1093  1
    arc_1_7_17  original_T_including_depot_unload_1119  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_800  1
    load_1_7_17  segment_load_conservation_1051  1
    load_1_7_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_802  -25
    arc_1_7_18  connected_order_arc_803  -13
    arc_1_7_18  out_degree_1047  1
    arc_1_7_18  in_degree_1099  1
    arc_1_7_18  original_T_including_depot_unload_1119  1.3842338084916330e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_802  1
    load_1_7_18  segment_load_conservation_1051  1
    load_1_7_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_804  -25
    arc_1_7_19  connected_order_arc_805  -13
    arc_1_7_19  out_degree_1047  1
    arc_1_7_19  in_degree_1105  1
    arc_1_7_19  original_T_including_depot_unload_1119  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_804  1
    load_1_7_19  segment_load_conservation_1051  1
    load_1_7_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_806  -25
    arc_1_7_20  connected_order_arc_807  -13
    arc_1_7_20  out_degree_1047  1
    arc_1_7_20  in_degree_1111  1
    arc_1_7_20  original_T_including_depot_unload_1119  1.3848663974280498e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_806  1
    load_1_7_20  segment_load_conservation_1051  1
    load_1_7_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_808  -25
    arc_1_8_0  depot_return_or_bypass_1039  1
    arc_1_8_0  out_degree_1054  1
    arc_1_8_0  original_T_including_depot_unload_1119  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_808  1
    load_1_8_0  segment_load_conservation_1058  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_809  -25
    arc_1_8_6  connected_order_arc_810  -13
    arc_1_8_6  in_degree_1041  1
    arc_1_8_6  out_degree_1054  1
    arc_1_8_6  original_T_including_depot_unload_1119  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_809  1
    load_1_8_6  segment_load_conservation_1044  -1
    load_1_8_6  segment_prefix_lb_1045  1
    load_1_8_6  segment_prefix_ub_1046  1
    load_1_8_6  segment_load_conservation_1058  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_811  -25
    arc_1_8_7  connected_order_arc_812  -13
    arc_1_8_7  in_degree_1048  1
    arc_1_8_7  out_degree_1054  1
    arc_1_8_7  original_T_including_depot_unload_1119  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_811  1
    load_1_8_7  segment_load_conservation_1051  -1
    load_1_8_7  segment_prefix_lb_1052  1
    load_1_8_7  segment_prefix_ub_1053  1
    load_1_8_7  segment_load_conservation_1058  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_813  -25
    arc_1_8_9  connected_order_arc_814  -13
    arc_1_8_9  out_degree_1054  1
    arc_1_8_9  in_degree_1062  1
    arc_1_8_9  original_T_including_depot_unload_1119  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_813  1
    load_1_8_9  segment_load_conservation_1058  1
    load_1_8_9  segment_load_conservation_1065  -1
    load_1_8_9  segment_prefix_lb_1066  1
    load_1_8_9  segment_prefix_ub_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_815  -25
    arc_1_8_13  connected_order_arc_816  -13
    arc_1_8_13  out_degree_1054  1
    arc_1_8_13  in_degree_1069  1
    arc_1_8_13  original_T_including_depot_unload_1119  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_815  1
    load_1_8_13  segment_load_conservation_1058  1
    load_1_8_13  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_817  -25
    arc_1_8_14  connected_order_arc_818  -13
    arc_1_8_14  out_degree_1054  1
    arc_1_8_14  in_degree_1075  1
    arc_1_8_14  original_T_including_depot_unload_1119  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_817  1
    load_1_8_14  segment_load_conservation_1058  1
    load_1_8_14  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_819  -25
    arc_1_8_15  connected_order_arc_820  -13
    arc_1_8_15  out_degree_1054  1
    arc_1_8_15  in_degree_1081  1
    arc_1_8_15  original_T_including_depot_unload_1119  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_819  1
    load_1_8_15  segment_load_conservation_1058  1
    load_1_8_15  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_821  -25
    arc_1_8_16  connected_order_arc_822  -13
    arc_1_8_16  out_degree_1054  1
    arc_1_8_16  in_degree_1087  1
    arc_1_8_16  original_T_including_depot_unload_1119  6.4732789246105290e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_821  1
    load_1_8_16  segment_load_conservation_1058  1
    load_1_8_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_823  -25
    arc_1_8_17  connected_order_arc_824  -13
    arc_1_8_17  out_degree_1054  1
    arc_1_8_17  in_degree_1093  1
    arc_1_8_17  original_T_including_depot_unload_1119  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_823  1
    load_1_8_17  segment_load_conservation_1058  1
    load_1_8_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_825  -25
    arc_1_8_18  connected_order_arc_826  -13
    arc_1_8_18  out_degree_1054  1
    arc_1_8_18  in_degree_1099  1
    arc_1_8_18  original_T_including_depot_unload_1119  6.4850607840217310e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_825  1
    load_1_8_18  segment_load_conservation_1058  1
    load_1_8_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_827  -25
    arc_1_8_19  connected_order_arc_828  -13
    arc_1_8_19  out_degree_1054  1
    arc_1_8_19  in_degree_1105  1
    arc_1_8_19  original_T_including_depot_unload_1119  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_827  1
    load_1_8_19  segment_load_conservation_1058  1
    load_1_8_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_829  -25
    arc_1_8_20  connected_order_arc_830  -13
    arc_1_8_20  out_degree_1054  1
    arc_1_8_20  in_degree_1111  1
    arc_1_8_20  original_T_including_depot_unload_1119  6.4832473911284285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_829  1
    load_1_8_20  segment_load_conservation_1058  1
    load_1_8_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_831  -25
    arc_1_9_0  depot_return_or_bypass_1039  1
    arc_1_9_0  out_degree_1061  1
    arc_1_9_0  original_T_including_depot_unload_1119  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_831  1
    load_1_9_0  segment_load_conservation_1065  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_832  -25
    arc_1_9_6  connected_order_arc_833  -13
    arc_1_9_6  in_degree_1041  1
    arc_1_9_6  out_degree_1061  1
    arc_1_9_6  original_T_including_depot_unload_1119  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_832  1
    load_1_9_6  segment_load_conservation_1044  -1
    load_1_9_6  segment_prefix_lb_1045  1
    load_1_9_6  segment_prefix_ub_1046  1
    load_1_9_6  segment_load_conservation_1065  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_834  -25
    arc_1_9_7  connected_order_arc_835  -13
    arc_1_9_7  in_degree_1048  1
    arc_1_9_7  out_degree_1061  1
    arc_1_9_7  original_T_including_depot_unload_1119  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_834  1
    load_1_9_7  segment_load_conservation_1051  -1
    load_1_9_7  segment_prefix_lb_1052  1
    load_1_9_7  segment_prefix_ub_1053  1
    load_1_9_7  segment_load_conservation_1065  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_836  -25
    arc_1_9_8  connected_order_arc_837  -13
    arc_1_9_8  in_degree_1055  1
    arc_1_9_8  out_degree_1061  1
    arc_1_9_8  original_T_including_depot_unload_1119  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_836  1
    load_1_9_8  segment_load_conservation_1058  -1
    load_1_9_8  segment_prefix_lb_1059  1
    load_1_9_8  segment_prefix_ub_1060  1
    load_1_9_8  segment_load_conservation_1065  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_838  -25
    arc_1_9_13  connected_order_arc_839  -13
    arc_1_9_13  out_degree_1061  1
    arc_1_9_13  in_degree_1069  1
    arc_1_9_13  original_T_including_depot_unload_1119  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_838  1
    load_1_9_13  segment_load_conservation_1065  1
    load_1_9_13  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_840  -25
    arc_1_9_14  connected_order_arc_841  -13
    arc_1_9_14  out_degree_1061  1
    arc_1_9_14  in_degree_1075  1
    arc_1_9_14  original_T_including_depot_unload_1119  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_840  1
    load_1_9_14  segment_load_conservation_1065  1
    load_1_9_14  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_842  -25
    arc_1_9_15  connected_order_arc_843  -13
    arc_1_9_15  out_degree_1061  1
    arc_1_9_15  in_degree_1081  1
    arc_1_9_15  original_T_including_depot_unload_1119  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_842  1
    load_1_9_15  segment_load_conservation_1065  1
    load_1_9_15  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_844  -25
    arc_1_9_16  connected_order_arc_845  -13
    arc_1_9_16  out_degree_1061  1
    arc_1_9_16  in_degree_1087  1
    arc_1_9_16  original_T_including_depot_unload_1119  6.3069852135268593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_844  1
    load_1_9_16  segment_load_conservation_1065  1
    load_1_9_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_846  -25
    arc_1_9_17  connected_order_arc_847  -13
    arc_1_9_17  out_degree_1061  1
    arc_1_9_17  in_degree_1093  1
    arc_1_9_17  original_T_including_depot_unload_1119  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_846  1
    load_1_9_17  segment_load_conservation_1065  1
    load_1_9_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_848  -25
    arc_1_9_18  connected_order_arc_849  -13
    arc_1_9_18  out_degree_1061  1
    arc_1_9_18  in_degree_1099  1
    arc_1_9_18  original_T_including_depot_unload_1119  6.3119444979991374e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_848  1
    load_1_9_18  segment_load_conservation_1065  1
    load_1_9_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_850  -25
    arc_1_9_19  connected_order_arc_851  -13
    arc_1_9_19  out_degree_1061  1
    arc_1_9_19  in_degree_1105  1
    arc_1_9_19  original_T_including_depot_unload_1119  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_850  1
    load_1_9_19  segment_load_conservation_1065  1
    load_1_9_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_852  -25
    arc_1_9_20  connected_order_arc_853  -13
    arc_1_9_20  out_degree_1061  1
    arc_1_9_20  in_degree_1111  1
    arc_1_9_20  original_T_including_depot_unload_1119  6.3046739375549225e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_852  1
    load_1_9_20  segment_load_conservation_1065  1
    load_1_9_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_854  -25
    arc_1_13_0  depot_return_or_bypass_1039  1
    arc_1_13_0  out_degree_1068  1
    arc_1_13_0  original_T_including_depot_unload_1119  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_854  1
    load_1_13_0  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_855  -25
    arc_1_13_6  connected_order_arc_856  -13
    arc_1_13_6  in_degree_1041  1
    arc_1_13_6  out_degree_1068  1
    arc_1_13_6  original_T_including_depot_unload_1119  1.5639034270630727e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_855  1
    load_1_13_6  segment_load_conservation_1044  -1
    load_1_13_6  segment_prefix_lb_1045  1
    load_1_13_6  segment_prefix_ub_1046  1
    load_1_13_6  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_857  -25
    arc_1_13_7  connected_order_arc_858  -13
    arc_1_13_7  in_degree_1048  1
    arc_1_13_7  out_degree_1068  1
    arc_1_13_7  original_T_including_depot_unload_1119  1.1885707701696851e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_857  1
    load_1_13_7  segment_load_conservation_1051  -1
    load_1_13_7  segment_prefix_lb_1052  1
    load_1_13_7  segment_prefix_ub_1053  1
    load_1_13_7  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_859  -25
    arc_1_13_8  connected_order_arc_860  -13
    arc_1_13_8  in_degree_1055  1
    arc_1_13_8  out_degree_1068  1
    arc_1_13_8  original_T_including_depot_unload_1119  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_859  1
    load_1_13_8  segment_load_conservation_1058  -1
    load_1_13_8  segment_prefix_lb_1059  1
    load_1_13_8  segment_prefix_ub_1060  1
    load_1_13_8  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_861  -25
    arc_1_13_9  connected_order_arc_862  -13
    arc_1_13_9  in_degree_1062  1
    arc_1_13_9  out_degree_1068  1
    arc_1_13_9  original_T_including_depot_unload_1119  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_861  1
    load_1_13_9  segment_load_conservation_1065  -1
    load_1_13_9  segment_prefix_lb_1066  1
    load_1_13_9  segment_prefix_ub_1067  1
    load_1_13_9  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_863  -25
    arc_1_13_14  connected_order_arc_864  -13
    arc_1_13_14  out_degree_1068  1
    arc_1_13_14  in_degree_1075  1
    arc_1_13_14  original_T_including_depot_unload_1119  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_863  1
    load_1_13_14  free_load_conservation_1073  1
    load_1_13_14  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_865  -25
    arc_1_13_15  connected_order_arc_866  -13
    arc_1_13_15  out_degree_1068  1
    arc_1_13_15  in_degree_1081  1
    arc_1_13_15  original_T_including_depot_unload_1119  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_865  1
    load_1_13_15  free_load_conservation_1073  1
    load_1_13_15  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_867  -25
    arc_1_13_16  connected_order_arc_868  -13
    arc_1_13_16  out_degree_1068  1
    arc_1_13_16  in_degree_1087  1
    arc_1_13_16  original_T_including_depot_unload_1119  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_867  1
    load_1_13_16  free_load_conservation_1073  1
    load_1_13_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_869  -25
    arc_1_13_17  connected_order_arc_870  -13
    arc_1_13_17  out_degree_1068  1
    arc_1_13_17  in_degree_1093  1
    arc_1_13_17  original_T_including_depot_unload_1119  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_869  1
    load_1_13_17  free_load_conservation_1073  1
    load_1_13_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_871  -25
    arc_1_13_18  connected_order_arc_872  -13
    arc_1_13_18  out_degree_1068  1
    arc_1_13_18  in_degree_1099  1
    arc_1_13_18  original_T_including_depot_unload_1119  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_871  1
    load_1_13_18  free_load_conservation_1073  1
    load_1_13_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_873  -25
    arc_1_13_19  connected_order_arc_874  -13
    arc_1_13_19  out_degree_1068  1
    arc_1_13_19  in_degree_1105  1
    arc_1_13_19  original_T_including_depot_unload_1119  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_873  1
    load_1_13_19  free_load_conservation_1073  1
    load_1_13_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_875  -25
    arc_1_13_20  connected_order_arc_876  -13
    arc_1_13_20  out_degree_1068  1
    arc_1_13_20  in_degree_1111  1
    arc_1_13_20  original_T_including_depot_unload_1119  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_875  1
    load_1_13_20  free_load_conservation_1073  1
    load_1_13_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_877  -25
    arc_1_14_0  depot_return_or_bypass_1039  1
    arc_1_14_0  out_degree_1074  1
    arc_1_14_0  original_T_including_depot_unload_1119  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_877  1
    load_1_14_0  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_878  -25
    arc_1_14_6  connected_order_arc_879  -13
    arc_1_14_6  in_degree_1041  1
    arc_1_14_6  out_degree_1074  1
    arc_1_14_6  original_T_including_depot_unload_1119  1.5634365646683834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_878  1
    load_1_14_6  segment_load_conservation_1044  -1
    load_1_14_6  segment_prefix_lb_1045  1
    load_1_14_6  segment_prefix_ub_1046  1
    load_1_14_6  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_880  -25
    arc_1_14_7  connected_order_arc_881  -13
    arc_1_14_7  in_degree_1048  1
    arc_1_14_7  out_degree_1074  1
    arc_1_14_7  original_T_including_depot_unload_1119  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_880  1
    load_1_14_7  segment_load_conservation_1051  -1
    load_1_14_7  segment_prefix_lb_1052  1
    load_1_14_7  segment_prefix_ub_1053  1
    load_1_14_7  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_882  -25
    arc_1_14_8  connected_order_arc_883  -13
    arc_1_14_8  in_degree_1055  1
    arc_1_14_8  out_degree_1074  1
    arc_1_14_8  original_T_including_depot_unload_1119  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_882  1
    load_1_14_8  segment_load_conservation_1058  -1
    load_1_14_8  segment_prefix_lb_1059  1
    load_1_14_8  segment_prefix_ub_1060  1
    load_1_14_8  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_884  -25
    arc_1_14_9  connected_order_arc_885  -13
    arc_1_14_9  in_degree_1062  1
    arc_1_14_9  out_degree_1074  1
    arc_1_14_9  original_T_including_depot_unload_1119  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_884  1
    load_1_14_9  segment_load_conservation_1065  -1
    load_1_14_9  segment_prefix_lb_1066  1
    load_1_14_9  segment_prefix_ub_1067  1
    load_1_14_9  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_886  -25
    arc_1_14_13  connected_order_arc_887  -13
    arc_1_14_13  in_degree_1069  1
    arc_1_14_13  out_degree_1074  1
    arc_1_14_13  original_T_including_depot_unload_1119  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_886  1
    load_1_14_13  free_load_conservation_1073  -1
    load_1_14_13  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_888  -25
    arc_1_14_15  connected_order_arc_889  -13
    arc_1_14_15  out_degree_1074  1
    arc_1_14_15  in_degree_1081  1
    arc_1_14_15  original_T_including_depot_unload_1119  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_888  1
    load_1_14_15  free_load_conservation_1079  1
    load_1_14_15  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_890  -25
    arc_1_14_16  connected_order_arc_891  -13
    arc_1_14_16  out_degree_1074  1
    arc_1_14_16  in_degree_1087  1
    arc_1_14_16  original_T_including_depot_unload_1119  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_890  1
    load_1_14_16  free_load_conservation_1079  1
    load_1_14_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_892  -25
    arc_1_14_17  connected_order_arc_893  -13
    arc_1_14_17  out_degree_1074  1
    arc_1_14_17  in_degree_1093  1
    arc_1_14_17  original_T_including_depot_unload_1119  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_892  1
    load_1_14_17  free_load_conservation_1079  1
    load_1_14_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_894  -25
    arc_1_14_18  connected_order_arc_895  -13
    arc_1_14_18  out_degree_1074  1
    arc_1_14_18  in_degree_1099  1
    arc_1_14_18  original_T_including_depot_unload_1119  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_894  1
    load_1_14_18  free_load_conservation_1079  1
    load_1_14_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_896  -25
    arc_1_14_19  connected_order_arc_897  -13
    arc_1_14_19  out_degree_1074  1
    arc_1_14_19  in_degree_1105  1
    arc_1_14_19  original_T_including_depot_unload_1119  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_896  1
    load_1_14_19  free_load_conservation_1079  1
    load_1_14_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_898  -25
    arc_1_14_20  connected_order_arc_899  -13
    arc_1_14_20  out_degree_1074  1
    arc_1_14_20  in_degree_1111  1
    arc_1_14_20  original_T_including_depot_unload_1119  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_898  1
    load_1_14_20  free_load_conservation_1079  1
    load_1_14_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_900  -25
    arc_1_15_0  depot_return_or_bypass_1039  1
    arc_1_15_0  out_degree_1080  1
    arc_1_15_0  original_T_including_depot_unload_1119  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_900  1
    load_1_15_0  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_901  -25
    arc_1_15_6  connected_order_arc_902  -13
    arc_1_15_6  in_degree_1041  1
    arc_1_15_6  out_degree_1080  1
    arc_1_15_6  original_T_including_depot_unload_1119  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_901  1
    load_1_15_6  segment_load_conservation_1044  -1
    load_1_15_6  segment_prefix_lb_1045  1
    load_1_15_6  segment_prefix_ub_1046  1
    load_1_15_6  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_903  -25
    arc_1_15_7  connected_order_arc_904  -13
    arc_1_15_7  in_degree_1048  1
    arc_1_15_7  out_degree_1080  1
    arc_1_15_7  original_T_including_depot_unload_1119  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_903  1
    load_1_15_7  segment_load_conservation_1051  -1
    load_1_15_7  segment_prefix_lb_1052  1
    load_1_15_7  segment_prefix_ub_1053  1
    load_1_15_7  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_905  -25
    arc_1_15_8  connected_order_arc_906  -13
    arc_1_15_8  in_degree_1055  1
    arc_1_15_8  out_degree_1080  1
    arc_1_15_8  original_T_including_depot_unload_1119  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_905  1
    load_1_15_8  segment_load_conservation_1058  -1
    load_1_15_8  segment_prefix_lb_1059  1
    load_1_15_8  segment_prefix_ub_1060  1
    load_1_15_8  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_907  -25
    arc_1_15_9  connected_order_arc_908  -13
    arc_1_15_9  in_degree_1062  1
    arc_1_15_9  out_degree_1080  1
    arc_1_15_9  original_T_including_depot_unload_1119  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_907  1
    load_1_15_9  segment_load_conservation_1065  -1
    load_1_15_9  segment_prefix_lb_1066  1
    load_1_15_9  segment_prefix_ub_1067  1
    load_1_15_9  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_909  -25
    arc_1_15_13  connected_order_arc_910  -13
    arc_1_15_13  in_degree_1069  1
    arc_1_15_13  out_degree_1080  1
    arc_1_15_13  original_T_including_depot_unload_1119  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_909  1
    load_1_15_13  free_load_conservation_1073  -1
    load_1_15_13  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_911  -25
    arc_1_15_14  connected_order_arc_912  -13
    arc_1_15_14  in_degree_1075  1
    arc_1_15_14  out_degree_1080  1
    arc_1_15_14  original_T_including_depot_unload_1119  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_911  1
    load_1_15_14  free_load_conservation_1079  -1
    load_1_15_14  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_913  -25
    arc_1_15_16  connected_order_arc_914  -13
    arc_1_15_16  out_degree_1080  1
    arc_1_15_16  in_degree_1087  1
    arc_1_15_16  original_T_including_depot_unload_1119  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_913  1
    load_1_15_16  free_load_conservation_1085  1
    load_1_15_16  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_915  -25
    arc_1_15_17  connected_order_arc_916  -13
    arc_1_15_17  out_degree_1080  1
    arc_1_15_17  in_degree_1093  1
    arc_1_15_17  original_T_including_depot_unload_1119  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_915  1
    load_1_15_17  free_load_conservation_1085  1
    load_1_15_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_917  -25
    arc_1_15_18  connected_order_arc_918  -13
    arc_1_15_18  out_degree_1080  1
    arc_1_15_18  in_degree_1099  1
    arc_1_15_18  original_T_including_depot_unload_1119  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_917  1
    load_1_15_18  free_load_conservation_1085  1
    load_1_15_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_919  -25
    arc_1_15_19  connected_order_arc_920  -13
    arc_1_15_19  out_degree_1080  1
    arc_1_15_19  in_degree_1105  1
    arc_1_15_19  original_T_including_depot_unload_1119  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_919  1
    load_1_15_19  free_load_conservation_1085  1
    load_1_15_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_921  -25
    arc_1_15_20  connected_order_arc_922  -13
    arc_1_15_20  out_degree_1080  1
    arc_1_15_20  in_degree_1111  1
    arc_1_15_20  original_T_including_depot_unload_1119  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_921  1
    load_1_15_20  free_load_conservation_1085  1
    load_1_15_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_923  -25
    arc_1_16_0  depot_return_or_bypass_1039  1
    arc_1_16_0  out_degree_1086  1
    arc_1_16_0  original_T_including_depot_unload_1119  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_923  1
    load_1_16_0  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_924  -25
    arc_1_16_6  connected_order_arc_925  -13
    arc_1_16_6  in_degree_1041  1
    arc_1_16_6  out_degree_1086  1
    arc_1_16_6  original_T_including_depot_unload_1119  1.5826657352191260e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_924  1
    load_1_16_6  segment_load_conservation_1044  -1
    load_1_16_6  segment_prefix_lb_1045  1
    load_1_16_6  segment_prefix_ub_1046  1
    load_1_16_6  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_926  -25
    arc_1_16_7  connected_order_arc_927  -13
    arc_1_16_7  in_degree_1048  1
    arc_1_16_7  out_degree_1086  1
    arc_1_16_7  original_T_including_depot_unload_1119  1.3825747156698872e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_926  1
    load_1_16_7  segment_load_conservation_1051  -1
    load_1_16_7  segment_prefix_lb_1052  1
    load_1_16_7  segment_prefix_ub_1053  1
    load_1_16_7  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_928  -25
    arc_1_16_8  connected_order_arc_929  -13
    arc_1_16_8  in_degree_1055  1
    arc_1_16_8  out_degree_1086  1
    arc_1_16_8  original_T_including_depot_unload_1119  6.4732789246105290e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_928  1
    load_1_16_8  segment_load_conservation_1058  -1
    load_1_16_8  segment_prefix_lb_1059  1
    load_1_16_8  segment_prefix_ub_1060  1
    load_1_16_8  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_930  -25
    arc_1_16_9  connected_order_arc_931  -13
    arc_1_16_9  in_degree_1062  1
    arc_1_16_9  out_degree_1086  1
    arc_1_16_9  original_T_including_depot_unload_1119  6.3069852135268593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_930  1
    load_1_16_9  segment_load_conservation_1065  -1
    load_1_16_9  segment_prefix_lb_1066  1
    load_1_16_9  segment_prefix_ub_1067  1
    load_1_16_9  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_932  -25
    arc_1_16_13  connected_order_arc_933  -13
    arc_1_16_13  in_degree_1069  1
    arc_1_16_13  out_degree_1086  1
    arc_1_16_13  original_T_including_depot_unload_1119  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_932  1
    load_1_16_13  free_load_conservation_1073  -1
    load_1_16_13  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_934  -25
    arc_1_16_14  connected_order_arc_935  -13
    arc_1_16_14  in_degree_1075  1
    arc_1_16_14  out_degree_1086  1
    arc_1_16_14  original_T_including_depot_unload_1119  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_934  1
    load_1_16_14  free_load_conservation_1079  -1
    load_1_16_14  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_936  -25
    arc_1_16_15  connected_order_arc_937  -13
    arc_1_16_15  in_degree_1081  1
    arc_1_16_15  out_degree_1086  1
    arc_1_16_15  original_T_including_depot_unload_1119  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_936  1
    load_1_16_15  free_load_conservation_1085  -1
    load_1_16_15  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_938  -25
    arc_1_16_17  connected_order_arc_939  -13
    arc_1_16_17  out_degree_1086  1
    arc_1_16_17  in_degree_1093  1
    arc_1_16_17  original_T_including_depot_unload_1119  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_938  1
    load_1_16_17  free_load_conservation_1091  1
    load_1_16_17  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_940  -25
    arc_1_16_18  connected_order_arc_941  -13
    arc_1_16_18  out_degree_1086  1
    arc_1_16_18  in_degree_1099  1
    arc_1_16_18  original_T_including_depot_unload_1119  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_940  1
    load_1_16_18  free_load_conservation_1091  1
    load_1_16_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_942  -25
    arc_1_16_19  connected_order_arc_943  -13
    arc_1_16_19  out_degree_1086  1
    arc_1_16_19  in_degree_1105  1
    arc_1_16_19  original_T_including_depot_unload_1119  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_942  1
    load_1_16_19  free_load_conservation_1091  1
    load_1_16_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_944  -25
    arc_1_16_20  connected_order_arc_945  -13
    arc_1_16_20  out_degree_1086  1
    arc_1_16_20  in_degree_1111  1
    arc_1_16_20  original_T_including_depot_unload_1119  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_944  1
    load_1_16_20  free_load_conservation_1091  1
    load_1_16_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_946  -25
    arc_1_17_0  depot_return_or_bypass_1039  1
    arc_1_17_0  out_degree_1092  1
    arc_1_17_0  original_T_including_depot_unload_1119  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_946  1
    load_1_17_0  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_947  -25
    arc_1_17_6  connected_order_arc_948  -13
    arc_1_17_6  in_degree_1041  1
    arc_1_17_6  out_degree_1092  1
    arc_1_17_6  original_T_including_depot_unload_1119  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_947  1
    load_1_17_6  segment_load_conservation_1044  -1
    load_1_17_6  segment_prefix_lb_1045  1
    load_1_17_6  segment_prefix_ub_1046  1
    load_1_17_6  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_949  -25
    arc_1_17_7  connected_order_arc_950  -13
    arc_1_17_7  in_degree_1048  1
    arc_1_17_7  out_degree_1092  1
    arc_1_17_7  original_T_including_depot_unload_1119  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_949  1
    load_1_17_7  segment_load_conservation_1051  -1
    load_1_17_7  segment_prefix_lb_1052  1
    load_1_17_7  segment_prefix_ub_1053  1
    load_1_17_7  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_951  -25
    arc_1_17_8  connected_order_arc_952  -13
    arc_1_17_8  in_degree_1055  1
    arc_1_17_8  out_degree_1092  1
    arc_1_17_8  original_T_including_depot_unload_1119  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_951  1
    load_1_17_8  segment_load_conservation_1058  -1
    load_1_17_8  segment_prefix_lb_1059  1
    load_1_17_8  segment_prefix_ub_1060  1
    load_1_17_8  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_953  -25
    arc_1_17_9  connected_order_arc_954  -13
    arc_1_17_9  in_degree_1062  1
    arc_1_17_9  out_degree_1092  1
    arc_1_17_9  original_T_including_depot_unload_1119  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_953  1
    load_1_17_9  segment_load_conservation_1065  -1
    load_1_17_9  segment_prefix_lb_1066  1
    load_1_17_9  segment_prefix_ub_1067  1
    load_1_17_9  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_955  -25
    arc_1_17_13  connected_order_arc_956  -13
    arc_1_17_13  in_degree_1069  1
    arc_1_17_13  out_degree_1092  1
    arc_1_17_13  original_T_including_depot_unload_1119  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_955  1
    load_1_17_13  free_load_conservation_1073  -1
    load_1_17_13  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_957  -25
    arc_1_17_14  connected_order_arc_958  -13
    arc_1_17_14  in_degree_1075  1
    arc_1_17_14  out_degree_1092  1
    arc_1_17_14  original_T_including_depot_unload_1119  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_957  1
    load_1_17_14  free_load_conservation_1079  -1
    load_1_17_14  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_959  -25
    arc_1_17_15  connected_order_arc_960  -13
    arc_1_17_15  in_degree_1081  1
    arc_1_17_15  out_degree_1092  1
    arc_1_17_15  original_T_including_depot_unload_1119  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_959  1
    load_1_17_15  free_load_conservation_1085  -1
    load_1_17_15  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_961  -25
    arc_1_17_16  connected_order_arc_962  -13
    arc_1_17_16  in_degree_1087  1
    arc_1_17_16  out_degree_1092  1
    arc_1_17_16  original_T_including_depot_unload_1119  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_961  1
    load_1_17_16  free_load_conservation_1091  -1
    load_1_17_16  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_963  -25
    arc_1_17_18  connected_order_arc_964  -13
    arc_1_17_18  out_degree_1092  1
    arc_1_17_18  in_degree_1099  1
    arc_1_17_18  original_T_including_depot_unload_1119  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_963  1
    load_1_17_18  free_load_conservation_1097  1
    load_1_17_18  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_965  -25
    arc_1_17_19  connected_order_arc_966  -13
    arc_1_17_19  out_degree_1092  1
    arc_1_17_19  in_degree_1105  1
    arc_1_17_19  original_T_including_depot_unload_1119  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_965  1
    load_1_17_19  free_load_conservation_1097  1
    load_1_17_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_967  -25
    arc_1_17_20  connected_order_arc_968  -13
    arc_1_17_20  out_degree_1092  1
    arc_1_17_20  in_degree_1111  1
    arc_1_17_20  original_T_including_depot_unload_1119  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_967  1
    load_1_17_20  free_load_conservation_1097  1
    load_1_17_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_969  -25
    arc_1_18_0  depot_return_or_bypass_1039  1
    arc_1_18_0  out_degree_1098  1
    arc_1_18_0  original_T_including_depot_unload_1119  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_969  1
    load_1_18_0  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_970  -25
    arc_1_18_6  connected_order_arc_971  -13
    arc_1_18_6  in_degree_1041  1
    arc_1_18_6  out_degree_1098  1
    arc_1_18_6  original_T_including_depot_unload_1119  1.5825017171049274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_970  1
    load_1_18_6  segment_load_conservation_1044  -1
    load_1_18_6  segment_prefix_lb_1045  1
    load_1_18_6  segment_prefix_ub_1046  1
    load_1_18_6  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_972  -25
    arc_1_18_7  connected_order_arc_973  -13
    arc_1_18_7  in_degree_1048  1
    arc_1_18_7  out_degree_1098  1
    arc_1_18_7  original_T_including_depot_unload_1119  1.3842338084916330e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_972  1
    load_1_18_7  segment_load_conservation_1051  -1
    load_1_18_7  segment_prefix_lb_1052  1
    load_1_18_7  segment_prefix_ub_1053  1
    load_1_18_7  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_974  -25
    arc_1_18_8  connected_order_arc_975  -13
    arc_1_18_8  in_degree_1055  1
    arc_1_18_8  out_degree_1098  1
    arc_1_18_8  original_T_including_depot_unload_1119  6.4850607840217310e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_974  1
    load_1_18_8  segment_load_conservation_1058  -1
    load_1_18_8  segment_prefix_lb_1059  1
    load_1_18_8  segment_prefix_ub_1060  1
    load_1_18_8  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_976  -25
    arc_1_18_9  connected_order_arc_977  -13
    arc_1_18_9  in_degree_1062  1
    arc_1_18_9  out_degree_1098  1
    arc_1_18_9  original_T_including_depot_unload_1119  6.3119444979991374e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_976  1
    load_1_18_9  segment_load_conservation_1065  -1
    load_1_18_9  segment_prefix_lb_1066  1
    load_1_18_9  segment_prefix_ub_1067  1
    load_1_18_9  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_978  -25
    arc_1_18_13  connected_order_arc_979  -13
    arc_1_18_13  in_degree_1069  1
    arc_1_18_13  out_degree_1098  1
    arc_1_18_13  original_T_including_depot_unload_1119  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_978  1
    load_1_18_13  free_load_conservation_1073  -1
    load_1_18_13  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_980  -25
    arc_1_18_14  connected_order_arc_981  -13
    arc_1_18_14  in_degree_1075  1
    arc_1_18_14  out_degree_1098  1
    arc_1_18_14  original_T_including_depot_unload_1119  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_980  1
    load_1_18_14  free_load_conservation_1079  -1
    load_1_18_14  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_982  -25
    arc_1_18_15  connected_order_arc_983  -13
    arc_1_18_15  in_degree_1081  1
    arc_1_18_15  out_degree_1098  1
    arc_1_18_15  original_T_including_depot_unload_1119  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_982  1
    load_1_18_15  free_load_conservation_1085  -1
    load_1_18_15  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_984  -25
    arc_1_18_16  connected_order_arc_985  -13
    arc_1_18_16  in_degree_1087  1
    arc_1_18_16  out_degree_1098  1
    arc_1_18_16  original_T_including_depot_unload_1119  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_984  1
    load_1_18_16  free_load_conservation_1091  -1
    load_1_18_16  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_986  -25
    arc_1_18_17  connected_order_arc_987  -13
    arc_1_18_17  in_degree_1093  1
    arc_1_18_17  out_degree_1098  1
    arc_1_18_17  original_T_including_depot_unload_1119  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_986  1
    load_1_18_17  free_load_conservation_1097  -1
    load_1_18_17  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_988  -25
    arc_1_18_19  connected_order_arc_989  -13
    arc_1_18_19  out_degree_1098  1
    arc_1_18_19  in_degree_1105  1
    arc_1_18_19  original_T_including_depot_unload_1119  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_988  1
    load_1_18_19  free_load_conservation_1103  1
    load_1_18_19  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_990  -25
    arc_1_18_20  connected_order_arc_991  -13
    arc_1_18_20  out_degree_1098  1
    arc_1_18_20  in_degree_1111  1
    arc_1_18_20  original_T_including_depot_unload_1119  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_990  1
    load_1_18_20  free_load_conservation_1103  1
    load_1_18_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_992  -25
    arc_1_19_0  depot_return_or_bypass_1039  1
    arc_1_19_0  out_degree_1104  1
    arc_1_19_0  original_T_including_depot_unload_1119  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_992  1
    load_1_19_0  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_993  -25
    arc_1_19_6  connected_order_arc_994  -13
    arc_1_19_6  in_degree_1041  1
    arc_1_19_6  out_degree_1104  1
    arc_1_19_6  original_T_including_depot_unload_1119  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_993  1
    load_1_19_6  segment_load_conservation_1044  -1
    load_1_19_6  segment_prefix_lb_1045  1
    load_1_19_6  segment_prefix_ub_1046  1
    load_1_19_6  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_995  -25
    arc_1_19_7  connected_order_arc_996  -13
    arc_1_19_7  in_degree_1048  1
    arc_1_19_7  out_degree_1104  1
    arc_1_19_7  original_T_including_depot_unload_1119  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_995  1
    load_1_19_7  segment_load_conservation_1051  -1
    load_1_19_7  segment_prefix_lb_1052  1
    load_1_19_7  segment_prefix_ub_1053  1
    load_1_19_7  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_997  -25
    arc_1_19_8  connected_order_arc_998  -13
    arc_1_19_8  in_degree_1055  1
    arc_1_19_8  out_degree_1104  1
    arc_1_19_8  original_T_including_depot_unload_1119  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_997  1
    load_1_19_8  segment_load_conservation_1058  -1
    load_1_19_8  segment_prefix_lb_1059  1
    load_1_19_8  segment_prefix_ub_1060  1
    load_1_19_8  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_999  -25
    arc_1_19_9  connected_order_arc_1000  -13
    arc_1_19_9  in_degree_1062  1
    arc_1_19_9  out_degree_1104  1
    arc_1_19_9  original_T_including_depot_unload_1119  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_999  1
    load_1_19_9  segment_load_conservation_1065  -1
    load_1_19_9  segment_prefix_lb_1066  1
    load_1_19_9  segment_prefix_ub_1067  1
    load_1_19_9  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1001  -25
    arc_1_19_13  connected_order_arc_1002  -13
    arc_1_19_13  in_degree_1069  1
    arc_1_19_13  out_degree_1104  1
    arc_1_19_13  original_T_including_depot_unload_1119  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1001  1
    load_1_19_13  free_load_conservation_1073  -1
    load_1_19_13  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1003  -25
    arc_1_19_14  connected_order_arc_1004  -13
    arc_1_19_14  in_degree_1075  1
    arc_1_19_14  out_degree_1104  1
    arc_1_19_14  original_T_including_depot_unload_1119  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1003  1
    load_1_19_14  free_load_conservation_1079  -1
    load_1_19_14  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1005  -25
    arc_1_19_15  connected_order_arc_1006  -13
    arc_1_19_15  in_degree_1081  1
    arc_1_19_15  out_degree_1104  1
    arc_1_19_15  original_T_including_depot_unload_1119  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1005  1
    load_1_19_15  free_load_conservation_1085  -1
    load_1_19_15  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1007  -25
    arc_1_19_16  connected_order_arc_1008  -13
    arc_1_19_16  in_degree_1087  1
    arc_1_19_16  out_degree_1104  1
    arc_1_19_16  original_T_including_depot_unload_1119  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1007  1
    load_1_19_16  free_load_conservation_1091  -1
    load_1_19_16  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1009  -25
    arc_1_19_17  connected_order_arc_1010  -13
    arc_1_19_17  in_degree_1093  1
    arc_1_19_17  out_degree_1104  1
    arc_1_19_17  original_T_including_depot_unload_1119  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1009  1
    load_1_19_17  free_load_conservation_1097  -1
    load_1_19_17  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1011  -25
    arc_1_19_18  connected_order_arc_1012  -13
    arc_1_19_18  in_degree_1099  1
    arc_1_19_18  out_degree_1104  1
    arc_1_19_18  original_T_including_depot_unload_1119  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1011  1
    load_1_19_18  free_load_conservation_1103  -1
    load_1_19_18  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1013  -25
    arc_1_19_20  connected_order_arc_1014  -13
    arc_1_19_20  out_degree_1104  1
    arc_1_19_20  in_degree_1111  1
    arc_1_19_20  original_T_including_depot_unload_1119  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1013  1
    load_1_19_20  free_load_conservation_1109  1
    load_1_19_20  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1015  -25
    arc_1_20_0  depot_return_or_bypass_1039  1
    arc_1_20_0  out_degree_1110  1
    arc_1_20_0  original_T_including_depot_unload_1119  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1015  1
    load_1_20_0  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1016  -25
    arc_1_20_6  connected_order_arc_1017  -13
    arc_1_20_6  in_degree_1041  1
    arc_1_20_6  out_degree_1110  1
    arc_1_20_6  original_T_including_depot_unload_1119  1.5814425672683194e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1016  1
    load_1_20_6  segment_load_conservation_1044  -1
    load_1_20_6  segment_prefix_lb_1045  1
    load_1_20_6  segment_prefix_ub_1046  1
    load_1_20_6  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1018  -25
    arc_1_20_7  connected_order_arc_1019  -13
    arc_1_20_7  in_degree_1048  1
    arc_1_20_7  out_degree_1110  1
    arc_1_20_7  original_T_including_depot_unload_1119  1.3848663974280498e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1018  1
    load_1_20_7  segment_load_conservation_1051  -1
    load_1_20_7  segment_prefix_lb_1052  1
    load_1_20_7  segment_prefix_ub_1053  1
    load_1_20_7  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1020  -25
    arc_1_20_8  connected_order_arc_1021  -13
    arc_1_20_8  in_degree_1055  1
    arc_1_20_8  out_degree_1110  1
    arc_1_20_8  original_T_including_depot_unload_1119  6.4832473911284285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1020  1
    load_1_20_8  segment_load_conservation_1058  -1
    load_1_20_8  segment_prefix_lb_1059  1
    load_1_20_8  segment_prefix_ub_1060  1
    load_1_20_8  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1022  -25
    arc_1_20_9  connected_order_arc_1023  -13
    arc_1_20_9  in_degree_1062  1
    arc_1_20_9  out_degree_1110  1
    arc_1_20_9  original_T_including_depot_unload_1119  6.3046739375549225e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1022  1
    load_1_20_9  segment_load_conservation_1065  -1
    load_1_20_9  segment_prefix_lb_1066  1
    load_1_20_9  segment_prefix_ub_1067  1
    load_1_20_9  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1024  -25
    arc_1_20_13  connected_order_arc_1025  -13
    arc_1_20_13  in_degree_1069  1
    arc_1_20_13  out_degree_1110  1
    arc_1_20_13  original_T_including_depot_unload_1119  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1024  1
    load_1_20_13  free_load_conservation_1073  -1
    load_1_20_13  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1026  -25
    arc_1_20_14  connected_order_arc_1027  -13
    arc_1_20_14  in_degree_1075  1
    arc_1_20_14  out_degree_1110  1
    arc_1_20_14  original_T_including_depot_unload_1119  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1026  1
    load_1_20_14  free_load_conservation_1079  -1
    load_1_20_14  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1028  -25
    arc_1_20_15  connected_order_arc_1029  -13
    arc_1_20_15  in_degree_1081  1
    arc_1_20_15  out_degree_1110  1
    arc_1_20_15  original_T_including_depot_unload_1119  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1028  1
    load_1_20_15  free_load_conservation_1085  -1
    load_1_20_15  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1030  -25
    arc_1_20_16  connected_order_arc_1031  -13
    arc_1_20_16  in_degree_1087  1
    arc_1_20_16  out_degree_1110  1
    arc_1_20_16  original_T_including_depot_unload_1119  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1030  1
    load_1_20_16  free_load_conservation_1091  -1
    load_1_20_16  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1032  -25
    arc_1_20_17  connected_order_arc_1033  -13
    arc_1_20_17  in_degree_1093  1
    arc_1_20_17  out_degree_1110  1
    arc_1_20_17  original_T_including_depot_unload_1119  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1032  1
    load_1_20_17  free_load_conservation_1097  -1
    load_1_20_17  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1034  -25
    arc_1_20_18  connected_order_arc_1035  -13
    arc_1_20_18  in_degree_1099  1
    arc_1_20_18  out_degree_1110  1
    arc_1_20_18  original_T_including_depot_unload_1119  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1034  1
    load_1_20_18  free_load_conservation_1103  -1
    load_1_20_18  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1036  -25
    arc_1_20_19  connected_order_arc_1037  -13
    arc_1_20_19  in_degree_1105  1
    arc_1_20_19  out_degree_1110  1
    arc_1_20_19  original_T_including_depot_unload_1119  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1036  1
    load_1_20_19  free_load_conservation_1109  -1
    load_1_20_19  free_load_conservation_1115  1
    visit_2_10  out_degree_1365  -1
    visit_2_10  in_degree_1366  -1
    visit_2_10  order_active_lb_1367  -1
    visit_2_10  order_active_ub_1368  -11
    order_2_10  connected_order_arc_1134  -1
    order_2_10  connected_order_arc_1136  -1
    order_2_10  connected_order_arc_1138  -1
    order_2_10  connected_order_arc_1140  -1
    order_2_10  connected_order_arc_1142  -1
    order_2_10  connected_order_arc_1144  -1
    order_2_10  connected_order_arc_1146  -1
    order_2_10  connected_order_arc_1148  -1
    order_2_10  connected_order_arc_1150  -1
    order_2_10  connected_order_arc_1152  -1
    order_2_10  connected_order_arc_1155  1
    order_2_10  connected_order_arc_1176  1
    order_2_10  connected_order_arc_1197  1
    order_2_10  connected_order_arc_1218  1
    order_2_10  connected_order_arc_1239  1
    order_2_10  connected_order_arc_1260  1
    order_2_10  connected_order_arc_1281  1
    order_2_10  connected_order_arc_1302  1
    order_2_10  connected_order_arc_1323  1
    order_2_10  connected_order_arc_1344  1
    order_2_10  order_active_lb_1367  1
    order_2_10  order_active_ub_1368  1
    order_2_10  fixed_segment_relative_order_1434  -1
    visit_2_11  out_degree_1372  -1
    visit_2_11  in_degree_1373  -1
    visit_2_11  order_active_lb_1374  -1
    visit_2_11  order_active_ub_1375  -11
    order_2_11  connected_order_arc_1134  1
    order_2_11  connected_order_arc_1155  -1
    order_2_11  connected_order_arc_1157  -1
    order_2_11  connected_order_arc_1159  -1
    order_2_11  connected_order_arc_1161  -1
    order_2_11  connected_order_arc_1163  -1
    order_2_11  connected_order_arc_1165  -1
    order_2_11  connected_order_arc_1167  -1
    order_2_11  connected_order_arc_1169  -1
    order_2_11  connected_order_arc_1171  -1
    order_2_11  connected_order_arc_1173  -1
    order_2_11  connected_order_arc_1178  1
    order_2_11  connected_order_arc_1199  1
    order_2_11  connected_order_arc_1220  1
    order_2_11  connected_order_arc_1241  1
    order_2_11  connected_order_arc_1262  1
    order_2_11  connected_order_arc_1283  1
    order_2_11  connected_order_arc_1304  1
    order_2_11  connected_order_arc_1325  1
    order_2_11  connected_order_arc_1346  1
    order_2_11  order_active_lb_1374  1
    order_2_11  order_active_ub_1375  1
    order_2_11  fixed_segment_relative_order_1434  1
    order_2_11  fixed_segment_relative_order_1435  -1
    visit_2_12  out_degree_1379  -1
    visit_2_12  in_degree_1380  -1
    visit_2_12  order_active_lb_1381  -1
    visit_2_12  order_active_ub_1382  -11
    order_2_12  connected_order_arc_1136  1
    order_2_12  connected_order_arc_1157  1
    order_2_12  connected_order_arc_1176  -1
    order_2_12  connected_order_arc_1178  -1
    order_2_12  connected_order_arc_1180  -1
    order_2_12  connected_order_arc_1182  -1
    order_2_12  connected_order_arc_1184  -1
    order_2_12  connected_order_arc_1186  -1
    order_2_12  connected_order_arc_1188  -1
    order_2_12  connected_order_arc_1190  -1
    order_2_12  connected_order_arc_1192  -1
    order_2_12  connected_order_arc_1194  -1
    order_2_12  connected_order_arc_1201  1
    order_2_12  connected_order_arc_1222  1
    order_2_12  connected_order_arc_1243  1
    order_2_12  connected_order_arc_1264  1
    order_2_12  connected_order_arc_1285  1
    order_2_12  connected_order_arc_1306  1
    order_2_12  connected_order_arc_1327  1
    order_2_12  connected_order_arc_1348  1
    order_2_12  order_active_lb_1381  1
    order_2_12  order_active_ub_1382  1
    order_2_12  fixed_segment_relative_order_1435  1
    visit_2_13  out_degree_1386  -1
    visit_2_13  in_degree_1387  -1
    visit_2_13  order_active_lb_1388  -1
    visit_2_13  order_active_ub_1389  -11
    visit_2_13  service_visit_def_1390  -1
    order_2_13  connected_order_arc_1138  1
    order_2_13  connected_order_arc_1159  1
    order_2_13  connected_order_arc_1180  1
    order_2_13  connected_order_arc_1197  -1
    order_2_13  connected_order_arc_1199  -1
    order_2_13  connected_order_arc_1201  -1
    order_2_13  connected_order_arc_1203  -1
    order_2_13  connected_order_arc_1205  -1
    order_2_13  connected_order_arc_1207  -1
    order_2_13  connected_order_arc_1209  -1
    order_2_13  connected_order_arc_1211  -1
    order_2_13  connected_order_arc_1213  -1
    order_2_13  connected_order_arc_1215  -1
    order_2_13  connected_order_arc_1224  1
    order_2_13  connected_order_arc_1245  1
    order_2_13  connected_order_arc_1266  1
    order_2_13  connected_order_arc_1287  1
    order_2_13  connected_order_arc_1308  1
    order_2_13  connected_order_arc_1329  1
    order_2_13  connected_order_arc_1350  1
    order_2_13  order_active_lb_1388  1
    order_2_13  order_active_ub_1389  1
    visit_2_14  out_degree_1392  -1
    visit_2_14  in_degree_1393  -1
    visit_2_14  order_active_lb_1394  -1
    visit_2_14  order_active_ub_1395  -11
    visit_2_14  service_visit_def_1396  -1
    order_2_14  connected_order_arc_1140  1
    order_2_14  connected_order_arc_1161  1
    order_2_14  connected_order_arc_1182  1
    order_2_14  connected_order_arc_1203  1
    order_2_14  connected_order_arc_1218  -1
    order_2_14  connected_order_arc_1220  -1
    order_2_14  connected_order_arc_1222  -1
    order_2_14  connected_order_arc_1224  -1
    order_2_14  connected_order_arc_1226  -1
    order_2_14  connected_order_arc_1228  -1
    order_2_14  connected_order_arc_1230  -1
    order_2_14  connected_order_arc_1232  -1
    order_2_14  connected_order_arc_1234  -1
    order_2_14  connected_order_arc_1236  -1
    order_2_14  connected_order_arc_1247  1
    order_2_14  connected_order_arc_1268  1
    order_2_14  connected_order_arc_1289  1
    order_2_14  connected_order_arc_1310  1
    order_2_14  connected_order_arc_1331  1
    order_2_14  connected_order_arc_1352  1
    order_2_14  order_active_lb_1394  1
    order_2_14  order_active_ub_1395  1
    visit_2_15  out_degree_1398  -1
    visit_2_15  in_degree_1399  -1
    visit_2_15  order_active_lb_1400  -1
    visit_2_15  order_active_ub_1401  -11
    visit_2_15  service_visit_def_1402  -1
    order_2_15  connected_order_arc_1142  1
    order_2_15  connected_order_arc_1163  1
    order_2_15  connected_order_arc_1184  1
    order_2_15  connected_order_arc_1205  1
    order_2_15  connected_order_arc_1226  1
    order_2_15  connected_order_arc_1239  -1
    order_2_15  connected_order_arc_1241  -1
    order_2_15  connected_order_arc_1243  -1
    order_2_15  connected_order_arc_1245  -1
    order_2_15  connected_order_arc_1247  -1
    order_2_15  connected_order_arc_1249  -1
    order_2_15  connected_order_arc_1251  -1
    order_2_15  connected_order_arc_1253  -1
    order_2_15  connected_order_arc_1255  -1
    order_2_15  connected_order_arc_1257  -1
    order_2_15  connected_order_arc_1270  1
    order_2_15  connected_order_arc_1291  1
    order_2_15  connected_order_arc_1312  1
    order_2_15  connected_order_arc_1333  1
    order_2_15  connected_order_arc_1354  1
    order_2_15  order_active_lb_1400  1
    order_2_15  order_active_ub_1401  1
    visit_2_16  out_degree_1404  -1
    visit_2_16  in_degree_1405  -1
    visit_2_16  order_active_lb_1406  -1
    visit_2_16  order_active_ub_1407  -11
    visit_2_16  service_visit_def_1408  -1
    order_2_16  connected_order_arc_1144  1
    order_2_16  connected_order_arc_1165  1
    order_2_16  connected_order_arc_1186  1
    order_2_16  connected_order_arc_1207  1
    order_2_16  connected_order_arc_1228  1
    order_2_16  connected_order_arc_1249  1
    order_2_16  connected_order_arc_1260  -1
    order_2_16  connected_order_arc_1262  -1
    order_2_16  connected_order_arc_1264  -1
    order_2_16  connected_order_arc_1266  -1
    order_2_16  connected_order_arc_1268  -1
    order_2_16  connected_order_arc_1270  -1
    order_2_16  connected_order_arc_1272  -1
    order_2_16  connected_order_arc_1274  -1
    order_2_16  connected_order_arc_1276  -1
    order_2_16  connected_order_arc_1278  -1
    order_2_16  connected_order_arc_1293  1
    order_2_16  connected_order_arc_1314  1
    order_2_16  connected_order_arc_1335  1
    order_2_16  connected_order_arc_1356  1
    order_2_16  order_active_lb_1406  1
    order_2_16  order_active_ub_1407  1
    visit_2_17  out_degree_1410  -1
    visit_2_17  in_degree_1411  -1
    visit_2_17  order_active_lb_1412  -1
    visit_2_17  order_active_ub_1413  -11
    visit_2_17  service_visit_def_1414  -1
    order_2_17  connected_order_arc_1146  1
    order_2_17  connected_order_arc_1167  1
    order_2_17  connected_order_arc_1188  1
    order_2_17  connected_order_arc_1209  1
    order_2_17  connected_order_arc_1230  1
    order_2_17  connected_order_arc_1251  1
    order_2_17  connected_order_arc_1272  1
    order_2_17  connected_order_arc_1281  -1
    order_2_17  connected_order_arc_1283  -1
    order_2_17  connected_order_arc_1285  -1
    order_2_17  connected_order_arc_1287  -1
    order_2_17  connected_order_arc_1289  -1
    order_2_17  connected_order_arc_1291  -1
    order_2_17  connected_order_arc_1293  -1
    order_2_17  connected_order_arc_1295  -1
    order_2_17  connected_order_arc_1297  -1
    order_2_17  connected_order_arc_1299  -1
    order_2_17  connected_order_arc_1316  1
    order_2_17  connected_order_arc_1337  1
    order_2_17  connected_order_arc_1358  1
    order_2_17  order_active_lb_1412  1
    order_2_17  order_active_ub_1413  1
    visit_2_18  out_degree_1416  -1
    visit_2_18  in_degree_1417  -1
    visit_2_18  order_active_lb_1418  -1
    visit_2_18  order_active_ub_1419  -11
    visit_2_18  service_visit_def_1420  -1
    order_2_18  connected_order_arc_1148  1
    order_2_18  connected_order_arc_1169  1
    order_2_18  connected_order_arc_1190  1
    order_2_18  connected_order_arc_1211  1
    order_2_18  connected_order_arc_1232  1
    order_2_18  connected_order_arc_1253  1
    order_2_18  connected_order_arc_1274  1
    order_2_18  connected_order_arc_1295  1
    order_2_18  connected_order_arc_1302  -1
    order_2_18  connected_order_arc_1304  -1
    order_2_18  connected_order_arc_1306  -1
    order_2_18  connected_order_arc_1308  -1
    order_2_18  connected_order_arc_1310  -1
    order_2_18  connected_order_arc_1312  -1
    order_2_18  connected_order_arc_1314  -1
    order_2_18  connected_order_arc_1316  -1
    order_2_18  connected_order_arc_1318  -1
    order_2_18  connected_order_arc_1320  -1
    order_2_18  connected_order_arc_1339  1
    order_2_18  connected_order_arc_1360  1
    order_2_18  order_active_lb_1418  1
    order_2_18  order_active_ub_1419  1
    visit_2_19  out_degree_1422  -1
    visit_2_19  in_degree_1423  -1
    visit_2_19  order_active_lb_1424  -1
    visit_2_19  order_active_ub_1425  -11
    visit_2_19  service_visit_def_1426  -1
    order_2_19  connected_order_arc_1150  1
    order_2_19  connected_order_arc_1171  1
    order_2_19  connected_order_arc_1192  1
    order_2_19  connected_order_arc_1213  1
    order_2_19  connected_order_arc_1234  1
    order_2_19  connected_order_arc_1255  1
    order_2_19  connected_order_arc_1276  1
    order_2_19  connected_order_arc_1297  1
    order_2_19  connected_order_arc_1318  1
    order_2_19  connected_order_arc_1323  -1
    order_2_19  connected_order_arc_1325  -1
    order_2_19  connected_order_arc_1327  -1
    order_2_19  connected_order_arc_1329  -1
    order_2_19  connected_order_arc_1331  -1
    order_2_19  connected_order_arc_1333  -1
    order_2_19  connected_order_arc_1335  -1
    order_2_19  connected_order_arc_1337  -1
    order_2_19  connected_order_arc_1339  -1
    order_2_19  connected_order_arc_1341  -1
    order_2_19  connected_order_arc_1362  1
    order_2_19  order_active_lb_1424  1
    order_2_19  order_active_ub_1425  1
    visit_2_20  out_degree_1428  -1
    visit_2_20  in_degree_1429  -1
    visit_2_20  order_active_lb_1430  -1
    visit_2_20  order_active_ub_1431  -11
    visit_2_20  service_visit_def_1432  -1
    order_2_20  connected_order_arc_1152  1
    order_2_20  connected_order_arc_1173  1
    order_2_20  connected_order_arc_1194  1
    order_2_20  connected_order_arc_1215  1
    order_2_20  connected_order_arc_1236  1
    order_2_20  connected_order_arc_1257  1
    order_2_20  connected_order_arc_1278  1
    order_2_20  connected_order_arc_1299  1
    order_2_20  connected_order_arc_1320  1
    order_2_20  connected_order_arc_1341  1
    order_2_20  connected_order_arc_1344  -1
    order_2_20  connected_order_arc_1346  -1
    order_2_20  connected_order_arc_1348  -1
    order_2_20  connected_order_arc_1350  -1
    order_2_20  connected_order_arc_1352  -1
    order_2_20  connected_order_arc_1354  -1
    order_2_20  connected_order_arc_1356  -1
    order_2_20  connected_order_arc_1358  -1
    order_2_20  connected_order_arc_1360  -1
    order_2_20  connected_order_arc_1362  -1
    order_2_20  order_active_lb_1430  1
    order_2_20  order_active_ub_1431  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1120  -30
    arc_2_0_0  depot_departure_or_bypass_1363  1
    arc_2_0_0  depot_return_or_bypass_1364  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1121  -30
    arc_2_0_10  depot_departure_or_bypass_1363  1
    arc_2_0_10  in_degree_1366  1
    arc_2_0_10  original_T_including_depot_unload_1436  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1121  1
    load_2_0_10  segment_load_conservation_1369  -1
    load_2_0_10  segment_prefix_lb_1370  1
    load_2_0_10  segment_prefix_ub_1371  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1122  -30
    arc_2_0_11  depot_departure_or_bypass_1363  1
    arc_2_0_11  in_degree_1373  1
    arc_2_0_11  original_T_including_depot_unload_1436  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1122  1
    load_2_0_11  segment_load_conservation_1376  -1
    load_2_0_11  segment_prefix_lb_1377  1
    load_2_0_11  segment_prefix_ub_1378  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1123  -30
    arc_2_0_12  depot_departure_or_bypass_1363  1
    arc_2_0_12  in_degree_1380  1
    arc_2_0_12  original_T_including_depot_unload_1436  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1123  1
    load_2_0_12  segment_load_conservation_1383  -1
    load_2_0_12  segment_prefix_lb_1384  1
    load_2_0_12  segment_prefix_ub_1385  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1124  -30
    arc_2_0_13  depot_departure_or_bypass_1363  1
    arc_2_0_13  in_degree_1387  1
    arc_2_0_13  original_T_including_depot_unload_1436  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1124  1
    load_2_0_13  free_load_conservation_1391  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1125  -30
    arc_2_0_14  depot_departure_or_bypass_1363  1
    arc_2_0_14  in_degree_1393  1
    arc_2_0_14  original_T_including_depot_unload_1436  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1125  1
    load_2_0_14  free_load_conservation_1397  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1126  -30
    arc_2_0_15  depot_departure_or_bypass_1363  1
    arc_2_0_15  in_degree_1399  1
    arc_2_0_15  original_T_including_depot_unload_1436  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1126  1
    load_2_0_15  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1127  -30
    arc_2_0_16  depot_departure_or_bypass_1363  1
    arc_2_0_16  in_degree_1405  1
    arc_2_0_16  original_T_including_depot_unload_1436  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1127  1
    load_2_0_16  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1128  -30
    arc_2_0_17  depot_departure_or_bypass_1363  1
    arc_2_0_17  in_degree_1411  1
    arc_2_0_17  original_T_including_depot_unload_1436  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1128  1
    load_2_0_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1129  -30
    arc_2_0_18  depot_departure_or_bypass_1363  1
    arc_2_0_18  in_degree_1417  1
    arc_2_0_18  original_T_including_depot_unload_1436  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1129  1
    load_2_0_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1130  -30
    arc_2_0_19  depot_departure_or_bypass_1363  1
    arc_2_0_19  in_degree_1423  1
    arc_2_0_19  original_T_including_depot_unload_1436  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1130  1
    load_2_0_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1131  -30
    arc_2_0_20  depot_departure_or_bypass_1363  1
    arc_2_0_20  in_degree_1429  1
    arc_2_0_20  original_T_including_depot_unload_1436  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1131  1
    load_2_0_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1132  -30
    arc_2_10_0  depot_return_or_bypass_1364  1
    arc_2_10_0  out_degree_1365  1
    arc_2_10_0  original_T_including_depot_unload_1436  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1132  1
    load_2_10_0  segment_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1133  -30
    arc_2_10_11  connected_order_arc_1134  -12
    arc_2_10_11  out_degree_1365  1
    arc_2_10_11  in_degree_1373  1
    arc_2_10_11  original_T_including_depot_unload_1436  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1133  1
    load_2_10_11  segment_load_conservation_1369  1
    load_2_10_11  segment_load_conservation_1376  -1
    load_2_10_11  segment_prefix_lb_1377  1
    load_2_10_11  segment_prefix_ub_1378  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1135  -30
    arc_2_10_12  connected_order_arc_1136  -12
    arc_2_10_12  out_degree_1365  1
    arc_2_10_12  in_degree_1380  1
    arc_2_10_12  original_T_including_depot_unload_1436  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1135  1
    load_2_10_12  segment_load_conservation_1369  1
    load_2_10_12  segment_load_conservation_1383  -1
    load_2_10_12  segment_prefix_lb_1384  1
    load_2_10_12  segment_prefix_ub_1385  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1137  -30
    arc_2_10_13  connected_order_arc_1138  -12
    arc_2_10_13  out_degree_1365  1
    arc_2_10_13  in_degree_1387  1
    arc_2_10_13  original_T_including_depot_unload_1436  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1137  1
    load_2_10_13  segment_load_conservation_1369  1
    load_2_10_13  free_load_conservation_1391  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1139  -30
    arc_2_10_14  connected_order_arc_1140  -12
    arc_2_10_14  out_degree_1365  1
    arc_2_10_14  in_degree_1393  1
    arc_2_10_14  original_T_including_depot_unload_1436  1.3060135543268104e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1139  1
    load_2_10_14  segment_load_conservation_1369  1
    load_2_10_14  free_load_conservation_1397  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1141  -30
    arc_2_10_15  connected_order_arc_1142  -12
    arc_2_10_15  out_degree_1365  1
    arc_2_10_15  in_degree_1399  1
    arc_2_10_15  original_T_including_depot_unload_1436  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1141  1
    load_2_10_15  segment_load_conservation_1369  1
    load_2_10_15  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1143  -30
    arc_2_10_16  connected_order_arc_1144  -12
    arc_2_10_16  out_degree_1365  1
    arc_2_10_16  in_degree_1405  1
    arc_2_10_16  original_T_including_depot_unload_1436  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1143  1
    load_2_10_16  segment_load_conservation_1369  1
    load_2_10_16  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1145  -30
    arc_2_10_17  connected_order_arc_1146  -12
    arc_2_10_17  out_degree_1365  1
    arc_2_10_17  in_degree_1411  1
    arc_2_10_17  original_T_including_depot_unload_1436  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1145  1
    load_2_10_17  segment_load_conservation_1369  1
    load_2_10_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1147  -30
    arc_2_10_18  connected_order_arc_1148  -12
    arc_2_10_18  out_degree_1365  1
    arc_2_10_18  in_degree_1417  1
    arc_2_10_18  original_T_including_depot_unload_1436  1.0464557570570403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1147  1
    load_2_10_18  segment_load_conservation_1369  1
    load_2_10_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1149  -30
    arc_2_10_19  connected_order_arc_1150  -12
    arc_2_10_19  out_degree_1365  1
    arc_2_10_19  in_degree_1423  1
    arc_2_10_19  original_T_including_depot_unload_1436  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1149  1
    load_2_10_19  segment_load_conservation_1369  1
    load_2_10_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1151  -30
    arc_2_10_20  connected_order_arc_1152  -12
    arc_2_10_20  out_degree_1365  1
    arc_2_10_20  in_degree_1429  1
    arc_2_10_20  original_T_including_depot_unload_1436  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1151  1
    load_2_10_20  segment_load_conservation_1369  1
    load_2_10_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1153  -30
    arc_2_11_0  depot_return_or_bypass_1364  1
    arc_2_11_0  out_degree_1372  1
    arc_2_11_0  original_T_including_depot_unload_1436  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1153  1
    load_2_11_0  segment_load_conservation_1376  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1154  -30
    arc_2_11_10  connected_order_arc_1155  -12
    arc_2_11_10  in_degree_1366  1
    arc_2_11_10  out_degree_1372  1
    arc_2_11_10  original_T_including_depot_unload_1436  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1154  1
    load_2_11_10  segment_load_conservation_1369  -1
    load_2_11_10  segment_prefix_lb_1370  1
    load_2_11_10  segment_prefix_ub_1371  1
    load_2_11_10  segment_load_conservation_1376  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1156  -30
    arc_2_11_12  connected_order_arc_1157  -12
    arc_2_11_12  out_degree_1372  1
    arc_2_11_12  in_degree_1380  1
    arc_2_11_12  original_T_including_depot_unload_1436  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1156  1
    load_2_11_12  segment_load_conservation_1376  1
    load_2_11_12  segment_load_conservation_1383  -1
    load_2_11_12  segment_prefix_lb_1384  1
    load_2_11_12  segment_prefix_ub_1385  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1158  -30
    arc_2_11_13  connected_order_arc_1159  -12
    arc_2_11_13  out_degree_1372  1
    arc_2_11_13  in_degree_1387  1
    arc_2_11_13  original_T_including_depot_unload_1436  2.0883063288244971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1158  1
    load_2_11_13  segment_load_conservation_1376  1
    load_2_11_13  free_load_conservation_1391  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1160  -30
    arc_2_11_14  connected_order_arc_1161  -12
    arc_2_11_14  out_degree_1372  1
    arc_2_11_14  in_degree_1393  1
    arc_2_11_14  original_T_including_depot_unload_1436  2.1385293969918903e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1160  1
    load_2_11_14  segment_load_conservation_1376  1
    load_2_11_14  free_load_conservation_1397  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1162  -30
    arc_2_11_15  connected_order_arc_1163  -12
    arc_2_11_15  out_degree_1372  1
    arc_2_11_15  in_degree_1399  1
    arc_2_11_15  original_T_including_depot_unload_1436  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1162  1
    load_2_11_15  segment_load_conservation_1376  1
    load_2_11_15  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1164  -30
    arc_2_11_16  connected_order_arc_1165  -12
    arc_2_11_16  out_degree_1372  1
    arc_2_11_16  in_degree_1405  1
    arc_2_11_16  original_T_including_depot_unload_1436  2.0400693679210435e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1164  1
    load_2_11_16  segment_load_conservation_1376  1
    load_2_11_16  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1166  -30
    arc_2_11_17  connected_order_arc_1167  -12
    arc_2_11_17  out_degree_1372  1
    arc_2_11_17  in_degree_1411  1
    arc_2_11_17  original_T_including_depot_unload_1436  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1166  1
    load_2_11_17  segment_load_conservation_1376  1
    load_2_11_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1168  -30
    arc_2_11_18  connected_order_arc_1169  -12
    arc_2_11_18  out_degree_1372  1
    arc_2_11_18  in_degree_1417  1
    arc_2_11_18  original_T_including_depot_unload_1436  2.0393331898049819e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1168  1
    load_2_11_18  segment_load_conservation_1376  1
    load_2_11_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1170  -30
    arc_2_11_19  connected_order_arc_1171  -12
    arc_2_11_19  out_degree_1372  1
    arc_2_11_19  in_degree_1423  1
    arc_2_11_19  original_T_including_depot_unload_1436  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1170  1
    load_2_11_19  segment_load_conservation_1376  1
    load_2_11_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1172  -30
    arc_2_11_20  connected_order_arc_1173  -12
    arc_2_11_20  out_degree_1372  1
    arc_2_11_20  in_degree_1429  1
    arc_2_11_20  original_T_including_depot_unload_1436  2.0381190522271584e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1172  1
    load_2_11_20  segment_load_conservation_1376  1
    load_2_11_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1174  -30
    arc_2_12_0  depot_return_or_bypass_1364  1
    arc_2_12_0  out_degree_1379  1
    arc_2_12_0  original_T_including_depot_unload_1436  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1174  1
    load_2_12_0  segment_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1175  -30
    arc_2_12_10  connected_order_arc_1176  -12
    arc_2_12_10  in_degree_1366  1
    arc_2_12_10  out_degree_1379  1
    arc_2_12_10  original_T_including_depot_unload_1436  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1175  1
    load_2_12_10  segment_load_conservation_1369  -1
    load_2_12_10  segment_prefix_lb_1370  1
    load_2_12_10  segment_prefix_ub_1371  1
    load_2_12_10  segment_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1177  -30
    arc_2_12_11  connected_order_arc_1178  -12
    arc_2_12_11  in_degree_1373  1
    arc_2_12_11  out_degree_1379  1
    arc_2_12_11  original_T_including_depot_unload_1436  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1177  1
    load_2_12_11  segment_load_conservation_1376  -1
    load_2_12_11  segment_prefix_lb_1377  1
    load_2_12_11  segment_prefix_ub_1378  1
    load_2_12_11  segment_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1179  -30
    arc_2_12_13  connected_order_arc_1180  -12
    arc_2_12_13  out_degree_1379  1
    arc_2_12_13  in_degree_1387  1
    arc_2_12_13  original_T_including_depot_unload_1436  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1179  1
    load_2_12_13  segment_load_conservation_1383  1
    load_2_12_13  free_load_conservation_1391  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1181  -30
    arc_2_12_14  connected_order_arc_1182  -12
    arc_2_12_14  out_degree_1379  1
    arc_2_12_14  in_degree_1393  1
    arc_2_12_14  original_T_including_depot_unload_1436  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1181  1
    load_2_12_14  segment_load_conservation_1383  1
    load_2_12_14  free_load_conservation_1397  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1183  -30
    arc_2_12_15  connected_order_arc_1184  -12
    arc_2_12_15  out_degree_1379  1
    arc_2_12_15  in_degree_1399  1
    arc_2_12_15  original_T_including_depot_unload_1436  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1183  1
    load_2_12_15  segment_load_conservation_1383  1
    load_2_12_15  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1185  -30
    arc_2_12_16  connected_order_arc_1186  -12
    arc_2_12_16  out_degree_1379  1
    arc_2_12_16  in_degree_1405  1
    arc_2_12_16  original_T_including_depot_unload_1436  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1185  1
    load_2_12_16  segment_load_conservation_1383  1
    load_2_12_16  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1187  -30
    arc_2_12_17  connected_order_arc_1188  -12
    arc_2_12_17  out_degree_1379  1
    arc_2_12_17  in_degree_1411  1
    arc_2_12_17  original_T_including_depot_unload_1436  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1187  1
    load_2_12_17  segment_load_conservation_1383  1
    load_2_12_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1189  -30
    arc_2_12_18  connected_order_arc_1190  -12
    arc_2_12_18  out_degree_1379  1
    arc_2_12_18  in_degree_1417  1
    arc_2_12_18  original_T_including_depot_unload_1436  756.038676628532
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1189  1
    load_2_12_18  segment_load_conservation_1383  1
    load_2_12_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1191  -30
    arc_2_12_19  connected_order_arc_1192  -12
    arc_2_12_19  out_degree_1379  1
    arc_2_12_19  in_degree_1423  1
    arc_2_12_19  original_T_including_depot_unload_1436  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1191  1
    load_2_12_19  segment_load_conservation_1383  1
    load_2_12_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1193  -30
    arc_2_12_20  connected_order_arc_1194  -12
    arc_2_12_20  out_degree_1379  1
    arc_2_12_20  in_degree_1429  1
    arc_2_12_20  original_T_including_depot_unload_1436  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1193  1
    load_2_12_20  segment_load_conservation_1383  1
    load_2_12_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1195  -30
    arc_2_13_0  depot_return_or_bypass_1364  1
    arc_2_13_0  out_degree_1386  1
    arc_2_13_0  original_T_including_depot_unload_1436  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1195  1
    load_2_13_0  free_load_conservation_1391  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1196  -30
    arc_2_13_10  connected_order_arc_1197  -12
    arc_2_13_10  in_degree_1366  1
    arc_2_13_10  out_degree_1386  1
    arc_2_13_10  original_T_including_depot_unload_1436  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1196  1
    load_2_13_10  segment_load_conservation_1369  -1
    load_2_13_10  segment_prefix_lb_1370  1
    load_2_13_10  segment_prefix_ub_1371  1
    load_2_13_10  free_load_conservation_1391  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1198  -30
    arc_2_13_11  connected_order_arc_1199  -12
    arc_2_13_11  in_degree_1373  1
    arc_2_13_11  out_degree_1386  1
    arc_2_13_11  original_T_including_depot_unload_1436  1.7224091675467555e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1198  1
    load_2_13_11  segment_load_conservation_1376  -1
    load_2_13_11  segment_prefix_lb_1377  1
    load_2_13_11  segment_prefix_ub_1378  1
    load_2_13_11  free_load_conservation_1391  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1200  -30
    arc_2_13_12  connected_order_arc_1201  -12
    arc_2_13_12  in_degree_1380  1
    arc_2_13_12  out_degree_1386  1
    arc_2_13_12  original_T_including_depot_unload_1436  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1200  1
    load_2_13_12  segment_load_conservation_1383  -1
    load_2_13_12  segment_prefix_lb_1384  1
    load_2_13_12  segment_prefix_ub_1385  1
    load_2_13_12  free_load_conservation_1391  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1202  -30
    arc_2_13_14  connected_order_arc_1203  -12
    arc_2_13_14  out_degree_1386  1
    arc_2_13_14  in_degree_1393  1
    arc_2_13_14  original_T_including_depot_unload_1436  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1202  1
    load_2_13_14  free_load_conservation_1391  1
    load_2_13_14  free_load_conservation_1397  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1204  -30
    arc_2_13_15  connected_order_arc_1205  -12
    arc_2_13_15  out_degree_1386  1
    arc_2_13_15  in_degree_1399  1
    arc_2_13_15  original_T_including_depot_unload_1436  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1204  1
    load_2_13_15  free_load_conservation_1391  1
    load_2_13_15  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1206  -30
    arc_2_13_16  connected_order_arc_1207  -12
    arc_2_13_16  out_degree_1386  1
    arc_2_13_16  in_degree_1405  1
    arc_2_13_16  original_T_including_depot_unload_1436  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1206  1
    load_2_13_16  free_load_conservation_1391  1
    load_2_13_16  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1208  -30
    arc_2_13_17  connected_order_arc_1209  -12
    arc_2_13_17  out_degree_1386  1
    arc_2_13_17  in_degree_1411  1
    arc_2_13_17  original_T_including_depot_unload_1436  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1208  1
    load_2_13_17  free_load_conservation_1391  1
    load_2_13_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1210  -30
    arc_2_13_18  connected_order_arc_1211  -12
    arc_2_13_18  out_degree_1386  1
    arc_2_13_18  in_degree_1417  1
    arc_2_13_18  original_T_including_depot_unload_1436  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1210  1
    load_2_13_18  free_load_conservation_1391  1
    load_2_13_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1212  -30
    arc_2_13_19  connected_order_arc_1213  -12
    arc_2_13_19  out_degree_1386  1
    arc_2_13_19  in_degree_1423  1
    arc_2_13_19  original_T_including_depot_unload_1436  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1212  1
    load_2_13_19  free_load_conservation_1391  1
    load_2_13_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1214  -30
    arc_2_13_20  connected_order_arc_1215  -12
    arc_2_13_20  out_degree_1386  1
    arc_2_13_20  in_degree_1429  1
    arc_2_13_20  original_T_including_depot_unload_1436  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1214  1
    load_2_13_20  free_load_conservation_1391  1
    load_2_13_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1216  -30
    arc_2_14_0  depot_return_or_bypass_1364  1
    arc_2_14_0  out_degree_1392  1
    arc_2_14_0  original_T_including_depot_unload_1436  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1216  1
    load_2_14_0  free_load_conservation_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1217  -30
    arc_2_14_10  connected_order_arc_1218  -12
    arc_2_14_10  in_degree_1366  1
    arc_2_14_10  out_degree_1392  1
    arc_2_14_10  original_T_including_depot_unload_1436  1.3060135543268104e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1217  1
    load_2_14_10  segment_load_conservation_1369  -1
    load_2_14_10  segment_prefix_lb_1370  1
    load_2_14_10  segment_prefix_ub_1371  1
    load_2_14_10  free_load_conservation_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1219  -30
    arc_2_14_11  connected_order_arc_1220  -12
    arc_2_14_11  in_degree_1373  1
    arc_2_14_11  out_degree_1392  1
    arc_2_14_11  original_T_including_depot_unload_1436  1.8758493536744261e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1219  1
    load_2_14_11  segment_load_conservation_1376  -1
    load_2_14_11  segment_prefix_lb_1377  1
    load_2_14_11  segment_prefix_ub_1378  1
    load_2_14_11  free_load_conservation_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1221  -30
    arc_2_14_12  connected_order_arc_1222  -12
    arc_2_14_12  in_degree_1380  1
    arc_2_14_12  out_degree_1392  1
    arc_2_14_12  original_T_including_depot_unload_1436  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1221  1
    load_2_14_12  segment_load_conservation_1383  -1
    load_2_14_12  segment_prefix_lb_1384  1
    load_2_14_12  segment_prefix_ub_1385  1
    load_2_14_12  free_load_conservation_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1223  -30
    arc_2_14_13  connected_order_arc_1224  -12
    arc_2_14_13  in_degree_1387  1
    arc_2_14_13  out_degree_1392  1
    arc_2_14_13  original_T_including_depot_unload_1436  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1223  1
    load_2_14_13  free_load_conservation_1391  -1
    load_2_14_13  free_load_conservation_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1225  -30
    arc_2_14_15  connected_order_arc_1226  -12
    arc_2_14_15  out_degree_1392  1
    arc_2_14_15  in_degree_1399  1
    arc_2_14_15  original_T_including_depot_unload_1436  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1225  1
    load_2_14_15  free_load_conservation_1397  1
    load_2_14_15  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1227  -30
    arc_2_14_16  connected_order_arc_1228  -12
    arc_2_14_16  out_degree_1392  1
    arc_2_14_16  in_degree_1405  1
    arc_2_14_16  original_T_including_depot_unload_1436  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1227  1
    load_2_14_16  free_load_conservation_1397  1
    load_2_14_16  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1229  -30
    arc_2_14_17  connected_order_arc_1230  -12
    arc_2_14_17  out_degree_1392  1
    arc_2_14_17  in_degree_1411  1
    arc_2_14_17  original_T_including_depot_unload_1436  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1229  1
    load_2_14_17  free_load_conservation_1397  1
    load_2_14_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1231  -30
    arc_2_14_18  connected_order_arc_1232  -12
    arc_2_14_18  out_degree_1392  1
    arc_2_14_18  in_degree_1417  1
    arc_2_14_18  original_T_including_depot_unload_1436  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1231  1
    load_2_14_18  free_load_conservation_1397  1
    load_2_14_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1233  -30
    arc_2_14_19  connected_order_arc_1234  -12
    arc_2_14_19  out_degree_1392  1
    arc_2_14_19  in_degree_1423  1
    arc_2_14_19  original_T_including_depot_unload_1436  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1233  1
    load_2_14_19  free_load_conservation_1397  1
    load_2_14_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1235  -30
    arc_2_14_20  connected_order_arc_1236  -12
    arc_2_14_20  out_degree_1392  1
    arc_2_14_20  in_degree_1429  1
    arc_2_14_20  original_T_including_depot_unload_1436  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1235  1
    load_2_14_20  free_load_conservation_1397  1
    load_2_14_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1237  -30
    arc_2_15_0  depot_return_or_bypass_1364  1
    arc_2_15_0  out_degree_1398  1
    arc_2_15_0  original_T_including_depot_unload_1436  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1237  1
    load_2_15_0  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1238  -30
    arc_2_15_10  connected_order_arc_1239  -12
    arc_2_15_10  in_degree_1366  1
    arc_2_15_10  out_degree_1398  1
    arc_2_15_10  original_T_including_depot_unload_1436  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1238  1
    load_2_15_10  segment_load_conservation_1369  -1
    load_2_15_10  segment_prefix_lb_1370  1
    load_2_15_10  segment_prefix_ub_1371  1
    load_2_15_10  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1240  -30
    arc_2_15_11  connected_order_arc_1241  -12
    arc_2_15_11  in_degree_1373  1
    arc_2_15_11  out_degree_1398  1
    arc_2_15_11  original_T_including_depot_unload_1436  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1240  1
    load_2_15_11  segment_load_conservation_1376  -1
    load_2_15_11  segment_prefix_lb_1377  1
    load_2_15_11  segment_prefix_ub_1378  1
    load_2_15_11  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1242  -30
    arc_2_15_12  connected_order_arc_1243  -12
    arc_2_15_12  in_degree_1380  1
    arc_2_15_12  out_degree_1398  1
    arc_2_15_12  original_T_including_depot_unload_1436  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1242  1
    load_2_15_12  segment_load_conservation_1383  -1
    load_2_15_12  segment_prefix_lb_1384  1
    load_2_15_12  segment_prefix_ub_1385  1
    load_2_15_12  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1244  -30
    arc_2_15_13  connected_order_arc_1245  -12
    arc_2_15_13  in_degree_1387  1
    arc_2_15_13  out_degree_1398  1
    arc_2_15_13  original_T_including_depot_unload_1436  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1244  1
    load_2_15_13  free_load_conservation_1391  -1
    load_2_15_13  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1246  -30
    arc_2_15_14  connected_order_arc_1247  -12
    arc_2_15_14  in_degree_1393  1
    arc_2_15_14  out_degree_1398  1
    arc_2_15_14  original_T_including_depot_unload_1436  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1246  1
    load_2_15_14  free_load_conservation_1397  -1
    load_2_15_14  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1248  -30
    arc_2_15_16  connected_order_arc_1249  -12
    arc_2_15_16  out_degree_1398  1
    arc_2_15_16  in_degree_1405  1
    arc_2_15_16  original_T_including_depot_unload_1436  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1248  1
    load_2_15_16  free_load_conservation_1403  1
    load_2_15_16  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1250  -30
    arc_2_15_17  connected_order_arc_1251  -12
    arc_2_15_17  out_degree_1398  1
    arc_2_15_17  in_degree_1411  1
    arc_2_15_17  original_T_including_depot_unload_1436  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1250  1
    load_2_15_17  free_load_conservation_1403  1
    load_2_15_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1252  -30
    arc_2_15_18  connected_order_arc_1253  -12
    arc_2_15_18  out_degree_1398  1
    arc_2_15_18  in_degree_1417  1
    arc_2_15_18  original_T_including_depot_unload_1436  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1252  1
    load_2_15_18  free_load_conservation_1403  1
    load_2_15_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1254  -30
    arc_2_15_19  connected_order_arc_1255  -12
    arc_2_15_19  out_degree_1398  1
    arc_2_15_19  in_degree_1423  1
    arc_2_15_19  original_T_including_depot_unload_1436  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1254  1
    load_2_15_19  free_load_conservation_1403  1
    load_2_15_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1256  -30
    arc_2_15_20  connected_order_arc_1257  -12
    arc_2_15_20  out_degree_1398  1
    arc_2_15_20  in_degree_1429  1
    arc_2_15_20  original_T_including_depot_unload_1436  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1256  1
    load_2_15_20  free_load_conservation_1403  1
    load_2_15_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1258  -30
    arc_2_16_0  depot_return_or_bypass_1364  1
    arc_2_16_0  out_degree_1404  1
    arc_2_16_0  original_T_including_depot_unload_1436  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1258  1
    load_2_16_0  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1259  -30
    arc_2_16_10  connected_order_arc_1260  -12
    arc_2_16_10  in_degree_1366  1
    arc_2_16_10  out_degree_1404  1
    arc_2_16_10  original_T_including_depot_unload_1436  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1259  1
    load_2_16_10  segment_load_conservation_1369  -1
    load_2_16_10  segment_prefix_lb_1370  1
    load_2_16_10  segment_prefix_ub_1371  1
    load_2_16_10  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1261  -30
    arc_2_16_11  connected_order_arc_1262  -12
    arc_2_16_11  in_degree_1373  1
    arc_2_16_11  out_degree_1404  1
    arc_2_16_11  original_T_including_depot_unload_1436  1.5412757472294663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1261  1
    load_2_16_11  segment_load_conservation_1376  -1
    load_2_16_11  segment_prefix_lb_1377  1
    load_2_16_11  segment_prefix_ub_1378  1
    load_2_16_11  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1263  -30
    arc_2_16_12  connected_order_arc_1264  -12
    arc_2_16_12  in_degree_1380  1
    arc_2_16_12  out_degree_1404  1
    arc_2_16_12  original_T_including_depot_unload_1436  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1263  1
    load_2_16_12  segment_load_conservation_1383  -1
    load_2_16_12  segment_prefix_lb_1384  1
    load_2_16_12  segment_prefix_ub_1385  1
    load_2_16_12  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1265  -30
    arc_2_16_13  connected_order_arc_1266  -12
    arc_2_16_13  in_degree_1387  1
    arc_2_16_13  out_degree_1404  1
    arc_2_16_13  original_T_including_depot_unload_1436  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1265  1
    load_2_16_13  free_load_conservation_1391  -1
    load_2_16_13  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1267  -30
    arc_2_16_14  connected_order_arc_1268  -12
    arc_2_16_14  in_degree_1393  1
    arc_2_16_14  out_degree_1404  1
    arc_2_16_14  original_T_including_depot_unload_1436  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1267  1
    load_2_16_14  free_load_conservation_1397  -1
    load_2_16_14  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1269  -30
    arc_2_16_15  connected_order_arc_1270  -12
    arc_2_16_15  in_degree_1399  1
    arc_2_16_15  out_degree_1404  1
    arc_2_16_15  original_T_including_depot_unload_1436  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1269  1
    load_2_16_15  free_load_conservation_1403  -1
    load_2_16_15  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1271  -30
    arc_2_16_17  connected_order_arc_1272  -12
    arc_2_16_17  out_degree_1404  1
    arc_2_16_17  in_degree_1411  1
    arc_2_16_17  original_T_including_depot_unload_1436  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1271  1
    load_2_16_17  free_load_conservation_1409  1
    load_2_16_17  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1273  -30
    arc_2_16_18  connected_order_arc_1274  -12
    arc_2_16_18  out_degree_1404  1
    arc_2_16_18  in_degree_1417  1
    arc_2_16_18  original_T_including_depot_unload_1436  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1273  1
    load_2_16_18  free_load_conservation_1409  1
    load_2_16_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1275  -30
    arc_2_16_19  connected_order_arc_1276  -12
    arc_2_16_19  out_degree_1404  1
    arc_2_16_19  in_degree_1423  1
    arc_2_16_19  original_T_including_depot_unload_1436  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1275  1
    load_2_16_19  free_load_conservation_1409  1
    load_2_16_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1277  -30
    arc_2_16_20  connected_order_arc_1278  -12
    arc_2_16_20  out_degree_1404  1
    arc_2_16_20  in_degree_1429  1
    arc_2_16_20  original_T_including_depot_unload_1436  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1277  1
    load_2_16_20  free_load_conservation_1409  1
    load_2_16_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1279  -30
    arc_2_17_0  depot_return_or_bypass_1364  1
    arc_2_17_0  out_degree_1410  1
    arc_2_17_0  original_T_including_depot_unload_1436  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1279  1
    load_2_17_0  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1280  -30
    arc_2_17_10  connected_order_arc_1281  -12
    arc_2_17_10  in_degree_1366  1
    arc_2_17_10  out_degree_1410  1
    arc_2_17_10  original_T_including_depot_unload_1436  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1280  1
    load_2_17_10  segment_load_conservation_1369  -1
    load_2_17_10  segment_prefix_lb_1370  1
    load_2_17_10  segment_prefix_ub_1371  1
    load_2_17_10  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1282  -30
    arc_2_17_11  connected_order_arc_1283  -12
    arc_2_17_11  in_degree_1373  1
    arc_2_17_11  out_degree_1410  1
    arc_2_17_11  original_T_including_depot_unload_1436  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1282  1
    load_2_17_11  segment_load_conservation_1376  -1
    load_2_17_11  segment_prefix_lb_1377  1
    load_2_17_11  segment_prefix_ub_1378  1
    load_2_17_11  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1284  -30
    arc_2_17_12  connected_order_arc_1285  -12
    arc_2_17_12  in_degree_1380  1
    arc_2_17_12  out_degree_1410  1
    arc_2_17_12  original_T_including_depot_unload_1436  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1284  1
    load_2_17_12  segment_load_conservation_1383  -1
    load_2_17_12  segment_prefix_lb_1384  1
    load_2_17_12  segment_prefix_ub_1385  1
    load_2_17_12  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1286  -30
    arc_2_17_13  connected_order_arc_1287  -12
    arc_2_17_13  in_degree_1387  1
    arc_2_17_13  out_degree_1410  1
    arc_2_17_13  original_T_including_depot_unload_1436  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1286  1
    load_2_17_13  free_load_conservation_1391  -1
    load_2_17_13  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1288  -30
    arc_2_17_14  connected_order_arc_1289  -12
    arc_2_17_14  in_degree_1393  1
    arc_2_17_14  out_degree_1410  1
    arc_2_17_14  original_T_including_depot_unload_1436  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1288  1
    load_2_17_14  free_load_conservation_1397  -1
    load_2_17_14  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1290  -30
    arc_2_17_15  connected_order_arc_1291  -12
    arc_2_17_15  in_degree_1399  1
    arc_2_17_15  out_degree_1410  1
    arc_2_17_15  original_T_including_depot_unload_1436  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1290  1
    load_2_17_15  free_load_conservation_1403  -1
    load_2_17_15  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1292  -30
    arc_2_17_16  connected_order_arc_1293  -12
    arc_2_17_16  in_degree_1405  1
    arc_2_17_16  out_degree_1410  1
    arc_2_17_16  original_T_including_depot_unload_1436  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1292  1
    load_2_17_16  free_load_conservation_1409  -1
    load_2_17_16  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1294  -30
    arc_2_17_18  connected_order_arc_1295  -12
    arc_2_17_18  out_degree_1410  1
    arc_2_17_18  in_degree_1417  1
    arc_2_17_18  original_T_including_depot_unload_1436  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1294  1
    load_2_17_18  free_load_conservation_1415  1
    load_2_17_18  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1296  -30
    arc_2_17_19  connected_order_arc_1297  -12
    arc_2_17_19  out_degree_1410  1
    arc_2_17_19  in_degree_1423  1
    arc_2_17_19  original_T_including_depot_unload_1436  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1296  1
    load_2_17_19  free_load_conservation_1415  1
    load_2_17_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1298  -30
    arc_2_17_20  connected_order_arc_1299  -12
    arc_2_17_20  out_degree_1410  1
    arc_2_17_20  in_degree_1429  1
    arc_2_17_20  original_T_including_depot_unload_1436  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1298  1
    load_2_17_20  free_load_conservation_1415  1
    load_2_17_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1300  -30
    arc_2_18_0  depot_return_or_bypass_1364  1
    arc_2_18_0  out_degree_1416  1
    arc_2_18_0  original_T_including_depot_unload_1436  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1300  1
    load_2_18_0  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1301  -30
    arc_2_18_10  connected_order_arc_1302  -12
    arc_2_18_10  in_degree_1366  1
    arc_2_18_10  out_degree_1416  1
    arc_2_18_10  original_T_including_depot_unload_1436  1.0464557570570403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1301  1
    load_2_18_10  segment_load_conservation_1369  -1
    load_2_18_10  segment_prefix_lb_1370  1
    load_2_18_10  segment_prefix_ub_1371  1
    load_2_18_10  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1303  -30
    arc_2_18_11  connected_order_arc_1304  -12
    arc_2_18_11  in_degree_1373  1
    arc_2_18_11  out_degree_1416  1
    arc_2_18_11  original_T_including_depot_unload_1436  1.5396325562458978e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1303  1
    load_2_18_11  segment_load_conservation_1376  -1
    load_2_18_11  segment_prefix_lb_1377  1
    load_2_18_11  segment_prefix_ub_1378  1
    load_2_18_11  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1305  -30
    arc_2_18_12  connected_order_arc_1306  -12
    arc_2_18_12  in_degree_1380  1
    arc_2_18_12  out_degree_1416  1
    arc_2_18_12  original_T_including_depot_unload_1436  756.038676628532
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1305  1
    load_2_18_12  segment_load_conservation_1383  -1
    load_2_18_12  segment_prefix_lb_1384  1
    load_2_18_12  segment_prefix_ub_1385  1
    load_2_18_12  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1307  -30
    arc_2_18_13  connected_order_arc_1308  -12
    arc_2_18_13  in_degree_1387  1
    arc_2_18_13  out_degree_1416  1
    arc_2_18_13  original_T_including_depot_unload_1436  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1307  1
    load_2_18_13  free_load_conservation_1391  -1
    load_2_18_13  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1309  -30
    arc_2_18_14  connected_order_arc_1310  -12
    arc_2_18_14  in_degree_1393  1
    arc_2_18_14  out_degree_1416  1
    arc_2_18_14  original_T_including_depot_unload_1436  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1309  1
    load_2_18_14  free_load_conservation_1397  -1
    load_2_18_14  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1311  -30
    arc_2_18_15  connected_order_arc_1312  -12
    arc_2_18_15  in_degree_1399  1
    arc_2_18_15  out_degree_1416  1
    arc_2_18_15  original_T_including_depot_unload_1436  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1311  1
    load_2_18_15  free_load_conservation_1403  -1
    load_2_18_15  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1313  -30
    arc_2_18_16  connected_order_arc_1314  -12
    arc_2_18_16  in_degree_1405  1
    arc_2_18_16  out_degree_1416  1
    arc_2_18_16  original_T_including_depot_unload_1436  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1313  1
    load_2_18_16  free_load_conservation_1409  -1
    load_2_18_16  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1315  -30
    arc_2_18_17  connected_order_arc_1316  -12
    arc_2_18_17  in_degree_1411  1
    arc_2_18_17  out_degree_1416  1
    arc_2_18_17  original_T_including_depot_unload_1436  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1315  1
    load_2_18_17  free_load_conservation_1415  -1
    load_2_18_17  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1317  -30
    arc_2_18_19  connected_order_arc_1318  -12
    arc_2_18_19  out_degree_1416  1
    arc_2_18_19  in_degree_1423  1
    arc_2_18_19  original_T_including_depot_unload_1436  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1317  1
    load_2_18_19  free_load_conservation_1421  1
    load_2_18_19  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1319  -30
    arc_2_18_20  connected_order_arc_1320  -12
    arc_2_18_20  out_degree_1416  1
    arc_2_18_20  in_degree_1429  1
    arc_2_18_20  original_T_including_depot_unload_1436  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1319  1
    load_2_18_20  free_load_conservation_1421  1
    load_2_18_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1321  -30
    arc_2_19_0  depot_return_or_bypass_1364  1
    arc_2_19_0  out_degree_1422  1
    arc_2_19_0  original_T_including_depot_unload_1436  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1321  1
    load_2_19_0  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1322  -30
    arc_2_19_10  connected_order_arc_1323  -12
    arc_2_19_10  in_degree_1366  1
    arc_2_19_10  out_degree_1422  1
    arc_2_19_10  original_T_including_depot_unload_1436  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1322  1
    load_2_19_10  segment_load_conservation_1369  -1
    load_2_19_10  segment_prefix_lb_1370  1
    load_2_19_10  segment_prefix_ub_1371  1
    load_2_19_10  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1324  -30
    arc_2_19_11  connected_order_arc_1325  -12
    arc_2_19_11  in_degree_1373  1
    arc_2_19_11  out_degree_1422  1
    arc_2_19_11  original_T_including_depot_unload_1436  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1324  1
    load_2_19_11  segment_load_conservation_1376  -1
    load_2_19_11  segment_prefix_lb_1377  1
    load_2_19_11  segment_prefix_ub_1378  1
    load_2_19_11  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1326  -30
    arc_2_19_12  connected_order_arc_1327  -12
    arc_2_19_12  in_degree_1380  1
    arc_2_19_12  out_degree_1422  1
    arc_2_19_12  original_T_including_depot_unload_1436  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1326  1
    load_2_19_12  segment_load_conservation_1383  -1
    load_2_19_12  segment_prefix_lb_1384  1
    load_2_19_12  segment_prefix_ub_1385  1
    load_2_19_12  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1328  -30
    arc_2_19_13  connected_order_arc_1329  -12
    arc_2_19_13  in_degree_1387  1
    arc_2_19_13  out_degree_1422  1
    arc_2_19_13  original_T_including_depot_unload_1436  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1328  1
    load_2_19_13  free_load_conservation_1391  -1
    load_2_19_13  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1330  -30
    arc_2_19_14  connected_order_arc_1331  -12
    arc_2_19_14  in_degree_1393  1
    arc_2_19_14  out_degree_1422  1
    arc_2_19_14  original_T_including_depot_unload_1436  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1330  1
    load_2_19_14  free_load_conservation_1397  -1
    load_2_19_14  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1332  -30
    arc_2_19_15  connected_order_arc_1333  -12
    arc_2_19_15  in_degree_1399  1
    arc_2_19_15  out_degree_1422  1
    arc_2_19_15  original_T_including_depot_unload_1436  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1332  1
    load_2_19_15  free_load_conservation_1403  -1
    load_2_19_15  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1334  -30
    arc_2_19_16  connected_order_arc_1335  -12
    arc_2_19_16  in_degree_1405  1
    arc_2_19_16  out_degree_1422  1
    arc_2_19_16  original_T_including_depot_unload_1436  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1334  1
    load_2_19_16  free_load_conservation_1409  -1
    load_2_19_16  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1336  -30
    arc_2_19_17  connected_order_arc_1337  -12
    arc_2_19_17  in_degree_1411  1
    arc_2_19_17  out_degree_1422  1
    arc_2_19_17  original_T_including_depot_unload_1436  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1336  1
    load_2_19_17  free_load_conservation_1415  -1
    load_2_19_17  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1338  -30
    arc_2_19_18  connected_order_arc_1339  -12
    arc_2_19_18  in_degree_1417  1
    arc_2_19_18  out_degree_1422  1
    arc_2_19_18  original_T_including_depot_unload_1436  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1338  1
    load_2_19_18  free_load_conservation_1421  -1
    load_2_19_18  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1340  -30
    arc_2_19_20  connected_order_arc_1341  -12
    arc_2_19_20  out_degree_1422  1
    arc_2_19_20  in_degree_1429  1
    arc_2_19_20  original_T_including_depot_unload_1436  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1340  1
    load_2_19_20  free_load_conservation_1427  1
    load_2_19_20  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1342  -30
    arc_2_20_0  depot_return_or_bypass_1364  1
    arc_2_20_0  out_degree_1428  1
    arc_2_20_0  original_T_including_depot_unload_1436  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1342  1
    load_2_20_0  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1343  -30
    arc_2_20_10  connected_order_arc_1344  -12
    arc_2_20_10  in_degree_1366  1
    arc_2_20_10  out_degree_1428  1
    arc_2_20_10  original_T_including_depot_unload_1436  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1343  1
    load_2_20_10  segment_load_conservation_1369  -1
    load_2_20_10  segment_prefix_lb_1370  1
    load_2_20_10  segment_prefix_ub_1371  1
    load_2_20_10  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1345  -30
    arc_2_20_11  connected_order_arc_1346  -12
    arc_2_20_11  in_degree_1373  1
    arc_2_20_11  out_degree_1428  1
    arc_2_20_11  original_T_including_depot_unload_1436  1.5387417148054021e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1345  1
    load_2_20_11  segment_load_conservation_1376  -1
    load_2_20_11  segment_prefix_lb_1377  1
    load_2_20_11  segment_prefix_ub_1378  1
    load_2_20_11  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1347  -30
    arc_2_20_12  connected_order_arc_1348  -12
    arc_2_20_12  in_degree_1380  1
    arc_2_20_12  out_degree_1428  1
    arc_2_20_12  original_T_including_depot_unload_1436  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1347  1
    load_2_20_12  segment_load_conservation_1383  -1
    load_2_20_12  segment_prefix_lb_1384  1
    load_2_20_12  segment_prefix_ub_1385  1
    load_2_20_12  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1349  -30
    arc_2_20_13  connected_order_arc_1350  -12
    arc_2_20_13  in_degree_1387  1
    arc_2_20_13  out_degree_1428  1
    arc_2_20_13  original_T_including_depot_unload_1436  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1349  1
    load_2_20_13  free_load_conservation_1391  -1
    load_2_20_13  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1351  -30
    arc_2_20_14  connected_order_arc_1352  -12
    arc_2_20_14  in_degree_1393  1
    arc_2_20_14  out_degree_1428  1
    arc_2_20_14  original_T_including_depot_unload_1436  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1351  1
    load_2_20_14  free_load_conservation_1397  -1
    load_2_20_14  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1353  -30
    arc_2_20_15  connected_order_arc_1354  -12
    arc_2_20_15  in_degree_1399  1
    arc_2_20_15  out_degree_1428  1
    arc_2_20_15  original_T_including_depot_unload_1436  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1353  1
    load_2_20_15  free_load_conservation_1403  -1
    load_2_20_15  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1355  -30
    arc_2_20_16  connected_order_arc_1356  -12
    arc_2_20_16  in_degree_1405  1
    arc_2_20_16  out_degree_1428  1
    arc_2_20_16  original_T_including_depot_unload_1436  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1355  1
    load_2_20_16  free_load_conservation_1409  -1
    load_2_20_16  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1357  -30
    arc_2_20_17  connected_order_arc_1358  -12
    arc_2_20_17  in_degree_1411  1
    arc_2_20_17  out_degree_1428  1
    arc_2_20_17  original_T_including_depot_unload_1436  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1357  1
    load_2_20_17  free_load_conservation_1415  -1
    load_2_20_17  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1359  -30
    arc_2_20_18  connected_order_arc_1360  -12
    arc_2_20_18  in_degree_1417  1
    arc_2_20_18  out_degree_1428  1
    arc_2_20_18  original_T_including_depot_unload_1436  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1359  1
    load_2_20_18  free_load_conservation_1421  -1
    load_2_20_18  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1361  -30
    arc_2_20_19  connected_order_arc_1362  -12
    arc_2_20_19  in_degree_1423  1
    arc_2_20_19  out_degree_1428  1
    arc_2_20_19  original_T_including_depot_unload_1436  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1361  1
    load_2_20_19  free_load_conservation_1427  -1
    load_2_20_19  free_load_conservation_1433  1
RHS
    RHS1      OBJ       -2.3049714683005151e-01
    RHS1      onehot_15_18  1
    RHS1      onehot_13_39  1
    RHS1      onehot_34_74  1
    RHS1      onehot_17_91  1
    RHS1      onehot_29_116  1
    RHS1      onehot_18_141  1
    RHS1      onehot_27_158  1
    RHS1      onehot_19_183  1
    RHS1      stock_ub_187  24
    RHS1      parent_nonstrict_scope_188  2.5909533554042552e-01
    RHS1      normalization_245  1
    RHS1      connected_order_arc_336  -13
    RHS1      connected_order_arc_338  -13
    RHS1      connected_order_arc_340  -13
    RHS1      connected_order_arc_342  -13
    RHS1      connected_order_arc_344  -13
    RHS1      connected_order_arc_346  -13
    RHS1      connected_order_arc_348  -13
    RHS1      connected_order_arc_350  -13
    RHS1      connected_order_arc_352  -13
    RHS1      connected_order_arc_354  -13
    RHS1      connected_order_arc_356  -13
    RHS1      connected_order_arc_358  -13
    RHS1      connected_order_arc_361  -13
    RHS1      connected_order_arc_363  -13
    RHS1      connected_order_arc_365  -13
    RHS1      connected_order_arc_367  -13
    RHS1      connected_order_arc_369  -13
    RHS1      connected_order_arc_371  -13
    RHS1      connected_order_arc_373  -13
    RHS1      connected_order_arc_375  -13
    RHS1      connected_order_arc_377  -13
    RHS1      connected_order_arc_379  -13
    RHS1      connected_order_arc_381  -13
    RHS1      connected_order_arc_383  -13
    RHS1      connected_order_arc_386  -13
    RHS1      connected_order_arc_388  -13
    RHS1      connected_order_arc_390  -13
    RHS1      connected_order_arc_392  -13
    RHS1      connected_order_arc_394  -13
    RHS1      connected_order_arc_396  -13
    RHS1      connected_order_arc_398  -13
    RHS1      connected_order_arc_400  -13
    RHS1      connected_order_arc_402  -13
    RHS1      connected_order_arc_404  -13
    RHS1      connected_order_arc_406  -13
    RHS1      connected_order_arc_408  -13
    RHS1      connected_order_arc_411  -13
    RHS1      connected_order_arc_413  -13
    RHS1      connected_order_arc_415  -13
    RHS1      connected_order_arc_417  -13
    RHS1      connected_order_arc_419  -13
    RHS1      connected_order_arc_421  -13
    RHS1      connected_order_arc_423  -13
    RHS1      connected_order_arc_425  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_436  -13
    RHS1      connected_order_arc_438  -13
    RHS1      connected_order_arc_440  -13
    RHS1      connected_order_arc_442  -13
    RHS1      connected_order_arc_444  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      depot_departure_or_bypass_659  1
    RHS1      depot_return_or_bypass_660  1
    RHS1      segment_load_conservation_665  -2
    RHS1      segment_prefix_lb_666  2
    RHS1      segment_prefix_ub_667  20
    RHS1      segment_load_conservation_672  1
    RHS1      segment_prefix_ub_674  19
    RHS1      segment_load_conservation_679  3
    RHS1      segment_prefix_ub_681  17
    RHS1      segment_load_conservation_686  -4
    RHS1      segment_prefix_lb_687  4
    RHS1      segment_prefix_ub_688  14
    RHS1      segment_load_conservation_693  -1
    RHS1      segment_prefix_lb_694  1
    RHS1      segment_prefix_ub_695  18
    RHS1      fixed_segment_relative_order_744  1
    RHS1      fixed_segment_relative_order_745  1
    RHS1      fixed_segment_relative_order_746  1
    RHS1      fixed_segment_relative_order_747  1
    RHS1      original_T_including_depot_unload_748  3.3229277148580168e+03
    RHS1      connected_order_arc_764  -12
    RHS1      connected_order_arc_766  -12
    RHS1      connected_order_arc_768  -12
    RHS1      connected_order_arc_770  -12
    RHS1      connected_order_arc_772  -12
    RHS1      connected_order_arc_774  -12
    RHS1      connected_order_arc_776  -12
    RHS1      connected_order_arc_778  -12
    RHS1      connected_order_arc_780  -12
    RHS1      connected_order_arc_782  -12
    RHS1      connected_order_arc_784  -12
    RHS1      connected_order_arc_787  -12
    RHS1      connected_order_arc_789  -12
    RHS1      connected_order_arc_791  -12
    RHS1      connected_order_arc_793  -12
    RHS1      connected_order_arc_795  -12
    RHS1      connected_order_arc_797  -12
    RHS1      connected_order_arc_799  -12
    RHS1      connected_order_arc_801  -12
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_810  -12
    RHS1      connected_order_arc_812  -12
    RHS1      connected_order_arc_814  -12
    RHS1      connected_order_arc_816  -12
    RHS1      connected_order_arc_818  -12
    RHS1      connected_order_arc_820  -12
    RHS1      connected_order_arc_822  -12
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_833  -12
    RHS1      connected_order_arc_835  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_856  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      depot_departure_or_bypass_1038  1
    RHS1      depot_return_or_bypass_1039  1
    RHS1      segment_load_conservation_1044  4
    RHS1      segment_prefix_ub_1046  20
    RHS1      segment_load_conservation_1051  5
    RHS1      segment_prefix_ub_1053  20
    RHS1      segment_load_conservation_1058  -4
    RHS1      segment_prefix_lb_1059  4
    RHS1      segment_prefix_ub_1060  25
    RHS1      segment_load_conservation_1065  -5
    RHS1      segment_prefix_lb_1066  5
    RHS1      segment_prefix_ub_1067  25
    RHS1      fixed_segment_relative_order_1116  1
    RHS1      fixed_segment_relative_order_1117  1
    RHS1      fixed_segment_relative_order_1118  1
    RHS1      original_T_including_depot_unload_1119  4.0180155701548429e+03
    RHS1      connected_order_arc_1134  -11
    RHS1      connected_order_arc_1136  -11
    RHS1      connected_order_arc_1138  -11
    RHS1      connected_order_arc_1140  -11
    RHS1      connected_order_arc_1142  -11
    RHS1      connected_order_arc_1144  -11
    RHS1      connected_order_arc_1146  -11
    RHS1      connected_order_arc_1148  -11
    RHS1      connected_order_arc_1150  -11
    RHS1      connected_order_arc_1152  -11
    RHS1      connected_order_arc_1155  -11
    RHS1      connected_order_arc_1157  -11
    RHS1      connected_order_arc_1159  -11
    RHS1      connected_order_arc_1161  -11
    RHS1      connected_order_arc_1163  -11
    RHS1      connected_order_arc_1165  -11
    RHS1      connected_order_arc_1167  -11
    RHS1      connected_order_arc_1169  -11
    RHS1      connected_order_arc_1171  -11
    RHS1      connected_order_arc_1173  -11
    RHS1      connected_order_arc_1176  -11
    RHS1      connected_order_arc_1178  -11
    RHS1      connected_order_arc_1180  -11
    RHS1      connected_order_arc_1182  -11
    RHS1      connected_order_arc_1184  -11
    RHS1      connected_order_arc_1186  -11
    RHS1      connected_order_arc_1188  -11
    RHS1      connected_order_arc_1190  -11
    RHS1      connected_order_arc_1192  -11
    RHS1      connected_order_arc_1194  -11
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1201  -11
    RHS1      connected_order_arc_1203  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1207  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1213  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1222  -11
    RHS1      connected_order_arc_1224  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1228  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1234  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1291  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      depot_departure_or_bypass_1363  1
    RHS1      depot_return_or_bypass_1364  1
    RHS1      segment_load_conservation_1369  2
    RHS1      segment_prefix_ub_1371  28
    RHS1      segment_load_conservation_1376  1
    RHS1      segment_prefix_lb_1377  2
    RHS1      segment_prefix_ub_1378  28
    RHS1      segment_load_conservation_1383  -3
    RHS1      segment_prefix_lb_1384  3
    RHS1      segment_prefix_ub_1385  30
    RHS1      fixed_segment_relative_order_1434  1
    RHS1      fixed_segment_relative_order_1435  1
    RHS1      original_T_including_depot_unload_1436  3.3317427925191068e+03
BOUNDS
 LO BND1      t         2.6035209521422013e-02
 UP BND1      t         4.4376353742978512e-02
 UP BND1      q         4.0162002117312451e-01
 BV BND1      x_15_0  
 UP BND1      w_15_0    4.4376353742978512e-02
 BV BND1      x_15_1  
 UP BND1      w_15_1    4.4376353742978512e-02
 BV BND1      x_15_2  
 UP BND1      w_15_2    4.4376353742978512e-02
 BV BND1      x_15_3  
 UP BND1      w_15_3    4.4376353742978512e-02
 BV BND1      x_15_4  
 UP BND1      w_15_4    4.4376353742978512e-02
 BV BND1      x_15_5  
 UP BND1      w_15_5    4.4376353742978512e-02
 BV BND1      x_15_6  
 UP BND1      w_15_6    4.4376353742978512e-02
 BV BND1      x_15_7  
 UP BND1      w_15_7    4.4376353742978512e-02
 BV BND1      x_15_8  
 UP BND1      w_15_8    4.4376353742978512e-02
 UP BND1      rho_15    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    4.4376353742978512e-02
 BV BND1      x_13_1  
 UP BND1      w_13_1    4.4376353742978512e-02
 BV BND1      x_13_2  
 UP BND1      w_13_2    4.4376353742978512e-02
 BV BND1      x_13_3  
 UP BND1      w_13_3    4.4376353742978512e-02
 BV BND1      x_13_4  
 UP BND1      w_13_4    4.4376353742978512e-02
 BV BND1      x_13_5  
 UP BND1      w_13_5    4.4376353742978512e-02
 BV BND1      x_13_6  
 UP BND1      w_13_6    4.4376353742978512e-02
 BV BND1      x_13_7  
 UP BND1      w_13_7    4.4376353742978512e-02
 BV BND1      x_13_8  
 UP BND1      w_13_8    4.4376353742978512e-02
 UP BND1      rho_13    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.4376353742978512e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.4376353742978512e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.4376353742978512e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.4376353742978512e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.4376353742978512e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.4376353742978512e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.4376353742978512e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.4376353742978512e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.4376353742978512e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.4376353742978512e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.4376353742978512e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.4376353742978512e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.4376353742978512e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.4376353742978512e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.4376353742978512e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.4376353742978512e-02
 UP BND1      rho_34    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    4.4376353742978512e-02
 BV BND1      x_17_1  
 UP BND1      w_17_1    4.4376353742978512e-02
 BV BND1      x_17_2  
 UP BND1      w_17_2    4.4376353742978512e-02
 BV BND1      x_17_3  
 UP BND1      w_17_3    4.4376353742978512e-02
 BV BND1      x_17_4  
 UP BND1      w_17_4    4.4376353742978512e-02
 BV BND1      x_17_5  
 UP BND1      w_17_5    4.4376353742978512e-02
 BV BND1      x_17_6  
 UP BND1      w_17_6    4.4376353742978512e-02
 UP BND1      rho_17    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.4376353742978512e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.4376353742978512e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.4376353742978512e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.4376353742978512e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.4376353742978512e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.4376353742978512e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.4376353742978512e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.4376353742978512e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.4376353742978512e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.4376353742978512e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.4376353742978512e-02
 UP BND1      rho_29    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    4.4376353742978512e-02
 BV BND1      x_18_1  
 UP BND1      w_18_1    4.4376353742978512e-02
 BV BND1      x_18_2  
 UP BND1      w_18_2    4.4376353742978512e-02
 BV BND1      x_18_3  
 UP BND1      w_18_3    4.4376353742978512e-02
 BV BND1      x_18_4  
 UP BND1      w_18_4    4.4376353742978512e-02
 BV BND1      x_18_5  
 UP BND1      w_18_5    4.4376353742978512e-02
 BV BND1      x_18_6  
 UP BND1      w_18_6    4.4376353742978512e-02
 BV BND1      x_18_7  
 UP BND1      w_18_7    4.4376353742978512e-02
 BV BND1      x_18_8  
 UP BND1      w_18_8    4.4376353742978512e-02
 BV BND1      x_18_9  
 UP BND1      w_18_9    4.4376353742978512e-02
 BV BND1      x_18_10 
 UP BND1      w_18_10   4.4376353742978512e-02
 UP BND1      rho_18    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.4376353742978512e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.4376353742978512e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.4376353742978512e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.4376353742978512e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.4376353742978512e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.4376353742978512e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.4376353742978512e-02
 UP BND1      rho_27    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.4376353742978512e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.4376353742978512e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.4376353742978512e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.4376353742978512e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.4376353742978512e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.4376353742978512e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.4376353742978512e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.4376353742978512e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.4376353742978512e-02
 BV BND1      x_19_9  
 UP BND1      w_19_9    4.4376353742978512e-02
 BV BND1      x_19_10 
 UP BND1      w_19_10   4.4376353742978512e-02
 UP BND1      rho_19    1
 UP BND1      a_15_13   1
 UP BND1      a_15_34   1
 UP BND1      a_15_17   1
 UP BND1      a_15_29   1
 UP BND1      a_15_18   1
 UP BND1      a_15_27   1
 UP BND1      a_15_19   1
 UP BND1      a_13_34   1
 UP BND1      a_13_17   1
 UP BND1      a_13_29   1
 UP BND1      a_13_18   1
 UP BND1      a_13_27   1
 UP BND1      a_13_19   1
 UP BND1      a_34_17   1
 UP BND1      a_34_29   1
 UP BND1      a_34_18   1
 UP BND1      a_34_27   1
 UP BND1      a_34_19   1
 UP BND1      a_17_29   1
 UP BND1      a_17_18   1
 UP BND1      a_17_27   1
 UP BND1      a_17_19   1
 UP BND1      a_29_18   1
 UP BND1      a_29_27   1
 UP BND1      a_29_19   1
 UP BND1      a_18_27   1
 UP BND1      a_18_19   1
 UP BND1      a_27_19   1
 BV BND1      service_0_15_0
 BV BND1      service_0_15_1
 BV BND1      service_0_15_2
 BV BND1      service_0_15_3
 BV BND1      service_0_15_4
 BV BND1      service_0_15_6
 BV BND1      service_0_15_7
 BV BND1      service_0_15_8
 BV BND1      service_1_15_0
 BV BND1      service_1_15_1
 BV BND1      service_1_15_2
 BV BND1      service_1_15_3
 BV BND1      service_1_15_4
 BV BND1      service_1_15_6
 BV BND1      service_1_15_7
 BV BND1      service_1_15_8
 BV BND1      service_2_15_0
 BV BND1      service_2_15_1
 BV BND1      service_2_15_2
 BV BND1      service_2_15_3
 BV BND1      service_2_15_4
 BV BND1      service_2_15_6
 BV BND1      service_2_15_7
 BV BND1      service_2_15_8
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_3
 BV BND1      service_0_17_4
 BV BND1      service_0_17_6
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_3
 BV BND1      service_1_17_4
 BV BND1      service_1_17_6
 BV BND1      service_2_17_0
 BV BND1      service_2_17_1
 BV BND1      service_2_17_2
 BV BND1      service_2_17_3
 BV BND1      service_2_17_4
 BV BND1      service_2_17_6
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_18_0
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_1_18_0
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_2_18_0
 BV BND1      service_2_18_1
 BV BND1      service_2_18_2
 BV BND1      service_2_18_3
 BV BND1      service_2_18_4
 BV BND1      service_2_18_5
 BV BND1      service_2_18_6
 BV BND1      service_2_18_7
 BV BND1      service_2_18_9
 BV BND1      service_2_18_10
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_19_0
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_0_19_9
 BV BND1      service_0_19_10
 BV BND1      service_1_19_0
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_1_19_9
 BV BND1      service_1_19_10
 BV BND1      service_2_19_0
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_2_19_9
 BV BND1      service_2_19_10
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
