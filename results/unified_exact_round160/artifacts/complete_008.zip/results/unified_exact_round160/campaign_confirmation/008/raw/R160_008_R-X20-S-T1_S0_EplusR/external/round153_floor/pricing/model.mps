* Signature: 0x8c2f52ae7fd126cb
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  w_lb_1_0
 L  w_ub_1_0
 G  w_lb_1_1
 L  w_ub_1_1
 G  w_lb_1_2
 L  w_ub_1_2
 G  w_lb_1_3
 L  w_ub_1_3
 G  w_lb_1_4
 L  w_ub_1_4
 G  w_lb_1_5
 L  w_ub_1_5
 G  w_lb_1_6
 L  w_ub_1_6
 G  w_lb_1_7
 L  w_ub_1_7
 G  w_lb_1_8
 L  w_ub_1_8
 G  w_lb_1_9
 L  w_ub_1_9
 G  w_lb_1_10
 L  w_ub_1_10
 G  w_lb_1_11
 L  w_ub_1_11
 G  w_lb_1_12
 L  w_ub_1_12
 G  w_lb_1_13
 L  w_ub_1_13
 G  w_lb_1_14
 L  w_ub_1_14
 G  w_lb_1_15
 L  w_ub_1_15
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  w_lb_2_0
 L  w_ub_2_0
 G  w_lb_2_1
 L  w_ub_2_1
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  w_lb_3_0
 L  w_ub_3_0
 G  w_lb_3_1
 L  w_ub_3_1
 G  w_lb_3_2
 L  w_ub_3_2
 G  w_lb_3_3
 L  w_ub_3_3
 G  w_lb_3_4
 L  w_ub_3_4
 G  w_lb_3_5
 L  w_ub_3_5
 G  w_lb_3_6
 L  w_ub_3_6
 G  w_lb_3_7
 L  w_ub_3_7
 G  w_lb_3_8
 L  w_ub_3_8
 G  w_lb_3_9
 L  w_ub_3_9
 G  w_lb_3_10
 L  w_ub_3_10
 G  w_lb_3_11
 L  w_ub_3_11
 G  w_lb_3_12
 L  w_ub_3_12
 G  w_lb_3_13
 L  w_ub_3_13
 G  w_lb_3_14
 L  w_ub_3_14
 G  w_lb_3_15
 L  w_ub_3_15
 G  w_lb_3_16
 L  w_ub_3_16
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  w_lb_4_0
 L  w_ub_4_0
 G  w_lb_4_1
 L  w_ub_4_1
 G  w_lb_4_2
 L  w_ub_4_2
 G  w_lb_4_3
 L  w_ub_4_3
 G  w_lb_4_4
 L  w_ub_4_4
 G  w_lb_4_5
 L  w_ub_4_5
 G  w_lb_4_6
 L  w_ub_4_6
 G  w_lb_4_7
 L  w_ub_4_7
 G  w_lb_4_8
 L  w_ub_4_8
 G  w_lb_4_9
 L  w_ub_4_9
 G  w_lb_4_10
 L  w_ub_4_10
 G  w_lb_4_11
 L  w_ub_4_11
 G  w_lb_4_12
 L  w_ub_4_12
 G  w_lb_4_13
 L  w_ub_4_13
 G  w_lb_4_14
 L  w_ub_4_14
 G  w_lb_4_15
 L  w_ub_4_15
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  w_lb_5_0
 L  w_ub_5_0
 G  w_lb_5_1
 L  w_ub_5_1
 G  w_lb_5_2
 L  w_ub_5_2
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  w_lb_6_0
 L  w_ub_6_0
 G  w_lb_6_1
 L  w_ub_6_1
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  w_lb_7_0
 L  w_ub_7_0
 G  w_lb_7_1
 L  w_ub_7_1
 G  w_lb_7_2
 L  w_ub_7_2
 G  w_lb_7_3
 L  w_ub_7_3
 G  w_lb_7_4
 L  w_ub_7_4
 G  w_lb_7_5
 L  w_ub_7_5
 G  w_lb_7_6
 L  w_ub_7_6
 G  w_lb_7_7
 L  w_ub_7_7
 G  w_lb_7_8
 L  w_ub_7_8
 G  w_lb_7_9
 L  w_ub_7_9
 G  w_lb_7_10
 L  w_ub_7_10
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  w_lb_8_0
 L  w_ub_8_0
 G  w_lb_8_1
 L  w_ub_8_1
 G  w_lb_8_2
 L  w_ub_8_2
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  w_lb_9_0
 L  w_ub_9_0
 G  w_lb_9_1
 L  w_ub_9_1
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  w_lb_10_0
 L  w_ub_10_0
 G  w_lb_10_1
 L  w_ub_10_1
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  w_lb_11_0
 L  w_ub_11_0
 G  w_lb_11_1
 L  w_ub_11_1
 G  w_lb_11_2
 L  w_ub_11_2
 G  w_lb_11_3
 L  w_ub_11_3
 G  w_lb_11_4
 L  w_ub_11_4
 G  w_lb_11_5
 L  w_ub_11_5
 G  w_lb_11_6
 L  w_ub_11_6
 G  w_lb_11_7
 L  w_ub_11_7
 G  w_lb_11_8
 L  w_ub_11_8
 G  w_lb_11_9
 L  w_ub_11_9
 G  w_lb_11_10
 L  w_ub_11_10
 G  w_lb_11_11
 L  w_ub_11_11
 G  w_lb_11_12
 L  w_ub_11_12
 G  w_lb_11_13
 L  w_ub_11_13
 G  w_lb_11_14
 L  w_ub_11_14
 G  w_lb_11_15
 L  w_ub_11_15
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  w_lb_12_0
 L  w_ub_12_0
 G  w_lb_12_1
 L  w_ub_12_1
 G  w_lb_12_2
 L  w_ub_12_2
 G  w_lb_12_3
 L  w_ub_12_3
 G  w_lb_12_4
 L  w_ub_12_4
 G  w_lb_12_5
 L  w_ub_12_5
 G  w_lb_12_6
 L  w_ub_12_6
 G  w_lb_12_7
 L  w_ub_12_7
 G  w_lb_12_8
 L  w_ub_12_8
 G  w_lb_12_9
 L  w_ub_12_9
 G  w_lb_12_10
 L  w_ub_12_10
 G  w_lb_12_11
 L  w_ub_12_11
 G  w_lb_12_12
 L  w_ub_12_12
 G  w_lb_12_13
 L  w_ub_12_13
 G  w_lb_12_14
 L  w_ub_12_14
 G  w_lb_12_15
 L  w_ub_12_15
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  w_lb_13_0
 L  w_ub_13_0
 G  w_lb_13_1
 L  w_ub_13_1
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  w_lb_14_2
 L  w_ub_14_2
 G  w_lb_14_3
 L  w_ub_14_3
 G  w_lb_14_4
 L  w_ub_14_4
 G  w_lb_14_5
 L  w_ub_14_5
 G  w_lb_14_6
 L  w_ub_14_6
 G  w_lb_14_7
 L  w_ub_14_7
 G  w_lb_14_8
 L  w_ub_14_8
 G  w_lb_14_9
 L  w_ub_14_9
 G  w_lb_14_10
 L  w_ub_14_10
 G  w_lb_14_11
 L  w_ub_14_11
 G  w_lb_14_12
 L  w_ub_14_12
 G  w_lb_14_13
 L  w_ub_14_13
 G  w_lb_14_14
 L  w_ub_14_14
 G  w_lb_14_15
 L  w_ub_14_15
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  w_lb_15_0
 L  w_ub_15_0
 G  w_lb_15_1
 L  w_ub_15_1
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  w_lb_16_0
 L  w_ub_16_0
 G  w_lb_16_1
 L  w_ub_16_1
 G  w_lb_16_2
 L  w_ub_16_2
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  w_lb_17_2
 L  w_ub_17_2
 G  w_lb_17_3
 L  w_ub_17_3
 G  w_lb_17_4
 L  w_ub_17_4
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  w_lb_18_0
 L  w_ub_18_0
 G  w_lb_18_1
 L  w_ub_18_1
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  w_lb_19_0
 L  w_ub_19_0
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  w_lb_20_6
 L  w_ub_20_6
 G  w_lb_20_7
 L  w_ub_20_7
 G  w_lb_20_8
 L  w_ub_20_8
 G  w_lb_20_9
 L  w_ub_20_9
 G  w_lb_20_10
 L  w_ub_20_10
 G  w_lb_20_11
 L  w_ub_20_11
 G  w_lb_20_12
 L  w_ub_20_12
 G  w_lb_20_13
 L  w_ub_20_13
 G  w_lb_20_14
 L  w_ub_20_14
 G  w_lb_20_15
 L  w_ub_20_15
 E  normalized_inventory_20
 E  normalized_ratio_20
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  abs_p_1_2
 G  abs_m_1_2
 G  abs_p_1_3
 G  abs_m_1_3
 G  abs_p_1_4
 G  abs_m_1_4
 G  abs_p_1_5
 G  abs_m_1_5
 G  abs_p_1_6
 G  abs_m_1_6
 G  abs_p_1_7
 G  abs_m_1_7
 G  abs_p_1_8
 G  abs_m_1_8
 G  abs_p_1_9
 G  abs_m_1_9
 G  abs_p_1_10
 G  abs_m_1_10
 G  abs_p_1_11
 G  abs_m_1_11
 G  abs_p_1_12
 G  abs_m_1_12
 G  abs_p_1_13
 G  abs_m_1_13
 G  abs_p_1_14
 G  abs_m_1_14
 G  abs_p_1_15
 G  abs_m_1_15
 G  abs_p_1_16
 G  abs_m_1_16
 G  abs_p_1_17
 G  abs_m_1_17
 G  abs_p_1_18
 G  abs_m_1_18
 G  abs_p_1_19
 G  abs_m_1_19
 G  abs_p_1_20
 G  abs_m_1_20
 G  abs_p_2_3
 G  abs_m_2_3
 G  abs_p_2_4
 G  abs_m_2_4
 G  abs_p_2_5
 G  abs_m_2_5
 G  abs_p_2_6
 G  abs_m_2_6
 G  abs_p_2_7
 G  abs_m_2_7
 G  abs_p_2_8
 G  abs_m_2_8
 G  abs_p_2_9
 G  abs_m_2_9
 G  abs_p_2_10
 G  abs_m_2_10
 G  abs_p_2_11
 G  abs_m_2_11
 G  abs_p_2_12
 G  abs_m_2_12
 G  abs_p_2_13
 G  abs_m_2_13
 G  abs_p_2_14
 G  abs_m_2_14
 G  abs_p_2_15
 G  abs_m_2_15
 G  abs_p_2_16
 G  abs_m_2_16
 G  abs_p_2_17
 G  abs_m_2_17
 G  abs_p_2_18
 G  abs_m_2_18
 G  abs_p_2_19
 G  abs_m_2_19
 G  abs_p_2_20
 G  abs_m_2_20
 G  abs_p_3_4
 G  abs_m_3_4
 G  abs_p_3_5
 G  abs_m_3_5
 G  abs_p_3_6
 G  abs_m_3_6
 G  abs_p_3_7
 G  abs_m_3_7
 G  abs_p_3_8
 G  abs_m_3_8
 G  abs_p_3_9
 G  abs_m_3_9
 G  abs_p_3_10
 G  abs_m_3_10
 G  abs_p_3_11
 G  abs_m_3_11
 G  abs_p_3_12
 G  abs_m_3_12
 G  abs_p_3_13
 G  abs_m_3_13
 G  abs_p_3_14
 G  abs_m_3_14
 G  abs_p_3_15
 G  abs_m_3_15
 G  abs_p_3_16
 G  abs_m_3_16
 G  abs_p_3_17
 G  abs_m_3_17
 G  abs_p_3_18
 G  abs_m_3_18
 G  abs_p_3_19
 G  abs_m_3_19
 G  abs_p_3_20
 G  abs_m_3_20
 G  abs_p_4_5
 G  abs_m_4_5
 G  abs_p_4_6
 G  abs_m_4_6
 G  abs_p_4_7
 G  abs_m_4_7
 G  abs_p_4_8
 G  abs_m_4_8
 G  abs_p_4_9
 G  abs_m_4_9
 G  abs_p_4_10
 G  abs_m_4_10
 G  abs_p_4_11
 G  abs_m_4_11
 G  abs_p_4_12
 G  abs_m_4_12
 G  abs_p_4_13
 G  abs_m_4_13
 G  abs_p_4_14
 G  abs_m_4_14
 G  abs_p_4_15
 G  abs_m_4_15
 G  abs_p_4_16
 G  abs_m_4_16
 G  abs_p_4_17
 G  abs_m_4_17
 G  abs_p_4_18
 G  abs_m_4_18
 G  abs_p_4_19
 G  abs_m_4_19
 G  abs_p_4_20
 G  abs_m_4_20
 G  abs_p_5_6
 G  abs_m_5_6
 G  abs_p_5_7
 G  abs_m_5_7
 G  abs_p_5_8
 G  abs_m_5_8
 G  abs_p_5_9
 G  abs_m_5_9
 G  abs_p_5_10
 G  abs_m_5_10
 G  abs_p_5_11
 G  abs_m_5_11
 G  abs_p_5_12
 G  abs_m_5_12
 G  abs_p_5_13
 G  abs_m_5_13
 G  abs_p_5_14
 G  abs_m_5_14
 G  abs_p_5_15
 G  abs_m_5_15
 G  abs_p_5_16
 G  abs_m_5_16
 G  abs_p_5_17
 G  abs_m_5_17
 G  abs_p_5_18
 G  abs_m_5_18
 G  abs_p_5_19
 G  abs_m_5_19
 G  abs_p_5_20
 G  abs_m_5_20
 G  abs_p_6_7
 G  abs_m_6_7
 G  abs_p_6_8
 G  abs_m_6_8
 G  abs_p_6_9
 G  abs_m_6_9
 G  abs_p_6_10
 G  abs_m_6_10
 G  abs_p_6_11
 G  abs_m_6_11
 G  abs_p_6_12
 G  abs_m_6_12
 G  abs_p_6_13
 G  abs_m_6_13
 G  abs_p_6_14
 G  abs_m_6_14
 G  abs_p_6_15
 G  abs_m_6_15
 G  abs_p_6_16
 G  abs_m_6_16
 G  abs_p_6_17
 G  abs_m_6_17
 G  abs_p_6_18
 G  abs_m_6_18
 G  abs_p_6_19
 G  abs_m_6_19
 G  abs_p_6_20
 G  abs_m_6_20
 G  abs_p_7_8
 G  abs_m_7_8
 G  abs_p_7_9
 G  abs_m_7_9
 G  abs_p_7_10
 G  abs_m_7_10
 G  abs_p_7_11
 G  abs_m_7_11
 G  abs_p_7_12
 G  abs_m_7_12
 G  abs_p_7_13
 G  abs_m_7_13
 G  abs_p_7_14
 G  abs_m_7_14
 G  abs_p_7_15
 G  abs_m_7_15
 G  abs_p_7_16
 G  abs_m_7_16
 G  abs_p_7_17
 G  abs_m_7_17
 G  abs_p_7_18
 G  abs_m_7_18
 G  abs_p_7_19
 G  abs_m_7_19
 G  abs_p_7_20
 G  abs_m_7_20
 G  abs_p_8_9
 G  abs_m_8_9
 G  abs_p_8_10
 G  abs_m_8_10
 G  abs_p_8_11
 G  abs_m_8_11
 G  abs_p_8_12
 G  abs_m_8_12
 G  abs_p_8_13
 G  abs_m_8_13
 G  abs_p_8_14
 G  abs_m_8_14
 G  abs_p_8_15
 G  abs_m_8_15
 G  abs_p_8_16
 G  abs_m_8_16
 G  abs_p_8_17
 G  abs_m_8_17
 G  abs_p_8_18
 G  abs_m_8_18
 G  abs_p_8_19
 G  abs_m_8_19
 G  abs_p_8_20
 G  abs_m_8_20
 G  abs_p_9_10
 G  abs_m_9_10
 G  abs_p_9_11
 G  abs_m_9_11
 G  abs_p_9_12
 G  abs_m_9_12
 G  abs_p_9_13
 G  abs_m_9_13
 G  abs_p_9_14
 G  abs_m_9_14
 G  abs_p_9_15
 G  abs_m_9_15
 G  abs_p_9_16
 G  abs_m_9_16
 G  abs_p_9_17
 G  abs_m_9_17
 G  abs_p_9_18
 G  abs_m_9_18
 G  abs_p_9_19
 G  abs_m_9_19
 G  abs_p_9_20
 G  abs_m_9_20
 G  abs_p_10_11
 G  abs_m_10_11
 G  abs_p_10_12
 G  abs_m_10_12
 G  abs_p_10_13
 G  abs_m_10_13
 G  abs_p_10_14
 G  abs_m_10_14
 G  abs_p_10_15
 G  abs_m_10_15
 G  abs_p_10_16
 G  abs_m_10_16
 G  abs_p_10_17
 G  abs_m_10_17
 G  abs_p_10_18
 G  abs_m_10_18
 G  abs_p_10_19
 G  abs_m_10_19
 G  abs_p_10_20
 G  abs_m_10_20
 G  abs_p_11_12
 G  abs_m_11_12
 G  abs_p_11_13
 G  abs_m_11_13
 G  abs_p_11_14
 G  abs_m_11_14
 G  abs_p_11_15
 G  abs_m_11_15
 G  abs_p_11_16
 G  abs_m_11_16
 G  abs_p_11_17
 G  abs_m_11_17
 G  abs_p_11_18
 G  abs_m_11_18
 G  abs_p_11_19
 G  abs_m_11_19
 G  abs_p_11_20
 G  abs_m_11_20
 G  abs_p_12_13
 G  abs_m_12_13
 G  abs_p_12_14
 G  abs_m_12_14
 G  abs_p_12_15
 G  abs_m_12_15
 G  abs_p_12_16
 G  abs_m_12_16
 G  abs_p_12_17
 G  abs_m_12_17
 G  abs_p_12_18
 G  abs_m_12_18
 G  abs_p_12_19
 G  abs_m_12_19
 G  abs_p_12_20
 G  abs_m_12_20
 G  abs_p_13_14
 G  abs_m_13_14
 G  abs_p_13_15
 G  abs_m_13_15
 G  abs_p_13_16
 G  abs_m_13_16
 G  abs_p_13_17
 G  abs_m_13_17
 G  abs_p_13_18
 G  abs_m_13_18
 G  abs_p_13_19
 G  abs_m_13_19
 G  abs_p_13_20
 G  abs_m_13_20
 G  abs_p_14_15
 G  abs_m_14_15
 G  abs_p_14_16
 G  abs_m_14_16
 G  abs_p_14_17
 G  abs_m_14_17
 G  abs_p_14_18
 G  abs_m_14_18
 G  abs_p_14_19
 G  abs_m_14_19
 G  abs_p_14_20
 G  abs_m_14_20
 G  abs_p_15_16
 G  abs_m_15_16
 G  abs_p_15_17
 G  abs_m_15_17
 G  abs_p_15_18
 G  abs_m_15_18
 G  abs_p_15_19
 G  abs_m_15_19
 G  abs_p_15_20
 G  abs_m_15_20
 G  abs_p_16_17
 G  abs_m_16_17
 G  abs_p_16_18
 G  abs_m_16_18
 G  abs_p_16_19
 G  abs_m_16_19
 G  abs_p_16_20
 G  abs_m_16_20
 G  abs_p_17_18
 G  abs_m_17_18
 G  abs_p_17_19
 G  abs_m_17_19
 G  abs_p_17_20
 G  abs_m_17_20
 G  abs_p_18_19
 G  abs_m_18_19
 G  abs_p_18_20
 G  abs_m_18_20
 G  abs_p_19_20
 G  abs_m_19_20
 L  true_G_epigraph
 L  physical_G_upper
 G  old_normalized_TC
 G  old_normalized_TC2
 G  old_TS1 
 G  old_TS2 
 L  old_TS3 
 L  old_TS4 
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       3.2863847044708572e-02
    x[1,0]    onehot_1  1
    x[1,0]    w_lb_1_0  -5.0069541029207222e-02
    x[1,0]    w_ub_1_0  -7.9495268138801267e-01
    x[1,1]    OBJ       2.1909231363139048e-02
    x[1,1]    onehot_1  1
    x[1,1]    w_lb_1_1  -5.0069541029207222e-02
    x[1,1]    w_ub_1_1  -7.9495268138801267e-01
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,1]    old_TS1   -5.0069541029207222e-02
    x[1,1]    old_TS2   -7.9495268138801267e-01
    x[1,1]    old_TS3   -7.9495268138801267e-01
    x[1,1]    old_TS4   -5.0069541029207222e-02
    x[1,2]    OBJ       1.0954615681569527e-02
    x[1,2]    onehot_1  1
    x[1,2]    w_lb_1_2  -5.0069541029207222e-02
    x[1,2]    w_ub_1_2  -7.9495268138801267e-01
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,2]    old_TS1   -1.0013908205841444e-01
    x[1,2]    old_TS2   -1.5899053627760253e+00
    x[1,2]    old_TS3   -1.5899053627760253e+00
    x[1,2]    old_TS4   -1.0013908205841444e-01
    x[1,3]    OBJ       4.2567232944594006e-18
    x[1,3]    onehot_1  1
    x[1,3]    w_lb_1_3  -5.0069541029207222e-02
    x[1,3]    w_ub_1_3  -7.9495268138801267e-01
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[1,3]    old_TS1   -1.5020862308762167e-01
    x[1,3]    old_TS2   -2.3848580441640381e+00
    x[1,3]    old_TS3   -2.3848580441640381e+00
    x[1,3]    old_TS4   -1.5020862308762167e-01
    x[1,4]    OBJ       -1.0954615681569520e-02
    x[1,4]    onehot_1  1
    x[1,4]    w_lb_1_4  -5.0069541029207222e-02
    x[1,4]    w_ub_1_4  -7.9495268138801267e-01
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[1,4]    old_TS1   -2.0027816411682889e-01
    x[1,4]    old_TS2   -3.1798107255520507e+00
    x[1,4]    old_TS3   -3.1798107255520507e+00
    x[1,4]    old_TS4   -2.0027816411682889e-01
    x[1,5]    OBJ       -2.1909231363139044e-02
    x[1,5]    onehot_1  1
    x[1,5]    w_lb_1_5  -5.0069541029207222e-02
    x[1,5]    w_ub_1_5  -7.9495268138801267e-01
    x[1,5]    hard_lower  5
    x[1,5]    hard_upper  5
    x[1,5]    old_TS1   -2.5034770514603610e-01
    x[1,5]    old_TS2   -3.9747634069400632e+00
    x[1,5]    old_TS3   -3.9747634069400632e+00
    x[1,5]    old_TS4   -2.5034770514603610e-01
    x[1,6]    OBJ       -3.2863847044708572e-02
    x[1,6]    onehot_1  1
    x[1,6]    w_lb_1_6  -5.0069541029207222e-02
    x[1,6]    w_ub_1_6  -7.9495268138801267e-01
    x[1,6]    hard_lower  6
    x[1,6]    hard_upper  6
    x[1,6]    old_TS1   -3.0041724617524335e-01
    x[1,6]    old_TS2   -4.7697160883280763e+00
    x[1,6]    old_TS3   -4.7697160883280763e+00
    x[1,6]    old_TS4   -3.0041724617524335e-01
    x[1,7]    OBJ       -4.3818462726278096e-02
    x[1,7]    onehot_1  1
    x[1,7]    w_lb_1_7  -5.0069541029207222e-02
    x[1,7]    w_ub_1_7  -7.9495268138801267e-01
    x[1,7]    hard_lower  7
    x[1,7]    hard_upper  7
    x[1,7]    old_TS1   -3.5048678720445053e-01
    x[1,7]    old_TS2   -5.5646687697160884e+00
    x[1,7]    old_TS3   -5.5646687697160884e+00
    x[1,7]    old_TS4   -3.5048678720445053e-01
    x[1,8]    OBJ       -3.2863847044708579e-02
    x[1,8]    onehot_1  1
    x[1,8]    w_lb_1_8  -5.0069541029207222e-02
    x[1,8]    w_ub_1_8  -7.9495268138801267e-01
    x[1,8]    hard_lower  8
    x[1,8]    hard_upper  8
    x[1,8]    old_TS1   -4.0055632823365778e-01
    x[1,8]    old_TS2   -6.3596214511041014e+00
    x[1,8]    old_TS3   -6.3596214511041014e+00
    x[1,8]    old_TS4   -4.0055632823365778e-01
    x[1,9]    OBJ       -2.1909231363139051e-02
    x[1,9]    onehot_1  1
    x[1,9]    w_lb_1_9  -5.0069541029207222e-02
    x[1,9]    w_ub_1_9  -7.9495268138801267e-01
    x[1,9]    hard_lower  9
    x[1,9]    hard_upper  9
    x[1,9]    old_TS1   -0.450625869262865
    x[1,9]    old_TS2   -7.1545741324921144e+00
    x[1,9]    old_TS3   -7.1545741324921144e+00
    x[1,9]    old_TS4   -0.450625869262865
    x[1,10]   OBJ       -1.0954615681569529e-02
    x[1,10]   onehot_1  1
    x[1,10]   w_lb_1_10  -5.0069541029207222e-02
    x[1,10]   w_ub_1_10  -7.9495268138801267e-01
    x[1,10]   hard_lower  10
    x[1,10]   hard_upper  10
    x[1,10]   old_TS1   -5.0069541029207221e-01
    x[1,10]   old_TS2   -7.9495268138801265e+00
    x[1,10]   old_TS3   -7.9495268138801265e+00
    x[1,10]   old_TS4   -5.0069541029207221e-01
    x[1,11]   OBJ       -4.2567232944594006e-18
    x[1,11]   onehot_1  1
    x[1,11]   w_lb_1_11  -5.0069541029207222e-02
    x[1,11]   w_ub_1_11  -7.9495268138801267e-01
    x[1,11]   hard_lower  11
    x[1,11]   hard_upper  11
    x[1,11]   old_TS1   -5.5076495132127945e-01
    x[1,11]   old_TS2   -8.74447949526814
    x[1,11]   old_TS3   -8.74447949526814
    x[1,11]   old_TS4   -5.5076495132127945e-01
    x[1,12]   OBJ       1.0954615681569519e-02
    x[1,12]   onehot_1  1
    x[1,12]   w_lb_1_12  -5.0069541029207222e-02
    x[1,12]   w_ub_1_12  -7.9495268138801267e-01
    x[1,12]   hard_lower  12
    x[1,12]   hard_upper  12
    x[1,12]   old_TS1   -6.0083449235048669e-01
    x[1,12]   old_TS2   -9.5394321766561525e+00
    x[1,12]   old_TS3   -9.5394321766561525e+00
    x[1,12]   old_TS4   -6.0083449235048669e-01
    x[1,13]   OBJ       2.1909231363139041e-02
    x[1,13]   onehot_1  1
    x[1,13]   w_lb_1_13  -5.0069541029207222e-02
    x[1,13]   w_ub_1_13  -7.9495268138801267e-01
    x[1,13]   hard_lower  13
    x[1,13]   hard_upper  13
    x[1,13]   old_TS1   -6.5090403337969394e-01
    x[1,13]   old_TS2   -1.0334384858044166e+01
    x[1,13]   old_TS3   -1.0334384858044166e+01
    x[1,13]   old_TS4   -6.5090403337969394e-01
    x[1,14]   OBJ       3.2863847044708565e-02
    x[1,14]   onehot_1  1
    x[1,14]   w_lb_1_14  -5.0069541029207222e-02
    x[1,14]   w_ub_1_14  -7.9495268138801267e-01
    x[1,14]   hard_lower  14
    x[1,14]   hard_upper  14
    x[1,14]   old_TS1   -7.0097357440890107e-01
    x[1,14]   old_TS2   -1.1129337539432177e+01
    x[1,14]   old_TS3   -1.1129337539432177e+01
    x[1,14]   old_TS4   -7.0097357440890107e-01
    x[1,15]   OBJ       4.3818462726278089e-02
    x[1,15]   onehot_1  1
    x[1,15]   w_lb_1_15  -5.0069541029207222e-02
    x[1,15]   w_ub_1_15  -7.9495268138801267e-01
    x[1,15]   hard_lower  15
    x[1,15]   hard_upper  15
    x[1,15]   old_TS1   -7.5104311543810831e-01
    x[1,15]   old_TS2   -1.1924290220820190e+01
    x[1,15]   old_TS3   -1.1924290220820190e+01
    x[1,15]   old_TS4   -7.5104311543810831e-01
    x[2,0]    OBJ       6.3380304899829966e-03
    x[2,0]    onehot_2  1
    x[2,0]    w_lb_2_0  -5.0069541029207222e-02
    x[2,0]    w_ub_2_0  -7.9495268138801267e-01
    x[2,1]    OBJ       -6.3380304899829966e-03
    x[2,1]    onehot_2  1
    x[2,1]    w_lb_2_1  -5.0069541029207222e-02
    x[2,1]    w_ub_2_1  -7.9495268138801267e-01
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,1]    old_TS1   -5.0069541029207222e-02
    x[2,1]    old_TS2   -7.9495268138801267e-01
    x[2,1]    old_TS3   -7.9495268138801267e-01
    x[2,1]    old_TS4   -5.0069541029207222e-02
    x[3,0]    OBJ       5.0078236648368350e-02
    x[3,0]    onehot_3  1
    x[3,0]    w_lb_3_0  -5.0069541029207222e-02
    x[3,0]    w_ub_3_0  -7.9495268138801267e-01
    x[3,1]    OBJ       3.7558677486276261e-02
    x[3,1]    onehot_3  1
    x[3,1]    w_lb_3_1  -5.0069541029207222e-02
    x[3,1]    w_ub_3_1  -7.9495268138801267e-01
    x[3,1]    hard_lower  1
    x[3,1]    hard_upper  1
    x[3,1]    old_TS1   -5.0069541029207222e-02
    x[3,1]    old_TS2   -7.9495268138801267e-01
    x[3,1]    old_TS3   -7.9495268138801267e-01
    x[3,1]    old_TS4   -5.0069541029207222e-02
    x[3,2]    OBJ       2.5039118324184175e-02
    x[3,2]    onehot_3  1
    x[3,2]    w_lb_3_2  -5.0069541029207222e-02
    x[3,2]    w_ub_3_2  -7.9495268138801267e-01
    x[3,2]    hard_lower  2
    x[3,2]    hard_upper  2
    x[3,2]    old_TS1   -1.0013908205841444e-01
    x[3,2]    old_TS2   -1.5899053627760253e+00
    x[3,2]    old_TS3   -1.5899053627760253e+00
    x[3,2]    old_TS4   -1.0013908205841444e-01
    x[3,3]    OBJ       1.2519559162092088e-02
    x[3,3]    onehot_3  1
    x[3,3]    w_lb_3_3  -5.0069541029207222e-02
    x[3,3]    w_ub_3_3  -7.9495268138801267e-01
    x[3,3]    hard_lower  3
    x[3,3]    hard_upper  3
    x[3,3]    old_TS1   -1.5020862308762167e-01
    x[3,3]    old_TS2   -2.3848580441640381e+00
    x[3,3]    old_TS3   -2.3848580441640381e+00
    x[3,3]    old_TS4   -1.5020862308762167e-01
    x[3,4]    onehot_3  1
    x[3,4]    w_lb_3_4  -5.0069541029207222e-02
    x[3,4]    w_ub_3_4  -7.9495268138801267e-01
    x[3,4]    hard_lower  4
    x[3,4]    hard_upper  4
    x[3,4]    old_TS1   -2.0027816411682889e-01
    x[3,4]    old_TS2   -3.1798107255520507e+00
    x[3,4]    old_TS3   -3.1798107255520507e+00
    x[3,4]    old_TS4   -2.0027816411682889e-01
    x[3,5]    OBJ       -1.2519559162092088e-02
    x[3,5]    onehot_3  1
    x[3,5]    w_lb_3_5  -5.0069541029207222e-02
    x[3,5]    w_ub_3_5  -7.9495268138801267e-01
    x[3,5]    hard_lower  5
    x[3,5]    hard_upper  5
    x[3,5]    old_TS1   -2.5034770514603610e-01
    x[3,5]    old_TS2   -3.9747634069400632e+00
    x[3,5]    old_TS3   -3.9747634069400632e+00
    x[3,5]    old_TS4   -2.5034770514603610e-01
    x[3,6]    OBJ       -2.5039118324184175e-02
    x[3,6]    onehot_3  1
    x[3,6]    w_lb_3_6  -5.0069541029207222e-02
    x[3,6]    w_ub_3_6  -7.9495268138801267e-01
    x[3,6]    hard_lower  6
    x[3,6]    hard_upper  6
    x[3,6]    old_TS1   -3.0041724617524335e-01
    x[3,6]    old_TS2   -4.7697160883280763e+00
    x[3,6]    old_TS3   -4.7697160883280763e+00
    x[3,6]    old_TS4   -3.0041724617524335e-01
    x[3,7]    OBJ       -3.7558677486276268e-02
    x[3,7]    onehot_3  1
    x[3,7]    w_lb_3_7  -5.0069541029207222e-02
    x[3,7]    w_ub_3_7  -7.9495268138801267e-01
    x[3,7]    hard_lower  7
    x[3,7]    hard_upper  7
    x[3,7]    old_TS1   -3.5048678720445053e-01
    x[3,7]    old_TS2   -5.5646687697160884e+00
    x[3,7]    old_TS3   -5.5646687697160884e+00
    x[3,7]    old_TS4   -3.5048678720445053e-01
    x[3,8]    OBJ       -5.0078236648368350e-02
    x[3,8]    onehot_3  1
    x[3,8]    w_lb_3_8  -5.0069541029207222e-02
    x[3,8]    w_ub_3_8  -7.9495268138801267e-01
    x[3,8]    hard_lower  8
    x[3,8]    hard_upper  8
    x[3,8]    old_TS1   -4.0055632823365778e-01
    x[3,8]    old_TS2   -6.3596214511041014e+00
    x[3,8]    old_TS3   -6.3596214511041014e+00
    x[3,8]    old_TS4   -4.0055632823365778e-01
    x[3,9]    OBJ       -3.7558677486276268e-02
    x[3,9]    onehot_3  1
    x[3,9]    w_lb_3_9  -5.0069541029207222e-02
    x[3,9]    w_ub_3_9  -7.9495268138801267e-01
    x[3,9]    hard_lower  9
    x[3,9]    hard_upper  9
    x[3,9]    old_TS1   -0.450625869262865
    x[3,9]    old_TS2   -7.1545741324921144e+00
    x[3,9]    old_TS3   -7.1545741324921144e+00
    x[3,9]    old_TS4   -0.450625869262865
    x[3,10]   OBJ       -2.5039118324184175e-02
    x[3,10]   onehot_3  1
    x[3,10]   w_lb_3_10  -5.0069541029207222e-02
    x[3,10]   w_ub_3_10  -7.9495268138801267e-01
    x[3,10]   hard_lower  10
    x[3,10]   hard_upper  10
    x[3,10]   old_TS1   -5.0069541029207221e-01
    x[3,10]   old_TS2   -7.9495268138801265e+00
    x[3,10]   old_TS3   -7.9495268138801265e+00
    x[3,10]   old_TS4   -5.0069541029207221e-01
    x[3,11]   OBJ       -1.2519559162092088e-02
    x[3,11]   onehot_3  1
    x[3,11]   w_lb_3_11  -5.0069541029207222e-02
    x[3,11]   w_ub_3_11  -7.9495268138801267e-01
    x[3,11]   hard_lower  11
    x[3,11]   hard_upper  11
    x[3,11]   old_TS1   -5.5076495132127945e-01
    x[3,11]   old_TS2   -8.74447949526814
    x[3,11]   old_TS3   -8.74447949526814
    x[3,11]   old_TS4   -5.5076495132127945e-01
    x[3,12]   onehot_3  1
    x[3,12]   w_lb_3_12  -5.0069541029207222e-02
    x[3,12]   w_ub_3_12  -7.9495268138801267e-01
    x[3,12]   hard_lower  12
    x[3,12]   hard_upper  12
    x[3,12]   old_TS1   -6.0083449235048669e-01
    x[3,12]   old_TS2   -9.5394321766561525e+00
    x[3,12]   old_TS3   -9.5394321766561525e+00
    x[3,12]   old_TS4   -6.0083449235048669e-01
    x[3,13]   OBJ       1.2519559162092088e-02
    x[3,13]   onehot_3  1
    x[3,13]   w_lb_3_13  -5.0069541029207222e-02
    x[3,13]   w_ub_3_13  -7.9495268138801267e-01
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[3,13]   old_TS1   -6.5090403337969394e-01
    x[3,13]   old_TS2   -1.0334384858044166e+01
    x[3,13]   old_TS3   -1.0334384858044166e+01
    x[3,13]   old_TS4   -6.5090403337969394e-01
    x[3,14]   OBJ       2.5039118324184175e-02
    x[3,14]   onehot_3  1
    x[3,14]   w_lb_3_14  -5.0069541029207222e-02
    x[3,14]   w_ub_3_14  -7.9495268138801267e-01
    x[3,14]   hard_lower  14
    x[3,14]   hard_upper  14
    x[3,14]   old_TS1   -7.0097357440890107e-01
    x[3,14]   old_TS2   -1.1129337539432177e+01
    x[3,14]   old_TS3   -1.1129337539432177e+01
    x[3,14]   old_TS4   -7.0097357440890107e-01
    x[3,15]   OBJ       3.7558677486276261e-02
    x[3,15]   onehot_3  1
    x[3,15]   w_lb_3_15  -5.0069541029207222e-02
    x[3,15]   w_ub_3_15  -7.9495268138801267e-01
    x[3,15]   hard_lower  15
    x[3,15]   hard_upper  15
    x[3,15]   old_TS1   -7.5104311543810831e-01
    x[3,15]   old_TS2   -1.1924290220820190e+01
    x[3,15]   old_TS3   -1.1924290220820190e+01
    x[3,15]   old_TS4   -7.5104311543810831e-01
    x[3,16]   OBJ       5.0078236648368350e-02
    x[3,16]   onehot_3  1
    x[3,16]   w_lb_3_16  -5.0069541029207222e-02
    x[3,16]   w_ub_3_16  -7.9495268138801267e-01
    x[3,16]   hard_lower  16
    x[3,16]   hard_upper  16
    x[3,16]   old_TS1   -8.0111265646731555e-01
    x[3,16]   old_TS2   -1.2719242902208203e+01
    x[3,16]   old_TS3   -1.2719242902208203e+01
    x[3,16]   old_TS4   -8.0111265646731555e-01
    x[4,0]    OBJ       5.0078236648368350e-02
    x[4,0]    onehot_4  1
    x[4,0]    w_lb_4_0  -5.0069541029207222e-02
    x[4,0]    w_ub_4_0  -7.9495268138801267e-01
    x[4,1]    OBJ       3.7558677486276261e-02
    x[4,1]    onehot_4  1
    x[4,1]    w_lb_4_1  -5.0069541029207222e-02
    x[4,1]    w_ub_4_1  -7.9495268138801267e-01
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,1]    old_TS1   -5.0069541029207222e-02
    x[4,1]    old_TS2   -7.9495268138801267e-01
    x[4,1]    old_TS3   -7.9495268138801267e-01
    x[4,1]    old_TS4   -5.0069541029207222e-02
    x[4,2]    OBJ       2.5039118324184175e-02
    x[4,2]    onehot_4  1
    x[4,2]    w_lb_4_2  -5.0069541029207222e-02
    x[4,2]    w_ub_4_2  -7.9495268138801267e-01
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,2]    old_TS1   -1.0013908205841444e-01
    x[4,2]    old_TS2   -1.5899053627760253e+00
    x[4,2]    old_TS3   -1.5899053627760253e+00
    x[4,2]    old_TS4   -1.0013908205841444e-01
    x[4,3]    OBJ       1.2519559162092088e-02
    x[4,3]    onehot_4  1
    x[4,3]    w_lb_4_3  -5.0069541029207222e-02
    x[4,3]    w_ub_4_3  -7.9495268138801267e-01
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,3]    old_TS1   -1.5020862308762167e-01
    x[4,3]    old_TS2   -2.3848580441640381e+00
    x[4,3]    old_TS3   -2.3848580441640381e+00
    x[4,3]    old_TS4   -1.5020862308762167e-01
    x[4,4]    onehot_4  1
    x[4,4]    w_lb_4_4  -5.0069541029207222e-02
    x[4,4]    w_ub_4_4  -7.9495268138801267e-01
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,4]    old_TS1   -2.0027816411682889e-01
    x[4,4]    old_TS2   -3.1798107255520507e+00
    x[4,4]    old_TS3   -3.1798107255520507e+00
    x[4,4]    old_TS4   -2.0027816411682889e-01
    x[4,5]    OBJ       -1.2519559162092088e-02
    x[4,5]    onehot_4  1
    x[4,5]    w_lb_4_5  -5.0069541029207222e-02
    x[4,5]    w_ub_4_5  -7.9495268138801267e-01
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,5]    old_TS1   -2.5034770514603610e-01
    x[4,5]    old_TS2   -3.9747634069400632e+00
    x[4,5]    old_TS3   -3.9747634069400632e+00
    x[4,5]    old_TS4   -2.5034770514603610e-01
    x[4,6]    OBJ       -2.5039118324184175e-02
    x[4,6]    onehot_4  1
    x[4,6]    w_lb_4_6  -5.0069541029207222e-02
    x[4,6]    w_ub_4_6  -7.9495268138801267e-01
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,6]    old_TS1   -3.0041724617524335e-01
    x[4,6]    old_TS2   -4.7697160883280763e+00
    x[4,6]    old_TS3   -4.7697160883280763e+00
    x[4,6]    old_TS4   -3.0041724617524335e-01
    x[4,7]    OBJ       -3.7558677486276268e-02
    x[4,7]    onehot_4  1
    x[4,7]    w_lb_4_7  -5.0069541029207222e-02
    x[4,7]    w_ub_4_7  -7.9495268138801267e-01
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,7]    old_TS1   -3.5048678720445053e-01
    x[4,7]    old_TS2   -5.5646687697160884e+00
    x[4,7]    old_TS3   -5.5646687697160884e+00
    x[4,7]    old_TS4   -3.5048678720445053e-01
    x[4,8]    OBJ       -5.0078236648368350e-02
    x[4,8]    onehot_4  1
    x[4,8]    w_lb_4_8  -5.0069541029207222e-02
    x[4,8]    w_ub_4_8  -7.9495268138801267e-01
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,8]    old_TS1   -4.0055632823365778e-01
    x[4,8]    old_TS2   -6.3596214511041014e+00
    x[4,8]    old_TS3   -6.3596214511041014e+00
    x[4,8]    old_TS4   -4.0055632823365778e-01
    x[4,9]    OBJ       -3.7558677486276268e-02
    x[4,9]    onehot_4  1
    x[4,9]    w_lb_4_9  -5.0069541029207222e-02
    x[4,9]    w_ub_4_9  -7.9495268138801267e-01
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,9]    old_TS1   -0.450625869262865
    x[4,9]    old_TS2   -7.1545741324921144e+00
    x[4,9]    old_TS3   -7.1545741324921144e+00
    x[4,9]    old_TS4   -0.450625869262865
    x[4,10]   OBJ       -2.5039118324184175e-02
    x[4,10]   onehot_4  1
    x[4,10]   w_lb_4_10  -5.0069541029207222e-02
    x[4,10]   w_ub_4_10  -7.9495268138801267e-01
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,10]   old_TS1   -5.0069541029207221e-01
    x[4,10]   old_TS2   -7.9495268138801265e+00
    x[4,10]   old_TS3   -7.9495268138801265e+00
    x[4,10]   old_TS4   -5.0069541029207221e-01
    x[4,11]   OBJ       -1.2519559162092088e-02
    x[4,11]   onehot_4  1
    x[4,11]   w_lb_4_11  -5.0069541029207222e-02
    x[4,11]   w_ub_4_11  -7.9495268138801267e-01
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,11]   old_TS1   -5.5076495132127945e-01
    x[4,11]   old_TS2   -8.74447949526814
    x[4,11]   old_TS3   -8.74447949526814
    x[4,11]   old_TS4   -5.5076495132127945e-01
    x[4,12]   onehot_4  1
    x[4,12]   w_lb_4_12  -5.0069541029207222e-02
    x[4,12]   w_ub_4_12  -7.9495268138801267e-01
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,12]   old_TS1   -6.0083449235048669e-01
    x[4,12]   old_TS2   -9.5394321766561525e+00
    x[4,12]   old_TS3   -9.5394321766561525e+00
    x[4,12]   old_TS4   -6.0083449235048669e-01
    x[4,13]   OBJ       1.2519559162092088e-02
    x[4,13]   onehot_4  1
    x[4,13]   w_lb_4_13  -5.0069541029207222e-02
    x[4,13]   w_ub_4_13  -7.9495268138801267e-01
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,13]   old_TS1   -6.5090403337969394e-01
    x[4,13]   old_TS2   -1.0334384858044166e+01
    x[4,13]   old_TS3   -1.0334384858044166e+01
    x[4,13]   old_TS4   -6.5090403337969394e-01
    x[4,14]   OBJ       2.5039118324184175e-02
    x[4,14]   onehot_4  1
    x[4,14]   w_lb_4_14  -5.0069541029207222e-02
    x[4,14]   w_ub_4_14  -7.9495268138801267e-01
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,14]   old_TS1   -7.0097357440890107e-01
    x[4,14]   old_TS2   -1.1129337539432177e+01
    x[4,14]   old_TS3   -1.1129337539432177e+01
    x[4,14]   old_TS4   -7.0097357440890107e-01
    x[4,15]   OBJ       3.7558677486276261e-02
    x[4,15]   onehot_4  1
    x[4,15]   w_lb_4_15  -5.0069541029207222e-02
    x[4,15]   w_ub_4_15  -7.9495268138801267e-01
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[4,15]   old_TS1   -7.5104311543810831e-01
    x[4,15]   old_TS2   -1.1924290220820190e+01
    x[4,15]   old_TS3   -1.1924290220820190e+01
    x[4,15]   old_TS4   -7.5104311543810831e-01
    x[5,0]    OBJ       6.3380304899829966e-03
    x[5,0]    onehot_5  1
    x[5,0]    w_lb_5_0  -5.0069541029207222e-02
    x[5,0]    w_ub_5_0  -7.9495268138801267e-01
    x[5,1]    OBJ       -6.3380304899829966e-03
    x[5,1]    onehot_5  1
    x[5,1]    w_lb_5_1  -5.0069541029207222e-02
    x[5,1]    w_ub_5_1  -7.9495268138801267e-01
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,1]    old_TS1   -5.0069541029207222e-02
    x[5,1]    old_TS2   -7.9495268138801267e-01
    x[5,1]    old_TS3   -7.9495268138801267e-01
    x[5,1]    old_TS4   -5.0069541029207222e-02
    x[5,2]    OBJ       6.3380304899829966e-03
    x[5,2]    onehot_5  1
    x[5,2]    w_lb_5_2  -5.0069541029207222e-02
    x[5,2]    w_ub_5_2  -7.9495268138801267e-01
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,2]    old_TS1   -1.0013908205841444e-01
    x[5,2]    old_TS2   -1.5899053627760253e+00
    x[5,2]    old_TS3   -1.5899053627760253e+00
    x[5,2]    old_TS4   -1.0013908205841444e-01
    x[6,0]    OBJ       6.3380304899829966e-03
    x[6,0]    onehot_6  1
    x[6,0]    w_lb_6_0  -5.0069541029207222e-02
    x[6,0]    w_ub_6_0  -7.9495268138801267e-01
    x[6,1]    OBJ       -6.3380304899829966e-03
    x[6,1]    onehot_6  1
    x[6,1]    w_lb_6_1  -5.0069541029207222e-02
    x[6,1]    w_ub_6_1  -7.9495268138801267e-01
    x[6,1]    hard_lower  1
    x[6,1]    hard_upper  1
    x[6,1]    old_TS1   -5.0069541029207222e-02
    x[6,1]    old_TS2   -7.9495268138801267e-01
    x[6,1]    old_TS3   -7.9495268138801267e-01
    x[6,1]    old_TS4   -5.0069541029207222e-02
    x[7,0]    OBJ       1.9561824064893315e-02
    x[7,0]    onehot_7  1
    x[7,0]    w_lb_7_0  -5.0069541029207222e-02
    x[7,0]    w_ub_7_0  -7.9495268138801267e-01
    x[7,1]    OBJ       1.1737094438935987e-02
    x[7,1]    onehot_7  1
    x[7,1]    w_lb_7_1  -5.0069541029207222e-02
    x[7,1]    w_ub_7_1  -7.9495268138801267e-01
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,1]    old_TS1   -5.0069541029207222e-02
    x[7,1]    old_TS2   -7.9495268138801267e-01
    x[7,1]    old_TS3   -7.9495268138801267e-01
    x[7,1]    old_TS4   -5.0069541029207222e-02
    x[7,2]    OBJ       3.9123648129786590e-03
    x[7,2]    onehot_7  1
    x[7,2]    w_lb_7_2  -5.0069541029207222e-02
    x[7,2]    w_ub_7_2  -7.9495268138801267e-01
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,2]    old_TS1   -1.0013908205841444e-01
    x[7,2]    old_TS2   -1.5899053627760253e+00
    x[7,2]    old_TS3   -1.5899053627760253e+00
    x[7,2]    old_TS4   -1.0013908205841444e-01
    x[7,3]    OBJ       -3.9123648129786685e-03
    x[7,3]    onehot_7  1
    x[7,3]    w_lb_7_3  -5.0069541029207222e-02
    x[7,3]    w_ub_7_3  -7.9495268138801267e-01
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,3]    old_TS1   -1.5020862308762167e-01
    x[7,3]    old_TS2   -2.3848580441640381e+00
    x[7,3]    old_TS3   -2.3848580441640381e+00
    x[7,3]    old_TS4   -1.5020862308762167e-01
    x[7,4]    OBJ       -1.1737094438935997e-02
    x[7,4]    onehot_7  1
    x[7,4]    w_lb_7_4  -5.0069541029207222e-02
    x[7,4]    w_ub_7_4  -7.9495268138801267e-01
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,4]    old_TS1   -2.0027816411682889e-01
    x[7,4]    old_TS2   -3.1798107255520507e+00
    x[7,4]    old_TS3   -3.1798107255520507e+00
    x[7,4]    old_TS4   -2.0027816411682889e-01
    x[7,5]    OBJ       -1.9561824064893322e-02
    x[7,5]    onehot_7  1
    x[7,5]    w_lb_7_5  -5.0069541029207222e-02
    x[7,5]    w_ub_7_5  -7.9495268138801267e-01
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,5]    old_TS1   -2.5034770514603610e-01
    x[7,5]    old_TS2   -3.9747634069400632e+00
    x[7,5]    old_TS3   -3.9747634069400632e+00
    x[7,5]    old_TS4   -2.5034770514603610e-01
    x[7,6]    OBJ       -1.1737094438935992e-02
    x[7,6]    onehot_7  1
    x[7,6]    w_lb_7_6  -5.0069541029207222e-02
    x[7,6]    w_ub_7_6  -7.9495268138801267e-01
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,6]    old_TS1   -3.0041724617524335e-01
    x[7,6]    old_TS2   -4.7697160883280763e+00
    x[7,6]    old_TS3   -4.7697160883280763e+00
    x[7,6]    old_TS4   -3.0041724617524335e-01
    x[7,7]    OBJ       -3.9123648129786642e-03
    x[7,7]    onehot_7  1
    x[7,7]    w_lb_7_7  -5.0069541029207222e-02
    x[7,7]    w_ub_7_7  -7.9495268138801267e-01
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,7]    old_TS1   -3.5048678720445053e-01
    x[7,7]    old_TS2   -5.5646687697160884e+00
    x[7,7]    old_TS3   -5.5646687697160884e+00
    x[7,7]    old_TS4   -3.5048678720445053e-01
    x[7,8]    OBJ       3.9123648129786633e-03
    x[7,8]    onehot_7  1
    x[7,8]    w_lb_7_8  -5.0069541029207222e-02
    x[7,8]    w_ub_7_8  -7.9495268138801267e-01
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,8]    old_TS1   -4.0055632823365778e-01
    x[7,8]    old_TS2   -6.3596214511041014e+00
    x[7,8]    old_TS3   -6.3596214511041014e+00
    x[7,8]    old_TS4   -4.0055632823365778e-01
    x[7,9]    OBJ       1.1737094438935990e-02
    x[7,9]    onehot_7  1
    x[7,9]    w_lb_7_9  -5.0069541029207222e-02
    x[7,9]    w_ub_7_9  -7.9495268138801267e-01
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,9]    old_TS1   -0.450625869262865
    x[7,9]    old_TS2   -7.1545741324921144e+00
    x[7,9]    old_TS3   -7.1545741324921144e+00
    x[7,9]    old_TS4   -0.450625869262865
    x[7,10]   OBJ       1.9561824064893318e-02
    x[7,10]   onehot_7  1
    x[7,10]   w_lb_7_10  -5.0069541029207222e-02
    x[7,10]   w_ub_7_10  -7.9495268138801267e-01
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,10]   old_TS1   -5.0069541029207221e-01
    x[7,10]   old_TS2   -7.9495268138801265e+00
    x[7,10]   old_TS3   -7.9495268138801265e+00
    x[7,10]   old_TS4   -5.0069541029207221e-01
    x[8,0]    OBJ       6.3380304899829966e-03
    x[8,0]    onehot_8  1
    x[8,0]    w_lb_8_0  -5.0069541029207222e-02
    x[8,0]    w_ub_8_0  -7.9495268138801267e-01
    x[8,1]    OBJ       -6.3380304899829966e-03
    x[8,1]    onehot_8  1
    x[8,1]    w_lb_8_1  -5.0069541029207222e-02
    x[8,1]    w_ub_8_1  -7.9495268138801267e-01
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,1]    old_TS1   -5.0069541029207222e-02
    x[8,1]    old_TS2   -7.9495268138801267e-01
    x[8,1]    old_TS3   -7.9495268138801267e-01
    x[8,1]    old_TS4   -5.0069541029207222e-02
    x[8,2]    OBJ       6.3380304899829966e-03
    x[8,2]    onehot_8  1
    x[8,2]    w_lb_8_2  -5.0069541029207222e-02
    x[8,2]    w_ub_8_2  -7.9495268138801267e-01
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,2]    old_TS1   -1.0013908205841444e-01
    x[8,2]    old_TS2   -1.5899053627760253e+00
    x[8,2]    old_TS3   -1.5899053627760253e+00
    x[8,2]    old_TS4   -1.0013908205841444e-01
    x[9,0]    OBJ       6.3380304899829966e-03
    x[9,0]    onehot_9  1
    x[9,0]    w_lb_9_0  -5.0069541029207222e-02
    x[9,0]    w_ub_9_0  -7.9495268138801267e-01
    x[9,1]    OBJ       -6.3380304899829966e-03
    x[9,1]    onehot_9  1
    x[9,1]    w_lb_9_1  -5.0069541029207222e-02
    x[9,1]    w_ub_9_1  -7.9495268138801267e-01
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,1]    old_TS1   -5.0069541029207222e-02
    x[9,1]    old_TS2   -7.9495268138801267e-01
    x[9,1]    old_TS3   -7.9495268138801267e-01
    x[9,1]    old_TS4   -5.0069541029207222e-02
    x[10,0]   OBJ       6.3380304899829966e-03
    x[10,0]   onehot_10  1
    x[10,0]   w_lb_10_0  -5.0069541029207222e-02
    x[10,0]   w_ub_10_0  -7.9495268138801267e-01
    x[10,1]   OBJ       -6.3380304899829966e-03
    x[10,1]   onehot_10  1
    x[10,1]   w_lb_10_1  -5.0069541029207222e-02
    x[10,1]   w_ub_10_1  -7.9495268138801267e-01
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,1]   old_TS1   -5.0069541029207222e-02
    x[10,1]   old_TS2   -7.9495268138801267e-01
    x[10,1]   old_TS3   -7.9495268138801267e-01
    x[10,1]   old_TS4   -5.0069541029207222e-02
    x[11,0]   OBJ       5.0078236648368350e-02
    x[11,0]   onehot_11  1
    x[11,0]   w_lb_11_0  -5.0069541029207222e-02
    x[11,0]   w_ub_11_0  -7.9495268138801267e-01
    x[11,1]   OBJ       3.7558677486276261e-02
    x[11,1]   onehot_11  1
    x[11,1]   w_lb_11_1  -5.0069541029207222e-02
    x[11,1]   w_ub_11_1  -7.9495268138801267e-01
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,1]   old_TS1   -5.0069541029207222e-02
    x[11,1]   old_TS2   -7.9495268138801267e-01
    x[11,1]   old_TS3   -7.9495268138801267e-01
    x[11,1]   old_TS4   -5.0069541029207222e-02
    x[11,2]   OBJ       2.5039118324184175e-02
    x[11,2]   onehot_11  1
    x[11,2]   w_lb_11_2  -5.0069541029207222e-02
    x[11,2]   w_ub_11_2  -7.9495268138801267e-01
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,2]   old_TS1   -1.0013908205841444e-01
    x[11,2]   old_TS2   -1.5899053627760253e+00
    x[11,2]   old_TS3   -1.5899053627760253e+00
    x[11,2]   old_TS4   -1.0013908205841444e-01
    x[11,3]   OBJ       1.2519559162092088e-02
    x[11,3]   onehot_11  1
    x[11,3]   w_lb_11_3  -5.0069541029207222e-02
    x[11,3]   w_ub_11_3  -7.9495268138801267e-01
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,3]   old_TS1   -1.5020862308762167e-01
    x[11,3]   old_TS2   -2.3848580441640381e+00
    x[11,3]   old_TS3   -2.3848580441640381e+00
    x[11,3]   old_TS4   -1.5020862308762167e-01
    x[11,4]   onehot_11  1
    x[11,4]   w_lb_11_4  -5.0069541029207222e-02
    x[11,4]   w_ub_11_4  -7.9495268138801267e-01
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,4]   old_TS1   -2.0027816411682889e-01
    x[11,4]   old_TS2   -3.1798107255520507e+00
    x[11,4]   old_TS3   -3.1798107255520507e+00
    x[11,4]   old_TS4   -2.0027816411682889e-01
    x[11,5]   OBJ       -1.2519559162092088e-02
    x[11,5]   onehot_11  1
    x[11,5]   w_lb_11_5  -5.0069541029207222e-02
    x[11,5]   w_ub_11_5  -7.9495268138801267e-01
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,5]   old_TS1   -2.5034770514603610e-01
    x[11,5]   old_TS2   -3.9747634069400632e+00
    x[11,5]   old_TS3   -3.9747634069400632e+00
    x[11,5]   old_TS4   -2.5034770514603610e-01
    x[11,6]   OBJ       -2.5039118324184175e-02
    x[11,6]   onehot_11  1
    x[11,6]   w_lb_11_6  -5.0069541029207222e-02
    x[11,6]   w_ub_11_6  -7.9495268138801267e-01
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,6]   old_TS1   -3.0041724617524335e-01
    x[11,6]   old_TS2   -4.7697160883280763e+00
    x[11,6]   old_TS3   -4.7697160883280763e+00
    x[11,6]   old_TS4   -3.0041724617524335e-01
    x[11,7]   OBJ       -3.7558677486276268e-02
    x[11,7]   onehot_11  1
    x[11,7]   w_lb_11_7  -5.0069541029207222e-02
    x[11,7]   w_ub_11_7  -7.9495268138801267e-01
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,7]   old_TS1   -3.5048678720445053e-01
    x[11,7]   old_TS2   -5.5646687697160884e+00
    x[11,7]   old_TS3   -5.5646687697160884e+00
    x[11,7]   old_TS4   -3.5048678720445053e-01
    x[11,8]   OBJ       -5.0078236648368350e-02
    x[11,8]   onehot_11  1
    x[11,8]   w_lb_11_8  -5.0069541029207222e-02
    x[11,8]   w_ub_11_8  -7.9495268138801267e-01
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,8]   old_TS1   -4.0055632823365778e-01
    x[11,8]   old_TS2   -6.3596214511041014e+00
    x[11,8]   old_TS3   -6.3596214511041014e+00
    x[11,8]   old_TS4   -4.0055632823365778e-01
    x[11,9]   OBJ       -3.7558677486276268e-02
    x[11,9]   onehot_11  1
    x[11,9]   w_lb_11_9  -5.0069541029207222e-02
    x[11,9]   w_ub_11_9  -7.9495268138801267e-01
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,9]   old_TS1   -0.450625869262865
    x[11,9]   old_TS2   -7.1545741324921144e+00
    x[11,9]   old_TS3   -7.1545741324921144e+00
    x[11,9]   old_TS4   -0.450625869262865
    x[11,10]  OBJ       -2.5039118324184175e-02
    x[11,10]  onehot_11  1
    x[11,10]  w_lb_11_10  -5.0069541029207222e-02
    x[11,10]  w_ub_11_10  -7.9495268138801267e-01
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,10]  old_TS1   -5.0069541029207221e-01
    x[11,10]  old_TS2   -7.9495268138801265e+00
    x[11,10]  old_TS3   -7.9495268138801265e+00
    x[11,10]  old_TS4   -5.0069541029207221e-01
    x[11,11]  OBJ       -1.2519559162092088e-02
    x[11,11]  onehot_11  1
    x[11,11]  w_lb_11_11  -5.0069541029207222e-02
    x[11,11]  w_ub_11_11  -7.9495268138801267e-01
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,11]  old_TS1   -5.5076495132127945e-01
    x[11,11]  old_TS2   -8.74447949526814
    x[11,11]  old_TS3   -8.74447949526814
    x[11,11]  old_TS4   -5.5076495132127945e-01
    x[11,12]  onehot_11  1
    x[11,12]  w_lb_11_12  -5.0069541029207222e-02
    x[11,12]  w_ub_11_12  -7.9495268138801267e-01
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[11,12]  old_TS1   -6.0083449235048669e-01
    x[11,12]  old_TS2   -9.5394321766561525e+00
    x[11,12]  old_TS3   -9.5394321766561525e+00
    x[11,12]  old_TS4   -6.0083449235048669e-01
    x[11,13]  OBJ       1.2519559162092088e-02
    x[11,13]  onehot_11  1
    x[11,13]  w_lb_11_13  -5.0069541029207222e-02
    x[11,13]  w_ub_11_13  -7.9495268138801267e-01
    x[11,13]  hard_lower  13
    x[11,13]  hard_upper  13
    x[11,13]  old_TS1   -6.5090403337969394e-01
    x[11,13]  old_TS2   -1.0334384858044166e+01
    x[11,13]  old_TS3   -1.0334384858044166e+01
    x[11,13]  old_TS4   -6.5090403337969394e-01
    x[11,14]  OBJ       2.5039118324184175e-02
    x[11,14]  onehot_11  1
    x[11,14]  w_lb_11_14  -5.0069541029207222e-02
    x[11,14]  w_ub_11_14  -7.9495268138801267e-01
    x[11,14]  hard_lower  14
    x[11,14]  hard_upper  14
    x[11,14]  old_TS1   -7.0097357440890107e-01
    x[11,14]  old_TS2   -1.1129337539432177e+01
    x[11,14]  old_TS3   -1.1129337539432177e+01
    x[11,14]  old_TS4   -7.0097357440890107e-01
    x[11,15]  OBJ       3.7558677486276261e-02
    x[11,15]  onehot_11  1
    x[11,15]  w_lb_11_15  -5.0069541029207222e-02
    x[11,15]  w_ub_11_15  -7.9495268138801267e-01
    x[11,15]  hard_lower  15
    x[11,15]  hard_upper  15
    x[11,15]  old_TS1   -7.5104311543810831e-01
    x[11,15]  old_TS2   -1.1924290220820190e+01
    x[11,15]  old_TS3   -1.1924290220820190e+01
    x[11,15]  old_TS4   -7.5104311543810831e-01
    x[12,0]   OBJ       3.2863847044708572e-02
    x[12,0]   onehot_12  1
    x[12,0]   w_lb_12_0  -5.0069541029207222e-02
    x[12,0]   w_ub_12_0  -7.9495268138801267e-01
    x[12,1]   OBJ       2.1909231363139048e-02
    x[12,1]   onehot_12  1
    x[12,1]   w_lb_12_1  -5.0069541029207222e-02
    x[12,1]   w_ub_12_1  -7.9495268138801267e-01
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,1]   old_TS1   -5.0069541029207222e-02
    x[12,1]   old_TS2   -7.9495268138801267e-01
    x[12,1]   old_TS3   -7.9495268138801267e-01
    x[12,1]   old_TS4   -5.0069541029207222e-02
    x[12,2]   OBJ       1.0954615681569527e-02
    x[12,2]   onehot_12  1
    x[12,2]   w_lb_12_2  -5.0069541029207222e-02
    x[12,2]   w_ub_12_2  -7.9495268138801267e-01
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,2]   old_TS1   -1.0013908205841444e-01
    x[12,2]   old_TS2   -1.5899053627760253e+00
    x[12,2]   old_TS3   -1.5899053627760253e+00
    x[12,2]   old_TS4   -1.0013908205841444e-01
    x[12,3]   OBJ       4.2567232944594006e-18
    x[12,3]   onehot_12  1
    x[12,3]   w_lb_12_3  -5.0069541029207222e-02
    x[12,3]   w_ub_12_3  -7.9495268138801267e-01
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,3]   old_TS1   -1.5020862308762167e-01
    x[12,3]   old_TS2   -2.3848580441640381e+00
    x[12,3]   old_TS3   -2.3848580441640381e+00
    x[12,3]   old_TS4   -1.5020862308762167e-01
    x[12,4]   OBJ       -1.0954615681569520e-02
    x[12,4]   onehot_12  1
    x[12,4]   w_lb_12_4  -5.0069541029207222e-02
    x[12,4]   w_ub_12_4  -7.9495268138801267e-01
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,4]   old_TS1   -2.0027816411682889e-01
    x[12,4]   old_TS2   -3.1798107255520507e+00
    x[12,4]   old_TS3   -3.1798107255520507e+00
    x[12,4]   old_TS4   -2.0027816411682889e-01
    x[12,5]   OBJ       -2.1909231363139044e-02
    x[12,5]   onehot_12  1
    x[12,5]   w_lb_12_5  -5.0069541029207222e-02
    x[12,5]   w_ub_12_5  -7.9495268138801267e-01
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,5]   old_TS1   -2.5034770514603610e-01
    x[12,5]   old_TS2   -3.9747634069400632e+00
    x[12,5]   old_TS3   -3.9747634069400632e+00
    x[12,5]   old_TS4   -2.5034770514603610e-01
    x[12,6]   OBJ       -3.2863847044708572e-02
    x[12,6]   onehot_12  1
    x[12,6]   w_lb_12_6  -5.0069541029207222e-02
    x[12,6]   w_ub_12_6  -7.9495268138801267e-01
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,6]   old_TS1   -3.0041724617524335e-01
    x[12,6]   old_TS2   -4.7697160883280763e+00
    x[12,6]   old_TS3   -4.7697160883280763e+00
    x[12,6]   old_TS4   -3.0041724617524335e-01
    x[12,7]   OBJ       -4.3818462726278096e-02
    x[12,7]   onehot_12  1
    x[12,7]   w_lb_12_7  -5.0069541029207222e-02
    x[12,7]   w_ub_12_7  -7.9495268138801267e-01
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,7]   old_TS1   -3.5048678720445053e-01
    x[12,7]   old_TS2   -5.5646687697160884e+00
    x[12,7]   old_TS3   -5.5646687697160884e+00
    x[12,7]   old_TS4   -3.5048678720445053e-01
    x[12,8]   OBJ       -3.2863847044708579e-02
    x[12,8]   onehot_12  1
    x[12,8]   w_lb_12_8  -5.0069541029207222e-02
    x[12,8]   w_ub_12_8  -7.9495268138801267e-01
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,8]   old_TS1   -4.0055632823365778e-01
    x[12,8]   old_TS2   -6.3596214511041014e+00
    x[12,8]   old_TS3   -6.3596214511041014e+00
    x[12,8]   old_TS4   -4.0055632823365778e-01
    x[12,9]   OBJ       -2.1909231363139051e-02
    x[12,9]   onehot_12  1
    x[12,9]   w_lb_12_9  -5.0069541029207222e-02
    x[12,9]   w_ub_12_9  -7.9495268138801267e-01
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,9]   old_TS1   -0.450625869262865
    x[12,9]   old_TS2   -7.1545741324921144e+00
    x[12,9]   old_TS3   -7.1545741324921144e+00
    x[12,9]   old_TS4   -0.450625869262865
    x[12,10]  OBJ       -1.0954615681569529e-02
    x[12,10]  onehot_12  1
    x[12,10]  w_lb_12_10  -5.0069541029207222e-02
    x[12,10]  w_ub_12_10  -7.9495268138801267e-01
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,10]  old_TS1   -5.0069541029207221e-01
    x[12,10]  old_TS2   -7.9495268138801265e+00
    x[12,10]  old_TS3   -7.9495268138801265e+00
    x[12,10]  old_TS4   -5.0069541029207221e-01
    x[12,11]  OBJ       -4.2567232944594006e-18
    x[12,11]  onehot_12  1
    x[12,11]  w_lb_12_11  -5.0069541029207222e-02
    x[12,11]  w_ub_12_11  -7.9495268138801267e-01
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,11]  old_TS1   -5.5076495132127945e-01
    x[12,11]  old_TS2   -8.74447949526814
    x[12,11]  old_TS3   -8.74447949526814
    x[12,11]  old_TS4   -5.5076495132127945e-01
    x[12,12]  OBJ       1.0954615681569519e-02
    x[12,12]  onehot_12  1
    x[12,12]  w_lb_12_12  -5.0069541029207222e-02
    x[12,12]  w_ub_12_12  -7.9495268138801267e-01
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,12]  old_TS1   -6.0083449235048669e-01
    x[12,12]  old_TS2   -9.5394321766561525e+00
    x[12,12]  old_TS3   -9.5394321766561525e+00
    x[12,12]  old_TS4   -6.0083449235048669e-01
    x[12,13]  OBJ       2.1909231363139041e-02
    x[12,13]  onehot_12  1
    x[12,13]  w_lb_12_13  -5.0069541029207222e-02
    x[12,13]  w_ub_12_13  -7.9495268138801267e-01
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,13]  old_TS1   -6.5090403337969394e-01
    x[12,13]  old_TS2   -1.0334384858044166e+01
    x[12,13]  old_TS3   -1.0334384858044166e+01
    x[12,13]  old_TS4   -6.5090403337969394e-01
    x[12,14]  OBJ       3.2863847044708565e-02
    x[12,14]  onehot_12  1
    x[12,14]  w_lb_12_14  -5.0069541029207222e-02
    x[12,14]  w_ub_12_14  -7.9495268138801267e-01
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,14]  old_TS1   -7.0097357440890107e-01
    x[12,14]  old_TS2   -1.1129337539432177e+01
    x[12,14]  old_TS3   -1.1129337539432177e+01
    x[12,14]  old_TS4   -7.0097357440890107e-01
    x[12,15]  OBJ       4.3818462726278089e-02
    x[12,15]  onehot_12  1
    x[12,15]  w_lb_12_15  -5.0069541029207222e-02
    x[12,15]  w_ub_12_15  -7.9495268138801267e-01
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[12,15]  old_TS1   -7.5104311543810831e-01
    x[12,15]  old_TS2   -1.1924290220820190e+01
    x[12,15]  old_TS3   -1.1924290220820190e+01
    x[12,15]  old_TS4   -7.5104311543810831e-01
    x[13,0]   OBJ       6.3380304899829966e-03
    x[13,0]   onehot_13  1
    x[13,0]   w_lb_13_0  -5.0069541029207222e-02
    x[13,0]   w_ub_13_0  -7.9495268138801267e-01
    x[13,1]   OBJ       -6.3380304899829966e-03
    x[13,1]   onehot_13  1
    x[13,1]   w_lb_13_1  -5.0069541029207222e-02
    x[13,1]   w_ub_13_1  -7.9495268138801267e-01
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,1]   old_TS1   -5.0069541029207222e-02
    x[13,1]   old_TS2   -7.9495268138801267e-01
    x[13,1]   old_TS3   -7.9495268138801267e-01
    x[13,1]   old_TS4   -5.0069541029207222e-02
    x[14,2]   OBJ       1.0954615681569527e-02
    x[14,2]   onehot_14  1
    x[14,2]   w_lb_14_2  -5.0069541029207222e-02
    x[14,2]   w_ub_14_2  -7.9495268138801267e-01
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,2]   old_TS1   -1.0013908205841444e-01
    x[14,2]   old_TS2   -1.5899053627760253e+00
    x[14,2]   old_TS3   -1.5899053627760253e+00
    x[14,2]   old_TS4   -1.0013908205841444e-01
    x[14,3]   OBJ       4.2567232944594006e-18
    x[14,3]   onehot_14  1
    x[14,3]   w_lb_14_3  -5.0069541029207222e-02
    x[14,3]   w_ub_14_3  -7.9495268138801267e-01
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,3]   old_TS1   -1.5020862308762167e-01
    x[14,3]   old_TS2   -2.3848580441640381e+00
    x[14,3]   old_TS3   -2.3848580441640381e+00
    x[14,3]   old_TS4   -1.5020862308762167e-01
    x[14,4]   OBJ       -1.0954615681569520e-02
    x[14,4]   onehot_14  1
    x[14,4]   w_lb_14_4  -5.0069541029207222e-02
    x[14,4]   w_ub_14_4  -7.9495268138801267e-01
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,4]   old_TS1   -2.0027816411682889e-01
    x[14,4]   old_TS2   -3.1798107255520507e+00
    x[14,4]   old_TS3   -3.1798107255520507e+00
    x[14,4]   old_TS4   -2.0027816411682889e-01
    x[14,5]   OBJ       -2.1909231363139044e-02
    x[14,5]   onehot_14  1
    x[14,5]   w_lb_14_5  -5.0069541029207222e-02
    x[14,5]   w_ub_14_5  -7.9495268138801267e-01
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,5]   old_TS1   -2.5034770514603610e-01
    x[14,5]   old_TS2   -3.9747634069400632e+00
    x[14,5]   old_TS3   -3.9747634069400632e+00
    x[14,5]   old_TS4   -2.5034770514603610e-01
    x[14,6]   OBJ       -3.2863847044708572e-02
    x[14,6]   onehot_14  1
    x[14,6]   w_lb_14_6  -5.0069541029207222e-02
    x[14,6]   w_ub_14_6  -7.9495268138801267e-01
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,6]   old_TS1   -3.0041724617524335e-01
    x[14,6]   old_TS2   -4.7697160883280763e+00
    x[14,6]   old_TS3   -4.7697160883280763e+00
    x[14,6]   old_TS4   -3.0041724617524335e-01
    x[14,7]   OBJ       -4.3818462726278096e-02
    x[14,7]   onehot_14  1
    x[14,7]   w_lb_14_7  -5.0069541029207222e-02
    x[14,7]   w_ub_14_7  -7.9495268138801267e-01
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,7]   old_TS1   -3.5048678720445053e-01
    x[14,7]   old_TS2   -5.5646687697160884e+00
    x[14,7]   old_TS3   -5.5646687697160884e+00
    x[14,7]   old_TS4   -3.5048678720445053e-01
    x[14,8]   OBJ       -3.2863847044708579e-02
    x[14,8]   onehot_14  1
    x[14,8]   w_lb_14_8  -5.0069541029207222e-02
    x[14,8]   w_ub_14_8  -7.9495268138801267e-01
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,8]   old_TS1   -4.0055632823365778e-01
    x[14,8]   old_TS2   -6.3596214511041014e+00
    x[14,8]   old_TS3   -6.3596214511041014e+00
    x[14,8]   old_TS4   -4.0055632823365778e-01
    x[14,9]   OBJ       -2.1909231363139051e-02
    x[14,9]   onehot_14  1
    x[14,9]   w_lb_14_9  -5.0069541029207222e-02
    x[14,9]   w_ub_14_9  -7.9495268138801267e-01
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,9]   old_TS1   -0.450625869262865
    x[14,9]   old_TS2   -7.1545741324921144e+00
    x[14,9]   old_TS3   -7.1545741324921144e+00
    x[14,9]   old_TS4   -0.450625869262865
    x[14,10]  OBJ       -1.0954615681569529e-02
    x[14,10]  onehot_14  1
    x[14,10]  w_lb_14_10  -5.0069541029207222e-02
    x[14,10]  w_ub_14_10  -7.9495268138801267e-01
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,10]  old_TS1   -5.0069541029207221e-01
    x[14,10]  old_TS2   -7.9495268138801265e+00
    x[14,10]  old_TS3   -7.9495268138801265e+00
    x[14,10]  old_TS4   -5.0069541029207221e-01
    x[14,11]  OBJ       -4.2567232944594006e-18
    x[14,11]  onehot_14  1
    x[14,11]  w_lb_14_11  -5.0069541029207222e-02
    x[14,11]  w_ub_14_11  -7.9495268138801267e-01
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,11]  old_TS1   -5.5076495132127945e-01
    x[14,11]  old_TS2   -8.74447949526814
    x[14,11]  old_TS3   -8.74447949526814
    x[14,11]  old_TS4   -5.5076495132127945e-01
    x[14,12]  OBJ       1.0954615681569519e-02
    x[14,12]  onehot_14  1
    x[14,12]  w_lb_14_12  -5.0069541029207222e-02
    x[14,12]  w_ub_14_12  -7.9495268138801267e-01
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,12]  old_TS1   -6.0083449235048669e-01
    x[14,12]  old_TS2   -9.5394321766561525e+00
    x[14,12]  old_TS3   -9.5394321766561525e+00
    x[14,12]  old_TS4   -6.0083449235048669e-01
    x[14,13]  OBJ       2.1909231363139041e-02
    x[14,13]  onehot_14  1
    x[14,13]  w_lb_14_13  -5.0069541029207222e-02
    x[14,13]  w_ub_14_13  -7.9495268138801267e-01
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,13]  old_TS1   -6.5090403337969394e-01
    x[14,13]  old_TS2   -1.0334384858044166e+01
    x[14,13]  old_TS3   -1.0334384858044166e+01
    x[14,13]  old_TS4   -6.5090403337969394e-01
    x[14,14]  OBJ       3.2863847044708565e-02
    x[14,14]  onehot_14  1
    x[14,14]  w_lb_14_14  -5.0069541029207222e-02
    x[14,14]  w_ub_14_14  -7.9495268138801267e-01
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,14]  old_TS1   -7.0097357440890107e-01
    x[14,14]  old_TS2   -1.1129337539432177e+01
    x[14,14]  old_TS3   -1.1129337539432177e+01
    x[14,14]  old_TS4   -7.0097357440890107e-01
    x[14,15]  OBJ       4.3818462726278089e-02
    x[14,15]  onehot_14  1
    x[14,15]  w_lb_14_15  -5.0069541029207222e-02
    x[14,15]  w_ub_14_15  -7.9495268138801267e-01
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[14,15]  old_TS1   -7.5104311543810831e-01
    x[14,15]  old_TS2   -1.1924290220820190e+01
    x[14,15]  old_TS3   -1.1924290220820190e+01
    x[14,15]  old_TS4   -7.5104311543810831e-01
    x[15,0]   OBJ       6.3380304899829966e-03
    x[15,0]   onehot_15  1
    x[15,0]   w_lb_15_0  -5.0069541029207222e-02
    x[15,0]   w_ub_15_0  -7.9495268138801267e-01
    x[15,1]   OBJ       -6.3380304899829966e-03
    x[15,1]   onehot_15  1
    x[15,1]   w_lb_15_1  -5.0069541029207222e-02
    x[15,1]   w_ub_15_1  -7.9495268138801267e-01
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,1]   old_TS1   -5.0069541029207222e-02
    x[15,1]   old_TS2   -7.9495268138801267e-01
    x[15,1]   old_TS3   -7.9495268138801267e-01
    x[15,1]   old_TS4   -5.0069541029207222e-02
    x[16,0]   OBJ       6.3380304899829966e-03
    x[16,0]   onehot_16  1
    x[16,0]   w_lb_16_0  -5.0069541029207222e-02
    x[16,0]   w_ub_16_0  -7.9495268138801267e-01
    x[16,1]   OBJ       -6.3380304899829966e-03
    x[16,1]   onehot_16  1
    x[16,1]   w_lb_16_1  -5.0069541029207222e-02
    x[16,1]   w_ub_16_1  -7.9495268138801267e-01
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,1]   old_TS1   -5.0069541029207222e-02
    x[16,1]   old_TS2   -7.9495268138801267e-01
    x[16,1]   old_TS3   -7.9495268138801267e-01
    x[16,1]   old_TS4   -5.0069541029207222e-02
    x[16,2]   OBJ       6.3380304899829966e-03
    x[16,2]   onehot_16  1
    x[16,2]   w_lb_16_2  -5.0069541029207222e-02
    x[16,2]   w_ub_16_2  -7.9495268138801267e-01
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,2]   old_TS1   -1.0013908205841444e-01
    x[16,2]   old_TS2   -1.5899053627760253e+00
    x[16,2]   old_TS3   -1.5899053627760253e+00
    x[16,2]   old_TS4   -1.0013908205841444e-01
    x[17,2]   OBJ       1.4084512199962212e-02
    x[17,2]   onehot_17  1
    x[17,2]   w_lb_17_2  -5.0069541029207222e-02
    x[17,2]   w_ub_17_2  -7.9495268138801267e-01
    x[17,2]   hard_lower  2
    x[17,2]   hard_upper  2
    x[17,2]   old_TS1   -1.0013908205841444e-01
    x[17,2]   old_TS2   -1.5899053627760253e+00
    x[17,2]   old_TS3   -1.5899053627760253e+00
    x[17,2]   old_TS4   -1.0013908205841444e-01
    x[17,3]   onehot_17  1
    x[17,3]   w_lb_17_3  -5.0069541029207222e-02
    x[17,3]   w_ub_17_3  -7.9495268138801267e-01
    x[17,3]   hard_lower  3
    x[17,3]   hard_upper  3
    x[17,3]   old_TS1   -1.5020862308762167e-01
    x[17,3]   old_TS2   -2.3848580441640381e+00
    x[17,3]   old_TS3   -2.3848580441640381e+00
    x[17,3]   old_TS4   -1.5020862308762167e-01
    x[17,4]   OBJ       -1.4084512199962214e-02
    x[17,4]   onehot_17  1
    x[17,4]   w_lb_17_4  -5.0069541029207222e-02
    x[17,4]   w_ub_17_4  -7.9495268138801267e-01
    x[17,4]   hard_lower  4
    x[17,4]   hard_upper  4
    x[17,4]   old_TS1   -2.0027816411682889e-01
    x[17,4]   old_TS2   -3.1798107255520507e+00
    x[17,4]   old_TS3   -3.1798107255520507e+00
    x[17,4]   old_TS4   -2.0027816411682889e-01
    x[18,0]   OBJ       5.4773078407847611e-03
    x[18,0]   onehot_18  1
    x[18,0]   w_lb_18_0  -5.0069541029207222e-02
    x[18,0]   w_ub_18_0  -7.9495268138801267e-01
    x[18,1]   OBJ       -5.4773078407847620e-03
    x[18,1]   onehot_18  1
    x[18,1]   w_lb_18_1  -5.0069541029207222e-02
    x[18,1]   w_ub_18_1  -7.9495268138801267e-01
    x[18,1]   hard_lower  1
    x[18,1]   hard_upper  1
    x[18,1]   old_TS1   -5.0069541029207222e-02
    x[18,1]   old_TS2   -7.9495268138801267e-01
    x[18,1]   old_TS3   -7.9495268138801267e-01
    x[18,1]   old_TS4   -5.0069541029207222e-02
    x[19,0]   onehot_19  1
    x[19,0]   w_lb_19_0  -5.0069541029207222e-02
    x[19,0]   w_ub_19_0  -7.9495268138801267e-01
    x[20,6]   OBJ       -1.8779338743138134e-02
    x[20,6]   onehot_20  1
    x[20,6]   w_lb_20_6  -5.0069541029207222e-02
    x[20,6]   w_ub_20_6  -7.9495268138801267e-01
    x[20,6]   hard_lower  6
    x[20,6]   hard_upper  6
    x[20,6]   old_TS1   -3.0041724617524335e-01
    x[20,6]   old_TS2   -4.7697160883280763e+00
    x[20,6]   old_TS3   -4.7697160883280763e+00
    x[20,6]   old_TS4   -3.0041724617524335e-01
    x[20,7]   OBJ       -3.1298897905230223e-02
    x[20,7]   onehot_20  1
    x[20,7]   w_lb_20_7  -5.0069541029207222e-02
    x[20,7]   w_ub_20_7  -7.9495268138801267e-01
    x[20,7]   hard_lower  7
    x[20,7]   hard_upper  7
    x[20,7]   old_TS1   -3.5048678720445053e-01
    x[20,7]   old_TS2   -5.5646687697160884e+00
    x[20,7]   old_TS3   -5.5646687697160884e+00
    x[20,7]   old_TS4   -3.5048678720445053e-01
    x[20,8]   OBJ       -4.3818457067322313e-02
    x[20,8]   onehot_20  1
    x[20,8]   w_lb_20_8  -5.0069541029207222e-02
    x[20,8]   w_ub_20_8  -7.9495268138801267e-01
    x[20,8]   hard_lower  8
    x[20,8]   hard_upper  8
    x[20,8]   old_TS1   -4.0055632823365778e-01
    x[20,8]   old_TS2   -6.3596214511041014e+00
    x[20,8]   old_TS3   -6.3596214511041014e+00
    x[20,8]   old_TS4   -4.0055632823365778e-01
    x[20,9]   OBJ       -3.1298897905230223e-02
    x[20,9]   onehot_20  1
    x[20,9]   w_lb_20_9  -5.0069541029207222e-02
    x[20,9]   w_ub_20_9  -7.9495268138801267e-01
    x[20,9]   hard_lower  9
    x[20,9]   hard_upper  9
    x[20,9]   old_TS1   -0.450625869262865
    x[20,9]   old_TS2   -7.1545741324921144e+00
    x[20,9]   old_TS3   -7.1545741324921144e+00
    x[20,9]   old_TS4   -0.450625869262865
    x[20,10]  OBJ       -1.8779338743138134e-02
    x[20,10]  onehot_20  1
    x[20,10]  w_lb_20_10  -5.0069541029207222e-02
    x[20,10]  w_ub_20_10  -7.9495268138801267e-01
    x[20,10]  hard_lower  10
    x[20,10]  hard_upper  10
    x[20,10]  old_TS1   -5.0069541029207221e-01
    x[20,10]  old_TS2   -7.9495268138801265e+00
    x[20,10]  old_TS3   -7.9495268138801265e+00
    x[20,10]  old_TS4   -5.0069541029207221e-01
    x[20,11]  OBJ       -6.2597795810460438e-03
    x[20,11]  onehot_20  1
    x[20,11]  w_lb_20_11  -5.0069541029207222e-02
    x[20,11]  w_ub_20_11  -7.9495268138801267e-01
    x[20,11]  hard_lower  11
    x[20,11]  hard_upper  11
    x[20,11]  old_TS1   -5.5076495132127945e-01
    x[20,11]  old_TS2   -8.74447949526814
    x[20,11]  old_TS3   -8.74447949526814
    x[20,11]  old_TS4   -5.5076495132127945e-01
    x[20,12]  OBJ       6.2597795810460438e-03
    x[20,12]  onehot_20  1
    x[20,12]  w_lb_20_12  -5.0069541029207222e-02
    x[20,12]  w_ub_20_12  -7.9495268138801267e-01
    x[20,12]  hard_lower  12
    x[20,12]  hard_upper  12
    x[20,12]  old_TS1   -6.0083449235048669e-01
    x[20,12]  old_TS2   -9.5394321766561525e+00
    x[20,12]  old_TS3   -9.5394321766561525e+00
    x[20,12]  old_TS4   -6.0083449235048669e-01
    x[20,13]  OBJ       1.8779338743138130e-02
    x[20,13]  onehot_20  1
    x[20,13]  w_lb_20_13  -5.0069541029207222e-02
    x[20,13]  w_ub_20_13  -7.9495268138801267e-01
    x[20,13]  hard_lower  13
    x[20,13]  hard_upper  13
    x[20,13]  old_TS1   -6.5090403337969394e-01
    x[20,13]  old_TS2   -1.0334384858044166e+01
    x[20,13]  old_TS3   -1.0334384858044166e+01
    x[20,13]  old_TS4   -6.5090403337969394e-01
    x[20,14]  OBJ       3.1298897905230216e-02
    x[20,14]  onehot_20  1
    x[20,14]  w_lb_20_14  -5.0069541029207222e-02
    x[20,14]  w_ub_20_14  -7.9495268138801267e-01
    x[20,14]  hard_lower  14
    x[20,14]  hard_upper  14
    x[20,14]  old_TS1   -7.0097357440890107e-01
    x[20,14]  old_TS2   -1.1129337539432177e+01
    x[20,14]  old_TS3   -1.1129337539432177e+01
    x[20,14]  old_TS4   -7.0097357440890107e-01
    x[20,15]  OBJ       4.3818457067322306e-02
    x[20,15]  onehot_20  1
    x[20,15]  w_lb_20_15  -5.0069541029207222e-02
    x[20,15]  w_ub_20_15  -7.9495268138801267e-01
    x[20,15]  hard_lower  15
    x[20,15]  hard_upper  15
    x[20,15]  old_TS1   -7.5104311543810831e-01
    x[20,15]  old_TS2   -1.1924290220820190e+01
    x[20,15]  old_TS3   -1.1924290220820190e+01
    x[20,15]  old_TS4   -7.5104311543810831e-01
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    w_lb_1_0  1
    w[1,0]    w_ub_1_0  1
    w[1,1]    mass_1    1
    w[1,1]    w_lb_1_1  1
    w[1,1]    w_ub_1_1  1
    w[1,1]    normalized_inventory_1  -1
    w[1,1]    old_normalized_TC  -1.4285714285714285e-01
    w[1,1]    old_normalized_TC2  2.8571428571428570e-01
    w[1,2]    mass_1    1
    w[1,2]    w_lb_1_2  1
    w[1,2]    w_ub_1_2  1
    w[1,2]    normalized_inventory_1  -2
    w[1,2]    old_normalized_TC  -4.2857142857142855e-01
    w[1,2]    old_normalized_TC2  3.6507936507936506e-01
    w[1,3]    mass_1    1
    w[1,3]    w_lb_1_3  1
    w[1,3]    w_ub_1_3  1
    w[1,3]    normalized_inventory_1  -3
    w[1,3]    old_normalized_TC  -7.1428571428571419e-01
    w[1,3]    old_normalized_TC2  2.2222222222222221e-01
    w[1,4]    mass_1    1
    w[1,4]    w_lb_1_4  1
    w[1,4]    w_ub_1_4  1
    w[1,4]    normalized_inventory_1  -4
    w[1,4]    old_normalized_TC  -1.1269841269841268e+00
    w[1,4]    old_normalized_TC2  -4.7619047619047616e-02
    w[1,5]    mass_1    1
    w[1,5]    w_lb_1_5  1
    w[1,5]    w_ub_1_5  1
    w[1,5]    normalized_inventory_1  -5
    w[1,5]    old_normalized_TC  -1.5555555555555554e+00
    w[1,5]    old_normalized_TC2  -3.3333333333333331e-01
    w[1,6]    mass_1    1
    w[1,6]    w_lb_1_6  1
    w[1,6]    w_ub_1_6  1
    w[1,6]    normalized_inventory_1  -6
    w[1,6]    old_normalized_TC  -1.9841269841269840e+00
    w[1,6]    old_normalized_TC2  -0.726190476190476
    w[1,7]    mass_1    1
    w[1,7]    w_lb_1_7  1
    w[1,7]    w_ub_1_7  1
    w[1,7]    normalized_inventory_1  -7
    w[1,7]    old_normalized_TC  -2.5376984126984121e+00
    w[1,7]    old_normalized_TC2  -1.2797619047619044e+00
    w[1,8]    mass_1    1
    w[1,8]    w_lb_1_8  1
    w[1,8]    w_ub_1_8  1
    w[1,8]    normalized_inventory_1  -8
    w[1,8]    old_normalized_TC  -3.9841269841269833e+00
    w[1,8]    old_normalized_TC2  -2.7261904761904754e+00
    w[1,9]    mass_1    1
    w[1,9]    w_lb_1_9  1
    w[1,9]    w_ub_1_9  1
    w[1,9]    normalized_inventory_1  -9
    w[1,9]    old_normalized_TC  -5.5555555555555545e+00
    w[1,9]    old_normalized_TC2  -4.2976190476190466e+00
    w[1,10]   mass_1    1
    w[1,10]   w_lb_1_10  1
    w[1,10]   w_ub_1_10  1
    w[1,10]   normalized_inventory_1  -10
    w[1,10]   old_normalized_TC  -7.2698412698412689e+00
    w[1,10]   old_normalized_TC2  -6.0119047619047610e+00
    w[1,11]   mass_1    1
    w[1,11]   w_lb_1_11  1
    w[1,11]   w_ub_1_11  1
    w[1,11]   normalized_inventory_1  -11
    w[1,11]   old_normalized_TC  -8.9841269841269824e+00
    w[1,11]   old_normalized_TC2  -7.7261904761904745e+00
    w[1,12]   mass_1    1
    w[1,12]   w_lb_1_12  1
    w[1,12]   w_ub_1_12  1
    w[1,12]   normalized_inventory_1  -12
    w[1,12]   old_normalized_TC  -1.0812698412698410e+01
    w[1,12]   old_normalized_TC2  -9.5547619047619019e+00
    w[1,13]   mass_1    1
    w[1,13]   w_lb_1_13  1
    w[1,13]   w_ub_1_13  1
    w[1,13]   normalized_inventory_1  -13
    w[1,13]   old_normalized_TC  -1.2669841269841267e+01
    w[1,13]   old_normalized_TC2  -1.1411904761904760e+01
    w[1,14]   mass_1    1
    w[1,14]   w_lb_1_14  1
    w[1,14]   w_ub_1_14  1
    w[1,14]   normalized_inventory_1  -14
    w[1,14]   old_normalized_TC  -1.4651984126984125e+01
    w[1,14]   old_normalized_TC2  -1.3394047619047617e+01
    w[1,15]   mass_1    1
    w[1,15]   w_lb_1_15  1
    w[1,15]   w_ub_1_15  1
    w[1,15]   normalized_inventory_1  -15
    w[1,15]   old_normalized_TC  -1.7080555555555552e+01
    w[1,15]   old_normalized_TC2  -1.5822619047619044e+01
    w[2,0]    mass_2    1
    w[2,0]    w_lb_2_0  1
    w[2,0]    w_ub_2_0  1
    w[2,1]    mass_2    1
    w[2,1]    w_lb_2_1  1
    w[2,1]    w_ub_2_1  1
    w[2,1]    normalized_inventory_2  -1
    w[2,1]    old_normalized_TC  -2.5376984126984126e+00
    w[2,1]    old_normalized_TC2  -1.2797619047619047e+00
    w[3,0]    mass_3    1
    w[3,0]    w_lb_3_0  1
    w[3,0]    w_ub_3_0  1
    w[3,1]    mass_3    1
    w[3,1]    w_lb_3_1  1
    w[3,1]    w_ub_3_1  1
    w[3,1]    normalized_inventory_3  -1
    w[3,1]    old_normalized_TC  -0.125
    w[3,1]    old_normalized_TC2  0.25
    w[3,2]    mass_3    1
    w[3,2]    w_lb_3_2  1
    w[3,2]    w_ub_3_2  1
    w[3,2]    normalized_inventory_3  -2
    w[3,2]    old_normalized_TC  -3.5714285714285715e-01
    w[3,2]    old_normalized_TC2  3.6507936507936506e-01
    w[3,3]    mass_3    1
    w[3,3]    w_lb_3_3  1
    w[3,3]    w_ub_3_3  1
    w[3,3]    normalized_inventory_3  -3
    w[3,3]    old_normalized_TC  -6.0714285714285710e-01
    w[3,3]    old_normalized_TC2  2.7579365079365076e-01
    w[3,4]    mass_3    1
    w[3,4]    w_lb_3_4  1
    w[3,4]    w_ub_3_4  1
    w[3,4]    normalized_inventory_3  -4
    w[3,4]    old_normalized_TC  -9.1269841269841268e-01
    w[3,4]    old_normalized_TC2  9.5238095238095177e-02
    w[3,5]    mass_3    1
    w[3,5]    w_lb_3_5  1
    w[3,5]    w_ub_3_5  1
    w[3,5]    normalized_inventory_3  -5
    w[3,5]    old_normalized_TC  -1.2876984126984126e+00
    w[3,5]    old_normalized_TC2  -1.5476190476190482e-01
    w[3,6]    mass_3    1
    w[3,6]    w_lb_3_6  1
    w[3,6]    w_ub_3_6  1
    w[3,6]    normalized_inventory_3  -6
    w[3,6]    old_normalized_TC  -1.6626984126984126e+00
    w[3,6]    old_normalized_TC2  -4.0476190476190482e-01
    w[3,7]    mass_3    1
    w[3,7]    w_lb_3_7  1
    w[3,7]    w_ub_3_7  1
    w[3,7]    normalized_inventory_3  -7
    w[3,7]    old_normalized_TC  -2.0376984126984126e+00
    w[3,7]    old_normalized_TC2  -7.7976190476190477e-01
    w[3,8]    mass_3    1
    w[3,8]    w_lb_3_8  1
    w[3,8]    w_ub_3_8  1
    w[3,8]    normalized_inventory_3  -8
    w[3,8]    old_normalized_TC  -2.5376984126984126e+00
    w[3,8]    old_normalized_TC2  -1.2797619047619047e+00
    w[3,9]    mass_3    1
    w[3,9]    w_lb_3_9  1
    w[3,9]    w_ub_3_9  1
    w[3,9]    normalized_inventory_3  -9
    w[3,9]    old_normalized_TC  -3.7876984126984126e+00
    w[3,9]    old_normalized_TC2  -2.5297619047619047e+00
    w[3,10]   mass_3    1
    w[3,10]   w_lb_3_10  1
    w[3,10]   w_ub_3_10  1
    w[3,10]   normalized_inventory_3  -10
    w[3,10]   old_normalized_TC  -5.1626984126984121e+00
    w[3,10]   old_normalized_TC2  -3.9047619047619047e+00
    w[3,11]   mass_3    1
    w[3,11]   w_lb_3_11  1
    w[3,11]   w_ub_3_11  1
    w[3,11]   normalized_inventory_3  -11
    w[3,11]   old_normalized_TC  -6.6269841269841265e+00
    w[3,11]   old_normalized_TC2  -5.3690476190476186e+00
    w[3,12]   mass_3    1
    w[3,12]   w_lb_3_12  1
    w[3,12]   w_ub_3_12  1
    w[3,12]   normalized_inventory_3  -12
    w[3,12]   old_normalized_TC  -8.1269841269841265e+00
    w[3,12]   old_normalized_TC2  -6.8690476190476186e+00
    w[3,13]   mass_3    1
    w[3,13]   w_lb_3_13  1
    w[3,13]   w_ub_3_13  1
    w[3,13]   normalized_inventory_3  -13
    w[3,13]   old_normalized_TC  -9.6519841269841269e+00
    w[3,13]   old_normalized_TC2  -8.3940476190476190e+00
    w[3,14]   mass_3    1
    w[3,14]   w_lb_3_14  1
    w[3,14]   w_ub_3_14  1
    w[3,14]   normalized_inventory_3  -14
    w[3,14]   old_normalized_TC  -1.1276984126984127e+01
    w[3,14]   old_normalized_TC2  -1.0019047619047619e+01
    w[3,15]   mass_3    1
    w[3,15]   w_lb_3_15  1
    w[3,15]   w_ub_3_15  1
    w[3,15]   normalized_inventory_3  -15
    w[3,15]   old_normalized_TC  -1.2901984126984127e+01
    w[3,15]   old_normalized_TC2  -1.1644047619047619e+01
    w[3,16]   mass_3    1
    w[3,16]   w_lb_3_16  1
    w[3,16]   w_ub_3_16  1
    w[3,16]   normalized_inventory_3  -16
    w[3,16]   old_normalized_TC  -1.4651984126984127e+01
    w[3,16]   old_normalized_TC2  -1.3394047619047619e+01
    w[4,0]    mass_4    1
    w[4,0]    w_lb_4_0  1
    w[4,0]    w_ub_4_0  1
    w[4,1]    mass_4    1
    w[4,1]    w_lb_4_1  1
    w[4,1]    w_ub_4_1  1
    w[4,1]    normalized_inventory_4  -1
    w[4,1]    old_normalized_TC  -0.125
    w[4,1]    old_normalized_TC2  0.25
    w[4,2]    mass_4    1
    w[4,2]    w_lb_4_2  1
    w[4,2]    w_ub_4_2  1
    w[4,2]    normalized_inventory_4  -2
    w[4,2]    old_normalized_TC  -3.5714285714285715e-01
    w[4,2]    old_normalized_TC2  3.6507936507936506e-01
    w[4,3]    mass_4    1
    w[4,3]    w_lb_4_3  1
    w[4,3]    w_ub_4_3  1
    w[4,3]    normalized_inventory_4  -3
    w[4,3]    old_normalized_TC  -6.0714285714285710e-01
    w[4,3]    old_normalized_TC2  2.7579365079365076e-01
    w[4,4]    mass_4    1
    w[4,4]    w_lb_4_4  1
    w[4,4]    w_ub_4_4  1
    w[4,4]    normalized_inventory_4  -4
    w[4,4]    old_normalized_TC  -9.1269841269841268e-01
    w[4,4]    old_normalized_TC2  9.5238095238095177e-02
    w[4,5]    mass_4    1
    w[4,5]    w_lb_4_5  1
    w[4,5]    w_ub_4_5  1
    w[4,5]    normalized_inventory_4  -5
    w[4,5]    old_normalized_TC  -1.2876984126984126e+00
    w[4,5]    old_normalized_TC2  -1.5476190476190482e-01
    w[4,6]    mass_4    1
    w[4,6]    w_lb_4_6  1
    w[4,6]    w_ub_4_6  1
    w[4,6]    normalized_inventory_4  -6
    w[4,6]    old_normalized_TC  -1.6626984126984126e+00
    w[4,6]    old_normalized_TC2  -4.0476190476190482e-01
    w[4,7]    mass_4    1
    w[4,7]    w_lb_4_7  1
    w[4,7]    w_ub_4_7  1
    w[4,7]    normalized_inventory_4  -7
    w[4,7]    old_normalized_TC  -2.0376984126984126e+00
    w[4,7]    old_normalized_TC2  -7.7976190476190477e-01
    w[4,8]    mass_4    1
    w[4,8]    w_lb_4_8  1
    w[4,8]    w_ub_4_8  1
    w[4,8]    normalized_inventory_4  -8
    w[4,8]    old_normalized_TC  -2.5376984126984126e+00
    w[4,8]    old_normalized_TC2  -1.2797619047619047e+00
    w[4,9]    mass_4    1
    w[4,9]    w_lb_4_9  1
    w[4,9]    w_ub_4_9  1
    w[4,9]    normalized_inventory_4  -9
    w[4,9]    old_normalized_TC  -3.7876984126984126e+00
    w[4,9]    old_normalized_TC2  -2.5297619047619047e+00
    w[4,10]   mass_4    1
    w[4,10]   w_lb_4_10  1
    w[4,10]   w_ub_4_10  1
    w[4,10]   normalized_inventory_4  -10
    w[4,10]   old_normalized_TC  -5.1626984126984121e+00
    w[4,10]   old_normalized_TC2  -3.9047619047619047e+00
    w[4,11]   mass_4    1
    w[4,11]   w_lb_4_11  1
    w[4,11]   w_ub_4_11  1
    w[4,11]   normalized_inventory_4  -11
    w[4,11]   old_normalized_TC  -6.6269841269841265e+00
    w[4,11]   old_normalized_TC2  -5.3690476190476186e+00
    w[4,12]   mass_4    1
    w[4,12]   w_lb_4_12  1
    w[4,12]   w_ub_4_12  1
    w[4,12]   normalized_inventory_4  -12
    w[4,12]   old_normalized_TC  -8.1269841269841265e+00
    w[4,12]   old_normalized_TC2  -6.8690476190476186e+00
    w[4,13]   mass_4    1
    w[4,13]   w_lb_4_13  1
    w[4,13]   w_ub_4_13  1
    w[4,13]   normalized_inventory_4  -13
    w[4,13]   old_normalized_TC  -9.6519841269841269e+00
    w[4,13]   old_normalized_TC2  -8.3940476190476190e+00
    w[4,14]   mass_4    1
    w[4,14]   w_lb_4_14  1
    w[4,14]   w_ub_4_14  1
    w[4,14]   normalized_inventory_4  -14
    w[4,14]   old_normalized_TC  -1.1276984126984127e+01
    w[4,14]   old_normalized_TC2  -1.0019047619047619e+01
    w[4,15]   mass_4    1
    w[4,15]   w_lb_4_15  1
    w[4,15]   w_ub_4_15  1
    w[4,15]   normalized_inventory_4  -15
    w[4,15]   old_normalized_TC  -1.2901984126984127e+01
    w[4,15]   old_normalized_TC2  -1.1644047619047619e+01
    w[5,0]    mass_5    1
    w[5,0]    w_lb_5_0  1
    w[5,0]    w_ub_5_0  1
    w[5,1]    mass_5    1
    w[5,1]    w_lb_5_1  1
    w[5,1]    w_ub_5_1  1
    w[5,1]    normalized_inventory_5  -1
    w[5,1]    old_normalized_TC  -2.5376984126984126e+00
    w[5,1]    old_normalized_TC2  -1.2797619047619047e+00
    w[5,2]    mass_5    1
    w[5,2]    w_lb_5_2  1
    w[5,2]    w_ub_5_2  1
    w[5,2]    normalized_inventory_5  -2
    w[5,2]    old_normalized_TC  -1.4651984126984127e+01
    w[5,2]    old_normalized_TC2  -1.3394047619047619e+01
    w[6,0]    mass_6    1
    w[6,0]    w_lb_6_0  1
    w[6,0]    w_ub_6_0  1
    w[6,1]    mass_6    1
    w[6,1]    w_lb_6_1  1
    w[6,1]    w_ub_6_1  1
    w[6,1]    normalized_inventory_6  -1
    w[6,1]    old_normalized_TC  -2.5376984126984126e+00
    w[6,1]    old_normalized_TC2  -1.2797619047619047e+00
    w[7,0]    mass_7    1
    w[7,0]    w_lb_7_0  1
    w[7,0]    w_ub_7_0  1
    w[7,1]    mass_7    1
    w[7,1]    w_lb_7_1  1
    w[7,1]    w_ub_7_1  1
    w[7,1]    normalized_inventory_7  -1
    w[7,1]    old_normalized_TC  -2.5714285714285717e-01
    w[7,1]    old_normalized_TC2  3.4285714285714286e-01
    w[7,2]    mass_7    1
    w[7,2]    w_lb_7_2  1
    w[7,2]    w_ub_7_2  1
    w[7,2]    normalized_inventory_7  -2
    w[7,2]    old_normalized_TC  -6.5714285714285714e-01
    w[7,2]    old_normalized_TC2  2.5079365079365074e-01
    w[7,3]    mass_7    1
    w[7,3]    w_lb_7_3  1
    w[7,3]    w_ub_7_3  1
    w[7,3]    normalized_inventory_7  -3
    w[7,3]    old_normalized_TC  -1.2126984126984128e+00
    w[7,3]    old_normalized_TC2  -1.0476190476190489e-01
    w[7,4]    mass_7    1
    w[7,4]    w_lb_7_4  1
    w[7,4]    w_ub_7_4  1
    w[7,4]    normalized_inventory_7  -4
    w[7,4]    old_normalized_TC  -1.8126984126984127e+00
    w[7,4]    old_normalized_TC2  -5.5476190476190490e-01
    w[7,5]    mass_7    1
    w[7,5]    w_lb_7_5  1
    w[7,5]    w_ub_7_5  1
    w[7,5]    normalized_inventory_7  -5
    w[7,5]    old_normalized_TC  -2.5376984126984130e+00
    w[7,5]    old_normalized_TC2  -1.2797619047619053e+00
    w[7,6]    mass_7    1
    w[7,6]    w_lb_7_6  1
    w[7,6]    w_ub_7_6  1
    w[7,6]    normalized_inventory_7  -6
    w[7,6]    old_normalized_TC  -4.6126984126984132e+00
    w[7,6]    old_normalized_TC2  -3.3547619047619053e+00
    w[7,7]    mass_7    1
    w[7,7]    w_lb_7_7  1
    w[7,7]    w_ub_7_7  1
    w[7,7]    normalized_inventory_7  -7
    w[7,7]    old_normalized_TC  -6.9269841269841272e+00
    w[7,7]    old_normalized_TC2  -5.6690476190476193e+00
    w[7,8]    mass_7    1
    w[7,8]    w_lb_7_8  1
    w[7,8]    w_ub_7_8  1
    w[7,8]    normalized_inventory_7  -8
    w[7,8]    old_normalized_TC  -9.3269841269841276e+00
    w[7,8]    old_normalized_TC2  -8.06904761904762
    w[7,9]    mass_7    1
    w[7,9]    w_lb_7_9  1
    w[7,9]    w_ub_7_9  1
    w[7,9]    normalized_inventory_7  -9
    w[7,9]    old_normalized_TC  -1.1926984126984127e+01
    w[7,9]    old_normalized_TC2  -1.0669047619047619e+01
    w[7,10]   mass_7    1
    w[7,10]   w_lb_7_10  1
    w[7,10]   w_ub_7_10  1
    w[7,10]   normalized_inventory_7  -10
    w[7,10]   old_normalized_TC  -1.4651984126984129e+01
    w[7,10]   old_normalized_TC2  -1.3394047619047621e+01
    w[8,0]    mass_8    1
    w[8,0]    w_lb_8_0  1
    w[8,0]    w_ub_8_0  1
    w[8,1]    mass_8    1
    w[8,1]    w_lb_8_1  1
    w[8,1]    w_ub_8_1  1
    w[8,1]    normalized_inventory_8  -1
    w[8,1]    old_normalized_TC  -2.5376984126984126e+00
    w[8,1]    old_normalized_TC2  -1.2797619047619047e+00
    w[8,2]    mass_8    1
    w[8,2]    w_lb_8_2  1
    w[8,2]    w_ub_8_2  1
    w[8,2]    normalized_inventory_8  -2
    w[8,2]    old_normalized_TC  -1.4651984126984127e+01
    w[8,2]    old_normalized_TC2  -1.3394047619047619e+01
    w[9,0]    mass_9    1
    w[9,0]    w_lb_9_0  1
    w[9,0]    w_ub_9_0  1
    w[9,1]    mass_9    1
    w[9,1]    w_lb_9_1  1
    w[9,1]    w_ub_9_1  1
    w[9,1]    normalized_inventory_9  -1
    w[9,1]    old_normalized_TC  -2.5376984126984126e+00
    w[9,1]    old_normalized_TC2  -1.2797619047619047e+00
    w[10,0]   mass_10   1
    w[10,0]   w_lb_10_0  1
    w[10,0]   w_ub_10_0  1
    w[10,1]   mass_10   1
    w[10,1]   w_lb_10_1  1
    w[10,1]   w_ub_10_1  1
    w[10,1]   normalized_inventory_10  -1
    w[10,1]   old_normalized_TC  -2.5376984126984126e+00
    w[10,1]   old_normalized_TC2  -1.2797619047619047e+00
    w[11,0]   mass_11   1
    w[11,0]   w_lb_11_0  1
    w[11,0]   w_ub_11_0  1
    w[11,1]   mass_11   1
    w[11,1]   w_lb_11_1  1
    w[11,1]   w_ub_11_1  1
    w[11,1]   normalized_inventory_11  -1
    w[11,1]   old_normalized_TC  -0.125
    w[11,1]   old_normalized_TC2  0.25
    w[11,2]   mass_11   1
    w[11,2]   w_lb_11_2  1
    w[11,2]   w_ub_11_2  1
    w[11,2]   normalized_inventory_11  -2
    w[11,2]   old_normalized_TC  -3.5714285714285715e-01
    w[11,2]   old_normalized_TC2  3.6507936507936506e-01
    w[11,3]   mass_11   1
    w[11,3]   w_lb_11_3  1
    w[11,3]   w_ub_11_3  1
    w[11,3]   normalized_inventory_11  -3
    w[11,3]   old_normalized_TC  -6.0714285714285710e-01
    w[11,3]   old_normalized_TC2  2.7579365079365076e-01
    w[11,4]   mass_11   1
    w[11,4]   w_lb_11_4  1
    w[11,4]   w_ub_11_4  1
    w[11,4]   normalized_inventory_11  -4
    w[11,4]   old_normalized_TC  -9.1269841269841268e-01
    w[11,4]   old_normalized_TC2  9.5238095238095177e-02
    w[11,5]   mass_11   1
    w[11,5]   w_lb_11_5  1
    w[11,5]   w_ub_11_5  1
    w[11,5]   normalized_inventory_11  -5
    w[11,5]   old_normalized_TC  -1.2876984126984126e+00
    w[11,5]   old_normalized_TC2  -1.5476190476190482e-01
    w[11,6]   mass_11   1
    w[11,6]   w_lb_11_6  1
    w[11,6]   w_ub_11_6  1
    w[11,6]   normalized_inventory_11  -6
    w[11,6]   old_normalized_TC  -1.6626984126984126e+00
    w[11,6]   old_normalized_TC2  -4.0476190476190482e-01
    w[11,7]   mass_11   1
    w[11,7]   w_lb_11_7  1
    w[11,7]   w_ub_11_7  1
    w[11,7]   normalized_inventory_11  -7
    w[11,7]   old_normalized_TC  -2.0376984126984126e+00
    w[11,7]   old_normalized_TC2  -7.7976190476190477e-01
    w[11,8]   mass_11   1
    w[11,8]   w_lb_11_8  1
    w[11,8]   w_ub_11_8  1
    w[11,8]   normalized_inventory_11  -8
    w[11,8]   old_normalized_TC  -2.5376984126984126e+00
    w[11,8]   old_normalized_TC2  -1.2797619047619047e+00
    w[11,9]   mass_11   1
    w[11,9]   w_lb_11_9  1
    w[11,9]   w_ub_11_9  1
    w[11,9]   normalized_inventory_11  -9
    w[11,9]   old_normalized_TC  -3.7876984126984126e+00
    w[11,9]   old_normalized_TC2  -2.5297619047619047e+00
    w[11,10]  mass_11   1
    w[11,10]  w_lb_11_10  1
    w[11,10]  w_ub_11_10  1
    w[11,10]  normalized_inventory_11  -10
    w[11,10]  old_normalized_TC  -5.1626984126984121e+00
    w[11,10]  old_normalized_TC2  -3.9047619047619047e+00
    w[11,11]  mass_11   1
    w[11,11]  w_lb_11_11  1
    w[11,11]  w_ub_11_11  1
    w[11,11]  normalized_inventory_11  -11
    w[11,11]  old_normalized_TC  -6.6269841269841265e+00
    w[11,11]  old_normalized_TC2  -5.3690476190476186e+00
    w[11,12]  mass_11   1
    w[11,12]  w_lb_11_12  1
    w[11,12]  w_ub_11_12  1
    w[11,12]  normalized_inventory_11  -12
    w[11,12]  old_normalized_TC  -8.1269841269841265e+00
    w[11,12]  old_normalized_TC2  -6.8690476190476186e+00
    w[11,13]  mass_11   1
    w[11,13]  w_lb_11_13  1
    w[11,13]  w_ub_11_13  1
    w[11,13]  normalized_inventory_11  -13
    w[11,13]  old_normalized_TC  -9.6519841269841269e+00
    w[11,13]  old_normalized_TC2  -8.3940476190476190e+00
    w[11,14]  mass_11   1
    w[11,14]  w_lb_11_14  1
    w[11,14]  w_ub_11_14  1
    w[11,14]  normalized_inventory_11  -14
    w[11,14]  old_normalized_TC  -1.1276984126984127e+01
    w[11,14]  old_normalized_TC2  -1.0019047619047619e+01
    w[11,15]  mass_11   1
    w[11,15]  w_lb_11_15  1
    w[11,15]  w_ub_11_15  1
    w[11,15]  normalized_inventory_11  -15
    w[11,15]  old_normalized_TC  -1.2901984126984127e+01
    w[11,15]  old_normalized_TC2  -1.1644047619047619e+01
    w[12,0]   mass_12   1
    w[12,0]   w_lb_12_0  1
    w[12,0]   w_ub_12_0  1
    w[12,1]   mass_12   1
    w[12,1]   w_lb_12_1  1
    w[12,1]   w_ub_12_1  1
    w[12,1]   normalized_inventory_12  -1
    w[12,1]   old_normalized_TC  -1.4285714285714285e-01
    w[12,1]   old_normalized_TC2  2.8571428571428570e-01
    w[12,2]   mass_12   1
    w[12,2]   w_lb_12_2  1
    w[12,2]   w_ub_12_2  1
    w[12,2]   normalized_inventory_12  -2
    w[12,2]   old_normalized_TC  -4.2857142857142855e-01
    w[12,2]   old_normalized_TC2  3.6507936507936506e-01
    w[12,3]   mass_12   1
    w[12,3]   w_lb_12_3  1
    w[12,3]   w_ub_12_3  1
    w[12,3]   normalized_inventory_12  -3
    w[12,3]   old_normalized_TC  -7.1428571428571419e-01
    w[12,3]   old_normalized_TC2  2.2222222222222221e-01
    w[12,4]   mass_12   1
    w[12,4]   w_lb_12_4  1
    w[12,4]   w_ub_12_4  1
    w[12,4]   normalized_inventory_12  -4
    w[12,4]   old_normalized_TC  -1.1269841269841268e+00
    w[12,4]   old_normalized_TC2  -4.7619047619047616e-02
    w[12,5]   mass_12   1
    w[12,5]   w_lb_12_5  1
    w[12,5]   w_ub_12_5  1
    w[12,5]   normalized_inventory_12  -5
    w[12,5]   old_normalized_TC  -1.5555555555555554e+00
    w[12,5]   old_normalized_TC2  -3.3333333333333331e-01
    w[12,6]   mass_12   1
    w[12,6]   w_lb_12_6  1
    w[12,6]   w_ub_12_6  1
    w[12,6]   normalized_inventory_12  -6
    w[12,6]   old_normalized_TC  -1.9841269841269840e+00
    w[12,6]   old_normalized_TC2  -0.726190476190476
    w[12,7]   mass_12   1
    w[12,7]   w_lb_12_7  1
    w[12,7]   w_ub_12_7  1
    w[12,7]   normalized_inventory_12  -7
    w[12,7]   old_normalized_TC  -2.5376984126984121e+00
    w[12,7]   old_normalized_TC2  -1.2797619047619044e+00
    w[12,8]   mass_12   1
    w[12,8]   w_lb_12_8  1
    w[12,8]   w_ub_12_8  1
    w[12,8]   normalized_inventory_12  -8
    w[12,8]   old_normalized_TC  -3.9841269841269833e+00
    w[12,8]   old_normalized_TC2  -2.7261904761904754e+00
    w[12,9]   mass_12   1
    w[12,9]   w_lb_12_9  1
    w[12,9]   w_ub_12_9  1
    w[12,9]   normalized_inventory_12  -9
    w[12,9]   old_normalized_TC  -5.5555555555555545e+00
    w[12,9]   old_normalized_TC2  -4.2976190476190466e+00
    w[12,10]  mass_12   1
    w[12,10]  w_lb_12_10  1
    w[12,10]  w_ub_12_10  1
    w[12,10]  normalized_inventory_12  -10
    w[12,10]  old_normalized_TC  -7.2698412698412689e+00
    w[12,10]  old_normalized_TC2  -6.0119047619047610e+00
    w[12,11]  mass_12   1
    w[12,11]  w_lb_12_11  1
    w[12,11]  w_ub_12_11  1
    w[12,11]  normalized_inventory_12  -11
    w[12,11]  old_normalized_TC  -8.9841269841269824e+00
    w[12,11]  old_normalized_TC2  -7.7261904761904745e+00
    w[12,12]  mass_12   1
    w[12,12]  w_lb_12_12  1
    w[12,12]  w_ub_12_12  1
    w[12,12]  normalized_inventory_12  -12
    w[12,12]  old_normalized_TC  -1.0812698412698410e+01
    w[12,12]  old_normalized_TC2  -9.5547619047619019e+00
    w[12,13]  mass_12   1
    w[12,13]  w_lb_12_13  1
    w[12,13]  w_ub_12_13  1
    w[12,13]  normalized_inventory_12  -13
    w[12,13]  old_normalized_TC  -1.2669841269841267e+01
    w[12,13]  old_normalized_TC2  -1.1411904761904760e+01
    w[12,14]  mass_12   1
    w[12,14]  w_lb_12_14  1
    w[12,14]  w_ub_12_14  1
    w[12,14]  normalized_inventory_12  -14
    w[12,14]  old_normalized_TC  -1.4651984126984125e+01
    w[12,14]  old_normalized_TC2  -1.3394047619047617e+01
    w[12,15]  mass_12   1
    w[12,15]  w_lb_12_15  1
    w[12,15]  w_ub_12_15  1
    w[12,15]  normalized_inventory_12  -15
    w[12,15]  old_normalized_TC  -1.7080555555555552e+01
    w[12,15]  old_normalized_TC2  -1.5822619047619044e+01
    w[13,0]   mass_13   1
    w[13,0]   w_lb_13_0  1
    w[13,0]   w_ub_13_0  1
    w[13,1]   mass_13   1
    w[13,1]   w_lb_13_1  1
    w[13,1]   w_ub_13_1  1
    w[13,1]   normalized_inventory_13  -1
    w[13,1]   old_normalized_TC  -2.5376984126984126e+00
    w[13,1]   old_normalized_TC2  -1.2797619047619047e+00
    w[14,2]   mass_14   1
    w[14,2]   w_lb_14_2  1
    w[14,2]   w_ub_14_2  1
    w[14,2]   normalized_inventory_14  -2
    w[14,2]   old_normalized_TC  -4.2857142857142855e-01
    w[14,2]   old_normalized_TC2  3.6507936507936506e-01
    w[14,3]   mass_14   1
    w[14,3]   w_lb_14_3  1
    w[14,3]   w_ub_14_3  1
    w[14,3]   normalized_inventory_14  -3
    w[14,3]   old_normalized_TC  -7.1428571428571419e-01
    w[14,3]   old_normalized_TC2  2.2222222222222221e-01
    w[14,4]   mass_14   1
    w[14,4]   w_lb_14_4  1
    w[14,4]   w_ub_14_4  1
    w[14,4]   normalized_inventory_14  -4
    w[14,4]   old_normalized_TC  -1.1269841269841268e+00
    w[14,4]   old_normalized_TC2  -4.7619047619047616e-02
    w[14,5]   mass_14   1
    w[14,5]   w_lb_14_5  1
    w[14,5]   w_ub_14_5  1
    w[14,5]   normalized_inventory_14  -5
    w[14,5]   old_normalized_TC  -1.5555555555555554e+00
    w[14,5]   old_normalized_TC2  -3.3333333333333331e-01
    w[14,6]   mass_14   1
    w[14,6]   w_lb_14_6  1
    w[14,6]   w_ub_14_6  1
    w[14,6]   normalized_inventory_14  -6
    w[14,6]   old_normalized_TC  -1.9841269841269840e+00
    w[14,6]   old_normalized_TC2  -0.726190476190476
    w[14,7]   mass_14   1
    w[14,7]   w_lb_14_7  1
    w[14,7]   w_ub_14_7  1
    w[14,7]   normalized_inventory_14  -7
    w[14,7]   old_normalized_TC  -2.5376984126984121e+00
    w[14,7]   old_normalized_TC2  -1.2797619047619044e+00
    w[14,8]   mass_14   1
    w[14,8]   w_lb_14_8  1
    w[14,8]   w_ub_14_8  1
    w[14,8]   normalized_inventory_14  -8
    w[14,8]   old_normalized_TC  -3.9841269841269833e+00
    w[14,8]   old_normalized_TC2  -2.7261904761904754e+00
    w[14,9]   mass_14   1
    w[14,9]   w_lb_14_9  1
    w[14,9]   w_ub_14_9  1
    w[14,9]   normalized_inventory_14  -9
    w[14,9]   old_normalized_TC  -5.5555555555555545e+00
    w[14,9]   old_normalized_TC2  -4.2976190476190466e+00
    w[14,10]  mass_14   1
    w[14,10]  w_lb_14_10  1
    w[14,10]  w_ub_14_10  1
    w[14,10]  normalized_inventory_14  -10
    w[14,10]  old_normalized_TC  -7.2698412698412689e+00
    w[14,10]  old_normalized_TC2  -6.0119047619047610e+00
    w[14,11]  mass_14   1
    w[14,11]  w_lb_14_11  1
    w[14,11]  w_ub_14_11  1
    w[14,11]  normalized_inventory_14  -11
    w[14,11]  old_normalized_TC  -8.9841269841269824e+00
    w[14,11]  old_normalized_TC2  -7.7261904761904745e+00
    w[14,12]  mass_14   1
    w[14,12]  w_lb_14_12  1
    w[14,12]  w_ub_14_12  1
    w[14,12]  normalized_inventory_14  -12
    w[14,12]  old_normalized_TC  -1.0812698412698410e+01
    w[14,12]  old_normalized_TC2  -9.5547619047619019e+00
    w[14,13]  mass_14   1
    w[14,13]  w_lb_14_13  1
    w[14,13]  w_ub_14_13  1
    w[14,13]  normalized_inventory_14  -13
    w[14,13]  old_normalized_TC  -1.2669841269841267e+01
    w[14,13]  old_normalized_TC2  -1.1411904761904760e+01
    w[14,14]  mass_14   1
    w[14,14]  w_lb_14_14  1
    w[14,14]  w_ub_14_14  1
    w[14,14]  normalized_inventory_14  -14
    w[14,14]  old_normalized_TC  -1.4651984126984125e+01
    w[14,14]  old_normalized_TC2  -1.3394047619047617e+01
    w[14,15]  mass_14   1
    w[14,15]  w_lb_14_15  1
    w[14,15]  w_ub_14_15  1
    w[14,15]  normalized_inventory_14  -15
    w[14,15]  old_normalized_TC  -1.7080555555555552e+01
    w[14,15]  old_normalized_TC2  -1.5822619047619044e+01
    w[15,0]   mass_15   1
    w[15,0]   w_lb_15_0  1
    w[15,0]   w_ub_15_0  1
    w[15,1]   mass_15   1
    w[15,1]   w_lb_15_1  1
    w[15,1]   w_ub_15_1  1
    w[15,1]   normalized_inventory_15  -1
    w[15,1]   old_normalized_TC  -2.5376984126984126e+00
    w[15,1]   old_normalized_TC2  -1.2797619047619047e+00
    w[16,0]   mass_16   1
    w[16,0]   w_lb_16_0  1
    w[16,0]   w_ub_16_0  1
    w[16,1]   mass_16   1
    w[16,1]   w_lb_16_1  1
    w[16,1]   w_ub_16_1  1
    w[16,1]   normalized_inventory_16  -1
    w[16,1]   old_normalized_TC  -2.5376984126984126e+00
    w[16,1]   old_normalized_TC2  -1.2797619047619047e+00
    w[16,2]   mass_16   1
    w[16,2]   w_lb_16_2  1
    w[16,2]   w_ub_16_2  1
    w[16,2]   normalized_inventory_16  -2
    w[16,2]   old_normalized_TC  -1.4651984126984127e+01
    w[16,2]   old_normalized_TC2  -1.3394047619047619e+01
    w[17,2]   mass_17   1
    w[17,2]   w_lb_17_2  1
    w[17,2]   w_ub_17_2  1
    w[17,2]   normalized_inventory_17  -2
    w[17,2]   old_normalized_TC  -3.0158730158730157e-01
    w[17,2]   old_normalized_TC2  3.6507936507936506e-01
    w[17,3]   mass_17   1
    w[17,3]   w_lb_17_3  1
    w[17,3]   w_ub_17_3  1
    w[17,3]   normalized_inventory_17  -3
    w[17,3]   old_normalized_TC  -5.2380952380952372e-01
    w[17,3]   old_normalized_TC2  3.1746031746031744e-01
    w[17,4]   mass_17   1
    w[17,4]   w_lb_17_4  1
    w[17,4]   w_ub_17_4  1
    w[17,4]   normalized_inventory_17  -4
    w[17,4]   old_normalized_TC  -7.4603174603174593e-01
    w[17,4]   old_normalized_TC2  2.0634920634920634e-01
    w[18,0]   mass_18   1
    w[18,0]   w_lb_18_0  1
    w[18,0]   w_ub_18_0  1
    w[18,1]   mass_18   1
    w[18,1]   w_lb_18_1  1
    w[18,1]   w_ub_18_1  1
    w[18,1]   normalized_inventory_18  -1
    w[18,1]   old_normalized_TC  -1.4285714285714285e-01
    w[18,1]   old_normalized_TC2  2.8571428571428570e-01
    w[19,0]   mass_19   1
    w[19,0]   w_lb_19_0  1
    w[19,0]   w_ub_19_0  1
    w[20,6]   mass_20   1
    w[20,6]   w_lb_20_6  1
    w[20,6]   w_ub_20_6  1
    w[20,6]   normalized_inventory_20  -6
    w[20,6]   old_normalized_TC  -1.6626984126984126e+00
    w[20,6]   old_normalized_TC2  -4.0476190476190482e-01
    w[20,7]   mass_20   1
    w[20,7]   w_lb_20_7  1
    w[20,7]   w_ub_20_7  1
    w[20,7]   normalized_inventory_20  -7
    w[20,7]   old_normalized_TC  -2.0376984126984126e+00
    w[20,7]   old_normalized_TC2  -7.7976190476190477e-01
    w[20,8]   mass_20   1
    w[20,8]   w_lb_20_8  1
    w[20,8]   w_ub_20_8  1
    w[20,8]   normalized_inventory_20  -8
    w[20,8]   old_normalized_TC  -2.5376984126984126e+00
    w[20,8]   old_normalized_TC2  -1.2797619047619047e+00
    w[20,9]   mass_20   1
    w[20,9]   w_lb_20_9  1
    w[20,9]   w_ub_20_9  1
    w[20,9]   normalized_inventory_20  -9
    w[20,9]   old_normalized_TC  -3.7876984126984126e+00
    w[20,9]   old_normalized_TC2  -2.5297619047619047e+00
    w[20,10]  mass_20   1
    w[20,10]  w_lb_20_10  1
    w[20,10]  w_ub_20_10  1
    w[20,10]  normalized_inventory_20  -10
    w[20,10]  old_normalized_TC  -5.1626984126984121e+00
    w[20,10]  old_normalized_TC2  -3.9047619047619047e+00
    w[20,11]  mass_20   1
    w[20,11]  w_lb_20_11  1
    w[20,11]  w_ub_20_11  1
    w[20,11]  normalized_inventory_20  -11
    w[20,11]  old_normalized_TC  -6.6269841269841265e+00
    w[20,11]  old_normalized_TC2  -5.3690476190476186e+00
    w[20,12]  mass_20   1
    w[20,12]  w_lb_20_12  1
    w[20,12]  w_ub_20_12  1
    w[20,12]  normalized_inventory_20  -12
    w[20,12]  old_normalized_TC  -8.1269841269841265e+00
    w[20,12]  old_normalized_TC2  -6.8690476190476186e+00
    w[20,13]  mass_20   1
    w[20,13]  w_lb_20_13  1
    w[20,13]  w_ub_20_13  1
    w[20,13]  normalized_inventory_20  -13
    w[20,13]  old_normalized_TC  -9.6519841269841269e+00
    w[20,13]  old_normalized_TC2  -8.3940476190476190e+00
    w[20,14]  mass_20   1
    w[20,14]  w_lb_20_14  1
    w[20,14]  w_ub_20_14  1
    w[20,14]  normalized_inventory_20  -14
    w[20,14]  old_normalized_TC  -1.1276984126984127e+01
    w[20,14]  old_normalized_TC2  -1.0019047619047619e+01
    w[20,15]  mass_20   1
    w[20,15]  w_lb_20_15  1
    w[20,15]  w_ub_20_15  1
    w[20,15]  normalized_inventory_20  -15
    w[20,15]  old_normalized_TC  -1.2901984126984127e+01
    w[20,15]  old_normalized_TC2  -1.1644047619047619e+01
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         scaled_stock_lower  -5
    t         scaled_stock_upper  -65
    t         old_normalized_TC2  -2.2765873015873012e+01
    t         old_TS1   -5
    t         old_TS2   -65
    t         old_TS3   -5
    t         old_TS4   -65
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -1.4285714285714285e-01
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[1]      old_TS1   1
    z[1]      old_TS2   1
    z[1]      old_TS3   1
    z[1]      old_TS4   1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -1
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[2]      old_TS1   1
    z[2]      old_TS2   1
    z[2]      old_TS3   1
    z[2]      old_TS4   1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -0.125
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[3]      old_TS1   1
    z[3]      old_TS2   1
    z[3]      old_TS3   1
    z[3]      old_TS4   1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -0.125
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[4]      old_TS1   1
    z[4]      old_TS2   1
    z[4]      old_TS3   1
    z[4]      old_TS4   1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -1
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[5]      old_TS1   1
    z[5]      old_TS2   1
    z[5]      old_TS3   1
    z[5]      old_TS4   1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -1
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[6]      old_TS1   1
    z[6]      old_TS2   1
    z[6]      old_TS3   1
    z[6]      old_TS4   1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -0.2
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[7]      old_TS1   1
    z[7]      old_TS2   1
    z[7]      old_TS3   1
    z[7]      old_TS4   1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -1
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[8]      old_TS1   1
    z[8]      old_TS2   1
    z[8]      old_TS3   1
    z[8]      old_TS4   1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -1
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[9]      old_TS1   1
    z[9]      old_TS2   1
    z[9]      old_TS3   1
    z[9]      old_TS4   1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -1
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[10]     old_TS1   1
    z[10]     old_TS2   1
    z[10]     old_TS3   1
    z[10]     old_TS4   1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -0.125
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[11]     old_TS1   1
    z[11]     old_TS2   1
    z[11]     old_TS3   1
    z[11]     old_TS4   1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -1.4285714285714285e-01
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[12]     old_TS1   1
    z[12]     old_TS2   1
    z[12]     old_TS3   1
    z[12]     old_TS4   1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -1
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[13]     old_TS1   1
    z[13]     old_TS2   1
    z[13]     old_TS3   1
    z[13]     old_TS4   1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -1.4285714285714285e-01
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[14]     old_TS1   1
    z[14]     old_TS2   1
    z[14]     old_TS3   1
    z[14]     old_TS4   1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -1
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[15]     old_TS1   1
    z[15]     old_TS2   1
    z[15]     old_TS3   1
    z[15]     old_TS4   1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -1
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[16]     old_TS1   1
    z[16]     old_TS2   1
    z[16]     old_TS3   1
    z[16]     old_TS4   1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -1.1111111111111110e-01
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[17]     old_TS1   1
    z[17]     old_TS2   1
    z[17]     old_TS3   1
    z[17]     old_TS4   1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -1.4285714285714285e-01
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[18]     old_TS1   1
    z[18]     old_TS2   1
    z[18]     old_TS3   1
    z[18]     old_TS4   1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -0.5
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[19]     old_TS1   1
    z[19]     old_TS2   1
    z[19]     old_TS3   1
    z[19]     old_TS4   1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -0.125
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    z[20]     old_TS1   1
    z[20]     old_TS2   1
    z[20]     old_TS3   1
    z[20]     old_TS4   1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[1]      abs_p_1_3  -1
    r[1]      abs_m_1_3  1
    r[1]      abs_p_1_4  -1
    r[1]      abs_m_1_4  1
    r[1]      abs_p_1_5  -1
    r[1]      abs_m_1_5  1
    r[1]      abs_p_1_6  -1
    r[1]      abs_m_1_6  1
    r[1]      abs_p_1_7  -1
    r[1]      abs_m_1_7  1
    r[1]      abs_p_1_8  -1
    r[1]      abs_m_1_8  1
    r[1]      abs_p_1_9  -1
    r[1]      abs_m_1_9  1
    r[1]      abs_p_1_10  -1
    r[1]      abs_m_1_10  1
    r[1]      abs_p_1_11  -1
    r[1]      abs_m_1_11  1
    r[1]      abs_p_1_12  -1
    r[1]      abs_m_1_12  1
    r[1]      abs_p_1_13  -1
    r[1]      abs_m_1_13  1
    r[1]      abs_p_1_14  -1
    r[1]      abs_m_1_14  1
    r[1]      abs_p_1_15  -1
    r[1]      abs_m_1_15  1
    r[1]      abs_p_1_16  -1
    r[1]      abs_m_1_16  1
    r[1]      abs_p_1_17  -1
    r[1]      abs_m_1_17  1
    r[1]      abs_p_1_18  -1
    r[1]      abs_m_1_18  1
    r[1]      abs_p_1_19  -1
    r[1]      abs_m_1_19  1
    r[1]      abs_p_1_20  -1
    r[1]      abs_m_1_20  1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    r[2]      abs_p_2_3  -1
    r[2]      abs_m_2_3  1
    r[2]      abs_p_2_4  -1
    r[2]      abs_m_2_4  1
    r[2]      abs_p_2_5  -1
    r[2]      abs_m_2_5  1
    r[2]      abs_p_2_6  -1
    r[2]      abs_m_2_6  1
    r[2]      abs_p_2_7  -1
    r[2]      abs_m_2_7  1
    r[2]      abs_p_2_8  -1
    r[2]      abs_m_2_8  1
    r[2]      abs_p_2_9  -1
    r[2]      abs_m_2_9  1
    r[2]      abs_p_2_10  -1
    r[2]      abs_m_2_10  1
    r[2]      abs_p_2_11  -1
    r[2]      abs_m_2_11  1
    r[2]      abs_p_2_12  -1
    r[2]      abs_m_2_12  1
    r[2]      abs_p_2_13  -1
    r[2]      abs_m_2_13  1
    r[2]      abs_p_2_14  -1
    r[2]      abs_m_2_14  1
    r[2]      abs_p_2_15  -1
    r[2]      abs_m_2_15  1
    r[2]      abs_p_2_16  -1
    r[2]      abs_m_2_16  1
    r[2]      abs_p_2_17  -1
    r[2]      abs_m_2_17  1
    r[2]      abs_p_2_18  -1
    r[2]      abs_m_2_18  1
    r[2]      abs_p_2_19  -1
    r[2]      abs_m_2_19  1
    r[2]      abs_p_2_20  -1
    r[2]      abs_m_2_20  1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      abs_p_1_3  1
    r[3]      abs_m_1_3  -1
    r[3]      abs_p_2_3  1
    r[3]      abs_m_2_3  -1
    r[3]      abs_p_3_4  -1
    r[3]      abs_m_3_4  1
    r[3]      abs_p_3_5  -1
    r[3]      abs_m_3_5  1
    r[3]      abs_p_3_6  -1
    r[3]      abs_m_3_6  1
    r[3]      abs_p_3_7  -1
    r[3]      abs_m_3_7  1
    r[3]      abs_p_3_8  -1
    r[3]      abs_m_3_8  1
    r[3]      abs_p_3_9  -1
    r[3]      abs_m_3_9  1
    r[3]      abs_p_3_10  -1
    r[3]      abs_m_3_10  1
    r[3]      abs_p_3_11  -1
    r[3]      abs_m_3_11  1
    r[3]      abs_p_3_12  -1
    r[3]      abs_m_3_12  1
    r[3]      abs_p_3_13  -1
    r[3]      abs_m_3_13  1
    r[3]      abs_p_3_14  -1
    r[3]      abs_m_3_14  1
    r[3]      abs_p_3_15  -1
    r[3]      abs_m_3_15  1
    r[3]      abs_p_3_16  -1
    r[3]      abs_m_3_16  1
    r[3]      abs_p_3_17  -1
    r[3]      abs_m_3_17  1
    r[3]      abs_p_3_18  -1
    r[3]      abs_m_3_18  1
    r[3]      abs_p_3_19  -1
    r[3]      abs_m_3_19  1
    r[3]      abs_p_3_20  -1
    r[3]      abs_m_3_20  1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      abs_p_1_4  1
    r[4]      abs_m_1_4  -1
    r[4]      abs_p_2_4  1
    r[4]      abs_m_2_4  -1
    r[4]      abs_p_3_4  1
    r[4]      abs_m_3_4  -1
    r[4]      abs_p_4_5  -1
    r[4]      abs_m_4_5  1
    r[4]      abs_p_4_6  -1
    r[4]      abs_m_4_6  1
    r[4]      abs_p_4_7  -1
    r[4]      abs_m_4_7  1
    r[4]      abs_p_4_8  -1
    r[4]      abs_m_4_8  1
    r[4]      abs_p_4_9  -1
    r[4]      abs_m_4_9  1
    r[4]      abs_p_4_10  -1
    r[4]      abs_m_4_10  1
    r[4]      abs_p_4_11  -1
    r[4]      abs_m_4_11  1
    r[4]      abs_p_4_12  -1
    r[4]      abs_m_4_12  1
    r[4]      abs_p_4_13  -1
    r[4]      abs_m_4_13  1
    r[4]      abs_p_4_14  -1
    r[4]      abs_m_4_14  1
    r[4]      abs_p_4_15  -1
    r[4]      abs_m_4_15  1
    r[4]      abs_p_4_16  -1
    r[4]      abs_m_4_16  1
    r[4]      abs_p_4_17  -1
    r[4]      abs_m_4_17  1
    r[4]      abs_p_4_18  -1
    r[4]      abs_m_4_18  1
    r[4]      abs_p_4_19  -1
    r[4]      abs_m_4_19  1
    r[4]      abs_p_4_20  -1
    r[4]      abs_m_4_20  1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      abs_p_1_5  1
    r[5]      abs_m_1_5  -1
    r[5]      abs_p_2_5  1
    r[5]      abs_m_2_5  -1
    r[5]      abs_p_3_5  1
    r[5]      abs_m_3_5  -1
    r[5]      abs_p_4_5  1
    r[5]      abs_m_4_5  -1
    r[5]      abs_p_5_6  -1
    r[5]      abs_m_5_6  1
    r[5]      abs_p_5_7  -1
    r[5]      abs_m_5_7  1
    r[5]      abs_p_5_8  -1
    r[5]      abs_m_5_8  1
    r[5]      abs_p_5_9  -1
    r[5]      abs_m_5_9  1
    r[5]      abs_p_5_10  -1
    r[5]      abs_m_5_10  1
    r[5]      abs_p_5_11  -1
    r[5]      abs_m_5_11  1
    r[5]      abs_p_5_12  -1
    r[5]      abs_m_5_12  1
    r[5]      abs_p_5_13  -1
    r[5]      abs_m_5_13  1
    r[5]      abs_p_5_14  -1
    r[5]      abs_m_5_14  1
    r[5]      abs_p_5_15  -1
    r[5]      abs_m_5_15  1
    r[5]      abs_p_5_16  -1
    r[5]      abs_m_5_16  1
    r[5]      abs_p_5_17  -1
    r[5]      abs_m_5_17  1
    r[5]      abs_p_5_18  -1
    r[5]      abs_m_5_18  1
    r[5]      abs_p_5_19  -1
    r[5]      abs_m_5_19  1
    r[5]      abs_p_5_20  -1
    r[5]      abs_m_5_20  1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      abs_p_1_6  1
    r[6]      abs_m_1_6  -1
    r[6]      abs_p_2_6  1
    r[6]      abs_m_2_6  -1
    r[6]      abs_p_3_6  1
    r[6]      abs_m_3_6  -1
    r[6]      abs_p_4_6  1
    r[6]      abs_m_4_6  -1
    r[6]      abs_p_5_6  1
    r[6]      abs_m_5_6  -1
    r[6]      abs_p_6_7  -1
    r[6]      abs_m_6_7  1
    r[6]      abs_p_6_8  -1
    r[6]      abs_m_6_8  1
    r[6]      abs_p_6_9  -1
    r[6]      abs_m_6_9  1
    r[6]      abs_p_6_10  -1
    r[6]      abs_m_6_10  1
    r[6]      abs_p_6_11  -1
    r[6]      abs_m_6_11  1
    r[6]      abs_p_6_12  -1
    r[6]      abs_m_6_12  1
    r[6]      abs_p_6_13  -1
    r[6]      abs_m_6_13  1
    r[6]      abs_p_6_14  -1
    r[6]      abs_m_6_14  1
    r[6]      abs_p_6_15  -1
    r[6]      abs_m_6_15  1
    r[6]      abs_p_6_16  -1
    r[6]      abs_m_6_16  1
    r[6]      abs_p_6_17  -1
    r[6]      abs_m_6_17  1
    r[6]      abs_p_6_18  -1
    r[6]      abs_m_6_18  1
    r[6]      abs_p_6_19  -1
    r[6]      abs_m_6_19  1
    r[6]      abs_p_6_20  -1
    r[6]      abs_m_6_20  1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      abs_p_1_7  1
    r[7]      abs_m_1_7  -1
    r[7]      abs_p_2_7  1
    r[7]      abs_m_2_7  -1
    r[7]      abs_p_3_7  1
    r[7]      abs_m_3_7  -1
    r[7]      abs_p_4_7  1
    r[7]      abs_m_4_7  -1
    r[7]      abs_p_5_7  1
    r[7]      abs_m_5_7  -1
    r[7]      abs_p_6_7  1
    r[7]      abs_m_6_7  -1
    r[7]      abs_p_7_8  -1
    r[7]      abs_m_7_8  1
    r[7]      abs_p_7_9  -1
    r[7]      abs_m_7_9  1
    r[7]      abs_p_7_10  -1
    r[7]      abs_m_7_10  1
    r[7]      abs_p_7_11  -1
    r[7]      abs_m_7_11  1
    r[7]      abs_p_7_12  -1
    r[7]      abs_m_7_12  1
    r[7]      abs_p_7_13  -1
    r[7]      abs_m_7_13  1
    r[7]      abs_p_7_14  -1
    r[7]      abs_m_7_14  1
    r[7]      abs_p_7_15  -1
    r[7]      abs_m_7_15  1
    r[7]      abs_p_7_16  -1
    r[7]      abs_m_7_16  1
    r[7]      abs_p_7_17  -1
    r[7]      abs_m_7_17  1
    r[7]      abs_p_7_18  -1
    r[7]      abs_m_7_18  1
    r[7]      abs_p_7_19  -1
    r[7]      abs_m_7_19  1
    r[7]      abs_p_7_20  -1
    r[7]      abs_m_7_20  1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      abs_p_1_8  1
    r[8]      abs_m_1_8  -1
    r[8]      abs_p_2_8  1
    r[8]      abs_m_2_8  -1
    r[8]      abs_p_3_8  1
    r[8]      abs_m_3_8  -1
    r[8]      abs_p_4_8  1
    r[8]      abs_m_4_8  -1
    r[8]      abs_p_5_8  1
    r[8]      abs_m_5_8  -1
    r[8]      abs_p_6_8  1
    r[8]      abs_m_6_8  -1
    r[8]      abs_p_7_8  1
    r[8]      abs_m_7_8  -1
    r[8]      abs_p_8_9  -1
    r[8]      abs_m_8_9  1
    r[8]      abs_p_8_10  -1
    r[8]      abs_m_8_10  1
    r[8]      abs_p_8_11  -1
    r[8]      abs_m_8_11  1
    r[8]      abs_p_8_12  -1
    r[8]      abs_m_8_12  1
    r[8]      abs_p_8_13  -1
    r[8]      abs_m_8_13  1
    r[8]      abs_p_8_14  -1
    r[8]      abs_m_8_14  1
    r[8]      abs_p_8_15  -1
    r[8]      abs_m_8_15  1
    r[8]      abs_p_8_16  -1
    r[8]      abs_m_8_16  1
    r[8]      abs_p_8_17  -1
    r[8]      abs_m_8_17  1
    r[8]      abs_p_8_18  -1
    r[8]      abs_m_8_18  1
    r[8]      abs_p_8_19  -1
    r[8]      abs_m_8_19  1
    r[8]      abs_p_8_20  -1
    r[8]      abs_m_8_20  1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      abs_p_1_9  1
    r[9]      abs_m_1_9  -1
    r[9]      abs_p_2_9  1
    r[9]      abs_m_2_9  -1
    r[9]      abs_p_3_9  1
    r[9]      abs_m_3_9  -1
    r[9]      abs_p_4_9  1
    r[9]      abs_m_4_9  -1
    r[9]      abs_p_5_9  1
    r[9]      abs_m_5_9  -1
    r[9]      abs_p_6_9  1
    r[9]      abs_m_6_9  -1
    r[9]      abs_p_7_9  1
    r[9]      abs_m_7_9  -1
    r[9]      abs_p_8_9  1
    r[9]      abs_m_8_9  -1
    r[9]      abs_p_9_10  -1
    r[9]      abs_m_9_10  1
    r[9]      abs_p_9_11  -1
    r[9]      abs_m_9_11  1
    r[9]      abs_p_9_12  -1
    r[9]      abs_m_9_12  1
    r[9]      abs_p_9_13  -1
    r[9]      abs_m_9_13  1
    r[9]      abs_p_9_14  -1
    r[9]      abs_m_9_14  1
    r[9]      abs_p_9_15  -1
    r[9]      abs_m_9_15  1
    r[9]      abs_p_9_16  -1
    r[9]      abs_m_9_16  1
    r[9]      abs_p_9_17  -1
    r[9]      abs_m_9_17  1
    r[9]      abs_p_9_18  -1
    r[9]      abs_m_9_18  1
    r[9]      abs_p_9_19  -1
    r[9]      abs_m_9_19  1
    r[9]      abs_p_9_20  -1
    r[9]      abs_m_9_20  1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     abs_p_1_10  1
    r[10]     abs_m_1_10  -1
    r[10]     abs_p_2_10  1
    r[10]     abs_m_2_10  -1
    r[10]     abs_p_3_10  1
    r[10]     abs_m_3_10  -1
    r[10]     abs_p_4_10  1
    r[10]     abs_m_4_10  -1
    r[10]     abs_p_5_10  1
    r[10]     abs_m_5_10  -1
    r[10]     abs_p_6_10  1
    r[10]     abs_m_6_10  -1
    r[10]     abs_p_7_10  1
    r[10]     abs_m_7_10  -1
    r[10]     abs_p_8_10  1
    r[10]     abs_m_8_10  -1
    r[10]     abs_p_9_10  1
    r[10]     abs_m_9_10  -1
    r[10]     abs_p_10_11  -1
    r[10]     abs_m_10_11  1
    r[10]     abs_p_10_12  -1
    r[10]     abs_m_10_12  1
    r[10]     abs_p_10_13  -1
    r[10]     abs_m_10_13  1
    r[10]     abs_p_10_14  -1
    r[10]     abs_m_10_14  1
    r[10]     abs_p_10_15  -1
    r[10]     abs_m_10_15  1
    r[10]     abs_p_10_16  -1
    r[10]     abs_m_10_16  1
    r[10]     abs_p_10_17  -1
    r[10]     abs_m_10_17  1
    r[10]     abs_p_10_18  -1
    r[10]     abs_m_10_18  1
    r[10]     abs_p_10_19  -1
    r[10]     abs_m_10_19  1
    r[10]     abs_p_10_20  -1
    r[10]     abs_m_10_20  1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     abs_p_1_11  1
    r[11]     abs_m_1_11  -1
    r[11]     abs_p_2_11  1
    r[11]     abs_m_2_11  -1
    r[11]     abs_p_3_11  1
    r[11]     abs_m_3_11  -1
    r[11]     abs_p_4_11  1
    r[11]     abs_m_4_11  -1
    r[11]     abs_p_5_11  1
    r[11]     abs_m_5_11  -1
    r[11]     abs_p_6_11  1
    r[11]     abs_m_6_11  -1
    r[11]     abs_p_7_11  1
    r[11]     abs_m_7_11  -1
    r[11]     abs_p_8_11  1
    r[11]     abs_m_8_11  -1
    r[11]     abs_p_9_11  1
    r[11]     abs_m_9_11  -1
    r[11]     abs_p_10_11  1
    r[11]     abs_m_10_11  -1
    r[11]     abs_p_11_12  -1
    r[11]     abs_m_11_12  1
    r[11]     abs_p_11_13  -1
    r[11]     abs_m_11_13  1
    r[11]     abs_p_11_14  -1
    r[11]     abs_m_11_14  1
    r[11]     abs_p_11_15  -1
    r[11]     abs_m_11_15  1
    r[11]     abs_p_11_16  -1
    r[11]     abs_m_11_16  1
    r[11]     abs_p_11_17  -1
    r[11]     abs_m_11_17  1
    r[11]     abs_p_11_18  -1
    r[11]     abs_m_11_18  1
    r[11]     abs_p_11_19  -1
    r[11]     abs_m_11_19  1
    r[11]     abs_p_11_20  -1
    r[11]     abs_m_11_20  1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     abs_p_1_12  1
    r[12]     abs_m_1_12  -1
    r[12]     abs_p_2_12  1
    r[12]     abs_m_2_12  -1
    r[12]     abs_p_3_12  1
    r[12]     abs_m_3_12  -1
    r[12]     abs_p_4_12  1
    r[12]     abs_m_4_12  -1
    r[12]     abs_p_5_12  1
    r[12]     abs_m_5_12  -1
    r[12]     abs_p_6_12  1
    r[12]     abs_m_6_12  -1
    r[12]     abs_p_7_12  1
    r[12]     abs_m_7_12  -1
    r[12]     abs_p_8_12  1
    r[12]     abs_m_8_12  -1
    r[12]     abs_p_9_12  1
    r[12]     abs_m_9_12  -1
    r[12]     abs_p_10_12  1
    r[12]     abs_m_10_12  -1
    r[12]     abs_p_11_12  1
    r[12]     abs_m_11_12  -1
    r[12]     abs_p_12_13  -1
    r[12]     abs_m_12_13  1
    r[12]     abs_p_12_14  -1
    r[12]     abs_m_12_14  1
    r[12]     abs_p_12_15  -1
    r[12]     abs_m_12_15  1
    r[12]     abs_p_12_16  -1
    r[12]     abs_m_12_16  1
    r[12]     abs_p_12_17  -1
    r[12]     abs_m_12_17  1
    r[12]     abs_p_12_18  -1
    r[12]     abs_m_12_18  1
    r[12]     abs_p_12_19  -1
    r[12]     abs_m_12_19  1
    r[12]     abs_p_12_20  -1
    r[12]     abs_m_12_20  1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     abs_p_1_13  1
    r[13]     abs_m_1_13  -1
    r[13]     abs_p_2_13  1
    r[13]     abs_m_2_13  -1
    r[13]     abs_p_3_13  1
    r[13]     abs_m_3_13  -1
    r[13]     abs_p_4_13  1
    r[13]     abs_m_4_13  -1
    r[13]     abs_p_5_13  1
    r[13]     abs_m_5_13  -1
    r[13]     abs_p_6_13  1
    r[13]     abs_m_6_13  -1
    r[13]     abs_p_7_13  1
    r[13]     abs_m_7_13  -1
    r[13]     abs_p_8_13  1
    r[13]     abs_m_8_13  -1
    r[13]     abs_p_9_13  1
    r[13]     abs_m_9_13  -1
    r[13]     abs_p_10_13  1
    r[13]     abs_m_10_13  -1
    r[13]     abs_p_11_13  1
    r[13]     abs_m_11_13  -1
    r[13]     abs_p_12_13  1
    r[13]     abs_m_12_13  -1
    r[13]     abs_p_13_14  -1
    r[13]     abs_m_13_14  1
    r[13]     abs_p_13_15  -1
    r[13]     abs_m_13_15  1
    r[13]     abs_p_13_16  -1
    r[13]     abs_m_13_16  1
    r[13]     abs_p_13_17  -1
    r[13]     abs_m_13_17  1
    r[13]     abs_p_13_18  -1
    r[13]     abs_m_13_18  1
    r[13]     abs_p_13_19  -1
    r[13]     abs_m_13_19  1
    r[13]     abs_p_13_20  -1
    r[13]     abs_m_13_20  1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     abs_p_1_14  1
    r[14]     abs_m_1_14  -1
    r[14]     abs_p_2_14  1
    r[14]     abs_m_2_14  -1
    r[14]     abs_p_3_14  1
    r[14]     abs_m_3_14  -1
    r[14]     abs_p_4_14  1
    r[14]     abs_m_4_14  -1
    r[14]     abs_p_5_14  1
    r[14]     abs_m_5_14  -1
    r[14]     abs_p_6_14  1
    r[14]     abs_m_6_14  -1
    r[14]     abs_p_7_14  1
    r[14]     abs_m_7_14  -1
    r[14]     abs_p_8_14  1
    r[14]     abs_m_8_14  -1
    r[14]     abs_p_9_14  1
    r[14]     abs_m_9_14  -1
    r[14]     abs_p_10_14  1
    r[14]     abs_m_10_14  -1
    r[14]     abs_p_11_14  1
    r[14]     abs_m_11_14  -1
    r[14]     abs_p_12_14  1
    r[14]     abs_m_12_14  -1
    r[14]     abs_p_13_14  1
    r[14]     abs_m_13_14  -1
    r[14]     abs_p_14_15  -1
    r[14]     abs_m_14_15  1
    r[14]     abs_p_14_16  -1
    r[14]     abs_m_14_16  1
    r[14]     abs_p_14_17  -1
    r[14]     abs_m_14_17  1
    r[14]     abs_p_14_18  -1
    r[14]     abs_m_14_18  1
    r[14]     abs_p_14_19  -1
    r[14]     abs_m_14_19  1
    r[14]     abs_p_14_20  -1
    r[14]     abs_m_14_20  1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     abs_p_1_15  1
    r[15]     abs_m_1_15  -1
    r[15]     abs_p_2_15  1
    r[15]     abs_m_2_15  -1
    r[15]     abs_p_3_15  1
    r[15]     abs_m_3_15  -1
    r[15]     abs_p_4_15  1
    r[15]     abs_m_4_15  -1
    r[15]     abs_p_5_15  1
    r[15]     abs_m_5_15  -1
    r[15]     abs_p_6_15  1
    r[15]     abs_m_6_15  -1
    r[15]     abs_p_7_15  1
    r[15]     abs_m_7_15  -1
    r[15]     abs_p_8_15  1
    r[15]     abs_m_8_15  -1
    r[15]     abs_p_9_15  1
    r[15]     abs_m_9_15  -1
    r[15]     abs_p_10_15  1
    r[15]     abs_m_10_15  -1
    r[15]     abs_p_11_15  1
    r[15]     abs_m_11_15  -1
    r[15]     abs_p_12_15  1
    r[15]     abs_m_12_15  -1
    r[15]     abs_p_13_15  1
    r[15]     abs_m_13_15  -1
    r[15]     abs_p_14_15  1
    r[15]     abs_m_14_15  -1
    r[15]     abs_p_15_16  -1
    r[15]     abs_m_15_16  1
    r[15]     abs_p_15_17  -1
    r[15]     abs_m_15_17  1
    r[15]     abs_p_15_18  -1
    r[15]     abs_m_15_18  1
    r[15]     abs_p_15_19  -1
    r[15]     abs_m_15_19  1
    r[15]     abs_p_15_20  -1
    r[15]     abs_m_15_20  1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     abs_p_1_16  1
    r[16]     abs_m_1_16  -1
    r[16]     abs_p_2_16  1
    r[16]     abs_m_2_16  -1
    r[16]     abs_p_3_16  1
    r[16]     abs_m_3_16  -1
    r[16]     abs_p_4_16  1
    r[16]     abs_m_4_16  -1
    r[16]     abs_p_5_16  1
    r[16]     abs_m_5_16  -1
    r[16]     abs_p_6_16  1
    r[16]     abs_m_6_16  -1
    r[16]     abs_p_7_16  1
    r[16]     abs_m_7_16  -1
    r[16]     abs_p_8_16  1
    r[16]     abs_m_8_16  -1
    r[16]     abs_p_9_16  1
    r[16]     abs_m_9_16  -1
    r[16]     abs_p_10_16  1
    r[16]     abs_m_10_16  -1
    r[16]     abs_p_11_16  1
    r[16]     abs_m_11_16  -1
    r[16]     abs_p_12_16  1
    r[16]     abs_m_12_16  -1
    r[16]     abs_p_13_16  1
    r[16]     abs_m_13_16  -1
    r[16]     abs_p_14_16  1
    r[16]     abs_m_14_16  -1
    r[16]     abs_p_15_16  1
    r[16]     abs_m_15_16  -1
    r[16]     abs_p_16_17  -1
    r[16]     abs_m_16_17  1
    r[16]     abs_p_16_18  -1
    r[16]     abs_m_16_18  1
    r[16]     abs_p_16_19  -1
    r[16]     abs_m_16_19  1
    r[16]     abs_p_16_20  -1
    r[16]     abs_m_16_20  1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     abs_p_1_17  1
    r[17]     abs_m_1_17  -1
    r[17]     abs_p_2_17  1
    r[17]     abs_m_2_17  -1
    r[17]     abs_p_3_17  1
    r[17]     abs_m_3_17  -1
    r[17]     abs_p_4_17  1
    r[17]     abs_m_4_17  -1
    r[17]     abs_p_5_17  1
    r[17]     abs_m_5_17  -1
    r[17]     abs_p_6_17  1
    r[17]     abs_m_6_17  -1
    r[17]     abs_p_7_17  1
    r[17]     abs_m_7_17  -1
    r[17]     abs_p_8_17  1
    r[17]     abs_m_8_17  -1
    r[17]     abs_p_9_17  1
    r[17]     abs_m_9_17  -1
    r[17]     abs_p_10_17  1
    r[17]     abs_m_10_17  -1
    r[17]     abs_p_11_17  1
    r[17]     abs_m_11_17  -1
    r[17]     abs_p_12_17  1
    r[17]     abs_m_12_17  -1
    r[17]     abs_p_13_17  1
    r[17]     abs_m_13_17  -1
    r[17]     abs_p_14_17  1
    r[17]     abs_m_14_17  -1
    r[17]     abs_p_15_17  1
    r[17]     abs_m_15_17  -1
    r[17]     abs_p_16_17  1
    r[17]     abs_m_16_17  -1
    r[17]     abs_p_17_18  -1
    r[17]     abs_m_17_18  1
    r[17]     abs_p_17_19  -1
    r[17]     abs_m_17_19  1
    r[17]     abs_p_17_20  -1
    r[17]     abs_m_17_20  1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     abs_p_1_18  1
    r[18]     abs_m_1_18  -1
    r[18]     abs_p_2_18  1
    r[18]     abs_m_2_18  -1
    r[18]     abs_p_3_18  1
    r[18]     abs_m_3_18  -1
    r[18]     abs_p_4_18  1
    r[18]     abs_m_4_18  -1
    r[18]     abs_p_5_18  1
    r[18]     abs_m_5_18  -1
    r[18]     abs_p_6_18  1
    r[18]     abs_m_6_18  -1
    r[18]     abs_p_7_18  1
    r[18]     abs_m_7_18  -1
    r[18]     abs_p_8_18  1
    r[18]     abs_m_8_18  -1
    r[18]     abs_p_9_18  1
    r[18]     abs_m_9_18  -1
    r[18]     abs_p_10_18  1
    r[18]     abs_m_10_18  -1
    r[18]     abs_p_11_18  1
    r[18]     abs_m_11_18  -1
    r[18]     abs_p_12_18  1
    r[18]     abs_m_12_18  -1
    r[18]     abs_p_13_18  1
    r[18]     abs_m_13_18  -1
    r[18]     abs_p_14_18  1
    r[18]     abs_m_14_18  -1
    r[18]     abs_p_15_18  1
    r[18]     abs_m_15_18  -1
    r[18]     abs_p_16_18  1
    r[18]     abs_m_16_18  -1
    r[18]     abs_p_17_18  1
    r[18]     abs_m_17_18  -1
    r[18]     abs_p_18_19  -1
    r[18]     abs_m_18_19  1
    r[18]     abs_p_18_20  -1
    r[18]     abs_m_18_20  1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     abs_p_1_19  1
    r[19]     abs_m_1_19  -1
    r[19]     abs_p_2_19  1
    r[19]     abs_m_2_19  -1
    r[19]     abs_p_3_19  1
    r[19]     abs_m_3_19  -1
    r[19]     abs_p_4_19  1
    r[19]     abs_m_4_19  -1
    r[19]     abs_p_5_19  1
    r[19]     abs_m_5_19  -1
    r[19]     abs_p_6_19  1
    r[19]     abs_m_6_19  -1
    r[19]     abs_p_7_19  1
    r[19]     abs_m_7_19  -1
    r[19]     abs_p_8_19  1
    r[19]     abs_m_8_19  -1
    r[19]     abs_p_9_19  1
    r[19]     abs_m_9_19  -1
    r[19]     abs_p_10_19  1
    r[19]     abs_m_10_19  -1
    r[19]     abs_p_11_19  1
    r[19]     abs_m_11_19  -1
    r[19]     abs_p_12_19  1
    r[19]     abs_m_12_19  -1
    r[19]     abs_p_13_19  1
    r[19]     abs_m_13_19  -1
    r[19]     abs_p_14_19  1
    r[19]     abs_m_14_19  -1
    r[19]     abs_p_15_19  1
    r[19]     abs_m_15_19  -1
    r[19]     abs_p_16_19  1
    r[19]     abs_m_16_19  -1
    r[19]     abs_p_17_19  1
    r[19]     abs_m_17_19  -1
    r[19]     abs_p_18_19  1
    r[19]     abs_m_18_19  -1
    r[19]     abs_p_19_20  -1
    r[19]     abs_m_19_20  1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     abs_p_1_20  1
    r[20]     abs_m_1_20  -1
    r[20]     abs_p_2_20  1
    r[20]     abs_m_2_20  -1
    r[20]     abs_p_3_20  1
    r[20]     abs_m_3_20  -1
    r[20]     abs_p_4_20  1
    r[20]     abs_m_4_20  -1
    r[20]     abs_p_5_20  1
    r[20]     abs_m_5_20  -1
    r[20]     abs_p_6_20  1
    r[20]     abs_m_6_20  -1
    r[20]     abs_p_7_20  1
    r[20]     abs_m_7_20  -1
    r[20]     abs_p_8_20  1
    r[20]     abs_m_8_20  -1
    r[20]     abs_p_9_20  1
    r[20]     abs_m_9_20  -1
    r[20]     abs_p_10_20  1
    r[20]     abs_m_10_20  -1
    r[20]     abs_p_11_20  1
    r[20]     abs_m_11_20  -1
    r[20]     abs_p_12_20  1
    r[20]     abs_m_12_20  -1
    r[20]     abs_p_13_20  1
    r[20]     abs_m_13_20  -1
    r[20]     abs_p_14_20  1
    r[20]     abs_m_14_20  -1
    r[20]     abs_p_15_20  1
    r[20]     abs_m_15_20  -1
    r[20]     abs_p_16_20  1
    r[20]     abs_m_16_20  -1
    r[20]     abs_p_17_20  1
    r[20]     abs_m_17_20  -1
    r[20]     abs_p_18_20  1
    r[20]     abs_m_18_20  -1
    r[20]     abs_p_19_20  1
    r[20]     abs_m_19_20  -1
    a[1,2]    abs_p_1_2  1
    a[1,2]    abs_m_1_2  1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,2]    old_normalized_TC  1
    a[1,2]    old_normalized_TC2  1
    a[1,3]    abs_p_1_3  1
    a[1,3]    abs_m_1_3  1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,3]    old_normalized_TC  1
    a[1,3]    old_normalized_TC2  1
    a[1,4]    abs_p_1_4  1
    a[1,4]    abs_m_1_4  1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,4]    old_normalized_TC  1
    a[1,4]    old_normalized_TC2  1
    a[1,5]    abs_p_1_5  1
    a[1,5]    abs_m_1_5  1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,5]    old_normalized_TC  1
    a[1,5]    old_normalized_TC2  1
    a[1,6]    abs_p_1_6  1
    a[1,6]    abs_m_1_6  1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,6]    old_normalized_TC  1
    a[1,6]    old_normalized_TC2  1
    a[1,7]    abs_p_1_7  1
    a[1,7]    abs_m_1_7  1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,7]    old_normalized_TC  1
    a[1,7]    old_normalized_TC2  1
    a[1,8]    abs_p_1_8  1
    a[1,8]    abs_m_1_8  1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,8]    old_normalized_TC  1
    a[1,8]    old_normalized_TC2  1
    a[1,9]    abs_p_1_9  1
    a[1,9]    abs_m_1_9  1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,9]    old_normalized_TC  1
    a[1,9]    old_normalized_TC2  1
    a[1,10]   abs_p_1_10  1
    a[1,10]   abs_m_1_10  1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,10]   old_normalized_TC  1
    a[1,10]   old_normalized_TC2  1
    a[1,11]   abs_p_1_11  1
    a[1,11]   abs_m_1_11  1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,11]   old_normalized_TC  1
    a[1,11]   old_normalized_TC2  1
    a[1,12]   abs_p_1_12  1
    a[1,12]   abs_m_1_12  1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,12]   old_normalized_TC  1
    a[1,12]   old_normalized_TC2  1
    a[1,13]   abs_p_1_13  1
    a[1,13]   abs_m_1_13  1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,13]   old_normalized_TC  1
    a[1,13]   old_normalized_TC2  1
    a[1,14]   abs_p_1_14  1
    a[1,14]   abs_m_1_14  1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,14]   old_normalized_TC  1
    a[1,14]   old_normalized_TC2  1
    a[1,15]   abs_p_1_15  1
    a[1,15]   abs_m_1_15  1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,15]   old_normalized_TC  1
    a[1,15]   old_normalized_TC2  1
    a[1,16]   abs_p_1_16  1
    a[1,16]   abs_m_1_16  1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,16]   old_normalized_TC  1
    a[1,16]   old_normalized_TC2  1
    a[1,17]   abs_p_1_17  1
    a[1,17]   abs_m_1_17  1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,17]   old_normalized_TC  1
    a[1,17]   old_normalized_TC2  1
    a[1,18]   abs_p_1_18  1
    a[1,18]   abs_m_1_18  1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,18]   old_normalized_TC  1
    a[1,18]   old_normalized_TC2  1
    a[1,19]   abs_p_1_19  1
    a[1,19]   abs_m_1_19  1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,19]   old_normalized_TC  1
    a[1,19]   old_normalized_TC2  1
    a[1,20]   abs_p_1_20  1
    a[1,20]   abs_m_1_20  1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[1,20]   old_normalized_TC  1
    a[1,20]   old_normalized_TC2  1
    a[2,3]    abs_p_2_3  1
    a[2,3]    abs_m_2_3  1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,3]    old_normalized_TC  1
    a[2,3]    old_normalized_TC2  1
    a[2,4]    abs_p_2_4  1
    a[2,4]    abs_m_2_4  1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,4]    old_normalized_TC  1
    a[2,4]    old_normalized_TC2  1
    a[2,5]    abs_p_2_5  1
    a[2,5]    abs_m_2_5  1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,5]    old_normalized_TC  1
    a[2,5]    old_normalized_TC2  1
    a[2,6]    abs_p_2_6  1
    a[2,6]    abs_m_2_6  1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,6]    old_normalized_TC  1
    a[2,6]    old_normalized_TC2  1
    a[2,7]    abs_p_2_7  1
    a[2,7]    abs_m_2_7  1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,7]    old_normalized_TC  1
    a[2,7]    old_normalized_TC2  1
    a[2,8]    abs_p_2_8  1
    a[2,8]    abs_m_2_8  1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,8]    old_normalized_TC  1
    a[2,8]    old_normalized_TC2  1
    a[2,9]    abs_p_2_9  1
    a[2,9]    abs_m_2_9  1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,9]    old_normalized_TC  1
    a[2,9]    old_normalized_TC2  1
    a[2,10]   abs_p_2_10  1
    a[2,10]   abs_m_2_10  1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,10]   old_normalized_TC  1
    a[2,10]   old_normalized_TC2  1
    a[2,11]   abs_p_2_11  1
    a[2,11]   abs_m_2_11  1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,11]   old_normalized_TC  1
    a[2,11]   old_normalized_TC2  1
    a[2,12]   abs_p_2_12  1
    a[2,12]   abs_m_2_12  1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,12]   old_normalized_TC  1
    a[2,12]   old_normalized_TC2  1
    a[2,13]   abs_p_2_13  1
    a[2,13]   abs_m_2_13  1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,13]   old_normalized_TC  1
    a[2,13]   old_normalized_TC2  1
    a[2,14]   abs_p_2_14  1
    a[2,14]   abs_m_2_14  1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,14]   old_normalized_TC  1
    a[2,14]   old_normalized_TC2  1
    a[2,15]   abs_p_2_15  1
    a[2,15]   abs_m_2_15  1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,15]   old_normalized_TC  1
    a[2,15]   old_normalized_TC2  1
    a[2,16]   abs_p_2_16  1
    a[2,16]   abs_m_2_16  1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,16]   old_normalized_TC  1
    a[2,16]   old_normalized_TC2  1
    a[2,17]   abs_p_2_17  1
    a[2,17]   abs_m_2_17  1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,17]   old_normalized_TC  1
    a[2,17]   old_normalized_TC2  1
    a[2,18]   abs_p_2_18  1
    a[2,18]   abs_m_2_18  1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,18]   old_normalized_TC  1
    a[2,18]   old_normalized_TC2  1
    a[2,19]   abs_p_2_19  1
    a[2,19]   abs_m_2_19  1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,19]   old_normalized_TC  1
    a[2,19]   old_normalized_TC2  1
    a[2,20]   abs_p_2_20  1
    a[2,20]   abs_m_2_20  1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[2,20]   old_normalized_TC  1
    a[2,20]   old_normalized_TC2  1
    a[3,4]    abs_p_3_4  1
    a[3,4]    abs_m_3_4  1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,4]    old_normalized_TC  1
    a[3,4]    old_normalized_TC2  1
    a[3,5]    abs_p_3_5  1
    a[3,5]    abs_m_3_5  1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,5]    old_normalized_TC  1
    a[3,5]    old_normalized_TC2  1
    a[3,6]    abs_p_3_6  1
    a[3,6]    abs_m_3_6  1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,6]    old_normalized_TC  1
    a[3,6]    old_normalized_TC2  1
    a[3,7]    abs_p_3_7  1
    a[3,7]    abs_m_3_7  1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,7]    old_normalized_TC  1
    a[3,7]    old_normalized_TC2  1
    a[3,8]    abs_p_3_8  1
    a[3,8]    abs_m_3_8  1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,8]    old_normalized_TC  1
    a[3,8]    old_normalized_TC2  1
    a[3,9]    abs_p_3_9  1
    a[3,9]    abs_m_3_9  1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,9]    old_normalized_TC  1
    a[3,9]    old_normalized_TC2  1
    a[3,10]   abs_p_3_10  1
    a[3,10]   abs_m_3_10  1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,10]   old_normalized_TC  1
    a[3,10]   old_normalized_TC2  1
    a[3,11]   abs_p_3_11  1
    a[3,11]   abs_m_3_11  1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,11]   old_normalized_TC  1
    a[3,11]   old_normalized_TC2  1
    a[3,12]   abs_p_3_12  1
    a[3,12]   abs_m_3_12  1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,12]   old_normalized_TC  1
    a[3,12]   old_normalized_TC2  1
    a[3,13]   abs_p_3_13  1
    a[3,13]   abs_m_3_13  1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,13]   old_normalized_TC  1
    a[3,13]   old_normalized_TC2  1
    a[3,14]   abs_p_3_14  1
    a[3,14]   abs_m_3_14  1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,14]   old_normalized_TC  1
    a[3,14]   old_normalized_TC2  1
    a[3,15]   abs_p_3_15  1
    a[3,15]   abs_m_3_15  1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,15]   old_normalized_TC  1
    a[3,15]   old_normalized_TC2  1
    a[3,16]   abs_p_3_16  1
    a[3,16]   abs_m_3_16  1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,16]   old_normalized_TC  1
    a[3,16]   old_normalized_TC2  1
    a[3,17]   abs_p_3_17  1
    a[3,17]   abs_m_3_17  1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,17]   old_normalized_TC  1
    a[3,17]   old_normalized_TC2  1
    a[3,18]   abs_p_3_18  1
    a[3,18]   abs_m_3_18  1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,18]   old_normalized_TC  1
    a[3,18]   old_normalized_TC2  1
    a[3,19]   abs_p_3_19  1
    a[3,19]   abs_m_3_19  1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,19]   old_normalized_TC  1
    a[3,19]   old_normalized_TC2  1
    a[3,20]   abs_p_3_20  1
    a[3,20]   abs_m_3_20  1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[3,20]   old_normalized_TC  1
    a[3,20]   old_normalized_TC2  1
    a[4,5]    abs_p_4_5  1
    a[4,5]    abs_m_4_5  1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,5]    old_normalized_TC  1
    a[4,5]    old_normalized_TC2  1
    a[4,6]    abs_p_4_6  1
    a[4,6]    abs_m_4_6  1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,6]    old_normalized_TC  1
    a[4,6]    old_normalized_TC2  1
    a[4,7]    abs_p_4_7  1
    a[4,7]    abs_m_4_7  1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,7]    old_normalized_TC  1
    a[4,7]    old_normalized_TC2  1
    a[4,8]    abs_p_4_8  1
    a[4,8]    abs_m_4_8  1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,8]    old_normalized_TC  1
    a[4,8]    old_normalized_TC2  1
    a[4,9]    abs_p_4_9  1
    a[4,9]    abs_m_4_9  1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,9]    old_normalized_TC  1
    a[4,9]    old_normalized_TC2  1
    a[4,10]   abs_p_4_10  1
    a[4,10]   abs_m_4_10  1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,10]   old_normalized_TC  1
    a[4,10]   old_normalized_TC2  1
    a[4,11]   abs_p_4_11  1
    a[4,11]   abs_m_4_11  1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,11]   old_normalized_TC  1
    a[4,11]   old_normalized_TC2  1
    a[4,12]   abs_p_4_12  1
    a[4,12]   abs_m_4_12  1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,12]   old_normalized_TC  1
    a[4,12]   old_normalized_TC2  1
    a[4,13]   abs_p_4_13  1
    a[4,13]   abs_m_4_13  1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,13]   old_normalized_TC  1
    a[4,13]   old_normalized_TC2  1
    a[4,14]   abs_p_4_14  1
    a[4,14]   abs_m_4_14  1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,14]   old_normalized_TC  1
    a[4,14]   old_normalized_TC2  1
    a[4,15]   abs_p_4_15  1
    a[4,15]   abs_m_4_15  1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,15]   old_normalized_TC  1
    a[4,15]   old_normalized_TC2  1
    a[4,16]   abs_p_4_16  1
    a[4,16]   abs_m_4_16  1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,16]   old_normalized_TC  1
    a[4,16]   old_normalized_TC2  1
    a[4,17]   abs_p_4_17  1
    a[4,17]   abs_m_4_17  1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,17]   old_normalized_TC  1
    a[4,17]   old_normalized_TC2  1
    a[4,18]   abs_p_4_18  1
    a[4,18]   abs_m_4_18  1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,18]   old_normalized_TC  1
    a[4,18]   old_normalized_TC2  1
    a[4,19]   abs_p_4_19  1
    a[4,19]   abs_m_4_19  1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,19]   old_normalized_TC  1
    a[4,19]   old_normalized_TC2  1
    a[4,20]   abs_p_4_20  1
    a[4,20]   abs_m_4_20  1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[4,20]   old_normalized_TC  1
    a[4,20]   old_normalized_TC2  1
    a[5,6]    abs_p_5_6  1
    a[5,6]    abs_m_5_6  1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,6]    old_normalized_TC  1
    a[5,6]    old_normalized_TC2  1
    a[5,7]    abs_p_5_7  1
    a[5,7]    abs_m_5_7  1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,7]    old_normalized_TC  1
    a[5,7]    old_normalized_TC2  1
    a[5,8]    abs_p_5_8  1
    a[5,8]    abs_m_5_8  1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,8]    old_normalized_TC  1
    a[5,8]    old_normalized_TC2  1
    a[5,9]    abs_p_5_9  1
    a[5,9]    abs_m_5_9  1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,9]    old_normalized_TC  1
    a[5,9]    old_normalized_TC2  1
    a[5,10]   abs_p_5_10  1
    a[5,10]   abs_m_5_10  1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,10]   old_normalized_TC  1
    a[5,10]   old_normalized_TC2  1
    a[5,11]   abs_p_5_11  1
    a[5,11]   abs_m_5_11  1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,11]   old_normalized_TC  1
    a[5,11]   old_normalized_TC2  1
    a[5,12]   abs_p_5_12  1
    a[5,12]   abs_m_5_12  1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,12]   old_normalized_TC  1
    a[5,12]   old_normalized_TC2  1
    a[5,13]   abs_p_5_13  1
    a[5,13]   abs_m_5_13  1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,13]   old_normalized_TC  1
    a[5,13]   old_normalized_TC2  1
    a[5,14]   abs_p_5_14  1
    a[5,14]   abs_m_5_14  1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,14]   old_normalized_TC  1
    a[5,14]   old_normalized_TC2  1
    a[5,15]   abs_p_5_15  1
    a[5,15]   abs_m_5_15  1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,15]   old_normalized_TC  1
    a[5,15]   old_normalized_TC2  1
    a[5,16]   abs_p_5_16  1
    a[5,16]   abs_m_5_16  1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,16]   old_normalized_TC  1
    a[5,16]   old_normalized_TC2  1
    a[5,17]   abs_p_5_17  1
    a[5,17]   abs_m_5_17  1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,17]   old_normalized_TC  1
    a[5,17]   old_normalized_TC2  1
    a[5,18]   abs_p_5_18  1
    a[5,18]   abs_m_5_18  1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,18]   old_normalized_TC  1
    a[5,18]   old_normalized_TC2  1
    a[5,19]   abs_p_5_19  1
    a[5,19]   abs_m_5_19  1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,19]   old_normalized_TC  1
    a[5,19]   old_normalized_TC2  1
    a[5,20]   abs_p_5_20  1
    a[5,20]   abs_m_5_20  1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[5,20]   old_normalized_TC  1
    a[5,20]   old_normalized_TC2  1
    a[6,7]    abs_p_6_7  1
    a[6,7]    abs_m_6_7  1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,7]    old_normalized_TC  1
    a[6,7]    old_normalized_TC2  1
    a[6,8]    abs_p_6_8  1
    a[6,8]    abs_m_6_8  1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,8]    old_normalized_TC  1
    a[6,8]    old_normalized_TC2  1
    a[6,9]    abs_p_6_9  1
    a[6,9]    abs_m_6_9  1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,9]    old_normalized_TC  1
    a[6,9]    old_normalized_TC2  1
    a[6,10]   abs_p_6_10  1
    a[6,10]   abs_m_6_10  1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,10]   old_normalized_TC  1
    a[6,10]   old_normalized_TC2  1
    a[6,11]   abs_p_6_11  1
    a[6,11]   abs_m_6_11  1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,11]   old_normalized_TC  1
    a[6,11]   old_normalized_TC2  1
    a[6,12]   abs_p_6_12  1
    a[6,12]   abs_m_6_12  1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,12]   old_normalized_TC  1
    a[6,12]   old_normalized_TC2  1
    a[6,13]   abs_p_6_13  1
    a[6,13]   abs_m_6_13  1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,13]   old_normalized_TC  1
    a[6,13]   old_normalized_TC2  1
    a[6,14]   abs_p_6_14  1
    a[6,14]   abs_m_6_14  1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,14]   old_normalized_TC  1
    a[6,14]   old_normalized_TC2  1
    a[6,15]   abs_p_6_15  1
    a[6,15]   abs_m_6_15  1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,15]   old_normalized_TC  1
    a[6,15]   old_normalized_TC2  1
    a[6,16]   abs_p_6_16  1
    a[6,16]   abs_m_6_16  1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,16]   old_normalized_TC  1
    a[6,16]   old_normalized_TC2  1
    a[6,17]   abs_p_6_17  1
    a[6,17]   abs_m_6_17  1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,17]   old_normalized_TC  1
    a[6,17]   old_normalized_TC2  1
    a[6,18]   abs_p_6_18  1
    a[6,18]   abs_m_6_18  1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,18]   old_normalized_TC  1
    a[6,18]   old_normalized_TC2  1
    a[6,19]   abs_p_6_19  1
    a[6,19]   abs_m_6_19  1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,19]   old_normalized_TC  1
    a[6,19]   old_normalized_TC2  1
    a[6,20]   abs_p_6_20  1
    a[6,20]   abs_m_6_20  1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[6,20]   old_normalized_TC  1
    a[6,20]   old_normalized_TC2  1
    a[7,8]    abs_p_7_8  1
    a[7,8]    abs_m_7_8  1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,8]    old_normalized_TC  1
    a[7,8]    old_normalized_TC2  1
    a[7,9]    abs_p_7_9  1
    a[7,9]    abs_m_7_9  1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,9]    old_normalized_TC  1
    a[7,9]    old_normalized_TC2  1
    a[7,10]   abs_p_7_10  1
    a[7,10]   abs_m_7_10  1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,10]   old_normalized_TC  1
    a[7,10]   old_normalized_TC2  1
    a[7,11]   abs_p_7_11  1
    a[7,11]   abs_m_7_11  1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,11]   old_normalized_TC  1
    a[7,11]   old_normalized_TC2  1
    a[7,12]   abs_p_7_12  1
    a[7,12]   abs_m_7_12  1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,12]   old_normalized_TC  1
    a[7,12]   old_normalized_TC2  1
    a[7,13]   abs_p_7_13  1
    a[7,13]   abs_m_7_13  1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,13]   old_normalized_TC  1
    a[7,13]   old_normalized_TC2  1
    a[7,14]   abs_p_7_14  1
    a[7,14]   abs_m_7_14  1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,14]   old_normalized_TC  1
    a[7,14]   old_normalized_TC2  1
    a[7,15]   abs_p_7_15  1
    a[7,15]   abs_m_7_15  1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,15]   old_normalized_TC  1
    a[7,15]   old_normalized_TC2  1
    a[7,16]   abs_p_7_16  1
    a[7,16]   abs_m_7_16  1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,16]   old_normalized_TC  1
    a[7,16]   old_normalized_TC2  1
    a[7,17]   abs_p_7_17  1
    a[7,17]   abs_m_7_17  1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,17]   old_normalized_TC  1
    a[7,17]   old_normalized_TC2  1
    a[7,18]   abs_p_7_18  1
    a[7,18]   abs_m_7_18  1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,18]   old_normalized_TC  1
    a[7,18]   old_normalized_TC2  1
    a[7,19]   abs_p_7_19  1
    a[7,19]   abs_m_7_19  1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,19]   old_normalized_TC  1
    a[7,19]   old_normalized_TC2  1
    a[7,20]   abs_p_7_20  1
    a[7,20]   abs_m_7_20  1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[7,20]   old_normalized_TC  1
    a[7,20]   old_normalized_TC2  1
    a[8,9]    abs_p_8_9  1
    a[8,9]    abs_m_8_9  1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,9]    old_normalized_TC  1
    a[8,9]    old_normalized_TC2  1
    a[8,10]   abs_p_8_10  1
    a[8,10]   abs_m_8_10  1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,10]   old_normalized_TC  1
    a[8,10]   old_normalized_TC2  1
    a[8,11]   abs_p_8_11  1
    a[8,11]   abs_m_8_11  1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,11]   old_normalized_TC  1
    a[8,11]   old_normalized_TC2  1
    a[8,12]   abs_p_8_12  1
    a[8,12]   abs_m_8_12  1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,12]   old_normalized_TC  1
    a[8,12]   old_normalized_TC2  1
    a[8,13]   abs_p_8_13  1
    a[8,13]   abs_m_8_13  1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,13]   old_normalized_TC  1
    a[8,13]   old_normalized_TC2  1
    a[8,14]   abs_p_8_14  1
    a[8,14]   abs_m_8_14  1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,14]   old_normalized_TC  1
    a[8,14]   old_normalized_TC2  1
    a[8,15]   abs_p_8_15  1
    a[8,15]   abs_m_8_15  1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,15]   old_normalized_TC  1
    a[8,15]   old_normalized_TC2  1
    a[8,16]   abs_p_8_16  1
    a[8,16]   abs_m_8_16  1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,16]   old_normalized_TC  1
    a[8,16]   old_normalized_TC2  1
    a[8,17]   abs_p_8_17  1
    a[8,17]   abs_m_8_17  1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,17]   old_normalized_TC  1
    a[8,17]   old_normalized_TC2  1
    a[8,18]   abs_p_8_18  1
    a[8,18]   abs_m_8_18  1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,18]   old_normalized_TC  1
    a[8,18]   old_normalized_TC2  1
    a[8,19]   abs_p_8_19  1
    a[8,19]   abs_m_8_19  1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,19]   old_normalized_TC  1
    a[8,19]   old_normalized_TC2  1
    a[8,20]   abs_p_8_20  1
    a[8,20]   abs_m_8_20  1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[8,20]   old_normalized_TC  1
    a[8,20]   old_normalized_TC2  1
    a[9,10]   abs_p_9_10  1
    a[9,10]   abs_m_9_10  1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,10]   old_normalized_TC  1
    a[9,10]   old_normalized_TC2  1
    a[9,11]   abs_p_9_11  1
    a[9,11]   abs_m_9_11  1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,11]   old_normalized_TC  1
    a[9,11]   old_normalized_TC2  1
    a[9,12]   abs_p_9_12  1
    a[9,12]   abs_m_9_12  1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,12]   old_normalized_TC  1
    a[9,12]   old_normalized_TC2  1
    a[9,13]   abs_p_9_13  1
    a[9,13]   abs_m_9_13  1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,13]   old_normalized_TC  1
    a[9,13]   old_normalized_TC2  1
    a[9,14]   abs_p_9_14  1
    a[9,14]   abs_m_9_14  1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,14]   old_normalized_TC  1
    a[9,14]   old_normalized_TC2  1
    a[9,15]   abs_p_9_15  1
    a[9,15]   abs_m_9_15  1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,15]   old_normalized_TC  1
    a[9,15]   old_normalized_TC2  1
    a[9,16]   abs_p_9_16  1
    a[9,16]   abs_m_9_16  1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,16]   old_normalized_TC  1
    a[9,16]   old_normalized_TC2  1
    a[9,17]   abs_p_9_17  1
    a[9,17]   abs_m_9_17  1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,17]   old_normalized_TC  1
    a[9,17]   old_normalized_TC2  1
    a[9,18]   abs_p_9_18  1
    a[9,18]   abs_m_9_18  1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,18]   old_normalized_TC  1
    a[9,18]   old_normalized_TC2  1
    a[9,19]   abs_p_9_19  1
    a[9,19]   abs_m_9_19  1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,19]   old_normalized_TC  1
    a[9,19]   old_normalized_TC2  1
    a[9,20]   abs_p_9_20  1
    a[9,20]   abs_m_9_20  1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[9,20]   old_normalized_TC  1
    a[9,20]   old_normalized_TC2  1
    a[10,11]  abs_p_10_11  1
    a[10,11]  abs_m_10_11  1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,11]  old_normalized_TC  1
    a[10,11]  old_normalized_TC2  1
    a[10,12]  abs_p_10_12  1
    a[10,12]  abs_m_10_12  1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,12]  old_normalized_TC  1
    a[10,12]  old_normalized_TC2  1
    a[10,13]  abs_p_10_13  1
    a[10,13]  abs_m_10_13  1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,13]  old_normalized_TC  1
    a[10,13]  old_normalized_TC2  1
    a[10,14]  abs_p_10_14  1
    a[10,14]  abs_m_10_14  1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,14]  old_normalized_TC  1
    a[10,14]  old_normalized_TC2  1
    a[10,15]  abs_p_10_15  1
    a[10,15]  abs_m_10_15  1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,15]  old_normalized_TC  1
    a[10,15]  old_normalized_TC2  1
    a[10,16]  abs_p_10_16  1
    a[10,16]  abs_m_10_16  1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,16]  old_normalized_TC  1
    a[10,16]  old_normalized_TC2  1
    a[10,17]  abs_p_10_17  1
    a[10,17]  abs_m_10_17  1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,17]  old_normalized_TC  1
    a[10,17]  old_normalized_TC2  1
    a[10,18]  abs_p_10_18  1
    a[10,18]  abs_m_10_18  1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,18]  old_normalized_TC  1
    a[10,18]  old_normalized_TC2  1
    a[10,19]  abs_p_10_19  1
    a[10,19]  abs_m_10_19  1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,19]  old_normalized_TC  1
    a[10,19]  old_normalized_TC2  1
    a[10,20]  abs_p_10_20  1
    a[10,20]  abs_m_10_20  1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[10,20]  old_normalized_TC  1
    a[10,20]  old_normalized_TC2  1
    a[11,12]  abs_p_11_12  1
    a[11,12]  abs_m_11_12  1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,12]  old_normalized_TC  1
    a[11,12]  old_normalized_TC2  1
    a[11,13]  abs_p_11_13  1
    a[11,13]  abs_m_11_13  1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,13]  old_normalized_TC  1
    a[11,13]  old_normalized_TC2  1
    a[11,14]  abs_p_11_14  1
    a[11,14]  abs_m_11_14  1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,14]  old_normalized_TC  1
    a[11,14]  old_normalized_TC2  1
    a[11,15]  abs_p_11_15  1
    a[11,15]  abs_m_11_15  1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,15]  old_normalized_TC  1
    a[11,15]  old_normalized_TC2  1
    a[11,16]  abs_p_11_16  1
    a[11,16]  abs_m_11_16  1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,16]  old_normalized_TC  1
    a[11,16]  old_normalized_TC2  1
    a[11,17]  abs_p_11_17  1
    a[11,17]  abs_m_11_17  1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,17]  old_normalized_TC  1
    a[11,17]  old_normalized_TC2  1
    a[11,18]  abs_p_11_18  1
    a[11,18]  abs_m_11_18  1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,18]  old_normalized_TC  1
    a[11,18]  old_normalized_TC2  1
    a[11,19]  abs_p_11_19  1
    a[11,19]  abs_m_11_19  1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,19]  old_normalized_TC  1
    a[11,19]  old_normalized_TC2  1
    a[11,20]  abs_p_11_20  1
    a[11,20]  abs_m_11_20  1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[11,20]  old_normalized_TC  1
    a[11,20]  old_normalized_TC2  1
    a[12,13]  abs_p_12_13  1
    a[12,13]  abs_m_12_13  1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,13]  old_normalized_TC  1
    a[12,13]  old_normalized_TC2  1
    a[12,14]  abs_p_12_14  1
    a[12,14]  abs_m_12_14  1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,14]  old_normalized_TC  1
    a[12,14]  old_normalized_TC2  1
    a[12,15]  abs_p_12_15  1
    a[12,15]  abs_m_12_15  1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,15]  old_normalized_TC  1
    a[12,15]  old_normalized_TC2  1
    a[12,16]  abs_p_12_16  1
    a[12,16]  abs_m_12_16  1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,16]  old_normalized_TC  1
    a[12,16]  old_normalized_TC2  1
    a[12,17]  abs_p_12_17  1
    a[12,17]  abs_m_12_17  1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,17]  old_normalized_TC  1
    a[12,17]  old_normalized_TC2  1
    a[12,18]  abs_p_12_18  1
    a[12,18]  abs_m_12_18  1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,18]  old_normalized_TC  1
    a[12,18]  old_normalized_TC2  1
    a[12,19]  abs_p_12_19  1
    a[12,19]  abs_m_12_19  1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,19]  old_normalized_TC  1
    a[12,19]  old_normalized_TC2  1
    a[12,20]  abs_p_12_20  1
    a[12,20]  abs_m_12_20  1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[12,20]  old_normalized_TC  1
    a[12,20]  old_normalized_TC2  1
    a[13,14]  abs_p_13_14  1
    a[13,14]  abs_m_13_14  1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,14]  old_normalized_TC  1
    a[13,14]  old_normalized_TC2  1
    a[13,15]  abs_p_13_15  1
    a[13,15]  abs_m_13_15  1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,15]  old_normalized_TC  1
    a[13,15]  old_normalized_TC2  1
    a[13,16]  abs_p_13_16  1
    a[13,16]  abs_m_13_16  1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,16]  old_normalized_TC  1
    a[13,16]  old_normalized_TC2  1
    a[13,17]  abs_p_13_17  1
    a[13,17]  abs_m_13_17  1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,17]  old_normalized_TC  1
    a[13,17]  old_normalized_TC2  1
    a[13,18]  abs_p_13_18  1
    a[13,18]  abs_m_13_18  1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,18]  old_normalized_TC  1
    a[13,18]  old_normalized_TC2  1
    a[13,19]  abs_p_13_19  1
    a[13,19]  abs_m_13_19  1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,19]  old_normalized_TC  1
    a[13,19]  old_normalized_TC2  1
    a[13,20]  abs_p_13_20  1
    a[13,20]  abs_m_13_20  1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[13,20]  old_normalized_TC  1
    a[13,20]  old_normalized_TC2  1
    a[14,15]  abs_p_14_15  1
    a[14,15]  abs_m_14_15  1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,15]  old_normalized_TC  1
    a[14,15]  old_normalized_TC2  1
    a[14,16]  abs_p_14_16  1
    a[14,16]  abs_m_14_16  1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,16]  old_normalized_TC  1
    a[14,16]  old_normalized_TC2  1
    a[14,17]  abs_p_14_17  1
    a[14,17]  abs_m_14_17  1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,17]  old_normalized_TC  1
    a[14,17]  old_normalized_TC2  1
    a[14,18]  abs_p_14_18  1
    a[14,18]  abs_m_14_18  1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,18]  old_normalized_TC  1
    a[14,18]  old_normalized_TC2  1
    a[14,19]  abs_p_14_19  1
    a[14,19]  abs_m_14_19  1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,19]  old_normalized_TC  1
    a[14,19]  old_normalized_TC2  1
    a[14,20]  abs_p_14_20  1
    a[14,20]  abs_m_14_20  1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[14,20]  old_normalized_TC  1
    a[14,20]  old_normalized_TC2  1
    a[15,16]  abs_p_15_16  1
    a[15,16]  abs_m_15_16  1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,16]  old_normalized_TC  1
    a[15,16]  old_normalized_TC2  1
    a[15,17]  abs_p_15_17  1
    a[15,17]  abs_m_15_17  1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,17]  old_normalized_TC  1
    a[15,17]  old_normalized_TC2  1
    a[15,18]  abs_p_15_18  1
    a[15,18]  abs_m_15_18  1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,18]  old_normalized_TC  1
    a[15,18]  old_normalized_TC2  1
    a[15,19]  abs_p_15_19  1
    a[15,19]  abs_m_15_19  1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,19]  old_normalized_TC  1
    a[15,19]  old_normalized_TC2  1
    a[15,20]  abs_p_15_20  1
    a[15,20]  abs_m_15_20  1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[15,20]  old_normalized_TC  1
    a[15,20]  old_normalized_TC2  1
    a[16,17]  abs_p_16_17  1
    a[16,17]  abs_m_16_17  1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,17]  old_normalized_TC  1
    a[16,17]  old_normalized_TC2  1
    a[16,18]  abs_p_16_18  1
    a[16,18]  abs_m_16_18  1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,18]  old_normalized_TC  1
    a[16,18]  old_normalized_TC2  1
    a[16,19]  abs_p_16_19  1
    a[16,19]  abs_m_16_19  1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,19]  old_normalized_TC  1
    a[16,19]  old_normalized_TC2  1
    a[16,20]  abs_p_16_20  1
    a[16,20]  abs_m_16_20  1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[16,20]  old_normalized_TC  1
    a[16,20]  old_normalized_TC2  1
    a[17,18]  abs_p_17_18  1
    a[17,18]  abs_m_17_18  1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,18]  old_normalized_TC  1
    a[17,18]  old_normalized_TC2  1
    a[17,19]  abs_p_17_19  1
    a[17,19]  abs_m_17_19  1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,19]  old_normalized_TC  1
    a[17,19]  old_normalized_TC2  1
    a[17,20]  abs_p_17_20  1
    a[17,20]  abs_m_17_20  1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[17,20]  old_normalized_TC  1
    a[17,20]  old_normalized_TC2  1
    a[18,19]  abs_p_18_19  1
    a[18,19]  abs_m_18_19  1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,19]  old_normalized_TC  1
    a[18,19]  old_normalized_TC2  1
    a[18,20]  abs_p_18_20  1
    a[18,20]  abs_m_18_20  1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[18,20]  old_normalized_TC  1
    a[18,20]  old_normalized_TC2  1
    a[19,20]  abs_p_19_20  1
    a[19,20]  abs_m_19_20  1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    a[19,20]  old_normalized_TC  1
    a[19,20]  old_normalized_TC2  1
    q         OBJ       1
    q         true_G_epigraph  -20
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      hard_lower  5
    RHS1      hard_upper  65
    RHS1      normalization  1
    RHS1      physical_G_upper  1.3789908428597085e+01
    RHS1      old_TS1   -2.5034770514603649e-01
    RHS1      old_TS2   -5.1671924290220836e+01
    RHS1      old_TS3   -3.9747634069400584e+00
    RHS1      old_TS4   -3.2545201668984691e+00
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[1,5]  
 BV BND1      x[1,6]  
 BV BND1      x[1,7]  
 BV BND1      x[1,8]  
 BV BND1      x[1,9]  
 BV BND1      x[1,10] 
 BV BND1      x[1,11] 
 BV BND1      x[1,12] 
 BV BND1      x[1,13] 
 BV BND1      x[1,14] 
 BV BND1      x[1,15] 
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 BV BND1      x[3,5]  
 BV BND1      x[3,6]  
 BV BND1      x[3,7]  
 BV BND1      x[3,8]  
 BV BND1      x[3,9]  
 BV BND1      x[3,10] 
 BV BND1      x[3,11] 
 BV BND1      x[3,12] 
 BV BND1      x[3,13] 
 BV BND1      x[3,14] 
 BV BND1      x[3,15] 
 BV BND1      x[3,16] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[6,0]  
 BV BND1      x[6,1]  
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[11,13]
 BV BND1      x[11,14]
 BV BND1      x[11,15]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[17,2] 
 BV BND1      x[17,3] 
 BV BND1      x[17,4] 
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[19,0] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[20,11]
 BV BND1      x[20,12]
 BV BND1      x[20,13]
 BV BND1      x[20,14]
 BV BND1      x[20,15]
 UP BND1      w[1,0]    7.9495268138801267e-01
 UP BND1      w[1,1]    7.9495268138801267e-01
 UP BND1      w[1,2]    7.9495268138801267e-01
 UP BND1      w[1,3]    7.9495268138801267e-01
 UP BND1      w[1,4]    7.9495268138801267e-01
 UP BND1      w[1,5]    7.9495268138801267e-01
 UP BND1      w[1,6]    7.9495268138801267e-01
 UP BND1      w[1,7]    7.9495268138801267e-01
 UP BND1      w[1,8]    7.9495268138801267e-01
 UP BND1      w[1,9]    7.9495268138801267e-01
 UP BND1      w[1,10]   7.9495268138801267e-01
 UP BND1      w[1,11]   7.9495268138801267e-01
 UP BND1      w[1,12]   7.9495268138801267e-01
 UP BND1      w[1,13]   7.9495268138801267e-01
 UP BND1      w[1,14]   7.9495268138801267e-01
 UP BND1      w[1,15]   7.9495268138801267e-01
 UP BND1      w[2,0]    7.9495268138801267e-01
 UP BND1      w[2,1]    7.9495268138801267e-01
 UP BND1      w[3,0]    7.9495268138801267e-01
 UP BND1      w[3,1]    7.9495268138801267e-01
 UP BND1      w[3,2]    7.9495268138801267e-01
 UP BND1      w[3,3]    7.9495268138801267e-01
 UP BND1      w[3,4]    7.9495268138801267e-01
 UP BND1      w[3,5]    7.9495268138801267e-01
 UP BND1      w[3,6]    7.9495268138801267e-01
 UP BND1      w[3,7]    7.9495268138801267e-01
 UP BND1      w[3,8]    7.9495268138801267e-01
 UP BND1      w[3,9]    7.9495268138801267e-01
 UP BND1      w[3,10]   7.9495268138801267e-01
 UP BND1      w[3,11]   7.9495268138801267e-01
 UP BND1      w[3,12]   7.9495268138801267e-01
 UP BND1      w[3,13]   7.9495268138801267e-01
 UP BND1      w[3,14]   7.9495268138801267e-01
 UP BND1      w[3,15]   7.9495268138801267e-01
 UP BND1      w[3,16]   7.9495268138801267e-01
 UP BND1      w[4,0]    7.9495268138801267e-01
 UP BND1      w[4,1]    7.9495268138801267e-01
 UP BND1      w[4,2]    7.9495268138801267e-01
 UP BND1      w[4,3]    7.9495268138801267e-01
 UP BND1      w[4,4]    7.9495268138801267e-01
 UP BND1      w[4,5]    7.9495268138801267e-01
 UP BND1      w[4,6]    7.9495268138801267e-01
 UP BND1      w[4,7]    7.9495268138801267e-01
 UP BND1      w[4,8]    7.9495268138801267e-01
 UP BND1      w[4,9]    7.9495268138801267e-01
 UP BND1      w[4,10]   7.9495268138801267e-01
 UP BND1      w[4,11]   7.9495268138801267e-01
 UP BND1      w[4,12]   7.9495268138801267e-01
 UP BND1      w[4,13]   7.9495268138801267e-01
 UP BND1      w[4,14]   7.9495268138801267e-01
 UP BND1      w[4,15]   7.9495268138801267e-01
 UP BND1      w[5,0]    7.9495268138801267e-01
 UP BND1      w[5,1]    7.9495268138801267e-01
 UP BND1      w[5,2]    7.9495268138801267e-01
 UP BND1      w[6,0]    7.9495268138801267e-01
 UP BND1      w[6,1]    7.9495268138801267e-01
 UP BND1      w[7,0]    7.9495268138801267e-01
 UP BND1      w[7,1]    7.9495268138801267e-01
 UP BND1      w[7,2]    7.9495268138801267e-01
 UP BND1      w[7,3]    7.9495268138801267e-01
 UP BND1      w[7,4]    7.9495268138801267e-01
 UP BND1      w[7,5]    7.9495268138801267e-01
 UP BND1      w[7,6]    7.9495268138801267e-01
 UP BND1      w[7,7]    7.9495268138801267e-01
 UP BND1      w[7,8]    7.9495268138801267e-01
 UP BND1      w[7,9]    7.9495268138801267e-01
 UP BND1      w[7,10]   7.9495268138801267e-01
 UP BND1      w[8,0]    7.9495268138801267e-01
 UP BND1      w[8,1]    7.9495268138801267e-01
 UP BND1      w[8,2]    7.9495268138801267e-01
 UP BND1      w[9,0]    7.9495268138801267e-01
 UP BND1      w[9,1]    7.9495268138801267e-01
 UP BND1      w[10,0]   7.9495268138801267e-01
 UP BND1      w[10,1]   7.9495268138801267e-01
 UP BND1      w[11,0]   7.9495268138801267e-01
 UP BND1      w[11,1]   7.9495268138801267e-01
 UP BND1      w[11,2]   7.9495268138801267e-01
 UP BND1      w[11,3]   7.9495268138801267e-01
 UP BND1      w[11,4]   7.9495268138801267e-01
 UP BND1      w[11,5]   7.9495268138801267e-01
 UP BND1      w[11,6]   7.9495268138801267e-01
 UP BND1      w[11,7]   7.9495268138801267e-01
 UP BND1      w[11,8]   7.9495268138801267e-01
 UP BND1      w[11,9]   7.9495268138801267e-01
 UP BND1      w[11,10]  7.9495268138801267e-01
 UP BND1      w[11,11]  7.9495268138801267e-01
 UP BND1      w[11,12]  7.9495268138801267e-01
 UP BND1      w[11,13]  7.9495268138801267e-01
 UP BND1      w[11,14]  7.9495268138801267e-01
 UP BND1      w[11,15]  7.9495268138801267e-01
 UP BND1      w[12,0]   7.9495268138801267e-01
 UP BND1      w[12,1]   7.9495268138801267e-01
 UP BND1      w[12,2]   7.9495268138801267e-01
 UP BND1      w[12,3]   7.9495268138801267e-01
 UP BND1      w[12,4]   7.9495268138801267e-01
 UP BND1      w[12,5]   7.9495268138801267e-01
 UP BND1      w[12,6]   7.9495268138801267e-01
 UP BND1      w[12,7]   7.9495268138801267e-01
 UP BND1      w[12,8]   7.9495268138801267e-01
 UP BND1      w[12,9]   7.9495268138801267e-01
 UP BND1      w[12,10]  7.9495268138801267e-01
 UP BND1      w[12,11]  7.9495268138801267e-01
 UP BND1      w[12,12]  7.9495268138801267e-01
 UP BND1      w[12,13]  7.9495268138801267e-01
 UP BND1      w[12,14]  7.9495268138801267e-01
 UP BND1      w[12,15]  7.9495268138801267e-01
 UP BND1      w[13,0]   7.9495268138801267e-01
 UP BND1      w[13,1]   7.9495268138801267e-01
 UP BND1      w[14,2]   7.9495268138801267e-01
 UP BND1      w[14,3]   7.9495268138801267e-01
 UP BND1      w[14,4]   7.9495268138801267e-01
 UP BND1      w[14,5]   7.9495268138801267e-01
 UP BND1      w[14,6]   7.9495268138801267e-01
 UP BND1      w[14,7]   7.9495268138801267e-01
 UP BND1      w[14,8]   7.9495268138801267e-01
 UP BND1      w[14,9]   7.9495268138801267e-01
 UP BND1      w[14,10]  7.9495268138801267e-01
 UP BND1      w[14,11]  7.9495268138801267e-01
 UP BND1      w[14,12]  7.9495268138801267e-01
 UP BND1      w[14,13]  7.9495268138801267e-01
 UP BND1      w[14,14]  7.9495268138801267e-01
 UP BND1      w[14,15]  7.9495268138801267e-01
 UP BND1      w[15,0]   7.9495268138801267e-01
 UP BND1      w[15,1]   7.9495268138801267e-01
 UP BND1      w[16,0]   7.9495268138801267e-01
 UP BND1      w[16,1]   7.9495268138801267e-01
 UP BND1      w[16,2]   7.9495268138801267e-01
 UP BND1      w[17,2]   7.9495268138801267e-01
 UP BND1      w[17,3]   7.9495268138801267e-01
 UP BND1      w[17,4]   7.9495268138801267e-01
 UP BND1      w[18,0]   7.9495268138801267e-01
 UP BND1      w[18,1]   7.9495268138801267e-01
 UP BND1      w[19,0]   7.9495268138801267e-01
 UP BND1      w[20,6]   7.9495268138801267e-01
 UP BND1      w[20,7]   7.9495268138801267e-01
 UP BND1      w[20,8]   7.9495268138801267e-01
 UP BND1      w[20,9]   7.9495268138801267e-01
 UP BND1      w[20,10]  7.9495268138801267e-01
 UP BND1      w[20,11]  7.9495268138801267e-01
 UP BND1      w[20,12]  7.9495268138801267e-01
 UP BND1      w[20,13]  7.9495268138801267e-01
 UP BND1      w[20,14]  7.9495268138801267e-01
 UP BND1      w[20,15]  7.9495268138801267e-01
 LO BND1      t         5.0069541029207222e-02
 UP BND1      t         7.9495268138801267e-01
 UP BND1      q         6.8949542142985421e-01
ENDATA
