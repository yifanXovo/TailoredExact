* Signature: 0x85d6f06ec54c9ae7
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 E  onehot_5_34
 E  normalized_mass_5_35
 E  normalized_ratio_5_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 E  onehot_2_69
 E  normalized_mass_2_70
 E  normalized_ratio_2_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 E  onehot_31_98
 E  normalized_mass_31_99
 E  normalized_ratio_31_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 E  onehot_1_141
 E  normalized_mass_1_142
 E  normalized_ratio_1_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 E  onehot_6_166
 E  normalized_mass_6_167
 E  normalized_ratio_6_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 E  onehot_8_213
 E  normalized_mass_8_214
 E  normalized_ratio_8_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 G  product_lb_228
 L  product_ub_229
 G  product_lb_230
 L  product_ub_231
 G  product_lb_232
 L  product_ub_233
 G  product_lb_234
 L  product_ub_235
 G  product_lb_236
 L  product_ub_237
 G  product_lb_238
 L  product_ub_239
 G  product_lb_240
 L  product_ub_241
 E  onehot_32_242
 E  normalized_mass_32_243
 E  normalized_ratio_32_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 G  product_lb_265
 L  product_ub_266
 G  product_lb_267
 L  product_ub_268
 G  product_lb_269
 L  product_ub_270
 G  product_lb_271
 L  product_ub_272
 G  product_lb_273
 L  product_ub_274
 G  product_lb_275
 L  product_ub_276
 E  onehot_14_277
 E  normalized_mass_14_278
 E  normalized_ratio_14_279
 G  stock_lb_280
 L  stock_ub_281
 L  parent_nonstrict_scope_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 G  block_pair_pos_327
 G  block_pair_neg_328
 G  block_pair_pos_329
 G  block_pair_neg_330
 G  block_pair_pos_331
 G  block_pair_neg_332
 G  block_pair_pos_333
 G  block_pair_neg_334
 G  block_pair_pos_335
 G  block_pair_neg_336
 G  block_pair_pos_337
 G  block_pair_neg_338
 E  normalization_339
 G  full_original_Gini_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 E  unique_nonzero_owner_443
 E  unique_nonzero_owner_444
 E  unique_nonzero_owner_445
 E  unique_nonzero_owner_446
 E  unique_nonzero_owner_447
 E  unique_nonzero_owner_448
 E  unique_nonzero_owner_449
 E  unique_nonzero_owner_450
 E  unique_nonzero_owner_451
 E  unique_nonzero_owner_452
 E  unique_nonzero_owner_453
 E  unique_nonzero_owner_454
 E  unique_nonzero_owner_455
 E  unique_nonzero_owner_456
 E  unique_nonzero_owner_457
 E  unique_nonzero_owner_458
 E  unique_nonzero_owner_459
 E  unique_nonzero_owner_460
 L  arc_capacity_461
 L  arc_capacity_462
 L  arc_capacity_463
 L  arc_capacity_464
 L  arc_capacity_465
 L  arc_capacity_466
 L  arc_capacity_467
 L  arc_capacity_468
 L  arc_capacity_469
 L  arc_capacity_470
 L  arc_capacity_471
 L  arc_capacity_472
 L  arc_capacity_473
 L  arc_capacity_474
 L  arc_capacity_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 E  depot_departure_or_bypass_800
 E  depot_return_or_bypass_801
 E  out_degree_802
 E  in_degree_803
 G  order_active_lb_804
 L  order_active_ub_805
 E  segment_load_conservation_806
 G  segment_prefix_lb_807
 L  segment_prefix_ub_808
 E  out_degree_809
 E  in_degree_810
 G  order_active_lb_811
 L  order_active_ub_812
 E  segment_load_conservation_813
 G  segment_prefix_lb_814
 L  segment_prefix_ub_815
 E  out_degree_816
 E  in_degree_817
 G  order_active_lb_818
 L  order_active_ub_819
 E  segment_load_conservation_820
 G  segment_prefix_lb_821
 L  segment_prefix_ub_822
 E  out_degree_823
 E  in_degree_824
 G  order_active_lb_825
 L  order_active_ub_826
 E  segment_load_conservation_827
 G  segment_prefix_lb_828
 L  segment_prefix_ub_829
 E  out_degree_830
 E  in_degree_831
 G  order_active_lb_832
 L  order_active_ub_833
 E  segment_load_conservation_834
 G  segment_prefix_lb_835
 L  segment_prefix_ub_836
 E  out_degree_837
 E  in_degree_838
 G  order_active_lb_839
 L  order_active_ub_840
 E  service_visit_def_841
 E  free_load_conservation_842
 E  out_degree_843
 E  in_degree_844
 G  order_active_lb_845
 L  order_active_ub_846
 E  service_visit_def_847
 E  free_load_conservation_848
 E  out_degree_849
 E  in_degree_850
 G  order_active_lb_851
 L  order_active_ub_852
 E  service_visit_def_853
 E  free_load_conservation_854
 E  out_degree_855
 E  in_degree_856
 G  order_active_lb_857
 L  order_active_ub_858
 E  service_visit_def_859
 E  free_load_conservation_860
 E  out_degree_861
 E  in_degree_862
 G  order_active_lb_863
 L  order_active_ub_864
 E  service_visit_def_865
 E  free_load_conservation_866
 E  out_degree_867
 E  in_degree_868
 G  order_active_lb_869
 L  order_active_ub_870
 E  service_visit_def_871
 E  free_load_conservation_872
 E  out_degree_873
 E  in_degree_874
 G  order_active_lb_875
 L  order_active_ub_876
 E  service_visit_def_877
 E  free_load_conservation_878
 E  out_degree_879
 E  in_degree_880
 G  order_active_lb_881
 L  order_active_ub_882
 E  service_visit_def_883
 E  free_load_conservation_884
 G  fixed_segment_relative_order_885
 G  fixed_segment_relative_order_886
 G  fixed_segment_relative_order_887
 G  fixed_segment_relative_order_888
 L  original_T_including_depot_unload_889
 L  arc_capacity_890
 L  arc_capacity_891
 L  arc_capacity_892
 L  arc_capacity_893
 L  arc_capacity_894
 L  arc_capacity_895
 L  arc_capacity_896
 L  arc_capacity_897
 L  arc_capacity_898
 L  arc_capacity_899
 L  arc_capacity_900
 L  arc_capacity_901
 L  arc_capacity_902
 L  arc_capacity_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 E  depot_departure_or_bypass_1179
 E  depot_return_or_bypass_1180
 E  out_degree_1181
 E  in_degree_1182
 G  order_active_lb_1183
 L  order_active_ub_1184
 E  segment_load_conservation_1185
 G  segment_prefix_lb_1186
 L  segment_prefix_ub_1187
 E  out_degree_1188
 E  in_degree_1189
 G  order_active_lb_1190
 L  order_active_ub_1191
 E  segment_load_conservation_1192
 G  segment_prefix_lb_1193
 L  segment_prefix_ub_1194
 E  out_degree_1195
 E  in_degree_1196
 G  order_active_lb_1197
 L  order_active_ub_1198
 E  segment_load_conservation_1199
 G  segment_prefix_lb_1200
 L  segment_prefix_ub_1201
 E  out_degree_1202
 E  in_degree_1203
 G  order_active_lb_1204
 L  order_active_ub_1205
 E  segment_load_conservation_1206
 G  segment_prefix_lb_1207
 L  segment_prefix_ub_1208
 E  out_degree_1209
 E  in_degree_1210
 G  order_active_lb_1211
 L  order_active_ub_1212
 E  service_visit_def_1213
 E  free_load_conservation_1214
 E  out_degree_1215
 E  in_degree_1216
 G  order_active_lb_1217
 L  order_active_ub_1218
 E  service_visit_def_1219
 E  free_load_conservation_1220
 E  out_degree_1221
 E  in_degree_1222
 G  order_active_lb_1223
 L  order_active_ub_1224
 E  service_visit_def_1225
 E  free_load_conservation_1226
 E  out_degree_1227
 E  in_degree_1228
 G  order_active_lb_1229
 L  order_active_ub_1230
 E  service_visit_def_1231
 E  free_load_conservation_1232
 E  out_degree_1233
 E  in_degree_1234
 G  order_active_lb_1235
 L  order_active_ub_1236
 E  service_visit_def_1237
 E  free_load_conservation_1238
 E  out_degree_1239
 E  in_degree_1240
 G  order_active_lb_1241
 L  order_active_ub_1242
 E  service_visit_def_1243
 E  free_load_conservation_1244
 E  out_degree_1245
 E  in_degree_1246
 G  order_active_lb_1247
 L  order_active_ub_1248
 E  service_visit_def_1249
 E  free_load_conservation_1250
 E  out_degree_1251
 E  in_degree_1252
 G  order_active_lb_1253
 L  order_active_ub_1254
 E  service_visit_def_1255
 E  free_load_conservation_1256
 G  fixed_segment_relative_order_1257
 G  fixed_segment_relative_order_1258
 G  fixed_segment_relative_order_1259
 L  original_T_including_depot_unload_1260
 L  arc_capacity_1261
 L  arc_capacity_1262
 L  arc_capacity_1263
 L  arc_capacity_1264
 L  arc_capacity_1265
 L  arc_capacity_1266
 L  arc_capacity_1267
 L  arc_capacity_1268
 L  arc_capacity_1269
 L  arc_capacity_1270
 L  arc_capacity_1271
 L  arc_capacity_1272
 L  arc_capacity_1273
 L  arc_capacity_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 G  connected_order_arc_1518
 L  arc_capacity_1519
 G  connected_order_arc_1520
 L  arc_capacity_1521
 G  connected_order_arc_1522
 L  arc_capacity_1523
 G  connected_order_arc_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 L  arc_capacity_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 G  connected_order_arc_1531
 L  arc_capacity_1532
 G  connected_order_arc_1533
 L  arc_capacity_1534
 G  connected_order_arc_1535
 L  arc_capacity_1536
 G  connected_order_arc_1537
 L  arc_capacity_1538
 G  connected_order_arc_1539
 L  arc_capacity_1540
 G  connected_order_arc_1541
 L  arc_capacity_1542
 G  connected_order_arc_1543
 L  arc_capacity_1544
 G  connected_order_arc_1545
 L  arc_capacity_1546
 G  connected_order_arc_1547
 L  arc_capacity_1548
 G  connected_order_arc_1549
 E  depot_departure_or_bypass_1550
 E  depot_return_or_bypass_1551
 E  out_degree_1552
 E  in_degree_1553
 G  order_active_lb_1554
 L  order_active_ub_1555
 E  segment_load_conservation_1556
 G  segment_prefix_lb_1557
 L  segment_prefix_ub_1558
 E  out_degree_1559
 E  in_degree_1560
 G  order_active_lb_1561
 L  order_active_ub_1562
 E  segment_load_conservation_1563
 G  segment_prefix_lb_1564
 L  segment_prefix_ub_1565
 E  out_degree_1566
 E  in_degree_1567
 G  order_active_lb_1568
 L  order_active_ub_1569
 E  segment_load_conservation_1570
 G  segment_prefix_lb_1571
 L  segment_prefix_ub_1572
 E  out_degree_1573
 E  in_degree_1574
 G  order_active_lb_1575
 L  order_active_ub_1576
 E  segment_load_conservation_1577
 G  segment_prefix_lb_1578
 L  segment_prefix_ub_1579
 E  out_degree_1580
 E  in_degree_1581
 G  order_active_lb_1582
 L  order_active_ub_1583
 E  service_visit_def_1584
 E  free_load_conservation_1585
 E  out_degree_1586
 E  in_degree_1587
 G  order_active_lb_1588
 L  order_active_ub_1589
 E  service_visit_def_1590
 E  free_load_conservation_1591
 E  out_degree_1592
 E  in_degree_1593
 G  order_active_lb_1594
 L  order_active_ub_1595
 E  service_visit_def_1596
 E  free_load_conservation_1597
 E  out_degree_1598
 E  in_degree_1599
 G  order_active_lb_1600
 L  order_active_ub_1601
 E  service_visit_def_1602
 E  free_load_conservation_1603
 E  out_degree_1604
 E  in_degree_1605
 G  order_active_lb_1606
 L  order_active_ub_1607
 E  service_visit_def_1608
 E  free_load_conservation_1609
 E  out_degree_1610
 E  in_degree_1611
 G  order_active_lb_1612
 L  order_active_ub_1613
 E  service_visit_def_1614
 E  free_load_conservation_1615
 E  out_degree_1616
 E  in_degree_1617
 G  order_active_lb_1618
 L  order_active_ub_1619
 E  service_visit_def_1620
 E  free_load_conservation_1621
 E  out_degree_1622
 E  in_degree_1623
 G  order_active_lb_1624
 L  order_active_ub_1625
 E  service_visit_def_1626
 E  free_load_conservation_1627
 G  fixed_segment_relative_order_1628
 G  fixed_segment_relative_order_1629
 G  fixed_segment_relative_order_1630
 L  original_T_including_depot_unload_1631
COLUMNS
    t         normalized_mass_5_35  -1
    t         normalized_mass_2_70  -1
    t         normalized_mass_31_99  -1
    t         normalized_mass_1_142  -1
    t         normalized_mass_6_167  -1
    t         normalized_mass_8_214  -1
    t         normalized_mass_32_243  -1
    t         normalized_mass_14_278  -1
    t         normalization_339  2.4153571428571428e+01
    t         full_original_Gini_340  -8.9707142857142841e+01
    q         OBJ       1
    q         parent_nonstrict_scope_282  1
    q         full_original_Gini_340  35
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       0.048
    x_5_0     product_lb_0  -2.4822695035436170e-02
    x_5_0     product_ub_1  -4.1401744787857471e-02
    x_5_0     onehot_5_34  1
    x_5_0     parent_nonstrict_scope_282  0.096
    x_5_0     unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_0  1
    w_5_0     product_ub_1  1
    w_5_0     normalized_mass_5_35  1
    w_5_0     full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       3.6000000000000004e-02
    x_5_1     product_lb_2  -2.4822695035436170e-02
    x_5_1     product_ub_3  -4.1401744787857471e-02
    x_5_1     onehot_5_34  1
    x_5_1     stock_lb_280  1
    x_5_1     stock_ub_281  1
    x_5_1     parent_nonstrict_scope_282  0.084
    x_5_1     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_2  1
    w_5_1     product_ub_3  1
    w_5_1     normalized_mass_5_35  1
    w_5_1     normalized_ratio_5_36  -0.125
    w_5_1     full_original_Gini_340  -2.0778571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       2.4000000000000007e-02
    x_5_2     product_lb_4  -2.4822695035436170e-02
    x_5_2     product_ub_5  -4.1401744787857471e-02
    x_5_2     onehot_5_34  1
    x_5_2     stock_lb_280  2
    x_5_2     stock_ub_281  2
    x_5_2     parent_nonstrict_scope_282  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_4  1
    w_5_2     product_ub_5  1
    w_5_2     normalized_mass_5_35  1
    w_5_2     normalized_ratio_5_36  -0.25
    w_5_2     full_original_Gini_340  -1.7403571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     OBJ       1.1999999999999997e-02
    x_5_3     product_lb_6  -2.4822695035436170e-02
    x_5_3     product_ub_7  -4.1401744787857471e-02
    x_5_3     onehot_5_34  1
    x_5_3     stock_lb_280  3
    x_5_3     stock_ub_281  3
    x_5_3     parent_nonstrict_scope_282  0.06
    x_5_3     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_6  1
    w_5_3     product_ub_7  1
    w_5_3     normalized_mass_5_35  1
    w_5_3     normalized_ratio_5_36  -0.375
    w_5_3     full_original_Gini_340  -1.4528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     product_lb_8  -2.4822695035436170e-02
    x_5_4     product_ub_9  -4.1401744787857471e-02
    x_5_4     onehot_5_34  1
    x_5_4     stock_lb_280  4
    x_5_4     stock_ub_281  4
    x_5_4     parent_nonstrict_scope_282  0.048
    x_5_4     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_8  1
    w_5_4     product_ub_9  1
    w_5_4     normalized_mass_5_35  1
    w_5_4     normalized_ratio_5_36  -0.5
    w_5_4     full_original_Gini_340  -1.1853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.1999999999999997e-02
    x_5_5     product_lb_10  -2.4822695035436170e-02
    x_5_5     product_ub_11  -4.1401744787857471e-02
    x_5_5     onehot_5_34  1
    x_5_5     stock_lb_280  5
    x_5_5     stock_ub_281  5
    x_5_5     parent_nonstrict_scope_282  3.6000000000000004e-02
    x_5_5     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_10  1
    w_5_5     product_ub_11  1
    w_5_5     normalized_mass_5_35  1
    w_5_5     normalized_ratio_5_36  -0.625
    w_5_5     full_original_Gini_340  -9.47857142857143
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -0.024
    x_5_6     product_lb_12  -2.4822695035436170e-02
    x_5_6     product_ub_13  -4.1401744787857471e-02
    x_5_6     onehot_5_34  1
    x_5_6     stock_lb_280  6
    x_5_6     stock_ub_281  6
    x_5_6     parent_nonstrict_scope_282  0.024
    x_5_6     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_12  1
    w_5_6     product_ub_13  1
    w_5_6     normalized_mass_5_35  1
    w_5_6     normalized_ratio_5_36  -0.75
    w_5_6     full_original_Gini_340  -7.1749999999999989e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -3.6000000000000004e-02
    x_5_7     product_lb_14  -2.4822695035436170e-02
    x_5_7     product_ub_15  -4.1401744787857471e-02
    x_5_7     onehot_5_34  1
    x_5_7     stock_lb_280  7
    x_5_7     stock_ub_281  7
    x_5_7     parent_nonstrict_scope_282  0.012
    x_5_7     unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_14  1
    w_5_7     product_ub_15  1
    w_5_7     normalized_mass_5_35  1
    w_5_7     normalized_ratio_5_36  -0.875
    w_5_7     full_original_Gini_340  -5.2714285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -0.048
    x_5_8     product_lb_16  -2.4822695035436170e-02
    x_5_8     product_ub_17  -4.1401744787857471e-02
    x_5_8     onehot_5_34  1
    x_5_8     stock_lb_280  8
    x_5_8     stock_ub_281  8
    x_5_8     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_16  1
    w_5_8     product_ub_17  1
    w_5_8     normalized_mass_5_35  1
    w_5_8     normalized_ratio_5_36  -1
    w_5_8     full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -3.6000000000000004e-02
    x_5_9     product_lb_18  -2.4822695035436170e-02
    x_5_9     product_ub_19  -4.1401744787857471e-02
    x_5_9     onehot_5_34  1
    x_5_9     stock_lb_280  9
    x_5_9     stock_ub_281  9
    x_5_9     parent_nonstrict_scope_282  0.012
    x_5_9     unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_18  1
    w_5_9     product_ub_19  1
    w_5_9     normalized_mass_5_35  1
    w_5_9     normalized_ratio_5_36  -1.125
    w_5_9     full_original_Gini_340  -6.7714285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -0.024
    x_5_10    product_lb_20  -2.4822695035436170e-02
    x_5_10    product_ub_21  -4.1401744787857471e-02
    x_5_10    onehot_5_34  1
    x_5_10    stock_lb_280  10
    x_5_10    stock_ub_281  10
    x_5_10    parent_nonstrict_scope_282  0.024
    x_5_10    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_20  1
    w_5_10    product_ub_21  1
    w_5_10    normalized_mass_5_35  1
    w_5_10    normalized_ratio_5_36  -1.25
    w_5_10    full_original_Gini_340  -9.59642857142857
    MARKER    'MARKER'                 'INTORG'
    x_5_11    OBJ       -1.1999999999999997e-02
    x_5_11    product_lb_22  -2.4822695035436170e-02
    x_5_11    product_ub_23  -4.1401744787857471e-02
    x_5_11    onehot_5_34  1
    x_5_11    stock_lb_280  11
    x_5_11    stock_ub_281  11
    x_5_11    parent_nonstrict_scope_282  3.6000000000000004e-02
    x_5_11    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_22  1
    w_5_11    product_ub_23  1
    w_5_11    normalized_mass_5_35  1
    w_5_11    normalized_ratio_5_36  -1.375
    w_5_11    full_original_Gini_340  -1.2971428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    product_lb_24  -2.4822695035436170e-02
    x_5_12    product_ub_25  -4.1401744787857471e-02
    x_5_12    onehot_5_34  1
    x_5_12    stock_lb_280  12
    x_5_12    stock_ub_281  12
    x_5_12    parent_nonstrict_scope_282  0.048
    x_5_12    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_24  1
    w_5_12    product_ub_25  1
    w_5_12    normalized_mass_5_35  1
    w_5_12    normalized_ratio_5_36  -1.5
    w_5_12    full_original_Gini_340  -1.6346428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.1999999999999997e-02
    x_5_13    product_lb_26  -2.4822695035436170e-02
    x_5_13    product_ub_27  -4.1401744787857471e-02
    x_5_13    onehot_5_34  1
    x_5_13    stock_lb_280  13
    x_5_13    stock_ub_281  13
    x_5_13    parent_nonstrict_scope_282  0.06
    x_5_13    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_26  1
    w_5_13    product_ub_27  1
    w_5_13    normalized_mass_5_35  1
    w_5_13    normalized_ratio_5_36  -1.625
    w_5_13    full_original_Gini_340  -1.9721428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       2.4000000000000007e-02
    x_5_14    product_lb_28  -2.4822695035436170e-02
    x_5_14    product_ub_29  -4.1401744787857471e-02
    x_5_14    onehot_5_34  1
    x_5_14    stock_lb_280  14
    x_5_14    stock_ub_281  14
    x_5_14    parent_nonstrict_scope_282  7.2000000000000008e-02
    x_5_14    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_28  1
    w_5_14    product_ub_29  1
    w_5_14    normalized_mass_5_35  1
    w_5_14    normalized_ratio_5_36  -1.75
    w_5_14    full_original_Gini_340  -2.3096428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       3.6000000000000004e-02
    x_5_15    product_lb_30  -2.4822695035436170e-02
    x_5_15    product_ub_31  -4.1401744787857471e-02
    x_5_15    onehot_5_34  1
    x_5_15    stock_lb_280  15
    x_5_15    stock_ub_281  15
    x_5_15    parent_nonstrict_scope_282  0.084
    x_5_15    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_30  1
    w_5_15    product_ub_31  1
    w_5_15    normalized_mass_5_35  1
    w_5_15    normalized_ratio_5_36  -1.875
    w_5_15    full_original_Gini_340  -2.6471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_16    OBJ       0.048
    x_5_16    product_lb_32  -2.4822695035436170e-02
    x_5_16    product_ub_33  -4.1401744787857471e-02
    x_5_16    onehot_5_34  1
    x_5_16    stock_lb_280  16
    x_5_16    stock_ub_281  16
    x_5_16    parent_nonstrict_scope_282  0.096
    x_5_16    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_16    product_lb_32  1
    w_5_16    product_ub_33  1
    w_5_16    normalized_mass_5_35  1
    w_5_16    normalized_ratio_5_36  -2
    w_5_16    full_original_Gini_340  -2.9846428571428572e+01
    rho_5     normalized_ratio_5_36  1
    rho_5     block_pair_pos_303  -1
    rho_5     block_pair_neg_304  1
    rho_5     block_pair_pos_305  -1
    rho_5     block_pair_neg_306  1
    rho_5     block_pair_pos_307  -1
    rho_5     block_pair_neg_308  1
    rho_5     block_pair_pos_309  -1
    rho_5     block_pair_neg_310  1
    rho_5     block_pair_pos_311  -1
    rho_5     block_pair_neg_312  1
    rho_5     block_pair_pos_313  -1
    rho_5     block_pair_neg_314  1
    rho_5     block_pair_pos_315  -1
    rho_5     block_pair_neg_316  1
    rho_5     normalization_339  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_37  -2.4822695035436170e-02
    x_2_0     product_ub_38  -4.1401744787857471e-02
    x_2_0     onehot_2_69  1
    x_2_0     parent_nonstrict_scope_282  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_37  1
    w_2_0     product_ub_38  1
    w_2_0     normalized_mass_2_70  1
    w_2_0     full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_39  -2.4822695035436170e-02
    x_2_1     product_ub_40  -4.1401744787857471e-02
    x_2_1     onehot_2_69  1
    x_2_1     stock_lb_280  1
    x_2_1     stock_ub_281  1
    x_2_1     parent_nonstrict_scope_282  0.063
    x_2_1     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_39  1
    w_2_1     product_ub_40  1
    w_2_1     normalized_mass_2_70  1
    w_2_1     normalized_ratio_2_71  -1.4285714285714285e-01
    w_2_1     full_original_Gini_340  -2.0296428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_41  -2.4822695035436170e-02
    x_2_2     product_ub_42  -4.1401744787857471e-02
    x_2_2     onehot_2_69  1
    x_2_2     stock_lb_280  2
    x_2_2     stock_ub_281  2
    x_2_2     parent_nonstrict_scope_282  0.0525
    x_2_2     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_41  1
    w_2_2     product_ub_42  1
    w_2_2     normalized_mass_2_70  1
    w_2_2     normalized_ratio_2_71  -2.8571428571428570e-01
    w_2_2     full_original_Gini_340  -1.6582142857142852e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_43  -2.4822695035436170e-02
    x_2_3     product_ub_44  -4.1401744787857471e-02
    x_2_3     onehot_2_69  1
    x_2_3     stock_lb_280  3
    x_2_3     stock_ub_281  3
    x_2_3     parent_nonstrict_scope_282  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_43  1
    w_2_3     product_ub_44  1
    w_2_3     normalized_mass_2_70  1
    w_2_3     normalized_ratio_2_71  -4.2857142857142855e-01
    w_2_3     full_original_Gini_340  -1.3353571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_45  -2.4822695035436170e-02
    x_2_4     product_ub_46  -4.1401744787857471e-02
    x_2_4     onehot_2_69  1
    x_2_4     stock_lb_280  4
    x_2_4     stock_ub_281  4
    x_2_4     parent_nonstrict_scope_282  0.0315
    x_2_4     unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_45  1
    w_2_4     product_ub_46  1
    w_2_4     normalized_mass_2_70  1
    w_2_4     normalized_ratio_2_71  -5.7142857142857140e-01
    w_2_4     full_original_Gini_340  -1.0496428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_47  -2.4822695035436170e-02
    x_2_5     product_ub_48  -4.1401744787857471e-02
    x_2_5     onehot_2_69  1
    x_2_5     stock_lb_280  5
    x_2_5     stock_ub_281  5
    x_2_5     parent_nonstrict_scope_282  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_47  1
    w_2_5     product_ub_48  1
    w_2_5     normalized_mass_2_70  1
    w_2_5     normalized_ratio_2_71  -7.1428571428571419e-01
    w_2_5     full_original_Gini_340  -7.7821428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_49  -2.4822695035436170e-02
    x_2_6     product_ub_50  -4.1401744787857471e-02
    x_2_6     onehot_2_69  1
    x_2_6     stock_lb_280  6
    x_2_6     stock_ub_281  6
    x_2_6     parent_nonstrict_scope_282  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_49  1
    w_2_6     product_ub_50  1
    w_2_6     normalized_mass_2_70  1
    w_2_6     normalized_ratio_2_71  -8.5714285714285710e-01
    w_2_6     full_original_Gini_340  -5.4678571428571452e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_51  -2.4822695035436170e-02
    x_2_7     product_ub_52  -4.1401744787857471e-02
    x_2_7     onehot_2_69  1
    x_2_7     stock_lb_280  7
    x_2_7     stock_ub_281  7
    x_2_7     unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_51  1
    w_2_7     product_ub_52  1
    w_2_7     normalized_mass_2_70  1
    w_2_7     normalized_ratio_2_71  -1
    w_2_7     full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_53  -2.4822695035436170e-02
    x_2_8     product_ub_54  -4.1401744787857471e-02
    x_2_8     onehot_2_69  1
    x_2_8     stock_lb_280  8
    x_2_8     stock_ub_281  8
    x_2_8     parent_nonstrict_scope_282  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_53  1
    w_2_8     product_ub_54  1
    w_2_8     normalized_mass_2_70  1
    w_2_8     normalized_ratio_2_71  -1.1428571428571428e+00
    w_2_8     full_original_Gini_340  -7.1464285714285687e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_55  -2.4822695035436170e-02
    x_2_9     product_ub_56  -4.1401744787857471e-02
    x_2_9     onehot_2_69  1
    x_2_9     stock_lb_280  9
    x_2_9     stock_ub_281  9
    x_2_9     parent_nonstrict_scope_282  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_55  1
    w_2_9     product_ub_56  1
    w_2_9     normalized_mass_2_70  1
    w_2_9     normalized_ratio_2_71  -1.2857142857142856e+00
    w_2_9     full_original_Gini_340  -1.0560714285714280e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_57  -2.4822695035436170e-02
    x_2_10    product_ub_58  -4.1401744787857471e-02
    x_2_10    onehot_2_69  1
    x_2_10    stock_lb_280  10
    x_2_10    stock_ub_281  10
    x_2_10    parent_nonstrict_scope_282  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_57  1
    w_2_10    product_ub_58  1
    w_2_10    normalized_mass_2_70  1
    w_2_10    normalized_ratio_2_71  -1.4285714285714284e+00
    w_2_10    full_original_Gini_340  -1.4417857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_59  -2.4822695035436170e-02
    x_2_11    product_ub_60  -4.1401744787857471e-02
    x_2_11    onehot_2_69  1
    x_2_11    stock_lb_280  11
    x_2_11    stock_ub_281  11
    x_2_11    parent_nonstrict_scope_282  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_59  1
    w_2_11    product_ub_60  1
    w_2_11    normalized_mass_2_70  1
    w_2_11    normalized_ratio_2_71  -1.5714285714285714e+00
    w_2_11    full_original_Gini_340  -18.275
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_61  -2.4822695035436170e-02
    x_2_12    product_ub_62  -4.1401744787857471e-02
    x_2_12    onehot_2_69  1
    x_2_12    stock_lb_280  12
    x_2_12    stock_ub_281  12
    x_2_12    parent_nonstrict_scope_282  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_61  1
    w_2_12    product_ub_62  1
    w_2_12    normalized_mass_2_70  1
    w_2_12    normalized_ratio_2_71  -1.7142857142857142e+00
    w_2_12    full_original_Gini_340  -2.2132142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_63  -2.4822695035436170e-02
    x_2_13    product_ub_64  -4.1401744787857471e-02
    x_2_13    onehot_2_69  1
    x_2_13    stock_lb_280  13
    x_2_13    stock_ub_281  13
    x_2_13    parent_nonstrict_scope_282  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_63  1
    w_2_13    product_ub_64  1
    w_2_13    normalized_mass_2_70  1
    w_2_13    normalized_ratio_2_71  -1.8571428571428570e+00
    w_2_13    full_original_Gini_340  -2.5989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_65  -2.4822695035436170e-02
    x_2_14    product_ub_66  -4.1401744787857471e-02
    x_2_14    onehot_2_69  1
    x_2_14    stock_lb_280  14
    x_2_14    stock_ub_281  14
    x_2_14    parent_nonstrict_scope_282  0.0735
    x_2_14    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_65  1
    w_2_14    product_ub_66  1
    w_2_14    normalized_mass_2_70  1
    w_2_14    normalized_ratio_2_71  -2
    w_2_14    full_original_Gini_340  -2.9846428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_67  -2.4822695035436170e-02
    x_2_15    product_ub_68  -4.1401744787857471e-02
    x_2_15    onehot_2_69  1
    x_2_15    stock_lb_280  15
    x_2_15    stock_ub_281  15
    x_2_15    parent_nonstrict_scope_282  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_67  1
    w_2_15    product_ub_68  1
    w_2_15    normalized_mass_2_70  1
    w_2_15    normalized_ratio_2_71  -2.1428571428571428e+00
    w_2_15    full_original_Gini_340  -3.3703571428571422e+01
    rho_2     normalized_ratio_2_71  1
    rho_2     block_pair_pos_291  -1
    rho_2     block_pair_neg_292  1
    rho_2     block_pair_pos_293  -1
    rho_2     block_pair_neg_294  1
    rho_2     block_pair_pos_295  -1
    rho_2     block_pair_neg_296  1
    rho_2     block_pair_pos_297  -1
    rho_2     block_pair_neg_298  1
    rho_2     block_pair_pos_299  -1
    rho_2     block_pair_neg_300  1
    rho_2     block_pair_pos_301  -1
    rho_2     block_pair_neg_302  1
    rho_2     block_pair_pos_305  1
    rho_2     block_pair_neg_306  -1
    rho_2     normalization_339  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_72  -2.4822695035436170e-02
    x_31_0    product_ub_73  -4.1401744787857471e-02
    x_31_0    onehot_31_98  1
    x_31_0    parent_nonstrict_scope_282  0.0735
    x_31_0    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_72  1
    w_31_0    product_ub_73  1
    w_31_0    normalized_mass_31_99  1
    w_31_0    full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_74  -2.4822695035436170e-02
    x_31_1    product_ub_75  -4.1401744787857471e-02
    x_31_1    onehot_31_98  1
    x_31_1    stock_lb_280  1
    x_31_1    stock_ub_281  1
    x_31_1    parent_nonstrict_scope_282  0.063
    x_31_1    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_74  1
    w_31_1    product_ub_75  1
    w_31_1    normalized_mass_31_99  1
    w_31_1    normalized_ratio_31_100  -1.4285714285714285e-01
    w_31_1    full_original_Gini_340  -2.0296428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_76  -2.4822695035436170e-02
    x_31_2    product_ub_77  -4.1401744787857471e-02
    x_31_2    onehot_31_98  1
    x_31_2    stock_lb_280  2
    x_31_2    stock_ub_281  2
    x_31_2    parent_nonstrict_scope_282  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_76  1
    w_31_2    product_ub_77  1
    w_31_2    normalized_mass_31_99  1
    w_31_2    normalized_ratio_31_100  -2.8571428571428570e-01
    w_31_2    full_original_Gini_340  -1.6582142857142852e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_78  -2.4822695035436170e-02
    x_31_3    product_ub_79  -4.1401744787857471e-02
    x_31_3    onehot_31_98  1
    x_31_3    stock_lb_280  3
    x_31_3    stock_ub_281  3
    x_31_3    parent_nonstrict_scope_282  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_78  1
    w_31_3    product_ub_79  1
    w_31_3    normalized_mass_31_99  1
    w_31_3    normalized_ratio_31_100  -4.2857142857142855e-01
    w_31_3    full_original_Gini_340  -1.3353571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_80  -2.4822695035436170e-02
    x_31_4    product_ub_81  -4.1401744787857471e-02
    x_31_4    onehot_31_98  1
    x_31_4    stock_lb_280  4
    x_31_4    stock_ub_281  4
    x_31_4    parent_nonstrict_scope_282  0.0315
    x_31_4    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_80  1
    w_31_4    product_ub_81  1
    w_31_4    normalized_mass_31_99  1
    w_31_4    normalized_ratio_31_100  -5.7142857142857140e-01
    w_31_4    full_original_Gini_340  -1.0496428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_82  -2.4822695035436170e-02
    x_31_5    product_ub_83  -4.1401744787857471e-02
    x_31_5    onehot_31_98  1
    x_31_5    stock_lb_280  5
    x_31_5    stock_ub_281  5
    x_31_5    parent_nonstrict_scope_282  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_82  1
    w_31_5    product_ub_83  1
    w_31_5    normalized_mass_31_99  1
    w_31_5    normalized_ratio_31_100  -7.1428571428571419e-01
    w_31_5    full_original_Gini_340  -7.7821428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_84  -2.4822695035436170e-02
    x_31_6    product_ub_85  -4.1401744787857471e-02
    x_31_6    onehot_31_98  1
    x_31_6    stock_lb_280  6
    x_31_6    stock_ub_281  6
    x_31_6    parent_nonstrict_scope_282  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_84  1
    w_31_6    product_ub_85  1
    w_31_6    normalized_mass_31_99  1
    w_31_6    normalized_ratio_31_100  -8.5714285714285710e-01
    w_31_6    full_original_Gini_340  -5.4678571428571452e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_86  -2.4822695035436170e-02
    x_31_7    product_ub_87  -4.1401744787857471e-02
    x_31_7    onehot_31_98  1
    x_31_7    stock_lb_280  7
    x_31_7    stock_ub_281  7
    x_31_7    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_86  1
    w_31_7    product_ub_87  1
    w_31_7    normalized_mass_31_99  1
    w_31_7    normalized_ratio_31_100  -1
    w_31_7    full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_88  -2.4822695035436170e-02
    x_31_8    product_ub_89  -4.1401744787857471e-02
    x_31_8    onehot_31_98  1
    x_31_8    stock_lb_280  8
    x_31_8    stock_ub_281  8
    x_31_8    parent_nonstrict_scope_282  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_88  1
    w_31_8    product_ub_89  1
    w_31_8    normalized_mass_31_99  1
    w_31_8    normalized_ratio_31_100  -1.1428571428571428e+00
    w_31_8    full_original_Gini_340  -7.1464285714285687e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_90  -2.4822695035436170e-02
    x_31_9    product_ub_91  -4.1401744787857471e-02
    x_31_9    onehot_31_98  1
    x_31_9    stock_lb_280  9
    x_31_9    stock_ub_281  9
    x_31_9    parent_nonstrict_scope_282  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_90  1
    w_31_9    product_ub_91  1
    w_31_9    normalized_mass_31_99  1
    w_31_9    normalized_ratio_31_100  -1.2857142857142856e+00
    w_31_9    full_original_Gini_340  -1.0560714285714280e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_92  -2.4822695035436170e-02
    x_31_10   product_ub_93  -4.1401744787857471e-02
    x_31_10   onehot_31_98  1
    x_31_10   stock_lb_280  10
    x_31_10   stock_ub_281  10
    x_31_10   parent_nonstrict_scope_282  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_92  1
    w_31_10   product_ub_93  1
    w_31_10   normalized_mass_31_99  1
    w_31_10   normalized_ratio_31_100  -1.4285714285714284e+00
    w_31_10   full_original_Gini_340  -1.4417857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_94  -2.4822695035436170e-02
    x_31_11   product_ub_95  -4.1401744787857471e-02
    x_31_11   onehot_31_98  1
    x_31_11   stock_lb_280  11
    x_31_11   stock_ub_281  11
    x_31_11   parent_nonstrict_scope_282  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_94  1
    w_31_11   product_ub_95  1
    w_31_11   normalized_mass_31_99  1
    w_31_11   normalized_ratio_31_100  -1.5714285714285714e+00
    w_31_11   full_original_Gini_340  -18.275
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_96  -2.4822695035436170e-02
    x_31_12   product_ub_97  -4.1401744787857471e-02
    x_31_12   onehot_31_98  1
    x_31_12   stock_lb_280  12
    x_31_12   stock_ub_281  12
    x_31_12   parent_nonstrict_scope_282  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_96  1
    w_31_12   product_ub_97  1
    w_31_12   normalized_mass_31_99  1
    w_31_12   normalized_ratio_31_100  -1.7142857142857142e+00
    w_31_12   full_original_Gini_340  -2.2132142857142856e+01
    rho_31    normalized_ratio_31_100  1
    rho_31    block_pair_pos_299  1
    rho_31    block_pair_neg_300  -1
    rho_31    block_pair_pos_313  1
    rho_31    block_pair_neg_314  -1
    rho_31    block_pair_pos_327  -1
    rho_31    block_pair_neg_328  1
    rho_31    block_pair_pos_329  -1
    rho_31    block_pair_neg_330  1
    rho_31    block_pair_pos_331  -1
    rho_31    block_pair_neg_332  1
    rho_31    block_pair_pos_333  -1
    rho_31    block_pair_neg_334  1
    rho_31    block_pair_pos_335  -1
    rho_31    block_pair_neg_336  1
    rho_31    normalization_339  1
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     product_lb_101  -2.4822695035436170e-02
    x_1_0     product_ub_102  -4.1401744787857471e-02
    x_1_0     onehot_1_141  1
    x_1_0     parent_nonstrict_scope_282  0.15
    x_1_0     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_101  1
    w_1_0     product_ub_102  1
    w_1_0     normalized_mass_1_142  1
    w_1_0     full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       6.0000000000000012e-02
    x_1_1     product_lb_103  -2.4822695035436170e-02
    x_1_1     product_ub_104  -4.1401744787857471e-02
    x_1_1     onehot_1_141  1
    x_1_1     stock_lb_280  1
    x_1_1     stock_ub_281  1
    x_1_1     parent_nonstrict_scope_282  0.135
    x_1_1     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_103  1
    w_1_1     product_ub_104  1
    w_1_1     normalized_mass_1_142  1
    w_1_1     normalized_ratio_1_143  -0.1
    w_1_1     full_original_Gini_340  -2.1453571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       0.045
    x_1_2     product_lb_105  -2.4822695035436170e-02
    x_1_2     product_ub_106  -4.1401744787857471e-02
    x_1_2     onehot_1_141  1
    x_1_2     stock_lb_280  2
    x_1_2     stock_ub_281  2
    x_1_2     parent_nonstrict_scope_282  0.12
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_105  1
    w_1_2     product_ub_106  1
    w_1_2     normalized_mass_1_142  1
    w_1_2     normalized_ratio_1_143  -0.2
    w_1_2     full_original_Gini_340  -1.8753571428571437e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_3     OBJ       0.03
    x_1_3     product_lb_107  -2.4822695035436170e-02
    x_1_3     product_ub_108  -4.1401744787857471e-02
    x_1_3     onehot_1_141  1
    x_1_3     stock_lb_280  3
    x_1_3     stock_ub_281  3
    x_1_3     parent_nonstrict_scope_282  0.105
    x_1_3     unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_107  1
    w_1_3     product_ub_108  1
    w_1_3     normalized_mass_1_142  1
    w_1_3     normalized_ratio_1_143  -3.0000000000000004e-01
    w_1_3     full_original_Gini_340  -1.6253571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       0.015
    x_1_4     product_lb_109  -2.4822695035436170e-02
    x_1_4     product_ub_110  -4.1401744787857471e-02
    x_1_4     onehot_1_141  1
    x_1_4     stock_lb_280  4
    x_1_4     stock_ub_281  4
    x_1_4     parent_nonstrict_scope_282  0.09
    x_1_4     unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_109  1
    w_1_4     product_ub_110  1
    w_1_4     normalized_mass_1_142  1
    w_1_4     normalized_ratio_1_143  -0.4
    w_1_4     full_original_Gini_340  -1.3953571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_5     product_lb_111  -2.4822695035436170e-02
    x_1_5     product_ub_112  -4.1401744787857471e-02
    x_1_5     onehot_1_141  1
    x_1_5     stock_lb_280  5
    x_1_5     stock_ub_281  5
    x_1_5     parent_nonstrict_scope_282  0.075
    x_1_5     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_111  1
    w_1_5     product_ub_112  1
    w_1_5     normalized_mass_1_142  1
    w_1_5     normalized_ratio_1_143  -0.5
    w_1_5     full_original_Gini_340  -1.1853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -1.5000000000000013e-02
    x_1_6     product_lb_113  -2.4822695035436170e-02
    x_1_6     product_ub_114  -4.1401744787857471e-02
    x_1_6     onehot_1_141  1
    x_1_6     stock_lb_280  6
    x_1_6     stock_ub_281  6
    x_1_6     parent_nonstrict_scope_282  5.9999999999999984e-02
    x_1_6     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_113  1
    w_1_6     product_ub_114  1
    w_1_6     normalized_mass_1_142  1
    w_1_6     normalized_ratio_1_143  -6.0000000000000009e-01
    w_1_6     full_original_Gini_340  -9.9535714285714274e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -3.0000000000000006e-02
    x_1_7     product_lb_115  -2.4822695035436170e-02
    x_1_7     product_ub_116  -4.1401744787857471e-02
    x_1_7     onehot_1_141  1
    x_1_7     stock_lb_280  7
    x_1_7     stock_ub_281  7
    x_1_7     parent_nonstrict_scope_282  4.4999999999999991e-02
    x_1_7     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_115  1
    w_1_7     product_ub_116  1
    w_1_7     normalized_mass_1_142  1
    w_1_7     normalized_ratio_1_143  -7.0000000000000007e-01
    w_1_7     full_original_Gini_340  -8.0535714285714270e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -4.5000000000000005e-02
    x_1_8     product_lb_117  -2.4822695035436170e-02
    x_1_8     product_ub_118  -4.1401744787857471e-02
    x_1_8     onehot_1_141  1
    x_1_8     stock_lb_280  8
    x_1_8     stock_ub_281  8
    x_1_8     parent_nonstrict_scope_282  2.9999999999999992e-02
    x_1_8     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_117  1
    w_1_8     product_ub_118  1
    w_1_8     normalized_mass_1_142  1
    w_1_8     normalized_ratio_1_143  -0.8
    w_1_8     full_original_Gini_340  -6.3250000000000011e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -0.06
    x_1_9     product_lb_119  -2.4822695035436170e-02
    x_1_9     product_ub_120  -4.1401744787857471e-02
    x_1_9     onehot_1_141  1
    x_1_9     stock_lb_280  9
    x_1_9     stock_ub_281  9
    x_1_9     parent_nonstrict_scope_282  1.4999999999999996e-02
    x_1_9     unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_119  1
    w_1_9     product_ub_120  1
    w_1_9     normalized_mass_1_142  1
    w_1_9     normalized_ratio_1_143  -0.9
    w_1_9     full_original_Gini_340  -5.0464285714285717e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -0.075
    x_1_10    product_lb_121  -2.4822695035436170e-02
    x_1_10    product_ub_122  -4.1401744787857471e-02
    x_1_10    onehot_1_141  1
    x_1_10    stock_lb_280  10
    x_1_10    stock_ub_281  10
    x_1_10    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_121  1
    w_1_10    product_ub_122  1
    w_1_10    normalized_mass_1_142  1
    w_1_10    normalized_ratio_1_143  -1
    w_1_10    full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    OBJ       -5.9999999999999984e-02
    x_1_11    product_lb_123  -2.4822695035436170e-02
    x_1_11    product_ub_124  -4.1401744787857471e-02
    x_1_11    onehot_1_141  1
    x_1_11    stock_lb_280  11
    x_1_11    stock_ub_281  11
    x_1_11    parent_nonstrict_scope_282  1.5000000000000013e-02
    x_1_11    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_123  1
    w_1_11    product_ub_124  1
    w_1_11    normalized_mass_1_142  1
    w_1_11    normalized_ratio_1_143  -1.1
    w_1_11    full_original_Gini_340  -6.2464285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       -4.4999999999999971e-02
    x_1_12    product_lb_125  -2.4822695035436170e-02
    x_1_12    product_ub_126  -4.1401744787857471e-02
    x_1_12    onehot_1_141  1
    x_1_12    stock_lb_280  12
    x_1_12    stock_ub_281  12
    x_1_12    parent_nonstrict_scope_282  3.0000000000000027e-02
    x_1_12    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_125  1
    w_1_12    product_ub_126  1
    w_1_12    normalized_mass_1_142  1
    w_1_12    normalized_ratio_1_143  -1.2000000000000002e+00
    w_1_12    full_original_Gini_340  -8.3464285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       -2.9999999999999992e-02
    x_1_13    product_lb_127  -2.4822695035436170e-02
    x_1_13    product_ub_128  -4.1401744787857471e-02
    x_1_13    onehot_1_141  1
    x_1_13    stock_lb_280  13
    x_1_13    stock_ub_281  13
    x_1_13    parent_nonstrict_scope_282  4.5000000000000005e-02
    x_1_13    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_127  1
    w_1_13    product_ub_128  1
    w_1_13    normalized_mass_1_142  1
    w_1_13    normalized_ratio_1_143  -1.3
    w_1_13    full_original_Gini_340  -1.0946428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       -1.4999999999999979e-02
    x_1_14    product_lb_129  -2.4822695035436170e-02
    x_1_14    product_ub_130  -4.1401744787857471e-02
    x_1_14    onehot_1_141  1
    x_1_14    stock_lb_280  14
    x_1_14    stock_ub_281  14
    x_1_14    parent_nonstrict_scope_282  6.0000000000000019e-02
    x_1_14    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_129  1
    w_1_14    product_ub_130  1
    w_1_14    normalized_mass_1_142  1
    w_1_14    normalized_ratio_1_143  -1.4000000000000001e+00
    w_1_14    full_original_Gini_340  -1.3646428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_15    product_lb_131  -2.4822695035436170e-02
    x_1_15    product_ub_132  -4.1401744787857471e-02
    x_1_15    onehot_1_141  1
    x_1_15    stock_lb_280  15
    x_1_15    stock_ub_281  15
    x_1_15    parent_nonstrict_scope_282  0.075
    x_1_15    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_131  1
    w_1_15    product_ub_132  1
    w_1_15    normalized_mass_1_142  1
    w_1_15    normalized_ratio_1_143  -1.5
    w_1_15    full_original_Gini_340  -1.6346428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_16    OBJ       1.5000000000000013e-02
    x_1_16    product_lb_133  -2.4822695035436170e-02
    x_1_16    product_ub_134  -4.1401744787857471e-02
    x_1_16    onehot_1_141  1
    x_1_16    stock_lb_280  16
    x_1_16    stock_ub_281  16
    x_1_16    parent_nonstrict_scope_282  9.0000000000000011e-02
    x_1_16    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_16    product_lb_133  1
    w_1_16    product_ub_134  1
    w_1_16    normalized_mass_1_142  1
    w_1_16    normalized_ratio_1_143  -1.6
    w_1_16    full_original_Gini_340  -1.9046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_17    OBJ       3.0000000000000027e-02
    x_1_17    product_lb_135  -2.4822695035436170e-02
    x_1_17    product_ub_136  -4.1401744787857471e-02
    x_1_17    onehot_1_141  1
    x_1_17    stock_lb_280  17
    x_1_17    stock_ub_281  17
    x_1_17    parent_nonstrict_scope_282  1.0500000000000002e-01
    x_1_17    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_17    product_lb_135  1
    w_1_17    product_ub_136  1
    w_1_17    normalized_mass_1_142  1
    w_1_17    normalized_ratio_1_143  -1.7000000000000002e+00
    w_1_17    full_original_Gini_340  -2.1746428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_18    OBJ       0.045
    x_1_18    product_lb_137  -2.4822695035436170e-02
    x_1_18    product_ub_138  -4.1401744787857471e-02
    x_1_18    onehot_1_141  1
    x_1_18    stock_lb_280  18
    x_1_18    stock_ub_281  18
    x_1_18    parent_nonstrict_scope_282  0.12
    x_1_18    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_18    product_lb_137  1
    w_1_18    product_ub_138  1
    w_1_18    normalized_mass_1_142  1
    w_1_18    normalized_ratio_1_143  -1.8
    w_1_18    full_original_Gini_340  -2.4446428571428580e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_19    OBJ       6.0000000000000012e-02
    x_1_19    product_lb_139  -2.4822695035436170e-02
    x_1_19    product_ub_140  -4.1401744787857471e-02
    x_1_19    onehot_1_141  1
    x_1_19    stock_lb_280  19
    x_1_19    stock_ub_281  19
    x_1_19    parent_nonstrict_scope_282  0.135
    x_1_19    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_19    product_lb_139  1
    w_1_19    product_ub_140  1
    w_1_19    normalized_mass_1_142  1
    w_1_19    normalized_ratio_1_143  -1.9000000000000001e+00
    w_1_19    full_original_Gini_340  -2.7146428571428569e+01
    rho_1     normalized_ratio_1_143  1
    rho_1     block_pair_pos_283  -1
    rho_1     block_pair_neg_284  1
    rho_1     block_pair_pos_285  -1
    rho_1     block_pair_neg_286  1
    rho_1     block_pair_pos_287  -1
    rho_1     block_pair_neg_288  1
    rho_1     block_pair_pos_289  -1
    rho_1     block_pair_neg_290  1
    rho_1     block_pair_pos_291  1
    rho_1     block_pair_neg_292  -1
    rho_1     block_pair_pos_303  1
    rho_1     block_pair_neg_304  -1
    rho_1     block_pair_pos_327  1
    rho_1     block_pair_neg_328  -1
    rho_1     normalization_339  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_144  -2.4822695035436170e-02
    x_6_0     product_ub_145  -4.1401744787857471e-02
    x_6_0     onehot_6_166  1
    x_6_0     parent_nonstrict_scope_282  0.0375
    x_6_0     unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_144  1
    w_6_0     product_ub_145  1
    w_6_0     normalized_mass_6_167  1
    w_6_0     full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_146  -2.4822695035436170e-02
    x_6_1     product_ub_147  -4.1401744787857471e-02
    x_6_1     onehot_6_166  1
    x_6_1     stock_lb_280  1
    x_6_1     stock_ub_281  1
    x_6_1     parent_nonstrict_scope_282  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_146  1
    w_6_1     product_ub_147  1
    w_6_1     normalized_mass_6_167  1
    w_6_1     normalized_ratio_6_168  -0.2
    w_6_1     full_original_Gini_340  -1.8753571428571437e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_148  -2.4822695035436170e-02
    x_6_2     product_ub_149  -4.1401744787857471e-02
    x_6_2     onehot_6_166  1
    x_6_2     stock_lb_280  2
    x_6_2     stock_ub_281  2
    x_6_2     parent_nonstrict_scope_282  0.0225
    x_6_2     unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_148  1
    w_6_2     product_ub_149  1
    w_6_2     normalized_mass_6_167  1
    w_6_2     normalized_ratio_6_168  -0.4
    w_6_2     full_original_Gini_340  -1.3953571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_150  -2.4822695035436170e-02
    x_6_3     product_ub_151  -4.1401744787857471e-02
    x_6_3     onehot_6_166  1
    x_6_3     stock_lb_280  3
    x_6_3     stock_ub_281  3
    x_6_3     parent_nonstrict_scope_282  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_150  1
    w_6_3     product_ub_151  1
    w_6_3     normalized_mass_6_167  1
    w_6_3     normalized_ratio_6_168  -6.0000000000000009e-01
    w_6_3     full_original_Gini_340  -9.9535714285714274e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_152  -2.4822695035436170e-02
    x_6_4     product_ub_153  -4.1401744787857471e-02
    x_6_4     onehot_6_166  1
    x_6_4     stock_lb_280  4
    x_6_4     stock_ub_281  4
    x_6_4     parent_nonstrict_scope_282  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_152  1
    w_6_4     product_ub_153  1
    w_6_4     normalized_mass_6_167  1
    w_6_4     normalized_ratio_6_168  -0.8
    w_6_4     full_original_Gini_340  -6.3250000000000011e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_154  -2.4822695035436170e-02
    x_6_5     product_ub_155  -4.1401744787857471e-02
    x_6_5     onehot_6_166  1
    x_6_5     stock_lb_280  5
    x_6_5     stock_ub_281  5
    x_6_5     unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_154  1
    w_6_5     product_ub_155  1
    w_6_5     normalized_mass_6_167  1
    w_6_5     normalized_ratio_6_168  -1
    w_6_5     full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_156  -2.4822695035436170e-02
    x_6_6     product_ub_157  -4.1401744787857471e-02
    x_6_6     onehot_6_166  1
    x_6_6     stock_lb_280  6
    x_6_6     stock_ub_281  6
    x_6_6     parent_nonstrict_scope_282  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_156  1
    w_6_6     product_ub_157  1
    w_6_6     normalized_mass_6_167  1
    w_6_6     normalized_ratio_6_168  -1.2000000000000002e+00
    w_6_6     full_original_Gini_340  -8.3464285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_158  -2.4822695035436170e-02
    x_6_7     product_ub_159  -4.1401744787857471e-02
    x_6_7     onehot_6_166  1
    x_6_7     stock_lb_280  7
    x_6_7     stock_ub_281  7
    x_6_7     parent_nonstrict_scope_282  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_158  1
    w_6_7     product_ub_159  1
    w_6_7     normalized_mass_6_167  1
    w_6_7     normalized_ratio_6_168  -1.4000000000000001e+00
    w_6_7     full_original_Gini_340  -1.3646428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_160  -2.4822695035436170e-02
    x_6_8     product_ub_161  -4.1401744787857471e-02
    x_6_8     onehot_6_166  1
    x_6_8     stock_lb_280  8
    x_6_8     stock_ub_281  8
    x_6_8     parent_nonstrict_scope_282  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_160  1
    w_6_8     product_ub_161  1
    w_6_8     normalized_mass_6_167  1
    w_6_8     normalized_ratio_6_168  -1.6
    w_6_8     full_original_Gini_340  -1.9046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_162  -2.4822695035436170e-02
    x_6_9     product_ub_163  -4.1401744787857471e-02
    x_6_9     onehot_6_166  1
    x_6_9     stock_lb_280  9
    x_6_9     stock_ub_281  9
    x_6_9     parent_nonstrict_scope_282  0.03
    x_6_9     unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_162  1
    w_6_9     product_ub_163  1
    w_6_9     normalized_mass_6_167  1
    w_6_9     normalized_ratio_6_168  -1.8
    w_6_9     full_original_Gini_340  -2.4446428571428580e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_164  -2.4822695035436170e-02
    x_6_10    product_ub_165  -4.1401744787857471e-02
    x_6_10    onehot_6_166  1
    x_6_10    stock_lb_280  10
    x_6_10    stock_ub_281  10
    x_6_10    parent_nonstrict_scope_282  0.0375
    x_6_10    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_164  1
    w_6_10    product_ub_165  1
    w_6_10    normalized_mass_6_167  1
    w_6_10    normalized_ratio_6_168  -2
    w_6_10    full_original_Gini_340  -2.9846428571428572e+01
    rho_6     normalized_ratio_6_168  1
    rho_6     block_pair_pos_283  1
    rho_6     block_pair_neg_284  -1
    rho_6     block_pair_pos_293  1
    rho_6     block_pair_neg_294  -1
    rho_6     block_pair_pos_307  1
    rho_6     block_pair_neg_308  -1
    rho_6     block_pair_pos_317  -1
    rho_6     block_pair_neg_318  1
    rho_6     block_pair_pos_319  -1
    rho_6     block_pair_neg_320  1
    rho_6     block_pair_pos_321  -1
    rho_6     block_pair_neg_322  1
    rho_6     block_pair_pos_329  1
    rho_6     block_pair_neg_330  -1
    rho_6     normalization_339  1
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       6.7499999999999991e-02
    x_8_0     product_lb_169  -2.4822695035436170e-02
    x_8_0     product_ub_170  -4.1401744787857471e-02
    x_8_0     onehot_8_213  1
    x_8_0     parent_nonstrict_scope_282  0.15
    x_8_0     unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_169  1
    w_8_0     product_ub_170  1
    w_8_0     normalized_mass_8_214  1
    w_8_0     full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       5.2500000000000005e-02
    x_8_1     product_lb_171  -2.4822695035436170e-02
    x_8_1     product_ub_172  -4.1401744787857471e-02
    x_8_1     onehot_8_213  1
    x_8_1     stock_lb_280  1
    x_8_1     stock_ub_281  1
    x_8_1     parent_nonstrict_scope_282  0.135
    x_8_1     unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_171  1
    w_8_1     product_ub_172  1
    w_8_1     normalized_mass_8_214  1
    w_8_1     normalized_ratio_8_215  -0.1
    w_8_1     full_original_Gini_340  -2.1453571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       3.7499999999999992e-02
    x_8_2     product_lb_173  -2.4822695035436170e-02
    x_8_2     product_ub_174  -4.1401744787857471e-02
    x_8_2     onehot_8_213  1
    x_8_2     stock_lb_280  2
    x_8_2     stock_ub_281  2
    x_8_2     parent_nonstrict_scope_282  0.12
    x_8_2     unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_173  1
    w_8_2     product_ub_174  1
    w_8_2     normalized_mass_8_214  1
    w_8_2     normalized_ratio_8_215  -0.2
    w_8_2     full_original_Gini_340  -1.8753571428571437e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     OBJ       2.2499999999999992e-02
    x_8_3     product_lb_175  -2.4822695035436170e-02
    x_8_3     product_ub_176  -4.1401744787857471e-02
    x_8_3     onehot_8_213  1
    x_8_3     stock_lb_280  3
    x_8_3     stock_ub_281  3
    x_8_3     parent_nonstrict_scope_282  0.105
    x_8_3     unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_175  1
    w_8_3     product_ub_176  1
    w_8_3     normalized_mass_8_214  1
    w_8_3     normalized_ratio_8_215  -3.0000000000000004e-01
    w_8_3     full_original_Gini_340  -1.6253571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       7.4999999999999928e-03
    x_8_4     product_lb_177  -2.4822695035436170e-02
    x_8_4     product_ub_178  -4.1401744787857471e-02
    x_8_4     onehot_8_213  1
    x_8_4     stock_lb_280  4
    x_8_4     stock_ub_281  4
    x_8_4     parent_nonstrict_scope_282  0.09
    x_8_4     unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_177  1
    w_8_4     product_ub_178  1
    w_8_4     normalized_mass_8_214  1
    w_8_4     normalized_ratio_8_215  -0.4
    w_8_4     full_original_Gini_340  -1.3953571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -7.5000000000000067e-03
    x_8_5     product_lb_179  -2.4822695035436170e-02
    x_8_5     product_ub_180  -4.1401744787857471e-02
    x_8_5     onehot_8_213  1
    x_8_5     stock_lb_280  5
    x_8_5     stock_ub_281  5
    x_8_5     parent_nonstrict_scope_282  0.075
    x_8_5     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_179  1
    w_8_5     product_ub_180  1
    w_8_5     normalized_mass_8_214  1
    w_8_5     normalized_ratio_8_215  -0.5
    w_8_5     full_original_Gini_340  -1.1853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -2.2500000000000020e-02
    x_8_6     product_lb_181  -2.4822695035436170e-02
    x_8_6     product_ub_182  -4.1401744787857471e-02
    x_8_6     onehot_8_213  1
    x_8_6     stock_lb_280  6
    x_8_6     stock_ub_281  6
    x_8_6     parent_nonstrict_scope_282  5.9999999999999984e-02
    x_8_6     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_181  1
    w_8_6     product_ub_182  1
    w_8_6     normalized_mass_8_214  1
    w_8_6     normalized_ratio_8_215  -6.0000000000000009e-01
    w_8_6     full_original_Gini_340  -9.9535714285714274e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -3.7500000000000012e-02
    x_8_7     product_lb_183  -2.4822695035436170e-02
    x_8_7     product_ub_184  -4.1401744787857471e-02
    x_8_7     onehot_8_213  1
    x_8_7     stock_lb_280  7
    x_8_7     stock_ub_281  7
    x_8_7     parent_nonstrict_scope_282  4.4999999999999991e-02
    x_8_7     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_183  1
    w_8_7     product_ub_184  1
    w_8_7     normalized_mass_8_214  1
    w_8_7     normalized_ratio_8_215  -7.0000000000000007e-01
    w_8_7     full_original_Gini_340  -8.0535714285714270e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.2500000000000012e-02
    x_8_8     product_lb_185  -2.4822695035436170e-02
    x_8_8     product_ub_186  -4.1401744787857471e-02
    x_8_8     onehot_8_213  1
    x_8_8     stock_lb_280  8
    x_8_8     stock_ub_281  8
    x_8_8     parent_nonstrict_scope_282  2.9999999999999992e-02
    x_8_8     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_185  1
    w_8_8     product_ub_186  1
    w_8_8     normalized_mass_8_214  1
    w_8_8     normalized_ratio_8_215  -0.8
    w_8_8     full_original_Gini_340  -6.3250000000000011e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_9     OBJ       -0.0675
    x_8_9     product_lb_187  -2.4822695035436170e-02
    x_8_9     product_ub_188  -4.1401744787857471e-02
    x_8_9     onehot_8_213  1
    x_8_9     stock_lb_280  9
    x_8_9     stock_ub_281  9
    x_8_9     parent_nonstrict_scope_282  1.4999999999999996e-02
    x_8_9     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_187  1
    w_8_9     product_ub_188  1
    w_8_9     normalized_mass_8_214  1
    w_8_9     normalized_ratio_8_215  -0.9
    w_8_9     full_original_Gini_340  -5.0464285714285717e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       -0.0825
    x_8_10    product_lb_189  -2.4822695035436170e-02
    x_8_10    product_ub_190  -4.1401744787857471e-02
    x_8_10    onehot_8_213  1
    x_8_10    stock_lb_280  10
    x_8_10    stock_ub_281  10
    x_8_10    unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_189  1
    w_8_10    product_ub_190  1
    w_8_10    normalized_mass_8_214  1
    w_8_10    normalized_ratio_8_215  -1
    w_8_10    full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       -6.7499999999999991e-02
    x_8_11    product_lb_191  -2.4822695035436170e-02
    x_8_11    product_ub_192  -4.1401744787857471e-02
    x_8_11    onehot_8_213  1
    x_8_11    stock_lb_280  11
    x_8_11    stock_ub_281  11
    x_8_11    parent_nonstrict_scope_282  1.5000000000000013e-02
    x_8_11    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_191  1
    w_8_11    product_ub_192  1
    w_8_11    normalized_mass_8_214  1
    w_8_11    normalized_ratio_8_215  -1.1
    w_8_11    full_original_Gini_340  -6.2464285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       -5.2499999999999977e-02
    x_8_12    product_lb_193  -2.4822695035436170e-02
    x_8_12    product_ub_194  -4.1401744787857471e-02
    x_8_12    onehot_8_213  1
    x_8_12    stock_lb_280  12
    x_8_12    stock_ub_281  12
    x_8_12    parent_nonstrict_scope_282  3.0000000000000027e-02
    x_8_12    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_193  1
    w_8_12    product_ub_194  1
    w_8_12    normalized_mass_8_214  1
    w_8_12    normalized_ratio_8_215  -1.2000000000000002e+00
    w_8_12    full_original_Gini_340  -8.3464285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_13    OBJ       -0.0375
    x_8_13    product_lb_195  -2.4822695035436170e-02
    x_8_13    product_ub_196  -4.1401744787857471e-02
    x_8_13    onehot_8_213  1
    x_8_13    stock_lb_280  13
    x_8_13    stock_ub_281  13
    x_8_13    parent_nonstrict_scope_282  4.5000000000000005e-02
    x_8_13    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_13    product_lb_195  1
    w_8_13    product_ub_196  1
    w_8_13    normalized_mass_8_214  1
    w_8_13    normalized_ratio_8_215  -1.3
    w_8_13    full_original_Gini_340  -1.0946428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_14    OBJ       -2.2499999999999985e-02
    x_8_14    product_lb_197  -2.4822695035436170e-02
    x_8_14    product_ub_198  -4.1401744787857471e-02
    x_8_14    onehot_8_213  1
    x_8_14    stock_lb_280  14
    x_8_14    stock_ub_281  14
    x_8_14    parent_nonstrict_scope_282  6.0000000000000019e-02
    x_8_14    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_14    product_lb_197  1
    w_8_14    product_ub_198  1
    w_8_14    normalized_mass_8_214  1
    w_8_14    normalized_ratio_8_215  -1.4000000000000001e+00
    w_8_14    full_original_Gini_340  -1.3646428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_15    OBJ       -7.5000000000000067e-03
    x_8_15    product_lb_199  -2.4822695035436170e-02
    x_8_15    product_ub_200  -4.1401744787857471e-02
    x_8_15    onehot_8_213  1
    x_8_15    stock_lb_280  15
    x_8_15    stock_ub_281  15
    x_8_15    parent_nonstrict_scope_282  0.075
    MARKER    'MARKER'                 'INTEND'
    w_8_15    product_lb_199  1
    w_8_15    product_ub_200  1
    w_8_15    normalized_mass_8_214  1
    w_8_15    normalized_ratio_8_215  -1.5
    w_8_15    full_original_Gini_340  -1.6346428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_16    OBJ       7.5000000000000067e-03
    x_8_16    product_lb_201  -2.4822695035436170e-02
    x_8_16    product_ub_202  -4.1401744787857471e-02
    x_8_16    onehot_8_213  1
    x_8_16    stock_lb_280  16
    x_8_16    stock_ub_281  16
    x_8_16    parent_nonstrict_scope_282  9.0000000000000011e-02
    x_8_16    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_16    product_lb_201  1
    w_8_16    product_ub_202  1
    w_8_16    normalized_mass_8_214  1
    w_8_16    normalized_ratio_8_215  -1.6
    w_8_16    full_original_Gini_340  -1.9046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_17    OBJ       2.2500000000000020e-02
    x_8_17    product_lb_203  -2.4822695035436170e-02
    x_8_17    product_ub_204  -4.1401744787857471e-02
    x_8_17    onehot_8_213  1
    x_8_17    stock_lb_280  17
    x_8_17    stock_ub_281  17
    x_8_17    parent_nonstrict_scope_282  1.0500000000000002e-01
    x_8_17    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_17    product_lb_203  1
    w_8_17    product_ub_204  1
    w_8_17    normalized_mass_8_214  1
    w_8_17    normalized_ratio_8_215  -1.7000000000000002e+00
    w_8_17    full_original_Gini_340  -2.1746428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_18    OBJ       3.7499999999999992e-02
    x_8_18    product_lb_205  -2.4822695035436170e-02
    x_8_18    product_ub_206  -4.1401744787857471e-02
    x_8_18    onehot_8_213  1
    x_8_18    stock_lb_280  18
    x_8_18    stock_ub_281  18
    x_8_18    parent_nonstrict_scope_282  0.12
    x_8_18    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_18    product_lb_205  1
    w_8_18    product_ub_206  1
    w_8_18    normalized_mass_8_214  1
    w_8_18    normalized_ratio_8_215  -1.8
    w_8_18    full_original_Gini_340  -2.4446428571428580e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_19    OBJ       5.2500000000000005e-02
    x_8_19    product_lb_207  -2.4822695035436170e-02
    x_8_19    product_ub_208  -4.1401744787857471e-02
    x_8_19    onehot_8_213  1
    x_8_19    stock_lb_280  19
    x_8_19    stock_ub_281  19
    x_8_19    parent_nonstrict_scope_282  0.135
    x_8_19    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_19    product_lb_207  1
    w_8_19    product_ub_208  1
    w_8_19    normalized_mass_8_214  1
    w_8_19    normalized_ratio_8_215  -1.9000000000000001e+00
    w_8_19    full_original_Gini_340  -2.7146428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_20    OBJ       6.7499999999999991e-02
    x_8_20    product_lb_209  -2.4822695035436170e-02
    x_8_20    product_ub_210  -4.1401744787857471e-02
    x_8_20    onehot_8_213  1
    x_8_20    stock_lb_280  20
    x_8_20    stock_ub_281  20
    x_8_20    parent_nonstrict_scope_282  0.15
    x_8_20    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_20    product_lb_209  1
    w_8_20    product_ub_210  1
    w_8_20    normalized_mass_8_214  1
    w_8_20    normalized_ratio_8_215  -2
    w_8_20    full_original_Gini_340  -2.9846428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_21    OBJ       0.0825
    x_8_21    product_lb_211  -2.4822695035436170e-02
    x_8_21    product_ub_212  -4.1401744787857471e-02
    x_8_21    onehot_8_213  1
    x_8_21    stock_lb_280  21
    x_8_21    stock_ub_281  21
    x_8_21    parent_nonstrict_scope_282  0.165
    x_8_21    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_21    product_lb_211  1
    w_8_21    product_ub_212  1
    w_8_21    normalized_mass_8_214  1
    w_8_21    normalized_ratio_8_215  -2.1
    w_8_21    full_original_Gini_340  -3.2546428571428578e+01
    rho_8     normalized_ratio_8_215  1
    rho_8     block_pair_pos_285  1
    rho_8     block_pair_neg_286  -1
    rho_8     block_pair_pos_295  1
    rho_8     block_pair_neg_296  -1
    rho_8     block_pair_pos_309  1
    rho_8     block_pair_neg_310  -1
    rho_8     block_pair_pos_317  1
    rho_8     block_pair_neg_318  -1
    rho_8     block_pair_pos_323  -1
    rho_8     block_pair_neg_324  1
    rho_8     block_pair_pos_325  -1
    rho_8     block_pair_neg_326  1
    rho_8     block_pair_pos_331  1
    rho_8     block_pair_neg_332  -1
    rho_8     normalization_339  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_216  -2.4822695035436170e-02
    x_32_0    product_ub_217  -4.1401744787857471e-02
    x_32_0    onehot_32_242  1
    x_32_0    parent_nonstrict_scope_282  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_216  1
    w_32_0    product_ub_217  1
    w_32_0    normalized_mass_32_243  1
    w_32_0    full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_218  -2.4822695035436170e-02
    x_32_1    product_ub_219  -4.1401744787857471e-02
    x_32_1    onehot_32_242  1
    x_32_1    stock_lb_280  1
    x_32_1    stock_ub_281  1
    x_32_1    parent_nonstrict_scope_282  0.03
    x_32_1    unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_218  1
    w_32_1    product_ub_219  1
    w_32_1    normalized_mass_32_243  1
    w_32_1    normalized_ratio_32_244  -0.2
    w_32_1    full_original_Gini_340  -1.8753571428571437e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_220  -2.4822695035436170e-02
    x_32_2    product_ub_221  -4.1401744787857471e-02
    x_32_2    onehot_32_242  1
    x_32_2    stock_lb_280  2
    x_32_2    stock_ub_281  2
    x_32_2    parent_nonstrict_scope_282  0.0225
    x_32_2    unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_220  1
    w_32_2    product_ub_221  1
    w_32_2    normalized_mass_32_243  1
    w_32_2    normalized_ratio_32_244  -0.4
    w_32_2    full_original_Gini_340  -1.3953571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_222  -2.4822695035436170e-02
    x_32_3    product_ub_223  -4.1401744787857471e-02
    x_32_3    onehot_32_242  1
    x_32_3    stock_lb_280  3
    x_32_3    stock_ub_281  3
    x_32_3    parent_nonstrict_scope_282  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_222  1
    w_32_3    product_ub_223  1
    w_32_3    normalized_mass_32_243  1
    w_32_3    normalized_ratio_32_244  -6.0000000000000009e-01
    w_32_3    full_original_Gini_340  -9.9535714285714274e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_224  -2.4822695035436170e-02
    x_32_4    product_ub_225  -4.1401744787857471e-02
    x_32_4    onehot_32_242  1
    x_32_4    stock_lb_280  4
    x_32_4    stock_ub_281  4
    x_32_4    parent_nonstrict_scope_282  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_224  1
    w_32_4    product_ub_225  1
    w_32_4    normalized_mass_32_243  1
    w_32_4    normalized_ratio_32_244  -0.8
    w_32_4    full_original_Gini_340  -6.3250000000000011e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_226  -2.4822695035436170e-02
    x_32_5    product_ub_227  -4.1401744787857471e-02
    x_32_5    onehot_32_242  1
    x_32_5    stock_lb_280  5
    x_32_5    stock_ub_281  5
    x_32_5    unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_226  1
    w_32_5    product_ub_227  1
    w_32_5    normalized_mass_32_243  1
    w_32_5    normalized_ratio_32_244  -1
    w_32_5    full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_228  -2.4822695035436170e-02
    x_32_6    product_ub_229  -4.1401744787857471e-02
    x_32_6    onehot_32_242  1
    x_32_6    stock_lb_280  6
    x_32_6    stock_ub_281  6
    x_32_6    parent_nonstrict_scope_282  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_228  1
    w_32_6    product_ub_229  1
    w_32_6    normalized_mass_32_243  1
    w_32_6    normalized_ratio_32_244  -1.2000000000000002e+00
    w_32_6    full_original_Gini_340  -8.3464285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_230  -2.4822695035436170e-02
    x_32_7    product_ub_231  -4.1401744787857471e-02
    x_32_7    onehot_32_242  1
    x_32_7    stock_lb_280  7
    x_32_7    stock_ub_281  7
    x_32_7    parent_nonstrict_scope_282  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_230  1
    w_32_7    product_ub_231  1
    w_32_7    normalized_mass_32_243  1
    w_32_7    normalized_ratio_32_244  -1.4000000000000001e+00
    w_32_7    full_original_Gini_340  -1.3646428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_232  -2.4822695035436170e-02
    x_32_8    product_ub_233  -4.1401744787857471e-02
    x_32_8    onehot_32_242  1
    x_32_8    stock_lb_280  8
    x_32_8    stock_ub_281  8
    x_32_8    parent_nonstrict_scope_282  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_232  1
    w_32_8    product_ub_233  1
    w_32_8    normalized_mass_32_243  1
    w_32_8    normalized_ratio_32_244  -1.6
    w_32_8    full_original_Gini_340  -1.9046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_234  -2.4822695035436170e-02
    x_32_9    product_ub_235  -4.1401744787857471e-02
    x_32_9    onehot_32_242  1
    x_32_9    stock_lb_280  9
    x_32_9    stock_ub_281  9
    x_32_9    parent_nonstrict_scope_282  0.03
    x_32_9    unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_234  1
    w_32_9    product_ub_235  1
    w_32_9    normalized_mass_32_243  1
    w_32_9    normalized_ratio_32_244  -1.8
    w_32_9    full_original_Gini_340  -2.4446428571428580e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_236  -2.4822695035436170e-02
    x_32_10   product_ub_237  -4.1401744787857471e-02
    x_32_10   onehot_32_242  1
    x_32_10   stock_lb_280  10
    x_32_10   stock_ub_281  10
    x_32_10   parent_nonstrict_scope_282  0.0375
    x_32_10   unique_nonzero_owner_443  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_236  1
    w_32_10   product_ub_237  1
    w_32_10   normalized_mass_32_243  1
    w_32_10   normalized_ratio_32_244  -2
    w_32_10   full_original_Gini_340  -2.9846428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_238  -2.4822695035436170e-02
    x_32_11   product_ub_239  -4.1401744787857471e-02
    x_32_11   onehot_32_242  1
    x_32_11   stock_lb_280  11
    x_32_11   stock_ub_281  11
    x_32_11   parent_nonstrict_scope_282  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_444  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_238  1
    w_32_11   product_ub_239  1
    w_32_11   normalized_mass_32_243  1
    w_32_11   normalized_ratio_32_244  -2.2
    w_32_11   full_original_Gini_340  -3.5246428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_240  -2.4822695035436170e-02
    x_32_12   product_ub_241  -4.1401744787857471e-02
    x_32_12   onehot_32_242  1
    x_32_12   stock_lb_280  12
    x_32_12   stock_ub_281  12
    x_32_12   parent_nonstrict_scope_282  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_445  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_240  1
    w_32_12   product_ub_241  1
    w_32_12   normalized_mass_32_243  1
    w_32_12   normalized_ratio_32_244  -2.4000000000000004e+00
    w_32_12   full_original_Gini_340  -4.0646428571428565e+01
    rho_32    normalized_ratio_32_244  1
    rho_32    block_pair_pos_289  1
    rho_32    block_pair_neg_290  -1
    rho_32    block_pair_pos_301  1
    rho_32    block_pair_neg_302  -1
    rho_32    block_pair_pos_315  1
    rho_32    block_pair_neg_316  -1
    rho_32    block_pair_pos_321  1
    rho_32    block_pair_neg_322  -1
    rho_32    block_pair_pos_325  1
    rho_32    block_pair_neg_326  -1
    rho_32    block_pair_pos_335  1
    rho_32    block_pair_neg_336  -1
    rho_32    block_pair_pos_337  -1
    rho_32    block_pair_neg_338  1
    rho_32    normalization_339  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       0.048
    x_14_0    product_lb_245  -2.4822695035436170e-02
    x_14_0    product_ub_246  -4.1401744787857471e-02
    x_14_0    onehot_14_277  1
    x_14_0    parent_nonstrict_scope_282  0.096
    x_14_0    unique_nonzero_owner_446  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_245  1
    w_14_0    product_ub_246  1
    w_14_0    normalized_mass_14_278  1
    w_14_0    full_original_Gini_340  -2.4153571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.6000000000000004e-02
    x_14_1    product_lb_247  -2.4822695035436170e-02
    x_14_1    product_ub_248  -4.1401744787857471e-02
    x_14_1    onehot_14_277  1
    x_14_1    stock_lb_280  1
    x_14_1    stock_ub_281  1
    x_14_1    parent_nonstrict_scope_282  0.084
    x_14_1    unique_nonzero_owner_447  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_247  1
    w_14_1    product_ub_248  1
    w_14_1    normalized_mass_14_278  1
    w_14_1    normalized_ratio_14_279  -0.125
    w_14_1    full_original_Gini_340  -2.0778571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       2.4000000000000007e-02
    x_14_2    product_lb_249  -2.4822695035436170e-02
    x_14_2    product_ub_250  -4.1401744787857471e-02
    x_14_2    onehot_14_277  1
    x_14_2    stock_lb_280  2
    x_14_2    stock_ub_281  2
    x_14_2    parent_nonstrict_scope_282  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_249  1
    w_14_2    product_ub_250  1
    w_14_2    normalized_mass_14_278  1
    w_14_2    normalized_ratio_14_279  -0.25
    w_14_2    full_original_Gini_340  -1.7403571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       1.1999999999999997e-02
    x_14_3    product_lb_251  -2.4822695035436170e-02
    x_14_3    product_ub_252  -4.1401744787857471e-02
    x_14_3    onehot_14_277  1
    x_14_3    stock_lb_280  3
    x_14_3    stock_ub_281  3
    x_14_3    parent_nonstrict_scope_282  0.06
    x_14_3    unique_nonzero_owner_448  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_251  1
    w_14_3    product_ub_252  1
    w_14_3    normalized_mass_14_278  1
    w_14_3    normalized_ratio_14_279  -0.375
    w_14_3    full_original_Gini_340  -1.4528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_4    product_lb_253  -2.4822695035436170e-02
    x_14_4    product_ub_254  -4.1401744787857471e-02
    x_14_4    onehot_14_277  1
    x_14_4    stock_lb_280  4
    x_14_4    stock_ub_281  4
    x_14_4    parent_nonstrict_scope_282  0.048
    x_14_4    unique_nonzero_owner_449  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_253  1
    w_14_4    product_ub_254  1
    w_14_4    normalized_mass_14_278  1
    w_14_4    normalized_ratio_14_279  -0.5
    w_14_4    full_original_Gini_340  -1.1853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -1.1999999999999997e-02
    x_14_5    product_lb_255  -2.4822695035436170e-02
    x_14_5    product_ub_256  -4.1401744787857471e-02
    x_14_5    onehot_14_277  1
    x_14_5    stock_lb_280  5
    x_14_5    stock_ub_281  5
    x_14_5    parent_nonstrict_scope_282  3.6000000000000004e-02
    x_14_5    unique_nonzero_owner_450  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_255  1
    w_14_5    product_ub_256  1
    w_14_5    normalized_mass_14_278  1
    w_14_5    normalized_ratio_14_279  -0.625
    w_14_5    full_original_Gini_340  -9.47857142857143
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -0.024
    x_14_6    product_lb_257  -2.4822695035436170e-02
    x_14_6    product_ub_258  -4.1401744787857471e-02
    x_14_6    onehot_14_277  1
    x_14_6    stock_lb_280  6
    x_14_6    stock_ub_281  6
    x_14_6    parent_nonstrict_scope_282  0.024
    x_14_6    unique_nonzero_owner_451  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_257  1
    w_14_6    product_ub_258  1
    w_14_6    normalized_mass_14_278  1
    w_14_6    normalized_ratio_14_279  -0.75
    w_14_6    full_original_Gini_340  -7.1749999999999989e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -3.6000000000000004e-02
    x_14_7    product_lb_259  -2.4822695035436170e-02
    x_14_7    product_ub_260  -4.1401744787857471e-02
    x_14_7    onehot_14_277  1
    x_14_7    stock_lb_280  7
    x_14_7    stock_ub_281  7
    x_14_7    parent_nonstrict_scope_282  0.012
    x_14_7    unique_nonzero_owner_452  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_259  1
    w_14_7    product_ub_260  1
    w_14_7    normalized_mass_14_278  1
    w_14_7    normalized_ratio_14_279  -0.875
    w_14_7    full_original_Gini_340  -5.2714285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -0.048
    x_14_8    product_lb_261  -2.4822695035436170e-02
    x_14_8    product_ub_262  -4.1401744787857471e-02
    x_14_8    onehot_14_277  1
    x_14_8    stock_lb_280  8
    x_14_8    stock_ub_281  8
    x_14_8    unique_nonzero_owner_453  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_261  1
    w_14_8    product_ub_262  1
    w_14_8    normalized_mass_14_278  1
    w_14_8    normalized_ratio_14_279  -1
    w_14_8    full_original_Gini_340  -4.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -3.6000000000000004e-02
    x_14_9    product_lb_263  -2.4822695035436170e-02
    x_14_9    product_ub_264  -4.1401744787857471e-02
    x_14_9    onehot_14_277  1
    x_14_9    stock_lb_280  9
    x_14_9    stock_ub_281  9
    x_14_9    parent_nonstrict_scope_282  0.012
    x_14_9    unique_nonzero_owner_454  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_263  1
    w_14_9    product_ub_264  1
    w_14_9    normalized_mass_14_278  1
    w_14_9    normalized_ratio_14_279  -1.125
    w_14_9    full_original_Gini_340  -6.7714285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -0.024
    x_14_10   product_lb_265  -2.4822695035436170e-02
    x_14_10   product_ub_266  -4.1401744787857471e-02
    x_14_10   onehot_14_277  1
    x_14_10   stock_lb_280  10
    x_14_10   stock_ub_281  10
    x_14_10   parent_nonstrict_scope_282  0.024
    x_14_10   unique_nonzero_owner_455  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_265  1
    w_14_10   product_ub_266  1
    w_14_10   normalized_mass_14_278  1
    w_14_10   normalized_ratio_14_279  -1.25
    w_14_10   full_original_Gini_340  -9.59642857142857
    MARKER    'MARKER'                 'INTORG'
    x_14_11   OBJ       -1.1999999999999997e-02
    x_14_11   product_lb_267  -2.4822695035436170e-02
    x_14_11   product_ub_268  -4.1401744787857471e-02
    x_14_11   onehot_14_277  1
    x_14_11   stock_lb_280  11
    x_14_11   stock_ub_281  11
    x_14_11   parent_nonstrict_scope_282  3.6000000000000004e-02
    x_14_11   unique_nonzero_owner_456  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_267  1
    w_14_11   product_ub_268  1
    w_14_11   normalized_mass_14_278  1
    w_14_11   normalized_ratio_14_279  -1.375
    w_14_11   full_original_Gini_340  -1.2971428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   product_lb_269  -2.4822695035436170e-02
    x_14_12   product_ub_270  -4.1401744787857471e-02
    x_14_12   onehot_14_277  1
    x_14_12   stock_lb_280  12
    x_14_12   stock_ub_281  12
    x_14_12   parent_nonstrict_scope_282  0.048
    x_14_12   unique_nonzero_owner_457  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_269  1
    w_14_12   product_ub_270  1
    w_14_12   normalized_mass_14_278  1
    w_14_12   normalized_ratio_14_279  -1.5
    w_14_12   full_original_Gini_340  -1.6346428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       1.1999999999999997e-02
    x_14_13   product_lb_271  -2.4822695035436170e-02
    x_14_13   product_ub_272  -4.1401744787857471e-02
    x_14_13   onehot_14_277  1
    x_14_13   stock_lb_280  13
    x_14_13   stock_ub_281  13
    x_14_13   parent_nonstrict_scope_282  0.06
    x_14_13   unique_nonzero_owner_458  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_271  1
    w_14_13   product_ub_272  1
    w_14_13   normalized_mass_14_278  1
    w_14_13   normalized_ratio_14_279  -1.625
    w_14_13   full_original_Gini_340  -1.9721428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       2.4000000000000007e-02
    x_14_14   product_lb_273  -2.4822695035436170e-02
    x_14_14   product_ub_274  -4.1401744787857471e-02
    x_14_14   onehot_14_277  1
    x_14_14   stock_lb_280  14
    x_14_14   stock_ub_281  14
    x_14_14   parent_nonstrict_scope_282  7.2000000000000008e-02
    x_14_14   unique_nonzero_owner_459  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_273  1
    w_14_14   product_ub_274  1
    w_14_14   normalized_mass_14_278  1
    w_14_14   normalized_ratio_14_279  -1.75
    w_14_14   full_original_Gini_340  -2.3096428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       3.6000000000000004e-02
    x_14_15   product_lb_275  -2.4822695035436170e-02
    x_14_15   product_ub_276  -4.1401744787857471e-02
    x_14_15   onehot_14_277  1
    x_14_15   stock_lb_280  15
    x_14_15   stock_ub_281  15
    x_14_15   parent_nonstrict_scope_282  0.084
    x_14_15   unique_nonzero_owner_460  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_275  1
    w_14_15   product_ub_276  1
    w_14_15   normalized_mass_14_278  1
    w_14_15   normalized_ratio_14_279  -1.875
    w_14_15   full_original_Gini_340  -2.6471428571428572e+01
    rho_14    normalized_ratio_14_279  1
    rho_14    block_pair_pos_287  1
    rho_14    block_pair_neg_288  -1
    rho_14    block_pair_pos_297  1
    rho_14    block_pair_neg_298  -1
    rho_14    block_pair_pos_311  1
    rho_14    block_pair_neg_312  -1
    rho_14    block_pair_pos_319  1
    rho_14    block_pair_neg_320  -1
    rho_14    block_pair_pos_323  1
    rho_14    block_pair_neg_324  -1
    rho_14    block_pair_pos_333  1
    rho_14    block_pair_neg_334  -1
    rho_14    block_pair_pos_337  1
    rho_14    block_pair_neg_338  -1
    rho_14    normalization_339  1
    a_5_2     block_pair_pos_305  1
    a_5_2     block_pair_neg_306  1
    a_5_2     full_original_Gini_340  -1
    a_5_31    block_pair_pos_313  1
    a_5_31    block_pair_neg_314  1
    a_5_31    full_original_Gini_340  -1
    a_5_1     block_pair_pos_303  1
    a_5_1     block_pair_neg_304  1
    a_5_1     full_original_Gini_340  -1
    a_5_6     block_pair_pos_307  1
    a_5_6     block_pair_neg_308  1
    a_5_6     full_original_Gini_340  -1
    a_5_8     block_pair_pos_309  1
    a_5_8     block_pair_neg_310  1
    a_5_8     full_original_Gini_340  -1
    a_5_32    block_pair_pos_315  1
    a_5_32    block_pair_neg_316  1
    a_5_32    full_original_Gini_340  -1
    a_5_14    block_pair_pos_311  1
    a_5_14    block_pair_neg_312  1
    a_5_14    full_original_Gini_340  -1
    a_2_31    block_pair_pos_299  1
    a_2_31    block_pair_neg_300  1
    a_2_31    full_original_Gini_340  -1
    a_2_1     block_pair_pos_291  1
    a_2_1     block_pair_neg_292  1
    a_2_1     full_original_Gini_340  -1
    a_2_6     block_pair_pos_293  1
    a_2_6     block_pair_neg_294  1
    a_2_6     full_original_Gini_340  -1
    a_2_8     block_pair_pos_295  1
    a_2_8     block_pair_neg_296  1
    a_2_8     full_original_Gini_340  -1
    a_2_32    block_pair_pos_301  1
    a_2_32    block_pair_neg_302  1
    a_2_32    full_original_Gini_340  -1
    a_2_14    block_pair_pos_297  1
    a_2_14    block_pair_neg_298  1
    a_2_14    full_original_Gini_340  -1
    a_31_1    block_pair_pos_327  1
    a_31_1    block_pair_neg_328  1
    a_31_1    full_original_Gini_340  -1
    a_31_6    block_pair_pos_329  1
    a_31_6    block_pair_neg_330  1
    a_31_6    full_original_Gini_340  -1
    a_31_8    block_pair_pos_331  1
    a_31_8    block_pair_neg_332  1
    a_31_8    full_original_Gini_340  -1
    a_31_32   block_pair_pos_335  1
    a_31_32   block_pair_neg_336  1
    a_31_32   full_original_Gini_340  -1
    a_31_14   block_pair_pos_333  1
    a_31_14   block_pair_neg_334  1
    a_31_14   full_original_Gini_340  -1
    a_1_6     block_pair_pos_283  1
    a_1_6     block_pair_neg_284  1
    a_1_6     full_original_Gini_340  -1
    a_1_8     block_pair_pos_285  1
    a_1_8     block_pair_neg_286  1
    a_1_8     full_original_Gini_340  -1
    a_1_32    block_pair_pos_289  1
    a_1_32    block_pair_neg_290  1
    a_1_32    full_original_Gini_340  -1
    a_1_14    block_pair_pos_287  1
    a_1_14    block_pair_neg_288  1
    a_1_14    full_original_Gini_340  -1
    a_6_8     block_pair_pos_317  1
    a_6_8     block_pair_neg_318  1
    a_6_8     full_original_Gini_340  -1
    a_6_32    block_pair_pos_321  1
    a_6_32    block_pair_neg_322  1
    a_6_32    full_original_Gini_340  -1
    a_6_14    block_pair_pos_319  1
    a_6_14    block_pair_neg_320  1
    a_6_14    full_original_Gini_340  -1
    a_8_32    block_pair_pos_325  1
    a_8_32    block_pair_neg_326  1
    a_8_32    full_original_Gini_340  -1
    a_8_14    block_pair_pos_323  1
    a_8_14    block_pair_neg_324  1
    a_8_14    full_original_Gini_340  -1
    a_32_14   block_pair_pos_337  1
    a_32_14   block_pair_neg_338  1
    a_32_14   full_original_Gini_340  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_5_0  unique_nonzero_owner_341  1
    service_0_5_0  service_visit_def_841  1
    service_0_5_0  free_load_conservation_842  -2
    service_0_5_0  original_T_including_depot_unload_889  240
    service_0_5_1  unique_nonzero_owner_342  1
    service_0_5_1  service_visit_def_841  1
    service_0_5_1  free_load_conservation_842  -1
    service_0_5_1  original_T_including_depot_unload_889  120
    service_0_5_3  unique_nonzero_owner_343  1
    service_0_5_3  service_visit_def_841  1
    service_0_5_3  free_load_conservation_842  1
    service_0_5_4  unique_nonzero_owner_344  1
    service_0_5_4  service_visit_def_841  1
    service_0_5_4  free_load_conservation_842  2
    service_0_5_5  unique_nonzero_owner_345  1
    service_0_5_5  service_visit_def_841  1
    service_0_5_5  free_load_conservation_842  3
    service_0_5_6  unique_nonzero_owner_346  1
    service_0_5_6  service_visit_def_841  1
    service_0_5_6  free_load_conservation_842  4
    service_0_5_7  unique_nonzero_owner_347  1
    service_0_5_7  service_visit_def_841  1
    service_0_5_7  free_load_conservation_842  5
    service_0_5_8  unique_nonzero_owner_348  1
    service_0_5_8  service_visit_def_841  1
    service_0_5_8  free_load_conservation_842  6
    service_0_5_9  unique_nonzero_owner_349  1
    service_0_5_9  service_visit_def_841  1
    service_0_5_9  free_load_conservation_842  7
    service_0_5_10  unique_nonzero_owner_350  1
    service_0_5_10  service_visit_def_841  1
    service_0_5_10  free_load_conservation_842  8
    service_0_5_11  unique_nonzero_owner_351  1
    service_0_5_11  service_visit_def_841  1
    service_0_5_11  free_load_conservation_842  9
    service_0_5_12  unique_nonzero_owner_352  1
    service_0_5_12  service_visit_def_841  1
    service_0_5_12  free_load_conservation_842  10
    service_0_5_13  unique_nonzero_owner_353  1
    service_0_5_13  service_visit_def_841  1
    service_0_5_13  free_load_conservation_842  11
    service_0_5_14  unique_nonzero_owner_354  1
    service_0_5_14  service_visit_def_841  1
    service_0_5_14  free_load_conservation_842  12
    service_0_5_15  unique_nonzero_owner_355  1
    service_0_5_15  service_visit_def_841  1
    service_0_5_15  free_load_conservation_842  13
    service_0_5_16  unique_nonzero_owner_356  1
    service_0_5_16  service_visit_def_841  1
    service_0_5_16  free_load_conservation_842  14
    service_1_5_0  unique_nonzero_owner_341  1
    service_1_5_0  service_visit_def_1213  1
    service_1_5_0  free_load_conservation_1214  -2
    service_1_5_0  original_T_including_depot_unload_1260  240
    service_1_5_1  unique_nonzero_owner_342  1
    service_1_5_1  service_visit_def_1213  1
    service_1_5_1  free_load_conservation_1214  -1
    service_1_5_1  original_T_including_depot_unload_1260  120
    service_1_5_3  unique_nonzero_owner_343  1
    service_1_5_3  service_visit_def_1213  1
    service_1_5_3  free_load_conservation_1214  1
    service_1_5_4  unique_nonzero_owner_344  1
    service_1_5_4  service_visit_def_1213  1
    service_1_5_4  free_load_conservation_1214  2
    service_1_5_5  unique_nonzero_owner_345  1
    service_1_5_5  service_visit_def_1213  1
    service_1_5_5  free_load_conservation_1214  3
    service_1_5_6  unique_nonzero_owner_346  1
    service_1_5_6  service_visit_def_1213  1
    service_1_5_6  free_load_conservation_1214  4
    service_1_5_7  unique_nonzero_owner_347  1
    service_1_5_7  service_visit_def_1213  1
    service_1_5_7  free_load_conservation_1214  5
    service_1_5_8  unique_nonzero_owner_348  1
    service_1_5_8  service_visit_def_1213  1
    service_1_5_8  free_load_conservation_1214  6
    service_1_5_9  unique_nonzero_owner_349  1
    service_1_5_9  service_visit_def_1213  1
    service_1_5_9  free_load_conservation_1214  7
    service_1_5_10  unique_nonzero_owner_350  1
    service_1_5_10  service_visit_def_1213  1
    service_1_5_10  free_load_conservation_1214  8
    service_1_5_11  unique_nonzero_owner_351  1
    service_1_5_11  service_visit_def_1213  1
    service_1_5_11  free_load_conservation_1214  9
    service_1_5_12  unique_nonzero_owner_352  1
    service_1_5_12  service_visit_def_1213  1
    service_1_5_12  free_load_conservation_1214  10
    service_1_5_13  unique_nonzero_owner_353  1
    service_1_5_13  service_visit_def_1213  1
    service_1_5_13  free_load_conservation_1214  11
    service_1_5_14  unique_nonzero_owner_354  1
    service_1_5_14  service_visit_def_1213  1
    service_1_5_14  free_load_conservation_1214  12
    service_1_5_15  unique_nonzero_owner_355  1
    service_1_5_15  service_visit_def_1213  1
    service_1_5_15  free_load_conservation_1214  13
    service_1_5_16  unique_nonzero_owner_356  1
    service_1_5_16  service_visit_def_1213  1
    service_1_5_16  free_load_conservation_1214  14
    service_2_5_0  unique_nonzero_owner_341  1
    service_2_5_0  service_visit_def_1584  1
    service_2_5_0  free_load_conservation_1585  -2
    service_2_5_0  original_T_including_depot_unload_1631  240
    service_2_5_1  unique_nonzero_owner_342  1
    service_2_5_1  service_visit_def_1584  1
    service_2_5_1  free_load_conservation_1585  -1
    service_2_5_1  original_T_including_depot_unload_1631  120
    service_2_5_3  unique_nonzero_owner_343  1
    service_2_5_3  service_visit_def_1584  1
    service_2_5_3  free_load_conservation_1585  1
    service_2_5_4  unique_nonzero_owner_344  1
    service_2_5_4  service_visit_def_1584  1
    service_2_5_4  free_load_conservation_1585  2
    service_2_5_5  unique_nonzero_owner_345  1
    service_2_5_5  service_visit_def_1584  1
    service_2_5_5  free_load_conservation_1585  3
    service_2_5_6  unique_nonzero_owner_346  1
    service_2_5_6  service_visit_def_1584  1
    service_2_5_6  free_load_conservation_1585  4
    service_2_5_7  unique_nonzero_owner_347  1
    service_2_5_7  service_visit_def_1584  1
    service_2_5_7  free_load_conservation_1585  5
    service_2_5_8  unique_nonzero_owner_348  1
    service_2_5_8  service_visit_def_1584  1
    service_2_5_8  free_load_conservation_1585  6
    service_2_5_9  unique_nonzero_owner_349  1
    service_2_5_9  service_visit_def_1584  1
    service_2_5_9  free_load_conservation_1585  7
    service_2_5_10  unique_nonzero_owner_350  1
    service_2_5_10  service_visit_def_1584  1
    service_2_5_10  free_load_conservation_1585  8
    service_2_5_11  unique_nonzero_owner_351  1
    service_2_5_11  service_visit_def_1584  1
    service_2_5_11  free_load_conservation_1585  9
    service_2_5_12  unique_nonzero_owner_352  1
    service_2_5_12  service_visit_def_1584  1
    service_2_5_12  free_load_conservation_1585  10
    service_2_5_13  unique_nonzero_owner_353  1
    service_2_5_13  service_visit_def_1584  1
    service_2_5_13  free_load_conservation_1585  11
    service_2_5_14  unique_nonzero_owner_354  1
    service_2_5_14  service_visit_def_1584  1
    service_2_5_14  free_load_conservation_1585  12
    service_2_5_15  unique_nonzero_owner_355  1
    service_2_5_15  service_visit_def_1584  1
    service_2_5_15  free_load_conservation_1585  13
    service_2_5_16  unique_nonzero_owner_356  1
    service_2_5_16  service_visit_def_1584  1
    service_2_5_16  free_load_conservation_1585  14
    service_0_2_1  unique_nonzero_owner_357  1
    service_0_2_1  service_visit_def_847  1
    service_0_2_1  free_load_conservation_848  1
    service_0_2_2  unique_nonzero_owner_358  1
    service_0_2_2  service_visit_def_847  1
    service_0_2_2  free_load_conservation_848  2
    service_0_2_3  unique_nonzero_owner_359  1
    service_0_2_3  service_visit_def_847  1
    service_0_2_3  free_load_conservation_848  3
    service_0_2_4  unique_nonzero_owner_360  1
    service_0_2_4  service_visit_def_847  1
    service_0_2_4  free_load_conservation_848  4
    service_0_2_5  unique_nonzero_owner_361  1
    service_0_2_5  service_visit_def_847  1
    service_0_2_5  free_load_conservation_848  5
    service_0_2_6  unique_nonzero_owner_362  1
    service_0_2_6  service_visit_def_847  1
    service_0_2_6  free_load_conservation_848  6
    service_0_2_7  unique_nonzero_owner_363  1
    service_0_2_7  service_visit_def_847  1
    service_0_2_7  free_load_conservation_848  7
    service_0_2_8  unique_nonzero_owner_364  1
    service_0_2_8  service_visit_def_847  1
    service_0_2_8  free_load_conservation_848  8
    service_0_2_9  unique_nonzero_owner_365  1
    service_0_2_9  service_visit_def_847  1
    service_0_2_9  free_load_conservation_848  9
    service_0_2_10  unique_nonzero_owner_366  1
    service_0_2_10  service_visit_def_847  1
    service_0_2_10  free_load_conservation_848  10
    service_0_2_11  unique_nonzero_owner_367  1
    service_0_2_11  service_visit_def_847  1
    service_0_2_11  free_load_conservation_848  11
    service_0_2_12  unique_nonzero_owner_368  1
    service_0_2_12  service_visit_def_847  1
    service_0_2_12  free_load_conservation_848  12
    service_0_2_13  unique_nonzero_owner_369  1
    service_0_2_13  service_visit_def_847  1
    service_0_2_13  free_load_conservation_848  13
    service_0_2_14  unique_nonzero_owner_370  1
    service_0_2_14  service_visit_def_847  1
    service_0_2_14  free_load_conservation_848  14
    service_0_2_15  unique_nonzero_owner_371  1
    service_0_2_15  service_visit_def_847  1
    service_0_2_15  free_load_conservation_848  15
    service_1_2_1  unique_nonzero_owner_357  1
    service_1_2_1  service_visit_def_1219  1
    service_1_2_1  free_load_conservation_1220  1
    service_1_2_2  unique_nonzero_owner_358  1
    service_1_2_2  service_visit_def_1219  1
    service_1_2_2  free_load_conservation_1220  2
    service_1_2_3  unique_nonzero_owner_359  1
    service_1_2_3  service_visit_def_1219  1
    service_1_2_3  free_load_conservation_1220  3
    service_1_2_4  unique_nonzero_owner_360  1
    service_1_2_4  service_visit_def_1219  1
    service_1_2_4  free_load_conservation_1220  4
    service_1_2_5  unique_nonzero_owner_361  1
    service_1_2_5  service_visit_def_1219  1
    service_1_2_5  free_load_conservation_1220  5
    service_1_2_6  unique_nonzero_owner_362  1
    service_1_2_6  service_visit_def_1219  1
    service_1_2_6  free_load_conservation_1220  6
    service_1_2_7  unique_nonzero_owner_363  1
    service_1_2_7  service_visit_def_1219  1
    service_1_2_7  free_load_conservation_1220  7
    service_1_2_8  unique_nonzero_owner_364  1
    service_1_2_8  service_visit_def_1219  1
    service_1_2_8  free_load_conservation_1220  8
    service_1_2_9  unique_nonzero_owner_365  1
    service_1_2_9  service_visit_def_1219  1
    service_1_2_9  free_load_conservation_1220  9
    service_1_2_10  unique_nonzero_owner_366  1
    service_1_2_10  service_visit_def_1219  1
    service_1_2_10  free_load_conservation_1220  10
    service_1_2_11  unique_nonzero_owner_367  1
    service_1_2_11  service_visit_def_1219  1
    service_1_2_11  free_load_conservation_1220  11
    service_1_2_12  unique_nonzero_owner_368  1
    service_1_2_12  service_visit_def_1219  1
    service_1_2_12  free_load_conservation_1220  12
    service_1_2_13  unique_nonzero_owner_369  1
    service_1_2_13  service_visit_def_1219  1
    service_1_2_13  free_load_conservation_1220  13
    service_1_2_14  unique_nonzero_owner_370  1
    service_1_2_14  service_visit_def_1219  1
    service_1_2_14  free_load_conservation_1220  14
    service_1_2_15  unique_nonzero_owner_371  1
    service_1_2_15  service_visit_def_1219  1
    service_1_2_15  free_load_conservation_1220  15
    service_2_2_1  unique_nonzero_owner_357  1
    service_2_2_1  service_visit_def_1590  1
    service_2_2_1  free_load_conservation_1591  1
    service_2_2_2  unique_nonzero_owner_358  1
    service_2_2_2  service_visit_def_1590  1
    service_2_2_2  free_load_conservation_1591  2
    service_2_2_3  unique_nonzero_owner_359  1
    service_2_2_3  service_visit_def_1590  1
    service_2_2_3  free_load_conservation_1591  3
    service_2_2_4  unique_nonzero_owner_360  1
    service_2_2_4  service_visit_def_1590  1
    service_2_2_4  free_load_conservation_1591  4
    service_2_2_5  unique_nonzero_owner_361  1
    service_2_2_5  service_visit_def_1590  1
    service_2_2_5  free_load_conservation_1591  5
    service_2_2_6  unique_nonzero_owner_362  1
    service_2_2_6  service_visit_def_1590  1
    service_2_2_6  free_load_conservation_1591  6
    service_2_2_7  unique_nonzero_owner_363  1
    service_2_2_7  service_visit_def_1590  1
    service_2_2_7  free_load_conservation_1591  7
    service_2_2_8  unique_nonzero_owner_364  1
    service_2_2_8  service_visit_def_1590  1
    service_2_2_8  free_load_conservation_1591  8
    service_2_2_9  unique_nonzero_owner_365  1
    service_2_2_9  service_visit_def_1590  1
    service_2_2_9  free_load_conservation_1591  9
    service_2_2_10  unique_nonzero_owner_366  1
    service_2_2_10  service_visit_def_1590  1
    service_2_2_10  free_load_conservation_1591  10
    service_2_2_11  unique_nonzero_owner_367  1
    service_2_2_11  service_visit_def_1590  1
    service_2_2_11  free_load_conservation_1591  11
    service_2_2_12  unique_nonzero_owner_368  1
    service_2_2_12  service_visit_def_1590  1
    service_2_2_12  free_load_conservation_1591  12
    service_2_2_13  unique_nonzero_owner_369  1
    service_2_2_13  service_visit_def_1590  1
    service_2_2_13  free_load_conservation_1591  13
    service_2_2_14  unique_nonzero_owner_370  1
    service_2_2_14  service_visit_def_1590  1
    service_2_2_14  free_load_conservation_1591  14
    service_2_2_15  unique_nonzero_owner_371  1
    service_2_2_15  service_visit_def_1590  1
    service_2_2_15  free_load_conservation_1591  15
    service_0_31_0  unique_nonzero_owner_372  1
    service_0_31_0  service_visit_def_853  1
    service_0_31_0  free_load_conservation_854  -2
    service_0_31_0  original_T_including_depot_unload_889  240
    service_0_31_1  unique_nonzero_owner_373  1
    service_0_31_1  service_visit_def_853  1
    service_0_31_1  free_load_conservation_854  -1
    service_0_31_1  original_T_including_depot_unload_889  120
    service_0_31_3  unique_nonzero_owner_374  1
    service_0_31_3  service_visit_def_853  1
    service_0_31_3  free_load_conservation_854  1
    service_0_31_4  unique_nonzero_owner_375  1
    service_0_31_4  service_visit_def_853  1
    service_0_31_4  free_load_conservation_854  2
    service_0_31_5  unique_nonzero_owner_376  1
    service_0_31_5  service_visit_def_853  1
    service_0_31_5  free_load_conservation_854  3
    service_0_31_6  unique_nonzero_owner_377  1
    service_0_31_6  service_visit_def_853  1
    service_0_31_6  free_load_conservation_854  4
    service_0_31_7  unique_nonzero_owner_378  1
    service_0_31_7  service_visit_def_853  1
    service_0_31_7  free_load_conservation_854  5
    service_0_31_8  unique_nonzero_owner_379  1
    service_0_31_8  service_visit_def_853  1
    service_0_31_8  free_load_conservation_854  6
    service_0_31_9  unique_nonzero_owner_380  1
    service_0_31_9  service_visit_def_853  1
    service_0_31_9  free_load_conservation_854  7
    service_0_31_10  unique_nonzero_owner_381  1
    service_0_31_10  service_visit_def_853  1
    service_0_31_10  free_load_conservation_854  8
    service_0_31_11  unique_nonzero_owner_382  1
    service_0_31_11  service_visit_def_853  1
    service_0_31_11  free_load_conservation_854  9
    service_0_31_12  unique_nonzero_owner_383  1
    service_0_31_12  service_visit_def_853  1
    service_0_31_12  free_load_conservation_854  10
    service_1_31_0  unique_nonzero_owner_372  1
    service_1_31_0  service_visit_def_1225  1
    service_1_31_0  free_load_conservation_1226  -2
    service_1_31_0  original_T_including_depot_unload_1260  240
    service_1_31_1  unique_nonzero_owner_373  1
    service_1_31_1  service_visit_def_1225  1
    service_1_31_1  free_load_conservation_1226  -1
    service_1_31_1  original_T_including_depot_unload_1260  120
    service_1_31_3  unique_nonzero_owner_374  1
    service_1_31_3  service_visit_def_1225  1
    service_1_31_3  free_load_conservation_1226  1
    service_1_31_4  unique_nonzero_owner_375  1
    service_1_31_4  service_visit_def_1225  1
    service_1_31_4  free_load_conservation_1226  2
    service_1_31_5  unique_nonzero_owner_376  1
    service_1_31_5  service_visit_def_1225  1
    service_1_31_5  free_load_conservation_1226  3
    service_1_31_6  unique_nonzero_owner_377  1
    service_1_31_6  service_visit_def_1225  1
    service_1_31_6  free_load_conservation_1226  4
    service_1_31_7  unique_nonzero_owner_378  1
    service_1_31_7  service_visit_def_1225  1
    service_1_31_7  free_load_conservation_1226  5
    service_1_31_8  unique_nonzero_owner_379  1
    service_1_31_8  service_visit_def_1225  1
    service_1_31_8  free_load_conservation_1226  6
    service_1_31_9  unique_nonzero_owner_380  1
    service_1_31_9  service_visit_def_1225  1
    service_1_31_9  free_load_conservation_1226  7
    service_1_31_10  unique_nonzero_owner_381  1
    service_1_31_10  service_visit_def_1225  1
    service_1_31_10  free_load_conservation_1226  8
    service_1_31_11  unique_nonzero_owner_382  1
    service_1_31_11  service_visit_def_1225  1
    service_1_31_11  free_load_conservation_1226  9
    service_1_31_12  unique_nonzero_owner_383  1
    service_1_31_12  service_visit_def_1225  1
    service_1_31_12  free_load_conservation_1226  10
    service_2_31_0  unique_nonzero_owner_372  1
    service_2_31_0  service_visit_def_1596  1
    service_2_31_0  free_load_conservation_1597  -2
    service_2_31_0  original_T_including_depot_unload_1631  240
    service_2_31_1  unique_nonzero_owner_373  1
    service_2_31_1  service_visit_def_1596  1
    service_2_31_1  free_load_conservation_1597  -1
    service_2_31_1  original_T_including_depot_unload_1631  120
    service_2_31_3  unique_nonzero_owner_374  1
    service_2_31_3  service_visit_def_1596  1
    service_2_31_3  free_load_conservation_1597  1
    service_2_31_4  unique_nonzero_owner_375  1
    service_2_31_4  service_visit_def_1596  1
    service_2_31_4  free_load_conservation_1597  2
    service_2_31_5  unique_nonzero_owner_376  1
    service_2_31_5  service_visit_def_1596  1
    service_2_31_5  free_load_conservation_1597  3
    service_2_31_6  unique_nonzero_owner_377  1
    service_2_31_6  service_visit_def_1596  1
    service_2_31_6  free_load_conservation_1597  4
    service_2_31_7  unique_nonzero_owner_378  1
    service_2_31_7  service_visit_def_1596  1
    service_2_31_7  free_load_conservation_1597  5
    service_2_31_8  unique_nonzero_owner_379  1
    service_2_31_8  service_visit_def_1596  1
    service_2_31_8  free_load_conservation_1597  6
    service_2_31_9  unique_nonzero_owner_380  1
    service_2_31_9  service_visit_def_1596  1
    service_2_31_9  free_load_conservation_1597  7
    service_2_31_10  unique_nonzero_owner_381  1
    service_2_31_10  service_visit_def_1596  1
    service_2_31_10  free_load_conservation_1597  8
    service_2_31_11  unique_nonzero_owner_382  1
    service_2_31_11  service_visit_def_1596  1
    service_2_31_11  free_load_conservation_1597  9
    service_2_31_12  unique_nonzero_owner_383  1
    service_2_31_12  service_visit_def_1596  1
    service_2_31_12  free_load_conservation_1597  10
    service_0_1_0  unique_nonzero_owner_384  1
    service_0_1_0  service_visit_def_859  1
    service_0_1_0  free_load_conservation_860  -2
    service_0_1_0  original_T_including_depot_unload_889  240
    service_0_1_1  unique_nonzero_owner_385  1
    service_0_1_1  service_visit_def_859  1
    service_0_1_1  free_load_conservation_860  -1
    service_0_1_1  original_T_including_depot_unload_889  120
    service_0_1_3  unique_nonzero_owner_386  1
    service_0_1_3  service_visit_def_859  1
    service_0_1_3  free_load_conservation_860  1
    service_0_1_4  unique_nonzero_owner_387  1
    service_0_1_4  service_visit_def_859  1
    service_0_1_4  free_load_conservation_860  2
    service_0_1_5  unique_nonzero_owner_388  1
    service_0_1_5  service_visit_def_859  1
    service_0_1_5  free_load_conservation_860  3
    service_0_1_6  unique_nonzero_owner_389  1
    service_0_1_6  service_visit_def_859  1
    service_0_1_6  free_load_conservation_860  4
    service_0_1_7  unique_nonzero_owner_390  1
    service_0_1_7  service_visit_def_859  1
    service_0_1_7  free_load_conservation_860  5
    service_0_1_8  unique_nonzero_owner_391  1
    service_0_1_8  service_visit_def_859  1
    service_0_1_8  free_load_conservation_860  6
    service_0_1_9  unique_nonzero_owner_392  1
    service_0_1_9  service_visit_def_859  1
    service_0_1_9  free_load_conservation_860  7
    service_0_1_10  unique_nonzero_owner_393  1
    service_0_1_10  service_visit_def_859  1
    service_0_1_10  free_load_conservation_860  8
    service_0_1_11  unique_nonzero_owner_394  1
    service_0_1_11  service_visit_def_859  1
    service_0_1_11  free_load_conservation_860  9
    service_0_1_12  unique_nonzero_owner_395  1
    service_0_1_12  service_visit_def_859  1
    service_0_1_12  free_load_conservation_860  10
    service_0_1_13  unique_nonzero_owner_396  1
    service_0_1_13  service_visit_def_859  1
    service_0_1_13  free_load_conservation_860  11
    service_0_1_14  unique_nonzero_owner_397  1
    service_0_1_14  service_visit_def_859  1
    service_0_1_14  free_load_conservation_860  12
    service_0_1_15  unique_nonzero_owner_398  1
    service_0_1_15  service_visit_def_859  1
    service_0_1_15  free_load_conservation_860  13
    service_0_1_16  unique_nonzero_owner_399  1
    service_0_1_16  service_visit_def_859  1
    service_0_1_16  free_load_conservation_860  14
    service_0_1_17  unique_nonzero_owner_400  1
    service_0_1_17  service_visit_def_859  1
    service_0_1_17  free_load_conservation_860  15
    service_0_1_18  unique_nonzero_owner_401  1
    service_0_1_18  service_visit_def_859  1
    service_0_1_18  free_load_conservation_860  16
    service_0_1_19  unique_nonzero_owner_402  1
    service_0_1_19  service_visit_def_859  1
    service_0_1_19  free_load_conservation_860  17
    service_1_1_0  unique_nonzero_owner_384  1
    service_1_1_0  service_visit_def_1231  1
    service_1_1_0  free_load_conservation_1232  -2
    service_1_1_0  original_T_including_depot_unload_1260  240
    service_1_1_1  unique_nonzero_owner_385  1
    service_1_1_1  service_visit_def_1231  1
    service_1_1_1  free_load_conservation_1232  -1
    service_1_1_1  original_T_including_depot_unload_1260  120
    service_1_1_3  unique_nonzero_owner_386  1
    service_1_1_3  service_visit_def_1231  1
    service_1_1_3  free_load_conservation_1232  1
    service_1_1_4  unique_nonzero_owner_387  1
    service_1_1_4  service_visit_def_1231  1
    service_1_1_4  free_load_conservation_1232  2
    service_1_1_5  unique_nonzero_owner_388  1
    service_1_1_5  service_visit_def_1231  1
    service_1_1_5  free_load_conservation_1232  3
    service_1_1_6  unique_nonzero_owner_389  1
    service_1_1_6  service_visit_def_1231  1
    service_1_1_6  free_load_conservation_1232  4
    service_1_1_7  unique_nonzero_owner_390  1
    service_1_1_7  service_visit_def_1231  1
    service_1_1_7  free_load_conservation_1232  5
    service_1_1_8  unique_nonzero_owner_391  1
    service_1_1_8  service_visit_def_1231  1
    service_1_1_8  free_load_conservation_1232  6
    service_1_1_9  unique_nonzero_owner_392  1
    service_1_1_9  service_visit_def_1231  1
    service_1_1_9  free_load_conservation_1232  7
    service_1_1_10  unique_nonzero_owner_393  1
    service_1_1_10  service_visit_def_1231  1
    service_1_1_10  free_load_conservation_1232  8
    service_1_1_11  unique_nonzero_owner_394  1
    service_1_1_11  service_visit_def_1231  1
    service_1_1_11  free_load_conservation_1232  9
    service_1_1_12  unique_nonzero_owner_395  1
    service_1_1_12  service_visit_def_1231  1
    service_1_1_12  free_load_conservation_1232  10
    service_1_1_13  unique_nonzero_owner_396  1
    service_1_1_13  service_visit_def_1231  1
    service_1_1_13  free_load_conservation_1232  11
    service_1_1_14  unique_nonzero_owner_397  1
    service_1_1_14  service_visit_def_1231  1
    service_1_1_14  free_load_conservation_1232  12
    service_1_1_15  unique_nonzero_owner_398  1
    service_1_1_15  service_visit_def_1231  1
    service_1_1_15  free_load_conservation_1232  13
    service_1_1_16  unique_nonzero_owner_399  1
    service_1_1_16  service_visit_def_1231  1
    service_1_1_16  free_load_conservation_1232  14
    service_1_1_17  unique_nonzero_owner_400  1
    service_1_1_17  service_visit_def_1231  1
    service_1_1_17  free_load_conservation_1232  15
    service_1_1_18  unique_nonzero_owner_401  1
    service_1_1_18  service_visit_def_1231  1
    service_1_1_18  free_load_conservation_1232  16
    service_1_1_19  unique_nonzero_owner_402  1
    service_1_1_19  service_visit_def_1231  1
    service_1_1_19  free_load_conservation_1232  17
    service_2_1_0  unique_nonzero_owner_384  1
    service_2_1_0  service_visit_def_1602  1
    service_2_1_0  free_load_conservation_1603  -2
    service_2_1_0  original_T_including_depot_unload_1631  240
    service_2_1_1  unique_nonzero_owner_385  1
    service_2_1_1  service_visit_def_1602  1
    service_2_1_1  free_load_conservation_1603  -1
    service_2_1_1  original_T_including_depot_unload_1631  120
    service_2_1_3  unique_nonzero_owner_386  1
    service_2_1_3  service_visit_def_1602  1
    service_2_1_3  free_load_conservation_1603  1
    service_2_1_4  unique_nonzero_owner_387  1
    service_2_1_4  service_visit_def_1602  1
    service_2_1_4  free_load_conservation_1603  2
    service_2_1_5  unique_nonzero_owner_388  1
    service_2_1_5  service_visit_def_1602  1
    service_2_1_5  free_load_conservation_1603  3
    service_2_1_6  unique_nonzero_owner_389  1
    service_2_1_6  service_visit_def_1602  1
    service_2_1_6  free_load_conservation_1603  4
    service_2_1_7  unique_nonzero_owner_390  1
    service_2_1_7  service_visit_def_1602  1
    service_2_1_7  free_load_conservation_1603  5
    service_2_1_8  unique_nonzero_owner_391  1
    service_2_1_8  service_visit_def_1602  1
    service_2_1_8  free_load_conservation_1603  6
    service_2_1_9  unique_nonzero_owner_392  1
    service_2_1_9  service_visit_def_1602  1
    service_2_1_9  free_load_conservation_1603  7
    service_2_1_10  unique_nonzero_owner_393  1
    service_2_1_10  service_visit_def_1602  1
    service_2_1_10  free_load_conservation_1603  8
    service_2_1_11  unique_nonzero_owner_394  1
    service_2_1_11  service_visit_def_1602  1
    service_2_1_11  free_load_conservation_1603  9
    service_2_1_12  unique_nonzero_owner_395  1
    service_2_1_12  service_visit_def_1602  1
    service_2_1_12  free_load_conservation_1603  10
    service_2_1_13  unique_nonzero_owner_396  1
    service_2_1_13  service_visit_def_1602  1
    service_2_1_13  free_load_conservation_1603  11
    service_2_1_14  unique_nonzero_owner_397  1
    service_2_1_14  service_visit_def_1602  1
    service_2_1_14  free_load_conservation_1603  12
    service_2_1_15  unique_nonzero_owner_398  1
    service_2_1_15  service_visit_def_1602  1
    service_2_1_15  free_load_conservation_1603  13
    service_2_1_16  unique_nonzero_owner_399  1
    service_2_1_16  service_visit_def_1602  1
    service_2_1_16  free_load_conservation_1603  14
    service_2_1_17  unique_nonzero_owner_400  1
    service_2_1_17  service_visit_def_1602  1
    service_2_1_17  free_load_conservation_1603  15
    service_2_1_18  unique_nonzero_owner_401  1
    service_2_1_18  service_visit_def_1602  1
    service_2_1_18  free_load_conservation_1603  16
    service_2_1_19  unique_nonzero_owner_402  1
    service_2_1_19  service_visit_def_1602  1
    service_2_1_19  free_load_conservation_1603  17
    service_0_6_0  unique_nonzero_owner_403  1
    service_0_6_0  service_visit_def_865  1
    service_0_6_0  free_load_conservation_866  -1
    service_0_6_0  original_T_including_depot_unload_889  120
    service_0_6_2  unique_nonzero_owner_404  1
    service_0_6_2  service_visit_def_865  1
    service_0_6_2  free_load_conservation_866  1
    service_0_6_3  unique_nonzero_owner_405  1
    service_0_6_3  service_visit_def_865  1
    service_0_6_3  free_load_conservation_866  2
    service_0_6_4  unique_nonzero_owner_406  1
    service_0_6_4  service_visit_def_865  1
    service_0_6_4  free_load_conservation_866  3
    service_0_6_5  unique_nonzero_owner_407  1
    service_0_6_5  service_visit_def_865  1
    service_0_6_5  free_load_conservation_866  4
    service_0_6_6  unique_nonzero_owner_408  1
    service_0_6_6  service_visit_def_865  1
    service_0_6_6  free_load_conservation_866  5
    service_0_6_7  unique_nonzero_owner_409  1
    service_0_6_7  service_visit_def_865  1
    service_0_6_7  free_load_conservation_866  6
    service_0_6_8  unique_nonzero_owner_410  1
    service_0_6_8  service_visit_def_865  1
    service_0_6_8  free_load_conservation_866  7
    service_0_6_9  unique_nonzero_owner_411  1
    service_0_6_9  service_visit_def_865  1
    service_0_6_9  free_load_conservation_866  8
    service_0_6_10  unique_nonzero_owner_412  1
    service_0_6_10  service_visit_def_865  1
    service_0_6_10  free_load_conservation_866  9
    service_1_6_0  unique_nonzero_owner_403  1
    service_1_6_0  service_visit_def_1237  1
    service_1_6_0  free_load_conservation_1238  -1
    service_1_6_0  original_T_including_depot_unload_1260  120
    service_1_6_2  unique_nonzero_owner_404  1
    service_1_6_2  service_visit_def_1237  1
    service_1_6_2  free_load_conservation_1238  1
    service_1_6_3  unique_nonzero_owner_405  1
    service_1_6_3  service_visit_def_1237  1
    service_1_6_3  free_load_conservation_1238  2
    service_1_6_4  unique_nonzero_owner_406  1
    service_1_6_4  service_visit_def_1237  1
    service_1_6_4  free_load_conservation_1238  3
    service_1_6_5  unique_nonzero_owner_407  1
    service_1_6_5  service_visit_def_1237  1
    service_1_6_5  free_load_conservation_1238  4
    service_1_6_6  unique_nonzero_owner_408  1
    service_1_6_6  service_visit_def_1237  1
    service_1_6_6  free_load_conservation_1238  5
    service_1_6_7  unique_nonzero_owner_409  1
    service_1_6_7  service_visit_def_1237  1
    service_1_6_7  free_load_conservation_1238  6
    service_1_6_8  unique_nonzero_owner_410  1
    service_1_6_8  service_visit_def_1237  1
    service_1_6_8  free_load_conservation_1238  7
    service_1_6_9  unique_nonzero_owner_411  1
    service_1_6_9  service_visit_def_1237  1
    service_1_6_9  free_load_conservation_1238  8
    service_1_6_10  unique_nonzero_owner_412  1
    service_1_6_10  service_visit_def_1237  1
    service_1_6_10  free_load_conservation_1238  9
    service_2_6_0  unique_nonzero_owner_403  1
    service_2_6_0  service_visit_def_1608  1
    service_2_6_0  free_load_conservation_1609  -1
    service_2_6_0  original_T_including_depot_unload_1631  120
    service_2_6_2  unique_nonzero_owner_404  1
    service_2_6_2  service_visit_def_1608  1
    service_2_6_2  free_load_conservation_1609  1
    service_2_6_3  unique_nonzero_owner_405  1
    service_2_6_3  service_visit_def_1608  1
    service_2_6_3  free_load_conservation_1609  2
    service_2_6_4  unique_nonzero_owner_406  1
    service_2_6_4  service_visit_def_1608  1
    service_2_6_4  free_load_conservation_1609  3
    service_2_6_5  unique_nonzero_owner_407  1
    service_2_6_5  service_visit_def_1608  1
    service_2_6_5  free_load_conservation_1609  4
    service_2_6_6  unique_nonzero_owner_408  1
    service_2_6_6  service_visit_def_1608  1
    service_2_6_6  free_load_conservation_1609  5
    service_2_6_7  unique_nonzero_owner_409  1
    service_2_6_7  service_visit_def_1608  1
    service_2_6_7  free_load_conservation_1609  6
    service_2_6_8  unique_nonzero_owner_410  1
    service_2_6_8  service_visit_def_1608  1
    service_2_6_8  free_load_conservation_1609  7
    service_2_6_9  unique_nonzero_owner_411  1
    service_2_6_9  service_visit_def_1608  1
    service_2_6_9  free_load_conservation_1609  8
    service_2_6_10  unique_nonzero_owner_412  1
    service_2_6_10  service_visit_def_1608  1
    service_2_6_10  free_load_conservation_1609  9
    service_0_8_0  unique_nonzero_owner_413  1
    service_0_8_0  service_visit_def_871  1
    service_0_8_0  free_load_conservation_872  -15
    service_0_8_0  original_T_including_depot_unload_889  1800
    service_0_8_1  unique_nonzero_owner_414  1
    service_0_8_1  service_visit_def_871  1
    service_0_8_1  free_load_conservation_872  -14
    service_0_8_1  original_T_including_depot_unload_889  1680
    service_0_8_2  unique_nonzero_owner_415  1
    service_0_8_2  service_visit_def_871  1
    service_0_8_2  free_load_conservation_872  -13
    service_0_8_2  original_T_including_depot_unload_889  1560
    service_0_8_3  unique_nonzero_owner_416  1
    service_0_8_3  service_visit_def_871  1
    service_0_8_3  free_load_conservation_872  -12
    service_0_8_3  original_T_including_depot_unload_889  1440
    service_0_8_4  unique_nonzero_owner_417  1
    service_0_8_4  service_visit_def_871  1
    service_0_8_4  free_load_conservation_872  -11
    service_0_8_4  original_T_including_depot_unload_889  1320
    service_0_8_5  unique_nonzero_owner_418  1
    service_0_8_5  service_visit_def_871  1
    service_0_8_5  free_load_conservation_872  -10
    service_0_8_5  original_T_including_depot_unload_889  1200
    service_0_8_6  unique_nonzero_owner_419  1
    service_0_8_6  service_visit_def_871  1
    service_0_8_6  free_load_conservation_872  -9
    service_0_8_6  original_T_including_depot_unload_889  1080
    service_0_8_7  unique_nonzero_owner_420  1
    service_0_8_7  service_visit_def_871  1
    service_0_8_7  free_load_conservation_872  -8
    service_0_8_7  original_T_including_depot_unload_889  960
    service_0_8_8  unique_nonzero_owner_421  1
    service_0_8_8  service_visit_def_871  1
    service_0_8_8  free_load_conservation_872  -7
    service_0_8_8  original_T_including_depot_unload_889  840
    service_0_8_9  unique_nonzero_owner_422  1
    service_0_8_9  service_visit_def_871  1
    service_0_8_9  free_load_conservation_872  -6
    service_0_8_9  original_T_including_depot_unload_889  720
    service_0_8_10  unique_nonzero_owner_423  1
    service_0_8_10  service_visit_def_871  1
    service_0_8_10  free_load_conservation_872  -5
    service_0_8_10  original_T_including_depot_unload_889  600
    service_0_8_11  unique_nonzero_owner_424  1
    service_0_8_11  service_visit_def_871  1
    service_0_8_11  free_load_conservation_872  -4
    service_0_8_11  original_T_including_depot_unload_889  480
    service_0_8_12  unique_nonzero_owner_425  1
    service_0_8_12  service_visit_def_871  1
    service_0_8_12  free_load_conservation_872  -3
    service_0_8_12  original_T_including_depot_unload_889  360
    service_0_8_13  unique_nonzero_owner_426  1
    service_0_8_13  service_visit_def_871  1
    service_0_8_13  free_load_conservation_872  -2
    service_0_8_13  original_T_including_depot_unload_889  240
    service_0_8_14  unique_nonzero_owner_427  1
    service_0_8_14  service_visit_def_871  1
    service_0_8_14  free_load_conservation_872  -1
    service_0_8_14  original_T_including_depot_unload_889  120
    service_0_8_16  unique_nonzero_owner_428  1
    service_0_8_16  service_visit_def_871  1
    service_0_8_16  free_load_conservation_872  1
    service_0_8_17  unique_nonzero_owner_429  1
    service_0_8_17  service_visit_def_871  1
    service_0_8_17  free_load_conservation_872  2
    service_0_8_18  unique_nonzero_owner_430  1
    service_0_8_18  service_visit_def_871  1
    service_0_8_18  free_load_conservation_872  3
    service_0_8_19  unique_nonzero_owner_431  1
    service_0_8_19  service_visit_def_871  1
    service_0_8_19  free_load_conservation_872  4
    service_0_8_20  unique_nonzero_owner_432  1
    service_0_8_20  service_visit_def_871  1
    service_0_8_20  free_load_conservation_872  5
    service_0_8_21  unique_nonzero_owner_433  1
    service_0_8_21  service_visit_def_871  1
    service_0_8_21  free_load_conservation_872  6
    service_1_8_0  unique_nonzero_owner_413  1
    service_1_8_0  service_visit_def_1243  1
    service_1_8_0  free_load_conservation_1244  -15
    service_1_8_0  original_T_including_depot_unload_1260  1800
    service_1_8_1  unique_nonzero_owner_414  1
    service_1_8_1  service_visit_def_1243  1
    service_1_8_1  free_load_conservation_1244  -14
    service_1_8_1  original_T_including_depot_unload_1260  1680
    service_1_8_2  unique_nonzero_owner_415  1
    service_1_8_2  service_visit_def_1243  1
    service_1_8_2  free_load_conservation_1244  -13
    service_1_8_2  original_T_including_depot_unload_1260  1560
    service_1_8_3  unique_nonzero_owner_416  1
    service_1_8_3  service_visit_def_1243  1
    service_1_8_3  free_load_conservation_1244  -12
    service_1_8_3  original_T_including_depot_unload_1260  1440
    service_1_8_4  unique_nonzero_owner_417  1
    service_1_8_4  service_visit_def_1243  1
    service_1_8_4  free_load_conservation_1244  -11
    service_1_8_4  original_T_including_depot_unload_1260  1320
    service_1_8_5  unique_nonzero_owner_418  1
    service_1_8_5  service_visit_def_1243  1
    service_1_8_5  free_load_conservation_1244  -10
    service_1_8_5  original_T_including_depot_unload_1260  1200
    service_1_8_6  unique_nonzero_owner_419  1
    service_1_8_6  service_visit_def_1243  1
    service_1_8_6  free_load_conservation_1244  -9
    service_1_8_6  original_T_including_depot_unload_1260  1080
    service_1_8_7  unique_nonzero_owner_420  1
    service_1_8_7  service_visit_def_1243  1
    service_1_8_7  free_load_conservation_1244  -8
    service_1_8_7  original_T_including_depot_unload_1260  960
    service_1_8_8  unique_nonzero_owner_421  1
    service_1_8_8  service_visit_def_1243  1
    service_1_8_8  free_load_conservation_1244  -7
    service_1_8_8  original_T_including_depot_unload_1260  840
    service_1_8_9  unique_nonzero_owner_422  1
    service_1_8_9  service_visit_def_1243  1
    service_1_8_9  free_load_conservation_1244  -6
    service_1_8_9  original_T_including_depot_unload_1260  720
    service_1_8_10  unique_nonzero_owner_423  1
    service_1_8_10  service_visit_def_1243  1
    service_1_8_10  free_load_conservation_1244  -5
    service_1_8_10  original_T_including_depot_unload_1260  600
    service_1_8_11  unique_nonzero_owner_424  1
    service_1_8_11  service_visit_def_1243  1
    service_1_8_11  free_load_conservation_1244  -4
    service_1_8_11  original_T_including_depot_unload_1260  480
    service_1_8_12  unique_nonzero_owner_425  1
    service_1_8_12  service_visit_def_1243  1
    service_1_8_12  free_load_conservation_1244  -3
    service_1_8_12  original_T_including_depot_unload_1260  360
    service_1_8_13  unique_nonzero_owner_426  1
    service_1_8_13  service_visit_def_1243  1
    service_1_8_13  free_load_conservation_1244  -2
    service_1_8_13  original_T_including_depot_unload_1260  240
    service_1_8_14  unique_nonzero_owner_427  1
    service_1_8_14  service_visit_def_1243  1
    service_1_8_14  free_load_conservation_1244  -1
    service_1_8_14  original_T_including_depot_unload_1260  120
    service_1_8_16  unique_nonzero_owner_428  1
    service_1_8_16  service_visit_def_1243  1
    service_1_8_16  free_load_conservation_1244  1
    service_1_8_17  unique_nonzero_owner_429  1
    service_1_8_17  service_visit_def_1243  1
    service_1_8_17  free_load_conservation_1244  2
    service_1_8_18  unique_nonzero_owner_430  1
    service_1_8_18  service_visit_def_1243  1
    service_1_8_18  free_load_conservation_1244  3
    service_1_8_19  unique_nonzero_owner_431  1
    service_1_8_19  service_visit_def_1243  1
    service_1_8_19  free_load_conservation_1244  4
    service_1_8_20  unique_nonzero_owner_432  1
    service_1_8_20  service_visit_def_1243  1
    service_1_8_20  free_load_conservation_1244  5
    service_1_8_21  unique_nonzero_owner_433  1
    service_1_8_21  service_visit_def_1243  1
    service_1_8_21  free_load_conservation_1244  6
    service_2_8_0  unique_nonzero_owner_413  1
    service_2_8_0  service_visit_def_1614  1
    service_2_8_0  free_load_conservation_1615  -15
    service_2_8_0  original_T_including_depot_unload_1631  1800
    service_2_8_1  unique_nonzero_owner_414  1
    service_2_8_1  service_visit_def_1614  1
    service_2_8_1  free_load_conservation_1615  -14
    service_2_8_1  original_T_including_depot_unload_1631  1680
    service_2_8_2  unique_nonzero_owner_415  1
    service_2_8_2  service_visit_def_1614  1
    service_2_8_2  free_load_conservation_1615  -13
    service_2_8_2  original_T_including_depot_unload_1631  1560
    service_2_8_3  unique_nonzero_owner_416  1
    service_2_8_3  service_visit_def_1614  1
    service_2_8_3  free_load_conservation_1615  -12
    service_2_8_3  original_T_including_depot_unload_1631  1440
    service_2_8_4  unique_nonzero_owner_417  1
    service_2_8_4  service_visit_def_1614  1
    service_2_8_4  free_load_conservation_1615  -11
    service_2_8_4  original_T_including_depot_unload_1631  1320
    service_2_8_5  unique_nonzero_owner_418  1
    service_2_8_5  service_visit_def_1614  1
    service_2_8_5  free_load_conservation_1615  -10
    service_2_8_5  original_T_including_depot_unload_1631  1200
    service_2_8_6  unique_nonzero_owner_419  1
    service_2_8_6  service_visit_def_1614  1
    service_2_8_6  free_load_conservation_1615  -9
    service_2_8_6  original_T_including_depot_unload_1631  1080
    service_2_8_7  unique_nonzero_owner_420  1
    service_2_8_7  service_visit_def_1614  1
    service_2_8_7  free_load_conservation_1615  -8
    service_2_8_7  original_T_including_depot_unload_1631  960
    service_2_8_8  unique_nonzero_owner_421  1
    service_2_8_8  service_visit_def_1614  1
    service_2_8_8  free_load_conservation_1615  -7
    service_2_8_8  original_T_including_depot_unload_1631  840
    service_2_8_9  unique_nonzero_owner_422  1
    service_2_8_9  service_visit_def_1614  1
    service_2_8_9  free_load_conservation_1615  -6
    service_2_8_9  original_T_including_depot_unload_1631  720
    service_2_8_10  unique_nonzero_owner_423  1
    service_2_8_10  service_visit_def_1614  1
    service_2_8_10  free_load_conservation_1615  -5
    service_2_8_10  original_T_including_depot_unload_1631  600
    service_2_8_11  unique_nonzero_owner_424  1
    service_2_8_11  service_visit_def_1614  1
    service_2_8_11  free_load_conservation_1615  -4
    service_2_8_11  original_T_including_depot_unload_1631  480
    service_2_8_12  unique_nonzero_owner_425  1
    service_2_8_12  service_visit_def_1614  1
    service_2_8_12  free_load_conservation_1615  -3
    service_2_8_12  original_T_including_depot_unload_1631  360
    service_2_8_13  unique_nonzero_owner_426  1
    service_2_8_13  service_visit_def_1614  1
    service_2_8_13  free_load_conservation_1615  -2
    service_2_8_13  original_T_including_depot_unload_1631  240
    service_2_8_14  unique_nonzero_owner_427  1
    service_2_8_14  service_visit_def_1614  1
    service_2_8_14  free_load_conservation_1615  -1
    service_2_8_14  original_T_including_depot_unload_1631  120
    service_2_8_16  unique_nonzero_owner_428  1
    service_2_8_16  service_visit_def_1614  1
    service_2_8_16  free_load_conservation_1615  1
    service_2_8_17  unique_nonzero_owner_429  1
    service_2_8_17  service_visit_def_1614  1
    service_2_8_17  free_load_conservation_1615  2
    service_2_8_18  unique_nonzero_owner_430  1
    service_2_8_18  service_visit_def_1614  1
    service_2_8_18  free_load_conservation_1615  3
    service_2_8_19  unique_nonzero_owner_431  1
    service_2_8_19  service_visit_def_1614  1
    service_2_8_19  free_load_conservation_1615  4
    service_2_8_20  unique_nonzero_owner_432  1
    service_2_8_20  service_visit_def_1614  1
    service_2_8_20  free_load_conservation_1615  5
    service_2_8_21  unique_nonzero_owner_433  1
    service_2_8_21  service_visit_def_1614  1
    service_2_8_21  free_load_conservation_1615  6
    service_0_32_1  unique_nonzero_owner_434  1
    service_0_32_1  service_visit_def_877  1
    service_0_32_1  free_load_conservation_878  1
    service_0_32_2  unique_nonzero_owner_435  1
    service_0_32_2  service_visit_def_877  1
    service_0_32_2  free_load_conservation_878  2
    service_0_32_3  unique_nonzero_owner_436  1
    service_0_32_3  service_visit_def_877  1
    service_0_32_3  free_load_conservation_878  3
    service_0_32_4  unique_nonzero_owner_437  1
    service_0_32_4  service_visit_def_877  1
    service_0_32_4  free_load_conservation_878  4
    service_0_32_5  unique_nonzero_owner_438  1
    service_0_32_5  service_visit_def_877  1
    service_0_32_5  free_load_conservation_878  5
    service_0_32_6  unique_nonzero_owner_439  1
    service_0_32_6  service_visit_def_877  1
    service_0_32_6  free_load_conservation_878  6
    service_0_32_7  unique_nonzero_owner_440  1
    service_0_32_7  service_visit_def_877  1
    service_0_32_7  free_load_conservation_878  7
    service_0_32_8  unique_nonzero_owner_441  1
    service_0_32_8  service_visit_def_877  1
    service_0_32_8  free_load_conservation_878  8
    service_0_32_9  unique_nonzero_owner_442  1
    service_0_32_9  service_visit_def_877  1
    service_0_32_9  free_load_conservation_878  9
    service_0_32_10  unique_nonzero_owner_443  1
    service_0_32_10  service_visit_def_877  1
    service_0_32_10  free_load_conservation_878  10
    service_0_32_11  unique_nonzero_owner_444  1
    service_0_32_11  service_visit_def_877  1
    service_0_32_11  free_load_conservation_878  11
    service_0_32_12  unique_nonzero_owner_445  1
    service_0_32_12  service_visit_def_877  1
    service_0_32_12  free_load_conservation_878  12
    service_1_32_1  unique_nonzero_owner_434  1
    service_1_32_1  service_visit_def_1249  1
    service_1_32_1  free_load_conservation_1250  1
    service_1_32_2  unique_nonzero_owner_435  1
    service_1_32_2  service_visit_def_1249  1
    service_1_32_2  free_load_conservation_1250  2
    service_1_32_3  unique_nonzero_owner_436  1
    service_1_32_3  service_visit_def_1249  1
    service_1_32_3  free_load_conservation_1250  3
    service_1_32_4  unique_nonzero_owner_437  1
    service_1_32_4  service_visit_def_1249  1
    service_1_32_4  free_load_conservation_1250  4
    service_1_32_5  unique_nonzero_owner_438  1
    service_1_32_5  service_visit_def_1249  1
    service_1_32_5  free_load_conservation_1250  5
    service_1_32_6  unique_nonzero_owner_439  1
    service_1_32_6  service_visit_def_1249  1
    service_1_32_6  free_load_conservation_1250  6
    service_1_32_7  unique_nonzero_owner_440  1
    service_1_32_7  service_visit_def_1249  1
    service_1_32_7  free_load_conservation_1250  7
    service_1_32_8  unique_nonzero_owner_441  1
    service_1_32_8  service_visit_def_1249  1
    service_1_32_8  free_load_conservation_1250  8
    service_1_32_9  unique_nonzero_owner_442  1
    service_1_32_9  service_visit_def_1249  1
    service_1_32_9  free_load_conservation_1250  9
    service_1_32_10  unique_nonzero_owner_443  1
    service_1_32_10  service_visit_def_1249  1
    service_1_32_10  free_load_conservation_1250  10
    service_1_32_11  unique_nonzero_owner_444  1
    service_1_32_11  service_visit_def_1249  1
    service_1_32_11  free_load_conservation_1250  11
    service_1_32_12  unique_nonzero_owner_445  1
    service_1_32_12  service_visit_def_1249  1
    service_1_32_12  free_load_conservation_1250  12
    service_2_32_1  unique_nonzero_owner_434  1
    service_2_32_1  service_visit_def_1620  1
    service_2_32_1  free_load_conservation_1621  1
    service_2_32_2  unique_nonzero_owner_435  1
    service_2_32_2  service_visit_def_1620  1
    service_2_32_2  free_load_conservation_1621  2
    service_2_32_3  unique_nonzero_owner_436  1
    service_2_32_3  service_visit_def_1620  1
    service_2_32_3  free_load_conservation_1621  3
    service_2_32_4  unique_nonzero_owner_437  1
    service_2_32_4  service_visit_def_1620  1
    service_2_32_4  free_load_conservation_1621  4
    service_2_32_5  unique_nonzero_owner_438  1
    service_2_32_5  service_visit_def_1620  1
    service_2_32_5  free_load_conservation_1621  5
    service_2_32_6  unique_nonzero_owner_439  1
    service_2_32_6  service_visit_def_1620  1
    service_2_32_6  free_load_conservation_1621  6
    service_2_32_7  unique_nonzero_owner_440  1
    service_2_32_7  service_visit_def_1620  1
    service_2_32_7  free_load_conservation_1621  7
    service_2_32_8  unique_nonzero_owner_441  1
    service_2_32_8  service_visit_def_1620  1
    service_2_32_8  free_load_conservation_1621  8
    service_2_32_9  unique_nonzero_owner_442  1
    service_2_32_9  service_visit_def_1620  1
    service_2_32_9  free_load_conservation_1621  9
    service_2_32_10  unique_nonzero_owner_443  1
    service_2_32_10  service_visit_def_1620  1
    service_2_32_10  free_load_conservation_1621  10
    service_2_32_11  unique_nonzero_owner_444  1
    service_2_32_11  service_visit_def_1620  1
    service_2_32_11  free_load_conservation_1621  11
    service_2_32_12  unique_nonzero_owner_445  1
    service_2_32_12  service_visit_def_1620  1
    service_2_32_12  free_load_conservation_1621  12
    service_0_14_0  unique_nonzero_owner_446  1
    service_0_14_0  service_visit_def_883  1
    service_0_14_0  free_load_conservation_884  -2
    service_0_14_0  original_T_including_depot_unload_889  240
    service_0_14_1  unique_nonzero_owner_447  1
    service_0_14_1  service_visit_def_883  1
    service_0_14_1  free_load_conservation_884  -1
    service_0_14_1  original_T_including_depot_unload_889  120
    service_0_14_3  unique_nonzero_owner_448  1
    service_0_14_3  service_visit_def_883  1
    service_0_14_3  free_load_conservation_884  1
    service_0_14_4  unique_nonzero_owner_449  1
    service_0_14_4  service_visit_def_883  1
    service_0_14_4  free_load_conservation_884  2
    service_0_14_5  unique_nonzero_owner_450  1
    service_0_14_5  service_visit_def_883  1
    service_0_14_5  free_load_conservation_884  3
    service_0_14_6  unique_nonzero_owner_451  1
    service_0_14_6  service_visit_def_883  1
    service_0_14_6  free_load_conservation_884  4
    service_0_14_7  unique_nonzero_owner_452  1
    service_0_14_7  service_visit_def_883  1
    service_0_14_7  free_load_conservation_884  5
    service_0_14_8  unique_nonzero_owner_453  1
    service_0_14_8  service_visit_def_883  1
    service_0_14_8  free_load_conservation_884  6
    service_0_14_9  unique_nonzero_owner_454  1
    service_0_14_9  service_visit_def_883  1
    service_0_14_9  free_load_conservation_884  7
    service_0_14_10  unique_nonzero_owner_455  1
    service_0_14_10  service_visit_def_883  1
    service_0_14_10  free_load_conservation_884  8
    service_0_14_11  unique_nonzero_owner_456  1
    service_0_14_11  service_visit_def_883  1
    service_0_14_11  free_load_conservation_884  9
    service_0_14_12  unique_nonzero_owner_457  1
    service_0_14_12  service_visit_def_883  1
    service_0_14_12  free_load_conservation_884  10
    service_0_14_13  unique_nonzero_owner_458  1
    service_0_14_13  service_visit_def_883  1
    service_0_14_13  free_load_conservation_884  11
    service_0_14_14  unique_nonzero_owner_459  1
    service_0_14_14  service_visit_def_883  1
    service_0_14_14  free_load_conservation_884  12
    service_0_14_15  unique_nonzero_owner_460  1
    service_0_14_15  service_visit_def_883  1
    service_0_14_15  free_load_conservation_884  13
    service_1_14_0  unique_nonzero_owner_446  1
    service_1_14_0  service_visit_def_1255  1
    service_1_14_0  free_load_conservation_1256  -2
    service_1_14_0  original_T_including_depot_unload_1260  240
    service_1_14_1  unique_nonzero_owner_447  1
    service_1_14_1  service_visit_def_1255  1
    service_1_14_1  free_load_conservation_1256  -1
    service_1_14_1  original_T_including_depot_unload_1260  120
    service_1_14_3  unique_nonzero_owner_448  1
    service_1_14_3  service_visit_def_1255  1
    service_1_14_3  free_load_conservation_1256  1
    service_1_14_4  unique_nonzero_owner_449  1
    service_1_14_4  service_visit_def_1255  1
    service_1_14_4  free_load_conservation_1256  2
    service_1_14_5  unique_nonzero_owner_450  1
    service_1_14_5  service_visit_def_1255  1
    service_1_14_5  free_load_conservation_1256  3
    service_1_14_6  unique_nonzero_owner_451  1
    service_1_14_6  service_visit_def_1255  1
    service_1_14_6  free_load_conservation_1256  4
    service_1_14_7  unique_nonzero_owner_452  1
    service_1_14_7  service_visit_def_1255  1
    service_1_14_7  free_load_conservation_1256  5
    service_1_14_8  unique_nonzero_owner_453  1
    service_1_14_8  service_visit_def_1255  1
    service_1_14_8  free_load_conservation_1256  6
    service_1_14_9  unique_nonzero_owner_454  1
    service_1_14_9  service_visit_def_1255  1
    service_1_14_9  free_load_conservation_1256  7
    service_1_14_10  unique_nonzero_owner_455  1
    service_1_14_10  service_visit_def_1255  1
    service_1_14_10  free_load_conservation_1256  8
    service_1_14_11  unique_nonzero_owner_456  1
    service_1_14_11  service_visit_def_1255  1
    service_1_14_11  free_load_conservation_1256  9
    service_1_14_12  unique_nonzero_owner_457  1
    service_1_14_12  service_visit_def_1255  1
    service_1_14_12  free_load_conservation_1256  10
    service_1_14_13  unique_nonzero_owner_458  1
    service_1_14_13  service_visit_def_1255  1
    service_1_14_13  free_load_conservation_1256  11
    service_1_14_14  unique_nonzero_owner_459  1
    service_1_14_14  service_visit_def_1255  1
    service_1_14_14  free_load_conservation_1256  12
    service_1_14_15  unique_nonzero_owner_460  1
    service_1_14_15  service_visit_def_1255  1
    service_1_14_15  free_load_conservation_1256  13
    service_2_14_0  unique_nonzero_owner_446  1
    service_2_14_0  service_visit_def_1626  1
    service_2_14_0  free_load_conservation_1627  -2
    service_2_14_0  original_T_including_depot_unload_1631  240
    service_2_14_1  unique_nonzero_owner_447  1
    service_2_14_1  service_visit_def_1626  1
    service_2_14_1  free_load_conservation_1627  -1
    service_2_14_1  original_T_including_depot_unload_1631  120
    service_2_14_3  unique_nonzero_owner_448  1
    service_2_14_3  service_visit_def_1626  1
    service_2_14_3  free_load_conservation_1627  1
    service_2_14_4  unique_nonzero_owner_449  1
    service_2_14_4  service_visit_def_1626  1
    service_2_14_4  free_load_conservation_1627  2
    service_2_14_5  unique_nonzero_owner_450  1
    service_2_14_5  service_visit_def_1626  1
    service_2_14_5  free_load_conservation_1627  3
    service_2_14_6  unique_nonzero_owner_451  1
    service_2_14_6  service_visit_def_1626  1
    service_2_14_6  free_load_conservation_1627  4
    service_2_14_7  unique_nonzero_owner_452  1
    service_2_14_7  service_visit_def_1626  1
    service_2_14_7  free_load_conservation_1627  5
    service_2_14_8  unique_nonzero_owner_453  1
    service_2_14_8  service_visit_def_1626  1
    service_2_14_8  free_load_conservation_1627  6
    service_2_14_9  unique_nonzero_owner_454  1
    service_2_14_9  service_visit_def_1626  1
    service_2_14_9  free_load_conservation_1627  7
    service_2_14_10  unique_nonzero_owner_455  1
    service_2_14_10  service_visit_def_1626  1
    service_2_14_10  free_load_conservation_1627  8
    service_2_14_11  unique_nonzero_owner_456  1
    service_2_14_11  service_visit_def_1626  1
    service_2_14_11  free_load_conservation_1627  9
    service_2_14_12  unique_nonzero_owner_457  1
    service_2_14_12  service_visit_def_1626  1
    service_2_14_12  free_load_conservation_1627  10
    service_2_14_13  unique_nonzero_owner_458  1
    service_2_14_13  service_visit_def_1626  1
    service_2_14_13  free_load_conservation_1627  11
    service_2_14_14  unique_nonzero_owner_459  1
    service_2_14_14  service_visit_def_1626  1
    service_2_14_14  free_load_conservation_1627  12
    service_2_14_15  unique_nonzero_owner_460  1
    service_2_14_15  service_visit_def_1626  1
    service_2_14_15  free_load_conservation_1627  13
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_802  -1
    visit_0_1  in_degree_803  -1
    visit_0_1  order_active_lb_804  -1
    visit_0_1  order_active_ub_805  -13
    order_0_1  connected_order_arc_477  -1
    order_0_1  connected_order_arc_479  -1
    order_0_1  connected_order_arc_481  -1
    order_0_1  connected_order_arc_483  -1
    order_0_1  connected_order_arc_485  -1
    order_0_1  connected_order_arc_487  -1
    order_0_1  connected_order_arc_489  -1
    order_0_1  connected_order_arc_491  -1
    order_0_1  connected_order_arc_493  -1
    order_0_1  connected_order_arc_495  -1
    order_0_1  connected_order_arc_497  -1
    order_0_1  connected_order_arc_499  -1
    order_0_1  connected_order_arc_502  1
    order_0_1  connected_order_arc_527  1
    order_0_1  connected_order_arc_552  1
    order_0_1  connected_order_arc_577  1
    order_0_1  connected_order_arc_602  1
    order_0_1  connected_order_arc_627  1
    order_0_1  connected_order_arc_652  1
    order_0_1  connected_order_arc_677  1
    order_0_1  connected_order_arc_702  1
    order_0_1  connected_order_arc_727  1
    order_0_1  connected_order_arc_752  1
    order_0_1  connected_order_arc_777  1
    order_0_1  order_active_lb_804  1
    order_0_1  order_active_ub_805  1
    order_0_1  fixed_segment_relative_order_885  -1
    visit_0_2  out_degree_809  -1
    visit_0_2  in_degree_810  -1
    visit_0_2  order_active_lb_811  -1
    visit_0_2  order_active_ub_812  -13
    order_0_2  connected_order_arc_477  1
    order_0_2  connected_order_arc_502  -1
    order_0_2  connected_order_arc_504  -1
    order_0_2  connected_order_arc_506  -1
    order_0_2  connected_order_arc_508  -1
    order_0_2  connected_order_arc_510  -1
    order_0_2  connected_order_arc_512  -1
    order_0_2  connected_order_arc_514  -1
    order_0_2  connected_order_arc_516  -1
    order_0_2  connected_order_arc_518  -1
    order_0_2  connected_order_arc_520  -1
    order_0_2  connected_order_arc_522  -1
    order_0_2  connected_order_arc_524  -1
    order_0_2  connected_order_arc_529  1
    order_0_2  connected_order_arc_554  1
    order_0_2  connected_order_arc_579  1
    order_0_2  connected_order_arc_604  1
    order_0_2  connected_order_arc_629  1
    order_0_2  connected_order_arc_654  1
    order_0_2  connected_order_arc_679  1
    order_0_2  connected_order_arc_704  1
    order_0_2  connected_order_arc_729  1
    order_0_2  connected_order_arc_754  1
    order_0_2  connected_order_arc_779  1
    order_0_2  order_active_lb_811  1
    order_0_2  order_active_ub_812  1
    order_0_2  fixed_segment_relative_order_885  1
    order_0_2  fixed_segment_relative_order_886  -1
    visit_0_3  out_degree_816  -1
    visit_0_3  in_degree_817  -1
    visit_0_3  order_active_lb_818  -1
    visit_0_3  order_active_ub_819  -13
    order_0_3  connected_order_arc_479  1
    order_0_3  connected_order_arc_504  1
    order_0_3  connected_order_arc_527  -1
    order_0_3  connected_order_arc_529  -1
    order_0_3  connected_order_arc_531  -1
    order_0_3  connected_order_arc_533  -1
    order_0_3  connected_order_arc_535  -1
    order_0_3  connected_order_arc_537  -1
    order_0_3  connected_order_arc_539  -1
    order_0_3  connected_order_arc_541  -1
    order_0_3  connected_order_arc_543  -1
    order_0_3  connected_order_arc_545  -1
    order_0_3  connected_order_arc_547  -1
    order_0_3  connected_order_arc_549  -1
    order_0_3  connected_order_arc_556  1
    order_0_3  connected_order_arc_581  1
    order_0_3  connected_order_arc_606  1
    order_0_3  connected_order_arc_631  1
    order_0_3  connected_order_arc_656  1
    order_0_3  connected_order_arc_681  1
    order_0_3  connected_order_arc_706  1
    order_0_3  connected_order_arc_731  1
    order_0_3  connected_order_arc_756  1
    order_0_3  connected_order_arc_781  1
    order_0_3  order_active_lb_818  1
    order_0_3  order_active_ub_819  1
    order_0_3  fixed_segment_relative_order_886  1
    order_0_3  fixed_segment_relative_order_887  -1
    visit_0_4  out_degree_823  -1
    visit_0_4  in_degree_824  -1
    visit_0_4  order_active_lb_825  -1
    visit_0_4  order_active_ub_826  -13
    order_0_4  connected_order_arc_481  1
    order_0_4  connected_order_arc_506  1
    order_0_4  connected_order_arc_531  1
    order_0_4  connected_order_arc_552  -1
    order_0_4  connected_order_arc_554  -1
    order_0_4  connected_order_arc_556  -1
    order_0_4  connected_order_arc_558  -1
    order_0_4  connected_order_arc_560  -1
    order_0_4  connected_order_arc_562  -1
    order_0_4  connected_order_arc_564  -1
    order_0_4  connected_order_arc_566  -1
    order_0_4  connected_order_arc_568  -1
    order_0_4  connected_order_arc_570  -1
    order_0_4  connected_order_arc_572  -1
    order_0_4  connected_order_arc_574  -1
    order_0_4  connected_order_arc_583  1
    order_0_4  connected_order_arc_608  1
    order_0_4  connected_order_arc_633  1
    order_0_4  connected_order_arc_658  1
    order_0_4  connected_order_arc_683  1
    order_0_4  connected_order_arc_708  1
    order_0_4  connected_order_arc_733  1
    order_0_4  connected_order_arc_758  1
    order_0_4  connected_order_arc_783  1
    order_0_4  order_active_lb_825  1
    order_0_4  order_active_ub_826  1
    order_0_4  fixed_segment_relative_order_887  1
    order_0_4  fixed_segment_relative_order_888  -1
    visit_0_5  out_degree_830  -1
    visit_0_5  in_degree_831  -1
    visit_0_5  order_active_lb_832  -1
    visit_0_5  order_active_ub_833  -13
    order_0_5  connected_order_arc_483  1
    order_0_5  connected_order_arc_508  1
    order_0_5  connected_order_arc_533  1
    order_0_5  connected_order_arc_558  1
    order_0_5  connected_order_arc_577  -1
    order_0_5  connected_order_arc_579  -1
    order_0_5  connected_order_arc_581  -1
    order_0_5  connected_order_arc_583  -1
    order_0_5  connected_order_arc_585  -1
    order_0_5  connected_order_arc_587  -1
    order_0_5  connected_order_arc_589  -1
    order_0_5  connected_order_arc_591  -1
    order_0_5  connected_order_arc_593  -1
    order_0_5  connected_order_arc_595  -1
    order_0_5  connected_order_arc_597  -1
    order_0_5  connected_order_arc_599  -1
    order_0_5  connected_order_arc_610  1
    order_0_5  connected_order_arc_635  1
    order_0_5  connected_order_arc_660  1
    order_0_5  connected_order_arc_685  1
    order_0_5  connected_order_arc_710  1
    order_0_5  connected_order_arc_735  1
    order_0_5  connected_order_arc_760  1
    order_0_5  connected_order_arc_785  1
    order_0_5  order_active_lb_832  1
    order_0_5  order_active_ub_833  1
    order_0_5  fixed_segment_relative_order_888  1
    visit_0_14  out_degree_837  -1
    visit_0_14  in_degree_838  -1
    visit_0_14  order_active_lb_839  -1
    visit_0_14  order_active_ub_840  -13
    visit_0_14  service_visit_def_841  -1
    order_0_14  connected_order_arc_485  1
    order_0_14  connected_order_arc_510  1
    order_0_14  connected_order_arc_535  1
    order_0_14  connected_order_arc_560  1
    order_0_14  connected_order_arc_585  1
    order_0_14  connected_order_arc_602  -1
    order_0_14  connected_order_arc_604  -1
    order_0_14  connected_order_arc_606  -1
    order_0_14  connected_order_arc_608  -1
    order_0_14  connected_order_arc_610  -1
    order_0_14  connected_order_arc_612  -1
    order_0_14  connected_order_arc_614  -1
    order_0_14  connected_order_arc_616  -1
    order_0_14  connected_order_arc_618  -1
    order_0_14  connected_order_arc_620  -1
    order_0_14  connected_order_arc_622  -1
    order_0_14  connected_order_arc_624  -1
    order_0_14  connected_order_arc_637  1
    order_0_14  connected_order_arc_662  1
    order_0_14  connected_order_arc_687  1
    order_0_14  connected_order_arc_712  1
    order_0_14  connected_order_arc_737  1
    order_0_14  connected_order_arc_762  1
    order_0_14  connected_order_arc_787  1
    order_0_14  order_active_lb_839  1
    order_0_14  order_active_ub_840  1
    visit_0_15  out_degree_843  -1
    visit_0_15  in_degree_844  -1
    visit_0_15  order_active_lb_845  -1
    visit_0_15  order_active_ub_846  -13
    visit_0_15  service_visit_def_847  -1
    order_0_15  connected_order_arc_487  1
    order_0_15  connected_order_arc_512  1
    order_0_15  connected_order_arc_537  1
    order_0_15  connected_order_arc_562  1
    order_0_15  connected_order_arc_587  1
    order_0_15  connected_order_arc_612  1
    order_0_15  connected_order_arc_627  -1
    order_0_15  connected_order_arc_629  -1
    order_0_15  connected_order_arc_631  -1
    order_0_15  connected_order_arc_633  -1
    order_0_15  connected_order_arc_635  -1
    order_0_15  connected_order_arc_637  -1
    order_0_15  connected_order_arc_639  -1
    order_0_15  connected_order_arc_641  -1
    order_0_15  connected_order_arc_643  -1
    order_0_15  connected_order_arc_645  -1
    order_0_15  connected_order_arc_647  -1
    order_0_15  connected_order_arc_649  -1
    order_0_15  connected_order_arc_664  1
    order_0_15  connected_order_arc_689  1
    order_0_15  connected_order_arc_714  1
    order_0_15  connected_order_arc_739  1
    order_0_15  connected_order_arc_764  1
    order_0_15  connected_order_arc_789  1
    order_0_15  order_active_lb_845  1
    order_0_15  order_active_ub_846  1
    visit_0_16  out_degree_849  -1
    visit_0_16  in_degree_850  -1
    visit_0_16  order_active_lb_851  -1
    visit_0_16  order_active_ub_852  -13
    visit_0_16  service_visit_def_853  -1
    order_0_16  connected_order_arc_489  1
    order_0_16  connected_order_arc_514  1
    order_0_16  connected_order_arc_539  1
    order_0_16  connected_order_arc_564  1
    order_0_16  connected_order_arc_589  1
    order_0_16  connected_order_arc_614  1
    order_0_16  connected_order_arc_639  1
    order_0_16  connected_order_arc_652  -1
    order_0_16  connected_order_arc_654  -1
    order_0_16  connected_order_arc_656  -1
    order_0_16  connected_order_arc_658  -1
    order_0_16  connected_order_arc_660  -1
    order_0_16  connected_order_arc_662  -1
    order_0_16  connected_order_arc_664  -1
    order_0_16  connected_order_arc_666  -1
    order_0_16  connected_order_arc_668  -1
    order_0_16  connected_order_arc_670  -1
    order_0_16  connected_order_arc_672  -1
    order_0_16  connected_order_arc_674  -1
    order_0_16  connected_order_arc_691  1
    order_0_16  connected_order_arc_716  1
    order_0_16  connected_order_arc_741  1
    order_0_16  connected_order_arc_766  1
    order_0_16  connected_order_arc_791  1
    order_0_16  order_active_lb_851  1
    order_0_16  order_active_ub_852  1
    visit_0_17  out_degree_855  -1
    visit_0_17  in_degree_856  -1
    visit_0_17  order_active_lb_857  -1
    visit_0_17  order_active_ub_858  -13
    visit_0_17  service_visit_def_859  -1
    order_0_17  connected_order_arc_491  1
    order_0_17  connected_order_arc_516  1
    order_0_17  connected_order_arc_541  1
    order_0_17  connected_order_arc_566  1
    order_0_17  connected_order_arc_591  1
    order_0_17  connected_order_arc_616  1
    order_0_17  connected_order_arc_641  1
    order_0_17  connected_order_arc_666  1
    order_0_17  connected_order_arc_677  -1
    order_0_17  connected_order_arc_679  -1
    order_0_17  connected_order_arc_681  -1
    order_0_17  connected_order_arc_683  -1
    order_0_17  connected_order_arc_685  -1
    order_0_17  connected_order_arc_687  -1
    order_0_17  connected_order_arc_689  -1
    order_0_17  connected_order_arc_691  -1
    order_0_17  connected_order_arc_693  -1
    order_0_17  connected_order_arc_695  -1
    order_0_17  connected_order_arc_697  -1
    order_0_17  connected_order_arc_699  -1
    order_0_17  connected_order_arc_718  1
    order_0_17  connected_order_arc_743  1
    order_0_17  connected_order_arc_768  1
    order_0_17  connected_order_arc_793  1
    order_0_17  order_active_lb_857  1
    order_0_17  order_active_ub_858  1
    visit_0_18  out_degree_861  -1
    visit_0_18  in_degree_862  -1
    visit_0_18  order_active_lb_863  -1
    visit_0_18  order_active_ub_864  -13
    visit_0_18  service_visit_def_865  -1
    order_0_18  connected_order_arc_493  1
    order_0_18  connected_order_arc_518  1
    order_0_18  connected_order_arc_543  1
    order_0_18  connected_order_arc_568  1
    order_0_18  connected_order_arc_593  1
    order_0_18  connected_order_arc_618  1
    order_0_18  connected_order_arc_643  1
    order_0_18  connected_order_arc_668  1
    order_0_18  connected_order_arc_693  1
    order_0_18  connected_order_arc_702  -1
    order_0_18  connected_order_arc_704  -1
    order_0_18  connected_order_arc_706  -1
    order_0_18  connected_order_arc_708  -1
    order_0_18  connected_order_arc_710  -1
    order_0_18  connected_order_arc_712  -1
    order_0_18  connected_order_arc_714  -1
    order_0_18  connected_order_arc_716  -1
    order_0_18  connected_order_arc_718  -1
    order_0_18  connected_order_arc_720  -1
    order_0_18  connected_order_arc_722  -1
    order_0_18  connected_order_arc_724  -1
    order_0_18  connected_order_arc_745  1
    order_0_18  connected_order_arc_770  1
    order_0_18  connected_order_arc_795  1
    order_0_18  order_active_lb_863  1
    order_0_18  order_active_ub_864  1
    visit_0_19  out_degree_867  -1
    visit_0_19  in_degree_868  -1
    visit_0_19  order_active_lb_869  -1
    visit_0_19  order_active_ub_870  -13
    visit_0_19  service_visit_def_871  -1
    order_0_19  connected_order_arc_495  1
    order_0_19  connected_order_arc_520  1
    order_0_19  connected_order_arc_545  1
    order_0_19  connected_order_arc_570  1
    order_0_19  connected_order_arc_595  1
    order_0_19  connected_order_arc_620  1
    order_0_19  connected_order_arc_645  1
    order_0_19  connected_order_arc_670  1
    order_0_19  connected_order_arc_695  1
    order_0_19  connected_order_arc_720  1
    order_0_19  connected_order_arc_727  -1
    order_0_19  connected_order_arc_729  -1
    order_0_19  connected_order_arc_731  -1
    order_0_19  connected_order_arc_733  -1
    order_0_19  connected_order_arc_735  -1
    order_0_19  connected_order_arc_737  -1
    order_0_19  connected_order_arc_739  -1
    order_0_19  connected_order_arc_741  -1
    order_0_19  connected_order_arc_743  -1
    order_0_19  connected_order_arc_745  -1
    order_0_19  connected_order_arc_747  -1
    order_0_19  connected_order_arc_749  -1
    order_0_19  connected_order_arc_772  1
    order_0_19  connected_order_arc_797  1
    order_0_19  order_active_lb_869  1
    order_0_19  order_active_ub_870  1
    visit_0_20  out_degree_873  -1
    visit_0_20  in_degree_874  -1
    visit_0_20  order_active_lb_875  -1
    visit_0_20  order_active_ub_876  -13
    visit_0_20  service_visit_def_877  -1
    order_0_20  connected_order_arc_497  1
    order_0_20  connected_order_arc_522  1
    order_0_20  connected_order_arc_547  1
    order_0_20  connected_order_arc_572  1
    order_0_20  connected_order_arc_597  1
    order_0_20  connected_order_arc_622  1
    order_0_20  connected_order_arc_647  1
    order_0_20  connected_order_arc_672  1
    order_0_20  connected_order_arc_697  1
    order_0_20  connected_order_arc_722  1
    order_0_20  connected_order_arc_747  1
    order_0_20  connected_order_arc_752  -1
    order_0_20  connected_order_arc_754  -1
    order_0_20  connected_order_arc_756  -1
    order_0_20  connected_order_arc_758  -1
    order_0_20  connected_order_arc_760  -1
    order_0_20  connected_order_arc_762  -1
    order_0_20  connected_order_arc_764  -1
    order_0_20  connected_order_arc_766  -1
    order_0_20  connected_order_arc_768  -1
    order_0_20  connected_order_arc_770  -1
    order_0_20  connected_order_arc_772  -1
    order_0_20  connected_order_arc_774  -1
    order_0_20  connected_order_arc_799  1
    order_0_20  order_active_lb_875  1
    order_0_20  order_active_ub_876  1
    visit_0_21  out_degree_879  -1
    visit_0_21  in_degree_880  -1
    visit_0_21  order_active_lb_881  -1
    visit_0_21  order_active_ub_882  -13
    visit_0_21  service_visit_def_883  -1
    order_0_21  connected_order_arc_499  1
    order_0_21  connected_order_arc_524  1
    order_0_21  connected_order_arc_549  1
    order_0_21  connected_order_arc_574  1
    order_0_21  connected_order_arc_599  1
    order_0_21  connected_order_arc_624  1
    order_0_21  connected_order_arc_649  1
    order_0_21  connected_order_arc_674  1
    order_0_21  connected_order_arc_699  1
    order_0_21  connected_order_arc_724  1
    order_0_21  connected_order_arc_749  1
    order_0_21  connected_order_arc_774  1
    order_0_21  connected_order_arc_777  -1
    order_0_21  connected_order_arc_779  -1
    order_0_21  connected_order_arc_781  -1
    order_0_21  connected_order_arc_783  -1
    order_0_21  connected_order_arc_785  -1
    order_0_21  connected_order_arc_787  -1
    order_0_21  connected_order_arc_789  -1
    order_0_21  connected_order_arc_791  -1
    order_0_21  connected_order_arc_793  -1
    order_0_21  connected_order_arc_795  -1
    order_0_21  connected_order_arc_797  -1
    order_0_21  connected_order_arc_799  -1
    order_0_21  order_active_lb_881  1
    order_0_21  order_active_ub_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_461  -20
    arc_0_0_0  depot_departure_or_bypass_800  1
    arc_0_0_0  depot_return_or_bypass_801  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_461  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_462  -20
    arc_0_0_1  depot_departure_or_bypass_800  1
    arc_0_0_1  in_degree_803  1
    arc_0_0_1  original_T_including_depot_unload_889  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_462  1
    load_0_0_1  segment_load_conservation_806  -1
    load_0_0_1  segment_prefix_lb_807  1
    load_0_0_1  segment_prefix_ub_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_463  -20
    arc_0_0_2  depot_departure_or_bypass_800  1
    arc_0_0_2  in_degree_810  1
    arc_0_0_2  original_T_including_depot_unload_889  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_463  1
    load_0_0_2  segment_load_conservation_813  -1
    load_0_0_2  segment_prefix_lb_814  1
    load_0_0_2  segment_prefix_ub_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_464  -20
    arc_0_0_3  depot_departure_or_bypass_800  1
    arc_0_0_3  in_degree_817  1
    arc_0_0_3  original_T_including_depot_unload_889  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_464  1
    load_0_0_3  segment_load_conservation_820  -1
    load_0_0_3  segment_prefix_lb_821  1
    load_0_0_3  segment_prefix_ub_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_465  -20
    arc_0_0_4  depot_departure_or_bypass_800  1
    arc_0_0_4  in_degree_824  1
    arc_0_0_4  original_T_including_depot_unload_889  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_465  1
    load_0_0_4  segment_load_conservation_827  -1
    load_0_0_4  segment_prefix_lb_828  1
    load_0_0_4  segment_prefix_ub_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_466  -20
    arc_0_0_5  depot_departure_or_bypass_800  1
    arc_0_0_5  in_degree_831  1
    arc_0_0_5  original_T_including_depot_unload_889  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_466  1
    load_0_0_5  segment_load_conservation_834  -1
    load_0_0_5  segment_prefix_lb_835  1
    load_0_0_5  segment_prefix_ub_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_467  -20
    arc_0_0_14  depot_departure_or_bypass_800  1
    arc_0_0_14  in_degree_838  1
    arc_0_0_14  original_T_including_depot_unload_889  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_467  1
    load_0_0_14  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_468  -20
    arc_0_0_15  depot_departure_or_bypass_800  1
    arc_0_0_15  in_degree_844  1
    arc_0_0_15  original_T_including_depot_unload_889  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_468  1
    load_0_0_15  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_469  -20
    arc_0_0_16  depot_departure_or_bypass_800  1
    arc_0_0_16  in_degree_850  1
    arc_0_0_16  original_T_including_depot_unload_889  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_469  1
    load_0_0_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_470  -20
    arc_0_0_17  depot_departure_or_bypass_800  1
    arc_0_0_17  in_degree_856  1
    arc_0_0_17  original_T_including_depot_unload_889  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_470  1
    load_0_0_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_471  -20
    arc_0_0_18  depot_departure_or_bypass_800  1
    arc_0_0_18  in_degree_862  1
    arc_0_0_18  original_T_including_depot_unload_889  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_471  1
    load_0_0_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_472  -20
    arc_0_0_19  depot_departure_or_bypass_800  1
    arc_0_0_19  in_degree_868  1
    arc_0_0_19  original_T_including_depot_unload_889  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_472  1
    load_0_0_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_473  -20
    arc_0_0_20  depot_departure_or_bypass_800  1
    arc_0_0_20  in_degree_874  1
    arc_0_0_20  original_T_including_depot_unload_889  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_473  1
    load_0_0_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_474  -20
    arc_0_0_21  depot_departure_or_bypass_800  1
    arc_0_0_21  in_degree_880  1
    arc_0_0_21  original_T_including_depot_unload_889  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_474  1
    load_0_0_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_475  -20
    arc_0_1_0  depot_return_or_bypass_801  1
    arc_0_1_0  out_degree_802  1
    arc_0_1_0  original_T_including_depot_unload_889  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_475  1
    load_0_1_0  segment_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_476  -20
    arc_0_1_2  connected_order_arc_477  -14
    arc_0_1_2  out_degree_802  1
    arc_0_1_2  in_degree_810  1
    arc_0_1_2  original_T_including_depot_unload_889  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_476  1
    load_0_1_2  segment_load_conservation_806  1
    load_0_1_2  segment_load_conservation_813  -1
    load_0_1_2  segment_prefix_lb_814  1
    load_0_1_2  segment_prefix_ub_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_478  -20
    arc_0_1_3  connected_order_arc_479  -14
    arc_0_1_3  out_degree_802  1
    arc_0_1_3  in_degree_817  1
    arc_0_1_3  original_T_including_depot_unload_889  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_478  1
    load_0_1_3  segment_load_conservation_806  1
    load_0_1_3  segment_load_conservation_820  -1
    load_0_1_3  segment_prefix_lb_821  1
    load_0_1_3  segment_prefix_ub_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_480  -20
    arc_0_1_4  connected_order_arc_481  -14
    arc_0_1_4  out_degree_802  1
    arc_0_1_4  in_degree_824  1
    arc_0_1_4  original_T_including_depot_unload_889  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_480  1
    load_0_1_4  segment_load_conservation_806  1
    load_0_1_4  segment_load_conservation_827  -1
    load_0_1_4  segment_prefix_lb_828  1
    load_0_1_4  segment_prefix_ub_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_482  -20
    arc_0_1_5  connected_order_arc_483  -14
    arc_0_1_5  out_degree_802  1
    arc_0_1_5  in_degree_831  1
    arc_0_1_5  original_T_including_depot_unload_889  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_482  1
    load_0_1_5  segment_load_conservation_806  1
    load_0_1_5  segment_load_conservation_834  -1
    load_0_1_5  segment_prefix_lb_835  1
    load_0_1_5  segment_prefix_ub_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_484  -20
    arc_0_1_14  connected_order_arc_485  -14
    arc_0_1_14  out_degree_802  1
    arc_0_1_14  in_degree_838  1
    arc_0_1_14  original_T_including_depot_unload_889  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_484  1
    load_0_1_14  segment_load_conservation_806  1
    load_0_1_14  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_486  -20
    arc_0_1_15  connected_order_arc_487  -14
    arc_0_1_15  out_degree_802  1
    arc_0_1_15  in_degree_844  1
    arc_0_1_15  original_T_including_depot_unload_889  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_486  1
    load_0_1_15  segment_load_conservation_806  1
    load_0_1_15  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_488  -20
    arc_0_1_16  connected_order_arc_489  -14
    arc_0_1_16  out_degree_802  1
    arc_0_1_16  in_degree_850  1
    arc_0_1_16  original_T_including_depot_unload_889  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_488  1
    load_0_1_16  segment_load_conservation_806  1
    load_0_1_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_490  -20
    arc_0_1_17  connected_order_arc_491  -14
    arc_0_1_17  out_degree_802  1
    arc_0_1_17  in_degree_856  1
    arc_0_1_17  original_T_including_depot_unload_889  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_490  1
    load_0_1_17  segment_load_conservation_806  1
    load_0_1_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_492  -20
    arc_0_1_18  connected_order_arc_493  -14
    arc_0_1_18  out_degree_802  1
    arc_0_1_18  in_degree_862  1
    arc_0_1_18  original_T_including_depot_unload_889  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_492  1
    load_0_1_18  segment_load_conservation_806  1
    load_0_1_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_494  -20
    arc_0_1_19  connected_order_arc_495  -14
    arc_0_1_19  out_degree_802  1
    arc_0_1_19  in_degree_868  1
    arc_0_1_19  original_T_including_depot_unload_889  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_494  1
    load_0_1_19  segment_load_conservation_806  1
    load_0_1_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_496  -20
    arc_0_1_20  connected_order_arc_497  -14
    arc_0_1_20  out_degree_802  1
    arc_0_1_20  in_degree_874  1
    arc_0_1_20  original_T_including_depot_unload_889  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_496  1
    load_0_1_20  segment_load_conservation_806  1
    load_0_1_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_498  -20
    arc_0_1_21  connected_order_arc_499  -14
    arc_0_1_21  out_degree_802  1
    arc_0_1_21  in_degree_880  1
    arc_0_1_21  original_T_including_depot_unload_889  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_498  1
    load_0_1_21  segment_load_conservation_806  1
    load_0_1_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_500  -20
    arc_0_2_0  depot_return_or_bypass_801  1
    arc_0_2_0  out_degree_809  1
    arc_0_2_0  original_T_including_depot_unload_889  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_500  1
    load_0_2_0  segment_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_501  -20
    arc_0_2_1  connected_order_arc_502  -14
    arc_0_2_1  in_degree_803  1
    arc_0_2_1  out_degree_809  1
    arc_0_2_1  original_T_including_depot_unload_889  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_501  1
    load_0_2_1  segment_load_conservation_806  -1
    load_0_2_1  segment_prefix_lb_807  1
    load_0_2_1  segment_prefix_ub_808  1
    load_0_2_1  segment_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_503  -20
    arc_0_2_3  connected_order_arc_504  -14
    arc_0_2_3  out_degree_809  1
    arc_0_2_3  in_degree_817  1
    arc_0_2_3  original_T_including_depot_unload_889  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_503  1
    load_0_2_3  segment_load_conservation_813  1
    load_0_2_3  segment_load_conservation_820  -1
    load_0_2_3  segment_prefix_lb_821  1
    load_0_2_3  segment_prefix_ub_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_505  -20
    arc_0_2_4  connected_order_arc_506  -14
    arc_0_2_4  out_degree_809  1
    arc_0_2_4  in_degree_824  1
    arc_0_2_4  original_T_including_depot_unload_889  8.8588784481112123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_505  1
    load_0_2_4  segment_load_conservation_813  1
    load_0_2_4  segment_load_conservation_827  -1
    load_0_2_4  segment_prefix_lb_828  1
    load_0_2_4  segment_prefix_ub_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_507  -20
    arc_0_2_5  connected_order_arc_508  -14
    arc_0_2_5  out_degree_809  1
    arc_0_2_5  in_degree_831  1
    arc_0_2_5  original_T_including_depot_unload_889  1.0799954902659535e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_507  1
    load_0_2_5  segment_load_conservation_813  1
    load_0_2_5  segment_load_conservation_834  -1
    load_0_2_5  segment_prefix_lb_835  1
    load_0_2_5  segment_prefix_ub_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_509  -20
    arc_0_2_14  connected_order_arc_510  -14
    arc_0_2_14  out_degree_809  1
    arc_0_2_14  in_degree_838  1
    arc_0_2_14  original_T_including_depot_unload_889  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_509  1
    load_0_2_14  segment_load_conservation_813  1
    load_0_2_14  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_511  -20
    arc_0_2_15  connected_order_arc_512  -14
    arc_0_2_15  out_degree_809  1
    arc_0_2_15  in_degree_844  1
    arc_0_2_15  original_T_including_depot_unload_889  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_511  1
    load_0_2_15  segment_load_conservation_813  1
    load_0_2_15  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_513  -20
    arc_0_2_16  connected_order_arc_514  -14
    arc_0_2_16  out_degree_809  1
    arc_0_2_16  in_degree_850  1
    arc_0_2_16  original_T_including_depot_unload_889  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_513  1
    load_0_2_16  segment_load_conservation_813  1
    load_0_2_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_515  -20
    arc_0_2_17  connected_order_arc_516  -14
    arc_0_2_17  out_degree_809  1
    arc_0_2_17  in_degree_856  1
    arc_0_2_17  original_T_including_depot_unload_889  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_515  1
    load_0_2_17  segment_load_conservation_813  1
    load_0_2_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_517  -20
    arc_0_2_18  connected_order_arc_518  -14
    arc_0_2_18  out_degree_809  1
    arc_0_2_18  in_degree_862  1
    arc_0_2_18  original_T_including_depot_unload_889  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_517  1
    load_0_2_18  segment_load_conservation_813  1
    load_0_2_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_519  -20
    arc_0_2_19  connected_order_arc_520  -14
    arc_0_2_19  out_degree_809  1
    arc_0_2_19  in_degree_868  1
    arc_0_2_19  original_T_including_depot_unload_889  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_519  1
    load_0_2_19  segment_load_conservation_813  1
    load_0_2_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_521  -20
    arc_0_2_20  connected_order_arc_522  -14
    arc_0_2_20  out_degree_809  1
    arc_0_2_20  in_degree_874  1
    arc_0_2_20  original_T_including_depot_unload_889  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_521  1
    load_0_2_20  segment_load_conservation_813  1
    load_0_2_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_523  -20
    arc_0_2_21  connected_order_arc_524  -14
    arc_0_2_21  out_degree_809  1
    arc_0_2_21  in_degree_880  1
    arc_0_2_21  original_T_including_depot_unload_889  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_523  1
    load_0_2_21  segment_load_conservation_813  1
    load_0_2_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_525  -20
    arc_0_3_0  depot_return_or_bypass_801  1
    arc_0_3_0  out_degree_816  1
    arc_0_3_0  original_T_including_depot_unload_889  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_525  1
    load_0_3_0  segment_load_conservation_820  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_526  -20
    arc_0_3_1  connected_order_arc_527  -14
    arc_0_3_1  in_degree_803  1
    arc_0_3_1  out_degree_816  1
    arc_0_3_1  original_T_including_depot_unload_889  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_526  1
    load_0_3_1  segment_load_conservation_806  -1
    load_0_3_1  segment_prefix_lb_807  1
    load_0_3_1  segment_prefix_ub_808  1
    load_0_3_1  segment_load_conservation_820  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_528  -20
    arc_0_3_2  connected_order_arc_529  -14
    arc_0_3_2  in_degree_810  1
    arc_0_3_2  out_degree_816  1
    arc_0_3_2  original_T_including_depot_unload_889  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_528  1
    load_0_3_2  segment_load_conservation_813  -1
    load_0_3_2  segment_prefix_lb_814  1
    load_0_3_2  segment_prefix_ub_815  1
    load_0_3_2  segment_load_conservation_820  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_530  -20
    arc_0_3_4  connected_order_arc_531  -14
    arc_0_3_4  out_degree_816  1
    arc_0_3_4  in_degree_824  1
    arc_0_3_4  original_T_including_depot_unload_889  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_530  1
    load_0_3_4  segment_load_conservation_820  1
    load_0_3_4  segment_load_conservation_827  -1
    load_0_3_4  segment_prefix_lb_828  1
    load_0_3_4  segment_prefix_ub_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_532  -20
    arc_0_3_5  connected_order_arc_533  -14
    arc_0_3_5  out_degree_816  1
    arc_0_3_5  in_degree_831  1
    arc_0_3_5  original_T_including_depot_unload_889  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_532  1
    load_0_3_5  segment_load_conservation_820  1
    load_0_3_5  segment_load_conservation_834  -1
    load_0_3_5  segment_prefix_lb_835  1
    load_0_3_5  segment_prefix_ub_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_534  -20
    arc_0_3_14  connected_order_arc_535  -14
    arc_0_3_14  out_degree_816  1
    arc_0_3_14  in_degree_838  1
    arc_0_3_14  original_T_including_depot_unload_889  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_534  1
    load_0_3_14  segment_load_conservation_820  1
    load_0_3_14  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_536  -20
    arc_0_3_15  connected_order_arc_537  -14
    arc_0_3_15  out_degree_816  1
    arc_0_3_15  in_degree_844  1
    arc_0_3_15  original_T_including_depot_unload_889  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_536  1
    load_0_3_15  segment_load_conservation_820  1
    load_0_3_15  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_538  -20
    arc_0_3_16  connected_order_arc_539  -14
    arc_0_3_16  out_degree_816  1
    arc_0_3_16  in_degree_850  1
    arc_0_3_16  original_T_including_depot_unload_889  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_538  1
    load_0_3_16  segment_load_conservation_820  1
    load_0_3_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_540  -20
    arc_0_3_17  connected_order_arc_541  -14
    arc_0_3_17  out_degree_816  1
    arc_0_3_17  in_degree_856  1
    arc_0_3_17  original_T_including_depot_unload_889  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_540  1
    load_0_3_17  segment_load_conservation_820  1
    load_0_3_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_542  -20
    arc_0_3_18  connected_order_arc_543  -14
    arc_0_3_18  out_degree_816  1
    arc_0_3_18  in_degree_862  1
    arc_0_3_18  original_T_including_depot_unload_889  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_542  1
    load_0_3_18  segment_load_conservation_820  1
    load_0_3_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_544  -20
    arc_0_3_19  connected_order_arc_545  -14
    arc_0_3_19  out_degree_816  1
    arc_0_3_19  in_degree_868  1
    arc_0_3_19  original_T_including_depot_unload_889  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_544  1
    load_0_3_19  segment_load_conservation_820  1
    load_0_3_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_546  -20
    arc_0_3_20  connected_order_arc_547  -14
    arc_0_3_20  out_degree_816  1
    arc_0_3_20  in_degree_874  1
    arc_0_3_20  original_T_including_depot_unload_889  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_546  1
    load_0_3_20  segment_load_conservation_820  1
    load_0_3_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_548  -20
    arc_0_3_21  connected_order_arc_549  -14
    arc_0_3_21  out_degree_816  1
    arc_0_3_21  in_degree_880  1
    arc_0_3_21  original_T_including_depot_unload_889  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_548  1
    load_0_3_21  segment_load_conservation_820  1
    load_0_3_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_550  -20
    arc_0_4_0  depot_return_or_bypass_801  1
    arc_0_4_0  out_degree_823  1
    arc_0_4_0  original_T_including_depot_unload_889  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_550  1
    load_0_4_0  segment_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_551  -20
    arc_0_4_1  connected_order_arc_552  -14
    arc_0_4_1  in_degree_803  1
    arc_0_4_1  out_degree_823  1
    arc_0_4_1  original_T_including_depot_unload_889  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_551  1
    load_0_4_1  segment_load_conservation_806  -1
    load_0_4_1  segment_prefix_lb_807  1
    load_0_4_1  segment_prefix_ub_808  1
    load_0_4_1  segment_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_553  -20
    arc_0_4_2  connected_order_arc_554  -14
    arc_0_4_2  in_degree_810  1
    arc_0_4_2  out_degree_823  1
    arc_0_4_2  original_T_including_depot_unload_889  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_553  1
    load_0_4_2  segment_load_conservation_813  -1
    load_0_4_2  segment_prefix_lb_814  1
    load_0_4_2  segment_prefix_ub_815  1
    load_0_4_2  segment_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_555  -20
    arc_0_4_3  connected_order_arc_556  -14
    arc_0_4_3  in_degree_817  1
    arc_0_4_3  out_degree_823  1
    arc_0_4_3  original_T_including_depot_unload_889  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_555  1
    load_0_4_3  segment_load_conservation_820  -1
    load_0_4_3  segment_prefix_lb_821  1
    load_0_4_3  segment_prefix_ub_822  1
    load_0_4_3  segment_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_557  -20
    arc_0_4_5  connected_order_arc_558  -14
    arc_0_4_5  out_degree_823  1
    arc_0_4_5  in_degree_831  1
    arc_0_4_5  original_T_including_depot_unload_889  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_557  1
    load_0_4_5  segment_load_conservation_827  1
    load_0_4_5  segment_load_conservation_834  -1
    load_0_4_5  segment_prefix_lb_835  1
    load_0_4_5  segment_prefix_ub_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_559  -20
    arc_0_4_14  connected_order_arc_560  -14
    arc_0_4_14  out_degree_823  1
    arc_0_4_14  in_degree_838  1
    arc_0_4_14  original_T_including_depot_unload_889  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_559  1
    load_0_4_14  segment_load_conservation_827  1
    load_0_4_14  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_561  -20
    arc_0_4_15  connected_order_arc_562  -14
    arc_0_4_15  out_degree_823  1
    arc_0_4_15  in_degree_844  1
    arc_0_4_15  original_T_including_depot_unload_889  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_561  1
    load_0_4_15  segment_load_conservation_827  1
    load_0_4_15  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_563  -20
    arc_0_4_16  connected_order_arc_564  -14
    arc_0_4_16  out_degree_823  1
    arc_0_4_16  in_degree_850  1
    arc_0_4_16  original_T_including_depot_unload_889  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_563  1
    load_0_4_16  segment_load_conservation_827  1
    load_0_4_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_565  -20
    arc_0_4_17  connected_order_arc_566  -14
    arc_0_4_17  out_degree_823  1
    arc_0_4_17  in_degree_856  1
    arc_0_4_17  original_T_including_depot_unload_889  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_565  1
    load_0_4_17  segment_load_conservation_827  1
    load_0_4_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_567  -20
    arc_0_4_18  connected_order_arc_568  -14
    arc_0_4_18  out_degree_823  1
    arc_0_4_18  in_degree_862  1
    arc_0_4_18  original_T_including_depot_unload_889  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_567  1
    load_0_4_18  segment_load_conservation_827  1
    load_0_4_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_569  -20
    arc_0_4_19  connected_order_arc_570  -14
    arc_0_4_19  out_degree_823  1
    arc_0_4_19  in_degree_868  1
    arc_0_4_19  original_T_including_depot_unload_889  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_569  1
    load_0_4_19  segment_load_conservation_827  1
    load_0_4_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_571  -20
    arc_0_4_20  connected_order_arc_572  -14
    arc_0_4_20  out_degree_823  1
    arc_0_4_20  in_degree_874  1
    arc_0_4_20  original_T_including_depot_unload_889  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_571  1
    load_0_4_20  segment_load_conservation_827  1
    load_0_4_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_573  -20
    arc_0_4_21  connected_order_arc_574  -14
    arc_0_4_21  out_degree_823  1
    arc_0_4_21  in_degree_880  1
    arc_0_4_21  original_T_including_depot_unload_889  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_573  1
    load_0_4_21  segment_load_conservation_827  1
    load_0_4_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_575  -20
    arc_0_5_0  depot_return_or_bypass_801  1
    arc_0_5_0  out_degree_830  1
    arc_0_5_0  original_T_including_depot_unload_889  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_575  1
    load_0_5_0  segment_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_576  -20
    arc_0_5_1  connected_order_arc_577  -14
    arc_0_5_1  in_degree_803  1
    arc_0_5_1  out_degree_830  1
    arc_0_5_1  original_T_including_depot_unload_889  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_576  1
    load_0_5_1  segment_load_conservation_806  -1
    load_0_5_1  segment_prefix_lb_807  1
    load_0_5_1  segment_prefix_ub_808  1
    load_0_5_1  segment_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_578  -20
    arc_0_5_2  connected_order_arc_579  -14
    arc_0_5_2  in_degree_810  1
    arc_0_5_2  out_degree_830  1
    arc_0_5_2  original_T_including_depot_unload_889  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_578  1
    load_0_5_2  segment_load_conservation_813  -1
    load_0_5_2  segment_prefix_lb_814  1
    load_0_5_2  segment_prefix_ub_815  1
    load_0_5_2  segment_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_580  -20
    arc_0_5_3  connected_order_arc_581  -14
    arc_0_5_3  in_degree_817  1
    arc_0_5_3  out_degree_830  1
    arc_0_5_3  original_T_including_depot_unload_889  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_580  1
    load_0_5_3  segment_load_conservation_820  -1
    load_0_5_3  segment_prefix_lb_821  1
    load_0_5_3  segment_prefix_ub_822  1
    load_0_5_3  segment_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_582  -20
    arc_0_5_4  connected_order_arc_583  -14
    arc_0_5_4  in_degree_824  1
    arc_0_5_4  out_degree_830  1
    arc_0_5_4  original_T_including_depot_unload_889  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_582  1
    load_0_5_4  segment_load_conservation_827  -1
    load_0_5_4  segment_prefix_lb_828  1
    load_0_5_4  segment_prefix_ub_829  1
    load_0_5_4  segment_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_584  -20
    arc_0_5_14  connected_order_arc_585  -14
    arc_0_5_14  out_degree_830  1
    arc_0_5_14  in_degree_838  1
    arc_0_5_14  original_T_including_depot_unload_889  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_584  1
    load_0_5_14  segment_load_conservation_834  1
    load_0_5_14  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_586  -20
    arc_0_5_15  connected_order_arc_587  -14
    arc_0_5_15  out_degree_830  1
    arc_0_5_15  in_degree_844  1
    arc_0_5_15  original_T_including_depot_unload_889  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_586  1
    load_0_5_15  segment_load_conservation_834  1
    load_0_5_15  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_588  -20
    arc_0_5_16  connected_order_arc_589  -14
    arc_0_5_16  out_degree_830  1
    arc_0_5_16  in_degree_850  1
    arc_0_5_16  original_T_including_depot_unload_889  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_588  1
    load_0_5_16  segment_load_conservation_834  1
    load_0_5_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_590  -20
    arc_0_5_17  connected_order_arc_591  -14
    arc_0_5_17  out_degree_830  1
    arc_0_5_17  in_degree_856  1
    arc_0_5_17  original_T_including_depot_unload_889  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_590  1
    load_0_5_17  segment_load_conservation_834  1
    load_0_5_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_592  -20
    arc_0_5_18  connected_order_arc_593  -14
    arc_0_5_18  out_degree_830  1
    arc_0_5_18  in_degree_862  1
    arc_0_5_18  original_T_including_depot_unload_889  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_592  1
    load_0_5_18  segment_load_conservation_834  1
    load_0_5_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_594  -20
    arc_0_5_19  connected_order_arc_595  -14
    arc_0_5_19  out_degree_830  1
    arc_0_5_19  in_degree_868  1
    arc_0_5_19  original_T_including_depot_unload_889  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_594  1
    load_0_5_19  segment_load_conservation_834  1
    load_0_5_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_596  -20
    arc_0_5_20  connected_order_arc_597  -14
    arc_0_5_20  out_degree_830  1
    arc_0_5_20  in_degree_874  1
    arc_0_5_20  original_T_including_depot_unload_889  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_596  1
    load_0_5_20  segment_load_conservation_834  1
    load_0_5_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_598  -20
    arc_0_5_21  connected_order_arc_599  -14
    arc_0_5_21  out_degree_830  1
    arc_0_5_21  in_degree_880  1
    arc_0_5_21  original_T_including_depot_unload_889  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_598  1
    load_0_5_21  segment_load_conservation_834  1
    load_0_5_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_600  -20
    arc_0_14_0  depot_return_or_bypass_801  1
    arc_0_14_0  out_degree_837  1
    arc_0_14_0  original_T_including_depot_unload_889  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_600  1
    load_0_14_0  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_601  -20
    arc_0_14_1  connected_order_arc_602  -14
    arc_0_14_1  in_degree_803  1
    arc_0_14_1  out_degree_837  1
    arc_0_14_1  original_T_including_depot_unload_889  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_601  1
    load_0_14_1  segment_load_conservation_806  -1
    load_0_14_1  segment_prefix_lb_807  1
    load_0_14_1  segment_prefix_ub_808  1
    load_0_14_1  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_603  -20
    arc_0_14_2  connected_order_arc_604  -14
    arc_0_14_2  in_degree_810  1
    arc_0_14_2  out_degree_837  1
    arc_0_14_2  original_T_including_depot_unload_889  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_603  1
    load_0_14_2  segment_load_conservation_813  -1
    load_0_14_2  segment_prefix_lb_814  1
    load_0_14_2  segment_prefix_ub_815  1
    load_0_14_2  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_605  -20
    arc_0_14_3  connected_order_arc_606  -14
    arc_0_14_3  in_degree_817  1
    arc_0_14_3  out_degree_837  1
    arc_0_14_3  original_T_including_depot_unload_889  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_605  1
    load_0_14_3  segment_load_conservation_820  -1
    load_0_14_3  segment_prefix_lb_821  1
    load_0_14_3  segment_prefix_ub_822  1
    load_0_14_3  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_607  -20
    arc_0_14_4  connected_order_arc_608  -14
    arc_0_14_4  in_degree_824  1
    arc_0_14_4  out_degree_837  1
    arc_0_14_4  original_T_including_depot_unload_889  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_607  1
    load_0_14_4  segment_load_conservation_827  -1
    load_0_14_4  segment_prefix_lb_828  1
    load_0_14_4  segment_prefix_ub_829  1
    load_0_14_4  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_609  -20
    arc_0_14_5  connected_order_arc_610  -14
    arc_0_14_5  in_degree_831  1
    arc_0_14_5  out_degree_837  1
    arc_0_14_5  original_T_including_depot_unload_889  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_609  1
    load_0_14_5  segment_load_conservation_834  -1
    load_0_14_5  segment_prefix_lb_835  1
    load_0_14_5  segment_prefix_ub_836  1
    load_0_14_5  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_611  -20
    arc_0_14_15  connected_order_arc_612  -14
    arc_0_14_15  out_degree_837  1
    arc_0_14_15  in_degree_844  1
    arc_0_14_15  original_T_including_depot_unload_889  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_611  1
    load_0_14_15  free_load_conservation_842  1
    load_0_14_15  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_613  -20
    arc_0_14_16  connected_order_arc_614  -14
    arc_0_14_16  out_degree_837  1
    arc_0_14_16  in_degree_850  1
    arc_0_14_16  original_T_including_depot_unload_889  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_613  1
    load_0_14_16  free_load_conservation_842  1
    load_0_14_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_615  -20
    arc_0_14_17  connected_order_arc_616  -14
    arc_0_14_17  out_degree_837  1
    arc_0_14_17  in_degree_856  1
    arc_0_14_17  original_T_including_depot_unload_889  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_615  1
    load_0_14_17  free_load_conservation_842  1
    load_0_14_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_617  -20
    arc_0_14_18  connected_order_arc_618  -14
    arc_0_14_18  out_degree_837  1
    arc_0_14_18  in_degree_862  1
    arc_0_14_18  original_T_including_depot_unload_889  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_617  1
    load_0_14_18  free_load_conservation_842  1
    load_0_14_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_619  -20
    arc_0_14_19  connected_order_arc_620  -14
    arc_0_14_19  out_degree_837  1
    arc_0_14_19  in_degree_868  1
    arc_0_14_19  original_T_including_depot_unload_889  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_619  1
    load_0_14_19  free_load_conservation_842  1
    load_0_14_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_621  -20
    arc_0_14_20  connected_order_arc_622  -14
    arc_0_14_20  out_degree_837  1
    arc_0_14_20  in_degree_874  1
    arc_0_14_20  original_T_including_depot_unload_889  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_621  1
    load_0_14_20  free_load_conservation_842  1
    load_0_14_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_623  -20
    arc_0_14_21  connected_order_arc_624  -14
    arc_0_14_21  out_degree_837  1
    arc_0_14_21  in_degree_880  1
    arc_0_14_21  original_T_including_depot_unload_889  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_623  1
    load_0_14_21  free_load_conservation_842  1
    load_0_14_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_625  -20
    arc_0_15_0  depot_return_or_bypass_801  1
    arc_0_15_0  out_degree_843  1
    arc_0_15_0  original_T_including_depot_unload_889  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_625  1
    load_0_15_0  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_626  -20
    arc_0_15_1  connected_order_arc_627  -14
    arc_0_15_1  in_degree_803  1
    arc_0_15_1  out_degree_843  1
    arc_0_15_1  original_T_including_depot_unload_889  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_626  1
    load_0_15_1  segment_load_conservation_806  -1
    load_0_15_1  segment_prefix_lb_807  1
    load_0_15_1  segment_prefix_ub_808  1
    load_0_15_1  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_628  -20
    arc_0_15_2  connected_order_arc_629  -14
    arc_0_15_2  in_degree_810  1
    arc_0_15_2  out_degree_843  1
    arc_0_15_2  original_T_including_depot_unload_889  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_628  1
    load_0_15_2  segment_load_conservation_813  -1
    load_0_15_2  segment_prefix_lb_814  1
    load_0_15_2  segment_prefix_ub_815  1
    load_0_15_2  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_630  -20
    arc_0_15_3  connected_order_arc_631  -14
    arc_0_15_3  in_degree_817  1
    arc_0_15_3  out_degree_843  1
    arc_0_15_3  original_T_including_depot_unload_889  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_630  1
    load_0_15_3  segment_load_conservation_820  -1
    load_0_15_3  segment_prefix_lb_821  1
    load_0_15_3  segment_prefix_ub_822  1
    load_0_15_3  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_632  -20
    arc_0_15_4  connected_order_arc_633  -14
    arc_0_15_4  in_degree_824  1
    arc_0_15_4  out_degree_843  1
    arc_0_15_4  original_T_including_depot_unload_889  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_632  1
    load_0_15_4  segment_load_conservation_827  -1
    load_0_15_4  segment_prefix_lb_828  1
    load_0_15_4  segment_prefix_ub_829  1
    load_0_15_4  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_634  -20
    arc_0_15_5  connected_order_arc_635  -14
    arc_0_15_5  in_degree_831  1
    arc_0_15_5  out_degree_843  1
    arc_0_15_5  original_T_including_depot_unload_889  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_634  1
    load_0_15_5  segment_load_conservation_834  -1
    load_0_15_5  segment_prefix_lb_835  1
    load_0_15_5  segment_prefix_ub_836  1
    load_0_15_5  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_636  -20
    arc_0_15_14  connected_order_arc_637  -14
    arc_0_15_14  in_degree_838  1
    arc_0_15_14  out_degree_843  1
    arc_0_15_14  original_T_including_depot_unload_889  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_636  1
    load_0_15_14  free_load_conservation_842  -1
    load_0_15_14  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_638  -20
    arc_0_15_16  connected_order_arc_639  -14
    arc_0_15_16  out_degree_843  1
    arc_0_15_16  in_degree_850  1
    arc_0_15_16  original_T_including_depot_unload_889  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_638  1
    load_0_15_16  free_load_conservation_848  1
    load_0_15_16  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_640  -20
    arc_0_15_17  connected_order_arc_641  -14
    arc_0_15_17  out_degree_843  1
    arc_0_15_17  in_degree_856  1
    arc_0_15_17  original_T_including_depot_unload_889  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_640  1
    load_0_15_17  free_load_conservation_848  1
    load_0_15_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_642  -20
    arc_0_15_18  connected_order_arc_643  -14
    arc_0_15_18  out_degree_843  1
    arc_0_15_18  in_degree_862  1
    arc_0_15_18  original_T_including_depot_unload_889  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_642  1
    load_0_15_18  free_load_conservation_848  1
    load_0_15_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_644  -20
    arc_0_15_19  connected_order_arc_645  -14
    arc_0_15_19  out_degree_843  1
    arc_0_15_19  in_degree_868  1
    arc_0_15_19  original_T_including_depot_unload_889  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_644  1
    load_0_15_19  free_load_conservation_848  1
    load_0_15_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_646  -20
    arc_0_15_20  connected_order_arc_647  -14
    arc_0_15_20  out_degree_843  1
    arc_0_15_20  in_degree_874  1
    arc_0_15_20  original_T_including_depot_unload_889  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_646  1
    load_0_15_20  free_load_conservation_848  1
    load_0_15_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_648  -20
    arc_0_15_21  connected_order_arc_649  -14
    arc_0_15_21  out_degree_843  1
    arc_0_15_21  in_degree_880  1
    arc_0_15_21  original_T_including_depot_unload_889  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_648  1
    load_0_15_21  free_load_conservation_848  1
    load_0_15_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_650  -20
    arc_0_16_0  depot_return_or_bypass_801  1
    arc_0_16_0  out_degree_849  1
    arc_0_16_0  original_T_including_depot_unload_889  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_650  1
    load_0_16_0  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_651  -20
    arc_0_16_1  connected_order_arc_652  -14
    arc_0_16_1  in_degree_803  1
    arc_0_16_1  out_degree_849  1
    arc_0_16_1  original_T_including_depot_unload_889  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_651  1
    load_0_16_1  segment_load_conservation_806  -1
    load_0_16_1  segment_prefix_lb_807  1
    load_0_16_1  segment_prefix_ub_808  1
    load_0_16_1  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_653  -20
    arc_0_16_2  connected_order_arc_654  -14
    arc_0_16_2  in_degree_810  1
    arc_0_16_2  out_degree_849  1
    arc_0_16_2  original_T_including_depot_unload_889  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_653  1
    load_0_16_2  segment_load_conservation_813  -1
    load_0_16_2  segment_prefix_lb_814  1
    load_0_16_2  segment_prefix_ub_815  1
    load_0_16_2  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_655  -20
    arc_0_16_3  connected_order_arc_656  -14
    arc_0_16_3  in_degree_817  1
    arc_0_16_3  out_degree_849  1
    arc_0_16_3  original_T_including_depot_unload_889  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_655  1
    load_0_16_3  segment_load_conservation_820  -1
    load_0_16_3  segment_prefix_lb_821  1
    load_0_16_3  segment_prefix_ub_822  1
    load_0_16_3  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_657  -20
    arc_0_16_4  connected_order_arc_658  -14
    arc_0_16_4  in_degree_824  1
    arc_0_16_4  out_degree_849  1
    arc_0_16_4  original_T_including_depot_unload_889  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_657  1
    load_0_16_4  segment_load_conservation_827  -1
    load_0_16_4  segment_prefix_lb_828  1
    load_0_16_4  segment_prefix_ub_829  1
    load_0_16_4  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_659  -20
    arc_0_16_5  connected_order_arc_660  -14
    arc_0_16_5  in_degree_831  1
    arc_0_16_5  out_degree_849  1
    arc_0_16_5  original_T_including_depot_unload_889  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_659  1
    load_0_16_5  segment_load_conservation_834  -1
    load_0_16_5  segment_prefix_lb_835  1
    load_0_16_5  segment_prefix_ub_836  1
    load_0_16_5  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_661  -20
    arc_0_16_14  connected_order_arc_662  -14
    arc_0_16_14  in_degree_838  1
    arc_0_16_14  out_degree_849  1
    arc_0_16_14  original_T_including_depot_unload_889  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_661  1
    load_0_16_14  free_load_conservation_842  -1
    load_0_16_14  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_663  -20
    arc_0_16_15  connected_order_arc_664  -14
    arc_0_16_15  in_degree_844  1
    arc_0_16_15  out_degree_849  1
    arc_0_16_15  original_T_including_depot_unload_889  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_663  1
    load_0_16_15  free_load_conservation_848  -1
    load_0_16_15  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_665  -20
    arc_0_16_17  connected_order_arc_666  -14
    arc_0_16_17  out_degree_849  1
    arc_0_16_17  in_degree_856  1
    arc_0_16_17  original_T_including_depot_unload_889  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_665  1
    load_0_16_17  free_load_conservation_854  1
    load_0_16_17  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_667  -20
    arc_0_16_18  connected_order_arc_668  -14
    arc_0_16_18  out_degree_849  1
    arc_0_16_18  in_degree_862  1
    arc_0_16_18  original_T_including_depot_unload_889  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_667  1
    load_0_16_18  free_load_conservation_854  1
    load_0_16_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_669  -20
    arc_0_16_19  connected_order_arc_670  -14
    arc_0_16_19  out_degree_849  1
    arc_0_16_19  in_degree_868  1
    arc_0_16_19  original_T_including_depot_unload_889  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_669  1
    load_0_16_19  free_load_conservation_854  1
    load_0_16_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_671  -20
    arc_0_16_20  connected_order_arc_672  -14
    arc_0_16_20  out_degree_849  1
    arc_0_16_20  in_degree_874  1
    arc_0_16_20  original_T_including_depot_unload_889  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_671  1
    load_0_16_20  free_load_conservation_854  1
    load_0_16_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_673  -20
    arc_0_16_21  connected_order_arc_674  -14
    arc_0_16_21  out_degree_849  1
    arc_0_16_21  in_degree_880  1
    arc_0_16_21  original_T_including_depot_unload_889  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_673  1
    load_0_16_21  free_load_conservation_854  1
    load_0_16_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_675  -20
    arc_0_17_0  depot_return_or_bypass_801  1
    arc_0_17_0  out_degree_855  1
    arc_0_17_0  original_T_including_depot_unload_889  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_675  1
    load_0_17_0  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_676  -20
    arc_0_17_1  connected_order_arc_677  -14
    arc_0_17_1  in_degree_803  1
    arc_0_17_1  out_degree_855  1
    arc_0_17_1  original_T_including_depot_unload_889  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_676  1
    load_0_17_1  segment_load_conservation_806  -1
    load_0_17_1  segment_prefix_lb_807  1
    load_0_17_1  segment_prefix_ub_808  1
    load_0_17_1  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_678  -20
    arc_0_17_2  connected_order_arc_679  -14
    arc_0_17_2  in_degree_810  1
    arc_0_17_2  out_degree_855  1
    arc_0_17_2  original_T_including_depot_unload_889  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_678  1
    load_0_17_2  segment_load_conservation_813  -1
    load_0_17_2  segment_prefix_lb_814  1
    load_0_17_2  segment_prefix_ub_815  1
    load_0_17_2  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_680  -20
    arc_0_17_3  connected_order_arc_681  -14
    arc_0_17_3  in_degree_817  1
    arc_0_17_3  out_degree_855  1
    arc_0_17_3  original_T_including_depot_unload_889  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_680  1
    load_0_17_3  segment_load_conservation_820  -1
    load_0_17_3  segment_prefix_lb_821  1
    load_0_17_3  segment_prefix_ub_822  1
    load_0_17_3  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_682  -20
    arc_0_17_4  connected_order_arc_683  -14
    arc_0_17_4  in_degree_824  1
    arc_0_17_4  out_degree_855  1
    arc_0_17_4  original_T_including_depot_unload_889  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_682  1
    load_0_17_4  segment_load_conservation_827  -1
    load_0_17_4  segment_prefix_lb_828  1
    load_0_17_4  segment_prefix_ub_829  1
    load_0_17_4  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_684  -20
    arc_0_17_5  connected_order_arc_685  -14
    arc_0_17_5  in_degree_831  1
    arc_0_17_5  out_degree_855  1
    arc_0_17_5  original_T_including_depot_unload_889  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_684  1
    load_0_17_5  segment_load_conservation_834  -1
    load_0_17_5  segment_prefix_lb_835  1
    load_0_17_5  segment_prefix_ub_836  1
    load_0_17_5  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_686  -20
    arc_0_17_14  connected_order_arc_687  -14
    arc_0_17_14  in_degree_838  1
    arc_0_17_14  out_degree_855  1
    arc_0_17_14  original_T_including_depot_unload_889  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_686  1
    load_0_17_14  free_load_conservation_842  -1
    load_0_17_14  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_688  -20
    arc_0_17_15  connected_order_arc_689  -14
    arc_0_17_15  in_degree_844  1
    arc_0_17_15  out_degree_855  1
    arc_0_17_15  original_T_including_depot_unload_889  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_688  1
    load_0_17_15  free_load_conservation_848  -1
    load_0_17_15  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_690  -20
    arc_0_17_16  connected_order_arc_691  -14
    arc_0_17_16  in_degree_850  1
    arc_0_17_16  out_degree_855  1
    arc_0_17_16  original_T_including_depot_unload_889  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_690  1
    load_0_17_16  free_load_conservation_854  -1
    load_0_17_16  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_692  -20
    arc_0_17_18  connected_order_arc_693  -14
    arc_0_17_18  out_degree_855  1
    arc_0_17_18  in_degree_862  1
    arc_0_17_18  original_T_including_depot_unload_889  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_692  1
    load_0_17_18  free_load_conservation_860  1
    load_0_17_18  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_694  -20
    arc_0_17_19  connected_order_arc_695  -14
    arc_0_17_19  out_degree_855  1
    arc_0_17_19  in_degree_868  1
    arc_0_17_19  original_T_including_depot_unload_889  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_694  1
    load_0_17_19  free_load_conservation_860  1
    load_0_17_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_696  -20
    arc_0_17_20  connected_order_arc_697  -14
    arc_0_17_20  out_degree_855  1
    arc_0_17_20  in_degree_874  1
    arc_0_17_20  original_T_including_depot_unload_889  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_696  1
    load_0_17_20  free_load_conservation_860  1
    load_0_17_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_698  -20
    arc_0_17_21  connected_order_arc_699  -14
    arc_0_17_21  out_degree_855  1
    arc_0_17_21  in_degree_880  1
    arc_0_17_21  original_T_including_depot_unload_889  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_698  1
    load_0_17_21  free_load_conservation_860  1
    load_0_17_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_700  -20
    arc_0_18_0  depot_return_or_bypass_801  1
    arc_0_18_0  out_degree_861  1
    arc_0_18_0  original_T_including_depot_unload_889  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_700  1
    load_0_18_0  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_701  -20
    arc_0_18_1  connected_order_arc_702  -14
    arc_0_18_1  in_degree_803  1
    arc_0_18_1  out_degree_861  1
    arc_0_18_1  original_T_including_depot_unload_889  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_701  1
    load_0_18_1  segment_load_conservation_806  -1
    load_0_18_1  segment_prefix_lb_807  1
    load_0_18_1  segment_prefix_ub_808  1
    load_0_18_1  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_703  -20
    arc_0_18_2  connected_order_arc_704  -14
    arc_0_18_2  in_degree_810  1
    arc_0_18_2  out_degree_861  1
    arc_0_18_2  original_T_including_depot_unload_889  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_703  1
    load_0_18_2  segment_load_conservation_813  -1
    load_0_18_2  segment_prefix_lb_814  1
    load_0_18_2  segment_prefix_ub_815  1
    load_0_18_2  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_705  -20
    arc_0_18_3  connected_order_arc_706  -14
    arc_0_18_3  in_degree_817  1
    arc_0_18_3  out_degree_861  1
    arc_0_18_3  original_T_including_depot_unload_889  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_705  1
    load_0_18_3  segment_load_conservation_820  -1
    load_0_18_3  segment_prefix_lb_821  1
    load_0_18_3  segment_prefix_ub_822  1
    load_0_18_3  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_707  -20
    arc_0_18_4  connected_order_arc_708  -14
    arc_0_18_4  in_degree_824  1
    arc_0_18_4  out_degree_861  1
    arc_0_18_4  original_T_including_depot_unload_889  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_707  1
    load_0_18_4  segment_load_conservation_827  -1
    load_0_18_4  segment_prefix_lb_828  1
    load_0_18_4  segment_prefix_ub_829  1
    load_0_18_4  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_709  -20
    arc_0_18_5  connected_order_arc_710  -14
    arc_0_18_5  in_degree_831  1
    arc_0_18_5  out_degree_861  1
    arc_0_18_5  original_T_including_depot_unload_889  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_709  1
    load_0_18_5  segment_load_conservation_834  -1
    load_0_18_5  segment_prefix_lb_835  1
    load_0_18_5  segment_prefix_ub_836  1
    load_0_18_5  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_711  -20
    arc_0_18_14  connected_order_arc_712  -14
    arc_0_18_14  in_degree_838  1
    arc_0_18_14  out_degree_861  1
    arc_0_18_14  original_T_including_depot_unload_889  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_711  1
    load_0_18_14  free_load_conservation_842  -1
    load_0_18_14  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_713  -20
    arc_0_18_15  connected_order_arc_714  -14
    arc_0_18_15  in_degree_844  1
    arc_0_18_15  out_degree_861  1
    arc_0_18_15  original_T_including_depot_unload_889  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_713  1
    load_0_18_15  free_load_conservation_848  -1
    load_0_18_15  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_715  -20
    arc_0_18_16  connected_order_arc_716  -14
    arc_0_18_16  in_degree_850  1
    arc_0_18_16  out_degree_861  1
    arc_0_18_16  original_T_including_depot_unload_889  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_715  1
    load_0_18_16  free_load_conservation_854  -1
    load_0_18_16  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_717  -20
    arc_0_18_17  connected_order_arc_718  -14
    arc_0_18_17  in_degree_856  1
    arc_0_18_17  out_degree_861  1
    arc_0_18_17  original_T_including_depot_unload_889  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_717  1
    load_0_18_17  free_load_conservation_860  -1
    load_0_18_17  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_719  -20
    arc_0_18_19  connected_order_arc_720  -14
    arc_0_18_19  out_degree_861  1
    arc_0_18_19  in_degree_868  1
    arc_0_18_19  original_T_including_depot_unload_889  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_719  1
    load_0_18_19  free_load_conservation_866  1
    load_0_18_19  free_load_conservation_872  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_721  -20
    arc_0_18_20  connected_order_arc_722  -14
    arc_0_18_20  out_degree_861  1
    arc_0_18_20  in_degree_874  1
    arc_0_18_20  original_T_including_depot_unload_889  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_721  1
    load_0_18_20  free_load_conservation_866  1
    load_0_18_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_723  -20
    arc_0_18_21  connected_order_arc_724  -14
    arc_0_18_21  out_degree_861  1
    arc_0_18_21  in_degree_880  1
    arc_0_18_21  original_T_including_depot_unload_889  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_723  1
    load_0_18_21  free_load_conservation_866  1
    load_0_18_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_725  -20
    arc_0_19_0  depot_return_or_bypass_801  1
    arc_0_19_0  out_degree_867  1
    arc_0_19_0  original_T_including_depot_unload_889  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_725  1
    load_0_19_0  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_726  -20
    arc_0_19_1  connected_order_arc_727  -14
    arc_0_19_1  in_degree_803  1
    arc_0_19_1  out_degree_867  1
    arc_0_19_1  original_T_including_depot_unload_889  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_726  1
    load_0_19_1  segment_load_conservation_806  -1
    load_0_19_1  segment_prefix_lb_807  1
    load_0_19_1  segment_prefix_ub_808  1
    load_0_19_1  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_728  -20
    arc_0_19_2  connected_order_arc_729  -14
    arc_0_19_2  in_degree_810  1
    arc_0_19_2  out_degree_867  1
    arc_0_19_2  original_T_including_depot_unload_889  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_728  1
    load_0_19_2  segment_load_conservation_813  -1
    load_0_19_2  segment_prefix_lb_814  1
    load_0_19_2  segment_prefix_ub_815  1
    load_0_19_2  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_730  -20
    arc_0_19_3  connected_order_arc_731  -14
    arc_0_19_3  in_degree_817  1
    arc_0_19_3  out_degree_867  1
    arc_0_19_3  original_T_including_depot_unload_889  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_730  1
    load_0_19_3  segment_load_conservation_820  -1
    load_0_19_3  segment_prefix_lb_821  1
    load_0_19_3  segment_prefix_ub_822  1
    load_0_19_3  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_732  -20
    arc_0_19_4  connected_order_arc_733  -14
    arc_0_19_4  in_degree_824  1
    arc_0_19_4  out_degree_867  1
    arc_0_19_4  original_T_including_depot_unload_889  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_732  1
    load_0_19_4  segment_load_conservation_827  -1
    load_0_19_4  segment_prefix_lb_828  1
    load_0_19_4  segment_prefix_ub_829  1
    load_0_19_4  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_734  -20
    arc_0_19_5  connected_order_arc_735  -14
    arc_0_19_5  in_degree_831  1
    arc_0_19_5  out_degree_867  1
    arc_0_19_5  original_T_including_depot_unload_889  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_734  1
    load_0_19_5  segment_load_conservation_834  -1
    load_0_19_5  segment_prefix_lb_835  1
    load_0_19_5  segment_prefix_ub_836  1
    load_0_19_5  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_736  -20
    arc_0_19_14  connected_order_arc_737  -14
    arc_0_19_14  in_degree_838  1
    arc_0_19_14  out_degree_867  1
    arc_0_19_14  original_T_including_depot_unload_889  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_736  1
    load_0_19_14  free_load_conservation_842  -1
    load_0_19_14  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_738  -20
    arc_0_19_15  connected_order_arc_739  -14
    arc_0_19_15  in_degree_844  1
    arc_0_19_15  out_degree_867  1
    arc_0_19_15  original_T_including_depot_unload_889  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_738  1
    load_0_19_15  free_load_conservation_848  -1
    load_0_19_15  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_740  -20
    arc_0_19_16  connected_order_arc_741  -14
    arc_0_19_16  in_degree_850  1
    arc_0_19_16  out_degree_867  1
    arc_0_19_16  original_T_including_depot_unload_889  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_740  1
    load_0_19_16  free_load_conservation_854  -1
    load_0_19_16  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_742  -20
    arc_0_19_17  connected_order_arc_743  -14
    arc_0_19_17  in_degree_856  1
    arc_0_19_17  out_degree_867  1
    arc_0_19_17  original_T_including_depot_unload_889  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_742  1
    load_0_19_17  free_load_conservation_860  -1
    load_0_19_17  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_744  -20
    arc_0_19_18  connected_order_arc_745  -14
    arc_0_19_18  in_degree_862  1
    arc_0_19_18  out_degree_867  1
    arc_0_19_18  original_T_including_depot_unload_889  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_744  1
    load_0_19_18  free_load_conservation_866  -1
    load_0_19_18  free_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_746  -20
    arc_0_19_20  connected_order_arc_747  -14
    arc_0_19_20  out_degree_867  1
    arc_0_19_20  in_degree_874  1
    arc_0_19_20  original_T_including_depot_unload_889  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_746  1
    load_0_19_20  free_load_conservation_872  1
    load_0_19_20  free_load_conservation_878  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_748  -20
    arc_0_19_21  connected_order_arc_749  -14
    arc_0_19_21  out_degree_867  1
    arc_0_19_21  in_degree_880  1
    arc_0_19_21  original_T_including_depot_unload_889  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_748  1
    load_0_19_21  free_load_conservation_872  1
    load_0_19_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_750  -20
    arc_0_20_0  depot_return_or_bypass_801  1
    arc_0_20_0  out_degree_873  1
    arc_0_20_0  original_T_including_depot_unload_889  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_750  1
    load_0_20_0  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_751  -20
    arc_0_20_1  connected_order_arc_752  -14
    arc_0_20_1  in_degree_803  1
    arc_0_20_1  out_degree_873  1
    arc_0_20_1  original_T_including_depot_unload_889  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_751  1
    load_0_20_1  segment_load_conservation_806  -1
    load_0_20_1  segment_prefix_lb_807  1
    load_0_20_1  segment_prefix_ub_808  1
    load_0_20_1  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_753  -20
    arc_0_20_2  connected_order_arc_754  -14
    arc_0_20_2  in_degree_810  1
    arc_0_20_2  out_degree_873  1
    arc_0_20_2  original_T_including_depot_unload_889  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_753  1
    load_0_20_2  segment_load_conservation_813  -1
    load_0_20_2  segment_prefix_lb_814  1
    load_0_20_2  segment_prefix_ub_815  1
    load_0_20_2  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_755  -20
    arc_0_20_3  connected_order_arc_756  -14
    arc_0_20_3  in_degree_817  1
    arc_0_20_3  out_degree_873  1
    arc_0_20_3  original_T_including_depot_unload_889  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_755  1
    load_0_20_3  segment_load_conservation_820  -1
    load_0_20_3  segment_prefix_lb_821  1
    load_0_20_3  segment_prefix_ub_822  1
    load_0_20_3  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_757  -20
    arc_0_20_4  connected_order_arc_758  -14
    arc_0_20_4  in_degree_824  1
    arc_0_20_4  out_degree_873  1
    arc_0_20_4  original_T_including_depot_unload_889  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_757  1
    load_0_20_4  segment_load_conservation_827  -1
    load_0_20_4  segment_prefix_lb_828  1
    load_0_20_4  segment_prefix_ub_829  1
    load_0_20_4  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_759  -20
    arc_0_20_5  connected_order_arc_760  -14
    arc_0_20_5  in_degree_831  1
    arc_0_20_5  out_degree_873  1
    arc_0_20_5  original_T_including_depot_unload_889  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_759  1
    load_0_20_5  segment_load_conservation_834  -1
    load_0_20_5  segment_prefix_lb_835  1
    load_0_20_5  segment_prefix_ub_836  1
    load_0_20_5  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_761  -20
    arc_0_20_14  connected_order_arc_762  -14
    arc_0_20_14  in_degree_838  1
    arc_0_20_14  out_degree_873  1
    arc_0_20_14  original_T_including_depot_unload_889  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_761  1
    load_0_20_14  free_load_conservation_842  -1
    load_0_20_14  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_763  -20
    arc_0_20_15  connected_order_arc_764  -14
    arc_0_20_15  in_degree_844  1
    arc_0_20_15  out_degree_873  1
    arc_0_20_15  original_T_including_depot_unload_889  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_763  1
    load_0_20_15  free_load_conservation_848  -1
    load_0_20_15  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_765  -20
    arc_0_20_16  connected_order_arc_766  -14
    arc_0_20_16  in_degree_850  1
    arc_0_20_16  out_degree_873  1
    arc_0_20_16  original_T_including_depot_unload_889  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_765  1
    load_0_20_16  free_load_conservation_854  -1
    load_0_20_16  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_767  -20
    arc_0_20_17  connected_order_arc_768  -14
    arc_0_20_17  in_degree_856  1
    arc_0_20_17  out_degree_873  1
    arc_0_20_17  original_T_including_depot_unload_889  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_767  1
    load_0_20_17  free_load_conservation_860  -1
    load_0_20_17  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_769  -20
    arc_0_20_18  connected_order_arc_770  -14
    arc_0_20_18  in_degree_862  1
    arc_0_20_18  out_degree_873  1
    arc_0_20_18  original_T_including_depot_unload_889  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_769  1
    load_0_20_18  free_load_conservation_866  -1
    load_0_20_18  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_771  -20
    arc_0_20_19  connected_order_arc_772  -14
    arc_0_20_19  in_degree_868  1
    arc_0_20_19  out_degree_873  1
    arc_0_20_19  original_T_including_depot_unload_889  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_771  1
    load_0_20_19  free_load_conservation_872  -1
    load_0_20_19  free_load_conservation_878  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_773  -20
    arc_0_20_21  connected_order_arc_774  -14
    arc_0_20_21  out_degree_873  1
    arc_0_20_21  in_degree_880  1
    arc_0_20_21  original_T_including_depot_unload_889  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_773  1
    load_0_20_21  free_load_conservation_878  1
    load_0_20_21  free_load_conservation_884  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_775  -20
    arc_0_21_0  depot_return_or_bypass_801  1
    arc_0_21_0  out_degree_879  1
    arc_0_21_0  original_T_including_depot_unload_889  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_775  1
    load_0_21_0  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_776  -20
    arc_0_21_1  connected_order_arc_777  -14
    arc_0_21_1  in_degree_803  1
    arc_0_21_1  out_degree_879  1
    arc_0_21_1  original_T_including_depot_unload_889  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_776  1
    load_0_21_1  segment_load_conservation_806  -1
    load_0_21_1  segment_prefix_lb_807  1
    load_0_21_1  segment_prefix_ub_808  1
    load_0_21_1  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_778  -20
    arc_0_21_2  connected_order_arc_779  -14
    arc_0_21_2  in_degree_810  1
    arc_0_21_2  out_degree_879  1
    arc_0_21_2  original_T_including_depot_unload_889  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_778  1
    load_0_21_2  segment_load_conservation_813  -1
    load_0_21_2  segment_prefix_lb_814  1
    load_0_21_2  segment_prefix_ub_815  1
    load_0_21_2  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_780  -20
    arc_0_21_3  connected_order_arc_781  -14
    arc_0_21_3  in_degree_817  1
    arc_0_21_3  out_degree_879  1
    arc_0_21_3  original_T_including_depot_unload_889  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_780  1
    load_0_21_3  segment_load_conservation_820  -1
    load_0_21_3  segment_prefix_lb_821  1
    load_0_21_3  segment_prefix_ub_822  1
    load_0_21_3  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_782  -20
    arc_0_21_4  connected_order_arc_783  -14
    arc_0_21_4  in_degree_824  1
    arc_0_21_4  out_degree_879  1
    arc_0_21_4  original_T_including_depot_unload_889  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_782  1
    load_0_21_4  segment_load_conservation_827  -1
    load_0_21_4  segment_prefix_lb_828  1
    load_0_21_4  segment_prefix_ub_829  1
    load_0_21_4  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_784  -20
    arc_0_21_5  connected_order_arc_785  -14
    arc_0_21_5  in_degree_831  1
    arc_0_21_5  out_degree_879  1
    arc_0_21_5  original_T_including_depot_unload_889  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_784  1
    load_0_21_5  segment_load_conservation_834  -1
    load_0_21_5  segment_prefix_lb_835  1
    load_0_21_5  segment_prefix_ub_836  1
    load_0_21_5  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_786  -20
    arc_0_21_14  connected_order_arc_787  -14
    arc_0_21_14  in_degree_838  1
    arc_0_21_14  out_degree_879  1
    arc_0_21_14  original_T_including_depot_unload_889  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_786  1
    load_0_21_14  free_load_conservation_842  -1
    load_0_21_14  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_788  -20
    arc_0_21_15  connected_order_arc_789  -14
    arc_0_21_15  in_degree_844  1
    arc_0_21_15  out_degree_879  1
    arc_0_21_15  original_T_including_depot_unload_889  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_788  1
    load_0_21_15  free_load_conservation_848  -1
    load_0_21_15  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_790  -20
    arc_0_21_16  connected_order_arc_791  -14
    arc_0_21_16  in_degree_850  1
    arc_0_21_16  out_degree_879  1
    arc_0_21_16  original_T_including_depot_unload_889  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_790  1
    load_0_21_16  free_load_conservation_854  -1
    load_0_21_16  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_792  -20
    arc_0_21_17  connected_order_arc_793  -14
    arc_0_21_17  in_degree_856  1
    arc_0_21_17  out_degree_879  1
    arc_0_21_17  original_T_including_depot_unload_889  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_792  1
    load_0_21_17  free_load_conservation_860  -1
    load_0_21_17  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_794  -20
    arc_0_21_18  connected_order_arc_795  -14
    arc_0_21_18  in_degree_862  1
    arc_0_21_18  out_degree_879  1
    arc_0_21_18  original_T_including_depot_unload_889  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_794  1
    load_0_21_18  free_load_conservation_866  -1
    load_0_21_18  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_796  -20
    arc_0_21_19  connected_order_arc_797  -14
    arc_0_21_19  in_degree_868  1
    arc_0_21_19  out_degree_879  1
    arc_0_21_19  original_T_including_depot_unload_889  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_796  1
    load_0_21_19  free_load_conservation_872  -1
    load_0_21_19  free_load_conservation_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_798  -20
    arc_0_21_20  connected_order_arc_799  -14
    arc_0_21_20  in_degree_874  1
    arc_0_21_20  out_degree_879  1
    arc_0_21_20  original_T_including_depot_unload_889  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_798  1
    load_0_21_20  free_load_conservation_878  -1
    load_0_21_20  free_load_conservation_884  1
    visit_1_6  out_degree_1181  -1
    visit_1_6  in_degree_1182  -1
    visit_1_6  order_active_lb_1183  -1
    visit_1_6  order_active_ub_1184  -12
    order_1_6  connected_order_arc_905  -1
    order_1_6  connected_order_arc_907  -1
    order_1_6  connected_order_arc_909  -1
    order_1_6  connected_order_arc_911  -1
    order_1_6  connected_order_arc_913  -1
    order_1_6  connected_order_arc_915  -1
    order_1_6  connected_order_arc_917  -1
    order_1_6  connected_order_arc_919  -1
    order_1_6  connected_order_arc_921  -1
    order_1_6  connected_order_arc_923  -1
    order_1_6  connected_order_arc_925  -1
    order_1_6  connected_order_arc_928  1
    order_1_6  connected_order_arc_951  1
    order_1_6  connected_order_arc_974  1
    order_1_6  connected_order_arc_997  1
    order_1_6  connected_order_arc_1020  1
    order_1_6  connected_order_arc_1043  1
    order_1_6  connected_order_arc_1066  1
    order_1_6  connected_order_arc_1089  1
    order_1_6  connected_order_arc_1112  1
    order_1_6  connected_order_arc_1135  1
    order_1_6  connected_order_arc_1158  1
    order_1_6  order_active_lb_1183  1
    order_1_6  order_active_ub_1184  1
    order_1_6  fixed_segment_relative_order_1257  -1
    visit_1_7  out_degree_1188  -1
    visit_1_7  in_degree_1189  -1
    visit_1_7  order_active_lb_1190  -1
    visit_1_7  order_active_ub_1191  -12
    order_1_7  connected_order_arc_905  1
    order_1_7  connected_order_arc_928  -1
    order_1_7  connected_order_arc_930  -1
    order_1_7  connected_order_arc_932  -1
    order_1_7  connected_order_arc_934  -1
    order_1_7  connected_order_arc_936  -1
    order_1_7  connected_order_arc_938  -1
    order_1_7  connected_order_arc_940  -1
    order_1_7  connected_order_arc_942  -1
    order_1_7  connected_order_arc_944  -1
    order_1_7  connected_order_arc_946  -1
    order_1_7  connected_order_arc_948  -1
    order_1_7  connected_order_arc_953  1
    order_1_7  connected_order_arc_976  1
    order_1_7  connected_order_arc_999  1
    order_1_7  connected_order_arc_1022  1
    order_1_7  connected_order_arc_1045  1
    order_1_7  connected_order_arc_1068  1
    order_1_7  connected_order_arc_1091  1
    order_1_7  connected_order_arc_1114  1
    order_1_7  connected_order_arc_1137  1
    order_1_7  connected_order_arc_1160  1
    order_1_7  order_active_lb_1190  1
    order_1_7  order_active_ub_1191  1
    order_1_7  fixed_segment_relative_order_1257  1
    order_1_7  fixed_segment_relative_order_1258  -1
    visit_1_8  out_degree_1195  -1
    visit_1_8  in_degree_1196  -1
    visit_1_8  order_active_lb_1197  -1
    visit_1_8  order_active_ub_1198  -12
    order_1_8  connected_order_arc_907  1
    order_1_8  connected_order_arc_930  1
    order_1_8  connected_order_arc_951  -1
    order_1_8  connected_order_arc_953  -1
    order_1_8  connected_order_arc_955  -1
    order_1_8  connected_order_arc_957  -1
    order_1_8  connected_order_arc_959  -1
    order_1_8  connected_order_arc_961  -1
    order_1_8  connected_order_arc_963  -1
    order_1_8  connected_order_arc_965  -1
    order_1_8  connected_order_arc_967  -1
    order_1_8  connected_order_arc_969  -1
    order_1_8  connected_order_arc_971  -1
    order_1_8  connected_order_arc_978  1
    order_1_8  connected_order_arc_1001  1
    order_1_8  connected_order_arc_1024  1
    order_1_8  connected_order_arc_1047  1
    order_1_8  connected_order_arc_1070  1
    order_1_8  connected_order_arc_1093  1
    order_1_8  connected_order_arc_1116  1
    order_1_8  connected_order_arc_1139  1
    order_1_8  connected_order_arc_1162  1
    order_1_8  order_active_lb_1197  1
    order_1_8  order_active_ub_1198  1
    order_1_8  fixed_segment_relative_order_1258  1
    order_1_8  fixed_segment_relative_order_1259  -1
    visit_1_9  out_degree_1202  -1
    visit_1_9  in_degree_1203  -1
    visit_1_9  order_active_lb_1204  -1
    visit_1_9  order_active_ub_1205  -12
    order_1_9  connected_order_arc_909  1
    order_1_9  connected_order_arc_932  1
    order_1_9  connected_order_arc_955  1
    order_1_9  connected_order_arc_974  -1
    order_1_9  connected_order_arc_976  -1
    order_1_9  connected_order_arc_978  -1
    order_1_9  connected_order_arc_980  -1
    order_1_9  connected_order_arc_982  -1
    order_1_9  connected_order_arc_984  -1
    order_1_9  connected_order_arc_986  -1
    order_1_9  connected_order_arc_988  -1
    order_1_9  connected_order_arc_990  -1
    order_1_9  connected_order_arc_992  -1
    order_1_9  connected_order_arc_994  -1
    order_1_9  connected_order_arc_1003  1
    order_1_9  connected_order_arc_1026  1
    order_1_9  connected_order_arc_1049  1
    order_1_9  connected_order_arc_1072  1
    order_1_9  connected_order_arc_1095  1
    order_1_9  connected_order_arc_1118  1
    order_1_9  connected_order_arc_1141  1
    order_1_9  connected_order_arc_1164  1
    order_1_9  order_active_lb_1204  1
    order_1_9  order_active_ub_1205  1
    order_1_9  fixed_segment_relative_order_1259  1
    visit_1_14  out_degree_1209  -1
    visit_1_14  in_degree_1210  -1
    visit_1_14  order_active_lb_1211  -1
    visit_1_14  order_active_ub_1212  -12
    visit_1_14  service_visit_def_1213  -1
    order_1_14  connected_order_arc_911  1
    order_1_14  connected_order_arc_934  1
    order_1_14  connected_order_arc_957  1
    order_1_14  connected_order_arc_980  1
    order_1_14  connected_order_arc_997  -1
    order_1_14  connected_order_arc_999  -1
    order_1_14  connected_order_arc_1001  -1
    order_1_14  connected_order_arc_1003  -1
    order_1_14  connected_order_arc_1005  -1
    order_1_14  connected_order_arc_1007  -1
    order_1_14  connected_order_arc_1009  -1
    order_1_14  connected_order_arc_1011  -1
    order_1_14  connected_order_arc_1013  -1
    order_1_14  connected_order_arc_1015  -1
    order_1_14  connected_order_arc_1017  -1
    order_1_14  connected_order_arc_1028  1
    order_1_14  connected_order_arc_1051  1
    order_1_14  connected_order_arc_1074  1
    order_1_14  connected_order_arc_1097  1
    order_1_14  connected_order_arc_1120  1
    order_1_14  connected_order_arc_1143  1
    order_1_14  connected_order_arc_1166  1
    order_1_14  order_active_lb_1211  1
    order_1_14  order_active_ub_1212  1
    visit_1_15  out_degree_1215  -1
    visit_1_15  in_degree_1216  -1
    visit_1_15  order_active_lb_1217  -1
    visit_1_15  order_active_ub_1218  -12
    visit_1_15  service_visit_def_1219  -1
    order_1_15  connected_order_arc_913  1
    order_1_15  connected_order_arc_936  1
    order_1_15  connected_order_arc_959  1
    order_1_15  connected_order_arc_982  1
    order_1_15  connected_order_arc_1005  1
    order_1_15  connected_order_arc_1020  -1
    order_1_15  connected_order_arc_1022  -1
    order_1_15  connected_order_arc_1024  -1
    order_1_15  connected_order_arc_1026  -1
    order_1_15  connected_order_arc_1028  -1
    order_1_15  connected_order_arc_1030  -1
    order_1_15  connected_order_arc_1032  -1
    order_1_15  connected_order_arc_1034  -1
    order_1_15  connected_order_arc_1036  -1
    order_1_15  connected_order_arc_1038  -1
    order_1_15  connected_order_arc_1040  -1
    order_1_15  connected_order_arc_1053  1
    order_1_15  connected_order_arc_1076  1
    order_1_15  connected_order_arc_1099  1
    order_1_15  connected_order_arc_1122  1
    order_1_15  connected_order_arc_1145  1
    order_1_15  connected_order_arc_1168  1
    order_1_15  order_active_lb_1217  1
    order_1_15  order_active_ub_1218  1
    visit_1_16  out_degree_1221  -1
    visit_1_16  in_degree_1222  -1
    visit_1_16  order_active_lb_1223  -1
    visit_1_16  order_active_ub_1224  -12
    visit_1_16  service_visit_def_1225  -1
    order_1_16  connected_order_arc_915  1
    order_1_16  connected_order_arc_938  1
    order_1_16  connected_order_arc_961  1
    order_1_16  connected_order_arc_984  1
    order_1_16  connected_order_arc_1007  1
    order_1_16  connected_order_arc_1030  1
    order_1_16  connected_order_arc_1043  -1
    order_1_16  connected_order_arc_1045  -1
    order_1_16  connected_order_arc_1047  -1
    order_1_16  connected_order_arc_1049  -1
    order_1_16  connected_order_arc_1051  -1
    order_1_16  connected_order_arc_1053  -1
    order_1_16  connected_order_arc_1055  -1
    order_1_16  connected_order_arc_1057  -1
    order_1_16  connected_order_arc_1059  -1
    order_1_16  connected_order_arc_1061  -1
    order_1_16  connected_order_arc_1063  -1
    order_1_16  connected_order_arc_1078  1
    order_1_16  connected_order_arc_1101  1
    order_1_16  connected_order_arc_1124  1
    order_1_16  connected_order_arc_1147  1
    order_1_16  connected_order_arc_1170  1
    order_1_16  order_active_lb_1223  1
    order_1_16  order_active_ub_1224  1
    visit_1_17  out_degree_1227  -1
    visit_1_17  in_degree_1228  -1
    visit_1_17  order_active_lb_1229  -1
    visit_1_17  order_active_ub_1230  -12
    visit_1_17  service_visit_def_1231  -1
    order_1_17  connected_order_arc_917  1
    order_1_17  connected_order_arc_940  1
    order_1_17  connected_order_arc_963  1
    order_1_17  connected_order_arc_986  1
    order_1_17  connected_order_arc_1009  1
    order_1_17  connected_order_arc_1032  1
    order_1_17  connected_order_arc_1055  1
    order_1_17  connected_order_arc_1066  -1
    order_1_17  connected_order_arc_1068  -1
    order_1_17  connected_order_arc_1070  -1
    order_1_17  connected_order_arc_1072  -1
    order_1_17  connected_order_arc_1074  -1
    order_1_17  connected_order_arc_1076  -1
    order_1_17  connected_order_arc_1078  -1
    order_1_17  connected_order_arc_1080  -1
    order_1_17  connected_order_arc_1082  -1
    order_1_17  connected_order_arc_1084  -1
    order_1_17  connected_order_arc_1086  -1
    order_1_17  connected_order_arc_1103  1
    order_1_17  connected_order_arc_1126  1
    order_1_17  connected_order_arc_1149  1
    order_1_17  connected_order_arc_1172  1
    order_1_17  order_active_lb_1229  1
    order_1_17  order_active_ub_1230  1
    visit_1_18  out_degree_1233  -1
    visit_1_18  in_degree_1234  -1
    visit_1_18  order_active_lb_1235  -1
    visit_1_18  order_active_ub_1236  -12
    visit_1_18  service_visit_def_1237  -1
    order_1_18  connected_order_arc_919  1
    order_1_18  connected_order_arc_942  1
    order_1_18  connected_order_arc_965  1
    order_1_18  connected_order_arc_988  1
    order_1_18  connected_order_arc_1011  1
    order_1_18  connected_order_arc_1034  1
    order_1_18  connected_order_arc_1057  1
    order_1_18  connected_order_arc_1080  1
    order_1_18  connected_order_arc_1089  -1
    order_1_18  connected_order_arc_1091  -1
    order_1_18  connected_order_arc_1093  -1
    order_1_18  connected_order_arc_1095  -1
    order_1_18  connected_order_arc_1097  -1
    order_1_18  connected_order_arc_1099  -1
    order_1_18  connected_order_arc_1101  -1
    order_1_18  connected_order_arc_1103  -1
    order_1_18  connected_order_arc_1105  -1
    order_1_18  connected_order_arc_1107  -1
    order_1_18  connected_order_arc_1109  -1
    order_1_18  connected_order_arc_1128  1
    order_1_18  connected_order_arc_1151  1
    order_1_18  connected_order_arc_1174  1
    order_1_18  order_active_lb_1235  1
    order_1_18  order_active_ub_1236  1
    visit_1_19  out_degree_1239  -1
    visit_1_19  in_degree_1240  -1
    visit_1_19  order_active_lb_1241  -1
    visit_1_19  order_active_ub_1242  -12
    visit_1_19  service_visit_def_1243  -1
    order_1_19  connected_order_arc_921  1
    order_1_19  connected_order_arc_944  1
    order_1_19  connected_order_arc_967  1
    order_1_19  connected_order_arc_990  1
    order_1_19  connected_order_arc_1013  1
    order_1_19  connected_order_arc_1036  1
    order_1_19  connected_order_arc_1059  1
    order_1_19  connected_order_arc_1082  1
    order_1_19  connected_order_arc_1105  1
    order_1_19  connected_order_arc_1112  -1
    order_1_19  connected_order_arc_1114  -1
    order_1_19  connected_order_arc_1116  -1
    order_1_19  connected_order_arc_1118  -1
    order_1_19  connected_order_arc_1120  -1
    order_1_19  connected_order_arc_1122  -1
    order_1_19  connected_order_arc_1124  -1
    order_1_19  connected_order_arc_1126  -1
    order_1_19  connected_order_arc_1128  -1
    order_1_19  connected_order_arc_1130  -1
    order_1_19  connected_order_arc_1132  -1
    order_1_19  connected_order_arc_1153  1
    order_1_19  connected_order_arc_1176  1
    order_1_19  order_active_lb_1241  1
    order_1_19  order_active_ub_1242  1
    visit_1_20  out_degree_1245  -1
    visit_1_20  in_degree_1246  -1
    visit_1_20  order_active_lb_1247  -1
    visit_1_20  order_active_ub_1248  -12
    visit_1_20  service_visit_def_1249  -1
    order_1_20  connected_order_arc_923  1
    order_1_20  connected_order_arc_946  1
    order_1_20  connected_order_arc_969  1
    order_1_20  connected_order_arc_992  1
    order_1_20  connected_order_arc_1015  1
    order_1_20  connected_order_arc_1038  1
    order_1_20  connected_order_arc_1061  1
    order_1_20  connected_order_arc_1084  1
    order_1_20  connected_order_arc_1107  1
    order_1_20  connected_order_arc_1130  1
    order_1_20  connected_order_arc_1135  -1
    order_1_20  connected_order_arc_1137  -1
    order_1_20  connected_order_arc_1139  -1
    order_1_20  connected_order_arc_1141  -1
    order_1_20  connected_order_arc_1143  -1
    order_1_20  connected_order_arc_1145  -1
    order_1_20  connected_order_arc_1147  -1
    order_1_20  connected_order_arc_1149  -1
    order_1_20  connected_order_arc_1151  -1
    order_1_20  connected_order_arc_1153  -1
    order_1_20  connected_order_arc_1155  -1
    order_1_20  connected_order_arc_1178  1
    order_1_20  order_active_lb_1247  1
    order_1_20  order_active_ub_1248  1
    visit_1_21  out_degree_1251  -1
    visit_1_21  in_degree_1252  -1
    visit_1_21  order_active_lb_1253  -1
    visit_1_21  order_active_ub_1254  -12
    visit_1_21  service_visit_def_1255  -1
    order_1_21  connected_order_arc_925  1
    order_1_21  connected_order_arc_948  1
    order_1_21  connected_order_arc_971  1
    order_1_21  connected_order_arc_994  1
    order_1_21  connected_order_arc_1017  1
    order_1_21  connected_order_arc_1040  1
    order_1_21  connected_order_arc_1063  1
    order_1_21  connected_order_arc_1086  1
    order_1_21  connected_order_arc_1109  1
    order_1_21  connected_order_arc_1132  1
    order_1_21  connected_order_arc_1155  1
    order_1_21  connected_order_arc_1158  -1
    order_1_21  connected_order_arc_1160  -1
    order_1_21  connected_order_arc_1162  -1
    order_1_21  connected_order_arc_1164  -1
    order_1_21  connected_order_arc_1166  -1
    order_1_21  connected_order_arc_1168  -1
    order_1_21  connected_order_arc_1170  -1
    order_1_21  connected_order_arc_1172  -1
    order_1_21  connected_order_arc_1174  -1
    order_1_21  connected_order_arc_1176  -1
    order_1_21  connected_order_arc_1178  -1
    order_1_21  order_active_lb_1253  1
    order_1_21  order_active_ub_1254  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_890  -25
    arc_1_0_0  depot_departure_or_bypass_1179  1
    arc_1_0_0  depot_return_or_bypass_1180  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_890  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_891  -25
    arc_1_0_6  depot_departure_or_bypass_1179  1
    arc_1_0_6  in_degree_1182  1
    arc_1_0_6  original_T_including_depot_unload_1260  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_891  1
    load_1_0_6  segment_load_conservation_1185  -1
    load_1_0_6  segment_prefix_lb_1186  1
    load_1_0_6  segment_prefix_ub_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_892  -25
    arc_1_0_7  depot_departure_or_bypass_1179  1
    arc_1_0_7  in_degree_1189  1
    arc_1_0_7  original_T_including_depot_unload_1260  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_892  1
    load_1_0_7  segment_load_conservation_1192  -1
    load_1_0_7  segment_prefix_lb_1193  1
    load_1_0_7  segment_prefix_ub_1194  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_893  -25
    arc_1_0_8  depot_departure_or_bypass_1179  1
    arc_1_0_8  in_degree_1196  1
    arc_1_0_8  original_T_including_depot_unload_1260  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_893  1
    load_1_0_8  segment_load_conservation_1199  -1
    load_1_0_8  segment_prefix_lb_1200  1
    load_1_0_8  segment_prefix_ub_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_894  -25
    arc_1_0_9  depot_departure_or_bypass_1179  1
    arc_1_0_9  in_degree_1203  1
    arc_1_0_9  original_T_including_depot_unload_1260  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_894  1
    load_1_0_9  segment_load_conservation_1206  -1
    load_1_0_9  segment_prefix_lb_1207  1
    load_1_0_9  segment_prefix_ub_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_895  -25
    arc_1_0_14  depot_departure_or_bypass_1179  1
    arc_1_0_14  in_degree_1210  1
    arc_1_0_14  original_T_including_depot_unload_1260  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_895  1
    load_1_0_14  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_896  -25
    arc_1_0_15  depot_departure_or_bypass_1179  1
    arc_1_0_15  in_degree_1216  1
    arc_1_0_15  original_T_including_depot_unload_1260  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_896  1
    load_1_0_15  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_897  -25
    arc_1_0_16  depot_departure_or_bypass_1179  1
    arc_1_0_16  in_degree_1222  1
    arc_1_0_16  original_T_including_depot_unload_1260  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_897  1
    load_1_0_16  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_898  -25
    arc_1_0_17  depot_departure_or_bypass_1179  1
    arc_1_0_17  in_degree_1228  1
    arc_1_0_17  original_T_including_depot_unload_1260  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_898  1
    load_1_0_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_899  -25
    arc_1_0_18  depot_departure_or_bypass_1179  1
    arc_1_0_18  in_degree_1234  1
    arc_1_0_18  original_T_including_depot_unload_1260  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_899  1
    load_1_0_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_900  -25
    arc_1_0_19  depot_departure_or_bypass_1179  1
    arc_1_0_19  in_degree_1240  1
    arc_1_0_19  original_T_including_depot_unload_1260  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_900  1
    load_1_0_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_901  -25
    arc_1_0_20  depot_departure_or_bypass_1179  1
    arc_1_0_20  in_degree_1246  1
    arc_1_0_20  original_T_including_depot_unload_1260  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_901  1
    load_1_0_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_902  -25
    arc_1_0_21  depot_departure_or_bypass_1179  1
    arc_1_0_21  in_degree_1252  1
    arc_1_0_21  original_T_including_depot_unload_1260  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_902  1
    load_1_0_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_903  -25
    arc_1_6_0  depot_return_or_bypass_1180  1
    arc_1_6_0  out_degree_1181  1
    arc_1_6_0  original_T_including_depot_unload_1260  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_903  1
    load_1_6_0  segment_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_904  -25
    arc_1_6_7  connected_order_arc_905  -13
    arc_1_6_7  out_degree_1181  1
    arc_1_6_7  in_degree_1189  1
    arc_1_6_7  original_T_including_depot_unload_1260  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_904  1
    load_1_6_7  segment_load_conservation_1185  1
    load_1_6_7  segment_load_conservation_1192  -1
    load_1_6_7  segment_prefix_lb_1193  1
    load_1_6_7  segment_prefix_ub_1194  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_906  -25
    arc_1_6_8  connected_order_arc_907  -13
    arc_1_6_8  out_degree_1181  1
    arc_1_6_8  in_degree_1196  1
    arc_1_6_8  original_T_including_depot_unload_1260  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_906  1
    load_1_6_8  segment_load_conservation_1185  1
    load_1_6_8  segment_load_conservation_1199  -1
    load_1_6_8  segment_prefix_lb_1200  1
    load_1_6_8  segment_prefix_ub_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_908  -25
    arc_1_6_9  connected_order_arc_909  -13
    arc_1_6_9  out_degree_1181  1
    arc_1_6_9  in_degree_1203  1
    arc_1_6_9  original_T_including_depot_unload_1260  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_908  1
    load_1_6_9  segment_load_conservation_1185  1
    load_1_6_9  segment_load_conservation_1206  -1
    load_1_6_9  segment_prefix_lb_1207  1
    load_1_6_9  segment_prefix_ub_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_910  -25
    arc_1_6_14  connected_order_arc_911  -13
    arc_1_6_14  out_degree_1181  1
    arc_1_6_14  in_degree_1210  1
    arc_1_6_14  original_T_including_depot_unload_1260  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_910  1
    load_1_6_14  segment_load_conservation_1185  1
    load_1_6_14  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_912  -25
    arc_1_6_15  connected_order_arc_913  -13
    arc_1_6_15  out_degree_1181  1
    arc_1_6_15  in_degree_1216  1
    arc_1_6_15  original_T_including_depot_unload_1260  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_912  1
    load_1_6_15  segment_load_conservation_1185  1
    load_1_6_15  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_914  -25
    arc_1_6_16  connected_order_arc_915  -13
    arc_1_6_16  out_degree_1181  1
    arc_1_6_16  in_degree_1222  1
    arc_1_6_16  original_T_including_depot_unload_1260  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_914  1
    load_1_6_16  segment_load_conservation_1185  1
    load_1_6_16  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_916  -25
    arc_1_6_17  connected_order_arc_917  -13
    arc_1_6_17  out_degree_1181  1
    arc_1_6_17  in_degree_1228  1
    arc_1_6_17  original_T_including_depot_unload_1260  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_916  1
    load_1_6_17  segment_load_conservation_1185  1
    load_1_6_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_918  -25
    arc_1_6_18  connected_order_arc_919  -13
    arc_1_6_18  out_degree_1181  1
    arc_1_6_18  in_degree_1234  1
    arc_1_6_18  original_T_including_depot_unload_1260  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_918  1
    load_1_6_18  segment_load_conservation_1185  1
    load_1_6_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_920  -25
    arc_1_6_19  connected_order_arc_921  -13
    arc_1_6_19  out_degree_1181  1
    arc_1_6_19  in_degree_1240  1
    arc_1_6_19  original_T_including_depot_unload_1260  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_920  1
    load_1_6_19  segment_load_conservation_1185  1
    load_1_6_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_922  -25
    arc_1_6_20  connected_order_arc_923  -13
    arc_1_6_20  out_degree_1181  1
    arc_1_6_20  in_degree_1246  1
    arc_1_6_20  original_T_including_depot_unload_1260  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_922  1
    load_1_6_20  segment_load_conservation_1185  1
    load_1_6_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_924  -25
    arc_1_6_21  connected_order_arc_925  -13
    arc_1_6_21  out_degree_1181  1
    arc_1_6_21  in_degree_1252  1
    arc_1_6_21  original_T_including_depot_unload_1260  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_924  1
    load_1_6_21  segment_load_conservation_1185  1
    load_1_6_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_926  -25
    arc_1_7_0  depot_return_or_bypass_1180  1
    arc_1_7_0  out_degree_1188  1
    arc_1_7_0  original_T_including_depot_unload_1260  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_926  1
    load_1_7_0  segment_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_927  -25
    arc_1_7_6  connected_order_arc_928  -13
    arc_1_7_6  in_degree_1182  1
    arc_1_7_6  out_degree_1188  1
    arc_1_7_6  original_T_including_depot_unload_1260  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_927  1
    load_1_7_6  segment_load_conservation_1185  -1
    load_1_7_6  segment_prefix_lb_1186  1
    load_1_7_6  segment_prefix_ub_1187  1
    load_1_7_6  segment_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_929  -25
    arc_1_7_8  connected_order_arc_930  -13
    arc_1_7_8  out_degree_1188  1
    arc_1_7_8  in_degree_1196  1
    arc_1_7_8  original_T_including_depot_unload_1260  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_929  1
    load_1_7_8  segment_load_conservation_1192  1
    load_1_7_8  segment_load_conservation_1199  -1
    load_1_7_8  segment_prefix_lb_1200  1
    load_1_7_8  segment_prefix_ub_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_931  -25
    arc_1_7_9  connected_order_arc_932  -13
    arc_1_7_9  out_degree_1188  1
    arc_1_7_9  in_degree_1203  1
    arc_1_7_9  original_T_including_depot_unload_1260  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_931  1
    load_1_7_9  segment_load_conservation_1192  1
    load_1_7_9  segment_load_conservation_1206  -1
    load_1_7_9  segment_prefix_lb_1207  1
    load_1_7_9  segment_prefix_ub_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_933  -25
    arc_1_7_14  connected_order_arc_934  -13
    arc_1_7_14  out_degree_1188  1
    arc_1_7_14  in_degree_1210  1
    arc_1_7_14  original_T_including_depot_unload_1260  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_933  1
    load_1_7_14  segment_load_conservation_1192  1
    load_1_7_14  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_935  -25
    arc_1_7_15  connected_order_arc_936  -13
    arc_1_7_15  out_degree_1188  1
    arc_1_7_15  in_degree_1216  1
    arc_1_7_15  original_T_including_depot_unload_1260  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_935  1
    load_1_7_15  segment_load_conservation_1192  1
    load_1_7_15  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_937  -25
    arc_1_7_16  connected_order_arc_938  -13
    arc_1_7_16  out_degree_1188  1
    arc_1_7_16  in_degree_1222  1
    arc_1_7_16  original_T_including_depot_unload_1260  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_937  1
    load_1_7_16  segment_load_conservation_1192  1
    load_1_7_16  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_939  -25
    arc_1_7_17  connected_order_arc_940  -13
    arc_1_7_17  out_degree_1188  1
    arc_1_7_17  in_degree_1228  1
    arc_1_7_17  original_T_including_depot_unload_1260  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_939  1
    load_1_7_17  segment_load_conservation_1192  1
    load_1_7_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_941  -25
    arc_1_7_18  connected_order_arc_942  -13
    arc_1_7_18  out_degree_1188  1
    arc_1_7_18  in_degree_1234  1
    arc_1_7_18  original_T_including_depot_unload_1260  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_941  1
    load_1_7_18  segment_load_conservation_1192  1
    load_1_7_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_943  -25
    arc_1_7_19  connected_order_arc_944  -13
    arc_1_7_19  out_degree_1188  1
    arc_1_7_19  in_degree_1240  1
    arc_1_7_19  original_T_including_depot_unload_1260  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_943  1
    load_1_7_19  segment_load_conservation_1192  1
    load_1_7_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_945  -25
    arc_1_7_20  connected_order_arc_946  -13
    arc_1_7_20  out_degree_1188  1
    arc_1_7_20  in_degree_1246  1
    arc_1_7_20  original_T_including_depot_unload_1260  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_945  1
    load_1_7_20  segment_load_conservation_1192  1
    load_1_7_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_947  -25
    arc_1_7_21  connected_order_arc_948  -13
    arc_1_7_21  out_degree_1188  1
    arc_1_7_21  in_degree_1252  1
    arc_1_7_21  original_T_including_depot_unload_1260  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_947  1
    load_1_7_21  segment_load_conservation_1192  1
    load_1_7_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_949  -25
    arc_1_8_0  depot_return_or_bypass_1180  1
    arc_1_8_0  out_degree_1195  1
    arc_1_8_0  original_T_including_depot_unload_1260  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_949  1
    load_1_8_0  segment_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_950  -25
    arc_1_8_6  connected_order_arc_951  -13
    arc_1_8_6  in_degree_1182  1
    arc_1_8_6  out_degree_1195  1
    arc_1_8_6  original_T_including_depot_unload_1260  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_950  1
    load_1_8_6  segment_load_conservation_1185  -1
    load_1_8_6  segment_prefix_lb_1186  1
    load_1_8_6  segment_prefix_ub_1187  1
    load_1_8_6  segment_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_952  -25
    arc_1_8_7  connected_order_arc_953  -13
    arc_1_8_7  in_degree_1189  1
    arc_1_8_7  out_degree_1195  1
    arc_1_8_7  original_T_including_depot_unload_1260  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_952  1
    load_1_8_7  segment_load_conservation_1192  -1
    load_1_8_7  segment_prefix_lb_1193  1
    load_1_8_7  segment_prefix_ub_1194  1
    load_1_8_7  segment_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_954  -25
    arc_1_8_9  connected_order_arc_955  -13
    arc_1_8_9  out_degree_1195  1
    arc_1_8_9  in_degree_1203  1
    arc_1_8_9  original_T_including_depot_unload_1260  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_954  1
    load_1_8_9  segment_load_conservation_1199  1
    load_1_8_9  segment_load_conservation_1206  -1
    load_1_8_9  segment_prefix_lb_1207  1
    load_1_8_9  segment_prefix_ub_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_956  -25
    arc_1_8_14  connected_order_arc_957  -13
    arc_1_8_14  out_degree_1195  1
    arc_1_8_14  in_degree_1210  1
    arc_1_8_14  original_T_including_depot_unload_1260  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_956  1
    load_1_8_14  segment_load_conservation_1199  1
    load_1_8_14  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_958  -25
    arc_1_8_15  connected_order_arc_959  -13
    arc_1_8_15  out_degree_1195  1
    arc_1_8_15  in_degree_1216  1
    arc_1_8_15  original_T_including_depot_unload_1260  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_958  1
    load_1_8_15  segment_load_conservation_1199  1
    load_1_8_15  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_960  -25
    arc_1_8_16  connected_order_arc_961  -13
    arc_1_8_16  out_degree_1195  1
    arc_1_8_16  in_degree_1222  1
    arc_1_8_16  original_T_including_depot_unload_1260  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_960  1
    load_1_8_16  segment_load_conservation_1199  1
    load_1_8_16  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_962  -25
    arc_1_8_17  connected_order_arc_963  -13
    arc_1_8_17  out_degree_1195  1
    arc_1_8_17  in_degree_1228  1
    arc_1_8_17  original_T_including_depot_unload_1260  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_962  1
    load_1_8_17  segment_load_conservation_1199  1
    load_1_8_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_964  -25
    arc_1_8_18  connected_order_arc_965  -13
    arc_1_8_18  out_degree_1195  1
    arc_1_8_18  in_degree_1234  1
    arc_1_8_18  original_T_including_depot_unload_1260  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_964  1
    load_1_8_18  segment_load_conservation_1199  1
    load_1_8_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_966  -25
    arc_1_8_19  connected_order_arc_967  -13
    arc_1_8_19  out_degree_1195  1
    arc_1_8_19  in_degree_1240  1
    arc_1_8_19  original_T_including_depot_unload_1260  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_966  1
    load_1_8_19  segment_load_conservation_1199  1
    load_1_8_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_968  -25
    arc_1_8_20  connected_order_arc_969  -13
    arc_1_8_20  out_degree_1195  1
    arc_1_8_20  in_degree_1246  1
    arc_1_8_20  original_T_including_depot_unload_1260  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_968  1
    load_1_8_20  segment_load_conservation_1199  1
    load_1_8_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_970  -25
    arc_1_8_21  connected_order_arc_971  -13
    arc_1_8_21  out_degree_1195  1
    arc_1_8_21  in_degree_1252  1
    arc_1_8_21  original_T_including_depot_unload_1260  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_970  1
    load_1_8_21  segment_load_conservation_1199  1
    load_1_8_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_972  -25
    arc_1_9_0  depot_return_or_bypass_1180  1
    arc_1_9_0  out_degree_1202  1
    arc_1_9_0  original_T_including_depot_unload_1260  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_972  1
    load_1_9_0  segment_load_conservation_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_973  -25
    arc_1_9_6  connected_order_arc_974  -13
    arc_1_9_6  in_degree_1182  1
    arc_1_9_6  out_degree_1202  1
    arc_1_9_6  original_T_including_depot_unload_1260  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_973  1
    load_1_9_6  segment_load_conservation_1185  -1
    load_1_9_6  segment_prefix_lb_1186  1
    load_1_9_6  segment_prefix_ub_1187  1
    load_1_9_6  segment_load_conservation_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_975  -25
    arc_1_9_7  connected_order_arc_976  -13
    arc_1_9_7  in_degree_1189  1
    arc_1_9_7  out_degree_1202  1
    arc_1_9_7  original_T_including_depot_unload_1260  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_975  1
    load_1_9_7  segment_load_conservation_1192  -1
    load_1_9_7  segment_prefix_lb_1193  1
    load_1_9_7  segment_prefix_ub_1194  1
    load_1_9_7  segment_load_conservation_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_977  -25
    arc_1_9_8  connected_order_arc_978  -13
    arc_1_9_8  in_degree_1196  1
    arc_1_9_8  out_degree_1202  1
    arc_1_9_8  original_T_including_depot_unload_1260  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_977  1
    load_1_9_8  segment_load_conservation_1199  -1
    load_1_9_8  segment_prefix_lb_1200  1
    load_1_9_8  segment_prefix_ub_1201  1
    load_1_9_8  segment_load_conservation_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_979  -25
    arc_1_9_14  connected_order_arc_980  -13
    arc_1_9_14  out_degree_1202  1
    arc_1_9_14  in_degree_1210  1
    arc_1_9_14  original_T_including_depot_unload_1260  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_979  1
    load_1_9_14  segment_load_conservation_1206  1
    load_1_9_14  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_981  -25
    arc_1_9_15  connected_order_arc_982  -13
    arc_1_9_15  out_degree_1202  1
    arc_1_9_15  in_degree_1216  1
    arc_1_9_15  original_T_including_depot_unload_1260  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_981  1
    load_1_9_15  segment_load_conservation_1206  1
    load_1_9_15  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_983  -25
    arc_1_9_16  connected_order_arc_984  -13
    arc_1_9_16  out_degree_1202  1
    arc_1_9_16  in_degree_1222  1
    arc_1_9_16  original_T_including_depot_unload_1260  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_983  1
    load_1_9_16  segment_load_conservation_1206  1
    load_1_9_16  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_985  -25
    arc_1_9_17  connected_order_arc_986  -13
    arc_1_9_17  out_degree_1202  1
    arc_1_9_17  in_degree_1228  1
    arc_1_9_17  original_T_including_depot_unload_1260  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_985  1
    load_1_9_17  segment_load_conservation_1206  1
    load_1_9_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_987  -25
    arc_1_9_18  connected_order_arc_988  -13
    arc_1_9_18  out_degree_1202  1
    arc_1_9_18  in_degree_1234  1
    arc_1_9_18  original_T_including_depot_unload_1260  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_987  1
    load_1_9_18  segment_load_conservation_1206  1
    load_1_9_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_989  -25
    arc_1_9_19  connected_order_arc_990  -13
    arc_1_9_19  out_degree_1202  1
    arc_1_9_19  in_degree_1240  1
    arc_1_9_19  original_T_including_depot_unload_1260  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_989  1
    load_1_9_19  segment_load_conservation_1206  1
    load_1_9_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_991  -25
    arc_1_9_20  connected_order_arc_992  -13
    arc_1_9_20  out_degree_1202  1
    arc_1_9_20  in_degree_1246  1
    arc_1_9_20  original_T_including_depot_unload_1260  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_991  1
    load_1_9_20  segment_load_conservation_1206  1
    load_1_9_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_993  -25
    arc_1_9_21  connected_order_arc_994  -13
    arc_1_9_21  out_degree_1202  1
    arc_1_9_21  in_degree_1252  1
    arc_1_9_21  original_T_including_depot_unload_1260  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_993  1
    load_1_9_21  segment_load_conservation_1206  1
    load_1_9_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_995  -25
    arc_1_14_0  depot_return_or_bypass_1180  1
    arc_1_14_0  out_degree_1209  1
    arc_1_14_0  original_T_including_depot_unload_1260  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_995  1
    load_1_14_0  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_996  -25
    arc_1_14_6  connected_order_arc_997  -13
    arc_1_14_6  in_degree_1182  1
    arc_1_14_6  out_degree_1209  1
    arc_1_14_6  original_T_including_depot_unload_1260  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_996  1
    load_1_14_6  segment_load_conservation_1185  -1
    load_1_14_6  segment_prefix_lb_1186  1
    load_1_14_6  segment_prefix_ub_1187  1
    load_1_14_6  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_998  -25
    arc_1_14_7  connected_order_arc_999  -13
    arc_1_14_7  in_degree_1189  1
    arc_1_14_7  out_degree_1209  1
    arc_1_14_7  original_T_including_depot_unload_1260  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_998  1
    load_1_14_7  segment_load_conservation_1192  -1
    load_1_14_7  segment_prefix_lb_1193  1
    load_1_14_7  segment_prefix_ub_1194  1
    load_1_14_7  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1000  -25
    arc_1_14_8  connected_order_arc_1001  -13
    arc_1_14_8  in_degree_1196  1
    arc_1_14_8  out_degree_1209  1
    arc_1_14_8  original_T_including_depot_unload_1260  1.6631507094436240e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1000  1
    load_1_14_8  segment_load_conservation_1199  -1
    load_1_14_8  segment_prefix_lb_1200  1
    load_1_14_8  segment_prefix_ub_1201  1
    load_1_14_8  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1002  -25
    arc_1_14_9  connected_order_arc_1003  -13
    arc_1_14_9  in_degree_1203  1
    arc_1_14_9  out_degree_1209  1
    arc_1_14_9  original_T_including_depot_unload_1260  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1002  1
    load_1_14_9  segment_load_conservation_1206  -1
    load_1_14_9  segment_prefix_lb_1207  1
    load_1_14_9  segment_prefix_ub_1208  1
    load_1_14_9  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1004  -25
    arc_1_14_15  connected_order_arc_1005  -13
    arc_1_14_15  out_degree_1209  1
    arc_1_14_15  in_degree_1216  1
    arc_1_14_15  original_T_including_depot_unload_1260  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1004  1
    load_1_14_15  free_load_conservation_1214  1
    load_1_14_15  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1006  -25
    arc_1_14_16  connected_order_arc_1007  -13
    arc_1_14_16  out_degree_1209  1
    arc_1_14_16  in_degree_1222  1
    arc_1_14_16  original_T_including_depot_unload_1260  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1006  1
    load_1_14_16  free_load_conservation_1214  1
    load_1_14_16  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1008  -25
    arc_1_14_17  connected_order_arc_1009  -13
    arc_1_14_17  out_degree_1209  1
    arc_1_14_17  in_degree_1228  1
    arc_1_14_17  original_T_including_depot_unload_1260  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1008  1
    load_1_14_17  free_load_conservation_1214  1
    load_1_14_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1010  -25
    arc_1_14_18  connected_order_arc_1011  -13
    arc_1_14_18  out_degree_1209  1
    arc_1_14_18  in_degree_1234  1
    arc_1_14_18  original_T_including_depot_unload_1260  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1010  1
    load_1_14_18  free_load_conservation_1214  1
    load_1_14_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1012  -25
    arc_1_14_19  connected_order_arc_1013  -13
    arc_1_14_19  out_degree_1209  1
    arc_1_14_19  in_degree_1240  1
    arc_1_14_19  original_T_including_depot_unload_1260  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1012  1
    load_1_14_19  free_load_conservation_1214  1
    load_1_14_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1014  -25
    arc_1_14_20  connected_order_arc_1015  -13
    arc_1_14_20  out_degree_1209  1
    arc_1_14_20  in_degree_1246  1
    arc_1_14_20  original_T_including_depot_unload_1260  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1014  1
    load_1_14_20  free_load_conservation_1214  1
    load_1_14_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_1016  -25
    arc_1_14_21  connected_order_arc_1017  -13
    arc_1_14_21  out_degree_1209  1
    arc_1_14_21  in_degree_1252  1
    arc_1_14_21  original_T_including_depot_unload_1260  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_1016  1
    load_1_14_21  free_load_conservation_1214  1
    load_1_14_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1018  -25
    arc_1_15_0  depot_return_or_bypass_1180  1
    arc_1_15_0  out_degree_1215  1
    arc_1_15_0  original_T_including_depot_unload_1260  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1018  1
    load_1_15_0  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1019  -25
    arc_1_15_6  connected_order_arc_1020  -13
    arc_1_15_6  in_degree_1182  1
    arc_1_15_6  out_degree_1215  1
    arc_1_15_6  original_T_including_depot_unload_1260  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1019  1
    load_1_15_6  segment_load_conservation_1185  -1
    load_1_15_6  segment_prefix_lb_1186  1
    load_1_15_6  segment_prefix_ub_1187  1
    load_1_15_6  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1021  -25
    arc_1_15_7  connected_order_arc_1022  -13
    arc_1_15_7  in_degree_1189  1
    arc_1_15_7  out_degree_1215  1
    arc_1_15_7  original_T_including_depot_unload_1260  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1021  1
    load_1_15_7  segment_load_conservation_1192  -1
    load_1_15_7  segment_prefix_lb_1193  1
    load_1_15_7  segment_prefix_ub_1194  1
    load_1_15_7  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1023  -25
    arc_1_15_8  connected_order_arc_1024  -13
    arc_1_15_8  in_degree_1196  1
    arc_1_15_8  out_degree_1215  1
    arc_1_15_8  original_T_including_depot_unload_1260  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1023  1
    load_1_15_8  segment_load_conservation_1199  -1
    load_1_15_8  segment_prefix_lb_1200  1
    load_1_15_8  segment_prefix_ub_1201  1
    load_1_15_8  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1025  -25
    arc_1_15_9  connected_order_arc_1026  -13
    arc_1_15_9  in_degree_1203  1
    arc_1_15_9  out_degree_1215  1
    arc_1_15_9  original_T_including_depot_unload_1260  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1025  1
    load_1_15_9  segment_load_conservation_1206  -1
    load_1_15_9  segment_prefix_lb_1207  1
    load_1_15_9  segment_prefix_ub_1208  1
    load_1_15_9  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1027  -25
    arc_1_15_14  connected_order_arc_1028  -13
    arc_1_15_14  in_degree_1210  1
    arc_1_15_14  out_degree_1215  1
    arc_1_15_14  original_T_including_depot_unload_1260  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1027  1
    load_1_15_14  free_load_conservation_1214  -1
    load_1_15_14  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1029  -25
    arc_1_15_16  connected_order_arc_1030  -13
    arc_1_15_16  out_degree_1215  1
    arc_1_15_16  in_degree_1222  1
    arc_1_15_16  original_T_including_depot_unload_1260  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1029  1
    load_1_15_16  free_load_conservation_1220  1
    load_1_15_16  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1031  -25
    arc_1_15_17  connected_order_arc_1032  -13
    arc_1_15_17  out_degree_1215  1
    arc_1_15_17  in_degree_1228  1
    arc_1_15_17  original_T_including_depot_unload_1260  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1031  1
    load_1_15_17  free_load_conservation_1220  1
    load_1_15_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1033  -25
    arc_1_15_18  connected_order_arc_1034  -13
    arc_1_15_18  out_degree_1215  1
    arc_1_15_18  in_degree_1234  1
    arc_1_15_18  original_T_including_depot_unload_1260  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1033  1
    load_1_15_18  free_load_conservation_1220  1
    load_1_15_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1035  -25
    arc_1_15_19  connected_order_arc_1036  -13
    arc_1_15_19  out_degree_1215  1
    arc_1_15_19  in_degree_1240  1
    arc_1_15_19  original_T_including_depot_unload_1260  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1035  1
    load_1_15_19  free_load_conservation_1220  1
    load_1_15_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1037  -25
    arc_1_15_20  connected_order_arc_1038  -13
    arc_1_15_20  out_degree_1215  1
    arc_1_15_20  in_degree_1246  1
    arc_1_15_20  original_T_including_depot_unload_1260  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1037  1
    load_1_15_20  free_load_conservation_1220  1
    load_1_15_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1039  -25
    arc_1_15_21  connected_order_arc_1040  -13
    arc_1_15_21  out_degree_1215  1
    arc_1_15_21  in_degree_1252  1
    arc_1_15_21  original_T_including_depot_unload_1260  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1039  1
    load_1_15_21  free_load_conservation_1220  1
    load_1_15_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1041  -25
    arc_1_16_0  depot_return_or_bypass_1180  1
    arc_1_16_0  out_degree_1221  1
    arc_1_16_0  original_T_including_depot_unload_1260  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1041  1
    load_1_16_0  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1042  -25
    arc_1_16_6  connected_order_arc_1043  -13
    arc_1_16_6  in_degree_1182  1
    arc_1_16_6  out_degree_1221  1
    arc_1_16_6  original_T_including_depot_unload_1260  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1042  1
    load_1_16_6  segment_load_conservation_1185  -1
    load_1_16_6  segment_prefix_lb_1186  1
    load_1_16_6  segment_prefix_ub_1187  1
    load_1_16_6  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1044  -25
    arc_1_16_7  connected_order_arc_1045  -13
    arc_1_16_7  in_degree_1189  1
    arc_1_16_7  out_degree_1221  1
    arc_1_16_7  original_T_including_depot_unload_1260  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1044  1
    load_1_16_7  segment_load_conservation_1192  -1
    load_1_16_7  segment_prefix_lb_1193  1
    load_1_16_7  segment_prefix_ub_1194  1
    load_1_16_7  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1046  -25
    arc_1_16_8  connected_order_arc_1047  -13
    arc_1_16_8  in_degree_1196  1
    arc_1_16_8  out_degree_1221  1
    arc_1_16_8  original_T_including_depot_unload_1260  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1046  1
    load_1_16_8  segment_load_conservation_1199  -1
    load_1_16_8  segment_prefix_lb_1200  1
    load_1_16_8  segment_prefix_ub_1201  1
    load_1_16_8  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1048  -25
    arc_1_16_9  connected_order_arc_1049  -13
    arc_1_16_9  in_degree_1203  1
    arc_1_16_9  out_degree_1221  1
    arc_1_16_9  original_T_including_depot_unload_1260  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1048  1
    load_1_16_9  segment_load_conservation_1206  -1
    load_1_16_9  segment_prefix_lb_1207  1
    load_1_16_9  segment_prefix_ub_1208  1
    load_1_16_9  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1050  -25
    arc_1_16_14  connected_order_arc_1051  -13
    arc_1_16_14  in_degree_1210  1
    arc_1_16_14  out_degree_1221  1
    arc_1_16_14  original_T_including_depot_unload_1260  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1050  1
    load_1_16_14  free_load_conservation_1214  -1
    load_1_16_14  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1052  -25
    arc_1_16_15  connected_order_arc_1053  -13
    arc_1_16_15  in_degree_1216  1
    arc_1_16_15  out_degree_1221  1
    arc_1_16_15  original_T_including_depot_unload_1260  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1052  1
    load_1_16_15  free_load_conservation_1220  -1
    load_1_16_15  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1054  -25
    arc_1_16_17  connected_order_arc_1055  -13
    arc_1_16_17  out_degree_1221  1
    arc_1_16_17  in_degree_1228  1
    arc_1_16_17  original_T_including_depot_unload_1260  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1054  1
    load_1_16_17  free_load_conservation_1226  1
    load_1_16_17  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1056  -25
    arc_1_16_18  connected_order_arc_1057  -13
    arc_1_16_18  out_degree_1221  1
    arc_1_16_18  in_degree_1234  1
    arc_1_16_18  original_T_including_depot_unload_1260  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1056  1
    load_1_16_18  free_load_conservation_1226  1
    load_1_16_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1058  -25
    arc_1_16_19  connected_order_arc_1059  -13
    arc_1_16_19  out_degree_1221  1
    arc_1_16_19  in_degree_1240  1
    arc_1_16_19  original_T_including_depot_unload_1260  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1058  1
    load_1_16_19  free_load_conservation_1226  1
    load_1_16_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1060  -25
    arc_1_16_20  connected_order_arc_1061  -13
    arc_1_16_20  out_degree_1221  1
    arc_1_16_20  in_degree_1246  1
    arc_1_16_20  original_T_including_depot_unload_1260  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1060  1
    load_1_16_20  free_load_conservation_1226  1
    load_1_16_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1062  -25
    arc_1_16_21  connected_order_arc_1063  -13
    arc_1_16_21  out_degree_1221  1
    arc_1_16_21  in_degree_1252  1
    arc_1_16_21  original_T_including_depot_unload_1260  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1062  1
    load_1_16_21  free_load_conservation_1226  1
    load_1_16_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1064  -25
    arc_1_17_0  depot_return_or_bypass_1180  1
    arc_1_17_0  out_degree_1227  1
    arc_1_17_0  original_T_including_depot_unload_1260  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1064  1
    load_1_17_0  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1065  -25
    arc_1_17_6  connected_order_arc_1066  -13
    arc_1_17_6  in_degree_1182  1
    arc_1_17_6  out_degree_1227  1
    arc_1_17_6  original_T_including_depot_unload_1260  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1065  1
    load_1_17_6  segment_load_conservation_1185  -1
    load_1_17_6  segment_prefix_lb_1186  1
    load_1_17_6  segment_prefix_ub_1187  1
    load_1_17_6  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1067  -25
    arc_1_17_7  connected_order_arc_1068  -13
    arc_1_17_7  in_degree_1189  1
    arc_1_17_7  out_degree_1227  1
    arc_1_17_7  original_T_including_depot_unload_1260  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1067  1
    load_1_17_7  segment_load_conservation_1192  -1
    load_1_17_7  segment_prefix_lb_1193  1
    load_1_17_7  segment_prefix_ub_1194  1
    load_1_17_7  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1069  -25
    arc_1_17_8  connected_order_arc_1070  -13
    arc_1_17_8  in_degree_1196  1
    arc_1_17_8  out_degree_1227  1
    arc_1_17_8  original_T_including_depot_unload_1260  1.3874440214926751e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1069  1
    load_1_17_8  segment_load_conservation_1199  -1
    load_1_17_8  segment_prefix_lb_1200  1
    load_1_17_8  segment_prefix_ub_1201  1
    load_1_17_8  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1071  -25
    arc_1_17_9  connected_order_arc_1072  -13
    arc_1_17_9  in_degree_1203  1
    arc_1_17_9  out_degree_1227  1
    arc_1_17_9  original_T_including_depot_unload_1260  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1071  1
    load_1_17_9  segment_load_conservation_1206  -1
    load_1_17_9  segment_prefix_lb_1207  1
    load_1_17_9  segment_prefix_ub_1208  1
    load_1_17_9  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1073  -25
    arc_1_17_14  connected_order_arc_1074  -13
    arc_1_17_14  in_degree_1210  1
    arc_1_17_14  out_degree_1227  1
    arc_1_17_14  original_T_including_depot_unload_1260  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1073  1
    load_1_17_14  free_load_conservation_1214  -1
    load_1_17_14  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1075  -25
    arc_1_17_15  connected_order_arc_1076  -13
    arc_1_17_15  in_degree_1216  1
    arc_1_17_15  out_degree_1227  1
    arc_1_17_15  original_T_including_depot_unload_1260  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1075  1
    load_1_17_15  free_load_conservation_1220  -1
    load_1_17_15  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1077  -25
    arc_1_17_16  connected_order_arc_1078  -13
    arc_1_17_16  in_degree_1222  1
    arc_1_17_16  out_degree_1227  1
    arc_1_17_16  original_T_including_depot_unload_1260  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1077  1
    load_1_17_16  free_load_conservation_1226  -1
    load_1_17_16  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1079  -25
    arc_1_17_18  connected_order_arc_1080  -13
    arc_1_17_18  out_degree_1227  1
    arc_1_17_18  in_degree_1234  1
    arc_1_17_18  original_T_including_depot_unload_1260  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1079  1
    load_1_17_18  free_load_conservation_1232  1
    load_1_17_18  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1081  -25
    arc_1_17_19  connected_order_arc_1082  -13
    arc_1_17_19  out_degree_1227  1
    arc_1_17_19  in_degree_1240  1
    arc_1_17_19  original_T_including_depot_unload_1260  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1081  1
    load_1_17_19  free_load_conservation_1232  1
    load_1_17_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1083  -25
    arc_1_17_20  connected_order_arc_1084  -13
    arc_1_17_20  out_degree_1227  1
    arc_1_17_20  in_degree_1246  1
    arc_1_17_20  original_T_including_depot_unload_1260  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1083  1
    load_1_17_20  free_load_conservation_1232  1
    load_1_17_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1085  -25
    arc_1_17_21  connected_order_arc_1086  -13
    arc_1_17_21  out_degree_1227  1
    arc_1_17_21  in_degree_1252  1
    arc_1_17_21  original_T_including_depot_unload_1260  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1085  1
    load_1_17_21  free_load_conservation_1232  1
    load_1_17_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1087  -25
    arc_1_18_0  depot_return_or_bypass_1180  1
    arc_1_18_0  out_degree_1233  1
    arc_1_18_0  original_T_including_depot_unload_1260  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1087  1
    load_1_18_0  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1088  -25
    arc_1_18_6  connected_order_arc_1089  -13
    arc_1_18_6  in_degree_1182  1
    arc_1_18_6  out_degree_1233  1
    arc_1_18_6  original_T_including_depot_unload_1260  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1088  1
    load_1_18_6  segment_load_conservation_1185  -1
    load_1_18_6  segment_prefix_lb_1186  1
    load_1_18_6  segment_prefix_ub_1187  1
    load_1_18_6  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1090  -25
    arc_1_18_7  connected_order_arc_1091  -13
    arc_1_18_7  in_degree_1189  1
    arc_1_18_7  out_degree_1233  1
    arc_1_18_7  original_T_including_depot_unload_1260  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1090  1
    load_1_18_7  segment_load_conservation_1192  -1
    load_1_18_7  segment_prefix_lb_1193  1
    load_1_18_7  segment_prefix_ub_1194  1
    load_1_18_7  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1092  -25
    arc_1_18_8  connected_order_arc_1093  -13
    arc_1_18_8  in_degree_1196  1
    arc_1_18_8  out_degree_1233  1
    arc_1_18_8  original_T_including_depot_unload_1260  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1092  1
    load_1_18_8  segment_load_conservation_1199  -1
    load_1_18_8  segment_prefix_lb_1200  1
    load_1_18_8  segment_prefix_ub_1201  1
    load_1_18_8  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1094  -25
    arc_1_18_9  connected_order_arc_1095  -13
    arc_1_18_9  in_degree_1203  1
    arc_1_18_9  out_degree_1233  1
    arc_1_18_9  original_T_including_depot_unload_1260  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1094  1
    load_1_18_9  segment_load_conservation_1206  -1
    load_1_18_9  segment_prefix_lb_1207  1
    load_1_18_9  segment_prefix_ub_1208  1
    load_1_18_9  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1096  -25
    arc_1_18_14  connected_order_arc_1097  -13
    arc_1_18_14  in_degree_1210  1
    arc_1_18_14  out_degree_1233  1
    arc_1_18_14  original_T_including_depot_unload_1260  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1096  1
    load_1_18_14  free_load_conservation_1214  -1
    load_1_18_14  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1098  -25
    arc_1_18_15  connected_order_arc_1099  -13
    arc_1_18_15  in_degree_1216  1
    arc_1_18_15  out_degree_1233  1
    arc_1_18_15  original_T_including_depot_unload_1260  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1098  1
    load_1_18_15  free_load_conservation_1220  -1
    load_1_18_15  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1100  -25
    arc_1_18_16  connected_order_arc_1101  -13
    arc_1_18_16  in_degree_1222  1
    arc_1_18_16  out_degree_1233  1
    arc_1_18_16  original_T_including_depot_unload_1260  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1100  1
    load_1_18_16  free_load_conservation_1226  -1
    load_1_18_16  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1102  -25
    arc_1_18_17  connected_order_arc_1103  -13
    arc_1_18_17  in_degree_1228  1
    arc_1_18_17  out_degree_1233  1
    arc_1_18_17  original_T_including_depot_unload_1260  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1102  1
    load_1_18_17  free_load_conservation_1232  -1
    load_1_18_17  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1104  -25
    arc_1_18_19  connected_order_arc_1105  -13
    arc_1_18_19  out_degree_1233  1
    arc_1_18_19  in_degree_1240  1
    arc_1_18_19  original_T_including_depot_unload_1260  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1104  1
    load_1_18_19  free_load_conservation_1238  1
    load_1_18_19  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1106  -25
    arc_1_18_20  connected_order_arc_1107  -13
    arc_1_18_20  out_degree_1233  1
    arc_1_18_20  in_degree_1246  1
    arc_1_18_20  original_T_including_depot_unload_1260  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1106  1
    load_1_18_20  free_load_conservation_1238  1
    load_1_18_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1108  -25
    arc_1_18_21  connected_order_arc_1109  -13
    arc_1_18_21  out_degree_1233  1
    arc_1_18_21  in_degree_1252  1
    arc_1_18_21  original_T_including_depot_unload_1260  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1108  1
    load_1_18_21  free_load_conservation_1238  1
    load_1_18_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1110  -25
    arc_1_19_0  depot_return_or_bypass_1180  1
    arc_1_19_0  out_degree_1239  1
    arc_1_19_0  original_T_including_depot_unload_1260  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1110  1
    load_1_19_0  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1111  -25
    arc_1_19_6  connected_order_arc_1112  -13
    arc_1_19_6  in_degree_1182  1
    arc_1_19_6  out_degree_1239  1
    arc_1_19_6  original_T_including_depot_unload_1260  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1111  1
    load_1_19_6  segment_load_conservation_1185  -1
    load_1_19_6  segment_prefix_lb_1186  1
    load_1_19_6  segment_prefix_ub_1187  1
    load_1_19_6  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1113  -25
    arc_1_19_7  connected_order_arc_1114  -13
    arc_1_19_7  in_degree_1189  1
    arc_1_19_7  out_degree_1239  1
    arc_1_19_7  original_T_including_depot_unload_1260  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1113  1
    load_1_19_7  segment_load_conservation_1192  -1
    load_1_19_7  segment_prefix_lb_1193  1
    load_1_19_7  segment_prefix_ub_1194  1
    load_1_19_7  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1115  -25
    arc_1_19_8  connected_order_arc_1116  -13
    arc_1_19_8  in_degree_1196  1
    arc_1_19_8  out_degree_1239  1
    arc_1_19_8  original_T_including_depot_unload_1260  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1115  1
    load_1_19_8  segment_load_conservation_1199  -1
    load_1_19_8  segment_prefix_lb_1200  1
    load_1_19_8  segment_prefix_ub_1201  1
    load_1_19_8  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1117  -25
    arc_1_19_9  connected_order_arc_1118  -13
    arc_1_19_9  in_degree_1203  1
    arc_1_19_9  out_degree_1239  1
    arc_1_19_9  original_T_including_depot_unload_1260  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1117  1
    load_1_19_9  segment_load_conservation_1206  -1
    load_1_19_9  segment_prefix_lb_1207  1
    load_1_19_9  segment_prefix_ub_1208  1
    load_1_19_9  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1119  -25
    arc_1_19_14  connected_order_arc_1120  -13
    arc_1_19_14  in_degree_1210  1
    arc_1_19_14  out_degree_1239  1
    arc_1_19_14  original_T_including_depot_unload_1260  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1119  1
    load_1_19_14  free_load_conservation_1214  -1
    load_1_19_14  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1121  -25
    arc_1_19_15  connected_order_arc_1122  -13
    arc_1_19_15  in_degree_1216  1
    arc_1_19_15  out_degree_1239  1
    arc_1_19_15  original_T_including_depot_unload_1260  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1121  1
    load_1_19_15  free_load_conservation_1220  -1
    load_1_19_15  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1123  -25
    arc_1_19_16  connected_order_arc_1124  -13
    arc_1_19_16  in_degree_1222  1
    arc_1_19_16  out_degree_1239  1
    arc_1_19_16  original_T_including_depot_unload_1260  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1123  1
    load_1_19_16  free_load_conservation_1226  -1
    load_1_19_16  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1125  -25
    arc_1_19_17  connected_order_arc_1126  -13
    arc_1_19_17  in_degree_1228  1
    arc_1_19_17  out_degree_1239  1
    arc_1_19_17  original_T_including_depot_unload_1260  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1125  1
    load_1_19_17  free_load_conservation_1232  -1
    load_1_19_17  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1127  -25
    arc_1_19_18  connected_order_arc_1128  -13
    arc_1_19_18  in_degree_1234  1
    arc_1_19_18  out_degree_1239  1
    arc_1_19_18  original_T_including_depot_unload_1260  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1127  1
    load_1_19_18  free_load_conservation_1238  -1
    load_1_19_18  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1129  -25
    arc_1_19_20  connected_order_arc_1130  -13
    arc_1_19_20  out_degree_1239  1
    arc_1_19_20  in_degree_1246  1
    arc_1_19_20  original_T_including_depot_unload_1260  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1129  1
    load_1_19_20  free_load_conservation_1244  1
    load_1_19_20  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1131  -25
    arc_1_19_21  connected_order_arc_1132  -13
    arc_1_19_21  out_degree_1239  1
    arc_1_19_21  in_degree_1252  1
    arc_1_19_21  original_T_including_depot_unload_1260  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1131  1
    load_1_19_21  free_load_conservation_1244  1
    load_1_19_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1133  -25
    arc_1_20_0  depot_return_or_bypass_1180  1
    arc_1_20_0  out_degree_1245  1
    arc_1_20_0  original_T_including_depot_unload_1260  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1133  1
    load_1_20_0  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1134  -25
    arc_1_20_6  connected_order_arc_1135  -13
    arc_1_20_6  in_degree_1182  1
    arc_1_20_6  out_degree_1245  1
    arc_1_20_6  original_T_including_depot_unload_1260  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1134  1
    load_1_20_6  segment_load_conservation_1185  -1
    load_1_20_6  segment_prefix_lb_1186  1
    load_1_20_6  segment_prefix_ub_1187  1
    load_1_20_6  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1136  -25
    arc_1_20_7  connected_order_arc_1137  -13
    arc_1_20_7  in_degree_1189  1
    arc_1_20_7  out_degree_1245  1
    arc_1_20_7  original_T_including_depot_unload_1260  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1136  1
    load_1_20_7  segment_load_conservation_1192  -1
    load_1_20_7  segment_prefix_lb_1193  1
    load_1_20_7  segment_prefix_ub_1194  1
    load_1_20_7  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1138  -25
    arc_1_20_8  connected_order_arc_1139  -13
    arc_1_20_8  in_degree_1196  1
    arc_1_20_8  out_degree_1245  1
    arc_1_20_8  original_T_including_depot_unload_1260  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1138  1
    load_1_20_8  segment_load_conservation_1199  -1
    load_1_20_8  segment_prefix_lb_1200  1
    load_1_20_8  segment_prefix_ub_1201  1
    load_1_20_8  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1140  -25
    arc_1_20_9  connected_order_arc_1141  -13
    arc_1_20_9  in_degree_1203  1
    arc_1_20_9  out_degree_1245  1
    arc_1_20_9  original_T_including_depot_unload_1260  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1140  1
    load_1_20_9  segment_load_conservation_1206  -1
    load_1_20_9  segment_prefix_lb_1207  1
    load_1_20_9  segment_prefix_ub_1208  1
    load_1_20_9  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1142  -25
    arc_1_20_14  connected_order_arc_1143  -13
    arc_1_20_14  in_degree_1210  1
    arc_1_20_14  out_degree_1245  1
    arc_1_20_14  original_T_including_depot_unload_1260  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1142  1
    load_1_20_14  free_load_conservation_1214  -1
    load_1_20_14  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1144  -25
    arc_1_20_15  connected_order_arc_1145  -13
    arc_1_20_15  in_degree_1216  1
    arc_1_20_15  out_degree_1245  1
    arc_1_20_15  original_T_including_depot_unload_1260  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1144  1
    load_1_20_15  free_load_conservation_1220  -1
    load_1_20_15  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1146  -25
    arc_1_20_16  connected_order_arc_1147  -13
    arc_1_20_16  in_degree_1222  1
    arc_1_20_16  out_degree_1245  1
    arc_1_20_16  original_T_including_depot_unload_1260  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1146  1
    load_1_20_16  free_load_conservation_1226  -1
    load_1_20_16  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1148  -25
    arc_1_20_17  connected_order_arc_1149  -13
    arc_1_20_17  in_degree_1228  1
    arc_1_20_17  out_degree_1245  1
    arc_1_20_17  original_T_including_depot_unload_1260  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1148  1
    load_1_20_17  free_load_conservation_1232  -1
    load_1_20_17  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1150  -25
    arc_1_20_18  connected_order_arc_1151  -13
    arc_1_20_18  in_degree_1234  1
    arc_1_20_18  out_degree_1245  1
    arc_1_20_18  original_T_including_depot_unload_1260  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1150  1
    load_1_20_18  free_load_conservation_1238  -1
    load_1_20_18  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1152  -25
    arc_1_20_19  connected_order_arc_1153  -13
    arc_1_20_19  in_degree_1240  1
    arc_1_20_19  out_degree_1245  1
    arc_1_20_19  original_T_including_depot_unload_1260  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1152  1
    load_1_20_19  free_load_conservation_1244  -1
    load_1_20_19  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1154  -25
    arc_1_20_21  connected_order_arc_1155  -13
    arc_1_20_21  out_degree_1245  1
    arc_1_20_21  in_degree_1252  1
    arc_1_20_21  original_T_including_depot_unload_1260  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1154  1
    load_1_20_21  free_load_conservation_1250  1
    load_1_20_21  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1156  -25
    arc_1_21_0  depot_return_or_bypass_1180  1
    arc_1_21_0  out_degree_1251  1
    arc_1_21_0  original_T_including_depot_unload_1260  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1156  1
    load_1_21_0  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1157  -25
    arc_1_21_6  connected_order_arc_1158  -13
    arc_1_21_6  in_degree_1182  1
    arc_1_21_6  out_degree_1251  1
    arc_1_21_6  original_T_including_depot_unload_1260  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1157  1
    load_1_21_6  segment_load_conservation_1185  -1
    load_1_21_6  segment_prefix_lb_1186  1
    load_1_21_6  segment_prefix_ub_1187  1
    load_1_21_6  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1159  -25
    arc_1_21_7  connected_order_arc_1160  -13
    arc_1_21_7  in_degree_1189  1
    arc_1_21_7  out_degree_1251  1
    arc_1_21_7  original_T_including_depot_unload_1260  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1159  1
    load_1_21_7  segment_load_conservation_1192  -1
    load_1_21_7  segment_prefix_lb_1193  1
    load_1_21_7  segment_prefix_ub_1194  1
    load_1_21_7  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1161  -25
    arc_1_21_8  connected_order_arc_1162  -13
    arc_1_21_8  in_degree_1196  1
    arc_1_21_8  out_degree_1251  1
    arc_1_21_8  original_T_including_depot_unload_1260  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1161  1
    load_1_21_8  segment_load_conservation_1199  -1
    load_1_21_8  segment_prefix_lb_1200  1
    load_1_21_8  segment_prefix_ub_1201  1
    load_1_21_8  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1163  -25
    arc_1_21_9  connected_order_arc_1164  -13
    arc_1_21_9  in_degree_1203  1
    arc_1_21_9  out_degree_1251  1
    arc_1_21_9  original_T_including_depot_unload_1260  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1163  1
    load_1_21_9  segment_load_conservation_1206  -1
    load_1_21_9  segment_prefix_lb_1207  1
    load_1_21_9  segment_prefix_ub_1208  1
    load_1_21_9  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1165  -25
    arc_1_21_14  connected_order_arc_1166  -13
    arc_1_21_14  in_degree_1210  1
    arc_1_21_14  out_degree_1251  1
    arc_1_21_14  original_T_including_depot_unload_1260  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1165  1
    load_1_21_14  free_load_conservation_1214  -1
    load_1_21_14  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1167  -25
    arc_1_21_15  connected_order_arc_1168  -13
    arc_1_21_15  in_degree_1216  1
    arc_1_21_15  out_degree_1251  1
    arc_1_21_15  original_T_including_depot_unload_1260  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1167  1
    load_1_21_15  free_load_conservation_1220  -1
    load_1_21_15  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1169  -25
    arc_1_21_16  connected_order_arc_1170  -13
    arc_1_21_16  in_degree_1222  1
    arc_1_21_16  out_degree_1251  1
    arc_1_21_16  original_T_including_depot_unload_1260  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1169  1
    load_1_21_16  free_load_conservation_1226  -1
    load_1_21_16  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1171  -25
    arc_1_21_17  connected_order_arc_1172  -13
    arc_1_21_17  in_degree_1228  1
    arc_1_21_17  out_degree_1251  1
    arc_1_21_17  original_T_including_depot_unload_1260  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1171  1
    load_1_21_17  free_load_conservation_1232  -1
    load_1_21_17  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1173  -25
    arc_1_21_18  connected_order_arc_1174  -13
    arc_1_21_18  in_degree_1234  1
    arc_1_21_18  out_degree_1251  1
    arc_1_21_18  original_T_including_depot_unload_1260  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1173  1
    load_1_21_18  free_load_conservation_1238  -1
    load_1_21_18  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1175  -25
    arc_1_21_19  connected_order_arc_1176  -13
    arc_1_21_19  in_degree_1240  1
    arc_1_21_19  out_degree_1251  1
    arc_1_21_19  original_T_including_depot_unload_1260  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1175  1
    load_1_21_19  free_load_conservation_1244  -1
    load_1_21_19  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1177  -25
    arc_1_21_20  connected_order_arc_1178  -13
    arc_1_21_20  in_degree_1246  1
    arc_1_21_20  out_degree_1251  1
    arc_1_21_20  original_T_including_depot_unload_1260  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1177  1
    load_1_21_20  free_load_conservation_1250  -1
    load_1_21_20  free_load_conservation_1256  1
    visit_2_10  out_degree_1552  -1
    visit_2_10  in_degree_1553  -1
    visit_2_10  order_active_lb_1554  -1
    visit_2_10  order_active_ub_1555  -12
    order_2_10  connected_order_arc_1276  -1
    order_2_10  connected_order_arc_1278  -1
    order_2_10  connected_order_arc_1280  -1
    order_2_10  connected_order_arc_1282  -1
    order_2_10  connected_order_arc_1284  -1
    order_2_10  connected_order_arc_1286  -1
    order_2_10  connected_order_arc_1288  -1
    order_2_10  connected_order_arc_1290  -1
    order_2_10  connected_order_arc_1292  -1
    order_2_10  connected_order_arc_1294  -1
    order_2_10  connected_order_arc_1296  -1
    order_2_10  connected_order_arc_1299  1
    order_2_10  connected_order_arc_1322  1
    order_2_10  connected_order_arc_1345  1
    order_2_10  connected_order_arc_1368  1
    order_2_10  connected_order_arc_1391  1
    order_2_10  connected_order_arc_1414  1
    order_2_10  connected_order_arc_1437  1
    order_2_10  connected_order_arc_1460  1
    order_2_10  connected_order_arc_1483  1
    order_2_10  connected_order_arc_1506  1
    order_2_10  connected_order_arc_1529  1
    order_2_10  order_active_lb_1554  1
    order_2_10  order_active_ub_1555  1
    order_2_10  fixed_segment_relative_order_1628  -1
    visit_2_11  out_degree_1559  -1
    visit_2_11  in_degree_1560  -1
    visit_2_11  order_active_lb_1561  -1
    visit_2_11  order_active_ub_1562  -12
    order_2_11  connected_order_arc_1276  1
    order_2_11  connected_order_arc_1299  -1
    order_2_11  connected_order_arc_1301  -1
    order_2_11  connected_order_arc_1303  -1
    order_2_11  connected_order_arc_1305  -1
    order_2_11  connected_order_arc_1307  -1
    order_2_11  connected_order_arc_1309  -1
    order_2_11  connected_order_arc_1311  -1
    order_2_11  connected_order_arc_1313  -1
    order_2_11  connected_order_arc_1315  -1
    order_2_11  connected_order_arc_1317  -1
    order_2_11  connected_order_arc_1319  -1
    order_2_11  connected_order_arc_1324  1
    order_2_11  connected_order_arc_1347  1
    order_2_11  connected_order_arc_1370  1
    order_2_11  connected_order_arc_1393  1
    order_2_11  connected_order_arc_1416  1
    order_2_11  connected_order_arc_1439  1
    order_2_11  connected_order_arc_1462  1
    order_2_11  connected_order_arc_1485  1
    order_2_11  connected_order_arc_1508  1
    order_2_11  connected_order_arc_1531  1
    order_2_11  order_active_lb_1561  1
    order_2_11  order_active_ub_1562  1
    order_2_11  fixed_segment_relative_order_1628  1
    order_2_11  fixed_segment_relative_order_1629  -1
    visit_2_12  out_degree_1566  -1
    visit_2_12  in_degree_1567  -1
    visit_2_12  order_active_lb_1568  -1
    visit_2_12  order_active_ub_1569  -12
    order_2_12  connected_order_arc_1278  1
    order_2_12  connected_order_arc_1301  1
    order_2_12  connected_order_arc_1322  -1
    order_2_12  connected_order_arc_1324  -1
    order_2_12  connected_order_arc_1326  -1
    order_2_12  connected_order_arc_1328  -1
    order_2_12  connected_order_arc_1330  -1
    order_2_12  connected_order_arc_1332  -1
    order_2_12  connected_order_arc_1334  -1
    order_2_12  connected_order_arc_1336  -1
    order_2_12  connected_order_arc_1338  -1
    order_2_12  connected_order_arc_1340  -1
    order_2_12  connected_order_arc_1342  -1
    order_2_12  connected_order_arc_1349  1
    order_2_12  connected_order_arc_1372  1
    order_2_12  connected_order_arc_1395  1
    order_2_12  connected_order_arc_1418  1
    order_2_12  connected_order_arc_1441  1
    order_2_12  connected_order_arc_1464  1
    order_2_12  connected_order_arc_1487  1
    order_2_12  connected_order_arc_1510  1
    order_2_12  connected_order_arc_1533  1
    order_2_12  order_active_lb_1568  1
    order_2_12  order_active_ub_1569  1
    order_2_12  fixed_segment_relative_order_1629  1
    order_2_12  fixed_segment_relative_order_1630  -1
    visit_2_13  out_degree_1573  -1
    visit_2_13  in_degree_1574  -1
    visit_2_13  order_active_lb_1575  -1
    visit_2_13  order_active_ub_1576  -12
    order_2_13  connected_order_arc_1280  1
    order_2_13  connected_order_arc_1303  1
    order_2_13  connected_order_arc_1326  1
    order_2_13  connected_order_arc_1345  -1
    order_2_13  connected_order_arc_1347  -1
    order_2_13  connected_order_arc_1349  -1
    order_2_13  connected_order_arc_1351  -1
    order_2_13  connected_order_arc_1353  -1
    order_2_13  connected_order_arc_1355  -1
    order_2_13  connected_order_arc_1357  -1
    order_2_13  connected_order_arc_1359  -1
    order_2_13  connected_order_arc_1361  -1
    order_2_13  connected_order_arc_1363  -1
    order_2_13  connected_order_arc_1365  -1
    order_2_13  connected_order_arc_1374  1
    order_2_13  connected_order_arc_1397  1
    order_2_13  connected_order_arc_1420  1
    order_2_13  connected_order_arc_1443  1
    order_2_13  connected_order_arc_1466  1
    order_2_13  connected_order_arc_1489  1
    order_2_13  connected_order_arc_1512  1
    order_2_13  connected_order_arc_1535  1
    order_2_13  order_active_lb_1575  1
    order_2_13  order_active_ub_1576  1
    order_2_13  fixed_segment_relative_order_1630  1
    visit_2_14  out_degree_1580  -1
    visit_2_14  in_degree_1581  -1
    visit_2_14  order_active_lb_1582  -1
    visit_2_14  order_active_ub_1583  -12
    visit_2_14  service_visit_def_1584  -1
    order_2_14  connected_order_arc_1282  1
    order_2_14  connected_order_arc_1305  1
    order_2_14  connected_order_arc_1328  1
    order_2_14  connected_order_arc_1351  1
    order_2_14  connected_order_arc_1368  -1
    order_2_14  connected_order_arc_1370  -1
    order_2_14  connected_order_arc_1372  -1
    order_2_14  connected_order_arc_1374  -1
    order_2_14  connected_order_arc_1376  -1
    order_2_14  connected_order_arc_1378  -1
    order_2_14  connected_order_arc_1380  -1
    order_2_14  connected_order_arc_1382  -1
    order_2_14  connected_order_arc_1384  -1
    order_2_14  connected_order_arc_1386  -1
    order_2_14  connected_order_arc_1388  -1
    order_2_14  connected_order_arc_1399  1
    order_2_14  connected_order_arc_1422  1
    order_2_14  connected_order_arc_1445  1
    order_2_14  connected_order_arc_1468  1
    order_2_14  connected_order_arc_1491  1
    order_2_14  connected_order_arc_1514  1
    order_2_14  connected_order_arc_1537  1
    order_2_14  order_active_lb_1582  1
    order_2_14  order_active_ub_1583  1
    visit_2_15  out_degree_1586  -1
    visit_2_15  in_degree_1587  -1
    visit_2_15  order_active_lb_1588  -1
    visit_2_15  order_active_ub_1589  -12
    visit_2_15  service_visit_def_1590  -1
    order_2_15  connected_order_arc_1284  1
    order_2_15  connected_order_arc_1307  1
    order_2_15  connected_order_arc_1330  1
    order_2_15  connected_order_arc_1353  1
    order_2_15  connected_order_arc_1376  1
    order_2_15  connected_order_arc_1391  -1
    order_2_15  connected_order_arc_1393  -1
    order_2_15  connected_order_arc_1395  -1
    order_2_15  connected_order_arc_1397  -1
    order_2_15  connected_order_arc_1399  -1
    order_2_15  connected_order_arc_1401  -1
    order_2_15  connected_order_arc_1403  -1
    order_2_15  connected_order_arc_1405  -1
    order_2_15  connected_order_arc_1407  -1
    order_2_15  connected_order_arc_1409  -1
    order_2_15  connected_order_arc_1411  -1
    order_2_15  connected_order_arc_1424  1
    order_2_15  connected_order_arc_1447  1
    order_2_15  connected_order_arc_1470  1
    order_2_15  connected_order_arc_1493  1
    order_2_15  connected_order_arc_1516  1
    order_2_15  connected_order_arc_1539  1
    order_2_15  order_active_lb_1588  1
    order_2_15  order_active_ub_1589  1
    visit_2_16  out_degree_1592  -1
    visit_2_16  in_degree_1593  -1
    visit_2_16  order_active_lb_1594  -1
    visit_2_16  order_active_ub_1595  -12
    visit_2_16  service_visit_def_1596  -1
    order_2_16  connected_order_arc_1286  1
    order_2_16  connected_order_arc_1309  1
    order_2_16  connected_order_arc_1332  1
    order_2_16  connected_order_arc_1355  1
    order_2_16  connected_order_arc_1378  1
    order_2_16  connected_order_arc_1401  1
    order_2_16  connected_order_arc_1414  -1
    order_2_16  connected_order_arc_1416  -1
    order_2_16  connected_order_arc_1418  -1
    order_2_16  connected_order_arc_1420  -1
    order_2_16  connected_order_arc_1422  -1
    order_2_16  connected_order_arc_1424  -1
    order_2_16  connected_order_arc_1426  -1
    order_2_16  connected_order_arc_1428  -1
    order_2_16  connected_order_arc_1430  -1
    order_2_16  connected_order_arc_1432  -1
    order_2_16  connected_order_arc_1434  -1
    order_2_16  connected_order_arc_1449  1
    order_2_16  connected_order_arc_1472  1
    order_2_16  connected_order_arc_1495  1
    order_2_16  connected_order_arc_1518  1
    order_2_16  connected_order_arc_1541  1
    order_2_16  order_active_lb_1594  1
    order_2_16  order_active_ub_1595  1
    visit_2_17  out_degree_1598  -1
    visit_2_17  in_degree_1599  -1
    visit_2_17  order_active_lb_1600  -1
    visit_2_17  order_active_ub_1601  -12
    visit_2_17  service_visit_def_1602  -1
    order_2_17  connected_order_arc_1288  1
    order_2_17  connected_order_arc_1311  1
    order_2_17  connected_order_arc_1334  1
    order_2_17  connected_order_arc_1357  1
    order_2_17  connected_order_arc_1380  1
    order_2_17  connected_order_arc_1403  1
    order_2_17  connected_order_arc_1426  1
    order_2_17  connected_order_arc_1437  -1
    order_2_17  connected_order_arc_1439  -1
    order_2_17  connected_order_arc_1441  -1
    order_2_17  connected_order_arc_1443  -1
    order_2_17  connected_order_arc_1445  -1
    order_2_17  connected_order_arc_1447  -1
    order_2_17  connected_order_arc_1449  -1
    order_2_17  connected_order_arc_1451  -1
    order_2_17  connected_order_arc_1453  -1
    order_2_17  connected_order_arc_1455  -1
    order_2_17  connected_order_arc_1457  -1
    order_2_17  connected_order_arc_1474  1
    order_2_17  connected_order_arc_1497  1
    order_2_17  connected_order_arc_1520  1
    order_2_17  connected_order_arc_1543  1
    order_2_17  order_active_lb_1600  1
    order_2_17  order_active_ub_1601  1
    visit_2_18  out_degree_1604  -1
    visit_2_18  in_degree_1605  -1
    visit_2_18  order_active_lb_1606  -1
    visit_2_18  order_active_ub_1607  -12
    visit_2_18  service_visit_def_1608  -1
    order_2_18  connected_order_arc_1290  1
    order_2_18  connected_order_arc_1313  1
    order_2_18  connected_order_arc_1336  1
    order_2_18  connected_order_arc_1359  1
    order_2_18  connected_order_arc_1382  1
    order_2_18  connected_order_arc_1405  1
    order_2_18  connected_order_arc_1428  1
    order_2_18  connected_order_arc_1451  1
    order_2_18  connected_order_arc_1460  -1
    order_2_18  connected_order_arc_1462  -1
    order_2_18  connected_order_arc_1464  -1
    order_2_18  connected_order_arc_1466  -1
    order_2_18  connected_order_arc_1468  -1
    order_2_18  connected_order_arc_1470  -1
    order_2_18  connected_order_arc_1472  -1
    order_2_18  connected_order_arc_1474  -1
    order_2_18  connected_order_arc_1476  -1
    order_2_18  connected_order_arc_1478  -1
    order_2_18  connected_order_arc_1480  -1
    order_2_18  connected_order_arc_1499  1
    order_2_18  connected_order_arc_1522  1
    order_2_18  connected_order_arc_1545  1
    order_2_18  order_active_lb_1606  1
    order_2_18  order_active_ub_1607  1
    visit_2_19  out_degree_1610  -1
    visit_2_19  in_degree_1611  -1
    visit_2_19  order_active_lb_1612  -1
    visit_2_19  order_active_ub_1613  -12
    visit_2_19  service_visit_def_1614  -1
    order_2_19  connected_order_arc_1292  1
    order_2_19  connected_order_arc_1315  1
    order_2_19  connected_order_arc_1338  1
    order_2_19  connected_order_arc_1361  1
    order_2_19  connected_order_arc_1384  1
    order_2_19  connected_order_arc_1407  1
    order_2_19  connected_order_arc_1430  1
    order_2_19  connected_order_arc_1453  1
    order_2_19  connected_order_arc_1476  1
    order_2_19  connected_order_arc_1483  -1
    order_2_19  connected_order_arc_1485  -1
    order_2_19  connected_order_arc_1487  -1
    order_2_19  connected_order_arc_1489  -1
    order_2_19  connected_order_arc_1491  -1
    order_2_19  connected_order_arc_1493  -1
    order_2_19  connected_order_arc_1495  -1
    order_2_19  connected_order_arc_1497  -1
    order_2_19  connected_order_arc_1499  -1
    order_2_19  connected_order_arc_1501  -1
    order_2_19  connected_order_arc_1503  -1
    order_2_19  connected_order_arc_1524  1
    order_2_19  connected_order_arc_1547  1
    order_2_19  order_active_lb_1612  1
    order_2_19  order_active_ub_1613  1
    visit_2_20  out_degree_1616  -1
    visit_2_20  in_degree_1617  -1
    visit_2_20  order_active_lb_1618  -1
    visit_2_20  order_active_ub_1619  -12
    visit_2_20  service_visit_def_1620  -1
    order_2_20  connected_order_arc_1294  1
    order_2_20  connected_order_arc_1317  1
    order_2_20  connected_order_arc_1340  1
    order_2_20  connected_order_arc_1363  1
    order_2_20  connected_order_arc_1386  1
    order_2_20  connected_order_arc_1409  1
    order_2_20  connected_order_arc_1432  1
    order_2_20  connected_order_arc_1455  1
    order_2_20  connected_order_arc_1478  1
    order_2_20  connected_order_arc_1501  1
    order_2_20  connected_order_arc_1506  -1
    order_2_20  connected_order_arc_1508  -1
    order_2_20  connected_order_arc_1510  -1
    order_2_20  connected_order_arc_1512  -1
    order_2_20  connected_order_arc_1514  -1
    order_2_20  connected_order_arc_1516  -1
    order_2_20  connected_order_arc_1518  -1
    order_2_20  connected_order_arc_1520  -1
    order_2_20  connected_order_arc_1522  -1
    order_2_20  connected_order_arc_1524  -1
    order_2_20  connected_order_arc_1526  -1
    order_2_20  connected_order_arc_1549  1
    order_2_20  order_active_lb_1618  1
    order_2_20  order_active_ub_1619  1
    visit_2_21  out_degree_1622  -1
    visit_2_21  in_degree_1623  -1
    visit_2_21  order_active_lb_1624  -1
    visit_2_21  order_active_ub_1625  -12
    visit_2_21  service_visit_def_1626  -1
    order_2_21  connected_order_arc_1296  1
    order_2_21  connected_order_arc_1319  1
    order_2_21  connected_order_arc_1342  1
    order_2_21  connected_order_arc_1365  1
    order_2_21  connected_order_arc_1388  1
    order_2_21  connected_order_arc_1411  1
    order_2_21  connected_order_arc_1434  1
    order_2_21  connected_order_arc_1457  1
    order_2_21  connected_order_arc_1480  1
    order_2_21  connected_order_arc_1503  1
    order_2_21  connected_order_arc_1526  1
    order_2_21  connected_order_arc_1529  -1
    order_2_21  connected_order_arc_1531  -1
    order_2_21  connected_order_arc_1533  -1
    order_2_21  connected_order_arc_1535  -1
    order_2_21  connected_order_arc_1537  -1
    order_2_21  connected_order_arc_1539  -1
    order_2_21  connected_order_arc_1541  -1
    order_2_21  connected_order_arc_1543  -1
    order_2_21  connected_order_arc_1545  -1
    order_2_21  connected_order_arc_1547  -1
    order_2_21  connected_order_arc_1549  -1
    order_2_21  order_active_lb_1624  1
    order_2_21  order_active_ub_1625  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1261  -30
    arc_2_0_0  depot_departure_or_bypass_1550  1
    arc_2_0_0  depot_return_or_bypass_1551  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1262  -30
    arc_2_0_10  depot_departure_or_bypass_1550  1
    arc_2_0_10  in_degree_1553  1
    arc_2_0_10  original_T_including_depot_unload_1631  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1262  1
    load_2_0_10  segment_load_conservation_1556  -1
    load_2_0_10  segment_prefix_lb_1557  1
    load_2_0_10  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1263  -30
    arc_2_0_11  depot_departure_or_bypass_1550  1
    arc_2_0_11  in_degree_1560  1
    arc_2_0_11  original_T_including_depot_unload_1631  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1263  1
    load_2_0_11  segment_load_conservation_1563  -1
    load_2_0_11  segment_prefix_lb_1564  1
    load_2_0_11  segment_prefix_ub_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1264  -30
    arc_2_0_12  depot_departure_or_bypass_1550  1
    arc_2_0_12  in_degree_1567  1
    arc_2_0_12  original_T_including_depot_unload_1631  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1264  1
    load_2_0_12  segment_load_conservation_1570  -1
    load_2_0_12  segment_prefix_lb_1571  1
    load_2_0_12  segment_prefix_ub_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1265  -30
    arc_2_0_13  depot_departure_or_bypass_1550  1
    arc_2_0_13  in_degree_1574  1
    arc_2_0_13  original_T_including_depot_unload_1631  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1265  1
    load_2_0_13  segment_load_conservation_1577  -1
    load_2_0_13  segment_prefix_lb_1578  1
    load_2_0_13  segment_prefix_ub_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1266  -30
    arc_2_0_14  depot_departure_or_bypass_1550  1
    arc_2_0_14  in_degree_1581  1
    arc_2_0_14  original_T_including_depot_unload_1631  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1266  1
    load_2_0_14  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1267  -30
    arc_2_0_15  depot_departure_or_bypass_1550  1
    arc_2_0_15  in_degree_1587  1
    arc_2_0_15  original_T_including_depot_unload_1631  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1267  1
    load_2_0_15  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1268  -30
    arc_2_0_16  depot_departure_or_bypass_1550  1
    arc_2_0_16  in_degree_1593  1
    arc_2_0_16  original_T_including_depot_unload_1631  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1268  1
    load_2_0_16  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1269  -30
    arc_2_0_17  depot_departure_or_bypass_1550  1
    arc_2_0_17  in_degree_1599  1
    arc_2_0_17  original_T_including_depot_unload_1631  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1269  1
    load_2_0_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1270  -30
    arc_2_0_18  depot_departure_or_bypass_1550  1
    arc_2_0_18  in_degree_1605  1
    arc_2_0_18  original_T_including_depot_unload_1631  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1270  1
    load_2_0_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1271  -30
    arc_2_0_19  depot_departure_or_bypass_1550  1
    arc_2_0_19  in_degree_1611  1
    arc_2_0_19  original_T_including_depot_unload_1631  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1271  1
    load_2_0_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1272  -30
    arc_2_0_20  depot_departure_or_bypass_1550  1
    arc_2_0_20  in_degree_1617  1
    arc_2_0_20  original_T_including_depot_unload_1631  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1272  1
    load_2_0_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1273  -30
    arc_2_0_21  depot_departure_or_bypass_1550  1
    arc_2_0_21  in_degree_1623  1
    arc_2_0_21  original_T_including_depot_unload_1631  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1273  1
    load_2_0_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1274  -30
    arc_2_10_0  depot_return_or_bypass_1551  1
    arc_2_10_0  out_degree_1552  1
    arc_2_10_0  original_T_including_depot_unload_1631  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1274  1
    load_2_10_0  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1275  -30
    arc_2_10_11  connected_order_arc_1276  -13
    arc_2_10_11  out_degree_1552  1
    arc_2_10_11  in_degree_1560  1
    arc_2_10_11  original_T_including_depot_unload_1631  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1275  1
    load_2_10_11  segment_load_conservation_1556  1
    load_2_10_11  segment_load_conservation_1563  -1
    load_2_10_11  segment_prefix_lb_1564  1
    load_2_10_11  segment_prefix_ub_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1277  -30
    arc_2_10_12  connected_order_arc_1278  -13
    arc_2_10_12  out_degree_1552  1
    arc_2_10_12  in_degree_1567  1
    arc_2_10_12  original_T_including_depot_unload_1631  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1277  1
    load_2_10_12  segment_load_conservation_1556  1
    load_2_10_12  segment_load_conservation_1570  -1
    load_2_10_12  segment_prefix_lb_1571  1
    load_2_10_12  segment_prefix_ub_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1279  -30
    arc_2_10_13  connected_order_arc_1280  -13
    arc_2_10_13  out_degree_1552  1
    arc_2_10_13  in_degree_1574  1
    arc_2_10_13  original_T_including_depot_unload_1631  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1279  1
    load_2_10_13  segment_load_conservation_1556  1
    load_2_10_13  segment_load_conservation_1577  -1
    load_2_10_13  segment_prefix_lb_1578  1
    load_2_10_13  segment_prefix_ub_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1281  -30
    arc_2_10_14  connected_order_arc_1282  -13
    arc_2_10_14  out_degree_1552  1
    arc_2_10_14  in_degree_1581  1
    arc_2_10_14  original_T_including_depot_unload_1631  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1281  1
    load_2_10_14  segment_load_conservation_1556  1
    load_2_10_14  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1283  -30
    arc_2_10_15  connected_order_arc_1284  -13
    arc_2_10_15  out_degree_1552  1
    arc_2_10_15  in_degree_1587  1
    arc_2_10_15  original_T_including_depot_unload_1631  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1283  1
    load_2_10_15  segment_load_conservation_1556  1
    load_2_10_15  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1285  -30
    arc_2_10_16  connected_order_arc_1286  -13
    arc_2_10_16  out_degree_1552  1
    arc_2_10_16  in_degree_1593  1
    arc_2_10_16  original_T_including_depot_unload_1631  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1285  1
    load_2_10_16  segment_load_conservation_1556  1
    load_2_10_16  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1287  -30
    arc_2_10_17  connected_order_arc_1288  -13
    arc_2_10_17  out_degree_1552  1
    arc_2_10_17  in_degree_1599  1
    arc_2_10_17  original_T_including_depot_unload_1631  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1287  1
    load_2_10_17  segment_load_conservation_1556  1
    load_2_10_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1289  -30
    arc_2_10_18  connected_order_arc_1290  -13
    arc_2_10_18  out_degree_1552  1
    arc_2_10_18  in_degree_1605  1
    arc_2_10_18  original_T_including_depot_unload_1631  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1289  1
    load_2_10_18  segment_load_conservation_1556  1
    load_2_10_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1291  -30
    arc_2_10_19  connected_order_arc_1292  -13
    arc_2_10_19  out_degree_1552  1
    arc_2_10_19  in_degree_1611  1
    arc_2_10_19  original_T_including_depot_unload_1631  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1291  1
    load_2_10_19  segment_load_conservation_1556  1
    load_2_10_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1293  -30
    arc_2_10_20  connected_order_arc_1294  -13
    arc_2_10_20  out_degree_1552  1
    arc_2_10_20  in_degree_1617  1
    arc_2_10_20  original_T_including_depot_unload_1631  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1293  1
    load_2_10_20  segment_load_conservation_1556  1
    load_2_10_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1295  -30
    arc_2_10_21  connected_order_arc_1296  -13
    arc_2_10_21  out_degree_1552  1
    arc_2_10_21  in_degree_1623  1
    arc_2_10_21  original_T_including_depot_unload_1631  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1295  1
    load_2_10_21  segment_load_conservation_1556  1
    load_2_10_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1297  -30
    arc_2_11_0  depot_return_or_bypass_1551  1
    arc_2_11_0  out_degree_1559  1
    arc_2_11_0  original_T_including_depot_unload_1631  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1297  1
    load_2_11_0  segment_load_conservation_1563  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1298  -30
    arc_2_11_10  connected_order_arc_1299  -13
    arc_2_11_10  in_degree_1553  1
    arc_2_11_10  out_degree_1559  1
    arc_2_11_10  original_T_including_depot_unload_1631  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1298  1
    load_2_11_10  segment_load_conservation_1556  -1
    load_2_11_10  segment_prefix_lb_1557  1
    load_2_11_10  segment_prefix_ub_1558  1
    load_2_11_10  segment_load_conservation_1563  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1300  -30
    arc_2_11_12  connected_order_arc_1301  -13
    arc_2_11_12  out_degree_1559  1
    arc_2_11_12  in_degree_1567  1
    arc_2_11_12  original_T_including_depot_unload_1631  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1300  1
    load_2_11_12  segment_load_conservation_1563  1
    load_2_11_12  segment_load_conservation_1570  -1
    load_2_11_12  segment_prefix_lb_1571  1
    load_2_11_12  segment_prefix_ub_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1302  -30
    arc_2_11_13  connected_order_arc_1303  -13
    arc_2_11_13  out_degree_1559  1
    arc_2_11_13  in_degree_1574  1
    arc_2_11_13  original_T_including_depot_unload_1631  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1302  1
    load_2_11_13  segment_load_conservation_1563  1
    load_2_11_13  segment_load_conservation_1577  -1
    load_2_11_13  segment_prefix_lb_1578  1
    load_2_11_13  segment_prefix_ub_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1304  -30
    arc_2_11_14  connected_order_arc_1305  -13
    arc_2_11_14  out_degree_1559  1
    arc_2_11_14  in_degree_1581  1
    arc_2_11_14  original_T_including_depot_unload_1631  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1304  1
    load_2_11_14  segment_load_conservation_1563  1
    load_2_11_14  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1306  -30
    arc_2_11_15  connected_order_arc_1307  -13
    arc_2_11_15  out_degree_1559  1
    arc_2_11_15  in_degree_1587  1
    arc_2_11_15  original_T_including_depot_unload_1631  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1306  1
    load_2_11_15  segment_load_conservation_1563  1
    load_2_11_15  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1308  -30
    arc_2_11_16  connected_order_arc_1309  -13
    arc_2_11_16  out_degree_1559  1
    arc_2_11_16  in_degree_1593  1
    arc_2_11_16  original_T_including_depot_unload_1631  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1308  1
    load_2_11_16  segment_load_conservation_1563  1
    load_2_11_16  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1310  -30
    arc_2_11_17  connected_order_arc_1311  -13
    arc_2_11_17  out_degree_1559  1
    arc_2_11_17  in_degree_1599  1
    arc_2_11_17  original_T_including_depot_unload_1631  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1310  1
    load_2_11_17  segment_load_conservation_1563  1
    load_2_11_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1312  -30
    arc_2_11_18  connected_order_arc_1313  -13
    arc_2_11_18  out_degree_1559  1
    arc_2_11_18  in_degree_1605  1
    arc_2_11_18  original_T_including_depot_unload_1631  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1312  1
    load_2_11_18  segment_load_conservation_1563  1
    load_2_11_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1314  -30
    arc_2_11_19  connected_order_arc_1315  -13
    arc_2_11_19  out_degree_1559  1
    arc_2_11_19  in_degree_1611  1
    arc_2_11_19  original_T_including_depot_unload_1631  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1314  1
    load_2_11_19  segment_load_conservation_1563  1
    load_2_11_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1316  -30
    arc_2_11_20  connected_order_arc_1317  -13
    arc_2_11_20  out_degree_1559  1
    arc_2_11_20  in_degree_1617  1
    arc_2_11_20  original_T_including_depot_unload_1631  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1316  1
    load_2_11_20  segment_load_conservation_1563  1
    load_2_11_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1318  -30
    arc_2_11_21  connected_order_arc_1319  -13
    arc_2_11_21  out_degree_1559  1
    arc_2_11_21  in_degree_1623  1
    arc_2_11_21  original_T_including_depot_unload_1631  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1318  1
    load_2_11_21  segment_load_conservation_1563  1
    load_2_11_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1320  -30
    arc_2_12_0  depot_return_or_bypass_1551  1
    arc_2_12_0  out_degree_1566  1
    arc_2_12_0  original_T_including_depot_unload_1631  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1320  1
    load_2_12_0  segment_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1321  -30
    arc_2_12_10  connected_order_arc_1322  -13
    arc_2_12_10  in_degree_1553  1
    arc_2_12_10  out_degree_1566  1
    arc_2_12_10  original_T_including_depot_unload_1631  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1321  1
    load_2_12_10  segment_load_conservation_1556  -1
    load_2_12_10  segment_prefix_lb_1557  1
    load_2_12_10  segment_prefix_ub_1558  1
    load_2_12_10  segment_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1323  -30
    arc_2_12_11  connected_order_arc_1324  -13
    arc_2_12_11  in_degree_1560  1
    arc_2_12_11  out_degree_1566  1
    arc_2_12_11  original_T_including_depot_unload_1631  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1323  1
    load_2_12_11  segment_load_conservation_1563  -1
    load_2_12_11  segment_prefix_lb_1564  1
    load_2_12_11  segment_prefix_ub_1565  1
    load_2_12_11  segment_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1325  -30
    arc_2_12_13  connected_order_arc_1326  -13
    arc_2_12_13  out_degree_1566  1
    arc_2_12_13  in_degree_1574  1
    arc_2_12_13  original_T_including_depot_unload_1631  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1325  1
    load_2_12_13  segment_load_conservation_1570  1
    load_2_12_13  segment_load_conservation_1577  -1
    load_2_12_13  segment_prefix_lb_1578  1
    load_2_12_13  segment_prefix_ub_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1327  -30
    arc_2_12_14  connected_order_arc_1328  -13
    arc_2_12_14  out_degree_1566  1
    arc_2_12_14  in_degree_1581  1
    arc_2_12_14  original_T_including_depot_unload_1631  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1327  1
    load_2_12_14  segment_load_conservation_1570  1
    load_2_12_14  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1329  -30
    arc_2_12_15  connected_order_arc_1330  -13
    arc_2_12_15  out_degree_1566  1
    arc_2_12_15  in_degree_1587  1
    arc_2_12_15  original_T_including_depot_unload_1631  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1329  1
    load_2_12_15  segment_load_conservation_1570  1
    load_2_12_15  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1331  -30
    arc_2_12_16  connected_order_arc_1332  -13
    arc_2_12_16  out_degree_1566  1
    arc_2_12_16  in_degree_1593  1
    arc_2_12_16  original_T_including_depot_unload_1631  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1331  1
    load_2_12_16  segment_load_conservation_1570  1
    load_2_12_16  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1333  -30
    arc_2_12_17  connected_order_arc_1334  -13
    arc_2_12_17  out_degree_1566  1
    arc_2_12_17  in_degree_1599  1
    arc_2_12_17  original_T_including_depot_unload_1631  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1333  1
    load_2_12_17  segment_load_conservation_1570  1
    load_2_12_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1335  -30
    arc_2_12_18  connected_order_arc_1336  -13
    arc_2_12_18  out_degree_1566  1
    arc_2_12_18  in_degree_1605  1
    arc_2_12_18  original_T_including_depot_unload_1631  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1335  1
    load_2_12_18  segment_load_conservation_1570  1
    load_2_12_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1337  -30
    arc_2_12_19  connected_order_arc_1338  -13
    arc_2_12_19  out_degree_1566  1
    arc_2_12_19  in_degree_1611  1
    arc_2_12_19  original_T_including_depot_unload_1631  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1337  1
    load_2_12_19  segment_load_conservation_1570  1
    load_2_12_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1339  -30
    arc_2_12_20  connected_order_arc_1340  -13
    arc_2_12_20  out_degree_1566  1
    arc_2_12_20  in_degree_1617  1
    arc_2_12_20  original_T_including_depot_unload_1631  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1339  1
    load_2_12_20  segment_load_conservation_1570  1
    load_2_12_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1341  -30
    arc_2_12_21  connected_order_arc_1342  -13
    arc_2_12_21  out_degree_1566  1
    arc_2_12_21  in_degree_1623  1
    arc_2_12_21  original_T_including_depot_unload_1631  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1341  1
    load_2_12_21  segment_load_conservation_1570  1
    load_2_12_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1343  -30
    arc_2_13_0  depot_return_or_bypass_1551  1
    arc_2_13_0  out_degree_1573  1
    arc_2_13_0  original_T_including_depot_unload_1631  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1343  1
    load_2_13_0  segment_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1344  -30
    arc_2_13_10  connected_order_arc_1345  -13
    arc_2_13_10  in_degree_1553  1
    arc_2_13_10  out_degree_1573  1
    arc_2_13_10  original_T_including_depot_unload_1631  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1344  1
    load_2_13_10  segment_load_conservation_1556  -1
    load_2_13_10  segment_prefix_lb_1557  1
    load_2_13_10  segment_prefix_ub_1558  1
    load_2_13_10  segment_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1346  -30
    arc_2_13_11  connected_order_arc_1347  -13
    arc_2_13_11  in_degree_1560  1
    arc_2_13_11  out_degree_1573  1
    arc_2_13_11  original_T_including_depot_unload_1631  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1346  1
    load_2_13_11  segment_load_conservation_1563  -1
    load_2_13_11  segment_prefix_lb_1564  1
    load_2_13_11  segment_prefix_ub_1565  1
    load_2_13_11  segment_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1348  -30
    arc_2_13_12  connected_order_arc_1349  -13
    arc_2_13_12  in_degree_1567  1
    arc_2_13_12  out_degree_1573  1
    arc_2_13_12  original_T_including_depot_unload_1631  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1348  1
    load_2_13_12  segment_load_conservation_1570  -1
    load_2_13_12  segment_prefix_lb_1571  1
    load_2_13_12  segment_prefix_ub_1572  1
    load_2_13_12  segment_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1350  -30
    arc_2_13_14  connected_order_arc_1351  -13
    arc_2_13_14  out_degree_1573  1
    arc_2_13_14  in_degree_1581  1
    arc_2_13_14  original_T_including_depot_unload_1631  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1350  1
    load_2_13_14  segment_load_conservation_1577  1
    load_2_13_14  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1352  -30
    arc_2_13_15  connected_order_arc_1353  -13
    arc_2_13_15  out_degree_1573  1
    arc_2_13_15  in_degree_1587  1
    arc_2_13_15  original_T_including_depot_unload_1631  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1352  1
    load_2_13_15  segment_load_conservation_1577  1
    load_2_13_15  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1354  -30
    arc_2_13_16  connected_order_arc_1355  -13
    arc_2_13_16  out_degree_1573  1
    arc_2_13_16  in_degree_1593  1
    arc_2_13_16  original_T_including_depot_unload_1631  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1354  1
    load_2_13_16  segment_load_conservation_1577  1
    load_2_13_16  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1356  -30
    arc_2_13_17  connected_order_arc_1357  -13
    arc_2_13_17  out_degree_1573  1
    arc_2_13_17  in_degree_1599  1
    arc_2_13_17  original_T_including_depot_unload_1631  1.0428409649002836e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1356  1
    load_2_13_17  segment_load_conservation_1577  1
    load_2_13_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1358  -30
    arc_2_13_18  connected_order_arc_1359  -13
    arc_2_13_18  out_degree_1573  1
    arc_2_13_18  in_degree_1605  1
    arc_2_13_18  original_T_including_depot_unload_1631  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1358  1
    load_2_13_18  segment_load_conservation_1577  1
    load_2_13_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1360  -30
    arc_2_13_19  connected_order_arc_1361  -13
    arc_2_13_19  out_degree_1573  1
    arc_2_13_19  in_degree_1611  1
    arc_2_13_19  original_T_including_depot_unload_1631  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1360  1
    load_2_13_19  segment_load_conservation_1577  1
    load_2_13_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1362  -30
    arc_2_13_20  connected_order_arc_1363  -13
    arc_2_13_20  out_degree_1573  1
    arc_2_13_20  in_degree_1617  1
    arc_2_13_20  original_T_including_depot_unload_1631  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1362  1
    load_2_13_20  segment_load_conservation_1577  1
    load_2_13_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1364  -30
    arc_2_13_21  connected_order_arc_1365  -13
    arc_2_13_21  out_degree_1573  1
    arc_2_13_21  in_degree_1623  1
    arc_2_13_21  original_T_including_depot_unload_1631  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1364  1
    load_2_13_21  segment_load_conservation_1577  1
    load_2_13_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1366  -30
    arc_2_14_0  depot_return_or_bypass_1551  1
    arc_2_14_0  out_degree_1580  1
    arc_2_14_0  original_T_including_depot_unload_1631  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1366  1
    load_2_14_0  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1367  -30
    arc_2_14_10  connected_order_arc_1368  -13
    arc_2_14_10  in_degree_1553  1
    arc_2_14_10  out_degree_1580  1
    arc_2_14_10  original_T_including_depot_unload_1631  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1367  1
    load_2_14_10  segment_load_conservation_1556  -1
    load_2_14_10  segment_prefix_lb_1557  1
    load_2_14_10  segment_prefix_ub_1558  1
    load_2_14_10  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1369  -30
    arc_2_14_11  connected_order_arc_1370  -13
    arc_2_14_11  in_degree_1560  1
    arc_2_14_11  out_degree_1580  1
    arc_2_14_11  original_T_including_depot_unload_1631  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1369  1
    load_2_14_11  segment_load_conservation_1563  -1
    load_2_14_11  segment_prefix_lb_1564  1
    load_2_14_11  segment_prefix_ub_1565  1
    load_2_14_11  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1371  -30
    arc_2_14_12  connected_order_arc_1372  -13
    arc_2_14_12  in_degree_1567  1
    arc_2_14_12  out_degree_1580  1
    arc_2_14_12  original_T_including_depot_unload_1631  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1371  1
    load_2_14_12  segment_load_conservation_1570  -1
    load_2_14_12  segment_prefix_lb_1571  1
    load_2_14_12  segment_prefix_ub_1572  1
    load_2_14_12  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1373  -30
    arc_2_14_13  connected_order_arc_1374  -13
    arc_2_14_13  in_degree_1574  1
    arc_2_14_13  out_degree_1580  1
    arc_2_14_13  original_T_including_depot_unload_1631  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1373  1
    load_2_14_13  segment_load_conservation_1577  -1
    load_2_14_13  segment_prefix_lb_1578  1
    load_2_14_13  segment_prefix_ub_1579  1
    load_2_14_13  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1375  -30
    arc_2_14_15  connected_order_arc_1376  -13
    arc_2_14_15  out_degree_1580  1
    arc_2_14_15  in_degree_1587  1
    arc_2_14_15  original_T_including_depot_unload_1631  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1375  1
    load_2_14_15  free_load_conservation_1585  1
    load_2_14_15  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1377  -30
    arc_2_14_16  connected_order_arc_1378  -13
    arc_2_14_16  out_degree_1580  1
    arc_2_14_16  in_degree_1593  1
    arc_2_14_16  original_T_including_depot_unload_1631  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1377  1
    load_2_14_16  free_load_conservation_1585  1
    load_2_14_16  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1379  -30
    arc_2_14_17  connected_order_arc_1380  -13
    arc_2_14_17  out_degree_1580  1
    arc_2_14_17  in_degree_1599  1
    arc_2_14_17  original_T_including_depot_unload_1631  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1379  1
    load_2_14_17  free_load_conservation_1585  1
    load_2_14_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1381  -30
    arc_2_14_18  connected_order_arc_1382  -13
    arc_2_14_18  out_degree_1580  1
    arc_2_14_18  in_degree_1605  1
    arc_2_14_18  original_T_including_depot_unload_1631  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1381  1
    load_2_14_18  free_load_conservation_1585  1
    load_2_14_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1383  -30
    arc_2_14_19  connected_order_arc_1384  -13
    arc_2_14_19  out_degree_1580  1
    arc_2_14_19  in_degree_1611  1
    arc_2_14_19  original_T_including_depot_unload_1631  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1383  1
    load_2_14_19  free_load_conservation_1585  1
    load_2_14_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1385  -30
    arc_2_14_20  connected_order_arc_1386  -13
    arc_2_14_20  out_degree_1580  1
    arc_2_14_20  in_degree_1617  1
    arc_2_14_20  original_T_including_depot_unload_1631  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1385  1
    load_2_14_20  free_load_conservation_1585  1
    load_2_14_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1387  -30
    arc_2_14_21  connected_order_arc_1388  -13
    arc_2_14_21  out_degree_1580  1
    arc_2_14_21  in_degree_1623  1
    arc_2_14_21  original_T_including_depot_unload_1631  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1387  1
    load_2_14_21  free_load_conservation_1585  1
    load_2_14_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1389  -30
    arc_2_15_0  depot_return_or_bypass_1551  1
    arc_2_15_0  out_degree_1586  1
    arc_2_15_0  original_T_including_depot_unload_1631  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1389  1
    load_2_15_0  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1390  -30
    arc_2_15_10  connected_order_arc_1391  -13
    arc_2_15_10  in_degree_1553  1
    arc_2_15_10  out_degree_1586  1
    arc_2_15_10  original_T_including_depot_unload_1631  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1390  1
    load_2_15_10  segment_load_conservation_1556  -1
    load_2_15_10  segment_prefix_lb_1557  1
    load_2_15_10  segment_prefix_ub_1558  1
    load_2_15_10  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1392  -30
    arc_2_15_11  connected_order_arc_1393  -13
    arc_2_15_11  in_degree_1560  1
    arc_2_15_11  out_degree_1586  1
    arc_2_15_11  original_T_including_depot_unload_1631  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1392  1
    load_2_15_11  segment_load_conservation_1563  -1
    load_2_15_11  segment_prefix_lb_1564  1
    load_2_15_11  segment_prefix_ub_1565  1
    load_2_15_11  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1394  -30
    arc_2_15_12  connected_order_arc_1395  -13
    arc_2_15_12  in_degree_1567  1
    arc_2_15_12  out_degree_1586  1
    arc_2_15_12  original_T_including_depot_unload_1631  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1394  1
    load_2_15_12  segment_load_conservation_1570  -1
    load_2_15_12  segment_prefix_lb_1571  1
    load_2_15_12  segment_prefix_ub_1572  1
    load_2_15_12  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1396  -30
    arc_2_15_13  connected_order_arc_1397  -13
    arc_2_15_13  in_degree_1574  1
    arc_2_15_13  out_degree_1586  1
    arc_2_15_13  original_T_including_depot_unload_1631  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1396  1
    load_2_15_13  segment_load_conservation_1577  -1
    load_2_15_13  segment_prefix_lb_1578  1
    load_2_15_13  segment_prefix_ub_1579  1
    load_2_15_13  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1398  -30
    arc_2_15_14  connected_order_arc_1399  -13
    arc_2_15_14  in_degree_1581  1
    arc_2_15_14  out_degree_1586  1
    arc_2_15_14  original_T_including_depot_unload_1631  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1398  1
    load_2_15_14  free_load_conservation_1585  -1
    load_2_15_14  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1400  -30
    arc_2_15_16  connected_order_arc_1401  -13
    arc_2_15_16  out_degree_1586  1
    arc_2_15_16  in_degree_1593  1
    arc_2_15_16  original_T_including_depot_unload_1631  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1400  1
    load_2_15_16  free_load_conservation_1591  1
    load_2_15_16  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1402  -30
    arc_2_15_17  connected_order_arc_1403  -13
    arc_2_15_17  out_degree_1586  1
    arc_2_15_17  in_degree_1599  1
    arc_2_15_17  original_T_including_depot_unload_1631  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1402  1
    load_2_15_17  free_load_conservation_1591  1
    load_2_15_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1404  -30
    arc_2_15_18  connected_order_arc_1405  -13
    arc_2_15_18  out_degree_1586  1
    arc_2_15_18  in_degree_1605  1
    arc_2_15_18  original_T_including_depot_unload_1631  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1404  1
    load_2_15_18  free_load_conservation_1591  1
    load_2_15_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1406  -30
    arc_2_15_19  connected_order_arc_1407  -13
    arc_2_15_19  out_degree_1586  1
    arc_2_15_19  in_degree_1611  1
    arc_2_15_19  original_T_including_depot_unload_1631  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1406  1
    load_2_15_19  free_load_conservation_1591  1
    load_2_15_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1408  -30
    arc_2_15_20  connected_order_arc_1409  -13
    arc_2_15_20  out_degree_1586  1
    arc_2_15_20  in_degree_1617  1
    arc_2_15_20  original_T_including_depot_unload_1631  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1408  1
    load_2_15_20  free_load_conservation_1591  1
    load_2_15_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1410  -30
    arc_2_15_21  connected_order_arc_1411  -13
    arc_2_15_21  out_degree_1586  1
    arc_2_15_21  in_degree_1623  1
    arc_2_15_21  original_T_including_depot_unload_1631  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1410  1
    load_2_15_21  free_load_conservation_1591  1
    load_2_15_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1412  -30
    arc_2_16_0  depot_return_or_bypass_1551  1
    arc_2_16_0  out_degree_1592  1
    arc_2_16_0  original_T_including_depot_unload_1631  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1412  1
    load_2_16_0  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1413  -30
    arc_2_16_10  connected_order_arc_1414  -13
    arc_2_16_10  in_degree_1553  1
    arc_2_16_10  out_degree_1592  1
    arc_2_16_10  original_T_including_depot_unload_1631  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1413  1
    load_2_16_10  segment_load_conservation_1556  -1
    load_2_16_10  segment_prefix_lb_1557  1
    load_2_16_10  segment_prefix_ub_1558  1
    load_2_16_10  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1415  -30
    arc_2_16_11  connected_order_arc_1416  -13
    arc_2_16_11  in_degree_1560  1
    arc_2_16_11  out_degree_1592  1
    arc_2_16_11  original_T_including_depot_unload_1631  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1415  1
    load_2_16_11  segment_load_conservation_1563  -1
    load_2_16_11  segment_prefix_lb_1564  1
    load_2_16_11  segment_prefix_ub_1565  1
    load_2_16_11  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1417  -30
    arc_2_16_12  connected_order_arc_1418  -13
    arc_2_16_12  in_degree_1567  1
    arc_2_16_12  out_degree_1592  1
    arc_2_16_12  original_T_including_depot_unload_1631  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1417  1
    load_2_16_12  segment_load_conservation_1570  -1
    load_2_16_12  segment_prefix_lb_1571  1
    load_2_16_12  segment_prefix_ub_1572  1
    load_2_16_12  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1419  -30
    arc_2_16_13  connected_order_arc_1420  -13
    arc_2_16_13  in_degree_1574  1
    arc_2_16_13  out_degree_1592  1
    arc_2_16_13  original_T_including_depot_unload_1631  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1419  1
    load_2_16_13  segment_load_conservation_1577  -1
    load_2_16_13  segment_prefix_lb_1578  1
    load_2_16_13  segment_prefix_ub_1579  1
    load_2_16_13  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1421  -30
    arc_2_16_14  connected_order_arc_1422  -13
    arc_2_16_14  in_degree_1581  1
    arc_2_16_14  out_degree_1592  1
    arc_2_16_14  original_T_including_depot_unload_1631  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1421  1
    load_2_16_14  free_load_conservation_1585  -1
    load_2_16_14  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1423  -30
    arc_2_16_15  connected_order_arc_1424  -13
    arc_2_16_15  in_degree_1587  1
    arc_2_16_15  out_degree_1592  1
    arc_2_16_15  original_T_including_depot_unload_1631  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1423  1
    load_2_16_15  free_load_conservation_1591  -1
    load_2_16_15  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1425  -30
    arc_2_16_17  connected_order_arc_1426  -13
    arc_2_16_17  out_degree_1592  1
    arc_2_16_17  in_degree_1599  1
    arc_2_16_17  original_T_including_depot_unload_1631  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1425  1
    load_2_16_17  free_load_conservation_1597  1
    load_2_16_17  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1427  -30
    arc_2_16_18  connected_order_arc_1428  -13
    arc_2_16_18  out_degree_1592  1
    arc_2_16_18  in_degree_1605  1
    arc_2_16_18  original_T_including_depot_unload_1631  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1427  1
    load_2_16_18  free_load_conservation_1597  1
    load_2_16_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1429  -30
    arc_2_16_19  connected_order_arc_1430  -13
    arc_2_16_19  out_degree_1592  1
    arc_2_16_19  in_degree_1611  1
    arc_2_16_19  original_T_including_depot_unload_1631  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1429  1
    load_2_16_19  free_load_conservation_1597  1
    load_2_16_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1431  -30
    arc_2_16_20  connected_order_arc_1432  -13
    arc_2_16_20  out_degree_1592  1
    arc_2_16_20  in_degree_1617  1
    arc_2_16_20  original_T_including_depot_unload_1631  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1431  1
    load_2_16_20  free_load_conservation_1597  1
    load_2_16_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1433  -30
    arc_2_16_21  connected_order_arc_1434  -13
    arc_2_16_21  out_degree_1592  1
    arc_2_16_21  in_degree_1623  1
    arc_2_16_21  original_T_including_depot_unload_1631  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1433  1
    load_2_16_21  free_load_conservation_1597  1
    load_2_16_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1435  -30
    arc_2_17_0  depot_return_or_bypass_1551  1
    arc_2_17_0  out_degree_1598  1
    arc_2_17_0  original_T_including_depot_unload_1631  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1435  1
    load_2_17_0  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1436  -30
    arc_2_17_10  connected_order_arc_1437  -13
    arc_2_17_10  in_degree_1553  1
    arc_2_17_10  out_degree_1598  1
    arc_2_17_10  original_T_including_depot_unload_1631  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1436  1
    load_2_17_10  segment_load_conservation_1556  -1
    load_2_17_10  segment_prefix_lb_1557  1
    load_2_17_10  segment_prefix_ub_1558  1
    load_2_17_10  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1438  -30
    arc_2_17_11  connected_order_arc_1439  -13
    arc_2_17_11  in_degree_1560  1
    arc_2_17_11  out_degree_1598  1
    arc_2_17_11  original_T_including_depot_unload_1631  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1438  1
    load_2_17_11  segment_load_conservation_1563  -1
    load_2_17_11  segment_prefix_lb_1564  1
    load_2_17_11  segment_prefix_ub_1565  1
    load_2_17_11  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1440  -30
    arc_2_17_12  connected_order_arc_1441  -13
    arc_2_17_12  in_degree_1567  1
    arc_2_17_12  out_degree_1598  1
    arc_2_17_12  original_T_including_depot_unload_1631  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1440  1
    load_2_17_12  segment_load_conservation_1570  -1
    load_2_17_12  segment_prefix_lb_1571  1
    load_2_17_12  segment_prefix_ub_1572  1
    load_2_17_12  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1442  -30
    arc_2_17_13  connected_order_arc_1443  -13
    arc_2_17_13  in_degree_1574  1
    arc_2_17_13  out_degree_1598  1
    arc_2_17_13  original_T_including_depot_unload_1631  8.8580487162181055e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1442  1
    load_2_17_13  segment_load_conservation_1577  -1
    load_2_17_13  segment_prefix_lb_1578  1
    load_2_17_13  segment_prefix_ub_1579  1
    load_2_17_13  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1444  -30
    arc_2_17_14  connected_order_arc_1445  -13
    arc_2_17_14  in_degree_1581  1
    arc_2_17_14  out_degree_1598  1
    arc_2_17_14  original_T_including_depot_unload_1631  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1444  1
    load_2_17_14  free_load_conservation_1585  -1
    load_2_17_14  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1446  -30
    arc_2_17_15  connected_order_arc_1447  -13
    arc_2_17_15  in_degree_1587  1
    arc_2_17_15  out_degree_1598  1
    arc_2_17_15  original_T_including_depot_unload_1631  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1446  1
    load_2_17_15  free_load_conservation_1591  -1
    load_2_17_15  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1448  -30
    arc_2_17_16  connected_order_arc_1449  -13
    arc_2_17_16  in_degree_1593  1
    arc_2_17_16  out_degree_1598  1
    arc_2_17_16  original_T_including_depot_unload_1631  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1448  1
    load_2_17_16  free_load_conservation_1597  -1
    load_2_17_16  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1450  -30
    arc_2_17_18  connected_order_arc_1451  -13
    arc_2_17_18  out_degree_1598  1
    arc_2_17_18  in_degree_1605  1
    arc_2_17_18  original_T_including_depot_unload_1631  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1450  1
    load_2_17_18  free_load_conservation_1603  1
    load_2_17_18  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1452  -30
    arc_2_17_19  connected_order_arc_1453  -13
    arc_2_17_19  out_degree_1598  1
    arc_2_17_19  in_degree_1611  1
    arc_2_17_19  original_T_including_depot_unload_1631  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1452  1
    load_2_17_19  free_load_conservation_1603  1
    load_2_17_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1454  -30
    arc_2_17_20  connected_order_arc_1455  -13
    arc_2_17_20  out_degree_1598  1
    arc_2_17_20  in_degree_1617  1
    arc_2_17_20  original_T_including_depot_unload_1631  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1454  1
    load_2_17_20  free_load_conservation_1603  1
    load_2_17_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1456  -30
    arc_2_17_21  connected_order_arc_1457  -13
    arc_2_17_21  out_degree_1598  1
    arc_2_17_21  in_degree_1623  1
    arc_2_17_21  original_T_including_depot_unload_1631  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1456  1
    load_2_17_21  free_load_conservation_1603  1
    load_2_17_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1458  -30
    arc_2_18_0  depot_return_or_bypass_1551  1
    arc_2_18_0  out_degree_1604  1
    arc_2_18_0  original_T_including_depot_unload_1631  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1458  1
    load_2_18_0  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1459  -30
    arc_2_18_10  connected_order_arc_1460  -13
    arc_2_18_10  in_degree_1553  1
    arc_2_18_10  out_degree_1604  1
    arc_2_18_10  original_T_including_depot_unload_1631  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1459  1
    load_2_18_10  segment_load_conservation_1556  -1
    load_2_18_10  segment_prefix_lb_1557  1
    load_2_18_10  segment_prefix_ub_1558  1
    load_2_18_10  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1461  -30
    arc_2_18_11  connected_order_arc_1462  -13
    arc_2_18_11  in_degree_1560  1
    arc_2_18_11  out_degree_1604  1
    arc_2_18_11  original_T_including_depot_unload_1631  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1461  1
    load_2_18_11  segment_load_conservation_1563  -1
    load_2_18_11  segment_prefix_lb_1564  1
    load_2_18_11  segment_prefix_ub_1565  1
    load_2_18_11  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1463  -30
    arc_2_18_12  connected_order_arc_1464  -13
    arc_2_18_12  in_degree_1567  1
    arc_2_18_12  out_degree_1604  1
    arc_2_18_12  original_T_including_depot_unload_1631  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1463  1
    load_2_18_12  segment_load_conservation_1570  -1
    load_2_18_12  segment_prefix_lb_1571  1
    load_2_18_12  segment_prefix_ub_1572  1
    load_2_18_12  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1465  -30
    arc_2_18_13  connected_order_arc_1466  -13
    arc_2_18_13  in_degree_1574  1
    arc_2_18_13  out_degree_1604  1
    arc_2_18_13  original_T_including_depot_unload_1631  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1465  1
    load_2_18_13  segment_load_conservation_1577  -1
    load_2_18_13  segment_prefix_lb_1578  1
    load_2_18_13  segment_prefix_ub_1579  1
    load_2_18_13  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1467  -30
    arc_2_18_14  connected_order_arc_1468  -13
    arc_2_18_14  in_degree_1581  1
    arc_2_18_14  out_degree_1604  1
    arc_2_18_14  original_T_including_depot_unload_1631  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1467  1
    load_2_18_14  free_load_conservation_1585  -1
    load_2_18_14  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1469  -30
    arc_2_18_15  connected_order_arc_1470  -13
    arc_2_18_15  in_degree_1587  1
    arc_2_18_15  out_degree_1604  1
    arc_2_18_15  original_T_including_depot_unload_1631  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1469  1
    load_2_18_15  free_load_conservation_1591  -1
    load_2_18_15  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1471  -30
    arc_2_18_16  connected_order_arc_1472  -13
    arc_2_18_16  in_degree_1593  1
    arc_2_18_16  out_degree_1604  1
    arc_2_18_16  original_T_including_depot_unload_1631  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1471  1
    load_2_18_16  free_load_conservation_1597  -1
    load_2_18_16  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1473  -30
    arc_2_18_17  connected_order_arc_1474  -13
    arc_2_18_17  in_degree_1599  1
    arc_2_18_17  out_degree_1604  1
    arc_2_18_17  original_T_including_depot_unload_1631  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1473  1
    load_2_18_17  free_load_conservation_1603  -1
    load_2_18_17  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1475  -30
    arc_2_18_19  connected_order_arc_1476  -13
    arc_2_18_19  out_degree_1604  1
    arc_2_18_19  in_degree_1611  1
    arc_2_18_19  original_T_including_depot_unload_1631  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1475  1
    load_2_18_19  free_load_conservation_1609  1
    load_2_18_19  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1477  -30
    arc_2_18_20  connected_order_arc_1478  -13
    arc_2_18_20  out_degree_1604  1
    arc_2_18_20  in_degree_1617  1
    arc_2_18_20  original_T_including_depot_unload_1631  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1477  1
    load_2_18_20  free_load_conservation_1609  1
    load_2_18_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1479  -30
    arc_2_18_21  connected_order_arc_1480  -13
    arc_2_18_21  out_degree_1604  1
    arc_2_18_21  in_degree_1623  1
    arc_2_18_21  original_T_including_depot_unload_1631  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1479  1
    load_2_18_21  free_load_conservation_1609  1
    load_2_18_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1481  -30
    arc_2_19_0  depot_return_or_bypass_1551  1
    arc_2_19_0  out_degree_1610  1
    arc_2_19_0  original_T_including_depot_unload_1631  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1481  1
    load_2_19_0  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1482  -30
    arc_2_19_10  connected_order_arc_1483  -13
    arc_2_19_10  in_degree_1553  1
    arc_2_19_10  out_degree_1610  1
    arc_2_19_10  original_T_including_depot_unload_1631  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1482  1
    load_2_19_10  segment_load_conservation_1556  -1
    load_2_19_10  segment_prefix_lb_1557  1
    load_2_19_10  segment_prefix_ub_1558  1
    load_2_19_10  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1484  -30
    arc_2_19_11  connected_order_arc_1485  -13
    arc_2_19_11  in_degree_1560  1
    arc_2_19_11  out_degree_1610  1
    arc_2_19_11  original_T_including_depot_unload_1631  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1484  1
    load_2_19_11  segment_load_conservation_1563  -1
    load_2_19_11  segment_prefix_lb_1564  1
    load_2_19_11  segment_prefix_ub_1565  1
    load_2_19_11  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1486  -30
    arc_2_19_12  connected_order_arc_1487  -13
    arc_2_19_12  in_degree_1567  1
    arc_2_19_12  out_degree_1610  1
    arc_2_19_12  original_T_including_depot_unload_1631  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1486  1
    load_2_19_12  segment_load_conservation_1570  -1
    load_2_19_12  segment_prefix_lb_1571  1
    load_2_19_12  segment_prefix_ub_1572  1
    load_2_19_12  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1488  -30
    arc_2_19_13  connected_order_arc_1489  -13
    arc_2_19_13  in_degree_1574  1
    arc_2_19_13  out_degree_1610  1
    arc_2_19_13  original_T_including_depot_unload_1631  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1488  1
    load_2_19_13  segment_load_conservation_1577  -1
    load_2_19_13  segment_prefix_lb_1578  1
    load_2_19_13  segment_prefix_ub_1579  1
    load_2_19_13  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1490  -30
    arc_2_19_14  connected_order_arc_1491  -13
    arc_2_19_14  in_degree_1581  1
    arc_2_19_14  out_degree_1610  1
    arc_2_19_14  original_T_including_depot_unload_1631  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1490  1
    load_2_19_14  free_load_conservation_1585  -1
    load_2_19_14  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1492  -30
    arc_2_19_15  connected_order_arc_1493  -13
    arc_2_19_15  in_degree_1587  1
    arc_2_19_15  out_degree_1610  1
    arc_2_19_15  original_T_including_depot_unload_1631  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1492  1
    load_2_19_15  free_load_conservation_1591  -1
    load_2_19_15  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1494  -30
    arc_2_19_16  connected_order_arc_1495  -13
    arc_2_19_16  in_degree_1593  1
    arc_2_19_16  out_degree_1610  1
    arc_2_19_16  original_T_including_depot_unload_1631  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1494  1
    load_2_19_16  free_load_conservation_1597  -1
    load_2_19_16  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1496  -30
    arc_2_19_17  connected_order_arc_1497  -13
    arc_2_19_17  in_degree_1599  1
    arc_2_19_17  out_degree_1610  1
    arc_2_19_17  original_T_including_depot_unload_1631  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1496  1
    load_2_19_17  free_load_conservation_1603  -1
    load_2_19_17  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1498  -30
    arc_2_19_18  connected_order_arc_1499  -13
    arc_2_19_18  in_degree_1605  1
    arc_2_19_18  out_degree_1610  1
    arc_2_19_18  original_T_including_depot_unload_1631  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1498  1
    load_2_19_18  free_load_conservation_1609  -1
    load_2_19_18  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1500  -30
    arc_2_19_20  connected_order_arc_1501  -13
    arc_2_19_20  out_degree_1610  1
    arc_2_19_20  in_degree_1617  1
    arc_2_19_20  original_T_including_depot_unload_1631  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1500  1
    load_2_19_20  free_load_conservation_1615  1
    load_2_19_20  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1502  -30
    arc_2_19_21  connected_order_arc_1503  -13
    arc_2_19_21  out_degree_1610  1
    arc_2_19_21  in_degree_1623  1
    arc_2_19_21  original_T_including_depot_unload_1631  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1502  1
    load_2_19_21  free_load_conservation_1615  1
    load_2_19_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1504  -30
    arc_2_20_0  depot_return_or_bypass_1551  1
    arc_2_20_0  out_degree_1616  1
    arc_2_20_0  original_T_including_depot_unload_1631  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1504  1
    load_2_20_0  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1505  -30
    arc_2_20_10  connected_order_arc_1506  -13
    arc_2_20_10  in_degree_1553  1
    arc_2_20_10  out_degree_1616  1
    arc_2_20_10  original_T_including_depot_unload_1631  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1505  1
    load_2_20_10  segment_load_conservation_1556  -1
    load_2_20_10  segment_prefix_lb_1557  1
    load_2_20_10  segment_prefix_ub_1558  1
    load_2_20_10  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1507  -30
    arc_2_20_11  connected_order_arc_1508  -13
    arc_2_20_11  in_degree_1560  1
    arc_2_20_11  out_degree_1616  1
    arc_2_20_11  original_T_including_depot_unload_1631  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1507  1
    load_2_20_11  segment_load_conservation_1563  -1
    load_2_20_11  segment_prefix_lb_1564  1
    load_2_20_11  segment_prefix_ub_1565  1
    load_2_20_11  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1509  -30
    arc_2_20_12  connected_order_arc_1510  -13
    arc_2_20_12  in_degree_1567  1
    arc_2_20_12  out_degree_1616  1
    arc_2_20_12  original_T_including_depot_unload_1631  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1509  1
    load_2_20_12  segment_load_conservation_1570  -1
    load_2_20_12  segment_prefix_lb_1571  1
    load_2_20_12  segment_prefix_ub_1572  1
    load_2_20_12  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1511  -30
    arc_2_20_13  connected_order_arc_1512  -13
    arc_2_20_13  in_degree_1574  1
    arc_2_20_13  out_degree_1616  1
    arc_2_20_13  original_T_including_depot_unload_1631  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1511  1
    load_2_20_13  segment_load_conservation_1577  -1
    load_2_20_13  segment_prefix_lb_1578  1
    load_2_20_13  segment_prefix_ub_1579  1
    load_2_20_13  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1513  -30
    arc_2_20_14  connected_order_arc_1514  -13
    arc_2_20_14  in_degree_1581  1
    arc_2_20_14  out_degree_1616  1
    arc_2_20_14  original_T_including_depot_unload_1631  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1513  1
    load_2_20_14  free_load_conservation_1585  -1
    load_2_20_14  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1515  -30
    arc_2_20_15  connected_order_arc_1516  -13
    arc_2_20_15  in_degree_1587  1
    arc_2_20_15  out_degree_1616  1
    arc_2_20_15  original_T_including_depot_unload_1631  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1515  1
    load_2_20_15  free_load_conservation_1591  -1
    load_2_20_15  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1517  -30
    arc_2_20_16  connected_order_arc_1518  -13
    arc_2_20_16  in_degree_1593  1
    arc_2_20_16  out_degree_1616  1
    arc_2_20_16  original_T_including_depot_unload_1631  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1517  1
    load_2_20_16  free_load_conservation_1597  -1
    load_2_20_16  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1519  -30
    arc_2_20_17  connected_order_arc_1520  -13
    arc_2_20_17  in_degree_1599  1
    arc_2_20_17  out_degree_1616  1
    arc_2_20_17  original_T_including_depot_unload_1631  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1519  1
    load_2_20_17  free_load_conservation_1603  -1
    load_2_20_17  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1521  -30
    arc_2_20_18  connected_order_arc_1522  -13
    arc_2_20_18  in_degree_1605  1
    arc_2_20_18  out_degree_1616  1
    arc_2_20_18  original_T_including_depot_unload_1631  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1521  1
    load_2_20_18  free_load_conservation_1609  -1
    load_2_20_18  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1523  -30
    arc_2_20_19  connected_order_arc_1524  -13
    arc_2_20_19  in_degree_1611  1
    arc_2_20_19  out_degree_1616  1
    arc_2_20_19  original_T_including_depot_unload_1631  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1523  1
    load_2_20_19  free_load_conservation_1615  -1
    load_2_20_19  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1525  -30
    arc_2_20_21  connected_order_arc_1526  -13
    arc_2_20_21  out_degree_1616  1
    arc_2_20_21  in_degree_1623  1
    arc_2_20_21  original_T_including_depot_unload_1631  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1525  1
    load_2_20_21  free_load_conservation_1621  1
    load_2_20_21  free_load_conservation_1627  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1527  -30
    arc_2_21_0  depot_return_or_bypass_1551  1
    arc_2_21_0  out_degree_1622  1
    arc_2_21_0  original_T_including_depot_unload_1631  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1527  1
    load_2_21_0  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1528  -30
    arc_2_21_10  connected_order_arc_1529  -13
    arc_2_21_10  in_degree_1553  1
    arc_2_21_10  out_degree_1622  1
    arc_2_21_10  original_T_including_depot_unload_1631  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1528  1
    load_2_21_10  segment_load_conservation_1556  -1
    load_2_21_10  segment_prefix_lb_1557  1
    load_2_21_10  segment_prefix_ub_1558  1
    load_2_21_10  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1530  -30
    arc_2_21_11  connected_order_arc_1531  -13
    arc_2_21_11  in_degree_1560  1
    arc_2_21_11  out_degree_1622  1
    arc_2_21_11  original_T_including_depot_unload_1631  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1530  1
    load_2_21_11  segment_load_conservation_1563  -1
    load_2_21_11  segment_prefix_lb_1564  1
    load_2_21_11  segment_prefix_ub_1565  1
    load_2_21_11  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1532  -30
    arc_2_21_12  connected_order_arc_1533  -13
    arc_2_21_12  in_degree_1567  1
    arc_2_21_12  out_degree_1622  1
    arc_2_21_12  original_T_including_depot_unload_1631  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1532  1
    load_2_21_12  segment_load_conservation_1570  -1
    load_2_21_12  segment_prefix_lb_1571  1
    load_2_21_12  segment_prefix_ub_1572  1
    load_2_21_12  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1534  -30
    arc_2_21_13  connected_order_arc_1535  -13
    arc_2_21_13  in_degree_1574  1
    arc_2_21_13  out_degree_1622  1
    arc_2_21_13  original_T_including_depot_unload_1631  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1534  1
    load_2_21_13  segment_load_conservation_1577  -1
    load_2_21_13  segment_prefix_lb_1578  1
    load_2_21_13  segment_prefix_ub_1579  1
    load_2_21_13  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1536  -30
    arc_2_21_14  connected_order_arc_1537  -13
    arc_2_21_14  in_degree_1581  1
    arc_2_21_14  out_degree_1622  1
    arc_2_21_14  original_T_including_depot_unload_1631  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1536  1
    load_2_21_14  free_load_conservation_1585  -1
    load_2_21_14  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1538  -30
    arc_2_21_15  connected_order_arc_1539  -13
    arc_2_21_15  in_degree_1587  1
    arc_2_21_15  out_degree_1622  1
    arc_2_21_15  original_T_including_depot_unload_1631  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1538  1
    load_2_21_15  free_load_conservation_1591  -1
    load_2_21_15  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1540  -30
    arc_2_21_16  connected_order_arc_1541  -13
    arc_2_21_16  in_degree_1593  1
    arc_2_21_16  out_degree_1622  1
    arc_2_21_16  original_T_including_depot_unload_1631  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1540  1
    load_2_21_16  free_load_conservation_1597  -1
    load_2_21_16  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1542  -30
    arc_2_21_17  connected_order_arc_1543  -13
    arc_2_21_17  in_degree_1599  1
    arc_2_21_17  out_degree_1622  1
    arc_2_21_17  original_T_including_depot_unload_1631  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1542  1
    load_2_21_17  free_load_conservation_1603  -1
    load_2_21_17  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1544  -30
    arc_2_21_18  connected_order_arc_1545  -13
    arc_2_21_18  in_degree_1605  1
    arc_2_21_18  out_degree_1622  1
    arc_2_21_18  original_T_including_depot_unload_1631  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1544  1
    load_2_21_18  free_load_conservation_1609  -1
    load_2_21_18  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1546  -30
    arc_2_21_19  connected_order_arc_1547  -13
    arc_2_21_19  in_degree_1611  1
    arc_2_21_19  out_degree_1622  1
    arc_2_21_19  original_T_including_depot_unload_1631  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1546  1
    load_2_21_19  free_load_conservation_1615  -1
    load_2_21_19  free_load_conservation_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1548  -30
    arc_2_21_20  connected_order_arc_1549  -13
    arc_2_21_20  in_degree_1617  1
    arc_2_21_20  out_degree_1622  1
    arc_2_21_20  original_T_including_depot_unload_1631  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1548  1
    load_2_21_20  free_load_conservation_1621  -1
    load_2_21_20  free_load_conservation_1627  1
RHS
    RHS1      OBJ       -0.54525
    RHS1      onehot_5_34  1
    RHS1      onehot_2_69  1
    RHS1      onehot_31_98  1
    RHS1      onehot_1_141  1
    RHS1      onehot_6_166  1
    RHS1      onehot_8_213  1
    RHS1      onehot_32_242  1
    RHS1      onehot_14_277  1
    RHS1      stock_ub_281  40
    RHS1      parent_nonstrict_scope_282  3.7796954911354419e-01
    RHS1      normalization_339  1
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_693  -13
    RHS1      connected_order_arc_695  -13
    RHS1      connected_order_arc_697  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_708  -13
    RHS1      connected_order_arc_710  -13
    RHS1      connected_order_arc_712  -13
    RHS1      connected_order_arc_714  -13
    RHS1      connected_order_arc_716  -13
    RHS1      connected_order_arc_718  -13
    RHS1      connected_order_arc_720  -13
    RHS1      connected_order_arc_722  -13
    RHS1      connected_order_arc_724  -13
    RHS1      connected_order_arc_727  -13
    RHS1      connected_order_arc_729  -13
    RHS1      connected_order_arc_731  -13
    RHS1      connected_order_arc_733  -13
    RHS1      connected_order_arc_735  -13
    RHS1      connected_order_arc_737  -13
    RHS1      connected_order_arc_739  -13
    RHS1      connected_order_arc_741  -13
    RHS1      connected_order_arc_743  -13
    RHS1      connected_order_arc_745  -13
    RHS1      connected_order_arc_747  -13
    RHS1      connected_order_arc_749  -13
    RHS1      connected_order_arc_752  -13
    RHS1      connected_order_arc_754  -13
    RHS1      connected_order_arc_756  -13
    RHS1      connected_order_arc_758  -13
    RHS1      connected_order_arc_760  -13
    RHS1      connected_order_arc_762  -13
    RHS1      connected_order_arc_764  -13
    RHS1      connected_order_arc_766  -13
    RHS1      connected_order_arc_768  -13
    RHS1      connected_order_arc_770  -13
    RHS1      connected_order_arc_772  -13
    RHS1      connected_order_arc_774  -13
    RHS1      connected_order_arc_777  -13
    RHS1      connected_order_arc_779  -13
    RHS1      connected_order_arc_781  -13
    RHS1      connected_order_arc_783  -13
    RHS1      connected_order_arc_785  -13
    RHS1      connected_order_arc_787  -13
    RHS1      connected_order_arc_789  -13
    RHS1      connected_order_arc_791  -13
    RHS1      connected_order_arc_793  -13
    RHS1      connected_order_arc_795  -13
    RHS1      connected_order_arc_797  -13
    RHS1      connected_order_arc_799  -13
    RHS1      depot_departure_or_bypass_800  1
    RHS1      depot_return_or_bypass_801  1
    RHS1      segment_load_conservation_806  4
    RHS1      segment_prefix_ub_808  16
    RHS1      segment_load_conservation_813  7
    RHS1      segment_prefix_lb_814  2
    RHS1      segment_prefix_ub_815  13
    RHS1      segment_load_conservation_820  4
    RHS1      segment_prefix_ub_822  16
    RHS1      segment_load_conservation_827  5
    RHS1      segment_prefix_ub_829  15
    RHS1      segment_load_conservation_834  -13
    RHS1      segment_prefix_lb_835  13
    RHS1      segment_prefix_ub_836  20
    RHS1      fixed_segment_relative_order_885  1
    RHS1      fixed_segment_relative_order_886  1
    RHS1      fixed_segment_relative_order_887  1
    RHS1      fixed_segment_relative_order_888  1
    RHS1      original_T_including_depot_unload_889  3.3747892440461683e+03
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1135  -12
    RHS1      connected_order_arc_1137  -12
    RHS1      connected_order_arc_1139  -12
    RHS1      connected_order_arc_1141  -12
    RHS1      connected_order_arc_1143  -12
    RHS1      connected_order_arc_1145  -12
    RHS1      connected_order_arc_1147  -12
    RHS1      connected_order_arc_1149  -12
    RHS1      connected_order_arc_1151  -12
    RHS1      connected_order_arc_1153  -12
    RHS1      connected_order_arc_1155  -12
    RHS1      connected_order_arc_1158  -12
    RHS1      connected_order_arc_1160  -12
    RHS1      connected_order_arc_1162  -12
    RHS1      connected_order_arc_1164  -12
    RHS1      connected_order_arc_1166  -12
    RHS1      connected_order_arc_1168  -12
    RHS1      connected_order_arc_1170  -12
    RHS1      connected_order_arc_1172  -12
    RHS1      connected_order_arc_1174  -12
    RHS1      connected_order_arc_1176  -12
    RHS1      connected_order_arc_1178  -12
    RHS1      depot_departure_or_bypass_1179  1
    RHS1      depot_return_or_bypass_1180  1
    RHS1      segment_load_conservation_1185  6
    RHS1      segment_prefix_ub_1187  19
    RHS1      segment_load_conservation_1192  -4
    RHS1      segment_prefix_lb_1193  4
    RHS1      segment_prefix_ub_1194  25
    RHS1      segment_load_conservation_1199  4
    RHS1      segment_prefix_lb_1200  2
    RHS1      segment_prefix_ub_1201  21
    RHS1      segment_load_conservation_1206  -6
    RHS1      segment_prefix_lb_1207  6
    RHS1      segment_prefix_ub_1208  25
    RHS1      fixed_segment_relative_order_1257  1
    RHS1      fixed_segment_relative_order_1258  1
    RHS1      fixed_segment_relative_order_1259  1
    RHS1      original_T_including_depot_unload_1260  2.2736280646580772e+03
    RHS1      connected_order_arc_1276  -12
    RHS1      connected_order_arc_1278  -12
    RHS1      connected_order_arc_1280  -12
    RHS1      connected_order_arc_1282  -12
    RHS1      connected_order_arc_1284  -12
    RHS1      connected_order_arc_1286  -12
    RHS1      connected_order_arc_1288  -12
    RHS1      connected_order_arc_1290  -12
    RHS1      connected_order_arc_1292  -12
    RHS1      connected_order_arc_1294  -12
    RHS1      connected_order_arc_1296  -12
    RHS1      connected_order_arc_1299  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1305  -12
    RHS1      connected_order_arc_1307  -12
    RHS1      connected_order_arc_1309  -12
    RHS1      connected_order_arc_1311  -12
    RHS1      connected_order_arc_1313  -12
    RHS1      connected_order_arc_1315  -12
    RHS1      connected_order_arc_1317  -12
    RHS1      connected_order_arc_1319  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1328  -12
    RHS1      connected_order_arc_1330  -12
    RHS1      connected_order_arc_1332  -12
    RHS1      connected_order_arc_1334  -12
    RHS1      connected_order_arc_1336  -12
    RHS1      connected_order_arc_1338  -12
    RHS1      connected_order_arc_1340  -12
    RHS1      connected_order_arc_1342  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1351  -12
    RHS1      connected_order_arc_1353  -12
    RHS1      connected_order_arc_1355  -12
    RHS1      connected_order_arc_1357  -12
    RHS1      connected_order_arc_1359  -12
    RHS1      connected_order_arc_1361  -12
    RHS1      connected_order_arc_1363  -12
    RHS1      connected_order_arc_1365  -12
    RHS1      connected_order_arc_1368  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1374  -12
    RHS1      connected_order_arc_1376  -12
    RHS1      connected_order_arc_1378  -12
    RHS1      connected_order_arc_1380  -12
    RHS1      connected_order_arc_1382  -12
    RHS1      connected_order_arc_1384  -12
    RHS1      connected_order_arc_1386  -12
    RHS1      connected_order_arc_1388  -12
    RHS1      connected_order_arc_1391  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1397  -12
    RHS1      connected_order_arc_1399  -12
    RHS1      connected_order_arc_1401  -12
    RHS1      connected_order_arc_1403  -12
    RHS1      connected_order_arc_1405  -12
    RHS1      connected_order_arc_1407  -12
    RHS1      connected_order_arc_1409  -12
    RHS1      connected_order_arc_1411  -12
    RHS1      connected_order_arc_1414  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1420  -12
    RHS1      connected_order_arc_1422  -12
    RHS1      connected_order_arc_1424  -12
    RHS1      connected_order_arc_1426  -12
    RHS1      connected_order_arc_1428  -12
    RHS1      connected_order_arc_1430  -12
    RHS1      connected_order_arc_1432  -12
    RHS1      connected_order_arc_1434  -12
    RHS1      connected_order_arc_1437  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1443  -12
    RHS1      connected_order_arc_1445  -12
    RHS1      connected_order_arc_1447  -12
    RHS1      connected_order_arc_1449  -12
    RHS1      connected_order_arc_1451  -12
    RHS1      connected_order_arc_1453  -12
    RHS1      connected_order_arc_1455  -12
    RHS1      connected_order_arc_1457  -12
    RHS1      connected_order_arc_1460  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1466  -12
    RHS1      connected_order_arc_1468  -12
    RHS1      connected_order_arc_1470  -12
    RHS1      connected_order_arc_1472  -12
    RHS1      connected_order_arc_1474  -12
    RHS1      connected_order_arc_1476  -12
    RHS1      connected_order_arc_1478  -12
    RHS1      connected_order_arc_1480  -12
    RHS1      connected_order_arc_1483  -12
    RHS1      connected_order_arc_1485  -12
    RHS1      connected_order_arc_1487  -12
    RHS1      connected_order_arc_1489  -12
    RHS1      connected_order_arc_1491  -12
    RHS1      connected_order_arc_1493  -12
    RHS1      connected_order_arc_1495  -12
    RHS1      connected_order_arc_1497  -12
    RHS1      connected_order_arc_1499  -12
    RHS1      connected_order_arc_1501  -12
    RHS1      connected_order_arc_1503  -12
    RHS1      connected_order_arc_1506  -12
    RHS1      connected_order_arc_1508  -12
    RHS1      connected_order_arc_1510  -12
    RHS1      connected_order_arc_1512  -12
    RHS1      connected_order_arc_1514  -12
    RHS1      connected_order_arc_1516  -12
    RHS1      connected_order_arc_1518  -12
    RHS1      connected_order_arc_1520  -12
    RHS1      connected_order_arc_1522  -12
    RHS1      connected_order_arc_1524  -12
    RHS1      connected_order_arc_1526  -12
    RHS1      connected_order_arc_1529  -12
    RHS1      connected_order_arc_1531  -12
    RHS1      connected_order_arc_1533  -12
    RHS1      connected_order_arc_1535  -12
    RHS1      connected_order_arc_1537  -12
    RHS1      connected_order_arc_1539  -12
    RHS1      connected_order_arc_1541  -12
    RHS1      connected_order_arc_1543  -12
    RHS1      connected_order_arc_1545  -12
    RHS1      connected_order_arc_1547  -12
    RHS1      connected_order_arc_1549  -12
    RHS1      depot_departure_or_bypass_1550  1
    RHS1      depot_return_or_bypass_1551  1
    RHS1      segment_load_conservation_1556  2
    RHS1      segment_prefix_ub_1558  28
    RHS1      segment_load_conservation_1563  3
    RHS1      segment_prefix_ub_1565  27
    RHS1      segment_load_conservation_1570  -1
    RHS1      segment_prefix_lb_1571  1
    RHS1      segment_prefix_ub_1572  30
    RHS1      segment_load_conservation_1577  5
    RHS1      segment_prefix_ub_1579  25
    RHS1      fixed_segment_relative_order_1628  1
    RHS1      fixed_segment_relative_order_1629  1
    RHS1      fixed_segment_relative_order_1630  1
    RHS1      original_T_including_depot_unload_1631  5512.18965781578
BOUNDS
 LO BND1      t         2.4822695035436170e-02
 UP BND1      t         4.1401744787857471e-02
 UP BND1      q         5.4596954911354423e-01
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.1401744787857471e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.1401744787857471e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.1401744787857471e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.1401744787857471e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.1401744787857471e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.1401744787857471e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.1401744787857471e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.1401744787857471e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.1401744787857471e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.1401744787857471e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.1401744787857471e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.1401744787857471e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.1401744787857471e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.1401744787857471e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.1401744787857471e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.1401744787857471e-02
 BV BND1      x_5_16  
 UP BND1      w_5_16    4.1401744787857471e-02
 UP BND1      rho_5     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.1401744787857471e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.1401744787857471e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.1401744787857471e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.1401744787857471e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.1401744787857471e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.1401744787857471e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.1401744787857471e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.1401744787857471e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.1401744787857471e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.1401744787857471e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.1401744787857471e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.1401744787857471e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.1401744787857471e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.1401744787857471e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.1401744787857471e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.1401744787857471e-02
 UP BND1      rho_2     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1401744787857471e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1401744787857471e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1401744787857471e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1401744787857471e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1401744787857471e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1401744787857471e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1401744787857471e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1401744787857471e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1401744787857471e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1401744787857471e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1401744787857471e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1401744787857471e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1401744787857471e-02
 UP BND1      rho_31    1
 BV BND1      x_1_0   
 UP BND1      w_1_0     4.1401744787857471e-02
 BV BND1      x_1_1   
 UP BND1      w_1_1     4.1401744787857471e-02
 BV BND1      x_1_2   
 UP BND1      w_1_2     4.1401744787857471e-02
 BV BND1      x_1_3   
 UP BND1      w_1_3     4.1401744787857471e-02
 BV BND1      x_1_4   
 UP BND1      w_1_4     4.1401744787857471e-02
 BV BND1      x_1_5   
 UP BND1      w_1_5     4.1401744787857471e-02
 BV BND1      x_1_6   
 UP BND1      w_1_6     4.1401744787857471e-02
 BV BND1      x_1_7   
 UP BND1      w_1_7     4.1401744787857471e-02
 BV BND1      x_1_8   
 UP BND1      w_1_8     4.1401744787857471e-02
 BV BND1      x_1_9   
 UP BND1      w_1_9     4.1401744787857471e-02
 BV BND1      x_1_10  
 UP BND1      w_1_10    4.1401744787857471e-02
 BV BND1      x_1_11  
 UP BND1      w_1_11    4.1401744787857471e-02
 BV BND1      x_1_12  
 UP BND1      w_1_12    4.1401744787857471e-02
 BV BND1      x_1_13  
 UP BND1      w_1_13    4.1401744787857471e-02
 BV BND1      x_1_14  
 UP BND1      w_1_14    4.1401744787857471e-02
 BV BND1      x_1_15  
 UP BND1      w_1_15    4.1401744787857471e-02
 BV BND1      x_1_16  
 UP BND1      w_1_16    4.1401744787857471e-02
 BV BND1      x_1_17  
 UP BND1      w_1_17    4.1401744787857471e-02
 BV BND1      x_1_18  
 UP BND1      w_1_18    4.1401744787857471e-02
 BV BND1      x_1_19  
 UP BND1      w_1_19    4.1401744787857471e-02
 UP BND1      rho_1     1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.1401744787857471e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.1401744787857471e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.1401744787857471e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.1401744787857471e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.1401744787857471e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.1401744787857471e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.1401744787857471e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.1401744787857471e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.1401744787857471e-02
 BV BND1      x_6_9   
 UP BND1      w_6_9     4.1401744787857471e-02
 BV BND1      x_6_10  
 UP BND1      w_6_10    4.1401744787857471e-02
 UP BND1      rho_6     1
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.1401744787857471e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.1401744787857471e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.1401744787857471e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.1401744787857471e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.1401744787857471e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.1401744787857471e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.1401744787857471e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.1401744787857471e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.1401744787857471e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.1401744787857471e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.1401744787857471e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.1401744787857471e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.1401744787857471e-02
 BV BND1      x_8_13  
 UP BND1      w_8_13    4.1401744787857471e-02
 BV BND1      x_8_14  
 UP BND1      w_8_14    4.1401744787857471e-02
 BV BND1      x_8_15  
 UP BND1      w_8_15    4.1401744787857471e-02
 BV BND1      x_8_16  
 UP BND1      w_8_16    4.1401744787857471e-02
 BV BND1      x_8_17  
 UP BND1      w_8_17    4.1401744787857471e-02
 BV BND1      x_8_18  
 UP BND1      w_8_18    4.1401744787857471e-02
 BV BND1      x_8_19  
 UP BND1      w_8_19    4.1401744787857471e-02
 BV BND1      x_8_20  
 UP BND1      w_8_20    4.1401744787857471e-02
 BV BND1      x_8_21  
 UP BND1      w_8_21    4.1401744787857471e-02
 UP BND1      rho_8     1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1401744787857471e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1401744787857471e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1401744787857471e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1401744787857471e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1401744787857471e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1401744787857471e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1401744787857471e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1401744787857471e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1401744787857471e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1401744787857471e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1401744787857471e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1401744787857471e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1401744787857471e-02
 UP BND1      rho_32    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    4.1401744787857471e-02
 BV BND1      x_14_1  
 UP BND1      w_14_1    4.1401744787857471e-02
 BV BND1      x_14_2  
 UP BND1      w_14_2    4.1401744787857471e-02
 BV BND1      x_14_3  
 UP BND1      w_14_3    4.1401744787857471e-02
 BV BND1      x_14_4  
 UP BND1      w_14_4    4.1401744787857471e-02
 BV BND1      x_14_5  
 UP BND1      w_14_5    4.1401744787857471e-02
 BV BND1      x_14_6  
 UP BND1      w_14_6    4.1401744787857471e-02
 BV BND1      x_14_7  
 UP BND1      w_14_7    4.1401744787857471e-02
 BV BND1      x_14_8  
 UP BND1      w_14_8    4.1401744787857471e-02
 BV BND1      x_14_9  
 UP BND1      w_14_9    4.1401744787857471e-02
 BV BND1      x_14_10 
 UP BND1      w_14_10   4.1401744787857471e-02
 BV BND1      x_14_11 
 UP BND1      w_14_11   4.1401744787857471e-02
 BV BND1      x_14_12 
 UP BND1      w_14_12   4.1401744787857471e-02
 BV BND1      x_14_13 
 UP BND1      w_14_13   4.1401744787857471e-02
 BV BND1      x_14_14 
 UP BND1      w_14_14   4.1401744787857471e-02
 BV BND1      x_14_15 
 UP BND1      w_14_15   4.1401744787857471e-02
 UP BND1      rho_14    1
 UP BND1      a_5_2     1
 UP BND1      a_5_31    1
 UP BND1      a_5_1     1
 UP BND1      a_5_6     1
 UP BND1      a_5_8     1
 UP BND1      a_5_32    1
 UP BND1      a_5_14    1
 UP BND1      a_2_31    1
 UP BND1      a_2_1     1
 UP BND1      a_2_6     1
 UP BND1      a_2_8     1
 UP BND1      a_2_32    1
 UP BND1      a_2_14    1
 UP BND1      a_31_1    1
 UP BND1      a_31_6    1
 UP BND1      a_31_8    1
 UP BND1      a_31_32   1
 UP BND1      a_31_14   1
 UP BND1      a_1_6     1
 UP BND1      a_1_8     1
 UP BND1      a_1_32    1
 UP BND1      a_1_14    1
 UP BND1      a_6_8     1
 UP BND1      a_6_32    1
 UP BND1      a_6_14    1
 UP BND1      a_8_32    1
 UP BND1      a_8_14    1
 UP BND1      a_32_14   1
 BV BND1      service_0_5_0
 BV BND1      service_0_5_1
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_0_5_16
 BV BND1      service_1_5_0
 BV BND1      service_1_5_1
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_1_5_16
 BV BND1      service_2_5_0
 BV BND1      service_2_5_1
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_2_5_16
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_0_1_16
 BV BND1      service_0_1_17
 BV BND1      service_0_1_18
 BV BND1      service_0_1_19
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_1_1_16
 BV BND1      service_1_1_17
 BV BND1      service_1_1_18
 BV BND1      service_1_1_19
 BV BND1      service_2_1_0
 BV BND1      service_2_1_1
 BV BND1      service_2_1_3
 BV BND1      service_2_1_4
 BV BND1      service_2_1_5
 BV BND1      service_2_1_6
 BV BND1      service_2_1_7
 BV BND1      service_2_1_8
 BV BND1      service_2_1_9
 BV BND1      service_2_1_10
 BV BND1      service_2_1_11
 BV BND1      service_2_1_12
 BV BND1      service_2_1_13
 BV BND1      service_2_1_14
 BV BND1      service_2_1_15
 BV BND1      service_2_1_16
 BV BND1      service_2_1_17
 BV BND1      service_2_1_18
 BV BND1      service_2_1_19
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_9
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_0_8_13
 BV BND1      service_0_8_14
 BV BND1      service_0_8_16
 BV BND1      service_0_8_17
 BV BND1      service_0_8_18
 BV BND1      service_0_8_19
 BV BND1      service_0_8_20
 BV BND1      service_0_8_21
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_9
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_1_8_13
 BV BND1      service_1_8_14
 BV BND1      service_1_8_16
 BV BND1      service_1_8_17
 BV BND1      service_1_8_18
 BV BND1      service_1_8_19
 BV BND1      service_1_8_20
 BV BND1      service_1_8_21
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_9
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 BV BND1      service_2_8_13
 BV BND1      service_2_8_14
 BV BND1      service_2_8_16
 BV BND1      service_2_8_17
 BV BND1      service_2_8_18
 BV BND1      service_2_8_19
 BV BND1      service_2_8_20
 BV BND1      service_2_8_21
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_11
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_11
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_2_14_9
 BV BND1      service_2_14_10
 BV BND1      service_2_14_11
 BV BND1      service_2_14_12
 BV BND1      service_2_14_13
 BV BND1      service_2_14_14
 BV BND1      service_2_14_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
