* Signature: 0x704b4ee7f218b2fc
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  R2      
 L  R3      
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  R8      
 L  R9      
 G  R10     
 L  R11     
 G  R12     
 L  R13     
 G  R14     
 L  R15     
 G  R16     
 L  R17     
 G  R18     
 L  R19     
 G  R20     
 L  R21     
 G  R22     
 L  R23     
 G  R24     
 L  R25     
 G  R26     
 L  R27     
 G  R28     
 L  R29     
 G  R30     
 L  R31     
 G  R32     
 L  R33     
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 G  R38     
 L  R39     
 G  R40     
 L  R41     
 G  R42     
 L  R43     
 G  R44     
 L  R45     
 G  R46     
 L  R47     
 G  R48     
 L  R49     
 G  R50     
 L  R51     
 G  R52     
 L  R53     
 G  R54     
 L  R55     
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  R60     
 L  R61     
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  R66     
 L  R67     
 G  R68     
 L  R69     
 G  R70     
 L  R71     
 G  R72     
 L  R73     
 G  R74     
 L  R75     
 G  R76     
 L  R77     
 G  R78     
 L  R79     
 G  R80     
 L  R81     
 G  R82     
 L  R83     
 G  R84     
 L  R85     
 G  R86     
 L  R87     
 G  R88     
 L  R89     
 G  R90     
 L  R91     
 G  R92     
 L  R93     
 G  R94     
 L  R95     
 G  R96     
 L  R97     
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  R102    
 L  R103    
 G  R104    
 L  R105    
 G  R106    
 L  R107    
 G  R108    
 L  R109    
 G  R110    
 L  R111    
 G  R112    
 L  R113    
 G  R114    
 L  R115    
 G  R116    
 L  R117    
 G  R118    
 L  R119    
 G  R120    
 L  R121    
 G  R122    
 L  R123    
 G  R124    
 L  R125    
 G  R126    
 L  R127    
 G  R128    
 L  R129    
 G  R130    
 L  R131    
 G  R132    
 L  R133    
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  R138    
 L  R139    
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  R144    
 L  R145    
 G  R146    
 L  R147    
 G  R148    
 L  R149    
 G  R150    
 L  R151    
 G  R152    
 L  R153    
 G  R154    
 L  R155    
 G  R156    
 L  R157    
 G  R158    
 L  R159    
 G  R160    
 L  R161    
 G  R162    
 L  R163    
 G  R164    
 L  R165    
 G  R166    
 L  R167    
 G  R168    
 L  R169    
 G  R170    
 L  R171    
 G  R172    
 L  R173    
 G  R174    
 L  R175    
 G  R176    
 L  R177    
 G  R178    
 L  R179    
 G  R180    
 L  R181    
 G  R182    
 L  R183    
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  R188    
 L  R189    
 G  R190    
 L  R191    
 G  R192    
 L  R193    
 G  R194    
 L  R195    
 G  R196    
 L  R197    
 G  R198    
 L  R199    
 G  R200    
 L  R201    
 G  R202    
 L  R203    
 G  R204    
 L  R205    
 G  R206    
 L  R207    
 G  R208    
 L  R209    
 G  R210    
 L  R211    
 G  R212    
 L  R213    
 G  R214    
 L  R215    
 G  R216    
 L  R217    
 G  R218    
 L  R219    
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  R224    
 L  R225    
 G  R226    
 L  R227    
 G  R228    
 L  R229    
 G  R230    
 L  R231    
 G  R232    
 L  R233    
 G  R234    
 L  R235    
 G  R236    
 L  R237    
 G  R238    
 L  R239    
 G  R240    
 L  R241    
 G  R242    
 L  R243    
 G  R244    
 L  R245    
 G  R246    
 L  R247    
 G  R248    
 L  R249    
 G  R250    
 L  R251    
 G  R252    
 L  R253    
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  R258    
 L  R259    
 G  R260    
 L  R261    
 G  R262    
 L  R263    
 G  R264    
 L  R265    
 G  R266    
 L  R267    
 G  R268    
 L  R269    
 G  R270    
 L  R271    
 G  R272    
 L  R273    
 G  R274    
 L  R275    
 G  R276    
 L  R277    
 G  R278    
 L  R279    
 G  R280    
 L  R281    
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  R286    
 L  R287    
 G  R288    
 L  R289    
 G  R290    
 L  R291    
 G  R292    
 L  R293    
 G  R294    
 L  R295    
 G  R296    
 L  R297    
 G  R298    
 L  R299    
 G  R300    
 L  R301    
 G  R302    
 L  R303    
 G  R304    
 L  R305    
 G  R306    
 L  R307    
 G  R308    
 L  R309    
 G  R310    
 L  R311    
 G  R312    
 L  R313    
 G  R314    
 L  R315    
 G  R316    
 L  R317    
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  R322    
 L  R323    
 G  R324    
 L  R325    
 G  R326    
 L  R327    
 G  R328    
 L  R329    
 G  R330    
 L  R331    
 G  R332    
 L  R333    
 G  R334    
 L  R335    
 G  R336    
 L  R337    
 G  R338    
 L  R339    
 G  R340    
 L  R341    
 G  R342    
 L  R343    
 G  R344    
 L  R345    
 G  R346    
 L  R347    
 G  R348    
 L  R349    
 G  R350    
 L  R351    
 G  R352    
 L  R353    
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  R358    
 L  R359    
 G  R360    
 L  R361    
 G  R362    
 L  R363    
 G  R364    
 L  R365    
 G  R366    
 L  R367    
 G  R368    
 L  R369    
 G  R370    
 L  R371    
 G  R372    
 L  R373    
 G  R374    
 L  R375    
 G  R376    
 L  R377    
 G  R378    
 L  R379    
 G  R380    
 L  R381    
 G  R382    
 L  R383    
 G  R384    
 L  R385    
 G  R386    
 L  R387    
 G  R388    
 L  R389    
 G  R390    
 L  R391    
 G  R392    
 L  R393    
 G  R394    
 L  R395    
 G  R396    
 L  R397    
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  R402    
 L  R403    
 G  R404    
 L  R405    
 G  R406    
 L  R407    
 G  R408    
 L  R409    
 G  R410    
 L  R411    
 G  R412    
 L  R413    
 G  R414    
 L  R415    
 G  R416    
 L  R417    
 G  R418    
 L  R419    
 G  R420    
 L  R421    
 G  R422    
 L  R423    
 G  R424    
 L  R425    
 G  R426    
 L  R427    
 G  R428    
 L  R429    
 G  R430    
 L  R431    
 G  R432    
 L  R433    
 G  R434    
 L  R435    
 G  R436    
 L  R437    
 G  R438    
 L  R439    
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  R444    
 L  R445    
 G  R446    
 L  R447    
 G  R448    
 L  R449    
 G  R450    
 L  R451    
 G  R452    
 L  R453    
 G  R454    
 L  R455    
 G  R456    
 L  R457    
 G  R458    
 L  R459    
 G  R460    
 L  R461    
 G  R462    
 L  R463    
 G  R464    
 L  R465    
 G  R466    
 L  R467    
 G  R468    
 L  R469    
 G  R470    
 L  R471    
 G  R472    
 L  R473    
 G  R474    
 L  R475    
 G  R476    
 L  R477    
 G  R478    
 L  R479    
 G  R480    
 L  R481    
 G  R482    
 L  R483    
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  R488    
 L  R489    
 G  R490    
 L  R491    
 G  R492    
 L  R493    
 G  R494    
 L  R495    
 G  R496    
 L  R497    
 G  R498    
 L  R499    
 G  R500    
 L  R501    
 G  R502    
 L  R503    
 G  R504    
 L  R505    
 G  R506    
 L  R507    
 G  R508    
 L  R509    
 G  R510    
 L  R511    
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  R516    
 L  R517    
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  R522    
 L  R523    
 G  R524    
 L  R525    
 G  R526    
 L  R527    
 G  R528    
 L  R529    
 G  R530    
 L  R531    
 G  R532    
 L  R533    
 G  R534    
 L  R535    
 G  R536    
 L  R537    
 G  R538    
 L  R539    
 G  R540    
 L  R541    
 G  R542    
 L  R543    
 G  R544    
 L  R545    
 G  R546    
 L  R547    
 G  R548    
 L  R549    
 G  R550    
 L  R551    
 G  R552    
 L  R553    
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  R558    
 L  R559    
 G  R560    
 L  R561    
 G  R562    
 L  R563    
 G  R564    
 L  R565    
 G  R566    
 L  R567    
 G  R568    
 L  R569    
 G  R570    
 L  R571    
 G  R572    
 L  R573    
 G  R574    
 L  R575    
 G  R576    
 L  R577    
 G  R578    
 L  R579    
 G  R580    
 L  R581    
 G  R582    
 L  R583    
 G  R584    
 L  R585    
 G  R586    
 L  R587    
 G  R588    
 L  R589    
 G  R590    
 L  R591    
 G  R592    
 L  R593    
 G  R594    
 L  R595    
 G  R596    
 L  R597    
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  R602    
 L  R603    
 G  R604    
 L  R605    
 G  R606    
 L  R607    
 G  R608    
 L  R609    
 G  R610    
 L  R611    
 G  R612    
 L  R613    
 G  R614    
 L  R615    
 G  R616    
 L  R617    
 G  R618    
 L  R619    
 G  R620    
 L  R621    
 G  R622    
 L  R623    
 G  R624    
 L  R625    
 G  R626    
 L  R627    
 G  R628    
 L  R629    
 G  R630    
 L  R631    
 G  R632    
 L  R633    
 E  normalized_inventory_20
 E  normalized_ratio_20
 E  onehot_21
 E  mass_21 
 G  R638    
 L  R639    
 G  R640    
 L  R641    
 G  R642    
 L  R643    
 G  R644    
 L  R645    
 G  R646    
 L  R647    
 G  R648    
 L  R649    
 G  R650    
 L  R651    
 G  R652    
 L  R653    
 G  R654    
 L  R655    
 G  R656    
 L  R657    
 G  R658    
 L  R659    
 G  R660    
 L  R661    
 G  R662    
 L  R663    
 G  R664    
 L  R665    
 G  R666    
 L  R667    
 G  R668    
 L  R669    
 G  R670    
 L  R671    
 G  R672    
 L  R673    
 G  R674    
 L  R675    
 G  R676    
 L  R677    
 E  normalized_inventory_21
 E  normalized_ratio_21
 E  onehot_22
 E  mass_22 
 G  R682    
 L  R683    
 G  R684    
 L  R685    
 G  R686    
 L  R687    
 G  R688    
 L  R689    
 G  R690    
 L  R691    
 G  R692    
 L  R693    
 G  R694    
 L  R695    
 G  R696    
 L  R697    
 G  R698    
 L  R699    
 G  R700    
 L  R701    
 G  R702    
 L  R703    
 G  R704    
 L  R705    
 G  R706    
 L  R707    
 G  R708    
 L  R709    
 G  R710    
 L  R711    
 G  R712    
 L  R713    
 G  R714    
 L  R715    
 G  R716    
 L  R717    
 G  R718    
 L  R719    
 G  R720    
 L  R721    
 E  normalized_inventory_22
 E  normalized_ratio_22
 E  onehot_23
 E  mass_23 
 G  R726    
 L  R727    
 G  R728    
 L  R729    
 G  R730    
 L  R731    
 G  R732    
 L  R733    
 G  R734    
 L  R735    
 G  R736    
 L  R737    
 G  R738    
 L  R739    
 G  R740    
 L  R741    
 G  R742    
 L  R743    
 G  R744    
 L  R745    
 G  R746    
 L  R747    
 G  R748    
 L  R749    
 G  R750    
 L  R751    
 G  R752    
 L  R753    
 G  R754    
 L  R755    
 G  R756    
 L  R757    
 E  normalized_inventory_23
 E  normalized_ratio_23
 E  onehot_24
 E  mass_24 
 G  R762    
 L  R763    
 G  R764    
 L  R765    
 G  R766    
 L  R767    
 G  R768    
 L  R769    
 G  R770    
 L  R771    
 G  R772    
 L  R773    
 G  R774    
 L  R775    
 G  R776    
 L  R777    
 G  R778    
 L  R779    
 E  normalized_inventory_24
 E  normalized_ratio_24
 E  onehot_25
 E  mass_25 
 G  R784    
 L  R785    
 G  R786    
 L  R787    
 G  R788    
 L  R789    
 G  R790    
 L  R791    
 G  R792    
 L  R793    
 G  R794    
 L  R795    
 G  R796    
 L  R797    
 G  R798    
 L  R799    
 G  R800    
 L  R801    
 G  R802    
 L  R803    
 G  R804    
 L  R805    
 G  R806    
 L  R807    
 G  R808    
 L  R809    
 G  R810    
 L  R811    
 G  R812    
 L  R813    
 G  R814    
 L  R815    
 E  normalized_inventory_25
 E  normalized_ratio_25
 E  onehot_26
 E  mass_26 
 G  R820    
 L  R821    
 G  R822    
 L  R823    
 G  R824    
 L  R825    
 G  R826    
 L  R827    
 G  R828    
 L  R829    
 G  R830    
 L  R831    
 G  R832    
 L  R833    
 G  R834    
 L  R835    
 G  R836    
 L  R837    
 G  R838    
 L  R839    
 G  R840    
 L  R841    
 G  R842    
 L  R843    
 G  R844    
 L  R845    
 G  R846    
 L  R847    
 G  R848    
 L  R849    
 G  R850    
 L  R851    
 E  normalized_inventory_26
 E  normalized_ratio_26
 E  onehot_27
 E  mass_27 
 G  R856    
 L  R857    
 G  R858    
 L  R859    
 G  R860    
 L  R861    
 G  R862    
 L  R863    
 G  R864    
 L  R865    
 G  R866    
 L  R867    
 G  R868    
 L  R869    
 G  R870    
 L  R871    
 G  R872    
 L  R873    
 G  R874    
 L  R875    
 G  R876    
 L  R877    
 G  R878    
 L  R879    
 G  R880    
 L  R881    
 G  R882    
 L  R883    
 G  R884    
 L  R885    
 G  R886    
 L  R887    
 G  R888    
 L  R889    
 G  R890    
 L  R891    
 G  R892    
 L  R893    
 G  R894    
 L  R895    
 E  normalized_inventory_27
 E  normalized_ratio_27
 E  onehot_28
 E  mass_28 
 G  R900    
 L  R901    
 G  R902    
 L  R903    
 G  R904    
 L  R905    
 G  R906    
 L  R907    
 G  R908    
 L  R909    
 G  R910    
 L  R911    
 G  R912    
 L  R913    
 G  R914    
 L  R915    
 G  R916    
 L  R917    
 G  R918    
 L  R919    
 G  R920    
 L  R921    
 G  R922    
 L  R923    
 G  R924    
 L  R925    
 G  R926    
 L  R927    
 G  R928    
 L  R929    
 G  R930    
 L  R931    
 E  normalized_inventory_28
 E  normalized_ratio_28
 E  onehot_29
 E  mass_29 
 G  R936    
 L  R937    
 G  R938    
 L  R939    
 G  R940    
 L  R941    
 G  R942    
 L  R943    
 G  R944    
 L  R945    
 G  R946    
 L  R947    
 G  R948    
 L  R949    
 G  R950    
 L  R951    
 G  R952    
 L  R953    
 G  R954    
 L  R955    
 G  R956    
 L  R957    
 G  R958    
 L  R959    
 G  R960    
 L  R961    
 G  R962    
 L  R963    
 G  R964    
 L  R965    
 G  R966    
 L  R967    
 E  normalized_inventory_29
 E  normalized_ratio_29
 E  onehot_30
 E  mass_30 
 G  R972    
 L  R973    
 G  R974    
 L  R975    
 G  R976    
 L  R977    
 G  R978    
 L  R979    
 G  R980    
 L  R981    
 G  R982    
 L  R983    
 G  R984    
 L  R985    
 G  R986    
 L  R987    
 G  R988    
 L  R989    
 G  R990    
 L  R991    
 G  R992    
 L  R993    
 G  R994    
 L  R995    
 G  R996    
 L  R997    
 G  R998    
 L  R999    
 G  R1000   
 L  R1001   
 G  R1002   
 L  R1003   
 G  R1004   
 L  R1005   
 G  R1006   
 L  R1007   
 G  R1008   
 L  R1009   
 G  R1010   
 L  R1011   
 G  R1012   
 L  R1013   
 E  normalized_inventory_30
 E  normalized_ratio_30
 E  onehot_31
 E  mass_31 
 G  R1018   
 L  R1019   
 G  R1020   
 L  R1021   
 G  R1022   
 L  R1023   
 G  R1024   
 L  R1025   
 G  R1026   
 L  R1027   
 G  R1028   
 L  R1029   
 G  R1030   
 L  R1031   
 G  R1032   
 L  R1033   
 G  R1034   
 L  R1035   
 G  R1036   
 L  R1037   
 G  R1038   
 L  R1039   
 G  R1040   
 L  R1041   
 G  R1042   
 L  R1043   
 G  R1044   
 L  R1045   
 G  R1046   
 L  R1047   
 G  R1048   
 L  R1049   
 E  normalized_inventory_31
 E  normalized_ratio_31
 E  onehot_32
 E  mass_32 
 G  R1054   
 L  R1055   
 G  R1056   
 L  R1057   
 G  R1058   
 L  R1059   
 G  R1060   
 L  R1061   
 G  R1062   
 L  R1063   
 G  R1064   
 L  R1065   
 G  R1066   
 L  R1067   
 G  R1068   
 L  R1069   
 G  R1070   
 L  R1071   
 G  R1072   
 L  R1073   
 G  R1074   
 L  R1075   
 G  R1076   
 L  R1077   
 G  R1078   
 L  R1079   
 G  R1080   
 L  R1081   
 G  R1082   
 L  R1083   
 G  R1084   
 L  R1085   
 E  normalized_inventory_32
 E  normalized_ratio_32
 E  onehot_33
 E  mass_33 
 G  R1090   
 L  R1091   
 G  R1092   
 L  R1093   
 G  R1094   
 L  R1095   
 G  R1096   
 L  R1097   
 G  R1098   
 L  R1099   
 G  R1100   
 L  R1101   
 G  R1102   
 L  R1103   
 G  R1104   
 L  R1105   
 G  R1106   
 L  R1107   
 G  R1108   
 L  R1109   
 G  R1110   
 L  R1111   
 G  R1112   
 L  R1113   
 G  R1114   
 L  R1115   
 G  R1116   
 L  R1117   
 G  R1118   
 L  R1119   
 G  R1120   
 L  R1121   
 G  R1122   
 L  R1123   
 G  R1124   
 L  R1125   
 G  R1126   
 L  R1127   
 G  R1128   
 L  R1129   
 G  R1130   
 L  R1131   
 G  R1132   
 L  R1133   
 G  R1134   
 L  R1135   
 G  R1136   
 L  R1137   
 G  R1138   
 L  R1139   
 E  normalized_inventory_33
 E  normalized_ratio_33
 E  onehot_34
 E  mass_34 
 G  R1144   
 L  R1145   
 G  R1146   
 L  R1147   
 G  R1148   
 L  R1149   
 G  R1150   
 L  R1151   
 G  R1152   
 L  R1153   
 G  R1154   
 L  R1155   
 G  R1156   
 L  R1157   
 G  R1158   
 L  R1159   
 G  R1160   
 L  R1161   
 G  R1162   
 L  R1163   
 G  R1164   
 L  R1165   
 G  R1166   
 L  R1167   
 G  R1168   
 L  R1169   
 G  R1170   
 L  R1171   
 G  R1172   
 L  R1173   
 G  R1174   
 L  R1175   
 E  normalized_inventory_34
 E  normalized_ratio_34
 E  onehot_35
 E  mass_35 
 G  R1180   
 L  R1181   
 G  R1182   
 L  R1183   
 G  R1184   
 L  R1185   
 G  R1186   
 L  R1187   
 G  R1188   
 L  R1189   
 G  R1190   
 L  R1191   
 G  R1192   
 L  R1193   
 G  R1194   
 L  R1195   
 G  R1196   
 L  R1197   
 G  R1198   
 L  R1199   
 G  R1200   
 L  R1201   
 G  R1202   
 L  R1203   
 G  R1204   
 L  R1205   
 G  R1206   
 L  R1207   
 G  R1208   
 L  R1209   
 G  R1210   
 L  R1211   
 G  R1212   
 L  R1213   
 G  R1214   
 L  R1215   
 E  normalized_inventory_35
 E  normalized_ratio_35
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  R1223   
 G  R1224   
 G  R1225   
 G  R1226   
 G  R1227   
 G  R1228   
 G  R1229   
 G  R1230   
 G  R1231   
 G  R1232   
 G  R1233   
 G  R1234   
 G  R1235   
 G  R1236   
 G  R1237   
 G  R1238   
 G  R1239   
 G  R1240   
 G  R1241   
 G  R1242   
 G  R1243   
 G  R1244   
 G  R1245   
 G  R1246   
 G  R1247   
 G  R1248   
 G  R1249   
 G  R1250   
 G  R1251   
 G  R1252   
 G  R1253   
 G  R1254   
 G  R1255   
 G  R1256   
 G  R1257   
 G  R1258   
 G  R1259   
 G  R1260   
 G  R1261   
 G  R1262   
 G  R1263   
 G  R1264   
 G  R1265   
 G  R1266   
 G  R1267   
 G  R1268   
 G  R1269   
 G  R1270   
 G  R1271   
 G  R1272   
 G  R1273   
 G  R1274   
 G  R1275   
 G  R1276   
 G  R1277   
 G  R1278   
 G  R1279   
 G  R1280   
 G  R1281   
 G  R1282   
 G  R1283   
 G  R1284   
 G  R1285   
 G  R1286   
 G  R1287   
 G  R1288   
 G  R1289   
 G  R1290   
 G  R1291   
 G  R1292   
 G  R1293   
 G  R1294   
 G  R1295   
 G  R1296   
 G  R1297   
 G  R1298   
 G  R1299   
 G  R1300   
 G  R1301   
 G  R1302   
 G  R1303   
 G  R1304   
 G  R1305   
 G  R1306   
 G  R1307   
 G  R1308   
 G  R1309   
 G  R1310   
 G  R1311   
 G  R1312   
 G  R1313   
 G  R1314   
 G  R1315   
 G  R1316   
 G  R1317   
 G  R1318   
 G  R1319   
 G  R1320   
 G  R1321   
 G  R1322   
 G  R1323   
 G  R1324   
 G  R1325   
 G  R1326   
 G  R1327   
 G  R1328   
 G  R1329   
 G  R1330   
 G  R1331   
 G  R1332   
 G  R1333   
 G  R1334   
 G  R1335   
 G  R1336   
 G  R1337   
 G  R1338   
 G  R1339   
 G  R1340   
 G  R1341   
 G  R1342   
 G  R1343   
 G  R1344   
 G  R1345   
 G  R1346   
 G  R1347   
 G  R1348   
 G  R1349   
 G  R1350   
 G  R1351   
 G  R1352   
 G  R1353   
 G  R1354   
 G  R1355   
 G  R1356   
 G  R1357   
 G  R1358   
 G  R1359   
 G  R1360   
 G  R1361   
 G  R1362   
 G  R1363   
 G  R1364   
 G  R1365   
 G  R1366   
 G  R1367   
 G  R1368   
 G  R1369   
 G  R1370   
 G  R1371   
 G  R1372   
 G  R1373   
 G  R1374   
 G  R1375   
 G  R1376   
 G  R1377   
 G  R1378   
 G  R1379   
 G  R1380   
 G  R1381   
 G  R1382   
 G  R1383   
 G  R1384   
 G  R1385   
 G  R1386   
 G  R1387   
 G  R1388   
 G  R1389   
 G  R1390   
 G  R1391   
 G  R1392   
 G  R1393   
 G  R1394   
 G  R1395   
 G  R1396   
 G  R1397   
 G  R1398   
 G  R1399   
 G  R1400   
 G  R1401   
 G  R1402   
 G  R1403   
 G  R1404   
 G  R1405   
 G  R1406   
 G  R1407   
 G  R1408   
 G  R1409   
 G  R1410   
 G  R1411   
 G  R1412   
 G  R1413   
 G  R1414   
 G  R1415   
 G  R1416   
 G  R1417   
 G  R1418   
 G  R1419   
 G  R1420   
 G  R1421   
 G  R1422   
 G  R1423   
 G  R1424   
 G  R1425   
 G  R1426   
 G  R1427   
 G  R1428   
 G  R1429   
 G  R1430   
 G  R1431   
 G  R1432   
 G  R1433   
 G  R1434   
 G  R1435   
 G  R1436   
 G  R1437   
 G  R1438   
 G  R1439   
 G  R1440   
 G  R1441   
 G  R1442   
 G  R1443   
 G  R1444   
 G  R1445   
 G  R1446   
 G  R1447   
 G  R1448   
 G  R1449   
 G  R1450   
 G  R1451   
 G  R1452   
 G  R1453   
 G  R1454   
 G  R1455   
 G  R1456   
 G  R1457   
 G  R1458   
 G  R1459   
 G  R1460   
 G  R1461   
 G  R1462   
 G  R1463   
 G  R1464   
 G  R1465   
 G  R1466   
 G  R1467   
 G  R1468   
 G  R1469   
 G  R1470   
 G  R1471   
 G  R1472   
 G  R1473   
 G  R1474   
 G  R1475   
 G  R1476   
 G  R1477   
 G  R1478   
 G  R1479   
 G  R1480   
 G  R1481   
 G  R1482   
 G  R1483   
 G  R1484   
 G  R1485   
 G  R1486   
 G  R1487   
 G  R1488   
 G  R1489   
 G  R1490   
 G  R1491   
 G  R1492   
 G  R1493   
 G  R1494   
 G  R1495   
 G  R1496   
 G  R1497   
 G  R1498   
 G  R1499   
 G  R1500   
 G  R1501   
 G  R1502   
 G  R1503   
 G  R1504   
 G  R1505   
 G  R1506   
 G  R1507   
 G  R1508   
 G  R1509   
 G  R1510   
 G  R1511   
 G  R1512   
 G  R1513   
 G  R1514   
 G  R1515   
 G  R1516   
 G  R1517   
 G  R1518   
 G  R1519   
 G  R1520   
 G  R1521   
 G  R1522   
 G  R1523   
 G  R1524   
 G  R1525   
 G  R1526   
 G  R1527   
 G  R1528   
 G  R1529   
 G  R1530   
 G  R1531   
 G  R1532   
 G  R1533   
 G  R1534   
 G  R1535   
 G  R1536   
 G  R1537   
 G  R1538   
 G  R1539   
 G  R1540   
 G  R1541   
 G  R1542   
 G  R1543   
 G  R1544   
 G  R1545   
 G  R1546   
 G  R1547   
 G  R1548   
 G  R1549   
 G  R1550   
 G  R1551   
 G  R1552   
 G  R1553   
 G  R1554   
 G  R1555   
 G  R1556   
 G  R1557   
 G  R1558   
 G  R1559   
 G  R1560   
 G  R1561   
 G  R1562   
 G  R1563   
 G  R1564   
 G  R1565   
 G  R1566   
 G  R1567   
 G  R1568   
 G  R1569   
 G  R1570   
 G  R1571   
 G  R1572   
 G  R1573   
 G  R1574   
 G  R1575   
 G  R1576   
 G  R1577   
 G  R1578   
 G  R1579   
 G  R1580   
 G  R1581   
 G  R1582   
 G  R1583   
 G  R1584   
 G  R1585   
 G  R1586   
 G  R1587   
 G  R1588   
 G  R1589   
 G  R1590   
 G  R1591   
 G  R1592   
 G  R1593   
 G  R1594   
 G  R1595   
 G  R1596   
 G  R1597   
 G  R1598   
 G  R1599   
 G  R1600   
 G  R1601   
 G  R1602   
 G  R1603   
 G  R1604   
 G  R1605   
 G  R1606   
 G  R1607   
 G  R1608   
 G  R1609   
 G  R1610   
 G  R1611   
 G  R1612   
 G  R1613   
 G  R1614   
 G  R1615   
 G  R1616   
 G  R1617   
 G  R1618   
 G  R1619   
 G  R1620   
 G  R1621   
 G  R1622   
 G  R1623   
 G  R1624   
 G  R1625   
 G  R1626   
 G  R1627   
 G  R1628   
 G  R1629   
 G  R1630   
 G  R1631   
 G  R1632   
 G  R1633   
 G  R1634   
 G  R1635   
 G  R1636   
 G  R1637   
 G  R1638   
 G  R1639   
 G  R1640   
 G  R1641   
 G  R1642   
 G  R1643   
 G  R1644   
 G  R1645   
 G  R1646   
 G  R1647   
 G  R1648   
 G  R1649   
 G  R1650   
 G  R1651   
 G  R1652   
 G  R1653   
 G  R1654   
 G  R1655   
 G  R1656   
 G  R1657   
 G  R1658   
 G  R1659   
 G  R1660   
 G  R1661   
 G  R1662   
 G  R1663   
 G  R1664   
 G  R1665   
 G  R1666   
 G  R1667   
 G  R1668   
 G  R1669   
 G  R1670   
 G  R1671   
 G  R1672   
 G  R1673   
 G  R1674   
 G  R1675   
 G  R1676   
 G  R1677   
 G  R1678   
 G  R1679   
 G  R1680   
 G  R1681   
 G  R1682   
 G  R1683   
 G  R1684   
 G  R1685   
 G  R1686   
 G  R1687   
 G  R1688   
 G  R1689   
 G  R1690   
 G  R1691   
 G  R1692   
 G  R1693   
 G  R1694   
 G  R1695   
 G  R1696   
 G  R1697   
 G  R1698   
 G  R1699   
 G  R1700   
 G  R1701   
 G  R1702   
 G  R1703   
 G  R1704   
 G  R1705   
 G  R1706   
 G  R1707   
 G  R1708   
 G  R1709   
 G  R1710   
 G  R1711   
 G  R1712   
 G  R1713   
 G  R1714   
 G  R1715   
 G  R1716   
 G  R1717   
 G  R1718   
 G  R1719   
 G  R1720   
 G  R1721   
 G  R1722   
 G  R1723   
 G  R1724   
 G  R1725   
 G  R1726   
 G  R1727   
 G  R1728   
 G  R1729   
 G  R1730   
 G  R1731   
 G  R1732   
 G  R1733   
 G  R1734   
 G  R1735   
 G  R1736   
 G  R1737   
 G  R1738   
 G  R1739   
 G  R1740   
 G  R1741   
 G  R1742   
 G  R1743   
 G  R1744   
 G  R1745   
 G  R1746   
 G  R1747   
 G  R1748   
 G  R1749   
 G  R1750   
 G  R1751   
 G  R1752   
 G  R1753   
 G  R1754   
 G  R1755   
 G  R1756   
 G  R1757   
 G  R1758   
 G  R1759   
 G  R1760   
 G  R1761   
 G  R1762   
 G  R1763   
 G  R1764   
 G  R1765   
 G  R1766   
 G  R1767   
 G  R1768   
 G  R1769   
 G  R1770   
 G  R1771   
 G  R1772   
 G  R1773   
 G  R1774   
 G  R1775   
 G  R1776   
 G  R1777   
 G  R1778   
 G  R1779   
 G  R1780   
 G  R1781   
 G  R1782   
 G  R1783   
 G  R1784   
 G  R1785   
 G  R1786   
 G  R1787   
 G  R1788   
 G  R1789   
 G  R1790   
 G  R1791   
 G  R1792   
 G  R1793   
 G  R1794   
 G  R1795   
 G  R1796   
 G  R1797   
 G  R1798   
 G  R1799   
 G  R1800   
 G  R1801   
 G  R1802   
 G  R1803   
 G  R1804   
 G  R1805   
 G  R1806   
 G  R1807   
 G  R1808   
 G  R1809   
 G  R1810   
 G  R1811   
 G  R1812   
 G  R1813   
 G  R1814   
 G  R1815   
 G  R1816   
 G  R1817   
 G  R1818   
 G  R1819   
 G  R1820   
 G  R1821   
 G  R1822   
 G  R1823   
 G  R1824   
 G  R1825   
 G  R1826   
 G  R1827   
 G  R1828   
 G  R1829   
 G  R1830   
 G  R1831   
 G  R1832   
 G  R1833   
 G  R1834   
 G  R1835   
 G  R1836   
 G  R1837   
 G  R1838   
 G  R1839   
 G  R1840   
 G  R1841   
 G  R1842   
 G  R1843   
 G  R1844   
 G  R1845   
 G  R1846   
 G  R1847   
 G  R1848   
 G  R1849   
 G  R1850   
 G  R1851   
 G  R1852   
 G  R1853   
 G  R1854   
 G  R1855   
 G  R1856   
 G  R1857   
 G  R1858   
 G  R1859   
 G  R1860   
 G  R1861   
 G  R1862   
 G  R1863   
 G  R1864   
 G  R1865   
 G  R1866   
 G  R1867   
 G  R1868   
 G  R1869   
 G  R1870   
 G  R1871   
 G  R1872   
 G  R1873   
 G  R1874   
 G  R1875   
 G  R1876   
 G  R1877   
 G  R1878   
 G  R1879   
 G  R1880   
 G  R1881   
 G  R1882   
 G  R1883   
 G  R1884   
 G  R1885   
 G  R1886   
 G  R1887   
 G  R1888   
 G  R1889   
 G  R1890   
 G  R1891   
 G  R1892   
 G  R1893   
 G  R1894   
 G  R1895   
 G  R1896   
 G  R1897   
 G  R1898   
 G  R1899   
 G  R1900   
 G  R1901   
 G  R1902   
 G  R1903   
 G  R1904   
 G  R1905   
 G  R1906   
 G  R1907   
 G  R1908   
 G  R1909   
 G  R1910   
 G  R1911   
 G  R1912   
 G  R1913   
 G  R1914   
 G  R1915   
 G  R1916   
 G  R1917   
 G  R1918   
 G  R1919   
 G  R1920   
 G  R1921   
 G  R1922   
 G  R1923   
 G  R1924   
 G  R1925   
 G  R1926   
 G  R1927   
 G  R1928   
 G  R1929   
 G  R1930   
 G  R1931   
 G  R1932   
 G  R1933   
 G  R1934   
 G  R1935   
 G  R1936   
 G  R1937   
 G  R1938   
 G  R1939   
 G  R1940   
 G  R1941   
 G  R1942   
 G  R1943   
 G  R1944   
 G  R1945   
 G  R1946   
 G  R1947   
 G  R1948   
 G  R1949   
 G  R1950   
 G  R1951   
 G  R1952   
 G  R1953   
 G  R1954   
 G  R1955   
 G  R1956   
 G  R1957   
 G  R1958   
 G  R1959   
 G  R1960   
 G  R1961   
 G  R1962   
 G  R1963   
 G  R1964   
 G  R1965   
 G  R1966   
 G  R1967   
 G  R1968   
 G  R1969   
 G  R1970   
 G  R1971   
 G  R1972   
 G  R1973   
 G  R1974   
 G  R1975   
 G  R1976   
 G  R1977   
 G  R1978   
 G  R1979   
 G  R1980   
 G  R1981   
 G  R1982   
 G  R1983   
 G  R1984   
 G  R1985   
 G  R1986   
 G  R1987   
 G  R1988   
 G  R1989   
 G  R1990   
 G  R1991   
 G  R1992   
 G  R1993   
 G  R1994   
 G  R1995   
 G  R1996   
 G  R1997   
 G  R1998   
 G  R1999   
 G  R2000   
 G  R2001   
 G  R2002   
 G  R2003   
 G  R2004   
 G  R2005   
 G  R2006   
 G  R2007   
 G  R2008   
 G  R2009   
 G  R2010   
 G  R2011   
 G  R2012   
 G  R2013   
 G  R2014   
 G  R2015   
 G  R2016   
 G  R2017   
 G  R2018   
 G  R2019   
 G  R2020   
 G  R2021   
 G  R2022   
 G  R2023   
 G  R2024   
 G  R2025   
 G  R2026   
 G  R2027   
 G  R2028   
 G  R2029   
 G  R2030   
 G  R2031   
 G  R2032   
 G  R2033   
 G  R2034   
 G  R2035   
 G  R2036   
 G  R2037   
 G  R2038   
 G  R2039   
 G  R2040   
 G  R2041   
 G  R2042   
 G  R2043   
 G  R2044   
 G  R2045   
 G  R2046   
 G  R2047   
 G  R2048   
 G  R2049   
 G  R2050   
 G  R2051   
 G  R2052   
 G  R2053   
 G  R2054   
 G  R2055   
 G  R2056   
 G  R2057   
 G  R2058   
 G  R2059   
 G  R2060   
 G  R2061   
 G  R2062   
 G  R2063   
 G  R2064   
 G  R2065   
 G  R2066   
 G  R2067   
 G  R2068   
 G  R2069   
 G  R2070   
 G  R2071   
 G  R2072   
 G  R2073   
 G  R2074   
 G  R2075   
 G  R2076   
 G  R2077   
 G  R2078   
 G  R2079   
 G  R2080   
 G  R2081   
 G  R2082   
 G  R2083   
 G  R2084   
 G  R2085   
 G  R2086   
 G  R2087   
 G  R2088   
 G  R2089   
 G  R2090   
 G  R2091   
 G  R2092   
 G  R2093   
 G  R2094   
 G  R2095   
 G  R2096   
 G  R2097   
 G  R2098   
 G  R2099   
 G  R2100   
 G  R2101   
 G  R2102   
 G  R2103   
 G  R2104   
 G  R2105   
 G  R2106   
 G  R2107   
 G  R2108   
 G  R2109   
 G  R2110   
 G  R2111   
 G  R2112   
 G  R2113   
 G  R2114   
 G  R2115   
 G  R2116   
 G  R2117   
 G  R2118   
 G  R2119   
 G  R2120   
 G  R2121   
 G  R2122   
 G  R2123   
 G  R2124   
 G  R2125   
 G  R2126   
 G  R2127   
 G  R2128   
 G  R2129   
 G  R2130   
 G  R2131   
 G  R2132   
 G  R2133   
 G  R2134   
 G  R2135   
 G  R2136   
 G  R2137   
 G  R2138   
 G  R2139   
 G  R2140   
 G  R2141   
 G  R2142   
 G  R2143   
 G  R2144   
 G  R2145   
 G  R2146   
 G  R2147   
 G  R2148   
 G  R2149   
 G  R2150   
 G  R2151   
 G  R2152   
 G  R2153   
 G  R2154   
 G  R2155   
 G  R2156   
 G  R2157   
 G  R2158   
 G  R2159   
 G  R2160   
 G  R2161   
 G  R2162   
 G  R2163   
 G  R2164   
 G  R2165   
 G  R2166   
 G  R2167   
 G  R2168   
 G  R2169   
 G  R2170   
 G  R2171   
 G  R2172   
 G  R2173   
 G  R2174   
 G  R2175   
 G  R2176   
 G  R2177   
 G  R2178   
 G  R2179   
 G  R2180   
 G  R2181   
 G  R2182   
 G  R2183   
 G  R2184   
 G  R2185   
 G  R2186   
 G  R2187   
 G  R2188   
 G  R2189   
 G  R2190   
 G  R2191   
 G  R2192   
 G  R2193   
 G  R2194   
 G  R2195   
 G  R2196   
 G  R2197   
 G  R2198   
 G  R2199   
 G  R2200   
 G  R2201   
 G  R2202   
 G  R2203   
 G  R2204   
 G  R2205   
 G  R2206   
 G  R2207   
 G  R2208   
 G  R2209   
 G  R2210   
 G  R2211   
 G  R2212   
 G  R2213   
 G  R2214   
 G  R2215   
 G  R2216   
 G  R2217   
 G  R2218   
 G  R2219   
 G  R2220   
 G  R2221   
 G  R2222   
 G  R2223   
 G  R2224   
 G  R2225   
 G  R2226   
 G  R2227   
 G  R2228   
 G  R2229   
 G  R2230   
 G  R2231   
 G  R2232   
 G  R2233   
 G  R2234   
 G  R2235   
 G  R2236   
 G  R2237   
 G  R2238   
 G  R2239   
 G  R2240   
 G  R2241   
 G  R2242   
 G  R2243   
 G  R2244   
 G  R2245   
 G  R2246   
 G  R2247   
 G  R2248   
 G  R2249   
 G  R2250   
 G  R2251   
 G  R2252   
 G  R2253   
 G  R2254   
 G  R2255   
 G  R2256   
 G  R2257   
 G  R2258   
 G  R2259   
 G  R2260   
 G  R2261   
 G  R2262   
 G  R2263   
 G  R2264   
 G  R2265   
 G  R2266   
 G  R2267   
 G  R2268   
 G  R2269   
 G  R2270   
 G  R2271   
 G  R2272   
 G  R2273   
 G  R2274   
 G  R2275   
 G  R2276   
 G  R2277   
 G  R2278   
 G  R2279   
 G  R2280   
 G  R2281   
 G  R2282   
 G  R2283   
 G  R2284   
 G  R2285   
 G  R2286   
 G  R2287   
 G  R2288   
 G  R2289   
 G  R2290   
 G  R2291   
 G  R2292   
 G  R2293   
 G  R2294   
 G  R2295   
 G  R2296   
 G  R2297   
 G  R2298   
 G  R2299   
 G  R2300   
 G  R2301   
 G  R2302   
 G  R2303   
 G  R2304   
 G  R2305   
 G  R2306   
 G  R2307   
 G  R2308   
 G  R2309   
 G  R2310   
 G  R2311   
 G  R2312   
 G  R2313   
 G  R2314   
 G  R2315   
 G  R2316   
 G  R2317   
 G  R2318   
 G  R2319   
 G  R2320   
 G  R2321   
 G  R2322   
 G  R2323   
 G  R2324   
 G  R2325   
 G  R2326   
 G  R2327   
 G  R2328   
 G  R2329   
 G  R2330   
 G  R2331   
 G  R2332   
 G  R2333   
 G  R2334   
 G  R2335   
 G  R2336   
 G  R2337   
 G  R2338   
 G  R2339   
 G  R2340   
 G  R2341   
 G  R2342   
 G  R2343   
 G  R2344   
 G  R2345   
 G  R2346   
 G  R2347   
 G  R2348   
 G  R2349   
 G  R2350   
 G  R2351   
 G  R2352   
 G  R2353   
 G  R2354   
 G  R2355   
 G  R2356   
 G  R2357   
 G  R2358   
 G  R2359   
 G  R2360   
 G  R2361   
 G  R2362   
 G  R2363   
 G  R2364   
 G  R2365   
 G  R2366   
 G  R2367   
 G  R2368   
 G  R2369   
 G  R2370   
 G  R2371   
 G  R2372   
 G  R2373   
 G  R2374   
 G  R2375   
 G  R2376   
 G  R2377   
 G  R2378   
 G  R2379   
 G  R2380   
 G  R2381   
 G  R2382   
 G  R2383   
 G  R2384   
 G  R2385   
 G  R2386   
 G  R2387   
 G  R2388   
 G  R2389   
 G  R2390   
 G  R2391   
 G  R2392   
 G  R2393   
 G  R2394   
 G  R2395   
 G  R2396   
 G  R2397   
 G  R2398   
 G  R2399   
 G  R2400   
 G  R2401   
 G  R2402   
 G  R2403   
 G  R2404   
 G  R2405   
 G  R2406   
 G  R2407   
 G  R2408   
 G  R2409   
 G  R2410   
 G  R2411   
 G  R2412   
 L  true_G_epigraph
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,4]    OBJ       2.8402349999999996e-02
    x[1,4]    onehot_1  1
    x[1,4]    R2        -2.2258731252318614e-02
    x[1,4]    R3        -3.9535535354550462e-02
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[2,0]    OBJ       5.0000000000000017e-02
    x[2,0]    onehot_2  1
    x[2,0]    R8        -2.2258731252318614e-02
    x[2,0]    R9        -3.9535535354550462e-02
    x[2,1]    OBJ       5.0000000000000010e-02
    x[2,1]    onehot_2  1
    x[2,1]    R10       -2.2258731252318614e-02
    x[2,1]    R11       -3.9535535354550462e-02
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,2]    OBJ       0.05
    x[2,2]    onehot_2  1
    x[2,2]    R12       -2.2258731252318614e-02
    x[2,2]    R13       -3.9535535354550462e-02
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,3]    OBJ       0.05
    x[2,3]    onehot_2  1
    x[2,3]    R14       -2.2258731252318614e-02
    x[2,3]    R15       -3.9535535354550462e-02
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,4]    OBJ       0.05
    x[2,4]    onehot_2  1
    x[2,4]    R16       -2.2258731252318614e-02
    x[2,4]    R17       -3.9535535354550462e-02
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[2,5]    OBJ       5.0000000000000010e-02
    x[2,5]    onehot_2  1
    x[2,5]    R18       -2.2258731252318614e-02
    x[2,5]    R19       -3.9535535354550462e-02
    x[2,5]    hard_lower  5
    x[2,5]    hard_upper  5
    x[2,6]    OBJ       5.0000000000000010e-02
    x[2,6]    onehot_2  1
    x[2,6]    R20       -2.2258731252318614e-02
    x[2,6]    R21       -3.9535535354550462e-02
    x[2,6]    hard_lower  6
    x[2,6]    hard_upper  6
    x[2,7]    OBJ       5.0000000000000010e-02
    x[2,7]    onehot_2  1
    x[2,7]    R22       -2.2258731252318614e-02
    x[2,7]    R23       -3.9535535354550462e-02
    x[2,7]    hard_lower  7
    x[2,7]    hard_upper  7
    x[2,8]    OBJ       5.0000000000000010e-02
    x[2,8]    onehot_2  1
    x[2,8]    R24       -2.2258731252318614e-02
    x[2,8]    R25       -3.9535535354550462e-02
    x[2,8]    hard_lower  8
    x[2,8]    hard_upper  8
    x[2,9]    OBJ       0.05
    x[2,9]    onehot_2  1
    x[2,9]    R26       -2.2258731252318614e-02
    x[2,9]    R27       -3.9535535354550462e-02
    x[2,9]    hard_lower  9
    x[2,9]    hard_upper  9
    x[2,10]   OBJ       5.0000000000000010e-02
    x[2,10]   onehot_2  1
    x[2,10]   R28       -2.2258731252318614e-02
    x[2,10]   R29       -3.9535535354550462e-02
    x[2,10]   hard_lower  10
    x[2,10]   hard_upper  10
    x[2,11]   OBJ       5.0000000000000010e-02
    x[2,11]   onehot_2  1
    x[2,11]   R30       -2.2258731252318614e-02
    x[2,11]   R31       -3.9535535354550462e-02
    x[2,11]   hard_lower  11
    x[2,11]   hard_upper  11
    x[2,12]   OBJ       7.0949163211153631e-18
    x[2,12]   onehot_2  1
    x[2,12]   R32       -2.2258731252318614e-02
    x[2,12]   R33       -3.9535535354550462e-02
    x[2,12]   hard_lower  12
    x[2,12]   hard_upper  12
    x[2,13]   OBJ       5.0000000000000010e-02
    x[2,13]   onehot_2  1
    x[2,13]   R34       -2.2258731252318614e-02
    x[2,13]   R35       -3.9535535354550462e-02
    x[2,13]   hard_lower  13
    x[2,13]   hard_upper  13
    x[2,14]   OBJ       0.05
    x[2,14]   onehot_2  1
    x[2,14]   R36       -2.2258731252318614e-02
    x[2,14]   R37       -3.9535535354550462e-02
    x[2,14]   hard_lower  14
    x[2,14]   hard_upper  14
    x[2,15]   OBJ       0.05
    x[2,15]   onehot_2  1
    x[2,15]   R38       -2.2258731252318614e-02
    x[2,15]   R39       -3.9535535354550462e-02
    x[2,15]   hard_lower  15
    x[2,15]   hard_upper  15
    x[2,16]   OBJ       0.05
    x[2,16]   onehot_2  1
    x[2,16]   R40       -2.2258731252318614e-02
    x[2,16]   R41       -3.9535535354550462e-02
    x[2,16]   hard_lower  16
    x[2,16]   hard_upper  16
    x[2,17]   OBJ       5.0000000000000010e-02
    x[2,17]   onehot_2  1
    x[2,17]   R42       -2.2258731252318614e-02
    x[2,17]   R43       -3.9535535354550462e-02
    x[2,17]   hard_lower  17
    x[2,17]   hard_upper  17
    x[2,18]   OBJ       5.0000000000000010e-02
    x[2,18]   onehot_2  1
    x[2,18]   R44       -2.2258731252318614e-02
    x[2,18]   R45       -3.9535535354550462e-02
    x[2,18]   hard_lower  18
    x[2,18]   hard_upper  18
    x[2,19]   OBJ       5.0000000000000010e-02
    x[2,19]   onehot_2  1
    x[2,19]   R46       -2.2258731252318614e-02
    x[2,19]   R47       -3.9535535354550462e-02
    x[2,19]   hard_lower  19
    x[2,19]   hard_upper  19
    x[2,20]   OBJ       5.0000000000000010e-02
    x[2,20]   onehot_2  1
    x[2,20]   R48       -2.2258731252318614e-02
    x[2,20]   R49       -3.9535535354550462e-02
    x[2,20]   hard_lower  20
    x[2,20]   hard_upper  20
    x[2,21]   OBJ       0.05
    x[2,21]   onehot_2  1
    x[2,21]   R50       -2.2258731252318614e-02
    x[2,21]   R51       -3.9535535354550462e-02
    x[2,21]   hard_lower  21
    x[2,21]   hard_upper  21
    x[2,22]   OBJ       0.05
    x[2,22]   onehot_2  1
    x[2,22]   R52       -2.2258731252318614e-02
    x[2,22]   R53       -3.9535535354550462e-02
    x[2,22]   hard_lower  22
    x[2,22]   hard_upper  22
    x[2,23]   OBJ       5.0000000000000010e-02
    x[2,23]   onehot_2  1
    x[2,23]   R54       -2.2258731252318614e-02
    x[2,23]   R55       -3.9535535354550462e-02
    x[2,23]   hard_lower  23
    x[2,23]   hard_upper  23
    x[3,13]   OBJ       3.7278128571428565e-02
    x[3,13]   onehot_3  1
    x[3,13]   R60       -2.2258731252318614e-02
    x[3,13]   R61       -3.9535535354550462e-02
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[4,0]    OBJ       0.05
    x[4,0]    onehot_4  1
    x[4,0]    R66       -2.2258731252318614e-02
    x[4,0]    R67       -3.9535535354550462e-02
    x[4,1]    OBJ       0.05
    x[4,1]    onehot_4  1
    x[4,1]    R68       -2.2258731252318614e-02
    x[4,1]    R69       -3.9535535354550462e-02
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,2]    OBJ       0.05
    x[4,2]    onehot_4  1
    x[4,2]    R70       -2.2258731252318614e-02
    x[4,2]    R71       -3.9535535354550462e-02
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,3]    OBJ       0.05
    x[4,3]    onehot_4  1
    x[4,3]    R72       -2.2258731252318614e-02
    x[4,3]    R73       -3.9535535354550462e-02
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,4]    OBJ       0.05
    x[4,4]    onehot_4  1
    x[4,4]    R74       -2.2258731252318614e-02
    x[4,4]    R75       -3.9535535354550462e-02
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,5]    OBJ       0.05
    x[4,5]    onehot_4  1
    x[4,5]    R76       -2.2258731252318614e-02
    x[4,5]    R77       -3.9535535354550462e-02
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,6]    OBJ       0.05
    x[4,6]    onehot_4  1
    x[4,6]    R78       -2.2258731252318614e-02
    x[4,6]    R79       -3.9535535354550462e-02
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,7]    OBJ       2.4142438048713188e-18
    x[4,7]    onehot_4  1
    x[4,7]    R80       -2.2258731252318614e-02
    x[4,7]    R81       -3.9535535354550462e-02
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,8]    OBJ       4.9999999999999996e-02
    x[4,8]    onehot_4  1
    x[4,8]    R82       -2.2258731252318614e-02
    x[4,8]    R83       -3.9535535354550462e-02
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,9]    OBJ       4.9999999999999996e-02
    x[4,9]    onehot_4  1
    x[4,9]    R84       -2.2258731252318614e-02
    x[4,9]    R85       -3.9535535354550462e-02
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,10]   OBJ       4.9999999999999996e-02
    x[4,10]   onehot_4  1
    x[4,10]   R86       -2.2258731252318614e-02
    x[4,10]   R87       -3.9535535354550462e-02
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,11]   OBJ       0.05
    x[4,11]   onehot_4  1
    x[4,11]   R88       -2.2258731252318614e-02
    x[4,11]   R89       -3.9535535354550462e-02
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,12]   OBJ       0.05
    x[4,12]   onehot_4  1
    x[4,12]   R90       -2.2258731252318614e-02
    x[4,12]   R91       -3.9535535354550462e-02
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,13]   OBJ       -9.4230665102431888e-03
    x[4,13]   onehot_4  1
    x[4,13]   R92       -2.2258731252318614e-02
    x[4,13]   R93       -3.9535535354550462e-02
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,14]   OBJ       0.05
    x[4,14]   onehot_4  1
    x[4,14]   R94       -2.2258731252318614e-02
    x[4,14]   R95       -3.9535535354550462e-02
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,15]   OBJ       0.05
    x[4,15]   onehot_4  1
    x[4,15]   R96       -2.2258731252318614e-02
    x[4,15]   R97       -3.9535535354550462e-02
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[5,0]    OBJ       0.05
    x[5,0]    onehot_5  1
    x[5,0]    R102      -2.2258731252318614e-02
    x[5,0]    R103      -3.9535535354550462e-02
    x[5,1]    OBJ       4.9999999999999996e-02
    x[5,1]    onehot_5  1
    x[5,1]    R104      -2.2258731252318614e-02
    x[5,1]    R105      -3.9535535354550462e-02
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,2]    OBJ       4.9999999999999996e-02
    x[5,2]    onehot_5  1
    x[5,2]    R106      -2.2258731252318614e-02
    x[5,2]    R107      -3.9535535354550462e-02
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,3]    OBJ       4.9999999999999996e-02
    x[5,3]    onehot_5  1
    x[5,3]    R108      -2.2258731252318614e-02
    x[5,3]    R109      -3.9535535354550462e-02
    x[5,3]    hard_lower  3
    x[5,3]    hard_upper  3
    x[5,4]    OBJ       0.05
    x[5,4]    onehot_5  1
    x[5,4]    R110      -2.2258731252318614e-02
    x[5,4]    R111      -3.9535535354550462e-02
    x[5,4]    hard_lower  4
    x[5,4]    hard_upper  4
    x[5,5]    OBJ       4.9999999999999996e-02
    x[5,5]    onehot_5  1
    x[5,5]    R112      -2.2258731252318614e-02
    x[5,5]    R113      -3.9535535354550462e-02
    x[5,5]    hard_lower  5
    x[5,5]    hard_upper  5
    x[5,6]    OBJ       0.05
    x[5,6]    onehot_5  1
    x[5,6]    R114      -2.2258731252318614e-02
    x[5,6]    R115      -3.9535535354550462e-02
    x[5,6]    hard_lower  6
    x[5,6]    hard_upper  6
    x[5,7]    OBJ       0.05
    x[5,7]    onehot_5  1
    x[5,7]    R116      -2.2258731252318614e-02
    x[5,7]    R117      -3.9535535354550462e-02
    x[5,7]    hard_lower  7
    x[5,7]    hard_upper  7
    x[5,8]    onehot_5  1
    x[5,8]    R118      -2.2258731252318614e-02
    x[5,8]    R119      -3.9535535354550462e-02
    x[5,8]    hard_lower  8
    x[5,8]    hard_upper  8
    x[5,9]    OBJ       0.05
    x[5,9]    onehot_5  1
    x[5,9]    R120      -2.2258731252318614e-02
    x[5,9]    R121      -3.9535535354550462e-02
    x[5,9]    hard_lower  9
    x[5,9]    hard_upper  9
    x[5,10]   OBJ       0.05
    x[5,10]   onehot_5  1
    x[5,10]   R122      -2.2258731252318614e-02
    x[5,10]   R123      -3.9535535354550462e-02
    x[5,10]   hard_lower  10
    x[5,10]   hard_upper  10
    x[5,11]   OBJ       4.9999999999999996e-02
    x[5,11]   onehot_5  1
    x[5,11]   R124      -2.2258731252318614e-02
    x[5,11]   R125      -3.9535535354550462e-02
    x[5,11]   hard_lower  11
    x[5,11]   hard_upper  11
    x[5,12]   OBJ       0.05
    x[5,12]   onehot_5  1
    x[5,12]   R126      -2.2258731252318614e-02
    x[5,12]   R127      -3.9535535354550462e-02
    x[5,12]   hard_lower  12
    x[5,12]   hard_upper  12
    x[5,13]   OBJ       4.9999999999999996e-02
    x[5,13]   onehot_5  1
    x[5,13]   R128      -2.2258731252318614e-02
    x[5,13]   R129      -3.9535535354550462e-02
    x[5,13]   hard_lower  13
    x[5,13]   hard_upper  13
    x[5,14]   OBJ       4.9999999999999996e-02
    x[5,14]   onehot_5  1
    x[5,14]   R130      -2.2258731252318614e-02
    x[5,14]   R131      -3.9535535354550462e-02
    x[5,14]   hard_lower  14
    x[5,14]   hard_upper  14
    x[5,15]   OBJ       4.9999999999999996e-02
    x[5,15]   onehot_5  1
    x[5,15]   R132      -2.2258731252318614e-02
    x[5,15]   R133      -3.9535535354550462e-02
    x[5,15]   hard_lower  15
    x[5,15]   hard_upper  15
    x[6,4]    OBJ       3.9940833333333328e-02
    x[6,4]    onehot_6  1
    x[6,4]    R138      -2.2258731252318614e-02
    x[6,4]    R139      -3.9535535354550462e-02
    x[6,4]    hard_lower  4
    x[6,4]    hard_upper  4
    x[7,0]    OBJ       5.0000000000000010e-02
    x[7,0]    onehot_7  1
    x[7,0]    R144      -2.2258731252318614e-02
    x[7,0]    R145      -3.9535535354550462e-02
    x[7,1]    OBJ       5.0000000000000010e-02
    x[7,1]    onehot_7  1
    x[7,1]    R146      -2.2258731252318614e-02
    x[7,1]    R147      -3.9535535354550462e-02
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,2]    OBJ       0.05
    x[7,2]    onehot_7  1
    x[7,2]    R148      -2.2258731252318614e-02
    x[7,2]    R149      -3.9535535354550462e-02
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,3]    OBJ       0.05
    x[7,3]    onehot_7  1
    x[7,3]    R150      -2.2258731252318614e-02
    x[7,3]    R151      -3.9535535354550462e-02
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,4]    OBJ       0.05
    x[7,4]    onehot_7  1
    x[7,4]    R152      -2.2258731252318614e-02
    x[7,4]    R153      -3.9535535354550462e-02
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,5]    OBJ       0.05
    x[7,5]    onehot_7  1
    x[7,5]    R154      -2.2258731252318614e-02
    x[7,5]    R155      -3.9535535354550462e-02
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,6]    OBJ       0.05
    x[7,6]    onehot_7  1
    x[7,6]    R156      -2.2258731252318614e-02
    x[7,6]    R157      -3.9535535354550462e-02
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,7]    OBJ       0.05
    x[7,7]    onehot_7  1
    x[7,7]    R158      -2.2258731252318614e-02
    x[7,7]    R159      -3.9535535354550462e-02
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,8]    OBJ       0.05
    x[7,8]    onehot_7  1
    x[7,8]    R160      -2.2258731252318614e-02
    x[7,8]    R161      -3.9535535354550462e-02
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,9]    OBJ       5.0000000000000010e-02
    x[7,9]    onehot_7  1
    x[7,9]    R162      -2.2258731252318614e-02
    x[7,9]    R163      -3.9535535354550462e-02
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,10]   OBJ       4.9270254542932435e-18
    x[7,10]   onehot_7  1
    x[7,10]   R164      -2.2258731252318614e-02
    x[7,10]   R165      -3.9535535354550462e-02
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,11]   OBJ       0.05
    x[7,11]   onehot_7  1
    x[7,11]   R166      -2.2258731252318614e-02
    x[7,11]   R167      -3.9535535354550462e-02
    x[7,11]   hard_lower  11
    x[7,11]   hard_upper  11
    x[7,12]   OBJ       0.05
    x[7,12]   onehot_7  1
    x[7,12]   R168      -2.2258731252318614e-02
    x[7,12]   R169      -3.9535535354550462e-02
    x[7,12]   hard_lower  12
    x[7,12]   hard_upper  12
    x[7,13]   OBJ       0.05
    x[7,13]   onehot_7  1
    x[7,13]   R170      -2.2258731252318614e-02
    x[7,13]   R171      -3.9535535354550462e-02
    x[7,13]   hard_lower  13
    x[7,13]   hard_upper  13
    x[7,14]   OBJ       0.05
    x[7,14]   onehot_7  1
    x[7,14]   R172      -2.2258731252318614e-02
    x[7,14]   R173      -3.9535535354550462e-02
    x[7,14]   hard_lower  14
    x[7,14]   hard_upper  14
    x[7,15]   OBJ       0.05
    x[7,15]   onehot_7  1
    x[7,15]   R174      -2.2258731252318614e-02
    x[7,15]   R175      -3.9535535354550462e-02
    x[7,15]   hard_lower  15
    x[7,15]   hard_upper  15
    x[7,16]   OBJ       0.05
    x[7,16]   onehot_7  1
    x[7,16]   R176      -2.2258731252318614e-02
    x[7,16]   R177      -3.9535535354550462e-02
    x[7,16]   hard_lower  16
    x[7,16]   hard_upper  16
    x[7,17]   OBJ       0.05
    x[7,17]   onehot_7  1
    x[7,17]   R178      -2.2258731252318614e-02
    x[7,17]   R179      -3.9535535354550462e-02
    x[7,17]   hard_lower  17
    x[7,17]   hard_upper  17
    x[7,18]   OBJ       4.9999999999999996e-02
    x[7,18]   onehot_7  1
    x[7,18]   R180      -2.2258731252318614e-02
    x[7,18]   R181      -3.9535535354550462e-02
    x[7,18]   hard_lower  18
    x[7,18]   hard_upper  18
    x[7,19]   OBJ       0.05
    x[7,19]   onehot_7  1
    x[7,19]   R182      -2.2258731252318614e-02
    x[7,19]   R183      -3.9535535354550462e-02
    x[7,19]   hard_lower  19
    x[7,19]   hard_upper  19
    x[8,0]    OBJ       0.05
    x[8,0]    onehot_8  1
    x[8,0]    R188      -2.2258731252318614e-02
    x[8,0]    R189      -3.9535535354550462e-02
    x[8,1]    OBJ       0.05
    x[8,1]    onehot_8  1
    x[8,1]    R190      -2.2258731252318614e-02
    x[8,1]    R191      -3.9535535354550462e-02
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,2]    OBJ       0.05
    x[8,2]    onehot_8  1
    x[8,2]    R192      -2.2258731252318614e-02
    x[8,2]    R193      -3.9535535354550462e-02
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,3]    OBJ       0.05
    x[8,3]    onehot_8  1
    x[8,3]    R194      -2.2258731252318614e-02
    x[8,3]    R195      -3.9535535354550462e-02
    x[8,3]    hard_lower  3
    x[8,3]    hard_upper  3
    x[8,4]    OBJ       0.05
    x[8,4]    onehot_8  1
    x[8,4]    R196      -2.2258731252318614e-02
    x[8,4]    R197      -3.9535535354550462e-02
    x[8,4]    hard_lower  4
    x[8,4]    hard_upper  4
    x[8,5]    OBJ       0.05
    x[8,5]    onehot_8  1
    x[8,5]    R198      -2.2258731252318614e-02
    x[8,5]    R199      -3.9535535354550462e-02
    x[8,5]    hard_lower  5
    x[8,5]    hard_upper  5
    x[8,6]    OBJ       0.05
    x[8,6]    onehot_8  1
    x[8,6]    R200      -2.2258731252318614e-02
    x[8,6]    R201      -3.9535535354550462e-02
    x[8,6]    hard_lower  6
    x[8,6]    hard_upper  6
    x[8,7]    OBJ       2.4142438048713188e-18
    x[8,7]    onehot_8  1
    x[8,7]    R202      -2.2258731252318614e-02
    x[8,7]    R203      -3.9535535354550462e-02
    x[8,7]    hard_lower  7
    x[8,7]    hard_upper  7
    x[8,8]    OBJ       4.9999999999999996e-02
    x[8,8]    onehot_8  1
    x[8,8]    R204      -2.2258731252318614e-02
    x[8,8]    R205      -3.9535535354550462e-02
    x[8,8]    hard_lower  8
    x[8,8]    hard_upper  8
    x[8,9]    OBJ       4.9999999999999996e-02
    x[8,9]    onehot_8  1
    x[8,9]    R206      -2.2258731252318614e-02
    x[8,9]    R207      -3.9535535354550462e-02
    x[8,9]    hard_lower  9
    x[8,9]    hard_upper  9
    x[8,10]   OBJ       4.9999999999999996e-02
    x[8,10]   onehot_8  1
    x[8,10]   R208      -2.2258731252318614e-02
    x[8,10]   R209      -3.9535535354550462e-02
    x[8,10]   hard_lower  10
    x[8,10]   hard_upper  10
    x[8,11]   OBJ       0.05
    x[8,11]   onehot_8  1
    x[8,11]   R210      -2.2258731252318614e-02
    x[8,11]   R211      -3.9535535354550462e-02
    x[8,11]   hard_lower  11
    x[8,11]   hard_upper  11
    x[8,12]   OBJ       0.05
    x[8,12]   onehot_8  1
    x[8,12]   R212      -2.2258731252318614e-02
    x[8,12]   R213      -3.9535535354550462e-02
    x[8,12]   hard_lower  12
    x[8,12]   hard_upper  12
    x[8,13]   OBJ       0.05
    x[8,13]   onehot_8  1
    x[8,13]   R214      -2.2258731252318614e-02
    x[8,13]   R215      -3.9535535354550462e-02
    x[8,13]   hard_lower  13
    x[8,13]   hard_upper  13
    x[8,14]   OBJ       0.05
    x[8,14]   onehot_8  1
    x[8,14]   R216      -2.2258731252318614e-02
    x[8,14]   R217      -3.9535535354550462e-02
    x[8,14]   hard_lower  14
    x[8,14]   hard_upper  14
    x[8,15]   OBJ       0.05
    x[8,15]   onehot_8  1
    x[8,15]   R218      -2.2258731252318614e-02
    x[8,15]   R219      -3.9535535354550462e-02
    x[8,15]   hard_lower  15
    x[8,15]   hard_upper  15
    x[9,0]    OBJ       5.0000000000000010e-02
    x[9,0]    onehot_9  1
    x[9,0]    R224      -2.2258731252318614e-02
    x[9,0]    R225      -3.9535535354550462e-02
    x[9,1]    OBJ       5.0000000000000010e-02
    x[9,1]    onehot_9  1
    x[9,1]    R226      -2.2258731252318614e-02
    x[9,1]    R227      -3.9535535354550462e-02
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,2]    OBJ       0.05
    x[9,2]    onehot_9  1
    x[9,2]    R228      -2.2258731252318614e-02
    x[9,2]    R229      -3.9535535354550462e-02
    x[9,2]    hard_lower  2
    x[9,2]    hard_upper  2
    x[9,3]    OBJ       0.05
    x[9,3]    onehot_9  1
    x[9,3]    R230      -2.2258731252318614e-02
    x[9,3]    R231      -3.9535535354550462e-02
    x[9,3]    hard_lower  3
    x[9,3]    hard_upper  3
    x[9,4]    OBJ       0.05
    x[9,4]    onehot_9  1
    x[9,4]    R232      -2.2258731252318614e-02
    x[9,4]    R233      -3.9535535354550462e-02
    x[9,4]    hard_lower  4
    x[9,4]    hard_upper  4
    x[9,5]    OBJ       -1.2101350719677936e-02
    x[9,5]    onehot_9  1
    x[9,5]    R234      -2.2258731252318614e-02
    x[9,5]    R235      -3.9535535354550462e-02
    x[9,5]    hard_lower  5
    x[9,5]    hard_upper  5
    x[9,6]    OBJ       0.05
    x[9,6]    onehot_9  1
    x[9,6]    R236      -2.2258731252318614e-02
    x[9,6]    R237      -3.9535535354550462e-02
    x[9,6]    hard_lower  6
    x[9,6]    hard_upper  6
    x[9,7]    OBJ       0.05
    x[9,7]    onehot_9  1
    x[9,7]    R238      -2.2258731252318614e-02
    x[9,7]    R239      -3.9535535354550462e-02
    x[9,7]    hard_lower  7
    x[9,7]    hard_upper  7
    x[9,8]    OBJ       0.05
    x[9,8]    onehot_9  1
    x[9,8]    R240      -2.2258731252318614e-02
    x[9,8]    R241      -3.9535535354550462e-02
    x[9,8]    hard_lower  8
    x[9,8]    hard_upper  8
    x[9,9]    OBJ       5.0000000000000010e-02
    x[9,9]    onehot_9  1
    x[9,9]    R242      -2.2258731252318614e-02
    x[9,9]    R243      -3.9535535354550462e-02
    x[9,9]    hard_lower  9
    x[9,9]    hard_upper  9
    x[9,10]   OBJ       4.9270254542932435e-18
    x[9,10]   onehot_9  1
    x[9,10]   R244      -2.2258731252318614e-02
    x[9,10]   R245      -3.9535535354550462e-02
    x[9,10]   hard_lower  10
    x[9,10]   hard_upper  10
    x[9,11]   OBJ       0.05
    x[9,11]   onehot_9  1
    x[9,11]   R246      -2.2258731252318614e-02
    x[9,11]   R247      -3.9535535354550462e-02
    x[9,11]   hard_lower  11
    x[9,11]   hard_upper  11
    x[9,12]   OBJ       0.05
    x[9,12]   onehot_9  1
    x[9,12]   R248      -2.2258731252318614e-02
    x[9,12]   R249      -3.9535535354550462e-02
    x[9,12]   hard_lower  12
    x[9,12]   hard_upper  12
    x[9,13]   OBJ       0.05
    x[9,13]   onehot_9  1
    x[9,13]   R250      -2.2258731252318614e-02
    x[9,13]   R251      -3.9535535354550462e-02
    x[9,13]   hard_lower  13
    x[9,13]   hard_upper  13
    x[9,14]   OBJ       0.05
    x[9,14]   onehot_9  1
    x[9,14]   R252      -2.2258731252318614e-02
    x[9,14]   R253      -3.9535535354550462e-02
    x[9,14]   hard_lower  14
    x[9,14]   hard_upper  14
    x[10,0]   OBJ       0.05
    x[10,0]   onehot_10  1
    x[10,0]   R258      -2.2258731252318614e-02
    x[10,0]   R259      -3.9535535354550462e-02
    x[10,1]   OBJ       0.05
    x[10,1]   onehot_10  1
    x[10,1]   R260      -2.2258731252318614e-02
    x[10,1]   R261      -3.9535535354550462e-02
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,2]   OBJ       0.05
    x[10,2]   onehot_10  1
    x[10,2]   R262      -2.2258731252318614e-02
    x[10,2]   R263      -3.9535535354550462e-02
    x[10,2]   hard_lower  2
    x[10,2]   hard_upper  2
    x[10,3]   OBJ       0.05
    x[10,3]   onehot_10  1
    x[10,3]   R264      -2.2258731252318614e-02
    x[10,3]   R265      -3.9535535354550462e-02
    x[10,3]   hard_lower  3
    x[10,3]   hard_upper  3
    x[10,4]   OBJ       -8.1300226228394022e-03
    x[10,4]   onehot_10  1
    x[10,4]   R266      -2.2258731252318614e-02
    x[10,4]   R267      -3.9535535354550462e-02
    x[10,4]   hard_lower  4
    x[10,4]   hard_upper  4
    x[10,5]   OBJ       4.9999999999999996e-02
    x[10,5]   onehot_10  1
    x[10,5]   R268      -2.2258731252318614e-02
    x[10,5]   R269      -3.9535535354550462e-02
    x[10,5]   hard_lower  5
    x[10,5]   hard_upper  5
    x[10,6]   OBJ       1.7737311619470120e-18
    x[10,6]   onehot_10  1
    x[10,6]   R270      -2.2258731252318614e-02
    x[10,6]   R271      -3.9535535354550462e-02
    x[10,6]   hard_lower  6
    x[10,6]   hard_upper  6
    x[10,7]   OBJ       -3.2260997895732359e-03
    x[10,7]   onehot_10  1
    x[10,7]   R272      -2.2258731252318614e-02
    x[10,7]   R273      -3.9535535354550462e-02
    x[10,7]   hard_lower  7
    x[10,7]   hard_upper  7
    x[10,8]   OBJ       4.9999999999999996e-02
    x[10,8]   onehot_10  1
    x[10,8]   R274      -2.2258731252318614e-02
    x[10,8]   R275      -3.9535535354550462e-02
    x[10,8]   hard_lower  8
    x[10,8]   hard_upper  8
    x[10,9]   OBJ       4.9999999999999996e-02
    x[10,9]   onehot_10  1
    x[10,9]   R276      -2.2258731252318614e-02
    x[10,9]   R277      -3.9535535354550462e-02
    x[10,9]   hard_lower  9
    x[10,9]   hard_upper  9
    x[10,10]  OBJ       0.05
    x[10,10]  onehot_10  1
    x[10,10]  R278      -2.2258731252318614e-02
    x[10,10]  R279      -3.9535535354550462e-02
    x[10,10]  hard_lower  10
    x[10,10]  hard_upper  10
    x[10,11]  OBJ       0.05
    x[10,11]  onehot_10  1
    x[10,11]  R280      -2.2258731252318614e-02
    x[10,11]  R281      -3.9535535354550462e-02
    x[10,11]  hard_lower  11
    x[10,11]  hard_upper  11
    x[11,0]   OBJ       0.05
    x[11,0]   onehot_11  1
    x[11,0]   R286      -2.2258731252318614e-02
    x[11,0]   R287      -3.9535535354550462e-02
    x[11,1]   OBJ       0.05
    x[11,1]   onehot_11  1
    x[11,1]   R288      -2.2258731252318614e-02
    x[11,1]   R289      -3.9535535354550462e-02
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,2]   OBJ       0.05
    x[11,2]   onehot_11  1
    x[11,2]   R290      -2.2258731252318614e-02
    x[11,2]   R291      -3.9535535354550462e-02
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,3]   OBJ       0.05
    x[11,3]   onehot_11  1
    x[11,3]   R292      -2.2258731252318614e-02
    x[11,3]   R293      -3.9535535354550462e-02
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,4]   OBJ       0.05
    x[11,4]   onehot_11  1
    x[11,4]   R294      -2.2258731252318614e-02
    x[11,4]   R295      -3.9535535354550462e-02
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,5]   OBJ       0.05
    x[11,5]   onehot_11  1
    x[11,5]   R296      -2.2258731252318614e-02
    x[11,5]   R297      -3.9535535354550462e-02
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,6]   OBJ       0.05
    x[11,6]   onehot_11  1
    x[11,6]   R298      -2.2258731252318614e-02
    x[11,6]   R299      -3.9535535354550462e-02
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,7]   OBJ       2.4142438048713188e-18
    x[11,7]   onehot_11  1
    x[11,7]   R300      -2.2258731252318614e-02
    x[11,7]   R301      -3.9535535354550462e-02
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,8]   OBJ       4.9999999999999996e-02
    x[11,8]   onehot_11  1
    x[11,8]   R302      -2.2258731252318614e-02
    x[11,8]   R303      -3.9535535354550462e-02
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,9]   OBJ       4.9999999999999996e-02
    x[11,9]   onehot_11  1
    x[11,9]   R304      -2.2258731252318614e-02
    x[11,9]   R305      -3.9535535354550462e-02
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,10]  OBJ       4.9999999999999996e-02
    x[11,10]  onehot_11  1
    x[11,10]  R306      -2.2258731252318614e-02
    x[11,10]  R307      -3.9535535354550462e-02
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,11]  OBJ       0.05
    x[11,11]  onehot_11  1
    x[11,11]  R308      -2.2258731252318614e-02
    x[11,11]  R309      -3.9535535354550462e-02
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,12]  OBJ       0.05
    x[11,12]  onehot_11  1
    x[11,12]  R310      -2.2258731252318614e-02
    x[11,12]  R311      -3.9535535354550462e-02
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[11,13]  OBJ       0.05
    x[11,13]  onehot_11  1
    x[11,13]  R312      -2.2258731252318614e-02
    x[11,13]  R313      -3.9535535354550462e-02
    x[11,13]  hard_lower  13
    x[11,13]  hard_upper  13
    x[11,14]  OBJ       0.05
    x[11,14]  onehot_11  1
    x[11,14]  R314      -2.2258731252318614e-02
    x[11,14]  R315      -3.9535535354550462e-02
    x[11,14]  hard_lower  14
    x[11,14]  hard_upper  14
    x[11,15]  OBJ       0.05
    x[11,15]  onehot_11  1
    x[11,15]  R316      -2.2258731252318614e-02
    x[11,15]  R317      -3.9535535354550462e-02
    x[11,15]  hard_lower  15
    x[11,15]  hard_upper  15
    x[12,0]   OBJ       0.05
    x[12,0]   onehot_12  1
    x[12,0]   R322      -2.2258731252318614e-02
    x[12,0]   R323      -3.9535535354550462e-02
    x[12,1]   OBJ       4.9999999999999996e-02
    x[12,1]   onehot_12  1
    x[12,1]   R324      -2.2258731252318614e-02
    x[12,1]   R325      -3.9535535354550462e-02
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,2]   OBJ       4.9999999999999996e-02
    x[12,2]   onehot_12  1
    x[12,2]   R326      -2.2258731252318614e-02
    x[12,2]   R327      -3.9535535354550462e-02
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,3]   OBJ       4.9999999999999996e-02
    x[12,3]   onehot_12  1
    x[12,3]   R328      -2.2258731252318614e-02
    x[12,3]   R329      -3.9535535354550462e-02
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,4]   OBJ       0.05
    x[12,4]   onehot_12  1
    x[12,4]   R330      -2.2258731252318614e-02
    x[12,4]   R331      -3.9535535354550462e-02
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,5]   OBJ       4.9999999999999996e-02
    x[12,5]   onehot_12  1
    x[12,5]   R332      -2.2258731252318614e-02
    x[12,5]   R333      -3.9535535354550462e-02
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,6]   OBJ       0.05
    x[12,6]   onehot_12  1
    x[12,6]   R334      -2.2258731252318614e-02
    x[12,6]   R335      -3.9535535354550462e-02
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,7]   OBJ       0.05
    x[12,7]   onehot_12  1
    x[12,7]   R336      -2.2258731252318614e-02
    x[12,7]   R337      -3.9535535354550462e-02
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,8]   onehot_12  1
    x[12,8]   R338      -2.2258731252318614e-02
    x[12,8]   R339      -3.9535535354550462e-02
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,9]   OBJ       0.05
    x[12,9]   onehot_12  1
    x[12,9]   R340      -2.2258731252318614e-02
    x[12,9]   R341      -3.9535535354550462e-02
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,10]  OBJ       0.05
    x[12,10]  onehot_12  1
    x[12,10]  R342      -2.2258731252318614e-02
    x[12,10]  R343      -3.9535535354550462e-02
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,11]  OBJ       4.9999999999999996e-02
    x[12,11]  onehot_12  1
    x[12,11]  R344      -2.2258731252318614e-02
    x[12,11]  R345      -3.9535535354550462e-02
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,12]  OBJ       0.05
    x[12,12]  onehot_12  1
    x[12,12]  R346      -2.2258731252318614e-02
    x[12,12]  R347      -3.9535535354550462e-02
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,13]  OBJ       4.9999999999999996e-02
    x[12,13]  onehot_12  1
    x[12,13]  R348      -2.2258731252318614e-02
    x[12,13]  R349      -3.9535535354550462e-02
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,14]  OBJ       -1.6136994404056918e-02
    x[12,14]  onehot_12  1
    x[12,14]  R350      -2.2258731252318614e-02
    x[12,14]  R351      -3.9535535354550462e-02
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,15]  OBJ       4.9999999999999996e-02
    x[12,15]  onehot_12  1
    x[12,15]  R352      -2.2258731252318614e-02
    x[12,15]  R353      -3.9535535354550462e-02
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[13,0]   OBJ       5.0000000000000010e-02
    x[13,0]   onehot_13  1
    x[13,0]   R358      -2.2258731252318614e-02
    x[13,0]   R359      -3.9535535354550462e-02
    x[13,1]   OBJ       5.0000000000000010e-02
    x[13,1]   onehot_13  1
    x[13,1]   R360      -2.2258731252318614e-02
    x[13,1]   R361      -3.9535535354550462e-02
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,2]   OBJ       0.05
    x[13,2]   onehot_13  1
    x[13,2]   R362      -2.2258731252318614e-02
    x[13,2]   R363      -3.9535535354550462e-02
    x[13,2]   hard_lower  2
    x[13,2]   hard_upper  2
    x[13,3]   OBJ       0.05
    x[13,3]   onehot_13  1
    x[13,3]   R364      -2.2258731252318614e-02
    x[13,3]   R365      -3.9535535354550462e-02
    x[13,3]   hard_lower  3
    x[13,3]   hard_upper  3
    x[13,4]   OBJ       0.05
    x[13,4]   onehot_13  1
    x[13,4]   R366      -2.2258731252318614e-02
    x[13,4]   R367      -3.9535535354550462e-02
    x[13,4]   hard_lower  4
    x[13,4]   hard_upper  4
    x[13,5]   OBJ       0.05
    x[13,5]   onehot_13  1
    x[13,5]   R368      -2.2258731252318614e-02
    x[13,5]   R369      -3.9535535354550462e-02
    x[13,5]   hard_lower  5
    x[13,5]   hard_upper  5
    x[13,6]   OBJ       0.05
    x[13,6]   onehot_13  1
    x[13,6]   R370      -2.2258731252318614e-02
    x[13,6]   R371      -3.9535535354550462e-02
    x[13,6]   hard_lower  6
    x[13,6]   hard_upper  6
    x[13,7]   OBJ       0.05
    x[13,7]   onehot_13  1
    x[13,7]   R372      -2.2258731252318614e-02
    x[13,7]   R373      -3.9535535354550462e-02
    x[13,7]   hard_lower  7
    x[13,7]   hard_upper  7
    x[13,8]   OBJ       0.05
    x[13,8]   onehot_13  1
    x[13,8]   R374      -2.2258731252318614e-02
    x[13,8]   R375      -3.9535535354550462e-02
    x[13,8]   hard_lower  8
    x[13,8]   hard_upper  8
    x[13,9]   OBJ       5.0000000000000010e-02
    x[13,9]   onehot_13  1
    x[13,9]   R376      -2.2258731252318614e-02
    x[13,9]   R377      -3.9535535354550462e-02
    x[13,9]   hard_lower  9
    x[13,9]   hard_upper  9
    x[13,10]  OBJ       4.9270254542932435e-18
    x[13,10]  onehot_13  1
    x[13,10]  R378      -2.2258731252318614e-02
    x[13,10]  R379      -3.9535535354550462e-02
    x[13,10]  hard_lower  10
    x[13,10]  hard_upper  10
    x[13,11]  OBJ       0.05
    x[13,11]  onehot_13  1
    x[13,11]  R380      -2.2258731252318614e-02
    x[13,11]  R381      -3.9535535354550462e-02
    x[13,11]  hard_lower  11
    x[13,11]  hard_upper  11
    x[13,12]  OBJ       0.05
    x[13,12]  onehot_13  1
    x[13,12]  R382      -2.2258731252318614e-02
    x[13,12]  R383      -3.9535535354550462e-02
    x[13,12]  hard_lower  12
    x[13,12]  hard_upper  12
    x[13,13]  OBJ       0.05
    x[13,13]  onehot_13  1
    x[13,13]  R384      -2.2258731252318614e-02
    x[13,13]  R385      -3.9535535354550462e-02
    x[13,13]  hard_lower  13
    x[13,13]  hard_upper  13
    x[13,14]  OBJ       0.05
    x[13,14]  onehot_13  1
    x[13,14]  R386      -2.2258731252318614e-02
    x[13,14]  R387      -3.9535535354550462e-02
    x[13,14]  hard_lower  14
    x[13,14]  hard_upper  14
    x[13,15]  OBJ       0.05
    x[13,15]  onehot_13  1
    x[13,15]  R388      -2.2258731252318614e-02
    x[13,15]  R389      -3.9535535354550462e-02
    x[13,15]  hard_lower  15
    x[13,15]  hard_upper  15
    x[13,16]  OBJ       0.05
    x[13,16]  onehot_13  1
    x[13,16]  R390      -2.2258731252318614e-02
    x[13,16]  R391      -3.9535535354550462e-02
    x[13,16]  hard_lower  16
    x[13,16]  hard_upper  16
    x[13,17]  OBJ       0.05
    x[13,17]  onehot_13  1
    x[13,17]  R392      -2.2258731252318614e-02
    x[13,17]  R393      -3.9535535354550462e-02
    x[13,17]  hard_lower  17
    x[13,17]  hard_upper  17
    x[13,18]  OBJ       4.9999999999999996e-02
    x[13,18]  onehot_13  1
    x[13,18]  R394      -2.2258731252318614e-02
    x[13,18]  R395      -3.9535535354550462e-02
    x[13,18]  hard_lower  18
    x[13,18]  hard_upper  18
    x[13,19]  OBJ       0.05
    x[13,19]  onehot_13  1
    x[13,19]  R396      -2.2258731252318614e-02
    x[13,19]  R397      -3.9535535354550462e-02
    x[13,19]  hard_lower  19
    x[13,19]  hard_upper  19
    x[14,0]   OBJ       5.0000000000000010e-02
    x[14,0]   onehot_14  1
    x[14,0]   R402      -2.2258731252318614e-02
    x[14,0]   R403      -3.9535535354550462e-02
    x[14,1]   OBJ       5.0000000000000010e-02
    x[14,1]   onehot_14  1
    x[14,1]   R404      -2.2258731252318614e-02
    x[14,1]   R405      -3.9535535354550462e-02
    x[14,1]   hard_lower  1
    x[14,1]   hard_upper  1
    x[14,2]   OBJ       0.05
    x[14,2]   onehot_14  1
    x[14,2]   R406      -2.2258731252318614e-02
    x[14,2]   R407      -3.9535535354550462e-02
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,3]   OBJ       0.05
    x[14,3]   onehot_14  1
    x[14,3]   R408      -2.2258731252318614e-02
    x[14,3]   R409      -3.9535535354550462e-02
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,4]   OBJ       0.05
    x[14,4]   onehot_14  1
    x[14,4]   R410      -2.2258731252318614e-02
    x[14,4]   R411      -3.9535535354550462e-02
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,5]   OBJ       0.05
    x[14,5]   onehot_14  1
    x[14,5]   R412      -2.2258731252318614e-02
    x[14,5]   R413      -3.9535535354550462e-02
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,6]   OBJ       0.05
    x[14,6]   onehot_14  1
    x[14,6]   R414      -2.2258731252318614e-02
    x[14,6]   R415      -3.9535535354550462e-02
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,7]   OBJ       0.05
    x[14,7]   onehot_14  1
    x[14,7]   R416      -2.2258731252318614e-02
    x[14,7]   R417      -3.9535535354550462e-02
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,8]   OBJ       0.05
    x[14,8]   onehot_14  1
    x[14,8]   R418      -2.2258731252318614e-02
    x[14,8]   R419      -3.9535535354550462e-02
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,9]   OBJ       5.0000000000000010e-02
    x[14,9]   onehot_14  1
    x[14,9]   R420      -2.2258731252318614e-02
    x[14,9]   R421      -3.9535535354550462e-02
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,10]  OBJ       4.9270254542932435e-18
    x[14,10]  onehot_14  1
    x[14,10]  R422      -2.2258731252318614e-02
    x[14,10]  R423      -3.9535535354550462e-02
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,11]  OBJ       0.05
    x[14,11]  onehot_14  1
    x[14,11]  R424      -2.2258731252318614e-02
    x[14,11]  R425      -3.9535535354550462e-02
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,12]  OBJ       0.05
    x[14,12]  onehot_14  1
    x[14,12]  R426      -2.2258731252318614e-02
    x[14,12]  R427      -3.9535535354550462e-02
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,13]  OBJ       0.05
    x[14,13]  onehot_14  1
    x[14,13]  R428      -2.2258731252318614e-02
    x[14,13]  R429      -3.9535535354550462e-02
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,14]  OBJ       0.05
    x[14,14]  onehot_14  1
    x[14,14]  R430      -2.2258731252318614e-02
    x[14,14]  R431      -3.9535535354550462e-02
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,15]  OBJ       0.05
    x[14,15]  onehot_14  1
    x[14,15]  R432      -2.2258731252318614e-02
    x[14,15]  R433      -3.9535535354550462e-02
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[14,16]  OBJ       0.05
    x[14,16]  onehot_14  1
    x[14,16]  R434      -2.2258731252318614e-02
    x[14,16]  R435      -3.9535535354550462e-02
    x[14,16]  hard_lower  16
    x[14,16]  hard_upper  16
    x[14,17]  OBJ       0.05
    x[14,17]  onehot_14  1
    x[14,17]  R436      -2.2258731252318614e-02
    x[14,17]  R437      -3.9535535354550462e-02
    x[14,17]  hard_lower  17
    x[14,17]  hard_upper  17
    x[14,18]  OBJ       4.9999999999999996e-02
    x[14,18]  onehot_14  1
    x[14,18]  R438      -2.2258731252318614e-02
    x[14,18]  R439      -3.9535535354550462e-02
    x[14,18]  hard_lower  18
    x[14,18]  hard_upper  18
    x[15,0]   OBJ       5.0000000000000010e-02
    x[15,0]   onehot_15  1
    x[15,0]   R444      -2.2258731252318614e-02
    x[15,0]   R445      -3.9535535354550462e-02
    x[15,1]   OBJ       5.0000000000000010e-02
    x[15,1]   onehot_15  1
    x[15,1]   R446      -2.2258731252318614e-02
    x[15,1]   R447      -3.9535535354550462e-02
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,2]   OBJ       0.05
    x[15,2]   onehot_15  1
    x[15,2]   R448      -2.2258731252318614e-02
    x[15,2]   R449      -3.9535535354550462e-02
    x[15,2]   hard_lower  2
    x[15,2]   hard_upper  2
    x[15,3]   OBJ       0.05
    x[15,3]   onehot_15  1
    x[15,3]   R450      -2.2258731252318614e-02
    x[15,3]   R451      -3.9535535354550462e-02
    x[15,3]   hard_lower  3
    x[15,3]   hard_upper  3
    x[15,4]   OBJ       0.05
    x[15,4]   onehot_15  1
    x[15,4]   R452      -2.2258731252318614e-02
    x[15,4]   R453      -3.9535535354550462e-02
    x[15,4]   hard_lower  4
    x[15,4]   hard_upper  4
    x[15,5]   OBJ       0.05
    x[15,5]   onehot_15  1
    x[15,5]   R454      -2.2258731252318614e-02
    x[15,5]   R455      -3.9535535354550462e-02
    x[15,5]   hard_lower  5
    x[15,5]   hard_upper  5
    x[15,6]   OBJ       0.05
    x[15,6]   onehot_15  1
    x[15,6]   R456      -2.2258731252318614e-02
    x[15,6]   R457      -3.9535535354550462e-02
    x[15,6]   hard_lower  6
    x[15,6]   hard_upper  6
    x[15,7]   OBJ       0.05
    x[15,7]   onehot_15  1
    x[15,7]   R458      -2.2258731252318614e-02
    x[15,7]   R459      -3.9535535354550462e-02
    x[15,7]   hard_lower  7
    x[15,7]   hard_upper  7
    x[15,8]   OBJ       0.05
    x[15,8]   onehot_15  1
    x[15,8]   R460      -2.2258731252318614e-02
    x[15,8]   R461      -3.9535535354550462e-02
    x[15,8]   hard_lower  8
    x[15,8]   hard_upper  8
    x[15,9]   OBJ       5.0000000000000010e-02
    x[15,9]   onehot_15  1
    x[15,9]   R462      -2.2258731252318614e-02
    x[15,9]   R463      -3.9535535354550462e-02
    x[15,9]   hard_lower  9
    x[15,9]   hard_upper  9
    x[15,10]  OBJ       4.9270254542932435e-18
    x[15,10]  onehot_15  1
    x[15,10]  R464      -2.2258731252318614e-02
    x[15,10]  R465      -3.9535535354550462e-02
    x[15,10]  hard_lower  10
    x[15,10]  hard_upper  10
    x[15,11]  OBJ       0.05
    x[15,11]  onehot_15  1
    x[15,11]  R466      -2.2258731252318614e-02
    x[15,11]  R467      -3.9535535354550462e-02
    x[15,11]  hard_lower  11
    x[15,11]  hard_upper  11
    x[15,12]  OBJ       0.05
    x[15,12]  onehot_15  1
    x[15,12]  R468      -2.2258731252318614e-02
    x[15,12]  R469      -3.9535535354550462e-02
    x[15,12]  hard_lower  12
    x[15,12]  hard_upper  12
    x[15,13]  OBJ       0.05
    x[15,13]  onehot_15  1
    x[15,13]  R470      -2.2258731252318614e-02
    x[15,13]  R471      -3.9535535354550462e-02
    x[15,13]  hard_lower  13
    x[15,13]  hard_upper  13
    x[15,14]  OBJ       0.05
    x[15,14]  onehot_15  1
    x[15,14]  R472      -2.2258731252318614e-02
    x[15,14]  R473      -3.9535535354550462e-02
    x[15,14]  hard_lower  14
    x[15,14]  hard_upper  14
    x[15,15]  OBJ       0.05
    x[15,15]  onehot_15  1
    x[15,15]  R474      -2.2258731252318614e-02
    x[15,15]  R475      -3.9535535354550462e-02
    x[15,15]  hard_lower  15
    x[15,15]  hard_upper  15
    x[15,16]  OBJ       0.05
    x[15,16]  onehot_15  1
    x[15,16]  R476      -2.2258731252318614e-02
    x[15,16]  R477      -3.9535535354550462e-02
    x[15,16]  hard_lower  16
    x[15,16]  hard_upper  16
    x[15,17]  OBJ       0.05
    x[15,17]  onehot_15  1
    x[15,17]  R478      -2.2258731252318614e-02
    x[15,17]  R479      -3.9535535354550462e-02
    x[15,17]  hard_lower  17
    x[15,17]  hard_upper  17
    x[15,18]  OBJ       4.9999999999999996e-02
    x[15,18]  onehot_15  1
    x[15,18]  R480      -2.2258731252318614e-02
    x[15,18]  R481      -3.9535535354550462e-02
    x[15,18]  hard_lower  18
    x[15,18]  hard_upper  18
    x[15,19]  OBJ       0.05
    x[15,19]  onehot_15  1
    x[15,19]  R482      -2.2258731252318614e-02
    x[15,19]  R483      -3.9535535354550462e-02
    x[15,19]  hard_lower  19
    x[15,19]  hard_upper  19
    x[16,0]   OBJ       5.8875739999999996e-02
    x[16,0]   onehot_16  1
    x[16,0]   R488      -2.2258731252318614e-02
    x[16,0]   R489      -3.9535535354550462e-02
    x[16,1]   OBJ       5.8875739999999996e-02
    x[16,1]   onehot_16  1
    x[16,1]   R490      -2.2258731252318614e-02
    x[16,1]   R491      -3.9535535354550462e-02
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,2]   OBJ       5.8875739999999996e-02
    x[16,2]   onehot_16  1
    x[16,2]   R492      -2.2258731252318614e-02
    x[16,2]   R493      -3.9535535354550462e-02
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,3]   OBJ       8.8757399999999983e-03
    x[16,3]   onehot_16  1
    x[16,3]   R494      -2.2258731252318614e-02
    x[16,3]   R495      -3.9535535354550462e-02
    x[16,3]   hard_lower  3
    x[16,3]   hard_upper  3
    x[16,4]   OBJ       0.05887574
    x[16,4]   onehot_16  1
    x[16,4]   R496      -2.2258731252318614e-02
    x[16,4]   R497      -3.9535535354550462e-02
    x[16,4]   hard_lower  4
    x[16,4]   hard_upper  4
    x[16,5]   OBJ       0.05887574
    x[16,5]   onehot_16  1
    x[16,5]   R498      -2.2258731252318614e-02
    x[16,5]   R499      -3.9535535354550462e-02
    x[16,5]   hard_lower  5
    x[16,5]   hard_upper  5
    x[16,6]   OBJ       5.8875739999999996e-02
    x[16,6]   onehot_16  1
    x[16,6]   R500      -2.2258731252318614e-02
    x[16,6]   R501      -3.9535535354550462e-02
    x[16,6]   hard_lower  6
    x[16,6]   hard_upper  6
    x[16,7]   OBJ       0.05887574
    x[16,7]   onehot_16  1
    x[16,7]   R502      -2.2258731252318614e-02
    x[16,7]   R503      -3.9535535354550462e-02
    x[16,7]   hard_lower  7
    x[16,7]   hard_upper  7
    x[16,8]   OBJ       5.8875739999999996e-02
    x[16,8]   onehot_16  1
    x[16,8]   R504      -2.2258731252318614e-02
    x[16,8]   R505      -3.9535535354550462e-02
    x[16,8]   hard_lower  8
    x[16,8]   hard_upper  8
    x[16,9]   OBJ       0.05887574
    x[16,9]   onehot_16  1
    x[16,9]   R506      -2.2258731252318614e-02
    x[16,9]   R507      -3.9535535354550462e-02
    x[16,9]   hard_lower  9
    x[16,9]   hard_upper  9
    x[16,10]  OBJ       5.8875739999999996e-02
    x[16,10]  onehot_16  1
    x[16,10]  R508      -2.2258731252318614e-02
    x[16,10]  R509      -3.9535535354550462e-02
    x[16,10]  hard_lower  10
    x[16,10]  hard_upper  10
    x[16,11]  OBJ       0.00247935696095804
    x[16,11]  onehot_16  1
    x[16,11]  R510      -2.2258731252318614e-02
    x[16,11]  R511      -3.9535535354550462e-02
    x[16,11]  hard_lower  11
    x[16,11]  hard_upper  11
    x[17,16]  OBJ       5.5917166666666657e-02
    x[17,16]  onehot_17  1
    x[17,16]  R516      -2.2258731252318614e-02
    x[17,16]  R517      -3.9535535354550462e-02
    x[17,16]  hard_lower  16
    x[17,16]  hard_upper  16
    x[18,0]   OBJ       0.05
    x[18,0]   onehot_18  1
    x[18,0]   R522      -2.2258731252318614e-02
    x[18,0]   R523      -3.9535535354550462e-02
    x[18,1]   OBJ       0.05
    x[18,1]   onehot_18  1
    x[18,1]   R524      -2.2258731252318614e-02
    x[18,1]   R525      -3.9535535354550462e-02
    x[18,1]   hard_lower  1
    x[18,1]   hard_upper  1
    x[18,2]   OBJ       0.05
    x[18,2]   onehot_18  1
    x[18,2]   R526      -2.2258731252318614e-02
    x[18,2]   R527      -3.9535535354550462e-02
    x[18,2]   hard_lower  2
    x[18,2]   hard_upper  2
    x[18,3]   OBJ       0.05
    x[18,3]   onehot_18  1
    x[18,3]   R528      -2.2258731252318614e-02
    x[18,3]   R529      -3.9535535354550462e-02
    x[18,3]   hard_lower  3
    x[18,3]   hard_upper  3
    x[18,4]   OBJ       0.05
    x[18,4]   onehot_18  1
    x[18,4]   R530      -2.2258731252318614e-02
    x[18,4]   R531      -3.9535535354550462e-02
    x[18,4]   hard_lower  4
    x[18,4]   hard_upper  4
    x[18,5]   OBJ       0.05
    x[18,5]   onehot_18  1
    x[18,5]   R532      -2.2258731252318614e-02
    x[18,5]   R533      -3.9535535354550462e-02
    x[18,5]   hard_lower  5
    x[18,5]   hard_upper  5
    x[18,6]   OBJ       0.05
    x[18,6]   onehot_18  1
    x[18,6]   R534      -2.2258731252318614e-02
    x[18,6]   R535      -3.9535535354550462e-02
    x[18,6]   hard_lower  6
    x[18,6]   hard_upper  6
    x[18,7]   OBJ       2.4142438048713188e-18
    x[18,7]   onehot_18  1
    x[18,7]   R536      -2.2258731252318614e-02
    x[18,7]   R537      -3.9535535354550462e-02
    x[18,7]   hard_lower  7
    x[18,7]   hard_upper  7
    x[18,8]   OBJ       4.9999999999999996e-02
    x[18,8]   onehot_18  1
    x[18,8]   R538      -2.2258731252318614e-02
    x[18,8]   R539      -3.9535535354550462e-02
    x[18,8]   hard_lower  8
    x[18,8]   hard_upper  8
    x[18,9]   OBJ       4.9999999999999996e-02
    x[18,9]   onehot_18  1
    x[18,9]   R540      -2.2258731252318614e-02
    x[18,9]   R541      -3.9535535354550462e-02
    x[18,9]   hard_lower  9
    x[18,9]   hard_upper  9
    x[18,10]  OBJ       4.9999999999999996e-02
    x[18,10]  onehot_18  1
    x[18,10]  R542      -2.2258731252318614e-02
    x[18,10]  R543      -3.9535535354550462e-02
    x[18,10]  hard_lower  10
    x[18,10]  hard_upper  10
    x[18,11]  OBJ       0.05
    x[18,11]  onehot_18  1
    x[18,11]  R544      -2.2258731252318614e-02
    x[18,11]  R545      -3.9535535354550462e-02
    x[18,11]  hard_lower  11
    x[18,11]  hard_upper  11
    x[18,12]  OBJ       0.05
    x[18,12]  onehot_18  1
    x[18,12]  R546      -2.2258731252318614e-02
    x[18,12]  R547      -3.9535535354550462e-02
    x[18,12]  hard_lower  12
    x[18,12]  hard_upper  12
    x[18,13]  OBJ       0.05
    x[18,13]  onehot_18  1
    x[18,13]  R548      -2.2258731252318614e-02
    x[18,13]  R549      -3.9535535354550462e-02
    x[18,13]  hard_lower  13
    x[18,13]  hard_upper  13
    x[18,14]  OBJ       0.05
    x[18,14]  onehot_18  1
    x[18,14]  R550      -2.2258731252318614e-02
    x[18,14]  R551      -3.9535535354550462e-02
    x[18,14]  hard_lower  14
    x[18,14]  hard_upper  14
    x[18,15]  OBJ       0.05
    x[18,15]  onehot_18  1
    x[18,15]  R552      -2.2258731252318614e-02
    x[18,15]  R553      -3.9535535354550462e-02
    x[18,15]  hard_lower  15
    x[18,15]  hard_upper  15
    x[19,0]   OBJ       0.05
    x[19,0]   onehot_19  1
    x[19,0]   R558      -2.2258731252318614e-02
    x[19,0]   R559      -3.9535535354550462e-02
    x[19,1]   OBJ       5.0000000000000010e-02
    x[19,1]   onehot_19  1
    x[19,1]   R560      -2.2258731252318614e-02
    x[19,1]   R561      -3.9535535354550462e-02
    x[19,1]   hard_lower  1
    x[19,1]   hard_upper  1
    x[19,2]   OBJ       5.0000000000000010e-02
    x[19,2]   onehot_19  1
    x[19,2]   R562      -2.2258731252318614e-02
    x[19,2]   R563      -3.9535535354550462e-02
    x[19,2]   hard_lower  2
    x[19,2]   hard_upper  2
    x[19,3]   OBJ       0.05
    x[19,3]   onehot_19  1
    x[19,3]   R564      -2.2258731252318614e-02
    x[19,3]   R565      -3.9535535354550462e-02
    x[19,3]   hard_lower  3
    x[19,3]   hard_upper  3
    x[19,4]   OBJ       0.05
    x[19,4]   onehot_19  1
    x[19,4]   R566      -2.2258731252318614e-02
    x[19,4]   R567      -3.9535535354550462e-02
    x[19,4]   hard_lower  4
    x[19,4]   hard_upper  4
    x[19,5]   OBJ       0.05
    x[19,5]   onehot_19  1
    x[19,5]   R568      -2.2258731252318614e-02
    x[19,5]   R569      -3.9535535354550462e-02
    x[19,5]   hard_lower  5
    x[19,5]   hard_upper  5
    x[19,6]   OBJ       0.05
    x[19,6]   onehot_19  1
    x[19,6]   R570      -2.2258731252318614e-02
    x[19,6]   R571      -3.9535535354550462e-02
    x[19,6]   hard_lower  6
    x[19,6]   hard_upper  6
    x[19,7]   OBJ       5.0000000000000010e-02
    x[19,7]   onehot_19  1
    x[19,7]   R572      -2.2258731252318614e-02
    x[19,7]   R573      -3.9535535354550462e-02
    x[19,7]   hard_lower  7
    x[19,7]   hard_upper  7
    x[19,8]   OBJ       0.05
    x[19,8]   onehot_19  1
    x[19,8]   R574      -2.2258731252318614e-02
    x[19,8]   R575      -3.9535535354550462e-02
    x[19,8]   hard_lower  8
    x[19,8]   hard_upper  8
    x[19,9]   OBJ       3.9908909510444345e-18
    x[19,9]   onehot_19  1
    x[19,9]   R576      -2.2258731252318614e-02
    x[19,9]   R577      -3.9535535354550462e-02
    x[19,9]   hard_lower  9
    x[19,9]   hard_upper  9
    x[19,10]  OBJ       0.05
    x[19,10]  onehot_19  1
    x[19,10]  R578      -2.2258731252318614e-02
    x[19,10]  R579      -3.9535535354550462e-02
    x[19,10]  hard_lower  10
    x[19,10]  hard_upper  10
    x[19,11]  OBJ       0.05
    x[19,11]  onehot_19  1
    x[19,11]  R580      -2.2258731252318614e-02
    x[19,11]  R581      -3.9535535354550462e-02
    x[19,11]  hard_lower  11
    x[19,11]  hard_upper  11
    x[19,12]  OBJ       0.05
    x[19,12]  onehot_19  1
    x[19,12]  R582      -2.2258731252318614e-02
    x[19,12]  R583      -3.9535535354550462e-02
    x[19,12]  hard_lower  12
    x[19,12]  hard_upper  12
    x[19,13]  OBJ       0.05
    x[19,13]  onehot_19  1
    x[19,13]  R584      -2.2258731252318614e-02
    x[19,13]  R585      -3.9535535354550462e-02
    x[19,13]  hard_lower  13
    x[19,13]  hard_upper  13
    x[19,14]  OBJ       0.05
    x[19,14]  onehot_19  1
    x[19,14]  R586      -2.2258731252318614e-02
    x[19,14]  R587      -3.9535535354550462e-02
    x[19,14]  hard_lower  14
    x[19,14]  hard_upper  14
    x[19,15]  OBJ       0.05
    x[19,15]  onehot_19  1
    x[19,15]  R588      -2.2258731252318614e-02
    x[19,15]  R589      -3.9535535354550462e-02
    x[19,15]  hard_lower  15
    x[19,15]  hard_upper  15
    x[19,16]  OBJ       0.05
    x[19,16]  onehot_19  1
    x[19,16]  R590      -2.2258731252318614e-02
    x[19,16]  R591      -3.9535535354550462e-02
    x[19,16]  hard_lower  16
    x[19,16]  hard_upper  16
    x[19,17]  OBJ       0.05
    x[19,17]  onehot_19  1
    x[19,17]  R592      -2.2258731252318614e-02
    x[19,17]  R593      -3.9535535354550462e-02
    x[19,17]  hard_lower  17
    x[19,17]  hard_upper  17
    x[19,18]  OBJ       5.0000000000000010e-02
    x[19,18]  onehot_19  1
    x[19,18]  R594      -2.2258731252318614e-02
    x[19,18]  R595      -3.9535535354550462e-02
    x[19,18]  hard_lower  18
    x[19,18]  hard_upper  18
    x[19,19]  OBJ       0.05
    x[19,19]  onehot_19  1
    x[19,19]  R596      -2.2258731252318614e-02
    x[19,19]  R597      -3.9535535354550462e-02
    x[19,19]  hard_lower  19
    x[19,19]  hard_upper  19
    x[20,0]   OBJ       0.05
    x[20,0]   onehot_20  1
    x[20,0]   R602      -2.2258731252318614e-02
    x[20,0]   R603      -3.9535535354550462e-02
    x[20,1]   OBJ       0.05
    x[20,1]   onehot_20  1
    x[20,1]   R604      -2.2258731252318614e-02
    x[20,1]   R605      -3.9535535354550462e-02
    x[20,1]   hard_lower  1
    x[20,1]   hard_upper  1
    x[20,2]   OBJ       0.05
    x[20,2]   onehot_20  1
    x[20,2]   R606      -2.2258731252318614e-02
    x[20,2]   R607      -3.9535535354550462e-02
    x[20,2]   hard_lower  2
    x[20,2]   hard_upper  2
    x[20,3]   OBJ       0.05
    x[20,3]   onehot_20  1
    x[20,3]   R608      -2.2258731252318614e-02
    x[20,3]   R609      -3.9535535354550462e-02
    x[20,3]   hard_lower  3
    x[20,3]   hard_upper  3
    x[20,4]   OBJ       0.05
    x[20,4]   onehot_20  1
    x[20,4]   R610      -2.2258731252318614e-02
    x[20,4]   R611      -3.9535535354550462e-02
    x[20,4]   hard_lower  4
    x[20,4]   hard_upper  4
    x[20,5]   OBJ       0.05
    x[20,5]   onehot_20  1
    x[20,5]   R612      -2.2258731252318614e-02
    x[20,5]   R613      -3.9535535354550462e-02
    x[20,5]   hard_lower  5
    x[20,5]   hard_upper  5
    x[20,6]   OBJ       0.05
    x[20,6]   onehot_20  1
    x[20,6]   R614      -2.2258731252318614e-02
    x[20,6]   R615      -3.9535535354550462e-02
    x[20,6]   hard_lower  6
    x[20,6]   hard_upper  6
    x[20,7]   OBJ       2.4142438048713188e-18
    x[20,7]   onehot_20  1
    x[20,7]   R616      -2.2258731252318614e-02
    x[20,7]   R617      -3.9535535354550462e-02
    x[20,7]   hard_lower  7
    x[20,7]   hard_upper  7
    x[20,8]   OBJ       4.9999999999999996e-02
    x[20,8]   onehot_20  1
    x[20,8]   R618      -2.2258731252318614e-02
    x[20,8]   R619      -3.9535535354550462e-02
    x[20,8]   hard_lower  8
    x[20,8]   hard_upper  8
    x[20,9]   OBJ       4.9999999999999996e-02
    x[20,9]   onehot_20  1
    x[20,9]   R620      -2.2258731252318614e-02
    x[20,9]   R621      -3.9535535354550462e-02
    x[20,9]   hard_lower  9
    x[20,9]   hard_upper  9
    x[20,10]  OBJ       4.9999999999999996e-02
    x[20,10]  onehot_20  1
    x[20,10]  R622      -2.2258731252318614e-02
    x[20,10]  R623      -3.9535535354550462e-02
    x[20,10]  hard_lower  10
    x[20,10]  hard_upper  10
    x[20,11]  OBJ       0.05
    x[20,11]  onehot_20  1
    x[20,11]  R624      -2.2258731252318614e-02
    x[20,11]  R625      -3.9535535354550462e-02
    x[20,11]  hard_lower  11
    x[20,11]  hard_upper  11
    x[20,12]  OBJ       0.05
    x[20,12]  onehot_20  1
    x[20,12]  R626      -2.2258731252318614e-02
    x[20,12]  R627      -3.9535535354550462e-02
    x[20,12]  hard_lower  12
    x[20,12]  hard_upper  12
    x[20,13]  OBJ       0.05
    x[20,13]  onehot_20  1
    x[20,13]  R628      -2.2258731252318614e-02
    x[20,13]  R629      -3.9535535354550462e-02
    x[20,13]  hard_lower  13
    x[20,13]  hard_upper  13
    x[20,14]  OBJ       0.05
    x[20,14]  onehot_20  1
    x[20,14]  R630      -2.2258731252318614e-02
    x[20,14]  R631      -3.9535535354550462e-02
    x[20,14]  hard_lower  14
    x[20,14]  hard_upper  14
    x[20,15]  OBJ       0.05
    x[20,15]  onehot_20  1
    x[20,15]  R632      -2.2258731252318614e-02
    x[20,15]  R633      -3.9535535354550462e-02
    x[20,15]  hard_lower  15
    x[20,15]  hard_upper  15
    x[21,0]   OBJ       0.05
    x[21,0]   onehot_21  1
    x[21,0]   R638      -2.2258731252318614e-02
    x[21,0]   R639      -3.9535535354550462e-02
    x[21,1]   OBJ       5.0000000000000010e-02
    x[21,1]   onehot_21  1
    x[21,1]   R640      -2.2258731252318614e-02
    x[21,1]   R641      -3.9535535354550462e-02
    x[21,1]   hard_lower  1
    x[21,1]   hard_upper  1
    x[21,2]   OBJ       5.0000000000000010e-02
    x[21,2]   onehot_21  1
    x[21,2]   R642      -2.2258731252318614e-02
    x[21,2]   R643      -3.9535535354550462e-02
    x[21,2]   hard_lower  2
    x[21,2]   hard_upper  2
    x[21,3]   OBJ       0.05
    x[21,3]   onehot_21  1
    x[21,3]   R644      -2.2258731252318614e-02
    x[21,3]   R645      -3.9535535354550462e-02
    x[21,3]   hard_lower  3
    x[21,3]   hard_upper  3
    x[21,4]   OBJ       0.05
    x[21,4]   onehot_21  1
    x[21,4]   R646      -2.2258731252318614e-02
    x[21,4]   R647      -3.9535535354550462e-02
    x[21,4]   hard_lower  4
    x[21,4]   hard_upper  4
    x[21,5]   OBJ       0.05
    x[21,5]   onehot_21  1
    x[21,5]   R648      -2.2258731252318614e-02
    x[21,5]   R649      -3.9535535354550462e-02
    x[21,5]   hard_lower  5
    x[21,5]   hard_upper  5
    x[21,6]   OBJ       0.05
    x[21,6]   onehot_21  1
    x[21,6]   R650      -2.2258731252318614e-02
    x[21,6]   R651      -3.9535535354550462e-02
    x[21,6]   hard_lower  6
    x[21,6]   hard_upper  6
    x[21,7]   OBJ       5.0000000000000010e-02
    x[21,7]   onehot_21  1
    x[21,7]   R652      -2.2258731252318614e-02
    x[21,7]   R653      -3.9535535354550462e-02
    x[21,7]   hard_lower  7
    x[21,7]   hard_upper  7
    x[21,8]   OBJ       0.05
    x[21,8]   onehot_21  1
    x[21,8]   R654      -2.2258731252318614e-02
    x[21,8]   R655      -3.9535535354550462e-02
    x[21,8]   hard_lower  8
    x[21,8]   hard_upper  8
    x[21,9]   OBJ       3.9908909510444345e-18
    x[21,9]   onehot_21  1
    x[21,9]   R656      -2.2258731252318614e-02
    x[21,9]   R657      -3.9535535354550462e-02
    x[21,9]   hard_lower  9
    x[21,9]   hard_upper  9
    x[21,10]  OBJ       0.05
    x[21,10]  onehot_21  1
    x[21,10]  R658      -2.2258731252318614e-02
    x[21,10]  R659      -3.9535535354550462e-02
    x[21,10]  hard_lower  10
    x[21,10]  hard_upper  10
    x[21,11]  OBJ       0.05
    x[21,11]  onehot_21  1
    x[21,11]  R660      -2.2258731252318614e-02
    x[21,11]  R661      -3.9535535354550462e-02
    x[21,11]  hard_lower  11
    x[21,11]  hard_upper  11
    x[21,12]  OBJ       0.05
    x[21,12]  onehot_21  1
    x[21,12]  R662      -2.2258731252318614e-02
    x[21,12]  R663      -3.9535535354550462e-02
    x[21,12]  hard_lower  12
    x[21,12]  hard_upper  12
    x[21,13]  OBJ       0.05
    x[21,13]  onehot_21  1
    x[21,13]  R664      -2.2258731252318614e-02
    x[21,13]  R665      -3.9535535354550462e-02
    x[21,13]  hard_lower  13
    x[21,13]  hard_upper  13
    x[21,14]  OBJ       0.05
    x[21,14]  onehot_21  1
    x[21,14]  R666      -2.2258731252318614e-02
    x[21,14]  R667      -3.9535535354550462e-02
    x[21,14]  hard_lower  14
    x[21,14]  hard_upper  14
    x[21,15]  OBJ       0.05
    x[21,15]  onehot_21  1
    x[21,15]  R668      -2.2258731252318614e-02
    x[21,15]  R669      -3.9535535354550462e-02
    x[21,15]  hard_lower  15
    x[21,15]  hard_upper  15
    x[21,16]  OBJ       0.05
    x[21,16]  onehot_21  1
    x[21,16]  R670      -2.2258731252318614e-02
    x[21,16]  R671      -3.9535535354550462e-02
    x[21,16]  hard_lower  16
    x[21,16]  hard_upper  16
    x[21,17]  OBJ       0.05
    x[21,17]  onehot_21  1
    x[21,17]  R672      -2.2258731252318614e-02
    x[21,17]  R673      -3.9535535354550462e-02
    x[21,17]  hard_lower  17
    x[21,17]  hard_upper  17
    x[21,18]  OBJ       5.0000000000000010e-02
    x[21,18]  onehot_21  1
    x[21,18]  R674      -2.2258731252318614e-02
    x[21,18]  R675      -3.9535535354550462e-02
    x[21,18]  hard_lower  18
    x[21,18]  hard_upper  18
    x[21,19]  OBJ       0.05
    x[21,19]  onehot_21  1
    x[21,19]  R676      -2.2258731252318614e-02
    x[21,19]  R677      -3.9535535354550462e-02
    x[21,19]  hard_lower  19
    x[21,19]  hard_upper  19
    x[22,0]   OBJ       5.0000000000000010e-02
    x[22,0]   onehot_22  1
    x[22,0]   R682      -2.2258731252318614e-02
    x[22,0]   R683      -3.9535535354550462e-02
    x[22,1]   OBJ       5.0000000000000010e-02
    x[22,1]   onehot_22  1
    x[22,1]   R684      -2.2258731252318614e-02
    x[22,1]   R685      -3.9535535354550462e-02
    x[22,1]   hard_lower  1
    x[22,1]   hard_upper  1
    x[22,2]   OBJ       0.05
    x[22,2]   onehot_22  1
    x[22,2]   R686      -2.2258731252318614e-02
    x[22,2]   R687      -3.9535535354550462e-02
    x[22,2]   hard_lower  2
    x[22,2]   hard_upper  2
    x[22,3]   OBJ       0.05
    x[22,3]   onehot_22  1
    x[22,3]   R688      -2.2258731252318614e-02
    x[22,3]   R689      -3.9535535354550462e-02
    x[22,3]   hard_lower  3
    x[22,3]   hard_upper  3
    x[22,4]   OBJ       0.05
    x[22,4]   onehot_22  1
    x[22,4]   R690      -2.2258731252318614e-02
    x[22,4]   R691      -3.9535535354550462e-02
    x[22,4]   hard_lower  4
    x[22,4]   hard_upper  4
    x[22,5]   OBJ       0.05
    x[22,5]   onehot_22  1
    x[22,5]   R692      -2.2258731252318614e-02
    x[22,5]   R693      -3.9535535354550462e-02
    x[22,5]   hard_lower  5
    x[22,5]   hard_upper  5
    x[22,6]   OBJ       0.05
    x[22,6]   onehot_22  1
    x[22,6]   R694      -2.2258731252318614e-02
    x[22,6]   R695      -3.9535535354550462e-02
    x[22,6]   hard_lower  6
    x[22,6]   hard_upper  6
    x[22,7]   OBJ       0.05
    x[22,7]   onehot_22  1
    x[22,7]   R696      -2.2258731252318614e-02
    x[22,7]   R697      -3.9535535354550462e-02
    x[22,7]   hard_lower  7
    x[22,7]   hard_upper  7
    x[22,8]   OBJ       0.05
    x[22,8]   onehot_22  1
    x[22,8]   R698      -2.2258731252318614e-02
    x[22,8]   R699      -3.9535535354550462e-02
    x[22,8]   hard_lower  8
    x[22,8]   hard_upper  8
    x[22,9]   OBJ       5.0000000000000010e-02
    x[22,9]   onehot_22  1
    x[22,9]   R700      -2.2258731252318614e-02
    x[22,9]   R701      -3.9535535354550462e-02
    x[22,9]   hard_lower  9
    x[22,9]   hard_upper  9
    x[22,10]  OBJ       4.9270254542932435e-18
    x[22,10]  onehot_22  1
    x[22,10]  R702      -2.2258731252318614e-02
    x[22,10]  R703      -3.9535535354550462e-02
    x[22,10]  hard_lower  10
    x[22,10]  hard_upper  10
    x[22,11]  OBJ       0.05
    x[22,11]  onehot_22  1
    x[22,11]  R704      -2.2258731252318614e-02
    x[22,11]  R705      -3.9535535354550462e-02
    x[22,11]  hard_lower  11
    x[22,11]  hard_upper  11
    x[22,12]  OBJ       0.05
    x[22,12]  onehot_22  1
    x[22,12]  R706      -2.2258731252318614e-02
    x[22,12]  R707      -3.9535535354550462e-02
    x[22,12]  hard_lower  12
    x[22,12]  hard_upper  12
    x[22,13]  OBJ       0.05
    x[22,13]  onehot_22  1
    x[22,13]  R708      -2.2258731252318614e-02
    x[22,13]  R709      -3.9535535354550462e-02
    x[22,13]  hard_lower  13
    x[22,13]  hard_upper  13
    x[22,14]  OBJ       0.05
    x[22,14]  onehot_22  1
    x[22,14]  R710      -2.2258731252318614e-02
    x[22,14]  R711      -3.9535535354550462e-02
    x[22,14]  hard_lower  14
    x[22,14]  hard_upper  14
    x[22,15]  OBJ       0.05
    x[22,15]  onehot_22  1
    x[22,15]  R712      -2.2258731252318614e-02
    x[22,15]  R713      -3.9535535354550462e-02
    x[22,15]  hard_lower  15
    x[22,15]  hard_upper  15
    x[22,16]  OBJ       0.05
    x[22,16]  onehot_22  1
    x[22,16]  R714      -2.2258731252318614e-02
    x[22,16]  R715      -3.9535535354550462e-02
    x[22,16]  hard_lower  16
    x[22,16]  hard_upper  16
    x[22,17]  OBJ       0.05
    x[22,17]  onehot_22  1
    x[22,17]  R716      -2.2258731252318614e-02
    x[22,17]  R717      -3.9535535354550462e-02
    x[22,17]  hard_lower  17
    x[22,17]  hard_upper  17
    x[22,18]  OBJ       4.9999999999999996e-02
    x[22,18]  onehot_22  1
    x[22,18]  R718      -2.2258731252318614e-02
    x[22,18]  R719      -3.9535535354550462e-02
    x[22,18]  hard_lower  18
    x[22,18]  hard_upper  18
    x[22,19]  OBJ       0.05
    x[22,19]  onehot_22  1
    x[22,19]  R720      -2.2258731252318614e-02
    x[22,19]  R721      -3.9535535354550462e-02
    x[22,19]  hard_lower  19
    x[22,19]  hard_upper  19
    x[23,0]   OBJ       0.05
    x[23,0]   onehot_23  1
    x[23,0]   R726      -2.2258731252318614e-02
    x[23,0]   R727      -3.9535535354550462e-02
    x[23,1]   OBJ       4.9999999999999996e-02
    x[23,1]   onehot_23  1
    x[23,1]   R728      -2.2258731252318614e-02
    x[23,1]   R729      -3.9535535354550462e-02
    x[23,1]   hard_lower  1
    x[23,1]   hard_upper  1
    x[23,2]   OBJ       4.9999999999999996e-02
    x[23,2]   onehot_23  1
    x[23,2]   R730      -2.2258731252318614e-02
    x[23,2]   R731      -3.9535535354550462e-02
    x[23,2]   hard_lower  2
    x[23,2]   hard_upper  2
    x[23,3]   OBJ       4.9999999999999996e-02
    x[23,3]   onehot_23  1
    x[23,3]   R732      -2.2258731252318614e-02
    x[23,3]   R733      -3.9535535354550462e-02
    x[23,3]   hard_lower  3
    x[23,3]   hard_upper  3
    x[23,4]   OBJ       0.05
    x[23,4]   onehot_23  1
    x[23,4]   R734      -2.2258731252318614e-02
    x[23,4]   R735      -3.9535535354550462e-02
    x[23,4]   hard_lower  4
    x[23,4]   hard_upper  4
    x[23,5]   OBJ       4.9999999999999996e-02
    x[23,5]   onehot_23  1
    x[23,5]   R736      -2.2258731252318614e-02
    x[23,5]   R737      -3.9535535354550462e-02
    x[23,5]   hard_lower  5
    x[23,5]   hard_upper  5
    x[23,6]   OBJ       0.05
    x[23,6]   onehot_23  1
    x[23,6]   R738      -2.2258731252318614e-02
    x[23,6]   R739      -3.9535535354550462e-02
    x[23,6]   hard_lower  6
    x[23,6]   hard_upper  6
    x[23,7]   OBJ       0.05
    x[23,7]   onehot_23  1
    x[23,7]   R740      -2.2258731252318614e-02
    x[23,7]   R741      -3.9535535354550462e-02
    x[23,7]   hard_lower  7
    x[23,7]   hard_upper  7
    x[23,8]   onehot_23  1
    x[23,8]   R742      -2.2258731252318614e-02
    x[23,8]   R743      -3.9535535354550462e-02
    x[23,8]   hard_lower  8
    x[23,8]   hard_upper  8
    x[23,9]   OBJ       0.05
    x[23,9]   onehot_23  1
    x[23,9]   R744      -2.2258731252318614e-02
    x[23,9]   R745      -3.9535535354550462e-02
    x[23,9]   hard_lower  9
    x[23,9]   hard_upper  9
    x[23,10]  OBJ       0.05
    x[23,10]  onehot_23  1
    x[23,10]  R746      -2.2258731252318614e-02
    x[23,10]  R747      -3.9535535354550462e-02
    x[23,10]  hard_lower  10
    x[23,10]  hard_upper  10
    x[23,11]  OBJ       4.9999999999999996e-02
    x[23,11]  onehot_23  1
    x[23,11]  R748      -2.2258731252318614e-02
    x[23,11]  R749      -3.9535535354550462e-02
    x[23,11]  hard_lower  11
    x[23,11]  hard_upper  11
    x[23,12]  OBJ       0.05
    x[23,12]  onehot_23  1
    x[23,12]  R750      -2.2258731252318614e-02
    x[23,12]  R751      -3.9535535354550462e-02
    x[23,12]  hard_lower  12
    x[23,12]  hard_upper  12
    x[23,13]  OBJ       -5.3560038152280524e-03
    x[23,13]  onehot_23  1
    x[23,13]  R752      -2.2258731252318614e-02
    x[23,13]  R753      -3.9535535354550462e-02
    x[23,13]  hard_lower  13
    x[23,13]  hard_upper  13
    x[23,14]  OBJ       4.9999999999999996e-02
    x[23,14]  onehot_23  1
    x[23,14]  R754      -2.2258731252318614e-02
    x[23,14]  R755      -3.9535535354550462e-02
    x[23,14]  hard_lower  14
    x[23,14]  hard_upper  14
    x[23,15]  OBJ       4.9999999999999996e-02
    x[23,15]  onehot_23  1
    x[23,15]  R756      -2.2258731252318614e-02
    x[23,15]  R757      -3.9535535354550462e-02
    x[23,15]  hard_lower  15
    x[23,15]  hard_upper  15
    x[24,0]   OBJ       0.0575
    x[24,0]   onehot_24  1
    x[24,0]   R762      -2.2258731252318614e-02
    x[24,0]   R763      -3.9535535354550462e-02
    x[24,1]   OBJ       0.0575
    x[24,1]   onehot_24  1
    x[24,1]   R764      -2.2258731252318614e-02
    x[24,1]   R765      -3.9535535354550462e-02
    x[24,1]   hard_lower  1
    x[24,1]   hard_upper  1
    x[24,2]   OBJ       0.0075
    x[24,2]   onehot_24  1
    x[24,2]   R766      -2.2258731252318614e-02
    x[24,2]   R767      -3.9535535354550462e-02
    x[24,2]   hard_lower  2
    x[24,2]   hard_upper  2
    x[24,3]   OBJ       5.7499999999999996e-02
    x[24,3]   onehot_24  1
    x[24,3]   R768      -2.2258731252318614e-02
    x[24,3]   R769      -3.9535535354550462e-02
    x[24,3]   hard_lower  3
    x[24,3]   hard_upper  3
    x[24,4]   OBJ       1.0510122143484395e-02
    x[24,4]   onehot_24  1
    x[24,4]   R770      -2.2258731252318614e-02
    x[24,4]   R771      -3.9535535354550462e-02
    x[24,4]   hard_lower  4
    x[24,4]   hard_upper  4
    x[24,5]   OBJ       5.7499999999999996e-02
    x[24,5]   onehot_24  1
    x[24,5]   R772      -2.2258731252318614e-02
    x[24,5]   R773      -3.9535535354550462e-02
    x[24,5]   hard_lower  5
    x[24,5]   hard_upper  5
    x[24,6]   OBJ       0.0575
    x[24,6]   onehot_24  1
    x[24,6]   R774      -2.2258731252318614e-02
    x[24,6]   R775      -3.9535535354550462e-02
    x[24,6]   hard_lower  6
    x[24,6]   hard_upper  6
    x[24,7]   OBJ       0.0575
    x[24,7]   onehot_24  1
    x[24,7]   R776      -2.2258731252318614e-02
    x[24,7]   R777      -3.9535535354550462e-02
    x[24,7]   hard_lower  7
    x[24,7]   hard_upper  7
    x[24,8]   OBJ       -1.5874520305797293e-03
    x[24,8]   onehot_24  1
    x[24,8]   R778      -2.2258731252318614e-02
    x[24,8]   R779      -3.9535535354550462e-02
    x[24,8]   hard_lower  8
    x[24,8]   hard_upper  8
    x[25,0]   OBJ       0.05
    x[25,0]   onehot_25  1
    x[25,0]   R784      -2.2258731252318614e-02
    x[25,0]   R785      -3.9535535354550462e-02
    x[25,1]   OBJ       0.05
    x[25,1]   onehot_25  1
    x[25,1]   R786      -2.2258731252318614e-02
    x[25,1]   R787      -3.9535535354550462e-02
    x[25,1]   hard_lower  1
    x[25,1]   hard_upper  1
    x[25,2]   OBJ       0.05
    x[25,2]   onehot_25  1
    x[25,2]   R788      -2.2258731252318614e-02
    x[25,2]   R789      -3.9535535354550462e-02
    x[25,2]   hard_lower  2
    x[25,2]   hard_upper  2
    x[25,3]   OBJ       0.05
    x[25,3]   onehot_25  1
    x[25,3]   R790      -2.2258731252318614e-02
    x[25,3]   R791      -3.9535535354550462e-02
    x[25,3]   hard_lower  3
    x[25,3]   hard_upper  3
    x[25,4]   OBJ       0.05
    x[25,4]   onehot_25  1
    x[25,4]   R792      -2.2258731252318614e-02
    x[25,4]   R793      -3.9535535354550462e-02
    x[25,4]   hard_lower  4
    x[25,4]   hard_upper  4
    x[25,5]   OBJ       0.05
    x[25,5]   onehot_25  1
    x[25,5]   R794      -2.2258731252318614e-02
    x[25,5]   R795      -3.9535535354550462e-02
    x[25,5]   hard_lower  5
    x[25,5]   hard_upper  5
    x[25,6]   OBJ       0.05
    x[25,6]   onehot_25  1
    x[25,6]   R796      -2.2258731252318614e-02
    x[25,6]   R797      -3.9535535354550462e-02
    x[25,6]   hard_lower  6
    x[25,6]   hard_upper  6
    x[25,7]   OBJ       2.4142438048713188e-18
    x[25,7]   onehot_25  1
    x[25,7]   R798      -2.2258731252318614e-02
    x[25,7]   R799      -3.9535535354550462e-02
    x[25,7]   hard_lower  7
    x[25,7]   hard_upper  7
    x[25,8]   OBJ       4.9999999999999996e-02
    x[25,8]   onehot_25  1
    x[25,8]   R800      -2.2258731252318614e-02
    x[25,8]   R801      -3.9535535354550462e-02
    x[25,8]   hard_lower  8
    x[25,8]   hard_upper  8
    x[25,9]   OBJ       4.9999999999999996e-02
    x[25,9]   onehot_25  1
    x[25,9]   R802      -2.2258731252318614e-02
    x[25,9]   R803      -3.9535535354550462e-02
    x[25,9]   hard_lower  9
    x[25,9]   hard_upper  9
    x[25,10]  OBJ       4.9999999999999996e-02
    x[25,10]  onehot_25  1
    x[25,10]  R804      -2.2258731252318614e-02
    x[25,10]  R805      -3.9535535354550462e-02
    x[25,10]  hard_lower  10
    x[25,10]  hard_upper  10
    x[25,11]  OBJ       0.05
    x[25,11]  onehot_25  1
    x[25,11]  R806      -2.2258731252318614e-02
    x[25,11]  R807      -3.9535535354550462e-02
    x[25,11]  hard_lower  11
    x[25,11]  hard_upper  11
    x[25,12]  OBJ       0.05
    x[25,12]  onehot_25  1
    x[25,12]  R808      -2.2258731252318614e-02
    x[25,12]  R809      -3.9535535354550462e-02
    x[25,12]  hard_lower  12
    x[25,12]  hard_upper  12
    x[25,13]  OBJ       0.05
    x[25,13]  onehot_25  1
    x[25,13]  R810      -2.2258731252318614e-02
    x[25,13]  R811      -3.9535535354550462e-02
    x[25,13]  hard_lower  13
    x[25,13]  hard_upper  13
    x[25,14]  OBJ       0.05
    x[25,14]  onehot_25  1
    x[25,14]  R812      -2.2258731252318614e-02
    x[25,14]  R813      -3.9535535354550462e-02
    x[25,14]  hard_lower  14
    x[25,14]  hard_upper  14
    x[25,15]  OBJ       0.05
    x[25,15]  onehot_25  1
    x[25,15]  R814      -2.2258731252318614e-02
    x[25,15]  R815      -3.9535535354550462e-02
    x[25,15]  hard_lower  15
    x[25,15]  hard_upper  15
    x[26,0]   OBJ       0.05
    x[26,0]   onehot_26  1
    x[26,0]   R820      -2.2258731252318614e-02
    x[26,0]   R821      -3.9535535354550462e-02
    x[26,1]   OBJ       4.9999999999999996e-02
    x[26,1]   onehot_26  1
    x[26,1]   R822      -2.2258731252318614e-02
    x[26,1]   R823      -3.9535535354550462e-02
    x[26,1]   hard_lower  1
    x[26,1]   hard_upper  1
    x[26,2]   OBJ       4.9999999999999996e-02
    x[26,2]   onehot_26  1
    x[26,2]   R824      -2.2258731252318614e-02
    x[26,2]   R825      -3.9535535354550462e-02
    x[26,2]   hard_lower  2
    x[26,2]   hard_upper  2
    x[26,3]   OBJ       4.9999999999999996e-02
    x[26,3]   onehot_26  1
    x[26,3]   R826      -2.2258731252318614e-02
    x[26,3]   R827      -3.9535535354550462e-02
    x[26,3]   hard_lower  3
    x[26,3]   hard_upper  3
    x[26,4]   OBJ       0.05
    x[26,4]   onehot_26  1
    x[26,4]   R828      -2.2258731252318614e-02
    x[26,4]   R829      -3.9535535354550462e-02
    x[26,4]   hard_lower  4
    x[26,4]   hard_upper  4
    x[26,5]   OBJ       4.9999999999999996e-02
    x[26,5]   onehot_26  1
    x[26,5]   R830      -2.2258731252318614e-02
    x[26,5]   R831      -3.9535535354550462e-02
    x[26,5]   hard_lower  5
    x[26,5]   hard_upper  5
    x[26,6]   OBJ       0.05
    x[26,6]   onehot_26  1
    x[26,6]   R832      -2.2258731252318614e-02
    x[26,6]   R833      -3.9535535354550462e-02
    x[26,6]   hard_lower  6
    x[26,6]   hard_upper  6
    x[26,7]   OBJ       0.05
    x[26,7]   onehot_26  1
    x[26,7]   R834      -2.2258731252318614e-02
    x[26,7]   R835      -3.9535535354550462e-02
    x[26,7]   hard_lower  7
    x[26,7]   hard_upper  7
    x[26,8]   onehot_26  1
    x[26,8]   R836      -2.2258731252318614e-02
    x[26,8]   R837      -3.9535535354550462e-02
    x[26,8]   hard_lower  8
    x[26,8]   hard_upper  8
    x[26,9]   OBJ       0.05
    x[26,9]   onehot_26  1
    x[26,9]   R838      -2.2258731252318614e-02
    x[26,9]   R839      -3.9535535354550462e-02
    x[26,9]   hard_lower  9
    x[26,9]   hard_upper  9
    x[26,10]  OBJ       0.05
    x[26,10]  onehot_26  1
    x[26,10]  R840      -2.2258731252318614e-02
    x[26,10]  R841      -3.9535535354550462e-02
    x[26,10]  hard_lower  10
    x[26,10]  hard_upper  10
    x[26,11]  OBJ       4.9999999999999996e-02
    x[26,11]  onehot_26  1
    x[26,11]  R842      -2.2258731252318614e-02
    x[26,11]  R843      -3.9535535354550462e-02
    x[26,11]  hard_lower  11
    x[26,11]  hard_upper  11
    x[26,12]  OBJ       0.05
    x[26,12]  onehot_26  1
    x[26,12]  R844      -2.2258731252318614e-02
    x[26,12]  R845      -3.9535535354550462e-02
    x[26,12]  hard_lower  12
    x[26,12]  hard_upper  12
    x[26,13]  OBJ       -1.3478440126425909e-02
    x[26,13]  onehot_26  1
    x[26,13]  R846      -2.2258731252318614e-02
    x[26,13]  R847      -3.9535535354550462e-02
    x[26,13]  hard_lower  13
    x[26,13]  hard_upper  13
    x[26,14]  OBJ       4.9999999999999996e-02
    x[26,14]  onehot_26  1
    x[26,14]  R848      -2.2258731252318614e-02
    x[26,14]  R849      -3.9535535354550462e-02
    x[26,14]  hard_lower  14
    x[26,14]  hard_upper  14
    x[26,15]  OBJ       4.9999999999999996e-02
    x[26,15]  onehot_26  1
    x[26,15]  R850      -2.2258731252318614e-02
    x[26,15]  R851      -3.9535535354550462e-02
    x[26,15]  hard_lower  15
    x[26,15]  hard_upper  15
    x[27,0]   OBJ       0.05
    x[27,0]   onehot_27  1
    x[27,0]   R856      -2.2258731252318614e-02
    x[27,0]   R857      -3.9535535354550462e-02
    x[27,1]   OBJ       5.0000000000000010e-02
    x[27,1]   onehot_27  1
    x[27,1]   R858      -2.2258731252318614e-02
    x[27,1]   R859      -3.9535535354550462e-02
    x[27,1]   hard_lower  1
    x[27,1]   hard_upper  1
    x[27,2]   OBJ       5.0000000000000010e-02
    x[27,2]   onehot_27  1
    x[27,2]   R860      -2.2258731252318614e-02
    x[27,2]   R861      -3.9535535354550462e-02
    x[27,2]   hard_lower  2
    x[27,2]   hard_upper  2
    x[27,3]   OBJ       0.05
    x[27,3]   onehot_27  1
    x[27,3]   R862      -2.2258731252318614e-02
    x[27,3]   R863      -3.9535535354550462e-02
    x[27,3]   hard_lower  3
    x[27,3]   hard_upper  3
    x[27,4]   OBJ       0.05
    x[27,4]   onehot_27  1
    x[27,4]   R864      -2.2258731252318614e-02
    x[27,4]   R865      -3.9535535354550462e-02
    x[27,4]   hard_lower  4
    x[27,4]   hard_upper  4
    x[27,5]   OBJ       0.05
    x[27,5]   onehot_27  1
    x[27,5]   R866      -2.2258731252318614e-02
    x[27,5]   R867      -3.9535535354550462e-02
    x[27,5]   hard_lower  5
    x[27,5]   hard_upper  5
    x[27,6]   OBJ       0.05
    x[27,6]   onehot_27  1
    x[27,6]   R868      -2.2258731252318614e-02
    x[27,6]   R869      -3.9535535354550462e-02
    x[27,6]   hard_lower  6
    x[27,6]   hard_upper  6
    x[27,7]   OBJ       5.0000000000000010e-02
    x[27,7]   onehot_27  1
    x[27,7]   R870      -2.2258731252318614e-02
    x[27,7]   R871      -3.9535535354550462e-02
    x[27,7]   hard_lower  7
    x[27,7]   hard_upper  7
    x[27,8]   OBJ       0.05
    x[27,8]   onehot_27  1
    x[27,8]   R872      -2.2258731252318614e-02
    x[27,8]   R873      -3.9535535354550462e-02
    x[27,8]   hard_lower  8
    x[27,8]   hard_upper  8
    x[27,9]   OBJ       3.9908909510444345e-18
    x[27,9]   onehot_27  1
    x[27,9]   R874      -2.2258731252318614e-02
    x[27,9]   R875      -3.9535535354550462e-02
    x[27,9]   hard_lower  9
    x[27,9]   hard_upper  9
    x[27,10]  OBJ       0.05
    x[27,10]  onehot_27  1
    x[27,10]  R876      -2.2258731252318614e-02
    x[27,10]  R877      -3.9535535354550462e-02
    x[27,10]  hard_lower  10
    x[27,10]  hard_upper  10
    x[27,11]  OBJ       0.05
    x[27,11]  onehot_27  1
    x[27,11]  R878      -2.2258731252318614e-02
    x[27,11]  R879      -3.9535535354550462e-02
    x[27,11]  hard_lower  11
    x[27,11]  hard_upper  11
    x[27,12]  OBJ       0.05
    x[27,12]  onehot_27  1
    x[27,12]  R880      -2.2258731252318614e-02
    x[27,12]  R881      -3.9535535354550462e-02
    x[27,12]  hard_lower  12
    x[27,12]  hard_upper  12
    x[27,13]  OBJ       0.05
    x[27,13]  onehot_27  1
    x[27,13]  R882      -2.2258731252318614e-02
    x[27,13]  R883      -3.9535535354550462e-02
    x[27,13]  hard_lower  13
    x[27,13]  hard_upper  13
    x[27,14]  OBJ       0.05
    x[27,14]  onehot_27  1
    x[27,14]  R884      -2.2258731252318614e-02
    x[27,14]  R885      -3.9535535354550462e-02
    x[27,14]  hard_lower  14
    x[27,14]  hard_upper  14
    x[27,15]  OBJ       0.05
    x[27,15]  onehot_27  1
    x[27,15]  R886      -2.2258731252318614e-02
    x[27,15]  R887      -3.9535535354550462e-02
    x[27,15]  hard_lower  15
    x[27,15]  hard_upper  15
    x[27,16]  OBJ       0.05
    x[27,16]  onehot_27  1
    x[27,16]  R888      -2.2258731252318614e-02
    x[27,16]  R889      -3.9535535354550462e-02
    x[27,16]  hard_lower  16
    x[27,16]  hard_upper  16
    x[27,17]  OBJ       0.05
    x[27,17]  onehot_27  1
    x[27,17]  R890      -2.2258731252318614e-02
    x[27,17]  R891      -3.9535535354550462e-02
    x[27,17]  hard_lower  17
    x[27,17]  hard_upper  17
    x[27,18]  OBJ       5.0000000000000010e-02
    x[27,18]  onehot_27  1
    x[27,18]  R892      -2.2258731252318614e-02
    x[27,18]  R893      -3.9535535354550462e-02
    x[27,18]  hard_lower  18
    x[27,18]  hard_upper  18
    x[27,19]  OBJ       0.05
    x[27,19]  onehot_27  1
    x[27,19]  R894      -2.2258731252318614e-02
    x[27,19]  R895      -3.9535535354550462e-02
    x[27,19]  hard_lower  19
    x[27,19]  hard_upper  19
    x[28,0]   OBJ       0.05
    x[28,0]   onehot_28  1
    x[28,0]   R900      -2.2258731252318614e-02
    x[28,0]   R901      -3.9535535354550462e-02
    x[28,1]   OBJ       0.05
    x[28,1]   onehot_28  1
    x[28,1]   R902      -2.2258731252318614e-02
    x[28,1]   R903      -3.9535535354550462e-02
    x[28,1]   hard_lower  1
    x[28,1]   hard_upper  1
    x[28,2]   OBJ       0.05
    x[28,2]   onehot_28  1
    x[28,2]   R904      -2.2258731252318614e-02
    x[28,2]   R905      -3.9535535354550462e-02
    x[28,2]   hard_lower  2
    x[28,2]   hard_upper  2
    x[28,3]   OBJ       0.05
    x[28,3]   onehot_28  1
    x[28,3]   R906      -2.2258731252318614e-02
    x[28,3]   R907      -3.9535535354550462e-02
    x[28,3]   hard_lower  3
    x[28,3]   hard_upper  3
    x[28,4]   OBJ       0.05
    x[28,4]   onehot_28  1
    x[28,4]   R908      -2.2258731252318614e-02
    x[28,4]   R909      -3.9535535354550462e-02
    x[28,4]   hard_lower  4
    x[28,4]   hard_upper  4
    x[28,5]   OBJ       0.05
    x[28,5]   onehot_28  1
    x[28,5]   R910      -2.2258731252318614e-02
    x[28,5]   R911      -3.9535535354550462e-02
    x[28,5]   hard_lower  5
    x[28,5]   hard_upper  5
    x[28,6]   OBJ       0.05
    x[28,6]   onehot_28  1
    x[28,6]   R912      -2.2258731252318614e-02
    x[28,6]   R913      -3.9535535354550462e-02
    x[28,6]   hard_lower  6
    x[28,6]   hard_upper  6
    x[28,7]   OBJ       2.4142438048713188e-18
    x[28,7]   onehot_28  1
    x[28,7]   R914      -2.2258731252318614e-02
    x[28,7]   R915      -3.9535535354550462e-02
    x[28,7]   hard_lower  7
    x[28,7]   hard_upper  7
    x[28,8]   OBJ       4.9999999999999996e-02
    x[28,8]   onehot_28  1
    x[28,8]   R916      -2.2258731252318614e-02
    x[28,8]   R917      -3.9535535354550462e-02
    x[28,8]   hard_lower  8
    x[28,8]   hard_upper  8
    x[28,9]   OBJ       4.9999999999999996e-02
    x[28,9]   onehot_28  1
    x[28,9]   R918      -2.2258731252318614e-02
    x[28,9]   R919      -3.9535535354550462e-02
    x[28,9]   hard_lower  9
    x[28,9]   hard_upper  9
    x[28,10]  OBJ       4.9999999999999996e-02
    x[28,10]  onehot_28  1
    x[28,10]  R920      -2.2258731252318614e-02
    x[28,10]  R921      -3.9535535354550462e-02
    x[28,10]  hard_lower  10
    x[28,10]  hard_upper  10
    x[28,11]  OBJ       0.05
    x[28,11]  onehot_28  1
    x[28,11]  R922      -2.2258731252318614e-02
    x[28,11]  R923      -3.9535535354550462e-02
    x[28,11]  hard_lower  11
    x[28,11]  hard_upper  11
    x[28,12]  OBJ       0.05
    x[28,12]  onehot_28  1
    x[28,12]  R924      -2.2258731252318614e-02
    x[28,12]  R925      -3.9535535354550462e-02
    x[28,12]  hard_lower  12
    x[28,12]  hard_upper  12
    x[28,13]  OBJ       0.05
    x[28,13]  onehot_28  1
    x[28,13]  R926      -2.2258731252318614e-02
    x[28,13]  R927      -3.9535535354550462e-02
    x[28,13]  hard_lower  13
    x[28,13]  hard_upper  13
    x[28,14]  OBJ       0.05
    x[28,14]  onehot_28  1
    x[28,14]  R928      -2.2258731252318614e-02
    x[28,14]  R929      -3.9535535354550462e-02
    x[28,14]  hard_lower  14
    x[28,14]  hard_upper  14
    x[28,15]  OBJ       0.05
    x[28,15]  onehot_28  1
    x[28,15]  R930      -2.2258731252318614e-02
    x[28,15]  R931      -3.9535535354550462e-02
    x[28,15]  hard_lower  15
    x[28,15]  hard_upper  15
    x[29,0]   OBJ       0.05
    x[29,0]   onehot_29  1
    x[29,0]   R936      -2.2258731252318614e-02
    x[29,0]   R937      -3.9535535354550462e-02
    x[29,1]   OBJ       0.05
    x[29,1]   onehot_29  1
    x[29,1]   R938      -2.2258731252318614e-02
    x[29,1]   R939      -3.9535535354550462e-02
    x[29,1]   hard_lower  1
    x[29,1]   hard_upper  1
    x[29,2]   OBJ       0.05
    x[29,2]   onehot_29  1
    x[29,2]   R940      -2.2258731252318614e-02
    x[29,2]   R941      -3.9535535354550462e-02
    x[29,2]   hard_lower  2
    x[29,2]   hard_upper  2
    x[29,3]   OBJ       0.05
    x[29,3]   onehot_29  1
    x[29,3]   R942      -2.2258731252318614e-02
    x[29,3]   R943      -3.9535535354550462e-02
    x[29,3]   hard_lower  3
    x[29,3]   hard_upper  3
    x[29,4]   OBJ       0.05
    x[29,4]   onehot_29  1
    x[29,4]   R944      -2.2258731252318614e-02
    x[29,4]   R945      -3.9535535354550462e-02
    x[29,4]   hard_lower  4
    x[29,4]   hard_upper  4
    x[29,5]   OBJ       0.05
    x[29,5]   onehot_29  1
    x[29,5]   R946      -2.2258731252318614e-02
    x[29,5]   R947      -3.9535535354550462e-02
    x[29,5]   hard_lower  5
    x[29,5]   hard_upper  5
    x[29,6]   OBJ       0.05
    x[29,6]   onehot_29  1
    x[29,6]   R948      -2.2258731252318614e-02
    x[29,6]   R949      -3.9535535354550462e-02
    x[29,6]   hard_lower  6
    x[29,6]   hard_upper  6
    x[29,7]   OBJ       2.4142438048713188e-18
    x[29,7]   onehot_29  1
    x[29,7]   R950      -2.2258731252318614e-02
    x[29,7]   R951      -3.9535535354550462e-02
    x[29,7]   hard_lower  7
    x[29,7]   hard_upper  7
    x[29,8]   OBJ       4.9999999999999996e-02
    x[29,8]   onehot_29  1
    x[29,8]   R952      -2.2258731252318614e-02
    x[29,8]   R953      -3.9535535354550462e-02
    x[29,8]   hard_lower  8
    x[29,8]   hard_upper  8
    x[29,9]   OBJ       4.9999999999999996e-02
    x[29,9]   onehot_29  1
    x[29,9]   R954      -2.2258731252318614e-02
    x[29,9]   R955      -3.9535535354550462e-02
    x[29,9]   hard_lower  9
    x[29,9]   hard_upper  9
    x[29,10]  OBJ       4.9999999999999996e-02
    x[29,10]  onehot_29  1
    x[29,10]  R956      -2.2258731252318614e-02
    x[29,10]  R957      -3.9535535354550462e-02
    x[29,10]  hard_lower  10
    x[29,10]  hard_upper  10
    x[29,11]  OBJ       0.05
    x[29,11]  onehot_29  1
    x[29,11]  R958      -2.2258731252318614e-02
    x[29,11]  R959      -3.9535535354550462e-02
    x[29,11]  hard_lower  11
    x[29,11]  hard_upper  11
    x[29,12]  OBJ       0.05
    x[29,12]  onehot_29  1
    x[29,12]  R960      -2.2258731252318614e-02
    x[29,12]  R961      -3.9535535354550462e-02
    x[29,12]  hard_lower  12
    x[29,12]  hard_upper  12
    x[29,13]  OBJ       0.05
    x[29,13]  onehot_29  1
    x[29,13]  R962      -2.2258731252318614e-02
    x[29,13]  R963      -3.9535535354550462e-02
    x[29,13]  hard_lower  13
    x[29,13]  hard_upper  13
    x[29,14]  OBJ       0.05
    x[29,14]  onehot_29  1
    x[29,14]  R964      -2.2258731252318614e-02
    x[29,14]  R965      -3.9535535354550462e-02
    x[29,14]  hard_lower  14
    x[29,14]  hard_upper  14
    x[29,15]  OBJ       0.05
    x[29,15]  onehot_29  1
    x[29,15]  R966      -2.2258731252318614e-02
    x[29,15]  R967      -3.9535535354550462e-02
    x[29,15]  hard_lower  15
    x[29,15]  hard_upper  15
    x[30,0]   OBJ       0.05
    x[30,0]   onehot_30  1
    x[30,0]   R972      -2.2258731252318614e-02
    x[30,0]   R973      -3.9535535354550462e-02
    x[30,1]   OBJ       4.9999999999999996e-02
    x[30,1]   onehot_30  1
    x[30,1]   R974      -2.2258731252318614e-02
    x[30,1]   R975      -3.9535535354550462e-02
    x[30,1]   hard_lower  1
    x[30,1]   hard_upper  1
    x[30,2]   OBJ       0.05
    x[30,2]   onehot_30  1
    x[30,2]   R976      -2.2258731252318614e-02
    x[30,2]   R977      -3.9535535354550462e-02
    x[30,2]   hard_lower  2
    x[30,2]   hard_upper  2
    x[30,3]   OBJ       4.9999999999999996e-02
    x[30,3]   onehot_30  1
    x[30,3]   R978      -2.2258731252318614e-02
    x[30,3]   R979      -3.9535535354550462e-02
    x[30,3]   hard_lower  3
    x[30,3]   hard_upper  3
    x[30,4]   OBJ       0.05
    x[30,4]   onehot_30  1
    x[30,4]   R980      -2.2258731252318614e-02
    x[30,4]   R981      -3.9535535354550462e-02
    x[30,4]   hard_lower  4
    x[30,4]   hard_upper  4
    x[30,5]   OBJ       0.05
    x[30,5]   onehot_30  1
    x[30,5]   R982      -2.2258731252318614e-02
    x[30,5]   R983      -3.9535535354550462e-02
    x[30,5]   hard_lower  5
    x[30,5]   hard_upper  5
    x[30,6]   OBJ       0.05
    x[30,6]   onehot_30  1
    x[30,6]   R984      -2.2258731252318614e-02
    x[30,6]   R985      -3.9535535354550462e-02
    x[30,6]   hard_lower  6
    x[30,6]   hard_upper  6
    x[30,7]   OBJ       0.05
    x[30,7]   onehot_30  1
    x[30,7]   R986      -2.2258731252318614e-02
    x[30,7]   R987      -3.9535535354550462e-02
    x[30,7]   hard_lower  7
    x[30,7]   hard_upper  7
    x[30,8]   OBJ       0.05
    x[30,8]   onehot_30  1
    x[30,8]   R988      -2.2258731252318614e-02
    x[30,8]   R989      -3.9535535354550462e-02
    x[30,8]   hard_lower  8
    x[30,8]   hard_upper  8
    x[30,9]   OBJ       0.05
    x[30,9]   onehot_30  1
    x[30,9]   R990      -2.2258731252318614e-02
    x[30,9]   R991      -3.9535535354550462e-02
    x[30,9]   hard_lower  9
    x[30,9]   hard_upper  9
    x[30,10]  OBJ       0.05
    x[30,10]  onehot_30  1
    x[30,10]  R992      -2.2258731252318614e-02
    x[30,10]  R993      -3.9535535354550462e-02
    x[30,10]  hard_lower  10
    x[30,10]  hard_upper  10
    x[30,11]  OBJ       2.9808489010463287e-18
    x[30,11]  onehot_30  1
    x[30,11]  R994      -2.2258731252318614e-02
    x[30,11]  R995      -3.9535535354550462e-02
    x[30,11]  hard_lower  11
    x[30,11]  hard_upper  11
    x[30,12]  OBJ       4.9999999999999996e-02
    x[30,12]  onehot_30  1
    x[30,12]  R996      -2.2258731252318614e-02
    x[30,12]  R997      -3.9535535354550462e-02
    x[30,12]  hard_lower  12
    x[30,12]  hard_upper  12
    x[30,13]  OBJ       0.05
    x[30,13]  onehot_30  1
    x[30,13]  R998      -2.2258731252318614e-02
    x[30,13]  R999      -3.9535535354550462e-02
    x[30,13]  hard_lower  13
    x[30,13]  hard_upper  13
    x[30,14]  OBJ       0.05
    x[30,14]  onehot_30  1
    x[30,14]  R1000     -2.2258731252318614e-02
    x[30,14]  R1001     -3.9535535354550462e-02
    x[30,14]  hard_lower  14
    x[30,14]  hard_upper  14
    x[30,15]  OBJ       0.05
    x[30,15]  onehot_30  1
    x[30,15]  R1002     -2.2258731252318614e-02
    x[30,15]  R1003     -3.9535535354550462e-02
    x[30,15]  hard_lower  15
    x[30,15]  hard_upper  15
    x[30,16]  OBJ       0.05
    x[30,16]  onehot_30  1
    x[30,16]  R1004     -2.2258731252318614e-02
    x[30,16]  R1005     -3.9535535354550462e-02
    x[30,16]  hard_lower  16
    x[30,16]  hard_upper  16
    x[30,17]  OBJ       0.05
    x[30,17]  onehot_30  1
    x[30,17]  R1006     -2.2258731252318614e-02
    x[30,17]  R1007     -3.9535535354550462e-02
    x[30,17]  hard_lower  17
    x[30,17]  hard_upper  17
    x[30,18]  OBJ       4.9999999999999996e-02
    x[30,18]  onehot_30  1
    x[30,18]  R1008     -2.2258731252318614e-02
    x[30,18]  R1009     -3.9535535354550462e-02
    x[30,18]  hard_lower  18
    x[30,18]  hard_upper  18
    x[30,19]  OBJ       0.05
    x[30,19]  onehot_30  1
    x[30,19]  R1010     -2.2258731252318614e-02
    x[30,19]  R1011     -3.9535535354550462e-02
    x[30,19]  hard_lower  19
    x[30,19]  hard_upper  19
    x[30,20]  OBJ       0.05
    x[30,20]  onehot_30  1
    x[30,20]  R1012     -2.2258731252318614e-02
    x[30,20]  R1013     -3.9535535354550462e-02
    x[30,20]  hard_lower  20
    x[30,20]  hard_upper  20
    x[31,0]   OBJ       0.05
    x[31,0]   onehot_31  1
    x[31,0]   R1018     -2.2258731252318614e-02
    x[31,0]   R1019     -3.9535535354550462e-02
    x[31,1]   OBJ       0.05
    x[31,1]   onehot_31  1
    x[31,1]   R1020     -2.2258731252318614e-02
    x[31,1]   R1021     -3.9535535354550462e-02
    x[31,1]   hard_lower  1
    x[31,1]   hard_upper  1
    x[31,2]   OBJ       0.05
    x[31,2]   onehot_31  1
    x[31,2]   R1022     -2.2258731252318614e-02
    x[31,2]   R1023     -3.9535535354550462e-02
    x[31,2]   hard_lower  2
    x[31,2]   hard_upper  2
    x[31,3]   OBJ       0.05
    x[31,3]   onehot_31  1
    x[31,3]   R1024     -2.2258731252318614e-02
    x[31,3]   R1025     -3.9535535354550462e-02
    x[31,3]   hard_lower  3
    x[31,3]   hard_upper  3
    x[31,4]   OBJ       0.05
    x[31,4]   onehot_31  1
    x[31,4]   R1026     -2.2258731252318614e-02
    x[31,4]   R1027     -3.9535535354550462e-02
    x[31,4]   hard_lower  4
    x[31,4]   hard_upper  4
    x[31,5]   OBJ       0.05
    x[31,5]   onehot_31  1
    x[31,5]   R1028     -2.2258731252318614e-02
    x[31,5]   R1029     -3.9535535354550462e-02
    x[31,5]   hard_lower  5
    x[31,5]   hard_upper  5
    x[31,6]   OBJ       0.05
    x[31,6]   onehot_31  1
    x[31,6]   R1030     -2.2258731252318614e-02
    x[31,6]   R1031     -3.9535535354550462e-02
    x[31,6]   hard_lower  6
    x[31,6]   hard_upper  6
    x[31,7]   OBJ       2.4142438048713188e-18
    x[31,7]   onehot_31  1
    x[31,7]   R1032     -2.2258731252318614e-02
    x[31,7]   R1033     -3.9535535354550462e-02
    x[31,7]   hard_lower  7
    x[31,7]   hard_upper  7
    x[31,8]   OBJ       4.9999999999999996e-02
    x[31,8]   onehot_31  1
    x[31,8]   R1034     -2.2258731252318614e-02
    x[31,8]   R1035     -3.9535535354550462e-02
    x[31,8]   hard_lower  8
    x[31,8]   hard_upper  8
    x[31,9]   OBJ       4.9999999999999996e-02
    x[31,9]   onehot_31  1
    x[31,9]   R1036     -2.2258731252318614e-02
    x[31,9]   R1037     -3.9535535354550462e-02
    x[31,9]   hard_lower  9
    x[31,9]   hard_upper  9
    x[31,10]  OBJ       4.9999999999999996e-02
    x[31,10]  onehot_31  1
    x[31,10]  R1038     -2.2258731252318614e-02
    x[31,10]  R1039     -3.9535535354550462e-02
    x[31,10]  hard_lower  10
    x[31,10]  hard_upper  10
    x[31,11]  OBJ       0.05
    x[31,11]  onehot_31  1
    x[31,11]  R1040     -2.2258731252318614e-02
    x[31,11]  R1041     -3.9535535354550462e-02
    x[31,11]  hard_lower  11
    x[31,11]  hard_upper  11
    x[31,12]  OBJ       0.05
    x[31,12]  onehot_31  1
    x[31,12]  R1042     -2.2258731252318614e-02
    x[31,12]  R1043     -3.9535535354550462e-02
    x[31,12]  hard_lower  12
    x[31,12]  hard_upper  12
    x[31,13]  OBJ       0.05
    x[31,13]  onehot_31  1
    x[31,13]  R1044     -2.2258731252318614e-02
    x[31,13]  R1045     -3.9535535354550462e-02
    x[31,13]  hard_lower  13
    x[31,13]  hard_upper  13
    x[31,14]  OBJ       0.05
    x[31,14]  onehot_31  1
    x[31,14]  R1046     -2.2258731252318614e-02
    x[31,14]  R1047     -3.9535535354550462e-02
    x[31,14]  hard_lower  14
    x[31,14]  hard_upper  14
    x[31,15]  OBJ       0.05
    x[31,15]  onehot_31  1
    x[31,15]  R1048     -2.2258731252318614e-02
    x[31,15]  R1049     -3.9535535354550462e-02
    x[31,15]  hard_lower  15
    x[31,15]  hard_upper  15
    x[32,0]   OBJ       0.05
    x[32,0]   onehot_32  1
    x[32,0]   R1054     -2.2258731252318614e-02
    x[32,0]   R1055     -3.9535535354550462e-02
    x[32,1]   OBJ       4.9999999999999996e-02
    x[32,1]   onehot_32  1
    x[32,1]   R1056     -2.2258731252318614e-02
    x[32,1]   R1057     -3.9535535354550462e-02
    x[32,1]   hard_lower  1
    x[32,1]   hard_upper  1
    x[32,2]   OBJ       4.9999999999999996e-02
    x[32,2]   onehot_32  1
    x[32,2]   R1058     -2.2258731252318614e-02
    x[32,2]   R1059     -3.9535535354550462e-02
    x[32,2]   hard_lower  2
    x[32,2]   hard_upper  2
    x[32,3]   OBJ       4.9999999999999996e-02
    x[32,3]   onehot_32  1
    x[32,3]   R1060     -2.2258731252318614e-02
    x[32,3]   R1061     -3.9535535354550462e-02
    x[32,3]   hard_lower  3
    x[32,3]   hard_upper  3
    x[32,4]   OBJ       0.05
    x[32,4]   onehot_32  1
    x[32,4]   R1062     -2.2258731252318614e-02
    x[32,4]   R1063     -3.9535535354550462e-02
    x[32,4]   hard_lower  4
    x[32,4]   hard_upper  4
    x[32,5]   OBJ       4.9999999999999996e-02
    x[32,5]   onehot_32  1
    x[32,5]   R1064     -2.2258731252318614e-02
    x[32,5]   R1065     -3.9535535354550462e-02
    x[32,5]   hard_lower  5
    x[32,5]   hard_upper  5
    x[32,6]   OBJ       0.05
    x[32,6]   onehot_32  1
    x[32,6]   R1066     -2.2258731252318614e-02
    x[32,6]   R1067     -3.9535535354550462e-02
    x[32,6]   hard_lower  6
    x[32,6]   hard_upper  6
    x[32,7]   OBJ       0.05
    x[32,7]   onehot_32  1
    x[32,7]   R1068     -2.2258731252318614e-02
    x[32,7]   R1069     -3.9535535354550462e-02
    x[32,7]   hard_lower  7
    x[32,7]   hard_upper  7
    x[32,8]   onehot_32  1
    x[32,8]   R1070     -2.2258731252318614e-02
    x[32,8]   R1071     -3.9535535354550462e-02
    x[32,8]   hard_lower  8
    x[32,8]   hard_upper  8
    x[32,9]   OBJ       0.05
    x[32,9]   onehot_32  1
    x[32,9]   R1072     -2.2258731252318614e-02
    x[32,9]   R1073     -3.9535535354550462e-02
    x[32,9]   hard_lower  9
    x[32,9]   hard_upper  9
    x[32,10]  OBJ       0.05
    x[32,10]  onehot_32  1
    x[32,10]  R1074     -2.2258731252318614e-02
    x[32,10]  R1075     -3.9535535354550462e-02
    x[32,10]  hard_lower  10
    x[32,10]  hard_upper  10
    x[32,11]  OBJ       4.9999999999999996e-02
    x[32,11]  onehot_32  1
    x[32,11]  R1076     -2.2258731252318614e-02
    x[32,11]  R1077     -3.9535535354550462e-02
    x[32,11]  hard_lower  11
    x[32,11]  hard_upper  11
    x[32,12]  OBJ       0.05
    x[32,12]  onehot_32  1
    x[32,12]  R1078     -2.2258731252318614e-02
    x[32,12]  R1079     -3.9535535354550462e-02
    x[32,12]  hard_lower  12
    x[32,12]  hard_upper  12
    x[32,13]  OBJ       4.9999999999999996e-02
    x[32,13]  onehot_32  1
    x[32,13]  R1080     -2.2258731252318614e-02
    x[32,13]  R1081     -3.9535535354550462e-02
    x[32,13]  hard_lower  13
    x[32,13]  hard_upper  13
    x[32,14]  OBJ       4.9999999999999996e-02
    x[32,14]  onehot_32  1
    x[32,14]  R1082     -2.2258731252318614e-02
    x[32,14]  R1083     -3.9535535354550462e-02
    x[32,14]  hard_lower  14
    x[32,14]  hard_upper  14
    x[32,15]  OBJ       4.9999999999999996e-02
    x[32,15]  onehot_32  1
    x[32,15]  R1084     -2.2258731252318614e-02
    x[32,15]  R1085     -3.9535535354550462e-02
    x[32,15]  hard_lower  15
    x[32,15]  hard_upper  15
    x[33,0]   OBJ       5.0000000000000017e-02
    x[33,0]   onehot_33  1
    x[33,0]   R1090     -2.2258731252318614e-02
    x[33,0]   R1091     -3.9535535354550462e-02
    x[33,1]   OBJ       0.05
    x[33,1]   onehot_33  1
    x[33,1]   R1092     -2.2258731252318614e-02
    x[33,1]   R1093     -3.9535535354550462e-02
    x[33,1]   hard_lower  1
    x[33,1]   hard_upper  1
    x[33,2]   OBJ       5.0000000000000017e-02
    x[33,2]   onehot_33  1
    x[33,2]   R1094     -2.2258731252318614e-02
    x[33,2]   R1095     -3.9535535354550462e-02
    x[33,2]   hard_lower  2
    x[33,2]   hard_upper  2
    x[33,3]   OBJ       5.0000000000000017e-02
    x[33,3]   onehot_33  1
    x[33,3]   R1096     -2.2258731252318614e-02
    x[33,3]   R1097     -3.9535535354550462e-02
    x[33,3]   hard_lower  3
    x[33,3]   hard_upper  3
    x[33,4]   OBJ       5.0000000000000010e-02
    x[33,4]   onehot_33  1
    x[33,4]   R1098     -2.2258731252318614e-02
    x[33,4]   R1099     -3.9535535354550462e-02
    x[33,4]   hard_lower  4
    x[33,4]   hard_upper  4
    x[33,5]   OBJ       5.0000000000000010e-02
    x[33,5]   onehot_33  1
    x[33,5]   R1100     -2.2258731252318614e-02
    x[33,5]   R1101     -3.9535535354550462e-02
    x[33,5]   hard_lower  5
    x[33,5]   hard_upper  5
    x[33,6]   OBJ       5.0000000000000010e-02
    x[33,6]   onehot_33  1
    x[33,6]   R1102     -2.2258731252318614e-02
    x[33,6]   R1103     -3.9535535354550462e-02
    x[33,6]   hard_lower  6
    x[33,6]   hard_upper  6
    x[33,7]   OBJ       5.0000000000000010e-02
    x[33,7]   onehot_33  1
    x[33,7]   R1104     -2.2258731252318614e-02
    x[33,7]   R1105     -3.9535535354550462e-02
    x[33,7]   hard_lower  7
    x[33,7]   hard_upper  7
    x[33,8]   OBJ       5.0000000000000010e-02
    x[33,8]   onehot_33  1
    x[33,8]   R1106     -2.2258731252318614e-02
    x[33,8]   R1107     -3.9535535354550462e-02
    x[33,8]   hard_lower  8
    x[33,8]   hard_upper  8
    x[33,9]   OBJ       0.05
    x[33,9]   onehot_33  1
    x[33,9]   R1108     -2.2258731252318614e-02
    x[33,9]   R1109     -3.9535535354550462e-02
    x[33,9]   hard_lower  9
    x[33,9]   hard_upper  9
    x[33,10]  OBJ       0.05
    x[33,10]  onehot_33  1
    x[33,10]  R1110     -2.2258731252318614e-02
    x[33,10]  R1111     -3.9535535354550462e-02
    x[33,10]  hard_lower  10
    x[33,10]  hard_upper  10
    x[33,11]  OBJ       5.0000000000000010e-02
    x[33,11]  onehot_33  1
    x[33,11]  R1112     -2.2258731252318614e-02
    x[33,11]  R1113     -3.9535535354550462e-02
    x[33,11]  hard_lower  11
    x[33,11]  hard_upper  11
    x[33,12]  OBJ       0.05
    x[33,12]  onehot_33  1
    x[33,12]  R1114     -2.2258731252318614e-02
    x[33,12]  R1115     -3.9535535354550462e-02
    x[33,12]  hard_lower  12
    x[33,12]  hard_upper  12
    x[33,13]  OBJ       8.3266726846886737e-18
    x[33,13]  onehot_33  1
    x[33,13]  R1116     -2.2258731252318614e-02
    x[33,13]  R1117     -3.9535535354550462e-02
    x[33,13]  hard_lower  13
    x[33,13]  hard_upper  13
    x[33,14]  OBJ       5.0000000000000010e-02
    x[33,14]  onehot_33  1
    x[33,14]  R1118     -2.2258731252318614e-02
    x[33,14]  R1119     -3.9535535354550462e-02
    x[33,14]  hard_lower  14
    x[33,14]  hard_upper  14
    x[33,15]  OBJ       5.0000000000000010e-02
    x[33,15]  onehot_33  1
    x[33,15]  R1120     -2.2258731252318614e-02
    x[33,15]  R1121     -3.9535535354550462e-02
    x[33,15]  hard_lower  15
    x[33,15]  hard_upper  15
    x[33,16]  OBJ       5.0000000000000010e-02
    x[33,16]  onehot_33  1
    x[33,16]  R1122     -2.2258731252318614e-02
    x[33,16]  R1123     -3.9535535354550462e-02
    x[33,16]  hard_lower  16
    x[33,16]  hard_upper  16
    x[33,17]  OBJ       5.0000000000000010e-02
    x[33,17]  onehot_33  1
    x[33,17]  R1124     -2.2258731252318614e-02
    x[33,17]  R1125     -3.9535535354550462e-02
    x[33,17]  hard_lower  17
    x[33,17]  hard_upper  17
    x[33,18]  OBJ       5.0000000000000010e-02
    x[33,18]  onehot_33  1
    x[33,18]  R1126     -2.2258731252318614e-02
    x[33,18]  R1127     -3.9535535354550462e-02
    x[33,18]  hard_lower  18
    x[33,18]  hard_upper  18
    x[33,19]  OBJ       5.0000000000000010e-02
    x[33,19]  onehot_33  1
    x[33,19]  R1128     -2.2258731252318614e-02
    x[33,19]  R1129     -3.9535535354550462e-02
    x[33,19]  hard_lower  19
    x[33,19]  hard_upper  19
    x[33,20]  OBJ       5.0000000000000010e-02
    x[33,20]  onehot_33  1
    x[33,20]  R1130     -2.2258731252318614e-02
    x[33,20]  R1131     -3.9535535354550462e-02
    x[33,20]  hard_lower  20
    x[33,20]  hard_upper  20
    x[33,21]  OBJ       5.0000000000000010e-02
    x[33,21]  onehot_33  1
    x[33,21]  R1132     -2.2258731252318614e-02
    x[33,21]  R1133     -3.9535535354550462e-02
    x[33,21]  hard_lower  21
    x[33,21]  hard_upper  21
    x[33,22]  OBJ       5.0000000000000010e-02
    x[33,22]  onehot_33  1
    x[33,22]  R1134     -2.2258731252318614e-02
    x[33,22]  R1135     -3.9535535354550462e-02
    x[33,22]  hard_lower  22
    x[33,22]  hard_upper  22
    x[33,23]  OBJ       5.0000000000000017e-02
    x[33,23]  onehot_33  1
    x[33,23]  R1136     -2.2258731252318614e-02
    x[33,23]  R1137     -3.9535535354550462e-02
    x[33,23]  hard_lower  23
    x[33,23]  hard_upper  23
    x[33,24]  OBJ       0.05
    x[33,24]  onehot_33  1
    x[33,24]  R1138     -2.2258731252318614e-02
    x[33,24]  R1139     -3.9535535354550462e-02
    x[33,24]  hard_lower  24
    x[33,24]  hard_upper  24
    x[34,0]   OBJ       0.05
    x[34,0]   onehot_34  1
    x[34,0]   R1144     -2.2258731252318614e-02
    x[34,0]   R1145     -3.9535535354550462e-02
    x[34,1]   OBJ       4.9999999999999996e-02
    x[34,1]   onehot_34  1
    x[34,1]   R1146     -2.2258731252318614e-02
    x[34,1]   R1147     -3.9535535354550462e-02
    x[34,1]   hard_lower  1
    x[34,1]   hard_upper  1
    x[34,2]   OBJ       4.9999999999999996e-02
    x[34,2]   onehot_34  1
    x[34,2]   R1148     -2.2258731252318614e-02
    x[34,2]   R1149     -3.9535535354550462e-02
    x[34,2]   hard_lower  2
    x[34,2]   hard_upper  2
    x[34,3]   OBJ       4.9999999999999996e-02
    x[34,3]   onehot_34  1
    x[34,3]   R1150     -2.2258731252318614e-02
    x[34,3]   R1151     -3.9535535354550462e-02
    x[34,3]   hard_lower  3
    x[34,3]   hard_upper  3
    x[34,4]   OBJ       0.05
    x[34,4]   onehot_34  1
    x[34,4]   R1152     -2.2258731252318614e-02
    x[34,4]   R1153     -3.9535535354550462e-02
    x[34,4]   hard_lower  4
    x[34,4]   hard_upper  4
    x[34,5]   OBJ       4.9999999999999996e-02
    x[34,5]   onehot_34  1
    x[34,5]   R1154     -2.2258731252318614e-02
    x[34,5]   R1155     -3.9535535354550462e-02
    x[34,5]   hard_lower  5
    x[34,5]   hard_upper  5
    x[34,6]   OBJ       0.05
    x[34,6]   onehot_34  1
    x[34,6]   R1156     -2.2258731252318614e-02
    x[34,6]   R1157     -3.9535535354550462e-02
    x[34,6]   hard_lower  6
    x[34,6]   hard_upper  6
    x[34,7]   OBJ       0.05
    x[34,7]   onehot_34  1
    x[34,7]   R1158     -2.2258731252318614e-02
    x[34,7]   R1159     -3.9535535354550462e-02
    x[34,7]   hard_lower  7
    x[34,7]   hard_upper  7
    x[34,8]   onehot_34  1
    x[34,8]   R1160     -2.2258731252318614e-02
    x[34,8]   R1161     -3.9535535354550462e-02
    x[34,8]   hard_lower  8
    x[34,8]   hard_upper  8
    x[34,9]   OBJ       0.05
    x[34,9]   onehot_34  1
    x[34,9]   R1162     -2.2258731252318614e-02
    x[34,9]   R1163     -3.9535535354550462e-02
    x[34,9]   hard_lower  9
    x[34,9]   hard_upper  9
    x[34,10]  OBJ       0.05
    x[34,10]  onehot_34  1
    x[34,10]  R1164     -2.2258731252318614e-02
    x[34,10]  R1165     -3.9535535354550462e-02
    x[34,10]  hard_lower  10
    x[34,10]  hard_upper  10
    x[34,11]  OBJ       4.9999999999999996e-02
    x[34,11]  onehot_34  1
    x[34,11]  R1166     -2.2258731252318614e-02
    x[34,11]  R1167     -3.9535535354550462e-02
    x[34,11]  hard_lower  11
    x[34,11]  hard_upper  11
    x[34,12]  OBJ       0.05
    x[34,12]  onehot_34  1
    x[34,12]  R1168     -2.2258731252318614e-02
    x[34,12]  R1169     -3.9535535354550462e-02
    x[34,12]  hard_lower  12
    x[34,12]  hard_upper  12
    x[34,13]  OBJ       4.9999999999999996e-02
    x[34,13]  onehot_34  1
    x[34,13]  R1170     -2.2258731252318614e-02
    x[34,13]  R1171     -3.9535535354550462e-02
    x[34,13]  hard_lower  13
    x[34,13]  hard_upper  13
    x[34,14]  OBJ       4.9999999999999996e-02
    x[34,14]  onehot_34  1
    x[34,14]  R1172     -2.2258731252318614e-02
    x[34,14]  R1173     -3.9535535354550462e-02
    x[34,14]  hard_lower  14
    x[34,14]  hard_upper  14
    x[34,15]  OBJ       4.9999999999999996e-02
    x[34,15]  onehot_34  1
    x[34,15]  R1174     -2.2258731252318614e-02
    x[34,15]  R1175     -3.9535535354550462e-02
    x[34,15]  hard_lower  15
    x[34,15]  hard_upper  15
    x[35,0]   OBJ       0.05
    x[35,0]   onehot_35  1
    x[35,0]   R1180     -2.2258731252318614e-02
    x[35,0]   R1181     -3.9535535354550462e-02
    x[35,1]   OBJ       5.0000000000000010e-02
    x[35,1]   onehot_35  1
    x[35,1]   R1182     -2.2258731252318614e-02
    x[35,1]   R1183     -3.9535535354550462e-02
    x[35,1]   hard_lower  1
    x[35,1]   hard_upper  1
    x[35,2]   OBJ       5.0000000000000010e-02
    x[35,2]   onehot_35  1
    x[35,2]   R1184     -2.2258731252318614e-02
    x[35,2]   R1185     -3.9535535354550462e-02
    x[35,2]   hard_lower  2
    x[35,2]   hard_upper  2
    x[35,3]   OBJ       0.05
    x[35,3]   onehot_35  1
    x[35,3]   R1186     -2.2258731252318614e-02
    x[35,3]   R1187     -3.9535535354550462e-02
    x[35,3]   hard_lower  3
    x[35,3]   hard_upper  3
    x[35,4]   OBJ       0.05
    x[35,4]   onehot_35  1
    x[35,4]   R1188     -2.2258731252318614e-02
    x[35,4]   R1189     -3.9535535354550462e-02
    x[35,4]   hard_lower  4
    x[35,4]   hard_upper  4
    x[35,5]   OBJ       0.05
    x[35,5]   onehot_35  1
    x[35,5]   R1190     -2.2258731252318614e-02
    x[35,5]   R1191     -3.9535535354550462e-02
    x[35,5]   hard_lower  5
    x[35,5]   hard_upper  5
    x[35,6]   OBJ       0.05
    x[35,6]   onehot_35  1
    x[35,6]   R1192     -2.2258731252318614e-02
    x[35,6]   R1193     -3.9535535354550462e-02
    x[35,6]   hard_lower  6
    x[35,6]   hard_upper  6
    x[35,7]   OBJ       5.0000000000000010e-02
    x[35,7]   onehot_35  1
    x[35,7]   R1194     -2.2258731252318614e-02
    x[35,7]   R1195     -3.9535535354550462e-02
    x[35,7]   hard_lower  7
    x[35,7]   hard_upper  7
    x[35,8]   OBJ       0.05
    x[35,8]   onehot_35  1
    x[35,8]   R1196     -2.2258731252318614e-02
    x[35,8]   R1197     -3.9535535354550462e-02
    x[35,8]   hard_lower  8
    x[35,8]   hard_upper  8
    x[35,9]   OBJ       3.9908909510444345e-18
    x[35,9]   onehot_35  1
    x[35,9]   R1198     -2.2258731252318614e-02
    x[35,9]   R1199     -3.9535535354550462e-02
    x[35,9]   hard_lower  9
    x[35,9]   hard_upper  9
    x[35,10]  OBJ       0.05
    x[35,10]  onehot_35  1
    x[35,10]  R1200     -2.2258731252318614e-02
    x[35,10]  R1201     -3.9535535354550462e-02
    x[35,10]  hard_lower  10
    x[35,10]  hard_upper  10
    x[35,11]  OBJ       0.05
    x[35,11]  onehot_35  1
    x[35,11]  R1202     -2.2258731252318614e-02
    x[35,11]  R1203     -3.9535535354550462e-02
    x[35,11]  hard_lower  11
    x[35,11]  hard_upper  11
    x[35,12]  OBJ       0.05
    x[35,12]  onehot_35  1
    x[35,12]  R1204     -2.2258731252318614e-02
    x[35,12]  R1205     -3.9535535354550462e-02
    x[35,12]  hard_lower  12
    x[35,12]  hard_upper  12
    x[35,13]  OBJ       0.05
    x[35,13]  onehot_35  1
    x[35,13]  R1206     -2.2258731252318614e-02
    x[35,13]  R1207     -3.9535535354550462e-02
    x[35,13]  hard_lower  13
    x[35,13]  hard_upper  13
    x[35,14]  OBJ       0.05
    x[35,14]  onehot_35  1
    x[35,14]  R1208     -2.2258731252318614e-02
    x[35,14]  R1209     -3.9535535354550462e-02
    x[35,14]  hard_lower  14
    x[35,14]  hard_upper  14
    x[35,15]  OBJ       0.05
    x[35,15]  onehot_35  1
    x[35,15]  R1210     -2.2258731252318614e-02
    x[35,15]  R1211     -3.9535535354550462e-02
    x[35,15]  hard_lower  15
    x[35,15]  hard_upper  15
    x[35,16]  OBJ       0.05
    x[35,16]  onehot_35  1
    x[35,16]  R1212     -2.2258731252318614e-02
    x[35,16]  R1213     -3.9535535354550462e-02
    x[35,16]  hard_lower  16
    x[35,16]  hard_upper  16
    x[35,17]  OBJ       0.05
    x[35,17]  onehot_35  1
    x[35,17]  R1214     -2.2258731252318614e-02
    x[35,17]  R1215     -3.9535535354550462e-02
    x[35,17]  hard_lower  17
    x[35,17]  hard_upper  17
    MARKER    'MARKER'                 'INTEND'
    w[1,4]    mass_1    1
    w[1,4]    R2        1
    w[1,4]    R3        1
    w[1,4]    normalized_inventory_1  -4
    w[2,0]    mass_2    1
    w[2,0]    R8        1
    w[2,0]    R9        1
    w[2,1]    mass_2    1
    w[2,1]    R10       1
    w[2,1]    R11       1
    w[2,1]    normalized_inventory_2  -1
    w[2,2]    mass_2    1
    w[2,2]    R12       1
    w[2,2]    R13       1
    w[2,2]    normalized_inventory_2  -2
    w[2,3]    mass_2    1
    w[2,3]    R14       1
    w[2,3]    R15       1
    w[2,3]    normalized_inventory_2  -3
    w[2,4]    mass_2    1
    w[2,4]    R16       1
    w[2,4]    R17       1
    w[2,4]    normalized_inventory_2  -4
    w[2,5]    mass_2    1
    w[2,5]    R18       1
    w[2,5]    R19       1
    w[2,5]    normalized_inventory_2  -5
    w[2,6]    mass_2    1
    w[2,6]    R20       1
    w[2,6]    R21       1
    w[2,6]    normalized_inventory_2  -6
    w[2,7]    mass_2    1
    w[2,7]    R22       1
    w[2,7]    R23       1
    w[2,7]    normalized_inventory_2  -7
    w[2,8]    mass_2    1
    w[2,8]    R24       1
    w[2,8]    R25       1
    w[2,8]    normalized_inventory_2  -8
    w[2,9]    mass_2    1
    w[2,9]    R26       1
    w[2,9]    R27       1
    w[2,9]    normalized_inventory_2  -9
    w[2,10]   mass_2    1
    w[2,10]   R28       1
    w[2,10]   R29       1
    w[2,10]   normalized_inventory_2  -10
    w[2,11]   mass_2    1
    w[2,11]   R30       1
    w[2,11]   R31       1
    w[2,11]   normalized_inventory_2  -11
    w[2,12]   mass_2    1
    w[2,12]   R32       1
    w[2,12]   R33       1
    w[2,12]   normalized_inventory_2  -12
    w[2,13]   mass_2    1
    w[2,13]   R34       1
    w[2,13]   R35       1
    w[2,13]   normalized_inventory_2  -13
    w[2,14]   mass_2    1
    w[2,14]   R36       1
    w[2,14]   R37       1
    w[2,14]   normalized_inventory_2  -14
    w[2,15]   mass_2    1
    w[2,15]   R38       1
    w[2,15]   R39       1
    w[2,15]   normalized_inventory_2  -15
    w[2,16]   mass_2    1
    w[2,16]   R40       1
    w[2,16]   R41       1
    w[2,16]   normalized_inventory_2  -16
    w[2,17]   mass_2    1
    w[2,17]   R42       1
    w[2,17]   R43       1
    w[2,17]   normalized_inventory_2  -17
    w[2,18]   mass_2    1
    w[2,18]   R44       1
    w[2,18]   R45       1
    w[2,18]   normalized_inventory_2  -18
    w[2,19]   mass_2    1
    w[2,19]   R46       1
    w[2,19]   R47       1
    w[2,19]   normalized_inventory_2  -19
    w[2,20]   mass_2    1
    w[2,20]   R48       1
    w[2,20]   R49       1
    w[2,20]   normalized_inventory_2  -20
    w[2,21]   mass_2    1
    w[2,21]   R50       1
    w[2,21]   R51       1
    w[2,21]   normalized_inventory_2  -21
    w[2,22]   mass_2    1
    w[2,22]   R52       1
    w[2,22]   R53       1
    w[2,22]   normalized_inventory_2  -22
    w[2,23]   mass_2    1
    w[2,23]   R54       1
    w[2,23]   R55       1
    w[2,23]   normalized_inventory_2  -23
    w[3,13]   mass_3    1
    w[3,13]   R60       1
    w[3,13]   R61       1
    w[3,13]   normalized_inventory_3  -13
    w[4,0]    mass_4    1
    w[4,0]    R66       1
    w[4,0]    R67       1
    w[4,1]    mass_4    1
    w[4,1]    R68       1
    w[4,1]    R69       1
    w[4,1]    normalized_inventory_4  -1
    w[4,2]    mass_4    1
    w[4,2]    R70       1
    w[4,2]    R71       1
    w[4,2]    normalized_inventory_4  -2
    w[4,3]    mass_4    1
    w[4,3]    R72       1
    w[4,3]    R73       1
    w[4,3]    normalized_inventory_4  -3
    w[4,4]    mass_4    1
    w[4,4]    R74       1
    w[4,4]    R75       1
    w[4,4]    normalized_inventory_4  -4
    w[4,5]    mass_4    1
    w[4,5]    R76       1
    w[4,5]    R77       1
    w[4,5]    normalized_inventory_4  -5
    w[4,6]    mass_4    1
    w[4,6]    R78       1
    w[4,6]    R79       1
    w[4,6]    normalized_inventory_4  -6
    w[4,7]    mass_4    1
    w[4,7]    R80       1
    w[4,7]    R81       1
    w[4,7]    normalized_inventory_4  -7
    w[4,8]    mass_4    1
    w[4,8]    R82       1
    w[4,8]    R83       1
    w[4,8]    normalized_inventory_4  -8
    w[4,9]    mass_4    1
    w[4,9]    R84       1
    w[4,9]    R85       1
    w[4,9]    normalized_inventory_4  -9
    w[4,10]   mass_4    1
    w[4,10]   R86       1
    w[4,10]   R87       1
    w[4,10]   normalized_inventory_4  -10
    w[4,11]   mass_4    1
    w[4,11]   R88       1
    w[4,11]   R89       1
    w[4,11]   normalized_inventory_4  -11
    w[4,12]   mass_4    1
    w[4,12]   R90       1
    w[4,12]   R91       1
    w[4,12]   normalized_inventory_4  -12
    w[4,13]   mass_4    1
    w[4,13]   R92       1
    w[4,13]   R93       1
    w[4,13]   normalized_inventory_4  -13
    w[4,14]   mass_4    1
    w[4,14]   R94       1
    w[4,14]   R95       1
    w[4,14]   normalized_inventory_4  -14
    w[4,15]   mass_4    1
    w[4,15]   R96       1
    w[4,15]   R97       1
    w[4,15]   normalized_inventory_4  -15
    w[5,0]    mass_5    1
    w[5,0]    R102      1
    w[5,0]    R103      1
    w[5,1]    mass_5    1
    w[5,1]    R104      1
    w[5,1]    R105      1
    w[5,1]    normalized_inventory_5  -1
    w[5,2]    mass_5    1
    w[5,2]    R106      1
    w[5,2]    R107      1
    w[5,2]    normalized_inventory_5  -2
    w[5,3]    mass_5    1
    w[5,3]    R108      1
    w[5,3]    R109      1
    w[5,3]    normalized_inventory_5  -3
    w[5,4]    mass_5    1
    w[5,4]    R110      1
    w[5,4]    R111      1
    w[5,4]    normalized_inventory_5  -4
    w[5,5]    mass_5    1
    w[5,5]    R112      1
    w[5,5]    R113      1
    w[5,5]    normalized_inventory_5  -5
    w[5,6]    mass_5    1
    w[5,6]    R114      1
    w[5,6]    R115      1
    w[5,6]    normalized_inventory_5  -6
    w[5,7]    mass_5    1
    w[5,7]    R116      1
    w[5,7]    R117      1
    w[5,7]    normalized_inventory_5  -7
    w[5,8]    mass_5    1
    w[5,8]    R118      1
    w[5,8]    R119      1
    w[5,8]    normalized_inventory_5  -8
    w[5,9]    mass_5    1
    w[5,9]    R120      1
    w[5,9]    R121      1
    w[5,9]    normalized_inventory_5  -9
    w[5,10]   mass_5    1
    w[5,10]   R122      1
    w[5,10]   R123      1
    w[5,10]   normalized_inventory_5  -10
    w[5,11]   mass_5    1
    w[5,11]   R124      1
    w[5,11]   R125      1
    w[5,11]   normalized_inventory_5  -11
    w[5,12]   mass_5    1
    w[5,12]   R126      1
    w[5,12]   R127      1
    w[5,12]   normalized_inventory_5  -12
    w[5,13]   mass_5    1
    w[5,13]   R128      1
    w[5,13]   R129      1
    w[5,13]   normalized_inventory_5  -13
    w[5,14]   mass_5    1
    w[5,14]   R130      1
    w[5,14]   R131      1
    w[5,14]   normalized_inventory_5  -14
    w[5,15]   mass_5    1
    w[5,15]   R132      1
    w[5,15]   R133      1
    w[5,15]   normalized_inventory_5  -15
    w[6,4]    mass_6    1
    w[6,4]    R138      1
    w[6,4]    R139      1
    w[6,4]    normalized_inventory_6  -4
    w[7,0]    mass_7    1
    w[7,0]    R144      1
    w[7,0]    R145      1
    w[7,1]    mass_7    1
    w[7,1]    R146      1
    w[7,1]    R147      1
    w[7,1]    normalized_inventory_7  -1
    w[7,2]    mass_7    1
    w[7,2]    R148      1
    w[7,2]    R149      1
    w[7,2]    normalized_inventory_7  -2
    w[7,3]    mass_7    1
    w[7,3]    R150      1
    w[7,3]    R151      1
    w[7,3]    normalized_inventory_7  -3
    w[7,4]    mass_7    1
    w[7,4]    R152      1
    w[7,4]    R153      1
    w[7,4]    normalized_inventory_7  -4
    w[7,5]    mass_7    1
    w[7,5]    R154      1
    w[7,5]    R155      1
    w[7,5]    normalized_inventory_7  -5
    w[7,6]    mass_7    1
    w[7,6]    R156      1
    w[7,6]    R157      1
    w[7,6]    normalized_inventory_7  -6
    w[7,7]    mass_7    1
    w[7,7]    R158      1
    w[7,7]    R159      1
    w[7,7]    normalized_inventory_7  -7
    w[7,8]    mass_7    1
    w[7,8]    R160      1
    w[7,8]    R161      1
    w[7,8]    normalized_inventory_7  -8
    w[7,9]    mass_7    1
    w[7,9]    R162      1
    w[7,9]    R163      1
    w[7,9]    normalized_inventory_7  -9
    w[7,10]   mass_7    1
    w[7,10]   R164      1
    w[7,10]   R165      1
    w[7,10]   normalized_inventory_7  -10
    w[7,11]   mass_7    1
    w[7,11]   R166      1
    w[7,11]   R167      1
    w[7,11]   normalized_inventory_7  -11
    w[7,12]   mass_7    1
    w[7,12]   R168      1
    w[7,12]   R169      1
    w[7,12]   normalized_inventory_7  -12
    w[7,13]   mass_7    1
    w[7,13]   R170      1
    w[7,13]   R171      1
    w[7,13]   normalized_inventory_7  -13
    w[7,14]   mass_7    1
    w[7,14]   R172      1
    w[7,14]   R173      1
    w[7,14]   normalized_inventory_7  -14
    w[7,15]   mass_7    1
    w[7,15]   R174      1
    w[7,15]   R175      1
    w[7,15]   normalized_inventory_7  -15
    w[7,16]   mass_7    1
    w[7,16]   R176      1
    w[7,16]   R177      1
    w[7,16]   normalized_inventory_7  -16
    w[7,17]   mass_7    1
    w[7,17]   R178      1
    w[7,17]   R179      1
    w[7,17]   normalized_inventory_7  -17
    w[7,18]   mass_7    1
    w[7,18]   R180      1
    w[7,18]   R181      1
    w[7,18]   normalized_inventory_7  -18
    w[7,19]   mass_7    1
    w[7,19]   R182      1
    w[7,19]   R183      1
    w[7,19]   normalized_inventory_7  -19
    w[8,0]    mass_8    1
    w[8,0]    R188      1
    w[8,0]    R189      1
    w[8,1]    mass_8    1
    w[8,1]    R190      1
    w[8,1]    R191      1
    w[8,1]    normalized_inventory_8  -1
    w[8,2]    mass_8    1
    w[8,2]    R192      1
    w[8,2]    R193      1
    w[8,2]    normalized_inventory_8  -2
    w[8,3]    mass_8    1
    w[8,3]    R194      1
    w[8,3]    R195      1
    w[8,3]    normalized_inventory_8  -3
    w[8,4]    mass_8    1
    w[8,4]    R196      1
    w[8,4]    R197      1
    w[8,4]    normalized_inventory_8  -4
    w[8,5]    mass_8    1
    w[8,5]    R198      1
    w[8,5]    R199      1
    w[8,5]    normalized_inventory_8  -5
    w[8,6]    mass_8    1
    w[8,6]    R200      1
    w[8,6]    R201      1
    w[8,6]    normalized_inventory_8  -6
    w[8,7]    mass_8    1
    w[8,7]    R202      1
    w[8,7]    R203      1
    w[8,7]    normalized_inventory_8  -7
    w[8,8]    mass_8    1
    w[8,8]    R204      1
    w[8,8]    R205      1
    w[8,8]    normalized_inventory_8  -8
    w[8,9]    mass_8    1
    w[8,9]    R206      1
    w[8,9]    R207      1
    w[8,9]    normalized_inventory_8  -9
    w[8,10]   mass_8    1
    w[8,10]   R208      1
    w[8,10]   R209      1
    w[8,10]   normalized_inventory_8  -10
    w[8,11]   mass_8    1
    w[8,11]   R210      1
    w[8,11]   R211      1
    w[8,11]   normalized_inventory_8  -11
    w[8,12]   mass_8    1
    w[8,12]   R212      1
    w[8,12]   R213      1
    w[8,12]   normalized_inventory_8  -12
    w[8,13]   mass_8    1
    w[8,13]   R214      1
    w[8,13]   R215      1
    w[8,13]   normalized_inventory_8  -13
    w[8,14]   mass_8    1
    w[8,14]   R216      1
    w[8,14]   R217      1
    w[8,14]   normalized_inventory_8  -14
    w[8,15]   mass_8    1
    w[8,15]   R218      1
    w[8,15]   R219      1
    w[8,15]   normalized_inventory_8  -15
    w[9,0]    mass_9    1
    w[9,0]    R224      1
    w[9,0]    R225      1
    w[9,1]    mass_9    1
    w[9,1]    R226      1
    w[9,1]    R227      1
    w[9,1]    normalized_inventory_9  -1
    w[9,2]    mass_9    1
    w[9,2]    R228      1
    w[9,2]    R229      1
    w[9,2]    normalized_inventory_9  -2
    w[9,3]    mass_9    1
    w[9,3]    R230      1
    w[9,3]    R231      1
    w[9,3]    normalized_inventory_9  -3
    w[9,4]    mass_9    1
    w[9,4]    R232      1
    w[9,4]    R233      1
    w[9,4]    normalized_inventory_9  -4
    w[9,5]    mass_9    1
    w[9,5]    R234      1
    w[9,5]    R235      1
    w[9,5]    normalized_inventory_9  -5
    w[9,6]    mass_9    1
    w[9,6]    R236      1
    w[9,6]    R237      1
    w[9,6]    normalized_inventory_9  -6
    w[9,7]    mass_9    1
    w[9,7]    R238      1
    w[9,7]    R239      1
    w[9,7]    normalized_inventory_9  -7
    w[9,8]    mass_9    1
    w[9,8]    R240      1
    w[9,8]    R241      1
    w[9,8]    normalized_inventory_9  -8
    w[9,9]    mass_9    1
    w[9,9]    R242      1
    w[9,9]    R243      1
    w[9,9]    normalized_inventory_9  -9
    w[9,10]   mass_9    1
    w[9,10]   R244      1
    w[9,10]   R245      1
    w[9,10]   normalized_inventory_9  -10
    w[9,11]   mass_9    1
    w[9,11]   R246      1
    w[9,11]   R247      1
    w[9,11]   normalized_inventory_9  -11
    w[9,12]   mass_9    1
    w[9,12]   R248      1
    w[9,12]   R249      1
    w[9,12]   normalized_inventory_9  -12
    w[9,13]   mass_9    1
    w[9,13]   R250      1
    w[9,13]   R251      1
    w[9,13]   normalized_inventory_9  -13
    w[9,14]   mass_9    1
    w[9,14]   R252      1
    w[9,14]   R253      1
    w[9,14]   normalized_inventory_9  -14
    w[10,0]   mass_10   1
    w[10,0]   R258      1
    w[10,0]   R259      1
    w[10,1]   mass_10   1
    w[10,1]   R260      1
    w[10,1]   R261      1
    w[10,1]   normalized_inventory_10  -1
    w[10,2]   mass_10   1
    w[10,2]   R262      1
    w[10,2]   R263      1
    w[10,2]   normalized_inventory_10  -2
    w[10,3]   mass_10   1
    w[10,3]   R264      1
    w[10,3]   R265      1
    w[10,3]   normalized_inventory_10  -3
    w[10,4]   mass_10   1
    w[10,4]   R266      1
    w[10,4]   R267      1
    w[10,4]   normalized_inventory_10  -4
    w[10,5]   mass_10   1
    w[10,5]   R268      1
    w[10,5]   R269      1
    w[10,5]   normalized_inventory_10  -5
    w[10,6]   mass_10   1
    w[10,6]   R270      1
    w[10,6]   R271      1
    w[10,6]   normalized_inventory_10  -6
    w[10,7]   mass_10   1
    w[10,7]   R272      1
    w[10,7]   R273      1
    w[10,7]   normalized_inventory_10  -7
    w[10,8]   mass_10   1
    w[10,8]   R274      1
    w[10,8]   R275      1
    w[10,8]   normalized_inventory_10  -8
    w[10,9]   mass_10   1
    w[10,9]   R276      1
    w[10,9]   R277      1
    w[10,9]   normalized_inventory_10  -9
    w[10,10]  mass_10   1
    w[10,10]  R278      1
    w[10,10]  R279      1
    w[10,10]  normalized_inventory_10  -10
    w[10,11]  mass_10   1
    w[10,11]  R280      1
    w[10,11]  R281      1
    w[10,11]  normalized_inventory_10  -11
    w[11,0]   mass_11   1
    w[11,0]   R286      1
    w[11,0]   R287      1
    w[11,1]   mass_11   1
    w[11,1]   R288      1
    w[11,1]   R289      1
    w[11,1]   normalized_inventory_11  -1
    w[11,2]   mass_11   1
    w[11,2]   R290      1
    w[11,2]   R291      1
    w[11,2]   normalized_inventory_11  -2
    w[11,3]   mass_11   1
    w[11,3]   R292      1
    w[11,3]   R293      1
    w[11,3]   normalized_inventory_11  -3
    w[11,4]   mass_11   1
    w[11,4]   R294      1
    w[11,4]   R295      1
    w[11,4]   normalized_inventory_11  -4
    w[11,5]   mass_11   1
    w[11,5]   R296      1
    w[11,5]   R297      1
    w[11,5]   normalized_inventory_11  -5
    w[11,6]   mass_11   1
    w[11,6]   R298      1
    w[11,6]   R299      1
    w[11,6]   normalized_inventory_11  -6
    w[11,7]   mass_11   1
    w[11,7]   R300      1
    w[11,7]   R301      1
    w[11,7]   normalized_inventory_11  -7
    w[11,8]   mass_11   1
    w[11,8]   R302      1
    w[11,8]   R303      1
    w[11,8]   normalized_inventory_11  -8
    w[11,9]   mass_11   1
    w[11,9]   R304      1
    w[11,9]   R305      1
    w[11,9]   normalized_inventory_11  -9
    w[11,10]  mass_11   1
    w[11,10]  R306      1
    w[11,10]  R307      1
    w[11,10]  normalized_inventory_11  -10
    w[11,11]  mass_11   1
    w[11,11]  R308      1
    w[11,11]  R309      1
    w[11,11]  normalized_inventory_11  -11
    w[11,12]  mass_11   1
    w[11,12]  R310      1
    w[11,12]  R311      1
    w[11,12]  normalized_inventory_11  -12
    w[11,13]  mass_11   1
    w[11,13]  R312      1
    w[11,13]  R313      1
    w[11,13]  normalized_inventory_11  -13
    w[11,14]  mass_11   1
    w[11,14]  R314      1
    w[11,14]  R315      1
    w[11,14]  normalized_inventory_11  -14
    w[11,15]  mass_11   1
    w[11,15]  R316      1
    w[11,15]  R317      1
    w[11,15]  normalized_inventory_11  -15
    w[12,0]   mass_12   1
    w[12,0]   R322      1
    w[12,0]   R323      1
    w[12,1]   mass_12   1
    w[12,1]   R324      1
    w[12,1]   R325      1
    w[12,1]   normalized_inventory_12  -1
    w[12,2]   mass_12   1
    w[12,2]   R326      1
    w[12,2]   R327      1
    w[12,2]   normalized_inventory_12  -2
    w[12,3]   mass_12   1
    w[12,3]   R328      1
    w[12,3]   R329      1
    w[12,3]   normalized_inventory_12  -3
    w[12,4]   mass_12   1
    w[12,4]   R330      1
    w[12,4]   R331      1
    w[12,4]   normalized_inventory_12  -4
    w[12,5]   mass_12   1
    w[12,5]   R332      1
    w[12,5]   R333      1
    w[12,5]   normalized_inventory_12  -5
    w[12,6]   mass_12   1
    w[12,6]   R334      1
    w[12,6]   R335      1
    w[12,6]   normalized_inventory_12  -6
    w[12,7]   mass_12   1
    w[12,7]   R336      1
    w[12,7]   R337      1
    w[12,7]   normalized_inventory_12  -7
    w[12,8]   mass_12   1
    w[12,8]   R338      1
    w[12,8]   R339      1
    w[12,8]   normalized_inventory_12  -8
    w[12,9]   mass_12   1
    w[12,9]   R340      1
    w[12,9]   R341      1
    w[12,9]   normalized_inventory_12  -9
    w[12,10]  mass_12   1
    w[12,10]  R342      1
    w[12,10]  R343      1
    w[12,10]  normalized_inventory_12  -10
    w[12,11]  mass_12   1
    w[12,11]  R344      1
    w[12,11]  R345      1
    w[12,11]  normalized_inventory_12  -11
    w[12,12]  mass_12   1
    w[12,12]  R346      1
    w[12,12]  R347      1
    w[12,12]  normalized_inventory_12  -12
    w[12,13]  mass_12   1
    w[12,13]  R348      1
    w[12,13]  R349      1
    w[12,13]  normalized_inventory_12  -13
    w[12,14]  mass_12   1
    w[12,14]  R350      1
    w[12,14]  R351      1
    w[12,14]  normalized_inventory_12  -14
    w[12,15]  mass_12   1
    w[12,15]  R352      1
    w[12,15]  R353      1
    w[12,15]  normalized_inventory_12  -15
    w[13,0]   mass_13   1
    w[13,0]   R358      1
    w[13,0]   R359      1
    w[13,1]   mass_13   1
    w[13,1]   R360      1
    w[13,1]   R361      1
    w[13,1]   normalized_inventory_13  -1
    w[13,2]   mass_13   1
    w[13,2]   R362      1
    w[13,2]   R363      1
    w[13,2]   normalized_inventory_13  -2
    w[13,3]   mass_13   1
    w[13,3]   R364      1
    w[13,3]   R365      1
    w[13,3]   normalized_inventory_13  -3
    w[13,4]   mass_13   1
    w[13,4]   R366      1
    w[13,4]   R367      1
    w[13,4]   normalized_inventory_13  -4
    w[13,5]   mass_13   1
    w[13,5]   R368      1
    w[13,5]   R369      1
    w[13,5]   normalized_inventory_13  -5
    w[13,6]   mass_13   1
    w[13,6]   R370      1
    w[13,6]   R371      1
    w[13,6]   normalized_inventory_13  -6
    w[13,7]   mass_13   1
    w[13,7]   R372      1
    w[13,7]   R373      1
    w[13,7]   normalized_inventory_13  -7
    w[13,8]   mass_13   1
    w[13,8]   R374      1
    w[13,8]   R375      1
    w[13,8]   normalized_inventory_13  -8
    w[13,9]   mass_13   1
    w[13,9]   R376      1
    w[13,9]   R377      1
    w[13,9]   normalized_inventory_13  -9
    w[13,10]  mass_13   1
    w[13,10]  R378      1
    w[13,10]  R379      1
    w[13,10]  normalized_inventory_13  -10
    w[13,11]  mass_13   1
    w[13,11]  R380      1
    w[13,11]  R381      1
    w[13,11]  normalized_inventory_13  -11
    w[13,12]  mass_13   1
    w[13,12]  R382      1
    w[13,12]  R383      1
    w[13,12]  normalized_inventory_13  -12
    w[13,13]  mass_13   1
    w[13,13]  R384      1
    w[13,13]  R385      1
    w[13,13]  normalized_inventory_13  -13
    w[13,14]  mass_13   1
    w[13,14]  R386      1
    w[13,14]  R387      1
    w[13,14]  normalized_inventory_13  -14
    w[13,15]  mass_13   1
    w[13,15]  R388      1
    w[13,15]  R389      1
    w[13,15]  normalized_inventory_13  -15
    w[13,16]  mass_13   1
    w[13,16]  R390      1
    w[13,16]  R391      1
    w[13,16]  normalized_inventory_13  -16
    w[13,17]  mass_13   1
    w[13,17]  R392      1
    w[13,17]  R393      1
    w[13,17]  normalized_inventory_13  -17
    w[13,18]  mass_13   1
    w[13,18]  R394      1
    w[13,18]  R395      1
    w[13,18]  normalized_inventory_13  -18
    w[13,19]  mass_13   1
    w[13,19]  R396      1
    w[13,19]  R397      1
    w[13,19]  normalized_inventory_13  -19
    w[14,0]   mass_14   1
    w[14,0]   R402      1
    w[14,0]   R403      1
    w[14,1]   mass_14   1
    w[14,1]   R404      1
    w[14,1]   R405      1
    w[14,1]   normalized_inventory_14  -1
    w[14,2]   mass_14   1
    w[14,2]   R406      1
    w[14,2]   R407      1
    w[14,2]   normalized_inventory_14  -2
    w[14,3]   mass_14   1
    w[14,3]   R408      1
    w[14,3]   R409      1
    w[14,3]   normalized_inventory_14  -3
    w[14,4]   mass_14   1
    w[14,4]   R410      1
    w[14,4]   R411      1
    w[14,4]   normalized_inventory_14  -4
    w[14,5]   mass_14   1
    w[14,5]   R412      1
    w[14,5]   R413      1
    w[14,5]   normalized_inventory_14  -5
    w[14,6]   mass_14   1
    w[14,6]   R414      1
    w[14,6]   R415      1
    w[14,6]   normalized_inventory_14  -6
    w[14,7]   mass_14   1
    w[14,7]   R416      1
    w[14,7]   R417      1
    w[14,7]   normalized_inventory_14  -7
    w[14,8]   mass_14   1
    w[14,8]   R418      1
    w[14,8]   R419      1
    w[14,8]   normalized_inventory_14  -8
    w[14,9]   mass_14   1
    w[14,9]   R420      1
    w[14,9]   R421      1
    w[14,9]   normalized_inventory_14  -9
    w[14,10]  mass_14   1
    w[14,10]  R422      1
    w[14,10]  R423      1
    w[14,10]  normalized_inventory_14  -10
    w[14,11]  mass_14   1
    w[14,11]  R424      1
    w[14,11]  R425      1
    w[14,11]  normalized_inventory_14  -11
    w[14,12]  mass_14   1
    w[14,12]  R426      1
    w[14,12]  R427      1
    w[14,12]  normalized_inventory_14  -12
    w[14,13]  mass_14   1
    w[14,13]  R428      1
    w[14,13]  R429      1
    w[14,13]  normalized_inventory_14  -13
    w[14,14]  mass_14   1
    w[14,14]  R430      1
    w[14,14]  R431      1
    w[14,14]  normalized_inventory_14  -14
    w[14,15]  mass_14   1
    w[14,15]  R432      1
    w[14,15]  R433      1
    w[14,15]  normalized_inventory_14  -15
    w[14,16]  mass_14   1
    w[14,16]  R434      1
    w[14,16]  R435      1
    w[14,16]  normalized_inventory_14  -16
    w[14,17]  mass_14   1
    w[14,17]  R436      1
    w[14,17]  R437      1
    w[14,17]  normalized_inventory_14  -17
    w[14,18]  mass_14   1
    w[14,18]  R438      1
    w[14,18]  R439      1
    w[14,18]  normalized_inventory_14  -18
    w[15,0]   mass_15   1
    w[15,0]   R444      1
    w[15,0]   R445      1
    w[15,1]   mass_15   1
    w[15,1]   R446      1
    w[15,1]   R447      1
    w[15,1]   normalized_inventory_15  -1
    w[15,2]   mass_15   1
    w[15,2]   R448      1
    w[15,2]   R449      1
    w[15,2]   normalized_inventory_15  -2
    w[15,3]   mass_15   1
    w[15,3]   R450      1
    w[15,3]   R451      1
    w[15,3]   normalized_inventory_15  -3
    w[15,4]   mass_15   1
    w[15,4]   R452      1
    w[15,4]   R453      1
    w[15,4]   normalized_inventory_15  -4
    w[15,5]   mass_15   1
    w[15,5]   R454      1
    w[15,5]   R455      1
    w[15,5]   normalized_inventory_15  -5
    w[15,6]   mass_15   1
    w[15,6]   R456      1
    w[15,6]   R457      1
    w[15,6]   normalized_inventory_15  -6
    w[15,7]   mass_15   1
    w[15,7]   R458      1
    w[15,7]   R459      1
    w[15,7]   normalized_inventory_15  -7
    w[15,8]   mass_15   1
    w[15,8]   R460      1
    w[15,8]   R461      1
    w[15,8]   normalized_inventory_15  -8
    w[15,9]   mass_15   1
    w[15,9]   R462      1
    w[15,9]   R463      1
    w[15,9]   normalized_inventory_15  -9
    w[15,10]  mass_15   1
    w[15,10]  R464      1
    w[15,10]  R465      1
    w[15,10]  normalized_inventory_15  -10
    w[15,11]  mass_15   1
    w[15,11]  R466      1
    w[15,11]  R467      1
    w[15,11]  normalized_inventory_15  -11
    w[15,12]  mass_15   1
    w[15,12]  R468      1
    w[15,12]  R469      1
    w[15,12]  normalized_inventory_15  -12
    w[15,13]  mass_15   1
    w[15,13]  R470      1
    w[15,13]  R471      1
    w[15,13]  normalized_inventory_15  -13
    w[15,14]  mass_15   1
    w[15,14]  R472      1
    w[15,14]  R473      1
    w[15,14]  normalized_inventory_15  -14
    w[15,15]  mass_15   1
    w[15,15]  R474      1
    w[15,15]  R475      1
    w[15,15]  normalized_inventory_15  -15
    w[15,16]  mass_15   1
    w[15,16]  R476      1
    w[15,16]  R477      1
    w[15,16]  normalized_inventory_15  -16
    w[15,17]  mass_15   1
    w[15,17]  R478      1
    w[15,17]  R479      1
    w[15,17]  normalized_inventory_15  -17
    w[15,18]  mass_15   1
    w[15,18]  R480      1
    w[15,18]  R481      1
    w[15,18]  normalized_inventory_15  -18
    w[15,19]  mass_15   1
    w[15,19]  R482      1
    w[15,19]  R483      1
    w[15,19]  normalized_inventory_15  -19
    w[16,0]   mass_16   1
    w[16,0]   R488      1
    w[16,0]   R489      1
    w[16,1]   mass_16   1
    w[16,1]   R490      1
    w[16,1]   R491      1
    w[16,1]   normalized_inventory_16  -1
    w[16,2]   mass_16   1
    w[16,2]   R492      1
    w[16,2]   R493      1
    w[16,2]   normalized_inventory_16  -2
    w[16,3]   mass_16   1
    w[16,3]   R494      1
    w[16,3]   R495      1
    w[16,3]   normalized_inventory_16  -3
    w[16,4]   mass_16   1
    w[16,4]   R496      1
    w[16,4]   R497      1
    w[16,4]   normalized_inventory_16  -4
    w[16,5]   mass_16   1
    w[16,5]   R498      1
    w[16,5]   R499      1
    w[16,5]   normalized_inventory_16  -5
    w[16,6]   mass_16   1
    w[16,6]   R500      1
    w[16,6]   R501      1
    w[16,6]   normalized_inventory_16  -6
    w[16,7]   mass_16   1
    w[16,7]   R502      1
    w[16,7]   R503      1
    w[16,7]   normalized_inventory_16  -7
    w[16,8]   mass_16   1
    w[16,8]   R504      1
    w[16,8]   R505      1
    w[16,8]   normalized_inventory_16  -8
    w[16,9]   mass_16   1
    w[16,9]   R506      1
    w[16,9]   R507      1
    w[16,9]   normalized_inventory_16  -9
    w[16,10]  mass_16   1
    w[16,10]  R508      1
    w[16,10]  R509      1
    w[16,10]  normalized_inventory_16  -10
    w[16,11]  mass_16   1
    w[16,11]  R510      1
    w[16,11]  R511      1
    w[16,11]  normalized_inventory_16  -11
    w[17,16]  mass_17   1
    w[17,16]  R516      1
    w[17,16]  R517      1
    w[17,16]  normalized_inventory_17  -16
    w[18,0]   mass_18   1
    w[18,0]   R522      1
    w[18,0]   R523      1
    w[18,1]   mass_18   1
    w[18,1]   R524      1
    w[18,1]   R525      1
    w[18,1]   normalized_inventory_18  -1
    w[18,2]   mass_18   1
    w[18,2]   R526      1
    w[18,2]   R527      1
    w[18,2]   normalized_inventory_18  -2
    w[18,3]   mass_18   1
    w[18,3]   R528      1
    w[18,3]   R529      1
    w[18,3]   normalized_inventory_18  -3
    w[18,4]   mass_18   1
    w[18,4]   R530      1
    w[18,4]   R531      1
    w[18,4]   normalized_inventory_18  -4
    w[18,5]   mass_18   1
    w[18,5]   R532      1
    w[18,5]   R533      1
    w[18,5]   normalized_inventory_18  -5
    w[18,6]   mass_18   1
    w[18,6]   R534      1
    w[18,6]   R535      1
    w[18,6]   normalized_inventory_18  -6
    w[18,7]   mass_18   1
    w[18,7]   R536      1
    w[18,7]   R537      1
    w[18,7]   normalized_inventory_18  -7
    w[18,8]   mass_18   1
    w[18,8]   R538      1
    w[18,8]   R539      1
    w[18,8]   normalized_inventory_18  -8
    w[18,9]   mass_18   1
    w[18,9]   R540      1
    w[18,9]   R541      1
    w[18,9]   normalized_inventory_18  -9
    w[18,10]  mass_18   1
    w[18,10]  R542      1
    w[18,10]  R543      1
    w[18,10]  normalized_inventory_18  -10
    w[18,11]  mass_18   1
    w[18,11]  R544      1
    w[18,11]  R545      1
    w[18,11]  normalized_inventory_18  -11
    w[18,12]  mass_18   1
    w[18,12]  R546      1
    w[18,12]  R547      1
    w[18,12]  normalized_inventory_18  -12
    w[18,13]  mass_18   1
    w[18,13]  R548      1
    w[18,13]  R549      1
    w[18,13]  normalized_inventory_18  -13
    w[18,14]  mass_18   1
    w[18,14]  R550      1
    w[18,14]  R551      1
    w[18,14]  normalized_inventory_18  -14
    w[18,15]  mass_18   1
    w[18,15]  R552      1
    w[18,15]  R553      1
    w[18,15]  normalized_inventory_18  -15
    w[19,0]   mass_19   1
    w[19,0]   R558      1
    w[19,0]   R559      1
    w[19,1]   mass_19   1
    w[19,1]   R560      1
    w[19,1]   R561      1
    w[19,1]   normalized_inventory_19  -1
    w[19,2]   mass_19   1
    w[19,2]   R562      1
    w[19,2]   R563      1
    w[19,2]   normalized_inventory_19  -2
    w[19,3]   mass_19   1
    w[19,3]   R564      1
    w[19,3]   R565      1
    w[19,3]   normalized_inventory_19  -3
    w[19,4]   mass_19   1
    w[19,4]   R566      1
    w[19,4]   R567      1
    w[19,4]   normalized_inventory_19  -4
    w[19,5]   mass_19   1
    w[19,5]   R568      1
    w[19,5]   R569      1
    w[19,5]   normalized_inventory_19  -5
    w[19,6]   mass_19   1
    w[19,6]   R570      1
    w[19,6]   R571      1
    w[19,6]   normalized_inventory_19  -6
    w[19,7]   mass_19   1
    w[19,7]   R572      1
    w[19,7]   R573      1
    w[19,7]   normalized_inventory_19  -7
    w[19,8]   mass_19   1
    w[19,8]   R574      1
    w[19,8]   R575      1
    w[19,8]   normalized_inventory_19  -8
    w[19,9]   mass_19   1
    w[19,9]   R576      1
    w[19,9]   R577      1
    w[19,9]   normalized_inventory_19  -9
    w[19,10]  mass_19   1
    w[19,10]  R578      1
    w[19,10]  R579      1
    w[19,10]  normalized_inventory_19  -10
    w[19,11]  mass_19   1
    w[19,11]  R580      1
    w[19,11]  R581      1
    w[19,11]  normalized_inventory_19  -11
    w[19,12]  mass_19   1
    w[19,12]  R582      1
    w[19,12]  R583      1
    w[19,12]  normalized_inventory_19  -12
    w[19,13]  mass_19   1
    w[19,13]  R584      1
    w[19,13]  R585      1
    w[19,13]  normalized_inventory_19  -13
    w[19,14]  mass_19   1
    w[19,14]  R586      1
    w[19,14]  R587      1
    w[19,14]  normalized_inventory_19  -14
    w[19,15]  mass_19   1
    w[19,15]  R588      1
    w[19,15]  R589      1
    w[19,15]  normalized_inventory_19  -15
    w[19,16]  mass_19   1
    w[19,16]  R590      1
    w[19,16]  R591      1
    w[19,16]  normalized_inventory_19  -16
    w[19,17]  mass_19   1
    w[19,17]  R592      1
    w[19,17]  R593      1
    w[19,17]  normalized_inventory_19  -17
    w[19,18]  mass_19   1
    w[19,18]  R594      1
    w[19,18]  R595      1
    w[19,18]  normalized_inventory_19  -18
    w[19,19]  mass_19   1
    w[19,19]  R596      1
    w[19,19]  R597      1
    w[19,19]  normalized_inventory_19  -19
    w[20,0]   mass_20   1
    w[20,0]   R602      1
    w[20,0]   R603      1
    w[20,1]   mass_20   1
    w[20,1]   R604      1
    w[20,1]   R605      1
    w[20,1]   normalized_inventory_20  -1
    w[20,2]   mass_20   1
    w[20,2]   R606      1
    w[20,2]   R607      1
    w[20,2]   normalized_inventory_20  -2
    w[20,3]   mass_20   1
    w[20,3]   R608      1
    w[20,3]   R609      1
    w[20,3]   normalized_inventory_20  -3
    w[20,4]   mass_20   1
    w[20,4]   R610      1
    w[20,4]   R611      1
    w[20,4]   normalized_inventory_20  -4
    w[20,5]   mass_20   1
    w[20,5]   R612      1
    w[20,5]   R613      1
    w[20,5]   normalized_inventory_20  -5
    w[20,6]   mass_20   1
    w[20,6]   R614      1
    w[20,6]   R615      1
    w[20,6]   normalized_inventory_20  -6
    w[20,7]   mass_20   1
    w[20,7]   R616      1
    w[20,7]   R617      1
    w[20,7]   normalized_inventory_20  -7
    w[20,8]   mass_20   1
    w[20,8]   R618      1
    w[20,8]   R619      1
    w[20,8]   normalized_inventory_20  -8
    w[20,9]   mass_20   1
    w[20,9]   R620      1
    w[20,9]   R621      1
    w[20,9]   normalized_inventory_20  -9
    w[20,10]  mass_20   1
    w[20,10]  R622      1
    w[20,10]  R623      1
    w[20,10]  normalized_inventory_20  -10
    w[20,11]  mass_20   1
    w[20,11]  R624      1
    w[20,11]  R625      1
    w[20,11]  normalized_inventory_20  -11
    w[20,12]  mass_20   1
    w[20,12]  R626      1
    w[20,12]  R627      1
    w[20,12]  normalized_inventory_20  -12
    w[20,13]  mass_20   1
    w[20,13]  R628      1
    w[20,13]  R629      1
    w[20,13]  normalized_inventory_20  -13
    w[20,14]  mass_20   1
    w[20,14]  R630      1
    w[20,14]  R631      1
    w[20,14]  normalized_inventory_20  -14
    w[20,15]  mass_20   1
    w[20,15]  R632      1
    w[20,15]  R633      1
    w[20,15]  normalized_inventory_20  -15
    w[21,0]   mass_21   1
    w[21,0]   R638      1
    w[21,0]   R639      1
    w[21,1]   mass_21   1
    w[21,1]   R640      1
    w[21,1]   R641      1
    w[21,1]   normalized_inventory_21  -1
    w[21,2]   mass_21   1
    w[21,2]   R642      1
    w[21,2]   R643      1
    w[21,2]   normalized_inventory_21  -2
    w[21,3]   mass_21   1
    w[21,3]   R644      1
    w[21,3]   R645      1
    w[21,3]   normalized_inventory_21  -3
    w[21,4]   mass_21   1
    w[21,4]   R646      1
    w[21,4]   R647      1
    w[21,4]   normalized_inventory_21  -4
    w[21,5]   mass_21   1
    w[21,5]   R648      1
    w[21,5]   R649      1
    w[21,5]   normalized_inventory_21  -5
    w[21,6]   mass_21   1
    w[21,6]   R650      1
    w[21,6]   R651      1
    w[21,6]   normalized_inventory_21  -6
    w[21,7]   mass_21   1
    w[21,7]   R652      1
    w[21,7]   R653      1
    w[21,7]   normalized_inventory_21  -7
    w[21,8]   mass_21   1
    w[21,8]   R654      1
    w[21,8]   R655      1
    w[21,8]   normalized_inventory_21  -8
    w[21,9]   mass_21   1
    w[21,9]   R656      1
    w[21,9]   R657      1
    w[21,9]   normalized_inventory_21  -9
    w[21,10]  mass_21   1
    w[21,10]  R658      1
    w[21,10]  R659      1
    w[21,10]  normalized_inventory_21  -10
    w[21,11]  mass_21   1
    w[21,11]  R660      1
    w[21,11]  R661      1
    w[21,11]  normalized_inventory_21  -11
    w[21,12]  mass_21   1
    w[21,12]  R662      1
    w[21,12]  R663      1
    w[21,12]  normalized_inventory_21  -12
    w[21,13]  mass_21   1
    w[21,13]  R664      1
    w[21,13]  R665      1
    w[21,13]  normalized_inventory_21  -13
    w[21,14]  mass_21   1
    w[21,14]  R666      1
    w[21,14]  R667      1
    w[21,14]  normalized_inventory_21  -14
    w[21,15]  mass_21   1
    w[21,15]  R668      1
    w[21,15]  R669      1
    w[21,15]  normalized_inventory_21  -15
    w[21,16]  mass_21   1
    w[21,16]  R670      1
    w[21,16]  R671      1
    w[21,16]  normalized_inventory_21  -16
    w[21,17]  mass_21   1
    w[21,17]  R672      1
    w[21,17]  R673      1
    w[21,17]  normalized_inventory_21  -17
    w[21,18]  mass_21   1
    w[21,18]  R674      1
    w[21,18]  R675      1
    w[21,18]  normalized_inventory_21  -18
    w[21,19]  mass_21   1
    w[21,19]  R676      1
    w[21,19]  R677      1
    w[21,19]  normalized_inventory_21  -19
    w[22,0]   mass_22   1
    w[22,0]   R682      1
    w[22,0]   R683      1
    w[22,1]   mass_22   1
    w[22,1]   R684      1
    w[22,1]   R685      1
    w[22,1]   normalized_inventory_22  -1
    w[22,2]   mass_22   1
    w[22,2]   R686      1
    w[22,2]   R687      1
    w[22,2]   normalized_inventory_22  -2
    w[22,3]   mass_22   1
    w[22,3]   R688      1
    w[22,3]   R689      1
    w[22,3]   normalized_inventory_22  -3
    w[22,4]   mass_22   1
    w[22,4]   R690      1
    w[22,4]   R691      1
    w[22,4]   normalized_inventory_22  -4
    w[22,5]   mass_22   1
    w[22,5]   R692      1
    w[22,5]   R693      1
    w[22,5]   normalized_inventory_22  -5
    w[22,6]   mass_22   1
    w[22,6]   R694      1
    w[22,6]   R695      1
    w[22,6]   normalized_inventory_22  -6
    w[22,7]   mass_22   1
    w[22,7]   R696      1
    w[22,7]   R697      1
    w[22,7]   normalized_inventory_22  -7
    w[22,8]   mass_22   1
    w[22,8]   R698      1
    w[22,8]   R699      1
    w[22,8]   normalized_inventory_22  -8
    w[22,9]   mass_22   1
    w[22,9]   R700      1
    w[22,9]   R701      1
    w[22,9]   normalized_inventory_22  -9
    w[22,10]  mass_22   1
    w[22,10]  R702      1
    w[22,10]  R703      1
    w[22,10]  normalized_inventory_22  -10
    w[22,11]  mass_22   1
    w[22,11]  R704      1
    w[22,11]  R705      1
    w[22,11]  normalized_inventory_22  -11
    w[22,12]  mass_22   1
    w[22,12]  R706      1
    w[22,12]  R707      1
    w[22,12]  normalized_inventory_22  -12
    w[22,13]  mass_22   1
    w[22,13]  R708      1
    w[22,13]  R709      1
    w[22,13]  normalized_inventory_22  -13
    w[22,14]  mass_22   1
    w[22,14]  R710      1
    w[22,14]  R711      1
    w[22,14]  normalized_inventory_22  -14
    w[22,15]  mass_22   1
    w[22,15]  R712      1
    w[22,15]  R713      1
    w[22,15]  normalized_inventory_22  -15
    w[22,16]  mass_22   1
    w[22,16]  R714      1
    w[22,16]  R715      1
    w[22,16]  normalized_inventory_22  -16
    w[22,17]  mass_22   1
    w[22,17]  R716      1
    w[22,17]  R717      1
    w[22,17]  normalized_inventory_22  -17
    w[22,18]  mass_22   1
    w[22,18]  R718      1
    w[22,18]  R719      1
    w[22,18]  normalized_inventory_22  -18
    w[22,19]  mass_22   1
    w[22,19]  R720      1
    w[22,19]  R721      1
    w[22,19]  normalized_inventory_22  -19
    w[23,0]   mass_23   1
    w[23,0]   R726      1
    w[23,0]   R727      1
    w[23,1]   mass_23   1
    w[23,1]   R728      1
    w[23,1]   R729      1
    w[23,1]   normalized_inventory_23  -1
    w[23,2]   mass_23   1
    w[23,2]   R730      1
    w[23,2]   R731      1
    w[23,2]   normalized_inventory_23  -2
    w[23,3]   mass_23   1
    w[23,3]   R732      1
    w[23,3]   R733      1
    w[23,3]   normalized_inventory_23  -3
    w[23,4]   mass_23   1
    w[23,4]   R734      1
    w[23,4]   R735      1
    w[23,4]   normalized_inventory_23  -4
    w[23,5]   mass_23   1
    w[23,5]   R736      1
    w[23,5]   R737      1
    w[23,5]   normalized_inventory_23  -5
    w[23,6]   mass_23   1
    w[23,6]   R738      1
    w[23,6]   R739      1
    w[23,6]   normalized_inventory_23  -6
    w[23,7]   mass_23   1
    w[23,7]   R740      1
    w[23,7]   R741      1
    w[23,7]   normalized_inventory_23  -7
    w[23,8]   mass_23   1
    w[23,8]   R742      1
    w[23,8]   R743      1
    w[23,8]   normalized_inventory_23  -8
    w[23,9]   mass_23   1
    w[23,9]   R744      1
    w[23,9]   R745      1
    w[23,9]   normalized_inventory_23  -9
    w[23,10]  mass_23   1
    w[23,10]  R746      1
    w[23,10]  R747      1
    w[23,10]  normalized_inventory_23  -10
    w[23,11]  mass_23   1
    w[23,11]  R748      1
    w[23,11]  R749      1
    w[23,11]  normalized_inventory_23  -11
    w[23,12]  mass_23   1
    w[23,12]  R750      1
    w[23,12]  R751      1
    w[23,12]  normalized_inventory_23  -12
    w[23,13]  mass_23   1
    w[23,13]  R752      1
    w[23,13]  R753      1
    w[23,13]  normalized_inventory_23  -13
    w[23,14]  mass_23   1
    w[23,14]  R754      1
    w[23,14]  R755      1
    w[23,14]  normalized_inventory_23  -14
    w[23,15]  mass_23   1
    w[23,15]  R756      1
    w[23,15]  R757      1
    w[23,15]  normalized_inventory_23  -15
    w[24,0]   mass_24   1
    w[24,0]   R762      1
    w[24,0]   R763      1
    w[24,1]   mass_24   1
    w[24,1]   R764      1
    w[24,1]   R765      1
    w[24,1]   normalized_inventory_24  -1
    w[24,2]   mass_24   1
    w[24,2]   R766      1
    w[24,2]   R767      1
    w[24,2]   normalized_inventory_24  -2
    w[24,3]   mass_24   1
    w[24,3]   R768      1
    w[24,3]   R769      1
    w[24,3]   normalized_inventory_24  -3
    w[24,4]   mass_24   1
    w[24,4]   R770      1
    w[24,4]   R771      1
    w[24,4]   normalized_inventory_24  -4
    w[24,5]   mass_24   1
    w[24,5]   R772      1
    w[24,5]   R773      1
    w[24,5]   normalized_inventory_24  -5
    w[24,6]   mass_24   1
    w[24,6]   R774      1
    w[24,6]   R775      1
    w[24,6]   normalized_inventory_24  -6
    w[24,7]   mass_24   1
    w[24,7]   R776      1
    w[24,7]   R777      1
    w[24,7]   normalized_inventory_24  -7
    w[24,8]   mass_24   1
    w[24,8]   R778      1
    w[24,8]   R779      1
    w[24,8]   normalized_inventory_24  -8
    w[25,0]   mass_25   1
    w[25,0]   R784      1
    w[25,0]   R785      1
    w[25,1]   mass_25   1
    w[25,1]   R786      1
    w[25,1]   R787      1
    w[25,1]   normalized_inventory_25  -1
    w[25,2]   mass_25   1
    w[25,2]   R788      1
    w[25,2]   R789      1
    w[25,2]   normalized_inventory_25  -2
    w[25,3]   mass_25   1
    w[25,3]   R790      1
    w[25,3]   R791      1
    w[25,3]   normalized_inventory_25  -3
    w[25,4]   mass_25   1
    w[25,4]   R792      1
    w[25,4]   R793      1
    w[25,4]   normalized_inventory_25  -4
    w[25,5]   mass_25   1
    w[25,5]   R794      1
    w[25,5]   R795      1
    w[25,5]   normalized_inventory_25  -5
    w[25,6]   mass_25   1
    w[25,6]   R796      1
    w[25,6]   R797      1
    w[25,6]   normalized_inventory_25  -6
    w[25,7]   mass_25   1
    w[25,7]   R798      1
    w[25,7]   R799      1
    w[25,7]   normalized_inventory_25  -7
    w[25,8]   mass_25   1
    w[25,8]   R800      1
    w[25,8]   R801      1
    w[25,8]   normalized_inventory_25  -8
    w[25,9]   mass_25   1
    w[25,9]   R802      1
    w[25,9]   R803      1
    w[25,9]   normalized_inventory_25  -9
    w[25,10]  mass_25   1
    w[25,10]  R804      1
    w[25,10]  R805      1
    w[25,10]  normalized_inventory_25  -10
    w[25,11]  mass_25   1
    w[25,11]  R806      1
    w[25,11]  R807      1
    w[25,11]  normalized_inventory_25  -11
    w[25,12]  mass_25   1
    w[25,12]  R808      1
    w[25,12]  R809      1
    w[25,12]  normalized_inventory_25  -12
    w[25,13]  mass_25   1
    w[25,13]  R810      1
    w[25,13]  R811      1
    w[25,13]  normalized_inventory_25  -13
    w[25,14]  mass_25   1
    w[25,14]  R812      1
    w[25,14]  R813      1
    w[25,14]  normalized_inventory_25  -14
    w[25,15]  mass_25   1
    w[25,15]  R814      1
    w[25,15]  R815      1
    w[25,15]  normalized_inventory_25  -15
    w[26,0]   mass_26   1
    w[26,0]   R820      1
    w[26,0]   R821      1
    w[26,1]   mass_26   1
    w[26,1]   R822      1
    w[26,1]   R823      1
    w[26,1]   normalized_inventory_26  -1
    w[26,2]   mass_26   1
    w[26,2]   R824      1
    w[26,2]   R825      1
    w[26,2]   normalized_inventory_26  -2
    w[26,3]   mass_26   1
    w[26,3]   R826      1
    w[26,3]   R827      1
    w[26,3]   normalized_inventory_26  -3
    w[26,4]   mass_26   1
    w[26,4]   R828      1
    w[26,4]   R829      1
    w[26,4]   normalized_inventory_26  -4
    w[26,5]   mass_26   1
    w[26,5]   R830      1
    w[26,5]   R831      1
    w[26,5]   normalized_inventory_26  -5
    w[26,6]   mass_26   1
    w[26,6]   R832      1
    w[26,6]   R833      1
    w[26,6]   normalized_inventory_26  -6
    w[26,7]   mass_26   1
    w[26,7]   R834      1
    w[26,7]   R835      1
    w[26,7]   normalized_inventory_26  -7
    w[26,8]   mass_26   1
    w[26,8]   R836      1
    w[26,8]   R837      1
    w[26,8]   normalized_inventory_26  -8
    w[26,9]   mass_26   1
    w[26,9]   R838      1
    w[26,9]   R839      1
    w[26,9]   normalized_inventory_26  -9
    w[26,10]  mass_26   1
    w[26,10]  R840      1
    w[26,10]  R841      1
    w[26,10]  normalized_inventory_26  -10
    w[26,11]  mass_26   1
    w[26,11]  R842      1
    w[26,11]  R843      1
    w[26,11]  normalized_inventory_26  -11
    w[26,12]  mass_26   1
    w[26,12]  R844      1
    w[26,12]  R845      1
    w[26,12]  normalized_inventory_26  -12
    w[26,13]  mass_26   1
    w[26,13]  R846      1
    w[26,13]  R847      1
    w[26,13]  normalized_inventory_26  -13
    w[26,14]  mass_26   1
    w[26,14]  R848      1
    w[26,14]  R849      1
    w[26,14]  normalized_inventory_26  -14
    w[26,15]  mass_26   1
    w[26,15]  R850      1
    w[26,15]  R851      1
    w[26,15]  normalized_inventory_26  -15
    w[27,0]   mass_27   1
    w[27,0]   R856      1
    w[27,0]   R857      1
    w[27,1]   mass_27   1
    w[27,1]   R858      1
    w[27,1]   R859      1
    w[27,1]   normalized_inventory_27  -1
    w[27,2]   mass_27   1
    w[27,2]   R860      1
    w[27,2]   R861      1
    w[27,2]   normalized_inventory_27  -2
    w[27,3]   mass_27   1
    w[27,3]   R862      1
    w[27,3]   R863      1
    w[27,3]   normalized_inventory_27  -3
    w[27,4]   mass_27   1
    w[27,4]   R864      1
    w[27,4]   R865      1
    w[27,4]   normalized_inventory_27  -4
    w[27,5]   mass_27   1
    w[27,5]   R866      1
    w[27,5]   R867      1
    w[27,5]   normalized_inventory_27  -5
    w[27,6]   mass_27   1
    w[27,6]   R868      1
    w[27,6]   R869      1
    w[27,6]   normalized_inventory_27  -6
    w[27,7]   mass_27   1
    w[27,7]   R870      1
    w[27,7]   R871      1
    w[27,7]   normalized_inventory_27  -7
    w[27,8]   mass_27   1
    w[27,8]   R872      1
    w[27,8]   R873      1
    w[27,8]   normalized_inventory_27  -8
    w[27,9]   mass_27   1
    w[27,9]   R874      1
    w[27,9]   R875      1
    w[27,9]   normalized_inventory_27  -9
    w[27,10]  mass_27   1
    w[27,10]  R876      1
    w[27,10]  R877      1
    w[27,10]  normalized_inventory_27  -10
    w[27,11]  mass_27   1
    w[27,11]  R878      1
    w[27,11]  R879      1
    w[27,11]  normalized_inventory_27  -11
    w[27,12]  mass_27   1
    w[27,12]  R880      1
    w[27,12]  R881      1
    w[27,12]  normalized_inventory_27  -12
    w[27,13]  mass_27   1
    w[27,13]  R882      1
    w[27,13]  R883      1
    w[27,13]  normalized_inventory_27  -13
    w[27,14]  mass_27   1
    w[27,14]  R884      1
    w[27,14]  R885      1
    w[27,14]  normalized_inventory_27  -14
    w[27,15]  mass_27   1
    w[27,15]  R886      1
    w[27,15]  R887      1
    w[27,15]  normalized_inventory_27  -15
    w[27,16]  mass_27   1
    w[27,16]  R888      1
    w[27,16]  R889      1
    w[27,16]  normalized_inventory_27  -16
    w[27,17]  mass_27   1
    w[27,17]  R890      1
    w[27,17]  R891      1
    w[27,17]  normalized_inventory_27  -17
    w[27,18]  mass_27   1
    w[27,18]  R892      1
    w[27,18]  R893      1
    w[27,18]  normalized_inventory_27  -18
    w[27,19]  mass_27   1
    w[27,19]  R894      1
    w[27,19]  R895      1
    w[27,19]  normalized_inventory_27  -19
    w[28,0]   mass_28   1
    w[28,0]   R900      1
    w[28,0]   R901      1
    w[28,1]   mass_28   1
    w[28,1]   R902      1
    w[28,1]   R903      1
    w[28,1]   normalized_inventory_28  -1
    w[28,2]   mass_28   1
    w[28,2]   R904      1
    w[28,2]   R905      1
    w[28,2]   normalized_inventory_28  -2
    w[28,3]   mass_28   1
    w[28,3]   R906      1
    w[28,3]   R907      1
    w[28,3]   normalized_inventory_28  -3
    w[28,4]   mass_28   1
    w[28,4]   R908      1
    w[28,4]   R909      1
    w[28,4]   normalized_inventory_28  -4
    w[28,5]   mass_28   1
    w[28,5]   R910      1
    w[28,5]   R911      1
    w[28,5]   normalized_inventory_28  -5
    w[28,6]   mass_28   1
    w[28,6]   R912      1
    w[28,6]   R913      1
    w[28,6]   normalized_inventory_28  -6
    w[28,7]   mass_28   1
    w[28,7]   R914      1
    w[28,7]   R915      1
    w[28,7]   normalized_inventory_28  -7
    w[28,8]   mass_28   1
    w[28,8]   R916      1
    w[28,8]   R917      1
    w[28,8]   normalized_inventory_28  -8
    w[28,9]   mass_28   1
    w[28,9]   R918      1
    w[28,9]   R919      1
    w[28,9]   normalized_inventory_28  -9
    w[28,10]  mass_28   1
    w[28,10]  R920      1
    w[28,10]  R921      1
    w[28,10]  normalized_inventory_28  -10
    w[28,11]  mass_28   1
    w[28,11]  R922      1
    w[28,11]  R923      1
    w[28,11]  normalized_inventory_28  -11
    w[28,12]  mass_28   1
    w[28,12]  R924      1
    w[28,12]  R925      1
    w[28,12]  normalized_inventory_28  -12
    w[28,13]  mass_28   1
    w[28,13]  R926      1
    w[28,13]  R927      1
    w[28,13]  normalized_inventory_28  -13
    w[28,14]  mass_28   1
    w[28,14]  R928      1
    w[28,14]  R929      1
    w[28,14]  normalized_inventory_28  -14
    w[28,15]  mass_28   1
    w[28,15]  R930      1
    w[28,15]  R931      1
    w[28,15]  normalized_inventory_28  -15
    w[29,0]   mass_29   1
    w[29,0]   R936      1
    w[29,0]   R937      1
    w[29,1]   mass_29   1
    w[29,1]   R938      1
    w[29,1]   R939      1
    w[29,1]   normalized_inventory_29  -1
    w[29,2]   mass_29   1
    w[29,2]   R940      1
    w[29,2]   R941      1
    w[29,2]   normalized_inventory_29  -2
    w[29,3]   mass_29   1
    w[29,3]   R942      1
    w[29,3]   R943      1
    w[29,3]   normalized_inventory_29  -3
    w[29,4]   mass_29   1
    w[29,4]   R944      1
    w[29,4]   R945      1
    w[29,4]   normalized_inventory_29  -4
    w[29,5]   mass_29   1
    w[29,5]   R946      1
    w[29,5]   R947      1
    w[29,5]   normalized_inventory_29  -5
    w[29,6]   mass_29   1
    w[29,6]   R948      1
    w[29,6]   R949      1
    w[29,6]   normalized_inventory_29  -6
    w[29,7]   mass_29   1
    w[29,7]   R950      1
    w[29,7]   R951      1
    w[29,7]   normalized_inventory_29  -7
    w[29,8]   mass_29   1
    w[29,8]   R952      1
    w[29,8]   R953      1
    w[29,8]   normalized_inventory_29  -8
    w[29,9]   mass_29   1
    w[29,9]   R954      1
    w[29,9]   R955      1
    w[29,9]   normalized_inventory_29  -9
    w[29,10]  mass_29   1
    w[29,10]  R956      1
    w[29,10]  R957      1
    w[29,10]  normalized_inventory_29  -10
    w[29,11]  mass_29   1
    w[29,11]  R958      1
    w[29,11]  R959      1
    w[29,11]  normalized_inventory_29  -11
    w[29,12]  mass_29   1
    w[29,12]  R960      1
    w[29,12]  R961      1
    w[29,12]  normalized_inventory_29  -12
    w[29,13]  mass_29   1
    w[29,13]  R962      1
    w[29,13]  R963      1
    w[29,13]  normalized_inventory_29  -13
    w[29,14]  mass_29   1
    w[29,14]  R964      1
    w[29,14]  R965      1
    w[29,14]  normalized_inventory_29  -14
    w[29,15]  mass_29   1
    w[29,15]  R966      1
    w[29,15]  R967      1
    w[29,15]  normalized_inventory_29  -15
    w[30,0]   mass_30   1
    w[30,0]   R972      1
    w[30,0]   R973      1
    w[30,1]   mass_30   1
    w[30,1]   R974      1
    w[30,1]   R975      1
    w[30,1]   normalized_inventory_30  -1
    w[30,2]   mass_30   1
    w[30,2]   R976      1
    w[30,2]   R977      1
    w[30,2]   normalized_inventory_30  -2
    w[30,3]   mass_30   1
    w[30,3]   R978      1
    w[30,3]   R979      1
    w[30,3]   normalized_inventory_30  -3
    w[30,4]   mass_30   1
    w[30,4]   R980      1
    w[30,4]   R981      1
    w[30,4]   normalized_inventory_30  -4
    w[30,5]   mass_30   1
    w[30,5]   R982      1
    w[30,5]   R983      1
    w[30,5]   normalized_inventory_30  -5
    w[30,6]   mass_30   1
    w[30,6]   R984      1
    w[30,6]   R985      1
    w[30,6]   normalized_inventory_30  -6
    w[30,7]   mass_30   1
    w[30,7]   R986      1
    w[30,7]   R987      1
    w[30,7]   normalized_inventory_30  -7
    w[30,8]   mass_30   1
    w[30,8]   R988      1
    w[30,8]   R989      1
    w[30,8]   normalized_inventory_30  -8
    w[30,9]   mass_30   1
    w[30,9]   R990      1
    w[30,9]   R991      1
    w[30,9]   normalized_inventory_30  -9
    w[30,10]  mass_30   1
    w[30,10]  R992      1
    w[30,10]  R993      1
    w[30,10]  normalized_inventory_30  -10
    w[30,11]  mass_30   1
    w[30,11]  R994      1
    w[30,11]  R995      1
    w[30,11]  normalized_inventory_30  -11
    w[30,12]  mass_30   1
    w[30,12]  R996      1
    w[30,12]  R997      1
    w[30,12]  normalized_inventory_30  -12
    w[30,13]  mass_30   1
    w[30,13]  R998      1
    w[30,13]  R999      1
    w[30,13]  normalized_inventory_30  -13
    w[30,14]  mass_30   1
    w[30,14]  R1000     1
    w[30,14]  R1001     1
    w[30,14]  normalized_inventory_30  -14
    w[30,15]  mass_30   1
    w[30,15]  R1002     1
    w[30,15]  R1003     1
    w[30,15]  normalized_inventory_30  -15
    w[30,16]  mass_30   1
    w[30,16]  R1004     1
    w[30,16]  R1005     1
    w[30,16]  normalized_inventory_30  -16
    w[30,17]  mass_30   1
    w[30,17]  R1006     1
    w[30,17]  R1007     1
    w[30,17]  normalized_inventory_30  -17
    w[30,18]  mass_30   1
    w[30,18]  R1008     1
    w[30,18]  R1009     1
    w[30,18]  normalized_inventory_30  -18
    w[30,19]  mass_30   1
    w[30,19]  R1010     1
    w[30,19]  R1011     1
    w[30,19]  normalized_inventory_30  -19
    w[30,20]  mass_30   1
    w[30,20]  R1012     1
    w[30,20]  R1013     1
    w[30,20]  normalized_inventory_30  -20
    w[31,0]   mass_31   1
    w[31,0]   R1018     1
    w[31,0]   R1019     1
    w[31,1]   mass_31   1
    w[31,1]   R1020     1
    w[31,1]   R1021     1
    w[31,1]   normalized_inventory_31  -1
    w[31,2]   mass_31   1
    w[31,2]   R1022     1
    w[31,2]   R1023     1
    w[31,2]   normalized_inventory_31  -2
    w[31,3]   mass_31   1
    w[31,3]   R1024     1
    w[31,3]   R1025     1
    w[31,3]   normalized_inventory_31  -3
    w[31,4]   mass_31   1
    w[31,4]   R1026     1
    w[31,4]   R1027     1
    w[31,4]   normalized_inventory_31  -4
    w[31,5]   mass_31   1
    w[31,5]   R1028     1
    w[31,5]   R1029     1
    w[31,5]   normalized_inventory_31  -5
    w[31,6]   mass_31   1
    w[31,6]   R1030     1
    w[31,6]   R1031     1
    w[31,6]   normalized_inventory_31  -6
    w[31,7]   mass_31   1
    w[31,7]   R1032     1
    w[31,7]   R1033     1
    w[31,7]   normalized_inventory_31  -7
    w[31,8]   mass_31   1
    w[31,8]   R1034     1
    w[31,8]   R1035     1
    w[31,8]   normalized_inventory_31  -8
    w[31,9]   mass_31   1
    w[31,9]   R1036     1
    w[31,9]   R1037     1
    w[31,9]   normalized_inventory_31  -9
    w[31,10]  mass_31   1
    w[31,10]  R1038     1
    w[31,10]  R1039     1
    w[31,10]  normalized_inventory_31  -10
    w[31,11]  mass_31   1
    w[31,11]  R1040     1
    w[31,11]  R1041     1
    w[31,11]  normalized_inventory_31  -11
    w[31,12]  mass_31   1
    w[31,12]  R1042     1
    w[31,12]  R1043     1
    w[31,12]  normalized_inventory_31  -12
    w[31,13]  mass_31   1
    w[31,13]  R1044     1
    w[31,13]  R1045     1
    w[31,13]  normalized_inventory_31  -13
    w[31,14]  mass_31   1
    w[31,14]  R1046     1
    w[31,14]  R1047     1
    w[31,14]  normalized_inventory_31  -14
    w[31,15]  mass_31   1
    w[31,15]  R1048     1
    w[31,15]  R1049     1
    w[31,15]  normalized_inventory_31  -15
    w[32,0]   mass_32   1
    w[32,0]   R1054     1
    w[32,0]   R1055     1
    w[32,1]   mass_32   1
    w[32,1]   R1056     1
    w[32,1]   R1057     1
    w[32,1]   normalized_inventory_32  -1
    w[32,2]   mass_32   1
    w[32,2]   R1058     1
    w[32,2]   R1059     1
    w[32,2]   normalized_inventory_32  -2
    w[32,3]   mass_32   1
    w[32,3]   R1060     1
    w[32,3]   R1061     1
    w[32,3]   normalized_inventory_32  -3
    w[32,4]   mass_32   1
    w[32,4]   R1062     1
    w[32,4]   R1063     1
    w[32,4]   normalized_inventory_32  -4
    w[32,5]   mass_32   1
    w[32,5]   R1064     1
    w[32,5]   R1065     1
    w[32,5]   normalized_inventory_32  -5
    w[32,6]   mass_32   1
    w[32,6]   R1066     1
    w[32,6]   R1067     1
    w[32,6]   normalized_inventory_32  -6
    w[32,7]   mass_32   1
    w[32,7]   R1068     1
    w[32,7]   R1069     1
    w[32,7]   normalized_inventory_32  -7
    w[32,8]   mass_32   1
    w[32,8]   R1070     1
    w[32,8]   R1071     1
    w[32,8]   normalized_inventory_32  -8
    w[32,9]   mass_32   1
    w[32,9]   R1072     1
    w[32,9]   R1073     1
    w[32,9]   normalized_inventory_32  -9
    w[32,10]  mass_32   1
    w[32,10]  R1074     1
    w[32,10]  R1075     1
    w[32,10]  normalized_inventory_32  -10
    w[32,11]  mass_32   1
    w[32,11]  R1076     1
    w[32,11]  R1077     1
    w[32,11]  normalized_inventory_32  -11
    w[32,12]  mass_32   1
    w[32,12]  R1078     1
    w[32,12]  R1079     1
    w[32,12]  normalized_inventory_32  -12
    w[32,13]  mass_32   1
    w[32,13]  R1080     1
    w[32,13]  R1081     1
    w[32,13]  normalized_inventory_32  -13
    w[32,14]  mass_32   1
    w[32,14]  R1082     1
    w[32,14]  R1083     1
    w[32,14]  normalized_inventory_32  -14
    w[32,15]  mass_32   1
    w[32,15]  R1084     1
    w[32,15]  R1085     1
    w[32,15]  normalized_inventory_32  -15
    w[33,0]   mass_33   1
    w[33,0]   R1090     1
    w[33,0]   R1091     1
    w[33,1]   mass_33   1
    w[33,1]   R1092     1
    w[33,1]   R1093     1
    w[33,1]   normalized_inventory_33  -1
    w[33,2]   mass_33   1
    w[33,2]   R1094     1
    w[33,2]   R1095     1
    w[33,2]   normalized_inventory_33  -2
    w[33,3]   mass_33   1
    w[33,3]   R1096     1
    w[33,3]   R1097     1
    w[33,3]   normalized_inventory_33  -3
    w[33,4]   mass_33   1
    w[33,4]   R1098     1
    w[33,4]   R1099     1
    w[33,4]   normalized_inventory_33  -4
    w[33,5]   mass_33   1
    w[33,5]   R1100     1
    w[33,5]   R1101     1
    w[33,5]   normalized_inventory_33  -5
    w[33,6]   mass_33   1
    w[33,6]   R1102     1
    w[33,6]   R1103     1
    w[33,6]   normalized_inventory_33  -6
    w[33,7]   mass_33   1
    w[33,7]   R1104     1
    w[33,7]   R1105     1
    w[33,7]   normalized_inventory_33  -7
    w[33,8]   mass_33   1
    w[33,8]   R1106     1
    w[33,8]   R1107     1
    w[33,8]   normalized_inventory_33  -8
    w[33,9]   mass_33   1
    w[33,9]   R1108     1
    w[33,9]   R1109     1
    w[33,9]   normalized_inventory_33  -9
    w[33,10]  mass_33   1
    w[33,10]  R1110     1
    w[33,10]  R1111     1
    w[33,10]  normalized_inventory_33  -10
    w[33,11]  mass_33   1
    w[33,11]  R1112     1
    w[33,11]  R1113     1
    w[33,11]  normalized_inventory_33  -11
    w[33,12]  mass_33   1
    w[33,12]  R1114     1
    w[33,12]  R1115     1
    w[33,12]  normalized_inventory_33  -12
    w[33,13]  mass_33   1
    w[33,13]  R1116     1
    w[33,13]  R1117     1
    w[33,13]  normalized_inventory_33  -13
    w[33,14]  mass_33   1
    w[33,14]  R1118     1
    w[33,14]  R1119     1
    w[33,14]  normalized_inventory_33  -14
    w[33,15]  mass_33   1
    w[33,15]  R1120     1
    w[33,15]  R1121     1
    w[33,15]  normalized_inventory_33  -15
    w[33,16]  mass_33   1
    w[33,16]  R1122     1
    w[33,16]  R1123     1
    w[33,16]  normalized_inventory_33  -16
    w[33,17]  mass_33   1
    w[33,17]  R1124     1
    w[33,17]  R1125     1
    w[33,17]  normalized_inventory_33  -17
    w[33,18]  mass_33   1
    w[33,18]  R1126     1
    w[33,18]  R1127     1
    w[33,18]  normalized_inventory_33  -18
    w[33,19]  mass_33   1
    w[33,19]  R1128     1
    w[33,19]  R1129     1
    w[33,19]  normalized_inventory_33  -19
    w[33,20]  mass_33   1
    w[33,20]  R1130     1
    w[33,20]  R1131     1
    w[33,20]  normalized_inventory_33  -20
    w[33,21]  mass_33   1
    w[33,21]  R1132     1
    w[33,21]  R1133     1
    w[33,21]  normalized_inventory_33  -21
    w[33,22]  mass_33   1
    w[33,22]  R1134     1
    w[33,22]  R1135     1
    w[33,22]  normalized_inventory_33  -22
    w[33,23]  mass_33   1
    w[33,23]  R1136     1
    w[33,23]  R1137     1
    w[33,23]  normalized_inventory_33  -23
    w[33,24]  mass_33   1
    w[33,24]  R1138     1
    w[33,24]  R1139     1
    w[33,24]  normalized_inventory_33  -24
    w[34,0]   mass_34   1
    w[34,0]   R1144     1
    w[34,0]   R1145     1
    w[34,1]   mass_34   1
    w[34,1]   R1146     1
    w[34,1]   R1147     1
    w[34,1]   normalized_inventory_34  -1
    w[34,2]   mass_34   1
    w[34,2]   R1148     1
    w[34,2]   R1149     1
    w[34,2]   normalized_inventory_34  -2
    w[34,3]   mass_34   1
    w[34,3]   R1150     1
    w[34,3]   R1151     1
    w[34,3]   normalized_inventory_34  -3
    w[34,4]   mass_34   1
    w[34,4]   R1152     1
    w[34,4]   R1153     1
    w[34,4]   normalized_inventory_34  -4
    w[34,5]   mass_34   1
    w[34,5]   R1154     1
    w[34,5]   R1155     1
    w[34,5]   normalized_inventory_34  -5
    w[34,6]   mass_34   1
    w[34,6]   R1156     1
    w[34,6]   R1157     1
    w[34,6]   normalized_inventory_34  -6
    w[34,7]   mass_34   1
    w[34,7]   R1158     1
    w[34,7]   R1159     1
    w[34,7]   normalized_inventory_34  -7
    w[34,8]   mass_34   1
    w[34,8]   R1160     1
    w[34,8]   R1161     1
    w[34,8]   normalized_inventory_34  -8
    w[34,9]   mass_34   1
    w[34,9]   R1162     1
    w[34,9]   R1163     1
    w[34,9]   normalized_inventory_34  -9
    w[34,10]  mass_34   1
    w[34,10]  R1164     1
    w[34,10]  R1165     1
    w[34,10]  normalized_inventory_34  -10
    w[34,11]  mass_34   1
    w[34,11]  R1166     1
    w[34,11]  R1167     1
    w[34,11]  normalized_inventory_34  -11
    w[34,12]  mass_34   1
    w[34,12]  R1168     1
    w[34,12]  R1169     1
    w[34,12]  normalized_inventory_34  -12
    w[34,13]  mass_34   1
    w[34,13]  R1170     1
    w[34,13]  R1171     1
    w[34,13]  normalized_inventory_34  -13
    w[34,14]  mass_34   1
    w[34,14]  R1172     1
    w[34,14]  R1173     1
    w[34,14]  normalized_inventory_34  -14
    w[34,15]  mass_34   1
    w[34,15]  R1174     1
    w[34,15]  R1175     1
    w[34,15]  normalized_inventory_34  -15
    w[35,0]   mass_35   1
    w[35,0]   R1180     1
    w[35,0]   R1181     1
    w[35,1]   mass_35   1
    w[35,1]   R1182     1
    w[35,1]   R1183     1
    w[35,1]   normalized_inventory_35  -1
    w[35,2]   mass_35   1
    w[35,2]   R1184     1
    w[35,2]   R1185     1
    w[35,2]   normalized_inventory_35  -2
    w[35,3]   mass_35   1
    w[35,3]   R1186     1
    w[35,3]   R1187     1
    w[35,3]   normalized_inventory_35  -3
    w[35,4]   mass_35   1
    w[35,4]   R1188     1
    w[35,4]   R1189     1
    w[35,4]   normalized_inventory_35  -4
    w[35,5]   mass_35   1
    w[35,5]   R1190     1
    w[35,5]   R1191     1
    w[35,5]   normalized_inventory_35  -5
    w[35,6]   mass_35   1
    w[35,6]   R1192     1
    w[35,6]   R1193     1
    w[35,6]   normalized_inventory_35  -6
    w[35,7]   mass_35   1
    w[35,7]   R1194     1
    w[35,7]   R1195     1
    w[35,7]   normalized_inventory_35  -7
    w[35,8]   mass_35   1
    w[35,8]   R1196     1
    w[35,8]   R1197     1
    w[35,8]   normalized_inventory_35  -8
    w[35,9]   mass_35   1
    w[35,9]   R1198     1
    w[35,9]   R1199     1
    w[35,9]   normalized_inventory_35  -9
    w[35,10]  mass_35   1
    w[35,10]  R1200     1
    w[35,10]  R1201     1
    w[35,10]  normalized_inventory_35  -10
    w[35,11]  mass_35   1
    w[35,11]  R1202     1
    w[35,11]  R1203     1
    w[35,11]  normalized_inventory_35  -11
    w[35,12]  mass_35   1
    w[35,12]  R1204     1
    w[35,12]  R1205     1
    w[35,12]  normalized_inventory_35  -12
    w[35,13]  mass_35   1
    w[35,13]  R1206     1
    w[35,13]  R1207     1
    w[35,13]  normalized_inventory_35  -13
    w[35,14]  mass_35   1
    w[35,14]  R1208     1
    w[35,14]  R1209     1
    w[35,14]  normalized_inventory_35  -14
    w[35,15]  mass_35   1
    w[35,15]  R1210     1
    w[35,15]  R1211     1
    w[35,15]  normalized_inventory_35  -15
    w[35,16]  mass_35   1
    w[35,16]  R1212     1
    w[35,16]  R1213     1
    w[35,16]  normalized_inventory_35  -16
    w[35,17]  mass_35   1
    w[35,17]  R1214     1
    w[35,17]  R1215     1
    w[35,17]  normalized_inventory_35  -17
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         mass_21   -1
    t         mass_22   -1
    t         mass_23   -1
    t         mass_24   -1
    t         mass_25   -1
    t         mass_26   -1
    t         mass_27   -1
    t         mass_28   -1
    t         mass_29   -1
    t         mass_30   -1
    t         mass_31   -1
    t         mass_32   -1
    t         mass_33   -1
    t         mass_34   -1
    t         mass_35   -1
    t         scaled_stock_lower  -251
    t         scaled_stock_upper  -326
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -0.125
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -8.3333333333333329e-02
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -1.4285714285714285e-01
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -1.4285714285714285e-01
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -0.125
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -1.1111111111111110e-01
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -0.1
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -1.4285714285714285e-01
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -0.1
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -1.6666666666666666e-01
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -1.4285714285714285e-01
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -0.125
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -0.1
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -0.1
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -0.1
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -0.2
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -1.1111111111111110e-01
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -1.4285714285714285e-01
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -1.1111111111111110e-01
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -1.4285714285714285e-01
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    z[21]     normalized_inventory_21  1
    z[21]     normalized_ratio_21  -1.1111111111111110e-01
    z[21]     scaled_stock_lower  1
    z[21]     scaled_stock_upper  1
    z[22]     normalized_inventory_22  1
    z[22]     normalized_ratio_22  -0.1
    z[22]     scaled_stock_lower  1
    z[22]     scaled_stock_upper  1
    z[23]     normalized_inventory_23  1
    z[23]     normalized_ratio_23  -0.125
    z[23]     scaled_stock_lower  1
    z[23]     scaled_stock_upper  1
    z[24]     normalized_inventory_24  1
    z[24]     normalized_ratio_24  -0.25
    z[24]     scaled_stock_lower  1
    z[24]     scaled_stock_upper  1
    z[25]     normalized_inventory_25  1
    z[25]     normalized_ratio_25  -1.4285714285714285e-01
    z[25]     scaled_stock_lower  1
    z[25]     scaled_stock_upper  1
    z[26]     normalized_inventory_26  1
    z[26]     normalized_ratio_26  -0.125
    z[26]     scaled_stock_lower  1
    z[26]     scaled_stock_upper  1
    z[27]     normalized_inventory_27  1
    z[27]     normalized_ratio_27  -1.1111111111111110e-01
    z[27]     scaled_stock_lower  1
    z[27]     scaled_stock_upper  1
    z[28]     normalized_inventory_28  1
    z[28]     normalized_ratio_28  -1.4285714285714285e-01
    z[28]     scaled_stock_lower  1
    z[28]     scaled_stock_upper  1
    z[29]     normalized_inventory_29  1
    z[29]     normalized_ratio_29  -1.4285714285714285e-01
    z[29]     scaled_stock_lower  1
    z[29]     scaled_stock_upper  1
    z[30]     normalized_inventory_30  1
    z[30]     normalized_ratio_30  -9.0909090909090912e-02
    z[30]     scaled_stock_lower  1
    z[30]     scaled_stock_upper  1
    z[31]     normalized_inventory_31  1
    z[31]     normalized_ratio_31  -1.4285714285714285e-01
    z[31]     scaled_stock_lower  1
    z[31]     scaled_stock_upper  1
    z[32]     normalized_inventory_32  1
    z[32]     normalized_ratio_32  -0.125
    z[32]     scaled_stock_lower  1
    z[32]     scaled_stock_upper  1
    z[33]     normalized_inventory_33  1
    z[33]     normalized_ratio_33  -7.6923076923076927e-02
    z[33]     scaled_stock_lower  1
    z[33]     scaled_stock_upper  1
    z[34]     normalized_inventory_34  1
    z[34]     normalized_ratio_34  -0.125
    z[34]     scaled_stock_lower  1
    z[34]     scaled_stock_upper  1
    z[35]     normalized_inventory_35  1
    z[35]     normalized_ratio_35  -1.1111111111111110e-01
    z[35]     scaled_stock_lower  1
    z[35]     scaled_stock_upper  1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      R1223     -1
    r[1]      R1224     1
    r[1]      R1225     -1
    r[1]      R1226     1
    r[1]      R1227     -1
    r[1]      R1228     1
    r[1]      R1229     -1
    r[1]      R1230     1
    r[1]      R1231     -1
    r[1]      R1232     1
    r[1]      R1233     -1
    r[1]      R1234     1
    r[1]      R1235     -1
    r[1]      R1236     1
    r[1]      R1237     -1
    r[1]      R1238     1
    r[1]      R1239     -1
    r[1]      R1240     1
    r[1]      R1241     -1
    r[1]      R1242     1
    r[1]      R1243     -1
    r[1]      R1244     1
    r[1]      R1245     -1
    r[1]      R1246     1
    r[1]      R1247     -1
    r[1]      R1248     1
    r[1]      R1249     -1
    r[1]      R1250     1
    r[1]      R1251     -1
    r[1]      R1252     1
    r[1]      R1253     -1
    r[1]      R1254     1
    r[1]      R1255     -1
    r[1]      R1256     1
    r[1]      R1257     -1
    r[1]      R1258     1
    r[1]      R1259     -1
    r[1]      R1260     1
    r[1]      R1261     -1
    r[1]      R1262     1
    r[1]      R1263     -1
    r[1]      R1264     1
    r[1]      R1265     -1
    r[1]      R1266     1
    r[1]      R1267     -1
    r[1]      R1268     1
    r[1]      R1269     -1
    r[1]      R1270     1
    r[1]      R1271     -1
    r[1]      R1272     1
    r[1]      R1273     -1
    r[1]      R1274     1
    r[1]      R1275     -1
    r[1]      R1276     1
    r[1]      R1277     -1
    r[1]      R1278     1
    r[1]      R1279     -1
    r[1]      R1280     1
    r[1]      R1281     -1
    r[1]      R1282     1
    r[1]      R1283     -1
    r[1]      R1284     1
    r[1]      R1285     -1
    r[1]      R1286     1
    r[1]      R1287     -1
    r[1]      R1288     1
    r[1]      R1289     -1
    r[1]      R1290     1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      R1223     1
    r[2]      R1224     -1
    r[2]      R1291     -1
    r[2]      R1292     1
    r[2]      R1293     -1
    r[2]      R1294     1
    r[2]      R1295     -1
    r[2]      R1296     1
    r[2]      R1297     -1
    r[2]      R1298     1
    r[2]      R1299     -1
    r[2]      R1300     1
    r[2]      R1301     -1
    r[2]      R1302     1
    r[2]      R1303     -1
    r[2]      R1304     1
    r[2]      R1305     -1
    r[2]      R1306     1
    r[2]      R1307     -1
    r[2]      R1308     1
    r[2]      R1309     -1
    r[2]      R1310     1
    r[2]      R1311     -1
    r[2]      R1312     1
    r[2]      R1313     -1
    r[2]      R1314     1
    r[2]      R1315     -1
    r[2]      R1316     1
    r[2]      R1317     -1
    r[2]      R1318     1
    r[2]      R1319     -1
    r[2]      R1320     1
    r[2]      R1321     -1
    r[2]      R1322     1
    r[2]      R1323     -1
    r[2]      R1324     1
    r[2]      R1325     -1
    r[2]      R1326     1
    r[2]      R1327     -1
    r[2]      R1328     1
    r[2]      R1329     -1
    r[2]      R1330     1
    r[2]      R1331     -1
    r[2]      R1332     1
    r[2]      R1333     -1
    r[2]      R1334     1
    r[2]      R1335     -1
    r[2]      R1336     1
    r[2]      R1337     -1
    r[2]      R1338     1
    r[2]      R1339     -1
    r[2]      R1340     1
    r[2]      R1341     -1
    r[2]      R1342     1
    r[2]      R1343     -1
    r[2]      R1344     1
    r[2]      R1345     -1
    r[2]      R1346     1
    r[2]      R1347     -1
    r[2]      R1348     1
    r[2]      R1349     -1
    r[2]      R1350     1
    r[2]      R1351     -1
    r[2]      R1352     1
    r[2]      R1353     -1
    r[2]      R1354     1
    r[2]      R1355     -1
    r[2]      R1356     1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      R1225     1
    r[3]      R1226     -1
    r[3]      R1291     1
    r[3]      R1292     -1
    r[3]      R1357     -1
    r[3]      R1358     1
    r[3]      R1359     -1
    r[3]      R1360     1
    r[3]      R1361     -1
    r[3]      R1362     1
    r[3]      R1363     -1
    r[3]      R1364     1
    r[3]      R1365     -1
    r[3]      R1366     1
    r[3]      R1367     -1
    r[3]      R1368     1
    r[3]      R1369     -1
    r[3]      R1370     1
    r[3]      R1371     -1
    r[3]      R1372     1
    r[3]      R1373     -1
    r[3]      R1374     1
    r[3]      R1375     -1
    r[3]      R1376     1
    r[3]      R1377     -1
    r[3]      R1378     1
    r[3]      R1379     -1
    r[3]      R1380     1
    r[3]      R1381     -1
    r[3]      R1382     1
    r[3]      R1383     -1
    r[3]      R1384     1
    r[3]      R1385     -1
    r[3]      R1386     1
    r[3]      R1387     -1
    r[3]      R1388     1
    r[3]      R1389     -1
    r[3]      R1390     1
    r[3]      R1391     -1
    r[3]      R1392     1
    r[3]      R1393     -1
    r[3]      R1394     1
    r[3]      R1395     -1
    r[3]      R1396     1
    r[3]      R1397     -1
    r[3]      R1398     1
    r[3]      R1399     -1
    r[3]      R1400     1
    r[3]      R1401     -1
    r[3]      R1402     1
    r[3]      R1403     -1
    r[3]      R1404     1
    r[3]      R1405     -1
    r[3]      R1406     1
    r[3]      R1407     -1
    r[3]      R1408     1
    r[3]      R1409     -1
    r[3]      R1410     1
    r[3]      R1411     -1
    r[3]      R1412     1
    r[3]      R1413     -1
    r[3]      R1414     1
    r[3]      R1415     -1
    r[3]      R1416     1
    r[3]      R1417     -1
    r[3]      R1418     1
    r[3]      R1419     -1
    r[3]      R1420     1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      R1227     1
    r[4]      R1228     -1
    r[4]      R1293     1
    r[4]      R1294     -1
    r[4]      R1357     1
    r[4]      R1358     -1
    r[4]      R1421     -1
    r[4]      R1422     1
    r[4]      R1423     -1
    r[4]      R1424     1
    r[4]      R1425     -1
    r[4]      R1426     1
    r[4]      R1427     -1
    r[4]      R1428     1
    r[4]      R1429     -1
    r[4]      R1430     1
    r[4]      R1431     -1
    r[4]      R1432     1
    r[4]      R1433     -1
    r[4]      R1434     1
    r[4]      R1435     -1
    r[4]      R1436     1
    r[4]      R1437     -1
    r[4]      R1438     1
    r[4]      R1439     -1
    r[4]      R1440     1
    r[4]      R1441     -1
    r[4]      R1442     1
    r[4]      R1443     -1
    r[4]      R1444     1
    r[4]      R1445     -1
    r[4]      R1446     1
    r[4]      R1447     -1
    r[4]      R1448     1
    r[4]      R1449     -1
    r[4]      R1450     1
    r[4]      R1451     -1
    r[4]      R1452     1
    r[4]      R1453     -1
    r[4]      R1454     1
    r[4]      R1455     -1
    r[4]      R1456     1
    r[4]      R1457     -1
    r[4]      R1458     1
    r[4]      R1459     -1
    r[4]      R1460     1
    r[4]      R1461     -1
    r[4]      R1462     1
    r[4]      R1463     -1
    r[4]      R1464     1
    r[4]      R1465     -1
    r[4]      R1466     1
    r[4]      R1467     -1
    r[4]      R1468     1
    r[4]      R1469     -1
    r[4]      R1470     1
    r[4]      R1471     -1
    r[4]      R1472     1
    r[4]      R1473     -1
    r[4]      R1474     1
    r[4]      R1475     -1
    r[4]      R1476     1
    r[4]      R1477     -1
    r[4]      R1478     1
    r[4]      R1479     -1
    r[4]      R1480     1
    r[4]      R1481     -1
    r[4]      R1482     1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      R1229     1
    r[5]      R1230     -1
    r[5]      R1295     1
    r[5]      R1296     -1
    r[5]      R1359     1
    r[5]      R1360     -1
    r[5]      R1421     1
    r[5]      R1422     -1
    r[5]      R1483     -1
    r[5]      R1484     1
    r[5]      R1485     -1
    r[5]      R1486     1
    r[5]      R1487     -1
    r[5]      R1488     1
    r[5]      R1489     -1
    r[5]      R1490     1
    r[5]      R1491     -1
    r[5]      R1492     1
    r[5]      R1493     -1
    r[5]      R1494     1
    r[5]      R1495     -1
    r[5]      R1496     1
    r[5]      R1497     -1
    r[5]      R1498     1
    r[5]      R1499     -1
    r[5]      R1500     1
    r[5]      R1501     -1
    r[5]      R1502     1
    r[5]      R1503     -1
    r[5]      R1504     1
    r[5]      R1505     -1
    r[5]      R1506     1
    r[5]      R1507     -1
    r[5]      R1508     1
    r[5]      R1509     -1
    r[5]      R1510     1
    r[5]      R1511     -1
    r[5]      R1512     1
    r[5]      R1513     -1
    r[5]      R1514     1
    r[5]      R1515     -1
    r[5]      R1516     1
    r[5]      R1517     -1
    r[5]      R1518     1
    r[5]      R1519     -1
    r[5]      R1520     1
    r[5]      R1521     -1
    r[5]      R1522     1
    r[5]      R1523     -1
    r[5]      R1524     1
    r[5]      R1525     -1
    r[5]      R1526     1
    r[5]      R1527     -1
    r[5]      R1528     1
    r[5]      R1529     -1
    r[5]      R1530     1
    r[5]      R1531     -1
    r[5]      R1532     1
    r[5]      R1533     -1
    r[5]      R1534     1
    r[5]      R1535     -1
    r[5]      R1536     1
    r[5]      R1537     -1
    r[5]      R1538     1
    r[5]      R1539     -1
    r[5]      R1540     1
    r[5]      R1541     -1
    r[5]      R1542     1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      R1231     1
    r[6]      R1232     -1
    r[6]      R1297     1
    r[6]      R1298     -1
    r[6]      R1361     1
    r[6]      R1362     -1
    r[6]      R1423     1
    r[6]      R1424     -1
    r[6]      R1483     1
    r[6]      R1484     -1
    r[6]      R1543     -1
    r[6]      R1544     1
    r[6]      R1545     -1
    r[6]      R1546     1
    r[6]      R1547     -1
    r[6]      R1548     1
    r[6]      R1549     -1
    r[6]      R1550     1
    r[6]      R1551     -1
    r[6]      R1552     1
    r[6]      R1553     -1
    r[6]      R1554     1
    r[6]      R1555     -1
    r[6]      R1556     1
    r[6]      R1557     -1
    r[6]      R1558     1
    r[6]      R1559     -1
    r[6]      R1560     1
    r[6]      R1561     -1
    r[6]      R1562     1
    r[6]      R1563     -1
    r[6]      R1564     1
    r[6]      R1565     -1
    r[6]      R1566     1
    r[6]      R1567     -1
    r[6]      R1568     1
    r[6]      R1569     -1
    r[6]      R1570     1
    r[6]      R1571     -1
    r[6]      R1572     1
    r[6]      R1573     -1
    r[6]      R1574     1
    r[6]      R1575     -1
    r[6]      R1576     1
    r[6]      R1577     -1
    r[6]      R1578     1
    r[6]      R1579     -1
    r[6]      R1580     1
    r[6]      R1581     -1
    r[6]      R1582     1
    r[6]      R1583     -1
    r[6]      R1584     1
    r[6]      R1585     -1
    r[6]      R1586     1
    r[6]      R1587     -1
    r[6]      R1588     1
    r[6]      R1589     -1
    r[6]      R1590     1
    r[6]      R1591     -1
    r[6]      R1592     1
    r[6]      R1593     -1
    r[6]      R1594     1
    r[6]      R1595     -1
    r[6]      R1596     1
    r[6]      R1597     -1
    r[6]      R1598     1
    r[6]      R1599     -1
    r[6]      R1600     1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      R1233     1
    r[7]      R1234     -1
    r[7]      R1299     1
    r[7]      R1300     -1
    r[7]      R1363     1
    r[7]      R1364     -1
    r[7]      R1425     1
    r[7]      R1426     -1
    r[7]      R1485     1
    r[7]      R1486     -1
    r[7]      R1543     1
    r[7]      R1544     -1
    r[7]      R1601     -1
    r[7]      R1602     1
    r[7]      R1603     -1
    r[7]      R1604     1
    r[7]      R1605     -1
    r[7]      R1606     1
    r[7]      R1607     -1
    r[7]      R1608     1
    r[7]      R1609     -1
    r[7]      R1610     1
    r[7]      R1611     -1
    r[7]      R1612     1
    r[7]      R1613     -1
    r[7]      R1614     1
    r[7]      R1615     -1
    r[7]      R1616     1
    r[7]      R1617     -1
    r[7]      R1618     1
    r[7]      R1619     -1
    r[7]      R1620     1
    r[7]      R1621     -1
    r[7]      R1622     1
    r[7]      R1623     -1
    r[7]      R1624     1
    r[7]      R1625     -1
    r[7]      R1626     1
    r[7]      R1627     -1
    r[7]      R1628     1
    r[7]      R1629     -1
    r[7]      R1630     1
    r[7]      R1631     -1
    r[7]      R1632     1
    r[7]      R1633     -1
    r[7]      R1634     1
    r[7]      R1635     -1
    r[7]      R1636     1
    r[7]      R1637     -1
    r[7]      R1638     1
    r[7]      R1639     -1
    r[7]      R1640     1
    r[7]      R1641     -1
    r[7]      R1642     1
    r[7]      R1643     -1
    r[7]      R1644     1
    r[7]      R1645     -1
    r[7]      R1646     1
    r[7]      R1647     -1
    r[7]      R1648     1
    r[7]      R1649     -1
    r[7]      R1650     1
    r[7]      R1651     -1
    r[7]      R1652     1
    r[7]      R1653     -1
    r[7]      R1654     1
    r[7]      R1655     -1
    r[7]      R1656     1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      R1235     1
    r[8]      R1236     -1
    r[8]      R1301     1
    r[8]      R1302     -1
    r[8]      R1365     1
    r[8]      R1366     -1
    r[8]      R1427     1
    r[8]      R1428     -1
    r[8]      R1487     1
    r[8]      R1488     -1
    r[8]      R1545     1
    r[8]      R1546     -1
    r[8]      R1601     1
    r[8]      R1602     -1
    r[8]      R1657     -1
    r[8]      R1658     1
    r[8]      R1659     -1
    r[8]      R1660     1
    r[8]      R1661     -1
    r[8]      R1662     1
    r[8]      R1663     -1
    r[8]      R1664     1
    r[8]      R1665     -1
    r[8]      R1666     1
    r[8]      R1667     -1
    r[8]      R1668     1
    r[8]      R1669     -1
    r[8]      R1670     1
    r[8]      R1671     -1
    r[8]      R1672     1
    r[8]      R1673     -1
    r[8]      R1674     1
    r[8]      R1675     -1
    r[8]      R1676     1
    r[8]      R1677     -1
    r[8]      R1678     1
    r[8]      R1679     -1
    r[8]      R1680     1
    r[8]      R1681     -1
    r[8]      R1682     1
    r[8]      R1683     -1
    r[8]      R1684     1
    r[8]      R1685     -1
    r[8]      R1686     1
    r[8]      R1687     -1
    r[8]      R1688     1
    r[8]      R1689     -1
    r[8]      R1690     1
    r[8]      R1691     -1
    r[8]      R1692     1
    r[8]      R1693     -1
    r[8]      R1694     1
    r[8]      R1695     -1
    r[8]      R1696     1
    r[8]      R1697     -1
    r[8]      R1698     1
    r[8]      R1699     -1
    r[8]      R1700     1
    r[8]      R1701     -1
    r[8]      R1702     1
    r[8]      R1703     -1
    r[8]      R1704     1
    r[8]      R1705     -1
    r[8]      R1706     1
    r[8]      R1707     -1
    r[8]      R1708     1
    r[8]      R1709     -1
    r[8]      R1710     1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      R1237     1
    r[9]      R1238     -1
    r[9]      R1303     1
    r[9]      R1304     -1
    r[9]      R1367     1
    r[9]      R1368     -1
    r[9]      R1429     1
    r[9]      R1430     -1
    r[9]      R1489     1
    r[9]      R1490     -1
    r[9]      R1547     1
    r[9]      R1548     -1
    r[9]      R1603     1
    r[9]      R1604     -1
    r[9]      R1657     1
    r[9]      R1658     -1
    r[9]      R1711     -1
    r[9]      R1712     1
    r[9]      R1713     -1
    r[9]      R1714     1
    r[9]      R1715     -1
    r[9]      R1716     1
    r[9]      R1717     -1
    r[9]      R1718     1
    r[9]      R1719     -1
    r[9]      R1720     1
    r[9]      R1721     -1
    r[9]      R1722     1
    r[9]      R1723     -1
    r[9]      R1724     1
    r[9]      R1725     -1
    r[9]      R1726     1
    r[9]      R1727     -1
    r[9]      R1728     1
    r[9]      R1729     -1
    r[9]      R1730     1
    r[9]      R1731     -1
    r[9]      R1732     1
    r[9]      R1733     -1
    r[9]      R1734     1
    r[9]      R1735     -1
    r[9]      R1736     1
    r[9]      R1737     -1
    r[9]      R1738     1
    r[9]      R1739     -1
    r[9]      R1740     1
    r[9]      R1741     -1
    r[9]      R1742     1
    r[9]      R1743     -1
    r[9]      R1744     1
    r[9]      R1745     -1
    r[9]      R1746     1
    r[9]      R1747     -1
    r[9]      R1748     1
    r[9]      R1749     -1
    r[9]      R1750     1
    r[9]      R1751     -1
    r[9]      R1752     1
    r[9]      R1753     -1
    r[9]      R1754     1
    r[9]      R1755     -1
    r[9]      R1756     1
    r[9]      R1757     -1
    r[9]      R1758     1
    r[9]      R1759     -1
    r[9]      R1760     1
    r[9]      R1761     -1
    r[9]      R1762     1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     R1239     1
    r[10]     R1240     -1
    r[10]     R1305     1
    r[10]     R1306     -1
    r[10]     R1369     1
    r[10]     R1370     -1
    r[10]     R1431     1
    r[10]     R1432     -1
    r[10]     R1491     1
    r[10]     R1492     -1
    r[10]     R1549     1
    r[10]     R1550     -1
    r[10]     R1605     1
    r[10]     R1606     -1
    r[10]     R1659     1
    r[10]     R1660     -1
    r[10]     R1711     1
    r[10]     R1712     -1
    r[10]     R1763     -1
    r[10]     R1764     1
    r[10]     R1765     -1
    r[10]     R1766     1
    r[10]     R1767     -1
    r[10]     R1768     1
    r[10]     R1769     -1
    r[10]     R1770     1
    r[10]     R1771     -1
    r[10]     R1772     1
    r[10]     R1773     -1
    r[10]     R1774     1
    r[10]     R1775     -1
    r[10]     R1776     1
    r[10]     R1777     -1
    r[10]     R1778     1
    r[10]     R1779     -1
    r[10]     R1780     1
    r[10]     R1781     -1
    r[10]     R1782     1
    r[10]     R1783     -1
    r[10]     R1784     1
    r[10]     R1785     -1
    r[10]     R1786     1
    r[10]     R1787     -1
    r[10]     R1788     1
    r[10]     R1789     -1
    r[10]     R1790     1
    r[10]     R1791     -1
    r[10]     R1792     1
    r[10]     R1793     -1
    r[10]     R1794     1
    r[10]     R1795     -1
    r[10]     R1796     1
    r[10]     R1797     -1
    r[10]     R1798     1
    r[10]     R1799     -1
    r[10]     R1800     1
    r[10]     R1801     -1
    r[10]     R1802     1
    r[10]     R1803     -1
    r[10]     R1804     1
    r[10]     R1805     -1
    r[10]     R1806     1
    r[10]     R1807     -1
    r[10]     R1808     1
    r[10]     R1809     -1
    r[10]     R1810     1
    r[10]     R1811     -1
    r[10]     R1812     1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     R1241     1
    r[11]     R1242     -1
    r[11]     R1307     1
    r[11]     R1308     -1
    r[11]     R1371     1
    r[11]     R1372     -1
    r[11]     R1433     1
    r[11]     R1434     -1
    r[11]     R1493     1
    r[11]     R1494     -1
    r[11]     R1551     1
    r[11]     R1552     -1
    r[11]     R1607     1
    r[11]     R1608     -1
    r[11]     R1661     1
    r[11]     R1662     -1
    r[11]     R1713     1
    r[11]     R1714     -1
    r[11]     R1763     1
    r[11]     R1764     -1
    r[11]     R1813     -1
    r[11]     R1814     1
    r[11]     R1815     -1
    r[11]     R1816     1
    r[11]     R1817     -1
    r[11]     R1818     1
    r[11]     R1819     -1
    r[11]     R1820     1
    r[11]     R1821     -1
    r[11]     R1822     1
    r[11]     R1823     -1
    r[11]     R1824     1
    r[11]     R1825     -1
    r[11]     R1826     1
    r[11]     R1827     -1
    r[11]     R1828     1
    r[11]     R1829     -1
    r[11]     R1830     1
    r[11]     R1831     -1
    r[11]     R1832     1
    r[11]     R1833     -1
    r[11]     R1834     1
    r[11]     R1835     -1
    r[11]     R1836     1
    r[11]     R1837     -1
    r[11]     R1838     1
    r[11]     R1839     -1
    r[11]     R1840     1
    r[11]     R1841     -1
    r[11]     R1842     1
    r[11]     R1843     -1
    r[11]     R1844     1
    r[11]     R1845     -1
    r[11]     R1846     1
    r[11]     R1847     -1
    r[11]     R1848     1
    r[11]     R1849     -1
    r[11]     R1850     1
    r[11]     R1851     -1
    r[11]     R1852     1
    r[11]     R1853     -1
    r[11]     R1854     1
    r[11]     R1855     -1
    r[11]     R1856     1
    r[11]     R1857     -1
    r[11]     R1858     1
    r[11]     R1859     -1
    r[11]     R1860     1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     R1243     1
    r[12]     R1244     -1
    r[12]     R1309     1
    r[12]     R1310     -1
    r[12]     R1373     1
    r[12]     R1374     -1
    r[12]     R1435     1
    r[12]     R1436     -1
    r[12]     R1495     1
    r[12]     R1496     -1
    r[12]     R1553     1
    r[12]     R1554     -1
    r[12]     R1609     1
    r[12]     R1610     -1
    r[12]     R1663     1
    r[12]     R1664     -1
    r[12]     R1715     1
    r[12]     R1716     -1
    r[12]     R1765     1
    r[12]     R1766     -1
    r[12]     R1813     1
    r[12]     R1814     -1
    r[12]     R1861     -1
    r[12]     R1862     1
    r[12]     R1863     -1
    r[12]     R1864     1
    r[12]     R1865     -1
    r[12]     R1866     1
    r[12]     R1867     -1
    r[12]     R1868     1
    r[12]     R1869     -1
    r[12]     R1870     1
    r[12]     R1871     -1
    r[12]     R1872     1
    r[12]     R1873     -1
    r[12]     R1874     1
    r[12]     R1875     -1
    r[12]     R1876     1
    r[12]     R1877     -1
    r[12]     R1878     1
    r[12]     R1879     -1
    r[12]     R1880     1
    r[12]     R1881     -1
    r[12]     R1882     1
    r[12]     R1883     -1
    r[12]     R1884     1
    r[12]     R1885     -1
    r[12]     R1886     1
    r[12]     R1887     -1
    r[12]     R1888     1
    r[12]     R1889     -1
    r[12]     R1890     1
    r[12]     R1891     -1
    r[12]     R1892     1
    r[12]     R1893     -1
    r[12]     R1894     1
    r[12]     R1895     -1
    r[12]     R1896     1
    r[12]     R1897     -1
    r[12]     R1898     1
    r[12]     R1899     -1
    r[12]     R1900     1
    r[12]     R1901     -1
    r[12]     R1902     1
    r[12]     R1903     -1
    r[12]     R1904     1
    r[12]     R1905     -1
    r[12]     R1906     1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     R1245     1
    r[13]     R1246     -1
    r[13]     R1311     1
    r[13]     R1312     -1
    r[13]     R1375     1
    r[13]     R1376     -1
    r[13]     R1437     1
    r[13]     R1438     -1
    r[13]     R1497     1
    r[13]     R1498     -1
    r[13]     R1555     1
    r[13]     R1556     -1
    r[13]     R1611     1
    r[13]     R1612     -1
    r[13]     R1665     1
    r[13]     R1666     -1
    r[13]     R1717     1
    r[13]     R1718     -1
    r[13]     R1767     1
    r[13]     R1768     -1
    r[13]     R1815     1
    r[13]     R1816     -1
    r[13]     R1861     1
    r[13]     R1862     -1
    r[13]     R1907     -1
    r[13]     R1908     1
    r[13]     R1909     -1
    r[13]     R1910     1
    r[13]     R1911     -1
    r[13]     R1912     1
    r[13]     R1913     -1
    r[13]     R1914     1
    r[13]     R1915     -1
    r[13]     R1916     1
    r[13]     R1917     -1
    r[13]     R1918     1
    r[13]     R1919     -1
    r[13]     R1920     1
    r[13]     R1921     -1
    r[13]     R1922     1
    r[13]     R1923     -1
    r[13]     R1924     1
    r[13]     R1925     -1
    r[13]     R1926     1
    r[13]     R1927     -1
    r[13]     R1928     1
    r[13]     R1929     -1
    r[13]     R1930     1
    r[13]     R1931     -1
    r[13]     R1932     1
    r[13]     R1933     -1
    r[13]     R1934     1
    r[13]     R1935     -1
    r[13]     R1936     1
    r[13]     R1937     -1
    r[13]     R1938     1
    r[13]     R1939     -1
    r[13]     R1940     1
    r[13]     R1941     -1
    r[13]     R1942     1
    r[13]     R1943     -1
    r[13]     R1944     1
    r[13]     R1945     -1
    r[13]     R1946     1
    r[13]     R1947     -1
    r[13]     R1948     1
    r[13]     R1949     -1
    r[13]     R1950     1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     R1247     1
    r[14]     R1248     -1
    r[14]     R1313     1
    r[14]     R1314     -1
    r[14]     R1377     1
    r[14]     R1378     -1
    r[14]     R1439     1
    r[14]     R1440     -1
    r[14]     R1499     1
    r[14]     R1500     -1
    r[14]     R1557     1
    r[14]     R1558     -1
    r[14]     R1613     1
    r[14]     R1614     -1
    r[14]     R1667     1
    r[14]     R1668     -1
    r[14]     R1719     1
    r[14]     R1720     -1
    r[14]     R1769     1
    r[14]     R1770     -1
    r[14]     R1817     1
    r[14]     R1818     -1
    r[14]     R1863     1
    r[14]     R1864     -1
    r[14]     R1907     1
    r[14]     R1908     -1
    r[14]     R1951     -1
    r[14]     R1952     1
    r[14]     R1953     -1
    r[14]     R1954     1
    r[14]     R1955     -1
    r[14]     R1956     1
    r[14]     R1957     -1
    r[14]     R1958     1
    r[14]     R1959     -1
    r[14]     R1960     1
    r[14]     R1961     -1
    r[14]     R1962     1
    r[14]     R1963     -1
    r[14]     R1964     1
    r[14]     R1965     -1
    r[14]     R1966     1
    r[14]     R1967     -1
    r[14]     R1968     1
    r[14]     R1969     -1
    r[14]     R1970     1
    r[14]     R1971     -1
    r[14]     R1972     1
    r[14]     R1973     -1
    r[14]     R1974     1
    r[14]     R1975     -1
    r[14]     R1976     1
    r[14]     R1977     -1
    r[14]     R1978     1
    r[14]     R1979     -1
    r[14]     R1980     1
    r[14]     R1981     -1
    r[14]     R1982     1
    r[14]     R1983     -1
    r[14]     R1984     1
    r[14]     R1985     -1
    r[14]     R1986     1
    r[14]     R1987     -1
    r[14]     R1988     1
    r[14]     R1989     -1
    r[14]     R1990     1
    r[14]     R1991     -1
    r[14]     R1992     1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     R1249     1
    r[15]     R1250     -1
    r[15]     R1315     1
    r[15]     R1316     -1
    r[15]     R1379     1
    r[15]     R1380     -1
    r[15]     R1441     1
    r[15]     R1442     -1
    r[15]     R1501     1
    r[15]     R1502     -1
    r[15]     R1559     1
    r[15]     R1560     -1
    r[15]     R1615     1
    r[15]     R1616     -1
    r[15]     R1669     1
    r[15]     R1670     -1
    r[15]     R1721     1
    r[15]     R1722     -1
    r[15]     R1771     1
    r[15]     R1772     -1
    r[15]     R1819     1
    r[15]     R1820     -1
    r[15]     R1865     1
    r[15]     R1866     -1
    r[15]     R1909     1
    r[15]     R1910     -1
    r[15]     R1951     1
    r[15]     R1952     -1
    r[15]     R1993     -1
    r[15]     R1994     1
    r[15]     R1995     -1
    r[15]     R1996     1
    r[15]     R1997     -1
    r[15]     R1998     1
    r[15]     R1999     -1
    r[15]     R2000     1
    r[15]     R2001     -1
    r[15]     R2002     1
    r[15]     R2003     -1
    r[15]     R2004     1
    r[15]     R2005     -1
    r[15]     R2006     1
    r[15]     R2007     -1
    r[15]     R2008     1
    r[15]     R2009     -1
    r[15]     R2010     1
    r[15]     R2011     -1
    r[15]     R2012     1
    r[15]     R2013     -1
    r[15]     R2014     1
    r[15]     R2015     -1
    r[15]     R2016     1
    r[15]     R2017     -1
    r[15]     R2018     1
    r[15]     R2019     -1
    r[15]     R2020     1
    r[15]     R2021     -1
    r[15]     R2022     1
    r[15]     R2023     -1
    r[15]     R2024     1
    r[15]     R2025     -1
    r[15]     R2026     1
    r[15]     R2027     -1
    r[15]     R2028     1
    r[15]     R2029     -1
    r[15]     R2030     1
    r[15]     R2031     -1
    r[15]     R2032     1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     R1251     1
    r[16]     R1252     -1
    r[16]     R1317     1
    r[16]     R1318     -1
    r[16]     R1381     1
    r[16]     R1382     -1
    r[16]     R1443     1
    r[16]     R1444     -1
    r[16]     R1503     1
    r[16]     R1504     -1
    r[16]     R1561     1
    r[16]     R1562     -1
    r[16]     R1617     1
    r[16]     R1618     -1
    r[16]     R1671     1
    r[16]     R1672     -1
    r[16]     R1723     1
    r[16]     R1724     -1
    r[16]     R1773     1
    r[16]     R1774     -1
    r[16]     R1821     1
    r[16]     R1822     -1
    r[16]     R1867     1
    r[16]     R1868     -1
    r[16]     R1911     1
    r[16]     R1912     -1
    r[16]     R1953     1
    r[16]     R1954     -1
    r[16]     R1993     1
    r[16]     R1994     -1
    r[16]     R2033     -1
    r[16]     R2034     1
    r[16]     R2035     -1
    r[16]     R2036     1
    r[16]     R2037     -1
    r[16]     R2038     1
    r[16]     R2039     -1
    r[16]     R2040     1
    r[16]     R2041     -1
    r[16]     R2042     1
    r[16]     R2043     -1
    r[16]     R2044     1
    r[16]     R2045     -1
    r[16]     R2046     1
    r[16]     R2047     -1
    r[16]     R2048     1
    r[16]     R2049     -1
    r[16]     R2050     1
    r[16]     R2051     -1
    r[16]     R2052     1
    r[16]     R2053     -1
    r[16]     R2054     1
    r[16]     R2055     -1
    r[16]     R2056     1
    r[16]     R2057     -1
    r[16]     R2058     1
    r[16]     R2059     -1
    r[16]     R2060     1
    r[16]     R2061     -1
    r[16]     R2062     1
    r[16]     R2063     -1
    r[16]     R2064     1
    r[16]     R2065     -1
    r[16]     R2066     1
    r[16]     R2067     -1
    r[16]     R2068     1
    r[16]     R2069     -1
    r[16]     R2070     1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     R1253     1
    r[17]     R1254     -1
    r[17]     R1319     1
    r[17]     R1320     -1
    r[17]     R1383     1
    r[17]     R1384     -1
    r[17]     R1445     1
    r[17]     R1446     -1
    r[17]     R1505     1
    r[17]     R1506     -1
    r[17]     R1563     1
    r[17]     R1564     -1
    r[17]     R1619     1
    r[17]     R1620     -1
    r[17]     R1673     1
    r[17]     R1674     -1
    r[17]     R1725     1
    r[17]     R1726     -1
    r[17]     R1775     1
    r[17]     R1776     -1
    r[17]     R1823     1
    r[17]     R1824     -1
    r[17]     R1869     1
    r[17]     R1870     -1
    r[17]     R1913     1
    r[17]     R1914     -1
    r[17]     R1955     1
    r[17]     R1956     -1
    r[17]     R1995     1
    r[17]     R1996     -1
    r[17]     R2033     1
    r[17]     R2034     -1
    r[17]     R2071     -1
    r[17]     R2072     1
    r[17]     R2073     -1
    r[17]     R2074     1
    r[17]     R2075     -1
    r[17]     R2076     1
    r[17]     R2077     -1
    r[17]     R2078     1
    r[17]     R2079     -1
    r[17]     R2080     1
    r[17]     R2081     -1
    r[17]     R2082     1
    r[17]     R2083     -1
    r[17]     R2084     1
    r[17]     R2085     -1
    r[17]     R2086     1
    r[17]     R2087     -1
    r[17]     R2088     1
    r[17]     R2089     -1
    r[17]     R2090     1
    r[17]     R2091     -1
    r[17]     R2092     1
    r[17]     R2093     -1
    r[17]     R2094     1
    r[17]     R2095     -1
    r[17]     R2096     1
    r[17]     R2097     -1
    r[17]     R2098     1
    r[17]     R2099     -1
    r[17]     R2100     1
    r[17]     R2101     -1
    r[17]     R2102     1
    r[17]     R2103     -1
    r[17]     R2104     1
    r[17]     R2105     -1
    r[17]     R2106     1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     R1255     1
    r[18]     R1256     -1
    r[18]     R1321     1
    r[18]     R1322     -1
    r[18]     R1385     1
    r[18]     R1386     -1
    r[18]     R1447     1
    r[18]     R1448     -1
    r[18]     R1507     1
    r[18]     R1508     -1
    r[18]     R1565     1
    r[18]     R1566     -1
    r[18]     R1621     1
    r[18]     R1622     -1
    r[18]     R1675     1
    r[18]     R1676     -1
    r[18]     R1727     1
    r[18]     R1728     -1
    r[18]     R1777     1
    r[18]     R1778     -1
    r[18]     R1825     1
    r[18]     R1826     -1
    r[18]     R1871     1
    r[18]     R1872     -1
    r[18]     R1915     1
    r[18]     R1916     -1
    r[18]     R1957     1
    r[18]     R1958     -1
    r[18]     R1997     1
    r[18]     R1998     -1
    r[18]     R2035     1
    r[18]     R2036     -1
    r[18]     R2071     1
    r[18]     R2072     -1
    r[18]     R2107     -1
    r[18]     R2108     1
    r[18]     R2109     -1
    r[18]     R2110     1
    r[18]     R2111     -1
    r[18]     R2112     1
    r[18]     R2113     -1
    r[18]     R2114     1
    r[18]     R2115     -1
    r[18]     R2116     1
    r[18]     R2117     -1
    r[18]     R2118     1
    r[18]     R2119     -1
    r[18]     R2120     1
    r[18]     R2121     -1
    r[18]     R2122     1
    r[18]     R2123     -1
    r[18]     R2124     1
    r[18]     R2125     -1
    r[18]     R2126     1
    r[18]     R2127     -1
    r[18]     R2128     1
    r[18]     R2129     -1
    r[18]     R2130     1
    r[18]     R2131     -1
    r[18]     R2132     1
    r[18]     R2133     -1
    r[18]     R2134     1
    r[18]     R2135     -1
    r[18]     R2136     1
    r[18]     R2137     -1
    r[18]     R2138     1
    r[18]     R2139     -1
    r[18]     R2140     1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     R1257     1
    r[19]     R1258     -1
    r[19]     R1323     1
    r[19]     R1324     -1
    r[19]     R1387     1
    r[19]     R1388     -1
    r[19]     R1449     1
    r[19]     R1450     -1
    r[19]     R1509     1
    r[19]     R1510     -1
    r[19]     R1567     1
    r[19]     R1568     -1
    r[19]     R1623     1
    r[19]     R1624     -1
    r[19]     R1677     1
    r[19]     R1678     -1
    r[19]     R1729     1
    r[19]     R1730     -1
    r[19]     R1779     1
    r[19]     R1780     -1
    r[19]     R1827     1
    r[19]     R1828     -1
    r[19]     R1873     1
    r[19]     R1874     -1
    r[19]     R1917     1
    r[19]     R1918     -1
    r[19]     R1959     1
    r[19]     R1960     -1
    r[19]     R1999     1
    r[19]     R2000     -1
    r[19]     R2037     1
    r[19]     R2038     -1
    r[19]     R2073     1
    r[19]     R2074     -1
    r[19]     R2107     1
    r[19]     R2108     -1
    r[19]     R2141     -1
    r[19]     R2142     1
    r[19]     R2143     -1
    r[19]     R2144     1
    r[19]     R2145     -1
    r[19]     R2146     1
    r[19]     R2147     -1
    r[19]     R2148     1
    r[19]     R2149     -1
    r[19]     R2150     1
    r[19]     R2151     -1
    r[19]     R2152     1
    r[19]     R2153     -1
    r[19]     R2154     1
    r[19]     R2155     -1
    r[19]     R2156     1
    r[19]     R2157     -1
    r[19]     R2158     1
    r[19]     R2159     -1
    r[19]     R2160     1
    r[19]     R2161     -1
    r[19]     R2162     1
    r[19]     R2163     -1
    r[19]     R2164     1
    r[19]     R2165     -1
    r[19]     R2166     1
    r[19]     R2167     -1
    r[19]     R2168     1
    r[19]     R2169     -1
    r[19]     R2170     1
    r[19]     R2171     -1
    r[19]     R2172     1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     R1259     1
    r[20]     R1260     -1
    r[20]     R1325     1
    r[20]     R1326     -1
    r[20]     R1389     1
    r[20]     R1390     -1
    r[20]     R1451     1
    r[20]     R1452     -1
    r[20]     R1511     1
    r[20]     R1512     -1
    r[20]     R1569     1
    r[20]     R1570     -1
    r[20]     R1625     1
    r[20]     R1626     -1
    r[20]     R1679     1
    r[20]     R1680     -1
    r[20]     R1731     1
    r[20]     R1732     -1
    r[20]     R1781     1
    r[20]     R1782     -1
    r[20]     R1829     1
    r[20]     R1830     -1
    r[20]     R1875     1
    r[20]     R1876     -1
    r[20]     R1919     1
    r[20]     R1920     -1
    r[20]     R1961     1
    r[20]     R1962     -1
    r[20]     R2001     1
    r[20]     R2002     -1
    r[20]     R2039     1
    r[20]     R2040     -1
    r[20]     R2075     1
    r[20]     R2076     -1
    r[20]     R2109     1
    r[20]     R2110     -1
    r[20]     R2141     1
    r[20]     R2142     -1
    r[20]     R2173     -1
    r[20]     R2174     1
    r[20]     R2175     -1
    r[20]     R2176     1
    r[20]     R2177     -1
    r[20]     R2178     1
    r[20]     R2179     -1
    r[20]     R2180     1
    r[20]     R2181     -1
    r[20]     R2182     1
    r[20]     R2183     -1
    r[20]     R2184     1
    r[20]     R2185     -1
    r[20]     R2186     1
    r[20]     R2187     -1
    r[20]     R2188     1
    r[20]     R2189     -1
    r[20]     R2190     1
    r[20]     R2191     -1
    r[20]     R2192     1
    r[20]     R2193     -1
    r[20]     R2194     1
    r[20]     R2195     -1
    r[20]     R2196     1
    r[20]     R2197     -1
    r[20]     R2198     1
    r[20]     R2199     -1
    r[20]     R2200     1
    r[20]     R2201     -1
    r[20]     R2202     1
    r[21]     normalized_ratio_21  1
    r[21]     normalization  1
    r[21]     R1261     1
    r[21]     R1262     -1
    r[21]     R1327     1
    r[21]     R1328     -1
    r[21]     R1391     1
    r[21]     R1392     -1
    r[21]     R1453     1
    r[21]     R1454     -1
    r[21]     R1513     1
    r[21]     R1514     -1
    r[21]     R1571     1
    r[21]     R1572     -1
    r[21]     R1627     1
    r[21]     R1628     -1
    r[21]     R1681     1
    r[21]     R1682     -1
    r[21]     R1733     1
    r[21]     R1734     -1
    r[21]     R1783     1
    r[21]     R1784     -1
    r[21]     R1831     1
    r[21]     R1832     -1
    r[21]     R1877     1
    r[21]     R1878     -1
    r[21]     R1921     1
    r[21]     R1922     -1
    r[21]     R1963     1
    r[21]     R1964     -1
    r[21]     R2003     1
    r[21]     R2004     -1
    r[21]     R2041     1
    r[21]     R2042     -1
    r[21]     R2077     1
    r[21]     R2078     -1
    r[21]     R2111     1
    r[21]     R2112     -1
    r[21]     R2143     1
    r[21]     R2144     -1
    r[21]     R2173     1
    r[21]     R2174     -1
    r[21]     R2203     -1
    r[21]     R2204     1
    r[21]     R2205     -1
    r[21]     R2206     1
    r[21]     R2207     -1
    r[21]     R2208     1
    r[21]     R2209     -1
    r[21]     R2210     1
    r[21]     R2211     -1
    r[21]     R2212     1
    r[21]     R2213     -1
    r[21]     R2214     1
    r[21]     R2215     -1
    r[21]     R2216     1
    r[21]     R2217     -1
    r[21]     R2218     1
    r[21]     R2219     -1
    r[21]     R2220     1
    r[21]     R2221     -1
    r[21]     R2222     1
    r[21]     R2223     -1
    r[21]     R2224     1
    r[21]     R2225     -1
    r[21]     R2226     1
    r[21]     R2227     -1
    r[21]     R2228     1
    r[21]     R2229     -1
    r[21]     R2230     1
    r[22]     normalized_ratio_22  1
    r[22]     normalization  1
    r[22]     R1263     1
    r[22]     R1264     -1
    r[22]     R1329     1
    r[22]     R1330     -1
    r[22]     R1393     1
    r[22]     R1394     -1
    r[22]     R1455     1
    r[22]     R1456     -1
    r[22]     R1515     1
    r[22]     R1516     -1
    r[22]     R1573     1
    r[22]     R1574     -1
    r[22]     R1629     1
    r[22]     R1630     -1
    r[22]     R1683     1
    r[22]     R1684     -1
    r[22]     R1735     1
    r[22]     R1736     -1
    r[22]     R1785     1
    r[22]     R1786     -1
    r[22]     R1833     1
    r[22]     R1834     -1
    r[22]     R1879     1
    r[22]     R1880     -1
    r[22]     R1923     1
    r[22]     R1924     -1
    r[22]     R1965     1
    r[22]     R1966     -1
    r[22]     R2005     1
    r[22]     R2006     -1
    r[22]     R2043     1
    r[22]     R2044     -1
    r[22]     R2079     1
    r[22]     R2080     -1
    r[22]     R2113     1
    r[22]     R2114     -1
    r[22]     R2145     1
    r[22]     R2146     -1
    r[22]     R2175     1
    r[22]     R2176     -1
    r[22]     R2203     1
    r[22]     R2204     -1
    r[22]     R2231     -1
    r[22]     R2232     1
    r[22]     R2233     -1
    r[22]     R2234     1
    r[22]     R2235     -1
    r[22]     R2236     1
    r[22]     R2237     -1
    r[22]     R2238     1
    r[22]     R2239     -1
    r[22]     R2240     1
    r[22]     R2241     -1
    r[22]     R2242     1
    r[22]     R2243     -1
    r[22]     R2244     1
    r[22]     R2245     -1
    r[22]     R2246     1
    r[22]     R2247     -1
    r[22]     R2248     1
    r[22]     R2249     -1
    r[22]     R2250     1
    r[22]     R2251     -1
    r[22]     R2252     1
    r[22]     R2253     -1
    r[22]     R2254     1
    r[22]     R2255     -1
    r[22]     R2256     1
    r[23]     normalized_ratio_23  1
    r[23]     normalization  1
    r[23]     R1265     1
    r[23]     R1266     -1
    r[23]     R1331     1
    r[23]     R1332     -1
    r[23]     R1395     1
    r[23]     R1396     -1
    r[23]     R1457     1
    r[23]     R1458     -1
    r[23]     R1517     1
    r[23]     R1518     -1
    r[23]     R1575     1
    r[23]     R1576     -1
    r[23]     R1631     1
    r[23]     R1632     -1
    r[23]     R1685     1
    r[23]     R1686     -1
    r[23]     R1737     1
    r[23]     R1738     -1
    r[23]     R1787     1
    r[23]     R1788     -1
    r[23]     R1835     1
    r[23]     R1836     -1
    r[23]     R1881     1
    r[23]     R1882     -1
    r[23]     R1925     1
    r[23]     R1926     -1
    r[23]     R1967     1
    r[23]     R1968     -1
    r[23]     R2007     1
    r[23]     R2008     -1
    r[23]     R2045     1
    r[23]     R2046     -1
    r[23]     R2081     1
    r[23]     R2082     -1
    r[23]     R2115     1
    r[23]     R2116     -1
    r[23]     R2147     1
    r[23]     R2148     -1
    r[23]     R2177     1
    r[23]     R2178     -1
    r[23]     R2205     1
    r[23]     R2206     -1
    r[23]     R2231     1
    r[23]     R2232     -1
    r[23]     R2257     -1
    r[23]     R2258     1
    r[23]     R2259     -1
    r[23]     R2260     1
    r[23]     R2261     -1
    r[23]     R2262     1
    r[23]     R2263     -1
    r[23]     R2264     1
    r[23]     R2265     -1
    r[23]     R2266     1
    r[23]     R2267     -1
    r[23]     R2268     1
    r[23]     R2269     -1
    r[23]     R2270     1
    r[23]     R2271     -1
    r[23]     R2272     1
    r[23]     R2273     -1
    r[23]     R2274     1
    r[23]     R2275     -1
    r[23]     R2276     1
    r[23]     R2277     -1
    r[23]     R2278     1
    r[23]     R2279     -1
    r[23]     R2280     1
    r[24]     normalized_ratio_24  1
    r[24]     normalization  1
    r[24]     R1267     1
    r[24]     R1268     -1
    r[24]     R1333     1
    r[24]     R1334     -1
    r[24]     R1397     1
    r[24]     R1398     -1
    r[24]     R1459     1
    r[24]     R1460     -1
    r[24]     R1519     1
    r[24]     R1520     -1
    r[24]     R1577     1
    r[24]     R1578     -1
    r[24]     R1633     1
    r[24]     R1634     -1
    r[24]     R1687     1
    r[24]     R1688     -1
    r[24]     R1739     1
    r[24]     R1740     -1
    r[24]     R1789     1
    r[24]     R1790     -1
    r[24]     R1837     1
    r[24]     R1838     -1
    r[24]     R1883     1
    r[24]     R1884     -1
    r[24]     R1927     1
    r[24]     R1928     -1
    r[24]     R1969     1
    r[24]     R1970     -1
    r[24]     R2009     1
    r[24]     R2010     -1
    r[24]     R2047     1
    r[24]     R2048     -1
    r[24]     R2083     1
    r[24]     R2084     -1
    r[24]     R2117     1
    r[24]     R2118     -1
    r[24]     R2149     1
    r[24]     R2150     -1
    r[24]     R2179     1
    r[24]     R2180     -1
    r[24]     R2207     1
    r[24]     R2208     -1
    r[24]     R2233     1
    r[24]     R2234     -1
    r[24]     R2257     1
    r[24]     R2258     -1
    r[24]     R2281     -1
    r[24]     R2282     1
    r[24]     R2283     -1
    r[24]     R2284     1
    r[24]     R2285     -1
    r[24]     R2286     1
    r[24]     R2287     -1
    r[24]     R2288     1
    r[24]     R2289     -1
    r[24]     R2290     1
    r[24]     R2291     -1
    r[24]     R2292     1
    r[24]     R2293     -1
    r[24]     R2294     1
    r[24]     R2295     -1
    r[24]     R2296     1
    r[24]     R2297     -1
    r[24]     R2298     1
    r[24]     R2299     -1
    r[24]     R2300     1
    r[24]     R2301     -1
    r[24]     R2302     1
    r[25]     normalized_ratio_25  1
    r[25]     normalization  1
    r[25]     R1269     1
    r[25]     R1270     -1
    r[25]     R1335     1
    r[25]     R1336     -1
    r[25]     R1399     1
    r[25]     R1400     -1
    r[25]     R1461     1
    r[25]     R1462     -1
    r[25]     R1521     1
    r[25]     R1522     -1
    r[25]     R1579     1
    r[25]     R1580     -1
    r[25]     R1635     1
    r[25]     R1636     -1
    r[25]     R1689     1
    r[25]     R1690     -1
    r[25]     R1741     1
    r[25]     R1742     -1
    r[25]     R1791     1
    r[25]     R1792     -1
    r[25]     R1839     1
    r[25]     R1840     -1
    r[25]     R1885     1
    r[25]     R1886     -1
    r[25]     R1929     1
    r[25]     R1930     -1
    r[25]     R1971     1
    r[25]     R1972     -1
    r[25]     R2011     1
    r[25]     R2012     -1
    r[25]     R2049     1
    r[25]     R2050     -1
    r[25]     R2085     1
    r[25]     R2086     -1
    r[25]     R2119     1
    r[25]     R2120     -1
    r[25]     R2151     1
    r[25]     R2152     -1
    r[25]     R2181     1
    r[25]     R2182     -1
    r[25]     R2209     1
    r[25]     R2210     -1
    r[25]     R2235     1
    r[25]     R2236     -1
    r[25]     R2259     1
    r[25]     R2260     -1
    r[25]     R2281     1
    r[25]     R2282     -1
    r[25]     R2303     -1
    r[25]     R2304     1
    r[25]     R2305     -1
    r[25]     R2306     1
    r[25]     R2307     -1
    r[25]     R2308     1
    r[25]     R2309     -1
    r[25]     R2310     1
    r[25]     R2311     -1
    r[25]     R2312     1
    r[25]     R2313     -1
    r[25]     R2314     1
    r[25]     R2315     -1
    r[25]     R2316     1
    r[25]     R2317     -1
    r[25]     R2318     1
    r[25]     R2319     -1
    r[25]     R2320     1
    r[25]     R2321     -1
    r[25]     R2322     1
    r[26]     normalized_ratio_26  1
    r[26]     normalization  1
    r[26]     R1271     1
    r[26]     R1272     -1
    r[26]     R1337     1
    r[26]     R1338     -1
    r[26]     R1401     1
    r[26]     R1402     -1
    r[26]     R1463     1
    r[26]     R1464     -1
    r[26]     R1523     1
    r[26]     R1524     -1
    r[26]     R1581     1
    r[26]     R1582     -1
    r[26]     R1637     1
    r[26]     R1638     -1
    r[26]     R1691     1
    r[26]     R1692     -1
    r[26]     R1743     1
    r[26]     R1744     -1
    r[26]     R1793     1
    r[26]     R1794     -1
    r[26]     R1841     1
    r[26]     R1842     -1
    r[26]     R1887     1
    r[26]     R1888     -1
    r[26]     R1931     1
    r[26]     R1932     -1
    r[26]     R1973     1
    r[26]     R1974     -1
    r[26]     R2013     1
    r[26]     R2014     -1
    r[26]     R2051     1
    r[26]     R2052     -1
    r[26]     R2087     1
    r[26]     R2088     -1
    r[26]     R2121     1
    r[26]     R2122     -1
    r[26]     R2153     1
    r[26]     R2154     -1
    r[26]     R2183     1
    r[26]     R2184     -1
    r[26]     R2211     1
    r[26]     R2212     -1
    r[26]     R2237     1
    r[26]     R2238     -1
    r[26]     R2261     1
    r[26]     R2262     -1
    r[26]     R2283     1
    r[26]     R2284     -1
    r[26]     R2303     1
    r[26]     R2304     -1
    r[26]     R2323     -1
    r[26]     R2324     1
    r[26]     R2325     -1
    r[26]     R2326     1
    r[26]     R2327     -1
    r[26]     R2328     1
    r[26]     R2329     -1
    r[26]     R2330     1
    r[26]     R2331     -1
    r[26]     R2332     1
    r[26]     R2333     -1
    r[26]     R2334     1
    r[26]     R2335     -1
    r[26]     R2336     1
    r[26]     R2337     -1
    r[26]     R2338     1
    r[26]     R2339     -1
    r[26]     R2340     1
    r[27]     normalized_ratio_27  1
    r[27]     normalization  1
    r[27]     R1273     1
    r[27]     R1274     -1
    r[27]     R1339     1
    r[27]     R1340     -1
    r[27]     R1403     1
    r[27]     R1404     -1
    r[27]     R1465     1
    r[27]     R1466     -1
    r[27]     R1525     1
    r[27]     R1526     -1
    r[27]     R1583     1
    r[27]     R1584     -1
    r[27]     R1639     1
    r[27]     R1640     -1
    r[27]     R1693     1
    r[27]     R1694     -1
    r[27]     R1745     1
    r[27]     R1746     -1
    r[27]     R1795     1
    r[27]     R1796     -1
    r[27]     R1843     1
    r[27]     R1844     -1
    r[27]     R1889     1
    r[27]     R1890     -1
    r[27]     R1933     1
    r[27]     R1934     -1
    r[27]     R1975     1
    r[27]     R1976     -1
    r[27]     R2015     1
    r[27]     R2016     -1
    r[27]     R2053     1
    r[27]     R2054     -1
    r[27]     R2089     1
    r[27]     R2090     -1
    r[27]     R2123     1
    r[27]     R2124     -1
    r[27]     R2155     1
    r[27]     R2156     -1
    r[27]     R2185     1
    r[27]     R2186     -1
    r[27]     R2213     1
    r[27]     R2214     -1
    r[27]     R2239     1
    r[27]     R2240     -1
    r[27]     R2263     1
    r[27]     R2264     -1
    r[27]     R2285     1
    r[27]     R2286     -1
    r[27]     R2305     1
    r[27]     R2306     -1
    r[27]     R2323     1
    r[27]     R2324     -1
    r[27]     R2341     -1
    r[27]     R2342     1
    r[27]     R2343     -1
    r[27]     R2344     1
    r[27]     R2345     -1
    r[27]     R2346     1
    r[27]     R2347     -1
    r[27]     R2348     1
    r[27]     R2349     -1
    r[27]     R2350     1
    r[27]     R2351     -1
    r[27]     R2352     1
    r[27]     R2353     -1
    r[27]     R2354     1
    r[27]     R2355     -1
    r[27]     R2356     1
    r[28]     normalized_ratio_28  1
    r[28]     normalization  1
    r[28]     R1275     1
    r[28]     R1276     -1
    r[28]     R1341     1
    r[28]     R1342     -1
    r[28]     R1405     1
    r[28]     R1406     -1
    r[28]     R1467     1
    r[28]     R1468     -1
    r[28]     R1527     1
    r[28]     R1528     -1
    r[28]     R1585     1
    r[28]     R1586     -1
    r[28]     R1641     1
    r[28]     R1642     -1
    r[28]     R1695     1
    r[28]     R1696     -1
    r[28]     R1747     1
    r[28]     R1748     -1
    r[28]     R1797     1
    r[28]     R1798     -1
    r[28]     R1845     1
    r[28]     R1846     -1
    r[28]     R1891     1
    r[28]     R1892     -1
    r[28]     R1935     1
    r[28]     R1936     -1
    r[28]     R1977     1
    r[28]     R1978     -1
    r[28]     R2017     1
    r[28]     R2018     -1
    r[28]     R2055     1
    r[28]     R2056     -1
    r[28]     R2091     1
    r[28]     R2092     -1
    r[28]     R2125     1
    r[28]     R2126     -1
    r[28]     R2157     1
    r[28]     R2158     -1
    r[28]     R2187     1
    r[28]     R2188     -1
    r[28]     R2215     1
    r[28]     R2216     -1
    r[28]     R2241     1
    r[28]     R2242     -1
    r[28]     R2265     1
    r[28]     R2266     -1
    r[28]     R2287     1
    r[28]     R2288     -1
    r[28]     R2307     1
    r[28]     R2308     -1
    r[28]     R2325     1
    r[28]     R2326     -1
    r[28]     R2341     1
    r[28]     R2342     -1
    r[28]     R2357     -1
    r[28]     R2358     1
    r[28]     R2359     -1
    r[28]     R2360     1
    r[28]     R2361     -1
    r[28]     R2362     1
    r[28]     R2363     -1
    r[28]     R2364     1
    r[28]     R2365     -1
    r[28]     R2366     1
    r[28]     R2367     -1
    r[28]     R2368     1
    r[28]     R2369     -1
    r[28]     R2370     1
    r[29]     normalized_ratio_29  1
    r[29]     normalization  1
    r[29]     R1277     1
    r[29]     R1278     -1
    r[29]     R1343     1
    r[29]     R1344     -1
    r[29]     R1407     1
    r[29]     R1408     -1
    r[29]     R1469     1
    r[29]     R1470     -1
    r[29]     R1529     1
    r[29]     R1530     -1
    r[29]     R1587     1
    r[29]     R1588     -1
    r[29]     R1643     1
    r[29]     R1644     -1
    r[29]     R1697     1
    r[29]     R1698     -1
    r[29]     R1749     1
    r[29]     R1750     -1
    r[29]     R1799     1
    r[29]     R1800     -1
    r[29]     R1847     1
    r[29]     R1848     -1
    r[29]     R1893     1
    r[29]     R1894     -1
    r[29]     R1937     1
    r[29]     R1938     -1
    r[29]     R1979     1
    r[29]     R1980     -1
    r[29]     R2019     1
    r[29]     R2020     -1
    r[29]     R2057     1
    r[29]     R2058     -1
    r[29]     R2093     1
    r[29]     R2094     -1
    r[29]     R2127     1
    r[29]     R2128     -1
    r[29]     R2159     1
    r[29]     R2160     -1
    r[29]     R2189     1
    r[29]     R2190     -1
    r[29]     R2217     1
    r[29]     R2218     -1
    r[29]     R2243     1
    r[29]     R2244     -1
    r[29]     R2267     1
    r[29]     R2268     -1
    r[29]     R2289     1
    r[29]     R2290     -1
    r[29]     R2309     1
    r[29]     R2310     -1
    r[29]     R2327     1
    r[29]     R2328     -1
    r[29]     R2343     1
    r[29]     R2344     -1
    r[29]     R2357     1
    r[29]     R2358     -1
    r[29]     R2371     -1
    r[29]     R2372     1
    r[29]     R2373     -1
    r[29]     R2374     1
    r[29]     R2375     -1
    r[29]     R2376     1
    r[29]     R2377     -1
    r[29]     R2378     1
    r[29]     R2379     -1
    r[29]     R2380     1
    r[29]     R2381     -1
    r[29]     R2382     1
    r[30]     normalized_ratio_30  1
    r[30]     normalization  1
    r[30]     R1279     1
    r[30]     R1280     -1
    r[30]     R1345     1
    r[30]     R1346     -1
    r[30]     R1409     1
    r[30]     R1410     -1
    r[30]     R1471     1
    r[30]     R1472     -1
    r[30]     R1531     1
    r[30]     R1532     -1
    r[30]     R1589     1
    r[30]     R1590     -1
    r[30]     R1645     1
    r[30]     R1646     -1
    r[30]     R1699     1
    r[30]     R1700     -1
    r[30]     R1751     1
    r[30]     R1752     -1
    r[30]     R1801     1
    r[30]     R1802     -1
    r[30]     R1849     1
    r[30]     R1850     -1
    r[30]     R1895     1
    r[30]     R1896     -1
    r[30]     R1939     1
    r[30]     R1940     -1
    r[30]     R1981     1
    r[30]     R1982     -1
    r[30]     R2021     1
    r[30]     R2022     -1
    r[30]     R2059     1
    r[30]     R2060     -1
    r[30]     R2095     1
    r[30]     R2096     -1
    r[30]     R2129     1
    r[30]     R2130     -1
    r[30]     R2161     1
    r[30]     R2162     -1
    r[30]     R2191     1
    r[30]     R2192     -1
    r[30]     R2219     1
    r[30]     R2220     -1
    r[30]     R2245     1
    r[30]     R2246     -1
    r[30]     R2269     1
    r[30]     R2270     -1
    r[30]     R2291     1
    r[30]     R2292     -1
    r[30]     R2311     1
    r[30]     R2312     -1
    r[30]     R2329     1
    r[30]     R2330     -1
    r[30]     R2345     1
    r[30]     R2346     -1
    r[30]     R2359     1
    r[30]     R2360     -1
    r[30]     R2371     1
    r[30]     R2372     -1
    r[30]     R2383     -1
    r[30]     R2384     1
    r[30]     R2385     -1
    r[30]     R2386     1
    r[30]     R2387     -1
    r[30]     R2388     1
    r[30]     R2389     -1
    r[30]     R2390     1
    r[30]     R2391     -1
    r[30]     R2392     1
    r[31]     normalized_ratio_31  1
    r[31]     normalization  1
    r[31]     R1281     1
    r[31]     R1282     -1
    r[31]     R1347     1
    r[31]     R1348     -1
    r[31]     R1411     1
    r[31]     R1412     -1
    r[31]     R1473     1
    r[31]     R1474     -1
    r[31]     R1533     1
    r[31]     R1534     -1
    r[31]     R1591     1
    r[31]     R1592     -1
    r[31]     R1647     1
    r[31]     R1648     -1
    r[31]     R1701     1
    r[31]     R1702     -1
    r[31]     R1753     1
    r[31]     R1754     -1
    r[31]     R1803     1
    r[31]     R1804     -1
    r[31]     R1851     1
    r[31]     R1852     -1
    r[31]     R1897     1
    r[31]     R1898     -1
    r[31]     R1941     1
    r[31]     R1942     -1
    r[31]     R1983     1
    r[31]     R1984     -1
    r[31]     R2023     1
    r[31]     R2024     -1
    r[31]     R2061     1
    r[31]     R2062     -1
    r[31]     R2097     1
    r[31]     R2098     -1
    r[31]     R2131     1
    r[31]     R2132     -1
    r[31]     R2163     1
    r[31]     R2164     -1
    r[31]     R2193     1
    r[31]     R2194     -1
    r[31]     R2221     1
    r[31]     R2222     -1
    r[31]     R2247     1
    r[31]     R2248     -1
    r[31]     R2271     1
    r[31]     R2272     -1
    r[31]     R2293     1
    r[31]     R2294     -1
    r[31]     R2313     1
    r[31]     R2314     -1
    r[31]     R2331     1
    r[31]     R2332     -1
    r[31]     R2347     1
    r[31]     R2348     -1
    r[31]     R2361     1
    r[31]     R2362     -1
    r[31]     R2373     1
    r[31]     R2374     -1
    r[31]     R2383     1
    r[31]     R2384     -1
    r[31]     R2393     -1
    r[31]     R2394     1
    r[31]     R2395     -1
    r[31]     R2396     1
    r[31]     R2397     -1
    r[31]     R2398     1
    r[31]     R2399     -1
    r[31]     R2400     1
    r[32]     normalized_ratio_32  1
    r[32]     normalization  1
    r[32]     R1283     1
    r[32]     R1284     -1
    r[32]     R1349     1
    r[32]     R1350     -1
    r[32]     R1413     1
    r[32]     R1414     -1
    r[32]     R1475     1
    r[32]     R1476     -1
    r[32]     R1535     1
    r[32]     R1536     -1
    r[32]     R1593     1
    r[32]     R1594     -1
    r[32]     R1649     1
    r[32]     R1650     -1
    r[32]     R1703     1
    r[32]     R1704     -1
    r[32]     R1755     1
    r[32]     R1756     -1
    r[32]     R1805     1
    r[32]     R1806     -1
    r[32]     R1853     1
    r[32]     R1854     -1
    r[32]     R1899     1
    r[32]     R1900     -1
    r[32]     R1943     1
    r[32]     R1944     -1
    r[32]     R1985     1
    r[32]     R1986     -1
    r[32]     R2025     1
    r[32]     R2026     -1
    r[32]     R2063     1
    r[32]     R2064     -1
    r[32]     R2099     1
    r[32]     R2100     -1
    r[32]     R2133     1
    r[32]     R2134     -1
    r[32]     R2165     1
    r[32]     R2166     -1
    r[32]     R2195     1
    r[32]     R2196     -1
    r[32]     R2223     1
    r[32]     R2224     -1
    r[32]     R2249     1
    r[32]     R2250     -1
    r[32]     R2273     1
    r[32]     R2274     -1
    r[32]     R2295     1
    r[32]     R2296     -1
    r[32]     R2315     1
    r[32]     R2316     -1
    r[32]     R2333     1
    r[32]     R2334     -1
    r[32]     R2349     1
    r[32]     R2350     -1
    r[32]     R2363     1
    r[32]     R2364     -1
    r[32]     R2375     1
    r[32]     R2376     -1
    r[32]     R2385     1
    r[32]     R2386     -1
    r[32]     R2393     1
    r[32]     R2394     -1
    r[32]     R2401     -1
    r[32]     R2402     1
    r[32]     R2403     -1
    r[32]     R2404     1
    r[32]     R2405     -1
    r[32]     R2406     1
    r[33]     normalized_ratio_33  1
    r[33]     normalization  1
    r[33]     R1285     1
    r[33]     R1286     -1
    r[33]     R1351     1
    r[33]     R1352     -1
    r[33]     R1415     1
    r[33]     R1416     -1
    r[33]     R1477     1
    r[33]     R1478     -1
    r[33]     R1537     1
    r[33]     R1538     -1
    r[33]     R1595     1
    r[33]     R1596     -1
    r[33]     R1651     1
    r[33]     R1652     -1
    r[33]     R1705     1
    r[33]     R1706     -1
    r[33]     R1757     1
    r[33]     R1758     -1
    r[33]     R1807     1
    r[33]     R1808     -1
    r[33]     R1855     1
    r[33]     R1856     -1
    r[33]     R1901     1
    r[33]     R1902     -1
    r[33]     R1945     1
    r[33]     R1946     -1
    r[33]     R1987     1
    r[33]     R1988     -1
    r[33]     R2027     1
    r[33]     R2028     -1
    r[33]     R2065     1
    r[33]     R2066     -1
    r[33]     R2101     1
    r[33]     R2102     -1
    r[33]     R2135     1
    r[33]     R2136     -1
    r[33]     R2167     1
    r[33]     R2168     -1
    r[33]     R2197     1
    r[33]     R2198     -1
    r[33]     R2225     1
    r[33]     R2226     -1
    r[33]     R2251     1
    r[33]     R2252     -1
    r[33]     R2275     1
    r[33]     R2276     -1
    r[33]     R2297     1
    r[33]     R2298     -1
    r[33]     R2317     1
    r[33]     R2318     -1
    r[33]     R2335     1
    r[33]     R2336     -1
    r[33]     R2351     1
    r[33]     R2352     -1
    r[33]     R2365     1
    r[33]     R2366     -1
    r[33]     R2377     1
    r[33]     R2378     -1
    r[33]     R2387     1
    r[33]     R2388     -1
    r[33]     R2395     1
    r[33]     R2396     -1
    r[33]     R2401     1
    r[33]     R2402     -1
    r[33]     R2407     -1
    r[33]     R2408     1
    r[33]     R2409     -1
    r[33]     R2410     1
    r[34]     normalized_ratio_34  1
    r[34]     normalization  1
    r[34]     R1287     1
    r[34]     R1288     -1
    r[34]     R1353     1
    r[34]     R1354     -1
    r[34]     R1417     1
    r[34]     R1418     -1
    r[34]     R1479     1
    r[34]     R1480     -1
    r[34]     R1539     1
    r[34]     R1540     -1
    r[34]     R1597     1
    r[34]     R1598     -1
    r[34]     R1653     1
    r[34]     R1654     -1
    r[34]     R1707     1
    r[34]     R1708     -1
    r[34]     R1759     1
    r[34]     R1760     -1
    r[34]     R1809     1
    r[34]     R1810     -1
    r[34]     R1857     1
    r[34]     R1858     -1
    r[34]     R1903     1
    r[34]     R1904     -1
    r[34]     R1947     1
    r[34]     R1948     -1
    r[34]     R1989     1
    r[34]     R1990     -1
    r[34]     R2029     1
    r[34]     R2030     -1
    r[34]     R2067     1
    r[34]     R2068     -1
    r[34]     R2103     1
    r[34]     R2104     -1
    r[34]     R2137     1
    r[34]     R2138     -1
    r[34]     R2169     1
    r[34]     R2170     -1
    r[34]     R2199     1
    r[34]     R2200     -1
    r[34]     R2227     1
    r[34]     R2228     -1
    r[34]     R2253     1
    r[34]     R2254     -1
    r[34]     R2277     1
    r[34]     R2278     -1
    r[34]     R2299     1
    r[34]     R2300     -1
    r[34]     R2319     1
    r[34]     R2320     -1
    r[34]     R2337     1
    r[34]     R2338     -1
    r[34]     R2353     1
    r[34]     R2354     -1
    r[34]     R2367     1
    r[34]     R2368     -1
    r[34]     R2379     1
    r[34]     R2380     -1
    r[34]     R2389     1
    r[34]     R2390     -1
    r[34]     R2397     1
    r[34]     R2398     -1
    r[34]     R2403     1
    r[34]     R2404     -1
    r[34]     R2407     1
    r[34]     R2408     -1
    r[34]     R2411     -1
    r[34]     R2412     1
    r[35]     normalized_ratio_35  1
    r[35]     normalization  1
    r[35]     R1289     1
    r[35]     R1290     -1
    r[35]     R1355     1
    r[35]     R1356     -1
    r[35]     R1419     1
    r[35]     R1420     -1
    r[35]     R1481     1
    r[35]     R1482     -1
    r[35]     R1541     1
    r[35]     R1542     -1
    r[35]     R1599     1
    r[35]     R1600     -1
    r[35]     R1655     1
    r[35]     R1656     -1
    r[35]     R1709     1
    r[35]     R1710     -1
    r[35]     R1761     1
    r[35]     R1762     -1
    r[35]     R1811     1
    r[35]     R1812     -1
    r[35]     R1859     1
    r[35]     R1860     -1
    r[35]     R1905     1
    r[35]     R1906     -1
    r[35]     R1949     1
    r[35]     R1950     -1
    r[35]     R1991     1
    r[35]     R1992     -1
    r[35]     R2031     1
    r[35]     R2032     -1
    r[35]     R2069     1
    r[35]     R2070     -1
    r[35]     R2105     1
    r[35]     R2106     -1
    r[35]     R2139     1
    r[35]     R2140     -1
    r[35]     R2171     1
    r[35]     R2172     -1
    r[35]     R2201     1
    r[35]     R2202     -1
    r[35]     R2229     1
    r[35]     R2230     -1
    r[35]     R2255     1
    r[35]     R2256     -1
    r[35]     R2279     1
    r[35]     R2280     -1
    r[35]     R2301     1
    r[35]     R2302     -1
    r[35]     R2321     1
    r[35]     R2322     -1
    r[35]     R2339     1
    r[35]     R2340     -1
    r[35]     R2355     1
    r[35]     R2356     -1
    r[35]     R2369     1
    r[35]     R2370     -1
    r[35]     R2381     1
    r[35]     R2382     -1
    r[35]     R2391     1
    r[35]     R2392     -1
    r[35]     R2399     1
    r[35]     R2400     -1
    r[35]     R2405     1
    r[35]     R2406     -1
    r[35]     R2409     1
    r[35]     R2410     -1
    r[35]     R2411     1
    r[35]     R2412     -1
    a[1,2]    R1223     1
    a[1,2]    R1224     1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R1225     1
    a[1,3]    R1226     1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,4]    R1227     1
    a[1,4]    R1228     1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,5]    R1229     1
    a[1,5]    R1230     1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,6]    R1231     1
    a[1,6]    R1232     1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,7]    R1233     1
    a[1,7]    R1234     1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,8]    R1235     1
    a[1,8]    R1236     1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,9]    R1237     1
    a[1,9]    R1238     1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,10]   R1239     1
    a[1,10]   R1240     1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,11]   R1241     1
    a[1,11]   R1242     1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,12]   R1243     1
    a[1,12]   R1244     1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,13]   R1245     1
    a[1,13]   R1246     1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,14]   R1247     1
    a[1,14]   R1248     1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,15]   R1249     1
    a[1,15]   R1250     1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,16]   R1251     1
    a[1,16]   R1252     1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,17]   R1253     1
    a[1,17]   R1254     1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,18]   R1255     1
    a[1,18]   R1256     1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,19]   R1257     1
    a[1,19]   R1258     1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,20]   R1259     1
    a[1,20]   R1260     1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[1,21]   R1261     1
    a[1,21]   R1262     1
    a[1,21]   true_G_epigraph  1
    a[1,21]   physical_G_upper  1
    a[1,22]   R1263     1
    a[1,22]   R1264     1
    a[1,22]   true_G_epigraph  1
    a[1,22]   physical_G_upper  1
    a[1,23]   R1265     1
    a[1,23]   R1266     1
    a[1,23]   true_G_epigraph  1
    a[1,23]   physical_G_upper  1
    a[1,24]   R1267     1
    a[1,24]   R1268     1
    a[1,24]   true_G_epigraph  1
    a[1,24]   physical_G_upper  1
    a[1,25]   R1269     1
    a[1,25]   R1270     1
    a[1,25]   true_G_epigraph  1
    a[1,25]   physical_G_upper  1
    a[1,26]   R1271     1
    a[1,26]   R1272     1
    a[1,26]   true_G_epigraph  1
    a[1,26]   physical_G_upper  1
    a[1,27]   R1273     1
    a[1,27]   R1274     1
    a[1,27]   true_G_epigraph  1
    a[1,27]   physical_G_upper  1
    a[1,28]   R1275     1
    a[1,28]   R1276     1
    a[1,28]   true_G_epigraph  1
    a[1,28]   physical_G_upper  1
    a[1,29]   R1277     1
    a[1,29]   R1278     1
    a[1,29]   true_G_epigraph  1
    a[1,29]   physical_G_upper  1
    a[1,30]   R1279     1
    a[1,30]   R1280     1
    a[1,30]   true_G_epigraph  1
    a[1,30]   physical_G_upper  1
    a[1,31]   R1281     1
    a[1,31]   R1282     1
    a[1,31]   true_G_epigraph  1
    a[1,31]   physical_G_upper  1
    a[1,32]   R1283     1
    a[1,32]   R1284     1
    a[1,32]   true_G_epigraph  1
    a[1,32]   physical_G_upper  1
    a[1,33]   R1285     1
    a[1,33]   R1286     1
    a[1,33]   true_G_epigraph  1
    a[1,33]   physical_G_upper  1
    a[1,34]   R1287     1
    a[1,34]   R1288     1
    a[1,34]   true_G_epigraph  1
    a[1,34]   physical_G_upper  1
    a[1,35]   R1289     1
    a[1,35]   R1290     1
    a[1,35]   true_G_epigraph  1
    a[1,35]   physical_G_upper  1
    a[2,3]    R1291     1
    a[2,3]    R1292     1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,4]    R1293     1
    a[2,4]    R1294     1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,5]    R1295     1
    a[2,5]    R1296     1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,6]    R1297     1
    a[2,6]    R1298     1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,7]    R1299     1
    a[2,7]    R1300     1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,8]    R1301     1
    a[2,8]    R1302     1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,9]    R1303     1
    a[2,9]    R1304     1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,10]   R1305     1
    a[2,10]   R1306     1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,11]   R1307     1
    a[2,11]   R1308     1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,12]   R1309     1
    a[2,12]   R1310     1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,13]   R1311     1
    a[2,13]   R1312     1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,14]   R1313     1
    a[2,14]   R1314     1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,15]   R1315     1
    a[2,15]   R1316     1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,16]   R1317     1
    a[2,16]   R1318     1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,17]   R1319     1
    a[2,17]   R1320     1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,18]   R1321     1
    a[2,18]   R1322     1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,19]   R1323     1
    a[2,19]   R1324     1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,20]   R1325     1
    a[2,20]   R1326     1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[2,21]   R1327     1
    a[2,21]   R1328     1
    a[2,21]   true_G_epigraph  1
    a[2,21]   physical_G_upper  1
    a[2,22]   R1329     1
    a[2,22]   R1330     1
    a[2,22]   true_G_epigraph  1
    a[2,22]   physical_G_upper  1
    a[2,23]   R1331     1
    a[2,23]   R1332     1
    a[2,23]   true_G_epigraph  1
    a[2,23]   physical_G_upper  1
    a[2,24]   R1333     1
    a[2,24]   R1334     1
    a[2,24]   true_G_epigraph  1
    a[2,24]   physical_G_upper  1
    a[2,25]   R1335     1
    a[2,25]   R1336     1
    a[2,25]   true_G_epigraph  1
    a[2,25]   physical_G_upper  1
    a[2,26]   R1337     1
    a[2,26]   R1338     1
    a[2,26]   true_G_epigraph  1
    a[2,26]   physical_G_upper  1
    a[2,27]   R1339     1
    a[2,27]   R1340     1
    a[2,27]   true_G_epigraph  1
    a[2,27]   physical_G_upper  1
    a[2,28]   R1341     1
    a[2,28]   R1342     1
    a[2,28]   true_G_epigraph  1
    a[2,28]   physical_G_upper  1
    a[2,29]   R1343     1
    a[2,29]   R1344     1
    a[2,29]   true_G_epigraph  1
    a[2,29]   physical_G_upper  1
    a[2,30]   R1345     1
    a[2,30]   R1346     1
    a[2,30]   true_G_epigraph  1
    a[2,30]   physical_G_upper  1
    a[2,31]   R1347     1
    a[2,31]   R1348     1
    a[2,31]   true_G_epigraph  1
    a[2,31]   physical_G_upper  1
    a[2,32]   R1349     1
    a[2,32]   R1350     1
    a[2,32]   true_G_epigraph  1
    a[2,32]   physical_G_upper  1
    a[2,33]   R1351     1
    a[2,33]   R1352     1
    a[2,33]   true_G_epigraph  1
    a[2,33]   physical_G_upper  1
    a[2,34]   R1353     1
    a[2,34]   R1354     1
    a[2,34]   true_G_epigraph  1
    a[2,34]   physical_G_upper  1
    a[2,35]   R1355     1
    a[2,35]   R1356     1
    a[2,35]   true_G_epigraph  1
    a[2,35]   physical_G_upper  1
    a[3,4]    R1357     1
    a[3,4]    R1358     1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,5]    R1359     1
    a[3,5]    R1360     1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,6]    R1361     1
    a[3,6]    R1362     1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,7]    R1363     1
    a[3,7]    R1364     1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,8]    R1365     1
    a[3,8]    R1366     1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,9]    R1367     1
    a[3,9]    R1368     1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,10]   R1369     1
    a[3,10]   R1370     1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,11]   R1371     1
    a[3,11]   R1372     1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,12]   R1373     1
    a[3,12]   R1374     1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,13]   R1375     1
    a[3,13]   R1376     1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,14]   R1377     1
    a[3,14]   R1378     1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,15]   R1379     1
    a[3,15]   R1380     1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,16]   R1381     1
    a[3,16]   R1382     1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,17]   R1383     1
    a[3,17]   R1384     1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,18]   R1385     1
    a[3,18]   R1386     1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,19]   R1387     1
    a[3,19]   R1388     1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,20]   R1389     1
    a[3,20]   R1390     1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[3,21]   R1391     1
    a[3,21]   R1392     1
    a[3,21]   true_G_epigraph  1
    a[3,21]   physical_G_upper  1
    a[3,22]   R1393     1
    a[3,22]   R1394     1
    a[3,22]   true_G_epigraph  1
    a[3,22]   physical_G_upper  1
    a[3,23]   R1395     1
    a[3,23]   R1396     1
    a[3,23]   true_G_epigraph  1
    a[3,23]   physical_G_upper  1
    a[3,24]   R1397     1
    a[3,24]   R1398     1
    a[3,24]   true_G_epigraph  1
    a[3,24]   physical_G_upper  1
    a[3,25]   R1399     1
    a[3,25]   R1400     1
    a[3,25]   true_G_epigraph  1
    a[3,25]   physical_G_upper  1
    a[3,26]   R1401     1
    a[3,26]   R1402     1
    a[3,26]   true_G_epigraph  1
    a[3,26]   physical_G_upper  1
    a[3,27]   R1403     1
    a[3,27]   R1404     1
    a[3,27]   true_G_epigraph  1
    a[3,27]   physical_G_upper  1
    a[3,28]   R1405     1
    a[3,28]   R1406     1
    a[3,28]   true_G_epigraph  1
    a[3,28]   physical_G_upper  1
    a[3,29]   R1407     1
    a[3,29]   R1408     1
    a[3,29]   true_G_epigraph  1
    a[3,29]   physical_G_upper  1
    a[3,30]   R1409     1
    a[3,30]   R1410     1
    a[3,30]   true_G_epigraph  1
    a[3,30]   physical_G_upper  1
    a[3,31]   R1411     1
    a[3,31]   R1412     1
    a[3,31]   true_G_epigraph  1
    a[3,31]   physical_G_upper  1
    a[3,32]   R1413     1
    a[3,32]   R1414     1
    a[3,32]   true_G_epigraph  1
    a[3,32]   physical_G_upper  1
    a[3,33]   R1415     1
    a[3,33]   R1416     1
    a[3,33]   true_G_epigraph  1
    a[3,33]   physical_G_upper  1
    a[3,34]   R1417     1
    a[3,34]   R1418     1
    a[3,34]   true_G_epigraph  1
    a[3,34]   physical_G_upper  1
    a[3,35]   R1419     1
    a[3,35]   R1420     1
    a[3,35]   true_G_epigraph  1
    a[3,35]   physical_G_upper  1
    a[4,5]    R1421     1
    a[4,5]    R1422     1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,6]    R1423     1
    a[4,6]    R1424     1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,7]    R1425     1
    a[4,7]    R1426     1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,8]    R1427     1
    a[4,8]    R1428     1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,9]    R1429     1
    a[4,9]    R1430     1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,10]   R1431     1
    a[4,10]   R1432     1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,11]   R1433     1
    a[4,11]   R1434     1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,12]   R1435     1
    a[4,12]   R1436     1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,13]   R1437     1
    a[4,13]   R1438     1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,14]   R1439     1
    a[4,14]   R1440     1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,15]   R1441     1
    a[4,15]   R1442     1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,16]   R1443     1
    a[4,16]   R1444     1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,17]   R1445     1
    a[4,17]   R1446     1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,18]   R1447     1
    a[4,18]   R1448     1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,19]   R1449     1
    a[4,19]   R1450     1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,20]   R1451     1
    a[4,20]   R1452     1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[4,21]   R1453     1
    a[4,21]   R1454     1
    a[4,21]   true_G_epigraph  1
    a[4,21]   physical_G_upper  1
    a[4,22]   R1455     1
    a[4,22]   R1456     1
    a[4,22]   true_G_epigraph  1
    a[4,22]   physical_G_upper  1
    a[4,23]   R1457     1
    a[4,23]   R1458     1
    a[4,23]   true_G_epigraph  1
    a[4,23]   physical_G_upper  1
    a[4,24]   R1459     1
    a[4,24]   R1460     1
    a[4,24]   true_G_epigraph  1
    a[4,24]   physical_G_upper  1
    a[4,25]   R1461     1
    a[4,25]   R1462     1
    a[4,25]   true_G_epigraph  1
    a[4,25]   physical_G_upper  1
    a[4,26]   R1463     1
    a[4,26]   R1464     1
    a[4,26]   true_G_epigraph  1
    a[4,26]   physical_G_upper  1
    a[4,27]   R1465     1
    a[4,27]   R1466     1
    a[4,27]   true_G_epigraph  1
    a[4,27]   physical_G_upper  1
    a[4,28]   R1467     1
    a[4,28]   R1468     1
    a[4,28]   true_G_epigraph  1
    a[4,28]   physical_G_upper  1
    a[4,29]   R1469     1
    a[4,29]   R1470     1
    a[4,29]   true_G_epigraph  1
    a[4,29]   physical_G_upper  1
    a[4,30]   R1471     1
    a[4,30]   R1472     1
    a[4,30]   true_G_epigraph  1
    a[4,30]   physical_G_upper  1
    a[4,31]   R1473     1
    a[4,31]   R1474     1
    a[4,31]   true_G_epigraph  1
    a[4,31]   physical_G_upper  1
    a[4,32]   R1475     1
    a[4,32]   R1476     1
    a[4,32]   true_G_epigraph  1
    a[4,32]   physical_G_upper  1
    a[4,33]   R1477     1
    a[4,33]   R1478     1
    a[4,33]   true_G_epigraph  1
    a[4,33]   physical_G_upper  1
    a[4,34]   R1479     1
    a[4,34]   R1480     1
    a[4,34]   true_G_epigraph  1
    a[4,34]   physical_G_upper  1
    a[4,35]   R1481     1
    a[4,35]   R1482     1
    a[4,35]   true_G_epigraph  1
    a[4,35]   physical_G_upper  1
    a[5,6]    R1483     1
    a[5,6]    R1484     1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,7]    R1485     1
    a[5,7]    R1486     1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,8]    R1487     1
    a[5,8]    R1488     1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,9]    R1489     1
    a[5,9]    R1490     1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,10]   R1491     1
    a[5,10]   R1492     1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,11]   R1493     1
    a[5,11]   R1494     1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,12]   R1495     1
    a[5,12]   R1496     1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,13]   R1497     1
    a[5,13]   R1498     1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,14]   R1499     1
    a[5,14]   R1500     1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,15]   R1501     1
    a[5,15]   R1502     1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,16]   R1503     1
    a[5,16]   R1504     1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,17]   R1505     1
    a[5,17]   R1506     1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,18]   R1507     1
    a[5,18]   R1508     1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,19]   R1509     1
    a[5,19]   R1510     1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,20]   R1511     1
    a[5,20]   R1512     1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[5,21]   R1513     1
    a[5,21]   R1514     1
    a[5,21]   true_G_epigraph  1
    a[5,21]   physical_G_upper  1
    a[5,22]   R1515     1
    a[5,22]   R1516     1
    a[5,22]   true_G_epigraph  1
    a[5,22]   physical_G_upper  1
    a[5,23]   R1517     1
    a[5,23]   R1518     1
    a[5,23]   true_G_epigraph  1
    a[5,23]   physical_G_upper  1
    a[5,24]   R1519     1
    a[5,24]   R1520     1
    a[5,24]   true_G_epigraph  1
    a[5,24]   physical_G_upper  1
    a[5,25]   R1521     1
    a[5,25]   R1522     1
    a[5,25]   true_G_epigraph  1
    a[5,25]   physical_G_upper  1
    a[5,26]   R1523     1
    a[5,26]   R1524     1
    a[5,26]   true_G_epigraph  1
    a[5,26]   physical_G_upper  1
    a[5,27]   R1525     1
    a[5,27]   R1526     1
    a[5,27]   true_G_epigraph  1
    a[5,27]   physical_G_upper  1
    a[5,28]   R1527     1
    a[5,28]   R1528     1
    a[5,28]   true_G_epigraph  1
    a[5,28]   physical_G_upper  1
    a[5,29]   R1529     1
    a[5,29]   R1530     1
    a[5,29]   true_G_epigraph  1
    a[5,29]   physical_G_upper  1
    a[5,30]   R1531     1
    a[5,30]   R1532     1
    a[5,30]   true_G_epigraph  1
    a[5,30]   physical_G_upper  1
    a[5,31]   R1533     1
    a[5,31]   R1534     1
    a[5,31]   true_G_epigraph  1
    a[5,31]   physical_G_upper  1
    a[5,32]   R1535     1
    a[5,32]   R1536     1
    a[5,32]   true_G_epigraph  1
    a[5,32]   physical_G_upper  1
    a[5,33]   R1537     1
    a[5,33]   R1538     1
    a[5,33]   true_G_epigraph  1
    a[5,33]   physical_G_upper  1
    a[5,34]   R1539     1
    a[5,34]   R1540     1
    a[5,34]   true_G_epigraph  1
    a[5,34]   physical_G_upper  1
    a[5,35]   R1541     1
    a[5,35]   R1542     1
    a[5,35]   true_G_epigraph  1
    a[5,35]   physical_G_upper  1
    a[6,7]    R1543     1
    a[6,7]    R1544     1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,8]    R1545     1
    a[6,8]    R1546     1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,9]    R1547     1
    a[6,9]    R1548     1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,10]   R1549     1
    a[6,10]   R1550     1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,11]   R1551     1
    a[6,11]   R1552     1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,12]   R1553     1
    a[6,12]   R1554     1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,13]   R1555     1
    a[6,13]   R1556     1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,14]   R1557     1
    a[6,14]   R1558     1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,15]   R1559     1
    a[6,15]   R1560     1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,16]   R1561     1
    a[6,16]   R1562     1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,17]   R1563     1
    a[6,17]   R1564     1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,18]   R1565     1
    a[6,18]   R1566     1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,19]   R1567     1
    a[6,19]   R1568     1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,20]   R1569     1
    a[6,20]   R1570     1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[6,21]   R1571     1
    a[6,21]   R1572     1
    a[6,21]   true_G_epigraph  1
    a[6,21]   physical_G_upper  1
    a[6,22]   R1573     1
    a[6,22]   R1574     1
    a[6,22]   true_G_epigraph  1
    a[6,22]   physical_G_upper  1
    a[6,23]   R1575     1
    a[6,23]   R1576     1
    a[6,23]   true_G_epigraph  1
    a[6,23]   physical_G_upper  1
    a[6,24]   R1577     1
    a[6,24]   R1578     1
    a[6,24]   true_G_epigraph  1
    a[6,24]   physical_G_upper  1
    a[6,25]   R1579     1
    a[6,25]   R1580     1
    a[6,25]   true_G_epigraph  1
    a[6,25]   physical_G_upper  1
    a[6,26]   R1581     1
    a[6,26]   R1582     1
    a[6,26]   true_G_epigraph  1
    a[6,26]   physical_G_upper  1
    a[6,27]   R1583     1
    a[6,27]   R1584     1
    a[6,27]   true_G_epigraph  1
    a[6,27]   physical_G_upper  1
    a[6,28]   R1585     1
    a[6,28]   R1586     1
    a[6,28]   true_G_epigraph  1
    a[6,28]   physical_G_upper  1
    a[6,29]   R1587     1
    a[6,29]   R1588     1
    a[6,29]   true_G_epigraph  1
    a[6,29]   physical_G_upper  1
    a[6,30]   R1589     1
    a[6,30]   R1590     1
    a[6,30]   true_G_epigraph  1
    a[6,30]   physical_G_upper  1
    a[6,31]   R1591     1
    a[6,31]   R1592     1
    a[6,31]   true_G_epigraph  1
    a[6,31]   physical_G_upper  1
    a[6,32]   R1593     1
    a[6,32]   R1594     1
    a[6,32]   true_G_epigraph  1
    a[6,32]   physical_G_upper  1
    a[6,33]   R1595     1
    a[6,33]   R1596     1
    a[6,33]   true_G_epigraph  1
    a[6,33]   physical_G_upper  1
    a[6,34]   R1597     1
    a[6,34]   R1598     1
    a[6,34]   true_G_epigraph  1
    a[6,34]   physical_G_upper  1
    a[6,35]   R1599     1
    a[6,35]   R1600     1
    a[6,35]   true_G_epigraph  1
    a[6,35]   physical_G_upper  1
    a[7,8]    R1601     1
    a[7,8]    R1602     1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,9]    R1603     1
    a[7,9]    R1604     1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,10]   R1605     1
    a[7,10]   R1606     1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,11]   R1607     1
    a[7,11]   R1608     1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,12]   R1609     1
    a[7,12]   R1610     1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,13]   R1611     1
    a[7,13]   R1612     1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,14]   R1613     1
    a[7,14]   R1614     1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,15]   R1615     1
    a[7,15]   R1616     1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,16]   R1617     1
    a[7,16]   R1618     1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,17]   R1619     1
    a[7,17]   R1620     1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,18]   R1621     1
    a[7,18]   R1622     1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,19]   R1623     1
    a[7,19]   R1624     1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,20]   R1625     1
    a[7,20]   R1626     1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[7,21]   R1627     1
    a[7,21]   R1628     1
    a[7,21]   true_G_epigraph  1
    a[7,21]   physical_G_upper  1
    a[7,22]   R1629     1
    a[7,22]   R1630     1
    a[7,22]   true_G_epigraph  1
    a[7,22]   physical_G_upper  1
    a[7,23]   R1631     1
    a[7,23]   R1632     1
    a[7,23]   true_G_epigraph  1
    a[7,23]   physical_G_upper  1
    a[7,24]   R1633     1
    a[7,24]   R1634     1
    a[7,24]   true_G_epigraph  1
    a[7,24]   physical_G_upper  1
    a[7,25]   R1635     1
    a[7,25]   R1636     1
    a[7,25]   true_G_epigraph  1
    a[7,25]   physical_G_upper  1
    a[7,26]   R1637     1
    a[7,26]   R1638     1
    a[7,26]   true_G_epigraph  1
    a[7,26]   physical_G_upper  1
    a[7,27]   R1639     1
    a[7,27]   R1640     1
    a[7,27]   true_G_epigraph  1
    a[7,27]   physical_G_upper  1
    a[7,28]   R1641     1
    a[7,28]   R1642     1
    a[7,28]   true_G_epigraph  1
    a[7,28]   physical_G_upper  1
    a[7,29]   R1643     1
    a[7,29]   R1644     1
    a[7,29]   true_G_epigraph  1
    a[7,29]   physical_G_upper  1
    a[7,30]   R1645     1
    a[7,30]   R1646     1
    a[7,30]   true_G_epigraph  1
    a[7,30]   physical_G_upper  1
    a[7,31]   R1647     1
    a[7,31]   R1648     1
    a[7,31]   true_G_epigraph  1
    a[7,31]   physical_G_upper  1
    a[7,32]   R1649     1
    a[7,32]   R1650     1
    a[7,32]   true_G_epigraph  1
    a[7,32]   physical_G_upper  1
    a[7,33]   R1651     1
    a[7,33]   R1652     1
    a[7,33]   true_G_epigraph  1
    a[7,33]   physical_G_upper  1
    a[7,34]   R1653     1
    a[7,34]   R1654     1
    a[7,34]   true_G_epigraph  1
    a[7,34]   physical_G_upper  1
    a[7,35]   R1655     1
    a[7,35]   R1656     1
    a[7,35]   true_G_epigraph  1
    a[7,35]   physical_G_upper  1
    a[8,9]    R1657     1
    a[8,9]    R1658     1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,10]   R1659     1
    a[8,10]   R1660     1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,11]   R1661     1
    a[8,11]   R1662     1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,12]   R1663     1
    a[8,12]   R1664     1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,13]   R1665     1
    a[8,13]   R1666     1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,14]   R1667     1
    a[8,14]   R1668     1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,15]   R1669     1
    a[8,15]   R1670     1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,16]   R1671     1
    a[8,16]   R1672     1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,17]   R1673     1
    a[8,17]   R1674     1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,18]   R1675     1
    a[8,18]   R1676     1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,19]   R1677     1
    a[8,19]   R1678     1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,20]   R1679     1
    a[8,20]   R1680     1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[8,21]   R1681     1
    a[8,21]   R1682     1
    a[8,21]   true_G_epigraph  1
    a[8,21]   physical_G_upper  1
    a[8,22]   R1683     1
    a[8,22]   R1684     1
    a[8,22]   true_G_epigraph  1
    a[8,22]   physical_G_upper  1
    a[8,23]   R1685     1
    a[8,23]   R1686     1
    a[8,23]   true_G_epigraph  1
    a[8,23]   physical_G_upper  1
    a[8,24]   R1687     1
    a[8,24]   R1688     1
    a[8,24]   true_G_epigraph  1
    a[8,24]   physical_G_upper  1
    a[8,25]   R1689     1
    a[8,25]   R1690     1
    a[8,25]   true_G_epigraph  1
    a[8,25]   physical_G_upper  1
    a[8,26]   R1691     1
    a[8,26]   R1692     1
    a[8,26]   true_G_epigraph  1
    a[8,26]   physical_G_upper  1
    a[8,27]   R1693     1
    a[8,27]   R1694     1
    a[8,27]   true_G_epigraph  1
    a[8,27]   physical_G_upper  1
    a[8,28]   R1695     1
    a[8,28]   R1696     1
    a[8,28]   true_G_epigraph  1
    a[8,28]   physical_G_upper  1
    a[8,29]   R1697     1
    a[8,29]   R1698     1
    a[8,29]   true_G_epigraph  1
    a[8,29]   physical_G_upper  1
    a[8,30]   R1699     1
    a[8,30]   R1700     1
    a[8,30]   true_G_epigraph  1
    a[8,30]   physical_G_upper  1
    a[8,31]   R1701     1
    a[8,31]   R1702     1
    a[8,31]   true_G_epigraph  1
    a[8,31]   physical_G_upper  1
    a[8,32]   R1703     1
    a[8,32]   R1704     1
    a[8,32]   true_G_epigraph  1
    a[8,32]   physical_G_upper  1
    a[8,33]   R1705     1
    a[8,33]   R1706     1
    a[8,33]   true_G_epigraph  1
    a[8,33]   physical_G_upper  1
    a[8,34]   R1707     1
    a[8,34]   R1708     1
    a[8,34]   true_G_epigraph  1
    a[8,34]   physical_G_upper  1
    a[8,35]   R1709     1
    a[8,35]   R1710     1
    a[8,35]   true_G_epigraph  1
    a[8,35]   physical_G_upper  1
    a[9,10]   R1711     1
    a[9,10]   R1712     1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,11]   R1713     1
    a[9,11]   R1714     1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,12]   R1715     1
    a[9,12]   R1716     1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,13]   R1717     1
    a[9,13]   R1718     1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,14]   R1719     1
    a[9,14]   R1720     1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,15]   R1721     1
    a[9,15]   R1722     1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,16]   R1723     1
    a[9,16]   R1724     1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,17]   R1725     1
    a[9,17]   R1726     1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,18]   R1727     1
    a[9,18]   R1728     1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,19]   R1729     1
    a[9,19]   R1730     1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,20]   R1731     1
    a[9,20]   R1732     1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[9,21]   R1733     1
    a[9,21]   R1734     1
    a[9,21]   true_G_epigraph  1
    a[9,21]   physical_G_upper  1
    a[9,22]   R1735     1
    a[9,22]   R1736     1
    a[9,22]   true_G_epigraph  1
    a[9,22]   physical_G_upper  1
    a[9,23]   R1737     1
    a[9,23]   R1738     1
    a[9,23]   true_G_epigraph  1
    a[9,23]   physical_G_upper  1
    a[9,24]   R1739     1
    a[9,24]   R1740     1
    a[9,24]   true_G_epigraph  1
    a[9,24]   physical_G_upper  1
    a[9,25]   R1741     1
    a[9,25]   R1742     1
    a[9,25]   true_G_epigraph  1
    a[9,25]   physical_G_upper  1
    a[9,26]   R1743     1
    a[9,26]   R1744     1
    a[9,26]   true_G_epigraph  1
    a[9,26]   physical_G_upper  1
    a[9,27]   R1745     1
    a[9,27]   R1746     1
    a[9,27]   true_G_epigraph  1
    a[9,27]   physical_G_upper  1
    a[9,28]   R1747     1
    a[9,28]   R1748     1
    a[9,28]   true_G_epigraph  1
    a[9,28]   physical_G_upper  1
    a[9,29]   R1749     1
    a[9,29]   R1750     1
    a[9,29]   true_G_epigraph  1
    a[9,29]   physical_G_upper  1
    a[9,30]   R1751     1
    a[9,30]   R1752     1
    a[9,30]   true_G_epigraph  1
    a[9,30]   physical_G_upper  1
    a[9,31]   R1753     1
    a[9,31]   R1754     1
    a[9,31]   true_G_epigraph  1
    a[9,31]   physical_G_upper  1
    a[9,32]   R1755     1
    a[9,32]   R1756     1
    a[9,32]   true_G_epigraph  1
    a[9,32]   physical_G_upper  1
    a[9,33]   R1757     1
    a[9,33]   R1758     1
    a[9,33]   true_G_epigraph  1
    a[9,33]   physical_G_upper  1
    a[9,34]   R1759     1
    a[9,34]   R1760     1
    a[9,34]   true_G_epigraph  1
    a[9,34]   physical_G_upper  1
    a[9,35]   R1761     1
    a[9,35]   R1762     1
    a[9,35]   true_G_epigraph  1
    a[9,35]   physical_G_upper  1
    a[10,11]  R1763     1
    a[10,11]  R1764     1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,12]  R1765     1
    a[10,12]  R1766     1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,13]  R1767     1
    a[10,13]  R1768     1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,14]  R1769     1
    a[10,14]  R1770     1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,15]  R1771     1
    a[10,15]  R1772     1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,16]  R1773     1
    a[10,16]  R1774     1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,17]  R1775     1
    a[10,17]  R1776     1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,18]  R1777     1
    a[10,18]  R1778     1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,19]  R1779     1
    a[10,19]  R1780     1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,20]  R1781     1
    a[10,20]  R1782     1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[10,21]  R1783     1
    a[10,21]  R1784     1
    a[10,21]  true_G_epigraph  1
    a[10,21]  physical_G_upper  1
    a[10,22]  R1785     1
    a[10,22]  R1786     1
    a[10,22]  true_G_epigraph  1
    a[10,22]  physical_G_upper  1
    a[10,23]  R1787     1
    a[10,23]  R1788     1
    a[10,23]  true_G_epigraph  1
    a[10,23]  physical_G_upper  1
    a[10,24]  R1789     1
    a[10,24]  R1790     1
    a[10,24]  true_G_epigraph  1
    a[10,24]  physical_G_upper  1
    a[10,25]  R1791     1
    a[10,25]  R1792     1
    a[10,25]  true_G_epigraph  1
    a[10,25]  physical_G_upper  1
    a[10,26]  R1793     1
    a[10,26]  R1794     1
    a[10,26]  true_G_epigraph  1
    a[10,26]  physical_G_upper  1
    a[10,27]  R1795     1
    a[10,27]  R1796     1
    a[10,27]  true_G_epigraph  1
    a[10,27]  physical_G_upper  1
    a[10,28]  R1797     1
    a[10,28]  R1798     1
    a[10,28]  true_G_epigraph  1
    a[10,28]  physical_G_upper  1
    a[10,29]  R1799     1
    a[10,29]  R1800     1
    a[10,29]  true_G_epigraph  1
    a[10,29]  physical_G_upper  1
    a[10,30]  R1801     1
    a[10,30]  R1802     1
    a[10,30]  true_G_epigraph  1
    a[10,30]  physical_G_upper  1
    a[10,31]  R1803     1
    a[10,31]  R1804     1
    a[10,31]  true_G_epigraph  1
    a[10,31]  physical_G_upper  1
    a[10,32]  R1805     1
    a[10,32]  R1806     1
    a[10,32]  true_G_epigraph  1
    a[10,32]  physical_G_upper  1
    a[10,33]  R1807     1
    a[10,33]  R1808     1
    a[10,33]  true_G_epigraph  1
    a[10,33]  physical_G_upper  1
    a[10,34]  R1809     1
    a[10,34]  R1810     1
    a[10,34]  true_G_epigraph  1
    a[10,34]  physical_G_upper  1
    a[10,35]  R1811     1
    a[10,35]  R1812     1
    a[10,35]  true_G_epigraph  1
    a[10,35]  physical_G_upper  1
    a[11,12]  R1813     1
    a[11,12]  R1814     1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,13]  R1815     1
    a[11,13]  R1816     1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,14]  R1817     1
    a[11,14]  R1818     1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,15]  R1819     1
    a[11,15]  R1820     1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,16]  R1821     1
    a[11,16]  R1822     1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,17]  R1823     1
    a[11,17]  R1824     1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,18]  R1825     1
    a[11,18]  R1826     1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,19]  R1827     1
    a[11,19]  R1828     1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,20]  R1829     1
    a[11,20]  R1830     1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[11,21]  R1831     1
    a[11,21]  R1832     1
    a[11,21]  true_G_epigraph  1
    a[11,21]  physical_G_upper  1
    a[11,22]  R1833     1
    a[11,22]  R1834     1
    a[11,22]  true_G_epigraph  1
    a[11,22]  physical_G_upper  1
    a[11,23]  R1835     1
    a[11,23]  R1836     1
    a[11,23]  true_G_epigraph  1
    a[11,23]  physical_G_upper  1
    a[11,24]  R1837     1
    a[11,24]  R1838     1
    a[11,24]  true_G_epigraph  1
    a[11,24]  physical_G_upper  1
    a[11,25]  R1839     1
    a[11,25]  R1840     1
    a[11,25]  true_G_epigraph  1
    a[11,25]  physical_G_upper  1
    a[11,26]  R1841     1
    a[11,26]  R1842     1
    a[11,26]  true_G_epigraph  1
    a[11,26]  physical_G_upper  1
    a[11,27]  R1843     1
    a[11,27]  R1844     1
    a[11,27]  true_G_epigraph  1
    a[11,27]  physical_G_upper  1
    a[11,28]  R1845     1
    a[11,28]  R1846     1
    a[11,28]  true_G_epigraph  1
    a[11,28]  physical_G_upper  1
    a[11,29]  R1847     1
    a[11,29]  R1848     1
    a[11,29]  true_G_epigraph  1
    a[11,29]  physical_G_upper  1
    a[11,30]  R1849     1
    a[11,30]  R1850     1
    a[11,30]  true_G_epigraph  1
    a[11,30]  physical_G_upper  1
    a[11,31]  R1851     1
    a[11,31]  R1852     1
    a[11,31]  true_G_epigraph  1
    a[11,31]  physical_G_upper  1
    a[11,32]  R1853     1
    a[11,32]  R1854     1
    a[11,32]  true_G_epigraph  1
    a[11,32]  physical_G_upper  1
    a[11,33]  R1855     1
    a[11,33]  R1856     1
    a[11,33]  true_G_epigraph  1
    a[11,33]  physical_G_upper  1
    a[11,34]  R1857     1
    a[11,34]  R1858     1
    a[11,34]  true_G_epigraph  1
    a[11,34]  physical_G_upper  1
    a[11,35]  R1859     1
    a[11,35]  R1860     1
    a[11,35]  true_G_epigraph  1
    a[11,35]  physical_G_upper  1
    a[12,13]  R1861     1
    a[12,13]  R1862     1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,14]  R1863     1
    a[12,14]  R1864     1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,15]  R1865     1
    a[12,15]  R1866     1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,16]  R1867     1
    a[12,16]  R1868     1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,17]  R1869     1
    a[12,17]  R1870     1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,18]  R1871     1
    a[12,18]  R1872     1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,19]  R1873     1
    a[12,19]  R1874     1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,20]  R1875     1
    a[12,20]  R1876     1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[12,21]  R1877     1
    a[12,21]  R1878     1
    a[12,21]  true_G_epigraph  1
    a[12,21]  physical_G_upper  1
    a[12,22]  R1879     1
    a[12,22]  R1880     1
    a[12,22]  true_G_epigraph  1
    a[12,22]  physical_G_upper  1
    a[12,23]  R1881     1
    a[12,23]  R1882     1
    a[12,23]  true_G_epigraph  1
    a[12,23]  physical_G_upper  1
    a[12,24]  R1883     1
    a[12,24]  R1884     1
    a[12,24]  true_G_epigraph  1
    a[12,24]  physical_G_upper  1
    a[12,25]  R1885     1
    a[12,25]  R1886     1
    a[12,25]  true_G_epigraph  1
    a[12,25]  physical_G_upper  1
    a[12,26]  R1887     1
    a[12,26]  R1888     1
    a[12,26]  true_G_epigraph  1
    a[12,26]  physical_G_upper  1
    a[12,27]  R1889     1
    a[12,27]  R1890     1
    a[12,27]  true_G_epigraph  1
    a[12,27]  physical_G_upper  1
    a[12,28]  R1891     1
    a[12,28]  R1892     1
    a[12,28]  true_G_epigraph  1
    a[12,28]  physical_G_upper  1
    a[12,29]  R1893     1
    a[12,29]  R1894     1
    a[12,29]  true_G_epigraph  1
    a[12,29]  physical_G_upper  1
    a[12,30]  R1895     1
    a[12,30]  R1896     1
    a[12,30]  true_G_epigraph  1
    a[12,30]  physical_G_upper  1
    a[12,31]  R1897     1
    a[12,31]  R1898     1
    a[12,31]  true_G_epigraph  1
    a[12,31]  physical_G_upper  1
    a[12,32]  R1899     1
    a[12,32]  R1900     1
    a[12,32]  true_G_epigraph  1
    a[12,32]  physical_G_upper  1
    a[12,33]  R1901     1
    a[12,33]  R1902     1
    a[12,33]  true_G_epigraph  1
    a[12,33]  physical_G_upper  1
    a[12,34]  R1903     1
    a[12,34]  R1904     1
    a[12,34]  true_G_epigraph  1
    a[12,34]  physical_G_upper  1
    a[12,35]  R1905     1
    a[12,35]  R1906     1
    a[12,35]  true_G_epigraph  1
    a[12,35]  physical_G_upper  1
    a[13,14]  R1907     1
    a[13,14]  R1908     1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,15]  R1909     1
    a[13,15]  R1910     1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,16]  R1911     1
    a[13,16]  R1912     1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,17]  R1913     1
    a[13,17]  R1914     1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,18]  R1915     1
    a[13,18]  R1916     1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,19]  R1917     1
    a[13,19]  R1918     1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,20]  R1919     1
    a[13,20]  R1920     1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[13,21]  R1921     1
    a[13,21]  R1922     1
    a[13,21]  true_G_epigraph  1
    a[13,21]  physical_G_upper  1
    a[13,22]  R1923     1
    a[13,22]  R1924     1
    a[13,22]  true_G_epigraph  1
    a[13,22]  physical_G_upper  1
    a[13,23]  R1925     1
    a[13,23]  R1926     1
    a[13,23]  true_G_epigraph  1
    a[13,23]  physical_G_upper  1
    a[13,24]  R1927     1
    a[13,24]  R1928     1
    a[13,24]  true_G_epigraph  1
    a[13,24]  physical_G_upper  1
    a[13,25]  R1929     1
    a[13,25]  R1930     1
    a[13,25]  true_G_epigraph  1
    a[13,25]  physical_G_upper  1
    a[13,26]  R1931     1
    a[13,26]  R1932     1
    a[13,26]  true_G_epigraph  1
    a[13,26]  physical_G_upper  1
    a[13,27]  R1933     1
    a[13,27]  R1934     1
    a[13,27]  true_G_epigraph  1
    a[13,27]  physical_G_upper  1
    a[13,28]  R1935     1
    a[13,28]  R1936     1
    a[13,28]  true_G_epigraph  1
    a[13,28]  physical_G_upper  1
    a[13,29]  R1937     1
    a[13,29]  R1938     1
    a[13,29]  true_G_epigraph  1
    a[13,29]  physical_G_upper  1
    a[13,30]  R1939     1
    a[13,30]  R1940     1
    a[13,30]  true_G_epigraph  1
    a[13,30]  physical_G_upper  1
    a[13,31]  R1941     1
    a[13,31]  R1942     1
    a[13,31]  true_G_epigraph  1
    a[13,31]  physical_G_upper  1
    a[13,32]  R1943     1
    a[13,32]  R1944     1
    a[13,32]  true_G_epigraph  1
    a[13,32]  physical_G_upper  1
    a[13,33]  R1945     1
    a[13,33]  R1946     1
    a[13,33]  true_G_epigraph  1
    a[13,33]  physical_G_upper  1
    a[13,34]  R1947     1
    a[13,34]  R1948     1
    a[13,34]  true_G_epigraph  1
    a[13,34]  physical_G_upper  1
    a[13,35]  R1949     1
    a[13,35]  R1950     1
    a[13,35]  true_G_epigraph  1
    a[13,35]  physical_G_upper  1
    a[14,15]  R1951     1
    a[14,15]  R1952     1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,16]  R1953     1
    a[14,16]  R1954     1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,17]  R1955     1
    a[14,17]  R1956     1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,18]  R1957     1
    a[14,18]  R1958     1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,19]  R1959     1
    a[14,19]  R1960     1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,20]  R1961     1
    a[14,20]  R1962     1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[14,21]  R1963     1
    a[14,21]  R1964     1
    a[14,21]  true_G_epigraph  1
    a[14,21]  physical_G_upper  1
    a[14,22]  R1965     1
    a[14,22]  R1966     1
    a[14,22]  true_G_epigraph  1
    a[14,22]  physical_G_upper  1
    a[14,23]  R1967     1
    a[14,23]  R1968     1
    a[14,23]  true_G_epigraph  1
    a[14,23]  physical_G_upper  1
    a[14,24]  R1969     1
    a[14,24]  R1970     1
    a[14,24]  true_G_epigraph  1
    a[14,24]  physical_G_upper  1
    a[14,25]  R1971     1
    a[14,25]  R1972     1
    a[14,25]  true_G_epigraph  1
    a[14,25]  physical_G_upper  1
    a[14,26]  R1973     1
    a[14,26]  R1974     1
    a[14,26]  true_G_epigraph  1
    a[14,26]  physical_G_upper  1
    a[14,27]  R1975     1
    a[14,27]  R1976     1
    a[14,27]  true_G_epigraph  1
    a[14,27]  physical_G_upper  1
    a[14,28]  R1977     1
    a[14,28]  R1978     1
    a[14,28]  true_G_epigraph  1
    a[14,28]  physical_G_upper  1
    a[14,29]  R1979     1
    a[14,29]  R1980     1
    a[14,29]  true_G_epigraph  1
    a[14,29]  physical_G_upper  1
    a[14,30]  R1981     1
    a[14,30]  R1982     1
    a[14,30]  true_G_epigraph  1
    a[14,30]  physical_G_upper  1
    a[14,31]  R1983     1
    a[14,31]  R1984     1
    a[14,31]  true_G_epigraph  1
    a[14,31]  physical_G_upper  1
    a[14,32]  R1985     1
    a[14,32]  R1986     1
    a[14,32]  true_G_epigraph  1
    a[14,32]  physical_G_upper  1
    a[14,33]  R1987     1
    a[14,33]  R1988     1
    a[14,33]  true_G_epigraph  1
    a[14,33]  physical_G_upper  1
    a[14,34]  R1989     1
    a[14,34]  R1990     1
    a[14,34]  true_G_epigraph  1
    a[14,34]  physical_G_upper  1
    a[14,35]  R1991     1
    a[14,35]  R1992     1
    a[14,35]  true_G_epigraph  1
    a[14,35]  physical_G_upper  1
    a[15,16]  R1993     1
    a[15,16]  R1994     1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,17]  R1995     1
    a[15,17]  R1996     1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,18]  R1997     1
    a[15,18]  R1998     1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,19]  R1999     1
    a[15,19]  R2000     1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,20]  R2001     1
    a[15,20]  R2002     1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[15,21]  R2003     1
    a[15,21]  R2004     1
    a[15,21]  true_G_epigraph  1
    a[15,21]  physical_G_upper  1
    a[15,22]  R2005     1
    a[15,22]  R2006     1
    a[15,22]  true_G_epigraph  1
    a[15,22]  physical_G_upper  1
    a[15,23]  R2007     1
    a[15,23]  R2008     1
    a[15,23]  true_G_epigraph  1
    a[15,23]  physical_G_upper  1
    a[15,24]  R2009     1
    a[15,24]  R2010     1
    a[15,24]  true_G_epigraph  1
    a[15,24]  physical_G_upper  1
    a[15,25]  R2011     1
    a[15,25]  R2012     1
    a[15,25]  true_G_epigraph  1
    a[15,25]  physical_G_upper  1
    a[15,26]  R2013     1
    a[15,26]  R2014     1
    a[15,26]  true_G_epigraph  1
    a[15,26]  physical_G_upper  1
    a[15,27]  R2015     1
    a[15,27]  R2016     1
    a[15,27]  true_G_epigraph  1
    a[15,27]  physical_G_upper  1
    a[15,28]  R2017     1
    a[15,28]  R2018     1
    a[15,28]  true_G_epigraph  1
    a[15,28]  physical_G_upper  1
    a[15,29]  R2019     1
    a[15,29]  R2020     1
    a[15,29]  true_G_epigraph  1
    a[15,29]  physical_G_upper  1
    a[15,30]  R2021     1
    a[15,30]  R2022     1
    a[15,30]  true_G_epigraph  1
    a[15,30]  physical_G_upper  1
    a[15,31]  R2023     1
    a[15,31]  R2024     1
    a[15,31]  true_G_epigraph  1
    a[15,31]  physical_G_upper  1
    a[15,32]  R2025     1
    a[15,32]  R2026     1
    a[15,32]  true_G_epigraph  1
    a[15,32]  physical_G_upper  1
    a[15,33]  R2027     1
    a[15,33]  R2028     1
    a[15,33]  true_G_epigraph  1
    a[15,33]  physical_G_upper  1
    a[15,34]  R2029     1
    a[15,34]  R2030     1
    a[15,34]  true_G_epigraph  1
    a[15,34]  physical_G_upper  1
    a[15,35]  R2031     1
    a[15,35]  R2032     1
    a[15,35]  true_G_epigraph  1
    a[15,35]  physical_G_upper  1
    a[16,17]  R2033     1
    a[16,17]  R2034     1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,18]  R2035     1
    a[16,18]  R2036     1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,19]  R2037     1
    a[16,19]  R2038     1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,20]  R2039     1
    a[16,20]  R2040     1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[16,21]  R2041     1
    a[16,21]  R2042     1
    a[16,21]  true_G_epigraph  1
    a[16,21]  physical_G_upper  1
    a[16,22]  R2043     1
    a[16,22]  R2044     1
    a[16,22]  true_G_epigraph  1
    a[16,22]  physical_G_upper  1
    a[16,23]  R2045     1
    a[16,23]  R2046     1
    a[16,23]  true_G_epigraph  1
    a[16,23]  physical_G_upper  1
    a[16,24]  R2047     1
    a[16,24]  R2048     1
    a[16,24]  true_G_epigraph  1
    a[16,24]  physical_G_upper  1
    a[16,25]  R2049     1
    a[16,25]  R2050     1
    a[16,25]  true_G_epigraph  1
    a[16,25]  physical_G_upper  1
    a[16,26]  R2051     1
    a[16,26]  R2052     1
    a[16,26]  true_G_epigraph  1
    a[16,26]  physical_G_upper  1
    a[16,27]  R2053     1
    a[16,27]  R2054     1
    a[16,27]  true_G_epigraph  1
    a[16,27]  physical_G_upper  1
    a[16,28]  R2055     1
    a[16,28]  R2056     1
    a[16,28]  true_G_epigraph  1
    a[16,28]  physical_G_upper  1
    a[16,29]  R2057     1
    a[16,29]  R2058     1
    a[16,29]  true_G_epigraph  1
    a[16,29]  physical_G_upper  1
    a[16,30]  R2059     1
    a[16,30]  R2060     1
    a[16,30]  true_G_epigraph  1
    a[16,30]  physical_G_upper  1
    a[16,31]  R2061     1
    a[16,31]  R2062     1
    a[16,31]  true_G_epigraph  1
    a[16,31]  physical_G_upper  1
    a[16,32]  R2063     1
    a[16,32]  R2064     1
    a[16,32]  true_G_epigraph  1
    a[16,32]  physical_G_upper  1
    a[16,33]  R2065     1
    a[16,33]  R2066     1
    a[16,33]  true_G_epigraph  1
    a[16,33]  physical_G_upper  1
    a[16,34]  R2067     1
    a[16,34]  R2068     1
    a[16,34]  true_G_epigraph  1
    a[16,34]  physical_G_upper  1
    a[16,35]  R2069     1
    a[16,35]  R2070     1
    a[16,35]  true_G_epigraph  1
    a[16,35]  physical_G_upper  1
    a[17,18]  R2071     1
    a[17,18]  R2072     1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,19]  R2073     1
    a[17,19]  R2074     1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,20]  R2075     1
    a[17,20]  R2076     1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[17,21]  R2077     1
    a[17,21]  R2078     1
    a[17,21]  true_G_epigraph  1
    a[17,21]  physical_G_upper  1
    a[17,22]  R2079     1
    a[17,22]  R2080     1
    a[17,22]  true_G_epigraph  1
    a[17,22]  physical_G_upper  1
    a[17,23]  R2081     1
    a[17,23]  R2082     1
    a[17,23]  true_G_epigraph  1
    a[17,23]  physical_G_upper  1
    a[17,24]  R2083     1
    a[17,24]  R2084     1
    a[17,24]  true_G_epigraph  1
    a[17,24]  physical_G_upper  1
    a[17,25]  R2085     1
    a[17,25]  R2086     1
    a[17,25]  true_G_epigraph  1
    a[17,25]  physical_G_upper  1
    a[17,26]  R2087     1
    a[17,26]  R2088     1
    a[17,26]  true_G_epigraph  1
    a[17,26]  physical_G_upper  1
    a[17,27]  R2089     1
    a[17,27]  R2090     1
    a[17,27]  true_G_epigraph  1
    a[17,27]  physical_G_upper  1
    a[17,28]  R2091     1
    a[17,28]  R2092     1
    a[17,28]  true_G_epigraph  1
    a[17,28]  physical_G_upper  1
    a[17,29]  R2093     1
    a[17,29]  R2094     1
    a[17,29]  true_G_epigraph  1
    a[17,29]  physical_G_upper  1
    a[17,30]  R2095     1
    a[17,30]  R2096     1
    a[17,30]  true_G_epigraph  1
    a[17,30]  physical_G_upper  1
    a[17,31]  R2097     1
    a[17,31]  R2098     1
    a[17,31]  true_G_epigraph  1
    a[17,31]  physical_G_upper  1
    a[17,32]  R2099     1
    a[17,32]  R2100     1
    a[17,32]  true_G_epigraph  1
    a[17,32]  physical_G_upper  1
    a[17,33]  R2101     1
    a[17,33]  R2102     1
    a[17,33]  true_G_epigraph  1
    a[17,33]  physical_G_upper  1
    a[17,34]  R2103     1
    a[17,34]  R2104     1
    a[17,34]  true_G_epigraph  1
    a[17,34]  physical_G_upper  1
    a[17,35]  R2105     1
    a[17,35]  R2106     1
    a[17,35]  true_G_epigraph  1
    a[17,35]  physical_G_upper  1
    a[18,19]  R2107     1
    a[18,19]  R2108     1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,20]  R2109     1
    a[18,20]  R2110     1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[18,21]  R2111     1
    a[18,21]  R2112     1
    a[18,21]  true_G_epigraph  1
    a[18,21]  physical_G_upper  1
    a[18,22]  R2113     1
    a[18,22]  R2114     1
    a[18,22]  true_G_epigraph  1
    a[18,22]  physical_G_upper  1
    a[18,23]  R2115     1
    a[18,23]  R2116     1
    a[18,23]  true_G_epigraph  1
    a[18,23]  physical_G_upper  1
    a[18,24]  R2117     1
    a[18,24]  R2118     1
    a[18,24]  true_G_epigraph  1
    a[18,24]  physical_G_upper  1
    a[18,25]  R2119     1
    a[18,25]  R2120     1
    a[18,25]  true_G_epigraph  1
    a[18,25]  physical_G_upper  1
    a[18,26]  R2121     1
    a[18,26]  R2122     1
    a[18,26]  true_G_epigraph  1
    a[18,26]  physical_G_upper  1
    a[18,27]  R2123     1
    a[18,27]  R2124     1
    a[18,27]  true_G_epigraph  1
    a[18,27]  physical_G_upper  1
    a[18,28]  R2125     1
    a[18,28]  R2126     1
    a[18,28]  true_G_epigraph  1
    a[18,28]  physical_G_upper  1
    a[18,29]  R2127     1
    a[18,29]  R2128     1
    a[18,29]  true_G_epigraph  1
    a[18,29]  physical_G_upper  1
    a[18,30]  R2129     1
    a[18,30]  R2130     1
    a[18,30]  true_G_epigraph  1
    a[18,30]  physical_G_upper  1
    a[18,31]  R2131     1
    a[18,31]  R2132     1
    a[18,31]  true_G_epigraph  1
    a[18,31]  physical_G_upper  1
    a[18,32]  R2133     1
    a[18,32]  R2134     1
    a[18,32]  true_G_epigraph  1
    a[18,32]  physical_G_upper  1
    a[18,33]  R2135     1
    a[18,33]  R2136     1
    a[18,33]  true_G_epigraph  1
    a[18,33]  physical_G_upper  1
    a[18,34]  R2137     1
    a[18,34]  R2138     1
    a[18,34]  true_G_epigraph  1
    a[18,34]  physical_G_upper  1
    a[18,35]  R2139     1
    a[18,35]  R2140     1
    a[18,35]  true_G_epigraph  1
    a[18,35]  physical_G_upper  1
    a[19,20]  R2141     1
    a[19,20]  R2142     1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    a[19,21]  R2143     1
    a[19,21]  R2144     1
    a[19,21]  true_G_epigraph  1
    a[19,21]  physical_G_upper  1
    a[19,22]  R2145     1
    a[19,22]  R2146     1
    a[19,22]  true_G_epigraph  1
    a[19,22]  physical_G_upper  1
    a[19,23]  R2147     1
    a[19,23]  R2148     1
    a[19,23]  true_G_epigraph  1
    a[19,23]  physical_G_upper  1
    a[19,24]  R2149     1
    a[19,24]  R2150     1
    a[19,24]  true_G_epigraph  1
    a[19,24]  physical_G_upper  1
    a[19,25]  R2151     1
    a[19,25]  R2152     1
    a[19,25]  true_G_epigraph  1
    a[19,25]  physical_G_upper  1
    a[19,26]  R2153     1
    a[19,26]  R2154     1
    a[19,26]  true_G_epigraph  1
    a[19,26]  physical_G_upper  1
    a[19,27]  R2155     1
    a[19,27]  R2156     1
    a[19,27]  true_G_epigraph  1
    a[19,27]  physical_G_upper  1
    a[19,28]  R2157     1
    a[19,28]  R2158     1
    a[19,28]  true_G_epigraph  1
    a[19,28]  physical_G_upper  1
    a[19,29]  R2159     1
    a[19,29]  R2160     1
    a[19,29]  true_G_epigraph  1
    a[19,29]  physical_G_upper  1
    a[19,30]  R2161     1
    a[19,30]  R2162     1
    a[19,30]  true_G_epigraph  1
    a[19,30]  physical_G_upper  1
    a[19,31]  R2163     1
    a[19,31]  R2164     1
    a[19,31]  true_G_epigraph  1
    a[19,31]  physical_G_upper  1
    a[19,32]  R2165     1
    a[19,32]  R2166     1
    a[19,32]  true_G_epigraph  1
    a[19,32]  physical_G_upper  1
    a[19,33]  R2167     1
    a[19,33]  R2168     1
    a[19,33]  true_G_epigraph  1
    a[19,33]  physical_G_upper  1
    a[19,34]  R2169     1
    a[19,34]  R2170     1
    a[19,34]  true_G_epigraph  1
    a[19,34]  physical_G_upper  1
    a[19,35]  R2171     1
    a[19,35]  R2172     1
    a[19,35]  true_G_epigraph  1
    a[19,35]  physical_G_upper  1
    a[20,21]  R2173     1
    a[20,21]  R2174     1
    a[20,21]  true_G_epigraph  1
    a[20,21]  physical_G_upper  1
    a[20,22]  R2175     1
    a[20,22]  R2176     1
    a[20,22]  true_G_epigraph  1
    a[20,22]  physical_G_upper  1
    a[20,23]  R2177     1
    a[20,23]  R2178     1
    a[20,23]  true_G_epigraph  1
    a[20,23]  physical_G_upper  1
    a[20,24]  R2179     1
    a[20,24]  R2180     1
    a[20,24]  true_G_epigraph  1
    a[20,24]  physical_G_upper  1
    a[20,25]  R2181     1
    a[20,25]  R2182     1
    a[20,25]  true_G_epigraph  1
    a[20,25]  physical_G_upper  1
    a[20,26]  R2183     1
    a[20,26]  R2184     1
    a[20,26]  true_G_epigraph  1
    a[20,26]  physical_G_upper  1
    a[20,27]  R2185     1
    a[20,27]  R2186     1
    a[20,27]  true_G_epigraph  1
    a[20,27]  physical_G_upper  1
    a[20,28]  R2187     1
    a[20,28]  R2188     1
    a[20,28]  true_G_epigraph  1
    a[20,28]  physical_G_upper  1
    a[20,29]  R2189     1
    a[20,29]  R2190     1
    a[20,29]  true_G_epigraph  1
    a[20,29]  physical_G_upper  1
    a[20,30]  R2191     1
    a[20,30]  R2192     1
    a[20,30]  true_G_epigraph  1
    a[20,30]  physical_G_upper  1
    a[20,31]  R2193     1
    a[20,31]  R2194     1
    a[20,31]  true_G_epigraph  1
    a[20,31]  physical_G_upper  1
    a[20,32]  R2195     1
    a[20,32]  R2196     1
    a[20,32]  true_G_epigraph  1
    a[20,32]  physical_G_upper  1
    a[20,33]  R2197     1
    a[20,33]  R2198     1
    a[20,33]  true_G_epigraph  1
    a[20,33]  physical_G_upper  1
    a[20,34]  R2199     1
    a[20,34]  R2200     1
    a[20,34]  true_G_epigraph  1
    a[20,34]  physical_G_upper  1
    a[20,35]  R2201     1
    a[20,35]  R2202     1
    a[20,35]  true_G_epigraph  1
    a[20,35]  physical_G_upper  1
    a[21,22]  R2203     1
    a[21,22]  R2204     1
    a[21,22]  true_G_epigraph  1
    a[21,22]  physical_G_upper  1
    a[21,23]  R2205     1
    a[21,23]  R2206     1
    a[21,23]  true_G_epigraph  1
    a[21,23]  physical_G_upper  1
    a[21,24]  R2207     1
    a[21,24]  R2208     1
    a[21,24]  true_G_epigraph  1
    a[21,24]  physical_G_upper  1
    a[21,25]  R2209     1
    a[21,25]  R2210     1
    a[21,25]  true_G_epigraph  1
    a[21,25]  physical_G_upper  1
    a[21,26]  R2211     1
    a[21,26]  R2212     1
    a[21,26]  true_G_epigraph  1
    a[21,26]  physical_G_upper  1
    a[21,27]  R2213     1
    a[21,27]  R2214     1
    a[21,27]  true_G_epigraph  1
    a[21,27]  physical_G_upper  1
    a[21,28]  R2215     1
    a[21,28]  R2216     1
    a[21,28]  true_G_epigraph  1
    a[21,28]  physical_G_upper  1
    a[21,29]  R2217     1
    a[21,29]  R2218     1
    a[21,29]  true_G_epigraph  1
    a[21,29]  physical_G_upper  1
    a[21,30]  R2219     1
    a[21,30]  R2220     1
    a[21,30]  true_G_epigraph  1
    a[21,30]  physical_G_upper  1
    a[21,31]  R2221     1
    a[21,31]  R2222     1
    a[21,31]  true_G_epigraph  1
    a[21,31]  physical_G_upper  1
    a[21,32]  R2223     1
    a[21,32]  R2224     1
    a[21,32]  true_G_epigraph  1
    a[21,32]  physical_G_upper  1
    a[21,33]  R2225     1
    a[21,33]  R2226     1
    a[21,33]  true_G_epigraph  1
    a[21,33]  physical_G_upper  1
    a[21,34]  R2227     1
    a[21,34]  R2228     1
    a[21,34]  true_G_epigraph  1
    a[21,34]  physical_G_upper  1
    a[21,35]  R2229     1
    a[21,35]  R2230     1
    a[21,35]  true_G_epigraph  1
    a[21,35]  physical_G_upper  1
    a[22,23]  R2231     1
    a[22,23]  R2232     1
    a[22,23]  true_G_epigraph  1
    a[22,23]  physical_G_upper  1
    a[22,24]  R2233     1
    a[22,24]  R2234     1
    a[22,24]  true_G_epigraph  1
    a[22,24]  physical_G_upper  1
    a[22,25]  R2235     1
    a[22,25]  R2236     1
    a[22,25]  true_G_epigraph  1
    a[22,25]  physical_G_upper  1
    a[22,26]  R2237     1
    a[22,26]  R2238     1
    a[22,26]  true_G_epigraph  1
    a[22,26]  physical_G_upper  1
    a[22,27]  R2239     1
    a[22,27]  R2240     1
    a[22,27]  true_G_epigraph  1
    a[22,27]  physical_G_upper  1
    a[22,28]  R2241     1
    a[22,28]  R2242     1
    a[22,28]  true_G_epigraph  1
    a[22,28]  physical_G_upper  1
    a[22,29]  R2243     1
    a[22,29]  R2244     1
    a[22,29]  true_G_epigraph  1
    a[22,29]  physical_G_upper  1
    a[22,30]  R2245     1
    a[22,30]  R2246     1
    a[22,30]  true_G_epigraph  1
    a[22,30]  physical_G_upper  1
    a[22,31]  R2247     1
    a[22,31]  R2248     1
    a[22,31]  true_G_epigraph  1
    a[22,31]  physical_G_upper  1
    a[22,32]  R2249     1
    a[22,32]  R2250     1
    a[22,32]  true_G_epigraph  1
    a[22,32]  physical_G_upper  1
    a[22,33]  R2251     1
    a[22,33]  R2252     1
    a[22,33]  true_G_epigraph  1
    a[22,33]  physical_G_upper  1
    a[22,34]  R2253     1
    a[22,34]  R2254     1
    a[22,34]  true_G_epigraph  1
    a[22,34]  physical_G_upper  1
    a[22,35]  R2255     1
    a[22,35]  R2256     1
    a[22,35]  true_G_epigraph  1
    a[22,35]  physical_G_upper  1
    a[23,24]  R2257     1
    a[23,24]  R2258     1
    a[23,24]  true_G_epigraph  1
    a[23,24]  physical_G_upper  1
    a[23,25]  R2259     1
    a[23,25]  R2260     1
    a[23,25]  true_G_epigraph  1
    a[23,25]  physical_G_upper  1
    a[23,26]  R2261     1
    a[23,26]  R2262     1
    a[23,26]  true_G_epigraph  1
    a[23,26]  physical_G_upper  1
    a[23,27]  R2263     1
    a[23,27]  R2264     1
    a[23,27]  true_G_epigraph  1
    a[23,27]  physical_G_upper  1
    a[23,28]  R2265     1
    a[23,28]  R2266     1
    a[23,28]  true_G_epigraph  1
    a[23,28]  physical_G_upper  1
    a[23,29]  R2267     1
    a[23,29]  R2268     1
    a[23,29]  true_G_epigraph  1
    a[23,29]  physical_G_upper  1
    a[23,30]  R2269     1
    a[23,30]  R2270     1
    a[23,30]  true_G_epigraph  1
    a[23,30]  physical_G_upper  1
    a[23,31]  R2271     1
    a[23,31]  R2272     1
    a[23,31]  true_G_epigraph  1
    a[23,31]  physical_G_upper  1
    a[23,32]  R2273     1
    a[23,32]  R2274     1
    a[23,32]  true_G_epigraph  1
    a[23,32]  physical_G_upper  1
    a[23,33]  R2275     1
    a[23,33]  R2276     1
    a[23,33]  true_G_epigraph  1
    a[23,33]  physical_G_upper  1
    a[23,34]  R2277     1
    a[23,34]  R2278     1
    a[23,34]  true_G_epigraph  1
    a[23,34]  physical_G_upper  1
    a[23,35]  R2279     1
    a[23,35]  R2280     1
    a[23,35]  true_G_epigraph  1
    a[23,35]  physical_G_upper  1
    a[24,25]  R2281     1
    a[24,25]  R2282     1
    a[24,25]  true_G_epigraph  1
    a[24,25]  physical_G_upper  1
    a[24,26]  R2283     1
    a[24,26]  R2284     1
    a[24,26]  true_G_epigraph  1
    a[24,26]  physical_G_upper  1
    a[24,27]  R2285     1
    a[24,27]  R2286     1
    a[24,27]  true_G_epigraph  1
    a[24,27]  physical_G_upper  1
    a[24,28]  R2287     1
    a[24,28]  R2288     1
    a[24,28]  true_G_epigraph  1
    a[24,28]  physical_G_upper  1
    a[24,29]  R2289     1
    a[24,29]  R2290     1
    a[24,29]  true_G_epigraph  1
    a[24,29]  physical_G_upper  1
    a[24,30]  R2291     1
    a[24,30]  R2292     1
    a[24,30]  true_G_epigraph  1
    a[24,30]  physical_G_upper  1
    a[24,31]  R2293     1
    a[24,31]  R2294     1
    a[24,31]  true_G_epigraph  1
    a[24,31]  physical_G_upper  1
    a[24,32]  R2295     1
    a[24,32]  R2296     1
    a[24,32]  true_G_epigraph  1
    a[24,32]  physical_G_upper  1
    a[24,33]  R2297     1
    a[24,33]  R2298     1
    a[24,33]  true_G_epigraph  1
    a[24,33]  physical_G_upper  1
    a[24,34]  R2299     1
    a[24,34]  R2300     1
    a[24,34]  true_G_epigraph  1
    a[24,34]  physical_G_upper  1
    a[24,35]  R2301     1
    a[24,35]  R2302     1
    a[24,35]  true_G_epigraph  1
    a[24,35]  physical_G_upper  1
    a[25,26]  R2303     1
    a[25,26]  R2304     1
    a[25,26]  true_G_epigraph  1
    a[25,26]  physical_G_upper  1
    a[25,27]  R2305     1
    a[25,27]  R2306     1
    a[25,27]  true_G_epigraph  1
    a[25,27]  physical_G_upper  1
    a[25,28]  R2307     1
    a[25,28]  R2308     1
    a[25,28]  true_G_epigraph  1
    a[25,28]  physical_G_upper  1
    a[25,29]  R2309     1
    a[25,29]  R2310     1
    a[25,29]  true_G_epigraph  1
    a[25,29]  physical_G_upper  1
    a[25,30]  R2311     1
    a[25,30]  R2312     1
    a[25,30]  true_G_epigraph  1
    a[25,30]  physical_G_upper  1
    a[25,31]  R2313     1
    a[25,31]  R2314     1
    a[25,31]  true_G_epigraph  1
    a[25,31]  physical_G_upper  1
    a[25,32]  R2315     1
    a[25,32]  R2316     1
    a[25,32]  true_G_epigraph  1
    a[25,32]  physical_G_upper  1
    a[25,33]  R2317     1
    a[25,33]  R2318     1
    a[25,33]  true_G_epigraph  1
    a[25,33]  physical_G_upper  1
    a[25,34]  R2319     1
    a[25,34]  R2320     1
    a[25,34]  true_G_epigraph  1
    a[25,34]  physical_G_upper  1
    a[25,35]  R2321     1
    a[25,35]  R2322     1
    a[25,35]  true_G_epigraph  1
    a[25,35]  physical_G_upper  1
    a[26,27]  R2323     1
    a[26,27]  R2324     1
    a[26,27]  true_G_epigraph  1
    a[26,27]  physical_G_upper  1
    a[26,28]  R2325     1
    a[26,28]  R2326     1
    a[26,28]  true_G_epigraph  1
    a[26,28]  physical_G_upper  1
    a[26,29]  R2327     1
    a[26,29]  R2328     1
    a[26,29]  true_G_epigraph  1
    a[26,29]  physical_G_upper  1
    a[26,30]  R2329     1
    a[26,30]  R2330     1
    a[26,30]  true_G_epigraph  1
    a[26,30]  physical_G_upper  1
    a[26,31]  R2331     1
    a[26,31]  R2332     1
    a[26,31]  true_G_epigraph  1
    a[26,31]  physical_G_upper  1
    a[26,32]  R2333     1
    a[26,32]  R2334     1
    a[26,32]  true_G_epigraph  1
    a[26,32]  physical_G_upper  1
    a[26,33]  R2335     1
    a[26,33]  R2336     1
    a[26,33]  true_G_epigraph  1
    a[26,33]  physical_G_upper  1
    a[26,34]  R2337     1
    a[26,34]  R2338     1
    a[26,34]  true_G_epigraph  1
    a[26,34]  physical_G_upper  1
    a[26,35]  R2339     1
    a[26,35]  R2340     1
    a[26,35]  true_G_epigraph  1
    a[26,35]  physical_G_upper  1
    a[27,28]  R2341     1
    a[27,28]  R2342     1
    a[27,28]  true_G_epigraph  1
    a[27,28]  physical_G_upper  1
    a[27,29]  R2343     1
    a[27,29]  R2344     1
    a[27,29]  true_G_epigraph  1
    a[27,29]  physical_G_upper  1
    a[27,30]  R2345     1
    a[27,30]  R2346     1
    a[27,30]  true_G_epigraph  1
    a[27,30]  physical_G_upper  1
    a[27,31]  R2347     1
    a[27,31]  R2348     1
    a[27,31]  true_G_epigraph  1
    a[27,31]  physical_G_upper  1
    a[27,32]  R2349     1
    a[27,32]  R2350     1
    a[27,32]  true_G_epigraph  1
    a[27,32]  physical_G_upper  1
    a[27,33]  R2351     1
    a[27,33]  R2352     1
    a[27,33]  true_G_epigraph  1
    a[27,33]  physical_G_upper  1
    a[27,34]  R2353     1
    a[27,34]  R2354     1
    a[27,34]  true_G_epigraph  1
    a[27,34]  physical_G_upper  1
    a[27,35]  R2355     1
    a[27,35]  R2356     1
    a[27,35]  true_G_epigraph  1
    a[27,35]  physical_G_upper  1
    a[28,29]  R2357     1
    a[28,29]  R2358     1
    a[28,29]  true_G_epigraph  1
    a[28,29]  physical_G_upper  1
    a[28,30]  R2359     1
    a[28,30]  R2360     1
    a[28,30]  true_G_epigraph  1
    a[28,30]  physical_G_upper  1
    a[28,31]  R2361     1
    a[28,31]  R2362     1
    a[28,31]  true_G_epigraph  1
    a[28,31]  physical_G_upper  1
    a[28,32]  R2363     1
    a[28,32]  R2364     1
    a[28,32]  true_G_epigraph  1
    a[28,32]  physical_G_upper  1
    a[28,33]  R2365     1
    a[28,33]  R2366     1
    a[28,33]  true_G_epigraph  1
    a[28,33]  physical_G_upper  1
    a[28,34]  R2367     1
    a[28,34]  R2368     1
    a[28,34]  true_G_epigraph  1
    a[28,34]  physical_G_upper  1
    a[28,35]  R2369     1
    a[28,35]  R2370     1
    a[28,35]  true_G_epigraph  1
    a[28,35]  physical_G_upper  1
    a[29,30]  R2371     1
    a[29,30]  R2372     1
    a[29,30]  true_G_epigraph  1
    a[29,30]  physical_G_upper  1
    a[29,31]  R2373     1
    a[29,31]  R2374     1
    a[29,31]  true_G_epigraph  1
    a[29,31]  physical_G_upper  1
    a[29,32]  R2375     1
    a[29,32]  R2376     1
    a[29,32]  true_G_epigraph  1
    a[29,32]  physical_G_upper  1
    a[29,33]  R2377     1
    a[29,33]  R2378     1
    a[29,33]  true_G_epigraph  1
    a[29,33]  physical_G_upper  1
    a[29,34]  R2379     1
    a[29,34]  R2380     1
    a[29,34]  true_G_epigraph  1
    a[29,34]  physical_G_upper  1
    a[29,35]  R2381     1
    a[29,35]  R2382     1
    a[29,35]  true_G_epigraph  1
    a[29,35]  physical_G_upper  1
    a[30,31]  R2383     1
    a[30,31]  R2384     1
    a[30,31]  true_G_epigraph  1
    a[30,31]  physical_G_upper  1
    a[30,32]  R2385     1
    a[30,32]  R2386     1
    a[30,32]  true_G_epigraph  1
    a[30,32]  physical_G_upper  1
    a[30,33]  R2387     1
    a[30,33]  R2388     1
    a[30,33]  true_G_epigraph  1
    a[30,33]  physical_G_upper  1
    a[30,34]  R2389     1
    a[30,34]  R2390     1
    a[30,34]  true_G_epigraph  1
    a[30,34]  physical_G_upper  1
    a[30,35]  R2391     1
    a[30,35]  R2392     1
    a[30,35]  true_G_epigraph  1
    a[30,35]  physical_G_upper  1
    a[31,32]  R2393     1
    a[31,32]  R2394     1
    a[31,32]  true_G_epigraph  1
    a[31,32]  physical_G_upper  1
    a[31,33]  R2395     1
    a[31,33]  R2396     1
    a[31,33]  true_G_epigraph  1
    a[31,33]  physical_G_upper  1
    a[31,34]  R2397     1
    a[31,34]  R2398     1
    a[31,34]  true_G_epigraph  1
    a[31,34]  physical_G_upper  1
    a[31,35]  R2399     1
    a[31,35]  R2400     1
    a[31,35]  true_G_epigraph  1
    a[31,35]  physical_G_upper  1
    a[32,33]  R2401     1
    a[32,33]  R2402     1
    a[32,33]  true_G_epigraph  1
    a[32,33]  physical_G_upper  1
    a[32,34]  R2403     1
    a[32,34]  R2404     1
    a[32,34]  true_G_epigraph  1
    a[32,34]  physical_G_upper  1
    a[32,35]  R2405     1
    a[32,35]  R2406     1
    a[32,35]  true_G_epigraph  1
    a[32,35]  physical_G_upper  1
    a[33,34]  R2407     1
    a[33,34]  R2408     1
    a[33,34]  true_G_epigraph  1
    a[33,34]  physical_G_upper  1
    a[33,35]  R2409     1
    a[33,35]  R2410     1
    a[33,35]  true_G_epigraph  1
    a[33,35]  physical_G_upper  1
    a[34,35]  R2411     1
    a[34,35]  R2412     1
    a[34,35]  true_G_epigraph  1
    a[34,35]  physical_G_upper  1
    q         OBJ       1
    q         true_G_epigraph  -35
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      onehot_21  1
    RHS1      onehot_22  1
    RHS1      onehot_23  1
    RHS1      onehot_24  1
    RHS1      onehot_25  1
    RHS1      onehot_26  1
    RHS1      onehot_27  1
    RHS1      onehot_28  1
    RHS1      onehot_29  1
    RHS1      onehot_30  1
    RHS1      onehot_31  1
    RHS1      onehot_32  1
    RHS1      onehot_33  1
    RHS1      onehot_34  1
    RHS1      onehot_35  1
    RHS1      hard_lower  251
    RHS1      hard_upper  326
    RHS1      normalization  1
    RHS1      physical_G_upper  2.6860981165365086e+01
BOUNDS
 BV BND1      x[1,4]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[2,16] 
 BV BND1      x[2,17] 
 BV BND1      x[2,18] 
 BV BND1      x[2,19] 
 BV BND1      x[2,20] 
 BV BND1      x[2,21] 
 BV BND1      x[2,22] 
 BV BND1      x[2,23] 
 BV BND1      x[3,13] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[6,4]  
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[7,16] 
 BV BND1      x[7,17] 
 BV BND1      x[7,18] 
 BV BND1      x[7,19] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[8,13] 
 BV BND1      x[8,14] 
 BV BND1      x[8,15] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[9,11] 
 BV BND1      x[9,12] 
 BV BND1      x[9,13] 
 BV BND1      x[9,14] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[10,8] 
 BV BND1      x[10,9] 
 BV BND1      x[10,10]
 BV BND1      x[10,11]
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[11,13]
 BV BND1      x[11,14]
 BV BND1      x[11,15]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[13,9] 
 BV BND1      x[13,10]
 BV BND1      x[13,11]
 BV BND1      x[13,12]
 BV BND1      x[13,13]
 BV BND1      x[13,14]
 BV BND1      x[13,15]
 BV BND1      x[13,16]
 BV BND1      x[13,17]
 BV BND1      x[13,18]
 BV BND1      x[13,19]
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[14,16]
 BV BND1      x[14,17]
 BV BND1      x[14,18]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[15,9] 
 BV BND1      x[15,10]
 BV BND1      x[15,11]
 BV BND1      x[15,12]
 BV BND1      x[15,13]
 BV BND1      x[15,14]
 BV BND1      x[15,15]
 BV BND1      x[15,16]
 BV BND1      x[15,17]
 BV BND1      x[15,18]
 BV BND1      x[15,19]
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[17,16]
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[18,2] 
 BV BND1      x[18,3] 
 BV BND1      x[18,4] 
 BV BND1      x[18,5] 
 BV BND1      x[18,6] 
 BV BND1      x[18,7] 
 BV BND1      x[18,8] 
 BV BND1      x[18,9] 
 BV BND1      x[18,10]
 BV BND1      x[18,11]
 BV BND1      x[18,12]
 BV BND1      x[18,13]
 BV BND1      x[18,14]
 BV BND1      x[18,15]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[19,9] 
 BV BND1      x[19,10]
 BV BND1      x[19,11]
 BV BND1      x[19,12]
 BV BND1      x[19,13]
 BV BND1      x[19,14]
 BV BND1      x[19,15]
 BV BND1      x[19,16]
 BV BND1      x[19,17]
 BV BND1      x[19,18]
 BV BND1      x[19,19]
 BV BND1      x[20,0] 
 BV BND1      x[20,1] 
 BV BND1      x[20,2] 
 BV BND1      x[20,3] 
 BV BND1      x[20,4] 
 BV BND1      x[20,5] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[20,11]
 BV BND1      x[20,12]
 BV BND1      x[20,13]
 BV BND1      x[20,14]
 BV BND1      x[20,15]
 BV BND1      x[21,0] 
 BV BND1      x[21,1] 
 BV BND1      x[21,2] 
 BV BND1      x[21,3] 
 BV BND1      x[21,4] 
 BV BND1      x[21,5] 
 BV BND1      x[21,6] 
 BV BND1      x[21,7] 
 BV BND1      x[21,8] 
 BV BND1      x[21,9] 
 BV BND1      x[21,10]
 BV BND1      x[21,11]
 BV BND1      x[21,12]
 BV BND1      x[21,13]
 BV BND1      x[21,14]
 BV BND1      x[21,15]
 BV BND1      x[21,16]
 BV BND1      x[21,17]
 BV BND1      x[21,18]
 BV BND1      x[21,19]
 BV BND1      x[22,0] 
 BV BND1      x[22,1] 
 BV BND1      x[22,2] 
 BV BND1      x[22,3] 
 BV BND1      x[22,4] 
 BV BND1      x[22,5] 
 BV BND1      x[22,6] 
 BV BND1      x[22,7] 
 BV BND1      x[22,8] 
 BV BND1      x[22,9] 
 BV BND1      x[22,10]
 BV BND1      x[22,11]
 BV BND1      x[22,12]
 BV BND1      x[22,13]
 BV BND1      x[22,14]
 BV BND1      x[22,15]
 BV BND1      x[22,16]
 BV BND1      x[22,17]
 BV BND1      x[22,18]
 BV BND1      x[22,19]
 BV BND1      x[23,0] 
 BV BND1      x[23,1] 
 BV BND1      x[23,2] 
 BV BND1      x[23,3] 
 BV BND1      x[23,4] 
 BV BND1      x[23,5] 
 BV BND1      x[23,6] 
 BV BND1      x[23,7] 
 BV BND1      x[23,8] 
 BV BND1      x[23,9] 
 BV BND1      x[23,10]
 BV BND1      x[23,11]
 BV BND1      x[23,12]
 BV BND1      x[23,13]
 BV BND1      x[23,14]
 BV BND1      x[23,15]
 BV BND1      x[24,0] 
 BV BND1      x[24,1] 
 BV BND1      x[24,2] 
 BV BND1      x[24,3] 
 BV BND1      x[24,4] 
 BV BND1      x[24,5] 
 BV BND1      x[24,6] 
 BV BND1      x[24,7] 
 BV BND1      x[24,8] 
 BV BND1      x[25,0] 
 BV BND1      x[25,1] 
 BV BND1      x[25,2] 
 BV BND1      x[25,3] 
 BV BND1      x[25,4] 
 BV BND1      x[25,5] 
 BV BND1      x[25,6] 
 BV BND1      x[25,7] 
 BV BND1      x[25,8] 
 BV BND1      x[25,9] 
 BV BND1      x[25,10]
 BV BND1      x[25,11]
 BV BND1      x[25,12]
 BV BND1      x[25,13]
 BV BND1      x[25,14]
 BV BND1      x[25,15]
 BV BND1      x[26,0] 
 BV BND1      x[26,1] 
 BV BND1      x[26,2] 
 BV BND1      x[26,3] 
 BV BND1      x[26,4] 
 BV BND1      x[26,5] 
 BV BND1      x[26,6] 
 BV BND1      x[26,7] 
 BV BND1      x[26,8] 
 BV BND1      x[26,9] 
 BV BND1      x[26,10]
 BV BND1      x[26,11]
 BV BND1      x[26,12]
 BV BND1      x[26,13]
 BV BND1      x[26,14]
 BV BND1      x[26,15]
 BV BND1      x[27,0] 
 BV BND1      x[27,1] 
 BV BND1      x[27,2] 
 BV BND1      x[27,3] 
 BV BND1      x[27,4] 
 BV BND1      x[27,5] 
 BV BND1      x[27,6] 
 BV BND1      x[27,7] 
 BV BND1      x[27,8] 
 BV BND1      x[27,9] 
 BV BND1      x[27,10]
 BV BND1      x[27,11]
 BV BND1      x[27,12]
 BV BND1      x[27,13]
 BV BND1      x[27,14]
 BV BND1      x[27,15]
 BV BND1      x[27,16]
 BV BND1      x[27,17]
 BV BND1      x[27,18]
 BV BND1      x[27,19]
 BV BND1      x[28,0] 
 BV BND1      x[28,1] 
 BV BND1      x[28,2] 
 BV BND1      x[28,3] 
 BV BND1      x[28,4] 
 BV BND1      x[28,5] 
 BV BND1      x[28,6] 
 BV BND1      x[28,7] 
 BV BND1      x[28,8] 
 BV BND1      x[28,9] 
 BV BND1      x[28,10]
 BV BND1      x[28,11]
 BV BND1      x[28,12]
 BV BND1      x[28,13]
 BV BND1      x[28,14]
 BV BND1      x[28,15]
 BV BND1      x[29,0] 
 BV BND1      x[29,1] 
 BV BND1      x[29,2] 
 BV BND1      x[29,3] 
 BV BND1      x[29,4] 
 BV BND1      x[29,5] 
 BV BND1      x[29,6] 
 BV BND1      x[29,7] 
 BV BND1      x[29,8] 
 BV BND1      x[29,9] 
 BV BND1      x[29,10]
 BV BND1      x[29,11]
 BV BND1      x[29,12]
 BV BND1      x[29,13]
 BV BND1      x[29,14]
 BV BND1      x[29,15]
 BV BND1      x[30,0] 
 BV BND1      x[30,1] 
 BV BND1      x[30,2] 
 BV BND1      x[30,3] 
 BV BND1      x[30,4] 
 BV BND1      x[30,5] 
 BV BND1      x[30,6] 
 BV BND1      x[30,7] 
 BV BND1      x[30,8] 
 BV BND1      x[30,9] 
 BV BND1      x[30,10]
 BV BND1      x[30,11]
 BV BND1      x[30,12]
 BV BND1      x[30,13]
 BV BND1      x[30,14]
 BV BND1      x[30,15]
 BV BND1      x[30,16]
 BV BND1      x[30,17]
 BV BND1      x[30,18]
 BV BND1      x[30,19]
 BV BND1      x[30,20]
 BV BND1      x[31,0] 
 BV BND1      x[31,1] 
 BV BND1      x[31,2] 
 BV BND1      x[31,3] 
 BV BND1      x[31,4] 
 BV BND1      x[31,5] 
 BV BND1      x[31,6] 
 BV BND1      x[31,7] 
 BV BND1      x[31,8] 
 BV BND1      x[31,9] 
 BV BND1      x[31,10]
 BV BND1      x[31,11]
 BV BND1      x[31,12]
 BV BND1      x[31,13]
 BV BND1      x[31,14]
 BV BND1      x[31,15]
 BV BND1      x[32,0] 
 BV BND1      x[32,1] 
 BV BND1      x[32,2] 
 BV BND1      x[32,3] 
 BV BND1      x[32,4] 
 BV BND1      x[32,5] 
 BV BND1      x[32,6] 
 BV BND1      x[32,7] 
 BV BND1      x[32,8] 
 BV BND1      x[32,9] 
 BV BND1      x[32,10]
 BV BND1      x[32,11]
 BV BND1      x[32,12]
 BV BND1      x[32,13]
 BV BND1      x[32,14]
 BV BND1      x[32,15]
 BV BND1      x[33,0] 
 BV BND1      x[33,1] 
 BV BND1      x[33,2] 
 BV BND1      x[33,3] 
 BV BND1      x[33,4] 
 BV BND1      x[33,5] 
 BV BND1      x[33,6] 
 BV BND1      x[33,7] 
 BV BND1      x[33,8] 
 BV BND1      x[33,9] 
 BV BND1      x[33,10]
 BV BND1      x[33,11]
 BV BND1      x[33,12]
 BV BND1      x[33,13]
 BV BND1      x[33,14]
 BV BND1      x[33,15]
 BV BND1      x[33,16]
 BV BND1      x[33,17]
 BV BND1      x[33,18]
 BV BND1      x[33,19]
 BV BND1      x[33,20]
 BV BND1      x[33,21]
 BV BND1      x[33,22]
 BV BND1      x[33,23]
 BV BND1      x[33,24]
 BV BND1      x[34,0] 
 BV BND1      x[34,1] 
 BV BND1      x[34,2] 
 BV BND1      x[34,3] 
 BV BND1      x[34,4] 
 BV BND1      x[34,5] 
 BV BND1      x[34,6] 
 BV BND1      x[34,7] 
 BV BND1      x[34,8] 
 BV BND1      x[34,9] 
 BV BND1      x[34,10]
 BV BND1      x[34,11]
 BV BND1      x[34,12]
 BV BND1      x[34,13]
 BV BND1      x[34,14]
 BV BND1      x[34,15]
 BV BND1      x[35,0] 
 BV BND1      x[35,1] 
 BV BND1      x[35,2] 
 BV BND1      x[35,3] 
 BV BND1      x[35,4] 
 BV BND1      x[35,5] 
 BV BND1      x[35,6] 
 BV BND1      x[35,7] 
 BV BND1      x[35,8] 
 BV BND1      x[35,9] 
 BV BND1      x[35,10]
 BV BND1      x[35,11]
 BV BND1      x[35,12]
 BV BND1      x[35,13]
 BV BND1      x[35,14]
 BV BND1      x[35,15]
 BV BND1      x[35,16]
 BV BND1      x[35,17]
 UP BND1      w[1,4]    3.9535535354550462e-02
 UP BND1      w[2,0]    3.9535535354550462e-02
 UP BND1      w[2,1]    3.9535535354550462e-02
 UP BND1      w[2,2]    3.9535535354550462e-02
 UP BND1      w[2,3]    3.9535535354550462e-02
 UP BND1      w[2,4]    3.9535535354550462e-02
 UP BND1      w[2,5]    3.9535535354550462e-02
 UP BND1      w[2,6]    3.9535535354550462e-02
 UP BND1      w[2,7]    3.9535535354550462e-02
 UP BND1      w[2,8]    3.9535535354550462e-02
 UP BND1      w[2,9]    3.9535535354550462e-02
 UP BND1      w[2,10]   3.9535535354550462e-02
 UP BND1      w[2,11]   3.9535535354550462e-02
 UP BND1      w[2,12]   3.9535535354550462e-02
 UP BND1      w[2,13]   3.9535535354550462e-02
 UP BND1      w[2,14]   3.9535535354550462e-02
 UP BND1      w[2,15]   3.9535535354550462e-02
 UP BND1      w[2,16]   3.9535535354550462e-02
 UP BND1      w[2,17]   3.9535535354550462e-02
 UP BND1      w[2,18]   3.9535535354550462e-02
 UP BND1      w[2,19]   3.9535535354550462e-02
 UP BND1      w[2,20]   3.9535535354550462e-02
 UP BND1      w[2,21]   3.9535535354550462e-02
 UP BND1      w[2,22]   3.9535535354550462e-02
 UP BND1      w[2,23]   3.9535535354550462e-02
 UP BND1      w[3,13]   3.9535535354550462e-02
 UP BND1      w[4,0]    3.9535535354550462e-02
 UP BND1      w[4,1]    3.9535535354550462e-02
 UP BND1      w[4,2]    3.9535535354550462e-02
 UP BND1      w[4,3]    3.9535535354550462e-02
 UP BND1      w[4,4]    3.9535535354550462e-02
 UP BND1      w[4,5]    3.9535535354550462e-02
 UP BND1      w[4,6]    3.9535535354550462e-02
 UP BND1      w[4,7]    3.9535535354550462e-02
 UP BND1      w[4,8]    3.9535535354550462e-02
 UP BND1      w[4,9]    3.9535535354550462e-02
 UP BND1      w[4,10]   3.9535535354550462e-02
 UP BND1      w[4,11]   3.9535535354550462e-02
 UP BND1      w[4,12]   3.9535535354550462e-02
 UP BND1      w[4,13]   3.9535535354550462e-02
 UP BND1      w[4,14]   3.9535535354550462e-02
 UP BND1      w[4,15]   3.9535535354550462e-02
 UP BND1      w[5,0]    3.9535535354550462e-02
 UP BND1      w[5,1]    3.9535535354550462e-02
 UP BND1      w[5,2]    3.9535535354550462e-02
 UP BND1      w[5,3]    3.9535535354550462e-02
 UP BND1      w[5,4]    3.9535535354550462e-02
 UP BND1      w[5,5]    3.9535535354550462e-02
 UP BND1      w[5,6]    3.9535535354550462e-02
 UP BND1      w[5,7]    3.9535535354550462e-02
 UP BND1      w[5,8]    3.9535535354550462e-02
 UP BND1      w[5,9]    3.9535535354550462e-02
 UP BND1      w[5,10]   3.9535535354550462e-02
 UP BND1      w[5,11]   3.9535535354550462e-02
 UP BND1      w[5,12]   3.9535535354550462e-02
 UP BND1      w[5,13]   3.9535535354550462e-02
 UP BND1      w[5,14]   3.9535535354550462e-02
 UP BND1      w[5,15]   3.9535535354550462e-02
 UP BND1      w[6,4]    3.9535535354550462e-02
 UP BND1      w[7,0]    3.9535535354550462e-02
 UP BND1      w[7,1]    3.9535535354550462e-02
 UP BND1      w[7,2]    3.9535535354550462e-02
 UP BND1      w[7,3]    3.9535535354550462e-02
 UP BND1      w[7,4]    3.9535535354550462e-02
 UP BND1      w[7,5]    3.9535535354550462e-02
 UP BND1      w[7,6]    3.9535535354550462e-02
 UP BND1      w[7,7]    3.9535535354550462e-02
 UP BND1      w[7,8]    3.9535535354550462e-02
 UP BND1      w[7,9]    3.9535535354550462e-02
 UP BND1      w[7,10]   3.9535535354550462e-02
 UP BND1      w[7,11]   3.9535535354550462e-02
 UP BND1      w[7,12]   3.9535535354550462e-02
 UP BND1      w[7,13]   3.9535535354550462e-02
 UP BND1      w[7,14]   3.9535535354550462e-02
 UP BND1      w[7,15]   3.9535535354550462e-02
 UP BND1      w[7,16]   3.9535535354550462e-02
 UP BND1      w[7,17]   3.9535535354550462e-02
 UP BND1      w[7,18]   3.9535535354550462e-02
 UP BND1      w[7,19]   3.9535535354550462e-02
 UP BND1      w[8,0]    3.9535535354550462e-02
 UP BND1      w[8,1]    3.9535535354550462e-02
 UP BND1      w[8,2]    3.9535535354550462e-02
 UP BND1      w[8,3]    3.9535535354550462e-02
 UP BND1      w[8,4]    3.9535535354550462e-02
 UP BND1      w[8,5]    3.9535535354550462e-02
 UP BND1      w[8,6]    3.9535535354550462e-02
 UP BND1      w[8,7]    3.9535535354550462e-02
 UP BND1      w[8,8]    3.9535535354550462e-02
 UP BND1      w[8,9]    3.9535535354550462e-02
 UP BND1      w[8,10]   3.9535535354550462e-02
 UP BND1      w[8,11]   3.9535535354550462e-02
 UP BND1      w[8,12]   3.9535535354550462e-02
 UP BND1      w[8,13]   3.9535535354550462e-02
 UP BND1      w[8,14]   3.9535535354550462e-02
 UP BND1      w[8,15]   3.9535535354550462e-02
 UP BND1      w[9,0]    3.9535535354550462e-02
 UP BND1      w[9,1]    3.9535535354550462e-02
 UP BND1      w[9,2]    3.9535535354550462e-02
 UP BND1      w[9,3]    3.9535535354550462e-02
 UP BND1      w[9,4]    3.9535535354550462e-02
 UP BND1      w[9,5]    3.9535535354550462e-02
 UP BND1      w[9,6]    3.9535535354550462e-02
 UP BND1      w[9,7]    3.9535535354550462e-02
 UP BND1      w[9,8]    3.9535535354550462e-02
 UP BND1      w[9,9]    3.9535535354550462e-02
 UP BND1      w[9,10]   3.9535535354550462e-02
 UP BND1      w[9,11]   3.9535535354550462e-02
 UP BND1      w[9,12]   3.9535535354550462e-02
 UP BND1      w[9,13]   3.9535535354550462e-02
 UP BND1      w[9,14]   3.9535535354550462e-02
 UP BND1      w[10,0]   3.9535535354550462e-02
 UP BND1      w[10,1]   3.9535535354550462e-02
 UP BND1      w[10,2]   3.9535535354550462e-02
 UP BND1      w[10,3]   3.9535535354550462e-02
 UP BND1      w[10,4]   3.9535535354550462e-02
 UP BND1      w[10,5]   3.9535535354550462e-02
 UP BND1      w[10,6]   3.9535535354550462e-02
 UP BND1      w[10,7]   3.9535535354550462e-02
 UP BND1      w[10,8]   3.9535535354550462e-02
 UP BND1      w[10,9]   3.9535535354550462e-02
 UP BND1      w[10,10]  3.9535535354550462e-02
 UP BND1      w[10,11]  3.9535535354550462e-02
 UP BND1      w[11,0]   3.9535535354550462e-02
 UP BND1      w[11,1]   3.9535535354550462e-02
 UP BND1      w[11,2]   3.9535535354550462e-02
 UP BND1      w[11,3]   3.9535535354550462e-02
 UP BND1      w[11,4]   3.9535535354550462e-02
 UP BND1      w[11,5]   3.9535535354550462e-02
 UP BND1      w[11,6]   3.9535535354550462e-02
 UP BND1      w[11,7]   3.9535535354550462e-02
 UP BND1      w[11,8]   3.9535535354550462e-02
 UP BND1      w[11,9]   3.9535535354550462e-02
 UP BND1      w[11,10]  3.9535535354550462e-02
 UP BND1      w[11,11]  3.9535535354550462e-02
 UP BND1      w[11,12]  3.9535535354550462e-02
 UP BND1      w[11,13]  3.9535535354550462e-02
 UP BND1      w[11,14]  3.9535535354550462e-02
 UP BND1      w[11,15]  3.9535535354550462e-02
 UP BND1      w[12,0]   3.9535535354550462e-02
 UP BND1      w[12,1]   3.9535535354550462e-02
 UP BND1      w[12,2]   3.9535535354550462e-02
 UP BND1      w[12,3]   3.9535535354550462e-02
 UP BND1      w[12,4]   3.9535535354550462e-02
 UP BND1      w[12,5]   3.9535535354550462e-02
 UP BND1      w[12,6]   3.9535535354550462e-02
 UP BND1      w[12,7]   3.9535535354550462e-02
 UP BND1      w[12,8]   3.9535535354550462e-02
 UP BND1      w[12,9]   3.9535535354550462e-02
 UP BND1      w[12,10]  3.9535535354550462e-02
 UP BND1      w[12,11]  3.9535535354550462e-02
 UP BND1      w[12,12]  3.9535535354550462e-02
 UP BND1      w[12,13]  3.9535535354550462e-02
 UP BND1      w[12,14]  3.9535535354550462e-02
 UP BND1      w[12,15]  3.9535535354550462e-02
 UP BND1      w[13,0]   3.9535535354550462e-02
 UP BND1      w[13,1]   3.9535535354550462e-02
 UP BND1      w[13,2]   3.9535535354550462e-02
 UP BND1      w[13,3]   3.9535535354550462e-02
 UP BND1      w[13,4]   3.9535535354550462e-02
 UP BND1      w[13,5]   3.9535535354550462e-02
 UP BND1      w[13,6]   3.9535535354550462e-02
 UP BND1      w[13,7]   3.9535535354550462e-02
 UP BND1      w[13,8]   3.9535535354550462e-02
 UP BND1      w[13,9]   3.9535535354550462e-02
 UP BND1      w[13,10]  3.9535535354550462e-02
 UP BND1      w[13,11]  3.9535535354550462e-02
 UP BND1      w[13,12]  3.9535535354550462e-02
 UP BND1      w[13,13]  3.9535535354550462e-02
 UP BND1      w[13,14]  3.9535535354550462e-02
 UP BND1      w[13,15]  3.9535535354550462e-02
 UP BND1      w[13,16]  3.9535535354550462e-02
 UP BND1      w[13,17]  3.9535535354550462e-02
 UP BND1      w[13,18]  3.9535535354550462e-02
 UP BND1      w[13,19]  3.9535535354550462e-02
 UP BND1      w[14,0]   3.9535535354550462e-02
 UP BND1      w[14,1]   3.9535535354550462e-02
 UP BND1      w[14,2]   3.9535535354550462e-02
 UP BND1      w[14,3]   3.9535535354550462e-02
 UP BND1      w[14,4]   3.9535535354550462e-02
 UP BND1      w[14,5]   3.9535535354550462e-02
 UP BND1      w[14,6]   3.9535535354550462e-02
 UP BND1      w[14,7]   3.9535535354550462e-02
 UP BND1      w[14,8]   3.9535535354550462e-02
 UP BND1      w[14,9]   3.9535535354550462e-02
 UP BND1      w[14,10]  3.9535535354550462e-02
 UP BND1      w[14,11]  3.9535535354550462e-02
 UP BND1      w[14,12]  3.9535535354550462e-02
 UP BND1      w[14,13]  3.9535535354550462e-02
 UP BND1      w[14,14]  3.9535535354550462e-02
 UP BND1      w[14,15]  3.9535535354550462e-02
 UP BND1      w[14,16]  3.9535535354550462e-02
 UP BND1      w[14,17]  3.9535535354550462e-02
 UP BND1      w[14,18]  3.9535535354550462e-02
 UP BND1      w[15,0]   3.9535535354550462e-02
 UP BND1      w[15,1]   3.9535535354550462e-02
 UP BND1      w[15,2]   3.9535535354550462e-02
 UP BND1      w[15,3]   3.9535535354550462e-02
 UP BND1      w[15,4]   3.9535535354550462e-02
 UP BND1      w[15,5]   3.9535535354550462e-02
 UP BND1      w[15,6]   3.9535535354550462e-02
 UP BND1      w[15,7]   3.9535535354550462e-02
 UP BND1      w[15,8]   3.9535535354550462e-02
 UP BND1      w[15,9]   3.9535535354550462e-02
 UP BND1      w[15,10]  3.9535535354550462e-02
 UP BND1      w[15,11]  3.9535535354550462e-02
 UP BND1      w[15,12]  3.9535535354550462e-02
 UP BND1      w[15,13]  3.9535535354550462e-02
 UP BND1      w[15,14]  3.9535535354550462e-02
 UP BND1      w[15,15]  3.9535535354550462e-02
 UP BND1      w[15,16]  3.9535535354550462e-02
 UP BND1      w[15,17]  3.9535535354550462e-02
 UP BND1      w[15,18]  3.9535535354550462e-02
 UP BND1      w[15,19]  3.9535535354550462e-02
 UP BND1      w[16,0]   3.9535535354550462e-02
 UP BND1      w[16,1]   3.9535535354550462e-02
 UP BND1      w[16,2]   3.9535535354550462e-02
 UP BND1      w[16,3]   3.9535535354550462e-02
 UP BND1      w[16,4]   3.9535535354550462e-02
 UP BND1      w[16,5]   3.9535535354550462e-02
 UP BND1      w[16,6]   3.9535535354550462e-02
 UP BND1      w[16,7]   3.9535535354550462e-02
 UP BND1      w[16,8]   3.9535535354550462e-02
 UP BND1      w[16,9]   3.9535535354550462e-02
 UP BND1      w[16,10]  3.9535535354550462e-02
 UP BND1      w[16,11]  3.9535535354550462e-02
 UP BND1      w[17,16]  3.9535535354550462e-02
 UP BND1      w[18,0]   3.9535535354550462e-02
 UP BND1      w[18,1]   3.9535535354550462e-02
 UP BND1      w[18,2]   3.9535535354550462e-02
 UP BND1      w[18,3]   3.9535535354550462e-02
 UP BND1      w[18,4]   3.9535535354550462e-02
 UP BND1      w[18,5]   3.9535535354550462e-02
 UP BND1      w[18,6]   3.9535535354550462e-02
 UP BND1      w[18,7]   3.9535535354550462e-02
 UP BND1      w[18,8]   3.9535535354550462e-02
 UP BND1      w[18,9]   3.9535535354550462e-02
 UP BND1      w[18,10]  3.9535535354550462e-02
 UP BND1      w[18,11]  3.9535535354550462e-02
 UP BND1      w[18,12]  3.9535535354550462e-02
 UP BND1      w[18,13]  3.9535535354550462e-02
 UP BND1      w[18,14]  3.9535535354550462e-02
 UP BND1      w[18,15]  3.9535535354550462e-02
 UP BND1      w[19,0]   3.9535535354550462e-02
 UP BND1      w[19,1]   3.9535535354550462e-02
 UP BND1      w[19,2]   3.9535535354550462e-02
 UP BND1      w[19,3]   3.9535535354550462e-02
 UP BND1      w[19,4]   3.9535535354550462e-02
 UP BND1      w[19,5]   3.9535535354550462e-02
 UP BND1      w[19,6]   3.9535535354550462e-02
 UP BND1      w[19,7]   3.9535535354550462e-02
 UP BND1      w[19,8]   3.9535535354550462e-02
 UP BND1      w[19,9]   3.9535535354550462e-02
 UP BND1      w[19,10]  3.9535535354550462e-02
 UP BND1      w[19,11]  3.9535535354550462e-02
 UP BND1      w[19,12]  3.9535535354550462e-02
 UP BND1      w[19,13]  3.9535535354550462e-02
 UP BND1      w[19,14]  3.9535535354550462e-02
 UP BND1      w[19,15]  3.9535535354550462e-02
 UP BND1      w[19,16]  3.9535535354550462e-02
 UP BND1      w[19,17]  3.9535535354550462e-02
 UP BND1      w[19,18]  3.9535535354550462e-02
 UP BND1      w[19,19]  3.9535535354550462e-02
 UP BND1      w[20,0]   3.9535535354550462e-02
 UP BND1      w[20,1]   3.9535535354550462e-02
 UP BND1      w[20,2]   3.9535535354550462e-02
 UP BND1      w[20,3]   3.9535535354550462e-02
 UP BND1      w[20,4]   3.9535535354550462e-02
 UP BND1      w[20,5]   3.9535535354550462e-02
 UP BND1      w[20,6]   3.9535535354550462e-02
 UP BND1      w[20,7]   3.9535535354550462e-02
 UP BND1      w[20,8]   3.9535535354550462e-02
 UP BND1      w[20,9]   3.9535535354550462e-02
 UP BND1      w[20,10]  3.9535535354550462e-02
 UP BND1      w[20,11]  3.9535535354550462e-02
 UP BND1      w[20,12]  3.9535535354550462e-02
 UP BND1      w[20,13]  3.9535535354550462e-02
 UP BND1      w[20,14]  3.9535535354550462e-02
 UP BND1      w[20,15]  3.9535535354550462e-02
 UP BND1      w[21,0]   3.9535535354550462e-02
 UP BND1      w[21,1]   3.9535535354550462e-02
 UP BND1      w[21,2]   3.9535535354550462e-02
 UP BND1      w[21,3]   3.9535535354550462e-02
 UP BND1      w[21,4]   3.9535535354550462e-02
 UP BND1      w[21,5]   3.9535535354550462e-02
 UP BND1      w[21,6]   3.9535535354550462e-02
 UP BND1      w[21,7]   3.9535535354550462e-02
 UP BND1      w[21,8]   3.9535535354550462e-02
 UP BND1      w[21,9]   3.9535535354550462e-02
 UP BND1      w[21,10]  3.9535535354550462e-02
 UP BND1      w[21,11]  3.9535535354550462e-02
 UP BND1      w[21,12]  3.9535535354550462e-02
 UP BND1      w[21,13]  3.9535535354550462e-02
 UP BND1      w[21,14]  3.9535535354550462e-02
 UP BND1      w[21,15]  3.9535535354550462e-02
 UP BND1      w[21,16]  3.9535535354550462e-02
 UP BND1      w[21,17]  3.9535535354550462e-02
 UP BND1      w[21,18]  3.9535535354550462e-02
 UP BND1      w[21,19]  3.9535535354550462e-02
 UP BND1      w[22,0]   3.9535535354550462e-02
 UP BND1      w[22,1]   3.9535535354550462e-02
 UP BND1      w[22,2]   3.9535535354550462e-02
 UP BND1      w[22,3]   3.9535535354550462e-02
 UP BND1      w[22,4]   3.9535535354550462e-02
 UP BND1      w[22,5]   3.9535535354550462e-02
 UP BND1      w[22,6]   3.9535535354550462e-02
 UP BND1      w[22,7]   3.9535535354550462e-02
 UP BND1      w[22,8]   3.9535535354550462e-02
 UP BND1      w[22,9]   3.9535535354550462e-02
 UP BND1      w[22,10]  3.9535535354550462e-02
 UP BND1      w[22,11]  3.9535535354550462e-02
 UP BND1      w[22,12]  3.9535535354550462e-02
 UP BND1      w[22,13]  3.9535535354550462e-02
 UP BND1      w[22,14]  3.9535535354550462e-02
 UP BND1      w[22,15]  3.9535535354550462e-02
 UP BND1      w[22,16]  3.9535535354550462e-02
 UP BND1      w[22,17]  3.9535535354550462e-02
 UP BND1      w[22,18]  3.9535535354550462e-02
 UP BND1      w[22,19]  3.9535535354550462e-02
 UP BND1      w[23,0]   3.9535535354550462e-02
 UP BND1      w[23,1]   3.9535535354550462e-02
 UP BND1      w[23,2]   3.9535535354550462e-02
 UP BND1      w[23,3]   3.9535535354550462e-02
 UP BND1      w[23,4]   3.9535535354550462e-02
 UP BND1      w[23,5]   3.9535535354550462e-02
 UP BND1      w[23,6]   3.9535535354550462e-02
 UP BND1      w[23,7]   3.9535535354550462e-02
 UP BND1      w[23,8]   3.9535535354550462e-02
 UP BND1      w[23,9]   3.9535535354550462e-02
 UP BND1      w[23,10]  3.9535535354550462e-02
 UP BND1      w[23,11]  3.9535535354550462e-02
 UP BND1      w[23,12]  3.9535535354550462e-02
 UP BND1      w[23,13]  3.9535535354550462e-02
 UP BND1      w[23,14]  3.9535535354550462e-02
 UP BND1      w[23,15]  3.9535535354550462e-02
 UP BND1      w[24,0]   3.9535535354550462e-02
 UP BND1      w[24,1]   3.9535535354550462e-02
 UP BND1      w[24,2]   3.9535535354550462e-02
 UP BND1      w[24,3]   3.9535535354550462e-02
 UP BND1      w[24,4]   3.9535535354550462e-02
 UP BND1      w[24,5]   3.9535535354550462e-02
 UP BND1      w[24,6]   3.9535535354550462e-02
 UP BND1      w[24,7]   3.9535535354550462e-02
 UP BND1      w[24,8]   3.9535535354550462e-02
 UP BND1      w[25,0]   3.9535535354550462e-02
 UP BND1      w[25,1]   3.9535535354550462e-02
 UP BND1      w[25,2]   3.9535535354550462e-02
 UP BND1      w[25,3]   3.9535535354550462e-02
 UP BND1      w[25,4]   3.9535535354550462e-02
 UP BND1      w[25,5]   3.9535535354550462e-02
 UP BND1      w[25,6]   3.9535535354550462e-02
 UP BND1      w[25,7]   3.9535535354550462e-02
 UP BND1      w[25,8]   3.9535535354550462e-02
 UP BND1      w[25,9]   3.9535535354550462e-02
 UP BND1      w[25,10]  3.9535535354550462e-02
 UP BND1      w[25,11]  3.9535535354550462e-02
 UP BND1      w[25,12]  3.9535535354550462e-02
 UP BND1      w[25,13]  3.9535535354550462e-02
 UP BND1      w[25,14]  3.9535535354550462e-02
 UP BND1      w[25,15]  3.9535535354550462e-02
 UP BND1      w[26,0]   3.9535535354550462e-02
 UP BND1      w[26,1]   3.9535535354550462e-02
 UP BND1      w[26,2]   3.9535535354550462e-02
 UP BND1      w[26,3]   3.9535535354550462e-02
 UP BND1      w[26,4]   3.9535535354550462e-02
 UP BND1      w[26,5]   3.9535535354550462e-02
 UP BND1      w[26,6]   3.9535535354550462e-02
 UP BND1      w[26,7]   3.9535535354550462e-02
 UP BND1      w[26,8]   3.9535535354550462e-02
 UP BND1      w[26,9]   3.9535535354550462e-02
 UP BND1      w[26,10]  3.9535535354550462e-02
 UP BND1      w[26,11]  3.9535535354550462e-02
 UP BND1      w[26,12]  3.9535535354550462e-02
 UP BND1      w[26,13]  3.9535535354550462e-02
 UP BND1      w[26,14]  3.9535535354550462e-02
 UP BND1      w[26,15]  3.9535535354550462e-02
 UP BND1      w[27,0]   3.9535535354550462e-02
 UP BND1      w[27,1]   3.9535535354550462e-02
 UP BND1      w[27,2]   3.9535535354550462e-02
 UP BND1      w[27,3]   3.9535535354550462e-02
 UP BND1      w[27,4]   3.9535535354550462e-02
 UP BND1      w[27,5]   3.9535535354550462e-02
 UP BND1      w[27,6]   3.9535535354550462e-02
 UP BND1      w[27,7]   3.9535535354550462e-02
 UP BND1      w[27,8]   3.9535535354550462e-02
 UP BND1      w[27,9]   3.9535535354550462e-02
 UP BND1      w[27,10]  3.9535535354550462e-02
 UP BND1      w[27,11]  3.9535535354550462e-02
 UP BND1      w[27,12]  3.9535535354550462e-02
 UP BND1      w[27,13]  3.9535535354550462e-02
 UP BND1      w[27,14]  3.9535535354550462e-02
 UP BND1      w[27,15]  3.9535535354550462e-02
 UP BND1      w[27,16]  3.9535535354550462e-02
 UP BND1      w[27,17]  3.9535535354550462e-02
 UP BND1      w[27,18]  3.9535535354550462e-02
 UP BND1      w[27,19]  3.9535535354550462e-02
 UP BND1      w[28,0]   3.9535535354550462e-02
 UP BND1      w[28,1]   3.9535535354550462e-02
 UP BND1      w[28,2]   3.9535535354550462e-02
 UP BND1      w[28,3]   3.9535535354550462e-02
 UP BND1      w[28,4]   3.9535535354550462e-02
 UP BND1      w[28,5]   3.9535535354550462e-02
 UP BND1      w[28,6]   3.9535535354550462e-02
 UP BND1      w[28,7]   3.9535535354550462e-02
 UP BND1      w[28,8]   3.9535535354550462e-02
 UP BND1      w[28,9]   3.9535535354550462e-02
 UP BND1      w[28,10]  3.9535535354550462e-02
 UP BND1      w[28,11]  3.9535535354550462e-02
 UP BND1      w[28,12]  3.9535535354550462e-02
 UP BND1      w[28,13]  3.9535535354550462e-02
 UP BND1      w[28,14]  3.9535535354550462e-02
 UP BND1      w[28,15]  3.9535535354550462e-02
 UP BND1      w[29,0]   3.9535535354550462e-02
 UP BND1      w[29,1]   3.9535535354550462e-02
 UP BND1      w[29,2]   3.9535535354550462e-02
 UP BND1      w[29,3]   3.9535535354550462e-02
 UP BND1      w[29,4]   3.9535535354550462e-02
 UP BND1      w[29,5]   3.9535535354550462e-02
 UP BND1      w[29,6]   3.9535535354550462e-02
 UP BND1      w[29,7]   3.9535535354550462e-02
 UP BND1      w[29,8]   3.9535535354550462e-02
 UP BND1      w[29,9]   3.9535535354550462e-02
 UP BND1      w[29,10]  3.9535535354550462e-02
 UP BND1      w[29,11]  3.9535535354550462e-02
 UP BND1      w[29,12]  3.9535535354550462e-02
 UP BND1      w[29,13]  3.9535535354550462e-02
 UP BND1      w[29,14]  3.9535535354550462e-02
 UP BND1      w[29,15]  3.9535535354550462e-02
 UP BND1      w[30,0]   3.9535535354550462e-02
 UP BND1      w[30,1]   3.9535535354550462e-02
 UP BND1      w[30,2]   3.9535535354550462e-02
 UP BND1      w[30,3]   3.9535535354550462e-02
 UP BND1      w[30,4]   3.9535535354550462e-02
 UP BND1      w[30,5]   3.9535535354550462e-02
 UP BND1      w[30,6]   3.9535535354550462e-02
 UP BND1      w[30,7]   3.9535535354550462e-02
 UP BND1      w[30,8]   3.9535535354550462e-02
 UP BND1      w[30,9]   3.9535535354550462e-02
 UP BND1      w[30,10]  3.9535535354550462e-02
 UP BND1      w[30,11]  3.9535535354550462e-02
 UP BND1      w[30,12]  3.9535535354550462e-02
 UP BND1      w[30,13]  3.9535535354550462e-02
 UP BND1      w[30,14]  3.9535535354550462e-02
 UP BND1      w[30,15]  3.9535535354550462e-02
 UP BND1      w[30,16]  3.9535535354550462e-02
 UP BND1      w[30,17]  3.9535535354550462e-02
 UP BND1      w[30,18]  3.9535535354550462e-02
 UP BND1      w[30,19]  3.9535535354550462e-02
 UP BND1      w[30,20]  3.9535535354550462e-02
 UP BND1      w[31,0]   3.9535535354550462e-02
 UP BND1      w[31,1]   3.9535535354550462e-02
 UP BND1      w[31,2]   3.9535535354550462e-02
 UP BND1      w[31,3]   3.9535535354550462e-02
 UP BND1      w[31,4]   3.9535535354550462e-02
 UP BND1      w[31,5]   3.9535535354550462e-02
 UP BND1      w[31,6]   3.9535535354550462e-02
 UP BND1      w[31,7]   3.9535535354550462e-02
 UP BND1      w[31,8]   3.9535535354550462e-02
 UP BND1      w[31,9]   3.9535535354550462e-02
 UP BND1      w[31,10]  3.9535535354550462e-02
 UP BND1      w[31,11]  3.9535535354550462e-02
 UP BND1      w[31,12]  3.9535535354550462e-02
 UP BND1      w[31,13]  3.9535535354550462e-02
 UP BND1      w[31,14]  3.9535535354550462e-02
 UP BND1      w[31,15]  3.9535535354550462e-02
 UP BND1      w[32,0]   3.9535535354550462e-02
 UP BND1      w[32,1]   3.9535535354550462e-02
 UP BND1      w[32,2]   3.9535535354550462e-02
 UP BND1      w[32,3]   3.9535535354550462e-02
 UP BND1      w[32,4]   3.9535535354550462e-02
 UP BND1      w[32,5]   3.9535535354550462e-02
 UP BND1      w[32,6]   3.9535535354550462e-02
 UP BND1      w[32,7]   3.9535535354550462e-02
 UP BND1      w[32,8]   3.9535535354550462e-02
 UP BND1      w[32,9]   3.9535535354550462e-02
 UP BND1      w[32,10]  3.9535535354550462e-02
 UP BND1      w[32,11]  3.9535535354550462e-02
 UP BND1      w[32,12]  3.9535535354550462e-02
 UP BND1      w[32,13]  3.9535535354550462e-02
 UP BND1      w[32,14]  3.9535535354550462e-02
 UP BND1      w[32,15]  3.9535535354550462e-02
 UP BND1      w[33,0]   3.9535535354550462e-02
 UP BND1      w[33,1]   3.9535535354550462e-02
 UP BND1      w[33,2]   3.9535535354550462e-02
 UP BND1      w[33,3]   3.9535535354550462e-02
 UP BND1      w[33,4]   3.9535535354550462e-02
 UP BND1      w[33,5]   3.9535535354550462e-02
 UP BND1      w[33,6]   3.9535535354550462e-02
 UP BND1      w[33,7]   3.9535535354550462e-02
 UP BND1      w[33,8]   3.9535535354550462e-02
 UP BND1      w[33,9]   3.9535535354550462e-02
 UP BND1      w[33,10]  3.9535535354550462e-02
 UP BND1      w[33,11]  3.9535535354550462e-02
 UP BND1      w[33,12]  3.9535535354550462e-02
 UP BND1      w[33,13]  3.9535535354550462e-02
 UP BND1      w[33,14]  3.9535535354550462e-02
 UP BND1      w[33,15]  3.9535535354550462e-02
 UP BND1      w[33,16]  3.9535535354550462e-02
 UP BND1      w[33,17]  3.9535535354550462e-02
 UP BND1      w[33,18]  3.9535535354550462e-02
 UP BND1      w[33,19]  3.9535535354550462e-02
 UP BND1      w[33,20]  3.9535535354550462e-02
 UP BND1      w[33,21]  3.9535535354550462e-02
 UP BND1      w[33,22]  3.9535535354550462e-02
 UP BND1      w[33,23]  3.9535535354550462e-02
 UP BND1      w[33,24]  3.9535535354550462e-02
 UP BND1      w[34,0]   3.9535535354550462e-02
 UP BND1      w[34,1]   3.9535535354550462e-02
 UP BND1      w[34,2]   3.9535535354550462e-02
 UP BND1      w[34,3]   3.9535535354550462e-02
 UP BND1      w[34,4]   3.9535535354550462e-02
 UP BND1      w[34,5]   3.9535535354550462e-02
 UP BND1      w[34,6]   3.9535535354550462e-02
 UP BND1      w[34,7]   3.9535535354550462e-02
 UP BND1      w[34,8]   3.9535535354550462e-02
 UP BND1      w[34,9]   3.9535535354550462e-02
 UP BND1      w[34,10]  3.9535535354550462e-02
 UP BND1      w[34,11]  3.9535535354550462e-02
 UP BND1      w[34,12]  3.9535535354550462e-02
 UP BND1      w[34,13]  3.9535535354550462e-02
 UP BND1      w[34,14]  3.9535535354550462e-02
 UP BND1      w[34,15]  3.9535535354550462e-02
 UP BND1      w[35,0]   3.9535535354550462e-02
 UP BND1      w[35,1]   3.9535535354550462e-02
 UP BND1      w[35,2]   3.9535535354550462e-02
 UP BND1      w[35,3]   3.9535535354550462e-02
 UP BND1      w[35,4]   3.9535535354550462e-02
 UP BND1      w[35,5]   3.9535535354550462e-02
 UP BND1      w[35,6]   3.9535535354550462e-02
 UP BND1      w[35,7]   3.9535535354550462e-02
 UP BND1      w[35,8]   3.9535535354550462e-02
 UP BND1      w[35,9]   3.9535535354550462e-02
 UP BND1      w[35,10]  3.9535535354550462e-02
 UP BND1      w[35,11]  3.9535535354550462e-02
 UP BND1      w[35,12]  3.9535535354550462e-02
 UP BND1      w[35,13]  3.9535535354550462e-02
 UP BND1      w[35,14]  3.9535535354550462e-02
 UP BND1      w[35,15]  3.9535535354550462e-02
 UP BND1      w[35,16]  3.9535535354550462e-02
 UP BND1      w[35,17]  3.9535535354550462e-02
 LO BND1      t         2.2258731252318614e-02
 UP BND1      t         3.9535535354550462e-02
ENDATA
