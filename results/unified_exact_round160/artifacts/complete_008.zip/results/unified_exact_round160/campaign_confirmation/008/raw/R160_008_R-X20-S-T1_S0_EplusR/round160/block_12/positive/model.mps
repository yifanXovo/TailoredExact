* Signature: 0x77c1ee6e3cbebed4
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_4_32
 E  normalized_mass_4_33
 E  normalized_ratio_4_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 E  onehot_5_41
 E  normalized_mass_5_42
 E  normalized_ratio_5_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 E  onehot_18_76
 E  normalized_mass_18_77
 E  normalized_ratio_18_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 E  onehot_8_85
 E  normalized_mass_8_86
 E  normalized_ratio_8_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 E  onehot_17_122
 E  normalized_mass_17_123
 E  normalized_ratio_17_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 E  onehot_3_159
 E  normalized_mass_3_160
 E  normalized_ratio_3_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 E  onehot_11_194
 E  normalized_mass_11_195
 E  normalized_ratio_11_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 E  onehot_2_201
 E  normalized_mass_2_202
 E  normalized_ratio_2_203
 G  stock_lb_204
 L  stock_ub_205
 L  parent_nonstrict_scope_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 E  normalization_263
 G  full_original_Gini_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 L  arc_capacity_347
 L  arc_capacity_348
 L  arc_capacity_349
 L  arc_capacity_350
 L  arc_capacity_351
 L  arc_capacity_352
 L  arc_capacity_353
 L  arc_capacity_354
 L  arc_capacity_355
 L  arc_capacity_356
 L  arc_capacity_357
 L  arc_capacity_358
 L  arc_capacity_359
 L  arc_capacity_360
 L  arc_capacity_361
 L  arc_capacity_362
 L  arc_capacity_363
 G  connected_order_arc_364
 L  arc_capacity_365
 G  connected_order_arc_366
 L  arc_capacity_367
 G  connected_order_arc_368
 L  arc_capacity_369
 G  connected_order_arc_370
 L  arc_capacity_371
 G  connected_order_arc_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 E  depot_departure_or_bypass_740
 E  depot_return_or_bypass_741
 E  out_degree_742
 E  in_degree_743
 G  order_active_lb_744
 L  order_active_ub_745
 E  segment_load_conservation_746
 G  segment_prefix_lb_747
 L  segment_prefix_ub_748
 E  out_degree_749
 E  in_degree_750
 G  order_active_lb_751
 L  order_active_ub_752
 E  segment_load_conservation_753
 G  segment_prefix_lb_754
 L  segment_prefix_ub_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  segment_load_conservation_760
 G  segment_prefix_lb_761
 L  segment_prefix_ub_762
 E  out_degree_763
 E  in_degree_764
 G  order_active_lb_765
 L  order_active_ub_766
 E  segment_load_conservation_767
 G  segment_prefix_lb_768
 L  segment_prefix_ub_769
 E  out_degree_770
 E  in_degree_771
 G  order_active_lb_772
 L  order_active_ub_773
 E  segment_load_conservation_774
 G  segment_prefix_lb_775
 L  segment_prefix_ub_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  segment_load_conservation_781
 G  segment_prefix_lb_782
 L  segment_prefix_ub_783
 E  out_degree_784
 E  in_degree_785
 G  order_active_lb_786
 L  order_active_ub_787
 E  service_visit_def_788
 E  free_load_conservation_789
 E  out_degree_790
 E  in_degree_791
 G  order_active_lb_792
 L  order_active_ub_793
 E  service_visit_def_794
 E  free_load_conservation_795
 E  out_degree_796
 E  in_degree_797
 G  order_active_lb_798
 L  order_active_ub_799
 E  service_visit_def_800
 E  free_load_conservation_801
 E  out_degree_802
 E  in_degree_803
 G  order_active_lb_804
 L  order_active_ub_805
 E  service_visit_def_806
 E  free_load_conservation_807
 E  out_degree_808
 E  in_degree_809
 G  order_active_lb_810
 L  order_active_ub_811
 E  service_visit_def_812
 E  free_load_conservation_813
 E  out_degree_814
 E  in_degree_815
 G  order_active_lb_816
 L  order_active_ub_817
 E  service_visit_def_818
 E  free_load_conservation_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  service_visit_def_824
 E  free_load_conservation_825
 E  out_degree_826
 E  in_degree_827
 G  order_active_lb_828
 L  order_active_ub_829
 E  service_visit_def_830
 E  free_load_conservation_831
 G  fixed_segment_relative_order_832
 G  fixed_segment_relative_order_833
 G  fixed_segment_relative_order_834
 G  fixed_segment_relative_order_835
 G  fixed_segment_relative_order_836
 L  original_T_including_depot_unload_837
 L  arc_capacity_838
 L  arc_capacity_839
 L  arc_capacity_840
 L  arc_capacity_841
 L  arc_capacity_842
 L  arc_capacity_843
 L  arc_capacity_844
 L  arc_capacity_845
 L  arc_capacity_846
 L  arc_capacity_847
 L  arc_capacity_848
 L  arc_capacity_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 E  depot_departure_or_bypass_1039
 E  depot_return_or_bypass_1040
 E  out_degree_1041
 E  in_degree_1042
 G  order_active_lb_1043
 L  order_active_ub_1044
 E  segment_load_conservation_1045
 G  segment_prefix_lb_1046
 L  segment_prefix_ub_1047
 E  out_degree_1048
 E  in_degree_1049
 G  order_active_lb_1050
 L  order_active_ub_1051
 E  segment_load_conservation_1052
 G  segment_prefix_lb_1053
 L  segment_prefix_ub_1054
 E  out_degree_1055
 E  in_degree_1056
 G  order_active_lb_1057
 L  order_active_ub_1058
 E  service_visit_def_1059
 E  free_load_conservation_1060
 E  out_degree_1061
 E  in_degree_1062
 G  order_active_lb_1063
 L  order_active_ub_1064
 E  service_visit_def_1065
 E  free_load_conservation_1066
 E  out_degree_1067
 E  in_degree_1068
 G  order_active_lb_1069
 L  order_active_ub_1070
 E  service_visit_def_1071
 E  free_load_conservation_1072
 E  out_degree_1073
 E  in_degree_1074
 G  order_active_lb_1075
 L  order_active_ub_1076
 E  service_visit_def_1077
 E  free_load_conservation_1078
 E  out_degree_1079
 E  in_degree_1080
 G  order_active_lb_1081
 L  order_active_ub_1082
 E  service_visit_def_1083
 E  free_load_conservation_1084
 E  out_degree_1085
 E  in_degree_1086
 G  order_active_lb_1087
 L  order_active_ub_1088
 E  service_visit_def_1089
 E  free_load_conservation_1090
 E  out_degree_1091
 E  in_degree_1092
 G  order_active_lb_1093
 L  order_active_ub_1094
 E  service_visit_def_1095
 E  free_load_conservation_1096
 E  out_degree_1097
 E  in_degree_1098
 G  order_active_lb_1099
 L  order_active_ub_1100
 E  service_visit_def_1101
 E  free_load_conservation_1102
 G  fixed_segment_relative_order_1103
 L  original_T_including_depot_unload_1104
COLUMNS
    t         normalized_mass_4_33  -1
    t         normalized_mass_5_42  -1
    t         normalized_mass_18_77  -1
    t         normalized_mass_8_86  -1
    t         normalized_mass_17_123  -1
    t         normalized_mass_3_160  -1
    t         normalized_mass_11_195  -1
    t         normalized_mass_2_202  -1
    t         normalization_263  9.8714285714285719e+00
    t         full_original_Gini_264  -3.1785714285714278e+01
    q         OBJ       1
    q         parent_nonstrict_scope_206  1
    q         full_original_Gini_264  20
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       5.0078236648368350e-02
    x_4_0     product_lb_0  -4.0746370015805063e-02
    x_4_0     product_ub_1  -1.0130246020270624e-01
    x_4_0     onehot_4_32  1
    x_4_0     parent_nonstrict_scope_206  1.0015647329673670e-01
    x_4_0     unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_0  1
    w_4_0     product_ub_1  1
    w_4_0     normalized_mass_4_33  1
    w_4_0     full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       3.7558677486276261e-02
    x_4_1     product_lb_2  -4.0746370015805063e-02
    x_4_1     product_ub_3  -1.0130246020270624e-01
    x_4_1     onehot_4_32  1
    x_4_1     stock_lb_204  1
    x_4_1     stock_ub_205  1
    x_4_1     parent_nonstrict_scope_206  8.7636914134644611e-02
    x_4_1     unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_2  1
    w_4_1     product_ub_3  1
    w_4_1     normalized_mass_4_33  1
    w_4_1     normalized_ratio_4_34  -0.125
    w_4_1     full_original_Gini_264  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       2.5039118324184172e-02
    x_4_2     product_lb_4  -4.0746370015805063e-02
    x_4_2     product_ub_5  -1.0130246020270624e-01
    x_4_2     onehot_4_32  1
    x_4_2     stock_lb_204  2
    x_4_2     stock_ub_205  2
    x_4_2     parent_nonstrict_scope_206  7.5117354972552522e-02
    x_4_2     unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_4  1
    w_4_2     product_ub_5  1
    w_4_2     normalized_mass_4_33  1
    w_4_2     normalized_ratio_4_34  -0.25
    w_4_2     full_original_Gini_264  -7.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_3     OBJ       1.2519559162092082e-02
    x_4_3     product_lb_6  -4.0746370015805063e-02
    x_4_3     product_ub_7  -1.0130246020270624e-01
    x_4_3     onehot_4_32  1
    x_4_3     stock_lb_204  3
    x_4_3     stock_ub_205  3
    x_4_3     parent_nonstrict_scope_206  6.2597795810460433e-02
    x_4_3     unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_6  1
    w_4_3     product_ub_7  1
    w_4_3     normalized_mass_4_33  1
    w_4_3     normalized_ratio_4_34  -0.375
    w_4_3     full_original_Gini_264  -6.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_4     product_lb_8  -4.0746370015805063e-02
    x_4_4     product_ub_9  -1.0130246020270624e-01
    x_4_4     onehot_4_32  1
    x_4_4     stock_lb_204  4
    x_4_4     stock_ub_205  4
    x_4_4     parent_nonstrict_scope_206  5.0078236648368350e-02
    x_4_4     unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_8  1
    w_4_4     product_ub_9  1
    w_4_4     normalized_mass_4_33  1
    w_4_4     normalized_ratio_4_34  -0.5
    w_4_4     full_original_Gini_264  -6.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -1.2519559162092089e-02
    x_4_5     product_lb_10  -4.0746370015805063e-02
    x_4_5     product_ub_11  -1.0130246020270624e-01
    x_4_5     onehot_4_32  1
    x_4_5     stock_lb_204  5
    x_4_5     stock_ub_205  5
    x_4_5     parent_nonstrict_scope_206  3.7558677486276261e-02
    x_4_5     unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_10  1
    w_4_5     product_ub_11  1
    w_4_5     normalized_mass_4_33  1
    w_4_5     normalized_ratio_4_34  -0.625
    w_4_5     full_original_Gini_264  -5.2642857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -2.5039118324184175e-02
    x_4_6     product_lb_12  -4.0746370015805063e-02
    x_4_6     product_ub_13  -1.0130246020270624e-01
    x_4_6     onehot_4_32  1
    x_4_6     stock_lb_204  6
    x_4_6     stock_ub_205  6
    x_4_6     parent_nonstrict_scope_206  2.5039118324184175e-02
    x_4_6     unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_12  1
    w_4_6     product_ub_13  1
    w_4_6     normalized_mass_4_33  1
    w_4_6     normalized_ratio_4_34  -0.75
    w_4_6     full_original_Gini_264  -4.5142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -3.7558677486276261e-02
    x_4_7     product_lb_14  -4.0746370015805063e-02
    x_4_7     product_ub_15  -1.0130246020270624e-01
    x_4_7     onehot_4_32  1
    x_4_7     stock_lb_204  7
    x_4_7     stock_ub_205  7
    x_4_7     parent_nonstrict_scope_206  1.2519559162092088e-02
    x_4_7     unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_14  1
    w_4_7     product_ub_15  1
    w_4_7     normalized_mass_4_33  1
    w_4_7     normalized_ratio_4_34  -0.875
    w_4_7     full_original_Gini_264  -3.9142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -5.0078236648368350e-02
    x_4_8     product_lb_16  -4.0746370015805063e-02
    x_4_8     product_ub_17  -1.0130246020270624e-01
    x_4_8     onehot_4_32  1
    x_4_8     stock_lb_204  8
    x_4_8     stock_ub_205  8
    x_4_8     unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_16  1
    w_4_8     product_ub_17  1
    w_4_8     normalized_mass_4_33  1
    w_4_8     normalized_ratio_4_34  -1
    w_4_8     full_original_Gini_264  -3.4142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -3.7558677486276261e-02
    x_4_9     product_lb_18  -4.0746370015805063e-02
    x_4_9     product_ub_19  -1.0130246020270624e-01
    x_4_9     onehot_4_32  1
    x_4_9     stock_lb_204  9
    x_4_9     stock_ub_205  9
    x_4_9     parent_nonstrict_scope_206  1.2519559162092088e-02
    x_4_9     unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_18  1
    w_4_9     product_ub_19  1
    w_4_9     normalized_mass_4_33  1
    w_4_9     normalized_ratio_4_34  -1.125
    w_4_9     full_original_Gini_264  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -2.5039118324184175e-02
    x_4_10    product_lb_20  -4.0746370015805063e-02
    x_4_10    product_ub_21  -1.0130246020270624e-01
    x_4_10    onehot_4_32  1
    x_4_10    stock_lb_204  10
    x_4_10    stock_ub_205  10
    x_4_10    parent_nonstrict_scope_206  2.5039118324184175e-02
    x_4_10    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_20  1
    w_4_10    product_ub_21  1
    w_4_10    normalized_mass_4_33  1
    w_4_10    normalized_ratio_4_34  -1.25
    w_4_10    full_original_Gini_264  -5.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_11    OBJ       -1.2519559162092089e-02
    x_4_11    product_lb_22  -4.0746370015805063e-02
    x_4_11    product_ub_23  -1.0130246020270624e-01
    x_4_11    onehot_4_32  1
    x_4_11    stock_lb_204  11
    x_4_11    stock_ub_205  11
    x_4_11    parent_nonstrict_scope_206  3.7558677486276261e-02
    x_4_11    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_22  1
    w_4_11    product_ub_23  1
    w_4_11    normalized_mass_4_33  1
    w_4_11    normalized_ratio_4_34  -1.375
    w_4_11    full_original_Gini_264  -6.8785714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_12    product_lb_24  -4.0746370015805063e-02
    x_4_12    product_ub_25  -1.0130246020270624e-01
    x_4_12    onehot_4_32  1
    x_4_12    stock_lb_204  12
    x_4_12    stock_ub_205  12
    x_4_12    parent_nonstrict_scope_206  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_24  1
    w_4_12    product_ub_25  1
    w_4_12    normalized_mass_4_33  1
    w_4_12    normalized_ratio_4_34  -1.5
    w_4_12    full_original_Gini_264  -8.1285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       1.2519559162092082e-02
    x_4_13    product_lb_26  -4.0746370015805063e-02
    x_4_13    product_ub_27  -1.0130246020270624e-01
    x_4_13    onehot_4_32  1
    x_4_13    stock_lb_204  13
    x_4_13    stock_ub_205  13
    x_4_13    parent_nonstrict_scope_206  6.2597795810460433e-02
    x_4_13    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_26  1
    w_4_13    product_ub_27  1
    w_4_13    normalized_mass_4_33  1
    w_4_13    normalized_ratio_4_34  -1.625
    w_4_13    full_original_Gini_264  -9.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       2.5039118324184172e-02
    x_4_14    product_lb_28  -4.0746370015805063e-02
    x_4_14    product_ub_29  -1.0130246020270624e-01
    x_4_14    onehot_4_32  1
    x_4_14    stock_lb_204  14
    x_4_14    stock_ub_205  14
    x_4_14    parent_nonstrict_scope_206  7.5117354972552522e-02
    x_4_14    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_28  1
    w_4_14    product_ub_29  1
    w_4_14    normalized_mass_4_33  1
    w_4_14    normalized_ratio_4_34  -1.75
    w_4_14    full_original_Gini_264  -1.1128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       3.7558677486276261e-02
    x_4_15    product_lb_30  -4.0746370015805063e-02
    x_4_15    product_ub_31  -1.0130246020270624e-01
    x_4_15    onehot_4_32  1
    x_4_15    stock_lb_204  15
    x_4_15    stock_ub_205  15
    x_4_15    parent_nonstrict_scope_206  8.7636914134644611e-02
    x_4_15    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_30  1
    w_4_15    product_ub_31  1
    w_4_15    normalized_mass_4_33  1
    w_4_15    normalized_ratio_4_34  -1.875
    w_4_15    full_original_Gini_264  -1.2628571428571428e+01
    rho_4     normalized_ratio_4_34  1
    rho_4     block_pair_pos_211  -1
    rho_4     block_pair_neg_212  1
    rho_4     block_pair_pos_213  -1
    rho_4     block_pair_neg_214  1
    rho_4     block_pair_pos_215  -1
    rho_4     block_pair_neg_216  1
    rho_4     block_pair_pos_217  -1
    rho_4     block_pair_neg_218  1
    rho_4     block_pair_pos_219  -1
    rho_4     block_pair_neg_220  1
    rho_4     block_pair_pos_221  -1
    rho_4     block_pair_neg_222  1
    rho_4     block_pair_pos_223  -1
    rho_4     block_pair_neg_224  1
    rho_4     normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       6.3380304899829966e-03
    x_5_0     product_lb_35  -4.0746370015805063e-02
    x_5_0     product_ub_36  -1.0130246020270624e-01
    x_5_0     onehot_5_41  1
    x_5_0     parent_nonstrict_scope_206  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_35  1
    w_5_0     product_ub_36  1
    w_5_0     normalized_mass_5_42  1
    w_5_0     full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       -6.3380304899829966e-03
    x_5_1     product_lb_37  -4.0746370015805063e-02
    x_5_1     product_ub_38  -1.0130246020270624e-01
    x_5_1     onehot_5_41  1
    x_5_1     stock_lb_204  1
    x_5_1     stock_ub_205  1
    x_5_1     unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_37  1
    w_5_1     product_ub_38  1
    w_5_1     normalized_mass_5_42  1
    w_5_1     normalized_ratio_5_43  -1
    w_5_1     full_original_Gini_264  -3.4142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.3380304899829966e-03
    x_5_2     product_lb_39  -4.0746370015805063e-02
    x_5_2     product_ub_40  -1.0130246020270624e-01
    x_5_2     onehot_5_41  1
    x_5_2     stock_lb_204  2
    x_5_2     stock_ub_205  2
    x_5_2     parent_nonstrict_scope_206  1.2676060979965993e-02
    x_5_2     unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_39  1
    w_5_2     product_ub_40  1
    w_5_2     normalized_mass_5_42  1
    w_5_2     normalized_ratio_5_43  -2
    w_5_2     full_original_Gini_264  -1.4128571428571428e+01
    rho_5     normalized_ratio_5_43  1
    rho_5     block_pair_pos_215  1
    rho_5     block_pair_neg_216  -1
    rho_5     block_pair_pos_225  -1
    rho_5     block_pair_neg_226  1
    rho_5     block_pair_pos_227  -1
    rho_5     block_pair_neg_228  1
    rho_5     block_pair_pos_229  -1
    rho_5     block_pair_neg_230  1
    rho_5     block_pair_pos_231  -1
    rho_5     block_pair_neg_232  1
    rho_5     block_pair_pos_233  -1
    rho_5     block_pair_neg_234  1
    rho_5     block_pair_pos_235  -1
    rho_5     block_pair_neg_236  1
    rho_5     normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_44  -4.0746370015805063e-02
    x_18_0    product_ub_45  -1.0130246020270624e-01
    x_18_0    onehot_18_76  1
    x_18_0    parent_nonstrict_scope_206  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_44  1
    w_18_0    product_ub_45  1
    w_18_0    normalized_mass_18_77  1
    w_18_0    full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_46  -4.0746370015805063e-02
    x_18_1    product_ub_47  -1.0130246020270624e-01
    x_18_1    onehot_18_76  1
    x_18_1    stock_lb_204  1
    x_18_1    stock_ub_205  1
    x_18_1    parent_nonstrict_scope_206  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_46  1
    w_18_1    product_ub_47  1
    w_18_1    normalized_mass_18_77  1
    w_18_1    normalized_ratio_18_78  -1.4285714285714285e-01
    w_18_1    full_original_Gini_264  -8.72857142857143
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_48  -4.0746370015805063e-02
    x_18_2    product_ub_49  -1.0130246020270624e-01
    x_18_2    onehot_18_76  1
    x_18_2    stock_lb_204  2
    x_18_2    stock_ub_205  2
    x_18_2    parent_nonstrict_scope_206  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_48  1
    w_18_2    product_ub_49  1
    w_18_2    normalized_mass_18_77  1
    w_18_2    normalized_ratio_18_78  -2.8571428571428570e-01
    w_18_2    full_original_Gini_264  -7.5857142857142863e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_50  -4.0746370015805063e-02
    x_18_3    product_ub_51  -1.0130246020270624e-01
    x_18_3    onehot_18_76  1
    x_18_3    stock_lb_204  3
    x_18_3    stock_ub_205  3
    x_18_3    parent_nonstrict_scope_206  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_50  1
    w_18_3    product_ub_51  1
    w_18_3    normalized_mass_18_77  1
    w_18_3    normalized_ratio_18_78  -4.2857142857142855e-01
    w_18_3    full_original_Gini_264  -6.4428571428571422e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_52  -4.0746370015805063e-02
    x_18_4    product_ub_53  -1.0130246020270624e-01
    x_18_4    onehot_18_76  1
    x_18_4    stock_lb_204  4
    x_18_4    stock_ub_205  4
    x_18_4    parent_nonstrict_scope_206  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_52  1
    w_18_4    product_ub_53  1
    w_18_4    normalized_mass_18_77  1
    w_18_4    normalized_ratio_18_78  -5.7142857142857140e-01
    w_18_4    full_original_Gini_264  -5.5857142857142863e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_54  -4.0746370015805063e-02
    x_18_5    product_ub_55  -1.0130246020270624e-01
    x_18_5    onehot_18_76  1
    x_18_5    stock_lb_204  5
    x_18_5    stock_ub_205  5
    x_18_5    parent_nonstrict_scope_206  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_54  1
    w_18_5    product_ub_55  1
    w_18_5    normalized_mass_18_77  1
    w_18_5    normalized_ratio_18_78  -7.1428571428571419e-01
    w_18_5    full_original_Gini_264  -4.7285714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_56  -4.0746370015805063e-02
    x_18_6    product_ub_57  -1.0130246020270624e-01
    x_18_6    onehot_18_76  1
    x_18_6    stock_lb_204  6
    x_18_6    stock_ub_205  6
    x_18_6    parent_nonstrict_scope_206  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_56  1
    w_18_6    product_ub_57  1
    w_18_6    normalized_mass_18_77  1
    w_18_6    normalized_ratio_18_78  -8.5714285714285710e-01
    w_18_6    full_original_Gini_264  -3.9857142857142858e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_58  -4.0746370015805063e-02
    x_18_7    product_ub_59  -1.0130246020270624e-01
    x_18_7    onehot_18_76  1
    x_18_7    stock_lb_204  7
    x_18_7    stock_ub_205  7
    x_18_7    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_58  1
    w_18_7    product_ub_59  1
    w_18_7    normalized_mass_18_77  1
    w_18_7    normalized_ratio_18_78  -1
    w_18_7    full_original_Gini_264  -3.4142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_60  -4.0746370015805063e-02
    x_18_8    product_ub_61  -1.0130246020270624e-01
    x_18_8    onehot_18_76  1
    x_18_8    stock_lb_204  8
    x_18_8    stock_ub_205  8
    x_18_8    parent_nonstrict_scope_206  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_60  1
    w_18_8    product_ub_61  1
    w_18_8    normalized_mass_18_77  1
    w_18_8    normalized_ratio_18_78  -1.1428571428571428e+00
    w_18_8    full_original_Gini_264  -4.5571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_62  -4.0746370015805063e-02
    x_18_9    product_ub_63  -1.0130246020270624e-01
    x_18_9    onehot_18_76  1
    x_18_9    stock_lb_204  9
    x_18_9    stock_ub_205  9
    x_18_9    parent_nonstrict_scope_206  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_62  1
    w_18_9    product_ub_63  1
    w_18_9    normalized_mass_18_77  1
    w_18_9    normalized_ratio_18_78  -1.2857142857142856e+00
    w_18_9    full_original_Gini_264  -5.9857142857142849e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_64  -4.0746370015805063e-02
    x_18_10   product_ub_65  -1.0130246020270624e-01
    x_18_10   onehot_18_76  1
    x_18_10   stock_lb_204  10
    x_18_10   stock_ub_205  10
    x_18_10   parent_nonstrict_scope_206  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_64  1
    w_18_10   product_ub_65  1
    w_18_10   normalized_mass_18_77  1
    w_18_10   normalized_ratio_18_78  -1.4285714285714284e+00
    w_18_10   full_original_Gini_264  -7.4142857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_66  -4.0746370015805063e-02
    x_18_11   product_ub_67  -1.0130246020270624e-01
    x_18_11   onehot_18_76  1
    x_18_11   stock_lb_204  11
    x_18_11   stock_ub_205  11
    x_18_11   parent_nonstrict_scope_206  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_66  1
    w_18_11   product_ub_67  1
    w_18_11   normalized_mass_18_77  1
    w_18_11   normalized_ratio_18_78  -1.5714285714285714e+00
    w_18_11   full_original_Gini_264  -8.9857142857142840e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_68  -4.0746370015805063e-02
    x_18_12   product_ub_69  -1.0130246020270624e-01
    x_18_12   onehot_18_76  1
    x_18_12   stock_lb_204  12
    x_18_12   stock_ub_205  12
    x_18_12   parent_nonstrict_scope_206  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_68  1
    w_18_12   product_ub_69  1
    w_18_12   normalized_mass_18_77  1
    w_18_12   normalized_ratio_18_78  -1.7142857142857142e+00
    w_18_12   full_original_Gini_264  -1.0699999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_70  -4.0746370015805063e-02
    x_18_13   product_ub_71  -1.0130246020270624e-01
    x_18_13   onehot_18_76  1
    x_18_13   stock_lb_204  13
    x_18_13   stock_ub_205  13
    x_18_13   parent_nonstrict_scope_206  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_70  1
    w_18_13   product_ub_71  1
    w_18_13   normalized_mass_18_77  1
    w_18_13   normalized_ratio_18_78  -1.8571428571428570e+00
    w_18_13   full_original_Gini_264  -1.2414285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_72  -4.0746370015805063e-02
    x_18_14   product_ub_73  -1.0130246020270624e-01
    x_18_14   onehot_18_76  1
    x_18_14   stock_lb_204  14
    x_18_14   stock_ub_205  14
    x_18_14   parent_nonstrict_scope_206  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_72  1
    w_18_14   product_ub_73  1
    w_18_14   normalized_mass_18_77  1
    w_18_14   normalized_ratio_18_78  -2
    w_18_14   full_original_Gini_264  -1.4128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_74  -4.0746370015805063e-02
    x_18_15   product_ub_75  -1.0130246020270624e-01
    x_18_15   onehot_18_76  1
    x_18_15   stock_lb_204  15
    x_18_15   stock_ub_205  15
    x_18_15   parent_nonstrict_scope_206  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_74  1
    w_18_15   product_ub_75  1
    w_18_15   normalized_mass_18_77  1
    w_18_15   normalized_ratio_18_78  -2.1428571428571428e+00
    w_18_15   full_original_Gini_264  -1.5842857142857138e+01
    rho_18    normalized_ratio_18_78  1
    rho_18    block_pair_pos_223  1
    rho_18    block_pair_neg_224  -1
    rho_18    block_pair_pos_235  1
    rho_18    block_pair_neg_236  -1
    rho_18    block_pair_pos_253  -1
    rho_18    block_pair_neg_254  1
    rho_18    block_pair_pos_255  -1
    rho_18    block_pair_neg_256  1
    rho_18    block_pair_pos_257  -1
    rho_18    block_pair_neg_258  1
    rho_18    block_pair_pos_259  -1
    rho_18    block_pair_neg_260  1
    rho_18    block_pair_pos_261  -1
    rho_18    block_pair_neg_262  1
    rho_18    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       6.3380304899829966e-03
    x_8_0     product_lb_79  -4.0746370015805063e-02
    x_8_0     product_ub_80  -1.0130246020270624e-01
    x_8_0     onehot_8_85  1
    x_8_0     parent_nonstrict_scope_206  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_79  1
    w_8_0     product_ub_80  1
    w_8_0     normalized_mass_8_86  1
    w_8_0     full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       -6.3380304899829966e-03
    x_8_1     product_lb_81  -4.0746370015805063e-02
    x_8_1     product_ub_82  -1.0130246020270624e-01
    x_8_1     onehot_8_85  1
    x_8_1     stock_lb_204  1
    x_8_1     stock_ub_205  1
    x_8_1     unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_81  1
    w_8_1     product_ub_82  1
    w_8_1     normalized_mass_8_86  1
    w_8_1     normalized_ratio_8_87  -1
    w_8_1     full_original_Gini_264  -3.4142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       6.3380304899829966e-03
    x_8_2     product_lb_83  -4.0746370015805063e-02
    x_8_2     product_ub_84  -1.0130246020270624e-01
    x_8_2     onehot_8_85  1
    x_8_2     stock_lb_204  2
    x_8_2     stock_ub_205  2
    x_8_2     parent_nonstrict_scope_206  1.2676060979965993e-02
    x_8_2     unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_83  1
    w_8_2     product_ub_84  1
    w_8_2     normalized_mass_8_86  1
    w_8_2     normalized_ratio_8_87  -2
    w_8_2     full_original_Gini_264  -1.4128571428571428e+01
    rho_8     normalized_ratio_8_87  1
    rho_8     block_pair_pos_217  1
    rho_8     block_pair_neg_218  -1
    rho_8     block_pair_pos_229  1
    rho_8     block_pair_neg_230  -1
    rho_8     block_pair_pos_237  -1
    rho_8     block_pair_neg_238  1
    rho_8     block_pair_pos_239  -1
    rho_8     block_pair_neg_240  1
    rho_8     block_pair_pos_241  -1
    rho_8     block_pair_neg_242  1
    rho_8     block_pair_pos_243  -1
    rho_8     block_pair_neg_244  1
    rho_8     block_pair_pos_257  1
    rho_8     block_pair_neg_258  -1
    rho_8     normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_88  -4.0746370015805063e-02
    x_17_0    product_ub_89  -1.0130246020270624e-01
    x_17_0    onehot_17_122  1
    x_17_0    parent_nonstrict_scope_206  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_88  1
    w_17_0    product_ub_89  1
    w_17_0    normalized_mass_17_123  1
    w_17_0    full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_90  -4.0746370015805063e-02
    x_17_1    product_ub_91  -1.0130246020270624e-01
    x_17_1    onehot_17_122  1
    x_17_1    stock_lb_204  1
    x_17_1    stock_ub_205  1
    x_17_1    parent_nonstrict_scope_206  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_90  1
    w_17_1    product_ub_91  1
    w_17_1    normalized_mass_17_123  1
    w_17_1    normalized_ratio_17_124  -1.1111111111111110e-01
    w_17_1    full_original_Gini_264  -8.9825396825396826e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_92  -4.0746370015805063e-02
    x_17_2    product_ub_93  -1.0130246020270624e-01
    x_17_2    onehot_17_122  1
    x_17_2    stock_lb_204  2
    x_17_2    stock_ub_205  2
    x_17_2    parent_nonstrict_scope_206  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_92  1
    w_17_2    product_ub_93  1
    w_17_2    normalized_mass_17_123  1
    w_17_2    normalized_ratio_17_124  -2.2222222222222221e-01
    w_17_2    full_original_Gini_264  -8.0936507936507933e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_94  -4.0746370015805063e-02
    x_17_3    product_ub_95  -1.0130246020270624e-01
    x_17_3    onehot_17_122  1
    x_17_3    stock_lb_204  3
    x_17_3    stock_ub_205  3
    x_17_3    parent_nonstrict_scope_206  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_94  1
    w_17_3    product_ub_95  1
    w_17_3    normalized_mass_17_123  1
    w_17_3    normalized_ratio_17_124  -3.3333333333333331e-01
    w_17_3    full_original_Gini_264  -7.2047619047619058e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_96  -4.0746370015805063e-02
    x_17_4    product_ub_97  -1.0130246020270624e-01
    x_17_4    onehot_17_122  1
    x_17_4    stock_lb_204  4
    x_17_4    stock_ub_205  4
    x_17_4    parent_nonstrict_scope_206  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_96  1
    w_17_4    product_ub_97  1
    w_17_4    normalized_mass_17_123  1
    w_17_4    normalized_ratio_17_124  -4.4444444444444442e-01
    w_17_4    full_original_Gini_264  -6.3476190476190473e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_98  -4.0746370015805063e-02
    x_17_5    product_ub_99  -1.0130246020270624e-01
    x_17_5    onehot_17_122  1
    x_17_5    stock_lb_204  5
    x_17_5    stock_ub_205  5
    x_17_5    parent_nonstrict_scope_206  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_98  1
    w_17_5    product_ub_99  1
    w_17_5    normalized_mass_17_123  1
    w_17_5    normalized_ratio_17_124  -5.5555555555555558e-01
    w_17_5    full_original_Gini_264  -5.6809523809523812e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_100  -4.0746370015805063e-02
    x_17_6    product_ub_101  -1.0130246020270624e-01
    x_17_6    onehot_17_122  1
    x_17_6    stock_lb_204  6
    x_17_6    stock_ub_205  6
    x_17_6    parent_nonstrict_scope_206  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_100  1
    w_17_6    product_ub_101  1
    w_17_6    normalized_mass_17_123  1
    w_17_6    normalized_ratio_17_124  -6.6666666666666663e-01
    w_17_6    full_original_Gini_264  -5.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_102  -4.0746370015805063e-02
    x_17_7    product_ub_103  -1.0130246020270624e-01
    x_17_7    onehot_17_122  1
    x_17_7    stock_lb_204  7
    x_17_7    stock_ub_205  7
    x_17_7    parent_nonstrict_scope_206  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_102  1
    w_17_7    product_ub_103  1
    w_17_7    normalized_mass_17_123  1
    w_17_7    normalized_ratio_17_124  -7.7777777777777768e-01
    w_17_7    full_original_Gini_264  -4.3476190476190482e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_104  -4.0746370015805063e-02
    x_17_8    product_ub_105  -1.0130246020270624e-01
    x_17_8    onehot_17_122  1
    x_17_8    stock_lb_204  8
    x_17_8    stock_ub_205  8
    x_17_8    parent_nonstrict_scope_206  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_104  1
    w_17_8    product_ub_105  1
    w_17_8    normalized_mass_17_123  1
    w_17_8    normalized_ratio_17_124  -8.8888888888888884e-01
    w_17_8    full_original_Gini_264  -3.8587301587301588e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_106  -4.0746370015805063e-02
    x_17_9    product_ub_107  -1.0130246020270624e-01
    x_17_9    onehot_17_122  1
    x_17_9    stock_lb_204  9
    x_17_9    stock_ub_205  9
    x_17_9    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_106  1
    w_17_9    product_ub_107  1
    w_17_9    normalized_mass_17_123  1
    w_17_9    normalized_ratio_17_124  -1
    w_17_9    full_original_Gini_264  -3.4142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_108  -4.0746370015805063e-02
    x_17_10   product_ub_109  -1.0130246020270624e-01
    x_17_10   onehot_17_122  1
    x_17_10   stock_lb_204  10
    x_17_10   stock_ub_205  10
    x_17_10   parent_nonstrict_scope_206  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_108  1
    w_17_10   product_ub_109  1
    w_17_10   normalized_mass_17_123  1
    w_17_10   normalized_ratio_17_124  -1.1111111111111112e+00
    w_17_10   full_original_Gini_264  -4.3031746031746039e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_110  -4.0746370015805063e-02
    x_17_11   product_ub_111  -1.0130246020270624e-01
    x_17_11   onehot_17_122  1
    x_17_11   stock_lb_204  11
    x_17_11   stock_ub_205  11
    x_17_11   parent_nonstrict_scope_206  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_110  1
    w_17_11   product_ub_111  1
    w_17_11   normalized_mass_17_123  1
    w_17_11   normalized_ratio_17_124  -1.2222222222222221e+00
    w_17_11   full_original_Gini_264  -5.35079365079365
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_112  -4.0746370015805063e-02
    x_17_12   product_ub_113  -1.0130246020270624e-01
    x_17_12   onehot_17_122  1
    x_17_12   stock_lb_204  12
    x_17_12   stock_ub_205  12
    x_17_12   parent_nonstrict_scope_206  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_112  1
    w_17_12   product_ub_113  1
    w_17_12   normalized_mass_17_123  1
    w_17_12   normalized_ratio_17_124  -1.3333333333333333e+00
    w_17_12   full_original_Gini_264  -6.46190476190476
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_114  -4.0746370015805063e-02
    x_17_13   product_ub_115  -1.0130246020270624e-01
    x_17_13   onehot_17_122  1
    x_17_13   stock_lb_204  13
    x_17_13   stock_ub_205  13
    x_17_13   parent_nonstrict_scope_206  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_114  1
    w_17_13   product_ub_115  1
    w_17_13   normalized_mass_17_123  1
    w_17_13   normalized_ratio_17_124  -1.4444444444444444e+00
    w_17_13   full_original_Gini_264  -7.5730158730158736e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_116  -4.0746370015805063e-02
    x_17_14   product_ub_117  -1.0130246020270624e-01
    x_17_14   onehot_17_122  1
    x_17_14   stock_lb_204  14
    x_17_14   stock_ub_205  14
    x_17_14   parent_nonstrict_scope_206  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_116  1
    w_17_14   product_ub_117  1
    w_17_14   normalized_mass_17_123  1
    w_17_14   normalized_ratio_17_124  -1.5555555555555554e+00
    w_17_14   full_original_Gini_264  -8.7952380952380924e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_118  -4.0746370015805063e-02
    x_17_15   product_ub_119  -1.0130246020270624e-01
    x_17_15   onehot_17_122  1
    x_17_15   stock_lb_204  15
    x_17_15   stock_ub_205  15
    x_17_15   parent_nonstrict_scope_206  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_118  1
    w_17_15   product_ub_119  1
    w_17_15   normalized_mass_17_123  1
    w_17_15   normalized_ratio_17_124  -1.6666666666666665e+00
    w_17_15   full_original_Gini_264  -1.0128571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_120  -4.0746370015805063e-02
    x_17_16   product_ub_121  -1.0130246020270624e-01
    x_17_16   onehot_17_122  1
    x_17_16   stock_lb_204  16
    x_17_16   stock_ub_205  16
    x_17_16   parent_nonstrict_scope_206  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_120  1
    w_17_16   product_ub_121  1
    w_17_16   normalized_mass_17_123  1
    w_17_16   normalized_ratio_17_124  -1.7777777777777777e+00
    w_17_16   full_original_Gini_264  -1.1461904761904762e+01
    rho_17    normalized_ratio_17_124  1
    rho_17    block_pair_pos_221  1
    rho_17    block_pair_neg_222  -1
    rho_17    block_pair_pos_233  1
    rho_17    block_pair_neg_234  -1
    rho_17    block_pair_pos_243  1
    rho_17    block_pair_neg_244  -1
    rho_17    block_pair_pos_247  -1
    rho_17    block_pair_neg_248  1
    rho_17    block_pair_pos_249  -1
    rho_17    block_pair_neg_250  1
    rho_17    block_pair_pos_251  -1
    rho_17    block_pair_neg_252  1
    rho_17    block_pair_pos_261  1
    rho_17    block_pair_neg_262  -1
    rho_17    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       5.0078236648368350e-02
    x_3_0     product_lb_125  -4.0746370015805063e-02
    x_3_0     product_ub_126  -1.0130246020270624e-01
    x_3_0     onehot_3_159  1
    x_3_0     parent_nonstrict_scope_206  1.0015647329673670e-01
    x_3_0     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_125  1
    w_3_0     product_ub_126  1
    w_3_0     normalized_mass_3_160  1
    w_3_0     full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.7558677486276261e-02
    x_3_1     product_lb_127  -4.0746370015805063e-02
    x_3_1     product_ub_128  -1.0130246020270624e-01
    x_3_1     onehot_3_159  1
    x_3_1     stock_lb_204  1
    x_3_1     stock_ub_205  1
    x_3_1     parent_nonstrict_scope_206  8.7636914134644611e-02
    x_3_1     unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_127  1
    w_3_1     product_ub_128  1
    w_3_1     normalized_mass_3_160  1
    w_3_1     normalized_ratio_3_161  -0.125
    w_3_1     full_original_Gini_264  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       2.5039118324184172e-02
    x_3_2     product_lb_129  -4.0746370015805063e-02
    x_3_2     product_ub_130  -1.0130246020270624e-01
    x_3_2     onehot_3_159  1
    x_3_2     stock_lb_204  2
    x_3_2     stock_ub_205  2
    x_3_2     parent_nonstrict_scope_206  7.5117354972552522e-02
    x_3_2     unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_129  1
    w_3_2     product_ub_130  1
    w_3_2     normalized_mass_3_160  1
    w_3_2     normalized_ratio_3_161  -0.25
    w_3_2     full_original_Gini_264  -7.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       1.2519559162092082e-02
    x_3_3     product_lb_131  -4.0746370015805063e-02
    x_3_3     product_ub_132  -1.0130246020270624e-01
    x_3_3     onehot_3_159  1
    x_3_3     stock_lb_204  3
    x_3_3     stock_ub_205  3
    x_3_3     parent_nonstrict_scope_206  6.2597795810460433e-02
    x_3_3     unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_131  1
    w_3_3     product_ub_132  1
    w_3_3     normalized_mass_3_160  1
    w_3_3     normalized_ratio_3_161  -0.375
    w_3_3     full_original_Gini_264  -6.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_4     product_lb_133  -4.0746370015805063e-02
    x_3_4     product_ub_134  -1.0130246020270624e-01
    x_3_4     onehot_3_159  1
    x_3_4     stock_lb_204  4
    x_3_4     stock_ub_205  4
    x_3_4     parent_nonstrict_scope_206  5.0078236648368350e-02
    x_3_4     unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_133  1
    w_3_4     product_ub_134  1
    w_3_4     normalized_mass_3_160  1
    w_3_4     normalized_ratio_3_161  -0.5
    w_3_4     full_original_Gini_264  -6.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.2519559162092089e-02
    x_3_5     product_lb_135  -4.0746370015805063e-02
    x_3_5     product_ub_136  -1.0130246020270624e-01
    x_3_5     onehot_3_159  1
    x_3_5     stock_lb_204  5
    x_3_5     stock_ub_205  5
    x_3_5     parent_nonstrict_scope_206  3.7558677486276261e-02
    x_3_5     unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_135  1
    w_3_5     product_ub_136  1
    w_3_5     normalized_mass_3_160  1
    w_3_5     normalized_ratio_3_161  -0.625
    w_3_5     full_original_Gini_264  -5.2642857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -2.5039118324184175e-02
    x_3_6     product_lb_137  -4.0746370015805063e-02
    x_3_6     product_ub_138  -1.0130246020270624e-01
    x_3_6     onehot_3_159  1
    x_3_6     stock_lb_204  6
    x_3_6     stock_ub_205  6
    x_3_6     parent_nonstrict_scope_206  2.5039118324184175e-02
    x_3_6     unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_137  1
    w_3_6     product_ub_138  1
    w_3_6     normalized_mass_3_160  1
    w_3_6     normalized_ratio_3_161  -0.75
    w_3_6     full_original_Gini_264  -4.5142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -3.7558677486276261e-02
    x_3_7     product_lb_139  -4.0746370015805063e-02
    x_3_7     product_ub_140  -1.0130246020270624e-01
    x_3_7     onehot_3_159  1
    x_3_7     stock_lb_204  7
    x_3_7     stock_ub_205  7
    x_3_7     parent_nonstrict_scope_206  1.2519559162092088e-02
    x_3_7     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_139  1
    w_3_7     product_ub_140  1
    w_3_7     normalized_mass_3_160  1
    w_3_7     normalized_ratio_3_161  -0.875
    w_3_7     full_original_Gini_264  -3.9142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.0078236648368350e-02
    x_3_8     product_lb_141  -4.0746370015805063e-02
    x_3_8     product_ub_142  -1.0130246020270624e-01
    x_3_8     onehot_3_159  1
    x_3_8     stock_lb_204  8
    x_3_8     stock_ub_205  8
    x_3_8     unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_141  1
    w_3_8     product_ub_142  1
    w_3_8     normalized_mass_3_160  1
    w_3_8     normalized_ratio_3_161  -1
    w_3_8     full_original_Gini_264  -3.4142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -3.7558677486276261e-02
    x_3_9     product_lb_143  -4.0746370015805063e-02
    x_3_9     product_ub_144  -1.0130246020270624e-01
    x_3_9     onehot_3_159  1
    x_3_9     stock_lb_204  9
    x_3_9     stock_ub_205  9
    x_3_9     parent_nonstrict_scope_206  1.2519559162092088e-02
    x_3_9     unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_143  1
    w_3_9     product_ub_144  1
    w_3_9     normalized_mass_3_160  1
    w_3_9     normalized_ratio_3_161  -1.125
    w_3_9     full_original_Gini_264  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -2.5039118324184175e-02
    x_3_10    product_lb_145  -4.0746370015805063e-02
    x_3_10    product_ub_146  -1.0130246020270624e-01
    x_3_10    onehot_3_159  1
    x_3_10    stock_lb_204  10
    x_3_10    stock_ub_205  10
    x_3_10    parent_nonstrict_scope_206  2.5039118324184175e-02
    x_3_10    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_145  1
    w_3_10    product_ub_146  1
    w_3_10    normalized_mass_3_160  1
    w_3_10    normalized_ratio_3_161  -1.25
    w_3_10    full_original_Gini_264  -5.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.2519559162092089e-02
    x_3_11    product_lb_147  -4.0746370015805063e-02
    x_3_11    product_ub_148  -1.0130246020270624e-01
    x_3_11    onehot_3_159  1
    x_3_11    stock_lb_204  11
    x_3_11    stock_ub_205  11
    x_3_11    parent_nonstrict_scope_206  3.7558677486276261e-02
    x_3_11    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_147  1
    w_3_11    product_ub_148  1
    w_3_11    normalized_mass_3_160  1
    w_3_11    normalized_ratio_3_161  -1.375
    w_3_11    full_original_Gini_264  -6.8785714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_12    product_lb_149  -4.0746370015805063e-02
    x_3_12    product_ub_150  -1.0130246020270624e-01
    x_3_12    onehot_3_159  1
    x_3_12    stock_lb_204  12
    x_3_12    stock_ub_205  12
    x_3_12    parent_nonstrict_scope_206  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_149  1
    w_3_12    product_ub_150  1
    w_3_12    normalized_mass_3_160  1
    w_3_12    normalized_ratio_3_161  -1.5
    w_3_12    full_original_Gini_264  -8.1285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       1.2519559162092082e-02
    x_3_13    product_lb_151  -4.0746370015805063e-02
    x_3_13    product_ub_152  -1.0130246020270624e-01
    x_3_13    onehot_3_159  1
    x_3_13    stock_lb_204  13
    x_3_13    stock_ub_205  13
    x_3_13    parent_nonstrict_scope_206  6.2597795810460433e-02
    x_3_13    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_151  1
    w_3_13    product_ub_152  1
    w_3_13    normalized_mass_3_160  1
    w_3_13    normalized_ratio_3_161  -1.625
    w_3_13    full_original_Gini_264  -9.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       2.5039118324184172e-02
    x_3_14    product_lb_153  -4.0746370015805063e-02
    x_3_14    product_ub_154  -1.0130246020270624e-01
    x_3_14    onehot_3_159  1
    x_3_14    stock_lb_204  14
    x_3_14    stock_ub_205  14
    x_3_14    parent_nonstrict_scope_206  7.5117354972552522e-02
    x_3_14    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_153  1
    w_3_14    product_ub_154  1
    w_3_14    normalized_mass_3_160  1
    w_3_14    normalized_ratio_3_161  -1.75
    w_3_14    full_original_Gini_264  -1.1128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.7558677486276261e-02
    x_3_15    product_lb_155  -4.0746370015805063e-02
    x_3_15    product_ub_156  -1.0130246020270624e-01
    x_3_15    onehot_3_159  1
    x_3_15    stock_lb_204  15
    x_3_15    stock_ub_205  15
    x_3_15    parent_nonstrict_scope_206  8.7636914134644611e-02
    x_3_15    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_155  1
    w_3_15    product_ub_156  1
    w_3_15    normalized_mass_3_160  1
    w_3_15    normalized_ratio_3_161  -1.875
    w_3_15    full_original_Gini_264  -1.2628571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       5.0078236648368350e-02
    x_3_16    product_lb_157  -4.0746370015805063e-02
    x_3_16    product_ub_158  -1.0130246020270624e-01
    x_3_16    onehot_3_159  1
    x_3_16    stock_lb_204  16
    x_3_16    stock_ub_205  16
    x_3_16    parent_nonstrict_scope_206  1.0015647329673670e-01
    x_3_16    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_157  1
    w_3_16    product_ub_158  1
    w_3_16    normalized_mass_3_160  1
    w_3_16    normalized_ratio_3_161  -2
    w_3_16    full_original_Gini_264  -1.4128571428571428e+01
    rho_3     normalized_ratio_3_161  1
    rho_3     block_pair_pos_207  -1
    rho_3     block_pair_neg_208  1
    rho_3     block_pair_pos_209  -1
    rho_3     block_pair_neg_210  1
    rho_3     block_pair_pos_213  1
    rho_3     block_pair_neg_214  -1
    rho_3     block_pair_pos_227  1
    rho_3     block_pair_neg_228  -1
    rho_3     block_pair_pos_239  1
    rho_3     block_pair_neg_240  -1
    rho_3     block_pair_pos_249  1
    rho_3     block_pair_neg_250  -1
    rho_3     block_pair_pos_255  1
    rho_3     block_pair_neg_256  -1
    rho_3     normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_162  -4.0746370015805063e-02
    x_11_0    product_ub_163  -1.0130246020270624e-01
    x_11_0    onehot_11_194  1
    x_11_0    parent_nonstrict_scope_206  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_162  1
    w_11_0    product_ub_163  1
    w_11_0    normalized_mass_11_195  1
    w_11_0    full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_164  -4.0746370015805063e-02
    x_11_1    product_ub_165  -1.0130246020270624e-01
    x_11_1    onehot_11_194  1
    x_11_1    stock_lb_204  1
    x_11_1    stock_ub_205  1
    x_11_1    parent_nonstrict_scope_206  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_164  1
    w_11_1    product_ub_165  1
    w_11_1    normalized_mass_11_195  1
    w_11_1    normalized_ratio_11_196  -0.125
    w_11_1    full_original_Gini_264  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_166  -4.0746370015805063e-02
    x_11_2    product_ub_167  -1.0130246020270624e-01
    x_11_2    onehot_11_194  1
    x_11_2    stock_lb_204  2
    x_11_2    stock_ub_205  2
    x_11_2    parent_nonstrict_scope_206  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_166  1
    w_11_2    product_ub_167  1
    w_11_2    normalized_mass_11_195  1
    w_11_2    normalized_ratio_11_196  -0.25
    w_11_2    full_original_Gini_264  -7.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_168  -4.0746370015805063e-02
    x_11_3    product_ub_169  -1.0130246020270624e-01
    x_11_3    onehot_11_194  1
    x_11_3    stock_lb_204  3
    x_11_3    stock_ub_205  3
    x_11_3    parent_nonstrict_scope_206  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_168  1
    w_11_3    product_ub_169  1
    w_11_3    normalized_mass_11_195  1
    w_11_3    normalized_ratio_11_196  -0.375
    w_11_3    full_original_Gini_264  -6.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_170  -4.0746370015805063e-02
    x_11_4    product_ub_171  -1.0130246020270624e-01
    x_11_4    onehot_11_194  1
    x_11_4    stock_lb_204  4
    x_11_4    stock_ub_205  4
    x_11_4    parent_nonstrict_scope_206  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_170  1
    w_11_4    product_ub_171  1
    w_11_4    normalized_mass_11_195  1
    w_11_4    normalized_ratio_11_196  -0.5
    w_11_4    full_original_Gini_264  -6.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_172  -4.0746370015805063e-02
    x_11_5    product_ub_173  -1.0130246020270624e-01
    x_11_5    onehot_11_194  1
    x_11_5    stock_lb_204  5
    x_11_5    stock_ub_205  5
    x_11_5    parent_nonstrict_scope_206  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_172  1
    w_11_5    product_ub_173  1
    w_11_5    normalized_mass_11_195  1
    w_11_5    normalized_ratio_11_196  -0.625
    w_11_5    full_original_Gini_264  -5.2642857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_174  -4.0746370015805063e-02
    x_11_6    product_ub_175  -1.0130246020270624e-01
    x_11_6    onehot_11_194  1
    x_11_6    stock_lb_204  6
    x_11_6    stock_ub_205  6
    x_11_6    parent_nonstrict_scope_206  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_174  1
    w_11_6    product_ub_175  1
    w_11_6    normalized_mass_11_195  1
    w_11_6    normalized_ratio_11_196  -0.75
    w_11_6    full_original_Gini_264  -4.5142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_176  -4.0746370015805063e-02
    x_11_7    product_ub_177  -1.0130246020270624e-01
    x_11_7    onehot_11_194  1
    x_11_7    stock_lb_204  7
    x_11_7    stock_ub_205  7
    x_11_7    parent_nonstrict_scope_206  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_176  1
    w_11_7    product_ub_177  1
    w_11_7    normalized_mass_11_195  1
    w_11_7    normalized_ratio_11_196  -0.875
    w_11_7    full_original_Gini_264  -3.9142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_178  -4.0746370015805063e-02
    x_11_8    product_ub_179  -1.0130246020270624e-01
    x_11_8    onehot_11_194  1
    x_11_8    stock_lb_204  8
    x_11_8    stock_ub_205  8
    x_11_8    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_178  1
    w_11_8    product_ub_179  1
    w_11_8    normalized_mass_11_195  1
    w_11_8    normalized_ratio_11_196  -1
    w_11_8    full_original_Gini_264  -3.4142857142857141e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_180  -4.0746370015805063e-02
    x_11_9    product_ub_181  -1.0130246020270624e-01
    x_11_9    onehot_11_194  1
    x_11_9    stock_lb_204  9
    x_11_9    stock_ub_205  9
    x_11_9    parent_nonstrict_scope_206  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_180  1
    w_11_9    product_ub_181  1
    w_11_9    normalized_mass_11_195  1
    w_11_9    normalized_ratio_11_196  -1.125
    w_11_9    full_original_Gini_264  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_182  -4.0746370015805063e-02
    x_11_10   product_ub_183  -1.0130246020270624e-01
    x_11_10   onehot_11_194  1
    x_11_10   stock_lb_204  10
    x_11_10   stock_ub_205  10
    x_11_10   parent_nonstrict_scope_206  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_182  1
    w_11_10   product_ub_183  1
    w_11_10   normalized_mass_11_195  1
    w_11_10   normalized_ratio_11_196  -1.25
    w_11_10   full_original_Gini_264  -5.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_184  -4.0746370015805063e-02
    x_11_11   product_ub_185  -1.0130246020270624e-01
    x_11_11   onehot_11_194  1
    x_11_11   stock_lb_204  11
    x_11_11   stock_ub_205  11
    x_11_11   parent_nonstrict_scope_206  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_184  1
    w_11_11   product_ub_185  1
    w_11_11   normalized_mass_11_195  1
    w_11_11   normalized_ratio_11_196  -1.375
    w_11_11   full_original_Gini_264  -6.8785714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_186  -4.0746370015805063e-02
    x_11_12   product_ub_187  -1.0130246020270624e-01
    x_11_12   onehot_11_194  1
    x_11_12   stock_lb_204  12
    x_11_12   stock_ub_205  12
    x_11_12   parent_nonstrict_scope_206  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_186  1
    w_11_12   product_ub_187  1
    w_11_12   normalized_mass_11_195  1
    w_11_12   normalized_ratio_11_196  -1.5
    w_11_12   full_original_Gini_264  -8.1285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_188  -4.0746370015805063e-02
    x_11_13   product_ub_189  -1.0130246020270624e-01
    x_11_13   onehot_11_194  1
    x_11_13   stock_lb_204  13
    x_11_13   stock_ub_205  13
    x_11_13   parent_nonstrict_scope_206  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_188  1
    w_11_13   product_ub_189  1
    w_11_13   normalized_mass_11_195  1
    w_11_13   normalized_ratio_11_196  -1.625
    w_11_13   full_original_Gini_264  -9.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_190  -4.0746370015805063e-02
    x_11_14   product_ub_191  -1.0130246020270624e-01
    x_11_14   onehot_11_194  1
    x_11_14   stock_lb_204  14
    x_11_14   stock_ub_205  14
    x_11_14   parent_nonstrict_scope_206  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_190  1
    w_11_14   product_ub_191  1
    w_11_14   normalized_mass_11_195  1
    w_11_14   normalized_ratio_11_196  -1.75
    w_11_14   full_original_Gini_264  -1.1128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_192  -4.0746370015805063e-02
    x_11_15   product_ub_193  -1.0130246020270624e-01
    x_11_15   onehot_11_194  1
    x_11_15   stock_lb_204  15
    x_11_15   stock_ub_205  15
    x_11_15   parent_nonstrict_scope_206  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_192  1
    w_11_15   product_ub_193  1
    w_11_15   normalized_mass_11_195  1
    w_11_15   normalized_ratio_11_196  -1.875
    w_11_15   full_original_Gini_264  -1.2628571428571428e+01
    rho_11    normalized_ratio_11_196  1
    rho_11    block_pair_pos_209  1
    rho_11    block_pair_neg_210  -1
    rho_11    block_pair_pos_219  1
    rho_11    block_pair_neg_220  -1
    rho_11    block_pair_pos_231  1
    rho_11    block_pair_neg_232  -1
    rho_11    block_pair_pos_241  1
    rho_11    block_pair_neg_242  -1
    rho_11    block_pair_pos_245  -1
    rho_11    block_pair_neg_246  1
    rho_11    block_pair_pos_251  1
    rho_11    block_pair_neg_252  -1
    rho_11    block_pair_pos_259  1
    rho_11    block_pair_neg_260  -1
    rho_11    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       6.3380304899829966e-03
    x_2_0     product_lb_197  -4.0746370015805063e-02
    x_2_0     product_ub_198  -1.0130246020270624e-01
    x_2_0     onehot_2_201  1
    x_2_0     parent_nonstrict_scope_206  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_197  1
    w_2_0     product_ub_198  1
    w_2_0     normalized_mass_2_202  1
    w_2_0     full_original_Gini_264  -9.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       -6.3380304899829966e-03
    x_2_1     product_lb_199  -4.0746370015805063e-02
    x_2_1     product_ub_200  -1.0130246020270624e-01
    x_2_1     onehot_2_201  1
    x_2_1     stock_lb_204  1
    x_2_1     stock_ub_205  1
    x_2_1     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_199  1
    w_2_1     product_ub_200  1
    w_2_1     normalized_mass_2_202  1
    w_2_1     normalized_ratio_2_203  -1
    w_2_1     full_original_Gini_264  -3.4142857142857141e+00
    rho_2     normalized_ratio_2_203  1
    rho_2     block_pair_pos_207  1
    rho_2     block_pair_neg_208  -1
    rho_2     block_pair_pos_211  1
    rho_2     block_pair_neg_212  -1
    rho_2     block_pair_pos_225  1
    rho_2     block_pair_neg_226  -1
    rho_2     block_pair_pos_237  1
    rho_2     block_pair_neg_238  -1
    rho_2     block_pair_pos_245  1
    rho_2     block_pair_neg_246  -1
    rho_2     block_pair_pos_247  1
    rho_2     block_pair_neg_248  -1
    rho_2     block_pair_pos_253  1
    rho_2     block_pair_neg_254  -1
    rho_2     normalization_263  1
    a_4_5     block_pair_pos_215  1
    a_4_5     block_pair_neg_216  1
    a_4_5     full_original_Gini_264  -1
    a_4_18    block_pair_pos_223  1
    a_4_18    block_pair_neg_224  1
    a_4_18    full_original_Gini_264  -1
    a_4_8     block_pair_pos_217  1
    a_4_8     block_pair_neg_218  1
    a_4_8     full_original_Gini_264  -1
    a_4_17    block_pair_pos_221  1
    a_4_17    block_pair_neg_222  1
    a_4_17    full_original_Gini_264  -1
    a_4_3     block_pair_pos_213  1
    a_4_3     block_pair_neg_214  1
    a_4_3     full_original_Gini_264  -1
    a_4_11    block_pair_pos_219  1
    a_4_11    block_pair_neg_220  1
    a_4_11    full_original_Gini_264  -1
    a_4_2     block_pair_pos_211  1
    a_4_2     block_pair_neg_212  1
    a_4_2     full_original_Gini_264  -1
    a_5_18    block_pair_pos_235  1
    a_5_18    block_pair_neg_236  1
    a_5_18    full_original_Gini_264  -1
    a_5_8     block_pair_pos_229  1
    a_5_8     block_pair_neg_230  1
    a_5_8     full_original_Gini_264  -1
    a_5_17    block_pair_pos_233  1
    a_5_17    block_pair_neg_234  1
    a_5_17    full_original_Gini_264  -1
    a_5_3     block_pair_pos_227  1
    a_5_3     block_pair_neg_228  1
    a_5_3     full_original_Gini_264  -1
    a_5_11    block_pair_pos_231  1
    a_5_11    block_pair_neg_232  1
    a_5_11    full_original_Gini_264  -1
    a_5_2     block_pair_pos_225  1
    a_5_2     block_pair_neg_226  1
    a_5_2     full_original_Gini_264  -1
    a_18_8    block_pair_pos_257  1
    a_18_8    block_pair_neg_258  1
    a_18_8    full_original_Gini_264  -1
    a_18_17   block_pair_pos_261  1
    a_18_17   block_pair_neg_262  1
    a_18_17   full_original_Gini_264  -1
    a_18_3    block_pair_pos_255  1
    a_18_3    block_pair_neg_256  1
    a_18_3    full_original_Gini_264  -1
    a_18_11   block_pair_pos_259  1
    a_18_11   block_pair_neg_260  1
    a_18_11   full_original_Gini_264  -1
    a_18_2    block_pair_pos_253  1
    a_18_2    block_pair_neg_254  1
    a_18_2    full_original_Gini_264  -1
    a_8_17    block_pair_pos_243  1
    a_8_17    block_pair_neg_244  1
    a_8_17    full_original_Gini_264  -1
    a_8_3     block_pair_pos_239  1
    a_8_3     block_pair_neg_240  1
    a_8_3     full_original_Gini_264  -1
    a_8_11    block_pair_pos_241  1
    a_8_11    block_pair_neg_242  1
    a_8_11    full_original_Gini_264  -1
    a_8_2     block_pair_pos_237  1
    a_8_2     block_pair_neg_238  1
    a_8_2     full_original_Gini_264  -1
    a_17_3    block_pair_pos_249  1
    a_17_3    block_pair_neg_250  1
    a_17_3    full_original_Gini_264  -1
    a_17_11   block_pair_pos_251  1
    a_17_11   block_pair_neg_252  1
    a_17_11   full_original_Gini_264  -1
    a_17_2    block_pair_pos_247  1
    a_17_2    block_pair_neg_248  1
    a_17_2    full_original_Gini_264  -1
    a_3_11    block_pair_pos_209  1
    a_3_11    block_pair_neg_210  1
    a_3_11    full_original_Gini_264  -1
    a_3_2     block_pair_pos_207  1
    a_3_2     block_pair_neg_208  1
    a_3_2     full_original_Gini_264  -1
    a_11_2    block_pair_pos_245  1
    a_11_2    block_pair_neg_246  1
    a_11_2    full_original_Gini_264  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_4_0  unique_nonzero_owner_265  1
    service_0_4_0  service_visit_def_788  1
    service_0_4_0  free_load_conservation_789  -12
    service_0_4_0  original_T_including_depot_unload_837  1440
    service_0_4_1  unique_nonzero_owner_266  1
    service_0_4_1  service_visit_def_788  1
    service_0_4_1  free_load_conservation_789  -11
    service_0_4_1  original_T_including_depot_unload_837  1320
    service_0_4_2  unique_nonzero_owner_267  1
    service_0_4_2  service_visit_def_788  1
    service_0_4_2  free_load_conservation_789  -10
    service_0_4_2  original_T_including_depot_unload_837  1200
    service_0_4_3  unique_nonzero_owner_268  1
    service_0_4_3  service_visit_def_788  1
    service_0_4_3  free_load_conservation_789  -9
    service_0_4_3  original_T_including_depot_unload_837  1080
    service_0_4_4  unique_nonzero_owner_269  1
    service_0_4_4  service_visit_def_788  1
    service_0_4_4  free_load_conservation_789  -8
    service_0_4_4  original_T_including_depot_unload_837  960
    service_0_4_5  unique_nonzero_owner_270  1
    service_0_4_5  service_visit_def_788  1
    service_0_4_5  free_load_conservation_789  -7
    service_0_4_5  original_T_including_depot_unload_837  840
    service_0_4_6  unique_nonzero_owner_271  1
    service_0_4_6  service_visit_def_788  1
    service_0_4_6  free_load_conservation_789  -6
    service_0_4_6  original_T_including_depot_unload_837  720
    service_0_4_7  unique_nonzero_owner_272  1
    service_0_4_7  service_visit_def_788  1
    service_0_4_7  free_load_conservation_789  -5
    service_0_4_7  original_T_including_depot_unload_837  600
    service_0_4_8  unique_nonzero_owner_273  1
    service_0_4_8  service_visit_def_788  1
    service_0_4_8  free_load_conservation_789  -4
    service_0_4_8  original_T_including_depot_unload_837  480
    service_0_4_9  unique_nonzero_owner_274  1
    service_0_4_9  service_visit_def_788  1
    service_0_4_9  free_load_conservation_789  -3
    service_0_4_9  original_T_including_depot_unload_837  360
    service_0_4_10  unique_nonzero_owner_275  1
    service_0_4_10  service_visit_def_788  1
    service_0_4_10  free_load_conservation_789  -2
    service_0_4_10  original_T_including_depot_unload_837  240
    service_0_4_11  unique_nonzero_owner_276  1
    service_0_4_11  service_visit_def_788  1
    service_0_4_11  free_load_conservation_789  -1
    service_0_4_11  original_T_including_depot_unload_837  120
    service_0_4_13  unique_nonzero_owner_277  1
    service_0_4_13  service_visit_def_788  1
    service_0_4_13  free_load_conservation_789  1
    service_0_4_14  unique_nonzero_owner_278  1
    service_0_4_14  service_visit_def_788  1
    service_0_4_14  free_load_conservation_789  2
    service_0_4_15  unique_nonzero_owner_279  1
    service_0_4_15  service_visit_def_788  1
    service_0_4_15  free_load_conservation_789  3
    service_1_4_0  unique_nonzero_owner_265  1
    service_1_4_0  service_visit_def_1059  1
    service_1_4_0  free_load_conservation_1060  -12
    service_1_4_0  original_T_including_depot_unload_1104  1440
    service_1_4_1  unique_nonzero_owner_266  1
    service_1_4_1  service_visit_def_1059  1
    service_1_4_1  free_load_conservation_1060  -11
    service_1_4_1  original_T_including_depot_unload_1104  1320
    service_1_4_2  unique_nonzero_owner_267  1
    service_1_4_2  service_visit_def_1059  1
    service_1_4_2  free_load_conservation_1060  -10
    service_1_4_2  original_T_including_depot_unload_1104  1200
    service_1_4_3  unique_nonzero_owner_268  1
    service_1_4_3  service_visit_def_1059  1
    service_1_4_3  free_load_conservation_1060  -9
    service_1_4_3  original_T_including_depot_unload_1104  1080
    service_1_4_4  unique_nonzero_owner_269  1
    service_1_4_4  service_visit_def_1059  1
    service_1_4_4  free_load_conservation_1060  -8
    service_1_4_4  original_T_including_depot_unload_1104  960
    service_1_4_5  unique_nonzero_owner_270  1
    service_1_4_5  service_visit_def_1059  1
    service_1_4_5  free_load_conservation_1060  -7
    service_1_4_5  original_T_including_depot_unload_1104  840
    service_1_4_6  unique_nonzero_owner_271  1
    service_1_4_6  service_visit_def_1059  1
    service_1_4_6  free_load_conservation_1060  -6
    service_1_4_6  original_T_including_depot_unload_1104  720
    service_1_4_7  unique_nonzero_owner_272  1
    service_1_4_7  service_visit_def_1059  1
    service_1_4_7  free_load_conservation_1060  -5
    service_1_4_7  original_T_including_depot_unload_1104  600
    service_1_4_8  unique_nonzero_owner_273  1
    service_1_4_8  service_visit_def_1059  1
    service_1_4_8  free_load_conservation_1060  -4
    service_1_4_8  original_T_including_depot_unload_1104  480
    service_1_4_9  unique_nonzero_owner_274  1
    service_1_4_9  service_visit_def_1059  1
    service_1_4_9  free_load_conservation_1060  -3
    service_1_4_9  original_T_including_depot_unload_1104  360
    service_1_4_10  unique_nonzero_owner_275  1
    service_1_4_10  service_visit_def_1059  1
    service_1_4_10  free_load_conservation_1060  -2
    service_1_4_10  original_T_including_depot_unload_1104  240
    service_1_4_11  unique_nonzero_owner_276  1
    service_1_4_11  service_visit_def_1059  1
    service_1_4_11  free_load_conservation_1060  -1
    service_1_4_11  original_T_including_depot_unload_1104  120
    service_1_4_13  unique_nonzero_owner_277  1
    service_1_4_13  service_visit_def_1059  1
    service_1_4_13  free_load_conservation_1060  1
    service_1_4_14  unique_nonzero_owner_278  1
    service_1_4_14  service_visit_def_1059  1
    service_1_4_14  free_load_conservation_1060  2
    service_1_4_15  unique_nonzero_owner_279  1
    service_1_4_15  service_visit_def_1059  1
    service_1_4_15  free_load_conservation_1060  3
    service_0_5_1  unique_nonzero_owner_280  1
    service_0_5_1  service_visit_def_794  1
    service_0_5_1  free_load_conservation_795  1
    service_0_5_2  unique_nonzero_owner_281  1
    service_0_5_2  service_visit_def_794  1
    service_0_5_2  free_load_conservation_795  2
    service_1_5_1  unique_nonzero_owner_280  1
    service_1_5_1  service_visit_def_1065  1
    service_1_5_1  free_load_conservation_1066  1
    service_1_5_2  unique_nonzero_owner_281  1
    service_1_5_2  service_visit_def_1065  1
    service_1_5_2  free_load_conservation_1066  2
    service_0_18_1  unique_nonzero_owner_282  1
    service_0_18_1  service_visit_def_800  1
    service_0_18_1  free_load_conservation_801  1
    service_0_18_2  unique_nonzero_owner_283  1
    service_0_18_2  service_visit_def_800  1
    service_0_18_2  free_load_conservation_801  2
    service_0_18_3  unique_nonzero_owner_284  1
    service_0_18_3  service_visit_def_800  1
    service_0_18_3  free_load_conservation_801  3
    service_0_18_4  unique_nonzero_owner_285  1
    service_0_18_4  service_visit_def_800  1
    service_0_18_4  free_load_conservation_801  4
    service_0_18_5  unique_nonzero_owner_286  1
    service_0_18_5  service_visit_def_800  1
    service_0_18_5  free_load_conservation_801  5
    service_0_18_6  unique_nonzero_owner_287  1
    service_0_18_6  service_visit_def_800  1
    service_0_18_6  free_load_conservation_801  6
    service_0_18_7  unique_nonzero_owner_288  1
    service_0_18_7  service_visit_def_800  1
    service_0_18_7  free_load_conservation_801  7
    service_0_18_8  unique_nonzero_owner_289  1
    service_0_18_8  service_visit_def_800  1
    service_0_18_8  free_load_conservation_801  8
    service_0_18_9  unique_nonzero_owner_290  1
    service_0_18_9  service_visit_def_800  1
    service_0_18_9  free_load_conservation_801  9
    service_0_18_10  unique_nonzero_owner_291  1
    service_0_18_10  service_visit_def_800  1
    service_0_18_10  free_load_conservation_801  10
    service_0_18_11  unique_nonzero_owner_292  1
    service_0_18_11  service_visit_def_800  1
    service_0_18_11  free_load_conservation_801  11
    service_0_18_12  unique_nonzero_owner_293  1
    service_0_18_12  service_visit_def_800  1
    service_0_18_12  free_load_conservation_801  12
    service_0_18_13  unique_nonzero_owner_294  1
    service_0_18_13  service_visit_def_800  1
    service_0_18_13  free_load_conservation_801  13
    service_0_18_14  unique_nonzero_owner_295  1
    service_0_18_14  service_visit_def_800  1
    service_0_18_14  free_load_conservation_801  14
    service_0_18_15  unique_nonzero_owner_296  1
    service_0_18_15  service_visit_def_800  1
    service_0_18_15  free_load_conservation_801  15
    service_1_18_1  unique_nonzero_owner_282  1
    service_1_18_1  service_visit_def_1071  1
    service_1_18_1  free_load_conservation_1072  1
    service_1_18_2  unique_nonzero_owner_283  1
    service_1_18_2  service_visit_def_1071  1
    service_1_18_2  free_load_conservation_1072  2
    service_1_18_3  unique_nonzero_owner_284  1
    service_1_18_3  service_visit_def_1071  1
    service_1_18_3  free_load_conservation_1072  3
    service_1_18_4  unique_nonzero_owner_285  1
    service_1_18_4  service_visit_def_1071  1
    service_1_18_4  free_load_conservation_1072  4
    service_1_18_5  unique_nonzero_owner_286  1
    service_1_18_5  service_visit_def_1071  1
    service_1_18_5  free_load_conservation_1072  5
    service_1_18_6  unique_nonzero_owner_287  1
    service_1_18_6  service_visit_def_1071  1
    service_1_18_6  free_load_conservation_1072  6
    service_1_18_7  unique_nonzero_owner_288  1
    service_1_18_7  service_visit_def_1071  1
    service_1_18_7  free_load_conservation_1072  7
    service_1_18_8  unique_nonzero_owner_289  1
    service_1_18_8  service_visit_def_1071  1
    service_1_18_8  free_load_conservation_1072  8
    service_1_18_9  unique_nonzero_owner_290  1
    service_1_18_9  service_visit_def_1071  1
    service_1_18_9  free_load_conservation_1072  9
    service_1_18_10  unique_nonzero_owner_291  1
    service_1_18_10  service_visit_def_1071  1
    service_1_18_10  free_load_conservation_1072  10
    service_1_18_11  unique_nonzero_owner_292  1
    service_1_18_11  service_visit_def_1071  1
    service_1_18_11  free_load_conservation_1072  11
    service_1_18_12  unique_nonzero_owner_293  1
    service_1_18_12  service_visit_def_1071  1
    service_1_18_12  free_load_conservation_1072  12
    service_1_18_13  unique_nonzero_owner_294  1
    service_1_18_13  service_visit_def_1071  1
    service_1_18_13  free_load_conservation_1072  13
    service_1_18_14  unique_nonzero_owner_295  1
    service_1_18_14  service_visit_def_1071  1
    service_1_18_14  free_load_conservation_1072  14
    service_1_18_15  unique_nonzero_owner_296  1
    service_1_18_15  service_visit_def_1071  1
    service_1_18_15  free_load_conservation_1072  15
    service_0_8_1  unique_nonzero_owner_297  1
    service_0_8_1  service_visit_def_806  1
    service_0_8_1  free_load_conservation_807  1
    service_0_8_2  unique_nonzero_owner_298  1
    service_0_8_2  service_visit_def_806  1
    service_0_8_2  free_load_conservation_807  2
    service_1_8_1  unique_nonzero_owner_297  1
    service_1_8_1  service_visit_def_1077  1
    service_1_8_1  free_load_conservation_1078  1
    service_1_8_2  unique_nonzero_owner_298  1
    service_1_8_2  service_visit_def_1077  1
    service_1_8_2  free_load_conservation_1078  2
    service_0_17_0  unique_nonzero_owner_299  1
    service_0_17_0  service_visit_def_812  1
    service_0_17_0  free_load_conservation_813  -3
    service_0_17_0  original_T_including_depot_unload_837  360
    service_0_17_1  unique_nonzero_owner_300  1
    service_0_17_1  service_visit_def_812  1
    service_0_17_1  free_load_conservation_813  -2
    service_0_17_1  original_T_including_depot_unload_837  240
    service_0_17_2  unique_nonzero_owner_301  1
    service_0_17_2  service_visit_def_812  1
    service_0_17_2  free_load_conservation_813  -1
    service_0_17_2  original_T_including_depot_unload_837  120
    service_0_17_4  unique_nonzero_owner_302  1
    service_0_17_4  service_visit_def_812  1
    service_0_17_4  free_load_conservation_813  1
    service_0_17_5  unique_nonzero_owner_303  1
    service_0_17_5  service_visit_def_812  1
    service_0_17_5  free_load_conservation_813  2
    service_0_17_6  unique_nonzero_owner_304  1
    service_0_17_6  service_visit_def_812  1
    service_0_17_6  free_load_conservation_813  3
    service_0_17_7  unique_nonzero_owner_305  1
    service_0_17_7  service_visit_def_812  1
    service_0_17_7  free_load_conservation_813  4
    service_0_17_8  unique_nonzero_owner_306  1
    service_0_17_8  service_visit_def_812  1
    service_0_17_8  free_load_conservation_813  5
    service_0_17_9  unique_nonzero_owner_307  1
    service_0_17_9  service_visit_def_812  1
    service_0_17_9  free_load_conservation_813  6
    service_0_17_10  unique_nonzero_owner_308  1
    service_0_17_10  service_visit_def_812  1
    service_0_17_10  free_load_conservation_813  7
    service_0_17_11  unique_nonzero_owner_309  1
    service_0_17_11  service_visit_def_812  1
    service_0_17_11  free_load_conservation_813  8
    service_0_17_12  unique_nonzero_owner_310  1
    service_0_17_12  service_visit_def_812  1
    service_0_17_12  free_load_conservation_813  9
    service_0_17_13  unique_nonzero_owner_311  1
    service_0_17_13  service_visit_def_812  1
    service_0_17_13  free_load_conservation_813  10
    service_0_17_14  unique_nonzero_owner_312  1
    service_0_17_14  service_visit_def_812  1
    service_0_17_14  free_load_conservation_813  11
    service_0_17_15  unique_nonzero_owner_313  1
    service_0_17_15  service_visit_def_812  1
    service_0_17_15  free_load_conservation_813  12
    service_0_17_16  unique_nonzero_owner_314  1
    service_0_17_16  service_visit_def_812  1
    service_0_17_16  free_load_conservation_813  13
    service_1_17_0  unique_nonzero_owner_299  1
    service_1_17_0  service_visit_def_1083  1
    service_1_17_0  free_load_conservation_1084  -3
    service_1_17_0  original_T_including_depot_unload_1104  360
    service_1_17_1  unique_nonzero_owner_300  1
    service_1_17_1  service_visit_def_1083  1
    service_1_17_1  free_load_conservation_1084  -2
    service_1_17_1  original_T_including_depot_unload_1104  240
    service_1_17_2  unique_nonzero_owner_301  1
    service_1_17_2  service_visit_def_1083  1
    service_1_17_2  free_load_conservation_1084  -1
    service_1_17_2  original_T_including_depot_unload_1104  120
    service_1_17_4  unique_nonzero_owner_302  1
    service_1_17_4  service_visit_def_1083  1
    service_1_17_4  free_load_conservation_1084  1
    service_1_17_5  unique_nonzero_owner_303  1
    service_1_17_5  service_visit_def_1083  1
    service_1_17_5  free_load_conservation_1084  2
    service_1_17_6  unique_nonzero_owner_304  1
    service_1_17_6  service_visit_def_1083  1
    service_1_17_6  free_load_conservation_1084  3
    service_1_17_7  unique_nonzero_owner_305  1
    service_1_17_7  service_visit_def_1083  1
    service_1_17_7  free_load_conservation_1084  4
    service_1_17_8  unique_nonzero_owner_306  1
    service_1_17_8  service_visit_def_1083  1
    service_1_17_8  free_load_conservation_1084  5
    service_1_17_9  unique_nonzero_owner_307  1
    service_1_17_9  service_visit_def_1083  1
    service_1_17_9  free_load_conservation_1084  6
    service_1_17_10  unique_nonzero_owner_308  1
    service_1_17_10  service_visit_def_1083  1
    service_1_17_10  free_load_conservation_1084  7
    service_1_17_11  unique_nonzero_owner_309  1
    service_1_17_11  service_visit_def_1083  1
    service_1_17_11  free_load_conservation_1084  8
    service_1_17_12  unique_nonzero_owner_310  1
    service_1_17_12  service_visit_def_1083  1
    service_1_17_12  free_load_conservation_1084  9
    service_1_17_13  unique_nonzero_owner_311  1
    service_1_17_13  service_visit_def_1083  1
    service_1_17_13  free_load_conservation_1084  10
    service_1_17_14  unique_nonzero_owner_312  1
    service_1_17_14  service_visit_def_1083  1
    service_1_17_14  free_load_conservation_1084  11
    service_1_17_15  unique_nonzero_owner_313  1
    service_1_17_15  service_visit_def_1083  1
    service_1_17_15  free_load_conservation_1084  12
    service_1_17_16  unique_nonzero_owner_314  1
    service_1_17_16  service_visit_def_1083  1
    service_1_17_16  free_load_conservation_1084  13
    service_0_3_0  unique_nonzero_owner_315  1
    service_0_3_0  service_visit_def_818  1
    service_0_3_0  free_load_conservation_819  -12
    service_0_3_0  original_T_including_depot_unload_837  1440
    service_0_3_1  unique_nonzero_owner_316  1
    service_0_3_1  service_visit_def_818  1
    service_0_3_1  free_load_conservation_819  -11
    service_0_3_1  original_T_including_depot_unload_837  1320
    service_0_3_2  unique_nonzero_owner_317  1
    service_0_3_2  service_visit_def_818  1
    service_0_3_2  free_load_conservation_819  -10
    service_0_3_2  original_T_including_depot_unload_837  1200
    service_0_3_3  unique_nonzero_owner_318  1
    service_0_3_3  service_visit_def_818  1
    service_0_3_3  free_load_conservation_819  -9
    service_0_3_3  original_T_including_depot_unload_837  1080
    service_0_3_4  unique_nonzero_owner_319  1
    service_0_3_4  service_visit_def_818  1
    service_0_3_4  free_load_conservation_819  -8
    service_0_3_4  original_T_including_depot_unload_837  960
    service_0_3_5  unique_nonzero_owner_320  1
    service_0_3_5  service_visit_def_818  1
    service_0_3_5  free_load_conservation_819  -7
    service_0_3_5  original_T_including_depot_unload_837  840
    service_0_3_6  unique_nonzero_owner_321  1
    service_0_3_6  service_visit_def_818  1
    service_0_3_6  free_load_conservation_819  -6
    service_0_3_6  original_T_including_depot_unload_837  720
    service_0_3_7  unique_nonzero_owner_322  1
    service_0_3_7  service_visit_def_818  1
    service_0_3_7  free_load_conservation_819  -5
    service_0_3_7  original_T_including_depot_unload_837  600
    service_0_3_8  unique_nonzero_owner_323  1
    service_0_3_8  service_visit_def_818  1
    service_0_3_8  free_load_conservation_819  -4
    service_0_3_8  original_T_including_depot_unload_837  480
    service_0_3_9  unique_nonzero_owner_324  1
    service_0_3_9  service_visit_def_818  1
    service_0_3_9  free_load_conservation_819  -3
    service_0_3_9  original_T_including_depot_unload_837  360
    service_0_3_10  unique_nonzero_owner_325  1
    service_0_3_10  service_visit_def_818  1
    service_0_3_10  free_load_conservation_819  -2
    service_0_3_10  original_T_including_depot_unload_837  240
    service_0_3_11  unique_nonzero_owner_326  1
    service_0_3_11  service_visit_def_818  1
    service_0_3_11  free_load_conservation_819  -1
    service_0_3_11  original_T_including_depot_unload_837  120
    service_0_3_13  unique_nonzero_owner_327  1
    service_0_3_13  service_visit_def_818  1
    service_0_3_13  free_load_conservation_819  1
    service_0_3_14  unique_nonzero_owner_328  1
    service_0_3_14  service_visit_def_818  1
    service_0_3_14  free_load_conservation_819  2
    service_0_3_15  unique_nonzero_owner_329  1
    service_0_3_15  service_visit_def_818  1
    service_0_3_15  free_load_conservation_819  3
    service_0_3_16  unique_nonzero_owner_330  1
    service_0_3_16  service_visit_def_818  1
    service_0_3_16  free_load_conservation_819  4
    service_1_3_0  unique_nonzero_owner_315  1
    service_1_3_0  service_visit_def_1089  1
    service_1_3_0  free_load_conservation_1090  -12
    service_1_3_0  original_T_including_depot_unload_1104  1440
    service_1_3_1  unique_nonzero_owner_316  1
    service_1_3_1  service_visit_def_1089  1
    service_1_3_1  free_load_conservation_1090  -11
    service_1_3_1  original_T_including_depot_unload_1104  1320
    service_1_3_2  unique_nonzero_owner_317  1
    service_1_3_2  service_visit_def_1089  1
    service_1_3_2  free_load_conservation_1090  -10
    service_1_3_2  original_T_including_depot_unload_1104  1200
    service_1_3_3  unique_nonzero_owner_318  1
    service_1_3_3  service_visit_def_1089  1
    service_1_3_3  free_load_conservation_1090  -9
    service_1_3_3  original_T_including_depot_unload_1104  1080
    service_1_3_4  unique_nonzero_owner_319  1
    service_1_3_4  service_visit_def_1089  1
    service_1_3_4  free_load_conservation_1090  -8
    service_1_3_4  original_T_including_depot_unload_1104  960
    service_1_3_5  unique_nonzero_owner_320  1
    service_1_3_5  service_visit_def_1089  1
    service_1_3_5  free_load_conservation_1090  -7
    service_1_3_5  original_T_including_depot_unload_1104  840
    service_1_3_6  unique_nonzero_owner_321  1
    service_1_3_6  service_visit_def_1089  1
    service_1_3_6  free_load_conservation_1090  -6
    service_1_3_6  original_T_including_depot_unload_1104  720
    service_1_3_7  unique_nonzero_owner_322  1
    service_1_3_7  service_visit_def_1089  1
    service_1_3_7  free_load_conservation_1090  -5
    service_1_3_7  original_T_including_depot_unload_1104  600
    service_1_3_8  unique_nonzero_owner_323  1
    service_1_3_8  service_visit_def_1089  1
    service_1_3_8  free_load_conservation_1090  -4
    service_1_3_8  original_T_including_depot_unload_1104  480
    service_1_3_9  unique_nonzero_owner_324  1
    service_1_3_9  service_visit_def_1089  1
    service_1_3_9  free_load_conservation_1090  -3
    service_1_3_9  original_T_including_depot_unload_1104  360
    service_1_3_10  unique_nonzero_owner_325  1
    service_1_3_10  service_visit_def_1089  1
    service_1_3_10  free_load_conservation_1090  -2
    service_1_3_10  original_T_including_depot_unload_1104  240
    service_1_3_11  unique_nonzero_owner_326  1
    service_1_3_11  service_visit_def_1089  1
    service_1_3_11  free_load_conservation_1090  -1
    service_1_3_11  original_T_including_depot_unload_1104  120
    service_1_3_13  unique_nonzero_owner_327  1
    service_1_3_13  service_visit_def_1089  1
    service_1_3_13  free_load_conservation_1090  1
    service_1_3_14  unique_nonzero_owner_328  1
    service_1_3_14  service_visit_def_1089  1
    service_1_3_14  free_load_conservation_1090  2
    service_1_3_15  unique_nonzero_owner_329  1
    service_1_3_15  service_visit_def_1089  1
    service_1_3_15  free_load_conservation_1090  3
    service_1_3_16  unique_nonzero_owner_330  1
    service_1_3_16  service_visit_def_1089  1
    service_1_3_16  free_load_conservation_1090  4
    service_0_11_0  unique_nonzero_owner_331  1
    service_0_11_0  service_visit_def_824  1
    service_0_11_0  free_load_conservation_825  -1
    service_0_11_0  original_T_including_depot_unload_837  120
    service_0_11_2  unique_nonzero_owner_332  1
    service_0_11_2  service_visit_def_824  1
    service_0_11_2  free_load_conservation_825  1
    service_0_11_3  unique_nonzero_owner_333  1
    service_0_11_3  service_visit_def_824  1
    service_0_11_3  free_load_conservation_825  2
    service_0_11_4  unique_nonzero_owner_334  1
    service_0_11_4  service_visit_def_824  1
    service_0_11_4  free_load_conservation_825  3
    service_0_11_5  unique_nonzero_owner_335  1
    service_0_11_5  service_visit_def_824  1
    service_0_11_5  free_load_conservation_825  4
    service_0_11_6  unique_nonzero_owner_336  1
    service_0_11_6  service_visit_def_824  1
    service_0_11_6  free_load_conservation_825  5
    service_0_11_7  unique_nonzero_owner_337  1
    service_0_11_7  service_visit_def_824  1
    service_0_11_7  free_load_conservation_825  6
    service_0_11_8  unique_nonzero_owner_338  1
    service_0_11_8  service_visit_def_824  1
    service_0_11_8  free_load_conservation_825  7
    service_0_11_9  unique_nonzero_owner_339  1
    service_0_11_9  service_visit_def_824  1
    service_0_11_9  free_load_conservation_825  8
    service_0_11_10  unique_nonzero_owner_340  1
    service_0_11_10  service_visit_def_824  1
    service_0_11_10  free_load_conservation_825  9
    service_0_11_11  unique_nonzero_owner_341  1
    service_0_11_11  service_visit_def_824  1
    service_0_11_11  free_load_conservation_825  10
    service_0_11_12  unique_nonzero_owner_342  1
    service_0_11_12  service_visit_def_824  1
    service_0_11_12  free_load_conservation_825  11
    service_0_11_13  unique_nonzero_owner_343  1
    service_0_11_13  service_visit_def_824  1
    service_0_11_13  free_load_conservation_825  12
    service_0_11_14  unique_nonzero_owner_344  1
    service_0_11_14  service_visit_def_824  1
    service_0_11_14  free_load_conservation_825  13
    service_0_11_15  unique_nonzero_owner_345  1
    service_0_11_15  service_visit_def_824  1
    service_0_11_15  free_load_conservation_825  14
    service_1_11_0  unique_nonzero_owner_331  1
    service_1_11_0  service_visit_def_1095  1
    service_1_11_0  free_load_conservation_1096  -1
    service_1_11_0  original_T_including_depot_unload_1104  120
    service_1_11_2  unique_nonzero_owner_332  1
    service_1_11_2  service_visit_def_1095  1
    service_1_11_2  free_load_conservation_1096  1
    service_1_11_3  unique_nonzero_owner_333  1
    service_1_11_3  service_visit_def_1095  1
    service_1_11_3  free_load_conservation_1096  2
    service_1_11_4  unique_nonzero_owner_334  1
    service_1_11_4  service_visit_def_1095  1
    service_1_11_4  free_load_conservation_1096  3
    service_1_11_5  unique_nonzero_owner_335  1
    service_1_11_5  service_visit_def_1095  1
    service_1_11_5  free_load_conservation_1096  4
    service_1_11_6  unique_nonzero_owner_336  1
    service_1_11_6  service_visit_def_1095  1
    service_1_11_6  free_load_conservation_1096  5
    service_1_11_7  unique_nonzero_owner_337  1
    service_1_11_7  service_visit_def_1095  1
    service_1_11_7  free_load_conservation_1096  6
    service_1_11_8  unique_nonzero_owner_338  1
    service_1_11_8  service_visit_def_1095  1
    service_1_11_8  free_load_conservation_1096  7
    service_1_11_9  unique_nonzero_owner_339  1
    service_1_11_9  service_visit_def_1095  1
    service_1_11_9  free_load_conservation_1096  8
    service_1_11_10  unique_nonzero_owner_340  1
    service_1_11_10  service_visit_def_1095  1
    service_1_11_10  free_load_conservation_1096  9
    service_1_11_11  unique_nonzero_owner_341  1
    service_1_11_11  service_visit_def_1095  1
    service_1_11_11  free_load_conservation_1096  10
    service_1_11_12  unique_nonzero_owner_342  1
    service_1_11_12  service_visit_def_1095  1
    service_1_11_12  free_load_conservation_1096  11
    service_1_11_13  unique_nonzero_owner_343  1
    service_1_11_13  service_visit_def_1095  1
    service_1_11_13  free_load_conservation_1096  12
    service_1_11_14  unique_nonzero_owner_344  1
    service_1_11_14  service_visit_def_1095  1
    service_1_11_14  free_load_conservation_1096  13
    service_1_11_15  unique_nonzero_owner_345  1
    service_1_11_15  service_visit_def_1095  1
    service_1_11_15  free_load_conservation_1096  14
    service_0_2_1  unique_nonzero_owner_346  1
    service_0_2_1  service_visit_def_830  1
    service_0_2_1  free_load_conservation_831  1
    service_1_2_1  unique_nonzero_owner_346  1
    service_1_2_1  service_visit_def_1101  1
    service_1_2_1  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_742  -1
    visit_0_1  in_degree_743  -1
    visit_0_1  order_active_lb_744  -1
    visit_0_1  order_active_ub_745  -14
    order_0_1  connected_order_arc_364  -1
    order_0_1  connected_order_arc_366  -1
    order_0_1  connected_order_arc_368  -1
    order_0_1  connected_order_arc_370  -1
    order_0_1  connected_order_arc_372  -1
    order_0_1  connected_order_arc_374  -1
    order_0_1  connected_order_arc_376  -1
    order_0_1  connected_order_arc_378  -1
    order_0_1  connected_order_arc_380  -1
    order_0_1  connected_order_arc_382  -1
    order_0_1  connected_order_arc_384  -1
    order_0_1  connected_order_arc_386  -1
    order_0_1  connected_order_arc_388  -1
    order_0_1  connected_order_arc_391  1
    order_0_1  connected_order_arc_418  1
    order_0_1  connected_order_arc_445  1
    order_0_1  connected_order_arc_472  1
    order_0_1  connected_order_arc_499  1
    order_0_1  connected_order_arc_526  1
    order_0_1  connected_order_arc_553  1
    order_0_1  connected_order_arc_580  1
    order_0_1  connected_order_arc_607  1
    order_0_1  connected_order_arc_634  1
    order_0_1  connected_order_arc_661  1
    order_0_1  connected_order_arc_688  1
    order_0_1  connected_order_arc_715  1
    order_0_1  order_active_lb_744  1
    order_0_1  order_active_ub_745  1
    order_0_1  fixed_segment_relative_order_832  -1
    visit_0_2  out_degree_749  -1
    visit_0_2  in_degree_750  -1
    visit_0_2  order_active_lb_751  -1
    visit_0_2  order_active_ub_752  -14
    order_0_2  connected_order_arc_364  1
    order_0_2  connected_order_arc_391  -1
    order_0_2  connected_order_arc_393  -1
    order_0_2  connected_order_arc_395  -1
    order_0_2  connected_order_arc_397  -1
    order_0_2  connected_order_arc_399  -1
    order_0_2  connected_order_arc_401  -1
    order_0_2  connected_order_arc_403  -1
    order_0_2  connected_order_arc_405  -1
    order_0_2  connected_order_arc_407  -1
    order_0_2  connected_order_arc_409  -1
    order_0_2  connected_order_arc_411  -1
    order_0_2  connected_order_arc_413  -1
    order_0_2  connected_order_arc_415  -1
    order_0_2  connected_order_arc_420  1
    order_0_2  connected_order_arc_447  1
    order_0_2  connected_order_arc_474  1
    order_0_2  connected_order_arc_501  1
    order_0_2  connected_order_arc_528  1
    order_0_2  connected_order_arc_555  1
    order_0_2  connected_order_arc_582  1
    order_0_2  connected_order_arc_609  1
    order_0_2  connected_order_arc_636  1
    order_0_2  connected_order_arc_663  1
    order_0_2  connected_order_arc_690  1
    order_0_2  connected_order_arc_717  1
    order_0_2  order_active_lb_751  1
    order_0_2  order_active_ub_752  1
    order_0_2  fixed_segment_relative_order_832  1
    order_0_2  fixed_segment_relative_order_833  -1
    visit_0_3  out_degree_756  -1
    visit_0_3  in_degree_757  -1
    visit_0_3  order_active_lb_758  -1
    visit_0_3  order_active_ub_759  -14
    order_0_3  connected_order_arc_366  1
    order_0_3  connected_order_arc_393  1
    order_0_3  connected_order_arc_418  -1
    order_0_3  connected_order_arc_420  -1
    order_0_3  connected_order_arc_422  -1
    order_0_3  connected_order_arc_424  -1
    order_0_3  connected_order_arc_426  -1
    order_0_3  connected_order_arc_428  -1
    order_0_3  connected_order_arc_430  -1
    order_0_3  connected_order_arc_432  -1
    order_0_3  connected_order_arc_434  -1
    order_0_3  connected_order_arc_436  -1
    order_0_3  connected_order_arc_438  -1
    order_0_3  connected_order_arc_440  -1
    order_0_3  connected_order_arc_442  -1
    order_0_3  connected_order_arc_449  1
    order_0_3  connected_order_arc_476  1
    order_0_3  connected_order_arc_503  1
    order_0_3  connected_order_arc_530  1
    order_0_3  connected_order_arc_557  1
    order_0_3  connected_order_arc_584  1
    order_0_3  connected_order_arc_611  1
    order_0_3  connected_order_arc_638  1
    order_0_3  connected_order_arc_665  1
    order_0_3  connected_order_arc_692  1
    order_0_3  connected_order_arc_719  1
    order_0_3  order_active_lb_758  1
    order_0_3  order_active_ub_759  1
    order_0_3  fixed_segment_relative_order_833  1
    order_0_3  fixed_segment_relative_order_834  -1
    visit_0_4  out_degree_763  -1
    visit_0_4  in_degree_764  -1
    visit_0_4  order_active_lb_765  -1
    visit_0_4  order_active_ub_766  -14
    order_0_4  connected_order_arc_368  1
    order_0_4  connected_order_arc_395  1
    order_0_4  connected_order_arc_422  1
    order_0_4  connected_order_arc_445  -1
    order_0_4  connected_order_arc_447  -1
    order_0_4  connected_order_arc_449  -1
    order_0_4  connected_order_arc_451  -1
    order_0_4  connected_order_arc_453  -1
    order_0_4  connected_order_arc_455  -1
    order_0_4  connected_order_arc_457  -1
    order_0_4  connected_order_arc_459  -1
    order_0_4  connected_order_arc_461  -1
    order_0_4  connected_order_arc_463  -1
    order_0_4  connected_order_arc_465  -1
    order_0_4  connected_order_arc_467  -1
    order_0_4  connected_order_arc_469  -1
    order_0_4  connected_order_arc_478  1
    order_0_4  connected_order_arc_505  1
    order_0_4  connected_order_arc_532  1
    order_0_4  connected_order_arc_559  1
    order_0_4  connected_order_arc_586  1
    order_0_4  connected_order_arc_613  1
    order_0_4  connected_order_arc_640  1
    order_0_4  connected_order_arc_667  1
    order_0_4  connected_order_arc_694  1
    order_0_4  connected_order_arc_721  1
    order_0_4  order_active_lb_765  1
    order_0_4  order_active_ub_766  1
    order_0_4  fixed_segment_relative_order_834  1
    order_0_4  fixed_segment_relative_order_835  -1
    visit_0_5  out_degree_770  -1
    visit_0_5  in_degree_771  -1
    visit_0_5  order_active_lb_772  -1
    visit_0_5  order_active_ub_773  -14
    order_0_5  connected_order_arc_370  1
    order_0_5  connected_order_arc_397  1
    order_0_5  connected_order_arc_424  1
    order_0_5  connected_order_arc_451  1
    order_0_5  connected_order_arc_472  -1
    order_0_5  connected_order_arc_474  -1
    order_0_5  connected_order_arc_476  -1
    order_0_5  connected_order_arc_478  -1
    order_0_5  connected_order_arc_480  -1
    order_0_5  connected_order_arc_482  -1
    order_0_5  connected_order_arc_484  -1
    order_0_5  connected_order_arc_486  -1
    order_0_5  connected_order_arc_488  -1
    order_0_5  connected_order_arc_490  -1
    order_0_5  connected_order_arc_492  -1
    order_0_5  connected_order_arc_494  -1
    order_0_5  connected_order_arc_496  -1
    order_0_5  connected_order_arc_507  1
    order_0_5  connected_order_arc_534  1
    order_0_5  connected_order_arc_561  1
    order_0_5  connected_order_arc_588  1
    order_0_5  connected_order_arc_615  1
    order_0_5  connected_order_arc_642  1
    order_0_5  connected_order_arc_669  1
    order_0_5  connected_order_arc_696  1
    order_0_5  connected_order_arc_723  1
    order_0_5  order_active_lb_772  1
    order_0_5  order_active_ub_773  1
    order_0_5  fixed_segment_relative_order_835  1
    order_0_5  fixed_segment_relative_order_836  -1
    visit_0_6  out_degree_777  -1
    visit_0_6  in_degree_778  -1
    visit_0_6  order_active_lb_779  -1
    visit_0_6  order_active_ub_780  -14
    order_0_6  connected_order_arc_372  1
    order_0_6  connected_order_arc_399  1
    order_0_6  connected_order_arc_426  1
    order_0_6  connected_order_arc_453  1
    order_0_6  connected_order_arc_480  1
    order_0_6  connected_order_arc_499  -1
    order_0_6  connected_order_arc_501  -1
    order_0_6  connected_order_arc_503  -1
    order_0_6  connected_order_arc_505  -1
    order_0_6  connected_order_arc_507  -1
    order_0_6  connected_order_arc_509  -1
    order_0_6  connected_order_arc_511  -1
    order_0_6  connected_order_arc_513  -1
    order_0_6  connected_order_arc_515  -1
    order_0_6  connected_order_arc_517  -1
    order_0_6  connected_order_arc_519  -1
    order_0_6  connected_order_arc_521  -1
    order_0_6  connected_order_arc_523  -1
    order_0_6  connected_order_arc_536  1
    order_0_6  connected_order_arc_563  1
    order_0_6  connected_order_arc_590  1
    order_0_6  connected_order_arc_617  1
    order_0_6  connected_order_arc_644  1
    order_0_6  connected_order_arc_671  1
    order_0_6  connected_order_arc_698  1
    order_0_6  connected_order_arc_725  1
    order_0_6  order_active_lb_779  1
    order_0_6  order_active_ub_780  1
    order_0_6  fixed_segment_relative_order_836  1
    visit_0_9  out_degree_784  -1
    visit_0_9  in_degree_785  -1
    visit_0_9  order_active_lb_786  -1
    visit_0_9  order_active_ub_787  -14
    visit_0_9  service_visit_def_788  -1
    order_0_9  connected_order_arc_374  1
    order_0_9  connected_order_arc_401  1
    order_0_9  connected_order_arc_428  1
    order_0_9  connected_order_arc_455  1
    order_0_9  connected_order_arc_482  1
    order_0_9  connected_order_arc_509  1
    order_0_9  connected_order_arc_526  -1
    order_0_9  connected_order_arc_528  -1
    order_0_9  connected_order_arc_530  -1
    order_0_9  connected_order_arc_532  -1
    order_0_9  connected_order_arc_534  -1
    order_0_9  connected_order_arc_536  -1
    order_0_9  connected_order_arc_538  -1
    order_0_9  connected_order_arc_540  -1
    order_0_9  connected_order_arc_542  -1
    order_0_9  connected_order_arc_544  -1
    order_0_9  connected_order_arc_546  -1
    order_0_9  connected_order_arc_548  -1
    order_0_9  connected_order_arc_550  -1
    order_0_9  connected_order_arc_565  1
    order_0_9  connected_order_arc_592  1
    order_0_9  connected_order_arc_619  1
    order_0_9  connected_order_arc_646  1
    order_0_9  connected_order_arc_673  1
    order_0_9  connected_order_arc_700  1
    order_0_9  connected_order_arc_727  1
    order_0_9  order_active_lb_786  1
    order_0_9  order_active_ub_787  1
    visit_0_10  out_degree_790  -1
    visit_0_10  in_degree_791  -1
    visit_0_10  order_active_lb_792  -1
    visit_0_10  order_active_ub_793  -14
    visit_0_10  service_visit_def_794  -1
    order_0_10  connected_order_arc_376  1
    order_0_10  connected_order_arc_403  1
    order_0_10  connected_order_arc_430  1
    order_0_10  connected_order_arc_457  1
    order_0_10  connected_order_arc_484  1
    order_0_10  connected_order_arc_511  1
    order_0_10  connected_order_arc_538  1
    order_0_10  connected_order_arc_553  -1
    order_0_10  connected_order_arc_555  -1
    order_0_10  connected_order_arc_557  -1
    order_0_10  connected_order_arc_559  -1
    order_0_10  connected_order_arc_561  -1
    order_0_10  connected_order_arc_563  -1
    order_0_10  connected_order_arc_565  -1
    order_0_10  connected_order_arc_567  -1
    order_0_10  connected_order_arc_569  -1
    order_0_10  connected_order_arc_571  -1
    order_0_10  connected_order_arc_573  -1
    order_0_10  connected_order_arc_575  -1
    order_0_10  connected_order_arc_577  -1
    order_0_10  connected_order_arc_594  1
    order_0_10  connected_order_arc_621  1
    order_0_10  connected_order_arc_648  1
    order_0_10  connected_order_arc_675  1
    order_0_10  connected_order_arc_702  1
    order_0_10  connected_order_arc_729  1
    order_0_10  order_active_lb_792  1
    order_0_10  order_active_ub_793  1
    visit_0_11  out_degree_796  -1
    visit_0_11  in_degree_797  -1
    visit_0_11  order_active_lb_798  -1
    visit_0_11  order_active_ub_799  -14
    visit_0_11  service_visit_def_800  -1
    order_0_11  connected_order_arc_378  1
    order_0_11  connected_order_arc_405  1
    order_0_11  connected_order_arc_432  1
    order_0_11  connected_order_arc_459  1
    order_0_11  connected_order_arc_486  1
    order_0_11  connected_order_arc_513  1
    order_0_11  connected_order_arc_540  1
    order_0_11  connected_order_arc_567  1
    order_0_11  connected_order_arc_580  -1
    order_0_11  connected_order_arc_582  -1
    order_0_11  connected_order_arc_584  -1
    order_0_11  connected_order_arc_586  -1
    order_0_11  connected_order_arc_588  -1
    order_0_11  connected_order_arc_590  -1
    order_0_11  connected_order_arc_592  -1
    order_0_11  connected_order_arc_594  -1
    order_0_11  connected_order_arc_596  -1
    order_0_11  connected_order_arc_598  -1
    order_0_11  connected_order_arc_600  -1
    order_0_11  connected_order_arc_602  -1
    order_0_11  connected_order_arc_604  -1
    order_0_11  connected_order_arc_623  1
    order_0_11  connected_order_arc_650  1
    order_0_11  connected_order_arc_677  1
    order_0_11  connected_order_arc_704  1
    order_0_11  connected_order_arc_731  1
    order_0_11  order_active_lb_798  1
    order_0_11  order_active_ub_799  1
    visit_0_12  out_degree_802  -1
    visit_0_12  in_degree_803  -1
    visit_0_12  order_active_lb_804  -1
    visit_0_12  order_active_ub_805  -14
    visit_0_12  service_visit_def_806  -1
    order_0_12  connected_order_arc_380  1
    order_0_12  connected_order_arc_407  1
    order_0_12  connected_order_arc_434  1
    order_0_12  connected_order_arc_461  1
    order_0_12  connected_order_arc_488  1
    order_0_12  connected_order_arc_515  1
    order_0_12  connected_order_arc_542  1
    order_0_12  connected_order_arc_569  1
    order_0_12  connected_order_arc_596  1
    order_0_12  connected_order_arc_607  -1
    order_0_12  connected_order_arc_609  -1
    order_0_12  connected_order_arc_611  -1
    order_0_12  connected_order_arc_613  -1
    order_0_12  connected_order_arc_615  -1
    order_0_12  connected_order_arc_617  -1
    order_0_12  connected_order_arc_619  -1
    order_0_12  connected_order_arc_621  -1
    order_0_12  connected_order_arc_623  -1
    order_0_12  connected_order_arc_625  -1
    order_0_12  connected_order_arc_627  -1
    order_0_12  connected_order_arc_629  -1
    order_0_12  connected_order_arc_631  -1
    order_0_12  connected_order_arc_652  1
    order_0_12  connected_order_arc_679  1
    order_0_12  connected_order_arc_706  1
    order_0_12  connected_order_arc_733  1
    order_0_12  order_active_lb_804  1
    order_0_12  order_active_ub_805  1
    visit_0_13  out_degree_808  -1
    visit_0_13  in_degree_809  -1
    visit_0_13  order_active_lb_810  -1
    visit_0_13  order_active_ub_811  -14
    visit_0_13  service_visit_def_812  -1
    order_0_13  connected_order_arc_382  1
    order_0_13  connected_order_arc_409  1
    order_0_13  connected_order_arc_436  1
    order_0_13  connected_order_arc_463  1
    order_0_13  connected_order_arc_490  1
    order_0_13  connected_order_arc_517  1
    order_0_13  connected_order_arc_544  1
    order_0_13  connected_order_arc_571  1
    order_0_13  connected_order_arc_598  1
    order_0_13  connected_order_arc_625  1
    order_0_13  connected_order_arc_634  -1
    order_0_13  connected_order_arc_636  -1
    order_0_13  connected_order_arc_638  -1
    order_0_13  connected_order_arc_640  -1
    order_0_13  connected_order_arc_642  -1
    order_0_13  connected_order_arc_644  -1
    order_0_13  connected_order_arc_646  -1
    order_0_13  connected_order_arc_648  -1
    order_0_13  connected_order_arc_650  -1
    order_0_13  connected_order_arc_652  -1
    order_0_13  connected_order_arc_654  -1
    order_0_13  connected_order_arc_656  -1
    order_0_13  connected_order_arc_658  -1
    order_0_13  connected_order_arc_681  1
    order_0_13  connected_order_arc_708  1
    order_0_13  connected_order_arc_735  1
    order_0_13  order_active_lb_810  1
    order_0_13  order_active_ub_811  1
    visit_0_14  out_degree_814  -1
    visit_0_14  in_degree_815  -1
    visit_0_14  order_active_lb_816  -1
    visit_0_14  order_active_ub_817  -14
    visit_0_14  service_visit_def_818  -1
    order_0_14  connected_order_arc_384  1
    order_0_14  connected_order_arc_411  1
    order_0_14  connected_order_arc_438  1
    order_0_14  connected_order_arc_465  1
    order_0_14  connected_order_arc_492  1
    order_0_14  connected_order_arc_519  1
    order_0_14  connected_order_arc_546  1
    order_0_14  connected_order_arc_573  1
    order_0_14  connected_order_arc_600  1
    order_0_14  connected_order_arc_627  1
    order_0_14  connected_order_arc_654  1
    order_0_14  connected_order_arc_661  -1
    order_0_14  connected_order_arc_663  -1
    order_0_14  connected_order_arc_665  -1
    order_0_14  connected_order_arc_667  -1
    order_0_14  connected_order_arc_669  -1
    order_0_14  connected_order_arc_671  -1
    order_0_14  connected_order_arc_673  -1
    order_0_14  connected_order_arc_675  -1
    order_0_14  connected_order_arc_677  -1
    order_0_14  connected_order_arc_679  -1
    order_0_14  connected_order_arc_681  -1
    order_0_14  connected_order_arc_683  -1
    order_0_14  connected_order_arc_685  -1
    order_0_14  connected_order_arc_710  1
    order_0_14  connected_order_arc_737  1
    order_0_14  order_active_lb_816  1
    order_0_14  order_active_ub_817  1
    visit_0_15  out_degree_820  -1
    visit_0_15  in_degree_821  -1
    visit_0_15  order_active_lb_822  -1
    visit_0_15  order_active_ub_823  -14
    visit_0_15  service_visit_def_824  -1
    order_0_15  connected_order_arc_386  1
    order_0_15  connected_order_arc_413  1
    order_0_15  connected_order_arc_440  1
    order_0_15  connected_order_arc_467  1
    order_0_15  connected_order_arc_494  1
    order_0_15  connected_order_arc_521  1
    order_0_15  connected_order_arc_548  1
    order_0_15  connected_order_arc_575  1
    order_0_15  connected_order_arc_602  1
    order_0_15  connected_order_arc_629  1
    order_0_15  connected_order_arc_656  1
    order_0_15  connected_order_arc_683  1
    order_0_15  connected_order_arc_688  -1
    order_0_15  connected_order_arc_690  -1
    order_0_15  connected_order_arc_692  -1
    order_0_15  connected_order_arc_694  -1
    order_0_15  connected_order_arc_696  -1
    order_0_15  connected_order_arc_698  -1
    order_0_15  connected_order_arc_700  -1
    order_0_15  connected_order_arc_702  -1
    order_0_15  connected_order_arc_704  -1
    order_0_15  connected_order_arc_706  -1
    order_0_15  connected_order_arc_708  -1
    order_0_15  connected_order_arc_710  -1
    order_0_15  connected_order_arc_712  -1
    order_0_15  connected_order_arc_739  1
    order_0_15  order_active_lb_822  1
    order_0_15  order_active_ub_823  1
    visit_0_16  out_degree_826  -1
    visit_0_16  in_degree_827  -1
    visit_0_16  order_active_lb_828  -1
    visit_0_16  order_active_ub_829  -14
    visit_0_16  service_visit_def_830  -1
    order_0_16  connected_order_arc_388  1
    order_0_16  connected_order_arc_415  1
    order_0_16  connected_order_arc_442  1
    order_0_16  connected_order_arc_469  1
    order_0_16  connected_order_arc_496  1
    order_0_16  connected_order_arc_523  1
    order_0_16  connected_order_arc_550  1
    order_0_16  connected_order_arc_577  1
    order_0_16  connected_order_arc_604  1
    order_0_16  connected_order_arc_631  1
    order_0_16  connected_order_arc_658  1
    order_0_16  connected_order_arc_685  1
    order_0_16  connected_order_arc_712  1
    order_0_16  connected_order_arc_715  -1
    order_0_16  connected_order_arc_717  -1
    order_0_16  connected_order_arc_719  -1
    order_0_16  connected_order_arc_721  -1
    order_0_16  connected_order_arc_723  -1
    order_0_16  connected_order_arc_725  -1
    order_0_16  connected_order_arc_727  -1
    order_0_16  connected_order_arc_729  -1
    order_0_16  connected_order_arc_731  -1
    order_0_16  connected_order_arc_733  -1
    order_0_16  connected_order_arc_735  -1
    order_0_16  connected_order_arc_737  -1
    order_0_16  connected_order_arc_739  -1
    order_0_16  order_active_lb_828  1
    order_0_16  order_active_ub_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_347  -30
    arc_0_0_0  depot_departure_or_bypass_740  1
    arc_0_0_0  depot_return_or_bypass_741  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_347  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_348  -30
    arc_0_0_1  depot_departure_or_bypass_740  1
    arc_0_0_1  in_degree_743  1
    arc_0_0_1  original_T_including_depot_unload_837  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_348  1
    load_0_0_1  segment_load_conservation_746  -1
    load_0_0_1  segment_prefix_lb_747  1
    load_0_0_1  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_349  -30
    arc_0_0_2  depot_departure_or_bypass_740  1
    arc_0_0_2  in_degree_750  1
    arc_0_0_2  original_T_including_depot_unload_837  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_349  1
    load_0_0_2  segment_load_conservation_753  -1
    load_0_0_2  segment_prefix_lb_754  1
    load_0_0_2  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_350  -30
    arc_0_0_3  depot_departure_or_bypass_740  1
    arc_0_0_3  in_degree_757  1
    arc_0_0_3  original_T_including_depot_unload_837  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_350  1
    load_0_0_3  segment_load_conservation_760  -1
    load_0_0_3  segment_prefix_lb_761  1
    load_0_0_3  segment_prefix_ub_762  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_351  -30
    arc_0_0_4  depot_departure_or_bypass_740  1
    arc_0_0_4  in_degree_764  1
    arc_0_0_4  original_T_including_depot_unload_837  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_351  1
    load_0_0_4  segment_load_conservation_767  -1
    load_0_0_4  segment_prefix_lb_768  1
    load_0_0_4  segment_prefix_ub_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_352  -30
    arc_0_0_5  depot_departure_or_bypass_740  1
    arc_0_0_5  in_degree_771  1
    arc_0_0_5  original_T_including_depot_unload_837  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_352  1
    load_0_0_5  segment_load_conservation_774  -1
    load_0_0_5  segment_prefix_lb_775  1
    load_0_0_5  segment_prefix_ub_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_353  -30
    arc_0_0_6  depot_departure_or_bypass_740  1
    arc_0_0_6  in_degree_778  1
    arc_0_0_6  original_T_including_depot_unload_837  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_353  1
    load_0_0_6  segment_load_conservation_781  -1
    load_0_0_6  segment_prefix_lb_782  1
    load_0_0_6  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_354  -30
    arc_0_0_9  depot_departure_or_bypass_740  1
    arc_0_0_9  in_degree_785  1
    arc_0_0_9  original_T_including_depot_unload_837  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_354  1
    load_0_0_9  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_355  -30
    arc_0_0_10  depot_departure_or_bypass_740  1
    arc_0_0_10  in_degree_791  1
    arc_0_0_10  original_T_including_depot_unload_837  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_355  1
    load_0_0_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_356  -30
    arc_0_0_11  depot_departure_or_bypass_740  1
    arc_0_0_11  in_degree_797  1
    arc_0_0_11  original_T_including_depot_unload_837  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_356  1
    load_0_0_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_357  -30
    arc_0_0_12  depot_departure_or_bypass_740  1
    arc_0_0_12  in_degree_803  1
    arc_0_0_12  original_T_including_depot_unload_837  1.1810298132524642e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_357  1
    load_0_0_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_358  -30
    arc_0_0_13  depot_departure_or_bypass_740  1
    arc_0_0_13  in_degree_809  1
    arc_0_0_13  original_T_including_depot_unload_837  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_358  1
    load_0_0_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_359  -30
    arc_0_0_14  depot_departure_or_bypass_740  1
    arc_0_0_14  in_degree_815  1
    arc_0_0_14  original_T_including_depot_unload_837  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_359  1
    load_0_0_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_360  -30
    arc_0_0_15  depot_departure_or_bypass_740  1
    arc_0_0_15  in_degree_821  1
    arc_0_0_15  original_T_including_depot_unload_837  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_360  1
    load_0_0_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_361  -30
    arc_0_0_16  depot_departure_or_bypass_740  1
    arc_0_0_16  in_degree_827  1
    arc_0_0_16  original_T_including_depot_unload_837  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_361  1
    load_0_0_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_362  -30
    arc_0_1_0  depot_return_or_bypass_741  1
    arc_0_1_0  out_degree_742  1
    arc_0_1_0  original_T_including_depot_unload_837  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_362  1
    load_0_1_0  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_363  -30
    arc_0_1_2  connected_order_arc_364  -15
    arc_0_1_2  out_degree_742  1
    arc_0_1_2  in_degree_750  1
    arc_0_1_2  original_T_including_depot_unload_837  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_363  1
    load_0_1_2  segment_load_conservation_746  1
    load_0_1_2  segment_load_conservation_753  -1
    load_0_1_2  segment_prefix_lb_754  1
    load_0_1_2  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_365  -30
    arc_0_1_3  connected_order_arc_366  -15
    arc_0_1_3  out_degree_742  1
    arc_0_1_3  in_degree_757  1
    arc_0_1_3  original_T_including_depot_unload_837  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_365  1
    load_0_1_3  segment_load_conservation_746  1
    load_0_1_3  segment_load_conservation_760  -1
    load_0_1_3  segment_prefix_lb_761  1
    load_0_1_3  segment_prefix_ub_762  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_367  -30
    arc_0_1_4  connected_order_arc_368  -15
    arc_0_1_4  out_degree_742  1
    arc_0_1_4  in_degree_764  1
    arc_0_1_4  original_T_including_depot_unload_837  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_367  1
    load_0_1_4  segment_load_conservation_746  1
    load_0_1_4  segment_load_conservation_767  -1
    load_0_1_4  segment_prefix_lb_768  1
    load_0_1_4  segment_prefix_ub_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_369  -30
    arc_0_1_5  connected_order_arc_370  -15
    arc_0_1_5  out_degree_742  1
    arc_0_1_5  in_degree_771  1
    arc_0_1_5  original_T_including_depot_unload_837  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_369  1
    load_0_1_5  segment_load_conservation_746  1
    load_0_1_5  segment_load_conservation_774  -1
    load_0_1_5  segment_prefix_lb_775  1
    load_0_1_5  segment_prefix_ub_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_371  -30
    arc_0_1_6  connected_order_arc_372  -15
    arc_0_1_6  out_degree_742  1
    arc_0_1_6  in_degree_778  1
    arc_0_1_6  original_T_including_depot_unload_837  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_371  1
    load_0_1_6  segment_load_conservation_746  1
    load_0_1_6  segment_load_conservation_781  -1
    load_0_1_6  segment_prefix_lb_782  1
    load_0_1_6  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_373  -30
    arc_0_1_9  connected_order_arc_374  -15
    arc_0_1_9  out_degree_742  1
    arc_0_1_9  in_degree_785  1
    arc_0_1_9  original_T_including_depot_unload_837  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_373  1
    load_0_1_9  segment_load_conservation_746  1
    load_0_1_9  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_375  -30
    arc_0_1_10  connected_order_arc_376  -15
    arc_0_1_10  out_degree_742  1
    arc_0_1_10  in_degree_791  1
    arc_0_1_10  original_T_including_depot_unload_837  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_375  1
    load_0_1_10  segment_load_conservation_746  1
    load_0_1_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_377  -30
    arc_0_1_11  connected_order_arc_378  -15
    arc_0_1_11  out_degree_742  1
    arc_0_1_11  in_degree_797  1
    arc_0_1_11  original_T_including_depot_unload_837  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_377  1
    load_0_1_11  segment_load_conservation_746  1
    load_0_1_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_379  -30
    arc_0_1_12  connected_order_arc_380  -15
    arc_0_1_12  out_degree_742  1
    arc_0_1_12  in_degree_803  1
    arc_0_1_12  original_T_including_depot_unload_837  1.3431004957633038e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_379  1
    load_0_1_12  segment_load_conservation_746  1
    load_0_1_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_381  -30
    arc_0_1_13  connected_order_arc_382  -15
    arc_0_1_13  out_degree_742  1
    arc_0_1_13  in_degree_809  1
    arc_0_1_13  original_T_including_depot_unload_837  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_381  1
    load_0_1_13  segment_load_conservation_746  1
    load_0_1_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_383  -30
    arc_0_1_14  connected_order_arc_384  -15
    arc_0_1_14  out_degree_742  1
    arc_0_1_14  in_degree_815  1
    arc_0_1_14  original_T_including_depot_unload_837  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_383  1
    load_0_1_14  segment_load_conservation_746  1
    load_0_1_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_385  -30
    arc_0_1_15  connected_order_arc_386  -15
    arc_0_1_15  out_degree_742  1
    arc_0_1_15  in_degree_821  1
    arc_0_1_15  original_T_including_depot_unload_837  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_385  1
    load_0_1_15  segment_load_conservation_746  1
    load_0_1_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_387  -30
    arc_0_1_16  connected_order_arc_388  -15
    arc_0_1_16  out_degree_742  1
    arc_0_1_16  in_degree_827  1
    arc_0_1_16  original_T_including_depot_unload_837  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_387  1
    load_0_1_16  segment_load_conservation_746  1
    load_0_1_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_389  -30
    arc_0_2_0  depot_return_or_bypass_741  1
    arc_0_2_0  out_degree_749  1
    arc_0_2_0  original_T_including_depot_unload_837  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_389  1
    load_0_2_0  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_390  -30
    arc_0_2_1  connected_order_arc_391  -15
    arc_0_2_1  in_degree_743  1
    arc_0_2_1  out_degree_749  1
    arc_0_2_1  original_T_including_depot_unload_837  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_390  1
    load_0_2_1  segment_load_conservation_746  -1
    load_0_2_1  segment_prefix_lb_747  1
    load_0_2_1  segment_prefix_ub_748  1
    load_0_2_1  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_392  -30
    arc_0_2_3  connected_order_arc_393  -15
    arc_0_2_3  out_degree_749  1
    arc_0_2_3  in_degree_757  1
    arc_0_2_3  original_T_including_depot_unload_837  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_392  1
    load_0_2_3  segment_load_conservation_753  1
    load_0_2_3  segment_load_conservation_760  -1
    load_0_2_3  segment_prefix_lb_761  1
    load_0_2_3  segment_prefix_ub_762  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_394  -30
    arc_0_2_4  connected_order_arc_395  -15
    arc_0_2_4  out_degree_749  1
    arc_0_2_4  in_degree_764  1
    arc_0_2_4  original_T_including_depot_unload_837  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_394  1
    load_0_2_4  segment_load_conservation_753  1
    load_0_2_4  segment_load_conservation_767  -1
    load_0_2_4  segment_prefix_lb_768  1
    load_0_2_4  segment_prefix_ub_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_396  -30
    arc_0_2_5  connected_order_arc_397  -15
    arc_0_2_5  out_degree_749  1
    arc_0_2_5  in_degree_771  1
    arc_0_2_5  original_T_including_depot_unload_837  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_396  1
    load_0_2_5  segment_load_conservation_753  1
    load_0_2_5  segment_load_conservation_774  -1
    load_0_2_5  segment_prefix_lb_775  1
    load_0_2_5  segment_prefix_ub_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_398  -30
    arc_0_2_6  connected_order_arc_399  -15
    arc_0_2_6  out_degree_749  1
    arc_0_2_6  in_degree_778  1
    arc_0_2_6  original_T_including_depot_unload_837  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_398  1
    load_0_2_6  segment_load_conservation_753  1
    load_0_2_6  segment_load_conservation_781  -1
    load_0_2_6  segment_prefix_lb_782  1
    load_0_2_6  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_400  -30
    arc_0_2_9  connected_order_arc_401  -15
    arc_0_2_9  out_degree_749  1
    arc_0_2_9  in_degree_785  1
    arc_0_2_9  original_T_including_depot_unload_837  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_400  1
    load_0_2_9  segment_load_conservation_753  1
    load_0_2_9  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_402  -30
    arc_0_2_10  connected_order_arc_403  -15
    arc_0_2_10  out_degree_749  1
    arc_0_2_10  in_degree_791  1
    arc_0_2_10  original_T_including_depot_unload_837  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_402  1
    load_0_2_10  segment_load_conservation_753  1
    load_0_2_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_404  -30
    arc_0_2_11  connected_order_arc_405  -15
    arc_0_2_11  out_degree_749  1
    arc_0_2_11  in_degree_797  1
    arc_0_2_11  original_T_including_depot_unload_837  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_404  1
    load_0_2_11  segment_load_conservation_753  1
    load_0_2_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_406  -30
    arc_0_2_12  connected_order_arc_407  -15
    arc_0_2_12  out_degree_749  1
    arc_0_2_12  in_degree_803  1
    arc_0_2_12  original_T_including_depot_unload_837  6.5335687537758054e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_406  1
    load_0_2_12  segment_load_conservation_753  1
    load_0_2_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_408  -30
    arc_0_2_13  connected_order_arc_409  -15
    arc_0_2_13  out_degree_749  1
    arc_0_2_13  in_degree_809  1
    arc_0_2_13  original_T_including_depot_unload_837  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_408  1
    load_0_2_13  segment_load_conservation_753  1
    load_0_2_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_410  -30
    arc_0_2_14  connected_order_arc_411  -15
    arc_0_2_14  out_degree_749  1
    arc_0_2_14  in_degree_815  1
    arc_0_2_14  original_T_including_depot_unload_837  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_410  1
    load_0_2_14  segment_load_conservation_753  1
    load_0_2_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_412  -30
    arc_0_2_15  connected_order_arc_413  -15
    arc_0_2_15  out_degree_749  1
    arc_0_2_15  in_degree_821  1
    arc_0_2_15  original_T_including_depot_unload_837  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_412  1
    load_0_2_15  segment_load_conservation_753  1
    load_0_2_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_414  -30
    arc_0_2_16  connected_order_arc_415  -15
    arc_0_2_16  out_degree_749  1
    arc_0_2_16  in_degree_827  1
    arc_0_2_16  original_T_including_depot_unload_837  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_414  1
    load_0_2_16  segment_load_conservation_753  1
    load_0_2_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_416  -30
    arc_0_3_0  depot_return_or_bypass_741  1
    arc_0_3_0  out_degree_756  1
    arc_0_3_0  original_T_including_depot_unload_837  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_416  1
    load_0_3_0  segment_load_conservation_760  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_417  -30
    arc_0_3_1  connected_order_arc_418  -15
    arc_0_3_1  in_degree_743  1
    arc_0_3_1  out_degree_756  1
    arc_0_3_1  original_T_including_depot_unload_837  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_417  1
    load_0_3_1  segment_load_conservation_746  -1
    load_0_3_1  segment_prefix_lb_747  1
    load_0_3_1  segment_prefix_ub_748  1
    load_0_3_1  segment_load_conservation_760  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_419  -30
    arc_0_3_2  connected_order_arc_420  -15
    arc_0_3_2  in_degree_750  1
    arc_0_3_2  out_degree_756  1
    arc_0_3_2  original_T_including_depot_unload_837  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_419  1
    load_0_3_2  segment_load_conservation_753  -1
    load_0_3_2  segment_prefix_lb_754  1
    load_0_3_2  segment_prefix_ub_755  1
    load_0_3_2  segment_load_conservation_760  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_421  -30
    arc_0_3_4  connected_order_arc_422  -15
    arc_0_3_4  out_degree_756  1
    arc_0_3_4  in_degree_764  1
    arc_0_3_4  original_T_including_depot_unload_837  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_421  1
    load_0_3_4  segment_load_conservation_760  1
    load_0_3_4  segment_load_conservation_767  -1
    load_0_3_4  segment_prefix_lb_768  1
    load_0_3_4  segment_prefix_ub_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_423  -30
    arc_0_3_5  connected_order_arc_424  -15
    arc_0_3_5  out_degree_756  1
    arc_0_3_5  in_degree_771  1
    arc_0_3_5  original_T_including_depot_unload_837  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_423  1
    load_0_3_5  segment_load_conservation_760  1
    load_0_3_5  segment_load_conservation_774  -1
    load_0_3_5  segment_prefix_lb_775  1
    load_0_3_5  segment_prefix_ub_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_425  -30
    arc_0_3_6  connected_order_arc_426  -15
    arc_0_3_6  out_degree_756  1
    arc_0_3_6  in_degree_778  1
    arc_0_3_6  original_T_including_depot_unload_837  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_425  1
    load_0_3_6  segment_load_conservation_760  1
    load_0_3_6  segment_load_conservation_781  -1
    load_0_3_6  segment_prefix_lb_782  1
    load_0_3_6  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_427  -30
    arc_0_3_9  connected_order_arc_428  -15
    arc_0_3_9  out_degree_756  1
    arc_0_3_9  in_degree_785  1
    arc_0_3_9  original_T_including_depot_unload_837  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_427  1
    load_0_3_9  segment_load_conservation_760  1
    load_0_3_9  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_429  -30
    arc_0_3_10  connected_order_arc_430  -15
    arc_0_3_10  out_degree_756  1
    arc_0_3_10  in_degree_791  1
    arc_0_3_10  original_T_including_depot_unload_837  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_429  1
    load_0_3_10  segment_load_conservation_760  1
    load_0_3_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_431  -30
    arc_0_3_11  connected_order_arc_432  -15
    arc_0_3_11  out_degree_756  1
    arc_0_3_11  in_degree_797  1
    arc_0_3_11  original_T_including_depot_unload_837  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_431  1
    load_0_3_11  segment_load_conservation_760  1
    load_0_3_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_433  -30
    arc_0_3_12  connected_order_arc_434  -15
    arc_0_3_12  out_degree_756  1
    arc_0_3_12  in_degree_803  1
    arc_0_3_12  original_T_including_depot_unload_837  7.1112286974366077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_433  1
    load_0_3_12  segment_load_conservation_760  1
    load_0_3_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_435  -30
    arc_0_3_13  connected_order_arc_436  -15
    arc_0_3_13  out_degree_756  1
    arc_0_3_13  in_degree_809  1
    arc_0_3_13  original_T_including_depot_unload_837  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_435  1
    load_0_3_13  segment_load_conservation_760  1
    load_0_3_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_437  -30
    arc_0_3_14  connected_order_arc_438  -15
    arc_0_3_14  out_degree_756  1
    arc_0_3_14  in_degree_815  1
    arc_0_3_14  original_T_including_depot_unload_837  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_437  1
    load_0_3_14  segment_load_conservation_760  1
    load_0_3_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_439  -30
    arc_0_3_15  connected_order_arc_440  -15
    arc_0_3_15  out_degree_756  1
    arc_0_3_15  in_degree_821  1
    arc_0_3_15  original_T_including_depot_unload_837  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_439  1
    load_0_3_15  segment_load_conservation_760  1
    load_0_3_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_441  -30
    arc_0_3_16  connected_order_arc_442  -15
    arc_0_3_16  out_degree_756  1
    arc_0_3_16  in_degree_827  1
    arc_0_3_16  original_T_including_depot_unload_837  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_441  1
    load_0_3_16  segment_load_conservation_760  1
    load_0_3_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_443  -30
    arc_0_4_0  depot_return_or_bypass_741  1
    arc_0_4_0  out_degree_763  1
    arc_0_4_0  original_T_including_depot_unload_837  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_443  1
    load_0_4_0  segment_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_444  -30
    arc_0_4_1  connected_order_arc_445  -15
    arc_0_4_1  in_degree_743  1
    arc_0_4_1  out_degree_763  1
    arc_0_4_1  original_T_including_depot_unload_837  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_444  1
    load_0_4_1  segment_load_conservation_746  -1
    load_0_4_1  segment_prefix_lb_747  1
    load_0_4_1  segment_prefix_ub_748  1
    load_0_4_1  segment_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_446  -30
    arc_0_4_2  connected_order_arc_447  -15
    arc_0_4_2  in_degree_750  1
    arc_0_4_2  out_degree_763  1
    arc_0_4_2  original_T_including_depot_unload_837  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_446  1
    load_0_4_2  segment_load_conservation_753  -1
    load_0_4_2  segment_prefix_lb_754  1
    load_0_4_2  segment_prefix_ub_755  1
    load_0_4_2  segment_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_448  -30
    arc_0_4_3  connected_order_arc_449  -15
    arc_0_4_3  in_degree_757  1
    arc_0_4_3  out_degree_763  1
    arc_0_4_3  original_T_including_depot_unload_837  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_448  1
    load_0_4_3  segment_load_conservation_760  -1
    load_0_4_3  segment_prefix_lb_761  1
    load_0_4_3  segment_prefix_ub_762  1
    load_0_4_3  segment_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_450  -30
    arc_0_4_5  connected_order_arc_451  -15
    arc_0_4_5  out_degree_763  1
    arc_0_4_5  in_degree_771  1
    arc_0_4_5  original_T_including_depot_unload_837  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_450  1
    load_0_4_5  segment_load_conservation_767  1
    load_0_4_5  segment_load_conservation_774  -1
    load_0_4_5  segment_prefix_lb_775  1
    load_0_4_5  segment_prefix_ub_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_452  -30
    arc_0_4_6  connected_order_arc_453  -15
    arc_0_4_6  out_degree_763  1
    arc_0_4_6  in_degree_778  1
    arc_0_4_6  original_T_including_depot_unload_837  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_452  1
    load_0_4_6  segment_load_conservation_767  1
    load_0_4_6  segment_load_conservation_781  -1
    load_0_4_6  segment_prefix_lb_782  1
    load_0_4_6  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_454  -30
    arc_0_4_9  connected_order_arc_455  -15
    arc_0_4_9  out_degree_763  1
    arc_0_4_9  in_degree_785  1
    arc_0_4_9  original_T_including_depot_unload_837  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_454  1
    load_0_4_9  segment_load_conservation_767  1
    load_0_4_9  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_456  -30
    arc_0_4_10  connected_order_arc_457  -15
    arc_0_4_10  out_degree_763  1
    arc_0_4_10  in_degree_791  1
    arc_0_4_10  original_T_including_depot_unload_837  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_456  1
    load_0_4_10  segment_load_conservation_767  1
    load_0_4_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_458  -30
    arc_0_4_11  connected_order_arc_459  -15
    arc_0_4_11  out_degree_763  1
    arc_0_4_11  in_degree_797  1
    arc_0_4_11  original_T_including_depot_unload_837  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_458  1
    load_0_4_11  segment_load_conservation_767  1
    load_0_4_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_460  -30
    arc_0_4_12  connected_order_arc_461  -15
    arc_0_4_12  out_degree_763  1
    arc_0_4_12  in_degree_803  1
    arc_0_4_12  original_T_including_depot_unload_837  5.2012288834852347e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_460  1
    load_0_4_12  segment_load_conservation_767  1
    load_0_4_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_462  -30
    arc_0_4_13  connected_order_arc_463  -15
    arc_0_4_13  out_degree_763  1
    arc_0_4_13  in_degree_809  1
    arc_0_4_13  original_T_including_depot_unload_837  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_462  1
    load_0_4_13  segment_load_conservation_767  1
    load_0_4_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_464  -30
    arc_0_4_14  connected_order_arc_465  -15
    arc_0_4_14  out_degree_763  1
    arc_0_4_14  in_degree_815  1
    arc_0_4_14  original_T_including_depot_unload_837  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_464  1
    load_0_4_14  segment_load_conservation_767  1
    load_0_4_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_466  -30
    arc_0_4_15  connected_order_arc_467  -15
    arc_0_4_15  out_degree_763  1
    arc_0_4_15  in_degree_821  1
    arc_0_4_15  original_T_including_depot_unload_837  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_466  1
    load_0_4_15  segment_load_conservation_767  1
    load_0_4_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_468  -30
    arc_0_4_16  connected_order_arc_469  -15
    arc_0_4_16  out_degree_763  1
    arc_0_4_16  in_degree_827  1
    arc_0_4_16  original_T_including_depot_unload_837  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_468  1
    load_0_4_16  segment_load_conservation_767  1
    load_0_4_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_470  -30
    arc_0_5_0  depot_return_or_bypass_741  1
    arc_0_5_0  out_degree_770  1
    arc_0_5_0  original_T_including_depot_unload_837  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_470  1
    load_0_5_0  segment_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_471  -30
    arc_0_5_1  connected_order_arc_472  -15
    arc_0_5_1  in_degree_743  1
    arc_0_5_1  out_degree_770  1
    arc_0_5_1  original_T_including_depot_unload_837  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_471  1
    load_0_5_1  segment_load_conservation_746  -1
    load_0_5_1  segment_prefix_lb_747  1
    load_0_5_1  segment_prefix_ub_748  1
    load_0_5_1  segment_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_473  -30
    arc_0_5_2  connected_order_arc_474  -15
    arc_0_5_2  in_degree_750  1
    arc_0_5_2  out_degree_770  1
    arc_0_5_2  original_T_including_depot_unload_837  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_473  1
    load_0_5_2  segment_load_conservation_753  -1
    load_0_5_2  segment_prefix_lb_754  1
    load_0_5_2  segment_prefix_ub_755  1
    load_0_5_2  segment_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_475  -30
    arc_0_5_3  connected_order_arc_476  -15
    arc_0_5_3  in_degree_757  1
    arc_0_5_3  out_degree_770  1
    arc_0_5_3  original_T_including_depot_unload_837  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_475  1
    load_0_5_3  segment_load_conservation_760  -1
    load_0_5_3  segment_prefix_lb_761  1
    load_0_5_3  segment_prefix_ub_762  1
    load_0_5_3  segment_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_477  -30
    arc_0_5_4  connected_order_arc_478  -15
    arc_0_5_4  in_degree_764  1
    arc_0_5_4  out_degree_770  1
    arc_0_5_4  original_T_including_depot_unload_837  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_477  1
    load_0_5_4  segment_load_conservation_767  -1
    load_0_5_4  segment_prefix_lb_768  1
    load_0_5_4  segment_prefix_ub_769  1
    load_0_5_4  segment_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_479  -30
    arc_0_5_6  connected_order_arc_480  -15
    arc_0_5_6  out_degree_770  1
    arc_0_5_6  in_degree_778  1
    arc_0_5_6  original_T_including_depot_unload_837  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_479  1
    load_0_5_6  segment_load_conservation_774  1
    load_0_5_6  segment_load_conservation_781  -1
    load_0_5_6  segment_prefix_lb_782  1
    load_0_5_6  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_481  -30
    arc_0_5_9  connected_order_arc_482  -15
    arc_0_5_9  out_degree_770  1
    arc_0_5_9  in_degree_785  1
    arc_0_5_9  original_T_including_depot_unload_837  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_481  1
    load_0_5_9  segment_load_conservation_774  1
    load_0_5_9  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_483  -30
    arc_0_5_10  connected_order_arc_484  -15
    arc_0_5_10  out_degree_770  1
    arc_0_5_10  in_degree_791  1
    arc_0_5_10  original_T_including_depot_unload_837  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_483  1
    load_0_5_10  segment_load_conservation_774  1
    load_0_5_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_485  -30
    arc_0_5_11  connected_order_arc_486  -15
    arc_0_5_11  out_degree_770  1
    arc_0_5_11  in_degree_797  1
    arc_0_5_11  original_T_including_depot_unload_837  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_485  1
    load_0_5_11  segment_load_conservation_774  1
    load_0_5_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_487  -30
    arc_0_5_12  connected_order_arc_488  -15
    arc_0_5_12  out_degree_770  1
    arc_0_5_12  in_degree_803  1
    arc_0_5_12  original_T_including_depot_unload_837  6.1372385697152924e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_487  1
    load_0_5_12  segment_load_conservation_774  1
    load_0_5_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_489  -30
    arc_0_5_13  connected_order_arc_490  -15
    arc_0_5_13  out_degree_770  1
    arc_0_5_13  in_degree_809  1
    arc_0_5_13  original_T_including_depot_unload_837  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_489  1
    load_0_5_13  segment_load_conservation_774  1
    load_0_5_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_491  -30
    arc_0_5_14  connected_order_arc_492  -15
    arc_0_5_14  out_degree_770  1
    arc_0_5_14  in_degree_815  1
    arc_0_5_14  original_T_including_depot_unload_837  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_491  1
    load_0_5_14  segment_load_conservation_774  1
    load_0_5_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_493  -30
    arc_0_5_15  connected_order_arc_494  -15
    arc_0_5_15  out_degree_770  1
    arc_0_5_15  in_degree_821  1
    arc_0_5_15  original_T_including_depot_unload_837  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_493  1
    load_0_5_15  segment_load_conservation_774  1
    load_0_5_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_495  -30
    arc_0_5_16  connected_order_arc_496  -15
    arc_0_5_16  out_degree_770  1
    arc_0_5_16  in_degree_827  1
    arc_0_5_16  original_T_including_depot_unload_837  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_495  1
    load_0_5_16  segment_load_conservation_774  1
    load_0_5_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_497  -30
    arc_0_6_0  depot_return_or_bypass_741  1
    arc_0_6_0  out_degree_777  1
    arc_0_6_0  original_T_including_depot_unload_837  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_497  1
    load_0_6_0  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_498  -30
    arc_0_6_1  connected_order_arc_499  -15
    arc_0_6_1  in_degree_743  1
    arc_0_6_1  out_degree_777  1
    arc_0_6_1  original_T_including_depot_unload_837  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_498  1
    load_0_6_1  segment_load_conservation_746  -1
    load_0_6_1  segment_prefix_lb_747  1
    load_0_6_1  segment_prefix_ub_748  1
    load_0_6_1  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_500  -30
    arc_0_6_2  connected_order_arc_501  -15
    arc_0_6_2  in_degree_750  1
    arc_0_6_2  out_degree_777  1
    arc_0_6_2  original_T_including_depot_unload_837  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_500  1
    load_0_6_2  segment_load_conservation_753  -1
    load_0_6_2  segment_prefix_lb_754  1
    load_0_6_2  segment_prefix_ub_755  1
    load_0_6_2  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_502  -30
    arc_0_6_3  connected_order_arc_503  -15
    arc_0_6_3  in_degree_757  1
    arc_0_6_3  out_degree_777  1
    arc_0_6_3  original_T_including_depot_unload_837  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_502  1
    load_0_6_3  segment_load_conservation_760  -1
    load_0_6_3  segment_prefix_lb_761  1
    load_0_6_3  segment_prefix_ub_762  1
    load_0_6_3  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_504  -30
    arc_0_6_4  connected_order_arc_505  -15
    arc_0_6_4  in_degree_764  1
    arc_0_6_4  out_degree_777  1
    arc_0_6_4  original_T_including_depot_unload_837  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_504  1
    load_0_6_4  segment_load_conservation_767  -1
    load_0_6_4  segment_prefix_lb_768  1
    load_0_6_4  segment_prefix_ub_769  1
    load_0_6_4  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_506  -30
    arc_0_6_5  connected_order_arc_507  -15
    arc_0_6_5  in_degree_771  1
    arc_0_6_5  out_degree_777  1
    arc_0_6_5  original_T_including_depot_unload_837  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_506  1
    load_0_6_5  segment_load_conservation_774  -1
    load_0_6_5  segment_prefix_lb_775  1
    load_0_6_5  segment_prefix_ub_776  1
    load_0_6_5  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_9  arc_capacity_508  -30
    arc_0_6_9  connected_order_arc_509  -15
    arc_0_6_9  out_degree_777  1
    arc_0_6_9  in_degree_785  1
    arc_0_6_9  original_T_including_depot_unload_837  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_9  arc_capacity_508  1
    load_0_6_9  segment_load_conservation_781  1
    load_0_6_9  free_load_conservation_789  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_10  arc_capacity_510  -30
    arc_0_6_10  connected_order_arc_511  -15
    arc_0_6_10  out_degree_777  1
    arc_0_6_10  in_degree_791  1
    arc_0_6_10  original_T_including_depot_unload_837  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_10  arc_capacity_510  1
    load_0_6_10  segment_load_conservation_781  1
    load_0_6_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_512  -30
    arc_0_6_11  connected_order_arc_513  -15
    arc_0_6_11  out_degree_777  1
    arc_0_6_11  in_degree_797  1
    arc_0_6_11  original_T_including_depot_unload_837  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_512  1
    load_0_6_11  segment_load_conservation_781  1
    load_0_6_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_514  -30
    arc_0_6_12  connected_order_arc_515  -15
    arc_0_6_12  out_degree_777  1
    arc_0_6_12  in_degree_803  1
    arc_0_6_12  original_T_including_depot_unload_837  839.738057629617
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_514  1
    load_0_6_12  segment_load_conservation_781  1
    load_0_6_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_516  -30
    arc_0_6_13  connected_order_arc_517  -15
    arc_0_6_13  out_degree_777  1
    arc_0_6_13  in_degree_809  1
    arc_0_6_13  original_T_including_depot_unload_837  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_516  1
    load_0_6_13  segment_load_conservation_781  1
    load_0_6_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_518  -30
    arc_0_6_14  connected_order_arc_519  -15
    arc_0_6_14  out_degree_777  1
    arc_0_6_14  in_degree_815  1
    arc_0_6_14  original_T_including_depot_unload_837  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_518  1
    load_0_6_14  segment_load_conservation_781  1
    load_0_6_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_520  -30
    arc_0_6_15  connected_order_arc_521  -15
    arc_0_6_15  out_degree_777  1
    arc_0_6_15  in_degree_821  1
    arc_0_6_15  original_T_including_depot_unload_837  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_520  1
    load_0_6_15  segment_load_conservation_781  1
    load_0_6_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_522  -30
    arc_0_6_16  connected_order_arc_523  -15
    arc_0_6_16  out_degree_777  1
    arc_0_6_16  in_degree_827  1
    arc_0_6_16  original_T_including_depot_unload_837  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_522  1
    load_0_6_16  segment_load_conservation_781  1
    load_0_6_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_524  -30
    arc_0_9_0  depot_return_or_bypass_741  1
    arc_0_9_0  out_degree_784  1
    arc_0_9_0  original_T_including_depot_unload_837  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_524  1
    load_0_9_0  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_525  -30
    arc_0_9_1  connected_order_arc_526  -15
    arc_0_9_1  in_degree_743  1
    arc_0_9_1  out_degree_784  1
    arc_0_9_1  original_T_including_depot_unload_837  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_525  1
    load_0_9_1  segment_load_conservation_746  -1
    load_0_9_1  segment_prefix_lb_747  1
    load_0_9_1  segment_prefix_ub_748  1
    load_0_9_1  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_527  -30
    arc_0_9_2  connected_order_arc_528  -15
    arc_0_9_2  in_degree_750  1
    arc_0_9_2  out_degree_784  1
    arc_0_9_2  original_T_including_depot_unload_837  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_527  1
    load_0_9_2  segment_load_conservation_753  -1
    load_0_9_2  segment_prefix_lb_754  1
    load_0_9_2  segment_prefix_ub_755  1
    load_0_9_2  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_529  -30
    arc_0_9_3  connected_order_arc_530  -15
    arc_0_9_3  in_degree_757  1
    arc_0_9_3  out_degree_784  1
    arc_0_9_3  original_T_including_depot_unload_837  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_529  1
    load_0_9_3  segment_load_conservation_760  -1
    load_0_9_3  segment_prefix_lb_761  1
    load_0_9_3  segment_prefix_ub_762  1
    load_0_9_3  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_531  -30
    arc_0_9_4  connected_order_arc_532  -15
    arc_0_9_4  in_degree_764  1
    arc_0_9_4  out_degree_784  1
    arc_0_9_4  original_T_including_depot_unload_837  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_531  1
    load_0_9_4  segment_load_conservation_767  -1
    load_0_9_4  segment_prefix_lb_768  1
    load_0_9_4  segment_prefix_ub_769  1
    load_0_9_4  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_533  -30
    arc_0_9_5  connected_order_arc_534  -15
    arc_0_9_5  in_degree_771  1
    arc_0_9_5  out_degree_784  1
    arc_0_9_5  original_T_including_depot_unload_837  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_533  1
    load_0_9_5  segment_load_conservation_774  -1
    load_0_9_5  segment_prefix_lb_775  1
    load_0_9_5  segment_prefix_ub_776  1
    load_0_9_5  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_6  arc_capacity_535  -30
    arc_0_9_6  connected_order_arc_536  -15
    arc_0_9_6  in_degree_778  1
    arc_0_9_6  out_degree_784  1
    arc_0_9_6  original_T_including_depot_unload_837  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_6  arc_capacity_535  1
    load_0_9_6  segment_load_conservation_781  -1
    load_0_9_6  segment_prefix_lb_782  1
    load_0_9_6  segment_prefix_ub_783  1
    load_0_9_6  free_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_537  -30
    arc_0_9_10  connected_order_arc_538  -15
    arc_0_9_10  out_degree_784  1
    arc_0_9_10  in_degree_791  1
    arc_0_9_10  original_T_including_depot_unload_837  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_537  1
    load_0_9_10  free_load_conservation_789  1
    load_0_9_10  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_539  -30
    arc_0_9_11  connected_order_arc_540  -15
    arc_0_9_11  out_degree_784  1
    arc_0_9_11  in_degree_797  1
    arc_0_9_11  original_T_including_depot_unload_837  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_539  1
    load_0_9_11  free_load_conservation_789  1
    load_0_9_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_541  -30
    arc_0_9_12  connected_order_arc_542  -15
    arc_0_9_12  out_degree_784  1
    arc_0_9_12  in_degree_803  1
    arc_0_9_12  original_T_including_depot_unload_837  3.0084412628525462e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_541  1
    load_0_9_12  free_load_conservation_789  1
    load_0_9_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_543  -30
    arc_0_9_13  connected_order_arc_544  -15
    arc_0_9_13  out_degree_784  1
    arc_0_9_13  in_degree_809  1
    arc_0_9_13  original_T_including_depot_unload_837  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_543  1
    load_0_9_13  free_load_conservation_789  1
    load_0_9_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_545  -30
    arc_0_9_14  connected_order_arc_546  -15
    arc_0_9_14  out_degree_784  1
    arc_0_9_14  in_degree_815  1
    arc_0_9_14  original_T_including_depot_unload_837  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_545  1
    load_0_9_14  free_load_conservation_789  1
    load_0_9_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_547  -30
    arc_0_9_15  connected_order_arc_548  -15
    arc_0_9_15  out_degree_784  1
    arc_0_9_15  in_degree_821  1
    arc_0_9_15  original_T_including_depot_unload_837  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_547  1
    load_0_9_15  free_load_conservation_789  1
    load_0_9_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_16  arc_capacity_549  -30
    arc_0_9_16  connected_order_arc_550  -15
    arc_0_9_16  out_degree_784  1
    arc_0_9_16  in_degree_827  1
    arc_0_9_16  original_T_including_depot_unload_837  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_16  arc_capacity_549  1
    load_0_9_16  free_load_conservation_789  1
    load_0_9_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_551  -30
    arc_0_10_0  depot_return_or_bypass_741  1
    arc_0_10_0  out_degree_790  1
    arc_0_10_0  original_T_including_depot_unload_837  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_551  1
    load_0_10_0  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_552  -30
    arc_0_10_1  connected_order_arc_553  -15
    arc_0_10_1  in_degree_743  1
    arc_0_10_1  out_degree_790  1
    arc_0_10_1  original_T_including_depot_unload_837  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_552  1
    load_0_10_1  segment_load_conservation_746  -1
    load_0_10_1  segment_prefix_lb_747  1
    load_0_10_1  segment_prefix_ub_748  1
    load_0_10_1  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_554  -30
    arc_0_10_2  connected_order_arc_555  -15
    arc_0_10_2  in_degree_750  1
    arc_0_10_2  out_degree_790  1
    arc_0_10_2  original_T_including_depot_unload_837  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_554  1
    load_0_10_2  segment_load_conservation_753  -1
    load_0_10_2  segment_prefix_lb_754  1
    load_0_10_2  segment_prefix_ub_755  1
    load_0_10_2  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_556  -30
    arc_0_10_3  connected_order_arc_557  -15
    arc_0_10_3  in_degree_757  1
    arc_0_10_3  out_degree_790  1
    arc_0_10_3  original_T_including_depot_unload_837  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_556  1
    load_0_10_3  segment_load_conservation_760  -1
    load_0_10_3  segment_prefix_lb_761  1
    load_0_10_3  segment_prefix_ub_762  1
    load_0_10_3  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_558  -30
    arc_0_10_4  connected_order_arc_559  -15
    arc_0_10_4  in_degree_764  1
    arc_0_10_4  out_degree_790  1
    arc_0_10_4  original_T_including_depot_unload_837  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_558  1
    load_0_10_4  segment_load_conservation_767  -1
    load_0_10_4  segment_prefix_lb_768  1
    load_0_10_4  segment_prefix_ub_769  1
    load_0_10_4  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_560  -30
    arc_0_10_5  connected_order_arc_561  -15
    arc_0_10_5  in_degree_771  1
    arc_0_10_5  out_degree_790  1
    arc_0_10_5  original_T_including_depot_unload_837  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_560  1
    load_0_10_5  segment_load_conservation_774  -1
    load_0_10_5  segment_prefix_lb_775  1
    load_0_10_5  segment_prefix_ub_776  1
    load_0_10_5  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_6  arc_capacity_562  -30
    arc_0_10_6  connected_order_arc_563  -15
    arc_0_10_6  in_degree_778  1
    arc_0_10_6  out_degree_790  1
    arc_0_10_6  original_T_including_depot_unload_837  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_6  arc_capacity_562  1
    load_0_10_6  segment_load_conservation_781  -1
    load_0_10_6  segment_prefix_lb_782  1
    load_0_10_6  segment_prefix_ub_783  1
    load_0_10_6  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_564  -30
    arc_0_10_9  connected_order_arc_565  -15
    arc_0_10_9  in_degree_785  1
    arc_0_10_9  out_degree_790  1
    arc_0_10_9  original_T_including_depot_unload_837  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_564  1
    load_0_10_9  free_load_conservation_789  -1
    load_0_10_9  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_566  -30
    arc_0_10_11  connected_order_arc_567  -15
    arc_0_10_11  out_degree_790  1
    arc_0_10_11  in_degree_797  1
    arc_0_10_11  original_T_including_depot_unload_837  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_566  1
    load_0_10_11  free_load_conservation_795  1
    load_0_10_11  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_568  -30
    arc_0_10_12  connected_order_arc_569  -15
    arc_0_10_12  out_degree_790  1
    arc_0_10_12  in_degree_803  1
    arc_0_10_12  original_T_including_depot_unload_837  3.4611011743974603e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_568  1
    load_0_10_12  free_load_conservation_795  1
    load_0_10_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_570  -30
    arc_0_10_13  connected_order_arc_571  -15
    arc_0_10_13  out_degree_790  1
    arc_0_10_13  in_degree_809  1
    arc_0_10_13  original_T_including_depot_unload_837  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_570  1
    load_0_10_13  free_load_conservation_795  1
    load_0_10_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_572  -30
    arc_0_10_14  connected_order_arc_573  -15
    arc_0_10_14  out_degree_790  1
    arc_0_10_14  in_degree_815  1
    arc_0_10_14  original_T_including_depot_unload_837  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_572  1
    load_0_10_14  free_load_conservation_795  1
    load_0_10_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_574  -30
    arc_0_10_15  connected_order_arc_575  -15
    arc_0_10_15  out_degree_790  1
    arc_0_10_15  in_degree_821  1
    arc_0_10_15  original_T_including_depot_unload_837  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_574  1
    load_0_10_15  free_load_conservation_795  1
    load_0_10_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_16  arc_capacity_576  -30
    arc_0_10_16  connected_order_arc_577  -15
    arc_0_10_16  out_degree_790  1
    arc_0_10_16  in_degree_827  1
    arc_0_10_16  original_T_including_depot_unload_837  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_16  arc_capacity_576  1
    load_0_10_16  free_load_conservation_795  1
    load_0_10_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_578  -30
    arc_0_11_0  depot_return_or_bypass_741  1
    arc_0_11_0  out_degree_796  1
    arc_0_11_0  original_T_including_depot_unload_837  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_578  1
    load_0_11_0  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_579  -30
    arc_0_11_1  connected_order_arc_580  -15
    arc_0_11_1  in_degree_743  1
    arc_0_11_1  out_degree_796  1
    arc_0_11_1  original_T_including_depot_unload_837  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_579  1
    load_0_11_1  segment_load_conservation_746  -1
    load_0_11_1  segment_prefix_lb_747  1
    load_0_11_1  segment_prefix_ub_748  1
    load_0_11_1  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_581  -30
    arc_0_11_2  connected_order_arc_582  -15
    arc_0_11_2  in_degree_750  1
    arc_0_11_2  out_degree_796  1
    arc_0_11_2  original_T_including_depot_unload_837  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_581  1
    load_0_11_2  segment_load_conservation_753  -1
    load_0_11_2  segment_prefix_lb_754  1
    load_0_11_2  segment_prefix_ub_755  1
    load_0_11_2  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_583  -30
    arc_0_11_3  connected_order_arc_584  -15
    arc_0_11_3  in_degree_757  1
    arc_0_11_3  out_degree_796  1
    arc_0_11_3  original_T_including_depot_unload_837  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_583  1
    load_0_11_3  segment_load_conservation_760  -1
    load_0_11_3  segment_prefix_lb_761  1
    load_0_11_3  segment_prefix_ub_762  1
    load_0_11_3  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_585  -30
    arc_0_11_4  connected_order_arc_586  -15
    arc_0_11_4  in_degree_764  1
    arc_0_11_4  out_degree_796  1
    arc_0_11_4  original_T_including_depot_unload_837  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_585  1
    load_0_11_4  segment_load_conservation_767  -1
    load_0_11_4  segment_prefix_lb_768  1
    load_0_11_4  segment_prefix_ub_769  1
    load_0_11_4  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_587  -30
    arc_0_11_5  connected_order_arc_588  -15
    arc_0_11_5  in_degree_771  1
    arc_0_11_5  out_degree_796  1
    arc_0_11_5  original_T_including_depot_unload_837  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_587  1
    load_0_11_5  segment_load_conservation_774  -1
    load_0_11_5  segment_prefix_lb_775  1
    load_0_11_5  segment_prefix_ub_776  1
    load_0_11_5  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_589  -30
    arc_0_11_6  connected_order_arc_590  -15
    arc_0_11_6  in_degree_778  1
    arc_0_11_6  out_degree_796  1
    arc_0_11_6  original_T_including_depot_unload_837  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_589  1
    load_0_11_6  segment_load_conservation_781  -1
    load_0_11_6  segment_prefix_lb_782  1
    load_0_11_6  segment_prefix_ub_783  1
    load_0_11_6  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_591  -30
    arc_0_11_9  connected_order_arc_592  -15
    arc_0_11_9  in_degree_785  1
    arc_0_11_9  out_degree_796  1
    arc_0_11_9  original_T_including_depot_unload_837  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_591  1
    load_0_11_9  free_load_conservation_789  -1
    load_0_11_9  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_593  -30
    arc_0_11_10  connected_order_arc_594  -15
    arc_0_11_10  in_degree_791  1
    arc_0_11_10  out_degree_796  1
    arc_0_11_10  original_T_including_depot_unload_837  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_593  1
    load_0_11_10  free_load_conservation_795  -1
    load_0_11_10  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_595  -30
    arc_0_11_12  connected_order_arc_596  -15
    arc_0_11_12  out_degree_796  1
    arc_0_11_12  in_degree_803  1
    arc_0_11_12  original_T_including_depot_unload_837  3.3982588084805943e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_595  1
    load_0_11_12  free_load_conservation_801  1
    load_0_11_12  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_597  -30
    arc_0_11_13  connected_order_arc_598  -15
    arc_0_11_13  out_degree_796  1
    arc_0_11_13  in_degree_809  1
    arc_0_11_13  original_T_including_depot_unload_837  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_597  1
    load_0_11_13  free_load_conservation_801  1
    load_0_11_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_599  -30
    arc_0_11_14  connected_order_arc_600  -15
    arc_0_11_14  out_degree_796  1
    arc_0_11_14  in_degree_815  1
    arc_0_11_14  original_T_including_depot_unload_837  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_599  1
    load_0_11_14  free_load_conservation_801  1
    load_0_11_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_601  -30
    arc_0_11_15  connected_order_arc_602  -15
    arc_0_11_15  out_degree_796  1
    arc_0_11_15  in_degree_821  1
    arc_0_11_15  original_T_including_depot_unload_837  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_601  1
    load_0_11_15  free_load_conservation_801  1
    load_0_11_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_603  -30
    arc_0_11_16  connected_order_arc_604  -15
    arc_0_11_16  out_degree_796  1
    arc_0_11_16  in_degree_827  1
    arc_0_11_16  original_T_including_depot_unload_837  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_603  1
    load_0_11_16  free_load_conservation_801  1
    load_0_11_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_605  -30
    arc_0_12_0  depot_return_or_bypass_741  1
    arc_0_12_0  out_degree_802  1
    arc_0_12_0  original_T_including_depot_unload_837  1.1810298132524642e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_605  1
    load_0_12_0  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_606  -30
    arc_0_12_1  connected_order_arc_607  -15
    arc_0_12_1  in_degree_743  1
    arc_0_12_1  out_degree_802  1
    arc_0_12_1  original_T_including_depot_unload_837  1.3431004957633038e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_606  1
    load_0_12_1  segment_load_conservation_746  -1
    load_0_12_1  segment_prefix_lb_747  1
    load_0_12_1  segment_prefix_ub_748  1
    load_0_12_1  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_608  -30
    arc_0_12_2  connected_order_arc_609  -15
    arc_0_12_2  in_degree_750  1
    arc_0_12_2  out_degree_802  1
    arc_0_12_2  original_T_including_depot_unload_837  6.5335687537758054e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_608  1
    load_0_12_2  segment_load_conservation_753  -1
    load_0_12_2  segment_prefix_lb_754  1
    load_0_12_2  segment_prefix_ub_755  1
    load_0_12_2  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_610  -30
    arc_0_12_3  connected_order_arc_611  -15
    arc_0_12_3  in_degree_757  1
    arc_0_12_3  out_degree_802  1
    arc_0_12_3  original_T_including_depot_unload_837  7.1112286974366077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_610  1
    load_0_12_3  segment_load_conservation_760  -1
    load_0_12_3  segment_prefix_lb_761  1
    load_0_12_3  segment_prefix_ub_762  1
    load_0_12_3  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_612  -30
    arc_0_12_4  connected_order_arc_613  -15
    arc_0_12_4  in_degree_764  1
    arc_0_12_4  out_degree_802  1
    arc_0_12_4  original_T_including_depot_unload_837  5.2012288834852347e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_612  1
    load_0_12_4  segment_load_conservation_767  -1
    load_0_12_4  segment_prefix_lb_768  1
    load_0_12_4  segment_prefix_ub_769  1
    load_0_12_4  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_614  -30
    arc_0_12_5  connected_order_arc_615  -15
    arc_0_12_5  in_degree_771  1
    arc_0_12_5  out_degree_802  1
    arc_0_12_5  original_T_including_depot_unload_837  6.1372385697152924e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_614  1
    load_0_12_5  segment_load_conservation_774  -1
    load_0_12_5  segment_prefix_lb_775  1
    load_0_12_5  segment_prefix_ub_776  1
    load_0_12_5  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_616  -30
    arc_0_12_6  connected_order_arc_617  -15
    arc_0_12_6  in_degree_778  1
    arc_0_12_6  out_degree_802  1
    arc_0_12_6  original_T_including_depot_unload_837  839.738057629617
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_616  1
    load_0_12_6  segment_load_conservation_781  -1
    load_0_12_6  segment_prefix_lb_782  1
    load_0_12_6  segment_prefix_ub_783  1
    load_0_12_6  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_618  -30
    arc_0_12_9  connected_order_arc_619  -15
    arc_0_12_9  in_degree_785  1
    arc_0_12_9  out_degree_802  1
    arc_0_12_9  original_T_including_depot_unload_837  3.0084412628525462e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_618  1
    load_0_12_9  free_load_conservation_789  -1
    load_0_12_9  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_620  -30
    arc_0_12_10  connected_order_arc_621  -15
    arc_0_12_10  in_degree_791  1
    arc_0_12_10  out_degree_802  1
    arc_0_12_10  original_T_including_depot_unload_837  3.4611011743974603e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_620  1
    load_0_12_10  free_load_conservation_795  -1
    load_0_12_10  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_622  -30
    arc_0_12_11  connected_order_arc_623  -15
    arc_0_12_11  in_degree_797  1
    arc_0_12_11  out_degree_802  1
    arc_0_12_11  original_T_including_depot_unload_837  3.3982588084805943e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_622  1
    load_0_12_11  free_load_conservation_801  -1
    load_0_12_11  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_624  -30
    arc_0_12_13  connected_order_arc_625  -15
    arc_0_12_13  out_degree_802  1
    arc_0_12_13  in_degree_809  1
    arc_0_12_13  original_T_including_depot_unload_837  2.3944588415225576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_624  1
    load_0_12_13  free_load_conservation_807  1
    load_0_12_13  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_626  -30
    arc_0_12_14  connected_order_arc_627  -15
    arc_0_12_14  out_degree_802  1
    arc_0_12_14  in_degree_815  1
    arc_0_12_14  original_T_including_depot_unload_837  5.4851753823626359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_626  1
    load_0_12_14  free_load_conservation_807  1
    load_0_12_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_628  -30
    arc_0_12_15  connected_order_arc_629  -15
    arc_0_12_15  out_degree_802  1
    arc_0_12_15  in_degree_821  1
    arc_0_12_15  original_T_including_depot_unload_837  7.7442375831627771e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_628  1
    load_0_12_15  free_load_conservation_807  1
    load_0_12_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_630  -30
    arc_0_12_16  connected_order_arc_631  -15
    arc_0_12_16  out_degree_802  1
    arc_0_12_16  in_degree_827  1
    arc_0_12_16  original_T_including_depot_unload_837  6.2572113135330244e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_630  1
    load_0_12_16  free_load_conservation_807  1
    load_0_12_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_632  -30
    arc_0_13_0  depot_return_or_bypass_741  1
    arc_0_13_0  out_degree_808  1
    arc_0_13_0  original_T_including_depot_unload_837  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_632  1
    load_0_13_0  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_633  -30
    arc_0_13_1  connected_order_arc_634  -15
    arc_0_13_1  in_degree_743  1
    arc_0_13_1  out_degree_808  1
    arc_0_13_1  original_T_including_depot_unload_837  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_633  1
    load_0_13_1  segment_load_conservation_746  -1
    load_0_13_1  segment_prefix_lb_747  1
    load_0_13_1  segment_prefix_ub_748  1
    load_0_13_1  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_635  -30
    arc_0_13_2  connected_order_arc_636  -15
    arc_0_13_2  in_degree_750  1
    arc_0_13_2  out_degree_808  1
    arc_0_13_2  original_T_including_depot_unload_837  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_635  1
    load_0_13_2  segment_load_conservation_753  -1
    load_0_13_2  segment_prefix_lb_754  1
    load_0_13_2  segment_prefix_ub_755  1
    load_0_13_2  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_637  -30
    arc_0_13_3  connected_order_arc_638  -15
    arc_0_13_3  in_degree_757  1
    arc_0_13_3  out_degree_808  1
    arc_0_13_3  original_T_including_depot_unload_837  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_637  1
    load_0_13_3  segment_load_conservation_760  -1
    load_0_13_3  segment_prefix_lb_761  1
    load_0_13_3  segment_prefix_ub_762  1
    load_0_13_3  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_639  -30
    arc_0_13_4  connected_order_arc_640  -15
    arc_0_13_4  in_degree_764  1
    arc_0_13_4  out_degree_808  1
    arc_0_13_4  original_T_including_depot_unload_837  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_639  1
    load_0_13_4  segment_load_conservation_767  -1
    load_0_13_4  segment_prefix_lb_768  1
    load_0_13_4  segment_prefix_ub_769  1
    load_0_13_4  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_641  -30
    arc_0_13_5  connected_order_arc_642  -15
    arc_0_13_5  in_degree_771  1
    arc_0_13_5  out_degree_808  1
    arc_0_13_5  original_T_including_depot_unload_837  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_641  1
    load_0_13_5  segment_load_conservation_774  -1
    load_0_13_5  segment_prefix_lb_775  1
    load_0_13_5  segment_prefix_ub_776  1
    load_0_13_5  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_643  -30
    arc_0_13_6  connected_order_arc_644  -15
    arc_0_13_6  in_degree_778  1
    arc_0_13_6  out_degree_808  1
    arc_0_13_6  original_T_including_depot_unload_837  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_643  1
    load_0_13_6  segment_load_conservation_781  -1
    load_0_13_6  segment_prefix_lb_782  1
    load_0_13_6  segment_prefix_ub_783  1
    load_0_13_6  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_645  -30
    arc_0_13_9  connected_order_arc_646  -15
    arc_0_13_9  in_degree_785  1
    arc_0_13_9  out_degree_808  1
    arc_0_13_9  original_T_including_depot_unload_837  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_645  1
    load_0_13_9  free_load_conservation_789  -1
    load_0_13_9  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_647  -30
    arc_0_13_10  connected_order_arc_648  -15
    arc_0_13_10  in_degree_791  1
    arc_0_13_10  out_degree_808  1
    arc_0_13_10  original_T_including_depot_unload_837  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_647  1
    load_0_13_10  free_load_conservation_795  -1
    load_0_13_10  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_649  -30
    arc_0_13_11  connected_order_arc_650  -15
    arc_0_13_11  in_degree_797  1
    arc_0_13_11  out_degree_808  1
    arc_0_13_11  original_T_including_depot_unload_837  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_649  1
    load_0_13_11  free_load_conservation_801  -1
    load_0_13_11  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_651  -30
    arc_0_13_12  connected_order_arc_652  -15
    arc_0_13_12  in_degree_803  1
    arc_0_13_12  out_degree_808  1
    arc_0_13_12  original_T_including_depot_unload_837  2.3944588415225576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_651  1
    load_0_13_12  free_load_conservation_807  -1
    load_0_13_12  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_653  -30
    arc_0_13_14  connected_order_arc_654  -15
    arc_0_13_14  out_degree_808  1
    arc_0_13_14  in_degree_815  1
    arc_0_13_14  original_T_including_depot_unload_837  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_653  1
    load_0_13_14  free_load_conservation_813  1
    load_0_13_14  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_655  -30
    arc_0_13_15  connected_order_arc_656  -15
    arc_0_13_15  out_degree_808  1
    arc_0_13_15  in_degree_821  1
    arc_0_13_15  original_T_including_depot_unload_837  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_655  1
    load_0_13_15  free_load_conservation_813  1
    load_0_13_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_657  -30
    arc_0_13_16  connected_order_arc_658  -15
    arc_0_13_16  out_degree_808  1
    arc_0_13_16  in_degree_827  1
    arc_0_13_16  original_T_including_depot_unload_837  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_657  1
    load_0_13_16  free_load_conservation_813  1
    load_0_13_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_659  -30
    arc_0_14_0  depot_return_or_bypass_741  1
    arc_0_14_0  out_degree_814  1
    arc_0_14_0  original_T_including_depot_unload_837  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_659  1
    load_0_14_0  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_660  -30
    arc_0_14_1  connected_order_arc_661  -15
    arc_0_14_1  in_degree_743  1
    arc_0_14_1  out_degree_814  1
    arc_0_14_1  original_T_including_depot_unload_837  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_660  1
    load_0_14_1  segment_load_conservation_746  -1
    load_0_14_1  segment_prefix_lb_747  1
    load_0_14_1  segment_prefix_ub_748  1
    load_0_14_1  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_662  -30
    arc_0_14_2  connected_order_arc_663  -15
    arc_0_14_2  in_degree_750  1
    arc_0_14_2  out_degree_814  1
    arc_0_14_2  original_T_including_depot_unload_837  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_662  1
    load_0_14_2  segment_load_conservation_753  -1
    load_0_14_2  segment_prefix_lb_754  1
    load_0_14_2  segment_prefix_ub_755  1
    load_0_14_2  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_664  -30
    arc_0_14_3  connected_order_arc_665  -15
    arc_0_14_3  in_degree_757  1
    arc_0_14_3  out_degree_814  1
    arc_0_14_3  original_T_including_depot_unload_837  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_664  1
    load_0_14_3  segment_load_conservation_760  -1
    load_0_14_3  segment_prefix_lb_761  1
    load_0_14_3  segment_prefix_ub_762  1
    load_0_14_3  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_666  -30
    arc_0_14_4  connected_order_arc_667  -15
    arc_0_14_4  in_degree_764  1
    arc_0_14_4  out_degree_814  1
    arc_0_14_4  original_T_including_depot_unload_837  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_666  1
    load_0_14_4  segment_load_conservation_767  -1
    load_0_14_4  segment_prefix_lb_768  1
    load_0_14_4  segment_prefix_ub_769  1
    load_0_14_4  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_668  -30
    arc_0_14_5  connected_order_arc_669  -15
    arc_0_14_5  in_degree_771  1
    arc_0_14_5  out_degree_814  1
    arc_0_14_5  original_T_including_depot_unload_837  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_668  1
    load_0_14_5  segment_load_conservation_774  -1
    load_0_14_5  segment_prefix_lb_775  1
    load_0_14_5  segment_prefix_ub_776  1
    load_0_14_5  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_670  -30
    arc_0_14_6  connected_order_arc_671  -15
    arc_0_14_6  in_degree_778  1
    arc_0_14_6  out_degree_814  1
    arc_0_14_6  original_T_including_depot_unload_837  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_670  1
    load_0_14_6  segment_load_conservation_781  -1
    load_0_14_6  segment_prefix_lb_782  1
    load_0_14_6  segment_prefix_ub_783  1
    load_0_14_6  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_672  -30
    arc_0_14_9  connected_order_arc_673  -15
    arc_0_14_9  in_degree_785  1
    arc_0_14_9  out_degree_814  1
    arc_0_14_9  original_T_including_depot_unload_837  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_672  1
    load_0_14_9  free_load_conservation_789  -1
    load_0_14_9  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_674  -30
    arc_0_14_10  connected_order_arc_675  -15
    arc_0_14_10  in_degree_791  1
    arc_0_14_10  out_degree_814  1
    arc_0_14_10  original_T_including_depot_unload_837  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_674  1
    load_0_14_10  free_load_conservation_795  -1
    load_0_14_10  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_676  -30
    arc_0_14_11  connected_order_arc_677  -15
    arc_0_14_11  in_degree_797  1
    arc_0_14_11  out_degree_814  1
    arc_0_14_11  original_T_including_depot_unload_837  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_676  1
    load_0_14_11  free_load_conservation_801  -1
    load_0_14_11  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_678  -30
    arc_0_14_12  connected_order_arc_679  -15
    arc_0_14_12  in_degree_803  1
    arc_0_14_12  out_degree_814  1
    arc_0_14_12  original_T_including_depot_unload_837  5.4851753823626359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_678  1
    load_0_14_12  free_load_conservation_807  -1
    load_0_14_12  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_680  -30
    arc_0_14_13  connected_order_arc_681  -15
    arc_0_14_13  in_degree_809  1
    arc_0_14_13  out_degree_814  1
    arc_0_14_13  original_T_including_depot_unload_837  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_680  1
    load_0_14_13  free_load_conservation_813  -1
    load_0_14_13  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_682  -30
    arc_0_14_15  connected_order_arc_683  -15
    arc_0_14_15  out_degree_814  1
    arc_0_14_15  in_degree_821  1
    arc_0_14_15  original_T_including_depot_unload_837  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_682  1
    load_0_14_15  free_load_conservation_819  1
    load_0_14_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_684  -30
    arc_0_14_16  connected_order_arc_685  -15
    arc_0_14_16  out_degree_814  1
    arc_0_14_16  in_degree_827  1
    arc_0_14_16  original_T_including_depot_unload_837  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_684  1
    load_0_14_16  free_load_conservation_819  1
    load_0_14_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_686  -30
    arc_0_15_0  depot_return_or_bypass_741  1
    arc_0_15_0  out_degree_820  1
    arc_0_15_0  original_T_including_depot_unload_837  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_686  1
    load_0_15_0  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_687  -30
    arc_0_15_1  connected_order_arc_688  -15
    arc_0_15_1  in_degree_743  1
    arc_0_15_1  out_degree_820  1
    arc_0_15_1  original_T_including_depot_unload_837  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_687  1
    load_0_15_1  segment_load_conservation_746  -1
    load_0_15_1  segment_prefix_lb_747  1
    load_0_15_1  segment_prefix_ub_748  1
    load_0_15_1  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_689  -30
    arc_0_15_2  connected_order_arc_690  -15
    arc_0_15_2  in_degree_750  1
    arc_0_15_2  out_degree_820  1
    arc_0_15_2  original_T_including_depot_unload_837  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_689  1
    load_0_15_2  segment_load_conservation_753  -1
    load_0_15_2  segment_prefix_lb_754  1
    load_0_15_2  segment_prefix_ub_755  1
    load_0_15_2  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_691  -30
    arc_0_15_3  connected_order_arc_692  -15
    arc_0_15_3  in_degree_757  1
    arc_0_15_3  out_degree_820  1
    arc_0_15_3  original_T_including_depot_unload_837  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_691  1
    load_0_15_3  segment_load_conservation_760  -1
    load_0_15_3  segment_prefix_lb_761  1
    load_0_15_3  segment_prefix_ub_762  1
    load_0_15_3  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_693  -30
    arc_0_15_4  connected_order_arc_694  -15
    arc_0_15_4  in_degree_764  1
    arc_0_15_4  out_degree_820  1
    arc_0_15_4  original_T_including_depot_unload_837  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_693  1
    load_0_15_4  segment_load_conservation_767  -1
    load_0_15_4  segment_prefix_lb_768  1
    load_0_15_4  segment_prefix_ub_769  1
    load_0_15_4  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_695  -30
    arc_0_15_5  connected_order_arc_696  -15
    arc_0_15_5  in_degree_771  1
    arc_0_15_5  out_degree_820  1
    arc_0_15_5  original_T_including_depot_unload_837  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_695  1
    load_0_15_5  segment_load_conservation_774  -1
    load_0_15_5  segment_prefix_lb_775  1
    load_0_15_5  segment_prefix_ub_776  1
    load_0_15_5  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_697  -30
    arc_0_15_6  connected_order_arc_698  -15
    arc_0_15_6  in_degree_778  1
    arc_0_15_6  out_degree_820  1
    arc_0_15_6  original_T_including_depot_unload_837  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_697  1
    load_0_15_6  segment_load_conservation_781  -1
    load_0_15_6  segment_prefix_lb_782  1
    load_0_15_6  segment_prefix_ub_783  1
    load_0_15_6  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_699  -30
    arc_0_15_9  connected_order_arc_700  -15
    arc_0_15_9  in_degree_785  1
    arc_0_15_9  out_degree_820  1
    arc_0_15_9  original_T_including_depot_unload_837  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_699  1
    load_0_15_9  free_load_conservation_789  -1
    load_0_15_9  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_701  -30
    arc_0_15_10  connected_order_arc_702  -15
    arc_0_15_10  in_degree_791  1
    arc_0_15_10  out_degree_820  1
    arc_0_15_10  original_T_including_depot_unload_837  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_701  1
    load_0_15_10  free_load_conservation_795  -1
    load_0_15_10  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_703  -30
    arc_0_15_11  connected_order_arc_704  -15
    arc_0_15_11  in_degree_797  1
    arc_0_15_11  out_degree_820  1
    arc_0_15_11  original_T_including_depot_unload_837  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_703  1
    load_0_15_11  free_load_conservation_801  -1
    load_0_15_11  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_705  -30
    arc_0_15_12  connected_order_arc_706  -15
    arc_0_15_12  in_degree_803  1
    arc_0_15_12  out_degree_820  1
    arc_0_15_12  original_T_including_depot_unload_837  7.7442375831627771e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_705  1
    load_0_15_12  free_load_conservation_807  -1
    load_0_15_12  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_707  -30
    arc_0_15_13  connected_order_arc_708  -15
    arc_0_15_13  in_degree_809  1
    arc_0_15_13  out_degree_820  1
    arc_0_15_13  original_T_including_depot_unload_837  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_707  1
    load_0_15_13  free_load_conservation_813  -1
    load_0_15_13  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_709  -30
    arc_0_15_14  connected_order_arc_710  -15
    arc_0_15_14  in_degree_815  1
    arc_0_15_14  out_degree_820  1
    arc_0_15_14  original_T_including_depot_unload_837  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_709  1
    load_0_15_14  free_load_conservation_819  -1
    load_0_15_14  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_711  -30
    arc_0_15_16  connected_order_arc_712  -15
    arc_0_15_16  out_degree_820  1
    arc_0_15_16  in_degree_827  1
    arc_0_15_16  original_T_including_depot_unload_837  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_711  1
    load_0_15_16  free_load_conservation_825  1
    load_0_15_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_713  -30
    arc_0_16_0  depot_return_or_bypass_741  1
    arc_0_16_0  out_degree_826  1
    arc_0_16_0  original_T_including_depot_unload_837  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_713  1
    load_0_16_0  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_714  -30
    arc_0_16_1  connected_order_arc_715  -15
    arc_0_16_1  in_degree_743  1
    arc_0_16_1  out_degree_826  1
    arc_0_16_1  original_T_including_depot_unload_837  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_714  1
    load_0_16_1  segment_load_conservation_746  -1
    load_0_16_1  segment_prefix_lb_747  1
    load_0_16_1  segment_prefix_ub_748  1
    load_0_16_1  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_716  -30
    arc_0_16_2  connected_order_arc_717  -15
    arc_0_16_2  in_degree_750  1
    arc_0_16_2  out_degree_826  1
    arc_0_16_2  original_T_including_depot_unload_837  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_716  1
    load_0_16_2  segment_load_conservation_753  -1
    load_0_16_2  segment_prefix_lb_754  1
    load_0_16_2  segment_prefix_ub_755  1
    load_0_16_2  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_718  -30
    arc_0_16_3  connected_order_arc_719  -15
    arc_0_16_3  in_degree_757  1
    arc_0_16_3  out_degree_826  1
    arc_0_16_3  original_T_including_depot_unload_837  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_718  1
    load_0_16_3  segment_load_conservation_760  -1
    load_0_16_3  segment_prefix_lb_761  1
    load_0_16_3  segment_prefix_ub_762  1
    load_0_16_3  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_720  -30
    arc_0_16_4  connected_order_arc_721  -15
    arc_0_16_4  in_degree_764  1
    arc_0_16_4  out_degree_826  1
    arc_0_16_4  original_T_including_depot_unload_837  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_720  1
    load_0_16_4  segment_load_conservation_767  -1
    load_0_16_4  segment_prefix_lb_768  1
    load_0_16_4  segment_prefix_ub_769  1
    load_0_16_4  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_722  -30
    arc_0_16_5  connected_order_arc_723  -15
    arc_0_16_5  in_degree_771  1
    arc_0_16_5  out_degree_826  1
    arc_0_16_5  original_T_including_depot_unload_837  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_722  1
    load_0_16_5  segment_load_conservation_774  -1
    load_0_16_5  segment_prefix_lb_775  1
    load_0_16_5  segment_prefix_ub_776  1
    load_0_16_5  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_724  -30
    arc_0_16_6  connected_order_arc_725  -15
    arc_0_16_6  in_degree_778  1
    arc_0_16_6  out_degree_826  1
    arc_0_16_6  original_T_including_depot_unload_837  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_724  1
    load_0_16_6  segment_load_conservation_781  -1
    load_0_16_6  segment_prefix_lb_782  1
    load_0_16_6  segment_prefix_ub_783  1
    load_0_16_6  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_9  arc_capacity_726  -30
    arc_0_16_9  connected_order_arc_727  -15
    arc_0_16_9  in_degree_785  1
    arc_0_16_9  out_degree_826  1
    arc_0_16_9  original_T_including_depot_unload_837  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_9  arc_capacity_726  1
    load_0_16_9  free_load_conservation_789  -1
    load_0_16_9  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_10  arc_capacity_728  -30
    arc_0_16_10  connected_order_arc_729  -15
    arc_0_16_10  in_degree_791  1
    arc_0_16_10  out_degree_826  1
    arc_0_16_10  original_T_including_depot_unload_837  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_10  arc_capacity_728  1
    load_0_16_10  free_load_conservation_795  -1
    load_0_16_10  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_730  -30
    arc_0_16_11  connected_order_arc_731  -15
    arc_0_16_11  in_degree_797  1
    arc_0_16_11  out_degree_826  1
    arc_0_16_11  original_T_including_depot_unload_837  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_730  1
    load_0_16_11  free_load_conservation_801  -1
    load_0_16_11  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_732  -30
    arc_0_16_12  connected_order_arc_733  -15
    arc_0_16_12  in_degree_803  1
    arc_0_16_12  out_degree_826  1
    arc_0_16_12  original_T_including_depot_unload_837  6.2572113135330244e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_732  1
    load_0_16_12  free_load_conservation_807  -1
    load_0_16_12  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_734  -30
    arc_0_16_13  connected_order_arc_735  -15
    arc_0_16_13  in_degree_809  1
    arc_0_16_13  out_degree_826  1
    arc_0_16_13  original_T_including_depot_unload_837  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_734  1
    load_0_16_13  free_load_conservation_813  -1
    load_0_16_13  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_736  -30
    arc_0_16_14  connected_order_arc_737  -15
    arc_0_16_14  in_degree_815  1
    arc_0_16_14  out_degree_826  1
    arc_0_16_14  original_T_including_depot_unload_837  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_736  1
    load_0_16_14  free_load_conservation_819  -1
    load_0_16_14  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_738  -30
    arc_0_16_15  connected_order_arc_739  -15
    arc_0_16_15  in_degree_821  1
    arc_0_16_15  out_degree_826  1
    arc_0_16_15  original_T_including_depot_unload_837  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_738  1
    load_0_16_15  free_load_conservation_825  -1
    load_0_16_15  free_load_conservation_831  1
    visit_1_7  out_degree_1041  -1
    visit_1_7  in_degree_1042  -1
    visit_1_7  order_active_lb_1043  -1
    visit_1_7  order_active_ub_1044  -10
    order_1_7  connected_order_arc_851  -1
    order_1_7  connected_order_arc_853  -1
    order_1_7  connected_order_arc_855  -1
    order_1_7  connected_order_arc_857  -1
    order_1_7  connected_order_arc_859  -1
    order_1_7  connected_order_arc_861  -1
    order_1_7  connected_order_arc_863  -1
    order_1_7  connected_order_arc_865  -1
    order_1_7  connected_order_arc_867  -1
    order_1_7  connected_order_arc_870  1
    order_1_7  connected_order_arc_889  1
    order_1_7  connected_order_arc_908  1
    order_1_7  connected_order_arc_927  1
    order_1_7  connected_order_arc_946  1
    order_1_7  connected_order_arc_965  1
    order_1_7  connected_order_arc_984  1
    order_1_7  connected_order_arc_1003  1
    order_1_7  connected_order_arc_1022  1
    order_1_7  order_active_lb_1043  1
    order_1_7  order_active_ub_1044  1
    order_1_7  fixed_segment_relative_order_1103  -1
    visit_1_8  out_degree_1048  -1
    visit_1_8  in_degree_1049  -1
    visit_1_8  order_active_lb_1050  -1
    visit_1_8  order_active_ub_1051  -10
    order_1_8  connected_order_arc_851  1
    order_1_8  connected_order_arc_870  -1
    order_1_8  connected_order_arc_872  -1
    order_1_8  connected_order_arc_874  -1
    order_1_8  connected_order_arc_876  -1
    order_1_8  connected_order_arc_878  -1
    order_1_8  connected_order_arc_880  -1
    order_1_8  connected_order_arc_882  -1
    order_1_8  connected_order_arc_884  -1
    order_1_8  connected_order_arc_886  -1
    order_1_8  connected_order_arc_891  1
    order_1_8  connected_order_arc_910  1
    order_1_8  connected_order_arc_929  1
    order_1_8  connected_order_arc_948  1
    order_1_8  connected_order_arc_967  1
    order_1_8  connected_order_arc_986  1
    order_1_8  connected_order_arc_1005  1
    order_1_8  connected_order_arc_1024  1
    order_1_8  order_active_lb_1050  1
    order_1_8  order_active_ub_1051  1
    order_1_8  fixed_segment_relative_order_1103  1
    visit_1_9  out_degree_1055  -1
    visit_1_9  in_degree_1056  -1
    visit_1_9  order_active_lb_1057  -1
    visit_1_9  order_active_ub_1058  -10
    visit_1_9  service_visit_def_1059  -1
    order_1_9  connected_order_arc_853  1
    order_1_9  connected_order_arc_872  1
    order_1_9  connected_order_arc_889  -1
    order_1_9  connected_order_arc_891  -1
    order_1_9  connected_order_arc_893  -1
    order_1_9  connected_order_arc_895  -1
    order_1_9  connected_order_arc_897  -1
    order_1_9  connected_order_arc_899  -1
    order_1_9  connected_order_arc_901  -1
    order_1_9  connected_order_arc_903  -1
    order_1_9  connected_order_arc_905  -1
    order_1_9  connected_order_arc_912  1
    order_1_9  connected_order_arc_931  1
    order_1_9  connected_order_arc_950  1
    order_1_9  connected_order_arc_969  1
    order_1_9  connected_order_arc_988  1
    order_1_9  connected_order_arc_1007  1
    order_1_9  connected_order_arc_1026  1
    order_1_9  order_active_lb_1057  1
    order_1_9  order_active_ub_1058  1
    visit_1_10  out_degree_1061  -1
    visit_1_10  in_degree_1062  -1
    visit_1_10  order_active_lb_1063  -1
    visit_1_10  order_active_ub_1064  -10
    visit_1_10  service_visit_def_1065  -1
    order_1_10  connected_order_arc_855  1
    order_1_10  connected_order_arc_874  1
    order_1_10  connected_order_arc_893  1
    order_1_10  connected_order_arc_908  -1
    order_1_10  connected_order_arc_910  -1
    order_1_10  connected_order_arc_912  -1
    order_1_10  connected_order_arc_914  -1
    order_1_10  connected_order_arc_916  -1
    order_1_10  connected_order_arc_918  -1
    order_1_10  connected_order_arc_920  -1
    order_1_10  connected_order_arc_922  -1
    order_1_10  connected_order_arc_924  -1
    order_1_10  connected_order_arc_933  1
    order_1_10  connected_order_arc_952  1
    order_1_10  connected_order_arc_971  1
    order_1_10  connected_order_arc_990  1
    order_1_10  connected_order_arc_1009  1
    order_1_10  connected_order_arc_1028  1
    order_1_10  order_active_lb_1063  1
    order_1_10  order_active_ub_1064  1
    visit_1_11  out_degree_1067  -1
    visit_1_11  in_degree_1068  -1
    visit_1_11  order_active_lb_1069  -1
    visit_1_11  order_active_ub_1070  -10
    visit_1_11  service_visit_def_1071  -1
    order_1_11  connected_order_arc_857  1
    order_1_11  connected_order_arc_876  1
    order_1_11  connected_order_arc_895  1
    order_1_11  connected_order_arc_914  1
    order_1_11  connected_order_arc_927  -1
    order_1_11  connected_order_arc_929  -1
    order_1_11  connected_order_arc_931  -1
    order_1_11  connected_order_arc_933  -1
    order_1_11  connected_order_arc_935  -1
    order_1_11  connected_order_arc_937  -1
    order_1_11  connected_order_arc_939  -1
    order_1_11  connected_order_arc_941  -1
    order_1_11  connected_order_arc_943  -1
    order_1_11  connected_order_arc_954  1
    order_1_11  connected_order_arc_973  1
    order_1_11  connected_order_arc_992  1
    order_1_11  connected_order_arc_1011  1
    order_1_11  connected_order_arc_1030  1
    order_1_11  order_active_lb_1069  1
    order_1_11  order_active_ub_1070  1
    visit_1_12  out_degree_1073  -1
    visit_1_12  in_degree_1074  -1
    visit_1_12  order_active_lb_1075  -1
    visit_1_12  order_active_ub_1076  -10
    visit_1_12  service_visit_def_1077  -1
    order_1_12  connected_order_arc_859  1
    order_1_12  connected_order_arc_878  1
    order_1_12  connected_order_arc_897  1
    order_1_12  connected_order_arc_916  1
    order_1_12  connected_order_arc_935  1
    order_1_12  connected_order_arc_946  -1
    order_1_12  connected_order_arc_948  -1
    order_1_12  connected_order_arc_950  -1
    order_1_12  connected_order_arc_952  -1
    order_1_12  connected_order_arc_954  -1
    order_1_12  connected_order_arc_956  -1
    order_1_12  connected_order_arc_958  -1
    order_1_12  connected_order_arc_960  -1
    order_1_12  connected_order_arc_962  -1
    order_1_12  connected_order_arc_975  1
    order_1_12  connected_order_arc_994  1
    order_1_12  connected_order_arc_1013  1
    order_1_12  connected_order_arc_1032  1
    order_1_12  order_active_lb_1075  1
    order_1_12  order_active_ub_1076  1
    visit_1_13  out_degree_1079  -1
    visit_1_13  in_degree_1080  -1
    visit_1_13  order_active_lb_1081  -1
    visit_1_13  order_active_ub_1082  -10
    visit_1_13  service_visit_def_1083  -1
    order_1_13  connected_order_arc_861  1
    order_1_13  connected_order_arc_880  1
    order_1_13  connected_order_arc_899  1
    order_1_13  connected_order_arc_918  1
    order_1_13  connected_order_arc_937  1
    order_1_13  connected_order_arc_956  1
    order_1_13  connected_order_arc_965  -1
    order_1_13  connected_order_arc_967  -1
    order_1_13  connected_order_arc_969  -1
    order_1_13  connected_order_arc_971  -1
    order_1_13  connected_order_arc_973  -1
    order_1_13  connected_order_arc_975  -1
    order_1_13  connected_order_arc_977  -1
    order_1_13  connected_order_arc_979  -1
    order_1_13  connected_order_arc_981  -1
    order_1_13  connected_order_arc_996  1
    order_1_13  connected_order_arc_1015  1
    order_1_13  connected_order_arc_1034  1
    order_1_13  order_active_lb_1081  1
    order_1_13  order_active_ub_1082  1
    visit_1_14  out_degree_1085  -1
    visit_1_14  in_degree_1086  -1
    visit_1_14  order_active_lb_1087  -1
    visit_1_14  order_active_ub_1088  -10
    visit_1_14  service_visit_def_1089  -1
    order_1_14  connected_order_arc_863  1
    order_1_14  connected_order_arc_882  1
    order_1_14  connected_order_arc_901  1
    order_1_14  connected_order_arc_920  1
    order_1_14  connected_order_arc_939  1
    order_1_14  connected_order_arc_958  1
    order_1_14  connected_order_arc_977  1
    order_1_14  connected_order_arc_984  -1
    order_1_14  connected_order_arc_986  -1
    order_1_14  connected_order_arc_988  -1
    order_1_14  connected_order_arc_990  -1
    order_1_14  connected_order_arc_992  -1
    order_1_14  connected_order_arc_994  -1
    order_1_14  connected_order_arc_996  -1
    order_1_14  connected_order_arc_998  -1
    order_1_14  connected_order_arc_1000  -1
    order_1_14  connected_order_arc_1017  1
    order_1_14  connected_order_arc_1036  1
    order_1_14  order_active_lb_1087  1
    order_1_14  order_active_ub_1088  1
    visit_1_15  out_degree_1091  -1
    visit_1_15  in_degree_1092  -1
    visit_1_15  order_active_lb_1093  -1
    visit_1_15  order_active_ub_1094  -10
    visit_1_15  service_visit_def_1095  -1
    order_1_15  connected_order_arc_865  1
    order_1_15  connected_order_arc_884  1
    order_1_15  connected_order_arc_903  1
    order_1_15  connected_order_arc_922  1
    order_1_15  connected_order_arc_941  1
    order_1_15  connected_order_arc_960  1
    order_1_15  connected_order_arc_979  1
    order_1_15  connected_order_arc_998  1
    order_1_15  connected_order_arc_1003  -1
    order_1_15  connected_order_arc_1005  -1
    order_1_15  connected_order_arc_1007  -1
    order_1_15  connected_order_arc_1009  -1
    order_1_15  connected_order_arc_1011  -1
    order_1_15  connected_order_arc_1013  -1
    order_1_15  connected_order_arc_1015  -1
    order_1_15  connected_order_arc_1017  -1
    order_1_15  connected_order_arc_1019  -1
    order_1_15  connected_order_arc_1038  1
    order_1_15  order_active_lb_1093  1
    order_1_15  order_active_ub_1094  1
    visit_1_16  out_degree_1097  -1
    visit_1_16  in_degree_1098  -1
    visit_1_16  order_active_lb_1099  -1
    visit_1_16  order_active_ub_1100  -10
    visit_1_16  service_visit_def_1101  -1
    order_1_16  connected_order_arc_867  1
    order_1_16  connected_order_arc_886  1
    order_1_16  connected_order_arc_905  1
    order_1_16  connected_order_arc_924  1
    order_1_16  connected_order_arc_943  1
    order_1_16  connected_order_arc_962  1
    order_1_16  connected_order_arc_981  1
    order_1_16  connected_order_arc_1000  1
    order_1_16  connected_order_arc_1019  1
    order_1_16  connected_order_arc_1022  -1
    order_1_16  connected_order_arc_1024  -1
    order_1_16  connected_order_arc_1026  -1
    order_1_16  connected_order_arc_1028  -1
    order_1_16  connected_order_arc_1030  -1
    order_1_16  connected_order_arc_1032  -1
    order_1_16  connected_order_arc_1034  -1
    order_1_16  connected_order_arc_1036  -1
    order_1_16  connected_order_arc_1038  -1
    order_1_16  order_active_lb_1099  1
    order_1_16  order_active_ub_1100  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_838  -30
    arc_1_0_0  depot_departure_or_bypass_1039  1
    arc_1_0_0  depot_return_or_bypass_1040  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_839  -30
    arc_1_0_7  depot_departure_or_bypass_1039  1
    arc_1_0_7  in_degree_1042  1
    arc_1_0_7  original_T_including_depot_unload_1104  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_839  1
    load_1_0_7  segment_load_conservation_1045  -1
    load_1_0_7  segment_prefix_lb_1046  1
    load_1_0_7  segment_prefix_ub_1047  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_840  -30
    arc_1_0_8  depot_departure_or_bypass_1039  1
    arc_1_0_8  in_degree_1049  1
    arc_1_0_8  original_T_including_depot_unload_1104  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_840  1
    load_1_0_8  segment_load_conservation_1052  -1
    load_1_0_8  segment_prefix_lb_1053  1
    load_1_0_8  segment_prefix_ub_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_841  -30
    arc_1_0_9  depot_departure_or_bypass_1039  1
    arc_1_0_9  in_degree_1056  1
    arc_1_0_9  original_T_including_depot_unload_1104  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_841  1
    load_1_0_9  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_842  -30
    arc_1_0_10  depot_departure_or_bypass_1039  1
    arc_1_0_10  in_degree_1062  1
    arc_1_0_10  original_T_including_depot_unload_1104  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_842  1
    load_1_0_10  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_843  -30
    arc_1_0_11  depot_departure_or_bypass_1039  1
    arc_1_0_11  in_degree_1068  1
    arc_1_0_11  original_T_including_depot_unload_1104  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_843  1
    load_1_0_11  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_844  -30
    arc_1_0_12  depot_departure_or_bypass_1039  1
    arc_1_0_12  in_degree_1074  1
    arc_1_0_12  original_T_including_depot_unload_1104  1.1810298132524642e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_844  1
    load_1_0_12  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_845  -30
    arc_1_0_13  depot_departure_or_bypass_1039  1
    arc_1_0_13  in_degree_1080  1
    arc_1_0_13  original_T_including_depot_unload_1104  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_845  1
    load_1_0_13  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_846  -30
    arc_1_0_14  depot_departure_or_bypass_1039  1
    arc_1_0_14  in_degree_1086  1
    arc_1_0_14  original_T_including_depot_unload_1104  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_846  1
    load_1_0_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_847  -30
    arc_1_0_15  depot_departure_or_bypass_1039  1
    arc_1_0_15  in_degree_1092  1
    arc_1_0_15  original_T_including_depot_unload_1104  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_847  1
    load_1_0_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_848  -30
    arc_1_0_16  depot_departure_or_bypass_1039  1
    arc_1_0_16  in_degree_1098  1
    arc_1_0_16  original_T_including_depot_unload_1104  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_848  1
    load_1_0_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_849  -30
    arc_1_7_0  depot_return_or_bypass_1040  1
    arc_1_7_0  out_degree_1041  1
    arc_1_7_0  original_T_including_depot_unload_1104  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_849  1
    load_1_7_0  segment_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_850  -30
    arc_1_7_8  connected_order_arc_851  -11
    arc_1_7_8  out_degree_1041  1
    arc_1_7_8  in_degree_1049  1
    arc_1_7_8  original_T_including_depot_unload_1104  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_850  1
    load_1_7_8  segment_load_conservation_1045  1
    load_1_7_8  segment_load_conservation_1052  -1
    load_1_7_8  segment_prefix_lb_1053  1
    load_1_7_8  segment_prefix_ub_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_852  -30
    arc_1_7_9  connected_order_arc_853  -11
    arc_1_7_9  out_degree_1041  1
    arc_1_7_9  in_degree_1056  1
    arc_1_7_9  original_T_including_depot_unload_1104  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_852  1
    load_1_7_9  segment_load_conservation_1045  1
    load_1_7_9  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_854  -30
    arc_1_7_10  connected_order_arc_855  -11
    arc_1_7_10  out_degree_1041  1
    arc_1_7_10  in_degree_1062  1
    arc_1_7_10  original_T_including_depot_unload_1104  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_854  1
    load_1_7_10  segment_load_conservation_1045  1
    load_1_7_10  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_856  -30
    arc_1_7_11  connected_order_arc_857  -11
    arc_1_7_11  out_degree_1041  1
    arc_1_7_11  in_degree_1068  1
    arc_1_7_11  original_T_including_depot_unload_1104  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_856  1
    load_1_7_11  segment_load_conservation_1045  1
    load_1_7_11  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_858  -30
    arc_1_7_12  connected_order_arc_859  -11
    arc_1_7_12  out_degree_1041  1
    arc_1_7_12  in_degree_1074  1
    arc_1_7_12  original_T_including_depot_unload_1104  1.8734169658988160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_858  1
    load_1_7_12  segment_load_conservation_1045  1
    load_1_7_12  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_860  -30
    arc_1_7_13  connected_order_arc_861  -11
    arc_1_7_13  out_degree_1041  1
    arc_1_7_13  in_degree_1080  1
    arc_1_7_13  original_T_including_depot_unload_1104  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_860  1
    load_1_7_13  segment_load_conservation_1045  1
    load_1_7_13  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_862  -30
    arc_1_7_14  connected_order_arc_863  -11
    arc_1_7_14  out_degree_1041  1
    arc_1_7_14  in_degree_1086  1
    arc_1_7_14  original_T_including_depot_unload_1104  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_862  1
    load_1_7_14  segment_load_conservation_1045  1
    load_1_7_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_864  -30
    arc_1_7_15  connected_order_arc_865  -11
    arc_1_7_15  out_degree_1041  1
    arc_1_7_15  in_degree_1092  1
    arc_1_7_15  original_T_including_depot_unload_1104  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_864  1
    load_1_7_15  segment_load_conservation_1045  1
    load_1_7_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_866  -30
    arc_1_7_16  connected_order_arc_867  -11
    arc_1_7_16  out_degree_1041  1
    arc_1_7_16  in_degree_1098  1
    arc_1_7_16  original_T_including_depot_unload_1104  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_866  1
    load_1_7_16  segment_load_conservation_1045  1
    load_1_7_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_868  -30
    arc_1_8_0  depot_return_or_bypass_1040  1
    arc_1_8_0  out_degree_1048  1
    arc_1_8_0  original_T_including_depot_unload_1104  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_868  1
    load_1_8_0  segment_load_conservation_1052  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_869  -30
    arc_1_8_7  connected_order_arc_870  -11
    arc_1_8_7  in_degree_1042  1
    arc_1_8_7  out_degree_1048  1
    arc_1_8_7  original_T_including_depot_unload_1104  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_869  1
    load_1_8_7  segment_load_conservation_1045  -1
    load_1_8_7  segment_prefix_lb_1046  1
    load_1_8_7  segment_prefix_ub_1047  1
    load_1_8_7  segment_load_conservation_1052  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_871  -30
    arc_1_8_9  connected_order_arc_872  -11
    arc_1_8_9  out_degree_1048  1
    arc_1_8_9  in_degree_1056  1
    arc_1_8_9  original_T_including_depot_unload_1104  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_871  1
    load_1_8_9  segment_load_conservation_1052  1
    load_1_8_9  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_873  -30
    arc_1_8_10  connected_order_arc_874  -11
    arc_1_8_10  out_degree_1048  1
    arc_1_8_10  in_degree_1062  1
    arc_1_8_10  original_T_including_depot_unload_1104  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_873  1
    load_1_8_10  segment_load_conservation_1052  1
    load_1_8_10  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_875  -30
    arc_1_8_11  connected_order_arc_876  -11
    arc_1_8_11  out_degree_1048  1
    arc_1_8_11  in_degree_1068  1
    arc_1_8_11  original_T_including_depot_unload_1104  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_875  1
    load_1_8_11  segment_load_conservation_1052  1
    load_1_8_11  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_877  -30
    arc_1_8_12  connected_order_arc_878  -11
    arc_1_8_12  out_degree_1048  1
    arc_1_8_12  in_degree_1074  1
    arc_1_8_12  original_T_including_depot_unload_1104  1.8892128512324714e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_877  1
    load_1_8_12  segment_load_conservation_1052  1
    load_1_8_12  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_879  -30
    arc_1_8_13  connected_order_arc_880  -11
    arc_1_8_13  out_degree_1048  1
    arc_1_8_13  in_degree_1080  1
    arc_1_8_13  original_T_including_depot_unload_1104  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_879  1
    load_1_8_13  segment_load_conservation_1052  1
    load_1_8_13  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_881  -30
    arc_1_8_14  connected_order_arc_882  -11
    arc_1_8_14  out_degree_1048  1
    arc_1_8_14  in_degree_1086  1
    arc_1_8_14  original_T_including_depot_unload_1104  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_881  1
    load_1_8_14  segment_load_conservation_1052  1
    load_1_8_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_883  -30
    arc_1_8_15  connected_order_arc_884  -11
    arc_1_8_15  out_degree_1048  1
    arc_1_8_15  in_degree_1092  1
    arc_1_8_15  original_T_including_depot_unload_1104  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_883  1
    load_1_8_15  segment_load_conservation_1052  1
    load_1_8_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_885  -30
    arc_1_8_16  connected_order_arc_886  -11
    arc_1_8_16  out_degree_1048  1
    arc_1_8_16  in_degree_1098  1
    arc_1_8_16  original_T_including_depot_unload_1104  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_885  1
    load_1_8_16  segment_load_conservation_1052  1
    load_1_8_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_887  -30
    arc_1_9_0  depot_return_or_bypass_1040  1
    arc_1_9_0  out_degree_1055  1
    arc_1_9_0  original_T_including_depot_unload_1104  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_887  1
    load_1_9_0  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_888  -30
    arc_1_9_7  connected_order_arc_889  -11
    arc_1_9_7  in_degree_1042  1
    arc_1_9_7  out_degree_1055  1
    arc_1_9_7  original_T_including_depot_unload_1104  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_888  1
    load_1_9_7  segment_load_conservation_1045  -1
    load_1_9_7  segment_prefix_lb_1046  1
    load_1_9_7  segment_prefix_ub_1047  1
    load_1_9_7  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_890  -30
    arc_1_9_8  connected_order_arc_891  -11
    arc_1_9_8  in_degree_1049  1
    arc_1_9_8  out_degree_1055  1
    arc_1_9_8  original_T_including_depot_unload_1104  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_890  1
    load_1_9_8  segment_load_conservation_1052  -1
    load_1_9_8  segment_prefix_lb_1053  1
    load_1_9_8  segment_prefix_ub_1054  1
    load_1_9_8  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_892  -30
    arc_1_9_10  connected_order_arc_893  -11
    arc_1_9_10  out_degree_1055  1
    arc_1_9_10  in_degree_1062  1
    arc_1_9_10  original_T_including_depot_unload_1104  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_892  1
    load_1_9_10  free_load_conservation_1060  1
    load_1_9_10  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_894  -30
    arc_1_9_11  connected_order_arc_895  -11
    arc_1_9_11  out_degree_1055  1
    arc_1_9_11  in_degree_1068  1
    arc_1_9_11  original_T_including_depot_unload_1104  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_894  1
    load_1_9_11  free_load_conservation_1060  1
    load_1_9_11  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_896  -30
    arc_1_9_12  connected_order_arc_897  -11
    arc_1_9_12  out_degree_1055  1
    arc_1_9_12  in_degree_1074  1
    arc_1_9_12  original_T_including_depot_unload_1104  3.0084412628525462e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_896  1
    load_1_9_12  free_load_conservation_1060  1
    load_1_9_12  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_898  -30
    arc_1_9_13  connected_order_arc_899  -11
    arc_1_9_13  out_degree_1055  1
    arc_1_9_13  in_degree_1080  1
    arc_1_9_13  original_T_including_depot_unload_1104  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_898  1
    load_1_9_13  free_load_conservation_1060  1
    load_1_9_13  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_900  -30
    arc_1_9_14  connected_order_arc_901  -11
    arc_1_9_14  out_degree_1055  1
    arc_1_9_14  in_degree_1086  1
    arc_1_9_14  original_T_including_depot_unload_1104  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_900  1
    load_1_9_14  free_load_conservation_1060  1
    load_1_9_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_902  -30
    arc_1_9_15  connected_order_arc_903  -11
    arc_1_9_15  out_degree_1055  1
    arc_1_9_15  in_degree_1092  1
    arc_1_9_15  original_T_including_depot_unload_1104  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_902  1
    load_1_9_15  free_load_conservation_1060  1
    load_1_9_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_904  -30
    arc_1_9_16  connected_order_arc_905  -11
    arc_1_9_16  out_degree_1055  1
    arc_1_9_16  in_degree_1098  1
    arc_1_9_16  original_T_including_depot_unload_1104  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_904  1
    load_1_9_16  free_load_conservation_1060  1
    load_1_9_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_906  -30
    arc_1_10_0  depot_return_or_bypass_1040  1
    arc_1_10_0  out_degree_1061  1
    arc_1_10_0  original_T_including_depot_unload_1104  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_906  1
    load_1_10_0  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_907  -30
    arc_1_10_7  connected_order_arc_908  -11
    arc_1_10_7  in_degree_1042  1
    arc_1_10_7  out_degree_1061  1
    arc_1_10_7  original_T_including_depot_unload_1104  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_907  1
    load_1_10_7  segment_load_conservation_1045  -1
    load_1_10_7  segment_prefix_lb_1046  1
    load_1_10_7  segment_prefix_ub_1047  1
    load_1_10_7  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_909  -30
    arc_1_10_8  connected_order_arc_910  -11
    arc_1_10_8  in_degree_1049  1
    arc_1_10_8  out_degree_1061  1
    arc_1_10_8  original_T_including_depot_unload_1104  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_909  1
    load_1_10_8  segment_load_conservation_1052  -1
    load_1_10_8  segment_prefix_lb_1053  1
    load_1_10_8  segment_prefix_ub_1054  1
    load_1_10_8  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_911  -30
    arc_1_10_9  connected_order_arc_912  -11
    arc_1_10_9  in_degree_1056  1
    arc_1_10_9  out_degree_1061  1
    arc_1_10_9  original_T_including_depot_unload_1104  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_911  1
    load_1_10_9  free_load_conservation_1060  -1
    load_1_10_9  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_913  -30
    arc_1_10_11  connected_order_arc_914  -11
    arc_1_10_11  out_degree_1061  1
    arc_1_10_11  in_degree_1068  1
    arc_1_10_11  original_T_including_depot_unload_1104  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_913  1
    load_1_10_11  free_load_conservation_1066  1
    load_1_10_11  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_915  -30
    arc_1_10_12  connected_order_arc_916  -11
    arc_1_10_12  out_degree_1061  1
    arc_1_10_12  in_degree_1074  1
    arc_1_10_12  original_T_including_depot_unload_1104  3.4611011743974603e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_915  1
    load_1_10_12  free_load_conservation_1066  1
    load_1_10_12  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_917  -30
    arc_1_10_13  connected_order_arc_918  -11
    arc_1_10_13  out_degree_1061  1
    arc_1_10_13  in_degree_1080  1
    arc_1_10_13  original_T_including_depot_unload_1104  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_917  1
    load_1_10_13  free_load_conservation_1066  1
    load_1_10_13  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_919  -30
    arc_1_10_14  connected_order_arc_920  -11
    arc_1_10_14  out_degree_1061  1
    arc_1_10_14  in_degree_1086  1
    arc_1_10_14  original_T_including_depot_unload_1104  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_919  1
    load_1_10_14  free_load_conservation_1066  1
    load_1_10_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_921  -30
    arc_1_10_15  connected_order_arc_922  -11
    arc_1_10_15  out_degree_1061  1
    arc_1_10_15  in_degree_1092  1
    arc_1_10_15  original_T_including_depot_unload_1104  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_921  1
    load_1_10_15  free_load_conservation_1066  1
    load_1_10_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_923  -30
    arc_1_10_16  connected_order_arc_924  -11
    arc_1_10_16  out_degree_1061  1
    arc_1_10_16  in_degree_1098  1
    arc_1_10_16  original_T_including_depot_unload_1104  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_923  1
    load_1_10_16  free_load_conservation_1066  1
    load_1_10_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_925  -30
    arc_1_11_0  depot_return_or_bypass_1040  1
    arc_1_11_0  out_degree_1067  1
    arc_1_11_0  original_T_including_depot_unload_1104  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_925  1
    load_1_11_0  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_926  -30
    arc_1_11_7  connected_order_arc_927  -11
    arc_1_11_7  in_degree_1042  1
    arc_1_11_7  out_degree_1067  1
    arc_1_11_7  original_T_including_depot_unload_1104  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_926  1
    load_1_11_7  segment_load_conservation_1045  -1
    load_1_11_7  segment_prefix_lb_1046  1
    load_1_11_7  segment_prefix_ub_1047  1
    load_1_11_7  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_928  -30
    arc_1_11_8  connected_order_arc_929  -11
    arc_1_11_8  in_degree_1049  1
    arc_1_11_8  out_degree_1067  1
    arc_1_11_8  original_T_including_depot_unload_1104  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_928  1
    load_1_11_8  segment_load_conservation_1052  -1
    load_1_11_8  segment_prefix_lb_1053  1
    load_1_11_8  segment_prefix_ub_1054  1
    load_1_11_8  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_930  -30
    arc_1_11_9  connected_order_arc_931  -11
    arc_1_11_9  in_degree_1056  1
    arc_1_11_9  out_degree_1067  1
    arc_1_11_9  original_T_including_depot_unload_1104  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_930  1
    load_1_11_9  free_load_conservation_1060  -1
    load_1_11_9  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_932  -30
    arc_1_11_10  connected_order_arc_933  -11
    arc_1_11_10  in_degree_1062  1
    arc_1_11_10  out_degree_1067  1
    arc_1_11_10  original_T_including_depot_unload_1104  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_932  1
    load_1_11_10  free_load_conservation_1066  -1
    load_1_11_10  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_934  -30
    arc_1_11_12  connected_order_arc_935  -11
    arc_1_11_12  out_degree_1067  1
    arc_1_11_12  in_degree_1074  1
    arc_1_11_12  original_T_including_depot_unload_1104  3.3982588084805943e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_934  1
    load_1_11_12  free_load_conservation_1072  1
    load_1_11_12  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_936  -30
    arc_1_11_13  connected_order_arc_937  -11
    arc_1_11_13  out_degree_1067  1
    arc_1_11_13  in_degree_1080  1
    arc_1_11_13  original_T_including_depot_unload_1104  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_936  1
    load_1_11_13  free_load_conservation_1072  1
    load_1_11_13  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_938  -30
    arc_1_11_14  connected_order_arc_939  -11
    arc_1_11_14  out_degree_1067  1
    arc_1_11_14  in_degree_1086  1
    arc_1_11_14  original_T_including_depot_unload_1104  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_938  1
    load_1_11_14  free_load_conservation_1072  1
    load_1_11_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_940  -30
    arc_1_11_15  connected_order_arc_941  -11
    arc_1_11_15  out_degree_1067  1
    arc_1_11_15  in_degree_1092  1
    arc_1_11_15  original_T_including_depot_unload_1104  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_940  1
    load_1_11_15  free_load_conservation_1072  1
    load_1_11_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_942  -30
    arc_1_11_16  connected_order_arc_943  -11
    arc_1_11_16  out_degree_1067  1
    arc_1_11_16  in_degree_1098  1
    arc_1_11_16  original_T_including_depot_unload_1104  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_942  1
    load_1_11_16  free_load_conservation_1072  1
    load_1_11_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_944  -30
    arc_1_12_0  depot_return_or_bypass_1040  1
    arc_1_12_0  out_degree_1073  1
    arc_1_12_0  original_T_including_depot_unload_1104  1.1810298132524642e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_944  1
    load_1_12_0  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_945  -30
    arc_1_12_7  connected_order_arc_946  -11
    arc_1_12_7  in_degree_1042  1
    arc_1_12_7  out_degree_1073  1
    arc_1_12_7  original_T_including_depot_unload_1104  1.8734169658988160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_945  1
    load_1_12_7  segment_load_conservation_1045  -1
    load_1_12_7  segment_prefix_lb_1046  1
    load_1_12_7  segment_prefix_ub_1047  1
    load_1_12_7  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_947  -30
    arc_1_12_8  connected_order_arc_948  -11
    arc_1_12_8  in_degree_1049  1
    arc_1_12_8  out_degree_1073  1
    arc_1_12_8  original_T_including_depot_unload_1104  1.8892128512324714e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_947  1
    load_1_12_8  segment_load_conservation_1052  -1
    load_1_12_8  segment_prefix_lb_1053  1
    load_1_12_8  segment_prefix_ub_1054  1
    load_1_12_8  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_949  -30
    arc_1_12_9  connected_order_arc_950  -11
    arc_1_12_9  in_degree_1056  1
    arc_1_12_9  out_degree_1073  1
    arc_1_12_9  original_T_including_depot_unload_1104  3.0084412628525462e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_949  1
    load_1_12_9  free_load_conservation_1060  -1
    load_1_12_9  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_951  -30
    arc_1_12_10  connected_order_arc_952  -11
    arc_1_12_10  in_degree_1062  1
    arc_1_12_10  out_degree_1073  1
    arc_1_12_10  original_T_including_depot_unload_1104  3.4611011743974603e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_951  1
    load_1_12_10  free_load_conservation_1066  -1
    load_1_12_10  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_953  -30
    arc_1_12_11  connected_order_arc_954  -11
    arc_1_12_11  in_degree_1068  1
    arc_1_12_11  out_degree_1073  1
    arc_1_12_11  original_T_including_depot_unload_1104  3.3982588084805943e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_953  1
    load_1_12_11  free_load_conservation_1072  -1
    load_1_12_11  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_955  -30
    arc_1_12_13  connected_order_arc_956  -11
    arc_1_12_13  out_degree_1073  1
    arc_1_12_13  in_degree_1080  1
    arc_1_12_13  original_T_including_depot_unload_1104  2.3944588415225576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_955  1
    load_1_12_13  free_load_conservation_1078  1
    load_1_12_13  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_957  -30
    arc_1_12_14  connected_order_arc_958  -11
    arc_1_12_14  out_degree_1073  1
    arc_1_12_14  in_degree_1086  1
    arc_1_12_14  original_T_including_depot_unload_1104  5.4851753823626359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_957  1
    load_1_12_14  free_load_conservation_1078  1
    load_1_12_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_959  -30
    arc_1_12_15  connected_order_arc_960  -11
    arc_1_12_15  out_degree_1073  1
    arc_1_12_15  in_degree_1092  1
    arc_1_12_15  original_T_including_depot_unload_1104  7.7442375831627771e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_959  1
    load_1_12_15  free_load_conservation_1078  1
    load_1_12_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_961  -30
    arc_1_12_16  connected_order_arc_962  -11
    arc_1_12_16  out_degree_1073  1
    arc_1_12_16  in_degree_1098  1
    arc_1_12_16  original_T_including_depot_unload_1104  6.2572113135330244e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_961  1
    load_1_12_16  free_load_conservation_1078  1
    load_1_12_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_963  -30
    arc_1_13_0  depot_return_or_bypass_1040  1
    arc_1_13_0  out_degree_1079  1
    arc_1_13_0  original_T_including_depot_unload_1104  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_963  1
    load_1_13_0  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_964  -30
    arc_1_13_7  connected_order_arc_965  -11
    arc_1_13_7  in_degree_1042  1
    arc_1_13_7  out_degree_1079  1
    arc_1_13_7  original_T_including_depot_unload_1104  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_964  1
    load_1_13_7  segment_load_conservation_1045  -1
    load_1_13_7  segment_prefix_lb_1046  1
    load_1_13_7  segment_prefix_ub_1047  1
    load_1_13_7  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_966  -30
    arc_1_13_8  connected_order_arc_967  -11
    arc_1_13_8  in_degree_1049  1
    arc_1_13_8  out_degree_1079  1
    arc_1_13_8  original_T_including_depot_unload_1104  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_966  1
    load_1_13_8  segment_load_conservation_1052  -1
    load_1_13_8  segment_prefix_lb_1053  1
    load_1_13_8  segment_prefix_ub_1054  1
    load_1_13_8  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_968  -30
    arc_1_13_9  connected_order_arc_969  -11
    arc_1_13_9  in_degree_1056  1
    arc_1_13_9  out_degree_1079  1
    arc_1_13_9  original_T_including_depot_unload_1104  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_968  1
    load_1_13_9  free_load_conservation_1060  -1
    load_1_13_9  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_970  -30
    arc_1_13_10  connected_order_arc_971  -11
    arc_1_13_10  in_degree_1062  1
    arc_1_13_10  out_degree_1079  1
    arc_1_13_10  original_T_including_depot_unload_1104  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_970  1
    load_1_13_10  free_load_conservation_1066  -1
    load_1_13_10  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_972  -30
    arc_1_13_11  connected_order_arc_973  -11
    arc_1_13_11  in_degree_1068  1
    arc_1_13_11  out_degree_1079  1
    arc_1_13_11  original_T_including_depot_unload_1104  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_972  1
    load_1_13_11  free_load_conservation_1072  -1
    load_1_13_11  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_974  -30
    arc_1_13_12  connected_order_arc_975  -11
    arc_1_13_12  in_degree_1074  1
    arc_1_13_12  out_degree_1079  1
    arc_1_13_12  original_T_including_depot_unload_1104  2.3944588415225576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_974  1
    load_1_13_12  free_load_conservation_1078  -1
    load_1_13_12  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_976  -30
    arc_1_13_14  connected_order_arc_977  -11
    arc_1_13_14  out_degree_1079  1
    arc_1_13_14  in_degree_1086  1
    arc_1_13_14  original_T_including_depot_unload_1104  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_976  1
    load_1_13_14  free_load_conservation_1084  1
    load_1_13_14  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_978  -30
    arc_1_13_15  connected_order_arc_979  -11
    arc_1_13_15  out_degree_1079  1
    arc_1_13_15  in_degree_1092  1
    arc_1_13_15  original_T_including_depot_unload_1104  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_978  1
    load_1_13_15  free_load_conservation_1084  1
    load_1_13_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_980  -30
    arc_1_13_16  connected_order_arc_981  -11
    arc_1_13_16  out_degree_1079  1
    arc_1_13_16  in_degree_1098  1
    arc_1_13_16  original_T_including_depot_unload_1104  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_980  1
    load_1_13_16  free_load_conservation_1084  1
    load_1_13_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_982  -30
    arc_1_14_0  depot_return_or_bypass_1040  1
    arc_1_14_0  out_degree_1085  1
    arc_1_14_0  original_T_including_depot_unload_1104  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_982  1
    load_1_14_0  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_983  -30
    arc_1_14_7  connected_order_arc_984  -11
    arc_1_14_7  in_degree_1042  1
    arc_1_14_7  out_degree_1085  1
    arc_1_14_7  original_T_including_depot_unload_1104  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_983  1
    load_1_14_7  segment_load_conservation_1045  -1
    load_1_14_7  segment_prefix_lb_1046  1
    load_1_14_7  segment_prefix_ub_1047  1
    load_1_14_7  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_985  -30
    arc_1_14_8  connected_order_arc_986  -11
    arc_1_14_8  in_degree_1049  1
    arc_1_14_8  out_degree_1085  1
    arc_1_14_8  original_T_including_depot_unload_1104  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_985  1
    load_1_14_8  segment_load_conservation_1052  -1
    load_1_14_8  segment_prefix_lb_1053  1
    load_1_14_8  segment_prefix_ub_1054  1
    load_1_14_8  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_987  -30
    arc_1_14_9  connected_order_arc_988  -11
    arc_1_14_9  in_degree_1056  1
    arc_1_14_9  out_degree_1085  1
    arc_1_14_9  original_T_including_depot_unload_1104  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_987  1
    load_1_14_9  free_load_conservation_1060  -1
    load_1_14_9  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_989  -30
    arc_1_14_10  connected_order_arc_990  -11
    arc_1_14_10  in_degree_1062  1
    arc_1_14_10  out_degree_1085  1
    arc_1_14_10  original_T_including_depot_unload_1104  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_989  1
    load_1_14_10  free_load_conservation_1066  -1
    load_1_14_10  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_991  -30
    arc_1_14_11  connected_order_arc_992  -11
    arc_1_14_11  in_degree_1068  1
    arc_1_14_11  out_degree_1085  1
    arc_1_14_11  original_T_including_depot_unload_1104  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_991  1
    load_1_14_11  free_load_conservation_1072  -1
    load_1_14_11  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_993  -30
    arc_1_14_12  connected_order_arc_994  -11
    arc_1_14_12  in_degree_1074  1
    arc_1_14_12  out_degree_1085  1
    arc_1_14_12  original_T_including_depot_unload_1104  5.4851753823626359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_993  1
    load_1_14_12  free_load_conservation_1078  -1
    load_1_14_12  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_995  -30
    arc_1_14_13  connected_order_arc_996  -11
    arc_1_14_13  in_degree_1080  1
    arc_1_14_13  out_degree_1085  1
    arc_1_14_13  original_T_including_depot_unload_1104  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_995  1
    load_1_14_13  free_load_conservation_1084  -1
    load_1_14_13  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_997  -30
    arc_1_14_15  connected_order_arc_998  -11
    arc_1_14_15  out_degree_1085  1
    arc_1_14_15  in_degree_1092  1
    arc_1_14_15  original_T_including_depot_unload_1104  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_997  1
    load_1_14_15  free_load_conservation_1090  1
    load_1_14_15  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_999  -30
    arc_1_14_16  connected_order_arc_1000  -11
    arc_1_14_16  out_degree_1085  1
    arc_1_14_16  in_degree_1098  1
    arc_1_14_16  original_T_including_depot_unload_1104  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_999  1
    load_1_14_16  free_load_conservation_1090  1
    load_1_14_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1001  -30
    arc_1_15_0  depot_return_or_bypass_1040  1
    arc_1_15_0  out_degree_1091  1
    arc_1_15_0  original_T_including_depot_unload_1104  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1001  1
    load_1_15_0  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1002  -30
    arc_1_15_7  connected_order_arc_1003  -11
    arc_1_15_7  in_degree_1042  1
    arc_1_15_7  out_degree_1091  1
    arc_1_15_7  original_T_including_depot_unload_1104  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1002  1
    load_1_15_7  segment_load_conservation_1045  -1
    load_1_15_7  segment_prefix_lb_1046  1
    load_1_15_7  segment_prefix_ub_1047  1
    load_1_15_7  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1004  -30
    arc_1_15_8  connected_order_arc_1005  -11
    arc_1_15_8  in_degree_1049  1
    arc_1_15_8  out_degree_1091  1
    arc_1_15_8  original_T_including_depot_unload_1104  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1004  1
    load_1_15_8  segment_load_conservation_1052  -1
    load_1_15_8  segment_prefix_lb_1053  1
    load_1_15_8  segment_prefix_ub_1054  1
    load_1_15_8  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1006  -30
    arc_1_15_9  connected_order_arc_1007  -11
    arc_1_15_9  in_degree_1056  1
    arc_1_15_9  out_degree_1091  1
    arc_1_15_9  original_T_including_depot_unload_1104  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1006  1
    load_1_15_9  free_load_conservation_1060  -1
    load_1_15_9  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1008  -30
    arc_1_15_10  connected_order_arc_1009  -11
    arc_1_15_10  in_degree_1062  1
    arc_1_15_10  out_degree_1091  1
    arc_1_15_10  original_T_including_depot_unload_1104  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1008  1
    load_1_15_10  free_load_conservation_1066  -1
    load_1_15_10  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1010  -30
    arc_1_15_11  connected_order_arc_1011  -11
    arc_1_15_11  in_degree_1068  1
    arc_1_15_11  out_degree_1091  1
    arc_1_15_11  original_T_including_depot_unload_1104  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1010  1
    load_1_15_11  free_load_conservation_1072  -1
    load_1_15_11  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1012  -30
    arc_1_15_12  connected_order_arc_1013  -11
    arc_1_15_12  in_degree_1074  1
    arc_1_15_12  out_degree_1091  1
    arc_1_15_12  original_T_including_depot_unload_1104  7.7442375831627771e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1012  1
    load_1_15_12  free_load_conservation_1078  -1
    load_1_15_12  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1014  -30
    arc_1_15_13  connected_order_arc_1015  -11
    arc_1_15_13  in_degree_1080  1
    arc_1_15_13  out_degree_1091  1
    arc_1_15_13  original_T_including_depot_unload_1104  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1014  1
    load_1_15_13  free_load_conservation_1084  -1
    load_1_15_13  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1016  -30
    arc_1_15_14  connected_order_arc_1017  -11
    arc_1_15_14  in_degree_1086  1
    arc_1_15_14  out_degree_1091  1
    arc_1_15_14  original_T_including_depot_unload_1104  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1016  1
    load_1_15_14  free_load_conservation_1090  -1
    load_1_15_14  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1018  -30
    arc_1_15_16  connected_order_arc_1019  -11
    arc_1_15_16  out_degree_1091  1
    arc_1_15_16  in_degree_1098  1
    arc_1_15_16  original_T_including_depot_unload_1104  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1018  1
    load_1_15_16  free_load_conservation_1096  1
    load_1_15_16  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1020  -30
    arc_1_16_0  depot_return_or_bypass_1040  1
    arc_1_16_0  out_degree_1097  1
    arc_1_16_0  original_T_including_depot_unload_1104  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1020  1
    load_1_16_0  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1021  -30
    arc_1_16_7  connected_order_arc_1022  -11
    arc_1_16_7  in_degree_1042  1
    arc_1_16_7  out_degree_1097  1
    arc_1_16_7  original_T_including_depot_unload_1104  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1021  1
    load_1_16_7  segment_load_conservation_1045  -1
    load_1_16_7  segment_prefix_lb_1046  1
    load_1_16_7  segment_prefix_ub_1047  1
    load_1_16_7  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1023  -30
    arc_1_16_8  connected_order_arc_1024  -11
    arc_1_16_8  in_degree_1049  1
    arc_1_16_8  out_degree_1097  1
    arc_1_16_8  original_T_including_depot_unload_1104  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1023  1
    load_1_16_8  segment_load_conservation_1052  -1
    load_1_16_8  segment_prefix_lb_1053  1
    load_1_16_8  segment_prefix_ub_1054  1
    load_1_16_8  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1025  -30
    arc_1_16_9  connected_order_arc_1026  -11
    arc_1_16_9  in_degree_1056  1
    arc_1_16_9  out_degree_1097  1
    arc_1_16_9  original_T_including_depot_unload_1104  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1025  1
    load_1_16_9  free_load_conservation_1060  -1
    load_1_16_9  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1027  -30
    arc_1_16_10  connected_order_arc_1028  -11
    arc_1_16_10  in_degree_1062  1
    arc_1_16_10  out_degree_1097  1
    arc_1_16_10  original_T_including_depot_unload_1104  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1027  1
    load_1_16_10  free_load_conservation_1066  -1
    load_1_16_10  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1029  -30
    arc_1_16_11  connected_order_arc_1030  -11
    arc_1_16_11  in_degree_1068  1
    arc_1_16_11  out_degree_1097  1
    arc_1_16_11  original_T_including_depot_unload_1104  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1029  1
    load_1_16_11  free_load_conservation_1072  -1
    load_1_16_11  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1031  -30
    arc_1_16_12  connected_order_arc_1032  -11
    arc_1_16_12  in_degree_1074  1
    arc_1_16_12  out_degree_1097  1
    arc_1_16_12  original_T_including_depot_unload_1104  6.2572113135330244e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1031  1
    load_1_16_12  free_load_conservation_1078  -1
    load_1_16_12  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1033  -30
    arc_1_16_13  connected_order_arc_1034  -11
    arc_1_16_13  in_degree_1080  1
    arc_1_16_13  out_degree_1097  1
    arc_1_16_13  original_T_including_depot_unload_1104  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1033  1
    load_1_16_13  free_load_conservation_1084  -1
    load_1_16_13  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1035  -30
    arc_1_16_14  connected_order_arc_1036  -11
    arc_1_16_14  in_degree_1086  1
    arc_1_16_14  out_degree_1097  1
    arc_1_16_14  original_T_including_depot_unload_1104  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1035  1
    load_1_16_14  free_load_conservation_1090  -1
    load_1_16_14  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1037  -30
    arc_1_16_15  connected_order_arc_1038  -11
    arc_1_16_15  in_degree_1092  1
    arc_1_16_15  out_degree_1097  1
    arc_1_16_15  original_T_including_depot_unload_1104  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1037  1
    load_1_16_15  free_load_conservation_1096  -1
    load_1_16_15  free_load_conservation_1102  1
RHS
    RHS1      OBJ       -4.1447573568326740e-01
    RHS1      onehot_4_32  1
    RHS1      onehot_5_41  1
    RHS1      onehot_18_76  1
    RHS1      onehot_8_85  1
    RHS1      onehot_17_122  1
    RHS1      onehot_3_159  1
    RHS1      onehot_11_194  1
    RHS1      onehot_2_201  1
    RHS1      stock_ub_205  26
    RHS1      parent_nonstrict_scope_206  5.5602253369792887e-01
    RHS1      normalization_263  1
    RHS1      connected_order_arc_364  -14
    RHS1      connected_order_arc_366  -14
    RHS1      connected_order_arc_368  -14
    RHS1      connected_order_arc_370  -14
    RHS1      connected_order_arc_372  -14
    RHS1      connected_order_arc_374  -14
    RHS1      connected_order_arc_376  -14
    RHS1      connected_order_arc_378  -14
    RHS1      connected_order_arc_380  -14
    RHS1      connected_order_arc_382  -14
    RHS1      connected_order_arc_384  -14
    RHS1      connected_order_arc_386  -14
    RHS1      connected_order_arc_388  -14
    RHS1      connected_order_arc_391  -14
    RHS1      connected_order_arc_393  -14
    RHS1      connected_order_arc_395  -14
    RHS1      connected_order_arc_397  -14
    RHS1      connected_order_arc_399  -14
    RHS1      connected_order_arc_401  -14
    RHS1      connected_order_arc_403  -14
    RHS1      connected_order_arc_405  -14
    RHS1      connected_order_arc_407  -14
    RHS1      connected_order_arc_409  -14
    RHS1      connected_order_arc_411  -14
    RHS1      connected_order_arc_413  -14
    RHS1      connected_order_arc_415  -14
    RHS1      connected_order_arc_418  -14
    RHS1      connected_order_arc_420  -14
    RHS1      connected_order_arc_422  -14
    RHS1      connected_order_arc_424  -14
    RHS1      connected_order_arc_426  -14
    RHS1      connected_order_arc_428  -14
    RHS1      connected_order_arc_430  -14
    RHS1      connected_order_arc_432  -14
    RHS1      connected_order_arc_434  -14
    RHS1      connected_order_arc_436  -14
    RHS1      connected_order_arc_438  -14
    RHS1      connected_order_arc_440  -14
    RHS1      connected_order_arc_442  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_447  -14
    RHS1      connected_order_arc_449  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_453  -14
    RHS1      connected_order_arc_455  -14
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_474  -14
    RHS1      connected_order_arc_476  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_480  -14
    RHS1      connected_order_arc_482  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_501  -14
    RHS1      connected_order_arc_503  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_507  -14
    RHS1      connected_order_arc_509  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_528  -14
    RHS1      connected_order_arc_530  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_534  -14
    RHS1      connected_order_arc_536  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_555  -14
    RHS1      connected_order_arc_557  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_561  -14
    RHS1      connected_order_arc_563  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_582  -14
    RHS1      connected_order_arc_584  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_588  -14
    RHS1      connected_order_arc_590  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_609  -14
    RHS1      connected_order_arc_611  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_615  -14
    RHS1      connected_order_arc_617  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_636  -14
    RHS1      connected_order_arc_638  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_642  -14
    RHS1      connected_order_arc_644  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_663  -14
    RHS1      connected_order_arc_665  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_669  -14
    RHS1      connected_order_arc_671  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_690  -14
    RHS1      connected_order_arc_692  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_696  -14
    RHS1      connected_order_arc_698  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_717  -14
    RHS1      connected_order_arc_719  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_723  -14
    RHS1      connected_order_arc_725  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      depot_departure_or_bypass_740  1
    RHS1      depot_return_or_bypass_741  1
    RHS1      segment_load_conservation_746  3
    RHS1      segment_prefix_ub_748  27
    RHS1      segment_load_conservation_753  -1
    RHS1      segment_prefix_lb_754  1
    RHS1      segment_prefix_ub_755  30
    RHS1      segment_load_conservation_760  -2
    RHS1      segment_prefix_lb_761  2
    RHS1      segment_prefix_ub_762  30
    RHS1      segment_load_conservation_767  -1
    RHS1      segment_prefix_lb_768  1
    RHS1      segment_prefix_ub_769  30
    RHS1      segment_load_conservation_774  -3
    RHS1      segment_prefix_lb_775  3
    RHS1      segment_prefix_ub_776  30
    RHS1      segment_load_conservation_781  -1
    RHS1      segment_prefix_lb_782  1
    RHS1      segment_prefix_ub_783  30
    RHS1      fixed_segment_relative_order_832  1
    RHS1      fixed_segment_relative_order_833  1
    RHS1      fixed_segment_relative_order_834  1
    RHS1      fixed_segment_relative_order_835  1
    RHS1      fixed_segment_relative_order_836  1
    RHS1      original_T_including_depot_unload_837  4440
    RHS1      connected_order_arc_851  -10
    RHS1      connected_order_arc_853  -10
    RHS1      connected_order_arc_855  -10
    RHS1      connected_order_arc_857  -10
    RHS1      connected_order_arc_859  -10
    RHS1      connected_order_arc_861  -10
    RHS1      connected_order_arc_863  -10
    RHS1      connected_order_arc_865  -10
    RHS1      connected_order_arc_867  -10
    RHS1      connected_order_arc_870  -10
    RHS1      connected_order_arc_872  -10
    RHS1      connected_order_arc_874  -10
    RHS1      connected_order_arc_876  -10
    RHS1      connected_order_arc_878  -10
    RHS1      connected_order_arc_880  -10
    RHS1      connected_order_arc_882  -10
    RHS1      connected_order_arc_884  -10
    RHS1      connected_order_arc_886  -10
    RHS1      connected_order_arc_889  -10
    RHS1      connected_order_arc_891  -10
    RHS1      connected_order_arc_893  -10
    RHS1      connected_order_arc_895  -10
    RHS1      connected_order_arc_897  -10
    RHS1      connected_order_arc_899  -10
    RHS1      connected_order_arc_901  -10
    RHS1      connected_order_arc_903  -10
    RHS1      connected_order_arc_905  -10
    RHS1      connected_order_arc_908  -10
    RHS1      connected_order_arc_910  -10
    RHS1      connected_order_arc_912  -10
    RHS1      connected_order_arc_914  -10
    RHS1      connected_order_arc_916  -10
    RHS1      connected_order_arc_918  -10
    RHS1      connected_order_arc_920  -10
    RHS1      connected_order_arc_922  -10
    RHS1      connected_order_arc_924  -10
    RHS1      connected_order_arc_927  -10
    RHS1      connected_order_arc_929  -10
    RHS1      connected_order_arc_931  -10
    RHS1      connected_order_arc_933  -10
    RHS1      connected_order_arc_935  -10
    RHS1      connected_order_arc_937  -10
    RHS1      connected_order_arc_939  -10
    RHS1      connected_order_arc_941  -10
    RHS1      connected_order_arc_943  -10
    RHS1      connected_order_arc_946  -10
    RHS1      connected_order_arc_948  -10
    RHS1      connected_order_arc_950  -10
    RHS1      connected_order_arc_952  -10
    RHS1      connected_order_arc_954  -10
    RHS1      connected_order_arc_956  -10
    RHS1      connected_order_arc_958  -10
    RHS1      connected_order_arc_960  -10
    RHS1      connected_order_arc_962  -10
    RHS1      connected_order_arc_965  -10
    RHS1      connected_order_arc_967  -10
    RHS1      connected_order_arc_969  -10
    RHS1      connected_order_arc_971  -10
    RHS1      connected_order_arc_973  -10
    RHS1      connected_order_arc_975  -10
    RHS1      connected_order_arc_977  -10
    RHS1      connected_order_arc_979  -10
    RHS1      connected_order_arc_981  -10
    RHS1      connected_order_arc_984  -10
    RHS1      connected_order_arc_986  -10
    RHS1      connected_order_arc_988  -10
    RHS1      connected_order_arc_990  -10
    RHS1      connected_order_arc_992  -10
    RHS1      connected_order_arc_994  -10
    RHS1      connected_order_arc_996  -10
    RHS1      connected_order_arc_998  -10
    RHS1      connected_order_arc_1000  -10
    RHS1      connected_order_arc_1003  -10
    RHS1      connected_order_arc_1005  -10
    RHS1      connected_order_arc_1007  -10
    RHS1      connected_order_arc_1009  -10
    RHS1      connected_order_arc_1011  -10
    RHS1      connected_order_arc_1013  -10
    RHS1      connected_order_arc_1015  -10
    RHS1      connected_order_arc_1017  -10
    RHS1      connected_order_arc_1019  -10
    RHS1      connected_order_arc_1022  -10
    RHS1      connected_order_arc_1024  -10
    RHS1      connected_order_arc_1026  -10
    RHS1      connected_order_arc_1028  -10
    RHS1      connected_order_arc_1030  -10
    RHS1      connected_order_arc_1032  -10
    RHS1      connected_order_arc_1034  -10
    RHS1      connected_order_arc_1036  -10
    RHS1      connected_order_arc_1038  -10
    RHS1      depot_departure_or_bypass_1039  1
    RHS1      depot_return_or_bypass_1040  1
    RHS1      segment_load_conservation_1045  4
    RHS1      segment_prefix_ub_1047  26
    RHS1      segment_load_conservation_1052  -1
    RHS1      segment_prefix_lb_1053  1
    RHS1      segment_prefix_ub_1054  30
    RHS1      fixed_segment_relative_order_1103  1
    RHS1      original_T_including_depot_unload_1104  4320
BOUNDS
 LO BND1      t         4.0746370015805063e-02
 UP BND1      t         1.0130246020270624e-01
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_4_0   
 UP BND1      w_4_0     1.0130246020270624e-01
 BV BND1      x_4_1   
 UP BND1      w_4_1     1.0130246020270624e-01
 BV BND1      x_4_2   
 UP BND1      w_4_2     1.0130246020270624e-01
 BV BND1      x_4_3   
 UP BND1      w_4_3     1.0130246020270624e-01
 BV BND1      x_4_4   
 UP BND1      w_4_4     1.0130246020270624e-01
 BV BND1      x_4_5   
 UP BND1      w_4_5     1.0130246020270624e-01
 BV BND1      x_4_6   
 UP BND1      w_4_6     1.0130246020270624e-01
 BV BND1      x_4_7   
 UP BND1      w_4_7     1.0130246020270624e-01
 BV BND1      x_4_8   
 UP BND1      w_4_8     1.0130246020270624e-01
 BV BND1      x_4_9   
 UP BND1      w_4_9     1.0130246020270624e-01
 BV BND1      x_4_10  
 UP BND1      w_4_10    1.0130246020270624e-01
 BV BND1      x_4_11  
 UP BND1      w_4_11    1.0130246020270624e-01
 BV BND1      x_4_12  
 UP BND1      w_4_12    1.0130246020270624e-01
 BV BND1      x_4_13  
 UP BND1      w_4_13    1.0130246020270624e-01
 BV BND1      x_4_14  
 UP BND1      w_4_14    1.0130246020270624e-01
 BV BND1      x_4_15  
 UP BND1      w_4_15    1.0130246020270624e-01
 UP BND1      rho_4     1
 BV BND1      x_5_0   
 UP BND1      w_5_0     1.0130246020270624e-01
 BV BND1      x_5_1   
 UP BND1      w_5_1     1.0130246020270624e-01
 BV BND1      x_5_2   
 UP BND1      w_5_2     1.0130246020270624e-01
 UP BND1      rho_5     1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.0130246020270624e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.0130246020270624e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.0130246020270624e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.0130246020270624e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.0130246020270624e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.0130246020270624e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.0130246020270624e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.0130246020270624e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.0130246020270624e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.0130246020270624e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.0130246020270624e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.0130246020270624e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.0130246020270624e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.0130246020270624e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.0130246020270624e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.0130246020270624e-01
 UP BND1      rho_18    1
 BV BND1      x_8_0   
 UP BND1      w_8_0     1.0130246020270624e-01
 BV BND1      x_8_1   
 UP BND1      w_8_1     1.0130246020270624e-01
 BV BND1      x_8_2   
 UP BND1      w_8_2     1.0130246020270624e-01
 UP BND1      rho_8     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.0130246020270624e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.0130246020270624e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.0130246020270624e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.0130246020270624e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.0130246020270624e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.0130246020270624e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.0130246020270624e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.0130246020270624e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.0130246020270624e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.0130246020270624e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.0130246020270624e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.0130246020270624e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.0130246020270624e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.0130246020270624e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.0130246020270624e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.0130246020270624e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.0130246020270624e-01
 UP BND1      rho_17    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     1.0130246020270624e-01
 BV BND1      x_3_1   
 UP BND1      w_3_1     1.0130246020270624e-01
 BV BND1      x_3_2   
 UP BND1      w_3_2     1.0130246020270624e-01
 BV BND1      x_3_3   
 UP BND1      w_3_3     1.0130246020270624e-01
 BV BND1      x_3_4   
 UP BND1      w_3_4     1.0130246020270624e-01
 BV BND1      x_3_5   
 UP BND1      w_3_5     1.0130246020270624e-01
 BV BND1      x_3_6   
 UP BND1      w_3_6     1.0130246020270624e-01
 BV BND1      x_3_7   
 UP BND1      w_3_7     1.0130246020270624e-01
 BV BND1      x_3_8   
 UP BND1      w_3_8     1.0130246020270624e-01
 BV BND1      x_3_9   
 UP BND1      w_3_9     1.0130246020270624e-01
 BV BND1      x_3_10  
 UP BND1      w_3_10    1.0130246020270624e-01
 BV BND1      x_3_11  
 UP BND1      w_3_11    1.0130246020270624e-01
 BV BND1      x_3_12  
 UP BND1      w_3_12    1.0130246020270624e-01
 BV BND1      x_3_13  
 UP BND1      w_3_13    1.0130246020270624e-01
 BV BND1      x_3_14  
 UP BND1      w_3_14    1.0130246020270624e-01
 BV BND1      x_3_15  
 UP BND1      w_3_15    1.0130246020270624e-01
 BV BND1      x_3_16  
 UP BND1      w_3_16    1.0130246020270624e-01
 UP BND1      rho_3     1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.0130246020270624e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.0130246020270624e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.0130246020270624e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.0130246020270624e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.0130246020270624e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.0130246020270624e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.0130246020270624e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.0130246020270624e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.0130246020270624e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.0130246020270624e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.0130246020270624e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.0130246020270624e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.0130246020270624e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.0130246020270624e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.0130246020270624e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.0130246020270624e-01
 UP BND1      rho_11    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     1.0130246020270624e-01
 BV BND1      x_2_1   
 UP BND1      w_2_1     1.0130246020270624e-01
 UP BND1      rho_2     1
 UP BND1      a_4_5     1
 UP BND1      a_4_18    1
 UP BND1      a_4_8     1
 UP BND1      a_4_17    1
 UP BND1      a_4_3     1
 UP BND1      a_4_11    1
 UP BND1      a_4_2     1
 UP BND1      a_5_18    1
 UP BND1      a_5_8     1
 UP BND1      a_5_17    1
 UP BND1      a_5_3     1
 UP BND1      a_5_11    1
 UP BND1      a_5_2     1
 UP BND1      a_18_8    1
 UP BND1      a_18_17   1
 UP BND1      a_18_3    1
 UP BND1      a_18_11   1
 UP BND1      a_18_2    1
 UP BND1      a_8_17    1
 UP BND1      a_8_3     1
 UP BND1      a_8_11    1
 UP BND1      a_8_2     1
 UP BND1      a_17_3    1
 UP BND1      a_17_11   1
 UP BND1      a_17_2    1
 UP BND1      a_3_11    1
 UP BND1      a_3_2     1
 UP BND1      a_11_2    1
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_11
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_11
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_0_5_1
 BV BND1      service_0_5_2
 BV BND1      service_1_5_1
 BV BND1      service_1_5_2
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_2_1
 BV BND1      service_1_2_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  14
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  14
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  14
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  14
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_9
 UP BND1      load_0_6_9  30
 BV BND1      arc_0_6_10
 UP BND1      load_0_6_10  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_6
 UP BND1      load_0_9_6  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_9_16
 UP BND1      load_0_9_16  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_6
 UP BND1      load_0_10_6  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_10_16
 UP BND1      load_0_10_16  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_9
 UP BND1      load_0_16_9  30
 BV BND1      arc_0_16_10
 UP BND1      load_0_16_10  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  30
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
ENDATA
