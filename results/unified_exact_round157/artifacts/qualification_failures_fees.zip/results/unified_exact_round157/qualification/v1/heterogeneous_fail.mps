* Signature: 0x2b7e1795b5074d67
NAME R157_free_fleet_original_T
ROWS
 N  OBJ
 E  select_one_1
 E  select_one_2
 E  assign_service_1_1
 E  assign_service_2_2
 L  depart_once_0
 E  return_once_0
 L  original_time_0
 L  depart_once_1
 E  return_once_1
 L  original_time_1
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    select[1,1]  select_one_1  1
    select[1,1]  assign_service_1_1  -1
    select[2,2]  select_one_2  1
    select[2,2]  assign_service_2_2  -1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      select_one_1  1
    RHS1      select_one_2  1
    RHS1      depart_once_0  1
    RHS1      original_time_0  12
    RHS1      depart_once_1  1
    RHS1      original_time_1  12
BOUNDS
 BV BND1      select[1,1]
 BV BND1      select[2,2]
ENDATA
