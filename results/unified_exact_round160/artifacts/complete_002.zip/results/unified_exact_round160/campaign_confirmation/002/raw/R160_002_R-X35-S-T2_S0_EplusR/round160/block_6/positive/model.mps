* Signature: 0xb96a24fa6f2d3c7a
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_1_18
 E  normalized_mass_1_19
 E  normalized_ratio_1_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_2_53
 E  normalized_mass_2_54
 E  normalized_ratio_2_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 E  onehot_34_88
 E  normalized_mass_34_89
 E  normalized_ratio_34_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 E  onehot_3_117
 E  normalized_mass_3_118
 E  normalized_ratio_3_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 E  onehot_22_152
 E  normalized_mass_22_153
 E  normalized_ratio_22_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 E  onehot_4_187
 E  normalized_mass_4_188
 E  normalized_ratio_4_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 E  onehot_27_204
 E  normalized_mass_27_205
 E  normalized_ratio_27_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 E  onehot_5_239
 E  normalized_mass_5_240
 E  normalized_ratio_5_241
 G  stock_lb_242
 L  stock_ub_243
 L  parent_nonstrict_scope_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 E  normalization_301
 G  full_original_Gini_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 L  arc_capacity_404
 L  arc_capacity_405
 L  arc_capacity_406
 L  arc_capacity_407
 L  arc_capacity_408
 L  arc_capacity_409
 L  arc_capacity_410
 L  arc_capacity_411
 L  arc_capacity_412
 L  arc_capacity_413
 L  arc_capacity_414
 L  arc_capacity_415
 L  arc_capacity_416
 L  arc_capacity_417
 L  arc_capacity_418
 L  arc_capacity_419
 L  arc_capacity_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 E  depot_departure_or_bypass_855
 E  depot_return_or_bypass_856
 E  out_degree_857
 E  in_degree_858
 G  order_active_lb_859
 L  order_active_ub_860
 E  segment_load_conservation_861
 G  segment_prefix_lb_862
 L  segment_prefix_ub_863
 E  out_degree_864
 E  in_degree_865
 G  order_active_lb_866
 L  order_active_ub_867
 E  segment_load_conservation_868
 G  segment_prefix_lb_869
 L  segment_prefix_ub_870
 E  out_degree_871
 E  in_degree_872
 G  order_active_lb_873
 L  order_active_ub_874
 E  segment_load_conservation_875
 G  segment_prefix_lb_876
 L  segment_prefix_ub_877
 E  out_degree_878
 E  in_degree_879
 G  order_active_lb_880
 L  order_active_ub_881
 E  segment_load_conservation_882
 G  segment_prefix_lb_883
 L  segment_prefix_ub_884
 E  out_degree_885
 E  in_degree_886
 G  order_active_lb_887
 L  order_active_ub_888
 E  segment_load_conservation_889
 G  segment_prefix_lb_890
 L  segment_prefix_ub_891
 E  out_degree_892
 E  in_degree_893
 G  order_active_lb_894
 L  order_active_ub_895
 E  segment_load_conservation_896
 G  segment_prefix_lb_897
 L  segment_prefix_ub_898
 E  out_degree_899
 E  in_degree_900
 G  order_active_lb_901
 L  order_active_ub_902
 E  segment_load_conservation_903
 G  segment_prefix_lb_904
 L  segment_prefix_ub_905
 E  out_degree_906
 E  in_degree_907
 G  order_active_lb_908
 L  order_active_ub_909
 E  service_visit_def_910
 E  free_load_conservation_911
 E  out_degree_912
 E  in_degree_913
 G  order_active_lb_914
 L  order_active_ub_915
 E  service_visit_def_916
 E  free_load_conservation_917
 E  out_degree_918
 E  in_degree_919
 G  order_active_lb_920
 L  order_active_ub_921
 E  service_visit_def_922
 E  free_load_conservation_923
 E  out_degree_924
 E  in_degree_925
 G  order_active_lb_926
 L  order_active_ub_927
 E  service_visit_def_928
 E  free_load_conservation_929
 E  out_degree_930
 E  in_degree_931
 G  order_active_lb_932
 L  order_active_ub_933
 E  service_visit_def_934
 E  free_load_conservation_935
 E  out_degree_936
 E  in_degree_937
 G  order_active_lb_938
 L  order_active_ub_939
 E  service_visit_def_940
 E  free_load_conservation_941
 E  out_degree_942
 E  in_degree_943
 G  order_active_lb_944
 L  order_active_ub_945
 E  service_visit_def_946
 E  free_load_conservation_947
 E  out_degree_948
 E  in_degree_949
 G  order_active_lb_950
 L  order_active_ub_951
 E  service_visit_def_952
 E  free_load_conservation_953
 G  fixed_segment_relative_order_954
 G  fixed_segment_relative_order_955
 G  fixed_segment_relative_order_956
 G  fixed_segment_relative_order_957
 G  fixed_segment_relative_order_958
 G  fixed_segment_relative_order_959
 L  original_T_including_depot_unload_960
 L  arc_capacity_961
 L  arc_capacity_962
 L  arc_capacity_963
 L  arc_capacity_964
 L  arc_capacity_965
 L  arc_capacity_966
 L  arc_capacity_967
 L  arc_capacity_968
 L  arc_capacity_969
 L  arc_capacity_970
 L  arc_capacity_971
 L  arc_capacity_972
 L  arc_capacity_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 E  depot_departure_or_bypass_1204
 E  depot_return_or_bypass_1205
 E  out_degree_1206
 E  in_degree_1207
 G  order_active_lb_1208
 L  order_active_ub_1209
 E  segment_load_conservation_1210
 G  segment_prefix_lb_1211
 L  segment_prefix_ub_1212
 E  out_degree_1213
 E  in_degree_1214
 G  order_active_lb_1215
 L  order_active_ub_1216
 E  segment_load_conservation_1217
 G  segment_prefix_lb_1218
 L  segment_prefix_ub_1219
 E  out_degree_1220
 E  in_degree_1221
 G  order_active_lb_1222
 L  order_active_ub_1223
 E  segment_load_conservation_1224
 G  segment_prefix_lb_1225
 L  segment_prefix_ub_1226
 E  out_degree_1227
 E  in_degree_1228
 G  order_active_lb_1229
 L  order_active_ub_1230
 E  service_visit_def_1231
 E  free_load_conservation_1232
 E  out_degree_1233
 E  in_degree_1234
 G  order_active_lb_1235
 L  order_active_ub_1236
 E  service_visit_def_1237
 E  free_load_conservation_1238
 E  out_degree_1239
 E  in_degree_1240
 G  order_active_lb_1241
 L  order_active_ub_1242
 E  service_visit_def_1243
 E  free_load_conservation_1244
 E  out_degree_1245
 E  in_degree_1246
 G  order_active_lb_1247
 L  order_active_ub_1248
 E  service_visit_def_1249
 E  free_load_conservation_1250
 E  out_degree_1251
 E  in_degree_1252
 G  order_active_lb_1253
 L  order_active_ub_1254
 E  service_visit_def_1255
 E  free_load_conservation_1256
 E  out_degree_1257
 E  in_degree_1258
 G  order_active_lb_1259
 L  order_active_ub_1260
 E  service_visit_def_1261
 E  free_load_conservation_1262
 E  out_degree_1263
 E  in_degree_1264
 G  order_active_lb_1265
 L  order_active_ub_1266
 E  service_visit_def_1267
 E  free_load_conservation_1268
 E  out_degree_1269
 E  in_degree_1270
 G  order_active_lb_1271
 L  order_active_ub_1272
 E  service_visit_def_1273
 E  free_load_conservation_1274
 G  fixed_segment_relative_order_1275
 G  fixed_segment_relative_order_1276
 L  original_T_including_depot_unload_1277
 L  arc_capacity_1278
 L  arc_capacity_1279
 L  arc_capacity_1280
 L  arc_capacity_1281
 L  arc_capacity_1282
 L  arc_capacity_1283
 L  arc_capacity_1284
 L  arc_capacity_1285
 L  arc_capacity_1286
 L  arc_capacity_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 G  connected_order_arc_1518
 L  arc_capacity_1519
 G  connected_order_arc_1520
 L  arc_capacity_1521
 L  arc_capacity_1522
 G  connected_order_arc_1523
 L  arc_capacity_1524
 G  connected_order_arc_1525
 L  arc_capacity_1526
 G  connected_order_arc_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 G  connected_order_arc_1531
 L  arc_capacity_1532
 G  connected_order_arc_1533
 L  arc_capacity_1534
 G  connected_order_arc_1535
 L  arc_capacity_1536
 G  connected_order_arc_1537
 L  arc_capacity_1538
 G  connected_order_arc_1539
 L  arc_capacity_1540
 G  connected_order_arc_1541
 L  arc_capacity_1542
 G  connected_order_arc_1543
 L  arc_capacity_1544
 L  arc_capacity_1545
 G  connected_order_arc_1546
 L  arc_capacity_1547
 G  connected_order_arc_1548
 L  arc_capacity_1549
 G  connected_order_arc_1550
 L  arc_capacity_1551
 G  connected_order_arc_1552
 L  arc_capacity_1553
 G  connected_order_arc_1554
 L  arc_capacity_1555
 G  connected_order_arc_1556
 L  arc_capacity_1557
 G  connected_order_arc_1558
 L  arc_capacity_1559
 G  connected_order_arc_1560
 L  arc_capacity_1561
 G  connected_order_arc_1562
 L  arc_capacity_1563
 G  connected_order_arc_1564
 L  arc_capacity_1565
 G  connected_order_arc_1566
 E  depot_departure_or_bypass_1567
 E  depot_return_or_bypass_1568
 E  out_degree_1569
 E  in_degree_1570
 G  order_active_lb_1571
 L  order_active_ub_1572
 E  segment_load_conservation_1573
 G  segment_prefix_lb_1574
 L  segment_prefix_ub_1575
 E  out_degree_1576
 E  in_degree_1577
 G  order_active_lb_1578
 L  order_active_ub_1579
 E  segment_load_conservation_1580
 G  segment_prefix_lb_1581
 L  segment_prefix_ub_1582
 E  out_degree_1583
 E  in_degree_1584
 G  order_active_lb_1585
 L  order_active_ub_1586
 E  segment_load_conservation_1587
 G  segment_prefix_lb_1588
 L  segment_prefix_ub_1589
 E  out_degree_1590
 E  in_degree_1591
 G  order_active_lb_1592
 L  order_active_ub_1593
 E  segment_load_conservation_1594
 G  segment_prefix_lb_1595
 L  segment_prefix_ub_1596
 E  out_degree_1597
 E  in_degree_1598
 G  order_active_lb_1599
 L  order_active_ub_1600
 E  service_visit_def_1601
 E  free_load_conservation_1602
 E  out_degree_1603
 E  in_degree_1604
 G  order_active_lb_1605
 L  order_active_ub_1606
 E  service_visit_def_1607
 E  free_load_conservation_1608
 E  out_degree_1609
 E  in_degree_1610
 G  order_active_lb_1611
 L  order_active_ub_1612
 E  service_visit_def_1613
 E  free_load_conservation_1614
 E  out_degree_1615
 E  in_degree_1616
 G  order_active_lb_1617
 L  order_active_ub_1618
 E  service_visit_def_1619
 E  free_load_conservation_1620
 E  out_degree_1621
 E  in_degree_1622
 G  order_active_lb_1623
 L  order_active_ub_1624
 E  service_visit_def_1625
 E  free_load_conservation_1626
 E  out_degree_1627
 E  in_degree_1628
 G  order_active_lb_1629
 L  order_active_ub_1630
 E  service_visit_def_1631
 E  free_load_conservation_1632
 E  out_degree_1633
 E  in_degree_1634
 G  order_active_lb_1635
 L  order_active_ub_1636
 E  service_visit_def_1637
 E  free_load_conservation_1638
 E  out_degree_1639
 E  in_degree_1640
 G  order_active_lb_1641
 L  order_active_ub_1642
 E  service_visit_def_1643
 E  free_load_conservation_1644
 G  fixed_segment_relative_order_1645
 G  fixed_segment_relative_order_1646
 G  fixed_segment_relative_order_1647
 L  original_T_including_depot_unload_1648
COLUMNS
    t         normalized_mass_1_19  -1
    t         normalized_mass_2_54  -1
    t         normalized_mass_34_89  -1
    t         normalized_mass_3_118  -1
    t         normalized_mass_22_153  -1
    t         normalized_mass_4_188  -1
    t         normalized_mass_27_205  -1
    t         normalized_mass_5_240  -1
    t         normalization_301  2.2255952380952380e+01
    t         full_original_Gini_302  -8.4066666666666620e+01
    q         OBJ       1
    q         parent_nonstrict_scope_244  1
    q         full_original_Gini_302  35
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       7.4474103065332977e-03
    x_1_0     product_lb_0  -2.5838203629626577e-02
    x_1_0     product_ub_1  -4.4931799946554711e-02
    x_1_0     onehot_1_18  1
    x_1_0     parent_nonstrict_scope_244  1.4894820613066595e-02
    x_1_0     unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_0  1
    w_1_0     product_ub_1  1
    w_1_0     normalized_mass_1_19  1
    w_1_0     full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       3.7237051532666493e-03
    x_1_1     product_lb_2  -2.5838203629626577e-02
    x_1_1     product_ub_3  -4.4931799946554711e-02
    x_1_1     onehot_1_18  1
    x_1_1     stock_lb_242  1
    x_1_1     stock_ub_243  1
    x_1_1     parent_nonstrict_scope_244  1.1171115459799947e-02
    x_1_1     unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_2  1
    w_1_1     product_ub_3  1
    w_1_1     normalized_mass_1_19  1
    w_1_1     normalized_ratio_1_20  -0.25
    w_1_1     full_original_Gini_302  -1.6005952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_2     product_lb_4  -2.5838203629626577e-02
    x_1_2     product_ub_5  -4.4931799946554711e-02
    x_1_2     onehot_1_18  1
    x_1_2     stock_lb_242  2
    x_1_2     stock_ub_243  2
    x_1_2     parent_nonstrict_scope_244  7.4474103065332977e-03
    x_1_2     unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_4  1
    w_1_2     product_ub_5  1
    w_1_2     normalized_mass_1_19  1
    w_1_2     normalized_ratio_1_20  -0.5
    w_1_2     full_original_Gini_302  -9.9559523809523789e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_3     OBJ       -3.7237051532666488e-03
    x_1_3     product_lb_6  -2.5838203629626577e-02
    x_1_3     product_ub_7  -4.4931799946554711e-02
    x_1_3     onehot_1_18  1
    x_1_3     stock_lb_242  3
    x_1_3     stock_ub_243  3
    x_1_3     parent_nonstrict_scope_244  3.7237051532666488e-03
    x_1_3     unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_6  1
    w_1_3     product_ub_7  1
    w_1_3     normalized_mass_1_19  1
    w_1_3     normalized_ratio_1_20  -0.75
    w_1_3     full_original_Gini_302  -5.3607142857142849e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       -7.4474103065332977e-03
    x_1_4     product_lb_8  -2.5838203629626577e-02
    x_1_4     product_ub_9  -4.4931799946554711e-02
    x_1_4     onehot_1_18  1
    x_1_4     stock_lb_242  4
    x_1_4     stock_ub_243  4
    x_1_4     unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_8  1
    w_1_4     product_ub_9  1
    w_1_4     normalized_mass_1_19  1
    w_1_4     normalized_ratio_1_20  -1
    w_1_4     full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_5     OBJ       -3.7237051532666488e-03
    x_1_5     product_lb_10  -2.5838203629626577e-02
    x_1_5     product_ub_11  -4.4931799946554711e-02
    x_1_5     onehot_1_18  1
    x_1_5     stock_lb_242  5
    x_1_5     stock_ub_243  5
    x_1_5     parent_nonstrict_scope_244  3.7237051532666488e-03
    x_1_5     unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_10  1
    w_1_5     product_ub_11  1
    w_1_5     normalized_mass_1_19  1
    w_1_5     normalized_ratio_1_20  -1.25
    w_1_5     full_original_Gini_302  -1.1494047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_6     product_lb_12  -2.5838203629626577e-02
    x_1_6     product_ub_13  -4.4931799946554711e-02
    x_1_6     onehot_1_18  1
    x_1_6     stock_lb_242  6
    x_1_6     stock_ub_243  6
    x_1_6     parent_nonstrict_scope_244  7.4474103065332977e-03
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_12  1
    w_1_6     product_ub_13  1
    w_1_6     normalized_mass_1_19  1
    w_1_6     normalized_ratio_1_20  -1.5
    w_1_6     full_original_Gini_302  -1.8244047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       3.7237051532666493e-03
    x_1_7     product_lb_14  -2.5838203629626577e-02
    x_1_7     product_ub_15  -4.4931799946554711e-02
    x_1_7     onehot_1_18  1
    x_1_7     stock_lb_242  7
    x_1_7     stock_ub_243  7
    x_1_7     parent_nonstrict_scope_244  1.1171115459799947e-02
    x_1_7     unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_14  1
    w_1_7     product_ub_15  1
    w_1_7     normalized_mass_1_19  1
    w_1_7     normalized_ratio_1_20  -1.75
    w_1_7     full_original_Gini_302  -2.4994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       7.4474103065332977e-03
    x_1_8     product_lb_16  -2.5838203629626577e-02
    x_1_8     product_ub_17  -4.4931799946554711e-02
    x_1_8     onehot_1_18  1
    x_1_8     stock_lb_242  8
    x_1_8     stock_ub_243  8
    x_1_8     parent_nonstrict_scope_244  1.4894820613066595e-02
    x_1_8     unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_16  1
    w_1_8     product_ub_17  1
    w_1_8     normalized_mass_1_19  1
    w_1_8     normalized_ratio_1_20  -2
    w_1_8     full_original_Gini_302  -3.1744047619047620e+01
    rho_1     normalized_ratio_1_20  1
    rho_1     block_pair_pos_245  -1
    rho_1     block_pair_neg_246  1
    rho_1     block_pair_pos_247  -1
    rho_1     block_pair_neg_248  1
    rho_1     block_pair_pos_249  -1
    rho_1     block_pair_neg_250  1
    rho_1     block_pair_pos_251  -1
    rho_1     block_pair_neg_252  1
    rho_1     block_pair_pos_253  -1
    rho_1     block_pair_neg_254  1
    rho_1     block_pair_pos_255  -1
    rho_1     block_pair_neg_256  1
    rho_1     block_pair_pos_257  -1
    rho_1     block_pair_neg_258  1
    rho_1     normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       1.9549429837111887e-02
    x_2_0     product_lb_21  -2.5838203629626577e-02
    x_2_0     product_ub_22  -4.4931799946554711e-02
    x_2_0     onehot_2_53  1
    x_2_0     parent_nonstrict_scope_244  0.0456153362865944
    x_2_0     unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_21  1
    w_2_0     product_ub_22  1
    w_2_0     normalized_mass_2_54  1
    w_2_0     full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       1.3032953224741260e-02
    x_2_1     product_lb_23  -2.5838203629626577e-02
    x_2_1     product_ub_24  -4.4931799946554711e-02
    x_2_1     onehot_2_53  1
    x_2_1     stock_lb_242  1
    x_2_1     stock_ub_243  1
    x_2_1     parent_nonstrict_scope_244  3.9098859674223774e-02
    x_2_1     unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_23  1
    w_2_1     product_ub_24  1
    w_2_1     normalized_mass_2_54  1
    w_2_1     normalized_ratio_2_55  -1.4285714285714285e-01
    w_2_1     full_original_Gini_302  -1.8684523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       6.5164766123706336e-03
    x_2_2     product_lb_25  -2.5838203629626577e-02
    x_2_2     product_ub_26  -4.4931799946554711e-02
    x_2_2     onehot_2_53  1
    x_2_2     stock_lb_242  2
    x_2_2     stock_ub_243  2
    x_2_2     parent_nonstrict_scope_244  3.2582383061853147e-02
    x_2_2     unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_25  1
    w_2_2     product_ub_26  1
    w_2_2     normalized_mass_2_54  1
    w_2_2     normalized_ratio_2_55  -2.8571428571428570e-01
    w_2_2     full_original_Gini_302  -1.5113095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_27  -2.5838203629626577e-02
    x_2_3     product_ub_28  -4.4931799946554711e-02
    x_2_3     onehot_2_53  1
    x_2_3     stock_lb_242  3
    x_2_3     stock_ub_243  3
    x_2_3     parent_nonstrict_scope_244  2.6065906449482514e-02
    x_2_3     unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_27  1
    w_2_3     product_ub_28  1
    w_2_3     normalized_mass_2_54  1
    w_2_3     normalized_ratio_2_55  -4.2857142857142855e-01
    w_2_3     full_original_Gini_302  -1.1598809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -6.5164766123706266e-03
    x_2_4     product_lb_29  -2.5838203629626577e-02
    x_2_4     product_ub_30  -4.4931799946554711e-02
    x_2_4     onehot_2_53  1
    x_2_4     stock_lb_242  4
    x_2_4     stock_ub_243  4
    x_2_4     parent_nonstrict_scope_244  1.9549429837111887e-02
    x_2_4     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_29  1
    w_2_4     product_ub_30  1
    w_2_4     normalized_mass_2_54  1
    w_2_4     normalized_ratio_2_55  -5.7142857142857140e-01
    w_2_4     full_original_Gini_302  -8.4559523809523842e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -1.3032953224741252e-02
    x_2_5     product_lb_31  -2.5838203629626577e-02
    x_2_5     product_ub_32  -4.4931799946554711e-02
    x_2_5     onehot_2_53  1
    x_2_5     stock_lb_242  5
    x_2_5     stock_ub_243  5
    x_2_5     parent_nonstrict_scope_244  1.3032953224741262e-02
    x_2_5     unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_31  1
    w_2_5     product_ub_32  1
    w_2_5     normalized_mass_2_54  1
    w_2_5     normalized_ratio_2_55  -7.1428571428571419e-01
    w_2_5     full_original_Gini_302  -5.8249999999999993e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -1.9549429837111883e-02
    x_2_6     product_lb_33  -2.5838203629626577e-02
    x_2_6     product_ub_34  -4.4931799946554711e-02
    x_2_6     onehot_2_53  1
    x_2_6     stock_lb_242  6
    x_2_6     stock_ub_243  6
    x_2_6     parent_nonstrict_scope_244  6.5164766123706310e-03
    x_2_6     unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_33  1
    w_2_6     product_ub_34  1
    w_2_6     normalized_mass_2_54  1
    w_2_6     normalized_ratio_2_55  -8.5714285714285710e-01
    w_2_6     full_original_Gini_302  -4.8869047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -2.6065906449482514e-02
    x_2_7     product_lb_35  -2.5838203629626577e-02
    x_2_7     product_ub_36  -4.4931799946554711e-02
    x_2_7     onehot_2_53  1
    x_2_7     stock_lb_242  7
    x_2_7     stock_ub_243  7
    x_2_7     unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_35  1
    w_2_7     product_ub_36  1
    w_2_7     normalized_mass_2_54  1
    w_2_7     normalized_ratio_2_55  -1
    w_2_7     full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -1.9549429837111887e-02
    x_2_8     product_lb_37  -2.5838203629626577e-02
    x_2_8     product_ub_38  -4.4931799946554711e-02
    x_2_8     onehot_2_53  1
    x_2_8     stock_lb_242  8
    x_2_8     stock_ub_243  8
    x_2_8     parent_nonstrict_scope_244  6.5164766123706258e-03
    x_2_8     unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_37  1
    w_2_8     product_ub_38  1
    w_2_8     normalized_mass_2_54  1
    w_2_8     normalized_ratio_2_55  -1.1428571428571428e+00
    w_2_8     full_original_Gini_302  -8.6011904761904727e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -1.3032953224741262e-02
    x_2_9     product_lb_39  -2.5838203629626577e-02
    x_2_9     product_ub_40  -4.4931799946554711e-02
    x_2_9     onehot_2_53  1
    x_2_9     stock_lb_242  9
    x_2_9     stock_ub_243  9
    x_2_9     parent_nonstrict_scope_244  1.3032953224741252e-02
    x_2_9     unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_39  1
    w_2_9     product_ub_40  1
    w_2_9     normalized_mass_2_54  1
    w_2_9     normalized_ratio_2_55  -1.2857142857142856e+00
    w_2_9     full_original_Gini_302  -1.2458333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -6.5164766123706371e-03
    x_2_10    product_lb_41  -2.5838203629626577e-02
    x_2_10    product_ub_42  -4.4931799946554711e-02
    x_2_10    onehot_2_53  1
    x_2_10    stock_lb_242  10
    x_2_10    stock_ub_243  10
    x_2_10    parent_nonstrict_scope_244  1.9549429837111876e-02
    x_2_10    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_41  1
    w_2_10    product_ub_42  1
    w_2_10    normalized_mass_2_54  1
    w_2_10    normalized_ratio_2_55  -1.4285714285714284e+00
    w_2_10    full_original_Gini_302  -1.6315476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_43  -2.5838203629626577e-02
    x_2_11    product_ub_44  -4.4931799946554711e-02
    x_2_11    onehot_2_53  1
    x_2_11    stock_lb_242  11
    x_2_11    stock_ub_243  11
    x_2_11    parent_nonstrict_scope_244  2.6065906449482514e-02
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_43  1
    w_2_11    product_ub_44  1
    w_2_11    normalized_mass_2_54  1
    w_2_11    normalized_ratio_2_55  -1.5714285714285714e+00
    w_2_11    full_original_Gini_302  -2.0172619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       6.5164766123706266e-03
    x_2_12    product_lb_45  -2.5838203629626577e-02
    x_2_12    product_ub_46  -4.4931799946554711e-02
    x_2_12    onehot_2_53  1
    x_2_12    stock_lb_242  12
    x_2_12    stock_ub_243  12
    x_2_12    parent_nonstrict_scope_244  3.2582383061853140e-02
    x_2_12    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_45  1
    w_2_12    product_ub_46  1
    w_2_12    normalized_mass_2_54  1
    w_2_12    normalized_ratio_2_55  -1.7142857142857142e+00
    w_2_12    full_original_Gini_302  -24.0297619047619
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       1.3032953224741253e-02
    x_2_13    product_lb_47  -2.5838203629626577e-02
    x_2_13    product_ub_48  -4.4931799946554711e-02
    x_2_13    onehot_2_53  1
    x_2_13    stock_lb_242  13
    x_2_13    stock_ub_243  13
    x_2_13    parent_nonstrict_scope_244  3.9098859674223767e-02
    x_2_13    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_47  1
    w_2_13    product_ub_48  1
    w_2_13    normalized_mass_2_54  1
    w_2_13    normalized_ratio_2_55  -1.8571428571428570e+00
    w_2_13    full_original_Gini_302  -2.7886904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       1.9549429837111887e-02
    x_2_14    product_lb_49  -2.5838203629626577e-02
    x_2_14    product_ub_50  -4.4931799946554711e-02
    x_2_14    onehot_2_53  1
    x_2_14    stock_lb_242  14
    x_2_14    stock_ub_243  14
    x_2_14    parent_nonstrict_scope_244  0.0456153362865944
    x_2_14    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_49  1
    w_2_14    product_ub_50  1
    w_2_14    normalized_mass_2_54  1
    w_2_14    normalized_ratio_2_55  -2
    w_2_14    full_original_Gini_302  -3.1744047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       2.6065906449482514e-02
    x_2_15    product_lb_51  -2.5838203629626577e-02
    x_2_15    product_ub_52  -4.4931799946554711e-02
    x_2_15    onehot_2_53  1
    x_2_15    stock_lb_242  15
    x_2_15    stock_ub_243  15
    x_2_15    parent_nonstrict_scope_244  5.2131812898965027e-02
    x_2_15    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_51  1
    w_2_15    product_ub_52  1
    w_2_15    normalized_mass_2_54  1
    w_2_15    normalized_ratio_2_55  -2.1428571428571428e+00
    w_2_15    full_original_Gini_302  -3.5601190476190474e+01
    rho_2     normalized_ratio_2_55  1
    rho_2     block_pair_pos_245  1
    rho_2     block_pair_neg_246  -1
    rho_2     block_pair_pos_259  -1
    rho_2     block_pair_neg_260  1
    rho_2     block_pair_pos_261  -1
    rho_2     block_pair_neg_262  1
    rho_2     block_pair_pos_263  -1
    rho_2     block_pair_neg_264  1
    rho_2     block_pair_pos_265  -1
    rho_2     block_pair_neg_266  1
    rho_2     block_pair_pos_267  -1
    rho_2     block_pair_neg_268  1
    rho_2     block_pair_pos_269  -1
    rho_2     block_pair_neg_270  1
    rho_2     normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_56  -2.5838203629626577e-02
    x_34_0    product_ub_57  -4.4931799946554711e-02
    x_34_0    onehot_34_88  1
    x_34_0    parent_nonstrict_scope_244  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_56  1
    w_34_0    product_ub_57  1
    w_34_0    normalized_mass_34_89  1
    w_34_0    full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_58  -2.5838203629626577e-02
    x_34_1    product_ub_59  -4.4931799946554711e-02
    x_34_1    onehot_34_88  1
    x_34_1    stock_lb_242  1
    x_34_1    stock_ub_243  1
    x_34_1    parent_nonstrict_scope_244  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_58  1
    w_34_1    product_ub_59  1
    w_34_1    normalized_mass_34_89  1
    w_34_1    normalized_ratio_34_90  -0.125
    w_34_1    full_original_Gini_302  -1.9130952380952383e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_60  -2.5838203629626577e-02
    x_34_2    product_ub_61  -4.4931799946554711e-02
    x_34_2    onehot_34_88  1
    x_34_2    stock_lb_242  2
    x_34_2    stock_ub_243  2
    x_34_2    parent_nonstrict_scope_244  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_60  1
    w_34_2    product_ub_61  1
    w_34_2    normalized_mass_34_89  1
    w_34_2    normalized_ratio_34_90  -0.25
    w_34_2    full_original_Gini_302  -1.6005952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_62  -2.5838203629626577e-02
    x_34_3    product_ub_63  -4.4931799946554711e-02
    x_34_3    onehot_34_88  1
    x_34_3    stock_lb_242  3
    x_34_3    stock_ub_243  3
    x_34_3    parent_nonstrict_scope_244  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_62  1
    w_34_3    product_ub_63  1
    w_34_3    normalized_mass_34_89  1
    w_34_3    normalized_ratio_34_90  -0.375
    w_34_3    full_original_Gini_302  -1.2880952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_64  -2.5838203629626577e-02
    x_34_4    product_ub_65  -4.4931799946554711e-02
    x_34_4    onehot_34_88  1
    x_34_4    stock_lb_242  4
    x_34_4    stock_ub_243  4
    x_34_4    parent_nonstrict_scope_244  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_64  1
    w_34_4    product_ub_65  1
    w_34_4    normalized_mass_34_89  1
    w_34_4    normalized_ratio_34_90  -0.5
    w_34_4    full_original_Gini_302  -9.9559523809523789e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_66  -2.5838203629626577e-02
    x_34_5    product_ub_67  -4.4931799946554711e-02
    x_34_5    onehot_34_88  1
    x_34_5    stock_lb_242  5
    x_34_5    stock_ub_243  5
    x_34_5    parent_nonstrict_scope_244  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_66  1
    w_34_5    product_ub_67  1
    w_34_5    normalized_mass_34_89  1
    w_34_5    normalized_ratio_34_90  -0.625
    w_34_5    full_original_Gini_302  -7.3309523809523807e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_68  -2.5838203629626577e-02
    x_34_6    product_ub_69  -4.4931799946554711e-02
    x_34_6    onehot_34_88  1
    x_34_6    stock_lb_242  6
    x_34_6    stock_ub_243  6
    x_34_6    parent_nonstrict_scope_244  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_68  1
    w_34_6    product_ub_69  1
    w_34_6    normalized_mass_34_89  1
    w_34_6    normalized_ratio_34_90  -0.75
    w_34_6    full_original_Gini_302  -5.3607142857142849e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_70  -2.5838203629626577e-02
    x_34_7    product_ub_71  -4.4931799946554711e-02
    x_34_7    onehot_34_88  1
    x_34_7    stock_lb_242  7
    x_34_7    stock_ub_243  7
    x_34_7    parent_nonstrict_scope_244  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_70  1
    w_34_7    product_ub_71  1
    w_34_7    normalized_mass_34_89  1
    w_34_7    normalized_ratio_34_90  -0.875
    w_34_7    full_original_Gini_302  -4.8690476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_72  -2.5838203629626577e-02
    x_34_8    product_ub_73  -4.4931799946554711e-02
    x_34_8    onehot_34_88  1
    x_34_8    stock_lb_242  8
    x_34_8    stock_ub_243  8
    x_34_8    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_72  1
    w_34_8    product_ub_73  1
    w_34_8    normalized_mass_34_89  1
    w_34_8    normalized_ratio_34_90  -1
    w_34_8    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_74  -2.5838203629626577e-02
    x_34_9    product_ub_75  -4.4931799946554711e-02
    x_34_9    onehot_34_88  1
    x_34_9    stock_lb_242  9
    x_34_9    stock_ub_243  9
    x_34_9    parent_nonstrict_scope_244  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_74  1
    w_34_9    product_ub_75  1
    w_34_9    normalized_mass_34_89  1
    w_34_9    normalized_ratio_34_90  -1.125
    w_34_9    full_original_Gini_302  -8.1190476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_76  -2.5838203629626577e-02
    x_34_10   product_ub_77  -4.4931799946554711e-02
    x_34_10   onehot_34_88  1
    x_34_10   stock_lb_242  10
    x_34_10   stock_ub_243  10
    x_34_10   parent_nonstrict_scope_244  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_76  1
    w_34_10   product_ub_77  1
    w_34_10   normalized_mass_34_89  1
    w_34_10   normalized_ratio_34_90  -1.25
    w_34_10   full_original_Gini_302  -1.1494047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_78  -2.5838203629626577e-02
    x_34_11   product_ub_79  -4.4931799946554711e-02
    x_34_11   onehot_34_88  1
    x_34_11   stock_lb_242  11
    x_34_11   stock_ub_243  11
    x_34_11   parent_nonstrict_scope_244  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_78  1
    w_34_11   product_ub_79  1
    w_34_11   normalized_mass_34_89  1
    w_34_11   normalized_ratio_34_90  -1.375
    w_34_11   full_original_Gini_302  -1.4869047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_80  -2.5838203629626577e-02
    x_34_12   product_ub_81  -4.4931799946554711e-02
    x_34_12   onehot_34_88  1
    x_34_12   stock_lb_242  12
    x_34_12   stock_ub_243  12
    x_34_12   parent_nonstrict_scope_244  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_80  1
    w_34_12   product_ub_81  1
    w_34_12   normalized_mass_34_89  1
    w_34_12   normalized_ratio_34_90  -1.5
    w_34_12   full_original_Gini_302  -1.8244047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_82  -2.5838203629626577e-02
    x_34_13   product_ub_83  -4.4931799946554711e-02
    x_34_13   onehot_34_88  1
    x_34_13   stock_lb_242  13
    x_34_13   stock_ub_243  13
    x_34_13   parent_nonstrict_scope_244  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_82  1
    w_34_13   product_ub_83  1
    w_34_13   normalized_mass_34_89  1
    w_34_13   normalized_ratio_34_90  -1.625
    w_34_13   full_original_Gini_302  -2.1619047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_84  -2.5838203629626577e-02
    x_34_14   product_ub_85  -4.4931799946554711e-02
    x_34_14   onehot_34_88  1
    x_34_14   stock_lb_242  14
    x_34_14   stock_ub_243  14
    x_34_14   parent_nonstrict_scope_244  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_84  1
    w_34_14   product_ub_85  1
    w_34_14   normalized_mass_34_89  1
    w_34_14   normalized_ratio_34_90  -1.75
    w_34_14   full_original_Gini_302  -2.4994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_86  -2.5838203629626577e-02
    x_34_15   product_ub_87  -4.4931799946554711e-02
    x_34_15   onehot_34_88  1
    x_34_15   stock_lb_242  15
    x_34_15   stock_ub_243  15
    x_34_15   parent_nonstrict_scope_244  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_86  1
    w_34_15   product_ub_87  1
    w_34_15   normalized_mass_34_89  1
    w_34_15   normalized_ratio_34_90  -1.875
    w_34_15   full_original_Gini_302  -2.8369047619047620e+01
    rho_34    normalized_ratio_34_90  1
    rho_34    block_pair_pos_257  1
    rho_34    block_pair_neg_258  -1
    rho_34    block_pair_pos_269  1
    rho_34    block_pair_neg_270  -1
    rho_34    block_pair_pos_291  -1
    rho_34    block_pair_neg_292  1
    rho_34    block_pair_pos_293  -1
    rho_34    block_pair_neg_294  1
    rho_34    block_pair_pos_295  -1
    rho_34    block_pair_neg_296  1
    rho_34    block_pair_pos_297  -1
    rho_34    block_pair_neg_298  1
    rho_34    block_pair_pos_299  -1
    rho_34    block_pair_neg_300  1
    rho_34    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       1.6756644912833352e-02
    x_3_0     product_lb_91  -2.5838203629626577e-02
    x_3_0     product_ub_92  -4.4931799946554711e-02
    x_3_0     onehot_3_117  1
    x_3_0     parent_nonstrict_scope_244  0.0335132898256667
    x_3_0     unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_91  1
    w_3_0     product_ub_92  1
    w_3_0     normalized_mass_3_118  1
    w_3_0     full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       1.1171096608555569e-02
    x_3_1     product_lb_93  -2.5838203629626577e-02
    x_3_1     product_ub_94  -4.4931799946554711e-02
    x_3_1     onehot_3_117  1
    x_3_1     stock_lb_242  1
    x_3_1     stock_ub_243  1
    x_3_1     parent_nonstrict_scope_244  2.7927741521388921e-02
    x_3_1     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_93  1
    w_3_1     product_ub_94  1
    w_3_1     normalized_mass_3_118  1
    w_3_1     normalized_ratio_3_119  -1.6666666666666666e-01
    w_3_1     full_original_Gini_302  -1.8089285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       5.5855483042777862e-03
    x_3_2     product_lb_95  -2.5838203629626577e-02
    x_3_2     product_ub_96  -4.4931799946554711e-02
    x_3_2     onehot_3_117  1
    x_3_2     stock_lb_242  2
    x_3_2     stock_ub_243  2
    x_3_2     parent_nonstrict_scope_244  2.2342193217111138e-02
    x_3_2     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_95  1
    w_3_2     product_ub_96  1
    w_3_2     normalized_mass_3_118  1
    w_3_2     normalized_ratio_3_119  -3.3333333333333331e-01
    w_3_2     full_original_Gini_302  -1.3922619047619047e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     product_lb_97  -2.5838203629626577e-02
    x_3_3     product_ub_98  -4.4931799946554711e-02
    x_3_3     onehot_3_117  1
    x_3_3     stock_lb_242  3
    x_3_3     stock_ub_243  3
    x_3_3     parent_nonstrict_scope_244  1.6756644912833352e-02
    x_3_3     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_97  1
    w_3_3     product_ub_98  1
    w_3_3     normalized_mass_3_118  1
    w_3_3     normalized_ratio_3_119  -0.5
    w_3_3     full_original_Gini_302  -9.9559523809523789e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.5855483042777827e-03
    x_3_4     product_lb_99  -2.5838203629626577e-02
    x_3_4     product_ub_100  -4.4931799946554711e-02
    x_3_4     onehot_3_117  1
    x_3_4     stock_lb_242  4
    x_3_4     stock_ub_243  4
    x_3_4     parent_nonstrict_scope_244  1.1171096608555569e-02
    x_3_4     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_99  1
    w_3_4     product_ub_100  1
    w_3_4     normalized_mass_3_118  1
    w_3_4     normalized_ratio_3_119  -6.6666666666666663e-01
    w_3_4     full_original_Gini_302  -6.5392857142857137e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.1171096608555565e-02
    x_3_5     product_lb_101  -2.5838203629626577e-02
    x_3_5     product_ub_102  -4.4931799946554711e-02
    x_3_5     onehot_3_117  1
    x_3_5     stock_lb_242  5
    x_3_5     stock_ub_243  5
    x_3_5     parent_nonstrict_scope_244  5.5855483042777862e-03
    x_3_5     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_101  1
    w_3_5     product_ub_102  1
    w_3_5     normalized_mass_3_118  1
    w_3_5     normalized_ratio_3_119  -8.3333333333333326e-01
    w_3_5     full_original_Gini_302  -4.9107142857142865e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -1.6756644912833352e-02
    x_3_6     product_lb_103  -2.5838203629626577e-02
    x_3_6     product_ub_104  -4.4931799946554711e-02
    x_3_6     onehot_3_117  1
    x_3_6     stock_lb_242  6
    x_3_6     stock_ub_243  6
    x_3_6     unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_103  1
    w_3_6     product_ub_104  1
    w_3_6     normalized_mass_3_118  1
    w_3_6     normalized_ratio_3_119  -1
    w_3_6     full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -1.1171096608555572e-02
    x_3_7     product_lb_105  -2.5838203629626577e-02
    x_3_7     product_ub_106  -4.4931799946554711e-02
    x_3_7     onehot_3_117  1
    x_3_7     stock_lb_242  7
    x_3_7     stock_ub_243  7
    x_3_7     parent_nonstrict_scope_244  5.5855483042777793e-03
    x_3_7     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_105  1
    w_3_7     product_ub_106  1
    w_3_7     normalized_mass_3_118  1
    w_3_7     normalized_ratio_3_119  -1.1666666666666665e+00
    w_3_7     full_original_Gini_302  -9.2440476190476133e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.5855483042777862e-03
    x_3_8     product_lb_107  -2.5838203629626577e-02
    x_3_8     product_ub_108  -4.4931799946554711e-02
    x_3_8     onehot_3_117  1
    x_3_8     stock_lb_242  8
    x_3_8     stock_ub_243  8
    x_3_8     parent_nonstrict_scope_244  1.1171096608555565e-02
    x_3_8     unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_107  1
    w_3_8     product_ub_108  1
    w_3_8     normalized_mass_3_118  1
    w_3_8     normalized_ratio_3_119  -1.3333333333333333e+00
    w_3_8     full_original_Gini_302  -1.3744047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_9     product_lb_109  -2.5838203629626577e-02
    x_3_9     product_ub_110  -4.4931799946554711e-02
    x_3_9     onehot_3_117  1
    x_3_9     stock_lb_242  9
    x_3_9     stock_ub_243  9
    x_3_9     parent_nonstrict_scope_244  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_109  1
    w_3_9     product_ub_110  1
    w_3_9     normalized_mass_3_118  1
    w_3_9     normalized_ratio_3_119  -1.5
    w_3_9     full_original_Gini_302  -1.8244047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       5.5855483042777793e-03
    x_3_10    product_lb_111  -2.5838203629626577e-02
    x_3_10    product_ub_112  -4.4931799946554711e-02
    x_3_10    onehot_3_117  1
    x_3_10    stock_lb_242  10
    x_3_10    stock_ub_243  10
    x_3_10    parent_nonstrict_scope_244  2.2342193217111131e-02
    x_3_10    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_111  1
    w_3_10    product_ub_112  1
    w_3_10    normalized_mass_3_118  1
    w_3_10    normalized_ratio_3_119  -1.6666666666666665e+00
    w_3_10    full_original_Gini_302  -2.2744047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       1.1171096608555565e-02
    x_3_11    product_lb_113  -2.5838203629626577e-02
    x_3_11    product_ub_114  -4.4931799946554711e-02
    x_3_11    onehot_3_117  1
    x_3_11    stock_lb_242  11
    x_3_11    stock_ub_243  11
    x_3_11    parent_nonstrict_scope_244  2.7927741521388917e-02
    x_3_11    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_113  1
    w_3_11    product_ub_114  1
    w_3_11    normalized_mass_3_118  1
    w_3_11    normalized_ratio_3_119  -1.8333333333333333e+00
    w_3_11    full_original_Gini_302  -2.7244047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       1.6756644912833352e-02
    x_3_12    product_lb_115  -2.5838203629626577e-02
    x_3_12    product_ub_116  -4.4931799946554711e-02
    x_3_12    onehot_3_117  1
    x_3_12    stock_lb_242  12
    x_3_12    stock_ub_243  12
    x_3_12    parent_nonstrict_scope_244  0.0335132898256667
    x_3_12    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_115  1
    w_3_12    product_ub_116  1
    w_3_12    normalized_mass_3_118  1
    w_3_12    normalized_ratio_3_119  -2
    w_3_12    full_original_Gini_302  -3.1744047619047620e+01
    rho_3     normalized_ratio_3_119  1
    rho_3     block_pair_pos_247  1
    rho_3     block_pair_neg_248  -1
    rho_3     block_pair_pos_259  1
    rho_3     block_pair_neg_260  -1
    rho_3     block_pair_pos_271  -1
    rho_3     block_pair_neg_272  1
    rho_3     block_pair_pos_273  -1
    rho_3     block_pair_neg_274  1
    rho_3     block_pair_pos_275  -1
    rho_3     block_pair_neg_276  1
    rho_3     block_pair_pos_277  -1
    rho_3     block_pair_neg_278  1
    rho_3     block_pair_pos_291  1
    rho_3     block_pair_neg_292  -1
    rho_3     normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_120  -2.5838203629626577e-02
    x_22_0    product_ub_121  -4.4931799946554711e-02
    x_22_0    onehot_22_152  1
    x_22_0    parent_nonstrict_scope_244  0.0456153362865944
    x_22_0    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_120  1
    w_22_0    product_ub_121  1
    w_22_0    normalized_mass_22_153  1
    w_22_0    full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_122  -2.5838203629626577e-02
    x_22_1    product_ub_123  -4.4931799946554711e-02
    x_22_1    onehot_22_152  1
    x_22_1    stock_lb_242  1
    x_22_1    stock_ub_243  1
    x_22_1    parent_nonstrict_scope_244  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_122  1
    w_22_1    product_ub_123  1
    w_22_1    normalized_mass_22_153  1
    w_22_1    normalized_ratio_22_154  -1.4285714285714285e-01
    w_22_1    full_original_Gini_302  -1.8684523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_124  -2.5838203629626577e-02
    x_22_2    product_ub_125  -4.4931799946554711e-02
    x_22_2    onehot_22_152  1
    x_22_2    stock_lb_242  2
    x_22_2    stock_ub_243  2
    x_22_2    parent_nonstrict_scope_244  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_124  1
    w_22_2    product_ub_125  1
    w_22_2    normalized_mass_22_153  1
    w_22_2    normalized_ratio_22_154  -2.8571428571428570e-01
    w_22_2    full_original_Gini_302  -1.5113095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_126  -2.5838203629626577e-02
    x_22_3    product_ub_127  -4.4931799946554711e-02
    x_22_3    onehot_22_152  1
    x_22_3    stock_lb_242  3
    x_22_3    stock_ub_243  3
    x_22_3    parent_nonstrict_scope_244  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_126  1
    w_22_3    product_ub_127  1
    w_22_3    normalized_mass_22_153  1
    w_22_3    normalized_ratio_22_154  -4.2857142857142855e-01
    w_22_3    full_original_Gini_302  -1.1598809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_128  -2.5838203629626577e-02
    x_22_4    product_ub_129  -4.4931799946554711e-02
    x_22_4    onehot_22_152  1
    x_22_4    stock_lb_242  4
    x_22_4    stock_ub_243  4
    x_22_4    parent_nonstrict_scope_244  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_128  1
    w_22_4    product_ub_129  1
    w_22_4    normalized_mass_22_153  1
    w_22_4    normalized_ratio_22_154  -5.7142857142857140e-01
    w_22_4    full_original_Gini_302  -8.4559523809523842e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_130  -2.5838203629626577e-02
    x_22_5    product_ub_131  -4.4931799946554711e-02
    x_22_5    onehot_22_152  1
    x_22_5    stock_lb_242  5
    x_22_5    stock_ub_243  5
    x_22_5    parent_nonstrict_scope_244  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_130  1
    w_22_5    product_ub_131  1
    w_22_5    normalized_mass_22_153  1
    w_22_5    normalized_ratio_22_154  -7.1428571428571419e-01
    w_22_5    full_original_Gini_302  -5.8249999999999993e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_132  -2.5838203629626577e-02
    x_22_6    product_ub_133  -4.4931799946554711e-02
    x_22_6    onehot_22_152  1
    x_22_6    stock_lb_242  6
    x_22_6    stock_ub_243  6
    x_22_6    parent_nonstrict_scope_244  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_132  1
    w_22_6    product_ub_133  1
    w_22_6    normalized_mass_22_153  1
    w_22_6    normalized_ratio_22_154  -8.5714285714285710e-01
    w_22_6    full_original_Gini_302  -4.8869047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_134  -2.5838203629626577e-02
    x_22_7    product_ub_135  -4.4931799946554711e-02
    x_22_7    onehot_22_152  1
    x_22_7    stock_lb_242  7
    x_22_7    stock_ub_243  7
    x_22_7    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_134  1
    w_22_7    product_ub_135  1
    w_22_7    normalized_mass_22_153  1
    w_22_7    normalized_ratio_22_154  -1
    w_22_7    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_136  -2.5838203629626577e-02
    x_22_8    product_ub_137  -4.4931799946554711e-02
    x_22_8    onehot_22_152  1
    x_22_8    stock_lb_242  8
    x_22_8    stock_ub_243  8
    x_22_8    parent_nonstrict_scope_244  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_136  1
    w_22_8    product_ub_137  1
    w_22_8    normalized_mass_22_153  1
    w_22_8    normalized_ratio_22_154  -1.1428571428571428e+00
    w_22_8    full_original_Gini_302  -8.6011904761904727e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_138  -2.5838203629626577e-02
    x_22_9    product_ub_139  -4.4931799946554711e-02
    x_22_9    onehot_22_152  1
    x_22_9    stock_lb_242  9
    x_22_9    stock_ub_243  9
    x_22_9    parent_nonstrict_scope_244  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_138  1
    w_22_9    product_ub_139  1
    w_22_9    normalized_mass_22_153  1
    w_22_9    normalized_ratio_22_154  -1.2857142857142856e+00
    w_22_9    full_original_Gini_302  -1.2458333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_140  -2.5838203629626577e-02
    x_22_10   product_ub_141  -4.4931799946554711e-02
    x_22_10   onehot_22_152  1
    x_22_10   stock_lb_242  10
    x_22_10   stock_ub_243  10
    x_22_10   parent_nonstrict_scope_244  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_140  1
    w_22_10   product_ub_141  1
    w_22_10   normalized_mass_22_153  1
    w_22_10   normalized_ratio_22_154  -1.4285714285714284e+00
    w_22_10   full_original_Gini_302  -1.6315476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_142  -2.5838203629626577e-02
    x_22_11   product_ub_143  -4.4931799946554711e-02
    x_22_11   onehot_22_152  1
    x_22_11   stock_lb_242  11
    x_22_11   stock_ub_243  11
    x_22_11   parent_nonstrict_scope_244  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_142  1
    w_22_11   product_ub_143  1
    w_22_11   normalized_mass_22_153  1
    w_22_11   normalized_ratio_22_154  -1.5714285714285714e+00
    w_22_11   full_original_Gini_302  -2.0172619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_144  -2.5838203629626577e-02
    x_22_12   product_ub_145  -4.4931799946554711e-02
    x_22_12   onehot_22_152  1
    x_22_12   stock_lb_242  12
    x_22_12   stock_ub_243  12
    x_22_12   parent_nonstrict_scope_244  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_144  1
    w_22_12   product_ub_145  1
    w_22_12   normalized_mass_22_153  1
    w_22_12   normalized_ratio_22_154  -1.7142857142857142e+00
    w_22_12   full_original_Gini_302  -24.0297619047619
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_146  -2.5838203629626577e-02
    x_22_13   product_ub_147  -4.4931799946554711e-02
    x_22_13   onehot_22_152  1
    x_22_13   stock_lb_242  13
    x_22_13   stock_ub_243  13
    x_22_13   parent_nonstrict_scope_244  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_146  1
    w_22_13   product_ub_147  1
    w_22_13   normalized_mass_22_153  1
    w_22_13   normalized_ratio_22_154  -1.8571428571428570e+00
    w_22_13   full_original_Gini_302  -2.7886904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_148  -2.5838203629626577e-02
    x_22_14   product_ub_149  -4.4931799946554711e-02
    x_22_14   onehot_22_152  1
    x_22_14   stock_lb_242  14
    x_22_14   stock_ub_243  14
    x_22_14   parent_nonstrict_scope_244  0.0456153362865944
    x_22_14   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_148  1
    w_22_14   product_ub_149  1
    w_22_14   normalized_mass_22_153  1
    w_22_14   normalized_ratio_22_154  -2
    w_22_14   full_original_Gini_302  -3.1744047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_150  -2.5838203629626577e-02
    x_22_15   product_ub_151  -4.4931799946554711e-02
    x_22_15   onehot_22_152  1
    x_22_15   stock_lb_242  15
    x_22_15   stock_ub_243  15
    x_22_15   parent_nonstrict_scope_244  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_150  1
    w_22_15   product_ub_151  1
    w_22_15   normalized_mass_22_153  1
    w_22_15   normalized_ratio_22_154  -2.1428571428571428e+00
    w_22_15   full_original_Gini_302  -3.5601190476190474e+01
    rho_22    normalized_ratio_22_154  1
    rho_22    block_pair_pos_253  1
    rho_22    block_pair_neg_254  -1
    rho_22    block_pair_pos_265  1
    rho_22    block_pair_neg_266  -1
    rho_22    block_pair_pos_275  1
    rho_22    block_pair_neg_276  -1
    rho_22    block_pair_pos_283  -1
    rho_22    block_pair_neg_284  1
    rho_22    block_pair_pos_285  -1
    rho_22    block_pair_neg_286  1
    rho_22    block_pair_pos_287  -1
    rho_22    block_pair_neg_288  1
    rho_22    block_pair_pos_297  1
    rho_22    block_pair_neg_298  -1
    rho_22    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       1.9549429837111887e-02
    x_4_0     product_lb_155  -2.5838203629626577e-02
    x_4_0     product_ub_156  -4.4931799946554711e-02
    x_4_0     onehot_4_187  1
    x_4_0     parent_nonstrict_scope_244  0.0456153362865944
    x_4_0     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_155  1
    w_4_0     product_ub_156  1
    w_4_0     normalized_mass_4_188  1
    w_4_0     full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       1.3032953224741260e-02
    x_4_1     product_lb_157  -2.5838203629626577e-02
    x_4_1     product_ub_158  -4.4931799946554711e-02
    x_4_1     onehot_4_187  1
    x_4_1     stock_lb_242  1
    x_4_1     stock_ub_243  1
    x_4_1     parent_nonstrict_scope_244  3.9098859674223774e-02
    x_4_1     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_157  1
    w_4_1     product_ub_158  1
    w_4_1     normalized_mass_4_188  1
    w_4_1     normalized_ratio_4_189  -1.4285714285714285e-01
    w_4_1     full_original_Gini_302  -1.8684523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       6.5164766123706336e-03
    x_4_2     product_lb_159  -2.5838203629626577e-02
    x_4_2     product_ub_160  -4.4931799946554711e-02
    x_4_2     onehot_4_187  1
    x_4_2     stock_lb_242  2
    x_4_2     stock_ub_243  2
    x_4_2     parent_nonstrict_scope_244  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_159  1
    w_4_2     product_ub_160  1
    w_4_2     normalized_mass_4_188  1
    w_4_2     normalized_ratio_4_189  -2.8571428571428570e-01
    w_4_2     full_original_Gini_302  -1.5113095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_161  -2.5838203629626577e-02
    x_4_3     product_ub_162  -4.4931799946554711e-02
    x_4_3     onehot_4_187  1
    x_4_3     stock_lb_242  3
    x_4_3     stock_ub_243  3
    x_4_3     parent_nonstrict_scope_244  2.6065906449482514e-02
    x_4_3     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_161  1
    w_4_3     product_ub_162  1
    w_4_3     normalized_mass_4_188  1
    w_4_3     normalized_ratio_4_189  -4.2857142857142855e-01
    w_4_3     full_original_Gini_302  -1.1598809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -6.5164766123706266e-03
    x_4_4     product_lb_163  -2.5838203629626577e-02
    x_4_4     product_ub_164  -4.4931799946554711e-02
    x_4_4     onehot_4_187  1
    x_4_4     stock_lb_242  4
    x_4_4     stock_ub_243  4
    x_4_4     parent_nonstrict_scope_244  1.9549429837111887e-02
    x_4_4     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_163  1
    w_4_4     product_ub_164  1
    w_4_4     normalized_mass_4_188  1
    w_4_4     normalized_ratio_4_189  -5.7142857142857140e-01
    w_4_4     full_original_Gini_302  -8.4559523809523842e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -1.3032953224741252e-02
    x_4_5     product_lb_165  -2.5838203629626577e-02
    x_4_5     product_ub_166  -4.4931799946554711e-02
    x_4_5     onehot_4_187  1
    x_4_5     stock_lb_242  5
    x_4_5     stock_ub_243  5
    x_4_5     parent_nonstrict_scope_244  1.3032953224741262e-02
    x_4_5     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_165  1
    w_4_5     product_ub_166  1
    w_4_5     normalized_mass_4_188  1
    w_4_5     normalized_ratio_4_189  -7.1428571428571419e-01
    w_4_5     full_original_Gini_302  -5.8249999999999993e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -1.9549429837111883e-02
    x_4_6     product_lb_167  -2.5838203629626577e-02
    x_4_6     product_ub_168  -4.4931799946554711e-02
    x_4_6     onehot_4_187  1
    x_4_6     stock_lb_242  6
    x_4_6     stock_ub_243  6
    x_4_6     parent_nonstrict_scope_244  6.5164766123706310e-03
    x_4_6     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_167  1
    w_4_6     product_ub_168  1
    w_4_6     normalized_mass_4_188  1
    w_4_6     normalized_ratio_4_189  -8.5714285714285710e-01
    w_4_6     full_original_Gini_302  -4.8869047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -2.6065906449482514e-02
    x_4_7     product_lb_169  -2.5838203629626577e-02
    x_4_7     product_ub_170  -4.4931799946554711e-02
    x_4_7     onehot_4_187  1
    x_4_7     stock_lb_242  7
    x_4_7     stock_ub_243  7
    x_4_7     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_169  1
    w_4_7     product_ub_170  1
    w_4_7     normalized_mass_4_188  1
    w_4_7     normalized_ratio_4_189  -1
    w_4_7     full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -1.9549429837111887e-02
    x_4_8     product_lb_171  -2.5838203629626577e-02
    x_4_8     product_ub_172  -4.4931799946554711e-02
    x_4_8     onehot_4_187  1
    x_4_8     stock_lb_242  8
    x_4_8     stock_ub_243  8
    x_4_8     parent_nonstrict_scope_244  6.5164766123706258e-03
    x_4_8     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_171  1
    w_4_8     product_ub_172  1
    w_4_8     normalized_mass_4_188  1
    w_4_8     normalized_ratio_4_189  -1.1428571428571428e+00
    w_4_8     full_original_Gini_302  -8.6011904761904727e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -1.3032953224741262e-02
    x_4_9     product_lb_173  -2.5838203629626577e-02
    x_4_9     product_ub_174  -4.4931799946554711e-02
    x_4_9     onehot_4_187  1
    x_4_9     stock_lb_242  9
    x_4_9     stock_ub_243  9
    x_4_9     parent_nonstrict_scope_244  1.3032953224741252e-02
    x_4_9     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_173  1
    w_4_9     product_ub_174  1
    w_4_9     normalized_mass_4_188  1
    w_4_9     normalized_ratio_4_189  -1.2857142857142856e+00
    w_4_9     full_original_Gini_302  -1.2458333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -6.5164766123706371e-03
    x_4_10    product_lb_175  -2.5838203629626577e-02
    x_4_10    product_ub_176  -4.4931799946554711e-02
    x_4_10    onehot_4_187  1
    x_4_10    stock_lb_242  10
    x_4_10    stock_ub_243  10
    x_4_10    parent_nonstrict_scope_244  1.9549429837111876e-02
    x_4_10    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_175  1
    w_4_10    product_ub_176  1
    w_4_10    normalized_mass_4_188  1
    w_4_10    normalized_ratio_4_189  -1.4285714285714284e+00
    w_4_10    full_original_Gini_302  -1.6315476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_177  -2.5838203629626577e-02
    x_4_11    product_ub_178  -4.4931799946554711e-02
    x_4_11    onehot_4_187  1
    x_4_11    stock_lb_242  11
    x_4_11    stock_ub_243  11
    x_4_11    parent_nonstrict_scope_244  2.6065906449482514e-02
    x_4_11    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_177  1
    w_4_11    product_ub_178  1
    w_4_11    normalized_mass_4_188  1
    w_4_11    normalized_ratio_4_189  -1.5714285714285714e+00
    w_4_11    full_original_Gini_302  -2.0172619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       6.5164766123706266e-03
    x_4_12    product_lb_179  -2.5838203629626577e-02
    x_4_12    product_ub_180  -4.4931799946554711e-02
    x_4_12    onehot_4_187  1
    x_4_12    stock_lb_242  12
    x_4_12    stock_ub_243  12
    x_4_12    parent_nonstrict_scope_244  3.2582383061853140e-02
    x_4_12    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_179  1
    w_4_12    product_ub_180  1
    w_4_12    normalized_mass_4_188  1
    w_4_12    normalized_ratio_4_189  -1.7142857142857142e+00
    w_4_12    full_original_Gini_302  -24.0297619047619
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       1.3032953224741253e-02
    x_4_13    product_lb_181  -2.5838203629626577e-02
    x_4_13    product_ub_182  -4.4931799946554711e-02
    x_4_13    onehot_4_187  1
    x_4_13    stock_lb_242  13
    x_4_13    stock_ub_243  13
    x_4_13    parent_nonstrict_scope_244  3.9098859674223767e-02
    x_4_13    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_181  1
    w_4_13    product_ub_182  1
    w_4_13    normalized_mass_4_188  1
    w_4_13    normalized_ratio_4_189  -1.8571428571428570e+00
    w_4_13    full_original_Gini_302  -2.7886904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       1.9549429837111887e-02
    x_4_14    product_lb_183  -2.5838203629626577e-02
    x_4_14    product_ub_184  -4.4931799946554711e-02
    x_4_14    onehot_4_187  1
    x_4_14    stock_lb_242  14
    x_4_14    stock_ub_243  14
    x_4_14    parent_nonstrict_scope_244  0.0456153362865944
    x_4_14    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_183  1
    w_4_14    product_ub_184  1
    w_4_14    normalized_mass_4_188  1
    w_4_14    normalized_ratio_4_189  -2
    w_4_14    full_original_Gini_302  -3.1744047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       2.6065906449482514e-02
    x_4_15    product_lb_185  -2.5838203629626577e-02
    x_4_15    product_ub_186  -4.4931799946554711e-02
    x_4_15    onehot_4_187  1
    x_4_15    stock_lb_242  15
    x_4_15    stock_ub_243  15
    x_4_15    parent_nonstrict_scope_244  5.2131812898965027e-02
    x_4_15    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_185  1
    w_4_15    product_ub_186  1
    w_4_15    normalized_mass_4_188  1
    w_4_15    normalized_ratio_4_189  -2.1428571428571428e+00
    w_4_15    full_original_Gini_302  -3.5601190476190474e+01
    rho_4     normalized_ratio_4_189  1
    rho_4     block_pair_pos_249  1
    rho_4     block_pair_neg_250  -1
    rho_4     block_pair_pos_261  1
    rho_4     block_pair_neg_262  -1
    rho_4     block_pair_pos_271  1
    rho_4     block_pair_neg_272  -1
    rho_4     block_pair_pos_279  -1
    rho_4     block_pair_neg_280  1
    rho_4     block_pair_pos_281  -1
    rho_4     block_pair_neg_282  1
    rho_4     block_pair_pos_283  1
    rho_4     block_pair_neg_284  -1
    rho_4     block_pair_pos_293  1
    rho_4     block_pair_neg_294  -1
    rho_4     normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_190  -2.5838203629626577e-02
    x_27_0    product_ub_191  -4.4931799946554711e-02
    x_27_0    onehot_27_204  1
    x_27_0    parent_nonstrict_scope_244  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_190  1
    w_27_0    product_ub_191  1
    w_27_0    normalized_mass_27_205  1
    w_27_0    full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_192  -2.5838203629626577e-02
    x_27_1    product_ub_193  -4.4931799946554711e-02
    x_27_1    onehot_27_204  1
    x_27_1    stock_lb_242  1
    x_27_1    stock_ub_243  1
    x_27_1    parent_nonstrict_scope_244  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_192  1
    w_27_1    product_ub_193  1
    w_27_1    normalized_mass_27_205  1
    w_27_1    normalized_ratio_27_206  -3.3333333333333331e-01
    w_27_1    full_original_Gini_302  -1.3922619047619047e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_194  -2.5838203629626577e-02
    x_27_2    product_ub_195  -4.4931799946554711e-02
    x_27_2    onehot_27_204  1
    x_27_2    stock_lb_242  2
    x_27_2    stock_ub_243  2
    x_27_2    parent_nonstrict_scope_244  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_194  1
    w_27_2    product_ub_195  1
    w_27_2    normalized_mass_27_205  1
    w_27_2    normalized_ratio_27_206  -6.6666666666666663e-01
    w_27_2    full_original_Gini_302  -6.5392857142857137e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_196  -2.5838203629626577e-02
    x_27_3    product_ub_197  -4.4931799946554711e-02
    x_27_3    onehot_27_204  1
    x_27_3    stock_lb_242  3
    x_27_3    stock_ub_243  3
    x_27_3    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_196  1
    w_27_3    product_ub_197  1
    w_27_3    normalized_mass_27_205  1
    w_27_3    normalized_ratio_27_206  -1
    w_27_3    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_198  -2.5838203629626577e-02
    x_27_4    product_ub_199  -4.4931799946554711e-02
    x_27_4    onehot_27_204  1
    x_27_4    stock_lb_242  4
    x_27_4    stock_ub_243  4
    x_27_4    parent_nonstrict_scope_244  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_198  1
    w_27_4    product_ub_199  1
    w_27_4    normalized_mass_27_205  1
    w_27_4    normalized_ratio_27_206  -1.3333333333333333e+00
    w_27_4    full_original_Gini_302  -1.3744047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_200  -2.5838203629626577e-02
    x_27_5    product_ub_201  -4.4931799946554711e-02
    x_27_5    onehot_27_204  1
    x_27_5    stock_lb_242  5
    x_27_5    stock_ub_243  5
    x_27_5    parent_nonstrict_scope_244  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_200  1
    w_27_5    product_ub_201  1
    w_27_5    normalized_mass_27_205  1
    w_27_5    normalized_ratio_27_206  -1.6666666666666665e+00
    w_27_5    full_original_Gini_302  -2.2744047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_202  -2.5838203629626577e-02
    x_27_6    product_ub_203  -4.4931799946554711e-02
    x_27_6    onehot_27_204  1
    x_27_6    stock_lb_242  6
    x_27_6    stock_ub_243  6
    x_27_6    parent_nonstrict_scope_244  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_202  1
    w_27_6    product_ub_203  1
    w_27_6    normalized_mass_27_205  1
    w_27_6    normalized_ratio_27_206  -2
    w_27_6    full_original_Gini_302  -3.1744047619047620e+01
    rho_27    normalized_ratio_27_206  1
    rho_27    block_pair_pos_255  1
    rho_27    block_pair_neg_256  -1
    rho_27    block_pair_pos_267  1
    rho_27    block_pair_neg_268  -1
    rho_27    block_pair_pos_277  1
    rho_27    block_pair_neg_278  -1
    rho_27    block_pair_pos_281  1
    rho_27    block_pair_neg_282  -1
    rho_27    block_pair_pos_287  1
    rho_27    block_pair_neg_288  -1
    rho_27    block_pair_pos_289  -1
    rho_27    block_pair_neg_290  1
    rho_27    block_pair_pos_299  1
    rho_27    block_pair_neg_300  -1
    rho_27    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       1.9549429837111887e-02
    x_5_0     product_lb_207  -2.5838203629626577e-02
    x_5_0     product_ub_208  -4.4931799946554711e-02
    x_5_0     onehot_5_239  1
    x_5_0     parent_nonstrict_scope_244  0.0456153362865944
    x_5_0     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_207  1
    w_5_0     product_ub_208  1
    w_5_0     normalized_mass_5_240  1
    w_5_0     full_original_Gini_302  -2.2255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       1.3032953224741260e-02
    x_5_1     product_lb_209  -2.5838203629626577e-02
    x_5_1     product_ub_210  -4.4931799946554711e-02
    x_5_1     onehot_5_239  1
    x_5_1     stock_lb_242  1
    x_5_1     stock_ub_243  1
    x_5_1     parent_nonstrict_scope_244  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_209  1
    w_5_1     product_ub_210  1
    w_5_1     normalized_mass_5_240  1
    w_5_1     normalized_ratio_5_241  -1.4285714285714285e-01
    w_5_1     full_original_Gini_302  -1.8684523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.5164766123706336e-03
    x_5_2     product_lb_211  -2.5838203629626577e-02
    x_5_2     product_ub_212  -4.4931799946554711e-02
    x_5_2     onehot_5_239  1
    x_5_2     stock_lb_242  2
    x_5_2     stock_ub_243  2
    x_5_2     parent_nonstrict_scope_244  3.2582383061853147e-02
    x_5_2     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_211  1
    w_5_2     product_ub_212  1
    w_5_2     normalized_mass_5_240  1
    w_5_2     normalized_ratio_5_241  -2.8571428571428570e-01
    w_5_2     full_original_Gini_302  -1.5113095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     product_lb_213  -2.5838203629626577e-02
    x_5_3     product_ub_214  -4.4931799946554711e-02
    x_5_3     onehot_5_239  1
    x_5_3     stock_lb_242  3
    x_5_3     stock_ub_243  3
    x_5_3     parent_nonstrict_scope_244  2.6065906449482514e-02
    x_5_3     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_213  1
    w_5_3     product_ub_214  1
    w_5_3     normalized_mass_5_240  1
    w_5_3     normalized_ratio_5_241  -4.2857142857142855e-01
    w_5_3     full_original_Gini_302  -1.1598809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     OBJ       -6.5164766123706266e-03
    x_5_4     product_lb_215  -2.5838203629626577e-02
    x_5_4     product_ub_216  -4.4931799946554711e-02
    x_5_4     onehot_5_239  1
    x_5_4     stock_lb_242  4
    x_5_4     stock_ub_243  4
    x_5_4     parent_nonstrict_scope_244  1.9549429837111887e-02
    x_5_4     unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_215  1
    w_5_4     product_ub_216  1
    w_5_4     normalized_mass_5_240  1
    w_5_4     normalized_ratio_5_241  -5.7142857142857140e-01
    w_5_4     full_original_Gini_302  -8.4559523809523842e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.3032953224741252e-02
    x_5_5     product_lb_217  -2.5838203629626577e-02
    x_5_5     product_ub_218  -4.4931799946554711e-02
    x_5_5     onehot_5_239  1
    x_5_5     stock_lb_242  5
    x_5_5     stock_ub_243  5
    x_5_5     parent_nonstrict_scope_244  1.3032953224741262e-02
    x_5_5     unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_217  1
    w_5_5     product_ub_218  1
    w_5_5     normalized_mass_5_240  1
    w_5_5     normalized_ratio_5_241  -7.1428571428571419e-01
    w_5_5     full_original_Gini_302  -5.8249999999999993e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -1.9549429837111883e-02
    x_5_6     product_lb_219  -2.5838203629626577e-02
    x_5_6     product_ub_220  -4.4931799946554711e-02
    x_5_6     onehot_5_239  1
    x_5_6     stock_lb_242  6
    x_5_6     stock_ub_243  6
    x_5_6     parent_nonstrict_scope_244  6.5164766123706310e-03
    x_5_6     unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_219  1
    w_5_6     product_ub_220  1
    w_5_6     normalized_mass_5_240  1
    w_5_6     normalized_ratio_5_241  -8.5714285714285710e-01
    w_5_6     full_original_Gini_302  -4.8869047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -2.6065906449482514e-02
    x_5_7     product_lb_221  -2.5838203629626577e-02
    x_5_7     product_ub_222  -4.4931799946554711e-02
    x_5_7     onehot_5_239  1
    x_5_7     stock_lb_242  7
    x_5_7     stock_ub_243  7
    x_5_7     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_221  1
    w_5_7     product_ub_222  1
    w_5_7     normalized_mass_5_240  1
    w_5_7     normalized_ratio_5_241  -1
    w_5_7     full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -1.9549429837111887e-02
    x_5_8     product_lb_223  -2.5838203629626577e-02
    x_5_8     product_ub_224  -4.4931799946554711e-02
    x_5_8     onehot_5_239  1
    x_5_8     stock_lb_242  8
    x_5_8     stock_ub_243  8
    x_5_8     parent_nonstrict_scope_244  6.5164766123706258e-03
    x_5_8     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_223  1
    w_5_8     product_ub_224  1
    w_5_8     normalized_mass_5_240  1
    w_5_8     normalized_ratio_5_241  -1.1428571428571428e+00
    w_5_8     full_original_Gini_302  -8.6011904761904727e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -1.3032953224741262e-02
    x_5_9     product_lb_225  -2.5838203629626577e-02
    x_5_9     product_ub_226  -4.4931799946554711e-02
    x_5_9     onehot_5_239  1
    x_5_9     stock_lb_242  9
    x_5_9     stock_ub_243  9
    x_5_9     parent_nonstrict_scope_244  1.3032953224741252e-02
    x_5_9     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_225  1
    w_5_9     product_ub_226  1
    w_5_9     normalized_mass_5_240  1
    w_5_9     normalized_ratio_5_241  -1.2857142857142856e+00
    w_5_9     full_original_Gini_302  -1.2458333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -6.5164766123706371e-03
    x_5_10    product_lb_227  -2.5838203629626577e-02
    x_5_10    product_ub_228  -4.4931799946554711e-02
    x_5_10    onehot_5_239  1
    x_5_10    stock_lb_242  10
    x_5_10    stock_ub_243  10
    x_5_10    parent_nonstrict_scope_244  1.9549429837111876e-02
    x_5_10    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_227  1
    w_5_10    product_ub_228  1
    w_5_10    normalized_mass_5_240  1
    w_5_10    normalized_ratio_5_241  -1.4285714285714284e+00
    w_5_10    full_original_Gini_302  -1.6315476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_11    product_lb_229  -2.5838203629626577e-02
    x_5_11    product_ub_230  -4.4931799946554711e-02
    x_5_11    onehot_5_239  1
    x_5_11    stock_lb_242  11
    x_5_11    stock_ub_243  11
    x_5_11    parent_nonstrict_scope_244  2.6065906449482514e-02
    x_5_11    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_229  1
    w_5_11    product_ub_230  1
    w_5_11    normalized_mass_5_240  1
    w_5_11    normalized_ratio_5_241  -1.5714285714285714e+00
    w_5_11    full_original_Gini_302  -2.0172619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    OBJ       6.5164766123706266e-03
    x_5_12    product_lb_231  -2.5838203629626577e-02
    x_5_12    product_ub_232  -4.4931799946554711e-02
    x_5_12    onehot_5_239  1
    x_5_12    stock_lb_242  12
    x_5_12    stock_ub_243  12
    x_5_12    parent_nonstrict_scope_244  3.2582383061853140e-02
    x_5_12    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_231  1
    w_5_12    product_ub_232  1
    w_5_12    normalized_mass_5_240  1
    w_5_12    normalized_ratio_5_241  -1.7142857142857142e+00
    w_5_12    full_original_Gini_302  -24.0297619047619
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.3032953224741253e-02
    x_5_13    product_lb_233  -2.5838203629626577e-02
    x_5_13    product_ub_234  -4.4931799946554711e-02
    x_5_13    onehot_5_239  1
    x_5_13    stock_lb_242  13
    x_5_13    stock_ub_243  13
    x_5_13    parent_nonstrict_scope_244  3.9098859674223767e-02
    x_5_13    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_233  1
    w_5_13    product_ub_234  1
    w_5_13    normalized_mass_5_240  1
    w_5_13    normalized_ratio_5_241  -1.8571428571428570e+00
    w_5_13    full_original_Gini_302  -2.7886904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       1.9549429837111887e-02
    x_5_14    product_lb_235  -2.5838203629626577e-02
    x_5_14    product_ub_236  -4.4931799946554711e-02
    x_5_14    onehot_5_239  1
    x_5_14    stock_lb_242  14
    x_5_14    stock_ub_243  14
    x_5_14    parent_nonstrict_scope_244  0.0456153362865944
    x_5_14    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_235  1
    w_5_14    product_ub_236  1
    w_5_14    normalized_mass_5_240  1
    w_5_14    normalized_ratio_5_241  -2
    w_5_14    full_original_Gini_302  -3.1744047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       2.6065906449482514e-02
    x_5_15    product_lb_237  -2.5838203629626577e-02
    x_5_15    product_ub_238  -4.4931799946554711e-02
    x_5_15    onehot_5_239  1
    x_5_15    stock_lb_242  15
    x_5_15    stock_ub_243  15
    x_5_15    parent_nonstrict_scope_244  5.2131812898965027e-02
    x_5_15    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_237  1
    w_5_15    product_ub_238  1
    w_5_15    normalized_mass_5_240  1
    w_5_15    normalized_ratio_5_241  -2.1428571428571428e+00
    w_5_15    full_original_Gini_302  -3.5601190476190474e+01
    rho_5     normalized_ratio_5_241  1
    rho_5     block_pair_pos_251  1
    rho_5     block_pair_neg_252  -1
    rho_5     block_pair_pos_263  1
    rho_5     block_pair_neg_264  -1
    rho_5     block_pair_pos_273  1
    rho_5     block_pair_neg_274  -1
    rho_5     block_pair_pos_279  1
    rho_5     block_pair_neg_280  -1
    rho_5     block_pair_pos_285  1
    rho_5     block_pair_neg_286  -1
    rho_5     block_pair_pos_289  1
    rho_5     block_pair_neg_290  -1
    rho_5     block_pair_pos_295  1
    rho_5     block_pair_neg_296  -1
    rho_5     normalization_301  1
    a_1_2     block_pair_pos_245  1
    a_1_2     block_pair_neg_246  1
    a_1_2     full_original_Gini_302  -1
    a_1_34    block_pair_pos_257  1
    a_1_34    block_pair_neg_258  1
    a_1_34    full_original_Gini_302  -1
    a_1_3     block_pair_pos_247  1
    a_1_3     block_pair_neg_248  1
    a_1_3     full_original_Gini_302  -1
    a_1_22    block_pair_pos_253  1
    a_1_22    block_pair_neg_254  1
    a_1_22    full_original_Gini_302  -1
    a_1_4     block_pair_pos_249  1
    a_1_4     block_pair_neg_250  1
    a_1_4     full_original_Gini_302  -1
    a_1_27    block_pair_pos_255  1
    a_1_27    block_pair_neg_256  1
    a_1_27    full_original_Gini_302  -1
    a_1_5     block_pair_pos_251  1
    a_1_5     block_pair_neg_252  1
    a_1_5     full_original_Gini_302  -1
    a_2_34    block_pair_pos_269  1
    a_2_34    block_pair_neg_270  1
    a_2_34    full_original_Gini_302  -1
    a_2_3     block_pair_pos_259  1
    a_2_3     block_pair_neg_260  1
    a_2_3     full_original_Gini_302  -1
    a_2_22    block_pair_pos_265  1
    a_2_22    block_pair_neg_266  1
    a_2_22    full_original_Gini_302  -1
    a_2_4     block_pair_pos_261  1
    a_2_4     block_pair_neg_262  1
    a_2_4     full_original_Gini_302  -1
    a_2_27    block_pair_pos_267  1
    a_2_27    block_pair_neg_268  1
    a_2_27    full_original_Gini_302  -1
    a_2_5     block_pair_pos_263  1
    a_2_5     block_pair_neg_264  1
    a_2_5     full_original_Gini_302  -1
    a_34_3    block_pair_pos_291  1
    a_34_3    block_pair_neg_292  1
    a_34_3    full_original_Gini_302  -1
    a_34_22   block_pair_pos_297  1
    a_34_22   block_pair_neg_298  1
    a_34_22   full_original_Gini_302  -1
    a_34_4    block_pair_pos_293  1
    a_34_4    block_pair_neg_294  1
    a_34_4    full_original_Gini_302  -1
    a_34_27   block_pair_pos_299  1
    a_34_27   block_pair_neg_300  1
    a_34_27   full_original_Gini_302  -1
    a_34_5    block_pair_pos_295  1
    a_34_5    block_pair_neg_296  1
    a_34_5    full_original_Gini_302  -1
    a_3_22    block_pair_pos_275  1
    a_3_22    block_pair_neg_276  1
    a_3_22    full_original_Gini_302  -1
    a_3_4     block_pair_pos_271  1
    a_3_4     block_pair_neg_272  1
    a_3_4     full_original_Gini_302  -1
    a_3_27    block_pair_pos_277  1
    a_3_27    block_pair_neg_278  1
    a_3_27    full_original_Gini_302  -1
    a_3_5     block_pair_pos_273  1
    a_3_5     block_pair_neg_274  1
    a_3_5     full_original_Gini_302  -1
    a_22_4    block_pair_pos_283  1
    a_22_4    block_pair_neg_284  1
    a_22_4    full_original_Gini_302  -1
    a_22_27   block_pair_pos_287  1
    a_22_27   block_pair_neg_288  1
    a_22_27   full_original_Gini_302  -1
    a_22_5    block_pair_pos_285  1
    a_22_5    block_pair_neg_286  1
    a_22_5    full_original_Gini_302  -1
    a_4_27    block_pair_pos_281  1
    a_4_27    block_pair_neg_282  1
    a_4_27    full_original_Gini_302  -1
    a_4_5     block_pair_pos_279  1
    a_4_5     block_pair_neg_280  1
    a_4_5     full_original_Gini_302  -1
    a_27_5    block_pair_pos_289  1
    a_27_5    block_pair_neg_290  1
    a_27_5    full_original_Gini_302  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_1_0  unique_nonzero_owner_303  1
    service_0_1_0  service_visit_def_910  1
    service_0_1_0  free_load_conservation_911  -6
    service_0_1_0  original_T_including_depot_unload_960  720
    service_0_1_1  unique_nonzero_owner_304  1
    service_0_1_1  service_visit_def_910  1
    service_0_1_1  free_load_conservation_911  -5
    service_0_1_1  original_T_including_depot_unload_960  600
    service_0_1_2  unique_nonzero_owner_305  1
    service_0_1_2  service_visit_def_910  1
    service_0_1_2  free_load_conservation_911  -4
    service_0_1_2  original_T_including_depot_unload_960  480
    service_0_1_3  unique_nonzero_owner_306  1
    service_0_1_3  service_visit_def_910  1
    service_0_1_3  free_load_conservation_911  -3
    service_0_1_3  original_T_including_depot_unload_960  360
    service_0_1_4  unique_nonzero_owner_307  1
    service_0_1_4  service_visit_def_910  1
    service_0_1_4  free_load_conservation_911  -2
    service_0_1_4  original_T_including_depot_unload_960  240
    service_0_1_5  unique_nonzero_owner_308  1
    service_0_1_5  service_visit_def_910  1
    service_0_1_5  free_load_conservation_911  -1
    service_0_1_5  original_T_including_depot_unload_960  120
    service_0_1_7  unique_nonzero_owner_309  1
    service_0_1_7  service_visit_def_910  1
    service_0_1_7  free_load_conservation_911  1
    service_0_1_8  unique_nonzero_owner_310  1
    service_0_1_8  service_visit_def_910  1
    service_0_1_8  free_load_conservation_911  2
    service_1_1_0  unique_nonzero_owner_303  1
    service_1_1_0  service_visit_def_1231  1
    service_1_1_0  free_load_conservation_1232  -6
    service_1_1_0  original_T_including_depot_unload_1277  720
    service_1_1_1  unique_nonzero_owner_304  1
    service_1_1_1  service_visit_def_1231  1
    service_1_1_1  free_load_conservation_1232  -5
    service_1_1_1  original_T_including_depot_unload_1277  600
    service_1_1_2  unique_nonzero_owner_305  1
    service_1_1_2  service_visit_def_1231  1
    service_1_1_2  free_load_conservation_1232  -4
    service_1_1_2  original_T_including_depot_unload_1277  480
    service_1_1_3  unique_nonzero_owner_306  1
    service_1_1_3  service_visit_def_1231  1
    service_1_1_3  free_load_conservation_1232  -3
    service_1_1_3  original_T_including_depot_unload_1277  360
    service_1_1_4  unique_nonzero_owner_307  1
    service_1_1_4  service_visit_def_1231  1
    service_1_1_4  free_load_conservation_1232  -2
    service_1_1_4  original_T_including_depot_unload_1277  240
    service_1_1_5  unique_nonzero_owner_308  1
    service_1_1_5  service_visit_def_1231  1
    service_1_1_5  free_load_conservation_1232  -1
    service_1_1_5  original_T_including_depot_unload_1277  120
    service_1_1_7  unique_nonzero_owner_309  1
    service_1_1_7  service_visit_def_1231  1
    service_1_1_7  free_load_conservation_1232  1
    service_1_1_8  unique_nonzero_owner_310  1
    service_1_1_8  service_visit_def_1231  1
    service_1_1_8  free_load_conservation_1232  2
    service_2_1_0  unique_nonzero_owner_303  1
    service_2_1_0  service_visit_def_1601  1
    service_2_1_0  free_load_conservation_1602  -6
    service_2_1_0  original_T_including_depot_unload_1648  720
    service_2_1_1  unique_nonzero_owner_304  1
    service_2_1_1  service_visit_def_1601  1
    service_2_1_1  free_load_conservation_1602  -5
    service_2_1_1  original_T_including_depot_unload_1648  600
    service_2_1_2  unique_nonzero_owner_305  1
    service_2_1_2  service_visit_def_1601  1
    service_2_1_2  free_load_conservation_1602  -4
    service_2_1_2  original_T_including_depot_unload_1648  480
    service_2_1_3  unique_nonzero_owner_306  1
    service_2_1_3  service_visit_def_1601  1
    service_2_1_3  free_load_conservation_1602  -3
    service_2_1_3  original_T_including_depot_unload_1648  360
    service_2_1_4  unique_nonzero_owner_307  1
    service_2_1_4  service_visit_def_1601  1
    service_2_1_4  free_load_conservation_1602  -2
    service_2_1_4  original_T_including_depot_unload_1648  240
    service_2_1_5  unique_nonzero_owner_308  1
    service_2_1_5  service_visit_def_1601  1
    service_2_1_5  free_load_conservation_1602  -1
    service_2_1_5  original_T_including_depot_unload_1648  120
    service_2_1_7  unique_nonzero_owner_309  1
    service_2_1_7  service_visit_def_1601  1
    service_2_1_7  free_load_conservation_1602  1
    service_2_1_8  unique_nonzero_owner_310  1
    service_2_1_8  service_visit_def_1601  1
    service_2_1_8  free_load_conservation_1602  2
    service_0_2_0  unique_nonzero_owner_311  1
    service_0_2_0  service_visit_def_916  1
    service_0_2_0  free_load_conservation_917  -11
    service_0_2_0  original_T_including_depot_unload_960  1320
    service_0_2_1  unique_nonzero_owner_312  1
    service_0_2_1  service_visit_def_916  1
    service_0_2_1  free_load_conservation_917  -10
    service_0_2_1  original_T_including_depot_unload_960  1200
    service_0_2_2  unique_nonzero_owner_313  1
    service_0_2_2  service_visit_def_916  1
    service_0_2_2  free_load_conservation_917  -9
    service_0_2_2  original_T_including_depot_unload_960  1080
    service_0_2_3  unique_nonzero_owner_314  1
    service_0_2_3  service_visit_def_916  1
    service_0_2_3  free_load_conservation_917  -8
    service_0_2_3  original_T_including_depot_unload_960  960
    service_0_2_4  unique_nonzero_owner_315  1
    service_0_2_4  service_visit_def_916  1
    service_0_2_4  free_load_conservation_917  -7
    service_0_2_4  original_T_including_depot_unload_960  840
    service_0_2_5  unique_nonzero_owner_316  1
    service_0_2_5  service_visit_def_916  1
    service_0_2_5  free_load_conservation_917  -6
    service_0_2_5  original_T_including_depot_unload_960  720
    service_0_2_6  unique_nonzero_owner_317  1
    service_0_2_6  service_visit_def_916  1
    service_0_2_6  free_load_conservation_917  -5
    service_0_2_6  original_T_including_depot_unload_960  600
    service_0_2_7  unique_nonzero_owner_318  1
    service_0_2_7  service_visit_def_916  1
    service_0_2_7  free_load_conservation_917  -4
    service_0_2_7  original_T_including_depot_unload_960  480
    service_0_2_8  unique_nonzero_owner_319  1
    service_0_2_8  service_visit_def_916  1
    service_0_2_8  free_load_conservation_917  -3
    service_0_2_8  original_T_including_depot_unload_960  360
    service_0_2_9  unique_nonzero_owner_320  1
    service_0_2_9  service_visit_def_916  1
    service_0_2_9  free_load_conservation_917  -2
    service_0_2_9  original_T_including_depot_unload_960  240
    service_0_2_10  unique_nonzero_owner_321  1
    service_0_2_10  service_visit_def_916  1
    service_0_2_10  free_load_conservation_917  -1
    service_0_2_10  original_T_including_depot_unload_960  120
    service_0_2_12  unique_nonzero_owner_322  1
    service_0_2_12  service_visit_def_916  1
    service_0_2_12  free_load_conservation_917  1
    service_0_2_13  unique_nonzero_owner_323  1
    service_0_2_13  service_visit_def_916  1
    service_0_2_13  free_load_conservation_917  2
    service_0_2_14  unique_nonzero_owner_324  1
    service_0_2_14  service_visit_def_916  1
    service_0_2_14  free_load_conservation_917  3
    service_0_2_15  unique_nonzero_owner_325  1
    service_0_2_15  service_visit_def_916  1
    service_0_2_15  free_load_conservation_917  4
    service_1_2_0  unique_nonzero_owner_311  1
    service_1_2_0  service_visit_def_1237  1
    service_1_2_0  free_load_conservation_1238  -11
    service_1_2_0  original_T_including_depot_unload_1277  1320
    service_1_2_1  unique_nonzero_owner_312  1
    service_1_2_1  service_visit_def_1237  1
    service_1_2_1  free_load_conservation_1238  -10
    service_1_2_1  original_T_including_depot_unload_1277  1200
    service_1_2_2  unique_nonzero_owner_313  1
    service_1_2_2  service_visit_def_1237  1
    service_1_2_2  free_load_conservation_1238  -9
    service_1_2_2  original_T_including_depot_unload_1277  1080
    service_1_2_3  unique_nonzero_owner_314  1
    service_1_2_3  service_visit_def_1237  1
    service_1_2_3  free_load_conservation_1238  -8
    service_1_2_3  original_T_including_depot_unload_1277  960
    service_1_2_4  unique_nonzero_owner_315  1
    service_1_2_4  service_visit_def_1237  1
    service_1_2_4  free_load_conservation_1238  -7
    service_1_2_4  original_T_including_depot_unload_1277  840
    service_1_2_5  unique_nonzero_owner_316  1
    service_1_2_5  service_visit_def_1237  1
    service_1_2_5  free_load_conservation_1238  -6
    service_1_2_5  original_T_including_depot_unload_1277  720
    service_1_2_6  unique_nonzero_owner_317  1
    service_1_2_6  service_visit_def_1237  1
    service_1_2_6  free_load_conservation_1238  -5
    service_1_2_6  original_T_including_depot_unload_1277  600
    service_1_2_7  unique_nonzero_owner_318  1
    service_1_2_7  service_visit_def_1237  1
    service_1_2_7  free_load_conservation_1238  -4
    service_1_2_7  original_T_including_depot_unload_1277  480
    service_1_2_8  unique_nonzero_owner_319  1
    service_1_2_8  service_visit_def_1237  1
    service_1_2_8  free_load_conservation_1238  -3
    service_1_2_8  original_T_including_depot_unload_1277  360
    service_1_2_9  unique_nonzero_owner_320  1
    service_1_2_9  service_visit_def_1237  1
    service_1_2_9  free_load_conservation_1238  -2
    service_1_2_9  original_T_including_depot_unload_1277  240
    service_1_2_10  unique_nonzero_owner_321  1
    service_1_2_10  service_visit_def_1237  1
    service_1_2_10  free_load_conservation_1238  -1
    service_1_2_10  original_T_including_depot_unload_1277  120
    service_1_2_12  unique_nonzero_owner_322  1
    service_1_2_12  service_visit_def_1237  1
    service_1_2_12  free_load_conservation_1238  1
    service_1_2_13  unique_nonzero_owner_323  1
    service_1_2_13  service_visit_def_1237  1
    service_1_2_13  free_load_conservation_1238  2
    service_1_2_14  unique_nonzero_owner_324  1
    service_1_2_14  service_visit_def_1237  1
    service_1_2_14  free_load_conservation_1238  3
    service_1_2_15  unique_nonzero_owner_325  1
    service_1_2_15  service_visit_def_1237  1
    service_1_2_15  free_load_conservation_1238  4
    service_2_2_0  unique_nonzero_owner_311  1
    service_2_2_0  service_visit_def_1607  1
    service_2_2_0  free_load_conservation_1608  -11
    service_2_2_0  original_T_including_depot_unload_1648  1320
    service_2_2_1  unique_nonzero_owner_312  1
    service_2_2_1  service_visit_def_1607  1
    service_2_2_1  free_load_conservation_1608  -10
    service_2_2_1  original_T_including_depot_unload_1648  1200
    service_2_2_2  unique_nonzero_owner_313  1
    service_2_2_2  service_visit_def_1607  1
    service_2_2_2  free_load_conservation_1608  -9
    service_2_2_2  original_T_including_depot_unload_1648  1080
    service_2_2_3  unique_nonzero_owner_314  1
    service_2_2_3  service_visit_def_1607  1
    service_2_2_3  free_load_conservation_1608  -8
    service_2_2_3  original_T_including_depot_unload_1648  960
    service_2_2_4  unique_nonzero_owner_315  1
    service_2_2_4  service_visit_def_1607  1
    service_2_2_4  free_load_conservation_1608  -7
    service_2_2_4  original_T_including_depot_unload_1648  840
    service_2_2_5  unique_nonzero_owner_316  1
    service_2_2_5  service_visit_def_1607  1
    service_2_2_5  free_load_conservation_1608  -6
    service_2_2_5  original_T_including_depot_unload_1648  720
    service_2_2_6  unique_nonzero_owner_317  1
    service_2_2_6  service_visit_def_1607  1
    service_2_2_6  free_load_conservation_1608  -5
    service_2_2_6  original_T_including_depot_unload_1648  600
    service_2_2_7  unique_nonzero_owner_318  1
    service_2_2_7  service_visit_def_1607  1
    service_2_2_7  free_load_conservation_1608  -4
    service_2_2_7  original_T_including_depot_unload_1648  480
    service_2_2_8  unique_nonzero_owner_319  1
    service_2_2_8  service_visit_def_1607  1
    service_2_2_8  free_load_conservation_1608  -3
    service_2_2_8  original_T_including_depot_unload_1648  360
    service_2_2_9  unique_nonzero_owner_320  1
    service_2_2_9  service_visit_def_1607  1
    service_2_2_9  free_load_conservation_1608  -2
    service_2_2_9  original_T_including_depot_unload_1648  240
    service_2_2_10  unique_nonzero_owner_321  1
    service_2_2_10  service_visit_def_1607  1
    service_2_2_10  free_load_conservation_1608  -1
    service_2_2_10  original_T_including_depot_unload_1648  120
    service_2_2_12  unique_nonzero_owner_322  1
    service_2_2_12  service_visit_def_1607  1
    service_2_2_12  free_load_conservation_1608  1
    service_2_2_13  unique_nonzero_owner_323  1
    service_2_2_13  service_visit_def_1607  1
    service_2_2_13  free_load_conservation_1608  2
    service_2_2_14  unique_nonzero_owner_324  1
    service_2_2_14  service_visit_def_1607  1
    service_2_2_14  free_load_conservation_1608  3
    service_2_2_15  unique_nonzero_owner_325  1
    service_2_2_15  service_visit_def_1607  1
    service_2_2_15  free_load_conservation_1608  4
    service_0_34_0  unique_nonzero_owner_326  1
    service_0_34_0  service_visit_def_922  1
    service_0_34_0  free_load_conservation_923  -2
    service_0_34_0  original_T_including_depot_unload_960  240
    service_0_34_1  unique_nonzero_owner_327  1
    service_0_34_1  service_visit_def_922  1
    service_0_34_1  free_load_conservation_923  -1
    service_0_34_1  original_T_including_depot_unload_960  120
    service_0_34_3  unique_nonzero_owner_328  1
    service_0_34_3  service_visit_def_922  1
    service_0_34_3  free_load_conservation_923  1
    service_0_34_4  unique_nonzero_owner_329  1
    service_0_34_4  service_visit_def_922  1
    service_0_34_4  free_load_conservation_923  2
    service_0_34_5  unique_nonzero_owner_330  1
    service_0_34_5  service_visit_def_922  1
    service_0_34_5  free_load_conservation_923  3
    service_0_34_6  unique_nonzero_owner_331  1
    service_0_34_6  service_visit_def_922  1
    service_0_34_6  free_load_conservation_923  4
    service_0_34_7  unique_nonzero_owner_332  1
    service_0_34_7  service_visit_def_922  1
    service_0_34_7  free_load_conservation_923  5
    service_0_34_8  unique_nonzero_owner_333  1
    service_0_34_8  service_visit_def_922  1
    service_0_34_8  free_load_conservation_923  6
    service_0_34_9  unique_nonzero_owner_334  1
    service_0_34_9  service_visit_def_922  1
    service_0_34_9  free_load_conservation_923  7
    service_0_34_10  unique_nonzero_owner_335  1
    service_0_34_10  service_visit_def_922  1
    service_0_34_10  free_load_conservation_923  8
    service_0_34_11  unique_nonzero_owner_336  1
    service_0_34_11  service_visit_def_922  1
    service_0_34_11  free_load_conservation_923  9
    service_0_34_12  unique_nonzero_owner_337  1
    service_0_34_12  service_visit_def_922  1
    service_0_34_12  free_load_conservation_923  10
    service_0_34_13  unique_nonzero_owner_338  1
    service_0_34_13  service_visit_def_922  1
    service_0_34_13  free_load_conservation_923  11
    service_0_34_14  unique_nonzero_owner_339  1
    service_0_34_14  service_visit_def_922  1
    service_0_34_14  free_load_conservation_923  12
    service_0_34_15  unique_nonzero_owner_340  1
    service_0_34_15  service_visit_def_922  1
    service_0_34_15  free_load_conservation_923  13
    service_1_34_0  unique_nonzero_owner_326  1
    service_1_34_0  service_visit_def_1243  1
    service_1_34_0  free_load_conservation_1244  -2
    service_1_34_0  original_T_including_depot_unload_1277  240
    service_1_34_1  unique_nonzero_owner_327  1
    service_1_34_1  service_visit_def_1243  1
    service_1_34_1  free_load_conservation_1244  -1
    service_1_34_1  original_T_including_depot_unload_1277  120
    service_1_34_3  unique_nonzero_owner_328  1
    service_1_34_3  service_visit_def_1243  1
    service_1_34_3  free_load_conservation_1244  1
    service_1_34_4  unique_nonzero_owner_329  1
    service_1_34_4  service_visit_def_1243  1
    service_1_34_4  free_load_conservation_1244  2
    service_1_34_5  unique_nonzero_owner_330  1
    service_1_34_5  service_visit_def_1243  1
    service_1_34_5  free_load_conservation_1244  3
    service_1_34_6  unique_nonzero_owner_331  1
    service_1_34_6  service_visit_def_1243  1
    service_1_34_6  free_load_conservation_1244  4
    service_1_34_7  unique_nonzero_owner_332  1
    service_1_34_7  service_visit_def_1243  1
    service_1_34_7  free_load_conservation_1244  5
    service_1_34_8  unique_nonzero_owner_333  1
    service_1_34_8  service_visit_def_1243  1
    service_1_34_8  free_load_conservation_1244  6
    service_1_34_9  unique_nonzero_owner_334  1
    service_1_34_9  service_visit_def_1243  1
    service_1_34_9  free_load_conservation_1244  7
    service_1_34_10  unique_nonzero_owner_335  1
    service_1_34_10  service_visit_def_1243  1
    service_1_34_10  free_load_conservation_1244  8
    service_1_34_11  unique_nonzero_owner_336  1
    service_1_34_11  service_visit_def_1243  1
    service_1_34_11  free_load_conservation_1244  9
    service_1_34_12  unique_nonzero_owner_337  1
    service_1_34_12  service_visit_def_1243  1
    service_1_34_12  free_load_conservation_1244  10
    service_1_34_13  unique_nonzero_owner_338  1
    service_1_34_13  service_visit_def_1243  1
    service_1_34_13  free_load_conservation_1244  11
    service_1_34_14  unique_nonzero_owner_339  1
    service_1_34_14  service_visit_def_1243  1
    service_1_34_14  free_load_conservation_1244  12
    service_1_34_15  unique_nonzero_owner_340  1
    service_1_34_15  service_visit_def_1243  1
    service_1_34_15  free_load_conservation_1244  13
    service_2_34_0  unique_nonzero_owner_326  1
    service_2_34_0  service_visit_def_1613  1
    service_2_34_0  free_load_conservation_1614  -2
    service_2_34_0  original_T_including_depot_unload_1648  240
    service_2_34_1  unique_nonzero_owner_327  1
    service_2_34_1  service_visit_def_1613  1
    service_2_34_1  free_load_conservation_1614  -1
    service_2_34_1  original_T_including_depot_unload_1648  120
    service_2_34_3  unique_nonzero_owner_328  1
    service_2_34_3  service_visit_def_1613  1
    service_2_34_3  free_load_conservation_1614  1
    service_2_34_4  unique_nonzero_owner_329  1
    service_2_34_4  service_visit_def_1613  1
    service_2_34_4  free_load_conservation_1614  2
    service_2_34_5  unique_nonzero_owner_330  1
    service_2_34_5  service_visit_def_1613  1
    service_2_34_5  free_load_conservation_1614  3
    service_2_34_6  unique_nonzero_owner_331  1
    service_2_34_6  service_visit_def_1613  1
    service_2_34_6  free_load_conservation_1614  4
    service_2_34_7  unique_nonzero_owner_332  1
    service_2_34_7  service_visit_def_1613  1
    service_2_34_7  free_load_conservation_1614  5
    service_2_34_8  unique_nonzero_owner_333  1
    service_2_34_8  service_visit_def_1613  1
    service_2_34_8  free_load_conservation_1614  6
    service_2_34_9  unique_nonzero_owner_334  1
    service_2_34_9  service_visit_def_1613  1
    service_2_34_9  free_load_conservation_1614  7
    service_2_34_10  unique_nonzero_owner_335  1
    service_2_34_10  service_visit_def_1613  1
    service_2_34_10  free_load_conservation_1614  8
    service_2_34_11  unique_nonzero_owner_336  1
    service_2_34_11  service_visit_def_1613  1
    service_2_34_11  free_load_conservation_1614  9
    service_2_34_12  unique_nonzero_owner_337  1
    service_2_34_12  service_visit_def_1613  1
    service_2_34_12  free_load_conservation_1614  10
    service_2_34_13  unique_nonzero_owner_338  1
    service_2_34_13  service_visit_def_1613  1
    service_2_34_13  free_load_conservation_1614  11
    service_2_34_14  unique_nonzero_owner_339  1
    service_2_34_14  service_visit_def_1613  1
    service_2_34_14  free_load_conservation_1614  12
    service_2_34_15  unique_nonzero_owner_340  1
    service_2_34_15  service_visit_def_1613  1
    service_2_34_15  free_load_conservation_1614  13
    service_0_3_0  unique_nonzero_owner_341  1
    service_0_3_0  service_visit_def_928  1
    service_0_3_0  free_load_conservation_929  -9
    service_0_3_0  original_T_including_depot_unload_960  1080
    service_0_3_1  unique_nonzero_owner_342  1
    service_0_3_1  service_visit_def_928  1
    service_0_3_1  free_load_conservation_929  -8
    service_0_3_1  original_T_including_depot_unload_960  960
    service_0_3_2  unique_nonzero_owner_343  1
    service_0_3_2  service_visit_def_928  1
    service_0_3_2  free_load_conservation_929  -7
    service_0_3_2  original_T_including_depot_unload_960  840
    service_0_3_3  unique_nonzero_owner_344  1
    service_0_3_3  service_visit_def_928  1
    service_0_3_3  free_load_conservation_929  -6
    service_0_3_3  original_T_including_depot_unload_960  720
    service_0_3_4  unique_nonzero_owner_345  1
    service_0_3_4  service_visit_def_928  1
    service_0_3_4  free_load_conservation_929  -5
    service_0_3_4  original_T_including_depot_unload_960  600
    service_0_3_5  unique_nonzero_owner_346  1
    service_0_3_5  service_visit_def_928  1
    service_0_3_5  free_load_conservation_929  -4
    service_0_3_5  original_T_including_depot_unload_960  480
    service_0_3_6  unique_nonzero_owner_347  1
    service_0_3_6  service_visit_def_928  1
    service_0_3_6  free_load_conservation_929  -3
    service_0_3_6  original_T_including_depot_unload_960  360
    service_0_3_7  unique_nonzero_owner_348  1
    service_0_3_7  service_visit_def_928  1
    service_0_3_7  free_load_conservation_929  -2
    service_0_3_7  original_T_including_depot_unload_960  240
    service_0_3_8  unique_nonzero_owner_349  1
    service_0_3_8  service_visit_def_928  1
    service_0_3_8  free_load_conservation_929  -1
    service_0_3_8  original_T_including_depot_unload_960  120
    service_0_3_10  unique_nonzero_owner_350  1
    service_0_3_10  service_visit_def_928  1
    service_0_3_10  free_load_conservation_929  1
    service_0_3_11  unique_nonzero_owner_351  1
    service_0_3_11  service_visit_def_928  1
    service_0_3_11  free_load_conservation_929  2
    service_0_3_12  unique_nonzero_owner_352  1
    service_0_3_12  service_visit_def_928  1
    service_0_3_12  free_load_conservation_929  3
    service_1_3_0  unique_nonzero_owner_341  1
    service_1_3_0  service_visit_def_1249  1
    service_1_3_0  free_load_conservation_1250  -9
    service_1_3_0  original_T_including_depot_unload_1277  1080
    service_1_3_1  unique_nonzero_owner_342  1
    service_1_3_1  service_visit_def_1249  1
    service_1_3_1  free_load_conservation_1250  -8
    service_1_3_1  original_T_including_depot_unload_1277  960
    service_1_3_2  unique_nonzero_owner_343  1
    service_1_3_2  service_visit_def_1249  1
    service_1_3_2  free_load_conservation_1250  -7
    service_1_3_2  original_T_including_depot_unload_1277  840
    service_1_3_3  unique_nonzero_owner_344  1
    service_1_3_3  service_visit_def_1249  1
    service_1_3_3  free_load_conservation_1250  -6
    service_1_3_3  original_T_including_depot_unload_1277  720
    service_1_3_4  unique_nonzero_owner_345  1
    service_1_3_4  service_visit_def_1249  1
    service_1_3_4  free_load_conservation_1250  -5
    service_1_3_4  original_T_including_depot_unload_1277  600
    service_1_3_5  unique_nonzero_owner_346  1
    service_1_3_5  service_visit_def_1249  1
    service_1_3_5  free_load_conservation_1250  -4
    service_1_3_5  original_T_including_depot_unload_1277  480
    service_1_3_6  unique_nonzero_owner_347  1
    service_1_3_6  service_visit_def_1249  1
    service_1_3_6  free_load_conservation_1250  -3
    service_1_3_6  original_T_including_depot_unload_1277  360
    service_1_3_7  unique_nonzero_owner_348  1
    service_1_3_7  service_visit_def_1249  1
    service_1_3_7  free_load_conservation_1250  -2
    service_1_3_7  original_T_including_depot_unload_1277  240
    service_1_3_8  unique_nonzero_owner_349  1
    service_1_3_8  service_visit_def_1249  1
    service_1_3_8  free_load_conservation_1250  -1
    service_1_3_8  original_T_including_depot_unload_1277  120
    service_1_3_10  unique_nonzero_owner_350  1
    service_1_3_10  service_visit_def_1249  1
    service_1_3_10  free_load_conservation_1250  1
    service_1_3_11  unique_nonzero_owner_351  1
    service_1_3_11  service_visit_def_1249  1
    service_1_3_11  free_load_conservation_1250  2
    service_1_3_12  unique_nonzero_owner_352  1
    service_1_3_12  service_visit_def_1249  1
    service_1_3_12  free_load_conservation_1250  3
    service_2_3_0  unique_nonzero_owner_341  1
    service_2_3_0  service_visit_def_1619  1
    service_2_3_0  free_load_conservation_1620  -9
    service_2_3_0  original_T_including_depot_unload_1648  1080
    service_2_3_1  unique_nonzero_owner_342  1
    service_2_3_1  service_visit_def_1619  1
    service_2_3_1  free_load_conservation_1620  -8
    service_2_3_1  original_T_including_depot_unload_1648  960
    service_2_3_2  unique_nonzero_owner_343  1
    service_2_3_2  service_visit_def_1619  1
    service_2_3_2  free_load_conservation_1620  -7
    service_2_3_2  original_T_including_depot_unload_1648  840
    service_2_3_3  unique_nonzero_owner_344  1
    service_2_3_3  service_visit_def_1619  1
    service_2_3_3  free_load_conservation_1620  -6
    service_2_3_3  original_T_including_depot_unload_1648  720
    service_2_3_4  unique_nonzero_owner_345  1
    service_2_3_4  service_visit_def_1619  1
    service_2_3_4  free_load_conservation_1620  -5
    service_2_3_4  original_T_including_depot_unload_1648  600
    service_2_3_5  unique_nonzero_owner_346  1
    service_2_3_5  service_visit_def_1619  1
    service_2_3_5  free_load_conservation_1620  -4
    service_2_3_5  original_T_including_depot_unload_1648  480
    service_2_3_6  unique_nonzero_owner_347  1
    service_2_3_6  service_visit_def_1619  1
    service_2_3_6  free_load_conservation_1620  -3
    service_2_3_6  original_T_including_depot_unload_1648  360
    service_2_3_7  unique_nonzero_owner_348  1
    service_2_3_7  service_visit_def_1619  1
    service_2_3_7  free_load_conservation_1620  -2
    service_2_3_7  original_T_including_depot_unload_1648  240
    service_2_3_8  unique_nonzero_owner_349  1
    service_2_3_8  service_visit_def_1619  1
    service_2_3_8  free_load_conservation_1620  -1
    service_2_3_8  original_T_including_depot_unload_1648  120
    service_2_3_10  unique_nonzero_owner_350  1
    service_2_3_10  service_visit_def_1619  1
    service_2_3_10  free_load_conservation_1620  1
    service_2_3_11  unique_nonzero_owner_351  1
    service_2_3_11  service_visit_def_1619  1
    service_2_3_11  free_load_conservation_1620  2
    service_2_3_12  unique_nonzero_owner_352  1
    service_2_3_12  service_visit_def_1619  1
    service_2_3_12  free_load_conservation_1620  3
    service_0_22_0  unique_nonzero_owner_353  1
    service_0_22_0  service_visit_def_934  1
    service_0_22_0  free_load_conservation_935  -2
    service_0_22_0  original_T_including_depot_unload_960  240
    service_0_22_1  unique_nonzero_owner_354  1
    service_0_22_1  service_visit_def_934  1
    service_0_22_1  free_load_conservation_935  -1
    service_0_22_1  original_T_including_depot_unload_960  120
    service_0_22_3  unique_nonzero_owner_355  1
    service_0_22_3  service_visit_def_934  1
    service_0_22_3  free_load_conservation_935  1
    service_0_22_4  unique_nonzero_owner_356  1
    service_0_22_4  service_visit_def_934  1
    service_0_22_4  free_load_conservation_935  2
    service_0_22_5  unique_nonzero_owner_357  1
    service_0_22_5  service_visit_def_934  1
    service_0_22_5  free_load_conservation_935  3
    service_0_22_6  unique_nonzero_owner_358  1
    service_0_22_6  service_visit_def_934  1
    service_0_22_6  free_load_conservation_935  4
    service_0_22_7  unique_nonzero_owner_359  1
    service_0_22_7  service_visit_def_934  1
    service_0_22_7  free_load_conservation_935  5
    service_0_22_8  unique_nonzero_owner_360  1
    service_0_22_8  service_visit_def_934  1
    service_0_22_8  free_load_conservation_935  6
    service_0_22_9  unique_nonzero_owner_361  1
    service_0_22_9  service_visit_def_934  1
    service_0_22_9  free_load_conservation_935  7
    service_0_22_10  unique_nonzero_owner_362  1
    service_0_22_10  service_visit_def_934  1
    service_0_22_10  free_load_conservation_935  8
    service_0_22_11  unique_nonzero_owner_363  1
    service_0_22_11  service_visit_def_934  1
    service_0_22_11  free_load_conservation_935  9
    service_0_22_12  unique_nonzero_owner_364  1
    service_0_22_12  service_visit_def_934  1
    service_0_22_12  free_load_conservation_935  10
    service_0_22_13  unique_nonzero_owner_365  1
    service_0_22_13  service_visit_def_934  1
    service_0_22_13  free_load_conservation_935  11
    service_0_22_14  unique_nonzero_owner_366  1
    service_0_22_14  service_visit_def_934  1
    service_0_22_14  free_load_conservation_935  12
    service_0_22_15  unique_nonzero_owner_367  1
    service_0_22_15  service_visit_def_934  1
    service_0_22_15  free_load_conservation_935  13
    service_1_22_0  unique_nonzero_owner_353  1
    service_1_22_0  service_visit_def_1255  1
    service_1_22_0  free_load_conservation_1256  -2
    service_1_22_0  original_T_including_depot_unload_1277  240
    service_1_22_1  unique_nonzero_owner_354  1
    service_1_22_1  service_visit_def_1255  1
    service_1_22_1  free_load_conservation_1256  -1
    service_1_22_1  original_T_including_depot_unload_1277  120
    service_1_22_3  unique_nonzero_owner_355  1
    service_1_22_3  service_visit_def_1255  1
    service_1_22_3  free_load_conservation_1256  1
    service_1_22_4  unique_nonzero_owner_356  1
    service_1_22_4  service_visit_def_1255  1
    service_1_22_4  free_load_conservation_1256  2
    service_1_22_5  unique_nonzero_owner_357  1
    service_1_22_5  service_visit_def_1255  1
    service_1_22_5  free_load_conservation_1256  3
    service_1_22_6  unique_nonzero_owner_358  1
    service_1_22_6  service_visit_def_1255  1
    service_1_22_6  free_load_conservation_1256  4
    service_1_22_7  unique_nonzero_owner_359  1
    service_1_22_7  service_visit_def_1255  1
    service_1_22_7  free_load_conservation_1256  5
    service_1_22_8  unique_nonzero_owner_360  1
    service_1_22_8  service_visit_def_1255  1
    service_1_22_8  free_load_conservation_1256  6
    service_1_22_9  unique_nonzero_owner_361  1
    service_1_22_9  service_visit_def_1255  1
    service_1_22_9  free_load_conservation_1256  7
    service_1_22_10  unique_nonzero_owner_362  1
    service_1_22_10  service_visit_def_1255  1
    service_1_22_10  free_load_conservation_1256  8
    service_1_22_11  unique_nonzero_owner_363  1
    service_1_22_11  service_visit_def_1255  1
    service_1_22_11  free_load_conservation_1256  9
    service_1_22_12  unique_nonzero_owner_364  1
    service_1_22_12  service_visit_def_1255  1
    service_1_22_12  free_load_conservation_1256  10
    service_1_22_13  unique_nonzero_owner_365  1
    service_1_22_13  service_visit_def_1255  1
    service_1_22_13  free_load_conservation_1256  11
    service_1_22_14  unique_nonzero_owner_366  1
    service_1_22_14  service_visit_def_1255  1
    service_1_22_14  free_load_conservation_1256  12
    service_1_22_15  unique_nonzero_owner_367  1
    service_1_22_15  service_visit_def_1255  1
    service_1_22_15  free_load_conservation_1256  13
    service_2_22_0  unique_nonzero_owner_353  1
    service_2_22_0  service_visit_def_1625  1
    service_2_22_0  free_load_conservation_1626  -2
    service_2_22_0  original_T_including_depot_unload_1648  240
    service_2_22_1  unique_nonzero_owner_354  1
    service_2_22_1  service_visit_def_1625  1
    service_2_22_1  free_load_conservation_1626  -1
    service_2_22_1  original_T_including_depot_unload_1648  120
    service_2_22_3  unique_nonzero_owner_355  1
    service_2_22_3  service_visit_def_1625  1
    service_2_22_3  free_load_conservation_1626  1
    service_2_22_4  unique_nonzero_owner_356  1
    service_2_22_4  service_visit_def_1625  1
    service_2_22_4  free_load_conservation_1626  2
    service_2_22_5  unique_nonzero_owner_357  1
    service_2_22_5  service_visit_def_1625  1
    service_2_22_5  free_load_conservation_1626  3
    service_2_22_6  unique_nonzero_owner_358  1
    service_2_22_6  service_visit_def_1625  1
    service_2_22_6  free_load_conservation_1626  4
    service_2_22_7  unique_nonzero_owner_359  1
    service_2_22_7  service_visit_def_1625  1
    service_2_22_7  free_load_conservation_1626  5
    service_2_22_8  unique_nonzero_owner_360  1
    service_2_22_8  service_visit_def_1625  1
    service_2_22_8  free_load_conservation_1626  6
    service_2_22_9  unique_nonzero_owner_361  1
    service_2_22_9  service_visit_def_1625  1
    service_2_22_9  free_load_conservation_1626  7
    service_2_22_10  unique_nonzero_owner_362  1
    service_2_22_10  service_visit_def_1625  1
    service_2_22_10  free_load_conservation_1626  8
    service_2_22_11  unique_nonzero_owner_363  1
    service_2_22_11  service_visit_def_1625  1
    service_2_22_11  free_load_conservation_1626  9
    service_2_22_12  unique_nonzero_owner_364  1
    service_2_22_12  service_visit_def_1625  1
    service_2_22_12  free_load_conservation_1626  10
    service_2_22_13  unique_nonzero_owner_365  1
    service_2_22_13  service_visit_def_1625  1
    service_2_22_13  free_load_conservation_1626  11
    service_2_22_14  unique_nonzero_owner_366  1
    service_2_22_14  service_visit_def_1625  1
    service_2_22_14  free_load_conservation_1626  12
    service_2_22_15  unique_nonzero_owner_367  1
    service_2_22_15  service_visit_def_1625  1
    service_2_22_15  free_load_conservation_1626  13
    service_0_4_0  unique_nonzero_owner_368  1
    service_0_4_0  service_visit_def_940  1
    service_0_4_0  free_load_conservation_941  -2
    service_0_4_0  original_T_including_depot_unload_960  240
    service_0_4_1  unique_nonzero_owner_369  1
    service_0_4_1  service_visit_def_940  1
    service_0_4_1  free_load_conservation_941  -1
    service_0_4_1  original_T_including_depot_unload_960  120
    service_0_4_3  unique_nonzero_owner_370  1
    service_0_4_3  service_visit_def_940  1
    service_0_4_3  free_load_conservation_941  1
    service_0_4_4  unique_nonzero_owner_371  1
    service_0_4_4  service_visit_def_940  1
    service_0_4_4  free_load_conservation_941  2
    service_0_4_5  unique_nonzero_owner_372  1
    service_0_4_5  service_visit_def_940  1
    service_0_4_5  free_load_conservation_941  3
    service_0_4_6  unique_nonzero_owner_373  1
    service_0_4_6  service_visit_def_940  1
    service_0_4_6  free_load_conservation_941  4
    service_0_4_7  unique_nonzero_owner_374  1
    service_0_4_7  service_visit_def_940  1
    service_0_4_7  free_load_conservation_941  5
    service_0_4_8  unique_nonzero_owner_375  1
    service_0_4_8  service_visit_def_940  1
    service_0_4_8  free_load_conservation_941  6
    service_0_4_9  unique_nonzero_owner_376  1
    service_0_4_9  service_visit_def_940  1
    service_0_4_9  free_load_conservation_941  7
    service_0_4_10  unique_nonzero_owner_377  1
    service_0_4_10  service_visit_def_940  1
    service_0_4_10  free_load_conservation_941  8
    service_0_4_11  unique_nonzero_owner_378  1
    service_0_4_11  service_visit_def_940  1
    service_0_4_11  free_load_conservation_941  9
    service_0_4_12  unique_nonzero_owner_379  1
    service_0_4_12  service_visit_def_940  1
    service_0_4_12  free_load_conservation_941  10
    service_0_4_13  unique_nonzero_owner_380  1
    service_0_4_13  service_visit_def_940  1
    service_0_4_13  free_load_conservation_941  11
    service_0_4_14  unique_nonzero_owner_381  1
    service_0_4_14  service_visit_def_940  1
    service_0_4_14  free_load_conservation_941  12
    service_0_4_15  unique_nonzero_owner_382  1
    service_0_4_15  service_visit_def_940  1
    service_0_4_15  free_load_conservation_941  13
    service_1_4_0  unique_nonzero_owner_368  1
    service_1_4_0  service_visit_def_1261  1
    service_1_4_0  free_load_conservation_1262  -2
    service_1_4_0  original_T_including_depot_unload_1277  240
    service_1_4_1  unique_nonzero_owner_369  1
    service_1_4_1  service_visit_def_1261  1
    service_1_4_1  free_load_conservation_1262  -1
    service_1_4_1  original_T_including_depot_unload_1277  120
    service_1_4_3  unique_nonzero_owner_370  1
    service_1_4_3  service_visit_def_1261  1
    service_1_4_3  free_load_conservation_1262  1
    service_1_4_4  unique_nonzero_owner_371  1
    service_1_4_4  service_visit_def_1261  1
    service_1_4_4  free_load_conservation_1262  2
    service_1_4_5  unique_nonzero_owner_372  1
    service_1_4_5  service_visit_def_1261  1
    service_1_4_5  free_load_conservation_1262  3
    service_1_4_6  unique_nonzero_owner_373  1
    service_1_4_6  service_visit_def_1261  1
    service_1_4_6  free_load_conservation_1262  4
    service_1_4_7  unique_nonzero_owner_374  1
    service_1_4_7  service_visit_def_1261  1
    service_1_4_7  free_load_conservation_1262  5
    service_1_4_8  unique_nonzero_owner_375  1
    service_1_4_8  service_visit_def_1261  1
    service_1_4_8  free_load_conservation_1262  6
    service_1_4_9  unique_nonzero_owner_376  1
    service_1_4_9  service_visit_def_1261  1
    service_1_4_9  free_load_conservation_1262  7
    service_1_4_10  unique_nonzero_owner_377  1
    service_1_4_10  service_visit_def_1261  1
    service_1_4_10  free_load_conservation_1262  8
    service_1_4_11  unique_nonzero_owner_378  1
    service_1_4_11  service_visit_def_1261  1
    service_1_4_11  free_load_conservation_1262  9
    service_1_4_12  unique_nonzero_owner_379  1
    service_1_4_12  service_visit_def_1261  1
    service_1_4_12  free_load_conservation_1262  10
    service_1_4_13  unique_nonzero_owner_380  1
    service_1_4_13  service_visit_def_1261  1
    service_1_4_13  free_load_conservation_1262  11
    service_1_4_14  unique_nonzero_owner_381  1
    service_1_4_14  service_visit_def_1261  1
    service_1_4_14  free_load_conservation_1262  12
    service_1_4_15  unique_nonzero_owner_382  1
    service_1_4_15  service_visit_def_1261  1
    service_1_4_15  free_load_conservation_1262  13
    service_2_4_0  unique_nonzero_owner_368  1
    service_2_4_0  service_visit_def_1631  1
    service_2_4_0  free_load_conservation_1632  -2
    service_2_4_0  original_T_including_depot_unload_1648  240
    service_2_4_1  unique_nonzero_owner_369  1
    service_2_4_1  service_visit_def_1631  1
    service_2_4_1  free_load_conservation_1632  -1
    service_2_4_1  original_T_including_depot_unload_1648  120
    service_2_4_3  unique_nonzero_owner_370  1
    service_2_4_3  service_visit_def_1631  1
    service_2_4_3  free_load_conservation_1632  1
    service_2_4_4  unique_nonzero_owner_371  1
    service_2_4_4  service_visit_def_1631  1
    service_2_4_4  free_load_conservation_1632  2
    service_2_4_5  unique_nonzero_owner_372  1
    service_2_4_5  service_visit_def_1631  1
    service_2_4_5  free_load_conservation_1632  3
    service_2_4_6  unique_nonzero_owner_373  1
    service_2_4_6  service_visit_def_1631  1
    service_2_4_6  free_load_conservation_1632  4
    service_2_4_7  unique_nonzero_owner_374  1
    service_2_4_7  service_visit_def_1631  1
    service_2_4_7  free_load_conservation_1632  5
    service_2_4_8  unique_nonzero_owner_375  1
    service_2_4_8  service_visit_def_1631  1
    service_2_4_8  free_load_conservation_1632  6
    service_2_4_9  unique_nonzero_owner_376  1
    service_2_4_9  service_visit_def_1631  1
    service_2_4_9  free_load_conservation_1632  7
    service_2_4_10  unique_nonzero_owner_377  1
    service_2_4_10  service_visit_def_1631  1
    service_2_4_10  free_load_conservation_1632  8
    service_2_4_11  unique_nonzero_owner_378  1
    service_2_4_11  service_visit_def_1631  1
    service_2_4_11  free_load_conservation_1632  9
    service_2_4_12  unique_nonzero_owner_379  1
    service_2_4_12  service_visit_def_1631  1
    service_2_4_12  free_load_conservation_1632  10
    service_2_4_13  unique_nonzero_owner_380  1
    service_2_4_13  service_visit_def_1631  1
    service_2_4_13  free_load_conservation_1632  11
    service_2_4_14  unique_nonzero_owner_381  1
    service_2_4_14  service_visit_def_1631  1
    service_2_4_14  free_load_conservation_1632  12
    service_2_4_15  unique_nonzero_owner_382  1
    service_2_4_15  service_visit_def_1631  1
    service_2_4_15  free_load_conservation_1632  13
    service_0_27_1  unique_nonzero_owner_383  1
    service_0_27_1  service_visit_def_946  1
    service_0_27_1  free_load_conservation_947  1
    service_0_27_2  unique_nonzero_owner_384  1
    service_0_27_2  service_visit_def_946  1
    service_0_27_2  free_load_conservation_947  2
    service_0_27_3  unique_nonzero_owner_385  1
    service_0_27_3  service_visit_def_946  1
    service_0_27_3  free_load_conservation_947  3
    service_0_27_4  unique_nonzero_owner_386  1
    service_0_27_4  service_visit_def_946  1
    service_0_27_4  free_load_conservation_947  4
    service_0_27_5  unique_nonzero_owner_387  1
    service_0_27_5  service_visit_def_946  1
    service_0_27_5  free_load_conservation_947  5
    service_0_27_6  unique_nonzero_owner_388  1
    service_0_27_6  service_visit_def_946  1
    service_0_27_6  free_load_conservation_947  6
    service_1_27_1  unique_nonzero_owner_383  1
    service_1_27_1  service_visit_def_1267  1
    service_1_27_1  free_load_conservation_1268  1
    service_1_27_2  unique_nonzero_owner_384  1
    service_1_27_2  service_visit_def_1267  1
    service_1_27_2  free_load_conservation_1268  2
    service_1_27_3  unique_nonzero_owner_385  1
    service_1_27_3  service_visit_def_1267  1
    service_1_27_3  free_load_conservation_1268  3
    service_1_27_4  unique_nonzero_owner_386  1
    service_1_27_4  service_visit_def_1267  1
    service_1_27_4  free_load_conservation_1268  4
    service_1_27_5  unique_nonzero_owner_387  1
    service_1_27_5  service_visit_def_1267  1
    service_1_27_5  free_load_conservation_1268  5
    service_1_27_6  unique_nonzero_owner_388  1
    service_1_27_6  service_visit_def_1267  1
    service_1_27_6  free_load_conservation_1268  6
    service_2_27_1  unique_nonzero_owner_383  1
    service_2_27_1  service_visit_def_1637  1
    service_2_27_1  free_load_conservation_1638  1
    service_2_27_2  unique_nonzero_owner_384  1
    service_2_27_2  service_visit_def_1637  1
    service_2_27_2  free_load_conservation_1638  2
    service_2_27_3  unique_nonzero_owner_385  1
    service_2_27_3  service_visit_def_1637  1
    service_2_27_3  free_load_conservation_1638  3
    service_2_27_4  unique_nonzero_owner_386  1
    service_2_27_4  service_visit_def_1637  1
    service_2_27_4  free_load_conservation_1638  4
    service_2_27_5  unique_nonzero_owner_387  1
    service_2_27_5  service_visit_def_1637  1
    service_2_27_5  free_load_conservation_1638  5
    service_2_27_6  unique_nonzero_owner_388  1
    service_2_27_6  service_visit_def_1637  1
    service_2_27_6  free_load_conservation_1638  6
    service_0_5_0  unique_nonzero_owner_389  1
    service_0_5_0  service_visit_def_952  1
    service_0_5_0  free_load_conservation_953  -1
    service_0_5_0  original_T_including_depot_unload_960  120
    service_0_5_2  unique_nonzero_owner_390  1
    service_0_5_2  service_visit_def_952  1
    service_0_5_2  free_load_conservation_953  1
    service_0_5_3  unique_nonzero_owner_391  1
    service_0_5_3  service_visit_def_952  1
    service_0_5_3  free_load_conservation_953  2
    service_0_5_4  unique_nonzero_owner_392  1
    service_0_5_4  service_visit_def_952  1
    service_0_5_4  free_load_conservation_953  3
    service_0_5_5  unique_nonzero_owner_393  1
    service_0_5_5  service_visit_def_952  1
    service_0_5_5  free_load_conservation_953  4
    service_0_5_6  unique_nonzero_owner_394  1
    service_0_5_6  service_visit_def_952  1
    service_0_5_6  free_load_conservation_953  5
    service_0_5_7  unique_nonzero_owner_395  1
    service_0_5_7  service_visit_def_952  1
    service_0_5_7  free_load_conservation_953  6
    service_0_5_8  unique_nonzero_owner_396  1
    service_0_5_8  service_visit_def_952  1
    service_0_5_8  free_load_conservation_953  7
    service_0_5_9  unique_nonzero_owner_397  1
    service_0_5_9  service_visit_def_952  1
    service_0_5_9  free_load_conservation_953  8
    service_0_5_10  unique_nonzero_owner_398  1
    service_0_5_10  service_visit_def_952  1
    service_0_5_10  free_load_conservation_953  9
    service_0_5_11  unique_nonzero_owner_399  1
    service_0_5_11  service_visit_def_952  1
    service_0_5_11  free_load_conservation_953  10
    service_0_5_12  unique_nonzero_owner_400  1
    service_0_5_12  service_visit_def_952  1
    service_0_5_12  free_load_conservation_953  11
    service_0_5_13  unique_nonzero_owner_401  1
    service_0_5_13  service_visit_def_952  1
    service_0_5_13  free_load_conservation_953  12
    service_0_5_14  unique_nonzero_owner_402  1
    service_0_5_14  service_visit_def_952  1
    service_0_5_14  free_load_conservation_953  13
    service_0_5_15  unique_nonzero_owner_403  1
    service_0_5_15  service_visit_def_952  1
    service_0_5_15  free_load_conservation_953  14
    service_1_5_0  unique_nonzero_owner_389  1
    service_1_5_0  service_visit_def_1273  1
    service_1_5_0  free_load_conservation_1274  -1
    service_1_5_0  original_T_including_depot_unload_1277  120
    service_1_5_2  unique_nonzero_owner_390  1
    service_1_5_2  service_visit_def_1273  1
    service_1_5_2  free_load_conservation_1274  1
    service_1_5_3  unique_nonzero_owner_391  1
    service_1_5_3  service_visit_def_1273  1
    service_1_5_3  free_load_conservation_1274  2
    service_1_5_4  unique_nonzero_owner_392  1
    service_1_5_4  service_visit_def_1273  1
    service_1_5_4  free_load_conservation_1274  3
    service_1_5_5  unique_nonzero_owner_393  1
    service_1_5_5  service_visit_def_1273  1
    service_1_5_5  free_load_conservation_1274  4
    service_1_5_6  unique_nonzero_owner_394  1
    service_1_5_6  service_visit_def_1273  1
    service_1_5_6  free_load_conservation_1274  5
    service_1_5_7  unique_nonzero_owner_395  1
    service_1_5_7  service_visit_def_1273  1
    service_1_5_7  free_load_conservation_1274  6
    service_1_5_8  unique_nonzero_owner_396  1
    service_1_5_8  service_visit_def_1273  1
    service_1_5_8  free_load_conservation_1274  7
    service_1_5_9  unique_nonzero_owner_397  1
    service_1_5_9  service_visit_def_1273  1
    service_1_5_9  free_load_conservation_1274  8
    service_1_5_10  unique_nonzero_owner_398  1
    service_1_5_10  service_visit_def_1273  1
    service_1_5_10  free_load_conservation_1274  9
    service_1_5_11  unique_nonzero_owner_399  1
    service_1_5_11  service_visit_def_1273  1
    service_1_5_11  free_load_conservation_1274  10
    service_1_5_12  unique_nonzero_owner_400  1
    service_1_5_12  service_visit_def_1273  1
    service_1_5_12  free_load_conservation_1274  11
    service_1_5_13  unique_nonzero_owner_401  1
    service_1_5_13  service_visit_def_1273  1
    service_1_5_13  free_load_conservation_1274  12
    service_1_5_14  unique_nonzero_owner_402  1
    service_1_5_14  service_visit_def_1273  1
    service_1_5_14  free_load_conservation_1274  13
    service_1_5_15  unique_nonzero_owner_403  1
    service_1_5_15  service_visit_def_1273  1
    service_1_5_15  free_load_conservation_1274  14
    service_2_5_0  unique_nonzero_owner_389  1
    service_2_5_0  service_visit_def_1643  1
    service_2_5_0  free_load_conservation_1644  -1
    service_2_5_0  original_T_including_depot_unload_1648  120
    service_2_5_2  unique_nonzero_owner_390  1
    service_2_5_2  service_visit_def_1643  1
    service_2_5_2  free_load_conservation_1644  1
    service_2_5_3  unique_nonzero_owner_391  1
    service_2_5_3  service_visit_def_1643  1
    service_2_5_3  free_load_conservation_1644  2
    service_2_5_4  unique_nonzero_owner_392  1
    service_2_5_4  service_visit_def_1643  1
    service_2_5_4  free_load_conservation_1644  3
    service_2_5_5  unique_nonzero_owner_393  1
    service_2_5_5  service_visit_def_1643  1
    service_2_5_5  free_load_conservation_1644  4
    service_2_5_6  unique_nonzero_owner_394  1
    service_2_5_6  service_visit_def_1643  1
    service_2_5_6  free_load_conservation_1644  5
    service_2_5_7  unique_nonzero_owner_395  1
    service_2_5_7  service_visit_def_1643  1
    service_2_5_7  free_load_conservation_1644  6
    service_2_5_8  unique_nonzero_owner_396  1
    service_2_5_8  service_visit_def_1643  1
    service_2_5_8  free_load_conservation_1644  7
    service_2_5_9  unique_nonzero_owner_397  1
    service_2_5_9  service_visit_def_1643  1
    service_2_5_9  free_load_conservation_1644  8
    service_2_5_10  unique_nonzero_owner_398  1
    service_2_5_10  service_visit_def_1643  1
    service_2_5_10  free_load_conservation_1644  9
    service_2_5_11  unique_nonzero_owner_399  1
    service_2_5_11  service_visit_def_1643  1
    service_2_5_11  free_load_conservation_1644  10
    service_2_5_12  unique_nonzero_owner_400  1
    service_2_5_12  service_visit_def_1643  1
    service_2_5_12  free_load_conservation_1644  11
    service_2_5_13  unique_nonzero_owner_401  1
    service_2_5_13  service_visit_def_1643  1
    service_2_5_13  free_load_conservation_1644  12
    service_2_5_14  unique_nonzero_owner_402  1
    service_2_5_14  service_visit_def_1643  1
    service_2_5_14  free_load_conservation_1644  13
    service_2_5_15  unique_nonzero_owner_403  1
    service_2_5_15  service_visit_def_1643  1
    service_2_5_15  free_load_conservation_1644  14
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_857  -1
    visit_0_1  in_degree_858  -1
    visit_0_1  order_active_lb_859  -1
    visit_0_1  order_active_ub_860  -15
    order_0_1  connected_order_arc_422  -1
    order_0_1  connected_order_arc_424  -1
    order_0_1  connected_order_arc_426  -1
    order_0_1  connected_order_arc_428  -1
    order_0_1  connected_order_arc_430  -1
    order_0_1  connected_order_arc_432  -1
    order_0_1  connected_order_arc_434  -1
    order_0_1  connected_order_arc_436  -1
    order_0_1  connected_order_arc_438  -1
    order_0_1  connected_order_arc_440  -1
    order_0_1  connected_order_arc_442  -1
    order_0_1  connected_order_arc_444  -1
    order_0_1  connected_order_arc_446  -1
    order_0_1  connected_order_arc_448  -1
    order_0_1  connected_order_arc_451  1
    order_0_1  connected_order_arc_480  1
    order_0_1  connected_order_arc_509  1
    order_0_1  connected_order_arc_538  1
    order_0_1  connected_order_arc_567  1
    order_0_1  connected_order_arc_596  1
    order_0_1  connected_order_arc_625  1
    order_0_1  connected_order_arc_654  1
    order_0_1  connected_order_arc_683  1
    order_0_1  connected_order_arc_712  1
    order_0_1  connected_order_arc_741  1
    order_0_1  connected_order_arc_770  1
    order_0_1  connected_order_arc_799  1
    order_0_1  connected_order_arc_828  1
    order_0_1  order_active_lb_859  1
    order_0_1  order_active_ub_860  1
    order_0_1  fixed_segment_relative_order_954  -1
    visit_0_2  out_degree_864  -1
    visit_0_2  in_degree_865  -1
    visit_0_2  order_active_lb_866  -1
    visit_0_2  order_active_ub_867  -15
    order_0_2  connected_order_arc_422  1
    order_0_2  connected_order_arc_451  -1
    order_0_2  connected_order_arc_453  -1
    order_0_2  connected_order_arc_455  -1
    order_0_2  connected_order_arc_457  -1
    order_0_2  connected_order_arc_459  -1
    order_0_2  connected_order_arc_461  -1
    order_0_2  connected_order_arc_463  -1
    order_0_2  connected_order_arc_465  -1
    order_0_2  connected_order_arc_467  -1
    order_0_2  connected_order_arc_469  -1
    order_0_2  connected_order_arc_471  -1
    order_0_2  connected_order_arc_473  -1
    order_0_2  connected_order_arc_475  -1
    order_0_2  connected_order_arc_477  -1
    order_0_2  connected_order_arc_482  1
    order_0_2  connected_order_arc_511  1
    order_0_2  connected_order_arc_540  1
    order_0_2  connected_order_arc_569  1
    order_0_2  connected_order_arc_598  1
    order_0_2  connected_order_arc_627  1
    order_0_2  connected_order_arc_656  1
    order_0_2  connected_order_arc_685  1
    order_0_2  connected_order_arc_714  1
    order_0_2  connected_order_arc_743  1
    order_0_2  connected_order_arc_772  1
    order_0_2  connected_order_arc_801  1
    order_0_2  connected_order_arc_830  1
    order_0_2  order_active_lb_866  1
    order_0_2  order_active_ub_867  1
    order_0_2  fixed_segment_relative_order_954  1
    order_0_2  fixed_segment_relative_order_955  -1
    visit_0_3  out_degree_871  -1
    visit_0_3  in_degree_872  -1
    visit_0_3  order_active_lb_873  -1
    visit_0_3  order_active_ub_874  -15
    order_0_3  connected_order_arc_424  1
    order_0_3  connected_order_arc_453  1
    order_0_3  connected_order_arc_480  -1
    order_0_3  connected_order_arc_482  -1
    order_0_3  connected_order_arc_484  -1
    order_0_3  connected_order_arc_486  -1
    order_0_3  connected_order_arc_488  -1
    order_0_3  connected_order_arc_490  -1
    order_0_3  connected_order_arc_492  -1
    order_0_3  connected_order_arc_494  -1
    order_0_3  connected_order_arc_496  -1
    order_0_3  connected_order_arc_498  -1
    order_0_3  connected_order_arc_500  -1
    order_0_3  connected_order_arc_502  -1
    order_0_3  connected_order_arc_504  -1
    order_0_3  connected_order_arc_506  -1
    order_0_3  connected_order_arc_513  1
    order_0_3  connected_order_arc_542  1
    order_0_3  connected_order_arc_571  1
    order_0_3  connected_order_arc_600  1
    order_0_3  connected_order_arc_629  1
    order_0_3  connected_order_arc_658  1
    order_0_3  connected_order_arc_687  1
    order_0_3  connected_order_arc_716  1
    order_0_3  connected_order_arc_745  1
    order_0_3  connected_order_arc_774  1
    order_0_3  connected_order_arc_803  1
    order_0_3  connected_order_arc_832  1
    order_0_3  order_active_lb_873  1
    order_0_3  order_active_ub_874  1
    order_0_3  fixed_segment_relative_order_955  1
    order_0_3  fixed_segment_relative_order_956  -1
    visit_0_4  out_degree_878  -1
    visit_0_4  in_degree_879  -1
    visit_0_4  order_active_lb_880  -1
    visit_0_4  order_active_ub_881  -15
    order_0_4  connected_order_arc_426  1
    order_0_4  connected_order_arc_455  1
    order_0_4  connected_order_arc_484  1
    order_0_4  connected_order_arc_509  -1
    order_0_4  connected_order_arc_511  -1
    order_0_4  connected_order_arc_513  -1
    order_0_4  connected_order_arc_515  -1
    order_0_4  connected_order_arc_517  -1
    order_0_4  connected_order_arc_519  -1
    order_0_4  connected_order_arc_521  -1
    order_0_4  connected_order_arc_523  -1
    order_0_4  connected_order_arc_525  -1
    order_0_4  connected_order_arc_527  -1
    order_0_4  connected_order_arc_529  -1
    order_0_4  connected_order_arc_531  -1
    order_0_4  connected_order_arc_533  -1
    order_0_4  connected_order_arc_535  -1
    order_0_4  connected_order_arc_544  1
    order_0_4  connected_order_arc_573  1
    order_0_4  connected_order_arc_602  1
    order_0_4  connected_order_arc_631  1
    order_0_4  connected_order_arc_660  1
    order_0_4  connected_order_arc_689  1
    order_0_4  connected_order_arc_718  1
    order_0_4  connected_order_arc_747  1
    order_0_4  connected_order_arc_776  1
    order_0_4  connected_order_arc_805  1
    order_0_4  connected_order_arc_834  1
    order_0_4  order_active_lb_880  1
    order_0_4  order_active_ub_881  1
    order_0_4  fixed_segment_relative_order_956  1
    order_0_4  fixed_segment_relative_order_957  -1
    visit_0_5  out_degree_885  -1
    visit_0_5  in_degree_886  -1
    visit_0_5  order_active_lb_887  -1
    visit_0_5  order_active_ub_888  -15
    order_0_5  connected_order_arc_428  1
    order_0_5  connected_order_arc_457  1
    order_0_5  connected_order_arc_486  1
    order_0_5  connected_order_arc_515  1
    order_0_5  connected_order_arc_538  -1
    order_0_5  connected_order_arc_540  -1
    order_0_5  connected_order_arc_542  -1
    order_0_5  connected_order_arc_544  -1
    order_0_5  connected_order_arc_546  -1
    order_0_5  connected_order_arc_548  -1
    order_0_5  connected_order_arc_550  -1
    order_0_5  connected_order_arc_552  -1
    order_0_5  connected_order_arc_554  -1
    order_0_5  connected_order_arc_556  -1
    order_0_5  connected_order_arc_558  -1
    order_0_5  connected_order_arc_560  -1
    order_0_5  connected_order_arc_562  -1
    order_0_5  connected_order_arc_564  -1
    order_0_5  connected_order_arc_575  1
    order_0_5  connected_order_arc_604  1
    order_0_5  connected_order_arc_633  1
    order_0_5  connected_order_arc_662  1
    order_0_5  connected_order_arc_691  1
    order_0_5  connected_order_arc_720  1
    order_0_5  connected_order_arc_749  1
    order_0_5  connected_order_arc_778  1
    order_0_5  connected_order_arc_807  1
    order_0_5  connected_order_arc_836  1
    order_0_5  order_active_lb_887  1
    order_0_5  order_active_ub_888  1
    order_0_5  fixed_segment_relative_order_957  1
    order_0_5  fixed_segment_relative_order_958  -1
    visit_0_6  out_degree_892  -1
    visit_0_6  in_degree_893  -1
    visit_0_6  order_active_lb_894  -1
    visit_0_6  order_active_ub_895  -15
    order_0_6  connected_order_arc_430  1
    order_0_6  connected_order_arc_459  1
    order_0_6  connected_order_arc_488  1
    order_0_6  connected_order_arc_517  1
    order_0_6  connected_order_arc_546  1
    order_0_6  connected_order_arc_567  -1
    order_0_6  connected_order_arc_569  -1
    order_0_6  connected_order_arc_571  -1
    order_0_6  connected_order_arc_573  -1
    order_0_6  connected_order_arc_575  -1
    order_0_6  connected_order_arc_577  -1
    order_0_6  connected_order_arc_579  -1
    order_0_6  connected_order_arc_581  -1
    order_0_6  connected_order_arc_583  -1
    order_0_6  connected_order_arc_585  -1
    order_0_6  connected_order_arc_587  -1
    order_0_6  connected_order_arc_589  -1
    order_0_6  connected_order_arc_591  -1
    order_0_6  connected_order_arc_593  -1
    order_0_6  connected_order_arc_606  1
    order_0_6  connected_order_arc_635  1
    order_0_6  connected_order_arc_664  1
    order_0_6  connected_order_arc_693  1
    order_0_6  connected_order_arc_722  1
    order_0_6  connected_order_arc_751  1
    order_0_6  connected_order_arc_780  1
    order_0_6  connected_order_arc_809  1
    order_0_6  connected_order_arc_838  1
    order_0_6  order_active_lb_894  1
    order_0_6  order_active_ub_895  1
    order_0_6  fixed_segment_relative_order_958  1
    order_0_6  fixed_segment_relative_order_959  -1
    visit_0_7  out_degree_899  -1
    visit_0_7  in_degree_900  -1
    visit_0_7  order_active_lb_901  -1
    visit_0_7  order_active_ub_902  -15
    order_0_7  connected_order_arc_432  1
    order_0_7  connected_order_arc_461  1
    order_0_7  connected_order_arc_490  1
    order_0_7  connected_order_arc_519  1
    order_0_7  connected_order_arc_548  1
    order_0_7  connected_order_arc_577  1
    order_0_7  connected_order_arc_596  -1
    order_0_7  connected_order_arc_598  -1
    order_0_7  connected_order_arc_600  -1
    order_0_7  connected_order_arc_602  -1
    order_0_7  connected_order_arc_604  -1
    order_0_7  connected_order_arc_606  -1
    order_0_7  connected_order_arc_608  -1
    order_0_7  connected_order_arc_610  -1
    order_0_7  connected_order_arc_612  -1
    order_0_7  connected_order_arc_614  -1
    order_0_7  connected_order_arc_616  -1
    order_0_7  connected_order_arc_618  -1
    order_0_7  connected_order_arc_620  -1
    order_0_7  connected_order_arc_622  -1
    order_0_7  connected_order_arc_637  1
    order_0_7  connected_order_arc_666  1
    order_0_7  connected_order_arc_695  1
    order_0_7  connected_order_arc_724  1
    order_0_7  connected_order_arc_753  1
    order_0_7  connected_order_arc_782  1
    order_0_7  connected_order_arc_811  1
    order_0_7  connected_order_arc_840  1
    order_0_7  order_active_lb_901  1
    order_0_7  order_active_ub_902  1
    order_0_7  fixed_segment_relative_order_959  1
    visit_0_15  out_degree_906  -1
    visit_0_15  in_degree_907  -1
    visit_0_15  order_active_lb_908  -1
    visit_0_15  order_active_ub_909  -15
    visit_0_15  service_visit_def_910  -1
    order_0_15  connected_order_arc_434  1
    order_0_15  connected_order_arc_463  1
    order_0_15  connected_order_arc_492  1
    order_0_15  connected_order_arc_521  1
    order_0_15  connected_order_arc_550  1
    order_0_15  connected_order_arc_579  1
    order_0_15  connected_order_arc_608  1
    order_0_15  connected_order_arc_625  -1
    order_0_15  connected_order_arc_627  -1
    order_0_15  connected_order_arc_629  -1
    order_0_15  connected_order_arc_631  -1
    order_0_15  connected_order_arc_633  -1
    order_0_15  connected_order_arc_635  -1
    order_0_15  connected_order_arc_637  -1
    order_0_15  connected_order_arc_639  -1
    order_0_15  connected_order_arc_641  -1
    order_0_15  connected_order_arc_643  -1
    order_0_15  connected_order_arc_645  -1
    order_0_15  connected_order_arc_647  -1
    order_0_15  connected_order_arc_649  -1
    order_0_15  connected_order_arc_651  -1
    order_0_15  connected_order_arc_668  1
    order_0_15  connected_order_arc_697  1
    order_0_15  connected_order_arc_726  1
    order_0_15  connected_order_arc_755  1
    order_0_15  connected_order_arc_784  1
    order_0_15  connected_order_arc_813  1
    order_0_15  connected_order_arc_842  1
    order_0_15  order_active_lb_908  1
    order_0_15  order_active_ub_909  1
    visit_0_16  out_degree_912  -1
    visit_0_16  in_degree_913  -1
    visit_0_16  order_active_lb_914  -1
    visit_0_16  order_active_ub_915  -15
    visit_0_16  service_visit_def_916  -1
    order_0_16  connected_order_arc_436  1
    order_0_16  connected_order_arc_465  1
    order_0_16  connected_order_arc_494  1
    order_0_16  connected_order_arc_523  1
    order_0_16  connected_order_arc_552  1
    order_0_16  connected_order_arc_581  1
    order_0_16  connected_order_arc_610  1
    order_0_16  connected_order_arc_639  1
    order_0_16  connected_order_arc_654  -1
    order_0_16  connected_order_arc_656  -1
    order_0_16  connected_order_arc_658  -1
    order_0_16  connected_order_arc_660  -1
    order_0_16  connected_order_arc_662  -1
    order_0_16  connected_order_arc_664  -1
    order_0_16  connected_order_arc_666  -1
    order_0_16  connected_order_arc_668  -1
    order_0_16  connected_order_arc_670  -1
    order_0_16  connected_order_arc_672  -1
    order_0_16  connected_order_arc_674  -1
    order_0_16  connected_order_arc_676  -1
    order_0_16  connected_order_arc_678  -1
    order_0_16  connected_order_arc_680  -1
    order_0_16  connected_order_arc_699  1
    order_0_16  connected_order_arc_728  1
    order_0_16  connected_order_arc_757  1
    order_0_16  connected_order_arc_786  1
    order_0_16  connected_order_arc_815  1
    order_0_16  connected_order_arc_844  1
    order_0_16  order_active_lb_914  1
    order_0_16  order_active_ub_915  1
    visit_0_17  out_degree_918  -1
    visit_0_17  in_degree_919  -1
    visit_0_17  order_active_lb_920  -1
    visit_0_17  order_active_ub_921  -15
    visit_0_17  service_visit_def_922  -1
    order_0_17  connected_order_arc_438  1
    order_0_17  connected_order_arc_467  1
    order_0_17  connected_order_arc_496  1
    order_0_17  connected_order_arc_525  1
    order_0_17  connected_order_arc_554  1
    order_0_17  connected_order_arc_583  1
    order_0_17  connected_order_arc_612  1
    order_0_17  connected_order_arc_641  1
    order_0_17  connected_order_arc_670  1
    order_0_17  connected_order_arc_683  -1
    order_0_17  connected_order_arc_685  -1
    order_0_17  connected_order_arc_687  -1
    order_0_17  connected_order_arc_689  -1
    order_0_17  connected_order_arc_691  -1
    order_0_17  connected_order_arc_693  -1
    order_0_17  connected_order_arc_695  -1
    order_0_17  connected_order_arc_697  -1
    order_0_17  connected_order_arc_699  -1
    order_0_17  connected_order_arc_701  -1
    order_0_17  connected_order_arc_703  -1
    order_0_17  connected_order_arc_705  -1
    order_0_17  connected_order_arc_707  -1
    order_0_17  connected_order_arc_709  -1
    order_0_17  connected_order_arc_730  1
    order_0_17  connected_order_arc_759  1
    order_0_17  connected_order_arc_788  1
    order_0_17  connected_order_arc_817  1
    order_0_17  connected_order_arc_846  1
    order_0_17  order_active_lb_920  1
    order_0_17  order_active_ub_921  1
    visit_0_18  out_degree_924  -1
    visit_0_18  in_degree_925  -1
    visit_0_18  order_active_lb_926  -1
    visit_0_18  order_active_ub_927  -15
    visit_0_18  service_visit_def_928  -1
    order_0_18  connected_order_arc_440  1
    order_0_18  connected_order_arc_469  1
    order_0_18  connected_order_arc_498  1
    order_0_18  connected_order_arc_527  1
    order_0_18  connected_order_arc_556  1
    order_0_18  connected_order_arc_585  1
    order_0_18  connected_order_arc_614  1
    order_0_18  connected_order_arc_643  1
    order_0_18  connected_order_arc_672  1
    order_0_18  connected_order_arc_701  1
    order_0_18  connected_order_arc_712  -1
    order_0_18  connected_order_arc_714  -1
    order_0_18  connected_order_arc_716  -1
    order_0_18  connected_order_arc_718  -1
    order_0_18  connected_order_arc_720  -1
    order_0_18  connected_order_arc_722  -1
    order_0_18  connected_order_arc_724  -1
    order_0_18  connected_order_arc_726  -1
    order_0_18  connected_order_arc_728  -1
    order_0_18  connected_order_arc_730  -1
    order_0_18  connected_order_arc_732  -1
    order_0_18  connected_order_arc_734  -1
    order_0_18  connected_order_arc_736  -1
    order_0_18  connected_order_arc_738  -1
    order_0_18  connected_order_arc_761  1
    order_0_18  connected_order_arc_790  1
    order_0_18  connected_order_arc_819  1
    order_0_18  connected_order_arc_848  1
    order_0_18  order_active_lb_926  1
    order_0_18  order_active_ub_927  1
    visit_0_19  out_degree_930  -1
    visit_0_19  in_degree_931  -1
    visit_0_19  order_active_lb_932  -1
    visit_0_19  order_active_ub_933  -15
    visit_0_19  service_visit_def_934  -1
    order_0_19  connected_order_arc_442  1
    order_0_19  connected_order_arc_471  1
    order_0_19  connected_order_arc_500  1
    order_0_19  connected_order_arc_529  1
    order_0_19  connected_order_arc_558  1
    order_0_19  connected_order_arc_587  1
    order_0_19  connected_order_arc_616  1
    order_0_19  connected_order_arc_645  1
    order_0_19  connected_order_arc_674  1
    order_0_19  connected_order_arc_703  1
    order_0_19  connected_order_arc_732  1
    order_0_19  connected_order_arc_741  -1
    order_0_19  connected_order_arc_743  -1
    order_0_19  connected_order_arc_745  -1
    order_0_19  connected_order_arc_747  -1
    order_0_19  connected_order_arc_749  -1
    order_0_19  connected_order_arc_751  -1
    order_0_19  connected_order_arc_753  -1
    order_0_19  connected_order_arc_755  -1
    order_0_19  connected_order_arc_757  -1
    order_0_19  connected_order_arc_759  -1
    order_0_19  connected_order_arc_761  -1
    order_0_19  connected_order_arc_763  -1
    order_0_19  connected_order_arc_765  -1
    order_0_19  connected_order_arc_767  -1
    order_0_19  connected_order_arc_792  1
    order_0_19  connected_order_arc_821  1
    order_0_19  connected_order_arc_850  1
    order_0_19  order_active_lb_932  1
    order_0_19  order_active_ub_933  1
    visit_0_20  out_degree_936  -1
    visit_0_20  in_degree_937  -1
    visit_0_20  order_active_lb_938  -1
    visit_0_20  order_active_ub_939  -15
    visit_0_20  service_visit_def_940  -1
    order_0_20  connected_order_arc_444  1
    order_0_20  connected_order_arc_473  1
    order_0_20  connected_order_arc_502  1
    order_0_20  connected_order_arc_531  1
    order_0_20  connected_order_arc_560  1
    order_0_20  connected_order_arc_589  1
    order_0_20  connected_order_arc_618  1
    order_0_20  connected_order_arc_647  1
    order_0_20  connected_order_arc_676  1
    order_0_20  connected_order_arc_705  1
    order_0_20  connected_order_arc_734  1
    order_0_20  connected_order_arc_763  1
    order_0_20  connected_order_arc_770  -1
    order_0_20  connected_order_arc_772  -1
    order_0_20  connected_order_arc_774  -1
    order_0_20  connected_order_arc_776  -1
    order_0_20  connected_order_arc_778  -1
    order_0_20  connected_order_arc_780  -1
    order_0_20  connected_order_arc_782  -1
    order_0_20  connected_order_arc_784  -1
    order_0_20  connected_order_arc_786  -1
    order_0_20  connected_order_arc_788  -1
    order_0_20  connected_order_arc_790  -1
    order_0_20  connected_order_arc_792  -1
    order_0_20  connected_order_arc_794  -1
    order_0_20  connected_order_arc_796  -1
    order_0_20  connected_order_arc_823  1
    order_0_20  connected_order_arc_852  1
    order_0_20  order_active_lb_938  1
    order_0_20  order_active_ub_939  1
    visit_0_21  out_degree_942  -1
    visit_0_21  in_degree_943  -1
    visit_0_21  order_active_lb_944  -1
    visit_0_21  order_active_ub_945  -15
    visit_0_21  service_visit_def_946  -1
    order_0_21  connected_order_arc_446  1
    order_0_21  connected_order_arc_475  1
    order_0_21  connected_order_arc_504  1
    order_0_21  connected_order_arc_533  1
    order_0_21  connected_order_arc_562  1
    order_0_21  connected_order_arc_591  1
    order_0_21  connected_order_arc_620  1
    order_0_21  connected_order_arc_649  1
    order_0_21  connected_order_arc_678  1
    order_0_21  connected_order_arc_707  1
    order_0_21  connected_order_arc_736  1
    order_0_21  connected_order_arc_765  1
    order_0_21  connected_order_arc_794  1
    order_0_21  connected_order_arc_799  -1
    order_0_21  connected_order_arc_801  -1
    order_0_21  connected_order_arc_803  -1
    order_0_21  connected_order_arc_805  -1
    order_0_21  connected_order_arc_807  -1
    order_0_21  connected_order_arc_809  -1
    order_0_21  connected_order_arc_811  -1
    order_0_21  connected_order_arc_813  -1
    order_0_21  connected_order_arc_815  -1
    order_0_21  connected_order_arc_817  -1
    order_0_21  connected_order_arc_819  -1
    order_0_21  connected_order_arc_821  -1
    order_0_21  connected_order_arc_823  -1
    order_0_21  connected_order_arc_825  -1
    order_0_21  connected_order_arc_854  1
    order_0_21  order_active_lb_944  1
    order_0_21  order_active_ub_945  1
    visit_0_22  out_degree_948  -1
    visit_0_22  in_degree_949  -1
    visit_0_22  order_active_lb_950  -1
    visit_0_22  order_active_ub_951  -15
    visit_0_22  service_visit_def_952  -1
    order_0_22  connected_order_arc_448  1
    order_0_22  connected_order_arc_477  1
    order_0_22  connected_order_arc_506  1
    order_0_22  connected_order_arc_535  1
    order_0_22  connected_order_arc_564  1
    order_0_22  connected_order_arc_593  1
    order_0_22  connected_order_arc_622  1
    order_0_22  connected_order_arc_651  1
    order_0_22  connected_order_arc_680  1
    order_0_22  connected_order_arc_709  1
    order_0_22  connected_order_arc_738  1
    order_0_22  connected_order_arc_767  1
    order_0_22  connected_order_arc_796  1
    order_0_22  connected_order_arc_825  1
    order_0_22  connected_order_arc_828  -1
    order_0_22  connected_order_arc_830  -1
    order_0_22  connected_order_arc_832  -1
    order_0_22  connected_order_arc_834  -1
    order_0_22  connected_order_arc_836  -1
    order_0_22  connected_order_arc_838  -1
    order_0_22  connected_order_arc_840  -1
    order_0_22  connected_order_arc_842  -1
    order_0_22  connected_order_arc_844  -1
    order_0_22  connected_order_arc_846  -1
    order_0_22  connected_order_arc_848  -1
    order_0_22  connected_order_arc_850  -1
    order_0_22  connected_order_arc_852  -1
    order_0_22  connected_order_arc_854  -1
    order_0_22  order_active_lb_950  1
    order_0_22  order_active_ub_951  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_404  -20
    arc_0_0_0  depot_departure_or_bypass_855  1
    arc_0_0_0  depot_return_or_bypass_856  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_404  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_405  -20
    arc_0_0_1  depot_departure_or_bypass_855  1
    arc_0_0_1  in_degree_858  1
    arc_0_0_1  original_T_including_depot_unload_960  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_405  1
    load_0_0_1  segment_load_conservation_861  -1
    load_0_0_1  segment_prefix_lb_862  1
    load_0_0_1  segment_prefix_ub_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_406  -20
    arc_0_0_2  depot_departure_or_bypass_855  1
    arc_0_0_2  in_degree_865  1
    arc_0_0_2  original_T_including_depot_unload_960  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_406  1
    load_0_0_2  segment_load_conservation_868  -1
    load_0_0_2  segment_prefix_lb_869  1
    load_0_0_2  segment_prefix_ub_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_407  -20
    arc_0_0_3  depot_departure_or_bypass_855  1
    arc_0_0_3  in_degree_872  1
    arc_0_0_3  original_T_including_depot_unload_960  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_407  1
    load_0_0_3  segment_load_conservation_875  -1
    load_0_0_3  segment_prefix_lb_876  1
    load_0_0_3  segment_prefix_ub_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_408  -20
    arc_0_0_4  depot_departure_or_bypass_855  1
    arc_0_0_4  in_degree_879  1
    arc_0_0_4  original_T_including_depot_unload_960  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_408  1
    load_0_0_4  segment_load_conservation_882  -1
    load_0_0_4  segment_prefix_lb_883  1
    load_0_0_4  segment_prefix_ub_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_409  -20
    arc_0_0_5  depot_departure_or_bypass_855  1
    arc_0_0_5  in_degree_886  1
    arc_0_0_5  original_T_including_depot_unload_960  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_409  1
    load_0_0_5  segment_load_conservation_889  -1
    load_0_0_5  segment_prefix_lb_890  1
    load_0_0_5  segment_prefix_ub_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_410  -20
    arc_0_0_6  depot_departure_or_bypass_855  1
    arc_0_0_6  in_degree_893  1
    arc_0_0_6  original_T_including_depot_unload_960  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_410  1
    load_0_0_6  segment_load_conservation_896  -1
    load_0_0_6  segment_prefix_lb_897  1
    load_0_0_6  segment_prefix_ub_898  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_7  arc_capacity_411  -20
    arc_0_0_7  depot_departure_or_bypass_855  1
    arc_0_0_7  in_degree_900  1
    arc_0_0_7  original_T_including_depot_unload_960  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_7  arc_capacity_411  1
    load_0_0_7  segment_load_conservation_903  -1
    load_0_0_7  segment_prefix_lb_904  1
    load_0_0_7  segment_prefix_ub_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_412  -20
    arc_0_0_15  depot_departure_or_bypass_855  1
    arc_0_0_15  in_degree_907  1
    arc_0_0_15  original_T_including_depot_unload_960  1.9654373797357937e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_412  1
    load_0_0_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_413  -20
    arc_0_0_16  depot_departure_or_bypass_855  1
    arc_0_0_16  in_degree_913  1
    arc_0_0_16  original_T_including_depot_unload_960  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_413  1
    load_0_0_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_414  -20
    arc_0_0_17  depot_departure_or_bypass_855  1
    arc_0_0_17  in_degree_919  1
    arc_0_0_17  original_T_including_depot_unload_960  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_414  1
    load_0_0_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_415  -20
    arc_0_0_18  depot_departure_or_bypass_855  1
    arc_0_0_18  in_degree_925  1
    arc_0_0_18  original_T_including_depot_unload_960  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_415  1
    load_0_0_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_416  -20
    arc_0_0_19  depot_departure_or_bypass_855  1
    arc_0_0_19  in_degree_931  1
    arc_0_0_19  original_T_including_depot_unload_960  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_416  1
    load_0_0_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_417  -20
    arc_0_0_20  depot_departure_or_bypass_855  1
    arc_0_0_20  in_degree_937  1
    arc_0_0_20  original_T_including_depot_unload_960  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_417  1
    load_0_0_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_418  -20
    arc_0_0_21  depot_departure_or_bypass_855  1
    arc_0_0_21  in_degree_943  1
    arc_0_0_21  original_T_including_depot_unload_960  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_418  1
    load_0_0_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_419  -20
    arc_0_0_22  depot_departure_or_bypass_855  1
    arc_0_0_22  in_degree_949  1
    arc_0_0_22  original_T_including_depot_unload_960  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_419  1
    load_0_0_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_420  -20
    arc_0_1_0  depot_return_or_bypass_856  1
    arc_0_1_0  out_degree_857  1
    arc_0_1_0  original_T_including_depot_unload_960  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_420  1
    load_0_1_0  segment_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_421  -20
    arc_0_1_2  connected_order_arc_422  -16
    arc_0_1_2  out_degree_857  1
    arc_0_1_2  in_degree_865  1
    arc_0_1_2  original_T_including_depot_unload_960  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_421  1
    load_0_1_2  segment_load_conservation_861  1
    load_0_1_2  segment_load_conservation_868  -1
    load_0_1_2  segment_prefix_lb_869  1
    load_0_1_2  segment_prefix_ub_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_423  -20
    arc_0_1_3  connected_order_arc_424  -16
    arc_0_1_3  out_degree_857  1
    arc_0_1_3  in_degree_872  1
    arc_0_1_3  original_T_including_depot_unload_960  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_423  1
    load_0_1_3  segment_load_conservation_861  1
    load_0_1_3  segment_load_conservation_875  -1
    load_0_1_3  segment_prefix_lb_876  1
    load_0_1_3  segment_prefix_ub_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_425  -20
    arc_0_1_4  connected_order_arc_426  -16
    arc_0_1_4  out_degree_857  1
    arc_0_1_4  in_degree_879  1
    arc_0_1_4  original_T_including_depot_unload_960  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_425  1
    load_0_1_4  segment_load_conservation_861  1
    load_0_1_4  segment_load_conservation_882  -1
    load_0_1_4  segment_prefix_lb_883  1
    load_0_1_4  segment_prefix_ub_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_427  -20
    arc_0_1_5  connected_order_arc_428  -16
    arc_0_1_5  out_degree_857  1
    arc_0_1_5  in_degree_886  1
    arc_0_1_5  original_T_including_depot_unload_960  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_427  1
    load_0_1_5  segment_load_conservation_861  1
    load_0_1_5  segment_load_conservation_889  -1
    load_0_1_5  segment_prefix_lb_890  1
    load_0_1_5  segment_prefix_ub_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_429  -20
    arc_0_1_6  connected_order_arc_430  -16
    arc_0_1_6  out_degree_857  1
    arc_0_1_6  in_degree_893  1
    arc_0_1_6  original_T_including_depot_unload_960  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_429  1
    load_0_1_6  segment_load_conservation_861  1
    load_0_1_6  segment_load_conservation_896  -1
    load_0_1_6  segment_prefix_lb_897  1
    load_0_1_6  segment_prefix_ub_898  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_7  arc_capacity_431  -20
    arc_0_1_7  connected_order_arc_432  -16
    arc_0_1_7  out_degree_857  1
    arc_0_1_7  in_degree_900  1
    arc_0_1_7  original_T_including_depot_unload_960  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_7  arc_capacity_431  1
    load_0_1_7  segment_load_conservation_861  1
    load_0_1_7  segment_load_conservation_903  -1
    load_0_1_7  segment_prefix_lb_904  1
    load_0_1_7  segment_prefix_ub_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_433  -20
    arc_0_1_15  connected_order_arc_434  -16
    arc_0_1_15  out_degree_857  1
    arc_0_1_15  in_degree_907  1
    arc_0_1_15  original_T_including_depot_unload_960  1.3598923863120219e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_433  1
    load_0_1_15  segment_load_conservation_861  1
    load_0_1_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_435  -20
    arc_0_1_16  connected_order_arc_436  -16
    arc_0_1_16  out_degree_857  1
    arc_0_1_16  in_degree_913  1
    arc_0_1_16  original_T_including_depot_unload_960  8.9619134786808888e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_435  1
    load_0_1_16  segment_load_conservation_861  1
    load_0_1_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_437  -20
    arc_0_1_17  connected_order_arc_438  -16
    arc_0_1_17  out_degree_857  1
    arc_0_1_17  in_degree_919  1
    arc_0_1_17  original_T_including_depot_unload_960  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_437  1
    load_0_1_17  segment_load_conservation_861  1
    load_0_1_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_439  -20
    arc_0_1_18  connected_order_arc_440  -16
    arc_0_1_18  out_degree_857  1
    arc_0_1_18  in_degree_925  1
    arc_0_1_18  original_T_including_depot_unload_960  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_439  1
    load_0_1_18  segment_load_conservation_861  1
    load_0_1_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_441  -20
    arc_0_1_19  connected_order_arc_442  -16
    arc_0_1_19  out_degree_857  1
    arc_0_1_19  in_degree_931  1
    arc_0_1_19  original_T_including_depot_unload_960  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_441  1
    load_0_1_19  segment_load_conservation_861  1
    load_0_1_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_443  -20
    arc_0_1_20  connected_order_arc_444  -16
    arc_0_1_20  out_degree_857  1
    arc_0_1_20  in_degree_937  1
    arc_0_1_20  original_T_including_depot_unload_960  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_443  1
    load_0_1_20  segment_load_conservation_861  1
    load_0_1_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_445  -20
    arc_0_1_21  connected_order_arc_446  -16
    arc_0_1_21  out_degree_857  1
    arc_0_1_21  in_degree_943  1
    arc_0_1_21  original_T_including_depot_unload_960  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_445  1
    load_0_1_21  segment_load_conservation_861  1
    load_0_1_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_447  -20
    arc_0_1_22  connected_order_arc_448  -16
    arc_0_1_22  out_degree_857  1
    arc_0_1_22  in_degree_949  1
    arc_0_1_22  original_T_including_depot_unload_960  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_447  1
    load_0_1_22  segment_load_conservation_861  1
    load_0_1_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_449  -20
    arc_0_2_0  depot_return_or_bypass_856  1
    arc_0_2_0  out_degree_864  1
    arc_0_2_0  original_T_including_depot_unload_960  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_449  1
    load_0_2_0  segment_load_conservation_868  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_450  -20
    arc_0_2_1  connected_order_arc_451  -16
    arc_0_2_1  in_degree_858  1
    arc_0_2_1  out_degree_864  1
    arc_0_2_1  original_T_including_depot_unload_960  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_450  1
    load_0_2_1  segment_load_conservation_861  -1
    load_0_2_1  segment_prefix_lb_862  1
    load_0_2_1  segment_prefix_ub_863  1
    load_0_2_1  segment_load_conservation_868  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_452  -20
    arc_0_2_3  connected_order_arc_453  -16
    arc_0_2_3  out_degree_864  1
    arc_0_2_3  in_degree_872  1
    arc_0_2_3  original_T_including_depot_unload_960  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_452  1
    load_0_2_3  segment_load_conservation_868  1
    load_0_2_3  segment_load_conservation_875  -1
    load_0_2_3  segment_prefix_lb_876  1
    load_0_2_3  segment_prefix_ub_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_454  -20
    arc_0_2_4  connected_order_arc_455  -16
    arc_0_2_4  out_degree_864  1
    arc_0_2_4  in_degree_879  1
    arc_0_2_4  original_T_including_depot_unload_960  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_454  1
    load_0_2_4  segment_load_conservation_868  1
    load_0_2_4  segment_load_conservation_882  -1
    load_0_2_4  segment_prefix_lb_883  1
    load_0_2_4  segment_prefix_ub_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_456  -20
    arc_0_2_5  connected_order_arc_457  -16
    arc_0_2_5  out_degree_864  1
    arc_0_2_5  in_degree_886  1
    arc_0_2_5  original_T_including_depot_unload_960  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_456  1
    load_0_2_5  segment_load_conservation_868  1
    load_0_2_5  segment_load_conservation_889  -1
    load_0_2_5  segment_prefix_lb_890  1
    load_0_2_5  segment_prefix_ub_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_458  -20
    arc_0_2_6  connected_order_arc_459  -16
    arc_0_2_6  out_degree_864  1
    arc_0_2_6  in_degree_893  1
    arc_0_2_6  original_T_including_depot_unload_960  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_458  1
    load_0_2_6  segment_load_conservation_868  1
    load_0_2_6  segment_load_conservation_896  -1
    load_0_2_6  segment_prefix_lb_897  1
    load_0_2_6  segment_prefix_ub_898  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_7  arc_capacity_460  -20
    arc_0_2_7  connected_order_arc_461  -16
    arc_0_2_7  out_degree_864  1
    arc_0_2_7  in_degree_900  1
    arc_0_2_7  original_T_including_depot_unload_960  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_7  arc_capacity_460  1
    load_0_2_7  segment_load_conservation_868  1
    load_0_2_7  segment_load_conservation_903  -1
    load_0_2_7  segment_prefix_lb_904  1
    load_0_2_7  segment_prefix_ub_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_462  -20
    arc_0_2_15  connected_order_arc_463  -16
    arc_0_2_15  out_degree_864  1
    arc_0_2_15  in_degree_907  1
    arc_0_2_15  original_T_including_depot_unload_960  1.3592886119077182e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_462  1
    load_0_2_15  segment_load_conservation_868  1
    load_0_2_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_464  -20
    arc_0_2_16  connected_order_arc_465  -16
    arc_0_2_16  out_degree_864  1
    arc_0_2_16  in_degree_913  1
    arc_0_2_16  original_T_including_depot_unload_960  8.9557394138123709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_464  1
    load_0_2_16  segment_load_conservation_868  1
    load_0_2_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_466  -20
    arc_0_2_17  connected_order_arc_467  -16
    arc_0_2_17  out_degree_864  1
    arc_0_2_17  in_degree_919  1
    arc_0_2_17  original_T_including_depot_unload_960  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_466  1
    load_0_2_17  segment_load_conservation_868  1
    load_0_2_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_468  -20
    arc_0_2_18  connected_order_arc_469  -16
    arc_0_2_18  out_degree_864  1
    arc_0_2_18  in_degree_925  1
    arc_0_2_18  original_T_including_depot_unload_960  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_468  1
    load_0_2_18  segment_load_conservation_868  1
    load_0_2_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_470  -20
    arc_0_2_19  connected_order_arc_471  -16
    arc_0_2_19  out_degree_864  1
    arc_0_2_19  in_degree_931  1
    arc_0_2_19  original_T_including_depot_unload_960  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_470  1
    load_0_2_19  segment_load_conservation_868  1
    load_0_2_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_472  -20
    arc_0_2_20  connected_order_arc_473  -16
    arc_0_2_20  out_degree_864  1
    arc_0_2_20  in_degree_937  1
    arc_0_2_20  original_T_including_depot_unload_960  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_472  1
    load_0_2_20  segment_load_conservation_868  1
    load_0_2_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_474  -20
    arc_0_2_21  connected_order_arc_475  -16
    arc_0_2_21  out_degree_864  1
    arc_0_2_21  in_degree_943  1
    arc_0_2_21  original_T_including_depot_unload_960  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_474  1
    load_0_2_21  segment_load_conservation_868  1
    load_0_2_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_476  -20
    arc_0_2_22  connected_order_arc_477  -16
    arc_0_2_22  out_degree_864  1
    arc_0_2_22  in_degree_949  1
    arc_0_2_22  original_T_including_depot_unload_960  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_476  1
    load_0_2_22  segment_load_conservation_868  1
    load_0_2_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_478  -20
    arc_0_3_0  depot_return_or_bypass_856  1
    arc_0_3_0  out_degree_871  1
    arc_0_3_0  original_T_including_depot_unload_960  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_478  1
    load_0_3_0  segment_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_479  -20
    arc_0_3_1  connected_order_arc_480  -16
    arc_0_3_1  in_degree_858  1
    arc_0_3_1  out_degree_871  1
    arc_0_3_1  original_T_including_depot_unload_960  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_479  1
    load_0_3_1  segment_load_conservation_861  -1
    load_0_3_1  segment_prefix_lb_862  1
    load_0_3_1  segment_prefix_ub_863  1
    load_0_3_1  segment_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_481  -20
    arc_0_3_2  connected_order_arc_482  -16
    arc_0_3_2  in_degree_865  1
    arc_0_3_2  out_degree_871  1
    arc_0_3_2  original_T_including_depot_unload_960  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_481  1
    load_0_3_2  segment_load_conservation_868  -1
    load_0_3_2  segment_prefix_lb_869  1
    load_0_3_2  segment_prefix_ub_870  1
    load_0_3_2  segment_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_483  -20
    arc_0_3_4  connected_order_arc_484  -16
    arc_0_3_4  out_degree_871  1
    arc_0_3_4  in_degree_879  1
    arc_0_3_4  original_T_including_depot_unload_960  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_483  1
    load_0_3_4  segment_load_conservation_875  1
    load_0_3_4  segment_load_conservation_882  -1
    load_0_3_4  segment_prefix_lb_883  1
    load_0_3_4  segment_prefix_ub_884  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_485  -20
    arc_0_3_5  connected_order_arc_486  -16
    arc_0_3_5  out_degree_871  1
    arc_0_3_5  in_degree_886  1
    arc_0_3_5  original_T_including_depot_unload_960  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_485  1
    load_0_3_5  segment_load_conservation_875  1
    load_0_3_5  segment_load_conservation_889  -1
    load_0_3_5  segment_prefix_lb_890  1
    load_0_3_5  segment_prefix_ub_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_487  -20
    arc_0_3_6  connected_order_arc_488  -16
    arc_0_3_6  out_degree_871  1
    arc_0_3_6  in_degree_893  1
    arc_0_3_6  original_T_including_depot_unload_960  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_487  1
    load_0_3_6  segment_load_conservation_875  1
    load_0_3_6  segment_load_conservation_896  -1
    load_0_3_6  segment_prefix_lb_897  1
    load_0_3_6  segment_prefix_ub_898  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_7  arc_capacity_489  -20
    arc_0_3_7  connected_order_arc_490  -16
    arc_0_3_7  out_degree_871  1
    arc_0_3_7  in_degree_900  1
    arc_0_3_7  original_T_including_depot_unload_960  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_7  arc_capacity_489  1
    load_0_3_7  segment_load_conservation_875  1
    load_0_3_7  segment_load_conservation_903  -1
    load_0_3_7  segment_prefix_lb_904  1
    load_0_3_7  segment_prefix_ub_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_491  -20
    arc_0_3_15  connected_order_arc_492  -16
    arc_0_3_15  out_degree_871  1
    arc_0_3_15  in_degree_907  1
    arc_0_3_15  original_T_including_depot_unload_960  1.2069917207281110e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_491  1
    load_0_3_15  segment_load_conservation_875  1
    load_0_3_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_493  -20
    arc_0_3_16  connected_order_arc_494  -16
    arc_0_3_16  out_degree_871  1
    arc_0_3_16  in_degree_913  1
    arc_0_3_16  original_T_including_depot_unload_960  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_493  1
    load_0_3_16  segment_load_conservation_875  1
    load_0_3_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_495  -20
    arc_0_3_17  connected_order_arc_496  -16
    arc_0_3_17  out_degree_871  1
    arc_0_3_17  in_degree_919  1
    arc_0_3_17  original_T_including_depot_unload_960  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_495  1
    load_0_3_17  segment_load_conservation_875  1
    load_0_3_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_497  -20
    arc_0_3_18  connected_order_arc_498  -16
    arc_0_3_18  out_degree_871  1
    arc_0_3_18  in_degree_925  1
    arc_0_3_18  original_T_including_depot_unload_960  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_497  1
    load_0_3_18  segment_load_conservation_875  1
    load_0_3_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_499  -20
    arc_0_3_19  connected_order_arc_500  -16
    arc_0_3_19  out_degree_871  1
    arc_0_3_19  in_degree_931  1
    arc_0_3_19  original_T_including_depot_unload_960  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_499  1
    load_0_3_19  segment_load_conservation_875  1
    load_0_3_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_501  -20
    arc_0_3_20  connected_order_arc_502  -16
    arc_0_3_20  out_degree_871  1
    arc_0_3_20  in_degree_937  1
    arc_0_3_20  original_T_including_depot_unload_960  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_501  1
    load_0_3_20  segment_load_conservation_875  1
    load_0_3_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_503  -20
    arc_0_3_21  connected_order_arc_504  -16
    arc_0_3_21  out_degree_871  1
    arc_0_3_21  in_degree_943  1
    arc_0_3_21  original_T_including_depot_unload_960  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_503  1
    load_0_3_21  segment_load_conservation_875  1
    load_0_3_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_505  -20
    arc_0_3_22  connected_order_arc_506  -16
    arc_0_3_22  out_degree_871  1
    arc_0_3_22  in_degree_949  1
    arc_0_3_22  original_T_including_depot_unload_960  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_505  1
    load_0_3_22  segment_load_conservation_875  1
    load_0_3_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_507  -20
    arc_0_4_0  depot_return_or_bypass_856  1
    arc_0_4_0  out_degree_878  1
    arc_0_4_0  original_T_including_depot_unload_960  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_507  1
    load_0_4_0  segment_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_508  -20
    arc_0_4_1  connected_order_arc_509  -16
    arc_0_4_1  in_degree_858  1
    arc_0_4_1  out_degree_878  1
    arc_0_4_1  original_T_including_depot_unload_960  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_508  1
    load_0_4_1  segment_load_conservation_861  -1
    load_0_4_1  segment_prefix_lb_862  1
    load_0_4_1  segment_prefix_ub_863  1
    load_0_4_1  segment_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_510  -20
    arc_0_4_2  connected_order_arc_511  -16
    arc_0_4_2  in_degree_865  1
    arc_0_4_2  out_degree_878  1
    arc_0_4_2  original_T_including_depot_unload_960  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_510  1
    load_0_4_2  segment_load_conservation_868  -1
    load_0_4_2  segment_prefix_lb_869  1
    load_0_4_2  segment_prefix_ub_870  1
    load_0_4_2  segment_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_512  -20
    arc_0_4_3  connected_order_arc_513  -16
    arc_0_4_3  in_degree_872  1
    arc_0_4_3  out_degree_878  1
    arc_0_4_3  original_T_including_depot_unload_960  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_512  1
    load_0_4_3  segment_load_conservation_875  -1
    load_0_4_3  segment_prefix_lb_876  1
    load_0_4_3  segment_prefix_ub_877  1
    load_0_4_3  segment_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_514  -20
    arc_0_4_5  connected_order_arc_515  -16
    arc_0_4_5  out_degree_878  1
    arc_0_4_5  in_degree_886  1
    arc_0_4_5  original_T_including_depot_unload_960  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_514  1
    load_0_4_5  segment_load_conservation_882  1
    load_0_4_5  segment_load_conservation_889  -1
    load_0_4_5  segment_prefix_lb_890  1
    load_0_4_5  segment_prefix_ub_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_516  -20
    arc_0_4_6  connected_order_arc_517  -16
    arc_0_4_6  out_degree_878  1
    arc_0_4_6  in_degree_893  1
    arc_0_4_6  original_T_including_depot_unload_960  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_516  1
    load_0_4_6  segment_load_conservation_882  1
    load_0_4_6  segment_load_conservation_896  -1
    load_0_4_6  segment_prefix_lb_897  1
    load_0_4_6  segment_prefix_ub_898  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_7  arc_capacity_518  -20
    arc_0_4_7  connected_order_arc_519  -16
    arc_0_4_7  out_degree_878  1
    arc_0_4_7  in_degree_900  1
    arc_0_4_7  original_T_including_depot_unload_960  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_7  arc_capacity_518  1
    load_0_4_7  segment_load_conservation_882  1
    load_0_4_7  segment_load_conservation_903  -1
    load_0_4_7  segment_prefix_lb_904  1
    load_0_4_7  segment_prefix_ub_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_520  -20
    arc_0_4_15  connected_order_arc_521  -16
    arc_0_4_15  out_degree_878  1
    arc_0_4_15  in_degree_907  1
    arc_0_4_15  original_T_including_depot_unload_960  1.0954321746198136e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_520  1
    load_0_4_15  segment_load_conservation_882  1
    load_0_4_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_522  -20
    arc_0_4_16  connected_order_arc_523  -16
    arc_0_4_16  out_degree_878  1
    arc_0_4_16  in_degree_913  1
    arc_0_4_16  original_T_including_depot_unload_960  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_522  1
    load_0_4_16  segment_load_conservation_882  1
    load_0_4_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_524  -20
    arc_0_4_17  connected_order_arc_525  -16
    arc_0_4_17  out_degree_878  1
    arc_0_4_17  in_degree_919  1
    arc_0_4_17  original_T_including_depot_unload_960  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_524  1
    load_0_4_17  segment_load_conservation_882  1
    load_0_4_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_526  -20
    arc_0_4_18  connected_order_arc_527  -16
    arc_0_4_18  out_degree_878  1
    arc_0_4_18  in_degree_925  1
    arc_0_4_18  original_T_including_depot_unload_960  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_526  1
    load_0_4_18  segment_load_conservation_882  1
    load_0_4_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_528  -20
    arc_0_4_19  connected_order_arc_529  -16
    arc_0_4_19  out_degree_878  1
    arc_0_4_19  in_degree_931  1
    arc_0_4_19  original_T_including_depot_unload_960  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_528  1
    load_0_4_19  segment_load_conservation_882  1
    load_0_4_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_530  -20
    arc_0_4_20  connected_order_arc_531  -16
    arc_0_4_20  out_degree_878  1
    arc_0_4_20  in_degree_937  1
    arc_0_4_20  original_T_including_depot_unload_960  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_530  1
    load_0_4_20  segment_load_conservation_882  1
    load_0_4_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_532  -20
    arc_0_4_21  connected_order_arc_533  -16
    arc_0_4_21  out_degree_878  1
    arc_0_4_21  in_degree_943  1
    arc_0_4_21  original_T_including_depot_unload_960  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_532  1
    load_0_4_21  segment_load_conservation_882  1
    load_0_4_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_534  -20
    arc_0_4_22  connected_order_arc_535  -16
    arc_0_4_22  out_degree_878  1
    arc_0_4_22  in_degree_949  1
    arc_0_4_22  original_T_including_depot_unload_960  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_534  1
    load_0_4_22  segment_load_conservation_882  1
    load_0_4_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_536  -20
    arc_0_5_0  depot_return_or_bypass_856  1
    arc_0_5_0  out_degree_885  1
    arc_0_5_0  original_T_including_depot_unload_960  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_536  1
    load_0_5_0  segment_load_conservation_889  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_537  -20
    arc_0_5_1  connected_order_arc_538  -16
    arc_0_5_1  in_degree_858  1
    arc_0_5_1  out_degree_885  1
    arc_0_5_1  original_T_including_depot_unload_960  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_537  1
    load_0_5_1  segment_load_conservation_861  -1
    load_0_5_1  segment_prefix_lb_862  1
    load_0_5_1  segment_prefix_ub_863  1
    load_0_5_1  segment_load_conservation_889  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_539  -20
    arc_0_5_2  connected_order_arc_540  -16
    arc_0_5_2  in_degree_865  1
    arc_0_5_2  out_degree_885  1
    arc_0_5_2  original_T_including_depot_unload_960  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_539  1
    load_0_5_2  segment_load_conservation_868  -1
    load_0_5_2  segment_prefix_lb_869  1
    load_0_5_2  segment_prefix_ub_870  1
    load_0_5_2  segment_load_conservation_889  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_541  -20
    arc_0_5_3  connected_order_arc_542  -16
    arc_0_5_3  in_degree_872  1
    arc_0_5_3  out_degree_885  1
    arc_0_5_3  original_T_including_depot_unload_960  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_541  1
    load_0_5_3  segment_load_conservation_875  -1
    load_0_5_3  segment_prefix_lb_876  1
    load_0_5_3  segment_prefix_ub_877  1
    load_0_5_3  segment_load_conservation_889  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_543  -20
    arc_0_5_4  connected_order_arc_544  -16
    arc_0_5_4  in_degree_879  1
    arc_0_5_4  out_degree_885  1
    arc_0_5_4  original_T_including_depot_unload_960  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_543  1
    load_0_5_4  segment_load_conservation_882  -1
    load_0_5_4  segment_prefix_lb_883  1
    load_0_5_4  segment_prefix_ub_884  1
    load_0_5_4  segment_load_conservation_889  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_545  -20
    arc_0_5_6  connected_order_arc_546  -16
    arc_0_5_6  out_degree_885  1
    arc_0_5_6  in_degree_893  1
    arc_0_5_6  original_T_including_depot_unload_960  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_545  1
    load_0_5_6  segment_load_conservation_889  1
    load_0_5_6  segment_load_conservation_896  -1
    load_0_5_6  segment_prefix_lb_897  1
    load_0_5_6  segment_prefix_ub_898  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_7  arc_capacity_547  -20
    arc_0_5_7  connected_order_arc_548  -16
    arc_0_5_7  out_degree_885  1
    arc_0_5_7  in_degree_900  1
    arc_0_5_7  original_T_including_depot_unload_960  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_7  arc_capacity_547  1
    load_0_5_7  segment_load_conservation_889  1
    load_0_5_7  segment_load_conservation_903  -1
    load_0_5_7  segment_prefix_lb_904  1
    load_0_5_7  segment_prefix_ub_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_549  -20
    arc_0_5_15  connected_order_arc_550  -16
    arc_0_5_15  out_degree_885  1
    arc_0_5_15  in_degree_907  1
    arc_0_5_15  original_T_including_depot_unload_960  1.1103125019345705e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_549  1
    load_0_5_15  segment_load_conservation_889  1
    load_0_5_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_551  -20
    arc_0_5_16  connected_order_arc_552  -16
    arc_0_5_16  out_degree_885  1
    arc_0_5_16  in_degree_913  1
    arc_0_5_16  original_T_including_depot_unload_960  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_551  1
    load_0_5_16  segment_load_conservation_889  1
    load_0_5_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_553  -20
    arc_0_5_17  connected_order_arc_554  -16
    arc_0_5_17  out_degree_885  1
    arc_0_5_17  in_degree_919  1
    arc_0_5_17  original_T_including_depot_unload_960  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_553  1
    load_0_5_17  segment_load_conservation_889  1
    load_0_5_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_555  -20
    arc_0_5_18  connected_order_arc_556  -16
    arc_0_5_18  out_degree_885  1
    arc_0_5_18  in_degree_925  1
    arc_0_5_18  original_T_including_depot_unload_960  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_555  1
    load_0_5_18  segment_load_conservation_889  1
    load_0_5_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_557  -20
    arc_0_5_19  connected_order_arc_558  -16
    arc_0_5_19  out_degree_885  1
    arc_0_5_19  in_degree_931  1
    arc_0_5_19  original_T_including_depot_unload_960  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_557  1
    load_0_5_19  segment_load_conservation_889  1
    load_0_5_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_559  -20
    arc_0_5_20  connected_order_arc_560  -16
    arc_0_5_20  out_degree_885  1
    arc_0_5_20  in_degree_937  1
    arc_0_5_20  original_T_including_depot_unload_960  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_559  1
    load_0_5_20  segment_load_conservation_889  1
    load_0_5_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_561  -20
    arc_0_5_21  connected_order_arc_562  -16
    arc_0_5_21  out_degree_885  1
    arc_0_5_21  in_degree_943  1
    arc_0_5_21  original_T_including_depot_unload_960  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_561  1
    load_0_5_21  segment_load_conservation_889  1
    load_0_5_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_563  -20
    arc_0_5_22  connected_order_arc_564  -16
    arc_0_5_22  out_degree_885  1
    arc_0_5_22  in_degree_949  1
    arc_0_5_22  original_T_including_depot_unload_960  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_563  1
    load_0_5_22  segment_load_conservation_889  1
    load_0_5_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_565  -20
    arc_0_6_0  depot_return_or_bypass_856  1
    arc_0_6_0  out_degree_892  1
    arc_0_6_0  original_T_including_depot_unload_960  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_565  1
    load_0_6_0  segment_load_conservation_896  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_566  -20
    arc_0_6_1  connected_order_arc_567  -16
    arc_0_6_1  in_degree_858  1
    arc_0_6_1  out_degree_892  1
    arc_0_6_1  original_T_including_depot_unload_960  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_566  1
    load_0_6_1  segment_load_conservation_861  -1
    load_0_6_1  segment_prefix_lb_862  1
    load_0_6_1  segment_prefix_ub_863  1
    load_0_6_1  segment_load_conservation_896  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_568  -20
    arc_0_6_2  connected_order_arc_569  -16
    arc_0_6_2  in_degree_865  1
    arc_0_6_2  out_degree_892  1
    arc_0_6_2  original_T_including_depot_unload_960  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_568  1
    load_0_6_2  segment_load_conservation_868  -1
    load_0_6_2  segment_prefix_lb_869  1
    load_0_6_2  segment_prefix_ub_870  1
    load_0_6_2  segment_load_conservation_896  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_570  -20
    arc_0_6_3  connected_order_arc_571  -16
    arc_0_6_3  in_degree_872  1
    arc_0_6_3  out_degree_892  1
    arc_0_6_3  original_T_including_depot_unload_960  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_570  1
    load_0_6_3  segment_load_conservation_875  -1
    load_0_6_3  segment_prefix_lb_876  1
    load_0_6_3  segment_prefix_ub_877  1
    load_0_6_3  segment_load_conservation_896  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_572  -20
    arc_0_6_4  connected_order_arc_573  -16
    arc_0_6_4  in_degree_879  1
    arc_0_6_4  out_degree_892  1
    arc_0_6_4  original_T_including_depot_unload_960  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_572  1
    load_0_6_4  segment_load_conservation_882  -1
    load_0_6_4  segment_prefix_lb_883  1
    load_0_6_4  segment_prefix_ub_884  1
    load_0_6_4  segment_load_conservation_896  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_574  -20
    arc_0_6_5  connected_order_arc_575  -16
    arc_0_6_5  in_degree_886  1
    arc_0_6_5  out_degree_892  1
    arc_0_6_5  original_T_including_depot_unload_960  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_574  1
    load_0_6_5  segment_load_conservation_889  -1
    load_0_6_5  segment_prefix_lb_890  1
    load_0_6_5  segment_prefix_ub_891  1
    load_0_6_5  segment_load_conservation_896  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_7  arc_capacity_576  -20
    arc_0_6_7  connected_order_arc_577  -16
    arc_0_6_7  out_degree_892  1
    arc_0_6_7  in_degree_900  1
    arc_0_6_7  original_T_including_depot_unload_960  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_7  arc_capacity_576  1
    load_0_6_7  segment_load_conservation_896  1
    load_0_6_7  segment_load_conservation_903  -1
    load_0_6_7  segment_prefix_lb_904  1
    load_0_6_7  segment_prefix_ub_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_578  -20
    arc_0_6_15  connected_order_arc_579  -16
    arc_0_6_15  out_degree_892  1
    arc_0_6_15  in_degree_907  1
    arc_0_6_15  original_T_including_depot_unload_960  1.3583767670521690e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_578  1
    load_0_6_15  segment_load_conservation_896  1
    load_0_6_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_580  -20
    arc_0_6_16  connected_order_arc_581  -16
    arc_0_6_16  out_degree_892  1
    arc_0_6_16  in_degree_913  1
    arc_0_6_16  original_T_including_depot_unload_960  9.0007741891713113e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_580  1
    load_0_6_16  segment_load_conservation_896  1
    load_0_6_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_582  -20
    arc_0_6_17  connected_order_arc_583  -16
    arc_0_6_17  out_degree_892  1
    arc_0_6_17  in_degree_919  1
    arc_0_6_17  original_T_including_depot_unload_960  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_582  1
    load_0_6_17  segment_load_conservation_896  1
    load_0_6_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_584  -20
    arc_0_6_18  connected_order_arc_585  -16
    arc_0_6_18  out_degree_892  1
    arc_0_6_18  in_degree_925  1
    arc_0_6_18  original_T_including_depot_unload_960  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_584  1
    load_0_6_18  segment_load_conservation_896  1
    load_0_6_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_586  -20
    arc_0_6_19  connected_order_arc_587  -16
    arc_0_6_19  out_degree_892  1
    arc_0_6_19  in_degree_931  1
    arc_0_6_19  original_T_including_depot_unload_960  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_586  1
    load_0_6_19  segment_load_conservation_896  1
    load_0_6_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_588  -20
    arc_0_6_20  connected_order_arc_589  -16
    arc_0_6_20  out_degree_892  1
    arc_0_6_20  in_degree_937  1
    arc_0_6_20  original_T_including_depot_unload_960  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_588  1
    load_0_6_20  segment_load_conservation_896  1
    load_0_6_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_590  -20
    arc_0_6_21  connected_order_arc_591  -16
    arc_0_6_21  out_degree_892  1
    arc_0_6_21  in_degree_943  1
    arc_0_6_21  original_T_including_depot_unload_960  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_590  1
    load_0_6_21  segment_load_conservation_896  1
    load_0_6_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_22  arc_capacity_592  -20
    arc_0_6_22  connected_order_arc_593  -16
    arc_0_6_22  out_degree_892  1
    arc_0_6_22  in_degree_949  1
    arc_0_6_22  original_T_including_depot_unload_960  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_22  arc_capacity_592  1
    load_0_6_22  segment_load_conservation_896  1
    load_0_6_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_0  arc_capacity_594  -20
    arc_0_7_0  depot_return_or_bypass_856  1
    arc_0_7_0  out_degree_899  1
    arc_0_7_0  original_T_including_depot_unload_960  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_0  arc_capacity_594  1
    load_0_7_0  segment_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_1  arc_capacity_595  -20
    arc_0_7_1  connected_order_arc_596  -16
    arc_0_7_1  in_degree_858  1
    arc_0_7_1  out_degree_899  1
    arc_0_7_1  original_T_including_depot_unload_960  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_1  arc_capacity_595  1
    load_0_7_1  segment_load_conservation_861  -1
    load_0_7_1  segment_prefix_lb_862  1
    load_0_7_1  segment_prefix_ub_863  1
    load_0_7_1  segment_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_2  arc_capacity_597  -20
    arc_0_7_2  connected_order_arc_598  -16
    arc_0_7_2  in_degree_865  1
    arc_0_7_2  out_degree_899  1
    arc_0_7_2  original_T_including_depot_unload_960  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_2  arc_capacity_597  1
    load_0_7_2  segment_load_conservation_868  -1
    load_0_7_2  segment_prefix_lb_869  1
    load_0_7_2  segment_prefix_ub_870  1
    load_0_7_2  segment_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_3  arc_capacity_599  -20
    arc_0_7_3  connected_order_arc_600  -16
    arc_0_7_3  in_degree_872  1
    arc_0_7_3  out_degree_899  1
    arc_0_7_3  original_T_including_depot_unload_960  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_3  arc_capacity_599  1
    load_0_7_3  segment_load_conservation_875  -1
    load_0_7_3  segment_prefix_lb_876  1
    load_0_7_3  segment_prefix_ub_877  1
    load_0_7_3  segment_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_4  arc_capacity_601  -20
    arc_0_7_4  connected_order_arc_602  -16
    arc_0_7_4  in_degree_879  1
    arc_0_7_4  out_degree_899  1
    arc_0_7_4  original_T_including_depot_unload_960  1035.83277530205
    MARKER    'MARKER'                 'INTEND'
    load_0_7_4  arc_capacity_601  1
    load_0_7_4  segment_load_conservation_882  -1
    load_0_7_4  segment_prefix_lb_883  1
    load_0_7_4  segment_prefix_ub_884  1
    load_0_7_4  segment_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_5  arc_capacity_603  -20
    arc_0_7_5  connected_order_arc_604  -16
    arc_0_7_5  in_degree_886  1
    arc_0_7_5  out_degree_899  1
    arc_0_7_5  original_T_including_depot_unload_960  1.1516424799836650e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_5  arc_capacity_603  1
    load_0_7_5  segment_load_conservation_889  -1
    load_0_7_5  segment_prefix_lb_890  1
    load_0_7_5  segment_prefix_ub_891  1
    load_0_7_5  segment_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_6  arc_capacity_605  -20
    arc_0_7_6  connected_order_arc_606  -16
    arc_0_7_6  in_degree_893  1
    arc_0_7_6  out_degree_899  1
    arc_0_7_6  original_T_including_depot_unload_960  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_6  arc_capacity_605  1
    load_0_7_6  segment_load_conservation_896  -1
    load_0_7_6  segment_prefix_lb_897  1
    load_0_7_6  segment_prefix_ub_898  1
    load_0_7_6  segment_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_15  arc_capacity_607  -20
    arc_0_7_15  connected_order_arc_608  -16
    arc_0_7_15  out_degree_899  1
    arc_0_7_15  in_degree_907  1
    arc_0_7_15  original_T_including_depot_unload_960  2.1278710890079865e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_15  arc_capacity_607  1
    load_0_7_15  segment_load_conservation_903  1
    load_0_7_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_16  arc_capacity_609  -20
    arc_0_7_16  connected_order_arc_610  -16
    arc_0_7_16  out_degree_899  1
    arc_0_7_16  in_degree_913  1
    arc_0_7_16  original_T_including_depot_unload_960  1.6719633410042259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_16  arc_capacity_609  1
    load_0_7_16  segment_load_conservation_903  1
    load_0_7_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_17  arc_capacity_611  -20
    arc_0_7_17  connected_order_arc_612  -16
    arc_0_7_17  out_degree_899  1
    arc_0_7_17  in_degree_919  1
    arc_0_7_17  original_T_including_depot_unload_960  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_17  arc_capacity_611  1
    load_0_7_17  segment_load_conservation_903  1
    load_0_7_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_18  arc_capacity_613  -20
    arc_0_7_18  connected_order_arc_614  -16
    arc_0_7_18  out_degree_899  1
    arc_0_7_18  in_degree_925  1
    arc_0_7_18  original_T_including_depot_unload_960  1.3663551195332984e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_18  arc_capacity_613  1
    load_0_7_18  segment_load_conservation_903  1
    load_0_7_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_19  arc_capacity_615  -20
    arc_0_7_19  connected_order_arc_616  -16
    arc_0_7_19  out_degree_899  1
    arc_0_7_19  in_degree_931  1
    arc_0_7_19  original_T_including_depot_unload_960  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_19  arc_capacity_615  1
    load_0_7_19  segment_load_conservation_903  1
    load_0_7_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_20  arc_capacity_617  -20
    arc_0_7_20  connected_order_arc_618  -16
    arc_0_7_20  out_degree_899  1
    arc_0_7_20  in_degree_937  1
    arc_0_7_20  original_T_including_depot_unload_960  1.2450286067313011e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_20  arc_capacity_617  1
    load_0_7_20  segment_load_conservation_903  1
    load_0_7_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_21  arc_capacity_619  -20
    arc_0_7_21  connected_order_arc_620  -16
    arc_0_7_21  out_degree_899  1
    arc_0_7_21  in_degree_943  1
    arc_0_7_21  original_T_including_depot_unload_960  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_21  arc_capacity_619  1
    load_0_7_21  segment_load_conservation_903  1
    load_0_7_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_22  arc_capacity_621  -20
    arc_0_7_22  connected_order_arc_622  -16
    arc_0_7_22  out_degree_899  1
    arc_0_7_22  in_degree_949  1
    arc_0_7_22  original_T_including_depot_unload_960  1.1301442107738828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_22  arc_capacity_621  1
    load_0_7_22  segment_load_conservation_903  1
    load_0_7_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_623  -20
    arc_0_15_0  depot_return_or_bypass_856  1
    arc_0_15_0  out_degree_906  1
    arc_0_15_0  original_T_including_depot_unload_960  1.9654373797357937e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_623  1
    load_0_15_0  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_624  -20
    arc_0_15_1  connected_order_arc_625  -16
    arc_0_15_1  in_degree_858  1
    arc_0_15_1  out_degree_906  1
    arc_0_15_1  original_T_including_depot_unload_960  1.3598923863120219e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_624  1
    load_0_15_1  segment_load_conservation_861  -1
    load_0_15_1  segment_prefix_lb_862  1
    load_0_15_1  segment_prefix_ub_863  1
    load_0_15_1  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_626  -20
    arc_0_15_2  connected_order_arc_627  -16
    arc_0_15_2  in_degree_865  1
    arc_0_15_2  out_degree_906  1
    arc_0_15_2  original_T_including_depot_unload_960  1.3592886119077182e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_626  1
    load_0_15_2  segment_load_conservation_868  -1
    load_0_15_2  segment_prefix_lb_869  1
    load_0_15_2  segment_prefix_ub_870  1
    load_0_15_2  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_628  -20
    arc_0_15_3  connected_order_arc_629  -16
    arc_0_15_3  in_degree_872  1
    arc_0_15_3  out_degree_906  1
    arc_0_15_3  original_T_including_depot_unload_960  1.2069917207281110e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_628  1
    load_0_15_3  segment_load_conservation_875  -1
    load_0_15_3  segment_prefix_lb_876  1
    load_0_15_3  segment_prefix_ub_877  1
    load_0_15_3  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_630  -20
    arc_0_15_4  connected_order_arc_631  -16
    arc_0_15_4  in_degree_879  1
    arc_0_15_4  out_degree_906  1
    arc_0_15_4  original_T_including_depot_unload_960  1.0954321746198136e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_630  1
    load_0_15_4  segment_load_conservation_882  -1
    load_0_15_4  segment_prefix_lb_883  1
    load_0_15_4  segment_prefix_ub_884  1
    load_0_15_4  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_632  -20
    arc_0_15_5  connected_order_arc_633  -16
    arc_0_15_5  in_degree_886  1
    arc_0_15_5  out_degree_906  1
    arc_0_15_5  original_T_including_depot_unload_960  1.1103125019345705e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_632  1
    load_0_15_5  segment_load_conservation_889  -1
    load_0_15_5  segment_prefix_lb_890  1
    load_0_15_5  segment_prefix_ub_891  1
    load_0_15_5  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_634  -20
    arc_0_15_6  connected_order_arc_635  -16
    arc_0_15_6  in_degree_893  1
    arc_0_15_6  out_degree_906  1
    arc_0_15_6  original_T_including_depot_unload_960  1.3583767670521690e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_634  1
    load_0_15_6  segment_load_conservation_896  -1
    load_0_15_6  segment_prefix_lb_897  1
    load_0_15_6  segment_prefix_ub_898  1
    load_0_15_6  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_7  arc_capacity_636  -20
    arc_0_15_7  connected_order_arc_637  -16
    arc_0_15_7  in_degree_900  1
    arc_0_15_7  out_degree_906  1
    arc_0_15_7  original_T_including_depot_unload_960  1.4878271801513547e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_7  arc_capacity_636  1
    load_0_15_7  segment_load_conservation_903  -1
    load_0_15_7  segment_prefix_lb_904  1
    load_0_15_7  segment_prefix_ub_905  1
    load_0_15_7  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_638  -20
    arc_0_15_16  connected_order_arc_639  -16
    arc_0_15_16  out_degree_906  1
    arc_0_15_16  in_degree_913  1
    arc_0_15_16  original_T_including_depot_unload_960  4.9108306779271851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_638  1
    load_0_15_16  free_load_conservation_911  1
    load_0_15_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_640  -20
    arc_0_15_17  connected_order_arc_641  -16
    arc_0_15_17  out_degree_906  1
    arc_0_15_17  in_degree_919  1
    arc_0_15_17  original_T_including_depot_unload_960  3.4294674949374580e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_640  1
    load_0_15_17  free_load_conservation_911  1
    load_0_15_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_642  -20
    arc_0_15_18  connected_order_arc_643  -16
    arc_0_15_18  out_degree_906  1
    arc_0_15_18  in_degree_925  1
    arc_0_15_18  original_T_including_depot_unload_960  8.0990517952185235e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_642  1
    load_0_15_18  free_load_conservation_911  1
    load_0_15_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_644  -20
    arc_0_15_19  connected_order_arc_645  -16
    arc_0_15_19  out_degree_906  1
    arc_0_15_19  in_degree_931  1
    arc_0_15_19  original_T_including_depot_unload_960  2.3897696160028909e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_644  1
    load_0_15_19  free_load_conservation_911  1
    load_0_15_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_646  -20
    arc_0_15_20  connected_order_arc_647  -16
    arc_0_15_20  out_degree_906  1
    arc_0_15_20  in_degree_937  1
    arc_0_15_20  original_T_including_depot_unload_960  8.8284459023081490e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_646  1
    load_0_15_20  free_load_conservation_911  1
    load_0_15_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_648  -20
    arc_0_15_21  connected_order_arc_649  -16
    arc_0_15_21  out_degree_906  1
    arc_0_15_21  in_degree_943  1
    arc_0_15_21  original_T_including_depot_unload_960  2.8013754919345556e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_648  1
    load_0_15_21  free_load_conservation_911  1
    load_0_15_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_650  -20
    arc_0_15_22  connected_order_arc_651  -16
    arc_0_15_22  out_degree_906  1
    arc_0_15_22  in_degree_949  1
    arc_0_15_22  original_T_including_depot_unload_960  1.0617037707898505e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_650  1
    load_0_15_22  free_load_conservation_911  1
    load_0_15_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_652  -20
    arc_0_16_0  depot_return_or_bypass_856  1
    arc_0_16_0  out_degree_912  1
    arc_0_16_0  original_T_including_depot_unload_960  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_652  1
    load_0_16_0  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_653  -20
    arc_0_16_1  connected_order_arc_654  -16
    arc_0_16_1  in_degree_858  1
    arc_0_16_1  out_degree_912  1
    arc_0_16_1  original_T_including_depot_unload_960  8.9619134786808888e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_653  1
    load_0_16_1  segment_load_conservation_861  -1
    load_0_16_1  segment_prefix_lb_862  1
    load_0_16_1  segment_prefix_ub_863  1
    load_0_16_1  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_655  -20
    arc_0_16_2  connected_order_arc_656  -16
    arc_0_16_2  in_degree_865  1
    arc_0_16_2  out_degree_912  1
    arc_0_16_2  original_T_including_depot_unload_960  8.9557394138123709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_655  1
    load_0_16_2  segment_load_conservation_868  -1
    load_0_16_2  segment_prefix_lb_869  1
    load_0_16_2  segment_prefix_ub_870  1
    load_0_16_2  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_657  -20
    arc_0_16_3  connected_order_arc_658  -16
    arc_0_16_3  in_degree_872  1
    arc_0_16_3  out_degree_912  1
    arc_0_16_3  original_T_including_depot_unload_960  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_657  1
    load_0_16_3  segment_load_conservation_875  -1
    load_0_16_3  segment_prefix_lb_876  1
    load_0_16_3  segment_prefix_ub_877  1
    load_0_16_3  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_659  -20
    arc_0_16_4  connected_order_arc_660  -16
    arc_0_16_4  in_degree_879  1
    arc_0_16_4  out_degree_912  1
    arc_0_16_4  original_T_including_depot_unload_960  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_659  1
    load_0_16_4  segment_load_conservation_882  -1
    load_0_16_4  segment_prefix_lb_883  1
    load_0_16_4  segment_prefix_ub_884  1
    load_0_16_4  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_661  -20
    arc_0_16_5  connected_order_arc_662  -16
    arc_0_16_5  in_degree_886  1
    arc_0_16_5  out_degree_912  1
    arc_0_16_5  original_T_including_depot_unload_960  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_661  1
    load_0_16_5  segment_load_conservation_889  -1
    load_0_16_5  segment_prefix_lb_890  1
    load_0_16_5  segment_prefix_ub_891  1
    load_0_16_5  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_663  -20
    arc_0_16_6  connected_order_arc_664  -16
    arc_0_16_6  in_degree_893  1
    arc_0_16_6  out_degree_912  1
    arc_0_16_6  original_T_including_depot_unload_960  9.0007741891713113e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_663  1
    load_0_16_6  segment_load_conservation_896  -1
    load_0_16_6  segment_prefix_lb_897  1
    load_0_16_6  segment_prefix_ub_898  1
    load_0_16_6  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_7  arc_capacity_665  -20
    arc_0_16_7  connected_order_arc_666  -16
    arc_0_16_7  in_degree_900  1
    arc_0_16_7  out_degree_912  1
    arc_0_16_7  original_T_including_depot_unload_960  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_7  arc_capacity_665  1
    load_0_16_7  segment_load_conservation_903  -1
    load_0_16_7  segment_prefix_lb_904  1
    load_0_16_7  segment_prefix_ub_905  1
    load_0_16_7  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_667  -20
    arc_0_16_15  connected_order_arc_668  -16
    arc_0_16_15  in_degree_907  1
    arc_0_16_15  out_degree_912  1
    arc_0_16_15  original_T_including_depot_unload_960  4.9108306779271851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_667  1
    load_0_16_15  free_load_conservation_911  -1
    load_0_16_15  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_669  -20
    arc_0_16_17  connected_order_arc_670  -16
    arc_0_16_17  out_degree_912  1
    arc_0_16_17  in_degree_919  1
    arc_0_16_17  original_T_including_depot_unload_960  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_669  1
    load_0_16_17  free_load_conservation_917  1
    load_0_16_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_671  -20
    arc_0_16_18  connected_order_arc_672  -16
    arc_0_16_18  out_degree_912  1
    arc_0_16_18  in_degree_925  1
    arc_0_16_18  original_T_including_depot_unload_960  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_671  1
    load_0_16_18  free_load_conservation_917  1
    load_0_16_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_673  -20
    arc_0_16_19  connected_order_arc_674  -16
    arc_0_16_19  out_degree_912  1
    arc_0_16_19  in_degree_931  1
    arc_0_16_19  original_T_including_depot_unload_960  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_673  1
    load_0_16_19  free_load_conservation_917  1
    load_0_16_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_675  -20
    arc_0_16_20  connected_order_arc_676  -16
    arc_0_16_20  out_degree_912  1
    arc_0_16_20  in_degree_937  1
    arc_0_16_20  original_T_including_depot_unload_960  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_675  1
    load_0_16_20  free_load_conservation_917  1
    load_0_16_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_677  -20
    arc_0_16_21  connected_order_arc_678  -16
    arc_0_16_21  out_degree_912  1
    arc_0_16_21  in_degree_943  1
    arc_0_16_21  original_T_including_depot_unload_960  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_677  1
    load_0_16_21  free_load_conservation_917  1
    load_0_16_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_679  -20
    arc_0_16_22  connected_order_arc_680  -16
    arc_0_16_22  out_degree_912  1
    arc_0_16_22  in_degree_949  1
    arc_0_16_22  original_T_including_depot_unload_960  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_679  1
    load_0_16_22  free_load_conservation_917  1
    load_0_16_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_681  -20
    arc_0_17_0  depot_return_or_bypass_856  1
    arc_0_17_0  out_degree_918  1
    arc_0_17_0  original_T_including_depot_unload_960  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_681  1
    load_0_17_0  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_682  -20
    arc_0_17_1  connected_order_arc_683  -16
    arc_0_17_1  in_degree_858  1
    arc_0_17_1  out_degree_918  1
    arc_0_17_1  original_T_including_depot_unload_960  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_682  1
    load_0_17_1  segment_load_conservation_861  -1
    load_0_17_1  segment_prefix_lb_862  1
    load_0_17_1  segment_prefix_ub_863  1
    load_0_17_1  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_684  -20
    arc_0_17_2  connected_order_arc_685  -16
    arc_0_17_2  in_degree_865  1
    arc_0_17_2  out_degree_918  1
    arc_0_17_2  original_T_including_depot_unload_960  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_684  1
    load_0_17_2  segment_load_conservation_868  -1
    load_0_17_2  segment_prefix_lb_869  1
    load_0_17_2  segment_prefix_ub_870  1
    load_0_17_2  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_686  -20
    arc_0_17_3  connected_order_arc_687  -16
    arc_0_17_3  in_degree_872  1
    arc_0_17_3  out_degree_918  1
    arc_0_17_3  original_T_including_depot_unload_960  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_686  1
    load_0_17_3  segment_load_conservation_875  -1
    load_0_17_3  segment_prefix_lb_876  1
    load_0_17_3  segment_prefix_ub_877  1
    load_0_17_3  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_688  -20
    arc_0_17_4  connected_order_arc_689  -16
    arc_0_17_4  in_degree_879  1
    arc_0_17_4  out_degree_918  1
    arc_0_17_4  original_T_including_depot_unload_960  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_688  1
    load_0_17_4  segment_load_conservation_882  -1
    load_0_17_4  segment_prefix_lb_883  1
    load_0_17_4  segment_prefix_ub_884  1
    load_0_17_4  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_690  -20
    arc_0_17_5  connected_order_arc_691  -16
    arc_0_17_5  in_degree_886  1
    arc_0_17_5  out_degree_918  1
    arc_0_17_5  original_T_including_depot_unload_960  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_690  1
    load_0_17_5  segment_load_conservation_889  -1
    load_0_17_5  segment_prefix_lb_890  1
    load_0_17_5  segment_prefix_ub_891  1
    load_0_17_5  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_692  -20
    arc_0_17_6  connected_order_arc_693  -16
    arc_0_17_6  in_degree_893  1
    arc_0_17_6  out_degree_918  1
    arc_0_17_6  original_T_including_depot_unload_960  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_692  1
    load_0_17_6  segment_load_conservation_896  -1
    load_0_17_6  segment_prefix_lb_897  1
    load_0_17_6  segment_prefix_ub_898  1
    load_0_17_6  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_7  arc_capacity_694  -20
    arc_0_17_7  connected_order_arc_695  -16
    arc_0_17_7  in_degree_900  1
    arc_0_17_7  out_degree_918  1
    arc_0_17_7  original_T_including_depot_unload_960  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_7  arc_capacity_694  1
    load_0_17_7  segment_load_conservation_903  -1
    load_0_17_7  segment_prefix_lb_904  1
    load_0_17_7  segment_prefix_ub_905  1
    load_0_17_7  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_696  -20
    arc_0_17_15  connected_order_arc_697  -16
    arc_0_17_15  in_degree_907  1
    arc_0_17_15  out_degree_918  1
    arc_0_17_15  original_T_including_depot_unload_960  3.4294674949374580e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_696  1
    load_0_17_15  free_load_conservation_911  -1
    load_0_17_15  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_698  -20
    arc_0_17_16  connected_order_arc_699  -16
    arc_0_17_16  in_degree_913  1
    arc_0_17_16  out_degree_918  1
    arc_0_17_16  original_T_including_depot_unload_960  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_698  1
    load_0_17_16  free_load_conservation_917  -1
    load_0_17_16  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_700  -20
    arc_0_17_18  connected_order_arc_701  -16
    arc_0_17_18  out_degree_918  1
    arc_0_17_18  in_degree_925  1
    arc_0_17_18  original_T_including_depot_unload_960  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_700  1
    load_0_17_18  free_load_conservation_923  1
    load_0_17_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_702  -20
    arc_0_17_19  connected_order_arc_703  -16
    arc_0_17_19  out_degree_918  1
    arc_0_17_19  in_degree_931  1
    arc_0_17_19  original_T_including_depot_unload_960  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_702  1
    load_0_17_19  free_load_conservation_923  1
    load_0_17_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_704  -20
    arc_0_17_20  connected_order_arc_705  -16
    arc_0_17_20  out_degree_918  1
    arc_0_17_20  in_degree_937  1
    arc_0_17_20  original_T_including_depot_unload_960  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_704  1
    load_0_17_20  free_load_conservation_923  1
    load_0_17_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_706  -20
    arc_0_17_21  connected_order_arc_707  -16
    arc_0_17_21  out_degree_918  1
    arc_0_17_21  in_degree_943  1
    arc_0_17_21  original_T_including_depot_unload_960  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_706  1
    load_0_17_21  free_load_conservation_923  1
    load_0_17_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_708  -20
    arc_0_17_22  connected_order_arc_709  -16
    arc_0_17_22  out_degree_918  1
    arc_0_17_22  in_degree_949  1
    arc_0_17_22  original_T_including_depot_unload_960  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_708  1
    load_0_17_22  free_load_conservation_923  1
    load_0_17_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_710  -20
    arc_0_18_0  depot_return_or_bypass_856  1
    arc_0_18_0  out_degree_924  1
    arc_0_18_0  original_T_including_depot_unload_960  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_710  1
    load_0_18_0  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_711  -20
    arc_0_18_1  connected_order_arc_712  -16
    arc_0_18_1  in_degree_858  1
    arc_0_18_1  out_degree_924  1
    arc_0_18_1  original_T_including_depot_unload_960  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_711  1
    load_0_18_1  segment_load_conservation_861  -1
    load_0_18_1  segment_prefix_lb_862  1
    load_0_18_1  segment_prefix_ub_863  1
    load_0_18_1  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_713  -20
    arc_0_18_2  connected_order_arc_714  -16
    arc_0_18_2  in_degree_865  1
    arc_0_18_2  out_degree_924  1
    arc_0_18_2  original_T_including_depot_unload_960  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_713  1
    load_0_18_2  segment_load_conservation_868  -1
    load_0_18_2  segment_prefix_lb_869  1
    load_0_18_2  segment_prefix_ub_870  1
    load_0_18_2  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_715  -20
    arc_0_18_3  connected_order_arc_716  -16
    arc_0_18_3  in_degree_872  1
    arc_0_18_3  out_degree_924  1
    arc_0_18_3  original_T_including_depot_unload_960  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_715  1
    load_0_18_3  segment_load_conservation_875  -1
    load_0_18_3  segment_prefix_lb_876  1
    load_0_18_3  segment_prefix_ub_877  1
    load_0_18_3  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_717  -20
    arc_0_18_4  connected_order_arc_718  -16
    arc_0_18_4  in_degree_879  1
    arc_0_18_4  out_degree_924  1
    arc_0_18_4  original_T_including_depot_unload_960  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_717  1
    load_0_18_4  segment_load_conservation_882  -1
    load_0_18_4  segment_prefix_lb_883  1
    load_0_18_4  segment_prefix_ub_884  1
    load_0_18_4  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_719  -20
    arc_0_18_5  connected_order_arc_720  -16
    arc_0_18_5  in_degree_886  1
    arc_0_18_5  out_degree_924  1
    arc_0_18_5  original_T_including_depot_unload_960  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_719  1
    load_0_18_5  segment_load_conservation_889  -1
    load_0_18_5  segment_prefix_lb_890  1
    load_0_18_5  segment_prefix_ub_891  1
    load_0_18_5  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_721  -20
    arc_0_18_6  connected_order_arc_722  -16
    arc_0_18_6  in_degree_893  1
    arc_0_18_6  out_degree_924  1
    arc_0_18_6  original_T_including_depot_unload_960  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_721  1
    load_0_18_6  segment_load_conservation_896  -1
    load_0_18_6  segment_prefix_lb_897  1
    load_0_18_6  segment_prefix_ub_898  1
    load_0_18_6  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_7  arc_capacity_723  -20
    arc_0_18_7  connected_order_arc_724  -16
    arc_0_18_7  in_degree_900  1
    arc_0_18_7  out_degree_924  1
    arc_0_18_7  original_T_including_depot_unload_960  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_7  arc_capacity_723  1
    load_0_18_7  segment_load_conservation_903  -1
    load_0_18_7  segment_prefix_lb_904  1
    load_0_18_7  segment_prefix_ub_905  1
    load_0_18_7  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_725  -20
    arc_0_18_15  connected_order_arc_726  -16
    arc_0_18_15  in_degree_907  1
    arc_0_18_15  out_degree_924  1
    arc_0_18_15  original_T_including_depot_unload_960  8.0990517952185235e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_725  1
    load_0_18_15  free_load_conservation_911  -1
    load_0_18_15  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_727  -20
    arc_0_18_16  connected_order_arc_728  -16
    arc_0_18_16  in_degree_913  1
    arc_0_18_16  out_degree_924  1
    arc_0_18_16  original_T_including_depot_unload_960  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_727  1
    load_0_18_16  free_load_conservation_917  -1
    load_0_18_16  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_729  -20
    arc_0_18_17  connected_order_arc_730  -16
    arc_0_18_17  in_degree_919  1
    arc_0_18_17  out_degree_924  1
    arc_0_18_17  original_T_including_depot_unload_960  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_729  1
    load_0_18_17  free_load_conservation_923  -1
    load_0_18_17  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_731  -20
    arc_0_18_19  connected_order_arc_732  -16
    arc_0_18_19  out_degree_924  1
    arc_0_18_19  in_degree_931  1
    arc_0_18_19  original_T_including_depot_unload_960  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_731  1
    load_0_18_19  free_load_conservation_929  1
    load_0_18_19  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_733  -20
    arc_0_18_20  connected_order_arc_734  -16
    arc_0_18_20  out_degree_924  1
    arc_0_18_20  in_degree_937  1
    arc_0_18_20  original_T_including_depot_unload_960  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_733  1
    load_0_18_20  free_load_conservation_929  1
    load_0_18_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_735  -20
    arc_0_18_21  connected_order_arc_736  -16
    arc_0_18_21  out_degree_924  1
    arc_0_18_21  in_degree_943  1
    arc_0_18_21  original_T_including_depot_unload_960  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_735  1
    load_0_18_21  free_load_conservation_929  1
    load_0_18_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_737  -20
    arc_0_18_22  connected_order_arc_738  -16
    arc_0_18_22  out_degree_924  1
    arc_0_18_22  in_degree_949  1
    arc_0_18_22  original_T_including_depot_unload_960  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_737  1
    load_0_18_22  free_load_conservation_929  1
    load_0_18_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_739  -20
    arc_0_19_0  depot_return_or_bypass_856  1
    arc_0_19_0  out_degree_930  1
    arc_0_19_0  original_T_including_depot_unload_960  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_739  1
    load_0_19_0  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_740  -20
    arc_0_19_1  connected_order_arc_741  -16
    arc_0_19_1  in_degree_858  1
    arc_0_19_1  out_degree_930  1
    arc_0_19_1  original_T_including_depot_unload_960  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_740  1
    load_0_19_1  segment_load_conservation_861  -1
    load_0_19_1  segment_prefix_lb_862  1
    load_0_19_1  segment_prefix_ub_863  1
    load_0_19_1  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_742  -20
    arc_0_19_2  connected_order_arc_743  -16
    arc_0_19_2  in_degree_865  1
    arc_0_19_2  out_degree_930  1
    arc_0_19_2  original_T_including_depot_unload_960  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_742  1
    load_0_19_2  segment_load_conservation_868  -1
    load_0_19_2  segment_prefix_lb_869  1
    load_0_19_2  segment_prefix_ub_870  1
    load_0_19_2  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_744  -20
    arc_0_19_3  connected_order_arc_745  -16
    arc_0_19_3  in_degree_872  1
    arc_0_19_3  out_degree_930  1
    arc_0_19_3  original_T_including_depot_unload_960  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_744  1
    load_0_19_3  segment_load_conservation_875  -1
    load_0_19_3  segment_prefix_lb_876  1
    load_0_19_3  segment_prefix_ub_877  1
    load_0_19_3  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_746  -20
    arc_0_19_4  connected_order_arc_747  -16
    arc_0_19_4  in_degree_879  1
    arc_0_19_4  out_degree_930  1
    arc_0_19_4  original_T_including_depot_unload_960  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_746  1
    load_0_19_4  segment_load_conservation_882  -1
    load_0_19_4  segment_prefix_lb_883  1
    load_0_19_4  segment_prefix_ub_884  1
    load_0_19_4  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_748  -20
    arc_0_19_5  connected_order_arc_749  -16
    arc_0_19_5  in_degree_886  1
    arc_0_19_5  out_degree_930  1
    arc_0_19_5  original_T_including_depot_unload_960  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_748  1
    load_0_19_5  segment_load_conservation_889  -1
    load_0_19_5  segment_prefix_lb_890  1
    load_0_19_5  segment_prefix_ub_891  1
    load_0_19_5  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_750  -20
    arc_0_19_6  connected_order_arc_751  -16
    arc_0_19_6  in_degree_893  1
    arc_0_19_6  out_degree_930  1
    arc_0_19_6  original_T_including_depot_unload_960  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_750  1
    load_0_19_6  segment_load_conservation_896  -1
    load_0_19_6  segment_prefix_lb_897  1
    load_0_19_6  segment_prefix_ub_898  1
    load_0_19_6  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_7  arc_capacity_752  -20
    arc_0_19_7  connected_order_arc_753  -16
    arc_0_19_7  in_degree_900  1
    arc_0_19_7  out_degree_930  1
    arc_0_19_7  original_T_including_depot_unload_960  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_7  arc_capacity_752  1
    load_0_19_7  segment_load_conservation_903  -1
    load_0_19_7  segment_prefix_lb_904  1
    load_0_19_7  segment_prefix_ub_905  1
    load_0_19_7  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_754  -20
    arc_0_19_15  connected_order_arc_755  -16
    arc_0_19_15  in_degree_907  1
    arc_0_19_15  out_degree_930  1
    arc_0_19_15  original_T_including_depot_unload_960  2.3897696160028909e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_754  1
    load_0_19_15  free_load_conservation_911  -1
    load_0_19_15  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_756  -20
    arc_0_19_16  connected_order_arc_757  -16
    arc_0_19_16  in_degree_913  1
    arc_0_19_16  out_degree_930  1
    arc_0_19_16  original_T_including_depot_unload_960  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_756  1
    load_0_19_16  free_load_conservation_917  -1
    load_0_19_16  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_758  -20
    arc_0_19_17  connected_order_arc_759  -16
    arc_0_19_17  in_degree_919  1
    arc_0_19_17  out_degree_930  1
    arc_0_19_17  original_T_including_depot_unload_960  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_758  1
    load_0_19_17  free_load_conservation_923  -1
    load_0_19_17  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_760  -20
    arc_0_19_18  connected_order_arc_761  -16
    arc_0_19_18  in_degree_925  1
    arc_0_19_18  out_degree_930  1
    arc_0_19_18  original_T_including_depot_unload_960  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_760  1
    load_0_19_18  free_load_conservation_929  -1
    load_0_19_18  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_762  -20
    arc_0_19_20  connected_order_arc_763  -16
    arc_0_19_20  out_degree_930  1
    arc_0_19_20  in_degree_937  1
    arc_0_19_20  original_T_including_depot_unload_960  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_762  1
    load_0_19_20  free_load_conservation_935  1
    load_0_19_20  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_764  -20
    arc_0_19_21  connected_order_arc_765  -16
    arc_0_19_21  out_degree_930  1
    arc_0_19_21  in_degree_943  1
    arc_0_19_21  original_T_including_depot_unload_960  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_764  1
    load_0_19_21  free_load_conservation_935  1
    load_0_19_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_766  -20
    arc_0_19_22  connected_order_arc_767  -16
    arc_0_19_22  out_degree_930  1
    arc_0_19_22  in_degree_949  1
    arc_0_19_22  original_T_including_depot_unload_960  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_766  1
    load_0_19_22  free_load_conservation_935  1
    load_0_19_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_768  -20
    arc_0_20_0  depot_return_or_bypass_856  1
    arc_0_20_0  out_degree_936  1
    arc_0_20_0  original_T_including_depot_unload_960  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_768  1
    load_0_20_0  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_769  -20
    arc_0_20_1  connected_order_arc_770  -16
    arc_0_20_1  in_degree_858  1
    arc_0_20_1  out_degree_936  1
    arc_0_20_1  original_T_including_depot_unload_960  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_769  1
    load_0_20_1  segment_load_conservation_861  -1
    load_0_20_1  segment_prefix_lb_862  1
    load_0_20_1  segment_prefix_ub_863  1
    load_0_20_1  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_771  -20
    arc_0_20_2  connected_order_arc_772  -16
    arc_0_20_2  in_degree_865  1
    arc_0_20_2  out_degree_936  1
    arc_0_20_2  original_T_including_depot_unload_960  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_771  1
    load_0_20_2  segment_load_conservation_868  -1
    load_0_20_2  segment_prefix_lb_869  1
    load_0_20_2  segment_prefix_ub_870  1
    load_0_20_2  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_773  -20
    arc_0_20_3  connected_order_arc_774  -16
    arc_0_20_3  in_degree_872  1
    arc_0_20_3  out_degree_936  1
    arc_0_20_3  original_T_including_depot_unload_960  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_773  1
    load_0_20_3  segment_load_conservation_875  -1
    load_0_20_3  segment_prefix_lb_876  1
    load_0_20_3  segment_prefix_ub_877  1
    load_0_20_3  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_775  -20
    arc_0_20_4  connected_order_arc_776  -16
    arc_0_20_4  in_degree_879  1
    arc_0_20_4  out_degree_936  1
    arc_0_20_4  original_T_including_depot_unload_960  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_775  1
    load_0_20_4  segment_load_conservation_882  -1
    load_0_20_4  segment_prefix_lb_883  1
    load_0_20_4  segment_prefix_ub_884  1
    load_0_20_4  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_777  -20
    arc_0_20_5  connected_order_arc_778  -16
    arc_0_20_5  in_degree_886  1
    arc_0_20_5  out_degree_936  1
    arc_0_20_5  original_T_including_depot_unload_960  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_777  1
    load_0_20_5  segment_load_conservation_889  -1
    load_0_20_5  segment_prefix_lb_890  1
    load_0_20_5  segment_prefix_ub_891  1
    load_0_20_5  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_779  -20
    arc_0_20_6  connected_order_arc_780  -16
    arc_0_20_6  in_degree_893  1
    arc_0_20_6  out_degree_936  1
    arc_0_20_6  original_T_including_depot_unload_960  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_779  1
    load_0_20_6  segment_load_conservation_896  -1
    load_0_20_6  segment_prefix_lb_897  1
    load_0_20_6  segment_prefix_ub_898  1
    load_0_20_6  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_7  arc_capacity_781  -20
    arc_0_20_7  connected_order_arc_782  -16
    arc_0_20_7  in_degree_900  1
    arc_0_20_7  out_degree_936  1
    arc_0_20_7  original_T_including_depot_unload_960  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_7  arc_capacity_781  1
    load_0_20_7  segment_load_conservation_903  -1
    load_0_20_7  segment_prefix_lb_904  1
    load_0_20_7  segment_prefix_ub_905  1
    load_0_20_7  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_783  -20
    arc_0_20_15  connected_order_arc_784  -16
    arc_0_20_15  in_degree_907  1
    arc_0_20_15  out_degree_936  1
    arc_0_20_15  original_T_including_depot_unload_960  8.8284459023081490e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_783  1
    load_0_20_15  free_load_conservation_911  -1
    load_0_20_15  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_785  -20
    arc_0_20_16  connected_order_arc_786  -16
    arc_0_20_16  in_degree_913  1
    arc_0_20_16  out_degree_936  1
    arc_0_20_16  original_T_including_depot_unload_960  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_785  1
    load_0_20_16  free_load_conservation_917  -1
    load_0_20_16  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_787  -20
    arc_0_20_17  connected_order_arc_788  -16
    arc_0_20_17  in_degree_919  1
    arc_0_20_17  out_degree_936  1
    arc_0_20_17  original_T_including_depot_unload_960  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_787  1
    load_0_20_17  free_load_conservation_923  -1
    load_0_20_17  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_789  -20
    arc_0_20_18  connected_order_arc_790  -16
    arc_0_20_18  in_degree_925  1
    arc_0_20_18  out_degree_936  1
    arc_0_20_18  original_T_including_depot_unload_960  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_789  1
    load_0_20_18  free_load_conservation_929  -1
    load_0_20_18  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_791  -20
    arc_0_20_19  connected_order_arc_792  -16
    arc_0_20_19  in_degree_931  1
    arc_0_20_19  out_degree_936  1
    arc_0_20_19  original_T_including_depot_unload_960  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_791  1
    load_0_20_19  free_load_conservation_935  -1
    load_0_20_19  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_793  -20
    arc_0_20_21  connected_order_arc_794  -16
    arc_0_20_21  out_degree_936  1
    arc_0_20_21  in_degree_943  1
    arc_0_20_21  original_T_including_depot_unload_960  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_793  1
    load_0_20_21  free_load_conservation_941  1
    load_0_20_21  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_795  -20
    arc_0_20_22  connected_order_arc_796  -16
    arc_0_20_22  out_degree_936  1
    arc_0_20_22  in_degree_949  1
    arc_0_20_22  original_T_including_depot_unload_960  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_795  1
    load_0_20_22  free_load_conservation_941  1
    load_0_20_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_797  -20
    arc_0_21_0  depot_return_or_bypass_856  1
    arc_0_21_0  out_degree_942  1
    arc_0_21_0  original_T_including_depot_unload_960  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_797  1
    load_0_21_0  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_798  -20
    arc_0_21_1  connected_order_arc_799  -16
    arc_0_21_1  in_degree_858  1
    arc_0_21_1  out_degree_942  1
    arc_0_21_1  original_T_including_depot_unload_960  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_798  1
    load_0_21_1  segment_load_conservation_861  -1
    load_0_21_1  segment_prefix_lb_862  1
    load_0_21_1  segment_prefix_ub_863  1
    load_0_21_1  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_800  -20
    arc_0_21_2  connected_order_arc_801  -16
    arc_0_21_2  in_degree_865  1
    arc_0_21_2  out_degree_942  1
    arc_0_21_2  original_T_including_depot_unload_960  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_800  1
    load_0_21_2  segment_load_conservation_868  -1
    load_0_21_2  segment_prefix_lb_869  1
    load_0_21_2  segment_prefix_ub_870  1
    load_0_21_2  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_802  -20
    arc_0_21_3  connected_order_arc_803  -16
    arc_0_21_3  in_degree_872  1
    arc_0_21_3  out_degree_942  1
    arc_0_21_3  original_T_including_depot_unload_960  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_802  1
    load_0_21_3  segment_load_conservation_875  -1
    load_0_21_3  segment_prefix_lb_876  1
    load_0_21_3  segment_prefix_ub_877  1
    load_0_21_3  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_804  -20
    arc_0_21_4  connected_order_arc_805  -16
    arc_0_21_4  in_degree_879  1
    arc_0_21_4  out_degree_942  1
    arc_0_21_4  original_T_including_depot_unload_960  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_804  1
    load_0_21_4  segment_load_conservation_882  -1
    load_0_21_4  segment_prefix_lb_883  1
    load_0_21_4  segment_prefix_ub_884  1
    load_0_21_4  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_806  -20
    arc_0_21_5  connected_order_arc_807  -16
    arc_0_21_5  in_degree_886  1
    arc_0_21_5  out_degree_942  1
    arc_0_21_5  original_T_including_depot_unload_960  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_806  1
    load_0_21_5  segment_load_conservation_889  -1
    load_0_21_5  segment_prefix_lb_890  1
    load_0_21_5  segment_prefix_ub_891  1
    load_0_21_5  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_808  -20
    arc_0_21_6  connected_order_arc_809  -16
    arc_0_21_6  in_degree_893  1
    arc_0_21_6  out_degree_942  1
    arc_0_21_6  original_T_including_depot_unload_960  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_808  1
    load_0_21_6  segment_load_conservation_896  -1
    load_0_21_6  segment_prefix_lb_897  1
    load_0_21_6  segment_prefix_ub_898  1
    load_0_21_6  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_7  arc_capacity_810  -20
    arc_0_21_7  connected_order_arc_811  -16
    arc_0_21_7  in_degree_900  1
    arc_0_21_7  out_degree_942  1
    arc_0_21_7  original_T_including_depot_unload_960  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_7  arc_capacity_810  1
    load_0_21_7  segment_load_conservation_903  -1
    load_0_21_7  segment_prefix_lb_904  1
    load_0_21_7  segment_prefix_ub_905  1
    load_0_21_7  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_812  -20
    arc_0_21_15  connected_order_arc_813  -16
    arc_0_21_15  in_degree_907  1
    arc_0_21_15  out_degree_942  1
    arc_0_21_15  original_T_including_depot_unload_960  2.8013754919345556e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_812  1
    load_0_21_15  free_load_conservation_911  -1
    load_0_21_15  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_814  -20
    arc_0_21_16  connected_order_arc_815  -16
    arc_0_21_16  in_degree_913  1
    arc_0_21_16  out_degree_942  1
    arc_0_21_16  original_T_including_depot_unload_960  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_814  1
    load_0_21_16  free_load_conservation_917  -1
    load_0_21_16  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_816  -20
    arc_0_21_17  connected_order_arc_817  -16
    arc_0_21_17  in_degree_919  1
    arc_0_21_17  out_degree_942  1
    arc_0_21_17  original_T_including_depot_unload_960  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_816  1
    load_0_21_17  free_load_conservation_923  -1
    load_0_21_17  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_818  -20
    arc_0_21_18  connected_order_arc_819  -16
    arc_0_21_18  in_degree_925  1
    arc_0_21_18  out_degree_942  1
    arc_0_21_18  original_T_including_depot_unload_960  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_818  1
    load_0_21_18  free_load_conservation_929  -1
    load_0_21_18  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_820  -20
    arc_0_21_19  connected_order_arc_821  -16
    arc_0_21_19  in_degree_931  1
    arc_0_21_19  out_degree_942  1
    arc_0_21_19  original_T_including_depot_unload_960  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_820  1
    load_0_21_19  free_load_conservation_935  -1
    load_0_21_19  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_822  -20
    arc_0_21_20  connected_order_arc_823  -16
    arc_0_21_20  in_degree_937  1
    arc_0_21_20  out_degree_942  1
    arc_0_21_20  original_T_including_depot_unload_960  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_822  1
    load_0_21_20  free_load_conservation_941  -1
    load_0_21_20  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_824  -20
    arc_0_21_22  connected_order_arc_825  -16
    arc_0_21_22  out_degree_942  1
    arc_0_21_22  in_degree_949  1
    arc_0_21_22  original_T_including_depot_unload_960  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_824  1
    load_0_21_22  free_load_conservation_947  1
    load_0_21_22  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_826  -20
    arc_0_22_0  depot_return_or_bypass_856  1
    arc_0_22_0  out_degree_948  1
    arc_0_22_0  original_T_including_depot_unload_960  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_826  1
    load_0_22_0  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_827  -20
    arc_0_22_1  connected_order_arc_828  -16
    arc_0_22_1  in_degree_858  1
    arc_0_22_1  out_degree_948  1
    arc_0_22_1  original_T_including_depot_unload_960  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_827  1
    load_0_22_1  segment_load_conservation_861  -1
    load_0_22_1  segment_prefix_lb_862  1
    load_0_22_1  segment_prefix_ub_863  1
    load_0_22_1  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_829  -20
    arc_0_22_2  connected_order_arc_830  -16
    arc_0_22_2  in_degree_865  1
    arc_0_22_2  out_degree_948  1
    arc_0_22_2  original_T_including_depot_unload_960  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_829  1
    load_0_22_2  segment_load_conservation_868  -1
    load_0_22_2  segment_prefix_lb_869  1
    load_0_22_2  segment_prefix_ub_870  1
    load_0_22_2  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_831  -20
    arc_0_22_3  connected_order_arc_832  -16
    arc_0_22_3  in_degree_872  1
    arc_0_22_3  out_degree_948  1
    arc_0_22_3  original_T_including_depot_unload_960  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_831  1
    load_0_22_3  segment_load_conservation_875  -1
    load_0_22_3  segment_prefix_lb_876  1
    load_0_22_3  segment_prefix_ub_877  1
    load_0_22_3  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_833  -20
    arc_0_22_4  connected_order_arc_834  -16
    arc_0_22_4  in_degree_879  1
    arc_0_22_4  out_degree_948  1
    arc_0_22_4  original_T_including_depot_unload_960  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_833  1
    load_0_22_4  segment_load_conservation_882  -1
    load_0_22_4  segment_prefix_lb_883  1
    load_0_22_4  segment_prefix_ub_884  1
    load_0_22_4  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_835  -20
    arc_0_22_5  connected_order_arc_836  -16
    arc_0_22_5  in_degree_886  1
    arc_0_22_5  out_degree_948  1
    arc_0_22_5  original_T_including_depot_unload_960  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_835  1
    load_0_22_5  segment_load_conservation_889  -1
    load_0_22_5  segment_prefix_lb_890  1
    load_0_22_5  segment_prefix_ub_891  1
    load_0_22_5  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_6  arc_capacity_837  -20
    arc_0_22_6  connected_order_arc_838  -16
    arc_0_22_6  in_degree_893  1
    arc_0_22_6  out_degree_948  1
    arc_0_22_6  original_T_including_depot_unload_960  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_6  arc_capacity_837  1
    load_0_22_6  segment_load_conservation_896  -1
    load_0_22_6  segment_prefix_lb_897  1
    load_0_22_6  segment_prefix_ub_898  1
    load_0_22_6  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_7  arc_capacity_839  -20
    arc_0_22_7  connected_order_arc_840  -16
    arc_0_22_7  in_degree_900  1
    arc_0_22_7  out_degree_948  1
    arc_0_22_7  original_T_including_depot_unload_960  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_7  arc_capacity_839  1
    load_0_22_7  segment_load_conservation_903  -1
    load_0_22_7  segment_prefix_lb_904  1
    load_0_22_7  segment_prefix_ub_905  1
    load_0_22_7  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_841  -20
    arc_0_22_15  connected_order_arc_842  -16
    arc_0_22_15  in_degree_907  1
    arc_0_22_15  out_degree_948  1
    arc_0_22_15  original_T_including_depot_unload_960  1.0617037707898505e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_841  1
    load_0_22_15  free_load_conservation_911  -1
    load_0_22_15  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_843  -20
    arc_0_22_16  connected_order_arc_844  -16
    arc_0_22_16  in_degree_913  1
    arc_0_22_16  out_degree_948  1
    arc_0_22_16  original_T_including_depot_unload_960  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_843  1
    load_0_22_16  free_load_conservation_917  -1
    load_0_22_16  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_845  -20
    arc_0_22_17  connected_order_arc_846  -16
    arc_0_22_17  in_degree_919  1
    arc_0_22_17  out_degree_948  1
    arc_0_22_17  original_T_including_depot_unload_960  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_845  1
    load_0_22_17  free_load_conservation_923  -1
    load_0_22_17  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_847  -20
    arc_0_22_18  connected_order_arc_848  -16
    arc_0_22_18  in_degree_925  1
    arc_0_22_18  out_degree_948  1
    arc_0_22_18  original_T_including_depot_unload_960  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_847  1
    load_0_22_18  free_load_conservation_929  -1
    load_0_22_18  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_849  -20
    arc_0_22_19  connected_order_arc_850  -16
    arc_0_22_19  in_degree_931  1
    arc_0_22_19  out_degree_948  1
    arc_0_22_19  original_T_including_depot_unload_960  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_849  1
    load_0_22_19  free_load_conservation_935  -1
    load_0_22_19  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_851  -20
    arc_0_22_20  connected_order_arc_852  -16
    arc_0_22_20  in_degree_937  1
    arc_0_22_20  out_degree_948  1
    arc_0_22_20  original_T_including_depot_unload_960  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_851  1
    load_0_22_20  free_load_conservation_941  -1
    load_0_22_20  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_853  -20
    arc_0_22_21  connected_order_arc_854  -16
    arc_0_22_21  in_degree_943  1
    arc_0_22_21  out_degree_948  1
    arc_0_22_21  original_T_including_depot_unload_960  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_853  1
    load_0_22_21  free_load_conservation_947  -1
    load_0_22_21  free_load_conservation_953  1
    visit_1_8  out_degree_1206  -1
    visit_1_8  in_degree_1207  -1
    visit_1_8  order_active_lb_1208  -1
    visit_1_8  order_active_ub_1209  -11
    order_1_8  connected_order_arc_975  -1
    order_1_8  connected_order_arc_977  -1
    order_1_8  connected_order_arc_979  -1
    order_1_8  connected_order_arc_981  -1
    order_1_8  connected_order_arc_983  -1
    order_1_8  connected_order_arc_985  -1
    order_1_8  connected_order_arc_987  -1
    order_1_8  connected_order_arc_989  -1
    order_1_8  connected_order_arc_991  -1
    order_1_8  connected_order_arc_993  -1
    order_1_8  connected_order_arc_996  1
    order_1_8  connected_order_arc_1017  1
    order_1_8  connected_order_arc_1038  1
    order_1_8  connected_order_arc_1059  1
    order_1_8  connected_order_arc_1080  1
    order_1_8  connected_order_arc_1101  1
    order_1_8  connected_order_arc_1122  1
    order_1_8  connected_order_arc_1143  1
    order_1_8  connected_order_arc_1164  1
    order_1_8  connected_order_arc_1185  1
    order_1_8  order_active_lb_1208  1
    order_1_8  order_active_ub_1209  1
    order_1_8  fixed_segment_relative_order_1275  -1
    visit_1_9  out_degree_1213  -1
    visit_1_9  in_degree_1214  -1
    visit_1_9  order_active_lb_1215  -1
    visit_1_9  order_active_ub_1216  -11
    order_1_9  connected_order_arc_975  1
    order_1_9  connected_order_arc_996  -1
    order_1_9  connected_order_arc_998  -1
    order_1_9  connected_order_arc_1000  -1
    order_1_9  connected_order_arc_1002  -1
    order_1_9  connected_order_arc_1004  -1
    order_1_9  connected_order_arc_1006  -1
    order_1_9  connected_order_arc_1008  -1
    order_1_9  connected_order_arc_1010  -1
    order_1_9  connected_order_arc_1012  -1
    order_1_9  connected_order_arc_1014  -1
    order_1_9  connected_order_arc_1019  1
    order_1_9  connected_order_arc_1040  1
    order_1_9  connected_order_arc_1061  1
    order_1_9  connected_order_arc_1082  1
    order_1_9  connected_order_arc_1103  1
    order_1_9  connected_order_arc_1124  1
    order_1_9  connected_order_arc_1145  1
    order_1_9  connected_order_arc_1166  1
    order_1_9  connected_order_arc_1187  1
    order_1_9  order_active_lb_1215  1
    order_1_9  order_active_ub_1216  1
    order_1_9  fixed_segment_relative_order_1275  1
    order_1_9  fixed_segment_relative_order_1276  -1
    visit_1_10  out_degree_1220  -1
    visit_1_10  in_degree_1221  -1
    visit_1_10  order_active_lb_1222  -1
    visit_1_10  order_active_ub_1223  -11
    order_1_10  connected_order_arc_977  1
    order_1_10  connected_order_arc_998  1
    order_1_10  connected_order_arc_1017  -1
    order_1_10  connected_order_arc_1019  -1
    order_1_10  connected_order_arc_1021  -1
    order_1_10  connected_order_arc_1023  -1
    order_1_10  connected_order_arc_1025  -1
    order_1_10  connected_order_arc_1027  -1
    order_1_10  connected_order_arc_1029  -1
    order_1_10  connected_order_arc_1031  -1
    order_1_10  connected_order_arc_1033  -1
    order_1_10  connected_order_arc_1035  -1
    order_1_10  connected_order_arc_1042  1
    order_1_10  connected_order_arc_1063  1
    order_1_10  connected_order_arc_1084  1
    order_1_10  connected_order_arc_1105  1
    order_1_10  connected_order_arc_1126  1
    order_1_10  connected_order_arc_1147  1
    order_1_10  connected_order_arc_1168  1
    order_1_10  connected_order_arc_1189  1
    order_1_10  order_active_lb_1222  1
    order_1_10  order_active_ub_1223  1
    order_1_10  fixed_segment_relative_order_1276  1
    visit_1_15  out_degree_1227  -1
    visit_1_15  in_degree_1228  -1
    visit_1_15  order_active_lb_1229  -1
    visit_1_15  order_active_ub_1230  -11
    visit_1_15  service_visit_def_1231  -1
    order_1_15  connected_order_arc_979  1
    order_1_15  connected_order_arc_1000  1
    order_1_15  connected_order_arc_1021  1
    order_1_15  connected_order_arc_1038  -1
    order_1_15  connected_order_arc_1040  -1
    order_1_15  connected_order_arc_1042  -1
    order_1_15  connected_order_arc_1044  -1
    order_1_15  connected_order_arc_1046  -1
    order_1_15  connected_order_arc_1048  -1
    order_1_15  connected_order_arc_1050  -1
    order_1_15  connected_order_arc_1052  -1
    order_1_15  connected_order_arc_1054  -1
    order_1_15  connected_order_arc_1056  -1
    order_1_15  connected_order_arc_1065  1
    order_1_15  connected_order_arc_1086  1
    order_1_15  connected_order_arc_1107  1
    order_1_15  connected_order_arc_1128  1
    order_1_15  connected_order_arc_1149  1
    order_1_15  connected_order_arc_1170  1
    order_1_15  connected_order_arc_1191  1
    order_1_15  order_active_lb_1229  1
    order_1_15  order_active_ub_1230  1
    visit_1_16  out_degree_1233  -1
    visit_1_16  in_degree_1234  -1
    visit_1_16  order_active_lb_1235  -1
    visit_1_16  order_active_ub_1236  -11
    visit_1_16  service_visit_def_1237  -1
    order_1_16  connected_order_arc_981  1
    order_1_16  connected_order_arc_1002  1
    order_1_16  connected_order_arc_1023  1
    order_1_16  connected_order_arc_1044  1
    order_1_16  connected_order_arc_1059  -1
    order_1_16  connected_order_arc_1061  -1
    order_1_16  connected_order_arc_1063  -1
    order_1_16  connected_order_arc_1065  -1
    order_1_16  connected_order_arc_1067  -1
    order_1_16  connected_order_arc_1069  -1
    order_1_16  connected_order_arc_1071  -1
    order_1_16  connected_order_arc_1073  -1
    order_1_16  connected_order_arc_1075  -1
    order_1_16  connected_order_arc_1077  -1
    order_1_16  connected_order_arc_1088  1
    order_1_16  connected_order_arc_1109  1
    order_1_16  connected_order_arc_1130  1
    order_1_16  connected_order_arc_1151  1
    order_1_16  connected_order_arc_1172  1
    order_1_16  connected_order_arc_1193  1
    order_1_16  order_active_lb_1235  1
    order_1_16  order_active_ub_1236  1
    visit_1_17  out_degree_1239  -1
    visit_1_17  in_degree_1240  -1
    visit_1_17  order_active_lb_1241  -1
    visit_1_17  order_active_ub_1242  -11
    visit_1_17  service_visit_def_1243  -1
    order_1_17  connected_order_arc_983  1
    order_1_17  connected_order_arc_1004  1
    order_1_17  connected_order_arc_1025  1
    order_1_17  connected_order_arc_1046  1
    order_1_17  connected_order_arc_1067  1
    order_1_17  connected_order_arc_1080  -1
    order_1_17  connected_order_arc_1082  -1
    order_1_17  connected_order_arc_1084  -1
    order_1_17  connected_order_arc_1086  -1
    order_1_17  connected_order_arc_1088  -1
    order_1_17  connected_order_arc_1090  -1
    order_1_17  connected_order_arc_1092  -1
    order_1_17  connected_order_arc_1094  -1
    order_1_17  connected_order_arc_1096  -1
    order_1_17  connected_order_arc_1098  -1
    order_1_17  connected_order_arc_1111  1
    order_1_17  connected_order_arc_1132  1
    order_1_17  connected_order_arc_1153  1
    order_1_17  connected_order_arc_1174  1
    order_1_17  connected_order_arc_1195  1
    order_1_17  order_active_lb_1241  1
    order_1_17  order_active_ub_1242  1
    visit_1_18  out_degree_1245  -1
    visit_1_18  in_degree_1246  -1
    visit_1_18  order_active_lb_1247  -1
    visit_1_18  order_active_ub_1248  -11
    visit_1_18  service_visit_def_1249  -1
    order_1_18  connected_order_arc_985  1
    order_1_18  connected_order_arc_1006  1
    order_1_18  connected_order_arc_1027  1
    order_1_18  connected_order_arc_1048  1
    order_1_18  connected_order_arc_1069  1
    order_1_18  connected_order_arc_1090  1
    order_1_18  connected_order_arc_1101  -1
    order_1_18  connected_order_arc_1103  -1
    order_1_18  connected_order_arc_1105  -1
    order_1_18  connected_order_arc_1107  -1
    order_1_18  connected_order_arc_1109  -1
    order_1_18  connected_order_arc_1111  -1
    order_1_18  connected_order_arc_1113  -1
    order_1_18  connected_order_arc_1115  -1
    order_1_18  connected_order_arc_1117  -1
    order_1_18  connected_order_arc_1119  -1
    order_1_18  connected_order_arc_1134  1
    order_1_18  connected_order_arc_1155  1
    order_1_18  connected_order_arc_1176  1
    order_1_18  connected_order_arc_1197  1
    order_1_18  order_active_lb_1247  1
    order_1_18  order_active_ub_1248  1
    visit_1_19  out_degree_1251  -1
    visit_1_19  in_degree_1252  -1
    visit_1_19  order_active_lb_1253  -1
    visit_1_19  order_active_ub_1254  -11
    visit_1_19  service_visit_def_1255  -1
    order_1_19  connected_order_arc_987  1
    order_1_19  connected_order_arc_1008  1
    order_1_19  connected_order_arc_1029  1
    order_1_19  connected_order_arc_1050  1
    order_1_19  connected_order_arc_1071  1
    order_1_19  connected_order_arc_1092  1
    order_1_19  connected_order_arc_1113  1
    order_1_19  connected_order_arc_1122  -1
    order_1_19  connected_order_arc_1124  -1
    order_1_19  connected_order_arc_1126  -1
    order_1_19  connected_order_arc_1128  -1
    order_1_19  connected_order_arc_1130  -1
    order_1_19  connected_order_arc_1132  -1
    order_1_19  connected_order_arc_1134  -1
    order_1_19  connected_order_arc_1136  -1
    order_1_19  connected_order_arc_1138  -1
    order_1_19  connected_order_arc_1140  -1
    order_1_19  connected_order_arc_1157  1
    order_1_19  connected_order_arc_1178  1
    order_1_19  connected_order_arc_1199  1
    order_1_19  order_active_lb_1253  1
    order_1_19  order_active_ub_1254  1
    visit_1_20  out_degree_1257  -1
    visit_1_20  in_degree_1258  -1
    visit_1_20  order_active_lb_1259  -1
    visit_1_20  order_active_ub_1260  -11
    visit_1_20  service_visit_def_1261  -1
    order_1_20  connected_order_arc_989  1
    order_1_20  connected_order_arc_1010  1
    order_1_20  connected_order_arc_1031  1
    order_1_20  connected_order_arc_1052  1
    order_1_20  connected_order_arc_1073  1
    order_1_20  connected_order_arc_1094  1
    order_1_20  connected_order_arc_1115  1
    order_1_20  connected_order_arc_1136  1
    order_1_20  connected_order_arc_1143  -1
    order_1_20  connected_order_arc_1145  -1
    order_1_20  connected_order_arc_1147  -1
    order_1_20  connected_order_arc_1149  -1
    order_1_20  connected_order_arc_1151  -1
    order_1_20  connected_order_arc_1153  -1
    order_1_20  connected_order_arc_1155  -1
    order_1_20  connected_order_arc_1157  -1
    order_1_20  connected_order_arc_1159  -1
    order_1_20  connected_order_arc_1161  -1
    order_1_20  connected_order_arc_1180  1
    order_1_20  connected_order_arc_1201  1
    order_1_20  order_active_lb_1259  1
    order_1_20  order_active_ub_1260  1
    visit_1_21  out_degree_1263  -1
    visit_1_21  in_degree_1264  -1
    visit_1_21  order_active_lb_1265  -1
    visit_1_21  order_active_ub_1266  -11
    visit_1_21  service_visit_def_1267  -1
    order_1_21  connected_order_arc_991  1
    order_1_21  connected_order_arc_1012  1
    order_1_21  connected_order_arc_1033  1
    order_1_21  connected_order_arc_1054  1
    order_1_21  connected_order_arc_1075  1
    order_1_21  connected_order_arc_1096  1
    order_1_21  connected_order_arc_1117  1
    order_1_21  connected_order_arc_1138  1
    order_1_21  connected_order_arc_1159  1
    order_1_21  connected_order_arc_1164  -1
    order_1_21  connected_order_arc_1166  -1
    order_1_21  connected_order_arc_1168  -1
    order_1_21  connected_order_arc_1170  -1
    order_1_21  connected_order_arc_1172  -1
    order_1_21  connected_order_arc_1174  -1
    order_1_21  connected_order_arc_1176  -1
    order_1_21  connected_order_arc_1178  -1
    order_1_21  connected_order_arc_1180  -1
    order_1_21  connected_order_arc_1182  -1
    order_1_21  connected_order_arc_1203  1
    order_1_21  order_active_lb_1265  1
    order_1_21  order_active_ub_1266  1
    visit_1_22  out_degree_1269  -1
    visit_1_22  in_degree_1270  -1
    visit_1_22  order_active_lb_1271  -1
    visit_1_22  order_active_ub_1272  -11
    visit_1_22  service_visit_def_1273  -1
    order_1_22  connected_order_arc_993  1
    order_1_22  connected_order_arc_1014  1
    order_1_22  connected_order_arc_1035  1
    order_1_22  connected_order_arc_1056  1
    order_1_22  connected_order_arc_1077  1
    order_1_22  connected_order_arc_1098  1
    order_1_22  connected_order_arc_1119  1
    order_1_22  connected_order_arc_1140  1
    order_1_22  connected_order_arc_1161  1
    order_1_22  connected_order_arc_1182  1
    order_1_22  connected_order_arc_1185  -1
    order_1_22  connected_order_arc_1187  -1
    order_1_22  connected_order_arc_1189  -1
    order_1_22  connected_order_arc_1191  -1
    order_1_22  connected_order_arc_1193  -1
    order_1_22  connected_order_arc_1195  -1
    order_1_22  connected_order_arc_1197  -1
    order_1_22  connected_order_arc_1199  -1
    order_1_22  connected_order_arc_1201  -1
    order_1_22  connected_order_arc_1203  -1
    order_1_22  order_active_lb_1271  1
    order_1_22  order_active_ub_1272  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_961  -25
    arc_1_0_0  depot_departure_or_bypass_1204  1
    arc_1_0_0  depot_return_or_bypass_1205  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_961  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_962  -25
    arc_1_0_8  depot_departure_or_bypass_1204  1
    arc_1_0_8  in_degree_1207  1
    arc_1_0_8  original_T_including_depot_unload_1277  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_962  1
    load_1_0_8  segment_load_conservation_1210  -1
    load_1_0_8  segment_prefix_lb_1211  1
    load_1_0_8  segment_prefix_ub_1212  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_963  -25
    arc_1_0_9  depot_departure_or_bypass_1204  1
    arc_1_0_9  in_degree_1214  1
    arc_1_0_9  original_T_including_depot_unload_1277  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_963  1
    load_1_0_9  segment_load_conservation_1217  -1
    load_1_0_9  segment_prefix_lb_1218  1
    load_1_0_9  segment_prefix_ub_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_964  -25
    arc_1_0_10  depot_departure_or_bypass_1204  1
    arc_1_0_10  in_degree_1221  1
    arc_1_0_10  original_T_including_depot_unload_1277  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_964  1
    load_1_0_10  segment_load_conservation_1224  -1
    load_1_0_10  segment_prefix_lb_1225  1
    load_1_0_10  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_965  -25
    arc_1_0_15  depot_departure_or_bypass_1204  1
    arc_1_0_15  in_degree_1228  1
    arc_1_0_15  original_T_including_depot_unload_1277  1.9654373797357937e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_965  1
    load_1_0_15  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_966  -25
    arc_1_0_16  depot_departure_or_bypass_1204  1
    arc_1_0_16  in_degree_1234  1
    arc_1_0_16  original_T_including_depot_unload_1277  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_966  1
    load_1_0_16  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_967  -25
    arc_1_0_17  depot_departure_or_bypass_1204  1
    arc_1_0_17  in_degree_1240  1
    arc_1_0_17  original_T_including_depot_unload_1277  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_967  1
    load_1_0_17  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_968  -25
    arc_1_0_18  depot_departure_or_bypass_1204  1
    arc_1_0_18  in_degree_1246  1
    arc_1_0_18  original_T_including_depot_unload_1277  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_968  1
    load_1_0_18  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_969  -25
    arc_1_0_19  depot_departure_or_bypass_1204  1
    arc_1_0_19  in_degree_1252  1
    arc_1_0_19  original_T_including_depot_unload_1277  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_969  1
    load_1_0_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_970  -25
    arc_1_0_20  depot_departure_or_bypass_1204  1
    arc_1_0_20  in_degree_1258  1
    arc_1_0_20  original_T_including_depot_unload_1277  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_970  1
    load_1_0_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_971  -25
    arc_1_0_21  depot_departure_or_bypass_1204  1
    arc_1_0_21  in_degree_1264  1
    arc_1_0_21  original_T_including_depot_unload_1277  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_971  1
    load_1_0_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_972  -25
    arc_1_0_22  depot_departure_or_bypass_1204  1
    arc_1_0_22  in_degree_1270  1
    arc_1_0_22  original_T_including_depot_unload_1277  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_972  1
    load_1_0_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_973  -25
    arc_1_8_0  depot_return_or_bypass_1205  1
    arc_1_8_0  out_degree_1206  1
    arc_1_8_0  original_T_including_depot_unload_1277  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_973  1
    load_1_8_0  segment_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_974  -25
    arc_1_8_9  connected_order_arc_975  -12
    arc_1_8_9  out_degree_1206  1
    arc_1_8_9  in_degree_1214  1
    arc_1_8_9  original_T_including_depot_unload_1277  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_974  1
    load_1_8_9  segment_load_conservation_1210  1
    load_1_8_9  segment_load_conservation_1217  -1
    load_1_8_9  segment_prefix_lb_1218  1
    load_1_8_9  segment_prefix_ub_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_976  -25
    arc_1_8_10  connected_order_arc_977  -12
    arc_1_8_10  out_degree_1206  1
    arc_1_8_10  in_degree_1221  1
    arc_1_8_10  original_T_including_depot_unload_1277  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_976  1
    load_1_8_10  segment_load_conservation_1210  1
    load_1_8_10  segment_load_conservation_1224  -1
    load_1_8_10  segment_prefix_lb_1225  1
    load_1_8_10  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_978  -25
    arc_1_8_15  connected_order_arc_979  -12
    arc_1_8_15  out_degree_1206  1
    arc_1_8_15  in_degree_1228  1
    arc_1_8_15  original_T_including_depot_unload_1277  2.5663749241687369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_978  1
    load_1_8_15  segment_load_conservation_1210  1
    load_1_8_15  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_980  -25
    arc_1_8_16  connected_order_arc_981  -12
    arc_1_8_16  out_degree_1206  1
    arc_1_8_16  in_degree_1234  1
    arc_1_8_16  original_T_including_depot_unload_1277  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_980  1
    load_1_8_16  segment_load_conservation_1210  1
    load_1_8_16  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_982  -25
    arc_1_8_17  connected_order_arc_983  -12
    arc_1_8_17  out_degree_1206  1
    arc_1_8_17  in_degree_1240  1
    arc_1_8_17  original_T_including_depot_unload_1277  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_982  1
    load_1_8_17  segment_load_conservation_1210  1
    load_1_8_17  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_984  -25
    arc_1_8_18  connected_order_arc_985  -12
    arc_1_8_18  out_degree_1206  1
    arc_1_8_18  in_degree_1246  1
    arc_1_8_18  original_T_including_depot_unload_1277  1829.33035879167
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_984  1
    load_1_8_18  segment_load_conservation_1210  1
    load_1_8_18  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_986  -25
    arc_1_8_19  connected_order_arc_987  -12
    arc_1_8_19  out_degree_1206  1
    arc_1_8_19  in_degree_1252  1
    arc_1_8_19  original_T_including_depot_unload_1277  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_986  1
    load_1_8_19  segment_load_conservation_1210  1
    load_1_8_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_988  -25
    arc_1_8_20  connected_order_arc_989  -12
    arc_1_8_20  out_degree_1206  1
    arc_1_8_20  in_degree_1258  1
    arc_1_8_20  original_T_including_depot_unload_1277  1.9270569168668533e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_988  1
    load_1_8_20  segment_load_conservation_1210  1
    load_1_8_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_990  -25
    arc_1_8_21  connected_order_arc_991  -12
    arc_1_8_21  out_degree_1206  1
    arc_1_8_21  in_degree_1264  1
    arc_1_8_21  original_T_including_depot_unload_1277  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_990  1
    load_1_8_21  segment_load_conservation_1210  1
    load_1_8_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_992  -25
    arc_1_8_22  connected_order_arc_993  -12
    arc_1_8_22  out_degree_1206  1
    arc_1_8_22  in_degree_1270  1
    arc_1_8_22  original_T_including_depot_unload_1277  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_992  1
    load_1_8_22  segment_load_conservation_1210  1
    load_1_8_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_994  -25
    arc_1_9_0  depot_return_or_bypass_1205  1
    arc_1_9_0  out_degree_1213  1
    arc_1_9_0  original_T_including_depot_unload_1277  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_994  1
    load_1_9_0  segment_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_995  -25
    arc_1_9_8  connected_order_arc_996  -12
    arc_1_9_8  in_degree_1207  1
    arc_1_9_8  out_degree_1213  1
    arc_1_9_8  original_T_including_depot_unload_1277  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_995  1
    load_1_9_8  segment_load_conservation_1210  -1
    load_1_9_8  segment_prefix_lb_1211  1
    load_1_9_8  segment_prefix_ub_1212  1
    load_1_9_8  segment_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_997  -25
    arc_1_9_10  connected_order_arc_998  -12
    arc_1_9_10  out_degree_1213  1
    arc_1_9_10  in_degree_1221  1
    arc_1_9_10  original_T_including_depot_unload_1277  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_997  1
    load_1_9_10  segment_load_conservation_1217  1
    load_1_9_10  segment_load_conservation_1224  -1
    load_1_9_10  segment_prefix_lb_1225  1
    load_1_9_10  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_999  -25
    arc_1_9_15  connected_order_arc_1000  -12
    arc_1_9_15  out_degree_1213  1
    arc_1_9_15  in_degree_1228  1
    arc_1_9_15  original_T_including_depot_unload_1277  1.4641668022187741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_999  1
    load_1_9_15  segment_load_conservation_1217  1
    load_1_9_15  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_1001  -25
    arc_1_9_16  connected_order_arc_1002  -12
    arc_1_9_16  out_degree_1213  1
    arc_1_9_16  in_degree_1234  1
    arc_1_9_16  original_T_including_depot_unload_1277  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_1001  1
    load_1_9_16  segment_load_conservation_1217  1
    load_1_9_16  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_1003  -25
    arc_1_9_17  connected_order_arc_1004  -12
    arc_1_9_17  out_degree_1213  1
    arc_1_9_17  in_degree_1240  1
    arc_1_9_17  original_T_including_depot_unload_1277  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_1003  1
    load_1_9_17  segment_load_conservation_1217  1
    load_1_9_17  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_1005  -25
    arc_1_9_18  connected_order_arc_1006  -12
    arc_1_9_18  out_degree_1213  1
    arc_1_9_18  in_degree_1246  1
    arc_1_9_18  original_T_including_depot_unload_1277  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_1005  1
    load_1_9_18  segment_load_conservation_1217  1
    load_1_9_18  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_1007  -25
    arc_1_9_19  connected_order_arc_1008  -12
    arc_1_9_19  out_degree_1213  1
    arc_1_9_19  in_degree_1252  1
    arc_1_9_19  original_T_including_depot_unload_1277  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_1007  1
    load_1_9_19  segment_load_conservation_1217  1
    load_1_9_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_1009  -25
    arc_1_9_20  connected_order_arc_1010  -12
    arc_1_9_20  out_degree_1213  1
    arc_1_9_20  in_degree_1258  1
    arc_1_9_20  original_T_including_depot_unload_1277  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_1009  1
    load_1_9_20  segment_load_conservation_1217  1
    load_1_9_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_1011  -25
    arc_1_9_21  connected_order_arc_1012  -12
    arc_1_9_21  out_degree_1213  1
    arc_1_9_21  in_degree_1264  1
    arc_1_9_21  original_T_including_depot_unload_1277  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_1011  1
    load_1_9_21  segment_load_conservation_1217  1
    load_1_9_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_1013  -25
    arc_1_9_22  connected_order_arc_1014  -12
    arc_1_9_22  out_degree_1213  1
    arc_1_9_22  in_degree_1270  1
    arc_1_9_22  original_T_including_depot_unload_1277  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_1013  1
    load_1_9_22  segment_load_conservation_1217  1
    load_1_9_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1015  -25
    arc_1_10_0  depot_return_or_bypass_1205  1
    arc_1_10_0  out_degree_1220  1
    arc_1_10_0  original_T_including_depot_unload_1277  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1015  1
    load_1_10_0  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_1016  -25
    arc_1_10_8  connected_order_arc_1017  -12
    arc_1_10_8  in_degree_1207  1
    arc_1_10_8  out_degree_1220  1
    arc_1_10_8  original_T_including_depot_unload_1277  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_1016  1
    load_1_10_8  segment_load_conservation_1210  -1
    load_1_10_8  segment_prefix_lb_1211  1
    load_1_10_8  segment_prefix_ub_1212  1
    load_1_10_8  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1018  -25
    arc_1_10_9  connected_order_arc_1019  -12
    arc_1_10_9  in_degree_1214  1
    arc_1_10_9  out_degree_1220  1
    arc_1_10_9  original_T_including_depot_unload_1277  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1018  1
    load_1_10_9  segment_load_conservation_1217  -1
    load_1_10_9  segment_prefix_lb_1218  1
    load_1_10_9  segment_prefix_ub_1219  1
    load_1_10_9  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1020  -25
    arc_1_10_15  connected_order_arc_1021  -12
    arc_1_10_15  out_degree_1220  1
    arc_1_10_15  in_degree_1228  1
    arc_1_10_15  original_T_including_depot_unload_1277  1.7679982083227121e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1020  1
    load_1_10_15  segment_load_conservation_1224  1
    load_1_10_15  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1022  -25
    arc_1_10_16  connected_order_arc_1023  -12
    arc_1_10_16  out_degree_1220  1
    arc_1_10_16  in_degree_1234  1
    arc_1_10_16  original_T_including_depot_unload_1277  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1022  1
    load_1_10_16  segment_load_conservation_1224  1
    load_1_10_16  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1024  -25
    arc_1_10_17  connected_order_arc_1025  -12
    arc_1_10_17  out_degree_1220  1
    arc_1_10_17  in_degree_1240  1
    arc_1_10_17  original_T_including_depot_unload_1277  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1024  1
    load_1_10_17  segment_load_conservation_1224  1
    load_1_10_17  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1026  -25
    arc_1_10_18  connected_order_arc_1027  -12
    arc_1_10_18  out_degree_1220  1
    arc_1_10_18  in_degree_1246  1
    arc_1_10_18  original_T_including_depot_unload_1277  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1026  1
    load_1_10_18  segment_load_conservation_1224  1
    load_1_10_18  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1028  -25
    arc_1_10_19  connected_order_arc_1029  -12
    arc_1_10_19  out_degree_1220  1
    arc_1_10_19  in_degree_1252  1
    arc_1_10_19  original_T_including_depot_unload_1277  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1028  1
    load_1_10_19  segment_load_conservation_1224  1
    load_1_10_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1030  -25
    arc_1_10_20  connected_order_arc_1031  -12
    arc_1_10_20  out_degree_1220  1
    arc_1_10_20  in_degree_1258  1
    arc_1_10_20  original_T_including_depot_unload_1277  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1030  1
    load_1_10_20  segment_load_conservation_1224  1
    load_1_10_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1032  -25
    arc_1_10_21  connected_order_arc_1033  -12
    arc_1_10_21  out_degree_1220  1
    arc_1_10_21  in_degree_1264  1
    arc_1_10_21  original_T_including_depot_unload_1277  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1032  1
    load_1_10_21  segment_load_conservation_1224  1
    load_1_10_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_1034  -25
    arc_1_10_22  connected_order_arc_1035  -12
    arc_1_10_22  out_degree_1220  1
    arc_1_10_22  in_degree_1270  1
    arc_1_10_22  original_T_including_depot_unload_1277  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_1034  1
    load_1_10_22  segment_load_conservation_1224  1
    load_1_10_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1036  -25
    arc_1_15_0  depot_return_or_bypass_1205  1
    arc_1_15_0  out_degree_1227  1
    arc_1_15_0  original_T_including_depot_unload_1277  1.9654373797357937e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1036  1
    load_1_15_0  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1037  -25
    arc_1_15_8  connected_order_arc_1038  -12
    arc_1_15_8  in_degree_1207  1
    arc_1_15_8  out_degree_1227  1
    arc_1_15_8  original_T_including_depot_unload_1277  2.5663749241687369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1037  1
    load_1_15_8  segment_load_conservation_1210  -1
    load_1_15_8  segment_prefix_lb_1211  1
    load_1_15_8  segment_prefix_ub_1212  1
    load_1_15_8  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1039  -25
    arc_1_15_9  connected_order_arc_1040  -12
    arc_1_15_9  in_degree_1214  1
    arc_1_15_9  out_degree_1227  1
    arc_1_15_9  original_T_including_depot_unload_1277  1.4641668022187741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1039  1
    load_1_15_9  segment_load_conservation_1217  -1
    load_1_15_9  segment_prefix_lb_1218  1
    load_1_15_9  segment_prefix_ub_1219  1
    load_1_15_9  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1041  -25
    arc_1_15_10  connected_order_arc_1042  -12
    arc_1_15_10  in_degree_1221  1
    arc_1_15_10  out_degree_1227  1
    arc_1_15_10  original_T_including_depot_unload_1277  1.7679982083227121e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1041  1
    load_1_15_10  segment_load_conservation_1224  -1
    load_1_15_10  segment_prefix_lb_1225  1
    load_1_15_10  segment_prefix_ub_1226  1
    load_1_15_10  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1043  -25
    arc_1_15_16  connected_order_arc_1044  -12
    arc_1_15_16  out_degree_1227  1
    arc_1_15_16  in_degree_1234  1
    arc_1_15_16  original_T_including_depot_unload_1277  4.9108306779271851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1043  1
    load_1_15_16  free_load_conservation_1232  1
    load_1_15_16  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1045  -25
    arc_1_15_17  connected_order_arc_1046  -12
    arc_1_15_17  out_degree_1227  1
    arc_1_15_17  in_degree_1240  1
    arc_1_15_17  original_T_including_depot_unload_1277  3.4294674949374580e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1045  1
    load_1_15_17  free_load_conservation_1232  1
    load_1_15_17  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1047  -25
    arc_1_15_18  connected_order_arc_1048  -12
    arc_1_15_18  out_degree_1227  1
    arc_1_15_18  in_degree_1246  1
    arc_1_15_18  original_T_including_depot_unload_1277  8.0990517952185235e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1047  1
    load_1_15_18  free_load_conservation_1232  1
    load_1_15_18  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1049  -25
    arc_1_15_19  connected_order_arc_1050  -12
    arc_1_15_19  out_degree_1227  1
    arc_1_15_19  in_degree_1252  1
    arc_1_15_19  original_T_including_depot_unload_1277  2.3897696160028909e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1049  1
    load_1_15_19  free_load_conservation_1232  1
    load_1_15_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1051  -25
    arc_1_15_20  connected_order_arc_1052  -12
    arc_1_15_20  out_degree_1227  1
    arc_1_15_20  in_degree_1258  1
    arc_1_15_20  original_T_including_depot_unload_1277  8.8284459023081490e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1051  1
    load_1_15_20  free_load_conservation_1232  1
    load_1_15_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1053  -25
    arc_1_15_21  connected_order_arc_1054  -12
    arc_1_15_21  out_degree_1227  1
    arc_1_15_21  in_degree_1264  1
    arc_1_15_21  original_T_including_depot_unload_1277  2.8013754919345556e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1053  1
    load_1_15_21  free_load_conservation_1232  1
    load_1_15_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_1055  -25
    arc_1_15_22  connected_order_arc_1056  -12
    arc_1_15_22  out_degree_1227  1
    arc_1_15_22  in_degree_1270  1
    arc_1_15_22  original_T_including_depot_unload_1277  1.0617037707898505e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_1055  1
    load_1_15_22  free_load_conservation_1232  1
    load_1_15_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1057  -25
    arc_1_16_0  depot_return_or_bypass_1205  1
    arc_1_16_0  out_degree_1233  1
    arc_1_16_0  original_T_including_depot_unload_1277  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1057  1
    load_1_16_0  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1058  -25
    arc_1_16_8  connected_order_arc_1059  -12
    arc_1_16_8  in_degree_1207  1
    arc_1_16_8  out_degree_1233  1
    arc_1_16_8  original_T_including_depot_unload_1277  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1058  1
    load_1_16_8  segment_load_conservation_1210  -1
    load_1_16_8  segment_prefix_lb_1211  1
    load_1_16_8  segment_prefix_ub_1212  1
    load_1_16_8  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1060  -25
    arc_1_16_9  connected_order_arc_1061  -12
    arc_1_16_9  in_degree_1214  1
    arc_1_16_9  out_degree_1233  1
    arc_1_16_9  original_T_including_depot_unload_1277  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1060  1
    load_1_16_9  segment_load_conservation_1217  -1
    load_1_16_9  segment_prefix_lb_1218  1
    load_1_16_9  segment_prefix_ub_1219  1
    load_1_16_9  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1062  -25
    arc_1_16_10  connected_order_arc_1063  -12
    arc_1_16_10  in_degree_1221  1
    arc_1_16_10  out_degree_1233  1
    arc_1_16_10  original_T_including_depot_unload_1277  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1062  1
    load_1_16_10  segment_load_conservation_1224  -1
    load_1_16_10  segment_prefix_lb_1225  1
    load_1_16_10  segment_prefix_ub_1226  1
    load_1_16_10  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1064  -25
    arc_1_16_15  connected_order_arc_1065  -12
    arc_1_16_15  in_degree_1228  1
    arc_1_16_15  out_degree_1233  1
    arc_1_16_15  original_T_including_depot_unload_1277  4.9108306779271851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1064  1
    load_1_16_15  free_load_conservation_1232  -1
    load_1_16_15  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1066  -25
    arc_1_16_17  connected_order_arc_1067  -12
    arc_1_16_17  out_degree_1233  1
    arc_1_16_17  in_degree_1240  1
    arc_1_16_17  original_T_including_depot_unload_1277  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1066  1
    load_1_16_17  free_load_conservation_1238  1
    load_1_16_17  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1068  -25
    arc_1_16_18  connected_order_arc_1069  -12
    arc_1_16_18  out_degree_1233  1
    arc_1_16_18  in_degree_1246  1
    arc_1_16_18  original_T_including_depot_unload_1277  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1068  1
    load_1_16_18  free_load_conservation_1238  1
    load_1_16_18  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1070  -25
    arc_1_16_19  connected_order_arc_1071  -12
    arc_1_16_19  out_degree_1233  1
    arc_1_16_19  in_degree_1252  1
    arc_1_16_19  original_T_including_depot_unload_1277  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1070  1
    load_1_16_19  free_load_conservation_1238  1
    load_1_16_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1072  -25
    arc_1_16_20  connected_order_arc_1073  -12
    arc_1_16_20  out_degree_1233  1
    arc_1_16_20  in_degree_1258  1
    arc_1_16_20  original_T_including_depot_unload_1277  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1072  1
    load_1_16_20  free_load_conservation_1238  1
    load_1_16_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1074  -25
    arc_1_16_21  connected_order_arc_1075  -12
    arc_1_16_21  out_degree_1233  1
    arc_1_16_21  in_degree_1264  1
    arc_1_16_21  original_T_including_depot_unload_1277  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1074  1
    load_1_16_21  free_load_conservation_1238  1
    load_1_16_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_1076  -25
    arc_1_16_22  connected_order_arc_1077  -12
    arc_1_16_22  out_degree_1233  1
    arc_1_16_22  in_degree_1270  1
    arc_1_16_22  original_T_including_depot_unload_1277  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_1076  1
    load_1_16_22  free_load_conservation_1238  1
    load_1_16_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1078  -25
    arc_1_17_0  depot_return_or_bypass_1205  1
    arc_1_17_0  out_degree_1239  1
    arc_1_17_0  original_T_including_depot_unload_1277  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1078  1
    load_1_17_0  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1079  -25
    arc_1_17_8  connected_order_arc_1080  -12
    arc_1_17_8  in_degree_1207  1
    arc_1_17_8  out_degree_1239  1
    arc_1_17_8  original_T_including_depot_unload_1277  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1079  1
    load_1_17_8  segment_load_conservation_1210  -1
    load_1_17_8  segment_prefix_lb_1211  1
    load_1_17_8  segment_prefix_ub_1212  1
    load_1_17_8  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1081  -25
    arc_1_17_9  connected_order_arc_1082  -12
    arc_1_17_9  in_degree_1214  1
    arc_1_17_9  out_degree_1239  1
    arc_1_17_9  original_T_including_depot_unload_1277  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1081  1
    load_1_17_9  segment_load_conservation_1217  -1
    load_1_17_9  segment_prefix_lb_1218  1
    load_1_17_9  segment_prefix_ub_1219  1
    load_1_17_9  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1083  -25
    arc_1_17_10  connected_order_arc_1084  -12
    arc_1_17_10  in_degree_1221  1
    arc_1_17_10  out_degree_1239  1
    arc_1_17_10  original_T_including_depot_unload_1277  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1083  1
    load_1_17_10  segment_load_conservation_1224  -1
    load_1_17_10  segment_prefix_lb_1225  1
    load_1_17_10  segment_prefix_ub_1226  1
    load_1_17_10  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1085  -25
    arc_1_17_15  connected_order_arc_1086  -12
    arc_1_17_15  in_degree_1228  1
    arc_1_17_15  out_degree_1239  1
    arc_1_17_15  original_T_including_depot_unload_1277  3.4294674949374580e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1085  1
    load_1_17_15  free_load_conservation_1232  -1
    load_1_17_15  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1087  -25
    arc_1_17_16  connected_order_arc_1088  -12
    arc_1_17_16  in_degree_1234  1
    arc_1_17_16  out_degree_1239  1
    arc_1_17_16  original_T_including_depot_unload_1277  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1087  1
    load_1_17_16  free_load_conservation_1238  -1
    load_1_17_16  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1089  -25
    arc_1_17_18  connected_order_arc_1090  -12
    arc_1_17_18  out_degree_1239  1
    arc_1_17_18  in_degree_1246  1
    arc_1_17_18  original_T_including_depot_unload_1277  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1089  1
    load_1_17_18  free_load_conservation_1244  1
    load_1_17_18  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1091  -25
    arc_1_17_19  connected_order_arc_1092  -12
    arc_1_17_19  out_degree_1239  1
    arc_1_17_19  in_degree_1252  1
    arc_1_17_19  original_T_including_depot_unload_1277  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1091  1
    load_1_17_19  free_load_conservation_1244  1
    load_1_17_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1093  -25
    arc_1_17_20  connected_order_arc_1094  -12
    arc_1_17_20  out_degree_1239  1
    arc_1_17_20  in_degree_1258  1
    arc_1_17_20  original_T_including_depot_unload_1277  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1093  1
    load_1_17_20  free_load_conservation_1244  1
    load_1_17_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1095  -25
    arc_1_17_21  connected_order_arc_1096  -12
    arc_1_17_21  out_degree_1239  1
    arc_1_17_21  in_degree_1264  1
    arc_1_17_21  original_T_including_depot_unload_1277  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1095  1
    load_1_17_21  free_load_conservation_1244  1
    load_1_17_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1097  -25
    arc_1_17_22  connected_order_arc_1098  -12
    arc_1_17_22  out_degree_1239  1
    arc_1_17_22  in_degree_1270  1
    arc_1_17_22  original_T_including_depot_unload_1277  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1097  1
    load_1_17_22  free_load_conservation_1244  1
    load_1_17_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1099  -25
    arc_1_18_0  depot_return_or_bypass_1205  1
    arc_1_18_0  out_degree_1245  1
    arc_1_18_0  original_T_including_depot_unload_1277  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1099  1
    load_1_18_0  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1100  -25
    arc_1_18_8  connected_order_arc_1101  -12
    arc_1_18_8  in_degree_1207  1
    arc_1_18_8  out_degree_1245  1
    arc_1_18_8  original_T_including_depot_unload_1277  1829.33035879167
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1100  1
    load_1_18_8  segment_load_conservation_1210  -1
    load_1_18_8  segment_prefix_lb_1211  1
    load_1_18_8  segment_prefix_ub_1212  1
    load_1_18_8  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1102  -25
    arc_1_18_9  connected_order_arc_1103  -12
    arc_1_18_9  in_degree_1214  1
    arc_1_18_9  out_degree_1245  1
    arc_1_18_9  original_T_including_depot_unload_1277  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1102  1
    load_1_18_9  segment_load_conservation_1217  -1
    load_1_18_9  segment_prefix_lb_1218  1
    load_1_18_9  segment_prefix_ub_1219  1
    load_1_18_9  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1104  -25
    arc_1_18_10  connected_order_arc_1105  -12
    arc_1_18_10  in_degree_1221  1
    arc_1_18_10  out_degree_1245  1
    arc_1_18_10  original_T_including_depot_unload_1277  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1104  1
    load_1_18_10  segment_load_conservation_1224  -1
    load_1_18_10  segment_prefix_lb_1225  1
    load_1_18_10  segment_prefix_ub_1226  1
    load_1_18_10  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1106  -25
    arc_1_18_15  connected_order_arc_1107  -12
    arc_1_18_15  in_degree_1228  1
    arc_1_18_15  out_degree_1245  1
    arc_1_18_15  original_T_including_depot_unload_1277  8.0990517952185235e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1106  1
    load_1_18_15  free_load_conservation_1232  -1
    load_1_18_15  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1108  -25
    arc_1_18_16  connected_order_arc_1109  -12
    arc_1_18_16  in_degree_1234  1
    arc_1_18_16  out_degree_1245  1
    arc_1_18_16  original_T_including_depot_unload_1277  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1108  1
    load_1_18_16  free_load_conservation_1238  -1
    load_1_18_16  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1110  -25
    arc_1_18_17  connected_order_arc_1111  -12
    arc_1_18_17  in_degree_1240  1
    arc_1_18_17  out_degree_1245  1
    arc_1_18_17  original_T_including_depot_unload_1277  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1110  1
    load_1_18_17  free_load_conservation_1244  -1
    load_1_18_17  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1112  -25
    arc_1_18_19  connected_order_arc_1113  -12
    arc_1_18_19  out_degree_1245  1
    arc_1_18_19  in_degree_1252  1
    arc_1_18_19  original_T_including_depot_unload_1277  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1112  1
    load_1_18_19  free_load_conservation_1250  1
    load_1_18_19  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1114  -25
    arc_1_18_20  connected_order_arc_1115  -12
    arc_1_18_20  out_degree_1245  1
    arc_1_18_20  in_degree_1258  1
    arc_1_18_20  original_T_including_depot_unload_1277  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1114  1
    load_1_18_20  free_load_conservation_1250  1
    load_1_18_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1116  -25
    arc_1_18_21  connected_order_arc_1117  -12
    arc_1_18_21  out_degree_1245  1
    arc_1_18_21  in_degree_1264  1
    arc_1_18_21  original_T_including_depot_unload_1277  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1116  1
    load_1_18_21  free_load_conservation_1250  1
    load_1_18_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1118  -25
    arc_1_18_22  connected_order_arc_1119  -12
    arc_1_18_22  out_degree_1245  1
    arc_1_18_22  in_degree_1270  1
    arc_1_18_22  original_T_including_depot_unload_1277  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1118  1
    load_1_18_22  free_load_conservation_1250  1
    load_1_18_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1120  -25
    arc_1_19_0  depot_return_or_bypass_1205  1
    arc_1_19_0  out_degree_1251  1
    arc_1_19_0  original_T_including_depot_unload_1277  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1120  1
    load_1_19_0  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1121  -25
    arc_1_19_8  connected_order_arc_1122  -12
    arc_1_19_8  in_degree_1207  1
    arc_1_19_8  out_degree_1251  1
    arc_1_19_8  original_T_including_depot_unload_1277  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1121  1
    load_1_19_8  segment_load_conservation_1210  -1
    load_1_19_8  segment_prefix_lb_1211  1
    load_1_19_8  segment_prefix_ub_1212  1
    load_1_19_8  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1123  -25
    arc_1_19_9  connected_order_arc_1124  -12
    arc_1_19_9  in_degree_1214  1
    arc_1_19_9  out_degree_1251  1
    arc_1_19_9  original_T_including_depot_unload_1277  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1123  1
    load_1_19_9  segment_load_conservation_1217  -1
    load_1_19_9  segment_prefix_lb_1218  1
    load_1_19_9  segment_prefix_ub_1219  1
    load_1_19_9  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1125  -25
    arc_1_19_10  connected_order_arc_1126  -12
    arc_1_19_10  in_degree_1221  1
    arc_1_19_10  out_degree_1251  1
    arc_1_19_10  original_T_including_depot_unload_1277  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1125  1
    load_1_19_10  segment_load_conservation_1224  -1
    load_1_19_10  segment_prefix_lb_1225  1
    load_1_19_10  segment_prefix_ub_1226  1
    load_1_19_10  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1127  -25
    arc_1_19_15  connected_order_arc_1128  -12
    arc_1_19_15  in_degree_1228  1
    arc_1_19_15  out_degree_1251  1
    arc_1_19_15  original_T_including_depot_unload_1277  2.3897696160028909e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1127  1
    load_1_19_15  free_load_conservation_1232  -1
    load_1_19_15  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1129  -25
    arc_1_19_16  connected_order_arc_1130  -12
    arc_1_19_16  in_degree_1234  1
    arc_1_19_16  out_degree_1251  1
    arc_1_19_16  original_T_including_depot_unload_1277  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1129  1
    load_1_19_16  free_load_conservation_1238  -1
    load_1_19_16  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1131  -25
    arc_1_19_17  connected_order_arc_1132  -12
    arc_1_19_17  in_degree_1240  1
    arc_1_19_17  out_degree_1251  1
    arc_1_19_17  original_T_including_depot_unload_1277  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1131  1
    load_1_19_17  free_load_conservation_1244  -1
    load_1_19_17  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1133  -25
    arc_1_19_18  connected_order_arc_1134  -12
    arc_1_19_18  in_degree_1246  1
    arc_1_19_18  out_degree_1251  1
    arc_1_19_18  original_T_including_depot_unload_1277  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1133  1
    load_1_19_18  free_load_conservation_1250  -1
    load_1_19_18  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1135  -25
    arc_1_19_20  connected_order_arc_1136  -12
    arc_1_19_20  out_degree_1251  1
    arc_1_19_20  in_degree_1258  1
    arc_1_19_20  original_T_including_depot_unload_1277  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1135  1
    load_1_19_20  free_load_conservation_1256  1
    load_1_19_20  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1137  -25
    arc_1_19_21  connected_order_arc_1138  -12
    arc_1_19_21  out_degree_1251  1
    arc_1_19_21  in_degree_1264  1
    arc_1_19_21  original_T_including_depot_unload_1277  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1137  1
    load_1_19_21  free_load_conservation_1256  1
    load_1_19_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1139  -25
    arc_1_19_22  connected_order_arc_1140  -12
    arc_1_19_22  out_degree_1251  1
    arc_1_19_22  in_degree_1270  1
    arc_1_19_22  original_T_including_depot_unload_1277  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1139  1
    load_1_19_22  free_load_conservation_1256  1
    load_1_19_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1141  -25
    arc_1_20_0  depot_return_or_bypass_1205  1
    arc_1_20_0  out_degree_1257  1
    arc_1_20_0  original_T_including_depot_unload_1277  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1141  1
    load_1_20_0  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1142  -25
    arc_1_20_8  connected_order_arc_1143  -12
    arc_1_20_8  in_degree_1207  1
    arc_1_20_8  out_degree_1257  1
    arc_1_20_8  original_T_including_depot_unload_1277  1.9270569168668533e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1142  1
    load_1_20_8  segment_load_conservation_1210  -1
    load_1_20_8  segment_prefix_lb_1211  1
    load_1_20_8  segment_prefix_ub_1212  1
    load_1_20_8  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1144  -25
    arc_1_20_9  connected_order_arc_1145  -12
    arc_1_20_9  in_degree_1214  1
    arc_1_20_9  out_degree_1257  1
    arc_1_20_9  original_T_including_depot_unload_1277  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1144  1
    load_1_20_9  segment_load_conservation_1217  -1
    load_1_20_9  segment_prefix_lb_1218  1
    load_1_20_9  segment_prefix_ub_1219  1
    load_1_20_9  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1146  -25
    arc_1_20_10  connected_order_arc_1147  -12
    arc_1_20_10  in_degree_1221  1
    arc_1_20_10  out_degree_1257  1
    arc_1_20_10  original_T_including_depot_unload_1277  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1146  1
    load_1_20_10  segment_load_conservation_1224  -1
    load_1_20_10  segment_prefix_lb_1225  1
    load_1_20_10  segment_prefix_ub_1226  1
    load_1_20_10  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1148  -25
    arc_1_20_15  connected_order_arc_1149  -12
    arc_1_20_15  in_degree_1228  1
    arc_1_20_15  out_degree_1257  1
    arc_1_20_15  original_T_including_depot_unload_1277  8.8284459023081490e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1148  1
    load_1_20_15  free_load_conservation_1232  -1
    load_1_20_15  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1150  -25
    arc_1_20_16  connected_order_arc_1151  -12
    arc_1_20_16  in_degree_1234  1
    arc_1_20_16  out_degree_1257  1
    arc_1_20_16  original_T_including_depot_unload_1277  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1150  1
    load_1_20_16  free_load_conservation_1238  -1
    load_1_20_16  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1152  -25
    arc_1_20_17  connected_order_arc_1153  -12
    arc_1_20_17  in_degree_1240  1
    arc_1_20_17  out_degree_1257  1
    arc_1_20_17  original_T_including_depot_unload_1277  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1152  1
    load_1_20_17  free_load_conservation_1244  -1
    load_1_20_17  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1154  -25
    arc_1_20_18  connected_order_arc_1155  -12
    arc_1_20_18  in_degree_1246  1
    arc_1_20_18  out_degree_1257  1
    arc_1_20_18  original_T_including_depot_unload_1277  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1154  1
    load_1_20_18  free_load_conservation_1250  -1
    load_1_20_18  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1156  -25
    arc_1_20_19  connected_order_arc_1157  -12
    arc_1_20_19  in_degree_1252  1
    arc_1_20_19  out_degree_1257  1
    arc_1_20_19  original_T_including_depot_unload_1277  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1156  1
    load_1_20_19  free_load_conservation_1256  -1
    load_1_20_19  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1158  -25
    arc_1_20_21  connected_order_arc_1159  -12
    arc_1_20_21  out_degree_1257  1
    arc_1_20_21  in_degree_1264  1
    arc_1_20_21  original_T_including_depot_unload_1277  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1158  1
    load_1_20_21  free_load_conservation_1262  1
    load_1_20_21  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1160  -25
    arc_1_20_22  connected_order_arc_1161  -12
    arc_1_20_22  out_degree_1257  1
    arc_1_20_22  in_degree_1270  1
    arc_1_20_22  original_T_including_depot_unload_1277  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1160  1
    load_1_20_22  free_load_conservation_1262  1
    load_1_20_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1162  -25
    arc_1_21_0  depot_return_or_bypass_1205  1
    arc_1_21_0  out_degree_1263  1
    arc_1_21_0  original_T_including_depot_unload_1277  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1162  1
    load_1_21_0  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1163  -25
    arc_1_21_8  connected_order_arc_1164  -12
    arc_1_21_8  in_degree_1207  1
    arc_1_21_8  out_degree_1263  1
    arc_1_21_8  original_T_including_depot_unload_1277  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1163  1
    load_1_21_8  segment_load_conservation_1210  -1
    load_1_21_8  segment_prefix_lb_1211  1
    load_1_21_8  segment_prefix_ub_1212  1
    load_1_21_8  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1165  -25
    arc_1_21_9  connected_order_arc_1166  -12
    arc_1_21_9  in_degree_1214  1
    arc_1_21_9  out_degree_1263  1
    arc_1_21_9  original_T_including_depot_unload_1277  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1165  1
    load_1_21_9  segment_load_conservation_1217  -1
    load_1_21_9  segment_prefix_lb_1218  1
    load_1_21_9  segment_prefix_ub_1219  1
    load_1_21_9  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1167  -25
    arc_1_21_10  connected_order_arc_1168  -12
    arc_1_21_10  in_degree_1221  1
    arc_1_21_10  out_degree_1263  1
    arc_1_21_10  original_T_including_depot_unload_1277  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1167  1
    load_1_21_10  segment_load_conservation_1224  -1
    load_1_21_10  segment_prefix_lb_1225  1
    load_1_21_10  segment_prefix_ub_1226  1
    load_1_21_10  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1169  -25
    arc_1_21_15  connected_order_arc_1170  -12
    arc_1_21_15  in_degree_1228  1
    arc_1_21_15  out_degree_1263  1
    arc_1_21_15  original_T_including_depot_unload_1277  2.8013754919345556e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1169  1
    load_1_21_15  free_load_conservation_1232  -1
    load_1_21_15  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1171  -25
    arc_1_21_16  connected_order_arc_1172  -12
    arc_1_21_16  in_degree_1234  1
    arc_1_21_16  out_degree_1263  1
    arc_1_21_16  original_T_including_depot_unload_1277  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1171  1
    load_1_21_16  free_load_conservation_1238  -1
    load_1_21_16  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1173  -25
    arc_1_21_17  connected_order_arc_1174  -12
    arc_1_21_17  in_degree_1240  1
    arc_1_21_17  out_degree_1263  1
    arc_1_21_17  original_T_including_depot_unload_1277  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1173  1
    load_1_21_17  free_load_conservation_1244  -1
    load_1_21_17  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1175  -25
    arc_1_21_18  connected_order_arc_1176  -12
    arc_1_21_18  in_degree_1246  1
    arc_1_21_18  out_degree_1263  1
    arc_1_21_18  original_T_including_depot_unload_1277  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1175  1
    load_1_21_18  free_load_conservation_1250  -1
    load_1_21_18  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1177  -25
    arc_1_21_19  connected_order_arc_1178  -12
    arc_1_21_19  in_degree_1252  1
    arc_1_21_19  out_degree_1263  1
    arc_1_21_19  original_T_including_depot_unload_1277  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1177  1
    load_1_21_19  free_load_conservation_1256  -1
    load_1_21_19  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1179  -25
    arc_1_21_20  connected_order_arc_1180  -12
    arc_1_21_20  in_degree_1258  1
    arc_1_21_20  out_degree_1263  1
    arc_1_21_20  original_T_including_depot_unload_1277  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1179  1
    load_1_21_20  free_load_conservation_1262  -1
    load_1_21_20  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1181  -25
    arc_1_21_22  connected_order_arc_1182  -12
    arc_1_21_22  out_degree_1263  1
    arc_1_21_22  in_degree_1270  1
    arc_1_21_22  original_T_including_depot_unload_1277  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1181  1
    load_1_21_22  free_load_conservation_1268  1
    load_1_21_22  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1183  -25
    arc_1_22_0  depot_return_or_bypass_1205  1
    arc_1_22_0  out_degree_1269  1
    arc_1_22_0  original_T_including_depot_unload_1277  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1183  1
    load_1_22_0  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1184  -25
    arc_1_22_8  connected_order_arc_1185  -12
    arc_1_22_8  in_degree_1207  1
    arc_1_22_8  out_degree_1269  1
    arc_1_22_8  original_T_including_depot_unload_1277  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1184  1
    load_1_22_8  segment_load_conservation_1210  -1
    load_1_22_8  segment_prefix_lb_1211  1
    load_1_22_8  segment_prefix_ub_1212  1
    load_1_22_8  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1186  -25
    arc_1_22_9  connected_order_arc_1187  -12
    arc_1_22_9  in_degree_1214  1
    arc_1_22_9  out_degree_1269  1
    arc_1_22_9  original_T_including_depot_unload_1277  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1186  1
    load_1_22_9  segment_load_conservation_1217  -1
    load_1_22_9  segment_prefix_lb_1218  1
    load_1_22_9  segment_prefix_ub_1219  1
    load_1_22_9  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1188  -25
    arc_1_22_10  connected_order_arc_1189  -12
    arc_1_22_10  in_degree_1221  1
    arc_1_22_10  out_degree_1269  1
    arc_1_22_10  original_T_including_depot_unload_1277  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1188  1
    load_1_22_10  segment_load_conservation_1224  -1
    load_1_22_10  segment_prefix_lb_1225  1
    load_1_22_10  segment_prefix_ub_1226  1
    load_1_22_10  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1190  -25
    arc_1_22_15  connected_order_arc_1191  -12
    arc_1_22_15  in_degree_1228  1
    arc_1_22_15  out_degree_1269  1
    arc_1_22_15  original_T_including_depot_unload_1277  1.0617037707898505e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1190  1
    load_1_22_15  free_load_conservation_1232  -1
    load_1_22_15  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1192  -25
    arc_1_22_16  connected_order_arc_1193  -12
    arc_1_22_16  in_degree_1234  1
    arc_1_22_16  out_degree_1269  1
    arc_1_22_16  original_T_including_depot_unload_1277  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1192  1
    load_1_22_16  free_load_conservation_1238  -1
    load_1_22_16  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1194  -25
    arc_1_22_17  connected_order_arc_1195  -12
    arc_1_22_17  in_degree_1240  1
    arc_1_22_17  out_degree_1269  1
    arc_1_22_17  original_T_including_depot_unload_1277  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1194  1
    load_1_22_17  free_load_conservation_1244  -1
    load_1_22_17  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1196  -25
    arc_1_22_18  connected_order_arc_1197  -12
    arc_1_22_18  in_degree_1246  1
    arc_1_22_18  out_degree_1269  1
    arc_1_22_18  original_T_including_depot_unload_1277  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1196  1
    load_1_22_18  free_load_conservation_1250  -1
    load_1_22_18  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1198  -25
    arc_1_22_19  connected_order_arc_1199  -12
    arc_1_22_19  in_degree_1252  1
    arc_1_22_19  out_degree_1269  1
    arc_1_22_19  original_T_including_depot_unload_1277  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1198  1
    load_1_22_19  free_load_conservation_1256  -1
    load_1_22_19  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1200  -25
    arc_1_22_20  connected_order_arc_1201  -12
    arc_1_22_20  in_degree_1258  1
    arc_1_22_20  out_degree_1269  1
    arc_1_22_20  original_T_including_depot_unload_1277  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1200  1
    load_1_22_20  free_load_conservation_1262  -1
    load_1_22_20  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1202  -25
    arc_1_22_21  connected_order_arc_1203  -12
    arc_1_22_21  in_degree_1264  1
    arc_1_22_21  out_degree_1269  1
    arc_1_22_21  original_T_including_depot_unload_1277  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1202  1
    load_1_22_21  free_load_conservation_1268  -1
    load_1_22_21  free_load_conservation_1274  1
    visit_2_11  out_degree_1569  -1
    visit_2_11  in_degree_1570  -1
    visit_2_11  order_active_lb_1571  -1
    visit_2_11  order_active_ub_1572  -12
    order_2_11  connected_order_arc_1293  -1
    order_2_11  connected_order_arc_1295  -1
    order_2_11  connected_order_arc_1297  -1
    order_2_11  connected_order_arc_1299  -1
    order_2_11  connected_order_arc_1301  -1
    order_2_11  connected_order_arc_1303  -1
    order_2_11  connected_order_arc_1305  -1
    order_2_11  connected_order_arc_1307  -1
    order_2_11  connected_order_arc_1309  -1
    order_2_11  connected_order_arc_1311  -1
    order_2_11  connected_order_arc_1313  -1
    order_2_11  connected_order_arc_1316  1
    order_2_11  connected_order_arc_1339  1
    order_2_11  connected_order_arc_1362  1
    order_2_11  connected_order_arc_1385  1
    order_2_11  connected_order_arc_1408  1
    order_2_11  connected_order_arc_1431  1
    order_2_11  connected_order_arc_1454  1
    order_2_11  connected_order_arc_1477  1
    order_2_11  connected_order_arc_1500  1
    order_2_11  connected_order_arc_1523  1
    order_2_11  connected_order_arc_1546  1
    order_2_11  order_active_lb_1571  1
    order_2_11  order_active_ub_1572  1
    order_2_11  fixed_segment_relative_order_1645  -1
    visit_2_12  out_degree_1576  -1
    visit_2_12  in_degree_1577  -1
    visit_2_12  order_active_lb_1578  -1
    visit_2_12  order_active_ub_1579  -12
    order_2_12  connected_order_arc_1293  1
    order_2_12  connected_order_arc_1316  -1
    order_2_12  connected_order_arc_1318  -1
    order_2_12  connected_order_arc_1320  -1
    order_2_12  connected_order_arc_1322  -1
    order_2_12  connected_order_arc_1324  -1
    order_2_12  connected_order_arc_1326  -1
    order_2_12  connected_order_arc_1328  -1
    order_2_12  connected_order_arc_1330  -1
    order_2_12  connected_order_arc_1332  -1
    order_2_12  connected_order_arc_1334  -1
    order_2_12  connected_order_arc_1336  -1
    order_2_12  connected_order_arc_1341  1
    order_2_12  connected_order_arc_1364  1
    order_2_12  connected_order_arc_1387  1
    order_2_12  connected_order_arc_1410  1
    order_2_12  connected_order_arc_1433  1
    order_2_12  connected_order_arc_1456  1
    order_2_12  connected_order_arc_1479  1
    order_2_12  connected_order_arc_1502  1
    order_2_12  connected_order_arc_1525  1
    order_2_12  connected_order_arc_1548  1
    order_2_12  order_active_lb_1578  1
    order_2_12  order_active_ub_1579  1
    order_2_12  fixed_segment_relative_order_1645  1
    order_2_12  fixed_segment_relative_order_1646  -1
    visit_2_13  out_degree_1583  -1
    visit_2_13  in_degree_1584  -1
    visit_2_13  order_active_lb_1585  -1
    visit_2_13  order_active_ub_1586  -12
    order_2_13  connected_order_arc_1295  1
    order_2_13  connected_order_arc_1318  1
    order_2_13  connected_order_arc_1339  -1
    order_2_13  connected_order_arc_1341  -1
    order_2_13  connected_order_arc_1343  -1
    order_2_13  connected_order_arc_1345  -1
    order_2_13  connected_order_arc_1347  -1
    order_2_13  connected_order_arc_1349  -1
    order_2_13  connected_order_arc_1351  -1
    order_2_13  connected_order_arc_1353  -1
    order_2_13  connected_order_arc_1355  -1
    order_2_13  connected_order_arc_1357  -1
    order_2_13  connected_order_arc_1359  -1
    order_2_13  connected_order_arc_1366  1
    order_2_13  connected_order_arc_1389  1
    order_2_13  connected_order_arc_1412  1
    order_2_13  connected_order_arc_1435  1
    order_2_13  connected_order_arc_1458  1
    order_2_13  connected_order_arc_1481  1
    order_2_13  connected_order_arc_1504  1
    order_2_13  connected_order_arc_1527  1
    order_2_13  connected_order_arc_1550  1
    order_2_13  order_active_lb_1585  1
    order_2_13  order_active_ub_1586  1
    order_2_13  fixed_segment_relative_order_1646  1
    order_2_13  fixed_segment_relative_order_1647  -1
    visit_2_14  out_degree_1590  -1
    visit_2_14  in_degree_1591  -1
    visit_2_14  order_active_lb_1592  -1
    visit_2_14  order_active_ub_1593  -12
    order_2_14  connected_order_arc_1297  1
    order_2_14  connected_order_arc_1320  1
    order_2_14  connected_order_arc_1343  1
    order_2_14  connected_order_arc_1362  -1
    order_2_14  connected_order_arc_1364  -1
    order_2_14  connected_order_arc_1366  -1
    order_2_14  connected_order_arc_1368  -1
    order_2_14  connected_order_arc_1370  -1
    order_2_14  connected_order_arc_1372  -1
    order_2_14  connected_order_arc_1374  -1
    order_2_14  connected_order_arc_1376  -1
    order_2_14  connected_order_arc_1378  -1
    order_2_14  connected_order_arc_1380  -1
    order_2_14  connected_order_arc_1382  -1
    order_2_14  connected_order_arc_1391  1
    order_2_14  connected_order_arc_1414  1
    order_2_14  connected_order_arc_1437  1
    order_2_14  connected_order_arc_1460  1
    order_2_14  connected_order_arc_1483  1
    order_2_14  connected_order_arc_1506  1
    order_2_14  connected_order_arc_1529  1
    order_2_14  connected_order_arc_1552  1
    order_2_14  order_active_lb_1592  1
    order_2_14  order_active_ub_1593  1
    order_2_14  fixed_segment_relative_order_1647  1
    visit_2_15  out_degree_1597  -1
    visit_2_15  in_degree_1598  -1
    visit_2_15  order_active_lb_1599  -1
    visit_2_15  order_active_ub_1600  -12
    visit_2_15  service_visit_def_1601  -1
    order_2_15  connected_order_arc_1299  1
    order_2_15  connected_order_arc_1322  1
    order_2_15  connected_order_arc_1345  1
    order_2_15  connected_order_arc_1368  1
    order_2_15  connected_order_arc_1385  -1
    order_2_15  connected_order_arc_1387  -1
    order_2_15  connected_order_arc_1389  -1
    order_2_15  connected_order_arc_1391  -1
    order_2_15  connected_order_arc_1393  -1
    order_2_15  connected_order_arc_1395  -1
    order_2_15  connected_order_arc_1397  -1
    order_2_15  connected_order_arc_1399  -1
    order_2_15  connected_order_arc_1401  -1
    order_2_15  connected_order_arc_1403  -1
    order_2_15  connected_order_arc_1405  -1
    order_2_15  connected_order_arc_1416  1
    order_2_15  connected_order_arc_1439  1
    order_2_15  connected_order_arc_1462  1
    order_2_15  connected_order_arc_1485  1
    order_2_15  connected_order_arc_1508  1
    order_2_15  connected_order_arc_1531  1
    order_2_15  connected_order_arc_1554  1
    order_2_15  order_active_lb_1599  1
    order_2_15  order_active_ub_1600  1
    visit_2_16  out_degree_1603  -1
    visit_2_16  in_degree_1604  -1
    visit_2_16  order_active_lb_1605  -1
    visit_2_16  order_active_ub_1606  -12
    visit_2_16  service_visit_def_1607  -1
    order_2_16  connected_order_arc_1301  1
    order_2_16  connected_order_arc_1324  1
    order_2_16  connected_order_arc_1347  1
    order_2_16  connected_order_arc_1370  1
    order_2_16  connected_order_arc_1393  1
    order_2_16  connected_order_arc_1408  -1
    order_2_16  connected_order_arc_1410  -1
    order_2_16  connected_order_arc_1412  -1
    order_2_16  connected_order_arc_1414  -1
    order_2_16  connected_order_arc_1416  -1
    order_2_16  connected_order_arc_1418  -1
    order_2_16  connected_order_arc_1420  -1
    order_2_16  connected_order_arc_1422  -1
    order_2_16  connected_order_arc_1424  -1
    order_2_16  connected_order_arc_1426  -1
    order_2_16  connected_order_arc_1428  -1
    order_2_16  connected_order_arc_1441  1
    order_2_16  connected_order_arc_1464  1
    order_2_16  connected_order_arc_1487  1
    order_2_16  connected_order_arc_1510  1
    order_2_16  connected_order_arc_1533  1
    order_2_16  connected_order_arc_1556  1
    order_2_16  order_active_lb_1605  1
    order_2_16  order_active_ub_1606  1
    visit_2_17  out_degree_1609  -1
    visit_2_17  in_degree_1610  -1
    visit_2_17  order_active_lb_1611  -1
    visit_2_17  order_active_ub_1612  -12
    visit_2_17  service_visit_def_1613  -1
    order_2_17  connected_order_arc_1303  1
    order_2_17  connected_order_arc_1326  1
    order_2_17  connected_order_arc_1349  1
    order_2_17  connected_order_arc_1372  1
    order_2_17  connected_order_arc_1395  1
    order_2_17  connected_order_arc_1418  1
    order_2_17  connected_order_arc_1431  -1
    order_2_17  connected_order_arc_1433  -1
    order_2_17  connected_order_arc_1435  -1
    order_2_17  connected_order_arc_1437  -1
    order_2_17  connected_order_arc_1439  -1
    order_2_17  connected_order_arc_1441  -1
    order_2_17  connected_order_arc_1443  -1
    order_2_17  connected_order_arc_1445  -1
    order_2_17  connected_order_arc_1447  -1
    order_2_17  connected_order_arc_1449  -1
    order_2_17  connected_order_arc_1451  -1
    order_2_17  connected_order_arc_1466  1
    order_2_17  connected_order_arc_1489  1
    order_2_17  connected_order_arc_1512  1
    order_2_17  connected_order_arc_1535  1
    order_2_17  connected_order_arc_1558  1
    order_2_17  order_active_lb_1611  1
    order_2_17  order_active_ub_1612  1
    visit_2_18  out_degree_1615  -1
    visit_2_18  in_degree_1616  -1
    visit_2_18  order_active_lb_1617  -1
    visit_2_18  order_active_ub_1618  -12
    visit_2_18  service_visit_def_1619  -1
    order_2_18  connected_order_arc_1305  1
    order_2_18  connected_order_arc_1328  1
    order_2_18  connected_order_arc_1351  1
    order_2_18  connected_order_arc_1374  1
    order_2_18  connected_order_arc_1397  1
    order_2_18  connected_order_arc_1420  1
    order_2_18  connected_order_arc_1443  1
    order_2_18  connected_order_arc_1454  -1
    order_2_18  connected_order_arc_1456  -1
    order_2_18  connected_order_arc_1458  -1
    order_2_18  connected_order_arc_1460  -1
    order_2_18  connected_order_arc_1462  -1
    order_2_18  connected_order_arc_1464  -1
    order_2_18  connected_order_arc_1466  -1
    order_2_18  connected_order_arc_1468  -1
    order_2_18  connected_order_arc_1470  -1
    order_2_18  connected_order_arc_1472  -1
    order_2_18  connected_order_arc_1474  -1
    order_2_18  connected_order_arc_1491  1
    order_2_18  connected_order_arc_1514  1
    order_2_18  connected_order_arc_1537  1
    order_2_18  connected_order_arc_1560  1
    order_2_18  order_active_lb_1617  1
    order_2_18  order_active_ub_1618  1
    visit_2_19  out_degree_1621  -1
    visit_2_19  in_degree_1622  -1
    visit_2_19  order_active_lb_1623  -1
    visit_2_19  order_active_ub_1624  -12
    visit_2_19  service_visit_def_1625  -1
    order_2_19  connected_order_arc_1307  1
    order_2_19  connected_order_arc_1330  1
    order_2_19  connected_order_arc_1353  1
    order_2_19  connected_order_arc_1376  1
    order_2_19  connected_order_arc_1399  1
    order_2_19  connected_order_arc_1422  1
    order_2_19  connected_order_arc_1445  1
    order_2_19  connected_order_arc_1468  1
    order_2_19  connected_order_arc_1477  -1
    order_2_19  connected_order_arc_1479  -1
    order_2_19  connected_order_arc_1481  -1
    order_2_19  connected_order_arc_1483  -1
    order_2_19  connected_order_arc_1485  -1
    order_2_19  connected_order_arc_1487  -1
    order_2_19  connected_order_arc_1489  -1
    order_2_19  connected_order_arc_1491  -1
    order_2_19  connected_order_arc_1493  -1
    order_2_19  connected_order_arc_1495  -1
    order_2_19  connected_order_arc_1497  -1
    order_2_19  connected_order_arc_1516  1
    order_2_19  connected_order_arc_1539  1
    order_2_19  connected_order_arc_1562  1
    order_2_19  order_active_lb_1623  1
    order_2_19  order_active_ub_1624  1
    visit_2_20  out_degree_1627  -1
    visit_2_20  in_degree_1628  -1
    visit_2_20  order_active_lb_1629  -1
    visit_2_20  order_active_ub_1630  -12
    visit_2_20  service_visit_def_1631  -1
    order_2_20  connected_order_arc_1309  1
    order_2_20  connected_order_arc_1332  1
    order_2_20  connected_order_arc_1355  1
    order_2_20  connected_order_arc_1378  1
    order_2_20  connected_order_arc_1401  1
    order_2_20  connected_order_arc_1424  1
    order_2_20  connected_order_arc_1447  1
    order_2_20  connected_order_arc_1470  1
    order_2_20  connected_order_arc_1493  1
    order_2_20  connected_order_arc_1500  -1
    order_2_20  connected_order_arc_1502  -1
    order_2_20  connected_order_arc_1504  -1
    order_2_20  connected_order_arc_1506  -1
    order_2_20  connected_order_arc_1508  -1
    order_2_20  connected_order_arc_1510  -1
    order_2_20  connected_order_arc_1512  -1
    order_2_20  connected_order_arc_1514  -1
    order_2_20  connected_order_arc_1516  -1
    order_2_20  connected_order_arc_1518  -1
    order_2_20  connected_order_arc_1520  -1
    order_2_20  connected_order_arc_1541  1
    order_2_20  connected_order_arc_1564  1
    order_2_20  order_active_lb_1629  1
    order_2_20  order_active_ub_1630  1
    visit_2_21  out_degree_1633  -1
    visit_2_21  in_degree_1634  -1
    visit_2_21  order_active_lb_1635  -1
    visit_2_21  order_active_ub_1636  -12
    visit_2_21  service_visit_def_1637  -1
    order_2_21  connected_order_arc_1311  1
    order_2_21  connected_order_arc_1334  1
    order_2_21  connected_order_arc_1357  1
    order_2_21  connected_order_arc_1380  1
    order_2_21  connected_order_arc_1403  1
    order_2_21  connected_order_arc_1426  1
    order_2_21  connected_order_arc_1449  1
    order_2_21  connected_order_arc_1472  1
    order_2_21  connected_order_arc_1495  1
    order_2_21  connected_order_arc_1518  1
    order_2_21  connected_order_arc_1523  -1
    order_2_21  connected_order_arc_1525  -1
    order_2_21  connected_order_arc_1527  -1
    order_2_21  connected_order_arc_1529  -1
    order_2_21  connected_order_arc_1531  -1
    order_2_21  connected_order_arc_1533  -1
    order_2_21  connected_order_arc_1535  -1
    order_2_21  connected_order_arc_1537  -1
    order_2_21  connected_order_arc_1539  -1
    order_2_21  connected_order_arc_1541  -1
    order_2_21  connected_order_arc_1543  -1
    order_2_21  connected_order_arc_1566  1
    order_2_21  order_active_lb_1635  1
    order_2_21  order_active_ub_1636  1
    visit_2_22  out_degree_1639  -1
    visit_2_22  in_degree_1640  -1
    visit_2_22  order_active_lb_1641  -1
    visit_2_22  order_active_ub_1642  -12
    visit_2_22  service_visit_def_1643  -1
    order_2_22  connected_order_arc_1313  1
    order_2_22  connected_order_arc_1336  1
    order_2_22  connected_order_arc_1359  1
    order_2_22  connected_order_arc_1382  1
    order_2_22  connected_order_arc_1405  1
    order_2_22  connected_order_arc_1428  1
    order_2_22  connected_order_arc_1451  1
    order_2_22  connected_order_arc_1474  1
    order_2_22  connected_order_arc_1497  1
    order_2_22  connected_order_arc_1520  1
    order_2_22  connected_order_arc_1543  1
    order_2_22  connected_order_arc_1546  -1
    order_2_22  connected_order_arc_1548  -1
    order_2_22  connected_order_arc_1550  -1
    order_2_22  connected_order_arc_1552  -1
    order_2_22  connected_order_arc_1554  -1
    order_2_22  connected_order_arc_1556  -1
    order_2_22  connected_order_arc_1558  -1
    order_2_22  connected_order_arc_1560  -1
    order_2_22  connected_order_arc_1562  -1
    order_2_22  connected_order_arc_1564  -1
    order_2_22  connected_order_arc_1566  -1
    order_2_22  order_active_lb_1641  1
    order_2_22  order_active_ub_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1278  -30
    arc_2_0_0  depot_departure_or_bypass_1567  1
    arc_2_0_0  depot_return_or_bypass_1568  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1278  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1279  -30
    arc_2_0_11  depot_departure_or_bypass_1567  1
    arc_2_0_11  in_degree_1570  1
    arc_2_0_11  original_T_including_depot_unload_1648  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1279  1
    load_2_0_11  segment_load_conservation_1573  -1
    load_2_0_11  segment_prefix_lb_1574  1
    load_2_0_11  segment_prefix_ub_1575  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1280  -30
    arc_2_0_12  depot_departure_or_bypass_1567  1
    arc_2_0_12  in_degree_1577  1
    arc_2_0_12  original_T_including_depot_unload_1648  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1280  1
    load_2_0_12  segment_load_conservation_1580  -1
    load_2_0_12  segment_prefix_lb_1581  1
    load_2_0_12  segment_prefix_ub_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1281  -30
    arc_2_0_13  depot_departure_or_bypass_1567  1
    arc_2_0_13  in_degree_1584  1
    arc_2_0_13  original_T_including_depot_unload_1648  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1281  1
    load_2_0_13  segment_load_conservation_1587  -1
    load_2_0_13  segment_prefix_lb_1588  1
    load_2_0_13  segment_prefix_ub_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1282  -30
    arc_2_0_14  depot_departure_or_bypass_1567  1
    arc_2_0_14  in_degree_1591  1
    arc_2_0_14  original_T_including_depot_unload_1648  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1282  1
    load_2_0_14  segment_load_conservation_1594  -1
    load_2_0_14  segment_prefix_lb_1595  1
    load_2_0_14  segment_prefix_ub_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1283  -30
    arc_2_0_15  depot_departure_or_bypass_1567  1
    arc_2_0_15  in_degree_1598  1
    arc_2_0_15  original_T_including_depot_unload_1648  1.9654373797357937e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1283  1
    load_2_0_15  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1284  -30
    arc_2_0_16  depot_departure_or_bypass_1567  1
    arc_2_0_16  in_degree_1604  1
    arc_2_0_16  original_T_including_depot_unload_1648  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1284  1
    load_2_0_16  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1285  -30
    arc_2_0_17  depot_departure_or_bypass_1567  1
    arc_2_0_17  in_degree_1610  1
    arc_2_0_17  original_T_including_depot_unload_1648  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1285  1
    load_2_0_17  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1286  -30
    arc_2_0_18  depot_departure_or_bypass_1567  1
    arc_2_0_18  in_degree_1616  1
    arc_2_0_18  original_T_including_depot_unload_1648  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1286  1
    load_2_0_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1287  -30
    arc_2_0_19  depot_departure_or_bypass_1567  1
    arc_2_0_19  in_degree_1622  1
    arc_2_0_19  original_T_including_depot_unload_1648  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1287  1
    load_2_0_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1288  -30
    arc_2_0_20  depot_departure_or_bypass_1567  1
    arc_2_0_20  in_degree_1628  1
    arc_2_0_20  original_T_including_depot_unload_1648  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1288  1
    load_2_0_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1289  -30
    arc_2_0_21  depot_departure_or_bypass_1567  1
    arc_2_0_21  in_degree_1634  1
    arc_2_0_21  original_T_including_depot_unload_1648  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1289  1
    load_2_0_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1290  -30
    arc_2_0_22  depot_departure_or_bypass_1567  1
    arc_2_0_22  in_degree_1640  1
    arc_2_0_22  original_T_including_depot_unload_1648  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1290  1
    load_2_0_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1291  -30
    arc_2_11_0  depot_return_or_bypass_1568  1
    arc_2_11_0  out_degree_1569  1
    arc_2_11_0  original_T_including_depot_unload_1648  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1291  1
    load_2_11_0  segment_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1292  -30
    arc_2_11_12  connected_order_arc_1293  -13
    arc_2_11_12  out_degree_1569  1
    arc_2_11_12  in_degree_1577  1
    arc_2_11_12  original_T_including_depot_unload_1648  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1292  1
    load_2_11_12  segment_load_conservation_1573  1
    load_2_11_12  segment_load_conservation_1580  -1
    load_2_11_12  segment_prefix_lb_1581  1
    load_2_11_12  segment_prefix_ub_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1294  -30
    arc_2_11_13  connected_order_arc_1295  -13
    arc_2_11_13  out_degree_1569  1
    arc_2_11_13  in_degree_1584  1
    arc_2_11_13  original_T_including_depot_unload_1648  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1294  1
    load_2_11_13  segment_load_conservation_1573  1
    load_2_11_13  segment_load_conservation_1587  -1
    load_2_11_13  segment_prefix_lb_1588  1
    load_2_11_13  segment_prefix_ub_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1296  -30
    arc_2_11_14  connected_order_arc_1297  -13
    arc_2_11_14  out_degree_1569  1
    arc_2_11_14  in_degree_1591  1
    arc_2_11_14  original_T_including_depot_unload_1648  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1296  1
    load_2_11_14  segment_load_conservation_1573  1
    load_2_11_14  segment_load_conservation_1594  -1
    load_2_11_14  segment_prefix_lb_1595  1
    load_2_11_14  segment_prefix_ub_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1298  -30
    arc_2_11_15  connected_order_arc_1299  -13
    arc_2_11_15  out_degree_1569  1
    arc_2_11_15  in_degree_1598  1
    arc_2_11_15  original_T_including_depot_unload_1648  2.7605151383884454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1298  1
    load_2_11_15  segment_load_conservation_1573  1
    load_2_11_15  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1300  -30
    arc_2_11_16  connected_order_arc_1301  -13
    arc_2_11_16  out_degree_1569  1
    arc_2_11_16  in_degree_1604  1
    arc_2_11_16  original_T_including_depot_unload_1648  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1300  1
    load_2_11_16  segment_load_conservation_1573  1
    load_2_11_16  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1302  -30
    arc_2_11_17  connected_order_arc_1303  -13
    arc_2_11_17  out_degree_1569  1
    arc_2_11_17  in_degree_1610  1
    arc_2_11_17  original_T_including_depot_unload_1648  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1302  1
    load_2_11_17  segment_load_conservation_1573  1
    load_2_11_17  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1304  -30
    arc_2_11_18  connected_order_arc_1305  -13
    arc_2_11_18  out_degree_1569  1
    arc_2_11_18  in_degree_1616  1
    arc_2_11_18  original_T_including_depot_unload_1648  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1304  1
    load_2_11_18  segment_load_conservation_1573  1
    load_2_11_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1306  -30
    arc_2_11_19  connected_order_arc_1307  -13
    arc_2_11_19  out_degree_1569  1
    arc_2_11_19  in_degree_1622  1
    arc_2_11_19  original_T_including_depot_unload_1648  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1306  1
    load_2_11_19  segment_load_conservation_1573  1
    load_2_11_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1308  -30
    arc_2_11_20  connected_order_arc_1309  -13
    arc_2_11_20  out_degree_1569  1
    arc_2_11_20  in_degree_1628  1
    arc_2_11_20  original_T_including_depot_unload_1648  1.9010369513971175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1308  1
    load_2_11_20  segment_load_conservation_1573  1
    load_2_11_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1310  -30
    arc_2_11_21  connected_order_arc_1311  -13
    arc_2_11_21  out_degree_1569  1
    arc_2_11_21  in_degree_1634  1
    arc_2_11_21  original_T_including_depot_unload_1648  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1310  1
    load_2_11_21  segment_load_conservation_1573  1
    load_2_11_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_22  arc_capacity_1312  -30
    arc_2_11_22  connected_order_arc_1313  -13
    arc_2_11_22  out_degree_1569  1
    arc_2_11_22  in_degree_1640  1
    arc_2_11_22  original_T_including_depot_unload_1648  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_22  arc_capacity_1312  1
    load_2_11_22  segment_load_conservation_1573  1
    load_2_11_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1314  -30
    arc_2_12_0  depot_return_or_bypass_1568  1
    arc_2_12_0  out_degree_1576  1
    arc_2_12_0  original_T_including_depot_unload_1648  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1314  1
    load_2_12_0  segment_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1315  -30
    arc_2_12_11  connected_order_arc_1316  -13
    arc_2_12_11  in_degree_1570  1
    arc_2_12_11  out_degree_1576  1
    arc_2_12_11  original_T_including_depot_unload_1648  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1315  1
    load_2_12_11  segment_load_conservation_1573  -1
    load_2_12_11  segment_prefix_lb_1574  1
    load_2_12_11  segment_prefix_ub_1575  1
    load_2_12_11  segment_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1317  -30
    arc_2_12_13  connected_order_arc_1318  -13
    arc_2_12_13  out_degree_1576  1
    arc_2_12_13  in_degree_1584  1
    arc_2_12_13  original_T_including_depot_unload_1648  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1317  1
    load_2_12_13  segment_load_conservation_1580  1
    load_2_12_13  segment_load_conservation_1587  -1
    load_2_12_13  segment_prefix_lb_1588  1
    load_2_12_13  segment_prefix_ub_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1319  -30
    arc_2_12_14  connected_order_arc_1320  -13
    arc_2_12_14  out_degree_1576  1
    arc_2_12_14  in_degree_1591  1
    arc_2_12_14  original_T_including_depot_unload_1648  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1319  1
    load_2_12_14  segment_load_conservation_1580  1
    load_2_12_14  segment_load_conservation_1594  -1
    load_2_12_14  segment_prefix_lb_1595  1
    load_2_12_14  segment_prefix_ub_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1321  -30
    arc_2_12_15  connected_order_arc_1322  -13
    arc_2_12_15  out_degree_1576  1
    arc_2_12_15  in_degree_1598  1
    arc_2_12_15  original_T_including_depot_unload_1648  3.3636376794191874e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1321  1
    load_2_12_15  segment_load_conservation_1580  1
    load_2_12_15  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1323  -30
    arc_2_12_16  connected_order_arc_1324  -13
    arc_2_12_16  out_degree_1576  1
    arc_2_12_16  in_degree_1604  1
    arc_2_12_16  original_T_including_depot_unload_1648  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1323  1
    load_2_12_16  segment_load_conservation_1580  1
    load_2_12_16  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1325  -30
    arc_2_12_17  connected_order_arc_1326  -13
    arc_2_12_17  out_degree_1576  1
    arc_2_12_17  in_degree_1610  1
    arc_2_12_17  original_T_including_depot_unload_1648  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1325  1
    load_2_12_17  segment_load_conservation_1580  1
    load_2_12_17  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1327  -30
    arc_2_12_18  connected_order_arc_1328  -13
    arc_2_12_18  out_degree_1576  1
    arc_2_12_18  in_degree_1616  1
    arc_2_12_18  original_T_including_depot_unload_1648  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1327  1
    load_2_12_18  segment_load_conservation_1580  1
    load_2_12_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1329  -30
    arc_2_12_19  connected_order_arc_1330  -13
    arc_2_12_19  out_degree_1576  1
    arc_2_12_19  in_degree_1622  1
    arc_2_12_19  original_T_including_depot_unload_1648  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1329  1
    load_2_12_19  segment_load_conservation_1580  1
    load_2_12_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1331  -30
    arc_2_12_20  connected_order_arc_1332  -13
    arc_2_12_20  out_degree_1576  1
    arc_2_12_20  in_degree_1628  1
    arc_2_12_20  original_T_including_depot_unload_1648  2.4817723074148175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1331  1
    load_2_12_20  segment_load_conservation_1580  1
    load_2_12_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1333  -30
    arc_2_12_21  connected_order_arc_1334  -13
    arc_2_12_21  out_degree_1576  1
    arc_2_12_21  in_degree_1634  1
    arc_2_12_21  original_T_including_depot_unload_1648  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1333  1
    load_2_12_21  segment_load_conservation_1580  1
    load_2_12_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1335  -30
    arc_2_12_22  connected_order_arc_1336  -13
    arc_2_12_22  out_degree_1576  1
    arc_2_12_22  in_degree_1640  1
    arc_2_12_22  original_T_including_depot_unload_1648  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1335  1
    load_2_12_22  segment_load_conservation_1580  1
    load_2_12_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1337  -30
    arc_2_13_0  depot_return_or_bypass_1568  1
    arc_2_13_0  out_degree_1583  1
    arc_2_13_0  original_T_including_depot_unload_1648  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1337  1
    load_2_13_0  segment_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1338  -30
    arc_2_13_11  connected_order_arc_1339  -13
    arc_2_13_11  in_degree_1570  1
    arc_2_13_11  out_degree_1583  1
    arc_2_13_11  original_T_including_depot_unload_1648  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1338  1
    load_2_13_11  segment_load_conservation_1573  -1
    load_2_13_11  segment_prefix_lb_1574  1
    load_2_13_11  segment_prefix_ub_1575  1
    load_2_13_11  segment_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1340  -30
    arc_2_13_12  connected_order_arc_1341  -13
    arc_2_13_12  in_degree_1577  1
    arc_2_13_12  out_degree_1583  1
    arc_2_13_12  original_T_including_depot_unload_1648  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1340  1
    load_2_13_12  segment_load_conservation_1580  -1
    load_2_13_12  segment_prefix_lb_1581  1
    load_2_13_12  segment_prefix_ub_1582  1
    load_2_13_12  segment_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1342  -30
    arc_2_13_14  connected_order_arc_1343  -13
    arc_2_13_14  out_degree_1583  1
    arc_2_13_14  in_degree_1591  1
    arc_2_13_14  original_T_including_depot_unload_1648  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1342  1
    load_2_13_14  segment_load_conservation_1587  1
    load_2_13_14  segment_load_conservation_1594  -1
    load_2_13_14  segment_prefix_lb_1595  1
    load_2_13_14  segment_prefix_ub_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1344  -30
    arc_2_13_15  connected_order_arc_1345  -13
    arc_2_13_15  out_degree_1583  1
    arc_2_13_15  in_degree_1598  1
    arc_2_13_15  original_T_including_depot_unload_1648  3.3159486855231207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1344  1
    load_2_13_15  segment_load_conservation_1587  1
    load_2_13_15  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1346  -30
    arc_2_13_16  connected_order_arc_1347  -13
    arc_2_13_16  out_degree_1583  1
    arc_2_13_16  in_degree_1604  1
    arc_2_13_16  original_T_including_depot_unload_1648  2.8379597250568327e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1346  1
    load_2_13_16  segment_load_conservation_1587  1
    load_2_13_16  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1348  -30
    arc_2_13_17  connected_order_arc_1349  -13
    arc_2_13_17  out_degree_1583  1
    arc_2_13_17  in_degree_1610  1
    arc_2_13_17  original_T_including_depot_unload_1648  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1348  1
    load_2_13_17  segment_load_conservation_1587  1
    load_2_13_17  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1350  -30
    arc_2_13_18  connected_order_arc_1351  -13
    arc_2_13_18  out_degree_1583  1
    arc_2_13_18  in_degree_1616  1
    arc_2_13_18  original_T_including_depot_unload_1648  2.5456184368702352e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1350  1
    load_2_13_18  segment_load_conservation_1587  1
    load_2_13_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1352  -30
    arc_2_13_19  connected_order_arc_1353  -13
    arc_2_13_19  out_degree_1583  1
    arc_2_13_19  in_degree_1622  1
    arc_2_13_19  original_T_including_depot_unload_1648  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1352  1
    load_2_13_19  segment_load_conservation_1587  1
    load_2_13_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1354  -30
    arc_2_13_20  connected_order_arc_1355  -13
    arc_2_13_20  out_degree_1583  1
    arc_2_13_20  in_degree_1628  1
    arc_2_13_20  original_T_including_depot_unload_1648  2.6049598266898456e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1354  1
    load_2_13_20  segment_load_conservation_1587  1
    load_2_13_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1356  -30
    arc_2_13_21  connected_order_arc_1357  -13
    arc_2_13_21  out_degree_1583  1
    arc_2_13_21  in_degree_1634  1
    arc_2_13_21  original_T_including_depot_unload_1648  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1356  1
    load_2_13_21  segment_load_conservation_1587  1
    load_2_13_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1358  -30
    arc_2_13_22  connected_order_arc_1359  -13
    arc_2_13_22  out_degree_1583  1
    arc_2_13_22  in_degree_1640  1
    arc_2_13_22  original_T_including_depot_unload_1648  2.3225285101968207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1358  1
    load_2_13_22  segment_load_conservation_1587  1
    load_2_13_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1360  -30
    arc_2_14_0  depot_return_or_bypass_1568  1
    arc_2_14_0  out_degree_1590  1
    arc_2_14_0  original_T_including_depot_unload_1648  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1360  1
    load_2_14_0  segment_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1361  -30
    arc_2_14_11  connected_order_arc_1362  -13
    arc_2_14_11  in_degree_1570  1
    arc_2_14_11  out_degree_1590  1
    arc_2_14_11  original_T_including_depot_unload_1648  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1361  1
    load_2_14_11  segment_load_conservation_1573  -1
    load_2_14_11  segment_prefix_lb_1574  1
    load_2_14_11  segment_prefix_ub_1575  1
    load_2_14_11  segment_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1363  -30
    arc_2_14_12  connected_order_arc_1364  -13
    arc_2_14_12  in_degree_1577  1
    arc_2_14_12  out_degree_1590  1
    arc_2_14_12  original_T_including_depot_unload_1648  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1363  1
    load_2_14_12  segment_load_conservation_1580  -1
    load_2_14_12  segment_prefix_lb_1581  1
    load_2_14_12  segment_prefix_ub_1582  1
    load_2_14_12  segment_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1365  -30
    arc_2_14_13  connected_order_arc_1366  -13
    arc_2_14_13  in_degree_1584  1
    arc_2_14_13  out_degree_1590  1
    arc_2_14_13  original_T_including_depot_unload_1648  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1365  1
    load_2_14_13  segment_load_conservation_1587  -1
    load_2_14_13  segment_prefix_lb_1588  1
    load_2_14_13  segment_prefix_ub_1589  1
    load_2_14_13  segment_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1367  -30
    arc_2_14_15  connected_order_arc_1368  -13
    arc_2_14_15  out_degree_1590  1
    arc_2_14_15  in_degree_1598  1
    arc_2_14_15  original_T_including_depot_unload_1648  2.9211725463504486e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1367  1
    load_2_14_15  segment_load_conservation_1594  1
    load_2_14_15  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1369  -30
    arc_2_14_16  connected_order_arc_1370  -13
    arc_2_14_16  out_degree_1590  1
    arc_2_14_16  in_degree_1604  1
    arc_2_14_16  original_T_including_depot_unload_1648  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1369  1
    load_2_14_16  segment_load_conservation_1594  1
    load_2_14_16  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1371  -30
    arc_2_14_17  connected_order_arc_1372  -13
    arc_2_14_17  out_degree_1590  1
    arc_2_14_17  in_degree_1610  1
    arc_2_14_17  original_T_including_depot_unload_1648  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1371  1
    load_2_14_17  segment_load_conservation_1594  1
    load_2_14_17  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1373  -30
    arc_2_14_18  connected_order_arc_1374  -13
    arc_2_14_18  out_degree_1590  1
    arc_2_14_18  in_degree_1616  1
    arc_2_14_18  original_T_including_depot_unload_1648  2.1115837908099625e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1373  1
    load_2_14_18  segment_load_conservation_1594  1
    load_2_14_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1375  -30
    arc_2_14_19  connected_order_arc_1376  -13
    arc_2_14_19  out_degree_1590  1
    arc_2_14_19  in_degree_1622  1
    arc_2_14_19  original_T_including_depot_unload_1648  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1375  1
    load_2_14_19  segment_load_conservation_1594  1
    load_2_14_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1377  -30
    arc_2_14_20  connected_order_arc_1378  -13
    arc_2_14_20  out_degree_1590  1
    arc_2_14_20  in_degree_1628  1
    arc_2_14_20  original_T_including_depot_unload_1648  2.0943827068880682e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1377  1
    load_2_14_20  segment_load_conservation_1594  1
    load_2_14_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1379  -30
    arc_2_14_21  connected_order_arc_1380  -13
    arc_2_14_21  out_degree_1590  1
    arc_2_14_21  in_degree_1634  1
    arc_2_14_21  original_T_including_depot_unload_1648  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1379  1
    load_2_14_21  segment_load_conservation_1594  1
    load_2_14_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1381  -30
    arc_2_14_22  connected_order_arc_1382  -13
    arc_2_14_22  out_degree_1590  1
    arc_2_14_22  in_degree_1640  1
    arc_2_14_22  original_T_including_depot_unload_1648  1.8614801653445954e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1381  1
    load_2_14_22  segment_load_conservation_1594  1
    load_2_14_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1383  -30
    arc_2_15_0  depot_return_or_bypass_1568  1
    arc_2_15_0  out_degree_1597  1
    arc_2_15_0  original_T_including_depot_unload_1648  1.9654373797357937e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1383  1
    load_2_15_0  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1384  -30
    arc_2_15_11  connected_order_arc_1385  -13
    arc_2_15_11  in_degree_1570  1
    arc_2_15_11  out_degree_1597  1
    arc_2_15_11  original_T_including_depot_unload_1648  2.7605151383884454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1384  1
    load_2_15_11  segment_load_conservation_1573  -1
    load_2_15_11  segment_prefix_lb_1574  1
    load_2_15_11  segment_prefix_ub_1575  1
    load_2_15_11  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1386  -30
    arc_2_15_12  connected_order_arc_1387  -13
    arc_2_15_12  in_degree_1577  1
    arc_2_15_12  out_degree_1597  1
    arc_2_15_12  original_T_including_depot_unload_1648  3.3636376794191874e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1386  1
    load_2_15_12  segment_load_conservation_1580  -1
    load_2_15_12  segment_prefix_lb_1581  1
    load_2_15_12  segment_prefix_ub_1582  1
    load_2_15_12  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1388  -30
    arc_2_15_13  connected_order_arc_1389  -13
    arc_2_15_13  in_degree_1584  1
    arc_2_15_13  out_degree_1597  1
    arc_2_15_13  original_T_including_depot_unload_1648  3.3765642670177640e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1388  1
    load_2_15_13  segment_load_conservation_1587  -1
    load_2_15_13  segment_prefix_lb_1588  1
    load_2_15_13  segment_prefix_ub_1589  1
    load_2_15_13  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1390  -30
    arc_2_15_14  connected_order_arc_1391  -13
    arc_2_15_14  in_degree_1591  1
    arc_2_15_14  out_degree_1597  1
    arc_2_15_14  original_T_including_depot_unload_1648  2.9227976881822528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1390  1
    load_2_15_14  segment_load_conservation_1594  -1
    load_2_15_14  segment_prefix_lb_1595  1
    load_2_15_14  segment_prefix_ub_1596  1
    load_2_15_14  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1392  -30
    arc_2_15_16  connected_order_arc_1393  -13
    arc_2_15_16  out_degree_1597  1
    arc_2_15_16  in_degree_1604  1
    arc_2_15_16  original_T_including_depot_unload_1648  4.9108306779271851e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1392  1
    load_2_15_16  free_load_conservation_1602  1
    load_2_15_16  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1394  -30
    arc_2_15_17  connected_order_arc_1395  -13
    arc_2_15_17  out_degree_1597  1
    arc_2_15_17  in_degree_1610  1
    arc_2_15_17  original_T_including_depot_unload_1648  3.4294674949374580e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1394  1
    load_2_15_17  free_load_conservation_1602  1
    load_2_15_17  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1396  -30
    arc_2_15_18  connected_order_arc_1397  -13
    arc_2_15_18  out_degree_1597  1
    arc_2_15_18  in_degree_1616  1
    arc_2_15_18  original_T_including_depot_unload_1648  8.0990517952185235e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1396  1
    load_2_15_18  free_load_conservation_1602  1
    load_2_15_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1398  -30
    arc_2_15_19  connected_order_arc_1399  -13
    arc_2_15_19  out_degree_1597  1
    arc_2_15_19  in_degree_1622  1
    arc_2_15_19  original_T_including_depot_unload_1648  2.3897696160028909e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1398  1
    load_2_15_19  free_load_conservation_1602  1
    load_2_15_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1400  -30
    arc_2_15_20  connected_order_arc_1401  -13
    arc_2_15_20  out_degree_1597  1
    arc_2_15_20  in_degree_1628  1
    arc_2_15_20  original_T_including_depot_unload_1648  8.8284459023081490e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1400  1
    load_2_15_20  free_load_conservation_1602  1
    load_2_15_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1402  -30
    arc_2_15_21  connected_order_arc_1403  -13
    arc_2_15_21  out_degree_1597  1
    arc_2_15_21  in_degree_1634  1
    arc_2_15_21  original_T_including_depot_unload_1648  2.8013754919345556e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1402  1
    load_2_15_21  free_load_conservation_1602  1
    load_2_15_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1404  -30
    arc_2_15_22  connected_order_arc_1405  -13
    arc_2_15_22  out_degree_1597  1
    arc_2_15_22  in_degree_1640  1
    arc_2_15_22  original_T_including_depot_unload_1648  1.0617037707898505e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1404  1
    load_2_15_22  free_load_conservation_1602  1
    load_2_15_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1406  -30
    arc_2_16_0  depot_return_or_bypass_1568  1
    arc_2_16_0  out_degree_1603  1
    arc_2_16_0  original_T_including_depot_unload_1648  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1406  1
    load_2_16_0  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1407  -30
    arc_2_16_11  connected_order_arc_1408  -13
    arc_2_16_11  in_degree_1570  1
    arc_2_16_11  out_degree_1603  1
    arc_2_16_11  original_T_including_depot_unload_1648  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1407  1
    load_2_16_11  segment_load_conservation_1573  -1
    load_2_16_11  segment_prefix_lb_1574  1
    load_2_16_11  segment_prefix_ub_1575  1
    load_2_16_11  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1409  -30
    arc_2_16_12  connected_order_arc_1410  -13
    arc_2_16_12  in_degree_1577  1
    arc_2_16_12  out_degree_1603  1
    arc_2_16_12  original_T_including_depot_unload_1648  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1409  1
    load_2_16_12  segment_load_conservation_1580  -1
    load_2_16_12  segment_prefix_lb_1581  1
    load_2_16_12  segment_prefix_ub_1582  1
    load_2_16_12  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1411  -30
    arc_2_16_13  connected_order_arc_1412  -13
    arc_2_16_13  in_degree_1584  1
    arc_2_16_13  out_degree_1603  1
    arc_2_16_13  original_T_including_depot_unload_1648  2.9006291140474787e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1411  1
    load_2_16_13  segment_load_conservation_1587  -1
    load_2_16_13  segment_prefix_lb_1588  1
    load_2_16_13  segment_prefix_ub_1589  1
    load_2_16_13  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1413  -30
    arc_2_16_14  connected_order_arc_1414  -13
    arc_2_16_14  in_degree_1591  1
    arc_2_16_14  out_degree_1603  1
    arc_2_16_14  original_T_including_depot_unload_1648  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1413  1
    load_2_16_14  segment_load_conservation_1594  -1
    load_2_16_14  segment_prefix_lb_1595  1
    load_2_16_14  segment_prefix_ub_1596  1
    load_2_16_14  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1415  -30
    arc_2_16_15  connected_order_arc_1416  -13
    arc_2_16_15  in_degree_1598  1
    arc_2_16_15  out_degree_1603  1
    arc_2_16_15  original_T_including_depot_unload_1648  4.9108306779271851e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1415  1
    load_2_16_15  free_load_conservation_1602  -1
    load_2_16_15  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1417  -30
    arc_2_16_17  connected_order_arc_1418  -13
    arc_2_16_17  out_degree_1603  1
    arc_2_16_17  in_degree_1610  1
    arc_2_16_17  original_T_including_depot_unload_1648  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1417  1
    load_2_16_17  free_load_conservation_1608  1
    load_2_16_17  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1419  -30
    arc_2_16_18  connected_order_arc_1420  -13
    arc_2_16_18  out_degree_1603  1
    arc_2_16_18  in_degree_1616  1
    arc_2_16_18  original_T_including_depot_unload_1648  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1419  1
    load_2_16_18  free_load_conservation_1608  1
    load_2_16_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1421  -30
    arc_2_16_19  connected_order_arc_1422  -13
    arc_2_16_19  out_degree_1603  1
    arc_2_16_19  in_degree_1622  1
    arc_2_16_19  original_T_including_depot_unload_1648  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1421  1
    load_2_16_19  free_load_conservation_1608  1
    load_2_16_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1423  -30
    arc_2_16_20  connected_order_arc_1424  -13
    arc_2_16_20  out_degree_1603  1
    arc_2_16_20  in_degree_1628  1
    arc_2_16_20  original_T_including_depot_unload_1648  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1423  1
    load_2_16_20  free_load_conservation_1608  1
    load_2_16_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1425  -30
    arc_2_16_21  connected_order_arc_1426  -13
    arc_2_16_21  out_degree_1603  1
    arc_2_16_21  in_degree_1634  1
    arc_2_16_21  original_T_including_depot_unload_1648  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1425  1
    load_2_16_21  free_load_conservation_1608  1
    load_2_16_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1427  -30
    arc_2_16_22  connected_order_arc_1428  -13
    arc_2_16_22  out_degree_1603  1
    arc_2_16_22  in_degree_1640  1
    arc_2_16_22  original_T_including_depot_unload_1648  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1427  1
    load_2_16_22  free_load_conservation_1608  1
    load_2_16_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1429  -30
    arc_2_17_0  depot_return_or_bypass_1568  1
    arc_2_17_0  out_degree_1609  1
    arc_2_17_0  original_T_including_depot_unload_1648  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1429  1
    load_2_17_0  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1430  -30
    arc_2_17_11  connected_order_arc_1431  -13
    arc_2_17_11  in_degree_1570  1
    arc_2_17_11  out_degree_1609  1
    arc_2_17_11  original_T_including_depot_unload_1648  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1430  1
    load_2_17_11  segment_load_conservation_1573  -1
    load_2_17_11  segment_prefix_lb_1574  1
    load_2_17_11  segment_prefix_ub_1575  1
    load_2_17_11  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1432  -30
    arc_2_17_12  connected_order_arc_1433  -13
    arc_2_17_12  in_degree_1577  1
    arc_2_17_12  out_degree_1609  1
    arc_2_17_12  original_T_including_depot_unload_1648  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1432  1
    load_2_17_12  segment_load_conservation_1580  -1
    load_2_17_12  segment_prefix_lb_1581  1
    load_2_17_12  segment_prefix_ub_1582  1
    load_2_17_12  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1434  -30
    arc_2_17_13  connected_order_arc_1435  -13
    arc_2_17_13  in_degree_1584  1
    arc_2_17_13  out_degree_1609  1
    arc_2_17_13  original_T_including_depot_unload_1648  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1434  1
    load_2_17_13  segment_load_conservation_1587  -1
    load_2_17_13  segment_prefix_lb_1588  1
    load_2_17_13  segment_prefix_ub_1589  1
    load_2_17_13  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1436  -30
    arc_2_17_14  connected_order_arc_1437  -13
    arc_2_17_14  in_degree_1591  1
    arc_2_17_14  out_degree_1609  1
    arc_2_17_14  original_T_including_depot_unload_1648  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1436  1
    load_2_17_14  segment_load_conservation_1594  -1
    load_2_17_14  segment_prefix_lb_1595  1
    load_2_17_14  segment_prefix_ub_1596  1
    load_2_17_14  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1438  -30
    arc_2_17_15  connected_order_arc_1439  -13
    arc_2_17_15  in_degree_1598  1
    arc_2_17_15  out_degree_1609  1
    arc_2_17_15  original_T_including_depot_unload_1648  3.4294674949374580e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1438  1
    load_2_17_15  free_load_conservation_1602  -1
    load_2_17_15  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1440  -30
    arc_2_17_16  connected_order_arc_1441  -13
    arc_2_17_16  in_degree_1604  1
    arc_2_17_16  out_degree_1609  1
    arc_2_17_16  original_T_including_depot_unload_1648  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1440  1
    load_2_17_16  free_load_conservation_1608  -1
    load_2_17_16  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1442  -30
    arc_2_17_18  connected_order_arc_1443  -13
    arc_2_17_18  out_degree_1609  1
    arc_2_17_18  in_degree_1616  1
    arc_2_17_18  original_T_including_depot_unload_1648  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1442  1
    load_2_17_18  free_load_conservation_1614  1
    load_2_17_18  free_load_conservation_1620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1444  -30
    arc_2_17_19  connected_order_arc_1445  -13
    arc_2_17_19  out_degree_1609  1
    arc_2_17_19  in_degree_1622  1
    arc_2_17_19  original_T_including_depot_unload_1648  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1444  1
    load_2_17_19  free_load_conservation_1614  1
    load_2_17_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1446  -30
    arc_2_17_20  connected_order_arc_1447  -13
    arc_2_17_20  out_degree_1609  1
    arc_2_17_20  in_degree_1628  1
    arc_2_17_20  original_T_including_depot_unload_1648  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1446  1
    load_2_17_20  free_load_conservation_1614  1
    load_2_17_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1448  -30
    arc_2_17_21  connected_order_arc_1449  -13
    arc_2_17_21  out_degree_1609  1
    arc_2_17_21  in_degree_1634  1
    arc_2_17_21  original_T_including_depot_unload_1648  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1448  1
    load_2_17_21  free_load_conservation_1614  1
    load_2_17_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1450  -30
    arc_2_17_22  connected_order_arc_1451  -13
    arc_2_17_22  out_degree_1609  1
    arc_2_17_22  in_degree_1640  1
    arc_2_17_22  original_T_including_depot_unload_1648  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1450  1
    load_2_17_22  free_load_conservation_1614  1
    load_2_17_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1452  -30
    arc_2_18_0  depot_return_or_bypass_1568  1
    arc_2_18_0  out_degree_1615  1
    arc_2_18_0  original_T_including_depot_unload_1648  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1452  1
    load_2_18_0  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1453  -30
    arc_2_18_11  connected_order_arc_1454  -13
    arc_2_18_11  in_degree_1570  1
    arc_2_18_11  out_degree_1615  1
    arc_2_18_11  original_T_including_depot_unload_1648  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1453  1
    load_2_18_11  segment_load_conservation_1573  -1
    load_2_18_11  segment_prefix_lb_1574  1
    load_2_18_11  segment_prefix_ub_1575  1
    load_2_18_11  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1455  -30
    arc_2_18_12  connected_order_arc_1456  -13
    arc_2_18_12  in_degree_1577  1
    arc_2_18_12  out_degree_1615  1
    arc_2_18_12  original_T_including_depot_unload_1648  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1455  1
    load_2_18_12  segment_load_conservation_1580  -1
    load_2_18_12  segment_prefix_lb_1581  1
    load_2_18_12  segment_prefix_ub_1582  1
    load_2_18_12  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1457  -30
    arc_2_18_13  connected_order_arc_1458  -13
    arc_2_18_13  in_degree_1584  1
    arc_2_18_13  out_degree_1615  1
    arc_2_18_13  original_T_including_depot_unload_1648  2.5820660682901439e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1457  1
    load_2_18_13  segment_load_conservation_1587  -1
    load_2_18_13  segment_prefix_lb_1588  1
    load_2_18_13  segment_prefix_ub_1589  1
    load_2_18_13  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1459  -30
    arc_2_18_14  connected_order_arc_1460  -13
    arc_2_18_14  in_degree_1591  1
    arc_2_18_14  out_degree_1615  1
    arc_2_18_14  original_T_including_depot_unload_1648  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1459  1
    load_2_18_14  segment_load_conservation_1594  -1
    load_2_18_14  segment_prefix_lb_1595  1
    load_2_18_14  segment_prefix_ub_1596  1
    load_2_18_14  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1461  -30
    arc_2_18_15  connected_order_arc_1462  -13
    arc_2_18_15  in_degree_1598  1
    arc_2_18_15  out_degree_1615  1
    arc_2_18_15  original_T_including_depot_unload_1648  8.0990517952185235e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1461  1
    load_2_18_15  free_load_conservation_1602  -1
    load_2_18_15  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1463  -30
    arc_2_18_16  connected_order_arc_1464  -13
    arc_2_18_16  in_degree_1604  1
    arc_2_18_16  out_degree_1615  1
    arc_2_18_16  original_T_including_depot_unload_1648  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1463  1
    load_2_18_16  free_load_conservation_1608  -1
    load_2_18_16  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1465  -30
    arc_2_18_17  connected_order_arc_1466  -13
    arc_2_18_17  in_degree_1610  1
    arc_2_18_17  out_degree_1615  1
    arc_2_18_17  original_T_including_depot_unload_1648  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1465  1
    load_2_18_17  free_load_conservation_1614  -1
    load_2_18_17  free_load_conservation_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1467  -30
    arc_2_18_19  connected_order_arc_1468  -13
    arc_2_18_19  out_degree_1615  1
    arc_2_18_19  in_degree_1622  1
    arc_2_18_19  original_T_including_depot_unload_1648  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1467  1
    load_2_18_19  free_load_conservation_1620  1
    load_2_18_19  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1469  -30
    arc_2_18_20  connected_order_arc_1470  -13
    arc_2_18_20  out_degree_1615  1
    arc_2_18_20  in_degree_1628  1
    arc_2_18_20  original_T_including_depot_unload_1648  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1469  1
    load_2_18_20  free_load_conservation_1620  1
    load_2_18_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1471  -30
    arc_2_18_21  connected_order_arc_1472  -13
    arc_2_18_21  out_degree_1615  1
    arc_2_18_21  in_degree_1634  1
    arc_2_18_21  original_T_including_depot_unload_1648  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1471  1
    load_2_18_21  free_load_conservation_1620  1
    load_2_18_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1473  -30
    arc_2_18_22  connected_order_arc_1474  -13
    arc_2_18_22  out_degree_1615  1
    arc_2_18_22  in_degree_1640  1
    arc_2_18_22  original_T_including_depot_unload_1648  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1473  1
    load_2_18_22  free_load_conservation_1620  1
    load_2_18_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1475  -30
    arc_2_19_0  depot_return_or_bypass_1568  1
    arc_2_19_0  out_degree_1621  1
    arc_2_19_0  original_T_including_depot_unload_1648  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1475  1
    load_2_19_0  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1476  -30
    arc_2_19_11  connected_order_arc_1477  -13
    arc_2_19_11  in_degree_1570  1
    arc_2_19_11  out_degree_1621  1
    arc_2_19_11  original_T_including_depot_unload_1648  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1476  1
    load_2_19_11  segment_load_conservation_1573  -1
    load_2_19_11  segment_prefix_lb_1574  1
    load_2_19_11  segment_prefix_ub_1575  1
    load_2_19_11  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1478  -30
    arc_2_19_12  connected_order_arc_1479  -13
    arc_2_19_12  in_degree_1577  1
    arc_2_19_12  out_degree_1621  1
    arc_2_19_12  original_T_including_depot_unload_1648  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1478  1
    load_2_19_12  segment_load_conservation_1580  -1
    load_2_19_12  segment_prefix_lb_1581  1
    load_2_19_12  segment_prefix_ub_1582  1
    load_2_19_12  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1480  -30
    arc_2_19_13  connected_order_arc_1481  -13
    arc_2_19_13  in_degree_1584  1
    arc_2_19_13  out_degree_1621  1
    arc_2_19_13  original_T_including_depot_unload_1648  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1480  1
    load_2_19_13  segment_load_conservation_1587  -1
    load_2_19_13  segment_prefix_lb_1588  1
    load_2_19_13  segment_prefix_ub_1589  1
    load_2_19_13  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1482  -30
    arc_2_19_14  connected_order_arc_1483  -13
    arc_2_19_14  in_degree_1591  1
    arc_2_19_14  out_degree_1621  1
    arc_2_19_14  original_T_including_depot_unload_1648  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1482  1
    load_2_19_14  segment_load_conservation_1594  -1
    load_2_19_14  segment_prefix_lb_1595  1
    load_2_19_14  segment_prefix_ub_1596  1
    load_2_19_14  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1484  -30
    arc_2_19_15  connected_order_arc_1485  -13
    arc_2_19_15  in_degree_1598  1
    arc_2_19_15  out_degree_1621  1
    arc_2_19_15  original_T_including_depot_unload_1648  2.3897696160028909e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1484  1
    load_2_19_15  free_load_conservation_1602  -1
    load_2_19_15  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1486  -30
    arc_2_19_16  connected_order_arc_1487  -13
    arc_2_19_16  in_degree_1604  1
    arc_2_19_16  out_degree_1621  1
    arc_2_19_16  original_T_including_depot_unload_1648  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1486  1
    load_2_19_16  free_load_conservation_1608  -1
    load_2_19_16  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1488  -30
    arc_2_19_17  connected_order_arc_1489  -13
    arc_2_19_17  in_degree_1610  1
    arc_2_19_17  out_degree_1621  1
    arc_2_19_17  original_T_including_depot_unload_1648  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1488  1
    load_2_19_17  free_load_conservation_1614  -1
    load_2_19_17  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1490  -30
    arc_2_19_18  connected_order_arc_1491  -13
    arc_2_19_18  in_degree_1616  1
    arc_2_19_18  out_degree_1621  1
    arc_2_19_18  original_T_including_depot_unload_1648  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1490  1
    load_2_19_18  free_load_conservation_1620  -1
    load_2_19_18  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1492  -30
    arc_2_19_20  connected_order_arc_1493  -13
    arc_2_19_20  out_degree_1621  1
    arc_2_19_20  in_degree_1628  1
    arc_2_19_20  original_T_including_depot_unload_1648  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1492  1
    load_2_19_20  free_load_conservation_1626  1
    load_2_19_20  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1494  -30
    arc_2_19_21  connected_order_arc_1495  -13
    arc_2_19_21  out_degree_1621  1
    arc_2_19_21  in_degree_1634  1
    arc_2_19_21  original_T_including_depot_unload_1648  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1494  1
    load_2_19_21  free_load_conservation_1626  1
    load_2_19_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1496  -30
    arc_2_19_22  connected_order_arc_1497  -13
    arc_2_19_22  out_degree_1621  1
    arc_2_19_22  in_degree_1640  1
    arc_2_19_22  original_T_including_depot_unload_1648  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1496  1
    load_2_19_22  free_load_conservation_1626  1
    load_2_19_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1498  -30
    arc_2_20_0  depot_return_or_bypass_1568  1
    arc_2_20_0  out_degree_1627  1
    arc_2_20_0  original_T_including_depot_unload_1648  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1498  1
    load_2_20_0  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1499  -30
    arc_2_20_11  connected_order_arc_1500  -13
    arc_2_20_11  in_degree_1570  1
    arc_2_20_11  out_degree_1627  1
    arc_2_20_11  original_T_including_depot_unload_1648  1.9010369513971175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1499  1
    load_2_20_11  segment_load_conservation_1573  -1
    load_2_20_11  segment_prefix_lb_1574  1
    load_2_20_11  segment_prefix_ub_1575  1
    load_2_20_11  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1501  -30
    arc_2_20_12  connected_order_arc_1502  -13
    arc_2_20_12  in_degree_1577  1
    arc_2_20_12  out_degree_1627  1
    arc_2_20_12  original_T_including_depot_unload_1648  2.4817723074148175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1501  1
    load_2_20_12  segment_load_conservation_1580  -1
    load_2_20_12  segment_prefix_lb_1581  1
    load_2_20_12  segment_prefix_ub_1582  1
    load_2_20_12  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1503  -30
    arc_2_20_13  connected_order_arc_1504  -13
    arc_2_20_13  in_degree_1584  1
    arc_2_20_13  out_degree_1627  1
    arc_2_20_13  original_T_including_depot_unload_1648  2.5004905239513250e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1503  1
    load_2_20_13  segment_load_conservation_1587  -1
    load_2_20_13  segment_prefix_lb_1588  1
    load_2_20_13  segment_prefix_ub_1589  1
    load_2_20_13  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1505  -30
    arc_2_20_14  connected_order_arc_1506  -13
    arc_2_20_14  in_degree_1591  1
    arc_2_20_14  out_degree_1627  1
    arc_2_20_14  original_T_including_depot_unload_1648  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1505  1
    load_2_20_14  segment_load_conservation_1594  -1
    load_2_20_14  segment_prefix_lb_1595  1
    load_2_20_14  segment_prefix_ub_1596  1
    load_2_20_14  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1507  -30
    arc_2_20_15  connected_order_arc_1508  -13
    arc_2_20_15  in_degree_1598  1
    arc_2_20_15  out_degree_1627  1
    arc_2_20_15  original_T_including_depot_unload_1648  8.8284459023081490e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1507  1
    load_2_20_15  free_load_conservation_1602  -1
    load_2_20_15  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1509  -30
    arc_2_20_16  connected_order_arc_1510  -13
    arc_2_20_16  in_degree_1604  1
    arc_2_20_16  out_degree_1627  1
    arc_2_20_16  original_T_including_depot_unload_1648  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1509  1
    load_2_20_16  free_load_conservation_1608  -1
    load_2_20_16  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1511  -30
    arc_2_20_17  connected_order_arc_1512  -13
    arc_2_20_17  in_degree_1610  1
    arc_2_20_17  out_degree_1627  1
    arc_2_20_17  original_T_including_depot_unload_1648  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1511  1
    load_2_20_17  free_load_conservation_1614  -1
    load_2_20_17  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1513  -30
    arc_2_20_18  connected_order_arc_1514  -13
    arc_2_20_18  in_degree_1616  1
    arc_2_20_18  out_degree_1627  1
    arc_2_20_18  original_T_including_depot_unload_1648  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1513  1
    load_2_20_18  free_load_conservation_1620  -1
    load_2_20_18  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1515  -30
    arc_2_20_19  connected_order_arc_1516  -13
    arc_2_20_19  in_degree_1622  1
    arc_2_20_19  out_degree_1627  1
    arc_2_20_19  original_T_including_depot_unload_1648  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1515  1
    load_2_20_19  free_load_conservation_1626  -1
    load_2_20_19  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1517  -30
    arc_2_20_21  connected_order_arc_1518  -13
    arc_2_20_21  out_degree_1627  1
    arc_2_20_21  in_degree_1634  1
    arc_2_20_21  original_T_including_depot_unload_1648  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1517  1
    load_2_20_21  free_load_conservation_1632  1
    load_2_20_21  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1519  -30
    arc_2_20_22  connected_order_arc_1520  -13
    arc_2_20_22  out_degree_1627  1
    arc_2_20_22  in_degree_1640  1
    arc_2_20_22  original_T_including_depot_unload_1648  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1519  1
    load_2_20_22  free_load_conservation_1632  1
    load_2_20_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1521  -30
    arc_2_21_0  depot_return_or_bypass_1568  1
    arc_2_21_0  out_degree_1633  1
    arc_2_21_0  original_T_including_depot_unload_1648  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1521  1
    load_2_21_0  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1522  -30
    arc_2_21_11  connected_order_arc_1523  -13
    arc_2_21_11  in_degree_1570  1
    arc_2_21_11  out_degree_1633  1
    arc_2_21_11  original_T_including_depot_unload_1648  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1522  1
    load_2_21_11  segment_load_conservation_1573  -1
    load_2_21_11  segment_prefix_lb_1574  1
    load_2_21_11  segment_prefix_ub_1575  1
    load_2_21_11  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1524  -30
    arc_2_21_12  connected_order_arc_1525  -13
    arc_2_21_12  in_degree_1577  1
    arc_2_21_12  out_degree_1633  1
    arc_2_21_12  original_T_including_depot_unload_1648  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1524  1
    load_2_21_12  segment_load_conservation_1580  -1
    load_2_21_12  segment_prefix_lb_1581  1
    load_2_21_12  segment_prefix_ub_1582  1
    load_2_21_12  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1526  -30
    arc_2_21_13  connected_order_arc_1527  -13
    arc_2_21_13  in_degree_1584  1
    arc_2_21_13  out_degree_1633  1
    arc_2_21_13  original_T_including_depot_unload_1648  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1526  1
    load_2_21_13  segment_load_conservation_1587  -1
    load_2_21_13  segment_prefix_lb_1588  1
    load_2_21_13  segment_prefix_ub_1589  1
    load_2_21_13  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1528  -30
    arc_2_21_14  connected_order_arc_1529  -13
    arc_2_21_14  in_degree_1591  1
    arc_2_21_14  out_degree_1633  1
    arc_2_21_14  original_T_including_depot_unload_1648  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1528  1
    load_2_21_14  segment_load_conservation_1594  -1
    load_2_21_14  segment_prefix_lb_1595  1
    load_2_21_14  segment_prefix_ub_1596  1
    load_2_21_14  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1530  -30
    arc_2_21_15  connected_order_arc_1531  -13
    arc_2_21_15  in_degree_1598  1
    arc_2_21_15  out_degree_1633  1
    arc_2_21_15  original_T_including_depot_unload_1648  2.8013754919345556e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1530  1
    load_2_21_15  free_load_conservation_1602  -1
    load_2_21_15  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1532  -30
    arc_2_21_16  connected_order_arc_1533  -13
    arc_2_21_16  in_degree_1604  1
    arc_2_21_16  out_degree_1633  1
    arc_2_21_16  original_T_including_depot_unload_1648  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1532  1
    load_2_21_16  free_load_conservation_1608  -1
    load_2_21_16  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1534  -30
    arc_2_21_17  connected_order_arc_1535  -13
    arc_2_21_17  in_degree_1610  1
    arc_2_21_17  out_degree_1633  1
    arc_2_21_17  original_T_including_depot_unload_1648  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1534  1
    load_2_21_17  free_load_conservation_1614  -1
    load_2_21_17  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1536  -30
    arc_2_21_18  connected_order_arc_1537  -13
    arc_2_21_18  in_degree_1616  1
    arc_2_21_18  out_degree_1633  1
    arc_2_21_18  original_T_including_depot_unload_1648  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1536  1
    load_2_21_18  free_load_conservation_1620  -1
    load_2_21_18  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1538  -30
    arc_2_21_19  connected_order_arc_1539  -13
    arc_2_21_19  in_degree_1622  1
    arc_2_21_19  out_degree_1633  1
    arc_2_21_19  original_T_including_depot_unload_1648  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1538  1
    load_2_21_19  free_load_conservation_1626  -1
    load_2_21_19  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1540  -30
    arc_2_21_20  connected_order_arc_1541  -13
    arc_2_21_20  in_degree_1628  1
    arc_2_21_20  out_degree_1633  1
    arc_2_21_20  original_T_including_depot_unload_1648  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1540  1
    load_2_21_20  free_load_conservation_1632  -1
    load_2_21_20  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1542  -30
    arc_2_21_22  connected_order_arc_1543  -13
    arc_2_21_22  out_degree_1633  1
    arc_2_21_22  in_degree_1640  1
    arc_2_21_22  original_T_including_depot_unload_1648  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1542  1
    load_2_21_22  free_load_conservation_1638  1
    load_2_21_22  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1544  -30
    arc_2_22_0  depot_return_or_bypass_1568  1
    arc_2_22_0  out_degree_1639  1
    arc_2_22_0  original_T_including_depot_unload_1648  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1544  1
    load_2_22_0  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_11  arc_capacity_1545  -30
    arc_2_22_11  connected_order_arc_1546  -13
    arc_2_22_11  in_degree_1570  1
    arc_2_22_11  out_degree_1639  1
    arc_2_22_11  original_T_including_depot_unload_1648  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_11  arc_capacity_1545  1
    load_2_22_11  segment_load_conservation_1573  -1
    load_2_22_11  segment_prefix_lb_1574  1
    load_2_22_11  segment_prefix_ub_1575  1
    load_2_22_11  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1547  -30
    arc_2_22_12  connected_order_arc_1548  -13
    arc_2_22_12  in_degree_1577  1
    arc_2_22_12  out_degree_1639  1
    arc_2_22_12  original_T_including_depot_unload_1648  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1547  1
    load_2_22_12  segment_load_conservation_1580  -1
    load_2_22_12  segment_prefix_lb_1581  1
    load_2_22_12  segment_prefix_ub_1582  1
    load_2_22_12  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1549  -30
    arc_2_22_13  connected_order_arc_1550  -13
    arc_2_22_13  in_degree_1584  1
    arc_2_22_13  out_degree_1639  1
    arc_2_22_13  original_T_including_depot_unload_1648  2.3310908183310389e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1549  1
    load_2_22_13  segment_load_conservation_1587  -1
    load_2_22_13  segment_prefix_lb_1588  1
    load_2_22_13  segment_prefix_ub_1589  1
    load_2_22_13  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1551  -30
    arc_2_22_14  connected_order_arc_1552  -13
    arc_2_22_14  in_degree_1591  1
    arc_2_22_14  out_degree_1639  1
    arc_2_22_14  original_T_including_depot_unload_1648  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1551  1
    load_2_22_14  segment_load_conservation_1594  -1
    load_2_22_14  segment_prefix_lb_1595  1
    load_2_22_14  segment_prefix_ub_1596  1
    load_2_22_14  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1553  -30
    arc_2_22_15  connected_order_arc_1554  -13
    arc_2_22_15  in_degree_1598  1
    arc_2_22_15  out_degree_1639  1
    arc_2_22_15  original_T_including_depot_unload_1648  1.0617037707898505e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1553  1
    load_2_22_15  free_load_conservation_1602  -1
    load_2_22_15  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1555  -30
    arc_2_22_16  connected_order_arc_1556  -13
    arc_2_22_16  in_degree_1604  1
    arc_2_22_16  out_degree_1639  1
    arc_2_22_16  original_T_including_depot_unload_1648  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1555  1
    load_2_22_16  free_load_conservation_1608  -1
    load_2_22_16  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1557  -30
    arc_2_22_17  connected_order_arc_1558  -13
    arc_2_22_17  in_degree_1610  1
    arc_2_22_17  out_degree_1639  1
    arc_2_22_17  original_T_including_depot_unload_1648  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1557  1
    load_2_22_17  free_load_conservation_1614  -1
    load_2_22_17  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1559  -30
    arc_2_22_18  connected_order_arc_1560  -13
    arc_2_22_18  in_degree_1616  1
    arc_2_22_18  out_degree_1639  1
    arc_2_22_18  original_T_including_depot_unload_1648  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1559  1
    load_2_22_18  free_load_conservation_1620  -1
    load_2_22_18  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1561  -30
    arc_2_22_19  connected_order_arc_1562  -13
    arc_2_22_19  in_degree_1622  1
    arc_2_22_19  out_degree_1639  1
    arc_2_22_19  original_T_including_depot_unload_1648  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1561  1
    load_2_22_19  free_load_conservation_1626  -1
    load_2_22_19  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1563  -30
    arc_2_22_20  connected_order_arc_1564  -13
    arc_2_22_20  in_degree_1628  1
    arc_2_22_20  out_degree_1639  1
    arc_2_22_20  original_T_including_depot_unload_1648  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1563  1
    load_2_22_20  free_load_conservation_1632  -1
    load_2_22_20  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1565  -30
    arc_2_22_21  connected_order_arc_1566  -13
    arc_2_22_21  in_degree_1634  1
    arc_2_22_21  out_degree_1639  1
    arc_2_22_21  original_T_including_depot_unload_1648  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1565  1
    load_2_22_21  free_load_conservation_1638  -1
    load_2_22_21  free_load_conservation_1644  1
RHS
    RHS1      OBJ       -2.8076708318437255e-01
    RHS1      onehot_1_18  1
    RHS1      onehot_2_53  1
    RHS1      onehot_34_88  1
    RHS1      onehot_3_117  1
    RHS1      onehot_22_152  1
    RHS1      onehot_4_187  1
    RHS1      onehot_27_204  1
    RHS1      onehot_5_239  1
    RHS1      stock_ub_243  36
    RHS1      parent_nonstrict_scope_244  3.0561904154676517e-01
    RHS1      normalization_301  1
    RHS1      connected_order_arc_422  -15
    RHS1      connected_order_arc_424  -15
    RHS1      connected_order_arc_426  -15
    RHS1      connected_order_arc_428  -15
    RHS1      connected_order_arc_430  -15
    RHS1      connected_order_arc_432  -15
    RHS1      connected_order_arc_434  -15
    RHS1      connected_order_arc_436  -15
    RHS1      connected_order_arc_438  -15
    RHS1      connected_order_arc_440  -15
    RHS1      connected_order_arc_442  -15
    RHS1      connected_order_arc_444  -15
    RHS1      connected_order_arc_446  -15
    RHS1      connected_order_arc_448  -15
    RHS1      connected_order_arc_451  -15
    RHS1      connected_order_arc_453  -15
    RHS1      connected_order_arc_455  -15
    RHS1      connected_order_arc_457  -15
    RHS1      connected_order_arc_459  -15
    RHS1      connected_order_arc_461  -15
    RHS1      connected_order_arc_463  -15
    RHS1      connected_order_arc_465  -15
    RHS1      connected_order_arc_467  -15
    RHS1      connected_order_arc_469  -15
    RHS1      connected_order_arc_471  -15
    RHS1      connected_order_arc_473  -15
    RHS1      connected_order_arc_475  -15
    RHS1      connected_order_arc_477  -15
    RHS1      connected_order_arc_480  -15
    RHS1      connected_order_arc_482  -15
    RHS1      connected_order_arc_484  -15
    RHS1      connected_order_arc_486  -15
    RHS1      connected_order_arc_488  -15
    RHS1      connected_order_arc_490  -15
    RHS1      connected_order_arc_492  -15
    RHS1      connected_order_arc_494  -15
    RHS1      connected_order_arc_496  -15
    RHS1      connected_order_arc_498  -15
    RHS1      connected_order_arc_500  -15
    RHS1      connected_order_arc_502  -15
    RHS1      connected_order_arc_504  -15
    RHS1      connected_order_arc_506  -15
    RHS1      connected_order_arc_509  -15
    RHS1      connected_order_arc_511  -15
    RHS1      connected_order_arc_513  -15
    RHS1      connected_order_arc_515  -15
    RHS1      connected_order_arc_517  -15
    RHS1      connected_order_arc_519  -15
    RHS1      connected_order_arc_521  -15
    RHS1      connected_order_arc_523  -15
    RHS1      connected_order_arc_525  -15
    RHS1      connected_order_arc_527  -15
    RHS1      connected_order_arc_529  -15
    RHS1      connected_order_arc_531  -15
    RHS1      connected_order_arc_533  -15
    RHS1      connected_order_arc_535  -15
    RHS1      connected_order_arc_538  -15
    RHS1      connected_order_arc_540  -15
    RHS1      connected_order_arc_542  -15
    RHS1      connected_order_arc_544  -15
    RHS1      connected_order_arc_546  -15
    RHS1      connected_order_arc_548  -15
    RHS1      connected_order_arc_550  -15
    RHS1      connected_order_arc_552  -15
    RHS1      connected_order_arc_554  -15
    RHS1      connected_order_arc_556  -15
    RHS1      connected_order_arc_558  -15
    RHS1      connected_order_arc_560  -15
    RHS1      connected_order_arc_562  -15
    RHS1      connected_order_arc_564  -15
    RHS1      connected_order_arc_567  -15
    RHS1      connected_order_arc_569  -15
    RHS1      connected_order_arc_571  -15
    RHS1      connected_order_arc_573  -15
    RHS1      connected_order_arc_575  -15
    RHS1      connected_order_arc_577  -15
    RHS1      connected_order_arc_579  -15
    RHS1      connected_order_arc_581  -15
    RHS1      connected_order_arc_583  -15
    RHS1      connected_order_arc_585  -15
    RHS1      connected_order_arc_587  -15
    RHS1      connected_order_arc_589  -15
    RHS1      connected_order_arc_591  -15
    RHS1      connected_order_arc_593  -15
    RHS1      connected_order_arc_596  -15
    RHS1      connected_order_arc_598  -15
    RHS1      connected_order_arc_600  -15
    RHS1      connected_order_arc_602  -15
    RHS1      connected_order_arc_604  -15
    RHS1      connected_order_arc_606  -15
    RHS1      connected_order_arc_608  -15
    RHS1      connected_order_arc_610  -15
    RHS1      connected_order_arc_612  -15
    RHS1      connected_order_arc_614  -15
    RHS1      connected_order_arc_616  -15
    RHS1      connected_order_arc_618  -15
    RHS1      connected_order_arc_620  -15
    RHS1      connected_order_arc_622  -15
    RHS1      connected_order_arc_625  -15
    RHS1      connected_order_arc_627  -15
    RHS1      connected_order_arc_629  -15
    RHS1      connected_order_arc_631  -15
    RHS1      connected_order_arc_633  -15
    RHS1      connected_order_arc_635  -15
    RHS1      connected_order_arc_637  -15
    RHS1      connected_order_arc_639  -15
    RHS1      connected_order_arc_641  -15
    RHS1      connected_order_arc_643  -15
    RHS1      connected_order_arc_645  -15
    RHS1      connected_order_arc_647  -15
    RHS1      connected_order_arc_649  -15
    RHS1      connected_order_arc_651  -15
    RHS1      connected_order_arc_654  -15
    RHS1      connected_order_arc_656  -15
    RHS1      connected_order_arc_658  -15
    RHS1      connected_order_arc_660  -15
    RHS1      connected_order_arc_662  -15
    RHS1      connected_order_arc_664  -15
    RHS1      connected_order_arc_666  -15
    RHS1      connected_order_arc_668  -15
    RHS1      connected_order_arc_670  -15
    RHS1      connected_order_arc_672  -15
    RHS1      connected_order_arc_674  -15
    RHS1      connected_order_arc_676  -15
    RHS1      connected_order_arc_678  -15
    RHS1      connected_order_arc_680  -15
    RHS1      connected_order_arc_683  -15
    RHS1      connected_order_arc_685  -15
    RHS1      connected_order_arc_687  -15
    RHS1      connected_order_arc_689  -15
    RHS1      connected_order_arc_691  -15
    RHS1      connected_order_arc_693  -15
    RHS1      connected_order_arc_695  -15
    RHS1      connected_order_arc_697  -15
    RHS1      connected_order_arc_699  -15
    RHS1      connected_order_arc_701  -15
    RHS1      connected_order_arc_703  -15
    RHS1      connected_order_arc_705  -15
    RHS1      connected_order_arc_707  -15
    RHS1      connected_order_arc_709  -15
    RHS1      connected_order_arc_712  -15
    RHS1      connected_order_arc_714  -15
    RHS1      connected_order_arc_716  -15
    RHS1      connected_order_arc_718  -15
    RHS1      connected_order_arc_720  -15
    RHS1      connected_order_arc_722  -15
    RHS1      connected_order_arc_724  -15
    RHS1      connected_order_arc_726  -15
    RHS1      connected_order_arc_728  -15
    RHS1      connected_order_arc_730  -15
    RHS1      connected_order_arc_732  -15
    RHS1      connected_order_arc_734  -15
    RHS1      connected_order_arc_736  -15
    RHS1      connected_order_arc_738  -15
    RHS1      connected_order_arc_741  -15
    RHS1      connected_order_arc_743  -15
    RHS1      connected_order_arc_745  -15
    RHS1      connected_order_arc_747  -15
    RHS1      connected_order_arc_749  -15
    RHS1      connected_order_arc_751  -15
    RHS1      connected_order_arc_753  -15
    RHS1      connected_order_arc_755  -15
    RHS1      connected_order_arc_757  -15
    RHS1      connected_order_arc_759  -15
    RHS1      connected_order_arc_761  -15
    RHS1      connected_order_arc_763  -15
    RHS1      connected_order_arc_765  -15
    RHS1      connected_order_arc_767  -15
    RHS1      connected_order_arc_770  -15
    RHS1      connected_order_arc_772  -15
    RHS1      connected_order_arc_774  -15
    RHS1      connected_order_arc_776  -15
    RHS1      connected_order_arc_778  -15
    RHS1      connected_order_arc_780  -15
    RHS1      connected_order_arc_782  -15
    RHS1      connected_order_arc_784  -15
    RHS1      connected_order_arc_786  -15
    RHS1      connected_order_arc_788  -15
    RHS1      connected_order_arc_790  -15
    RHS1      connected_order_arc_792  -15
    RHS1      connected_order_arc_794  -15
    RHS1      connected_order_arc_796  -15
    RHS1      connected_order_arc_799  -15
    RHS1      connected_order_arc_801  -15
    RHS1      connected_order_arc_803  -15
    RHS1      connected_order_arc_805  -15
    RHS1      connected_order_arc_807  -15
    RHS1      connected_order_arc_809  -15
    RHS1      connected_order_arc_811  -15
    RHS1      connected_order_arc_813  -15
    RHS1      connected_order_arc_815  -15
    RHS1      connected_order_arc_817  -15
    RHS1      connected_order_arc_819  -15
    RHS1      connected_order_arc_821  -15
    RHS1      connected_order_arc_823  -15
    RHS1      connected_order_arc_825  -15
    RHS1      connected_order_arc_828  -15
    RHS1      connected_order_arc_830  -15
    RHS1      connected_order_arc_832  -15
    RHS1      connected_order_arc_834  -15
    RHS1      connected_order_arc_836  -15
    RHS1      connected_order_arc_838  -15
    RHS1      connected_order_arc_840  -15
    RHS1      connected_order_arc_842  -15
    RHS1      connected_order_arc_844  -15
    RHS1      connected_order_arc_846  -15
    RHS1      connected_order_arc_848  -15
    RHS1      connected_order_arc_850  -15
    RHS1      connected_order_arc_852  -15
    RHS1      connected_order_arc_854  -15
    RHS1      depot_departure_or_bypass_855  1
    RHS1      depot_return_or_bypass_856  1
    RHS1      segment_load_conservation_861  4
    RHS1      segment_prefix_ub_863  16
    RHS1      segment_load_conservation_868  1
    RHS1      segment_prefix_ub_870  19
    RHS1      segment_load_conservation_875  3
    RHS1      segment_prefix_ub_877  17
    RHS1      segment_load_conservation_882  3
    RHS1      segment_prefix_ub_884  17
    RHS1      segment_load_conservation_889  -4
    RHS1      segment_prefix_lb_890  4
    RHS1      segment_prefix_ub_891  20
    RHS1      segment_load_conservation_896  -2
    RHS1      segment_prefix_lb_897  2
    RHS1      segment_prefix_ub_898  20
    RHS1      segment_load_conservation_903  2
    RHS1      segment_prefix_ub_905  13
    RHS1      fixed_segment_relative_order_954  1
    RHS1      fixed_segment_relative_order_955  1
    RHS1      fixed_segment_relative_order_956  1
    RHS1      fixed_segment_relative_order_957  1
    RHS1      fixed_segment_relative_order_958  1
    RHS1      fixed_segment_relative_order_959  1
    RHS1      original_T_including_depot_unload_960  3.2350478046194758e+03
    RHS1      connected_order_arc_975  -11
    RHS1      connected_order_arc_977  -11
    RHS1      connected_order_arc_979  -11
    RHS1      connected_order_arc_981  -11
    RHS1      connected_order_arc_983  -11
    RHS1      connected_order_arc_985  -11
    RHS1      connected_order_arc_987  -11
    RHS1      connected_order_arc_989  -11
    RHS1      connected_order_arc_991  -11
    RHS1      connected_order_arc_993  -11
    RHS1      connected_order_arc_996  -11
    RHS1      connected_order_arc_998  -11
    RHS1      connected_order_arc_1000  -11
    RHS1      connected_order_arc_1002  -11
    RHS1      connected_order_arc_1004  -11
    RHS1      connected_order_arc_1006  -11
    RHS1      connected_order_arc_1008  -11
    RHS1      connected_order_arc_1010  -11
    RHS1      connected_order_arc_1012  -11
    RHS1      connected_order_arc_1014  -11
    RHS1      connected_order_arc_1017  -11
    RHS1      connected_order_arc_1019  -11
    RHS1      connected_order_arc_1021  -11
    RHS1      connected_order_arc_1023  -11
    RHS1      connected_order_arc_1025  -11
    RHS1      connected_order_arc_1027  -11
    RHS1      connected_order_arc_1029  -11
    RHS1      connected_order_arc_1031  -11
    RHS1      connected_order_arc_1033  -11
    RHS1      connected_order_arc_1035  -11
    RHS1      connected_order_arc_1038  -11
    RHS1      connected_order_arc_1040  -11
    RHS1      connected_order_arc_1042  -11
    RHS1      connected_order_arc_1044  -11
    RHS1      connected_order_arc_1046  -11
    RHS1      connected_order_arc_1048  -11
    RHS1      connected_order_arc_1050  -11
    RHS1      connected_order_arc_1052  -11
    RHS1      connected_order_arc_1054  -11
    RHS1      connected_order_arc_1056  -11
    RHS1      connected_order_arc_1059  -11
    RHS1      connected_order_arc_1061  -11
    RHS1      connected_order_arc_1063  -11
    RHS1      connected_order_arc_1065  -11
    RHS1      connected_order_arc_1067  -11
    RHS1      connected_order_arc_1069  -11
    RHS1      connected_order_arc_1071  -11
    RHS1      connected_order_arc_1073  -11
    RHS1      connected_order_arc_1075  -11
    RHS1      connected_order_arc_1077  -11
    RHS1      connected_order_arc_1080  -11
    RHS1      connected_order_arc_1082  -11
    RHS1      connected_order_arc_1084  -11
    RHS1      connected_order_arc_1086  -11
    RHS1      connected_order_arc_1088  -11
    RHS1      connected_order_arc_1090  -11
    RHS1      connected_order_arc_1092  -11
    RHS1      connected_order_arc_1094  -11
    RHS1      connected_order_arc_1096  -11
    RHS1      connected_order_arc_1098  -11
    RHS1      connected_order_arc_1101  -11
    RHS1      connected_order_arc_1103  -11
    RHS1      connected_order_arc_1105  -11
    RHS1      connected_order_arc_1107  -11
    RHS1      connected_order_arc_1109  -11
    RHS1      connected_order_arc_1111  -11
    RHS1      connected_order_arc_1113  -11
    RHS1      connected_order_arc_1115  -11
    RHS1      connected_order_arc_1117  -11
    RHS1      connected_order_arc_1119  -11
    RHS1      connected_order_arc_1122  -11
    RHS1      connected_order_arc_1124  -11
    RHS1      connected_order_arc_1126  -11
    RHS1      connected_order_arc_1128  -11
    RHS1      connected_order_arc_1130  -11
    RHS1      connected_order_arc_1132  -11
    RHS1      connected_order_arc_1134  -11
    RHS1      connected_order_arc_1136  -11
    RHS1      connected_order_arc_1138  -11
    RHS1      connected_order_arc_1140  -11
    RHS1      connected_order_arc_1143  -11
    RHS1      connected_order_arc_1145  -11
    RHS1      connected_order_arc_1147  -11
    RHS1      connected_order_arc_1149  -11
    RHS1      connected_order_arc_1151  -11
    RHS1      connected_order_arc_1153  -11
    RHS1      connected_order_arc_1155  -11
    RHS1      connected_order_arc_1157  -11
    RHS1      connected_order_arc_1159  -11
    RHS1      connected_order_arc_1161  -11
    RHS1      connected_order_arc_1164  -11
    RHS1      connected_order_arc_1166  -11
    RHS1      connected_order_arc_1168  -11
    RHS1      connected_order_arc_1170  -11
    RHS1      connected_order_arc_1172  -11
    RHS1      connected_order_arc_1174  -11
    RHS1      connected_order_arc_1176  -11
    RHS1      connected_order_arc_1178  -11
    RHS1      connected_order_arc_1180  -11
    RHS1      connected_order_arc_1182  -11
    RHS1      connected_order_arc_1185  -11
    RHS1      connected_order_arc_1187  -11
    RHS1      connected_order_arc_1189  -11
    RHS1      connected_order_arc_1191  -11
    RHS1      connected_order_arc_1193  -11
    RHS1      connected_order_arc_1195  -11
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1201  -11
    RHS1      connected_order_arc_1203  -11
    RHS1      depot_departure_or_bypass_1204  1
    RHS1      depot_return_or_bypass_1205  1
    RHS1      segment_load_conservation_1210  5
    RHS1      segment_prefix_ub_1212  20
    RHS1      segment_load_conservation_1217  -4
    RHS1      segment_prefix_lb_1218  4
    RHS1      segment_prefix_ub_1219  25
    RHS1      segment_load_conservation_1224  -6
    RHS1      segment_prefix_lb_1225  6
    RHS1      segment_prefix_ub_1226  25
    RHS1      fixed_segment_relative_order_1275  1
    RHS1      fixed_segment_relative_order_1276  1
    RHS1      original_T_including_depot_unload_1277  5700
    RHS1      connected_order_arc_1293  -12
    RHS1      connected_order_arc_1295  -12
    RHS1      connected_order_arc_1297  -12
    RHS1      connected_order_arc_1299  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1305  -12
    RHS1      connected_order_arc_1307  -12
    RHS1      connected_order_arc_1309  -12
    RHS1      connected_order_arc_1311  -12
    RHS1      connected_order_arc_1313  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1328  -12
    RHS1      connected_order_arc_1330  -12
    RHS1      connected_order_arc_1332  -12
    RHS1      connected_order_arc_1334  -12
    RHS1      connected_order_arc_1336  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1351  -12
    RHS1      connected_order_arc_1353  -12
    RHS1      connected_order_arc_1355  -12
    RHS1      connected_order_arc_1357  -12
    RHS1      connected_order_arc_1359  -12
    RHS1      connected_order_arc_1362  -12
    RHS1      connected_order_arc_1364  -12
    RHS1      connected_order_arc_1366  -12
    RHS1      connected_order_arc_1368  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1374  -12
    RHS1      connected_order_arc_1376  -12
    RHS1      connected_order_arc_1378  -12
    RHS1      connected_order_arc_1380  -12
    RHS1      connected_order_arc_1382  -12
    RHS1      connected_order_arc_1385  -12
    RHS1      connected_order_arc_1387  -12
    RHS1      connected_order_arc_1389  -12
    RHS1      connected_order_arc_1391  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1397  -12
    RHS1      connected_order_arc_1399  -12
    RHS1      connected_order_arc_1401  -12
    RHS1      connected_order_arc_1403  -12
    RHS1      connected_order_arc_1405  -12
    RHS1      connected_order_arc_1408  -12
    RHS1      connected_order_arc_1410  -12
    RHS1      connected_order_arc_1412  -12
    RHS1      connected_order_arc_1414  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1420  -12
    RHS1      connected_order_arc_1422  -12
    RHS1      connected_order_arc_1424  -12
    RHS1      connected_order_arc_1426  -12
    RHS1      connected_order_arc_1428  -12
    RHS1      connected_order_arc_1431  -12
    RHS1      connected_order_arc_1433  -12
    RHS1      connected_order_arc_1435  -12
    RHS1      connected_order_arc_1437  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1443  -12
    RHS1      connected_order_arc_1445  -12
    RHS1      connected_order_arc_1447  -12
    RHS1      connected_order_arc_1449  -12
    RHS1      connected_order_arc_1451  -12
    RHS1      connected_order_arc_1454  -12
    RHS1      connected_order_arc_1456  -12
    RHS1      connected_order_arc_1458  -12
    RHS1      connected_order_arc_1460  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1466  -12
    RHS1      connected_order_arc_1468  -12
    RHS1      connected_order_arc_1470  -12
    RHS1      connected_order_arc_1472  -12
    RHS1      connected_order_arc_1474  -12
    RHS1      connected_order_arc_1477  -12
    RHS1      connected_order_arc_1479  -12
    RHS1      connected_order_arc_1481  -12
    RHS1      connected_order_arc_1483  -12
    RHS1      connected_order_arc_1485  -12
    RHS1      connected_order_arc_1487  -12
    RHS1      connected_order_arc_1489  -12
    RHS1      connected_order_arc_1491  -12
    RHS1      connected_order_arc_1493  -12
    RHS1      connected_order_arc_1495  -12
    RHS1      connected_order_arc_1497  -12
    RHS1      connected_order_arc_1500  -12
    RHS1      connected_order_arc_1502  -12
    RHS1      connected_order_arc_1504  -12
    RHS1      connected_order_arc_1506  -12
    RHS1      connected_order_arc_1508  -12
    RHS1      connected_order_arc_1510  -12
    RHS1      connected_order_arc_1512  -12
    RHS1      connected_order_arc_1514  -12
    RHS1      connected_order_arc_1516  -12
    RHS1      connected_order_arc_1518  -12
    RHS1      connected_order_arc_1520  -12
    RHS1      connected_order_arc_1523  -12
    RHS1      connected_order_arc_1525  -12
    RHS1      connected_order_arc_1527  -12
    RHS1      connected_order_arc_1529  -12
    RHS1      connected_order_arc_1531  -12
    RHS1      connected_order_arc_1533  -12
    RHS1      connected_order_arc_1535  -12
    RHS1      connected_order_arc_1537  -12
    RHS1      connected_order_arc_1539  -12
    RHS1      connected_order_arc_1541  -12
    RHS1      connected_order_arc_1543  -12
    RHS1      connected_order_arc_1546  -12
    RHS1      connected_order_arc_1548  -12
    RHS1      connected_order_arc_1550  -12
    RHS1      connected_order_arc_1552  -12
    RHS1      connected_order_arc_1554  -12
    RHS1      connected_order_arc_1556  -12
    RHS1      connected_order_arc_1558  -12
    RHS1      connected_order_arc_1560  -12
    RHS1      connected_order_arc_1562  -12
    RHS1      connected_order_arc_1564  -12
    RHS1      connected_order_arc_1566  -12
    RHS1      depot_departure_or_bypass_1567  1
    RHS1      depot_return_or_bypass_1568  1
    RHS1      segment_load_conservation_1573  2
    RHS1      segment_prefix_ub_1575  28
    RHS1      segment_load_conservation_1580  2
    RHS1      segment_prefix_ub_1582  28
    RHS1      segment_load_conservation_1587  -1
    RHS1      segment_prefix_lb_1588  4
    RHS1      segment_prefix_ub_1589  30
    RHS1      segment_load_conservation_1594  -2
    RHS1      segment_prefix_lb_1595  2
    RHS1      segment_prefix_ub_1596  30
    RHS1      fixed_segment_relative_order_1645  1
    RHS1      fixed_segment_relative_order_1646  1
    RHS1      fixed_segment_relative_order_1647  1
    RHS1      original_T_including_depot_unload_1648  3.6732129147490105e+03
BOUNDS
 LO BND1      t         2.5838203629626577e-02
 UP BND1      t         4.4931799946554711e-02
 UP BND1      q         4.2393967896198825e-01
 BV BND1      x_1_0   
 UP BND1      w_1_0     4.4931799946554711e-02
 BV BND1      x_1_1   
 UP BND1      w_1_1     4.4931799946554711e-02
 BV BND1      x_1_2   
 UP BND1      w_1_2     4.4931799946554711e-02
 BV BND1      x_1_3   
 UP BND1      w_1_3     4.4931799946554711e-02
 BV BND1      x_1_4   
 UP BND1      w_1_4     4.4931799946554711e-02
 BV BND1      x_1_5   
 UP BND1      w_1_5     4.4931799946554711e-02
 BV BND1      x_1_6   
 UP BND1      w_1_6     4.4931799946554711e-02
 BV BND1      x_1_7   
 UP BND1      w_1_7     4.4931799946554711e-02
 BV BND1      x_1_8   
 UP BND1      w_1_8     4.4931799946554711e-02
 UP BND1      rho_1     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.4931799946554711e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.4931799946554711e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.4931799946554711e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.4931799946554711e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.4931799946554711e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.4931799946554711e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.4931799946554711e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.4931799946554711e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.4931799946554711e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.4931799946554711e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.4931799946554711e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.4931799946554711e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.4931799946554711e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.4931799946554711e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.4931799946554711e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.4931799946554711e-02
 UP BND1      rho_2     1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.4931799946554711e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.4931799946554711e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.4931799946554711e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.4931799946554711e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.4931799946554711e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.4931799946554711e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.4931799946554711e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.4931799946554711e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.4931799946554711e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.4931799946554711e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.4931799946554711e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.4931799946554711e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.4931799946554711e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.4931799946554711e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.4931799946554711e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.4931799946554711e-02
 UP BND1      rho_34    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.4931799946554711e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.4931799946554711e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.4931799946554711e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.4931799946554711e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.4931799946554711e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.4931799946554711e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.4931799946554711e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.4931799946554711e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.4931799946554711e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.4931799946554711e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.4931799946554711e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.4931799946554711e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.4931799946554711e-02
 UP BND1      rho_3     1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.4931799946554711e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.4931799946554711e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.4931799946554711e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.4931799946554711e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.4931799946554711e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.4931799946554711e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.4931799946554711e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.4931799946554711e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.4931799946554711e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.4931799946554711e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.4931799946554711e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.4931799946554711e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.4931799946554711e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.4931799946554711e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.4931799946554711e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.4931799946554711e-02
 UP BND1      rho_22    1
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.4931799946554711e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.4931799946554711e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.4931799946554711e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.4931799946554711e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.4931799946554711e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.4931799946554711e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.4931799946554711e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.4931799946554711e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.4931799946554711e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.4931799946554711e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.4931799946554711e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.4931799946554711e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.4931799946554711e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.4931799946554711e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.4931799946554711e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.4931799946554711e-02
 UP BND1      rho_4     1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.4931799946554711e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.4931799946554711e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.4931799946554711e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.4931799946554711e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.4931799946554711e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.4931799946554711e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.4931799946554711e-02
 UP BND1      rho_27    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.4931799946554711e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.4931799946554711e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.4931799946554711e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.4931799946554711e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.4931799946554711e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.4931799946554711e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.4931799946554711e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.4931799946554711e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.4931799946554711e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.4931799946554711e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.4931799946554711e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.4931799946554711e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.4931799946554711e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.4931799946554711e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.4931799946554711e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.4931799946554711e-02
 UP BND1      rho_5     1
 UP BND1      a_1_2     1
 UP BND1      a_1_34    1
 UP BND1      a_1_3     1
 UP BND1      a_1_22    1
 UP BND1      a_1_4     1
 UP BND1      a_1_27    1
 UP BND1      a_1_5     1
 UP BND1      a_2_34    1
 UP BND1      a_2_3     1
 UP BND1      a_2_22    1
 UP BND1      a_2_4     1
 UP BND1      a_2_27    1
 UP BND1      a_2_5     1
 UP BND1      a_34_3    1
 UP BND1      a_34_22   1
 UP BND1      a_34_4    1
 UP BND1      a_34_27   1
 UP BND1      a_34_5    1
 UP BND1      a_3_22    1
 UP BND1      a_3_4     1
 UP BND1      a_3_27    1
 UP BND1      a_3_5     1
 UP BND1      a_22_4    1
 UP BND1      a_22_27   1
 UP BND1      a_22_5    1
 UP BND1      a_4_27    1
 UP BND1      a_4_5     1
 UP BND1      a_27_5    1
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_0_1_2
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_1_1_2
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_2_1_0
 BV BND1      service_2_1_1
 BV BND1      service_2_1_2
 BV BND1      service_2_1_3
 BV BND1      service_2_1_4
 BV BND1      service_2_1_5
 BV BND1      service_2_1_7
 BV BND1      service_2_1_8
 BV BND1      service_0_2_0
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_0
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_0
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_12
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_12
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_12
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_11
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_11
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_11
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_5_0
 BV BND1      service_0_5_2
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_1_5_0
 BV BND1      service_1_5_2
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_2_5_0
 BV BND1      service_2_5_2
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  15
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  15
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  15
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  15
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  15
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  15
 FX BND1      visit_0_7  1
 UP BND1      order_0_7  15
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  15
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  15
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  15
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  15
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  15
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  15
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  15
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  15
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_7
 FX BND1      load_0_0_7  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_7
 UP BND1      load_0_1_7  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_7
 UP BND1      load_0_2_7  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_7
 UP BND1      load_0_3_7  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_7
 UP BND1      load_0_4_7  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_7
 UP BND1      load_0_5_7  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_7
 UP BND1      load_0_6_7  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_6_22
 UP BND1      load_0_6_22  20
 BV BND1      arc_0_7_0
 UP BND1      load_0_7_0  20
 BV BND1      arc_0_7_1
 UP BND1      load_0_7_1  20
 BV BND1      arc_0_7_2
 UP BND1      load_0_7_2  20
 BV BND1      arc_0_7_3
 UP BND1      load_0_7_3  20
 BV BND1      arc_0_7_4
 UP BND1      load_0_7_4  20
 BV BND1      arc_0_7_5
 UP BND1      load_0_7_5  20
 BV BND1      arc_0_7_6
 UP BND1      load_0_7_6  20
 BV BND1      arc_0_7_15
 UP BND1      load_0_7_15  20
 BV BND1      arc_0_7_16
 UP BND1      load_0_7_16  20
 BV BND1      arc_0_7_17
 UP BND1      load_0_7_17  20
 BV BND1      arc_0_7_18
 UP BND1      load_0_7_18  20
 BV BND1      arc_0_7_19
 UP BND1      load_0_7_19  20
 BV BND1      arc_0_7_20
 UP BND1      load_0_7_20  20
 BV BND1      arc_0_7_21
 UP BND1      load_0_7_21  20
 BV BND1      arc_0_7_22
 UP BND1      load_0_7_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_7
 UP BND1      load_0_15_7  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_7
 UP BND1      load_0_16_7  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_7
 UP BND1      load_0_17_7  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_7
 UP BND1      load_0_18_7  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_7
 UP BND1      load_0_19_7  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_7
 UP BND1      load_0_20_7  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_7
 UP BND1      load_0_21_7  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_6
 UP BND1      load_0_22_6  20
 BV BND1      arc_0_22_7
 UP BND1      load_0_22_7  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  11
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  11
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  11
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  11
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  11
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  11
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  11
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  11
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  11
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  11
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  11
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_11_22
 UP BND1      load_2_11_22  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_11
 UP BND1      load_2_22_11  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
