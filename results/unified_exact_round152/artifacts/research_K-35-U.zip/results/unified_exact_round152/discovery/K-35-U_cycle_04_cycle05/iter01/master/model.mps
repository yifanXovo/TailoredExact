* Signature: 0x9e5f20f948d88448
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
 L  column_13
 L  column_14
COLUMNS
    psi[1,4]  OBJ       1
    psi[1,4]  column_0  1
    psi[1,4]  column_1  1
    psi[1,4]  column_2  1
    psi[1,4]  column_3  1
    psi[1,4]  column_4  1
    psi[1,4]  column_5  1
    psi[1,4]  column_6  1
    psi[1,4]  column_7  1
    psi[1,4]  column_8  1
    psi[1,4]  column_9  1
    psi[1,4]  column_10  1
    psi[1,4]  column_11  1
    psi[1,4]  column_12  1
    psi[1,4]  column_13  1
    psi[1,4]  column_14  1
    psi[2,12]  OBJ       1
    psi[2,12]  column_0  1
    psi[2,12]  column_1  1
    psi[2,12]  column_2  1
    psi[2,12]  column_3  1
    psi[2,12]  column_4  1
    psi[2,12]  column_5  1
    psi[2,12]  column_6  1
    psi[2,12]  column_7  1
    psi[2,12]  column_8  1
    psi[2,12]  column_9  1
    psi[2,12]  column_10  1
    psi[2,12]  column_11  1
    psi[2,12]  column_12  1
    psi[2,12]  column_13  1
    psi[2,12]  column_14  1
    psi[3,13]  OBJ       1
    psi[3,13]  column_0  1
    psi[3,13]  column_1  1
    psi[3,13]  column_2  1
    psi[3,13]  column_3  1
    psi[3,13]  column_4  1
    psi[3,13]  column_5  1
    psi[3,13]  column_6  1
    psi[3,13]  column_7  1
    psi[3,13]  column_8  1
    psi[3,13]  column_9  1
    psi[3,13]  column_10  1
    psi[3,13]  column_11  1
    psi[3,13]  column_12  1
    psi[3,13]  column_13  1
    psi[3,13]  column_14  1
    psi[4,7]  OBJ       9.4444444444444475e-01
    psi[4,7]  column_0  1
    psi[4,7]  column_1  1
    psi[4,7]  column_2  1
    psi[4,7]  column_3  1
    psi[4,7]  column_4  1
    psi[4,7]  column_5  1
    psi[4,7]  column_6  1
    psi[4,7]  column_7  1
    psi[4,7]  column_8  1
    psi[4,7]  column_9  1
    psi[4,7]  column_10  1
    psi[4,13]  OBJ       5.5555555555555261e-02
    psi[4,13]  column_11  1
    psi[4,13]  column_12  1
    psi[4,13]  column_13  1
    psi[4,13]  column_14  1
    psi[5,8]  OBJ       1
    psi[5,8]  column_0  1
    psi[5,8]  column_1  1
    psi[5,8]  column_2  1
    psi[5,8]  column_3  1
    psi[5,8]  column_4  1
    psi[5,8]  column_5  1
    psi[5,8]  column_6  1
    psi[5,8]  column_7  1
    psi[5,8]  column_8  1
    psi[5,8]  column_9  1
    psi[5,8]  column_10  1
    psi[5,8]  column_11  1
    psi[5,8]  column_12  1
    psi[5,8]  column_13  1
    psi[5,8]  column_14  1
    psi[6,4]  OBJ       1
    psi[6,4]  column_0  1
    psi[6,4]  column_1  1
    psi[6,4]  column_2  1
    psi[6,4]  column_3  1
    psi[6,4]  column_4  1
    psi[6,4]  column_5  1
    psi[6,4]  column_6  1
    psi[6,4]  column_7  1
    psi[6,4]  column_8  1
    psi[6,4]  column_9  1
    psi[6,4]  column_10  1
    psi[6,4]  column_11  1
    psi[6,4]  column_12  1
    psi[6,4]  column_13  1
    psi[6,4]  column_14  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[7,10]  column_12  1
    psi[7,10]  column_13  1
    psi[7,10]  column_14  1
    psi[8,7]  OBJ       9.5890280523261373e-01
    psi[8,7]  column_0  1
    psi[8,7]  column_1  1
    psi[8,7]  column_2  1
    psi[8,7]  column_3  1
    psi[8,7]  column_4  1
    psi[8,7]  column_5  1
    psi[8,7]  column_6  1
    psi[8,7]  column_11  1
    psi[8,13]  OBJ       4.1097194767386304e-02
    psi[8,13]  column_7  1
    psi[8,13]  column_8  1
    psi[8,13]  column_9  1
    psi[8,13]  column_10  1
    psi[8,13]  column_12  1
    psi[8,13]  column_13  1
    psi[8,13]  column_14  1
    psi[9,5]  OBJ       1.1111111111111113e-01
    psi[9,5]  column_0  1
    psi[9,5]  column_7  1
    psi[9,5]  column_8  1
    psi[9,5]  column_9  1
    psi[9,5]  column_10  1
    psi[9,5]  column_11  1
    psi[9,5]  column_12  1
    psi[9,10]  OBJ       8.8888888888888884e-01
    psi[9,10]  column_1  1
    psi[9,10]  column_2  1
    psi[9,10]  column_3  1
    psi[9,10]  column_4  1
    psi[9,10]  column_5  1
    psi[9,10]  column_6  1
    psi[9,10]  column_13  1
    psi[9,10]  column_14  1
    psi[10,4]  OBJ       1.4468237434498352e-01
    psi[10,4]  column_1  1
    psi[10,4]  column_7  1
    psi[10,4]  column_8  1
    psi[10,4]  column_9  1
    psi[10,4]  column_11  1
    psi[10,4]  column_12  1
    psi[10,4]  column_13  1
    psi[10,4]  column_14  1
    psi[10,6]  OBJ       0.810958894514334
    psi[10,6]  column_0  1
    psi[10,6]  column_2  1
    psi[10,6]  column_3  1
    psi[10,6]  column_4  1
    psi[10,6]  column_5  1
    psi[10,7]  OBJ       4.4358731140682436e-02
    psi[10,7]  column_6  1
    psi[10,7]  column_10  1
    psi[11,7]  OBJ       1
    psi[11,7]  column_0  1
    psi[11,7]  column_1  1
    psi[11,7]  column_2  1
    psi[11,7]  column_3  1
    psi[11,7]  column_4  1
    psi[11,7]  column_5  1
    psi[11,7]  column_6  1
    psi[11,7]  column_7  1
    psi[11,7]  column_8  1
    psi[11,7]  column_9  1
    psi[11,7]  column_10  1
    psi[11,7]  column_11  1
    psi[11,7]  column_12  1
    psi[11,7]  column_13  1
    psi[11,7]  column_14  1
    psi[12,8]  OBJ       0.921358689303446
    psi[12,8]  column_1  1
    psi[12,8]  column_2  1
    psi[12,8]  column_3  1
    psi[12,8]  column_4  1
    psi[12,8]  column_5  1
    psi[12,8]  column_6  1
    psi[12,8]  column_7  1
    psi[12,8]  column_8  1
    psi[12,8]  column_9  1
    psi[12,8]  column_11  1
    psi[12,14]  OBJ       7.8641310696554056e-02
    psi[12,14]  column_0  1
    psi[12,14]  column_10  1
    psi[12,14]  column_12  1
    psi[12,14]  column_13  1
    psi[12,14]  column_14  1
    psi[13,10]  OBJ       1
    psi[13,10]  column_0  1
    psi[13,10]  column_1  1
    psi[13,10]  column_2  1
    psi[13,10]  column_3  1
    psi[13,10]  column_4  1
    psi[13,10]  column_5  1
    psi[13,10]  column_6  1
    psi[13,10]  column_7  1
    psi[13,10]  column_8  1
    psi[13,10]  column_9  1
    psi[13,10]  column_10  1
    psi[13,10]  column_11  1
    psi[13,10]  column_12  1
    psi[13,10]  column_13  1
    psi[13,10]  column_14  1
    psi[14,10]  OBJ       1
    psi[14,10]  column_0  1
    psi[14,10]  column_1  1
    psi[14,10]  column_2  1
    psi[14,10]  column_3  1
    psi[14,10]  column_4  1
    psi[14,10]  column_5  1
    psi[14,10]  column_6  1
    psi[14,10]  column_7  1
    psi[14,10]  column_8  1
    psi[14,10]  column_9  1
    psi[14,10]  column_10  1
    psi[14,10]  column_11  1
    psi[14,10]  column_12  1
    psi[14,10]  column_13  1
    psi[14,10]  column_14  1
    psi[15,10]  OBJ       1
    psi[15,10]  column_0  1
    psi[15,10]  column_1  1
    psi[15,10]  column_2  1
    psi[15,10]  column_3  1
    psi[15,10]  column_4  1
    psi[15,10]  column_5  1
    psi[15,10]  column_6  1
    psi[15,10]  column_7  1
    psi[15,10]  column_8  1
    psi[15,10]  column_9  1
    psi[15,10]  column_10  1
    psi[15,10]  column_11  1
    psi[15,10]  column_12  1
    psi[15,10]  column_13  1
    psi[15,10]  column_14  1
    psi[16,3]  OBJ       9.0286577020874470e-01
    psi[16,3]  column_0  1
    psi[16,3]  column_1  1
    psi[16,3]  column_2  1
    psi[16,3]  column_3  1
    psi[16,3]  column_4  1
    psi[16,3]  column_6  1
    psi[16,3]  column_7  1
    psi[16,3]  column_8  1
    psi[16,3]  column_9  1
    psi[16,3]  column_10  1
    psi[16,3]  column_11  1
    psi[16,3]  column_13  1
    psi[16,3]  column_14  1
    psi[16,11]  OBJ       0.0971342297912553
    psi[16,11]  column_5  1
    psi[16,11]  column_12  1
    psi[17,16]  OBJ       1
    psi[17,16]  column_0  1
    psi[17,16]  column_1  1
    psi[17,16]  column_2  1
    psi[17,16]  column_3  1
    psi[17,16]  column_4  1
    psi[17,16]  column_5  1
    psi[17,16]  column_6  1
    psi[17,16]  column_7  1
    psi[17,16]  column_8  1
    psi[17,16]  column_9  1
    psi[17,16]  column_10  1
    psi[17,16]  column_11  1
    psi[17,16]  column_12  1
    psi[17,16]  column_13  1
    psi[17,16]  column_14  1
    psi[18,7]  OBJ       1
    psi[18,7]  column_0  1
    psi[18,7]  column_1  1
    psi[18,7]  column_2  1
    psi[18,7]  column_3  1
    psi[18,7]  column_4  1
    psi[18,7]  column_5  1
    psi[18,7]  column_6  1
    psi[18,7]  column_7  1
    psi[18,7]  column_8  1
    psi[18,7]  column_9  1
    psi[18,7]  column_10  1
    psi[18,7]  column_11  1
    psi[18,7]  column_12  1
    psi[18,7]  column_13  1
    psi[18,7]  column_14  1
    psi[19,9]  OBJ       1
    psi[19,9]  column_0  1
    psi[19,9]  column_1  1
    psi[19,9]  column_2  1
    psi[19,9]  column_3  1
    psi[19,9]  column_4  1
    psi[19,9]  column_5  1
    psi[19,9]  column_6  1
    psi[19,9]  column_7  1
    psi[19,9]  column_8  1
    psi[19,9]  column_9  1
    psi[19,9]  column_10  1
    psi[19,9]  column_11  1
    psi[19,9]  column_12  1
    psi[19,9]  column_13  1
    psi[19,9]  column_14  1
    psi[20,7]  OBJ       1
    psi[20,7]  column_0  1
    psi[20,7]  column_1  1
    psi[20,7]  column_2  1
    psi[20,7]  column_3  1
    psi[20,7]  column_4  1
    psi[20,7]  column_5  1
    psi[20,7]  column_6  1
    psi[20,7]  column_7  1
    psi[20,7]  column_8  1
    psi[20,7]  column_9  1
    psi[20,7]  column_10  1
    psi[20,7]  column_11  1
    psi[20,7]  column_12  1
    psi[20,7]  column_13  1
    psi[20,7]  column_14  1
    psi[21,9]  OBJ       1
    psi[21,9]  column_0  1
    psi[21,9]  column_1  1
    psi[21,9]  column_2  1
    psi[21,9]  column_3  1
    psi[21,9]  column_4  1
    psi[21,9]  column_5  1
    psi[21,9]  column_6  1
    psi[21,9]  column_7  1
    psi[21,9]  column_8  1
    psi[21,9]  column_9  1
    psi[21,9]  column_10  1
    psi[21,9]  column_11  1
    psi[21,9]  column_12  1
    psi[21,9]  column_13  1
    psi[21,9]  column_14  1
    psi[22,10]  OBJ       1
    psi[22,10]  column_0  1
    psi[22,10]  column_1  1
    psi[22,10]  column_2  1
    psi[22,10]  column_3  1
    psi[22,10]  column_4  1
    psi[22,10]  column_5  1
    psi[22,10]  column_6  1
    psi[22,10]  column_7  1
    psi[22,10]  column_8  1
    psi[22,10]  column_9  1
    psi[22,10]  column_10  1
    psi[22,10]  column_11  1
    psi[22,10]  column_12  1
    psi[22,10]  column_13  1
    psi[22,10]  column_14  1
    psi[23,8]  OBJ       9.0563042716413511e-01
    psi[23,8]  column_1  1
    psi[23,8]  column_2  1
    psi[23,8]  column_3  1
    psi[23,8]  column_4  1
    psi[23,8]  column_5  1
    psi[23,8]  column_7  1
    psi[23,8]  column_8  1
    psi[23,8]  column_9  1
    psi[23,8]  column_10  1
    psi[23,8]  column_11  1
    psi[23,8]  column_13  1
    psi[23,8]  column_14  1
    psi[23,13]  OBJ       9.4369572835864876e-02
    psi[23,13]  column_0  1
    psi[23,13]  column_6  1
    psi[23,13]  column_12  1
    psi[24,2]  OBJ       5.2234107359192594e-01
    psi[24,2]  column_2  1
    psi[24,2]  column_3  1
    psi[24,2]  column_7  1
    psi[24,4]  OBJ       1.4380942646018735e-01
    psi[24,4]  column_5  1
    psi[24,4]  column_8  1
    psi[24,4]  column_10  1
    psi[24,4]  column_11  1
    psi[24,5]  OBJ       2.7000291225534788e-02
    psi[24,5]  column_9  1
    psi[24,5]  column_13  1
    psi[24,7]  OBJ       0.209714978931099
    psi[24,7]  column_1  1
    psi[24,7]  column_4  1
    psi[24,7]  column_12  1
    psi[24,8]  OBJ       0.0971342297912553
    psi[24,8]  column_0  1
    psi[24,8]  column_6  1
    psi[24,8]  column_14  1
    psi[25,7]  OBJ       1
    psi[25,7]  column_0  1
    psi[25,7]  column_1  1
    psi[25,7]  column_2  1
    psi[25,7]  column_3  1
    psi[25,7]  column_4  1
    psi[25,7]  column_5  1
    psi[25,7]  column_6  1
    psi[25,7]  column_7  1
    psi[25,7]  column_8  1
    psi[25,7]  column_9  1
    psi[25,7]  column_10  1
    psi[25,7]  column_11  1
    psi[25,7]  column_12  1
    psi[25,7]  column_13  1
    psi[25,7]  column_14  1
    psi[26,8]  OBJ       9.0563042716413511e-01
    psi[26,8]  column_0  1
    psi[26,8]  column_1  1
    psi[26,8]  column_2  1
    psi[26,8]  column_4  1
    psi[26,8]  column_5  1
    psi[26,8]  column_6  1
    psi[26,8]  column_7  1
    psi[26,8]  column_9  1
    psi[26,8]  column_10  1
    psi[26,8]  column_13  1
    psi[26,13]  OBJ       9.4369572835864876e-02
    psi[26,13]  column_3  1
    psi[26,13]  column_8  1
    psi[26,13]  column_11  1
    psi[26,13]  column_12  1
    psi[26,13]  column_14  1
    psi[27,9]  OBJ       1
    psi[27,9]  column_0  1
    psi[27,9]  column_1  1
    psi[27,9]  column_2  1
    psi[27,9]  column_3  1
    psi[27,9]  column_4  1
    psi[27,9]  column_5  1
    psi[27,9]  column_6  1
    psi[27,9]  column_7  1
    psi[27,9]  column_8  1
    psi[27,9]  column_9  1
    psi[27,9]  column_10  1
    psi[27,9]  column_11  1
    psi[27,9]  column_12  1
    psi[27,9]  column_13  1
    psi[27,9]  column_14  1
    psi[28,7]  OBJ       1
    psi[28,7]  column_0  1
    psi[28,7]  column_1  1
    psi[28,7]  column_2  1
    psi[28,7]  column_3  1
    psi[28,7]  column_4  1
    psi[28,7]  column_5  1
    psi[28,7]  column_6  1
    psi[28,7]  column_7  1
    psi[28,7]  column_8  1
    psi[28,7]  column_9  1
    psi[28,7]  column_10  1
    psi[28,7]  column_11  1
    psi[28,7]  column_12  1
    psi[28,7]  column_13  1
    psi[28,7]  column_14  1
    psi[29,7]  OBJ       1
    psi[29,7]  column_0  1
    psi[29,7]  column_1  1
    psi[29,7]  column_2  1
    psi[29,7]  column_3  1
    psi[29,7]  column_4  1
    psi[29,7]  column_5  1
    psi[29,7]  column_6  1
    psi[29,7]  column_7  1
    psi[29,7]  column_8  1
    psi[29,7]  column_9  1
    psi[29,7]  column_10  1
    psi[29,7]  column_11  1
    psi[29,7]  column_12  1
    psi[29,7]  column_13  1
    psi[29,7]  column_14  1
    psi[30,11]  OBJ       1
    psi[30,11]  column_0  1
    psi[30,11]  column_1  1
    psi[30,11]  column_2  1
    psi[30,11]  column_3  1
    psi[30,11]  column_4  1
    psi[30,11]  column_5  1
    psi[30,11]  column_6  1
    psi[30,11]  column_7  1
    psi[30,11]  column_8  1
    psi[30,11]  column_9  1
    psi[30,11]  column_10  1
    psi[30,11]  column_11  1
    psi[30,11]  column_12  1
    psi[30,11]  column_13  1
    psi[30,11]  column_14  1
    psi[31,7]  OBJ       1
    psi[31,7]  column_0  1
    psi[31,7]  column_1  1
    psi[31,7]  column_2  1
    psi[31,7]  column_3  1
    psi[31,7]  column_4  1
    psi[31,7]  column_5  1
    psi[31,7]  column_6  1
    psi[31,7]  column_7  1
    psi[31,7]  column_8  1
    psi[31,7]  column_9  1
    psi[31,7]  column_10  1
    psi[31,7]  column_11  1
    psi[31,7]  column_12  1
    psi[31,7]  column_13  1
    psi[31,7]  column_14  1
    psi[32,8]  OBJ       1
    psi[32,8]  column_0  1
    psi[32,8]  column_1  1
    psi[32,8]  column_2  1
    psi[32,8]  column_3  1
    psi[32,8]  column_4  1
    psi[32,8]  column_5  1
    psi[32,8]  column_6  1
    psi[32,8]  column_7  1
    psi[32,8]  column_8  1
    psi[32,8]  column_9  1
    psi[32,8]  column_10  1
    psi[32,8]  column_11  1
    psi[32,8]  column_12  1
    psi[32,8]  column_13  1
    psi[32,8]  column_14  1
    psi[33,13]  OBJ       1
    psi[33,13]  column_0  1
    psi[33,13]  column_1  1
    psi[33,13]  column_2  1
    psi[33,13]  column_3  1
    psi[33,13]  column_4  1
    psi[33,13]  column_5  1
    psi[33,13]  column_6  1
    psi[33,13]  column_7  1
    psi[33,13]  column_8  1
    psi[33,13]  column_9  1
    psi[33,13]  column_10  1
    psi[33,13]  column_11  1
    psi[33,13]  column_12  1
    psi[33,13]  column_13  1
    psi[33,13]  column_14  1
    psi[34,8]  OBJ       1
    psi[34,8]  column_0  1
    psi[34,8]  column_1  1
    psi[34,8]  column_2  1
    psi[34,8]  column_3  1
    psi[34,8]  column_4  1
    psi[34,8]  column_5  1
    psi[34,8]  column_6  1
    psi[34,8]  column_7  1
    psi[34,8]  column_8  1
    psi[34,8]  column_9  1
    psi[34,8]  column_10  1
    psi[34,8]  column_11  1
    psi[34,8]  column_12  1
    psi[34,8]  column_13  1
    psi[34,8]  column_14  1
    psi[35,9]  OBJ       1
    psi[35,9]  column_0  1
    psi[35,9]  column_1  1
    psi[35,9]  column_2  1
    psi[35,9]  column_3  1
    psi[35,9]  column_4  1
    psi[35,9]  column_5  1
    psi[35,9]  column_6  1
    psi[35,9]  column_7  1
    psi[35,9]  column_8  1
    psi[35,9]  column_9  1
    psi[35,9]  column_10  1
    psi[35,9]  column_11  1
    psi[35,9]  column_12  1
    psi[35,9]  column_13  1
    psi[35,9]  column_14  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
    a         column_13  1
    a         column_14  1
RHS
    RHS1      column_0  1.4118313013758360e-01
    RHS1      column_1  1.0655599333666714e-01
    RHS1      column_2  9.4844902442851931e-02
    RHS1      column_3  1.0834001050148612e-01
    RHS1      column_4  9.8145454201207349e-02
    RHS1      column_5  9.8231163338409491e-02
    RHS1      column_6  1.1861342688781591e-01
    RHS1      column_7  1.3353545781849310e-01
    RHS1      column_8  1.3330316498657457e-01
    RHS1      column_9  1.2625129118603634e-01
    RHS1      column_10  1.3036449083563234e-01
    RHS1      column_11  1.3330316498657457e-01
    RHS1      column_12  1.8074401196344753e-01
    RHS1      column_13  1.4132370608726103e-01
    RHS1      column_14  1.6095361368861377e-01
BOUNDS
 FX BND1      psi[1,4]  0
 FX BND1      psi[2,12]  0
 FX BND1      psi[3,13]  0
 FX BND1      psi[4,7]  0
 LO BND1      psi[4,13]  -0.05
 UP BND1      psi[4,13]  0.05
 FX BND1      psi[5,8]  0
 FX BND1      psi[6,4]  0
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,7]  0
 LO BND1      psi[8,13]  -0.05
 UP BND1      psi[8,13]  0.05
 LO BND1      psi[9,5]  -0.05
 UP BND1      psi[9,5]  0.05
 FX BND1      psi[9,10]  0
 LO BND1      psi[10,4]  -0.05
 UP BND1      psi[10,4]  0.05
 FX BND1      psi[10,6]  0
 LO BND1      psi[10,7]  -0.05
 UP BND1      psi[10,7]  0.05
 FX BND1      psi[11,7]  0
 FX BND1      psi[12,8]  0
 LO BND1      psi[12,14]  -0.05
 UP BND1      psi[12,14]  0.05
 FX BND1      psi[13,10]  0
 FX BND1      psi[14,10]  0
 FX BND1      psi[15,10]  0
 FX BND1      psi[16,3]  0
 LO BND1      psi[16,11]  -0.05
 UP BND1      psi[16,11]  0.05
 FX BND1      psi[17,16]  0
 FX BND1      psi[18,7]  0
 FX BND1      psi[19,9]  0
 FX BND1      psi[20,7]  0
 FX BND1      psi[21,9]  0
 FX BND1      psi[22,10]  0
 FX BND1      psi[23,8]  0
 LO BND1      psi[23,13]  -0.05
 UP BND1      psi[23,13]  0.05
 FX BND1      psi[24,2]  0
 LO BND1      psi[24,4]  -0.05
 UP BND1      psi[24,4]  0.05
 LO BND1      psi[24,5]  -0.05
 UP BND1      psi[24,5]  0.05
 LO BND1      psi[24,7]  -0.05
 UP BND1      psi[24,7]  0.05
 LO BND1      psi[24,8]  -0.05
 UP BND1      psi[24,8]  0.05
 FX BND1      psi[25,7]  0
 FX BND1      psi[26,8]  0
 LO BND1      psi[26,13]  -0.05
 UP BND1      psi[26,13]  0.05
 FX BND1      psi[27,9]  0
 FX BND1      psi[28,7]  0
 FX BND1      psi[29,7]  0
 FX BND1      psi[30,11]  0
 FX BND1      psi[31,7]  0
 FX BND1      psi[32,8]  0
 FX BND1      psi[33,13]  0
 FX BND1      psi[34,8]  0
 FX BND1      psi[35,9]  0
 FR BND1      a       
ENDATA
