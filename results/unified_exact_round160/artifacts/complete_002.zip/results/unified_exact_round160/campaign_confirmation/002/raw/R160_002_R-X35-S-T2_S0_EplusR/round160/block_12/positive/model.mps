* Signature: 0xf3799eca3f6fdc33
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_5_32
 E  normalized_mass_5_33
 E  normalized_ratio_5_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 E  onehot_7_67
 E  normalized_mass_7_68
 E  normalized_ratio_7_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 E  onehot_34_102
 E  normalized_mass_34_103
 E  normalized_ratio_34_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 E  onehot_6_123
 E  normalized_mass_6_124
 E  normalized_ratio_6_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 E  onehot_22_158
 E  normalized_mass_22_159
 E  normalized_ratio_22_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 E  onehot_3_187
 E  normalized_mass_3_188
 E  normalized_ratio_3_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 E  onehot_27_204
 E  normalized_mass_27_205
 E  normalized_ratio_27_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 E  onehot_8_233
 E  normalized_mass_8_234
 E  normalized_ratio_8_235
 G  stock_lb_236
 L  stock_ub_237
 L  parent_nonstrict_scope_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 E  normalization_295
 G  full_original_Gini_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 L  arc_capacity_398
 L  arc_capacity_399
 L  arc_capacity_400
 L  arc_capacity_401
 L  arc_capacity_402
 L  arc_capacity_403
 L  arc_capacity_404
 L  arc_capacity_405
 L  arc_capacity_406
 L  arc_capacity_407
 L  arc_capacity_408
 L  arc_capacity_409
 L  arc_capacity_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 E  depot_departure_or_bypass_788
 E  depot_return_or_bypass_789
 E  out_degree_790
 E  in_degree_791
 G  order_active_lb_792
 L  order_active_ub_793
 E  segment_load_conservation_794
 G  segment_prefix_lb_795
 L  segment_prefix_ub_796
 E  out_degree_797
 E  in_degree_798
 G  order_active_lb_799
 L  order_active_ub_800
 E  segment_load_conservation_801
 G  segment_prefix_lb_802
 L  segment_prefix_ub_803
 E  out_degree_804
 E  in_degree_805
 G  order_active_lb_806
 L  order_active_ub_807
 E  segment_load_conservation_808
 G  segment_prefix_lb_809
 L  segment_prefix_ub_810
 E  out_degree_811
 E  in_degree_812
 G  order_active_lb_813
 L  order_active_ub_814
 E  segment_load_conservation_815
 G  segment_prefix_lb_816
 L  segment_prefix_ub_817
 E  out_degree_818
 E  in_degree_819
 G  order_active_lb_820
 L  order_active_ub_821
 E  segment_load_conservation_822
 G  segment_prefix_lb_823
 L  segment_prefix_ub_824
 E  out_degree_825
 E  in_degree_826
 G  order_active_lb_827
 L  order_active_ub_828
 E  segment_load_conservation_829
 G  segment_prefix_lb_830
 L  segment_prefix_ub_831
 E  out_degree_832
 E  in_degree_833
 G  order_active_lb_834
 L  order_active_ub_835
 E  service_visit_def_836
 E  free_load_conservation_837
 E  out_degree_838
 E  in_degree_839
 G  order_active_lb_840
 L  order_active_ub_841
 E  service_visit_def_842
 E  free_load_conservation_843
 E  out_degree_844
 E  in_degree_845
 G  order_active_lb_846
 L  order_active_ub_847
 E  service_visit_def_848
 E  free_load_conservation_849
 E  out_degree_850
 E  in_degree_851
 G  order_active_lb_852
 L  order_active_ub_853
 E  service_visit_def_854
 E  free_load_conservation_855
 E  out_degree_856
 E  in_degree_857
 G  order_active_lb_858
 L  order_active_ub_859
 E  service_visit_def_860
 E  free_load_conservation_861
 E  out_degree_862
 E  in_degree_863
 G  order_active_lb_864
 L  order_active_ub_865
 E  service_visit_def_866
 E  free_load_conservation_867
 E  out_degree_868
 E  in_degree_869
 G  order_active_lb_870
 L  order_active_ub_871
 E  service_visit_def_872
 E  free_load_conservation_873
 E  out_degree_874
 E  in_degree_875
 G  order_active_lb_876
 L  order_active_ub_877
 E  service_visit_def_878
 E  free_load_conservation_879
 G  fixed_segment_relative_order_880
 G  fixed_segment_relative_order_881
 G  fixed_segment_relative_order_882
 G  fixed_segment_relative_order_883
 G  fixed_segment_relative_order_884
 L  original_T_including_depot_unload_885
 L  arc_capacity_886
 L  arc_capacity_887
 L  arc_capacity_888
 L  arc_capacity_889
 L  arc_capacity_890
 L  arc_capacity_891
 L  arc_capacity_892
 L  arc_capacity_893
 L  arc_capacity_894
 L  arc_capacity_895
 L  arc_capacity_896
 L  arc_capacity_897
 L  arc_capacity_898
 L  arc_capacity_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 E  depot_departure_or_bypass_1175
 E  depot_return_or_bypass_1176
 E  out_degree_1177
 E  in_degree_1178
 G  order_active_lb_1179
 L  order_active_ub_1180
 E  segment_load_conservation_1181
 G  segment_prefix_lb_1182
 L  segment_prefix_ub_1183
 E  out_degree_1184
 E  in_degree_1185
 G  order_active_lb_1186
 L  order_active_ub_1187
 E  segment_load_conservation_1188
 G  segment_prefix_lb_1189
 L  segment_prefix_ub_1190
 E  out_degree_1191
 E  in_degree_1192
 G  order_active_lb_1193
 L  order_active_ub_1194
 E  segment_load_conservation_1195
 G  segment_prefix_lb_1196
 L  segment_prefix_ub_1197
 E  out_degree_1198
 E  in_degree_1199
 G  order_active_lb_1200
 L  order_active_ub_1201
 E  segment_load_conservation_1202
 G  segment_prefix_lb_1203
 L  segment_prefix_ub_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  service_visit_def_1209
 E  free_load_conservation_1210
 E  out_degree_1211
 E  in_degree_1212
 G  order_active_lb_1213
 L  order_active_ub_1214
 E  service_visit_def_1215
 E  free_load_conservation_1216
 E  out_degree_1217
 E  in_degree_1218
 G  order_active_lb_1219
 L  order_active_ub_1220
 E  service_visit_def_1221
 E  free_load_conservation_1222
 E  out_degree_1223
 E  in_degree_1224
 G  order_active_lb_1225
 L  order_active_ub_1226
 E  service_visit_def_1227
 E  free_load_conservation_1228
 E  out_degree_1229
 E  in_degree_1230
 G  order_active_lb_1231
 L  order_active_ub_1232
 E  service_visit_def_1233
 E  free_load_conservation_1234
 E  out_degree_1235
 E  in_degree_1236
 G  order_active_lb_1237
 L  order_active_ub_1238
 E  service_visit_def_1239
 E  free_load_conservation_1240
 E  out_degree_1241
 E  in_degree_1242
 G  order_active_lb_1243
 L  order_active_ub_1244
 E  service_visit_def_1245
 E  free_load_conservation_1246
 E  out_degree_1247
 E  in_degree_1248
 G  order_active_lb_1249
 L  order_active_ub_1250
 E  service_visit_def_1251
 E  free_load_conservation_1252
 G  fixed_segment_relative_order_1253
 G  fixed_segment_relative_order_1254
 G  fixed_segment_relative_order_1255
 L  original_T_including_depot_unload_1256
 L  arc_capacity_1257
 L  arc_capacity_1258
 L  arc_capacity_1259
 L  arc_capacity_1260
 L  arc_capacity_1261
 L  arc_capacity_1262
 L  arc_capacity_1263
 L  arc_capacity_1264
 L  arc_capacity_1265
 L  arc_capacity_1266
 L  arc_capacity_1267
 L  arc_capacity_1268
 L  arc_capacity_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 E  depot_departure_or_bypass_1500
 E  depot_return_or_bypass_1501
 E  out_degree_1502
 E  in_degree_1503
 G  order_active_lb_1504
 L  order_active_ub_1505
 E  segment_load_conservation_1506
 G  segment_prefix_lb_1507
 L  segment_prefix_ub_1508
 E  out_degree_1509
 E  in_degree_1510
 G  order_active_lb_1511
 L  order_active_ub_1512
 E  segment_load_conservation_1513
 G  segment_prefix_lb_1514
 L  segment_prefix_ub_1515
 E  out_degree_1516
 E  in_degree_1517
 G  order_active_lb_1518
 L  order_active_ub_1519
 E  segment_load_conservation_1520
 G  segment_prefix_lb_1521
 L  segment_prefix_ub_1522
 E  out_degree_1523
 E  in_degree_1524
 G  order_active_lb_1525
 L  order_active_ub_1526
 E  service_visit_def_1527
 E  free_load_conservation_1528
 E  out_degree_1529
 E  in_degree_1530
 G  order_active_lb_1531
 L  order_active_ub_1532
 E  service_visit_def_1533
 E  free_load_conservation_1534
 E  out_degree_1535
 E  in_degree_1536
 G  order_active_lb_1537
 L  order_active_ub_1538
 E  service_visit_def_1539
 E  free_load_conservation_1540
 E  out_degree_1541
 E  in_degree_1542
 G  order_active_lb_1543
 L  order_active_ub_1544
 E  service_visit_def_1545
 E  free_load_conservation_1546
 E  out_degree_1547
 E  in_degree_1548
 G  order_active_lb_1549
 L  order_active_ub_1550
 E  service_visit_def_1551
 E  free_load_conservation_1552
 E  out_degree_1553
 E  in_degree_1554
 G  order_active_lb_1555
 L  order_active_ub_1556
 E  service_visit_def_1557
 E  free_load_conservation_1558
 E  out_degree_1559
 E  in_degree_1560
 G  order_active_lb_1561
 L  order_active_ub_1562
 E  service_visit_def_1563
 E  free_load_conservation_1564
 E  out_degree_1565
 E  in_degree_1566
 G  order_active_lb_1567
 L  order_active_ub_1568
 E  service_visit_def_1569
 E  free_load_conservation_1570
 G  fixed_segment_relative_order_1571
 G  fixed_segment_relative_order_1572
 L  original_T_including_depot_unload_1573
COLUMNS
    t         normalized_mass_5_33  -1
    t         normalized_mass_7_68  -1
    t         normalized_mass_34_103  -1
    t         normalized_mass_6_124  -1
    t         normalized_mass_22_159  -1
    t         normalized_mass_3_188  -1
    t         normalized_mass_27_205  -1
    t         normalized_mass_8_234  -1
    t         normalization_295  2.3130952380952380e+01
    t         full_original_Gini_296  -9.0273809523809433e+01
    q         OBJ       1
    q         parent_nonstrict_scope_238  1
    q         full_original_Gini_296  35
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       1.9549429837111887e-02
    x_5_0     product_lb_0  -2.5358490566012373e-02
    x_5_0     product_ub_1  -4.3232115285684006e-02
    x_5_0     onehot_5_32  1
    x_5_0     parent_nonstrict_scope_238  0.0456153362865944
    x_5_0     unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_0  1
    w_5_0     product_ub_1  1
    w_5_0     normalized_mass_5_33  1
    w_5_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       1.3032953224741260e-02
    x_5_1     product_lb_2  -2.5358490566012373e-02
    x_5_1     product_ub_3  -4.3232115285684006e-02
    x_5_1     onehot_5_32  1
    x_5_1     stock_lb_236  1
    x_5_1     stock_ub_237  1
    x_5_1     parent_nonstrict_scope_238  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_2  1
    w_5_1     product_ub_3  1
    w_5_1     normalized_mass_5_33  1
    w_5_1     normalized_ratio_5_34  -1.4285714285714285e-01
    w_5_1     full_original_Gini_296  -1.9559523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.5164766123706336e-03
    x_5_2     product_lb_4  -2.5358490566012373e-02
    x_5_2     product_ub_5  -4.3232115285684006e-02
    x_5_2     onehot_5_32  1
    x_5_2     stock_lb_236  2
    x_5_2     stock_ub_237  2
    x_5_2     parent_nonstrict_scope_238  3.2582383061853147e-02
    x_5_2     unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_4  1
    w_5_2     product_ub_5  1
    w_5_2     normalized_mass_5_33  1
    w_5_2     normalized_ratio_5_34  -2.8571428571428570e-01
    w_5_2     full_original_Gini_296  -1.5988095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     product_lb_6  -2.5358490566012373e-02
    x_5_3     product_ub_7  -4.3232115285684006e-02
    x_5_3     onehot_5_32  1
    x_5_3     stock_lb_236  3
    x_5_3     stock_ub_237  3
    x_5_3     parent_nonstrict_scope_238  2.6065906449482514e-02
    x_5_3     unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_6  1
    w_5_3     product_ub_7  1
    w_5_3     normalized_mass_5_33  1
    w_5_3     normalized_ratio_5_34  -4.2857142857142855e-01
    w_5_3     full_original_Gini_296  -1.2473809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     OBJ       -6.5164766123706266e-03
    x_5_4     product_lb_8  -2.5358490566012373e-02
    x_5_4     product_ub_9  -4.3232115285684006e-02
    x_5_4     onehot_5_32  1
    x_5_4     stock_lb_236  4
    x_5_4     stock_ub_237  4
    x_5_4     parent_nonstrict_scope_238  1.9549429837111887e-02
    x_5_4     unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_8  1
    w_5_4     product_ub_9  1
    w_5_4     normalized_mass_5_33  1
    w_5_4     normalized_ratio_5_34  -5.7142857142857140e-01
    w_5_4     full_original_Gini_296  -9.1880952380952419e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.3032953224741252e-02
    x_5_5     product_lb_10  -2.5358490566012373e-02
    x_5_5     product_ub_11  -4.3232115285684006e-02
    x_5_5     onehot_5_32  1
    x_5_5     stock_lb_236  5
    x_5_5     stock_ub_237  5
    x_5_5     parent_nonstrict_scope_238  1.3032953224741262e-02
    x_5_5     unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_10  1
    w_5_5     product_ub_11  1
    w_5_5     normalized_mass_5_33  1
    w_5_5     normalized_ratio_5_34  -7.1428571428571419e-01
    w_5_5     full_original_Gini_296  -6.2714285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -1.9549429837111883e-02
    x_5_6     product_lb_12  -2.5358490566012373e-02
    x_5_6     product_ub_13  -4.3232115285684006e-02
    x_5_6     onehot_5_32  1
    x_5_6     stock_lb_236  6
    x_5_6     stock_ub_237  6
    x_5_6     parent_nonstrict_scope_238  6.5164766123706310e-03
    x_5_6     unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_12  1
    w_5_6     product_ub_13  1
    w_5_6     normalized_mass_5_33  1
    w_5_6     normalized_ratio_5_34  -8.5714285714285710e-01
    w_5_6     full_original_Gini_296  -4.7619047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -2.6065906449482514e-02
    x_5_7     product_lb_14  -2.5358490566012373e-02
    x_5_7     product_ub_15  -4.3232115285684006e-02
    x_5_7     onehot_5_32  1
    x_5_7     stock_lb_236  7
    x_5_7     stock_ub_237  7
    x_5_7     unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_14  1
    w_5_7     product_ub_15  1
    w_5_7     normalized_mass_5_33  1
    w_5_7     normalized_ratio_5_34  -1
    w_5_7     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -1.9549429837111887e-02
    x_5_8     product_lb_16  -2.5358490566012373e-02
    x_5_8     product_ub_17  -4.3232115285684006e-02
    x_5_8     onehot_5_32  1
    x_5_8     stock_lb_236  8
    x_5_8     stock_ub_237  8
    x_5_8     parent_nonstrict_scope_238  6.5164766123706258e-03
    x_5_8     unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_16  1
    w_5_8     product_ub_17  1
    w_5_8     normalized_mass_5_33  1
    w_5_8     normalized_ratio_5_34  -1.1428571428571428e+00
    w_5_8     full_original_Gini_296  -8.4404761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -1.3032953224741262e-02
    x_5_9     product_lb_18  -2.5358490566012373e-02
    x_5_9     product_ub_19  -4.3232115285684006e-02
    x_5_9     onehot_5_32  1
    x_5_9     stock_lb_236  9
    x_5_9     stock_ub_237  9
    x_5_9     parent_nonstrict_scope_238  1.3032953224741252e-02
    x_5_9     unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_18  1
    w_5_9     product_ub_19  1
    w_5_9     normalized_mass_5_33  1
    w_5_9     normalized_ratio_5_34  -1.2857142857142856e+00
    w_5_9     full_original_Gini_296  -1.2011904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -6.5164766123706371e-03
    x_5_10    product_lb_20  -2.5358490566012373e-02
    x_5_10    product_ub_21  -4.3232115285684006e-02
    x_5_10    onehot_5_32  1
    x_5_10    stock_lb_236  10
    x_5_10    stock_ub_237  10
    x_5_10    parent_nonstrict_scope_238  1.9549429837111876e-02
    x_5_10    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_20  1
    w_5_10    product_ub_21  1
    w_5_10    normalized_mass_5_33  1
    w_5_10    normalized_ratio_5_34  -1.4285714285714284e+00
    w_5_10    full_original_Gini_296  -1.5583333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_11    product_lb_22  -2.5358490566012373e-02
    x_5_11    product_ub_23  -4.3232115285684006e-02
    x_5_11    onehot_5_32  1
    x_5_11    stock_lb_236  11
    x_5_11    stock_ub_237  11
    x_5_11    parent_nonstrict_scope_238  2.6065906449482514e-02
    x_5_11    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_22  1
    w_5_11    product_ub_23  1
    w_5_11    normalized_mass_5_33  1
    w_5_11    normalized_ratio_5_34  -1.5714285714285714e+00
    w_5_11    full_original_Gini_296  -1.9297619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    OBJ       6.5164766123706266e-03
    x_5_12    product_lb_24  -2.5358490566012373e-02
    x_5_12    product_ub_25  -4.3232115285684006e-02
    x_5_12    onehot_5_32  1
    x_5_12    stock_lb_236  12
    x_5_12    stock_ub_237  12
    x_5_12    parent_nonstrict_scope_238  3.2582383061853140e-02
    x_5_12    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_24  1
    w_5_12    product_ub_25  1
    w_5_12    normalized_mass_5_33  1
    w_5_12    normalized_ratio_5_34  -1.7142857142857142e+00
    w_5_12    full_original_Gini_296  -23.1547619047619
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.3032953224741253e-02
    x_5_13    product_lb_26  -2.5358490566012373e-02
    x_5_13    product_ub_27  -4.3232115285684006e-02
    x_5_13    onehot_5_32  1
    x_5_13    stock_lb_236  13
    x_5_13    stock_ub_237  13
    x_5_13    parent_nonstrict_scope_238  3.9098859674223767e-02
    x_5_13    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_26  1
    w_5_13    product_ub_27  1
    w_5_13    normalized_mass_5_33  1
    w_5_13    normalized_ratio_5_34  -1.8571428571428570e+00
    w_5_13    full_original_Gini_296  -2.7011904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       1.9549429837111887e-02
    x_5_14    product_lb_28  -2.5358490566012373e-02
    x_5_14    product_ub_29  -4.3232115285684006e-02
    x_5_14    onehot_5_32  1
    x_5_14    stock_lb_236  14
    x_5_14    stock_ub_237  14
    x_5_14    parent_nonstrict_scope_238  0.0456153362865944
    x_5_14    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_28  1
    w_5_14    product_ub_29  1
    w_5_14    normalized_mass_5_33  1
    w_5_14    normalized_ratio_5_34  -2
    w_5_14    full_original_Gini_296  -3.0869047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       2.6065906449482514e-02
    x_5_15    product_lb_30  -2.5358490566012373e-02
    x_5_15    product_ub_31  -4.3232115285684006e-02
    x_5_15    onehot_5_32  1
    x_5_15    stock_lb_236  15
    x_5_15    stock_ub_237  15
    x_5_15    parent_nonstrict_scope_238  5.2131812898965027e-02
    x_5_15    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_30  1
    w_5_15    product_ub_31  1
    w_5_15    normalized_mass_5_33  1
    w_5_15    normalized_ratio_5_34  -2.1428571428571428e+00
    w_5_15    full_original_Gini_296  -3.4726190476190474e+01
    rho_5     normalized_ratio_5_34  1
    rho_5     block_pair_pos_243  -1
    rho_5     block_pair_neg_244  1
    rho_5     block_pair_pos_245  -1
    rho_5     block_pair_neg_246  1
    rho_5     block_pair_pos_247  -1
    rho_5     block_pair_neg_248  1
    rho_5     block_pair_pos_249  -1
    rho_5     block_pair_neg_250  1
    rho_5     block_pair_pos_251  -1
    rho_5     block_pair_neg_252  1
    rho_5     block_pair_pos_253  -1
    rho_5     block_pair_neg_254  1
    rho_5     block_pair_pos_255  -1
    rho_5     block_pair_neg_256  1
    rho_5     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       1.9549429837111887e-02
    x_7_0     product_lb_35  -2.5358490566012373e-02
    x_7_0     product_ub_36  -4.3232115285684006e-02
    x_7_0     onehot_7_67  1
    x_7_0     parent_nonstrict_scope_238  0.0456153362865944
    x_7_0     unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_35  1
    w_7_0     product_ub_36  1
    w_7_0     normalized_mass_7_68  1
    w_7_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       1.3032953224741260e-02
    x_7_1     product_lb_37  -2.5358490566012373e-02
    x_7_1     product_ub_38  -4.3232115285684006e-02
    x_7_1     onehot_7_67  1
    x_7_1     stock_lb_236  1
    x_7_1     stock_ub_237  1
    x_7_1     parent_nonstrict_scope_238  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_37  1
    w_7_1     product_ub_38  1
    w_7_1     normalized_mass_7_68  1
    w_7_1     normalized_ratio_7_69  -1.4285714285714285e-01
    w_7_1     full_original_Gini_296  -1.9559523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       6.5164766123706336e-03
    x_7_2     product_lb_39  -2.5358490566012373e-02
    x_7_2     product_ub_40  -4.3232115285684006e-02
    x_7_2     onehot_7_67  1
    x_7_2     stock_lb_236  2
    x_7_2     stock_ub_237  2
    x_7_2     parent_nonstrict_scope_238  3.2582383061853147e-02
    x_7_2     unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_39  1
    w_7_2     product_ub_40  1
    w_7_2     normalized_mass_7_68  1
    w_7_2     normalized_ratio_7_69  -2.8571428571428570e-01
    w_7_2     full_original_Gini_296  -1.5988095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     product_lb_41  -2.5358490566012373e-02
    x_7_3     product_ub_42  -4.3232115285684006e-02
    x_7_3     onehot_7_67  1
    x_7_3     stock_lb_236  3
    x_7_3     stock_ub_237  3
    x_7_3     parent_nonstrict_scope_238  2.6065906449482514e-02
    x_7_3     unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_41  1
    w_7_3     product_ub_42  1
    w_7_3     normalized_mass_7_68  1
    w_7_3     normalized_ratio_7_69  -4.2857142857142855e-01
    w_7_3     full_original_Gini_296  -1.2473809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -6.5164766123706266e-03
    x_7_4     product_lb_43  -2.5358490566012373e-02
    x_7_4     product_ub_44  -4.3232115285684006e-02
    x_7_4     onehot_7_67  1
    x_7_4     stock_lb_236  4
    x_7_4     stock_ub_237  4
    x_7_4     parent_nonstrict_scope_238  1.9549429837111887e-02
    x_7_4     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_43  1
    w_7_4     product_ub_44  1
    w_7_4     normalized_mass_7_68  1
    w_7_4     normalized_ratio_7_69  -5.7142857142857140e-01
    w_7_4     full_original_Gini_296  -9.1880952380952419e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.3032953224741252e-02
    x_7_5     product_lb_45  -2.5358490566012373e-02
    x_7_5     product_ub_46  -4.3232115285684006e-02
    x_7_5     onehot_7_67  1
    x_7_5     stock_lb_236  5
    x_7_5     stock_ub_237  5
    x_7_5     parent_nonstrict_scope_238  1.3032953224741262e-02
    x_7_5     unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_45  1
    w_7_5     product_ub_46  1
    w_7_5     normalized_mass_7_68  1
    w_7_5     normalized_ratio_7_69  -7.1428571428571419e-01
    w_7_5     full_original_Gini_296  -6.2714285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -1.9549429837111883e-02
    x_7_6     product_lb_47  -2.5358490566012373e-02
    x_7_6     product_ub_48  -4.3232115285684006e-02
    x_7_6     onehot_7_67  1
    x_7_6     stock_lb_236  6
    x_7_6     stock_ub_237  6
    x_7_6     parent_nonstrict_scope_238  6.5164766123706310e-03
    x_7_6     unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_47  1
    w_7_6     product_ub_48  1
    w_7_6     normalized_mass_7_68  1
    w_7_6     normalized_ratio_7_69  -8.5714285714285710e-01
    w_7_6     full_original_Gini_296  -4.7619047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -2.6065906449482514e-02
    x_7_7     product_lb_49  -2.5358490566012373e-02
    x_7_7     product_ub_50  -4.3232115285684006e-02
    x_7_7     onehot_7_67  1
    x_7_7     stock_lb_236  7
    x_7_7     stock_ub_237  7
    x_7_7     unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_49  1
    w_7_7     product_ub_50  1
    w_7_7     normalized_mass_7_68  1
    w_7_7     normalized_ratio_7_69  -1
    w_7_7     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -1.9549429837111887e-02
    x_7_8     product_lb_51  -2.5358490566012373e-02
    x_7_8     product_ub_52  -4.3232115285684006e-02
    x_7_8     onehot_7_67  1
    x_7_8     stock_lb_236  8
    x_7_8     stock_ub_237  8
    x_7_8     parent_nonstrict_scope_238  6.5164766123706258e-03
    x_7_8     unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_51  1
    w_7_8     product_ub_52  1
    w_7_8     normalized_mass_7_68  1
    w_7_8     normalized_ratio_7_69  -1.1428571428571428e+00
    w_7_8     full_original_Gini_296  -8.4404761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -1.3032953224741262e-02
    x_7_9     product_lb_53  -2.5358490566012373e-02
    x_7_9     product_ub_54  -4.3232115285684006e-02
    x_7_9     onehot_7_67  1
    x_7_9     stock_lb_236  9
    x_7_9     stock_ub_237  9
    x_7_9     parent_nonstrict_scope_238  1.3032953224741252e-02
    x_7_9     unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_53  1
    w_7_9     product_ub_54  1
    w_7_9     normalized_mass_7_68  1
    w_7_9     normalized_ratio_7_69  -1.2857142857142856e+00
    w_7_9     full_original_Gini_296  -1.2011904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -6.5164766123706371e-03
    x_7_10    product_lb_55  -2.5358490566012373e-02
    x_7_10    product_ub_56  -4.3232115285684006e-02
    x_7_10    onehot_7_67  1
    x_7_10    stock_lb_236  10
    x_7_10    stock_ub_237  10
    x_7_10    parent_nonstrict_scope_238  1.9549429837111876e-02
    x_7_10    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_55  1
    w_7_10    product_ub_56  1
    w_7_10    normalized_mass_7_68  1
    w_7_10    normalized_ratio_7_69  -1.4285714285714284e+00
    w_7_10    full_original_Gini_296  -1.5583333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    product_lb_57  -2.5358490566012373e-02
    x_7_11    product_ub_58  -4.3232115285684006e-02
    x_7_11    onehot_7_67  1
    x_7_11    stock_lb_236  11
    x_7_11    stock_ub_237  11
    x_7_11    parent_nonstrict_scope_238  2.6065906449482514e-02
    x_7_11    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_57  1
    w_7_11    product_ub_58  1
    w_7_11    normalized_mass_7_68  1
    w_7_11    normalized_ratio_7_69  -1.5714285714285714e+00
    w_7_11    full_original_Gini_296  -1.9297619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       6.5164766123706266e-03
    x_7_12    product_lb_59  -2.5358490566012373e-02
    x_7_12    product_ub_60  -4.3232115285684006e-02
    x_7_12    onehot_7_67  1
    x_7_12    stock_lb_236  12
    x_7_12    stock_ub_237  12
    x_7_12    parent_nonstrict_scope_238  3.2582383061853140e-02
    x_7_12    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_59  1
    w_7_12    product_ub_60  1
    w_7_12    normalized_mass_7_68  1
    w_7_12    normalized_ratio_7_69  -1.7142857142857142e+00
    w_7_12    full_original_Gini_296  -23.1547619047619
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       1.3032953224741253e-02
    x_7_13    product_lb_61  -2.5358490566012373e-02
    x_7_13    product_ub_62  -4.3232115285684006e-02
    x_7_13    onehot_7_67  1
    x_7_13    stock_lb_236  13
    x_7_13    stock_ub_237  13
    x_7_13    parent_nonstrict_scope_238  3.9098859674223767e-02
    x_7_13    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_61  1
    w_7_13    product_ub_62  1
    w_7_13    normalized_mass_7_68  1
    w_7_13    normalized_ratio_7_69  -1.8571428571428570e+00
    w_7_13    full_original_Gini_296  -2.7011904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.9549429837111887e-02
    x_7_14    product_lb_63  -2.5358490566012373e-02
    x_7_14    product_ub_64  -4.3232115285684006e-02
    x_7_14    onehot_7_67  1
    x_7_14    stock_lb_236  14
    x_7_14    stock_ub_237  14
    x_7_14    parent_nonstrict_scope_238  0.0456153362865944
    x_7_14    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_63  1
    w_7_14    product_ub_64  1
    w_7_14    normalized_mass_7_68  1
    w_7_14    normalized_ratio_7_69  -2
    w_7_14    full_original_Gini_296  -3.0869047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       2.6065906449482514e-02
    x_7_15    product_lb_65  -2.5358490566012373e-02
    x_7_15    product_ub_66  -4.3232115285684006e-02
    x_7_15    onehot_7_67  1
    x_7_15    stock_lb_236  15
    x_7_15    stock_ub_237  15
    x_7_15    parent_nonstrict_scope_238  5.2131812898965027e-02
    x_7_15    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_65  1
    w_7_15    product_ub_66  1
    w_7_15    normalized_mass_7_68  1
    w_7_15    normalized_ratio_7_69  -2.1428571428571428e+00
    w_7_15    full_original_Gini_296  -3.4726190476190474e+01
    rho_7     normalized_ratio_7_69  1
    rho_7     block_pair_pos_247  1
    rho_7     block_pair_neg_248  -1
    rho_7     block_pair_pos_265  -1
    rho_7     block_pair_neg_266  1
    rho_7     block_pair_pos_267  -1
    rho_7     block_pair_neg_268  1
    rho_7     block_pair_pos_269  -1
    rho_7     block_pair_neg_270  1
    rho_7     block_pair_pos_271  -1
    rho_7     block_pair_neg_272  1
    rho_7     block_pair_pos_273  -1
    rho_7     block_pair_neg_274  1
    rho_7     block_pair_pos_275  -1
    rho_7     block_pair_neg_276  1
    rho_7     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_70  -2.5358490566012373e-02
    x_34_0    product_ub_71  -4.3232115285684006e-02
    x_34_0    onehot_34_102  1
    x_34_0    parent_nonstrict_scope_238  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_70  1
    w_34_0    product_ub_71  1
    w_34_0    normalized_mass_34_103  1
    w_34_0    full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_72  -2.5358490566012373e-02
    x_34_1    product_ub_73  -4.3232115285684006e-02
    x_34_1    onehot_34_102  1
    x_34_1    stock_lb_236  1
    x_34_1    stock_ub_237  1
    x_34_1    parent_nonstrict_scope_238  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_72  1
    w_34_1    product_ub_73  1
    w_34_1    normalized_mass_34_103  1
    w_34_1    normalized_ratio_34_104  -0.125
    w_34_1    full_original_Gini_296  -2.0005952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_74  -2.5358490566012373e-02
    x_34_2    product_ub_75  -4.3232115285684006e-02
    x_34_2    onehot_34_102  1
    x_34_2    stock_lb_236  2
    x_34_2    stock_ub_237  2
    x_34_2    parent_nonstrict_scope_238  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_74  1
    w_34_2    product_ub_75  1
    w_34_2    normalized_mass_34_103  1
    w_34_2    normalized_ratio_34_104  -0.25
    w_34_2    full_original_Gini_296  -1.6880952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_76  -2.5358490566012373e-02
    x_34_3    product_ub_77  -4.3232115285684006e-02
    x_34_3    onehot_34_102  1
    x_34_3    stock_lb_236  3
    x_34_3    stock_ub_237  3
    x_34_3    parent_nonstrict_scope_238  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_76  1
    w_34_3    product_ub_77  1
    w_34_3    normalized_mass_34_103  1
    w_34_3    normalized_ratio_34_104  -0.375
    w_34_3    full_original_Gini_296  -1.3755952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_78  -2.5358490566012373e-02
    x_34_4    product_ub_79  -4.3232115285684006e-02
    x_34_4    onehot_34_102  1
    x_34_4    stock_lb_236  4
    x_34_4    stock_ub_237  4
    x_34_4    parent_nonstrict_scope_238  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_78  1
    w_34_4    product_ub_79  1
    w_34_4    normalized_mass_34_103  1
    w_34_4    normalized_ratio_34_104  -0.5
    w_34_4    full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_80  -2.5358490566012373e-02
    x_34_5    product_ub_81  -4.3232115285684006e-02
    x_34_5    onehot_34_102  1
    x_34_5    stock_lb_236  5
    x_34_5    stock_ub_237  5
    x_34_5    parent_nonstrict_scope_238  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_80  1
    w_34_5    product_ub_81  1
    w_34_5    normalized_mass_34_103  1
    w_34_5    normalized_ratio_34_104  -0.625
    w_34_5    full_original_Gini_296  -7.9559523809523816e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_82  -2.5358490566012373e-02
    x_34_6    product_ub_83  -4.3232115285684006e-02
    x_34_6    onehot_34_102  1
    x_34_6    stock_lb_236  6
    x_34_6    stock_ub_237  6
    x_34_6    parent_nonstrict_scope_238  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_82  1
    w_34_6    product_ub_83  1
    w_34_6    normalized_mass_34_103  1
    w_34_6    normalized_ratio_34_104  -0.75
    w_34_6    full_original_Gini_296  -5.6642857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_84  -2.5358490566012373e-02
    x_34_7    product_ub_85  -4.3232115285684006e-02
    x_34_7    onehot_34_102  1
    x_34_7    stock_lb_236  7
    x_34_7    stock_ub_237  7
    x_34_7    parent_nonstrict_scope_238  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_84  1
    w_34_7    product_ub_85  1
    w_34_7    normalized_mass_34_103  1
    w_34_7    normalized_ratio_34_104  -0.875
    w_34_7    full_original_Gini_296  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_86  -2.5358490566012373e-02
    x_34_8    product_ub_87  -4.3232115285684006e-02
    x_34_8    onehot_34_102  1
    x_34_8    stock_lb_236  8
    x_34_8    stock_ub_237  8
    x_34_8    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_86  1
    w_34_8    product_ub_87  1
    w_34_8    normalized_mass_34_103  1
    w_34_8    normalized_ratio_34_104  -1
    w_34_8    full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_88  -2.5358490566012373e-02
    x_34_9    product_ub_89  -4.3232115285684006e-02
    x_34_9    onehot_34_102  1
    x_34_9    stock_lb_236  9
    x_34_9    stock_ub_237  9
    x_34_9    parent_nonstrict_scope_238  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_88  1
    w_34_9    product_ub_89  1
    w_34_9    normalized_mass_34_103  1
    w_34_9    normalized_ratio_34_104  -1.125
    w_34_9    full_original_Gini_296  -7.9940476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_90  -2.5358490566012373e-02
    x_34_10   product_ub_91  -4.3232115285684006e-02
    x_34_10   onehot_34_102  1
    x_34_10   stock_lb_236  10
    x_34_10   stock_ub_237  10
    x_34_10   parent_nonstrict_scope_238  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_90  1
    w_34_10   product_ub_91  1
    w_34_10   normalized_mass_34_103  1
    w_34_10   normalized_ratio_34_104  -1.25
    w_34_10   full_original_Gini_296  -1.1119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_92  -2.5358490566012373e-02
    x_34_11   product_ub_93  -4.3232115285684006e-02
    x_34_11   onehot_34_102  1
    x_34_11   stock_lb_236  11
    x_34_11   stock_ub_237  11
    x_34_11   parent_nonstrict_scope_238  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_92  1
    w_34_11   product_ub_93  1
    w_34_11   normalized_mass_34_103  1
    w_34_11   normalized_ratio_34_104  -1.375
    w_34_11   full_original_Gini_296  -1.4244047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_94  -2.5358490566012373e-02
    x_34_12   product_ub_95  -4.3232115285684006e-02
    x_34_12   onehot_34_102  1
    x_34_12   stock_lb_236  12
    x_34_12   stock_ub_237  12
    x_34_12   parent_nonstrict_scope_238  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_94  1
    w_34_12   product_ub_95  1
    w_34_12   normalized_mass_34_103  1
    w_34_12   normalized_ratio_34_104  -1.5
    w_34_12   full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_96  -2.5358490566012373e-02
    x_34_13   product_ub_97  -4.3232115285684006e-02
    x_34_13   onehot_34_102  1
    x_34_13   stock_lb_236  13
    x_34_13   stock_ub_237  13
    x_34_13   parent_nonstrict_scope_238  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_96  1
    w_34_13   product_ub_97  1
    w_34_13   normalized_mass_34_103  1
    w_34_13   normalized_ratio_34_104  -1.625
    w_34_13   full_original_Gini_296  -2.0744047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_98  -2.5358490566012373e-02
    x_34_14   product_ub_99  -4.3232115285684006e-02
    x_34_14   onehot_34_102  1
    x_34_14   stock_lb_236  14
    x_34_14   stock_ub_237  14
    x_34_14   parent_nonstrict_scope_238  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_98  1
    w_34_14   product_ub_99  1
    w_34_14   normalized_mass_34_103  1
    w_34_14   normalized_ratio_34_104  -1.75
    w_34_14   full_original_Gini_296  -2.4119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_100  -2.5358490566012373e-02
    x_34_15   product_ub_101  -4.3232115285684006e-02
    x_34_15   onehot_34_102  1
    x_34_15   stock_lb_236  15
    x_34_15   stock_ub_237  15
    x_34_15   parent_nonstrict_scope_238  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_100  1
    w_34_15   product_ub_101  1
    w_34_15   normalized_mass_34_103  1
    w_34_15   normalized_ratio_34_104  -1.875
    w_34_15   full_original_Gini_296  -2.7494047619047620e+01
    rho_34    normalized_ratio_34_104  1
    rho_34    block_pair_pos_255  1
    rho_34    block_pair_neg_256  -1
    rho_34    block_pair_pos_275  1
    rho_34    block_pair_neg_276  -1
    rho_34    block_pair_pos_285  -1
    rho_34    block_pair_neg_286  1
    rho_34    block_pair_pos_287  -1
    rho_34    block_pair_neg_288  1
    rho_34    block_pair_pos_289  -1
    rho_34    block_pair_neg_290  1
    rho_34    block_pair_pos_291  -1
    rho_34    block_pair_neg_292  1
    rho_34    block_pair_pos_293  -1
    rho_34    block_pair_neg_294  1
    rho_34    normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       7.4474103065332977e-03
    x_6_0     product_lb_105  -2.5358490566012373e-02
    x_6_0     product_ub_106  -4.3232115285684006e-02
    x_6_0     onehot_6_123  1
    x_6_0     parent_nonstrict_scope_238  1.4894820613066595e-02
    x_6_0     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_105  1
    w_6_0     product_ub_106  1
    w_6_0     normalized_mass_6_124  1
    w_6_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       3.7237051532666493e-03
    x_6_1     product_lb_107  -2.5358490566012373e-02
    x_6_1     product_ub_108  -4.3232115285684006e-02
    x_6_1     onehot_6_123  1
    x_6_1     stock_lb_236  1
    x_6_1     stock_ub_237  1
    x_6_1     parent_nonstrict_scope_238  1.1171115459799947e-02
    x_6_1     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_107  1
    w_6_1     product_ub_108  1
    w_6_1     normalized_mass_6_124  1
    w_6_1     normalized_ratio_6_125  -0.25
    w_6_1     full_original_Gini_296  -1.6880952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     product_lb_109  -2.5358490566012373e-02
    x_6_2     product_ub_110  -4.3232115285684006e-02
    x_6_2     onehot_6_123  1
    x_6_2     stock_lb_236  2
    x_6_2     stock_ub_237  2
    x_6_2     parent_nonstrict_scope_238  7.4474103065332977e-03
    x_6_2     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_109  1
    w_6_2     product_ub_110  1
    w_6_2     normalized_mass_6_124  1
    w_6_2     normalized_ratio_6_125  -0.5
    w_6_2     full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7237051532666488e-03
    x_6_3     product_lb_111  -2.5358490566012373e-02
    x_6_3     product_ub_112  -4.3232115285684006e-02
    x_6_3     onehot_6_123  1
    x_6_3     stock_lb_236  3
    x_6_3     stock_ub_237  3
    x_6_3     parent_nonstrict_scope_238  3.7237051532666488e-03
    x_6_3     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_111  1
    w_6_3     product_ub_112  1
    w_6_3     normalized_mass_6_124  1
    w_6_3     normalized_ratio_6_125  -0.75
    w_6_3     full_original_Gini_296  -5.6642857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -7.4474103065332977e-03
    x_6_4     product_lb_113  -2.5358490566012373e-02
    x_6_4     product_ub_114  -4.3232115285684006e-02
    x_6_4     onehot_6_123  1
    x_6_4     stock_lb_236  4
    x_6_4     stock_ub_237  4
    x_6_4     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_113  1
    w_6_4     product_ub_114  1
    w_6_4     normalized_mass_6_124  1
    w_6_4     normalized_ratio_6_125  -1
    w_6_4     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -3.7237051532666488e-03
    x_6_5     product_lb_115  -2.5358490566012373e-02
    x_6_5     product_ub_116  -4.3232115285684006e-02
    x_6_5     onehot_6_123  1
    x_6_5     stock_lb_236  5
    x_6_5     stock_ub_237  5
    x_6_5     parent_nonstrict_scope_238  3.7237051532666488e-03
    x_6_5     unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_115  1
    w_6_5     product_ub_116  1
    w_6_5     normalized_mass_6_124  1
    w_6_5     normalized_ratio_6_125  -1.25
    w_6_5     full_original_Gini_296  -1.1119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_6     product_lb_117  -2.5358490566012373e-02
    x_6_6     product_ub_118  -4.3232115285684006e-02
    x_6_6     onehot_6_123  1
    x_6_6     stock_lb_236  6
    x_6_6     stock_ub_237  6
    x_6_6     parent_nonstrict_scope_238  7.4474103065332977e-03
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_117  1
    w_6_6     product_ub_118  1
    w_6_6     normalized_mass_6_124  1
    w_6_6     normalized_ratio_6_125  -1.5
    w_6_6     full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       3.7237051532666493e-03
    x_6_7     product_lb_119  -2.5358490566012373e-02
    x_6_7     product_ub_120  -4.3232115285684006e-02
    x_6_7     onehot_6_123  1
    x_6_7     stock_lb_236  7
    x_6_7     stock_ub_237  7
    x_6_7     parent_nonstrict_scope_238  1.1171115459799947e-02
    x_6_7     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_119  1
    w_6_7     product_ub_120  1
    w_6_7     normalized_mass_6_124  1
    w_6_7     normalized_ratio_6_125  -1.75
    w_6_7     full_original_Gini_296  -2.4119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       7.4474103065332977e-03
    x_6_8     product_lb_121  -2.5358490566012373e-02
    x_6_8     product_ub_122  -4.3232115285684006e-02
    x_6_8     onehot_6_123  1
    x_6_8     stock_lb_236  8
    x_6_8     stock_ub_237  8
    x_6_8     parent_nonstrict_scope_238  1.4894820613066595e-02
    x_6_8     unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_121  1
    w_6_8     product_ub_122  1
    w_6_8     normalized_mass_6_124  1
    w_6_8     normalized_ratio_6_125  -2
    w_6_8     full_original_Gini_296  -3.0869047619047620e+01
    rho_6     normalized_ratio_6_125  1
    rho_6     block_pair_pos_245  1
    rho_6     block_pair_neg_246  -1
    rho_6     block_pair_pos_257  -1
    rho_6     block_pair_neg_258  1
    rho_6     block_pair_pos_259  -1
    rho_6     block_pair_neg_260  1
    rho_6     block_pair_pos_261  -1
    rho_6     block_pair_neg_262  1
    rho_6     block_pair_pos_263  -1
    rho_6     block_pair_neg_264  1
    rho_6     block_pair_pos_267  1
    rho_6     block_pair_neg_268  -1
    rho_6     block_pair_pos_287  1
    rho_6     block_pair_neg_288  -1
    rho_6     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_126  -2.5358490566012373e-02
    x_22_0    product_ub_127  -4.3232115285684006e-02
    x_22_0    onehot_22_158  1
    x_22_0    parent_nonstrict_scope_238  0.0456153362865944
    x_22_0    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_126  1
    w_22_0    product_ub_127  1
    w_22_0    normalized_mass_22_159  1
    w_22_0    full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_128  -2.5358490566012373e-02
    x_22_1    product_ub_129  -4.3232115285684006e-02
    x_22_1    onehot_22_158  1
    x_22_1    stock_lb_236  1
    x_22_1    stock_ub_237  1
    x_22_1    parent_nonstrict_scope_238  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_128  1
    w_22_1    product_ub_129  1
    w_22_1    normalized_mass_22_159  1
    w_22_1    normalized_ratio_22_160  -1.4285714285714285e-01
    w_22_1    full_original_Gini_296  -1.9559523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_130  -2.5358490566012373e-02
    x_22_2    product_ub_131  -4.3232115285684006e-02
    x_22_2    onehot_22_158  1
    x_22_2    stock_lb_236  2
    x_22_2    stock_ub_237  2
    x_22_2    parent_nonstrict_scope_238  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_130  1
    w_22_2    product_ub_131  1
    w_22_2    normalized_mass_22_159  1
    w_22_2    normalized_ratio_22_160  -2.8571428571428570e-01
    w_22_2    full_original_Gini_296  -1.5988095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_132  -2.5358490566012373e-02
    x_22_3    product_ub_133  -4.3232115285684006e-02
    x_22_3    onehot_22_158  1
    x_22_3    stock_lb_236  3
    x_22_3    stock_ub_237  3
    x_22_3    parent_nonstrict_scope_238  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_132  1
    w_22_3    product_ub_133  1
    w_22_3    normalized_mass_22_159  1
    w_22_3    normalized_ratio_22_160  -4.2857142857142855e-01
    w_22_3    full_original_Gini_296  -1.2473809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_134  -2.5358490566012373e-02
    x_22_4    product_ub_135  -4.3232115285684006e-02
    x_22_4    onehot_22_158  1
    x_22_4    stock_lb_236  4
    x_22_4    stock_ub_237  4
    x_22_4    parent_nonstrict_scope_238  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_134  1
    w_22_4    product_ub_135  1
    w_22_4    normalized_mass_22_159  1
    w_22_4    normalized_ratio_22_160  -5.7142857142857140e-01
    w_22_4    full_original_Gini_296  -9.1880952380952419e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_136  -2.5358490566012373e-02
    x_22_5    product_ub_137  -4.3232115285684006e-02
    x_22_5    onehot_22_158  1
    x_22_5    stock_lb_236  5
    x_22_5    stock_ub_237  5
    x_22_5    parent_nonstrict_scope_238  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_136  1
    w_22_5    product_ub_137  1
    w_22_5    normalized_mass_22_159  1
    w_22_5    normalized_ratio_22_160  -7.1428571428571419e-01
    w_22_5    full_original_Gini_296  -6.2714285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_138  -2.5358490566012373e-02
    x_22_6    product_ub_139  -4.3232115285684006e-02
    x_22_6    onehot_22_158  1
    x_22_6    stock_lb_236  6
    x_22_6    stock_ub_237  6
    x_22_6    parent_nonstrict_scope_238  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_138  1
    w_22_6    product_ub_139  1
    w_22_6    normalized_mass_22_159  1
    w_22_6    normalized_ratio_22_160  -8.5714285714285710e-01
    w_22_6    full_original_Gini_296  -4.7619047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_140  -2.5358490566012373e-02
    x_22_7    product_ub_141  -4.3232115285684006e-02
    x_22_7    onehot_22_158  1
    x_22_7    stock_lb_236  7
    x_22_7    stock_ub_237  7
    x_22_7    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_140  1
    w_22_7    product_ub_141  1
    w_22_7    normalized_mass_22_159  1
    w_22_7    normalized_ratio_22_160  -1
    w_22_7    full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_142  -2.5358490566012373e-02
    x_22_8    product_ub_143  -4.3232115285684006e-02
    x_22_8    onehot_22_158  1
    x_22_8    stock_lb_236  8
    x_22_8    stock_ub_237  8
    x_22_8    parent_nonstrict_scope_238  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_142  1
    w_22_8    product_ub_143  1
    w_22_8    normalized_mass_22_159  1
    w_22_8    normalized_ratio_22_160  -1.1428571428571428e+00
    w_22_8    full_original_Gini_296  -8.4404761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_144  -2.5358490566012373e-02
    x_22_9    product_ub_145  -4.3232115285684006e-02
    x_22_9    onehot_22_158  1
    x_22_9    stock_lb_236  9
    x_22_9    stock_ub_237  9
    x_22_9    parent_nonstrict_scope_238  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_144  1
    w_22_9    product_ub_145  1
    w_22_9    normalized_mass_22_159  1
    w_22_9    normalized_ratio_22_160  -1.2857142857142856e+00
    w_22_9    full_original_Gini_296  -1.2011904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_146  -2.5358490566012373e-02
    x_22_10   product_ub_147  -4.3232115285684006e-02
    x_22_10   onehot_22_158  1
    x_22_10   stock_lb_236  10
    x_22_10   stock_ub_237  10
    x_22_10   parent_nonstrict_scope_238  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_146  1
    w_22_10   product_ub_147  1
    w_22_10   normalized_mass_22_159  1
    w_22_10   normalized_ratio_22_160  -1.4285714285714284e+00
    w_22_10   full_original_Gini_296  -1.5583333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_148  -2.5358490566012373e-02
    x_22_11   product_ub_149  -4.3232115285684006e-02
    x_22_11   onehot_22_158  1
    x_22_11   stock_lb_236  11
    x_22_11   stock_ub_237  11
    x_22_11   parent_nonstrict_scope_238  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_148  1
    w_22_11   product_ub_149  1
    w_22_11   normalized_mass_22_159  1
    w_22_11   normalized_ratio_22_160  -1.5714285714285714e+00
    w_22_11   full_original_Gini_296  -1.9297619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_150  -2.5358490566012373e-02
    x_22_12   product_ub_151  -4.3232115285684006e-02
    x_22_12   onehot_22_158  1
    x_22_12   stock_lb_236  12
    x_22_12   stock_ub_237  12
    x_22_12   parent_nonstrict_scope_238  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_150  1
    w_22_12   product_ub_151  1
    w_22_12   normalized_mass_22_159  1
    w_22_12   normalized_ratio_22_160  -1.7142857142857142e+00
    w_22_12   full_original_Gini_296  -23.1547619047619
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_152  -2.5358490566012373e-02
    x_22_13   product_ub_153  -4.3232115285684006e-02
    x_22_13   onehot_22_158  1
    x_22_13   stock_lb_236  13
    x_22_13   stock_ub_237  13
    x_22_13   parent_nonstrict_scope_238  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_152  1
    w_22_13   product_ub_153  1
    w_22_13   normalized_mass_22_159  1
    w_22_13   normalized_ratio_22_160  -1.8571428571428570e+00
    w_22_13   full_original_Gini_296  -2.7011904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_154  -2.5358490566012373e-02
    x_22_14   product_ub_155  -4.3232115285684006e-02
    x_22_14   onehot_22_158  1
    x_22_14   stock_lb_236  14
    x_22_14   stock_ub_237  14
    x_22_14   parent_nonstrict_scope_238  0.0456153362865944
    x_22_14   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_154  1
    w_22_14   product_ub_155  1
    w_22_14   normalized_mass_22_159  1
    w_22_14   normalized_ratio_22_160  -2
    w_22_14   full_original_Gini_296  -3.0869047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_156  -2.5358490566012373e-02
    x_22_15   product_ub_157  -4.3232115285684006e-02
    x_22_15   onehot_22_158  1
    x_22_15   stock_lb_236  15
    x_22_15   stock_ub_237  15
    x_22_15   parent_nonstrict_scope_238  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_156  1
    w_22_15   product_ub_157  1
    w_22_15   normalized_mass_22_159  1
    w_22_15   normalized_ratio_22_160  -2.1428571428571428e+00
    w_22_15   full_original_Gini_296  -3.4726190476190474e+01
    rho_22    normalized_ratio_22_160  1
    rho_22    block_pair_pos_251  1
    rho_22    block_pair_neg_252  -1
    rho_22    block_pair_pos_261  1
    rho_22    block_pair_neg_262  -1
    rho_22    block_pair_pos_271  1
    rho_22    block_pair_neg_272  -1
    rho_22    block_pair_pos_277  -1
    rho_22    block_pair_neg_278  1
    rho_22    block_pair_pos_279  -1
    rho_22    block_pair_neg_280  1
    rho_22    block_pair_pos_281  -1
    rho_22    block_pair_neg_282  1
    rho_22    block_pair_pos_291  1
    rho_22    block_pair_neg_292  -1
    rho_22    normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       1.6756644912833352e-02
    x_3_0     product_lb_161  -2.5358490566012373e-02
    x_3_0     product_ub_162  -4.3232115285684006e-02
    x_3_0     onehot_3_187  1
    x_3_0     parent_nonstrict_scope_238  0.0335132898256667
    x_3_0     unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_161  1
    w_3_0     product_ub_162  1
    w_3_0     normalized_mass_3_188  1
    w_3_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       1.1171096608555569e-02
    x_3_1     product_lb_163  -2.5358490566012373e-02
    x_3_1     product_ub_164  -4.3232115285684006e-02
    x_3_1     onehot_3_187  1
    x_3_1     stock_lb_236  1
    x_3_1     stock_ub_237  1
    x_3_1     parent_nonstrict_scope_238  2.7927741521388921e-02
    x_3_1     unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_163  1
    w_3_1     product_ub_164  1
    w_3_1     normalized_mass_3_188  1
    w_3_1     normalized_ratio_3_189  -1.6666666666666666e-01
    w_3_1     full_original_Gini_296  -1.8964285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       5.5855483042777862e-03
    x_3_2     product_lb_165  -2.5358490566012373e-02
    x_3_2     product_ub_166  -4.3232115285684006e-02
    x_3_2     onehot_3_187  1
    x_3_2     stock_lb_236  2
    x_3_2     stock_ub_237  2
    x_3_2     parent_nonstrict_scope_238  2.2342193217111138e-02
    x_3_2     unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_165  1
    w_3_2     product_ub_166  1
    w_3_2     normalized_mass_3_188  1
    w_3_2     normalized_ratio_3_189  -3.3333333333333331e-01
    w_3_2     full_original_Gini_296  -1.4797619047619046e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     product_lb_167  -2.5358490566012373e-02
    x_3_3     product_ub_168  -4.3232115285684006e-02
    x_3_3     onehot_3_187  1
    x_3_3     stock_lb_236  3
    x_3_3     stock_ub_237  3
    x_3_3     parent_nonstrict_scope_238  1.6756644912833352e-02
    x_3_3     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_167  1
    w_3_3     product_ub_168  1
    w_3_3     normalized_mass_3_188  1
    w_3_3     normalized_ratio_3_189  -0.5
    w_3_3     full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.5855483042777827e-03
    x_3_4     product_lb_169  -2.5358490566012373e-02
    x_3_4     product_ub_170  -4.3232115285684006e-02
    x_3_4     onehot_3_187  1
    x_3_4     stock_lb_236  4
    x_3_4     stock_ub_237  4
    x_3_4     parent_nonstrict_scope_238  1.1171096608555569e-02
    x_3_4     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_169  1
    w_3_4     product_ub_170  1
    w_3_4     normalized_mass_3_188  1
    w_3_4     normalized_ratio_3_189  -6.6666666666666663e-01
    w_3_4     full_original_Gini_296  -7.0809523809523807e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.1171096608555565e-02
    x_3_5     product_lb_171  -2.5358490566012373e-02
    x_3_5     product_ub_172  -4.3232115285684006e-02
    x_3_5     onehot_3_187  1
    x_3_5     stock_lb_236  5
    x_3_5     stock_ub_237  5
    x_3_5     parent_nonstrict_scope_238  5.5855483042777862e-03
    x_3_5     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_171  1
    w_3_5     product_ub_172  1
    w_3_5     normalized_mass_3_188  1
    w_3_5     normalized_ratio_3_189  -8.3333333333333326e-01
    w_3_5     full_original_Gini_296  -4.8809523809523814e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -1.6756644912833352e-02
    x_3_6     product_lb_173  -2.5358490566012373e-02
    x_3_6     product_ub_174  -4.3232115285684006e-02
    x_3_6     onehot_3_187  1
    x_3_6     stock_lb_236  6
    x_3_6     stock_ub_237  6
    x_3_6     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_173  1
    w_3_6     product_ub_174  1
    w_3_6     normalized_mass_3_188  1
    w_3_6     normalized_ratio_3_189  -1
    w_3_6     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -1.1171096608555572e-02
    x_3_7     product_lb_175  -2.5358490566012373e-02
    x_3_7     product_ub_176  -4.3232115285684006e-02
    x_3_7     onehot_3_187  1
    x_3_7     stock_lb_236  7
    x_3_7     stock_ub_237  7
    x_3_7     parent_nonstrict_scope_238  5.5855483042777793e-03
    x_3_7     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_175  1
    w_3_7     product_ub_176  1
    w_3_7     normalized_mass_3_188  1
    w_3_7     normalized_ratio_3_189  -1.1666666666666665e+00
    w_3_7     full_original_Gini_296  -9.03571428571428
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.5855483042777862e-03
    x_3_8     product_lb_177  -2.5358490566012373e-02
    x_3_8     product_ub_178  -4.3232115285684006e-02
    x_3_8     onehot_3_187  1
    x_3_8     stock_lb_236  8
    x_3_8     stock_ub_237  8
    x_3_8     parent_nonstrict_scope_238  1.1171096608555565e-02
    x_3_8     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_177  1
    w_3_8     product_ub_178  1
    w_3_8     normalized_mass_3_188  1
    w_3_8     normalized_ratio_3_189  -1.3333333333333333e+00
    w_3_8     full_original_Gini_296  -1.3202380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_9     product_lb_179  -2.5358490566012373e-02
    x_3_9     product_ub_180  -4.3232115285684006e-02
    x_3_9     onehot_3_187  1
    x_3_9     stock_lb_236  9
    x_3_9     stock_ub_237  9
    x_3_9     parent_nonstrict_scope_238  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_179  1
    w_3_9     product_ub_180  1
    w_3_9     normalized_mass_3_188  1
    w_3_9     normalized_ratio_3_189  -1.5
    w_3_9     full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       5.5855483042777793e-03
    x_3_10    product_lb_181  -2.5358490566012373e-02
    x_3_10    product_ub_182  -4.3232115285684006e-02
    x_3_10    onehot_3_187  1
    x_3_10    stock_lb_236  10
    x_3_10    stock_ub_237  10
    x_3_10    parent_nonstrict_scope_238  2.2342193217111131e-02
    x_3_10    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_181  1
    w_3_10    product_ub_182  1
    w_3_10    normalized_mass_3_188  1
    w_3_10    normalized_ratio_3_189  -1.6666666666666665e+00
    w_3_10    full_original_Gini_296  -2.1869047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       1.1171096608555565e-02
    x_3_11    product_lb_183  -2.5358490566012373e-02
    x_3_11    product_ub_184  -4.3232115285684006e-02
    x_3_11    onehot_3_187  1
    x_3_11    stock_lb_236  11
    x_3_11    stock_ub_237  11
    x_3_11    parent_nonstrict_scope_238  2.7927741521388917e-02
    x_3_11    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_183  1
    w_3_11    product_ub_184  1
    w_3_11    normalized_mass_3_188  1
    w_3_11    normalized_ratio_3_189  -1.8333333333333333e+00
    w_3_11    full_original_Gini_296  -2.6369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       1.6756644912833352e-02
    x_3_12    product_lb_185  -2.5358490566012373e-02
    x_3_12    product_ub_186  -4.3232115285684006e-02
    x_3_12    onehot_3_187  1
    x_3_12    stock_lb_236  12
    x_3_12    stock_ub_237  12
    x_3_12    parent_nonstrict_scope_238  0.0335132898256667
    x_3_12    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_185  1
    w_3_12    product_ub_186  1
    w_3_12    normalized_mass_3_188  1
    w_3_12    normalized_ratio_3_189  -2
    w_3_12    full_original_Gini_296  -3.0869047619047620e+01
    rho_3     normalized_ratio_3_189  1
    rho_3     block_pair_pos_239  -1
    rho_3     block_pair_neg_240  1
    rho_3     block_pair_pos_241  -1
    rho_3     block_pair_neg_242  1
    rho_3     block_pair_pos_243  1
    rho_3     block_pair_neg_244  -1
    rho_3     block_pair_pos_257  1
    rho_3     block_pair_neg_258  -1
    rho_3     block_pair_pos_265  1
    rho_3     block_pair_neg_266  -1
    rho_3     block_pair_pos_277  1
    rho_3     block_pair_neg_278  -1
    rho_3     block_pair_pos_285  1
    rho_3     block_pair_neg_286  -1
    rho_3     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_190  -2.5358490566012373e-02
    x_27_0    product_ub_191  -4.3232115285684006e-02
    x_27_0    onehot_27_204  1
    x_27_0    parent_nonstrict_scope_238  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_190  1
    w_27_0    product_ub_191  1
    w_27_0    normalized_mass_27_205  1
    w_27_0    full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_192  -2.5358490566012373e-02
    x_27_1    product_ub_193  -4.3232115285684006e-02
    x_27_1    onehot_27_204  1
    x_27_1    stock_lb_236  1
    x_27_1    stock_ub_237  1
    x_27_1    parent_nonstrict_scope_238  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_192  1
    w_27_1    product_ub_193  1
    w_27_1    normalized_mass_27_205  1
    w_27_1    normalized_ratio_27_206  -3.3333333333333331e-01
    w_27_1    full_original_Gini_296  -1.4797619047619046e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_194  -2.5358490566012373e-02
    x_27_2    product_ub_195  -4.3232115285684006e-02
    x_27_2    onehot_27_204  1
    x_27_2    stock_lb_236  2
    x_27_2    stock_ub_237  2
    x_27_2    parent_nonstrict_scope_238  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_194  1
    w_27_2    product_ub_195  1
    w_27_2    normalized_mass_27_205  1
    w_27_2    normalized_ratio_27_206  -6.6666666666666663e-01
    w_27_2    full_original_Gini_296  -7.0809523809523807e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_196  -2.5358490566012373e-02
    x_27_3    product_ub_197  -4.3232115285684006e-02
    x_27_3    onehot_27_204  1
    x_27_3    stock_lb_236  3
    x_27_3    stock_ub_237  3
    x_27_3    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_196  1
    w_27_3    product_ub_197  1
    w_27_3    normalized_mass_27_205  1
    w_27_3    normalized_ratio_27_206  -1
    w_27_3    full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_198  -2.5358490566012373e-02
    x_27_4    product_ub_199  -4.3232115285684006e-02
    x_27_4    onehot_27_204  1
    x_27_4    stock_lb_236  4
    x_27_4    stock_ub_237  4
    x_27_4    parent_nonstrict_scope_238  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_198  1
    w_27_4    product_ub_199  1
    w_27_4    normalized_mass_27_205  1
    w_27_4    normalized_ratio_27_206  -1.3333333333333333e+00
    w_27_4    full_original_Gini_296  -1.3202380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_200  -2.5358490566012373e-02
    x_27_5    product_ub_201  -4.3232115285684006e-02
    x_27_5    onehot_27_204  1
    x_27_5    stock_lb_236  5
    x_27_5    stock_ub_237  5
    x_27_5    parent_nonstrict_scope_238  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_200  1
    w_27_5    product_ub_201  1
    w_27_5    normalized_mass_27_205  1
    w_27_5    normalized_ratio_27_206  -1.6666666666666665e+00
    w_27_5    full_original_Gini_296  -2.1869047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_202  -2.5358490566012373e-02
    x_27_6    product_ub_203  -4.3232115285684006e-02
    x_27_6    onehot_27_204  1
    x_27_6    stock_lb_236  6
    x_27_6    stock_ub_237  6
    x_27_6    parent_nonstrict_scope_238  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_202  1
    w_27_6    product_ub_203  1
    w_27_6    normalized_mass_27_205  1
    w_27_6    normalized_ratio_27_206  -2
    w_27_6    full_original_Gini_296  -3.0869047619047620e+01
    rho_27    normalized_ratio_27_206  1
    rho_27    block_pair_pos_241  1
    rho_27    block_pair_neg_242  -1
    rho_27    block_pair_pos_253  1
    rho_27    block_pair_neg_254  -1
    rho_27    block_pair_pos_263  1
    rho_27    block_pair_neg_264  -1
    rho_27    block_pair_pos_273  1
    rho_27    block_pair_neg_274  -1
    rho_27    block_pair_pos_281  1
    rho_27    block_pair_neg_282  -1
    rho_27    block_pair_pos_283  -1
    rho_27    block_pair_neg_284  1
    rho_27    block_pair_pos_293  1
    rho_27    block_pair_neg_294  -1
    rho_27    normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       1.6756644912833352e-02
    x_8_0     product_lb_207  -2.5358490566012373e-02
    x_8_0     product_ub_208  -4.3232115285684006e-02
    x_8_0     onehot_8_233  1
    x_8_0     parent_nonstrict_scope_238  0.0335132898256667
    x_8_0     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_207  1
    w_8_0     product_ub_208  1
    w_8_0     normalized_mass_8_234  1
    w_8_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       1.1171096608555569e-02
    x_8_1     product_lb_209  -2.5358490566012373e-02
    x_8_1     product_ub_210  -4.3232115285684006e-02
    x_8_1     onehot_8_233  1
    x_8_1     stock_lb_236  1
    x_8_1     stock_ub_237  1
    x_8_1     parent_nonstrict_scope_238  2.7927741521388921e-02
    x_8_1     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_209  1
    w_8_1     product_ub_210  1
    w_8_1     normalized_mass_8_234  1
    w_8_1     normalized_ratio_8_235  -1.6666666666666666e-01
    w_8_1     full_original_Gini_296  -1.8964285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       5.5855483042777862e-03
    x_8_2     product_lb_211  -2.5358490566012373e-02
    x_8_2     product_ub_212  -4.3232115285684006e-02
    x_8_2     onehot_8_233  1
    x_8_2     stock_lb_236  2
    x_8_2     stock_ub_237  2
    x_8_2     parent_nonstrict_scope_238  2.2342193217111138e-02
    x_8_2     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_211  1
    w_8_2     product_ub_212  1
    w_8_2     normalized_mass_8_234  1
    w_8_2     normalized_ratio_8_235  -3.3333333333333331e-01
    w_8_2     full_original_Gini_296  -1.4797619047619046e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     product_lb_213  -2.5358490566012373e-02
    x_8_3     product_ub_214  -4.3232115285684006e-02
    x_8_3     onehot_8_233  1
    x_8_3     stock_lb_236  3
    x_8_3     stock_ub_237  3
    x_8_3     parent_nonstrict_scope_238  1.6756644912833352e-02
    x_8_3     unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_213  1
    w_8_3     product_ub_214  1
    w_8_3     normalized_mass_8_234  1
    w_8_3     normalized_ratio_8_235  -0.5
    w_8_3     full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       -5.5855483042777827e-03
    x_8_4     product_lb_215  -2.5358490566012373e-02
    x_8_4     product_ub_216  -4.3232115285684006e-02
    x_8_4     onehot_8_233  1
    x_8_4     stock_lb_236  4
    x_8_4     stock_ub_237  4
    x_8_4     parent_nonstrict_scope_238  1.1171096608555569e-02
    x_8_4     unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_215  1
    w_8_4     product_ub_216  1
    w_8_4     normalized_mass_8_234  1
    w_8_4     normalized_ratio_8_235  -6.6666666666666663e-01
    w_8_4     full_original_Gini_296  -7.0809523809523807e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -1.1171096608555565e-02
    x_8_5     product_lb_217  -2.5358490566012373e-02
    x_8_5     product_ub_218  -4.3232115285684006e-02
    x_8_5     onehot_8_233  1
    x_8_5     stock_lb_236  5
    x_8_5     stock_ub_237  5
    x_8_5     parent_nonstrict_scope_238  5.5855483042777862e-03
    x_8_5     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_217  1
    w_8_5     product_ub_218  1
    w_8_5     normalized_mass_8_234  1
    w_8_5     normalized_ratio_8_235  -8.3333333333333326e-01
    w_8_5     full_original_Gini_296  -4.8809523809523814e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -1.6756644912833352e-02
    x_8_6     product_lb_219  -2.5358490566012373e-02
    x_8_6     product_ub_220  -4.3232115285684006e-02
    x_8_6     onehot_8_233  1
    x_8_6     stock_lb_236  6
    x_8_6     stock_ub_237  6
    x_8_6     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_219  1
    w_8_6     product_ub_220  1
    w_8_6     normalized_mass_8_234  1
    w_8_6     normalized_ratio_8_235  -1
    w_8_6     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -1.1171096608555572e-02
    x_8_7     product_lb_221  -2.5358490566012373e-02
    x_8_7     product_ub_222  -4.3232115285684006e-02
    x_8_7     onehot_8_233  1
    x_8_7     stock_lb_236  7
    x_8_7     stock_ub_237  7
    x_8_7     parent_nonstrict_scope_238  5.5855483042777793e-03
    x_8_7     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_221  1
    w_8_7     product_ub_222  1
    w_8_7     normalized_mass_8_234  1
    w_8_7     normalized_ratio_8_235  -1.1666666666666665e+00
    w_8_7     full_original_Gini_296  -9.03571428571428
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.5855483042777862e-03
    x_8_8     product_lb_223  -2.5358490566012373e-02
    x_8_8     product_ub_224  -4.3232115285684006e-02
    x_8_8     onehot_8_233  1
    x_8_8     stock_lb_236  8
    x_8_8     stock_ub_237  8
    x_8_8     parent_nonstrict_scope_238  1.1171096608555565e-02
    x_8_8     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_223  1
    w_8_8     product_ub_224  1
    w_8_8     normalized_mass_8_234  1
    w_8_8     normalized_ratio_8_235  -1.3333333333333333e+00
    w_8_8     full_original_Gini_296  -1.3202380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_9     product_lb_225  -2.5358490566012373e-02
    x_8_9     product_ub_226  -4.3232115285684006e-02
    x_8_9     onehot_8_233  1
    x_8_9     stock_lb_236  9
    x_8_9     stock_ub_237  9
    x_8_9     parent_nonstrict_scope_238  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_225  1
    w_8_9     product_ub_226  1
    w_8_9     normalized_mass_8_234  1
    w_8_9     normalized_ratio_8_235  -1.5
    w_8_9     full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       5.5855483042777793e-03
    x_8_10    product_lb_227  -2.5358490566012373e-02
    x_8_10    product_ub_228  -4.3232115285684006e-02
    x_8_10    onehot_8_233  1
    x_8_10    stock_lb_236  10
    x_8_10    stock_ub_237  10
    x_8_10    parent_nonstrict_scope_238  2.2342193217111131e-02
    x_8_10    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_227  1
    w_8_10    product_ub_228  1
    w_8_10    normalized_mass_8_234  1
    w_8_10    normalized_ratio_8_235  -1.6666666666666665e+00
    w_8_10    full_original_Gini_296  -2.1869047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       1.1171096608555565e-02
    x_8_11    product_lb_229  -2.5358490566012373e-02
    x_8_11    product_ub_230  -4.3232115285684006e-02
    x_8_11    onehot_8_233  1
    x_8_11    stock_lb_236  11
    x_8_11    stock_ub_237  11
    x_8_11    parent_nonstrict_scope_238  2.7927741521388917e-02
    x_8_11    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_229  1
    w_8_11    product_ub_230  1
    w_8_11    normalized_mass_8_234  1
    w_8_11    normalized_ratio_8_235  -1.8333333333333333e+00
    w_8_11    full_original_Gini_296  -2.6369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       1.6756644912833352e-02
    x_8_12    product_lb_231  -2.5358490566012373e-02
    x_8_12    product_ub_232  -4.3232115285684006e-02
    x_8_12    onehot_8_233  1
    x_8_12    stock_lb_236  12
    x_8_12    stock_ub_237  12
    x_8_12    parent_nonstrict_scope_238  0.0335132898256667
    x_8_12    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_231  1
    w_8_12    product_ub_232  1
    w_8_12    normalized_mass_8_234  1
    w_8_12    normalized_ratio_8_235  -2
    w_8_12    full_original_Gini_296  -3.0869047619047620e+01
    rho_8     normalized_ratio_8_235  1
    rho_8     block_pair_pos_239  1
    rho_8     block_pair_neg_240  -1
    rho_8     block_pair_pos_249  1
    rho_8     block_pair_neg_250  -1
    rho_8     block_pair_pos_259  1
    rho_8     block_pair_neg_260  -1
    rho_8     block_pair_pos_269  1
    rho_8     block_pair_neg_270  -1
    rho_8     block_pair_pos_279  1
    rho_8     block_pair_neg_280  -1
    rho_8     block_pair_pos_283  1
    rho_8     block_pair_neg_284  -1
    rho_8     block_pair_pos_289  1
    rho_8     block_pair_neg_290  -1
    rho_8     normalization_295  1
    a_5_7     block_pair_pos_247  1
    a_5_7     block_pair_neg_248  1
    a_5_7     full_original_Gini_296  -1
    a_5_34    block_pair_pos_255  1
    a_5_34    block_pair_neg_256  1
    a_5_34    full_original_Gini_296  -1
    a_5_6     block_pair_pos_245  1
    a_5_6     block_pair_neg_246  1
    a_5_6     full_original_Gini_296  -1
    a_5_22    block_pair_pos_251  1
    a_5_22    block_pair_neg_252  1
    a_5_22    full_original_Gini_296  -1
    a_5_3     block_pair_pos_243  1
    a_5_3     block_pair_neg_244  1
    a_5_3     full_original_Gini_296  -1
    a_5_27    block_pair_pos_253  1
    a_5_27    block_pair_neg_254  1
    a_5_27    full_original_Gini_296  -1
    a_5_8     block_pair_pos_249  1
    a_5_8     block_pair_neg_250  1
    a_5_8     full_original_Gini_296  -1
    a_7_34    block_pair_pos_275  1
    a_7_34    block_pair_neg_276  1
    a_7_34    full_original_Gini_296  -1
    a_7_6     block_pair_pos_267  1
    a_7_6     block_pair_neg_268  1
    a_7_6     full_original_Gini_296  -1
    a_7_22    block_pair_pos_271  1
    a_7_22    block_pair_neg_272  1
    a_7_22    full_original_Gini_296  -1
    a_7_3     block_pair_pos_265  1
    a_7_3     block_pair_neg_266  1
    a_7_3     full_original_Gini_296  -1
    a_7_27    block_pair_pos_273  1
    a_7_27    block_pair_neg_274  1
    a_7_27    full_original_Gini_296  -1
    a_7_8     block_pair_pos_269  1
    a_7_8     block_pair_neg_270  1
    a_7_8     full_original_Gini_296  -1
    a_34_6    block_pair_pos_287  1
    a_34_6    block_pair_neg_288  1
    a_34_6    full_original_Gini_296  -1
    a_34_22   block_pair_pos_291  1
    a_34_22   block_pair_neg_292  1
    a_34_22   full_original_Gini_296  -1
    a_34_3    block_pair_pos_285  1
    a_34_3    block_pair_neg_286  1
    a_34_3    full_original_Gini_296  -1
    a_34_27   block_pair_pos_293  1
    a_34_27   block_pair_neg_294  1
    a_34_27   full_original_Gini_296  -1
    a_34_8    block_pair_pos_289  1
    a_34_8    block_pair_neg_290  1
    a_34_8    full_original_Gini_296  -1
    a_6_22    block_pair_pos_261  1
    a_6_22    block_pair_neg_262  1
    a_6_22    full_original_Gini_296  -1
    a_6_3     block_pair_pos_257  1
    a_6_3     block_pair_neg_258  1
    a_6_3     full_original_Gini_296  -1
    a_6_27    block_pair_pos_263  1
    a_6_27    block_pair_neg_264  1
    a_6_27    full_original_Gini_296  -1
    a_6_8     block_pair_pos_259  1
    a_6_8     block_pair_neg_260  1
    a_6_8     full_original_Gini_296  -1
    a_22_3    block_pair_pos_277  1
    a_22_3    block_pair_neg_278  1
    a_22_3    full_original_Gini_296  -1
    a_22_27   block_pair_pos_281  1
    a_22_27   block_pair_neg_282  1
    a_22_27   full_original_Gini_296  -1
    a_22_8    block_pair_pos_279  1
    a_22_8    block_pair_neg_280  1
    a_22_8    full_original_Gini_296  -1
    a_3_27    block_pair_pos_241  1
    a_3_27    block_pair_neg_242  1
    a_3_27    full_original_Gini_296  -1
    a_3_8     block_pair_pos_239  1
    a_3_8     block_pair_neg_240  1
    a_3_8     full_original_Gini_296  -1
    a_27_8    block_pair_pos_283  1
    a_27_8    block_pair_neg_284  1
    a_27_8    full_original_Gini_296  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_5_0  unique_nonzero_owner_297  1
    service_0_5_0  service_visit_def_836  1
    service_0_5_0  free_load_conservation_837  -1
    service_0_5_0  original_T_including_depot_unload_885  120
    service_0_5_2  unique_nonzero_owner_298  1
    service_0_5_2  service_visit_def_836  1
    service_0_5_2  free_load_conservation_837  1
    service_0_5_3  unique_nonzero_owner_299  1
    service_0_5_3  service_visit_def_836  1
    service_0_5_3  free_load_conservation_837  2
    service_0_5_4  unique_nonzero_owner_300  1
    service_0_5_4  service_visit_def_836  1
    service_0_5_4  free_load_conservation_837  3
    service_0_5_5  unique_nonzero_owner_301  1
    service_0_5_5  service_visit_def_836  1
    service_0_5_5  free_load_conservation_837  4
    service_0_5_6  unique_nonzero_owner_302  1
    service_0_5_6  service_visit_def_836  1
    service_0_5_6  free_load_conservation_837  5
    service_0_5_7  unique_nonzero_owner_303  1
    service_0_5_7  service_visit_def_836  1
    service_0_5_7  free_load_conservation_837  6
    service_0_5_8  unique_nonzero_owner_304  1
    service_0_5_8  service_visit_def_836  1
    service_0_5_8  free_load_conservation_837  7
    service_0_5_9  unique_nonzero_owner_305  1
    service_0_5_9  service_visit_def_836  1
    service_0_5_9  free_load_conservation_837  8
    service_0_5_10  unique_nonzero_owner_306  1
    service_0_5_10  service_visit_def_836  1
    service_0_5_10  free_load_conservation_837  9
    service_0_5_11  unique_nonzero_owner_307  1
    service_0_5_11  service_visit_def_836  1
    service_0_5_11  free_load_conservation_837  10
    service_0_5_12  unique_nonzero_owner_308  1
    service_0_5_12  service_visit_def_836  1
    service_0_5_12  free_load_conservation_837  11
    service_0_5_13  unique_nonzero_owner_309  1
    service_0_5_13  service_visit_def_836  1
    service_0_5_13  free_load_conservation_837  12
    service_0_5_14  unique_nonzero_owner_310  1
    service_0_5_14  service_visit_def_836  1
    service_0_5_14  free_load_conservation_837  13
    service_0_5_15  unique_nonzero_owner_311  1
    service_0_5_15  service_visit_def_836  1
    service_0_5_15  free_load_conservation_837  14
    service_1_5_0  unique_nonzero_owner_297  1
    service_1_5_0  service_visit_def_1209  1
    service_1_5_0  free_load_conservation_1210  -1
    service_1_5_0  original_T_including_depot_unload_1256  120
    service_1_5_2  unique_nonzero_owner_298  1
    service_1_5_2  service_visit_def_1209  1
    service_1_5_2  free_load_conservation_1210  1
    service_1_5_3  unique_nonzero_owner_299  1
    service_1_5_3  service_visit_def_1209  1
    service_1_5_3  free_load_conservation_1210  2
    service_1_5_4  unique_nonzero_owner_300  1
    service_1_5_4  service_visit_def_1209  1
    service_1_5_4  free_load_conservation_1210  3
    service_1_5_5  unique_nonzero_owner_301  1
    service_1_5_5  service_visit_def_1209  1
    service_1_5_5  free_load_conservation_1210  4
    service_1_5_6  unique_nonzero_owner_302  1
    service_1_5_6  service_visit_def_1209  1
    service_1_5_6  free_load_conservation_1210  5
    service_1_5_7  unique_nonzero_owner_303  1
    service_1_5_7  service_visit_def_1209  1
    service_1_5_7  free_load_conservation_1210  6
    service_1_5_8  unique_nonzero_owner_304  1
    service_1_5_8  service_visit_def_1209  1
    service_1_5_8  free_load_conservation_1210  7
    service_1_5_9  unique_nonzero_owner_305  1
    service_1_5_9  service_visit_def_1209  1
    service_1_5_9  free_load_conservation_1210  8
    service_1_5_10  unique_nonzero_owner_306  1
    service_1_5_10  service_visit_def_1209  1
    service_1_5_10  free_load_conservation_1210  9
    service_1_5_11  unique_nonzero_owner_307  1
    service_1_5_11  service_visit_def_1209  1
    service_1_5_11  free_load_conservation_1210  10
    service_1_5_12  unique_nonzero_owner_308  1
    service_1_5_12  service_visit_def_1209  1
    service_1_5_12  free_load_conservation_1210  11
    service_1_5_13  unique_nonzero_owner_309  1
    service_1_5_13  service_visit_def_1209  1
    service_1_5_13  free_load_conservation_1210  12
    service_1_5_14  unique_nonzero_owner_310  1
    service_1_5_14  service_visit_def_1209  1
    service_1_5_14  free_load_conservation_1210  13
    service_1_5_15  unique_nonzero_owner_311  1
    service_1_5_15  service_visit_def_1209  1
    service_1_5_15  free_load_conservation_1210  14
    service_2_5_0  unique_nonzero_owner_297  1
    service_2_5_0  service_visit_def_1527  1
    service_2_5_0  free_load_conservation_1528  -1
    service_2_5_0  original_T_including_depot_unload_1573  120
    service_2_5_2  unique_nonzero_owner_298  1
    service_2_5_2  service_visit_def_1527  1
    service_2_5_2  free_load_conservation_1528  1
    service_2_5_3  unique_nonzero_owner_299  1
    service_2_5_3  service_visit_def_1527  1
    service_2_5_3  free_load_conservation_1528  2
    service_2_5_4  unique_nonzero_owner_300  1
    service_2_5_4  service_visit_def_1527  1
    service_2_5_4  free_load_conservation_1528  3
    service_2_5_5  unique_nonzero_owner_301  1
    service_2_5_5  service_visit_def_1527  1
    service_2_5_5  free_load_conservation_1528  4
    service_2_5_6  unique_nonzero_owner_302  1
    service_2_5_6  service_visit_def_1527  1
    service_2_5_6  free_load_conservation_1528  5
    service_2_5_7  unique_nonzero_owner_303  1
    service_2_5_7  service_visit_def_1527  1
    service_2_5_7  free_load_conservation_1528  6
    service_2_5_8  unique_nonzero_owner_304  1
    service_2_5_8  service_visit_def_1527  1
    service_2_5_8  free_load_conservation_1528  7
    service_2_5_9  unique_nonzero_owner_305  1
    service_2_5_9  service_visit_def_1527  1
    service_2_5_9  free_load_conservation_1528  8
    service_2_5_10  unique_nonzero_owner_306  1
    service_2_5_10  service_visit_def_1527  1
    service_2_5_10  free_load_conservation_1528  9
    service_2_5_11  unique_nonzero_owner_307  1
    service_2_5_11  service_visit_def_1527  1
    service_2_5_11  free_load_conservation_1528  10
    service_2_5_12  unique_nonzero_owner_308  1
    service_2_5_12  service_visit_def_1527  1
    service_2_5_12  free_load_conservation_1528  11
    service_2_5_13  unique_nonzero_owner_309  1
    service_2_5_13  service_visit_def_1527  1
    service_2_5_13  free_load_conservation_1528  12
    service_2_5_14  unique_nonzero_owner_310  1
    service_2_5_14  service_visit_def_1527  1
    service_2_5_14  free_load_conservation_1528  13
    service_2_5_15  unique_nonzero_owner_311  1
    service_2_5_15  service_visit_def_1527  1
    service_2_5_15  free_load_conservation_1528  14
    service_0_7_0  unique_nonzero_owner_312  1
    service_0_7_0  service_visit_def_842  1
    service_0_7_0  free_load_conservation_843  -1
    service_0_7_0  original_T_including_depot_unload_885  120
    service_0_7_2  unique_nonzero_owner_313  1
    service_0_7_2  service_visit_def_842  1
    service_0_7_2  free_load_conservation_843  1
    service_0_7_3  unique_nonzero_owner_314  1
    service_0_7_3  service_visit_def_842  1
    service_0_7_3  free_load_conservation_843  2
    service_0_7_4  unique_nonzero_owner_315  1
    service_0_7_4  service_visit_def_842  1
    service_0_7_4  free_load_conservation_843  3
    service_0_7_5  unique_nonzero_owner_316  1
    service_0_7_5  service_visit_def_842  1
    service_0_7_5  free_load_conservation_843  4
    service_0_7_6  unique_nonzero_owner_317  1
    service_0_7_6  service_visit_def_842  1
    service_0_7_6  free_load_conservation_843  5
    service_0_7_7  unique_nonzero_owner_318  1
    service_0_7_7  service_visit_def_842  1
    service_0_7_7  free_load_conservation_843  6
    service_0_7_8  unique_nonzero_owner_319  1
    service_0_7_8  service_visit_def_842  1
    service_0_7_8  free_load_conservation_843  7
    service_0_7_9  unique_nonzero_owner_320  1
    service_0_7_9  service_visit_def_842  1
    service_0_7_9  free_load_conservation_843  8
    service_0_7_10  unique_nonzero_owner_321  1
    service_0_7_10  service_visit_def_842  1
    service_0_7_10  free_load_conservation_843  9
    service_0_7_11  unique_nonzero_owner_322  1
    service_0_7_11  service_visit_def_842  1
    service_0_7_11  free_load_conservation_843  10
    service_0_7_12  unique_nonzero_owner_323  1
    service_0_7_12  service_visit_def_842  1
    service_0_7_12  free_load_conservation_843  11
    service_0_7_13  unique_nonzero_owner_324  1
    service_0_7_13  service_visit_def_842  1
    service_0_7_13  free_load_conservation_843  12
    service_0_7_14  unique_nonzero_owner_325  1
    service_0_7_14  service_visit_def_842  1
    service_0_7_14  free_load_conservation_843  13
    service_0_7_15  unique_nonzero_owner_326  1
    service_0_7_15  service_visit_def_842  1
    service_0_7_15  free_load_conservation_843  14
    service_1_7_0  unique_nonzero_owner_312  1
    service_1_7_0  service_visit_def_1215  1
    service_1_7_0  free_load_conservation_1216  -1
    service_1_7_0  original_T_including_depot_unload_1256  120
    service_1_7_2  unique_nonzero_owner_313  1
    service_1_7_2  service_visit_def_1215  1
    service_1_7_2  free_load_conservation_1216  1
    service_1_7_3  unique_nonzero_owner_314  1
    service_1_7_3  service_visit_def_1215  1
    service_1_7_3  free_load_conservation_1216  2
    service_1_7_4  unique_nonzero_owner_315  1
    service_1_7_4  service_visit_def_1215  1
    service_1_7_4  free_load_conservation_1216  3
    service_1_7_5  unique_nonzero_owner_316  1
    service_1_7_5  service_visit_def_1215  1
    service_1_7_5  free_load_conservation_1216  4
    service_1_7_6  unique_nonzero_owner_317  1
    service_1_7_6  service_visit_def_1215  1
    service_1_7_6  free_load_conservation_1216  5
    service_1_7_7  unique_nonzero_owner_318  1
    service_1_7_7  service_visit_def_1215  1
    service_1_7_7  free_load_conservation_1216  6
    service_1_7_8  unique_nonzero_owner_319  1
    service_1_7_8  service_visit_def_1215  1
    service_1_7_8  free_load_conservation_1216  7
    service_1_7_9  unique_nonzero_owner_320  1
    service_1_7_9  service_visit_def_1215  1
    service_1_7_9  free_load_conservation_1216  8
    service_1_7_10  unique_nonzero_owner_321  1
    service_1_7_10  service_visit_def_1215  1
    service_1_7_10  free_load_conservation_1216  9
    service_1_7_11  unique_nonzero_owner_322  1
    service_1_7_11  service_visit_def_1215  1
    service_1_7_11  free_load_conservation_1216  10
    service_1_7_12  unique_nonzero_owner_323  1
    service_1_7_12  service_visit_def_1215  1
    service_1_7_12  free_load_conservation_1216  11
    service_1_7_13  unique_nonzero_owner_324  1
    service_1_7_13  service_visit_def_1215  1
    service_1_7_13  free_load_conservation_1216  12
    service_1_7_14  unique_nonzero_owner_325  1
    service_1_7_14  service_visit_def_1215  1
    service_1_7_14  free_load_conservation_1216  13
    service_1_7_15  unique_nonzero_owner_326  1
    service_1_7_15  service_visit_def_1215  1
    service_1_7_15  free_load_conservation_1216  14
    service_2_7_0  unique_nonzero_owner_312  1
    service_2_7_0  service_visit_def_1533  1
    service_2_7_0  free_load_conservation_1534  -1
    service_2_7_0  original_T_including_depot_unload_1573  120
    service_2_7_2  unique_nonzero_owner_313  1
    service_2_7_2  service_visit_def_1533  1
    service_2_7_2  free_load_conservation_1534  1
    service_2_7_3  unique_nonzero_owner_314  1
    service_2_7_3  service_visit_def_1533  1
    service_2_7_3  free_load_conservation_1534  2
    service_2_7_4  unique_nonzero_owner_315  1
    service_2_7_4  service_visit_def_1533  1
    service_2_7_4  free_load_conservation_1534  3
    service_2_7_5  unique_nonzero_owner_316  1
    service_2_7_5  service_visit_def_1533  1
    service_2_7_5  free_load_conservation_1534  4
    service_2_7_6  unique_nonzero_owner_317  1
    service_2_7_6  service_visit_def_1533  1
    service_2_7_6  free_load_conservation_1534  5
    service_2_7_7  unique_nonzero_owner_318  1
    service_2_7_7  service_visit_def_1533  1
    service_2_7_7  free_load_conservation_1534  6
    service_2_7_8  unique_nonzero_owner_319  1
    service_2_7_8  service_visit_def_1533  1
    service_2_7_8  free_load_conservation_1534  7
    service_2_7_9  unique_nonzero_owner_320  1
    service_2_7_9  service_visit_def_1533  1
    service_2_7_9  free_load_conservation_1534  8
    service_2_7_10  unique_nonzero_owner_321  1
    service_2_7_10  service_visit_def_1533  1
    service_2_7_10  free_load_conservation_1534  9
    service_2_7_11  unique_nonzero_owner_322  1
    service_2_7_11  service_visit_def_1533  1
    service_2_7_11  free_load_conservation_1534  10
    service_2_7_12  unique_nonzero_owner_323  1
    service_2_7_12  service_visit_def_1533  1
    service_2_7_12  free_load_conservation_1534  11
    service_2_7_13  unique_nonzero_owner_324  1
    service_2_7_13  service_visit_def_1533  1
    service_2_7_13  free_load_conservation_1534  12
    service_2_7_14  unique_nonzero_owner_325  1
    service_2_7_14  service_visit_def_1533  1
    service_2_7_14  free_load_conservation_1534  13
    service_2_7_15  unique_nonzero_owner_326  1
    service_2_7_15  service_visit_def_1533  1
    service_2_7_15  free_load_conservation_1534  14
    service_0_34_0  unique_nonzero_owner_327  1
    service_0_34_0  service_visit_def_848  1
    service_0_34_0  free_load_conservation_849  -2
    service_0_34_0  original_T_including_depot_unload_885  240
    service_0_34_1  unique_nonzero_owner_328  1
    service_0_34_1  service_visit_def_848  1
    service_0_34_1  free_load_conservation_849  -1
    service_0_34_1  original_T_including_depot_unload_885  120
    service_0_34_3  unique_nonzero_owner_329  1
    service_0_34_3  service_visit_def_848  1
    service_0_34_3  free_load_conservation_849  1
    service_0_34_4  unique_nonzero_owner_330  1
    service_0_34_4  service_visit_def_848  1
    service_0_34_4  free_load_conservation_849  2
    service_0_34_5  unique_nonzero_owner_331  1
    service_0_34_5  service_visit_def_848  1
    service_0_34_5  free_load_conservation_849  3
    service_0_34_6  unique_nonzero_owner_332  1
    service_0_34_6  service_visit_def_848  1
    service_0_34_6  free_load_conservation_849  4
    service_0_34_7  unique_nonzero_owner_333  1
    service_0_34_7  service_visit_def_848  1
    service_0_34_7  free_load_conservation_849  5
    service_0_34_8  unique_nonzero_owner_334  1
    service_0_34_8  service_visit_def_848  1
    service_0_34_8  free_load_conservation_849  6
    service_0_34_9  unique_nonzero_owner_335  1
    service_0_34_9  service_visit_def_848  1
    service_0_34_9  free_load_conservation_849  7
    service_0_34_10  unique_nonzero_owner_336  1
    service_0_34_10  service_visit_def_848  1
    service_0_34_10  free_load_conservation_849  8
    service_0_34_11  unique_nonzero_owner_337  1
    service_0_34_11  service_visit_def_848  1
    service_0_34_11  free_load_conservation_849  9
    service_0_34_12  unique_nonzero_owner_338  1
    service_0_34_12  service_visit_def_848  1
    service_0_34_12  free_load_conservation_849  10
    service_0_34_13  unique_nonzero_owner_339  1
    service_0_34_13  service_visit_def_848  1
    service_0_34_13  free_load_conservation_849  11
    service_0_34_14  unique_nonzero_owner_340  1
    service_0_34_14  service_visit_def_848  1
    service_0_34_14  free_load_conservation_849  12
    service_0_34_15  unique_nonzero_owner_341  1
    service_0_34_15  service_visit_def_848  1
    service_0_34_15  free_load_conservation_849  13
    service_1_34_0  unique_nonzero_owner_327  1
    service_1_34_0  service_visit_def_1221  1
    service_1_34_0  free_load_conservation_1222  -2
    service_1_34_0  original_T_including_depot_unload_1256  240
    service_1_34_1  unique_nonzero_owner_328  1
    service_1_34_1  service_visit_def_1221  1
    service_1_34_1  free_load_conservation_1222  -1
    service_1_34_1  original_T_including_depot_unload_1256  120
    service_1_34_3  unique_nonzero_owner_329  1
    service_1_34_3  service_visit_def_1221  1
    service_1_34_3  free_load_conservation_1222  1
    service_1_34_4  unique_nonzero_owner_330  1
    service_1_34_4  service_visit_def_1221  1
    service_1_34_4  free_load_conservation_1222  2
    service_1_34_5  unique_nonzero_owner_331  1
    service_1_34_5  service_visit_def_1221  1
    service_1_34_5  free_load_conservation_1222  3
    service_1_34_6  unique_nonzero_owner_332  1
    service_1_34_6  service_visit_def_1221  1
    service_1_34_6  free_load_conservation_1222  4
    service_1_34_7  unique_nonzero_owner_333  1
    service_1_34_7  service_visit_def_1221  1
    service_1_34_7  free_load_conservation_1222  5
    service_1_34_8  unique_nonzero_owner_334  1
    service_1_34_8  service_visit_def_1221  1
    service_1_34_8  free_load_conservation_1222  6
    service_1_34_9  unique_nonzero_owner_335  1
    service_1_34_9  service_visit_def_1221  1
    service_1_34_9  free_load_conservation_1222  7
    service_1_34_10  unique_nonzero_owner_336  1
    service_1_34_10  service_visit_def_1221  1
    service_1_34_10  free_load_conservation_1222  8
    service_1_34_11  unique_nonzero_owner_337  1
    service_1_34_11  service_visit_def_1221  1
    service_1_34_11  free_load_conservation_1222  9
    service_1_34_12  unique_nonzero_owner_338  1
    service_1_34_12  service_visit_def_1221  1
    service_1_34_12  free_load_conservation_1222  10
    service_1_34_13  unique_nonzero_owner_339  1
    service_1_34_13  service_visit_def_1221  1
    service_1_34_13  free_load_conservation_1222  11
    service_1_34_14  unique_nonzero_owner_340  1
    service_1_34_14  service_visit_def_1221  1
    service_1_34_14  free_load_conservation_1222  12
    service_1_34_15  unique_nonzero_owner_341  1
    service_1_34_15  service_visit_def_1221  1
    service_1_34_15  free_load_conservation_1222  13
    service_2_34_0  unique_nonzero_owner_327  1
    service_2_34_0  service_visit_def_1539  1
    service_2_34_0  free_load_conservation_1540  -2
    service_2_34_0  original_T_including_depot_unload_1573  240
    service_2_34_1  unique_nonzero_owner_328  1
    service_2_34_1  service_visit_def_1539  1
    service_2_34_1  free_load_conservation_1540  -1
    service_2_34_1  original_T_including_depot_unload_1573  120
    service_2_34_3  unique_nonzero_owner_329  1
    service_2_34_3  service_visit_def_1539  1
    service_2_34_3  free_load_conservation_1540  1
    service_2_34_4  unique_nonzero_owner_330  1
    service_2_34_4  service_visit_def_1539  1
    service_2_34_4  free_load_conservation_1540  2
    service_2_34_5  unique_nonzero_owner_331  1
    service_2_34_5  service_visit_def_1539  1
    service_2_34_5  free_load_conservation_1540  3
    service_2_34_6  unique_nonzero_owner_332  1
    service_2_34_6  service_visit_def_1539  1
    service_2_34_6  free_load_conservation_1540  4
    service_2_34_7  unique_nonzero_owner_333  1
    service_2_34_7  service_visit_def_1539  1
    service_2_34_7  free_load_conservation_1540  5
    service_2_34_8  unique_nonzero_owner_334  1
    service_2_34_8  service_visit_def_1539  1
    service_2_34_8  free_load_conservation_1540  6
    service_2_34_9  unique_nonzero_owner_335  1
    service_2_34_9  service_visit_def_1539  1
    service_2_34_9  free_load_conservation_1540  7
    service_2_34_10  unique_nonzero_owner_336  1
    service_2_34_10  service_visit_def_1539  1
    service_2_34_10  free_load_conservation_1540  8
    service_2_34_11  unique_nonzero_owner_337  1
    service_2_34_11  service_visit_def_1539  1
    service_2_34_11  free_load_conservation_1540  9
    service_2_34_12  unique_nonzero_owner_338  1
    service_2_34_12  service_visit_def_1539  1
    service_2_34_12  free_load_conservation_1540  10
    service_2_34_13  unique_nonzero_owner_339  1
    service_2_34_13  service_visit_def_1539  1
    service_2_34_13  free_load_conservation_1540  11
    service_2_34_14  unique_nonzero_owner_340  1
    service_2_34_14  service_visit_def_1539  1
    service_2_34_14  free_load_conservation_1540  12
    service_2_34_15  unique_nonzero_owner_341  1
    service_2_34_15  service_visit_def_1539  1
    service_2_34_15  free_load_conservation_1540  13
    service_0_6_0  unique_nonzero_owner_342  1
    service_0_6_0  service_visit_def_854  1
    service_0_6_0  free_load_conservation_855  -6
    service_0_6_0  original_T_including_depot_unload_885  720
    service_0_6_1  unique_nonzero_owner_343  1
    service_0_6_1  service_visit_def_854  1
    service_0_6_1  free_load_conservation_855  -5
    service_0_6_1  original_T_including_depot_unload_885  600
    service_0_6_2  unique_nonzero_owner_344  1
    service_0_6_2  service_visit_def_854  1
    service_0_6_2  free_load_conservation_855  -4
    service_0_6_2  original_T_including_depot_unload_885  480
    service_0_6_3  unique_nonzero_owner_345  1
    service_0_6_3  service_visit_def_854  1
    service_0_6_3  free_load_conservation_855  -3
    service_0_6_3  original_T_including_depot_unload_885  360
    service_0_6_4  unique_nonzero_owner_346  1
    service_0_6_4  service_visit_def_854  1
    service_0_6_4  free_load_conservation_855  -2
    service_0_6_4  original_T_including_depot_unload_885  240
    service_0_6_5  unique_nonzero_owner_347  1
    service_0_6_5  service_visit_def_854  1
    service_0_6_5  free_load_conservation_855  -1
    service_0_6_5  original_T_including_depot_unload_885  120
    service_0_6_7  unique_nonzero_owner_348  1
    service_0_6_7  service_visit_def_854  1
    service_0_6_7  free_load_conservation_855  1
    service_0_6_8  unique_nonzero_owner_349  1
    service_0_6_8  service_visit_def_854  1
    service_0_6_8  free_load_conservation_855  2
    service_1_6_0  unique_nonzero_owner_342  1
    service_1_6_0  service_visit_def_1227  1
    service_1_6_0  free_load_conservation_1228  -6
    service_1_6_0  original_T_including_depot_unload_1256  720
    service_1_6_1  unique_nonzero_owner_343  1
    service_1_6_1  service_visit_def_1227  1
    service_1_6_1  free_load_conservation_1228  -5
    service_1_6_1  original_T_including_depot_unload_1256  600
    service_1_6_2  unique_nonzero_owner_344  1
    service_1_6_2  service_visit_def_1227  1
    service_1_6_2  free_load_conservation_1228  -4
    service_1_6_2  original_T_including_depot_unload_1256  480
    service_1_6_3  unique_nonzero_owner_345  1
    service_1_6_3  service_visit_def_1227  1
    service_1_6_3  free_load_conservation_1228  -3
    service_1_6_3  original_T_including_depot_unload_1256  360
    service_1_6_4  unique_nonzero_owner_346  1
    service_1_6_4  service_visit_def_1227  1
    service_1_6_4  free_load_conservation_1228  -2
    service_1_6_4  original_T_including_depot_unload_1256  240
    service_1_6_5  unique_nonzero_owner_347  1
    service_1_6_5  service_visit_def_1227  1
    service_1_6_5  free_load_conservation_1228  -1
    service_1_6_5  original_T_including_depot_unload_1256  120
    service_1_6_7  unique_nonzero_owner_348  1
    service_1_6_7  service_visit_def_1227  1
    service_1_6_7  free_load_conservation_1228  1
    service_1_6_8  unique_nonzero_owner_349  1
    service_1_6_8  service_visit_def_1227  1
    service_1_6_8  free_load_conservation_1228  2
    service_2_6_0  unique_nonzero_owner_342  1
    service_2_6_0  service_visit_def_1545  1
    service_2_6_0  free_load_conservation_1546  -6
    service_2_6_0  original_T_including_depot_unload_1573  720
    service_2_6_1  unique_nonzero_owner_343  1
    service_2_6_1  service_visit_def_1545  1
    service_2_6_1  free_load_conservation_1546  -5
    service_2_6_1  original_T_including_depot_unload_1573  600
    service_2_6_2  unique_nonzero_owner_344  1
    service_2_6_2  service_visit_def_1545  1
    service_2_6_2  free_load_conservation_1546  -4
    service_2_6_2  original_T_including_depot_unload_1573  480
    service_2_6_3  unique_nonzero_owner_345  1
    service_2_6_3  service_visit_def_1545  1
    service_2_6_3  free_load_conservation_1546  -3
    service_2_6_3  original_T_including_depot_unload_1573  360
    service_2_6_4  unique_nonzero_owner_346  1
    service_2_6_4  service_visit_def_1545  1
    service_2_6_4  free_load_conservation_1546  -2
    service_2_6_4  original_T_including_depot_unload_1573  240
    service_2_6_5  unique_nonzero_owner_347  1
    service_2_6_5  service_visit_def_1545  1
    service_2_6_5  free_load_conservation_1546  -1
    service_2_6_5  original_T_including_depot_unload_1573  120
    service_2_6_7  unique_nonzero_owner_348  1
    service_2_6_7  service_visit_def_1545  1
    service_2_6_7  free_load_conservation_1546  1
    service_2_6_8  unique_nonzero_owner_349  1
    service_2_6_8  service_visit_def_1545  1
    service_2_6_8  free_load_conservation_1546  2
    service_0_22_0  unique_nonzero_owner_350  1
    service_0_22_0  service_visit_def_860  1
    service_0_22_0  free_load_conservation_861  -2
    service_0_22_0  original_T_including_depot_unload_885  240
    service_0_22_1  unique_nonzero_owner_351  1
    service_0_22_1  service_visit_def_860  1
    service_0_22_1  free_load_conservation_861  -1
    service_0_22_1  original_T_including_depot_unload_885  120
    service_0_22_3  unique_nonzero_owner_352  1
    service_0_22_3  service_visit_def_860  1
    service_0_22_3  free_load_conservation_861  1
    service_0_22_4  unique_nonzero_owner_353  1
    service_0_22_4  service_visit_def_860  1
    service_0_22_4  free_load_conservation_861  2
    service_0_22_5  unique_nonzero_owner_354  1
    service_0_22_5  service_visit_def_860  1
    service_0_22_5  free_load_conservation_861  3
    service_0_22_6  unique_nonzero_owner_355  1
    service_0_22_6  service_visit_def_860  1
    service_0_22_6  free_load_conservation_861  4
    service_0_22_7  unique_nonzero_owner_356  1
    service_0_22_7  service_visit_def_860  1
    service_0_22_7  free_load_conservation_861  5
    service_0_22_8  unique_nonzero_owner_357  1
    service_0_22_8  service_visit_def_860  1
    service_0_22_8  free_load_conservation_861  6
    service_0_22_9  unique_nonzero_owner_358  1
    service_0_22_9  service_visit_def_860  1
    service_0_22_9  free_load_conservation_861  7
    service_0_22_10  unique_nonzero_owner_359  1
    service_0_22_10  service_visit_def_860  1
    service_0_22_10  free_load_conservation_861  8
    service_0_22_11  unique_nonzero_owner_360  1
    service_0_22_11  service_visit_def_860  1
    service_0_22_11  free_load_conservation_861  9
    service_0_22_12  unique_nonzero_owner_361  1
    service_0_22_12  service_visit_def_860  1
    service_0_22_12  free_load_conservation_861  10
    service_0_22_13  unique_nonzero_owner_362  1
    service_0_22_13  service_visit_def_860  1
    service_0_22_13  free_load_conservation_861  11
    service_0_22_14  unique_nonzero_owner_363  1
    service_0_22_14  service_visit_def_860  1
    service_0_22_14  free_load_conservation_861  12
    service_0_22_15  unique_nonzero_owner_364  1
    service_0_22_15  service_visit_def_860  1
    service_0_22_15  free_load_conservation_861  13
    service_1_22_0  unique_nonzero_owner_350  1
    service_1_22_0  service_visit_def_1233  1
    service_1_22_0  free_load_conservation_1234  -2
    service_1_22_0  original_T_including_depot_unload_1256  240
    service_1_22_1  unique_nonzero_owner_351  1
    service_1_22_1  service_visit_def_1233  1
    service_1_22_1  free_load_conservation_1234  -1
    service_1_22_1  original_T_including_depot_unload_1256  120
    service_1_22_3  unique_nonzero_owner_352  1
    service_1_22_3  service_visit_def_1233  1
    service_1_22_3  free_load_conservation_1234  1
    service_1_22_4  unique_nonzero_owner_353  1
    service_1_22_4  service_visit_def_1233  1
    service_1_22_4  free_load_conservation_1234  2
    service_1_22_5  unique_nonzero_owner_354  1
    service_1_22_5  service_visit_def_1233  1
    service_1_22_5  free_load_conservation_1234  3
    service_1_22_6  unique_nonzero_owner_355  1
    service_1_22_6  service_visit_def_1233  1
    service_1_22_6  free_load_conservation_1234  4
    service_1_22_7  unique_nonzero_owner_356  1
    service_1_22_7  service_visit_def_1233  1
    service_1_22_7  free_load_conservation_1234  5
    service_1_22_8  unique_nonzero_owner_357  1
    service_1_22_8  service_visit_def_1233  1
    service_1_22_8  free_load_conservation_1234  6
    service_1_22_9  unique_nonzero_owner_358  1
    service_1_22_9  service_visit_def_1233  1
    service_1_22_9  free_load_conservation_1234  7
    service_1_22_10  unique_nonzero_owner_359  1
    service_1_22_10  service_visit_def_1233  1
    service_1_22_10  free_load_conservation_1234  8
    service_1_22_11  unique_nonzero_owner_360  1
    service_1_22_11  service_visit_def_1233  1
    service_1_22_11  free_load_conservation_1234  9
    service_1_22_12  unique_nonzero_owner_361  1
    service_1_22_12  service_visit_def_1233  1
    service_1_22_12  free_load_conservation_1234  10
    service_1_22_13  unique_nonzero_owner_362  1
    service_1_22_13  service_visit_def_1233  1
    service_1_22_13  free_load_conservation_1234  11
    service_1_22_14  unique_nonzero_owner_363  1
    service_1_22_14  service_visit_def_1233  1
    service_1_22_14  free_load_conservation_1234  12
    service_1_22_15  unique_nonzero_owner_364  1
    service_1_22_15  service_visit_def_1233  1
    service_1_22_15  free_load_conservation_1234  13
    service_2_22_0  unique_nonzero_owner_350  1
    service_2_22_0  service_visit_def_1551  1
    service_2_22_0  free_load_conservation_1552  -2
    service_2_22_0  original_T_including_depot_unload_1573  240
    service_2_22_1  unique_nonzero_owner_351  1
    service_2_22_1  service_visit_def_1551  1
    service_2_22_1  free_load_conservation_1552  -1
    service_2_22_1  original_T_including_depot_unload_1573  120
    service_2_22_3  unique_nonzero_owner_352  1
    service_2_22_3  service_visit_def_1551  1
    service_2_22_3  free_load_conservation_1552  1
    service_2_22_4  unique_nonzero_owner_353  1
    service_2_22_4  service_visit_def_1551  1
    service_2_22_4  free_load_conservation_1552  2
    service_2_22_5  unique_nonzero_owner_354  1
    service_2_22_5  service_visit_def_1551  1
    service_2_22_5  free_load_conservation_1552  3
    service_2_22_6  unique_nonzero_owner_355  1
    service_2_22_6  service_visit_def_1551  1
    service_2_22_6  free_load_conservation_1552  4
    service_2_22_7  unique_nonzero_owner_356  1
    service_2_22_7  service_visit_def_1551  1
    service_2_22_7  free_load_conservation_1552  5
    service_2_22_8  unique_nonzero_owner_357  1
    service_2_22_8  service_visit_def_1551  1
    service_2_22_8  free_load_conservation_1552  6
    service_2_22_9  unique_nonzero_owner_358  1
    service_2_22_9  service_visit_def_1551  1
    service_2_22_9  free_load_conservation_1552  7
    service_2_22_10  unique_nonzero_owner_359  1
    service_2_22_10  service_visit_def_1551  1
    service_2_22_10  free_load_conservation_1552  8
    service_2_22_11  unique_nonzero_owner_360  1
    service_2_22_11  service_visit_def_1551  1
    service_2_22_11  free_load_conservation_1552  9
    service_2_22_12  unique_nonzero_owner_361  1
    service_2_22_12  service_visit_def_1551  1
    service_2_22_12  free_load_conservation_1552  10
    service_2_22_13  unique_nonzero_owner_362  1
    service_2_22_13  service_visit_def_1551  1
    service_2_22_13  free_load_conservation_1552  11
    service_2_22_14  unique_nonzero_owner_363  1
    service_2_22_14  service_visit_def_1551  1
    service_2_22_14  free_load_conservation_1552  12
    service_2_22_15  unique_nonzero_owner_364  1
    service_2_22_15  service_visit_def_1551  1
    service_2_22_15  free_load_conservation_1552  13
    service_0_3_0  unique_nonzero_owner_365  1
    service_0_3_0  service_visit_def_866  1
    service_0_3_0  free_load_conservation_867  -9
    service_0_3_0  original_T_including_depot_unload_885  1080
    service_0_3_1  unique_nonzero_owner_366  1
    service_0_3_1  service_visit_def_866  1
    service_0_3_1  free_load_conservation_867  -8
    service_0_3_1  original_T_including_depot_unload_885  960
    service_0_3_2  unique_nonzero_owner_367  1
    service_0_3_2  service_visit_def_866  1
    service_0_3_2  free_load_conservation_867  -7
    service_0_3_2  original_T_including_depot_unload_885  840
    service_0_3_3  unique_nonzero_owner_368  1
    service_0_3_3  service_visit_def_866  1
    service_0_3_3  free_load_conservation_867  -6
    service_0_3_3  original_T_including_depot_unload_885  720
    service_0_3_4  unique_nonzero_owner_369  1
    service_0_3_4  service_visit_def_866  1
    service_0_3_4  free_load_conservation_867  -5
    service_0_3_4  original_T_including_depot_unload_885  600
    service_0_3_5  unique_nonzero_owner_370  1
    service_0_3_5  service_visit_def_866  1
    service_0_3_5  free_load_conservation_867  -4
    service_0_3_5  original_T_including_depot_unload_885  480
    service_0_3_6  unique_nonzero_owner_371  1
    service_0_3_6  service_visit_def_866  1
    service_0_3_6  free_load_conservation_867  -3
    service_0_3_6  original_T_including_depot_unload_885  360
    service_0_3_7  unique_nonzero_owner_372  1
    service_0_3_7  service_visit_def_866  1
    service_0_3_7  free_load_conservation_867  -2
    service_0_3_7  original_T_including_depot_unload_885  240
    service_0_3_8  unique_nonzero_owner_373  1
    service_0_3_8  service_visit_def_866  1
    service_0_3_8  free_load_conservation_867  -1
    service_0_3_8  original_T_including_depot_unload_885  120
    service_0_3_10  unique_nonzero_owner_374  1
    service_0_3_10  service_visit_def_866  1
    service_0_3_10  free_load_conservation_867  1
    service_0_3_11  unique_nonzero_owner_375  1
    service_0_3_11  service_visit_def_866  1
    service_0_3_11  free_load_conservation_867  2
    service_0_3_12  unique_nonzero_owner_376  1
    service_0_3_12  service_visit_def_866  1
    service_0_3_12  free_load_conservation_867  3
    service_1_3_0  unique_nonzero_owner_365  1
    service_1_3_0  service_visit_def_1239  1
    service_1_3_0  free_load_conservation_1240  -9
    service_1_3_0  original_T_including_depot_unload_1256  1080
    service_1_3_1  unique_nonzero_owner_366  1
    service_1_3_1  service_visit_def_1239  1
    service_1_3_1  free_load_conservation_1240  -8
    service_1_3_1  original_T_including_depot_unload_1256  960
    service_1_3_2  unique_nonzero_owner_367  1
    service_1_3_2  service_visit_def_1239  1
    service_1_3_2  free_load_conservation_1240  -7
    service_1_3_2  original_T_including_depot_unload_1256  840
    service_1_3_3  unique_nonzero_owner_368  1
    service_1_3_3  service_visit_def_1239  1
    service_1_3_3  free_load_conservation_1240  -6
    service_1_3_3  original_T_including_depot_unload_1256  720
    service_1_3_4  unique_nonzero_owner_369  1
    service_1_3_4  service_visit_def_1239  1
    service_1_3_4  free_load_conservation_1240  -5
    service_1_3_4  original_T_including_depot_unload_1256  600
    service_1_3_5  unique_nonzero_owner_370  1
    service_1_3_5  service_visit_def_1239  1
    service_1_3_5  free_load_conservation_1240  -4
    service_1_3_5  original_T_including_depot_unload_1256  480
    service_1_3_6  unique_nonzero_owner_371  1
    service_1_3_6  service_visit_def_1239  1
    service_1_3_6  free_load_conservation_1240  -3
    service_1_3_6  original_T_including_depot_unload_1256  360
    service_1_3_7  unique_nonzero_owner_372  1
    service_1_3_7  service_visit_def_1239  1
    service_1_3_7  free_load_conservation_1240  -2
    service_1_3_7  original_T_including_depot_unload_1256  240
    service_1_3_8  unique_nonzero_owner_373  1
    service_1_3_8  service_visit_def_1239  1
    service_1_3_8  free_load_conservation_1240  -1
    service_1_3_8  original_T_including_depot_unload_1256  120
    service_1_3_10  unique_nonzero_owner_374  1
    service_1_3_10  service_visit_def_1239  1
    service_1_3_10  free_load_conservation_1240  1
    service_1_3_11  unique_nonzero_owner_375  1
    service_1_3_11  service_visit_def_1239  1
    service_1_3_11  free_load_conservation_1240  2
    service_1_3_12  unique_nonzero_owner_376  1
    service_1_3_12  service_visit_def_1239  1
    service_1_3_12  free_load_conservation_1240  3
    service_2_3_0  unique_nonzero_owner_365  1
    service_2_3_0  service_visit_def_1557  1
    service_2_3_0  free_load_conservation_1558  -9
    service_2_3_0  original_T_including_depot_unload_1573  1080
    service_2_3_1  unique_nonzero_owner_366  1
    service_2_3_1  service_visit_def_1557  1
    service_2_3_1  free_load_conservation_1558  -8
    service_2_3_1  original_T_including_depot_unload_1573  960
    service_2_3_2  unique_nonzero_owner_367  1
    service_2_3_2  service_visit_def_1557  1
    service_2_3_2  free_load_conservation_1558  -7
    service_2_3_2  original_T_including_depot_unload_1573  840
    service_2_3_3  unique_nonzero_owner_368  1
    service_2_3_3  service_visit_def_1557  1
    service_2_3_3  free_load_conservation_1558  -6
    service_2_3_3  original_T_including_depot_unload_1573  720
    service_2_3_4  unique_nonzero_owner_369  1
    service_2_3_4  service_visit_def_1557  1
    service_2_3_4  free_load_conservation_1558  -5
    service_2_3_4  original_T_including_depot_unload_1573  600
    service_2_3_5  unique_nonzero_owner_370  1
    service_2_3_5  service_visit_def_1557  1
    service_2_3_5  free_load_conservation_1558  -4
    service_2_3_5  original_T_including_depot_unload_1573  480
    service_2_3_6  unique_nonzero_owner_371  1
    service_2_3_6  service_visit_def_1557  1
    service_2_3_6  free_load_conservation_1558  -3
    service_2_3_6  original_T_including_depot_unload_1573  360
    service_2_3_7  unique_nonzero_owner_372  1
    service_2_3_7  service_visit_def_1557  1
    service_2_3_7  free_load_conservation_1558  -2
    service_2_3_7  original_T_including_depot_unload_1573  240
    service_2_3_8  unique_nonzero_owner_373  1
    service_2_3_8  service_visit_def_1557  1
    service_2_3_8  free_load_conservation_1558  -1
    service_2_3_8  original_T_including_depot_unload_1573  120
    service_2_3_10  unique_nonzero_owner_374  1
    service_2_3_10  service_visit_def_1557  1
    service_2_3_10  free_load_conservation_1558  1
    service_2_3_11  unique_nonzero_owner_375  1
    service_2_3_11  service_visit_def_1557  1
    service_2_3_11  free_load_conservation_1558  2
    service_2_3_12  unique_nonzero_owner_376  1
    service_2_3_12  service_visit_def_1557  1
    service_2_3_12  free_load_conservation_1558  3
    service_0_27_1  unique_nonzero_owner_377  1
    service_0_27_1  service_visit_def_872  1
    service_0_27_1  free_load_conservation_873  1
    service_0_27_2  unique_nonzero_owner_378  1
    service_0_27_2  service_visit_def_872  1
    service_0_27_2  free_load_conservation_873  2
    service_0_27_3  unique_nonzero_owner_379  1
    service_0_27_3  service_visit_def_872  1
    service_0_27_3  free_load_conservation_873  3
    service_0_27_4  unique_nonzero_owner_380  1
    service_0_27_4  service_visit_def_872  1
    service_0_27_4  free_load_conservation_873  4
    service_0_27_5  unique_nonzero_owner_381  1
    service_0_27_5  service_visit_def_872  1
    service_0_27_5  free_load_conservation_873  5
    service_0_27_6  unique_nonzero_owner_382  1
    service_0_27_6  service_visit_def_872  1
    service_0_27_6  free_load_conservation_873  6
    service_1_27_1  unique_nonzero_owner_377  1
    service_1_27_1  service_visit_def_1245  1
    service_1_27_1  free_load_conservation_1246  1
    service_1_27_2  unique_nonzero_owner_378  1
    service_1_27_2  service_visit_def_1245  1
    service_1_27_2  free_load_conservation_1246  2
    service_1_27_3  unique_nonzero_owner_379  1
    service_1_27_3  service_visit_def_1245  1
    service_1_27_3  free_load_conservation_1246  3
    service_1_27_4  unique_nonzero_owner_380  1
    service_1_27_4  service_visit_def_1245  1
    service_1_27_4  free_load_conservation_1246  4
    service_1_27_5  unique_nonzero_owner_381  1
    service_1_27_5  service_visit_def_1245  1
    service_1_27_5  free_load_conservation_1246  5
    service_1_27_6  unique_nonzero_owner_382  1
    service_1_27_6  service_visit_def_1245  1
    service_1_27_6  free_load_conservation_1246  6
    service_2_27_1  unique_nonzero_owner_377  1
    service_2_27_1  service_visit_def_1563  1
    service_2_27_1  free_load_conservation_1564  1
    service_2_27_2  unique_nonzero_owner_378  1
    service_2_27_2  service_visit_def_1563  1
    service_2_27_2  free_load_conservation_1564  2
    service_2_27_3  unique_nonzero_owner_379  1
    service_2_27_3  service_visit_def_1563  1
    service_2_27_3  free_load_conservation_1564  3
    service_2_27_4  unique_nonzero_owner_380  1
    service_2_27_4  service_visit_def_1563  1
    service_2_27_4  free_load_conservation_1564  4
    service_2_27_5  unique_nonzero_owner_381  1
    service_2_27_5  service_visit_def_1563  1
    service_2_27_5  free_load_conservation_1564  5
    service_2_27_6  unique_nonzero_owner_382  1
    service_2_27_6  service_visit_def_1563  1
    service_2_27_6  free_load_conservation_1564  6
    service_0_8_0  unique_nonzero_owner_383  1
    service_0_8_0  service_visit_def_878  1
    service_0_8_0  free_load_conservation_879  -9
    service_0_8_0  original_T_including_depot_unload_885  1080
    service_0_8_1  unique_nonzero_owner_384  1
    service_0_8_1  service_visit_def_878  1
    service_0_8_1  free_load_conservation_879  -8
    service_0_8_1  original_T_including_depot_unload_885  960
    service_0_8_2  unique_nonzero_owner_385  1
    service_0_8_2  service_visit_def_878  1
    service_0_8_2  free_load_conservation_879  -7
    service_0_8_2  original_T_including_depot_unload_885  840
    service_0_8_3  unique_nonzero_owner_386  1
    service_0_8_3  service_visit_def_878  1
    service_0_8_3  free_load_conservation_879  -6
    service_0_8_3  original_T_including_depot_unload_885  720
    service_0_8_4  unique_nonzero_owner_387  1
    service_0_8_4  service_visit_def_878  1
    service_0_8_4  free_load_conservation_879  -5
    service_0_8_4  original_T_including_depot_unload_885  600
    service_0_8_5  unique_nonzero_owner_388  1
    service_0_8_5  service_visit_def_878  1
    service_0_8_5  free_load_conservation_879  -4
    service_0_8_5  original_T_including_depot_unload_885  480
    service_0_8_6  unique_nonzero_owner_389  1
    service_0_8_6  service_visit_def_878  1
    service_0_8_6  free_load_conservation_879  -3
    service_0_8_6  original_T_including_depot_unload_885  360
    service_0_8_7  unique_nonzero_owner_390  1
    service_0_8_7  service_visit_def_878  1
    service_0_8_7  free_load_conservation_879  -2
    service_0_8_7  original_T_including_depot_unload_885  240
    service_0_8_8  unique_nonzero_owner_391  1
    service_0_8_8  service_visit_def_878  1
    service_0_8_8  free_load_conservation_879  -1
    service_0_8_8  original_T_including_depot_unload_885  120
    service_0_8_10  unique_nonzero_owner_392  1
    service_0_8_10  service_visit_def_878  1
    service_0_8_10  free_load_conservation_879  1
    service_0_8_11  unique_nonzero_owner_393  1
    service_0_8_11  service_visit_def_878  1
    service_0_8_11  free_load_conservation_879  2
    service_0_8_12  unique_nonzero_owner_394  1
    service_0_8_12  service_visit_def_878  1
    service_0_8_12  free_load_conservation_879  3
    service_1_8_0  unique_nonzero_owner_383  1
    service_1_8_0  service_visit_def_1251  1
    service_1_8_0  free_load_conservation_1252  -9
    service_1_8_0  original_T_including_depot_unload_1256  1080
    service_1_8_1  unique_nonzero_owner_384  1
    service_1_8_1  service_visit_def_1251  1
    service_1_8_1  free_load_conservation_1252  -8
    service_1_8_1  original_T_including_depot_unload_1256  960
    service_1_8_2  unique_nonzero_owner_385  1
    service_1_8_2  service_visit_def_1251  1
    service_1_8_2  free_load_conservation_1252  -7
    service_1_8_2  original_T_including_depot_unload_1256  840
    service_1_8_3  unique_nonzero_owner_386  1
    service_1_8_3  service_visit_def_1251  1
    service_1_8_3  free_load_conservation_1252  -6
    service_1_8_3  original_T_including_depot_unload_1256  720
    service_1_8_4  unique_nonzero_owner_387  1
    service_1_8_4  service_visit_def_1251  1
    service_1_8_4  free_load_conservation_1252  -5
    service_1_8_4  original_T_including_depot_unload_1256  600
    service_1_8_5  unique_nonzero_owner_388  1
    service_1_8_5  service_visit_def_1251  1
    service_1_8_5  free_load_conservation_1252  -4
    service_1_8_5  original_T_including_depot_unload_1256  480
    service_1_8_6  unique_nonzero_owner_389  1
    service_1_8_6  service_visit_def_1251  1
    service_1_8_6  free_load_conservation_1252  -3
    service_1_8_6  original_T_including_depot_unload_1256  360
    service_1_8_7  unique_nonzero_owner_390  1
    service_1_8_7  service_visit_def_1251  1
    service_1_8_7  free_load_conservation_1252  -2
    service_1_8_7  original_T_including_depot_unload_1256  240
    service_1_8_8  unique_nonzero_owner_391  1
    service_1_8_8  service_visit_def_1251  1
    service_1_8_8  free_load_conservation_1252  -1
    service_1_8_8  original_T_including_depot_unload_1256  120
    service_1_8_10  unique_nonzero_owner_392  1
    service_1_8_10  service_visit_def_1251  1
    service_1_8_10  free_load_conservation_1252  1
    service_1_8_11  unique_nonzero_owner_393  1
    service_1_8_11  service_visit_def_1251  1
    service_1_8_11  free_load_conservation_1252  2
    service_1_8_12  unique_nonzero_owner_394  1
    service_1_8_12  service_visit_def_1251  1
    service_1_8_12  free_load_conservation_1252  3
    service_2_8_0  unique_nonzero_owner_383  1
    service_2_8_0  service_visit_def_1569  1
    service_2_8_0  free_load_conservation_1570  -9
    service_2_8_0  original_T_including_depot_unload_1573  1080
    service_2_8_1  unique_nonzero_owner_384  1
    service_2_8_1  service_visit_def_1569  1
    service_2_8_1  free_load_conservation_1570  -8
    service_2_8_1  original_T_including_depot_unload_1573  960
    service_2_8_2  unique_nonzero_owner_385  1
    service_2_8_2  service_visit_def_1569  1
    service_2_8_2  free_load_conservation_1570  -7
    service_2_8_2  original_T_including_depot_unload_1573  840
    service_2_8_3  unique_nonzero_owner_386  1
    service_2_8_3  service_visit_def_1569  1
    service_2_8_3  free_load_conservation_1570  -6
    service_2_8_3  original_T_including_depot_unload_1573  720
    service_2_8_4  unique_nonzero_owner_387  1
    service_2_8_4  service_visit_def_1569  1
    service_2_8_4  free_load_conservation_1570  -5
    service_2_8_4  original_T_including_depot_unload_1573  600
    service_2_8_5  unique_nonzero_owner_388  1
    service_2_8_5  service_visit_def_1569  1
    service_2_8_5  free_load_conservation_1570  -4
    service_2_8_5  original_T_including_depot_unload_1573  480
    service_2_8_6  unique_nonzero_owner_389  1
    service_2_8_6  service_visit_def_1569  1
    service_2_8_6  free_load_conservation_1570  -3
    service_2_8_6  original_T_including_depot_unload_1573  360
    service_2_8_7  unique_nonzero_owner_390  1
    service_2_8_7  service_visit_def_1569  1
    service_2_8_7  free_load_conservation_1570  -2
    service_2_8_7  original_T_including_depot_unload_1573  240
    service_2_8_8  unique_nonzero_owner_391  1
    service_2_8_8  service_visit_def_1569  1
    service_2_8_8  free_load_conservation_1570  -1
    service_2_8_8  original_T_including_depot_unload_1573  120
    service_2_8_10  unique_nonzero_owner_392  1
    service_2_8_10  service_visit_def_1569  1
    service_2_8_10  free_load_conservation_1570  1
    service_2_8_11  unique_nonzero_owner_393  1
    service_2_8_11  service_visit_def_1569  1
    service_2_8_11  free_load_conservation_1570  2
    service_2_8_12  unique_nonzero_owner_394  1
    service_2_8_12  service_visit_def_1569  1
    service_2_8_12  free_load_conservation_1570  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_790  -1
    visit_0_1  in_degree_791  -1
    visit_0_1  order_active_lb_792  -1
    visit_0_1  order_active_ub_793  -14
    order_0_1  connected_order_arc_412  -1
    order_0_1  connected_order_arc_414  -1
    order_0_1  connected_order_arc_416  -1
    order_0_1  connected_order_arc_418  -1
    order_0_1  connected_order_arc_420  -1
    order_0_1  connected_order_arc_422  -1
    order_0_1  connected_order_arc_424  -1
    order_0_1  connected_order_arc_426  -1
    order_0_1  connected_order_arc_428  -1
    order_0_1  connected_order_arc_430  -1
    order_0_1  connected_order_arc_432  -1
    order_0_1  connected_order_arc_434  -1
    order_0_1  connected_order_arc_436  -1
    order_0_1  connected_order_arc_439  1
    order_0_1  connected_order_arc_466  1
    order_0_1  connected_order_arc_493  1
    order_0_1  connected_order_arc_520  1
    order_0_1  connected_order_arc_547  1
    order_0_1  connected_order_arc_574  1
    order_0_1  connected_order_arc_601  1
    order_0_1  connected_order_arc_628  1
    order_0_1  connected_order_arc_655  1
    order_0_1  connected_order_arc_682  1
    order_0_1  connected_order_arc_709  1
    order_0_1  connected_order_arc_736  1
    order_0_1  connected_order_arc_763  1
    order_0_1  order_active_lb_792  1
    order_0_1  order_active_ub_793  1
    order_0_1  fixed_segment_relative_order_880  -1
    visit_0_2  out_degree_797  -1
    visit_0_2  in_degree_798  -1
    visit_0_2  order_active_lb_799  -1
    visit_0_2  order_active_ub_800  -14
    order_0_2  connected_order_arc_412  1
    order_0_2  connected_order_arc_439  -1
    order_0_2  connected_order_arc_441  -1
    order_0_2  connected_order_arc_443  -1
    order_0_2  connected_order_arc_445  -1
    order_0_2  connected_order_arc_447  -1
    order_0_2  connected_order_arc_449  -1
    order_0_2  connected_order_arc_451  -1
    order_0_2  connected_order_arc_453  -1
    order_0_2  connected_order_arc_455  -1
    order_0_2  connected_order_arc_457  -1
    order_0_2  connected_order_arc_459  -1
    order_0_2  connected_order_arc_461  -1
    order_0_2  connected_order_arc_463  -1
    order_0_2  connected_order_arc_468  1
    order_0_2  connected_order_arc_495  1
    order_0_2  connected_order_arc_522  1
    order_0_2  connected_order_arc_549  1
    order_0_2  connected_order_arc_576  1
    order_0_2  connected_order_arc_603  1
    order_0_2  connected_order_arc_630  1
    order_0_2  connected_order_arc_657  1
    order_0_2  connected_order_arc_684  1
    order_0_2  connected_order_arc_711  1
    order_0_2  connected_order_arc_738  1
    order_0_2  connected_order_arc_765  1
    order_0_2  order_active_lb_799  1
    order_0_2  order_active_ub_800  1
    order_0_2  fixed_segment_relative_order_880  1
    order_0_2  fixed_segment_relative_order_881  -1
    visit_0_3  out_degree_804  -1
    visit_0_3  in_degree_805  -1
    visit_0_3  order_active_lb_806  -1
    visit_0_3  order_active_ub_807  -14
    order_0_3  connected_order_arc_414  1
    order_0_3  connected_order_arc_441  1
    order_0_3  connected_order_arc_466  -1
    order_0_3  connected_order_arc_468  -1
    order_0_3  connected_order_arc_470  -1
    order_0_3  connected_order_arc_472  -1
    order_0_3  connected_order_arc_474  -1
    order_0_3  connected_order_arc_476  -1
    order_0_3  connected_order_arc_478  -1
    order_0_3  connected_order_arc_480  -1
    order_0_3  connected_order_arc_482  -1
    order_0_3  connected_order_arc_484  -1
    order_0_3  connected_order_arc_486  -1
    order_0_3  connected_order_arc_488  -1
    order_0_3  connected_order_arc_490  -1
    order_0_3  connected_order_arc_497  1
    order_0_3  connected_order_arc_524  1
    order_0_3  connected_order_arc_551  1
    order_0_3  connected_order_arc_578  1
    order_0_3  connected_order_arc_605  1
    order_0_3  connected_order_arc_632  1
    order_0_3  connected_order_arc_659  1
    order_0_3  connected_order_arc_686  1
    order_0_3  connected_order_arc_713  1
    order_0_3  connected_order_arc_740  1
    order_0_3  connected_order_arc_767  1
    order_0_3  order_active_lb_806  1
    order_0_3  order_active_ub_807  1
    order_0_3  fixed_segment_relative_order_881  1
    order_0_3  fixed_segment_relative_order_882  -1
    visit_0_4  out_degree_811  -1
    visit_0_4  in_degree_812  -1
    visit_0_4  order_active_lb_813  -1
    visit_0_4  order_active_ub_814  -14
    order_0_4  connected_order_arc_416  1
    order_0_4  connected_order_arc_443  1
    order_0_4  connected_order_arc_470  1
    order_0_4  connected_order_arc_493  -1
    order_0_4  connected_order_arc_495  -1
    order_0_4  connected_order_arc_497  -1
    order_0_4  connected_order_arc_499  -1
    order_0_4  connected_order_arc_501  -1
    order_0_4  connected_order_arc_503  -1
    order_0_4  connected_order_arc_505  -1
    order_0_4  connected_order_arc_507  -1
    order_0_4  connected_order_arc_509  -1
    order_0_4  connected_order_arc_511  -1
    order_0_4  connected_order_arc_513  -1
    order_0_4  connected_order_arc_515  -1
    order_0_4  connected_order_arc_517  -1
    order_0_4  connected_order_arc_526  1
    order_0_4  connected_order_arc_553  1
    order_0_4  connected_order_arc_580  1
    order_0_4  connected_order_arc_607  1
    order_0_4  connected_order_arc_634  1
    order_0_4  connected_order_arc_661  1
    order_0_4  connected_order_arc_688  1
    order_0_4  connected_order_arc_715  1
    order_0_4  connected_order_arc_742  1
    order_0_4  connected_order_arc_769  1
    order_0_4  order_active_lb_813  1
    order_0_4  order_active_ub_814  1
    order_0_4  fixed_segment_relative_order_882  1
    order_0_4  fixed_segment_relative_order_883  -1
    visit_0_5  out_degree_818  -1
    visit_0_5  in_degree_819  -1
    visit_0_5  order_active_lb_820  -1
    visit_0_5  order_active_ub_821  -14
    order_0_5  connected_order_arc_418  1
    order_0_5  connected_order_arc_445  1
    order_0_5  connected_order_arc_472  1
    order_0_5  connected_order_arc_499  1
    order_0_5  connected_order_arc_520  -1
    order_0_5  connected_order_arc_522  -1
    order_0_5  connected_order_arc_524  -1
    order_0_5  connected_order_arc_526  -1
    order_0_5  connected_order_arc_528  -1
    order_0_5  connected_order_arc_530  -1
    order_0_5  connected_order_arc_532  -1
    order_0_5  connected_order_arc_534  -1
    order_0_5  connected_order_arc_536  -1
    order_0_5  connected_order_arc_538  -1
    order_0_5  connected_order_arc_540  -1
    order_0_5  connected_order_arc_542  -1
    order_0_5  connected_order_arc_544  -1
    order_0_5  connected_order_arc_555  1
    order_0_5  connected_order_arc_582  1
    order_0_5  connected_order_arc_609  1
    order_0_5  connected_order_arc_636  1
    order_0_5  connected_order_arc_663  1
    order_0_5  connected_order_arc_690  1
    order_0_5  connected_order_arc_717  1
    order_0_5  connected_order_arc_744  1
    order_0_5  connected_order_arc_771  1
    order_0_5  order_active_lb_820  1
    order_0_5  order_active_ub_821  1
    order_0_5  fixed_segment_relative_order_883  1
    order_0_5  fixed_segment_relative_order_884  -1
    visit_0_6  out_degree_825  -1
    visit_0_6  in_degree_826  -1
    visit_0_6  order_active_lb_827  -1
    visit_0_6  order_active_ub_828  -14
    order_0_6  connected_order_arc_420  1
    order_0_6  connected_order_arc_447  1
    order_0_6  connected_order_arc_474  1
    order_0_6  connected_order_arc_501  1
    order_0_6  connected_order_arc_528  1
    order_0_6  connected_order_arc_547  -1
    order_0_6  connected_order_arc_549  -1
    order_0_6  connected_order_arc_551  -1
    order_0_6  connected_order_arc_553  -1
    order_0_6  connected_order_arc_555  -1
    order_0_6  connected_order_arc_557  -1
    order_0_6  connected_order_arc_559  -1
    order_0_6  connected_order_arc_561  -1
    order_0_6  connected_order_arc_563  -1
    order_0_6  connected_order_arc_565  -1
    order_0_6  connected_order_arc_567  -1
    order_0_6  connected_order_arc_569  -1
    order_0_6  connected_order_arc_571  -1
    order_0_6  connected_order_arc_584  1
    order_0_6  connected_order_arc_611  1
    order_0_6  connected_order_arc_638  1
    order_0_6  connected_order_arc_665  1
    order_0_6  connected_order_arc_692  1
    order_0_6  connected_order_arc_719  1
    order_0_6  connected_order_arc_746  1
    order_0_6  connected_order_arc_773  1
    order_0_6  order_active_lb_827  1
    order_0_6  order_active_ub_828  1
    order_0_6  fixed_segment_relative_order_884  1
    visit_0_14  out_degree_832  -1
    visit_0_14  in_degree_833  -1
    visit_0_14  order_active_lb_834  -1
    visit_0_14  order_active_ub_835  -14
    visit_0_14  service_visit_def_836  -1
    order_0_14  connected_order_arc_422  1
    order_0_14  connected_order_arc_449  1
    order_0_14  connected_order_arc_476  1
    order_0_14  connected_order_arc_503  1
    order_0_14  connected_order_arc_530  1
    order_0_14  connected_order_arc_557  1
    order_0_14  connected_order_arc_574  -1
    order_0_14  connected_order_arc_576  -1
    order_0_14  connected_order_arc_578  -1
    order_0_14  connected_order_arc_580  -1
    order_0_14  connected_order_arc_582  -1
    order_0_14  connected_order_arc_584  -1
    order_0_14  connected_order_arc_586  -1
    order_0_14  connected_order_arc_588  -1
    order_0_14  connected_order_arc_590  -1
    order_0_14  connected_order_arc_592  -1
    order_0_14  connected_order_arc_594  -1
    order_0_14  connected_order_arc_596  -1
    order_0_14  connected_order_arc_598  -1
    order_0_14  connected_order_arc_613  1
    order_0_14  connected_order_arc_640  1
    order_0_14  connected_order_arc_667  1
    order_0_14  connected_order_arc_694  1
    order_0_14  connected_order_arc_721  1
    order_0_14  connected_order_arc_748  1
    order_0_14  connected_order_arc_775  1
    order_0_14  order_active_lb_834  1
    order_0_14  order_active_ub_835  1
    visit_0_15  out_degree_838  -1
    visit_0_15  in_degree_839  -1
    visit_0_15  order_active_lb_840  -1
    visit_0_15  order_active_ub_841  -14
    visit_0_15  service_visit_def_842  -1
    order_0_15  connected_order_arc_424  1
    order_0_15  connected_order_arc_451  1
    order_0_15  connected_order_arc_478  1
    order_0_15  connected_order_arc_505  1
    order_0_15  connected_order_arc_532  1
    order_0_15  connected_order_arc_559  1
    order_0_15  connected_order_arc_586  1
    order_0_15  connected_order_arc_601  -1
    order_0_15  connected_order_arc_603  -1
    order_0_15  connected_order_arc_605  -1
    order_0_15  connected_order_arc_607  -1
    order_0_15  connected_order_arc_609  -1
    order_0_15  connected_order_arc_611  -1
    order_0_15  connected_order_arc_613  -1
    order_0_15  connected_order_arc_615  -1
    order_0_15  connected_order_arc_617  -1
    order_0_15  connected_order_arc_619  -1
    order_0_15  connected_order_arc_621  -1
    order_0_15  connected_order_arc_623  -1
    order_0_15  connected_order_arc_625  -1
    order_0_15  connected_order_arc_642  1
    order_0_15  connected_order_arc_669  1
    order_0_15  connected_order_arc_696  1
    order_0_15  connected_order_arc_723  1
    order_0_15  connected_order_arc_750  1
    order_0_15  connected_order_arc_777  1
    order_0_15  order_active_lb_840  1
    order_0_15  order_active_ub_841  1
    visit_0_16  out_degree_844  -1
    visit_0_16  in_degree_845  -1
    visit_0_16  order_active_lb_846  -1
    visit_0_16  order_active_ub_847  -14
    visit_0_16  service_visit_def_848  -1
    order_0_16  connected_order_arc_426  1
    order_0_16  connected_order_arc_453  1
    order_0_16  connected_order_arc_480  1
    order_0_16  connected_order_arc_507  1
    order_0_16  connected_order_arc_534  1
    order_0_16  connected_order_arc_561  1
    order_0_16  connected_order_arc_588  1
    order_0_16  connected_order_arc_615  1
    order_0_16  connected_order_arc_628  -1
    order_0_16  connected_order_arc_630  -1
    order_0_16  connected_order_arc_632  -1
    order_0_16  connected_order_arc_634  -1
    order_0_16  connected_order_arc_636  -1
    order_0_16  connected_order_arc_638  -1
    order_0_16  connected_order_arc_640  -1
    order_0_16  connected_order_arc_642  -1
    order_0_16  connected_order_arc_644  -1
    order_0_16  connected_order_arc_646  -1
    order_0_16  connected_order_arc_648  -1
    order_0_16  connected_order_arc_650  -1
    order_0_16  connected_order_arc_652  -1
    order_0_16  connected_order_arc_671  1
    order_0_16  connected_order_arc_698  1
    order_0_16  connected_order_arc_725  1
    order_0_16  connected_order_arc_752  1
    order_0_16  connected_order_arc_779  1
    order_0_16  order_active_lb_846  1
    order_0_16  order_active_ub_847  1
    visit_0_17  out_degree_850  -1
    visit_0_17  in_degree_851  -1
    visit_0_17  order_active_lb_852  -1
    visit_0_17  order_active_ub_853  -14
    visit_0_17  service_visit_def_854  -1
    order_0_17  connected_order_arc_428  1
    order_0_17  connected_order_arc_455  1
    order_0_17  connected_order_arc_482  1
    order_0_17  connected_order_arc_509  1
    order_0_17  connected_order_arc_536  1
    order_0_17  connected_order_arc_563  1
    order_0_17  connected_order_arc_590  1
    order_0_17  connected_order_arc_617  1
    order_0_17  connected_order_arc_644  1
    order_0_17  connected_order_arc_655  -1
    order_0_17  connected_order_arc_657  -1
    order_0_17  connected_order_arc_659  -1
    order_0_17  connected_order_arc_661  -1
    order_0_17  connected_order_arc_663  -1
    order_0_17  connected_order_arc_665  -1
    order_0_17  connected_order_arc_667  -1
    order_0_17  connected_order_arc_669  -1
    order_0_17  connected_order_arc_671  -1
    order_0_17  connected_order_arc_673  -1
    order_0_17  connected_order_arc_675  -1
    order_0_17  connected_order_arc_677  -1
    order_0_17  connected_order_arc_679  -1
    order_0_17  connected_order_arc_700  1
    order_0_17  connected_order_arc_727  1
    order_0_17  connected_order_arc_754  1
    order_0_17  connected_order_arc_781  1
    order_0_17  order_active_lb_852  1
    order_0_17  order_active_ub_853  1
    visit_0_18  out_degree_856  -1
    visit_0_18  in_degree_857  -1
    visit_0_18  order_active_lb_858  -1
    visit_0_18  order_active_ub_859  -14
    visit_0_18  service_visit_def_860  -1
    order_0_18  connected_order_arc_430  1
    order_0_18  connected_order_arc_457  1
    order_0_18  connected_order_arc_484  1
    order_0_18  connected_order_arc_511  1
    order_0_18  connected_order_arc_538  1
    order_0_18  connected_order_arc_565  1
    order_0_18  connected_order_arc_592  1
    order_0_18  connected_order_arc_619  1
    order_0_18  connected_order_arc_646  1
    order_0_18  connected_order_arc_673  1
    order_0_18  connected_order_arc_682  -1
    order_0_18  connected_order_arc_684  -1
    order_0_18  connected_order_arc_686  -1
    order_0_18  connected_order_arc_688  -1
    order_0_18  connected_order_arc_690  -1
    order_0_18  connected_order_arc_692  -1
    order_0_18  connected_order_arc_694  -1
    order_0_18  connected_order_arc_696  -1
    order_0_18  connected_order_arc_698  -1
    order_0_18  connected_order_arc_700  -1
    order_0_18  connected_order_arc_702  -1
    order_0_18  connected_order_arc_704  -1
    order_0_18  connected_order_arc_706  -1
    order_0_18  connected_order_arc_729  1
    order_0_18  connected_order_arc_756  1
    order_0_18  connected_order_arc_783  1
    order_0_18  order_active_lb_858  1
    order_0_18  order_active_ub_859  1
    visit_0_19  out_degree_862  -1
    visit_0_19  in_degree_863  -1
    visit_0_19  order_active_lb_864  -1
    visit_0_19  order_active_ub_865  -14
    visit_0_19  service_visit_def_866  -1
    order_0_19  connected_order_arc_432  1
    order_0_19  connected_order_arc_459  1
    order_0_19  connected_order_arc_486  1
    order_0_19  connected_order_arc_513  1
    order_0_19  connected_order_arc_540  1
    order_0_19  connected_order_arc_567  1
    order_0_19  connected_order_arc_594  1
    order_0_19  connected_order_arc_621  1
    order_0_19  connected_order_arc_648  1
    order_0_19  connected_order_arc_675  1
    order_0_19  connected_order_arc_702  1
    order_0_19  connected_order_arc_709  -1
    order_0_19  connected_order_arc_711  -1
    order_0_19  connected_order_arc_713  -1
    order_0_19  connected_order_arc_715  -1
    order_0_19  connected_order_arc_717  -1
    order_0_19  connected_order_arc_719  -1
    order_0_19  connected_order_arc_721  -1
    order_0_19  connected_order_arc_723  -1
    order_0_19  connected_order_arc_725  -1
    order_0_19  connected_order_arc_727  -1
    order_0_19  connected_order_arc_729  -1
    order_0_19  connected_order_arc_731  -1
    order_0_19  connected_order_arc_733  -1
    order_0_19  connected_order_arc_758  1
    order_0_19  connected_order_arc_785  1
    order_0_19  order_active_lb_864  1
    order_0_19  order_active_ub_865  1
    visit_0_20  out_degree_868  -1
    visit_0_20  in_degree_869  -1
    visit_0_20  order_active_lb_870  -1
    visit_0_20  order_active_ub_871  -14
    visit_0_20  service_visit_def_872  -1
    order_0_20  connected_order_arc_434  1
    order_0_20  connected_order_arc_461  1
    order_0_20  connected_order_arc_488  1
    order_0_20  connected_order_arc_515  1
    order_0_20  connected_order_arc_542  1
    order_0_20  connected_order_arc_569  1
    order_0_20  connected_order_arc_596  1
    order_0_20  connected_order_arc_623  1
    order_0_20  connected_order_arc_650  1
    order_0_20  connected_order_arc_677  1
    order_0_20  connected_order_arc_704  1
    order_0_20  connected_order_arc_731  1
    order_0_20  connected_order_arc_736  -1
    order_0_20  connected_order_arc_738  -1
    order_0_20  connected_order_arc_740  -1
    order_0_20  connected_order_arc_742  -1
    order_0_20  connected_order_arc_744  -1
    order_0_20  connected_order_arc_746  -1
    order_0_20  connected_order_arc_748  -1
    order_0_20  connected_order_arc_750  -1
    order_0_20  connected_order_arc_752  -1
    order_0_20  connected_order_arc_754  -1
    order_0_20  connected_order_arc_756  -1
    order_0_20  connected_order_arc_758  -1
    order_0_20  connected_order_arc_760  -1
    order_0_20  connected_order_arc_787  1
    order_0_20  order_active_lb_870  1
    order_0_20  order_active_ub_871  1
    visit_0_21  out_degree_874  -1
    visit_0_21  in_degree_875  -1
    visit_0_21  order_active_lb_876  -1
    visit_0_21  order_active_ub_877  -14
    visit_0_21  service_visit_def_878  -1
    order_0_21  connected_order_arc_436  1
    order_0_21  connected_order_arc_463  1
    order_0_21  connected_order_arc_490  1
    order_0_21  connected_order_arc_517  1
    order_0_21  connected_order_arc_544  1
    order_0_21  connected_order_arc_571  1
    order_0_21  connected_order_arc_598  1
    order_0_21  connected_order_arc_625  1
    order_0_21  connected_order_arc_652  1
    order_0_21  connected_order_arc_679  1
    order_0_21  connected_order_arc_706  1
    order_0_21  connected_order_arc_733  1
    order_0_21  connected_order_arc_760  1
    order_0_21  connected_order_arc_763  -1
    order_0_21  connected_order_arc_765  -1
    order_0_21  connected_order_arc_767  -1
    order_0_21  connected_order_arc_769  -1
    order_0_21  connected_order_arc_771  -1
    order_0_21  connected_order_arc_773  -1
    order_0_21  connected_order_arc_775  -1
    order_0_21  connected_order_arc_777  -1
    order_0_21  connected_order_arc_779  -1
    order_0_21  connected_order_arc_781  -1
    order_0_21  connected_order_arc_783  -1
    order_0_21  connected_order_arc_785  -1
    order_0_21  connected_order_arc_787  -1
    order_0_21  order_active_lb_876  1
    order_0_21  order_active_ub_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_395  -20
    arc_0_0_0  depot_departure_or_bypass_788  1
    arc_0_0_0  depot_return_or_bypass_789  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_395  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_396  -20
    arc_0_0_1  depot_departure_or_bypass_788  1
    arc_0_0_1  in_degree_791  1
    arc_0_0_1  original_T_including_depot_unload_885  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_396  1
    load_0_0_1  segment_load_conservation_794  -1
    load_0_0_1  segment_prefix_lb_795  1
    load_0_0_1  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_397  -20
    arc_0_0_2  depot_departure_or_bypass_788  1
    arc_0_0_2  in_degree_798  1
    arc_0_0_2  original_T_including_depot_unload_885  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_397  1
    load_0_0_2  segment_load_conservation_801  -1
    load_0_0_2  segment_prefix_lb_802  1
    load_0_0_2  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_398  -20
    arc_0_0_3  depot_departure_or_bypass_788  1
    arc_0_0_3  in_degree_805  1
    arc_0_0_3  original_T_including_depot_unload_885  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_398  1
    load_0_0_3  segment_load_conservation_808  -1
    load_0_0_3  segment_prefix_lb_809  1
    load_0_0_3  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_399  -20
    arc_0_0_4  depot_departure_or_bypass_788  1
    arc_0_0_4  in_degree_812  1
    arc_0_0_4  original_T_including_depot_unload_885  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_399  1
    load_0_0_4  segment_load_conservation_815  -1
    load_0_0_4  segment_prefix_lb_816  1
    load_0_0_4  segment_prefix_ub_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_400  -20
    arc_0_0_5  depot_departure_or_bypass_788  1
    arc_0_0_5  in_degree_819  1
    arc_0_0_5  original_T_including_depot_unload_885  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_400  1
    load_0_0_5  segment_load_conservation_822  -1
    load_0_0_5  segment_prefix_lb_823  1
    load_0_0_5  segment_prefix_ub_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_401  -20
    arc_0_0_6  depot_departure_or_bypass_788  1
    arc_0_0_6  in_degree_826  1
    arc_0_0_6  original_T_including_depot_unload_885  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_401  1
    load_0_0_6  segment_load_conservation_829  -1
    load_0_0_6  segment_prefix_lb_830  1
    load_0_0_6  segment_prefix_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_402  -20
    arc_0_0_14  depot_departure_or_bypass_788  1
    arc_0_0_14  in_degree_833  1
    arc_0_0_14  original_T_including_depot_unload_885  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_402  1
    load_0_0_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_403  -20
    arc_0_0_15  depot_departure_or_bypass_788  1
    arc_0_0_15  in_degree_839  1
    arc_0_0_15  original_T_including_depot_unload_885  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_403  1
    load_0_0_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_404  -20
    arc_0_0_16  depot_departure_or_bypass_788  1
    arc_0_0_16  in_degree_845  1
    arc_0_0_16  original_T_including_depot_unload_885  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_404  1
    load_0_0_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_405  -20
    arc_0_0_17  depot_departure_or_bypass_788  1
    arc_0_0_17  in_degree_851  1
    arc_0_0_17  original_T_including_depot_unload_885  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_405  1
    load_0_0_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_406  -20
    arc_0_0_18  depot_departure_or_bypass_788  1
    arc_0_0_18  in_degree_857  1
    arc_0_0_18  original_T_including_depot_unload_885  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_406  1
    load_0_0_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_407  -20
    arc_0_0_19  depot_departure_or_bypass_788  1
    arc_0_0_19  in_degree_863  1
    arc_0_0_19  original_T_including_depot_unload_885  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_407  1
    load_0_0_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_408  -20
    arc_0_0_20  depot_departure_or_bypass_788  1
    arc_0_0_20  in_degree_869  1
    arc_0_0_20  original_T_including_depot_unload_885  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_408  1
    load_0_0_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_409  -20
    arc_0_0_21  depot_departure_or_bypass_788  1
    arc_0_0_21  in_degree_875  1
    arc_0_0_21  original_T_including_depot_unload_885  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_409  1
    load_0_0_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_410  -20
    arc_0_1_0  depot_return_or_bypass_789  1
    arc_0_1_0  out_degree_790  1
    arc_0_1_0  original_T_including_depot_unload_885  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_410  1
    load_0_1_0  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_411  -20
    arc_0_1_2  connected_order_arc_412  -15
    arc_0_1_2  out_degree_790  1
    arc_0_1_2  in_degree_798  1
    arc_0_1_2  original_T_including_depot_unload_885  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_411  1
    load_0_1_2  segment_load_conservation_794  1
    load_0_1_2  segment_load_conservation_801  -1
    load_0_1_2  segment_prefix_lb_802  1
    load_0_1_2  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_413  -20
    arc_0_1_3  connected_order_arc_414  -15
    arc_0_1_3  out_degree_790  1
    arc_0_1_3  in_degree_805  1
    arc_0_1_3  original_T_including_depot_unload_885  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_413  1
    load_0_1_3  segment_load_conservation_794  1
    load_0_1_3  segment_load_conservation_808  -1
    load_0_1_3  segment_prefix_lb_809  1
    load_0_1_3  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_415  -20
    arc_0_1_4  connected_order_arc_416  -15
    arc_0_1_4  out_degree_790  1
    arc_0_1_4  in_degree_812  1
    arc_0_1_4  original_T_including_depot_unload_885  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_415  1
    load_0_1_4  segment_load_conservation_794  1
    load_0_1_4  segment_load_conservation_815  -1
    load_0_1_4  segment_prefix_lb_816  1
    load_0_1_4  segment_prefix_ub_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_417  -20
    arc_0_1_5  connected_order_arc_418  -15
    arc_0_1_5  out_degree_790  1
    arc_0_1_5  in_degree_819  1
    arc_0_1_5  original_T_including_depot_unload_885  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_417  1
    load_0_1_5  segment_load_conservation_794  1
    load_0_1_5  segment_load_conservation_822  -1
    load_0_1_5  segment_prefix_lb_823  1
    load_0_1_5  segment_prefix_ub_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_419  -20
    arc_0_1_6  connected_order_arc_420  -15
    arc_0_1_6  out_degree_790  1
    arc_0_1_6  in_degree_826  1
    arc_0_1_6  original_T_including_depot_unload_885  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_419  1
    load_0_1_6  segment_load_conservation_794  1
    load_0_1_6  segment_load_conservation_829  -1
    load_0_1_6  segment_prefix_lb_830  1
    load_0_1_6  segment_prefix_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_421  -20
    arc_0_1_14  connected_order_arc_422  -15
    arc_0_1_14  out_degree_790  1
    arc_0_1_14  in_degree_833  1
    arc_0_1_14  original_T_including_depot_unload_885  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_421  1
    load_0_1_14  segment_load_conservation_794  1
    load_0_1_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_423  -20
    arc_0_1_15  connected_order_arc_424  -15
    arc_0_1_15  out_degree_790  1
    arc_0_1_15  in_degree_839  1
    arc_0_1_15  original_T_including_depot_unload_885  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_423  1
    load_0_1_15  segment_load_conservation_794  1
    load_0_1_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_425  -20
    arc_0_1_16  connected_order_arc_426  -15
    arc_0_1_16  out_degree_790  1
    arc_0_1_16  in_degree_845  1
    arc_0_1_16  original_T_including_depot_unload_885  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_425  1
    load_0_1_16  segment_load_conservation_794  1
    load_0_1_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_427  -20
    arc_0_1_17  connected_order_arc_428  -15
    arc_0_1_17  out_degree_790  1
    arc_0_1_17  in_degree_851  1
    arc_0_1_17  original_T_including_depot_unload_885  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_427  1
    load_0_1_17  segment_load_conservation_794  1
    load_0_1_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_429  -20
    arc_0_1_18  connected_order_arc_430  -15
    arc_0_1_18  out_degree_790  1
    arc_0_1_18  in_degree_857  1
    arc_0_1_18  original_T_including_depot_unload_885  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_429  1
    load_0_1_18  segment_load_conservation_794  1
    load_0_1_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_431  -20
    arc_0_1_19  connected_order_arc_432  -15
    arc_0_1_19  out_degree_790  1
    arc_0_1_19  in_degree_863  1
    arc_0_1_19  original_T_including_depot_unload_885  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_431  1
    load_0_1_19  segment_load_conservation_794  1
    load_0_1_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_433  -20
    arc_0_1_20  connected_order_arc_434  -15
    arc_0_1_20  out_degree_790  1
    arc_0_1_20  in_degree_869  1
    arc_0_1_20  original_T_including_depot_unload_885  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_433  1
    load_0_1_20  segment_load_conservation_794  1
    load_0_1_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_435  -20
    arc_0_1_21  connected_order_arc_436  -15
    arc_0_1_21  out_degree_790  1
    arc_0_1_21  in_degree_875  1
    arc_0_1_21  original_T_including_depot_unload_885  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_435  1
    load_0_1_21  segment_load_conservation_794  1
    load_0_1_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_437  -20
    arc_0_2_0  depot_return_or_bypass_789  1
    arc_0_2_0  out_degree_797  1
    arc_0_2_0  original_T_including_depot_unload_885  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_437  1
    load_0_2_0  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_438  -20
    arc_0_2_1  connected_order_arc_439  -15
    arc_0_2_1  in_degree_791  1
    arc_0_2_1  out_degree_797  1
    arc_0_2_1  original_T_including_depot_unload_885  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_438  1
    load_0_2_1  segment_load_conservation_794  -1
    load_0_2_1  segment_prefix_lb_795  1
    load_0_2_1  segment_prefix_ub_796  1
    load_0_2_1  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_440  -20
    arc_0_2_3  connected_order_arc_441  -15
    arc_0_2_3  out_degree_797  1
    arc_0_2_3  in_degree_805  1
    arc_0_2_3  original_T_including_depot_unload_885  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_440  1
    load_0_2_3  segment_load_conservation_801  1
    load_0_2_3  segment_load_conservation_808  -1
    load_0_2_3  segment_prefix_lb_809  1
    load_0_2_3  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_442  -20
    arc_0_2_4  connected_order_arc_443  -15
    arc_0_2_4  out_degree_797  1
    arc_0_2_4  in_degree_812  1
    arc_0_2_4  original_T_including_depot_unload_885  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_442  1
    load_0_2_4  segment_load_conservation_801  1
    load_0_2_4  segment_load_conservation_815  -1
    load_0_2_4  segment_prefix_lb_816  1
    load_0_2_4  segment_prefix_ub_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_444  -20
    arc_0_2_5  connected_order_arc_445  -15
    arc_0_2_5  out_degree_797  1
    arc_0_2_5  in_degree_819  1
    arc_0_2_5  original_T_including_depot_unload_885  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_444  1
    load_0_2_5  segment_load_conservation_801  1
    load_0_2_5  segment_load_conservation_822  -1
    load_0_2_5  segment_prefix_lb_823  1
    load_0_2_5  segment_prefix_ub_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_446  -20
    arc_0_2_6  connected_order_arc_447  -15
    arc_0_2_6  out_degree_797  1
    arc_0_2_6  in_degree_826  1
    arc_0_2_6  original_T_including_depot_unload_885  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_446  1
    load_0_2_6  segment_load_conservation_801  1
    load_0_2_6  segment_load_conservation_829  -1
    load_0_2_6  segment_prefix_lb_830  1
    load_0_2_6  segment_prefix_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_448  -20
    arc_0_2_14  connected_order_arc_449  -15
    arc_0_2_14  out_degree_797  1
    arc_0_2_14  in_degree_833  1
    arc_0_2_14  original_T_including_depot_unload_885  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_448  1
    load_0_2_14  segment_load_conservation_801  1
    load_0_2_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_450  -20
    arc_0_2_15  connected_order_arc_451  -15
    arc_0_2_15  out_degree_797  1
    arc_0_2_15  in_degree_839  1
    arc_0_2_15  original_T_including_depot_unload_885  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_450  1
    load_0_2_15  segment_load_conservation_801  1
    load_0_2_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_452  -20
    arc_0_2_16  connected_order_arc_453  -15
    arc_0_2_16  out_degree_797  1
    arc_0_2_16  in_degree_845  1
    arc_0_2_16  original_T_including_depot_unload_885  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_452  1
    load_0_2_16  segment_load_conservation_801  1
    load_0_2_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_454  -20
    arc_0_2_17  connected_order_arc_455  -15
    arc_0_2_17  out_degree_797  1
    arc_0_2_17  in_degree_851  1
    arc_0_2_17  original_T_including_depot_unload_885  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_454  1
    load_0_2_17  segment_load_conservation_801  1
    load_0_2_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_456  -20
    arc_0_2_18  connected_order_arc_457  -15
    arc_0_2_18  out_degree_797  1
    arc_0_2_18  in_degree_857  1
    arc_0_2_18  original_T_including_depot_unload_885  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_456  1
    load_0_2_18  segment_load_conservation_801  1
    load_0_2_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_458  -20
    arc_0_2_19  connected_order_arc_459  -15
    arc_0_2_19  out_degree_797  1
    arc_0_2_19  in_degree_863  1
    arc_0_2_19  original_T_including_depot_unload_885  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_458  1
    load_0_2_19  segment_load_conservation_801  1
    load_0_2_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_460  -20
    arc_0_2_20  connected_order_arc_461  -15
    arc_0_2_20  out_degree_797  1
    arc_0_2_20  in_degree_869  1
    arc_0_2_20  original_T_including_depot_unload_885  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_460  1
    load_0_2_20  segment_load_conservation_801  1
    load_0_2_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_462  -20
    arc_0_2_21  connected_order_arc_463  -15
    arc_0_2_21  out_degree_797  1
    arc_0_2_21  in_degree_875  1
    arc_0_2_21  original_T_including_depot_unload_885  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_462  1
    load_0_2_21  segment_load_conservation_801  1
    load_0_2_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_464  -20
    arc_0_3_0  depot_return_or_bypass_789  1
    arc_0_3_0  out_degree_804  1
    arc_0_3_0  original_T_including_depot_unload_885  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_464  1
    load_0_3_0  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_465  -20
    arc_0_3_1  connected_order_arc_466  -15
    arc_0_3_1  in_degree_791  1
    arc_0_3_1  out_degree_804  1
    arc_0_3_1  original_T_including_depot_unload_885  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_465  1
    load_0_3_1  segment_load_conservation_794  -1
    load_0_3_1  segment_prefix_lb_795  1
    load_0_3_1  segment_prefix_ub_796  1
    load_0_3_1  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_467  -20
    arc_0_3_2  connected_order_arc_468  -15
    arc_0_3_2  in_degree_798  1
    arc_0_3_2  out_degree_804  1
    arc_0_3_2  original_T_including_depot_unload_885  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_467  1
    load_0_3_2  segment_load_conservation_801  -1
    load_0_3_2  segment_prefix_lb_802  1
    load_0_3_2  segment_prefix_ub_803  1
    load_0_3_2  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_469  -20
    arc_0_3_4  connected_order_arc_470  -15
    arc_0_3_4  out_degree_804  1
    arc_0_3_4  in_degree_812  1
    arc_0_3_4  original_T_including_depot_unload_885  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_469  1
    load_0_3_4  segment_load_conservation_808  1
    load_0_3_4  segment_load_conservation_815  -1
    load_0_3_4  segment_prefix_lb_816  1
    load_0_3_4  segment_prefix_ub_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_471  -20
    arc_0_3_5  connected_order_arc_472  -15
    arc_0_3_5  out_degree_804  1
    arc_0_3_5  in_degree_819  1
    arc_0_3_5  original_T_including_depot_unload_885  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_471  1
    load_0_3_5  segment_load_conservation_808  1
    load_0_3_5  segment_load_conservation_822  -1
    load_0_3_5  segment_prefix_lb_823  1
    load_0_3_5  segment_prefix_ub_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_473  -20
    arc_0_3_6  connected_order_arc_474  -15
    arc_0_3_6  out_degree_804  1
    arc_0_3_6  in_degree_826  1
    arc_0_3_6  original_T_including_depot_unload_885  7.6007185336497685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_473  1
    load_0_3_6  segment_load_conservation_808  1
    load_0_3_6  segment_load_conservation_829  -1
    load_0_3_6  segment_prefix_lb_830  1
    load_0_3_6  segment_prefix_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_475  -20
    arc_0_3_14  connected_order_arc_476  -15
    arc_0_3_14  out_degree_804  1
    arc_0_3_14  in_degree_833  1
    arc_0_3_14  original_T_including_depot_unload_885  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_475  1
    load_0_3_14  segment_load_conservation_808  1
    load_0_3_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_477  -20
    arc_0_3_15  connected_order_arc_478  -15
    arc_0_3_15  out_degree_804  1
    arc_0_3_15  in_degree_839  1
    arc_0_3_15  original_T_including_depot_unload_885  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_477  1
    load_0_3_15  segment_load_conservation_808  1
    load_0_3_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_479  -20
    arc_0_3_16  connected_order_arc_480  -15
    arc_0_3_16  out_degree_804  1
    arc_0_3_16  in_degree_845  1
    arc_0_3_16  original_T_including_depot_unload_885  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_479  1
    load_0_3_16  segment_load_conservation_808  1
    load_0_3_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_481  -20
    arc_0_3_17  connected_order_arc_482  -15
    arc_0_3_17  out_degree_804  1
    arc_0_3_17  in_degree_851  1
    arc_0_3_17  original_T_including_depot_unload_885  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_481  1
    load_0_3_17  segment_load_conservation_808  1
    load_0_3_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_483  -20
    arc_0_3_18  connected_order_arc_484  -15
    arc_0_3_18  out_degree_804  1
    arc_0_3_18  in_degree_857  1
    arc_0_3_18  original_T_including_depot_unload_885  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_483  1
    load_0_3_18  segment_load_conservation_808  1
    load_0_3_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_485  -20
    arc_0_3_19  connected_order_arc_486  -15
    arc_0_3_19  out_degree_804  1
    arc_0_3_19  in_degree_863  1
    arc_0_3_19  original_T_including_depot_unload_885  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_485  1
    load_0_3_19  segment_load_conservation_808  1
    load_0_3_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_487  -20
    arc_0_3_20  connected_order_arc_488  -15
    arc_0_3_20  out_degree_804  1
    arc_0_3_20  in_degree_869  1
    arc_0_3_20  original_T_including_depot_unload_885  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_487  1
    load_0_3_20  segment_load_conservation_808  1
    load_0_3_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_489  -20
    arc_0_3_21  connected_order_arc_490  -15
    arc_0_3_21  out_degree_804  1
    arc_0_3_21  in_degree_875  1
    arc_0_3_21  original_T_including_depot_unload_885  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_489  1
    load_0_3_21  segment_load_conservation_808  1
    load_0_3_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_491  -20
    arc_0_4_0  depot_return_or_bypass_789  1
    arc_0_4_0  out_degree_811  1
    arc_0_4_0  original_T_including_depot_unload_885  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_491  1
    load_0_4_0  segment_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_492  -20
    arc_0_4_1  connected_order_arc_493  -15
    arc_0_4_1  in_degree_791  1
    arc_0_4_1  out_degree_811  1
    arc_0_4_1  original_T_including_depot_unload_885  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_492  1
    load_0_4_1  segment_load_conservation_794  -1
    load_0_4_1  segment_prefix_lb_795  1
    load_0_4_1  segment_prefix_ub_796  1
    load_0_4_1  segment_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_494  -20
    arc_0_4_2  connected_order_arc_495  -15
    arc_0_4_2  in_degree_798  1
    arc_0_4_2  out_degree_811  1
    arc_0_4_2  original_T_including_depot_unload_885  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_494  1
    load_0_4_2  segment_load_conservation_801  -1
    load_0_4_2  segment_prefix_lb_802  1
    load_0_4_2  segment_prefix_ub_803  1
    load_0_4_2  segment_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_496  -20
    arc_0_4_3  connected_order_arc_497  -15
    arc_0_4_3  in_degree_805  1
    arc_0_4_3  out_degree_811  1
    arc_0_4_3  original_T_including_depot_unload_885  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_496  1
    load_0_4_3  segment_load_conservation_808  -1
    load_0_4_3  segment_prefix_lb_809  1
    load_0_4_3  segment_prefix_ub_810  1
    load_0_4_3  segment_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_498  -20
    arc_0_4_5  connected_order_arc_499  -15
    arc_0_4_5  out_degree_811  1
    arc_0_4_5  in_degree_819  1
    arc_0_4_5  original_T_including_depot_unload_885  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_498  1
    load_0_4_5  segment_load_conservation_815  1
    load_0_4_5  segment_load_conservation_822  -1
    load_0_4_5  segment_prefix_lb_823  1
    load_0_4_5  segment_prefix_ub_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_500  -20
    arc_0_4_6  connected_order_arc_501  -15
    arc_0_4_6  out_degree_811  1
    arc_0_4_6  in_degree_826  1
    arc_0_4_6  original_T_including_depot_unload_885  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_500  1
    load_0_4_6  segment_load_conservation_815  1
    load_0_4_6  segment_load_conservation_829  -1
    load_0_4_6  segment_prefix_lb_830  1
    load_0_4_6  segment_prefix_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_502  -20
    arc_0_4_14  connected_order_arc_503  -15
    arc_0_4_14  out_degree_811  1
    arc_0_4_14  in_degree_833  1
    arc_0_4_14  original_T_including_depot_unload_885  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_502  1
    load_0_4_14  segment_load_conservation_815  1
    load_0_4_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_504  -20
    arc_0_4_15  connected_order_arc_505  -15
    arc_0_4_15  out_degree_811  1
    arc_0_4_15  in_degree_839  1
    arc_0_4_15  original_T_including_depot_unload_885  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_504  1
    load_0_4_15  segment_load_conservation_815  1
    load_0_4_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_506  -20
    arc_0_4_16  connected_order_arc_507  -15
    arc_0_4_16  out_degree_811  1
    arc_0_4_16  in_degree_845  1
    arc_0_4_16  original_T_including_depot_unload_885  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_506  1
    load_0_4_16  segment_load_conservation_815  1
    load_0_4_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_508  -20
    arc_0_4_17  connected_order_arc_509  -15
    arc_0_4_17  out_degree_811  1
    arc_0_4_17  in_degree_851  1
    arc_0_4_17  original_T_including_depot_unload_885  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_508  1
    load_0_4_17  segment_load_conservation_815  1
    load_0_4_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_510  -20
    arc_0_4_18  connected_order_arc_511  -15
    arc_0_4_18  out_degree_811  1
    arc_0_4_18  in_degree_857  1
    arc_0_4_18  original_T_including_depot_unload_885  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_510  1
    load_0_4_18  segment_load_conservation_815  1
    load_0_4_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_512  -20
    arc_0_4_19  connected_order_arc_513  -15
    arc_0_4_19  out_degree_811  1
    arc_0_4_19  in_degree_863  1
    arc_0_4_19  original_T_including_depot_unload_885  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_512  1
    load_0_4_19  segment_load_conservation_815  1
    load_0_4_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_514  -20
    arc_0_4_20  connected_order_arc_515  -15
    arc_0_4_20  out_degree_811  1
    arc_0_4_20  in_degree_869  1
    arc_0_4_20  original_T_including_depot_unload_885  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_514  1
    load_0_4_20  segment_load_conservation_815  1
    load_0_4_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_516  -20
    arc_0_4_21  connected_order_arc_517  -15
    arc_0_4_21  out_degree_811  1
    arc_0_4_21  in_degree_875  1
    arc_0_4_21  original_T_including_depot_unload_885  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_516  1
    load_0_4_21  segment_load_conservation_815  1
    load_0_4_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_518  -20
    arc_0_5_0  depot_return_or_bypass_789  1
    arc_0_5_0  out_degree_818  1
    arc_0_5_0  original_T_including_depot_unload_885  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_518  1
    load_0_5_0  segment_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_519  -20
    arc_0_5_1  connected_order_arc_520  -15
    arc_0_5_1  in_degree_791  1
    arc_0_5_1  out_degree_818  1
    arc_0_5_1  original_T_including_depot_unload_885  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_519  1
    load_0_5_1  segment_load_conservation_794  -1
    load_0_5_1  segment_prefix_lb_795  1
    load_0_5_1  segment_prefix_ub_796  1
    load_0_5_1  segment_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_521  -20
    arc_0_5_2  connected_order_arc_522  -15
    arc_0_5_2  in_degree_798  1
    arc_0_5_2  out_degree_818  1
    arc_0_5_2  original_T_including_depot_unload_885  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_521  1
    load_0_5_2  segment_load_conservation_801  -1
    load_0_5_2  segment_prefix_lb_802  1
    load_0_5_2  segment_prefix_ub_803  1
    load_0_5_2  segment_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_523  -20
    arc_0_5_3  connected_order_arc_524  -15
    arc_0_5_3  in_degree_805  1
    arc_0_5_3  out_degree_818  1
    arc_0_5_3  original_T_including_depot_unload_885  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_523  1
    load_0_5_3  segment_load_conservation_808  -1
    load_0_5_3  segment_prefix_lb_809  1
    load_0_5_3  segment_prefix_ub_810  1
    load_0_5_3  segment_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_525  -20
    arc_0_5_4  connected_order_arc_526  -15
    arc_0_5_4  in_degree_812  1
    arc_0_5_4  out_degree_818  1
    arc_0_5_4  original_T_including_depot_unload_885  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_525  1
    load_0_5_4  segment_load_conservation_815  -1
    load_0_5_4  segment_prefix_lb_816  1
    load_0_5_4  segment_prefix_ub_817  1
    load_0_5_4  segment_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_527  -20
    arc_0_5_6  connected_order_arc_528  -15
    arc_0_5_6  out_degree_818  1
    arc_0_5_6  in_degree_826  1
    arc_0_5_6  original_T_including_depot_unload_885  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_527  1
    load_0_5_6  segment_load_conservation_822  1
    load_0_5_6  segment_load_conservation_829  -1
    load_0_5_6  segment_prefix_lb_830  1
    load_0_5_6  segment_prefix_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_529  -20
    arc_0_5_14  connected_order_arc_530  -15
    arc_0_5_14  out_degree_818  1
    arc_0_5_14  in_degree_833  1
    arc_0_5_14  original_T_including_depot_unload_885  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_529  1
    load_0_5_14  segment_load_conservation_822  1
    load_0_5_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_531  -20
    arc_0_5_15  connected_order_arc_532  -15
    arc_0_5_15  out_degree_818  1
    arc_0_5_15  in_degree_839  1
    arc_0_5_15  original_T_including_depot_unload_885  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_531  1
    load_0_5_15  segment_load_conservation_822  1
    load_0_5_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_533  -20
    arc_0_5_16  connected_order_arc_534  -15
    arc_0_5_16  out_degree_818  1
    arc_0_5_16  in_degree_845  1
    arc_0_5_16  original_T_including_depot_unload_885  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_533  1
    load_0_5_16  segment_load_conservation_822  1
    load_0_5_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_535  -20
    arc_0_5_17  connected_order_arc_536  -15
    arc_0_5_17  out_degree_818  1
    arc_0_5_17  in_degree_851  1
    arc_0_5_17  original_T_including_depot_unload_885  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_535  1
    load_0_5_17  segment_load_conservation_822  1
    load_0_5_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_537  -20
    arc_0_5_18  connected_order_arc_538  -15
    arc_0_5_18  out_degree_818  1
    arc_0_5_18  in_degree_857  1
    arc_0_5_18  original_T_including_depot_unload_885  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_537  1
    load_0_5_18  segment_load_conservation_822  1
    load_0_5_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_539  -20
    arc_0_5_19  connected_order_arc_540  -15
    arc_0_5_19  out_degree_818  1
    arc_0_5_19  in_degree_863  1
    arc_0_5_19  original_T_including_depot_unload_885  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_539  1
    load_0_5_19  segment_load_conservation_822  1
    load_0_5_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_541  -20
    arc_0_5_20  connected_order_arc_542  -15
    arc_0_5_20  out_degree_818  1
    arc_0_5_20  in_degree_869  1
    arc_0_5_20  original_T_including_depot_unload_885  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_541  1
    load_0_5_20  segment_load_conservation_822  1
    load_0_5_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_543  -20
    arc_0_5_21  connected_order_arc_544  -15
    arc_0_5_21  out_degree_818  1
    arc_0_5_21  in_degree_875  1
    arc_0_5_21  original_T_including_depot_unload_885  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_543  1
    load_0_5_21  segment_load_conservation_822  1
    load_0_5_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_545  -20
    arc_0_6_0  depot_return_or_bypass_789  1
    arc_0_6_0  out_degree_825  1
    arc_0_6_0  original_T_including_depot_unload_885  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_545  1
    load_0_6_0  segment_load_conservation_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_546  -20
    arc_0_6_1  connected_order_arc_547  -15
    arc_0_6_1  in_degree_791  1
    arc_0_6_1  out_degree_825  1
    arc_0_6_1  original_T_including_depot_unload_885  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_546  1
    load_0_6_1  segment_load_conservation_794  -1
    load_0_6_1  segment_prefix_lb_795  1
    load_0_6_1  segment_prefix_ub_796  1
    load_0_6_1  segment_load_conservation_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_548  -20
    arc_0_6_2  connected_order_arc_549  -15
    arc_0_6_2  in_degree_798  1
    arc_0_6_2  out_degree_825  1
    arc_0_6_2  original_T_including_depot_unload_885  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_548  1
    load_0_6_2  segment_load_conservation_801  -1
    load_0_6_2  segment_prefix_lb_802  1
    load_0_6_2  segment_prefix_ub_803  1
    load_0_6_2  segment_load_conservation_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_550  -20
    arc_0_6_3  connected_order_arc_551  -15
    arc_0_6_3  in_degree_805  1
    arc_0_6_3  out_degree_825  1
    arc_0_6_3  original_T_including_depot_unload_885  1.2450286067313011e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_550  1
    load_0_6_3  segment_load_conservation_808  -1
    load_0_6_3  segment_prefix_lb_809  1
    load_0_6_3  segment_prefix_ub_810  1
    load_0_6_3  segment_load_conservation_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_552  -20
    arc_0_6_4  connected_order_arc_553  -15
    arc_0_6_4  in_degree_812  1
    arc_0_6_4  out_degree_825  1
    arc_0_6_4  original_T_including_depot_unload_885  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_552  1
    load_0_6_4  segment_load_conservation_815  -1
    load_0_6_4  segment_prefix_lb_816  1
    load_0_6_4  segment_prefix_ub_817  1
    load_0_6_4  segment_load_conservation_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_554  -20
    arc_0_6_5  connected_order_arc_555  -15
    arc_0_6_5  in_degree_819  1
    arc_0_6_5  out_degree_825  1
    arc_0_6_5  original_T_including_depot_unload_885  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_554  1
    load_0_6_5  segment_load_conservation_822  -1
    load_0_6_5  segment_prefix_lb_823  1
    load_0_6_5  segment_prefix_ub_824  1
    load_0_6_5  segment_load_conservation_829  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_556  -20
    arc_0_6_14  connected_order_arc_557  -15
    arc_0_6_14  out_degree_825  1
    arc_0_6_14  in_degree_833  1
    arc_0_6_14  original_T_including_depot_unload_885  1.1301442107738828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_556  1
    load_0_6_14  segment_load_conservation_829  1
    load_0_6_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_558  -20
    arc_0_6_15  connected_order_arc_559  -15
    arc_0_6_15  out_degree_825  1
    arc_0_6_15  in_degree_839  1
    arc_0_6_15  original_T_including_depot_unload_885  1.1516424799836650e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_558  1
    load_0_6_15  segment_load_conservation_829  1
    load_0_6_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_560  -20
    arc_0_6_16  connected_order_arc_561  -15
    arc_0_6_16  out_degree_825  1
    arc_0_6_16  in_degree_845  1
    arc_0_6_16  original_T_including_depot_unload_885  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_560  1
    load_0_6_16  segment_load_conservation_829  1
    load_0_6_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_562  -20
    arc_0_6_17  connected_order_arc_563  -15
    arc_0_6_17  out_degree_825  1
    arc_0_6_17  in_degree_851  1
    arc_0_6_17  original_T_including_depot_unload_885  1035.83277530205
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_562  1
    load_0_6_17  segment_load_conservation_829  1
    load_0_6_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_564  -20
    arc_0_6_18  connected_order_arc_565  -15
    arc_0_6_18  out_degree_825  1
    arc_0_6_18  in_degree_857  1
    arc_0_6_18  original_T_including_depot_unload_885  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_564  1
    load_0_6_18  segment_load_conservation_829  1
    load_0_6_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_566  -20
    arc_0_6_19  connected_order_arc_567  -15
    arc_0_6_19  out_degree_825  1
    arc_0_6_19  in_degree_863  1
    arc_0_6_19  original_T_including_depot_unload_885  1.3663551195332984e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_566  1
    load_0_6_19  segment_load_conservation_829  1
    load_0_6_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_568  -20
    arc_0_6_20  connected_order_arc_569  -15
    arc_0_6_20  out_degree_825  1
    arc_0_6_20  in_degree_869  1
    arc_0_6_20  original_T_including_depot_unload_885  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_568  1
    load_0_6_20  segment_load_conservation_829  1
    load_0_6_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_570  -20
    arc_0_6_21  connected_order_arc_571  -15
    arc_0_6_21  out_degree_825  1
    arc_0_6_21  in_degree_875  1
    arc_0_6_21  original_T_including_depot_unload_885  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_570  1
    load_0_6_21  segment_load_conservation_829  1
    load_0_6_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_572  -20
    arc_0_14_0  depot_return_or_bypass_789  1
    arc_0_14_0  out_degree_832  1
    arc_0_14_0  original_T_including_depot_unload_885  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_572  1
    load_0_14_0  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_573  -20
    arc_0_14_1  connected_order_arc_574  -15
    arc_0_14_1  in_degree_791  1
    arc_0_14_1  out_degree_832  1
    arc_0_14_1  original_T_including_depot_unload_885  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_573  1
    load_0_14_1  segment_load_conservation_794  -1
    load_0_14_1  segment_prefix_lb_795  1
    load_0_14_1  segment_prefix_ub_796  1
    load_0_14_1  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_575  -20
    arc_0_14_2  connected_order_arc_576  -15
    arc_0_14_2  in_degree_798  1
    arc_0_14_2  out_degree_832  1
    arc_0_14_2  original_T_including_depot_unload_885  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_575  1
    load_0_14_2  segment_load_conservation_801  -1
    load_0_14_2  segment_prefix_lb_802  1
    load_0_14_2  segment_prefix_ub_803  1
    load_0_14_2  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_577  -20
    arc_0_14_3  connected_order_arc_578  -15
    arc_0_14_3  in_degree_805  1
    arc_0_14_3  out_degree_832  1
    arc_0_14_3  original_T_including_depot_unload_885  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_577  1
    load_0_14_3  segment_load_conservation_808  -1
    load_0_14_3  segment_prefix_lb_809  1
    load_0_14_3  segment_prefix_ub_810  1
    load_0_14_3  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_579  -20
    arc_0_14_4  connected_order_arc_580  -15
    arc_0_14_4  in_degree_812  1
    arc_0_14_4  out_degree_832  1
    arc_0_14_4  original_T_including_depot_unload_885  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_579  1
    load_0_14_4  segment_load_conservation_815  -1
    load_0_14_4  segment_prefix_lb_816  1
    load_0_14_4  segment_prefix_ub_817  1
    load_0_14_4  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_581  -20
    arc_0_14_5  connected_order_arc_582  -15
    arc_0_14_5  in_degree_819  1
    arc_0_14_5  out_degree_832  1
    arc_0_14_5  original_T_including_depot_unload_885  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_581  1
    load_0_14_5  segment_load_conservation_822  -1
    load_0_14_5  segment_prefix_lb_823  1
    load_0_14_5  segment_prefix_ub_824  1
    load_0_14_5  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_583  -20
    arc_0_14_6  connected_order_arc_584  -15
    arc_0_14_6  in_degree_826  1
    arc_0_14_6  out_degree_832  1
    arc_0_14_6  original_T_including_depot_unload_885  6.6347574074434863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_583  1
    load_0_14_6  segment_load_conservation_829  -1
    load_0_14_6  segment_prefix_lb_830  1
    load_0_14_6  segment_prefix_ub_831  1
    load_0_14_6  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_585  -20
    arc_0_14_15  connected_order_arc_586  -15
    arc_0_14_15  out_degree_832  1
    arc_0_14_15  in_degree_839  1
    arc_0_14_15  original_T_including_depot_unload_885  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_585  1
    load_0_14_15  free_load_conservation_837  1
    load_0_14_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_587  -20
    arc_0_14_16  connected_order_arc_588  -15
    arc_0_14_16  out_degree_832  1
    arc_0_14_16  in_degree_845  1
    arc_0_14_16  original_T_including_depot_unload_885  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_587  1
    load_0_14_16  free_load_conservation_837  1
    load_0_14_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_589  -20
    arc_0_14_17  connected_order_arc_590  -15
    arc_0_14_17  out_degree_832  1
    arc_0_14_17  in_degree_851  1
    arc_0_14_17  original_T_including_depot_unload_885  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_589  1
    load_0_14_17  free_load_conservation_837  1
    load_0_14_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_591  -20
    arc_0_14_18  connected_order_arc_592  -15
    arc_0_14_18  out_degree_832  1
    arc_0_14_18  in_degree_857  1
    arc_0_14_18  original_T_including_depot_unload_885  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_591  1
    load_0_14_18  free_load_conservation_837  1
    load_0_14_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_593  -20
    arc_0_14_19  connected_order_arc_594  -15
    arc_0_14_19  out_degree_832  1
    arc_0_14_19  in_degree_863  1
    arc_0_14_19  original_T_including_depot_unload_885  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_593  1
    load_0_14_19  free_load_conservation_837  1
    load_0_14_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_595  -20
    arc_0_14_20  connected_order_arc_596  -15
    arc_0_14_20  out_degree_832  1
    arc_0_14_20  in_degree_869  1
    arc_0_14_20  original_T_including_depot_unload_885  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_595  1
    load_0_14_20  free_load_conservation_837  1
    load_0_14_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_597  -20
    arc_0_14_21  connected_order_arc_598  -15
    arc_0_14_21  out_degree_832  1
    arc_0_14_21  in_degree_875  1
    arc_0_14_21  original_T_including_depot_unload_885  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_597  1
    load_0_14_21  free_load_conservation_837  1
    load_0_14_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_599  -20
    arc_0_15_0  depot_return_or_bypass_789  1
    arc_0_15_0  out_degree_838  1
    arc_0_15_0  original_T_including_depot_unload_885  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_599  1
    load_0_15_0  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_600  -20
    arc_0_15_1  connected_order_arc_601  -15
    arc_0_15_1  in_degree_791  1
    arc_0_15_1  out_degree_838  1
    arc_0_15_1  original_T_including_depot_unload_885  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_600  1
    load_0_15_1  segment_load_conservation_794  -1
    load_0_15_1  segment_prefix_lb_795  1
    load_0_15_1  segment_prefix_ub_796  1
    load_0_15_1  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_602  -20
    arc_0_15_2  connected_order_arc_603  -15
    arc_0_15_2  in_degree_798  1
    arc_0_15_2  out_degree_838  1
    arc_0_15_2  original_T_including_depot_unload_885  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_602  1
    load_0_15_2  segment_load_conservation_801  -1
    load_0_15_2  segment_prefix_lb_802  1
    load_0_15_2  segment_prefix_ub_803  1
    load_0_15_2  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_604  -20
    arc_0_15_3  connected_order_arc_605  -15
    arc_0_15_3  in_degree_805  1
    arc_0_15_3  out_degree_838  1
    arc_0_15_3  original_T_including_depot_unload_885  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_604  1
    load_0_15_3  segment_load_conservation_808  -1
    load_0_15_3  segment_prefix_lb_809  1
    load_0_15_3  segment_prefix_ub_810  1
    load_0_15_3  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_606  -20
    arc_0_15_4  connected_order_arc_607  -15
    arc_0_15_4  in_degree_812  1
    arc_0_15_4  out_degree_838  1
    arc_0_15_4  original_T_including_depot_unload_885  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_606  1
    load_0_15_4  segment_load_conservation_815  -1
    load_0_15_4  segment_prefix_lb_816  1
    load_0_15_4  segment_prefix_ub_817  1
    load_0_15_4  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_608  -20
    arc_0_15_5  connected_order_arc_609  -15
    arc_0_15_5  in_degree_819  1
    arc_0_15_5  out_degree_838  1
    arc_0_15_5  original_T_including_depot_unload_885  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_608  1
    load_0_15_5  segment_load_conservation_822  -1
    load_0_15_5  segment_prefix_lb_823  1
    load_0_15_5  segment_prefix_ub_824  1
    load_0_15_5  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_610  -20
    arc_0_15_6  connected_order_arc_611  -15
    arc_0_15_6  in_degree_826  1
    arc_0_15_6  out_degree_838  1
    arc_0_15_6  original_T_including_depot_unload_885  7.0663858580683063e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_610  1
    load_0_15_6  segment_load_conservation_829  -1
    load_0_15_6  segment_prefix_lb_830  1
    load_0_15_6  segment_prefix_ub_831  1
    load_0_15_6  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_612  -20
    arc_0_15_14  connected_order_arc_613  -15
    arc_0_15_14  in_degree_833  1
    arc_0_15_14  out_degree_838  1
    arc_0_15_14  original_T_including_depot_unload_885  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_612  1
    load_0_15_14  free_load_conservation_837  -1
    load_0_15_14  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_614  -20
    arc_0_15_16  connected_order_arc_615  -15
    arc_0_15_16  out_degree_838  1
    arc_0_15_16  in_degree_845  1
    arc_0_15_16  original_T_including_depot_unload_885  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_614  1
    load_0_15_16  free_load_conservation_843  1
    load_0_15_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_616  -20
    arc_0_15_17  connected_order_arc_617  -15
    arc_0_15_17  out_degree_838  1
    arc_0_15_17  in_degree_851  1
    arc_0_15_17  original_T_including_depot_unload_885  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_616  1
    load_0_15_17  free_load_conservation_843  1
    load_0_15_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_618  -20
    arc_0_15_18  connected_order_arc_619  -15
    arc_0_15_18  out_degree_838  1
    arc_0_15_18  in_degree_857  1
    arc_0_15_18  original_T_including_depot_unload_885  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_618  1
    load_0_15_18  free_load_conservation_843  1
    load_0_15_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_620  -20
    arc_0_15_19  connected_order_arc_621  -15
    arc_0_15_19  out_degree_838  1
    arc_0_15_19  in_degree_863  1
    arc_0_15_19  original_T_including_depot_unload_885  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_620  1
    load_0_15_19  free_load_conservation_843  1
    load_0_15_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_622  -20
    arc_0_15_20  connected_order_arc_623  -15
    arc_0_15_20  out_degree_838  1
    arc_0_15_20  in_degree_869  1
    arc_0_15_20  original_T_including_depot_unload_885  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_622  1
    load_0_15_20  free_load_conservation_843  1
    load_0_15_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_624  -20
    arc_0_15_21  connected_order_arc_625  -15
    arc_0_15_21  out_degree_838  1
    arc_0_15_21  in_degree_875  1
    arc_0_15_21  original_T_including_depot_unload_885  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_624  1
    load_0_15_21  free_load_conservation_843  1
    load_0_15_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_626  -20
    arc_0_16_0  depot_return_or_bypass_789  1
    arc_0_16_0  out_degree_844  1
    arc_0_16_0  original_T_including_depot_unload_885  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_626  1
    load_0_16_0  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_627  -20
    arc_0_16_1  connected_order_arc_628  -15
    arc_0_16_1  in_degree_791  1
    arc_0_16_1  out_degree_844  1
    arc_0_16_1  original_T_including_depot_unload_885  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_627  1
    load_0_16_1  segment_load_conservation_794  -1
    load_0_16_1  segment_prefix_lb_795  1
    load_0_16_1  segment_prefix_ub_796  1
    load_0_16_1  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_629  -20
    arc_0_16_2  connected_order_arc_630  -15
    arc_0_16_2  in_degree_798  1
    arc_0_16_2  out_degree_844  1
    arc_0_16_2  original_T_including_depot_unload_885  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_629  1
    load_0_16_2  segment_load_conservation_801  -1
    load_0_16_2  segment_prefix_lb_802  1
    load_0_16_2  segment_prefix_ub_803  1
    load_0_16_2  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_631  -20
    arc_0_16_3  connected_order_arc_632  -15
    arc_0_16_3  in_degree_805  1
    arc_0_16_3  out_degree_844  1
    arc_0_16_3  original_T_including_depot_unload_885  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_631  1
    load_0_16_3  segment_load_conservation_808  -1
    load_0_16_3  segment_prefix_lb_809  1
    load_0_16_3  segment_prefix_ub_810  1
    load_0_16_3  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_633  -20
    arc_0_16_4  connected_order_arc_634  -15
    arc_0_16_4  in_degree_812  1
    arc_0_16_4  out_degree_844  1
    arc_0_16_4  original_T_including_depot_unload_885  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_633  1
    load_0_16_4  segment_load_conservation_815  -1
    load_0_16_4  segment_prefix_lb_816  1
    load_0_16_4  segment_prefix_ub_817  1
    load_0_16_4  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_635  -20
    arc_0_16_5  connected_order_arc_636  -15
    arc_0_16_5  in_degree_819  1
    arc_0_16_5  out_degree_844  1
    arc_0_16_5  original_T_including_depot_unload_885  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_635  1
    load_0_16_5  segment_load_conservation_822  -1
    load_0_16_5  segment_prefix_lb_823  1
    load_0_16_5  segment_prefix_ub_824  1
    load_0_16_5  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_637  -20
    arc_0_16_6  connected_order_arc_638  -15
    arc_0_16_6  in_degree_826  1
    arc_0_16_6  out_degree_844  1
    arc_0_16_6  original_T_including_depot_unload_885  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_637  1
    load_0_16_6  segment_load_conservation_829  -1
    load_0_16_6  segment_prefix_lb_830  1
    load_0_16_6  segment_prefix_ub_831  1
    load_0_16_6  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_639  -20
    arc_0_16_14  connected_order_arc_640  -15
    arc_0_16_14  in_degree_833  1
    arc_0_16_14  out_degree_844  1
    arc_0_16_14  original_T_including_depot_unload_885  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_639  1
    load_0_16_14  free_load_conservation_837  -1
    load_0_16_14  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_641  -20
    arc_0_16_15  connected_order_arc_642  -15
    arc_0_16_15  in_degree_839  1
    arc_0_16_15  out_degree_844  1
    arc_0_16_15  original_T_including_depot_unload_885  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_641  1
    load_0_16_15  free_load_conservation_843  -1
    load_0_16_15  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_643  -20
    arc_0_16_17  connected_order_arc_644  -15
    arc_0_16_17  out_degree_844  1
    arc_0_16_17  in_degree_851  1
    arc_0_16_17  original_T_including_depot_unload_885  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_643  1
    load_0_16_17  free_load_conservation_849  1
    load_0_16_17  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_645  -20
    arc_0_16_18  connected_order_arc_646  -15
    arc_0_16_18  out_degree_844  1
    arc_0_16_18  in_degree_857  1
    arc_0_16_18  original_T_including_depot_unload_885  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_645  1
    load_0_16_18  free_load_conservation_849  1
    load_0_16_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_647  -20
    arc_0_16_19  connected_order_arc_648  -15
    arc_0_16_19  out_degree_844  1
    arc_0_16_19  in_degree_863  1
    arc_0_16_19  original_T_including_depot_unload_885  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_647  1
    load_0_16_19  free_load_conservation_849  1
    load_0_16_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_649  -20
    arc_0_16_20  connected_order_arc_650  -15
    arc_0_16_20  out_degree_844  1
    arc_0_16_20  in_degree_869  1
    arc_0_16_20  original_T_including_depot_unload_885  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_649  1
    load_0_16_20  free_load_conservation_849  1
    load_0_16_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_651  -20
    arc_0_16_21  connected_order_arc_652  -15
    arc_0_16_21  out_degree_844  1
    arc_0_16_21  in_degree_875  1
    arc_0_16_21  original_T_including_depot_unload_885  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_651  1
    load_0_16_21  free_load_conservation_849  1
    load_0_16_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_653  -20
    arc_0_17_0  depot_return_or_bypass_789  1
    arc_0_17_0  out_degree_850  1
    arc_0_17_0  original_T_including_depot_unload_885  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_653  1
    load_0_17_0  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_654  -20
    arc_0_17_1  connected_order_arc_655  -15
    arc_0_17_1  in_degree_791  1
    arc_0_17_1  out_degree_850  1
    arc_0_17_1  original_T_including_depot_unload_885  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_654  1
    load_0_17_1  segment_load_conservation_794  -1
    load_0_17_1  segment_prefix_lb_795  1
    load_0_17_1  segment_prefix_ub_796  1
    load_0_17_1  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_656  -20
    arc_0_17_2  connected_order_arc_657  -15
    arc_0_17_2  in_degree_798  1
    arc_0_17_2  out_degree_850  1
    arc_0_17_2  original_T_including_depot_unload_885  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_656  1
    load_0_17_2  segment_load_conservation_801  -1
    load_0_17_2  segment_prefix_lb_802  1
    load_0_17_2  segment_prefix_ub_803  1
    load_0_17_2  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_658  -20
    arc_0_17_3  connected_order_arc_659  -15
    arc_0_17_3  in_degree_805  1
    arc_0_17_3  out_degree_850  1
    arc_0_17_3  original_T_including_depot_unload_885  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_658  1
    load_0_17_3  segment_load_conservation_808  -1
    load_0_17_3  segment_prefix_lb_809  1
    load_0_17_3  segment_prefix_ub_810  1
    load_0_17_3  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_660  -20
    arc_0_17_4  connected_order_arc_661  -15
    arc_0_17_4  in_degree_812  1
    arc_0_17_4  out_degree_850  1
    arc_0_17_4  original_T_including_depot_unload_885  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_660  1
    load_0_17_4  segment_load_conservation_815  -1
    load_0_17_4  segment_prefix_lb_816  1
    load_0_17_4  segment_prefix_ub_817  1
    load_0_17_4  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_662  -20
    arc_0_17_5  connected_order_arc_663  -15
    arc_0_17_5  in_degree_819  1
    arc_0_17_5  out_degree_850  1
    arc_0_17_5  original_T_including_depot_unload_885  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_662  1
    load_0_17_5  segment_load_conservation_822  -1
    load_0_17_5  segment_prefix_lb_823  1
    load_0_17_5  segment_prefix_ub_824  1
    load_0_17_5  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_664  -20
    arc_0_17_6  connected_order_arc_665  -15
    arc_0_17_6  in_degree_826  1
    arc_0_17_6  out_degree_850  1
    arc_0_17_6  original_T_including_depot_unload_885  5.5115772567966917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_664  1
    load_0_17_6  segment_load_conservation_829  -1
    load_0_17_6  segment_prefix_lb_830  1
    load_0_17_6  segment_prefix_ub_831  1
    load_0_17_6  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_666  -20
    arc_0_17_14  connected_order_arc_667  -15
    arc_0_17_14  in_degree_833  1
    arc_0_17_14  out_degree_850  1
    arc_0_17_14  original_T_including_depot_unload_885  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_666  1
    load_0_17_14  free_load_conservation_837  -1
    load_0_17_14  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_668  -20
    arc_0_17_15  connected_order_arc_669  -15
    arc_0_17_15  in_degree_839  1
    arc_0_17_15  out_degree_850  1
    arc_0_17_15  original_T_including_depot_unload_885  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_668  1
    load_0_17_15  free_load_conservation_843  -1
    load_0_17_15  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_670  -20
    arc_0_17_16  connected_order_arc_671  -15
    arc_0_17_16  in_degree_845  1
    arc_0_17_16  out_degree_850  1
    arc_0_17_16  original_T_including_depot_unload_885  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_670  1
    load_0_17_16  free_load_conservation_849  -1
    load_0_17_16  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_672  -20
    arc_0_17_18  connected_order_arc_673  -15
    arc_0_17_18  out_degree_850  1
    arc_0_17_18  in_degree_857  1
    arc_0_17_18  original_T_including_depot_unload_885  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_672  1
    load_0_17_18  free_load_conservation_855  1
    load_0_17_18  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_674  -20
    arc_0_17_19  connected_order_arc_675  -15
    arc_0_17_19  out_degree_850  1
    arc_0_17_19  in_degree_863  1
    arc_0_17_19  original_T_including_depot_unload_885  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_674  1
    load_0_17_19  free_load_conservation_855  1
    load_0_17_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_676  -20
    arc_0_17_20  connected_order_arc_677  -15
    arc_0_17_20  out_degree_850  1
    arc_0_17_20  in_degree_869  1
    arc_0_17_20  original_T_including_depot_unload_885  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_676  1
    load_0_17_20  free_load_conservation_855  1
    load_0_17_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_678  -20
    arc_0_17_21  connected_order_arc_679  -15
    arc_0_17_21  out_degree_850  1
    arc_0_17_21  in_degree_875  1
    arc_0_17_21  original_T_including_depot_unload_885  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_678  1
    load_0_17_21  free_load_conservation_855  1
    load_0_17_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_680  -20
    arc_0_18_0  depot_return_or_bypass_789  1
    arc_0_18_0  out_degree_856  1
    arc_0_18_0  original_T_including_depot_unload_885  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_680  1
    load_0_18_0  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_681  -20
    arc_0_18_1  connected_order_arc_682  -15
    arc_0_18_1  in_degree_791  1
    arc_0_18_1  out_degree_856  1
    arc_0_18_1  original_T_including_depot_unload_885  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_681  1
    load_0_18_1  segment_load_conservation_794  -1
    load_0_18_1  segment_prefix_lb_795  1
    load_0_18_1  segment_prefix_ub_796  1
    load_0_18_1  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_683  -20
    arc_0_18_2  connected_order_arc_684  -15
    arc_0_18_2  in_degree_798  1
    arc_0_18_2  out_degree_856  1
    arc_0_18_2  original_T_including_depot_unload_885  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_683  1
    load_0_18_2  segment_load_conservation_801  -1
    load_0_18_2  segment_prefix_lb_802  1
    load_0_18_2  segment_prefix_ub_803  1
    load_0_18_2  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_685  -20
    arc_0_18_3  connected_order_arc_686  -15
    arc_0_18_3  in_degree_805  1
    arc_0_18_3  out_degree_856  1
    arc_0_18_3  original_T_including_depot_unload_885  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_685  1
    load_0_18_3  segment_load_conservation_808  -1
    load_0_18_3  segment_prefix_lb_809  1
    load_0_18_3  segment_prefix_ub_810  1
    load_0_18_3  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_687  -20
    arc_0_18_4  connected_order_arc_688  -15
    arc_0_18_4  in_degree_812  1
    arc_0_18_4  out_degree_856  1
    arc_0_18_4  original_T_including_depot_unload_885  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_687  1
    load_0_18_4  segment_load_conservation_815  -1
    load_0_18_4  segment_prefix_lb_816  1
    load_0_18_4  segment_prefix_ub_817  1
    load_0_18_4  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_689  -20
    arc_0_18_5  connected_order_arc_690  -15
    arc_0_18_5  in_degree_819  1
    arc_0_18_5  out_degree_856  1
    arc_0_18_5  original_T_including_depot_unload_885  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_689  1
    load_0_18_5  segment_load_conservation_822  -1
    load_0_18_5  segment_prefix_lb_823  1
    load_0_18_5  segment_prefix_ub_824  1
    load_0_18_5  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_691  -20
    arc_0_18_6  connected_order_arc_692  -15
    arc_0_18_6  in_degree_826  1
    arc_0_18_6  out_degree_856  1
    arc_0_18_6  original_T_including_depot_unload_885  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_691  1
    load_0_18_6  segment_load_conservation_829  -1
    load_0_18_6  segment_prefix_lb_830  1
    load_0_18_6  segment_prefix_ub_831  1
    load_0_18_6  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_693  -20
    arc_0_18_14  connected_order_arc_694  -15
    arc_0_18_14  in_degree_833  1
    arc_0_18_14  out_degree_856  1
    arc_0_18_14  original_T_including_depot_unload_885  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_693  1
    load_0_18_14  free_load_conservation_837  -1
    load_0_18_14  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_695  -20
    arc_0_18_15  connected_order_arc_696  -15
    arc_0_18_15  in_degree_839  1
    arc_0_18_15  out_degree_856  1
    arc_0_18_15  original_T_including_depot_unload_885  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_695  1
    load_0_18_15  free_load_conservation_843  -1
    load_0_18_15  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_697  -20
    arc_0_18_16  connected_order_arc_698  -15
    arc_0_18_16  in_degree_845  1
    arc_0_18_16  out_degree_856  1
    arc_0_18_16  original_T_including_depot_unload_885  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_697  1
    load_0_18_16  free_load_conservation_849  -1
    load_0_18_16  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_699  -20
    arc_0_18_17  connected_order_arc_700  -15
    arc_0_18_17  in_degree_851  1
    arc_0_18_17  out_degree_856  1
    arc_0_18_17  original_T_including_depot_unload_885  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_699  1
    load_0_18_17  free_load_conservation_855  -1
    load_0_18_17  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_701  -20
    arc_0_18_19  connected_order_arc_702  -15
    arc_0_18_19  out_degree_856  1
    arc_0_18_19  in_degree_863  1
    arc_0_18_19  original_T_including_depot_unload_885  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_701  1
    load_0_18_19  free_load_conservation_861  1
    load_0_18_19  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_703  -20
    arc_0_18_20  connected_order_arc_704  -15
    arc_0_18_20  out_degree_856  1
    arc_0_18_20  in_degree_869  1
    arc_0_18_20  original_T_including_depot_unload_885  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_703  1
    load_0_18_20  free_load_conservation_861  1
    load_0_18_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_705  -20
    arc_0_18_21  connected_order_arc_706  -15
    arc_0_18_21  out_degree_856  1
    arc_0_18_21  in_degree_875  1
    arc_0_18_21  original_T_including_depot_unload_885  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_705  1
    load_0_18_21  free_load_conservation_861  1
    load_0_18_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_707  -20
    arc_0_19_0  depot_return_or_bypass_789  1
    arc_0_19_0  out_degree_862  1
    arc_0_19_0  original_T_including_depot_unload_885  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_707  1
    load_0_19_0  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_708  -20
    arc_0_19_1  connected_order_arc_709  -15
    arc_0_19_1  in_degree_791  1
    arc_0_19_1  out_degree_862  1
    arc_0_19_1  original_T_including_depot_unload_885  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_708  1
    load_0_19_1  segment_load_conservation_794  -1
    load_0_19_1  segment_prefix_lb_795  1
    load_0_19_1  segment_prefix_ub_796  1
    load_0_19_1  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_710  -20
    arc_0_19_2  connected_order_arc_711  -15
    arc_0_19_2  in_degree_798  1
    arc_0_19_2  out_degree_862  1
    arc_0_19_2  original_T_including_depot_unload_885  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_710  1
    load_0_19_2  segment_load_conservation_801  -1
    load_0_19_2  segment_prefix_lb_802  1
    load_0_19_2  segment_prefix_ub_803  1
    load_0_19_2  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_712  -20
    arc_0_19_3  connected_order_arc_713  -15
    arc_0_19_3  in_degree_805  1
    arc_0_19_3  out_degree_862  1
    arc_0_19_3  original_T_including_depot_unload_885  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_712  1
    load_0_19_3  segment_load_conservation_808  -1
    load_0_19_3  segment_prefix_lb_809  1
    load_0_19_3  segment_prefix_ub_810  1
    load_0_19_3  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_714  -20
    arc_0_19_4  connected_order_arc_715  -15
    arc_0_19_4  in_degree_812  1
    arc_0_19_4  out_degree_862  1
    arc_0_19_4  original_T_including_depot_unload_885  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_714  1
    load_0_19_4  segment_load_conservation_815  -1
    load_0_19_4  segment_prefix_lb_816  1
    load_0_19_4  segment_prefix_ub_817  1
    load_0_19_4  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_716  -20
    arc_0_19_5  connected_order_arc_717  -15
    arc_0_19_5  in_degree_819  1
    arc_0_19_5  out_degree_862  1
    arc_0_19_5  original_T_including_depot_unload_885  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_716  1
    load_0_19_5  segment_load_conservation_822  -1
    load_0_19_5  segment_prefix_lb_823  1
    load_0_19_5  segment_prefix_ub_824  1
    load_0_19_5  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_718  -20
    arc_0_19_6  connected_order_arc_719  -15
    arc_0_19_6  in_degree_826  1
    arc_0_19_6  out_degree_862  1
    arc_0_19_6  original_T_including_depot_unload_885  8.8827217910440470e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_718  1
    load_0_19_6  segment_load_conservation_829  -1
    load_0_19_6  segment_prefix_lb_830  1
    load_0_19_6  segment_prefix_ub_831  1
    load_0_19_6  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_720  -20
    arc_0_19_14  connected_order_arc_721  -15
    arc_0_19_14  in_degree_833  1
    arc_0_19_14  out_degree_862  1
    arc_0_19_14  original_T_including_depot_unload_885  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_720  1
    load_0_19_14  free_load_conservation_837  -1
    load_0_19_14  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_722  -20
    arc_0_19_15  connected_order_arc_723  -15
    arc_0_19_15  in_degree_839  1
    arc_0_19_15  out_degree_862  1
    arc_0_19_15  original_T_including_depot_unload_885  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_722  1
    load_0_19_15  free_load_conservation_843  -1
    load_0_19_15  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_724  -20
    arc_0_19_16  connected_order_arc_725  -15
    arc_0_19_16  in_degree_845  1
    arc_0_19_16  out_degree_862  1
    arc_0_19_16  original_T_including_depot_unload_885  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_724  1
    load_0_19_16  free_load_conservation_849  -1
    load_0_19_16  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_726  -20
    arc_0_19_17  connected_order_arc_727  -15
    arc_0_19_17  in_degree_851  1
    arc_0_19_17  out_degree_862  1
    arc_0_19_17  original_T_including_depot_unload_885  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_726  1
    load_0_19_17  free_load_conservation_855  -1
    load_0_19_17  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_728  -20
    arc_0_19_18  connected_order_arc_729  -15
    arc_0_19_18  in_degree_857  1
    arc_0_19_18  out_degree_862  1
    arc_0_19_18  original_T_including_depot_unload_885  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_728  1
    load_0_19_18  free_load_conservation_861  -1
    load_0_19_18  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_730  -20
    arc_0_19_20  connected_order_arc_731  -15
    arc_0_19_20  out_degree_862  1
    arc_0_19_20  in_degree_869  1
    arc_0_19_20  original_T_including_depot_unload_885  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_730  1
    load_0_19_20  free_load_conservation_867  1
    load_0_19_20  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_732  -20
    arc_0_19_21  connected_order_arc_733  -15
    arc_0_19_21  out_degree_862  1
    arc_0_19_21  in_degree_875  1
    arc_0_19_21  original_T_including_depot_unload_885  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_732  1
    load_0_19_21  free_load_conservation_867  1
    load_0_19_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_734  -20
    arc_0_20_0  depot_return_or_bypass_789  1
    arc_0_20_0  out_degree_868  1
    arc_0_20_0  original_T_including_depot_unload_885  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_734  1
    load_0_20_0  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_735  -20
    arc_0_20_1  connected_order_arc_736  -15
    arc_0_20_1  in_degree_791  1
    arc_0_20_1  out_degree_868  1
    arc_0_20_1  original_T_including_depot_unload_885  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_735  1
    load_0_20_1  segment_load_conservation_794  -1
    load_0_20_1  segment_prefix_lb_795  1
    load_0_20_1  segment_prefix_ub_796  1
    load_0_20_1  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_737  -20
    arc_0_20_2  connected_order_arc_738  -15
    arc_0_20_2  in_degree_798  1
    arc_0_20_2  out_degree_868  1
    arc_0_20_2  original_T_including_depot_unload_885  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_737  1
    load_0_20_2  segment_load_conservation_801  -1
    load_0_20_2  segment_prefix_lb_802  1
    load_0_20_2  segment_prefix_ub_803  1
    load_0_20_2  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_739  -20
    arc_0_20_3  connected_order_arc_740  -15
    arc_0_20_3  in_degree_805  1
    arc_0_20_3  out_degree_868  1
    arc_0_20_3  original_T_including_depot_unload_885  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_739  1
    load_0_20_3  segment_load_conservation_808  -1
    load_0_20_3  segment_prefix_lb_809  1
    load_0_20_3  segment_prefix_ub_810  1
    load_0_20_3  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_741  -20
    arc_0_20_4  connected_order_arc_742  -15
    arc_0_20_4  in_degree_812  1
    arc_0_20_4  out_degree_868  1
    arc_0_20_4  original_T_including_depot_unload_885  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_741  1
    load_0_20_4  segment_load_conservation_815  -1
    load_0_20_4  segment_prefix_lb_816  1
    load_0_20_4  segment_prefix_ub_817  1
    load_0_20_4  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_743  -20
    arc_0_20_5  connected_order_arc_744  -15
    arc_0_20_5  in_degree_819  1
    arc_0_20_5  out_degree_868  1
    arc_0_20_5  original_T_including_depot_unload_885  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_743  1
    load_0_20_5  segment_load_conservation_822  -1
    load_0_20_5  segment_prefix_lb_823  1
    load_0_20_5  segment_prefix_ub_824  1
    load_0_20_5  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_745  -20
    arc_0_20_6  connected_order_arc_746  -15
    arc_0_20_6  in_degree_826  1
    arc_0_20_6  out_degree_868  1
    arc_0_20_6  original_T_including_depot_unload_885  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_745  1
    load_0_20_6  segment_load_conservation_829  -1
    load_0_20_6  segment_prefix_lb_830  1
    load_0_20_6  segment_prefix_ub_831  1
    load_0_20_6  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_747  -20
    arc_0_20_14  connected_order_arc_748  -15
    arc_0_20_14  in_degree_833  1
    arc_0_20_14  out_degree_868  1
    arc_0_20_14  original_T_including_depot_unload_885  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_747  1
    load_0_20_14  free_load_conservation_837  -1
    load_0_20_14  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_749  -20
    arc_0_20_15  connected_order_arc_750  -15
    arc_0_20_15  in_degree_839  1
    arc_0_20_15  out_degree_868  1
    arc_0_20_15  original_T_including_depot_unload_885  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_749  1
    load_0_20_15  free_load_conservation_843  -1
    load_0_20_15  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_751  -20
    arc_0_20_16  connected_order_arc_752  -15
    arc_0_20_16  in_degree_845  1
    arc_0_20_16  out_degree_868  1
    arc_0_20_16  original_T_including_depot_unload_885  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_751  1
    load_0_20_16  free_load_conservation_849  -1
    load_0_20_16  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_753  -20
    arc_0_20_17  connected_order_arc_754  -15
    arc_0_20_17  in_degree_851  1
    arc_0_20_17  out_degree_868  1
    arc_0_20_17  original_T_including_depot_unload_885  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_753  1
    load_0_20_17  free_load_conservation_855  -1
    load_0_20_17  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_755  -20
    arc_0_20_18  connected_order_arc_756  -15
    arc_0_20_18  in_degree_857  1
    arc_0_20_18  out_degree_868  1
    arc_0_20_18  original_T_including_depot_unload_885  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_755  1
    load_0_20_18  free_load_conservation_861  -1
    load_0_20_18  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_757  -20
    arc_0_20_19  connected_order_arc_758  -15
    arc_0_20_19  in_degree_863  1
    arc_0_20_19  out_degree_868  1
    arc_0_20_19  original_T_including_depot_unload_885  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_757  1
    load_0_20_19  free_load_conservation_867  -1
    load_0_20_19  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_759  -20
    arc_0_20_21  connected_order_arc_760  -15
    arc_0_20_21  out_degree_868  1
    arc_0_20_21  in_degree_875  1
    arc_0_20_21  original_T_including_depot_unload_885  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_759  1
    load_0_20_21  free_load_conservation_873  1
    load_0_20_21  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_761  -20
    arc_0_21_0  depot_return_or_bypass_789  1
    arc_0_21_0  out_degree_874  1
    arc_0_21_0  original_T_including_depot_unload_885  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_761  1
    load_0_21_0  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_762  -20
    arc_0_21_1  connected_order_arc_763  -15
    arc_0_21_1  in_degree_791  1
    arc_0_21_1  out_degree_874  1
    arc_0_21_1  original_T_including_depot_unload_885  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_762  1
    load_0_21_1  segment_load_conservation_794  -1
    load_0_21_1  segment_prefix_lb_795  1
    load_0_21_1  segment_prefix_ub_796  1
    load_0_21_1  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_764  -20
    arc_0_21_2  connected_order_arc_765  -15
    arc_0_21_2  in_degree_798  1
    arc_0_21_2  out_degree_874  1
    arc_0_21_2  original_T_including_depot_unload_885  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_764  1
    load_0_21_2  segment_load_conservation_801  -1
    load_0_21_2  segment_prefix_lb_802  1
    load_0_21_2  segment_prefix_ub_803  1
    load_0_21_2  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_766  -20
    arc_0_21_3  connected_order_arc_767  -15
    arc_0_21_3  in_degree_805  1
    arc_0_21_3  out_degree_874  1
    arc_0_21_3  original_T_including_depot_unload_885  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_766  1
    load_0_21_3  segment_load_conservation_808  -1
    load_0_21_3  segment_prefix_lb_809  1
    load_0_21_3  segment_prefix_ub_810  1
    load_0_21_3  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_768  -20
    arc_0_21_4  connected_order_arc_769  -15
    arc_0_21_4  in_degree_812  1
    arc_0_21_4  out_degree_874  1
    arc_0_21_4  original_T_including_depot_unload_885  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_768  1
    load_0_21_4  segment_load_conservation_815  -1
    load_0_21_4  segment_prefix_lb_816  1
    load_0_21_4  segment_prefix_ub_817  1
    load_0_21_4  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_770  -20
    arc_0_21_5  connected_order_arc_771  -15
    arc_0_21_5  in_degree_819  1
    arc_0_21_5  out_degree_874  1
    arc_0_21_5  original_T_including_depot_unload_885  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_770  1
    load_0_21_5  segment_load_conservation_822  -1
    load_0_21_5  segment_prefix_lb_823  1
    load_0_21_5  segment_prefix_ub_824  1
    load_0_21_5  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_772  -20
    arc_0_21_6  connected_order_arc_773  -15
    arc_0_21_6  in_degree_826  1
    arc_0_21_6  out_degree_874  1
    arc_0_21_6  original_T_including_depot_unload_885  4.3907641772187384e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_772  1
    load_0_21_6  segment_load_conservation_829  -1
    load_0_21_6  segment_prefix_lb_830  1
    load_0_21_6  segment_prefix_ub_831  1
    load_0_21_6  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_774  -20
    arc_0_21_14  connected_order_arc_775  -15
    arc_0_21_14  in_degree_833  1
    arc_0_21_14  out_degree_874  1
    arc_0_21_14  original_T_including_depot_unload_885  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_774  1
    load_0_21_14  free_load_conservation_837  -1
    load_0_21_14  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_776  -20
    arc_0_21_15  connected_order_arc_777  -15
    arc_0_21_15  in_degree_839  1
    arc_0_21_15  out_degree_874  1
    arc_0_21_15  original_T_including_depot_unload_885  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_776  1
    load_0_21_15  free_load_conservation_843  -1
    load_0_21_15  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_778  -20
    arc_0_21_16  connected_order_arc_779  -15
    arc_0_21_16  in_degree_845  1
    arc_0_21_16  out_degree_874  1
    arc_0_21_16  original_T_including_depot_unload_885  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_778  1
    load_0_21_16  free_load_conservation_849  -1
    load_0_21_16  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_780  -20
    arc_0_21_17  connected_order_arc_781  -15
    arc_0_21_17  in_degree_851  1
    arc_0_21_17  out_degree_874  1
    arc_0_21_17  original_T_including_depot_unload_885  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_780  1
    load_0_21_17  free_load_conservation_855  -1
    load_0_21_17  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_782  -20
    arc_0_21_18  connected_order_arc_783  -15
    arc_0_21_18  in_degree_857  1
    arc_0_21_18  out_degree_874  1
    arc_0_21_18  original_T_including_depot_unload_885  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_782  1
    load_0_21_18  free_load_conservation_861  -1
    load_0_21_18  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_784  -20
    arc_0_21_19  connected_order_arc_785  -15
    arc_0_21_19  in_degree_863  1
    arc_0_21_19  out_degree_874  1
    arc_0_21_19  original_T_including_depot_unload_885  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_784  1
    load_0_21_19  free_load_conservation_867  -1
    load_0_21_19  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_786  -20
    arc_0_21_20  connected_order_arc_787  -15
    arc_0_21_20  in_degree_869  1
    arc_0_21_20  out_degree_874  1
    arc_0_21_20  original_T_including_depot_unload_885  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_786  1
    load_0_21_20  free_load_conservation_873  -1
    load_0_21_20  free_load_conservation_879  1
    visit_1_7  out_degree_1177  -1
    visit_1_7  in_degree_1178  -1
    visit_1_7  order_active_lb_1179  -1
    visit_1_7  order_active_ub_1180  -12
    order_1_7  connected_order_arc_901  -1
    order_1_7  connected_order_arc_903  -1
    order_1_7  connected_order_arc_905  -1
    order_1_7  connected_order_arc_907  -1
    order_1_7  connected_order_arc_909  -1
    order_1_7  connected_order_arc_911  -1
    order_1_7  connected_order_arc_913  -1
    order_1_7  connected_order_arc_915  -1
    order_1_7  connected_order_arc_917  -1
    order_1_7  connected_order_arc_919  -1
    order_1_7  connected_order_arc_921  -1
    order_1_7  connected_order_arc_924  1
    order_1_7  connected_order_arc_947  1
    order_1_7  connected_order_arc_970  1
    order_1_7  connected_order_arc_993  1
    order_1_7  connected_order_arc_1016  1
    order_1_7  connected_order_arc_1039  1
    order_1_7  connected_order_arc_1062  1
    order_1_7  connected_order_arc_1085  1
    order_1_7  connected_order_arc_1108  1
    order_1_7  connected_order_arc_1131  1
    order_1_7  connected_order_arc_1154  1
    order_1_7  order_active_lb_1179  1
    order_1_7  order_active_ub_1180  1
    order_1_7  fixed_segment_relative_order_1253  -1
    visit_1_8  out_degree_1184  -1
    visit_1_8  in_degree_1185  -1
    visit_1_8  order_active_lb_1186  -1
    visit_1_8  order_active_ub_1187  -12
    order_1_8  connected_order_arc_901  1
    order_1_8  connected_order_arc_924  -1
    order_1_8  connected_order_arc_926  -1
    order_1_8  connected_order_arc_928  -1
    order_1_8  connected_order_arc_930  -1
    order_1_8  connected_order_arc_932  -1
    order_1_8  connected_order_arc_934  -1
    order_1_8  connected_order_arc_936  -1
    order_1_8  connected_order_arc_938  -1
    order_1_8  connected_order_arc_940  -1
    order_1_8  connected_order_arc_942  -1
    order_1_8  connected_order_arc_944  -1
    order_1_8  connected_order_arc_949  1
    order_1_8  connected_order_arc_972  1
    order_1_8  connected_order_arc_995  1
    order_1_8  connected_order_arc_1018  1
    order_1_8  connected_order_arc_1041  1
    order_1_8  connected_order_arc_1064  1
    order_1_8  connected_order_arc_1087  1
    order_1_8  connected_order_arc_1110  1
    order_1_8  connected_order_arc_1133  1
    order_1_8  connected_order_arc_1156  1
    order_1_8  order_active_lb_1186  1
    order_1_8  order_active_ub_1187  1
    order_1_8  fixed_segment_relative_order_1253  1
    order_1_8  fixed_segment_relative_order_1254  -1
    visit_1_9  out_degree_1191  -1
    visit_1_9  in_degree_1192  -1
    visit_1_9  order_active_lb_1193  -1
    visit_1_9  order_active_ub_1194  -12
    order_1_9  connected_order_arc_903  1
    order_1_9  connected_order_arc_926  1
    order_1_9  connected_order_arc_947  -1
    order_1_9  connected_order_arc_949  -1
    order_1_9  connected_order_arc_951  -1
    order_1_9  connected_order_arc_953  -1
    order_1_9  connected_order_arc_955  -1
    order_1_9  connected_order_arc_957  -1
    order_1_9  connected_order_arc_959  -1
    order_1_9  connected_order_arc_961  -1
    order_1_9  connected_order_arc_963  -1
    order_1_9  connected_order_arc_965  -1
    order_1_9  connected_order_arc_967  -1
    order_1_9  connected_order_arc_974  1
    order_1_9  connected_order_arc_997  1
    order_1_9  connected_order_arc_1020  1
    order_1_9  connected_order_arc_1043  1
    order_1_9  connected_order_arc_1066  1
    order_1_9  connected_order_arc_1089  1
    order_1_9  connected_order_arc_1112  1
    order_1_9  connected_order_arc_1135  1
    order_1_9  connected_order_arc_1158  1
    order_1_9  order_active_lb_1193  1
    order_1_9  order_active_ub_1194  1
    order_1_9  fixed_segment_relative_order_1254  1
    order_1_9  fixed_segment_relative_order_1255  -1
    visit_1_10  out_degree_1198  -1
    visit_1_10  in_degree_1199  -1
    visit_1_10  order_active_lb_1200  -1
    visit_1_10  order_active_ub_1201  -12
    order_1_10  connected_order_arc_905  1
    order_1_10  connected_order_arc_928  1
    order_1_10  connected_order_arc_951  1
    order_1_10  connected_order_arc_970  -1
    order_1_10  connected_order_arc_972  -1
    order_1_10  connected_order_arc_974  -1
    order_1_10  connected_order_arc_976  -1
    order_1_10  connected_order_arc_978  -1
    order_1_10  connected_order_arc_980  -1
    order_1_10  connected_order_arc_982  -1
    order_1_10  connected_order_arc_984  -1
    order_1_10  connected_order_arc_986  -1
    order_1_10  connected_order_arc_988  -1
    order_1_10  connected_order_arc_990  -1
    order_1_10  connected_order_arc_999  1
    order_1_10  connected_order_arc_1022  1
    order_1_10  connected_order_arc_1045  1
    order_1_10  connected_order_arc_1068  1
    order_1_10  connected_order_arc_1091  1
    order_1_10  connected_order_arc_1114  1
    order_1_10  connected_order_arc_1137  1
    order_1_10  connected_order_arc_1160  1
    order_1_10  order_active_lb_1200  1
    order_1_10  order_active_ub_1201  1
    order_1_10  fixed_segment_relative_order_1255  1
    visit_1_14  out_degree_1205  -1
    visit_1_14  in_degree_1206  -1
    visit_1_14  order_active_lb_1207  -1
    visit_1_14  order_active_ub_1208  -12
    visit_1_14  service_visit_def_1209  -1
    order_1_14  connected_order_arc_907  1
    order_1_14  connected_order_arc_930  1
    order_1_14  connected_order_arc_953  1
    order_1_14  connected_order_arc_976  1
    order_1_14  connected_order_arc_993  -1
    order_1_14  connected_order_arc_995  -1
    order_1_14  connected_order_arc_997  -1
    order_1_14  connected_order_arc_999  -1
    order_1_14  connected_order_arc_1001  -1
    order_1_14  connected_order_arc_1003  -1
    order_1_14  connected_order_arc_1005  -1
    order_1_14  connected_order_arc_1007  -1
    order_1_14  connected_order_arc_1009  -1
    order_1_14  connected_order_arc_1011  -1
    order_1_14  connected_order_arc_1013  -1
    order_1_14  connected_order_arc_1024  1
    order_1_14  connected_order_arc_1047  1
    order_1_14  connected_order_arc_1070  1
    order_1_14  connected_order_arc_1093  1
    order_1_14  connected_order_arc_1116  1
    order_1_14  connected_order_arc_1139  1
    order_1_14  connected_order_arc_1162  1
    order_1_14  order_active_lb_1207  1
    order_1_14  order_active_ub_1208  1
    visit_1_15  out_degree_1211  -1
    visit_1_15  in_degree_1212  -1
    visit_1_15  order_active_lb_1213  -1
    visit_1_15  order_active_ub_1214  -12
    visit_1_15  service_visit_def_1215  -1
    order_1_15  connected_order_arc_909  1
    order_1_15  connected_order_arc_932  1
    order_1_15  connected_order_arc_955  1
    order_1_15  connected_order_arc_978  1
    order_1_15  connected_order_arc_1001  1
    order_1_15  connected_order_arc_1016  -1
    order_1_15  connected_order_arc_1018  -1
    order_1_15  connected_order_arc_1020  -1
    order_1_15  connected_order_arc_1022  -1
    order_1_15  connected_order_arc_1024  -1
    order_1_15  connected_order_arc_1026  -1
    order_1_15  connected_order_arc_1028  -1
    order_1_15  connected_order_arc_1030  -1
    order_1_15  connected_order_arc_1032  -1
    order_1_15  connected_order_arc_1034  -1
    order_1_15  connected_order_arc_1036  -1
    order_1_15  connected_order_arc_1049  1
    order_1_15  connected_order_arc_1072  1
    order_1_15  connected_order_arc_1095  1
    order_1_15  connected_order_arc_1118  1
    order_1_15  connected_order_arc_1141  1
    order_1_15  connected_order_arc_1164  1
    order_1_15  order_active_lb_1213  1
    order_1_15  order_active_ub_1214  1
    visit_1_16  out_degree_1217  -1
    visit_1_16  in_degree_1218  -1
    visit_1_16  order_active_lb_1219  -1
    visit_1_16  order_active_ub_1220  -12
    visit_1_16  service_visit_def_1221  -1
    order_1_16  connected_order_arc_911  1
    order_1_16  connected_order_arc_934  1
    order_1_16  connected_order_arc_957  1
    order_1_16  connected_order_arc_980  1
    order_1_16  connected_order_arc_1003  1
    order_1_16  connected_order_arc_1026  1
    order_1_16  connected_order_arc_1039  -1
    order_1_16  connected_order_arc_1041  -1
    order_1_16  connected_order_arc_1043  -1
    order_1_16  connected_order_arc_1045  -1
    order_1_16  connected_order_arc_1047  -1
    order_1_16  connected_order_arc_1049  -1
    order_1_16  connected_order_arc_1051  -1
    order_1_16  connected_order_arc_1053  -1
    order_1_16  connected_order_arc_1055  -1
    order_1_16  connected_order_arc_1057  -1
    order_1_16  connected_order_arc_1059  -1
    order_1_16  connected_order_arc_1074  1
    order_1_16  connected_order_arc_1097  1
    order_1_16  connected_order_arc_1120  1
    order_1_16  connected_order_arc_1143  1
    order_1_16  connected_order_arc_1166  1
    order_1_16  order_active_lb_1219  1
    order_1_16  order_active_ub_1220  1
    visit_1_17  out_degree_1223  -1
    visit_1_17  in_degree_1224  -1
    visit_1_17  order_active_lb_1225  -1
    visit_1_17  order_active_ub_1226  -12
    visit_1_17  service_visit_def_1227  -1
    order_1_17  connected_order_arc_913  1
    order_1_17  connected_order_arc_936  1
    order_1_17  connected_order_arc_959  1
    order_1_17  connected_order_arc_982  1
    order_1_17  connected_order_arc_1005  1
    order_1_17  connected_order_arc_1028  1
    order_1_17  connected_order_arc_1051  1
    order_1_17  connected_order_arc_1062  -1
    order_1_17  connected_order_arc_1064  -1
    order_1_17  connected_order_arc_1066  -1
    order_1_17  connected_order_arc_1068  -1
    order_1_17  connected_order_arc_1070  -1
    order_1_17  connected_order_arc_1072  -1
    order_1_17  connected_order_arc_1074  -1
    order_1_17  connected_order_arc_1076  -1
    order_1_17  connected_order_arc_1078  -1
    order_1_17  connected_order_arc_1080  -1
    order_1_17  connected_order_arc_1082  -1
    order_1_17  connected_order_arc_1099  1
    order_1_17  connected_order_arc_1122  1
    order_1_17  connected_order_arc_1145  1
    order_1_17  connected_order_arc_1168  1
    order_1_17  order_active_lb_1225  1
    order_1_17  order_active_ub_1226  1
    visit_1_18  out_degree_1229  -1
    visit_1_18  in_degree_1230  -1
    visit_1_18  order_active_lb_1231  -1
    visit_1_18  order_active_ub_1232  -12
    visit_1_18  service_visit_def_1233  -1
    order_1_18  connected_order_arc_915  1
    order_1_18  connected_order_arc_938  1
    order_1_18  connected_order_arc_961  1
    order_1_18  connected_order_arc_984  1
    order_1_18  connected_order_arc_1007  1
    order_1_18  connected_order_arc_1030  1
    order_1_18  connected_order_arc_1053  1
    order_1_18  connected_order_arc_1076  1
    order_1_18  connected_order_arc_1085  -1
    order_1_18  connected_order_arc_1087  -1
    order_1_18  connected_order_arc_1089  -1
    order_1_18  connected_order_arc_1091  -1
    order_1_18  connected_order_arc_1093  -1
    order_1_18  connected_order_arc_1095  -1
    order_1_18  connected_order_arc_1097  -1
    order_1_18  connected_order_arc_1099  -1
    order_1_18  connected_order_arc_1101  -1
    order_1_18  connected_order_arc_1103  -1
    order_1_18  connected_order_arc_1105  -1
    order_1_18  connected_order_arc_1124  1
    order_1_18  connected_order_arc_1147  1
    order_1_18  connected_order_arc_1170  1
    order_1_18  order_active_lb_1231  1
    order_1_18  order_active_ub_1232  1
    visit_1_19  out_degree_1235  -1
    visit_1_19  in_degree_1236  -1
    visit_1_19  order_active_lb_1237  -1
    visit_1_19  order_active_ub_1238  -12
    visit_1_19  service_visit_def_1239  -1
    order_1_19  connected_order_arc_917  1
    order_1_19  connected_order_arc_940  1
    order_1_19  connected_order_arc_963  1
    order_1_19  connected_order_arc_986  1
    order_1_19  connected_order_arc_1009  1
    order_1_19  connected_order_arc_1032  1
    order_1_19  connected_order_arc_1055  1
    order_1_19  connected_order_arc_1078  1
    order_1_19  connected_order_arc_1101  1
    order_1_19  connected_order_arc_1108  -1
    order_1_19  connected_order_arc_1110  -1
    order_1_19  connected_order_arc_1112  -1
    order_1_19  connected_order_arc_1114  -1
    order_1_19  connected_order_arc_1116  -1
    order_1_19  connected_order_arc_1118  -1
    order_1_19  connected_order_arc_1120  -1
    order_1_19  connected_order_arc_1122  -1
    order_1_19  connected_order_arc_1124  -1
    order_1_19  connected_order_arc_1126  -1
    order_1_19  connected_order_arc_1128  -1
    order_1_19  connected_order_arc_1149  1
    order_1_19  connected_order_arc_1172  1
    order_1_19  order_active_lb_1237  1
    order_1_19  order_active_ub_1238  1
    visit_1_20  out_degree_1241  -1
    visit_1_20  in_degree_1242  -1
    visit_1_20  order_active_lb_1243  -1
    visit_1_20  order_active_ub_1244  -12
    visit_1_20  service_visit_def_1245  -1
    order_1_20  connected_order_arc_919  1
    order_1_20  connected_order_arc_942  1
    order_1_20  connected_order_arc_965  1
    order_1_20  connected_order_arc_988  1
    order_1_20  connected_order_arc_1011  1
    order_1_20  connected_order_arc_1034  1
    order_1_20  connected_order_arc_1057  1
    order_1_20  connected_order_arc_1080  1
    order_1_20  connected_order_arc_1103  1
    order_1_20  connected_order_arc_1126  1
    order_1_20  connected_order_arc_1131  -1
    order_1_20  connected_order_arc_1133  -1
    order_1_20  connected_order_arc_1135  -1
    order_1_20  connected_order_arc_1137  -1
    order_1_20  connected_order_arc_1139  -1
    order_1_20  connected_order_arc_1141  -1
    order_1_20  connected_order_arc_1143  -1
    order_1_20  connected_order_arc_1145  -1
    order_1_20  connected_order_arc_1147  -1
    order_1_20  connected_order_arc_1149  -1
    order_1_20  connected_order_arc_1151  -1
    order_1_20  connected_order_arc_1174  1
    order_1_20  order_active_lb_1243  1
    order_1_20  order_active_ub_1244  1
    visit_1_21  out_degree_1247  -1
    visit_1_21  in_degree_1248  -1
    visit_1_21  order_active_lb_1249  -1
    visit_1_21  order_active_ub_1250  -12
    visit_1_21  service_visit_def_1251  -1
    order_1_21  connected_order_arc_921  1
    order_1_21  connected_order_arc_944  1
    order_1_21  connected_order_arc_967  1
    order_1_21  connected_order_arc_990  1
    order_1_21  connected_order_arc_1013  1
    order_1_21  connected_order_arc_1036  1
    order_1_21  connected_order_arc_1059  1
    order_1_21  connected_order_arc_1082  1
    order_1_21  connected_order_arc_1105  1
    order_1_21  connected_order_arc_1128  1
    order_1_21  connected_order_arc_1151  1
    order_1_21  connected_order_arc_1154  -1
    order_1_21  connected_order_arc_1156  -1
    order_1_21  connected_order_arc_1158  -1
    order_1_21  connected_order_arc_1160  -1
    order_1_21  connected_order_arc_1162  -1
    order_1_21  connected_order_arc_1164  -1
    order_1_21  connected_order_arc_1166  -1
    order_1_21  connected_order_arc_1168  -1
    order_1_21  connected_order_arc_1170  -1
    order_1_21  connected_order_arc_1172  -1
    order_1_21  connected_order_arc_1174  -1
    order_1_21  order_active_lb_1249  1
    order_1_21  order_active_ub_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_886  -25
    arc_1_0_0  depot_departure_or_bypass_1175  1
    arc_1_0_0  depot_return_or_bypass_1176  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_886  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_887  -25
    arc_1_0_7  depot_departure_or_bypass_1175  1
    arc_1_0_7  in_degree_1178  1
    arc_1_0_7  original_T_including_depot_unload_1256  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_887  1
    load_1_0_7  segment_load_conservation_1181  -1
    load_1_0_7  segment_prefix_lb_1182  1
    load_1_0_7  segment_prefix_ub_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_888  -25
    arc_1_0_8  depot_departure_or_bypass_1175  1
    arc_1_0_8  in_degree_1185  1
    arc_1_0_8  original_T_including_depot_unload_1256  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_888  1
    load_1_0_8  segment_load_conservation_1188  -1
    load_1_0_8  segment_prefix_lb_1189  1
    load_1_0_8  segment_prefix_ub_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_889  -25
    arc_1_0_9  depot_departure_or_bypass_1175  1
    arc_1_0_9  in_degree_1192  1
    arc_1_0_9  original_T_including_depot_unload_1256  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_889  1
    load_1_0_9  segment_load_conservation_1195  -1
    load_1_0_9  segment_prefix_lb_1196  1
    load_1_0_9  segment_prefix_ub_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_890  -25
    arc_1_0_10  depot_departure_or_bypass_1175  1
    arc_1_0_10  in_degree_1199  1
    arc_1_0_10  original_T_including_depot_unload_1256  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_890  1
    load_1_0_10  segment_load_conservation_1202  -1
    load_1_0_10  segment_prefix_lb_1203  1
    load_1_0_10  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_891  -25
    arc_1_0_14  depot_departure_or_bypass_1175  1
    arc_1_0_14  in_degree_1206  1
    arc_1_0_14  original_T_including_depot_unload_1256  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_891  1
    load_1_0_14  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_892  -25
    arc_1_0_15  depot_departure_or_bypass_1175  1
    arc_1_0_15  in_degree_1212  1
    arc_1_0_15  original_T_including_depot_unload_1256  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_892  1
    load_1_0_15  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_893  -25
    arc_1_0_16  depot_departure_or_bypass_1175  1
    arc_1_0_16  in_degree_1218  1
    arc_1_0_16  original_T_including_depot_unload_1256  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_893  1
    load_1_0_16  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_894  -25
    arc_1_0_17  depot_departure_or_bypass_1175  1
    arc_1_0_17  in_degree_1224  1
    arc_1_0_17  original_T_including_depot_unload_1256  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_894  1
    load_1_0_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_895  -25
    arc_1_0_18  depot_departure_or_bypass_1175  1
    arc_1_0_18  in_degree_1230  1
    arc_1_0_18  original_T_including_depot_unload_1256  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_895  1
    load_1_0_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_896  -25
    arc_1_0_19  depot_departure_or_bypass_1175  1
    arc_1_0_19  in_degree_1236  1
    arc_1_0_19  original_T_including_depot_unload_1256  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_896  1
    load_1_0_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_897  -25
    arc_1_0_20  depot_departure_or_bypass_1175  1
    arc_1_0_20  in_degree_1242  1
    arc_1_0_20  original_T_including_depot_unload_1256  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_897  1
    load_1_0_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_898  -25
    arc_1_0_21  depot_departure_or_bypass_1175  1
    arc_1_0_21  in_degree_1248  1
    arc_1_0_21  original_T_including_depot_unload_1256  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_898  1
    load_1_0_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_899  -25
    arc_1_7_0  depot_return_or_bypass_1176  1
    arc_1_7_0  out_degree_1177  1
    arc_1_7_0  original_T_including_depot_unload_1256  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_899  1
    load_1_7_0  segment_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_900  -25
    arc_1_7_8  connected_order_arc_901  -13
    arc_1_7_8  out_degree_1177  1
    arc_1_7_8  in_degree_1185  1
    arc_1_7_8  original_T_including_depot_unload_1256  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_900  1
    load_1_7_8  segment_load_conservation_1181  1
    load_1_7_8  segment_load_conservation_1188  -1
    load_1_7_8  segment_prefix_lb_1189  1
    load_1_7_8  segment_prefix_ub_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_902  -25
    arc_1_7_9  connected_order_arc_903  -13
    arc_1_7_9  out_degree_1177  1
    arc_1_7_9  in_degree_1192  1
    arc_1_7_9  original_T_including_depot_unload_1256  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_902  1
    load_1_7_9  segment_load_conservation_1181  1
    load_1_7_9  segment_load_conservation_1195  -1
    load_1_7_9  segment_prefix_lb_1196  1
    load_1_7_9  segment_prefix_ub_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_904  -25
    arc_1_7_10  connected_order_arc_905  -13
    arc_1_7_10  out_degree_1177  1
    arc_1_7_10  in_degree_1199  1
    arc_1_7_10  original_T_including_depot_unload_1256  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_904  1
    load_1_7_10  segment_load_conservation_1181  1
    load_1_7_10  segment_load_conservation_1202  -1
    load_1_7_10  segment_prefix_lb_1203  1
    load_1_7_10  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_906  -25
    arc_1_7_14  connected_order_arc_907  -13
    arc_1_7_14  out_degree_1177  1
    arc_1_7_14  in_degree_1206  1
    arc_1_7_14  original_T_including_depot_unload_1256  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_906  1
    load_1_7_14  segment_load_conservation_1181  1
    load_1_7_14  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_908  -25
    arc_1_7_15  connected_order_arc_909  -13
    arc_1_7_15  out_degree_1177  1
    arc_1_7_15  in_degree_1212  1
    arc_1_7_15  original_T_including_depot_unload_1256  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_908  1
    load_1_7_15  segment_load_conservation_1181  1
    load_1_7_15  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_910  -25
    arc_1_7_16  connected_order_arc_911  -13
    arc_1_7_16  out_degree_1177  1
    arc_1_7_16  in_degree_1218  1
    arc_1_7_16  original_T_including_depot_unload_1256  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_910  1
    load_1_7_16  segment_load_conservation_1181  1
    load_1_7_16  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_912  -25
    arc_1_7_17  connected_order_arc_913  -13
    arc_1_7_17  out_degree_1177  1
    arc_1_7_17  in_degree_1224  1
    arc_1_7_17  original_T_including_depot_unload_1256  7.0547985627601940e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_912  1
    load_1_7_17  segment_load_conservation_1181  1
    load_1_7_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_914  -25
    arc_1_7_18  connected_order_arc_915  -13
    arc_1_7_18  out_degree_1177  1
    arc_1_7_18  in_degree_1230  1
    arc_1_7_18  original_T_including_depot_unload_1256  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_914  1
    load_1_7_18  segment_load_conservation_1181  1
    load_1_7_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_916  -25
    arc_1_7_19  connected_order_arc_917  -13
    arc_1_7_19  out_degree_1177  1
    arc_1_7_19  in_degree_1236  1
    arc_1_7_19  original_T_including_depot_unload_1256  7.4895433191723123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_916  1
    load_1_7_19  segment_load_conservation_1181  1
    load_1_7_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_918  -25
    arc_1_7_20  connected_order_arc_919  -13
    arc_1_7_20  out_degree_1177  1
    arc_1_7_20  in_degree_1242  1
    arc_1_7_20  original_T_including_depot_unload_1256  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_918  1
    load_1_7_20  segment_load_conservation_1181  1
    load_1_7_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_920  -25
    arc_1_7_21  connected_order_arc_921  -13
    arc_1_7_21  out_degree_1177  1
    arc_1_7_21  in_degree_1248  1
    arc_1_7_21  original_T_including_depot_unload_1256  6.8151832047278333e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_920  1
    load_1_7_21  segment_load_conservation_1181  1
    load_1_7_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_922  -25
    arc_1_8_0  depot_return_or_bypass_1176  1
    arc_1_8_0  out_degree_1184  1
    arc_1_8_0  original_T_including_depot_unload_1256  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_922  1
    load_1_8_0  segment_load_conservation_1188  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_923  -25
    arc_1_8_7  connected_order_arc_924  -13
    arc_1_8_7  in_degree_1178  1
    arc_1_8_7  out_degree_1184  1
    arc_1_8_7  original_T_including_depot_unload_1256  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_923  1
    load_1_8_7  segment_load_conservation_1181  -1
    load_1_8_7  segment_prefix_lb_1182  1
    load_1_8_7  segment_prefix_ub_1183  1
    load_1_8_7  segment_load_conservation_1188  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_925  -25
    arc_1_8_9  connected_order_arc_926  -13
    arc_1_8_9  out_degree_1184  1
    arc_1_8_9  in_degree_1192  1
    arc_1_8_9  original_T_including_depot_unload_1256  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_925  1
    load_1_8_9  segment_load_conservation_1188  1
    load_1_8_9  segment_load_conservation_1195  -1
    load_1_8_9  segment_prefix_lb_1196  1
    load_1_8_9  segment_prefix_ub_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_927  -25
    arc_1_8_10  connected_order_arc_928  -13
    arc_1_8_10  out_degree_1184  1
    arc_1_8_10  in_degree_1199  1
    arc_1_8_10  original_T_including_depot_unload_1256  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_927  1
    load_1_8_10  segment_load_conservation_1188  1
    load_1_8_10  segment_load_conservation_1202  -1
    load_1_8_10  segment_prefix_lb_1203  1
    load_1_8_10  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_929  -25
    arc_1_8_14  connected_order_arc_930  -13
    arc_1_8_14  out_degree_1184  1
    arc_1_8_14  in_degree_1206  1
    arc_1_8_14  original_T_including_depot_unload_1256  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_929  1
    load_1_8_14  segment_load_conservation_1188  1
    load_1_8_14  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_931  -25
    arc_1_8_15  connected_order_arc_932  -13
    arc_1_8_15  out_degree_1184  1
    arc_1_8_15  in_degree_1212  1
    arc_1_8_15  original_T_including_depot_unload_1256  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_931  1
    load_1_8_15  segment_load_conservation_1188  1
    load_1_8_15  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_933  -25
    arc_1_8_16  connected_order_arc_934  -13
    arc_1_8_16  out_degree_1184  1
    arc_1_8_16  in_degree_1218  1
    arc_1_8_16  original_T_including_depot_unload_1256  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_933  1
    load_1_8_16  segment_load_conservation_1188  1
    load_1_8_16  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_935  -25
    arc_1_8_17  connected_order_arc_936  -13
    arc_1_8_17  out_degree_1184  1
    arc_1_8_17  in_degree_1224  1
    arc_1_8_17  original_T_including_depot_unload_1256  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_935  1
    load_1_8_17  segment_load_conservation_1188  1
    load_1_8_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_937  -25
    arc_1_8_18  connected_order_arc_938  -13
    arc_1_8_18  out_degree_1184  1
    arc_1_8_18  in_degree_1230  1
    arc_1_8_18  original_T_including_depot_unload_1256  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_937  1
    load_1_8_18  segment_load_conservation_1188  1
    load_1_8_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_939  -25
    arc_1_8_19  connected_order_arc_940  -13
    arc_1_8_19  out_degree_1184  1
    arc_1_8_19  in_degree_1236  1
    arc_1_8_19  original_T_including_depot_unload_1256  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_939  1
    load_1_8_19  segment_load_conservation_1188  1
    load_1_8_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_941  -25
    arc_1_8_20  connected_order_arc_942  -13
    arc_1_8_20  out_degree_1184  1
    arc_1_8_20  in_degree_1242  1
    arc_1_8_20  original_T_including_depot_unload_1256  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_941  1
    load_1_8_20  segment_load_conservation_1188  1
    load_1_8_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_943  -25
    arc_1_8_21  connected_order_arc_944  -13
    arc_1_8_21  out_degree_1184  1
    arc_1_8_21  in_degree_1248  1
    arc_1_8_21  original_T_including_depot_unload_1256  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_943  1
    load_1_8_21  segment_load_conservation_1188  1
    load_1_8_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_945  -25
    arc_1_9_0  depot_return_or_bypass_1176  1
    arc_1_9_0  out_degree_1191  1
    arc_1_9_0  original_T_including_depot_unload_1256  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_945  1
    load_1_9_0  segment_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_946  -25
    arc_1_9_7  connected_order_arc_947  -13
    arc_1_9_7  in_degree_1178  1
    arc_1_9_7  out_degree_1191  1
    arc_1_9_7  original_T_including_depot_unload_1256  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_946  1
    load_1_9_7  segment_load_conservation_1181  -1
    load_1_9_7  segment_prefix_lb_1182  1
    load_1_9_7  segment_prefix_ub_1183  1
    load_1_9_7  segment_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_948  -25
    arc_1_9_8  connected_order_arc_949  -13
    arc_1_9_8  in_degree_1185  1
    arc_1_9_8  out_degree_1191  1
    arc_1_9_8  original_T_including_depot_unload_1256  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_948  1
    load_1_9_8  segment_load_conservation_1188  -1
    load_1_9_8  segment_prefix_lb_1189  1
    load_1_9_8  segment_prefix_ub_1190  1
    load_1_9_8  segment_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_950  -25
    arc_1_9_10  connected_order_arc_951  -13
    arc_1_9_10  out_degree_1191  1
    arc_1_9_10  in_degree_1199  1
    arc_1_9_10  original_T_including_depot_unload_1256  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_950  1
    load_1_9_10  segment_load_conservation_1195  1
    load_1_9_10  segment_load_conservation_1202  -1
    load_1_9_10  segment_prefix_lb_1203  1
    load_1_9_10  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_952  -25
    arc_1_9_14  connected_order_arc_953  -13
    arc_1_9_14  out_degree_1191  1
    arc_1_9_14  in_degree_1206  1
    arc_1_9_14  original_T_including_depot_unload_1256  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_952  1
    load_1_9_14  segment_load_conservation_1195  1
    load_1_9_14  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_954  -25
    arc_1_9_15  connected_order_arc_955  -13
    arc_1_9_15  out_degree_1191  1
    arc_1_9_15  in_degree_1212  1
    arc_1_9_15  original_T_including_depot_unload_1256  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_954  1
    load_1_9_15  segment_load_conservation_1195  1
    load_1_9_15  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_956  -25
    arc_1_9_16  connected_order_arc_957  -13
    arc_1_9_16  out_degree_1191  1
    arc_1_9_16  in_degree_1218  1
    arc_1_9_16  original_T_including_depot_unload_1256  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_956  1
    load_1_9_16  segment_load_conservation_1195  1
    load_1_9_16  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_958  -25
    arc_1_9_17  connected_order_arc_959  -13
    arc_1_9_17  out_degree_1191  1
    arc_1_9_17  in_degree_1224  1
    arc_1_9_17  original_T_including_depot_unload_1256  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_958  1
    load_1_9_17  segment_load_conservation_1195  1
    load_1_9_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_960  -25
    arc_1_9_18  connected_order_arc_961  -13
    arc_1_9_18  out_degree_1191  1
    arc_1_9_18  in_degree_1230  1
    arc_1_9_18  original_T_including_depot_unload_1256  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_960  1
    load_1_9_18  segment_load_conservation_1195  1
    load_1_9_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_962  -25
    arc_1_9_19  connected_order_arc_963  -13
    arc_1_9_19  out_degree_1191  1
    arc_1_9_19  in_degree_1236  1
    arc_1_9_19  original_T_including_depot_unload_1256  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_962  1
    load_1_9_19  segment_load_conservation_1195  1
    load_1_9_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_964  -25
    arc_1_9_20  connected_order_arc_965  -13
    arc_1_9_20  out_degree_1191  1
    arc_1_9_20  in_degree_1242  1
    arc_1_9_20  original_T_including_depot_unload_1256  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_964  1
    load_1_9_20  segment_load_conservation_1195  1
    load_1_9_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_966  -25
    arc_1_9_21  connected_order_arc_967  -13
    arc_1_9_21  out_degree_1191  1
    arc_1_9_21  in_degree_1248  1
    arc_1_9_21  original_T_including_depot_unload_1256  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_966  1
    load_1_9_21  segment_load_conservation_1195  1
    load_1_9_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_968  -25
    arc_1_10_0  depot_return_or_bypass_1176  1
    arc_1_10_0  out_degree_1198  1
    arc_1_10_0  original_T_including_depot_unload_1256  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_968  1
    load_1_10_0  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_969  -25
    arc_1_10_7  connected_order_arc_970  -13
    arc_1_10_7  in_degree_1178  1
    arc_1_10_7  out_degree_1198  1
    arc_1_10_7  original_T_including_depot_unload_1256  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_969  1
    load_1_10_7  segment_load_conservation_1181  -1
    load_1_10_7  segment_prefix_lb_1182  1
    load_1_10_7  segment_prefix_ub_1183  1
    load_1_10_7  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_971  -25
    arc_1_10_8  connected_order_arc_972  -13
    arc_1_10_8  in_degree_1185  1
    arc_1_10_8  out_degree_1198  1
    arc_1_10_8  original_T_including_depot_unload_1256  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_971  1
    load_1_10_8  segment_load_conservation_1188  -1
    load_1_10_8  segment_prefix_lb_1189  1
    load_1_10_8  segment_prefix_ub_1190  1
    load_1_10_8  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_973  -25
    arc_1_10_9  connected_order_arc_974  -13
    arc_1_10_9  in_degree_1192  1
    arc_1_10_9  out_degree_1198  1
    arc_1_10_9  original_T_including_depot_unload_1256  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_973  1
    load_1_10_9  segment_load_conservation_1195  -1
    load_1_10_9  segment_prefix_lb_1196  1
    load_1_10_9  segment_prefix_ub_1197  1
    load_1_10_9  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_975  -25
    arc_1_10_14  connected_order_arc_976  -13
    arc_1_10_14  out_degree_1198  1
    arc_1_10_14  in_degree_1206  1
    arc_1_10_14  original_T_including_depot_unload_1256  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_975  1
    load_1_10_14  segment_load_conservation_1202  1
    load_1_10_14  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_977  -25
    arc_1_10_15  connected_order_arc_978  -13
    arc_1_10_15  out_degree_1198  1
    arc_1_10_15  in_degree_1212  1
    arc_1_10_15  original_T_including_depot_unload_1256  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_977  1
    load_1_10_15  segment_load_conservation_1202  1
    load_1_10_15  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_979  -25
    arc_1_10_16  connected_order_arc_980  -13
    arc_1_10_16  out_degree_1198  1
    arc_1_10_16  in_degree_1218  1
    arc_1_10_16  original_T_including_depot_unload_1256  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_979  1
    load_1_10_16  segment_load_conservation_1202  1
    load_1_10_16  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_981  -25
    arc_1_10_17  connected_order_arc_982  -13
    arc_1_10_17  out_degree_1198  1
    arc_1_10_17  in_degree_1224  1
    arc_1_10_17  original_T_including_depot_unload_1256  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_981  1
    load_1_10_17  segment_load_conservation_1202  1
    load_1_10_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_983  -25
    arc_1_10_18  connected_order_arc_984  -13
    arc_1_10_18  out_degree_1198  1
    arc_1_10_18  in_degree_1230  1
    arc_1_10_18  original_T_including_depot_unload_1256  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_983  1
    load_1_10_18  segment_load_conservation_1202  1
    load_1_10_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_985  -25
    arc_1_10_19  connected_order_arc_986  -13
    arc_1_10_19  out_degree_1198  1
    arc_1_10_19  in_degree_1236  1
    arc_1_10_19  original_T_including_depot_unload_1256  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_985  1
    load_1_10_19  segment_load_conservation_1202  1
    load_1_10_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_987  -25
    arc_1_10_20  connected_order_arc_988  -13
    arc_1_10_20  out_degree_1198  1
    arc_1_10_20  in_degree_1242  1
    arc_1_10_20  original_T_including_depot_unload_1256  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_987  1
    load_1_10_20  segment_load_conservation_1202  1
    load_1_10_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_989  -25
    arc_1_10_21  connected_order_arc_990  -13
    arc_1_10_21  out_degree_1198  1
    arc_1_10_21  in_degree_1248  1
    arc_1_10_21  original_T_including_depot_unload_1256  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_989  1
    load_1_10_21  segment_load_conservation_1202  1
    load_1_10_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_991  -25
    arc_1_14_0  depot_return_or_bypass_1176  1
    arc_1_14_0  out_degree_1205  1
    arc_1_14_0  original_T_including_depot_unload_1256  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_991  1
    load_1_14_0  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_992  -25
    arc_1_14_7  connected_order_arc_993  -13
    arc_1_14_7  in_degree_1178  1
    arc_1_14_7  out_degree_1205  1
    arc_1_14_7  original_T_including_depot_unload_1256  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_992  1
    load_1_14_7  segment_load_conservation_1181  -1
    load_1_14_7  segment_prefix_lb_1182  1
    load_1_14_7  segment_prefix_ub_1183  1
    load_1_14_7  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_994  -25
    arc_1_14_8  connected_order_arc_995  -13
    arc_1_14_8  in_degree_1185  1
    arc_1_14_8  out_degree_1205  1
    arc_1_14_8  original_T_including_depot_unload_1256  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_994  1
    load_1_14_8  segment_load_conservation_1188  -1
    load_1_14_8  segment_prefix_lb_1189  1
    load_1_14_8  segment_prefix_ub_1190  1
    load_1_14_8  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_996  -25
    arc_1_14_9  connected_order_arc_997  -13
    arc_1_14_9  in_degree_1192  1
    arc_1_14_9  out_degree_1205  1
    arc_1_14_9  original_T_including_depot_unload_1256  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_996  1
    load_1_14_9  segment_load_conservation_1195  -1
    load_1_14_9  segment_prefix_lb_1196  1
    load_1_14_9  segment_prefix_ub_1197  1
    load_1_14_9  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_998  -25
    arc_1_14_10  connected_order_arc_999  -13
    arc_1_14_10  in_degree_1199  1
    arc_1_14_10  out_degree_1205  1
    arc_1_14_10  original_T_including_depot_unload_1256  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_998  1
    load_1_14_10  segment_load_conservation_1202  -1
    load_1_14_10  segment_prefix_lb_1203  1
    load_1_14_10  segment_prefix_ub_1204  1
    load_1_14_10  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1000  -25
    arc_1_14_15  connected_order_arc_1001  -13
    arc_1_14_15  out_degree_1205  1
    arc_1_14_15  in_degree_1212  1
    arc_1_14_15  original_T_including_depot_unload_1256  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1000  1
    load_1_14_15  free_load_conservation_1210  1
    load_1_14_15  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1002  -25
    arc_1_14_16  connected_order_arc_1003  -13
    arc_1_14_16  out_degree_1205  1
    arc_1_14_16  in_degree_1218  1
    arc_1_14_16  original_T_including_depot_unload_1256  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1002  1
    load_1_14_16  free_load_conservation_1210  1
    load_1_14_16  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1004  -25
    arc_1_14_17  connected_order_arc_1005  -13
    arc_1_14_17  out_degree_1205  1
    arc_1_14_17  in_degree_1224  1
    arc_1_14_17  original_T_including_depot_unload_1256  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1004  1
    load_1_14_17  free_load_conservation_1210  1
    load_1_14_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1006  -25
    arc_1_14_18  connected_order_arc_1007  -13
    arc_1_14_18  out_degree_1205  1
    arc_1_14_18  in_degree_1230  1
    arc_1_14_18  original_T_including_depot_unload_1256  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1006  1
    load_1_14_18  free_load_conservation_1210  1
    load_1_14_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1008  -25
    arc_1_14_19  connected_order_arc_1009  -13
    arc_1_14_19  out_degree_1205  1
    arc_1_14_19  in_degree_1236  1
    arc_1_14_19  original_T_including_depot_unload_1256  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1008  1
    load_1_14_19  free_load_conservation_1210  1
    load_1_14_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1010  -25
    arc_1_14_20  connected_order_arc_1011  -13
    arc_1_14_20  out_degree_1205  1
    arc_1_14_20  in_degree_1242  1
    arc_1_14_20  original_T_including_depot_unload_1256  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1010  1
    load_1_14_20  free_load_conservation_1210  1
    load_1_14_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_1012  -25
    arc_1_14_21  connected_order_arc_1013  -13
    arc_1_14_21  out_degree_1205  1
    arc_1_14_21  in_degree_1248  1
    arc_1_14_21  original_T_including_depot_unload_1256  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_1012  1
    load_1_14_21  free_load_conservation_1210  1
    load_1_14_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1014  -25
    arc_1_15_0  depot_return_or_bypass_1176  1
    arc_1_15_0  out_degree_1211  1
    arc_1_15_0  original_T_including_depot_unload_1256  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1014  1
    load_1_15_0  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1015  -25
    arc_1_15_7  connected_order_arc_1016  -13
    arc_1_15_7  in_degree_1178  1
    arc_1_15_7  out_degree_1211  1
    arc_1_15_7  original_T_including_depot_unload_1256  1.5299353443215734e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1015  1
    load_1_15_7  segment_load_conservation_1181  -1
    load_1_15_7  segment_prefix_lb_1182  1
    load_1_15_7  segment_prefix_ub_1183  1
    load_1_15_7  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1017  -25
    arc_1_15_8  connected_order_arc_1018  -13
    arc_1_15_8  in_degree_1185  1
    arc_1_15_8  out_degree_1211  1
    arc_1_15_8  original_T_including_depot_unload_1256  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1017  1
    load_1_15_8  segment_load_conservation_1188  -1
    load_1_15_8  segment_prefix_lb_1189  1
    load_1_15_8  segment_prefix_ub_1190  1
    load_1_15_8  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1019  -25
    arc_1_15_9  connected_order_arc_1020  -13
    arc_1_15_9  in_degree_1192  1
    arc_1_15_9  out_degree_1211  1
    arc_1_15_9  original_T_including_depot_unload_1256  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1019  1
    load_1_15_9  segment_load_conservation_1195  -1
    load_1_15_9  segment_prefix_lb_1196  1
    load_1_15_9  segment_prefix_ub_1197  1
    load_1_15_9  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1021  -25
    arc_1_15_10  connected_order_arc_1022  -13
    arc_1_15_10  in_degree_1199  1
    arc_1_15_10  out_degree_1211  1
    arc_1_15_10  original_T_including_depot_unload_1256  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1021  1
    load_1_15_10  segment_load_conservation_1202  -1
    load_1_15_10  segment_prefix_lb_1203  1
    load_1_15_10  segment_prefix_ub_1204  1
    load_1_15_10  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1023  -25
    arc_1_15_14  connected_order_arc_1024  -13
    arc_1_15_14  in_degree_1206  1
    arc_1_15_14  out_degree_1211  1
    arc_1_15_14  original_T_including_depot_unload_1256  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1023  1
    load_1_15_14  free_load_conservation_1210  -1
    load_1_15_14  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1025  -25
    arc_1_15_16  connected_order_arc_1026  -13
    arc_1_15_16  out_degree_1211  1
    arc_1_15_16  in_degree_1218  1
    arc_1_15_16  original_T_including_depot_unload_1256  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1025  1
    load_1_15_16  free_load_conservation_1216  1
    load_1_15_16  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1027  -25
    arc_1_15_17  connected_order_arc_1028  -13
    arc_1_15_17  out_degree_1211  1
    arc_1_15_17  in_degree_1224  1
    arc_1_15_17  original_T_including_depot_unload_1256  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1027  1
    load_1_15_17  free_load_conservation_1216  1
    load_1_15_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1029  -25
    arc_1_15_18  connected_order_arc_1030  -13
    arc_1_15_18  out_degree_1211  1
    arc_1_15_18  in_degree_1230  1
    arc_1_15_18  original_T_including_depot_unload_1256  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1029  1
    load_1_15_18  free_load_conservation_1216  1
    load_1_15_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1031  -25
    arc_1_15_19  connected_order_arc_1032  -13
    arc_1_15_19  out_degree_1211  1
    arc_1_15_19  in_degree_1236  1
    arc_1_15_19  original_T_including_depot_unload_1256  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1031  1
    load_1_15_19  free_load_conservation_1216  1
    load_1_15_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1033  -25
    arc_1_15_20  connected_order_arc_1034  -13
    arc_1_15_20  out_degree_1211  1
    arc_1_15_20  in_degree_1242  1
    arc_1_15_20  original_T_including_depot_unload_1256  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1033  1
    load_1_15_20  free_load_conservation_1216  1
    load_1_15_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1035  -25
    arc_1_15_21  connected_order_arc_1036  -13
    arc_1_15_21  out_degree_1211  1
    arc_1_15_21  in_degree_1248  1
    arc_1_15_21  original_T_including_depot_unload_1256  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1035  1
    load_1_15_21  free_load_conservation_1216  1
    load_1_15_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1037  -25
    arc_1_16_0  depot_return_or_bypass_1176  1
    arc_1_16_0  out_degree_1217  1
    arc_1_16_0  original_T_including_depot_unload_1256  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1037  1
    load_1_16_0  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1038  -25
    arc_1_16_7  connected_order_arc_1039  -13
    arc_1_16_7  in_degree_1178  1
    arc_1_16_7  out_degree_1217  1
    arc_1_16_7  original_T_including_depot_unload_1256  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1038  1
    load_1_16_7  segment_load_conservation_1181  -1
    load_1_16_7  segment_prefix_lb_1182  1
    load_1_16_7  segment_prefix_ub_1183  1
    load_1_16_7  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1040  -25
    arc_1_16_8  connected_order_arc_1041  -13
    arc_1_16_8  in_degree_1185  1
    arc_1_16_8  out_degree_1217  1
    arc_1_16_8  original_T_including_depot_unload_1256  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1040  1
    load_1_16_8  segment_load_conservation_1188  -1
    load_1_16_8  segment_prefix_lb_1189  1
    load_1_16_8  segment_prefix_ub_1190  1
    load_1_16_8  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1042  -25
    arc_1_16_9  connected_order_arc_1043  -13
    arc_1_16_9  in_degree_1192  1
    arc_1_16_9  out_degree_1217  1
    arc_1_16_9  original_T_including_depot_unload_1256  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1042  1
    load_1_16_9  segment_load_conservation_1195  -1
    load_1_16_9  segment_prefix_lb_1196  1
    load_1_16_9  segment_prefix_ub_1197  1
    load_1_16_9  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1044  -25
    arc_1_16_10  connected_order_arc_1045  -13
    arc_1_16_10  in_degree_1199  1
    arc_1_16_10  out_degree_1217  1
    arc_1_16_10  original_T_including_depot_unload_1256  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1044  1
    load_1_16_10  segment_load_conservation_1202  -1
    load_1_16_10  segment_prefix_lb_1203  1
    load_1_16_10  segment_prefix_ub_1204  1
    load_1_16_10  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1046  -25
    arc_1_16_14  connected_order_arc_1047  -13
    arc_1_16_14  in_degree_1206  1
    arc_1_16_14  out_degree_1217  1
    arc_1_16_14  original_T_including_depot_unload_1256  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1046  1
    load_1_16_14  free_load_conservation_1210  -1
    load_1_16_14  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1048  -25
    arc_1_16_15  connected_order_arc_1049  -13
    arc_1_16_15  in_degree_1212  1
    arc_1_16_15  out_degree_1217  1
    arc_1_16_15  original_T_including_depot_unload_1256  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1048  1
    load_1_16_15  free_load_conservation_1216  -1
    load_1_16_15  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1050  -25
    arc_1_16_17  connected_order_arc_1051  -13
    arc_1_16_17  out_degree_1217  1
    arc_1_16_17  in_degree_1224  1
    arc_1_16_17  original_T_including_depot_unload_1256  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1050  1
    load_1_16_17  free_load_conservation_1222  1
    load_1_16_17  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1052  -25
    arc_1_16_18  connected_order_arc_1053  -13
    arc_1_16_18  out_degree_1217  1
    arc_1_16_18  in_degree_1230  1
    arc_1_16_18  original_T_including_depot_unload_1256  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1052  1
    load_1_16_18  free_load_conservation_1222  1
    load_1_16_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1054  -25
    arc_1_16_19  connected_order_arc_1055  -13
    arc_1_16_19  out_degree_1217  1
    arc_1_16_19  in_degree_1236  1
    arc_1_16_19  original_T_including_depot_unload_1256  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1054  1
    load_1_16_19  free_load_conservation_1222  1
    load_1_16_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1056  -25
    arc_1_16_20  connected_order_arc_1057  -13
    arc_1_16_20  out_degree_1217  1
    arc_1_16_20  in_degree_1242  1
    arc_1_16_20  original_T_including_depot_unload_1256  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1056  1
    load_1_16_20  free_load_conservation_1222  1
    load_1_16_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1058  -25
    arc_1_16_21  connected_order_arc_1059  -13
    arc_1_16_21  out_degree_1217  1
    arc_1_16_21  in_degree_1248  1
    arc_1_16_21  original_T_including_depot_unload_1256  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1058  1
    load_1_16_21  free_load_conservation_1222  1
    load_1_16_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1060  -25
    arc_1_17_0  depot_return_or_bypass_1176  1
    arc_1_17_0  out_degree_1223  1
    arc_1_17_0  original_T_including_depot_unload_1256  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1060  1
    load_1_17_0  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1061  -25
    arc_1_17_7  connected_order_arc_1062  -13
    arc_1_17_7  in_degree_1178  1
    arc_1_17_7  out_degree_1223  1
    arc_1_17_7  original_T_including_depot_unload_1256  1.7532207666032109e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1061  1
    load_1_17_7  segment_load_conservation_1181  -1
    load_1_17_7  segment_prefix_lb_1182  1
    load_1_17_7  segment_prefix_ub_1183  1
    load_1_17_7  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1063  -25
    arc_1_17_8  connected_order_arc_1064  -13
    arc_1_17_8  in_degree_1185  1
    arc_1_17_8  out_degree_1223  1
    arc_1_17_8  original_T_including_depot_unload_1256  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1063  1
    load_1_17_8  segment_load_conservation_1188  -1
    load_1_17_8  segment_prefix_lb_1189  1
    load_1_17_8  segment_prefix_ub_1190  1
    load_1_17_8  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1065  -25
    arc_1_17_9  connected_order_arc_1066  -13
    arc_1_17_9  in_degree_1192  1
    arc_1_17_9  out_degree_1223  1
    arc_1_17_9  original_T_including_depot_unload_1256  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1065  1
    load_1_17_9  segment_load_conservation_1195  -1
    load_1_17_9  segment_prefix_lb_1196  1
    load_1_17_9  segment_prefix_ub_1197  1
    load_1_17_9  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1067  -25
    arc_1_17_10  connected_order_arc_1068  -13
    arc_1_17_10  in_degree_1199  1
    arc_1_17_10  out_degree_1223  1
    arc_1_17_10  original_T_including_depot_unload_1256  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1067  1
    load_1_17_10  segment_load_conservation_1202  -1
    load_1_17_10  segment_prefix_lb_1203  1
    load_1_17_10  segment_prefix_ub_1204  1
    load_1_17_10  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1069  -25
    arc_1_17_14  connected_order_arc_1070  -13
    arc_1_17_14  in_degree_1206  1
    arc_1_17_14  out_degree_1223  1
    arc_1_17_14  original_T_including_depot_unload_1256  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1069  1
    load_1_17_14  free_load_conservation_1210  -1
    load_1_17_14  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1071  -25
    arc_1_17_15  connected_order_arc_1072  -13
    arc_1_17_15  in_degree_1212  1
    arc_1_17_15  out_degree_1223  1
    arc_1_17_15  original_T_including_depot_unload_1256  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1071  1
    load_1_17_15  free_load_conservation_1216  -1
    load_1_17_15  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1073  -25
    arc_1_17_16  connected_order_arc_1074  -13
    arc_1_17_16  in_degree_1218  1
    arc_1_17_16  out_degree_1223  1
    arc_1_17_16  original_T_including_depot_unload_1256  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1073  1
    load_1_17_16  free_load_conservation_1222  -1
    load_1_17_16  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1075  -25
    arc_1_17_18  connected_order_arc_1076  -13
    arc_1_17_18  out_degree_1223  1
    arc_1_17_18  in_degree_1230  1
    arc_1_17_18  original_T_including_depot_unload_1256  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1075  1
    load_1_17_18  free_load_conservation_1228  1
    load_1_17_18  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1077  -25
    arc_1_17_19  connected_order_arc_1078  -13
    arc_1_17_19  out_degree_1223  1
    arc_1_17_19  in_degree_1236  1
    arc_1_17_19  original_T_including_depot_unload_1256  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1077  1
    load_1_17_19  free_load_conservation_1228  1
    load_1_17_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1079  -25
    arc_1_17_20  connected_order_arc_1080  -13
    arc_1_17_20  out_degree_1223  1
    arc_1_17_20  in_degree_1242  1
    arc_1_17_20  original_T_including_depot_unload_1256  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1079  1
    load_1_17_20  free_load_conservation_1228  1
    load_1_17_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1081  -25
    arc_1_17_21  connected_order_arc_1082  -13
    arc_1_17_21  out_degree_1223  1
    arc_1_17_21  in_degree_1248  1
    arc_1_17_21  original_T_including_depot_unload_1256  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1081  1
    load_1_17_21  free_load_conservation_1228  1
    load_1_17_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1083  -25
    arc_1_18_0  depot_return_or_bypass_1176  1
    arc_1_18_0  out_degree_1229  1
    arc_1_18_0  original_T_including_depot_unload_1256  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1083  1
    load_1_18_0  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1084  -25
    arc_1_18_7  connected_order_arc_1085  -13
    arc_1_18_7  in_degree_1178  1
    arc_1_18_7  out_degree_1229  1
    arc_1_18_7  original_T_including_depot_unload_1256  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1084  1
    load_1_18_7  segment_load_conservation_1181  -1
    load_1_18_7  segment_prefix_lb_1182  1
    load_1_18_7  segment_prefix_ub_1183  1
    load_1_18_7  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1086  -25
    arc_1_18_8  connected_order_arc_1087  -13
    arc_1_18_8  in_degree_1185  1
    arc_1_18_8  out_degree_1229  1
    arc_1_18_8  original_T_including_depot_unload_1256  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1086  1
    load_1_18_8  segment_load_conservation_1188  -1
    load_1_18_8  segment_prefix_lb_1189  1
    load_1_18_8  segment_prefix_ub_1190  1
    load_1_18_8  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1088  -25
    arc_1_18_9  connected_order_arc_1089  -13
    arc_1_18_9  in_degree_1192  1
    arc_1_18_9  out_degree_1229  1
    arc_1_18_9  original_T_including_depot_unload_1256  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1088  1
    load_1_18_9  segment_load_conservation_1195  -1
    load_1_18_9  segment_prefix_lb_1196  1
    load_1_18_9  segment_prefix_ub_1197  1
    load_1_18_9  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1090  -25
    arc_1_18_10  connected_order_arc_1091  -13
    arc_1_18_10  in_degree_1199  1
    arc_1_18_10  out_degree_1229  1
    arc_1_18_10  original_T_including_depot_unload_1256  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1090  1
    load_1_18_10  segment_load_conservation_1202  -1
    load_1_18_10  segment_prefix_lb_1203  1
    load_1_18_10  segment_prefix_ub_1204  1
    load_1_18_10  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1092  -25
    arc_1_18_14  connected_order_arc_1093  -13
    arc_1_18_14  in_degree_1206  1
    arc_1_18_14  out_degree_1229  1
    arc_1_18_14  original_T_including_depot_unload_1256  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1092  1
    load_1_18_14  free_load_conservation_1210  -1
    load_1_18_14  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1094  -25
    arc_1_18_15  connected_order_arc_1095  -13
    arc_1_18_15  in_degree_1212  1
    arc_1_18_15  out_degree_1229  1
    arc_1_18_15  original_T_including_depot_unload_1256  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1094  1
    load_1_18_15  free_load_conservation_1216  -1
    load_1_18_15  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1096  -25
    arc_1_18_16  connected_order_arc_1097  -13
    arc_1_18_16  in_degree_1218  1
    arc_1_18_16  out_degree_1229  1
    arc_1_18_16  original_T_including_depot_unload_1256  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1096  1
    load_1_18_16  free_load_conservation_1222  -1
    load_1_18_16  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1098  -25
    arc_1_18_17  connected_order_arc_1099  -13
    arc_1_18_17  in_degree_1224  1
    arc_1_18_17  out_degree_1229  1
    arc_1_18_17  original_T_including_depot_unload_1256  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1098  1
    load_1_18_17  free_load_conservation_1228  -1
    load_1_18_17  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1100  -25
    arc_1_18_19  connected_order_arc_1101  -13
    arc_1_18_19  out_degree_1229  1
    arc_1_18_19  in_degree_1236  1
    arc_1_18_19  original_T_including_depot_unload_1256  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1100  1
    load_1_18_19  free_load_conservation_1234  1
    load_1_18_19  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1102  -25
    arc_1_18_20  connected_order_arc_1103  -13
    arc_1_18_20  out_degree_1229  1
    arc_1_18_20  in_degree_1242  1
    arc_1_18_20  original_T_including_depot_unload_1256  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1102  1
    load_1_18_20  free_load_conservation_1234  1
    load_1_18_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1104  -25
    arc_1_18_21  connected_order_arc_1105  -13
    arc_1_18_21  out_degree_1229  1
    arc_1_18_21  in_degree_1248  1
    arc_1_18_21  original_T_including_depot_unload_1256  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1104  1
    load_1_18_21  free_load_conservation_1234  1
    load_1_18_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1106  -25
    arc_1_19_0  depot_return_or_bypass_1176  1
    arc_1_19_0  out_degree_1235  1
    arc_1_19_0  original_T_including_depot_unload_1256  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1106  1
    load_1_19_0  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1107  -25
    arc_1_19_7  connected_order_arc_1108  -13
    arc_1_19_7  in_degree_1178  1
    arc_1_19_7  out_degree_1235  1
    arc_1_19_7  original_T_including_depot_unload_1256  1829.33035879167
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1107  1
    load_1_19_7  segment_load_conservation_1181  -1
    load_1_19_7  segment_prefix_lb_1182  1
    load_1_19_7  segment_prefix_ub_1183  1
    load_1_19_7  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1109  -25
    arc_1_19_8  connected_order_arc_1110  -13
    arc_1_19_8  in_degree_1185  1
    arc_1_19_8  out_degree_1235  1
    arc_1_19_8  original_T_including_depot_unload_1256  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1109  1
    load_1_19_8  segment_load_conservation_1188  -1
    load_1_19_8  segment_prefix_lb_1189  1
    load_1_19_8  segment_prefix_ub_1190  1
    load_1_19_8  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1111  -25
    arc_1_19_9  connected_order_arc_1112  -13
    arc_1_19_9  in_degree_1192  1
    arc_1_19_9  out_degree_1235  1
    arc_1_19_9  original_T_including_depot_unload_1256  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1111  1
    load_1_19_9  segment_load_conservation_1195  -1
    load_1_19_9  segment_prefix_lb_1196  1
    load_1_19_9  segment_prefix_ub_1197  1
    load_1_19_9  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1113  -25
    arc_1_19_10  connected_order_arc_1114  -13
    arc_1_19_10  in_degree_1199  1
    arc_1_19_10  out_degree_1235  1
    arc_1_19_10  original_T_including_depot_unload_1256  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1113  1
    load_1_19_10  segment_load_conservation_1202  -1
    load_1_19_10  segment_prefix_lb_1203  1
    load_1_19_10  segment_prefix_ub_1204  1
    load_1_19_10  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1115  -25
    arc_1_19_14  connected_order_arc_1116  -13
    arc_1_19_14  in_degree_1206  1
    arc_1_19_14  out_degree_1235  1
    arc_1_19_14  original_T_including_depot_unload_1256  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1115  1
    load_1_19_14  free_load_conservation_1210  -1
    load_1_19_14  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1117  -25
    arc_1_19_15  connected_order_arc_1118  -13
    arc_1_19_15  in_degree_1212  1
    arc_1_19_15  out_degree_1235  1
    arc_1_19_15  original_T_including_depot_unload_1256  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1117  1
    load_1_19_15  free_load_conservation_1216  -1
    load_1_19_15  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1119  -25
    arc_1_19_16  connected_order_arc_1120  -13
    arc_1_19_16  in_degree_1218  1
    arc_1_19_16  out_degree_1235  1
    arc_1_19_16  original_T_including_depot_unload_1256  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1119  1
    load_1_19_16  free_load_conservation_1222  -1
    load_1_19_16  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1121  -25
    arc_1_19_17  connected_order_arc_1122  -13
    arc_1_19_17  in_degree_1224  1
    arc_1_19_17  out_degree_1235  1
    arc_1_19_17  original_T_including_depot_unload_1256  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1121  1
    load_1_19_17  free_load_conservation_1228  -1
    load_1_19_17  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1123  -25
    arc_1_19_18  connected_order_arc_1124  -13
    arc_1_19_18  in_degree_1230  1
    arc_1_19_18  out_degree_1235  1
    arc_1_19_18  original_T_including_depot_unload_1256  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1123  1
    load_1_19_18  free_load_conservation_1234  -1
    load_1_19_18  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1125  -25
    arc_1_19_20  connected_order_arc_1126  -13
    arc_1_19_20  out_degree_1235  1
    arc_1_19_20  in_degree_1242  1
    arc_1_19_20  original_T_including_depot_unload_1256  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1125  1
    load_1_19_20  free_load_conservation_1240  1
    load_1_19_20  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1127  -25
    arc_1_19_21  connected_order_arc_1128  -13
    arc_1_19_21  out_degree_1235  1
    arc_1_19_21  in_degree_1248  1
    arc_1_19_21  original_T_including_depot_unload_1256  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1127  1
    load_1_19_21  free_load_conservation_1240  1
    load_1_19_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1129  -25
    arc_1_20_0  depot_return_or_bypass_1176  1
    arc_1_20_0  out_degree_1241  1
    arc_1_20_0  original_T_including_depot_unload_1256  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1129  1
    load_1_20_0  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1130  -25
    arc_1_20_7  connected_order_arc_1131  -13
    arc_1_20_7  in_degree_1178  1
    arc_1_20_7  out_degree_1241  1
    arc_1_20_7  original_T_including_depot_unload_1256  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1130  1
    load_1_20_7  segment_load_conservation_1181  -1
    load_1_20_7  segment_prefix_lb_1182  1
    load_1_20_7  segment_prefix_ub_1183  1
    load_1_20_7  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1132  -25
    arc_1_20_8  connected_order_arc_1133  -13
    arc_1_20_8  in_degree_1185  1
    arc_1_20_8  out_degree_1241  1
    arc_1_20_8  original_T_including_depot_unload_1256  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1132  1
    load_1_20_8  segment_load_conservation_1188  -1
    load_1_20_8  segment_prefix_lb_1189  1
    load_1_20_8  segment_prefix_ub_1190  1
    load_1_20_8  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1134  -25
    arc_1_20_9  connected_order_arc_1135  -13
    arc_1_20_9  in_degree_1192  1
    arc_1_20_9  out_degree_1241  1
    arc_1_20_9  original_T_including_depot_unload_1256  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1134  1
    load_1_20_9  segment_load_conservation_1195  -1
    load_1_20_9  segment_prefix_lb_1196  1
    load_1_20_9  segment_prefix_ub_1197  1
    load_1_20_9  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1136  -25
    arc_1_20_10  connected_order_arc_1137  -13
    arc_1_20_10  in_degree_1199  1
    arc_1_20_10  out_degree_1241  1
    arc_1_20_10  original_T_including_depot_unload_1256  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1136  1
    load_1_20_10  segment_load_conservation_1202  -1
    load_1_20_10  segment_prefix_lb_1203  1
    load_1_20_10  segment_prefix_ub_1204  1
    load_1_20_10  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1138  -25
    arc_1_20_14  connected_order_arc_1139  -13
    arc_1_20_14  in_degree_1206  1
    arc_1_20_14  out_degree_1241  1
    arc_1_20_14  original_T_including_depot_unload_1256  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1138  1
    load_1_20_14  free_load_conservation_1210  -1
    load_1_20_14  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1140  -25
    arc_1_20_15  connected_order_arc_1141  -13
    arc_1_20_15  in_degree_1212  1
    arc_1_20_15  out_degree_1241  1
    arc_1_20_15  original_T_including_depot_unload_1256  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1140  1
    load_1_20_15  free_load_conservation_1216  -1
    load_1_20_15  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1142  -25
    arc_1_20_16  connected_order_arc_1143  -13
    arc_1_20_16  in_degree_1218  1
    arc_1_20_16  out_degree_1241  1
    arc_1_20_16  original_T_including_depot_unload_1256  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1142  1
    load_1_20_16  free_load_conservation_1222  -1
    load_1_20_16  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1144  -25
    arc_1_20_17  connected_order_arc_1145  -13
    arc_1_20_17  in_degree_1224  1
    arc_1_20_17  out_degree_1241  1
    arc_1_20_17  original_T_including_depot_unload_1256  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1144  1
    load_1_20_17  free_load_conservation_1228  -1
    load_1_20_17  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1146  -25
    arc_1_20_18  connected_order_arc_1147  -13
    arc_1_20_18  in_degree_1230  1
    arc_1_20_18  out_degree_1241  1
    arc_1_20_18  original_T_including_depot_unload_1256  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1146  1
    load_1_20_18  free_load_conservation_1234  -1
    load_1_20_18  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1148  -25
    arc_1_20_19  connected_order_arc_1149  -13
    arc_1_20_19  in_degree_1236  1
    arc_1_20_19  out_degree_1241  1
    arc_1_20_19  original_T_including_depot_unload_1256  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1148  1
    load_1_20_19  free_load_conservation_1240  -1
    load_1_20_19  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1150  -25
    arc_1_20_21  connected_order_arc_1151  -13
    arc_1_20_21  out_degree_1241  1
    arc_1_20_21  in_degree_1248  1
    arc_1_20_21  original_T_including_depot_unload_1256  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1150  1
    load_1_20_21  free_load_conservation_1246  1
    load_1_20_21  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1152  -25
    arc_1_21_0  depot_return_or_bypass_1176  1
    arc_1_21_0  out_degree_1247  1
    arc_1_21_0  original_T_including_depot_unload_1256  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1152  1
    load_1_21_0  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1153  -25
    arc_1_21_7  connected_order_arc_1154  -13
    arc_1_21_7  in_degree_1178  1
    arc_1_21_7  out_degree_1247  1
    arc_1_21_7  original_T_including_depot_unload_1256  1.6985664713248598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1153  1
    load_1_21_7  segment_load_conservation_1181  -1
    load_1_21_7  segment_prefix_lb_1182  1
    load_1_21_7  segment_prefix_ub_1183  1
    load_1_21_7  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1155  -25
    arc_1_21_8  connected_order_arc_1156  -13
    arc_1_21_8  in_degree_1185  1
    arc_1_21_8  out_degree_1247  1
    arc_1_21_8  original_T_including_depot_unload_1256  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1155  1
    load_1_21_8  segment_load_conservation_1188  -1
    load_1_21_8  segment_prefix_lb_1189  1
    load_1_21_8  segment_prefix_ub_1190  1
    load_1_21_8  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1157  -25
    arc_1_21_9  connected_order_arc_1158  -13
    arc_1_21_9  in_degree_1192  1
    arc_1_21_9  out_degree_1247  1
    arc_1_21_9  original_T_including_depot_unload_1256  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1157  1
    load_1_21_9  segment_load_conservation_1195  -1
    load_1_21_9  segment_prefix_lb_1196  1
    load_1_21_9  segment_prefix_ub_1197  1
    load_1_21_9  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1159  -25
    arc_1_21_10  connected_order_arc_1160  -13
    arc_1_21_10  in_degree_1199  1
    arc_1_21_10  out_degree_1247  1
    arc_1_21_10  original_T_including_depot_unload_1256  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1159  1
    load_1_21_10  segment_load_conservation_1202  -1
    load_1_21_10  segment_prefix_lb_1203  1
    load_1_21_10  segment_prefix_ub_1204  1
    load_1_21_10  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1161  -25
    arc_1_21_14  connected_order_arc_1162  -13
    arc_1_21_14  in_degree_1206  1
    arc_1_21_14  out_degree_1247  1
    arc_1_21_14  original_T_including_depot_unload_1256  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1161  1
    load_1_21_14  free_load_conservation_1210  -1
    load_1_21_14  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1163  -25
    arc_1_21_15  connected_order_arc_1164  -13
    arc_1_21_15  in_degree_1212  1
    arc_1_21_15  out_degree_1247  1
    arc_1_21_15  original_T_including_depot_unload_1256  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1163  1
    load_1_21_15  free_load_conservation_1216  -1
    load_1_21_15  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1165  -25
    arc_1_21_16  connected_order_arc_1166  -13
    arc_1_21_16  in_degree_1218  1
    arc_1_21_16  out_degree_1247  1
    arc_1_21_16  original_T_including_depot_unload_1256  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1165  1
    load_1_21_16  free_load_conservation_1222  -1
    load_1_21_16  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1167  -25
    arc_1_21_17  connected_order_arc_1168  -13
    arc_1_21_17  in_degree_1224  1
    arc_1_21_17  out_degree_1247  1
    arc_1_21_17  original_T_including_depot_unload_1256  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1167  1
    load_1_21_17  free_load_conservation_1228  -1
    load_1_21_17  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1169  -25
    arc_1_21_18  connected_order_arc_1170  -13
    arc_1_21_18  in_degree_1230  1
    arc_1_21_18  out_degree_1247  1
    arc_1_21_18  original_T_including_depot_unload_1256  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1169  1
    load_1_21_18  free_load_conservation_1234  -1
    load_1_21_18  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1171  -25
    arc_1_21_19  connected_order_arc_1172  -13
    arc_1_21_19  in_degree_1236  1
    arc_1_21_19  out_degree_1247  1
    arc_1_21_19  original_T_including_depot_unload_1256  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1171  1
    load_1_21_19  free_load_conservation_1240  -1
    load_1_21_19  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1173  -25
    arc_1_21_20  connected_order_arc_1174  -13
    arc_1_21_20  in_degree_1242  1
    arc_1_21_20  out_degree_1247  1
    arc_1_21_20  original_T_including_depot_unload_1256  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1173  1
    load_1_21_20  free_load_conservation_1246  -1
    load_1_21_20  free_load_conservation_1252  1
    visit_2_11  out_degree_1502  -1
    visit_2_11  in_degree_1503  -1
    visit_2_11  order_active_lb_1504  -1
    visit_2_11  order_active_ub_1505  -11
    order_2_11  connected_order_arc_1271  -1
    order_2_11  connected_order_arc_1273  -1
    order_2_11  connected_order_arc_1275  -1
    order_2_11  connected_order_arc_1277  -1
    order_2_11  connected_order_arc_1279  -1
    order_2_11  connected_order_arc_1281  -1
    order_2_11  connected_order_arc_1283  -1
    order_2_11  connected_order_arc_1285  -1
    order_2_11  connected_order_arc_1287  -1
    order_2_11  connected_order_arc_1289  -1
    order_2_11  connected_order_arc_1292  1
    order_2_11  connected_order_arc_1313  1
    order_2_11  connected_order_arc_1334  1
    order_2_11  connected_order_arc_1355  1
    order_2_11  connected_order_arc_1376  1
    order_2_11  connected_order_arc_1397  1
    order_2_11  connected_order_arc_1418  1
    order_2_11  connected_order_arc_1439  1
    order_2_11  connected_order_arc_1460  1
    order_2_11  connected_order_arc_1481  1
    order_2_11  order_active_lb_1504  1
    order_2_11  order_active_ub_1505  1
    order_2_11  fixed_segment_relative_order_1571  -1
    visit_2_12  out_degree_1509  -1
    visit_2_12  in_degree_1510  -1
    visit_2_12  order_active_lb_1511  -1
    visit_2_12  order_active_ub_1512  -11
    order_2_12  connected_order_arc_1271  1
    order_2_12  connected_order_arc_1292  -1
    order_2_12  connected_order_arc_1294  -1
    order_2_12  connected_order_arc_1296  -1
    order_2_12  connected_order_arc_1298  -1
    order_2_12  connected_order_arc_1300  -1
    order_2_12  connected_order_arc_1302  -1
    order_2_12  connected_order_arc_1304  -1
    order_2_12  connected_order_arc_1306  -1
    order_2_12  connected_order_arc_1308  -1
    order_2_12  connected_order_arc_1310  -1
    order_2_12  connected_order_arc_1315  1
    order_2_12  connected_order_arc_1336  1
    order_2_12  connected_order_arc_1357  1
    order_2_12  connected_order_arc_1378  1
    order_2_12  connected_order_arc_1399  1
    order_2_12  connected_order_arc_1420  1
    order_2_12  connected_order_arc_1441  1
    order_2_12  connected_order_arc_1462  1
    order_2_12  connected_order_arc_1483  1
    order_2_12  order_active_lb_1511  1
    order_2_12  order_active_ub_1512  1
    order_2_12  fixed_segment_relative_order_1571  1
    order_2_12  fixed_segment_relative_order_1572  -1
    visit_2_13  out_degree_1516  -1
    visit_2_13  in_degree_1517  -1
    visit_2_13  order_active_lb_1518  -1
    visit_2_13  order_active_ub_1519  -11
    order_2_13  connected_order_arc_1273  1
    order_2_13  connected_order_arc_1294  1
    order_2_13  connected_order_arc_1313  -1
    order_2_13  connected_order_arc_1315  -1
    order_2_13  connected_order_arc_1317  -1
    order_2_13  connected_order_arc_1319  -1
    order_2_13  connected_order_arc_1321  -1
    order_2_13  connected_order_arc_1323  -1
    order_2_13  connected_order_arc_1325  -1
    order_2_13  connected_order_arc_1327  -1
    order_2_13  connected_order_arc_1329  -1
    order_2_13  connected_order_arc_1331  -1
    order_2_13  connected_order_arc_1338  1
    order_2_13  connected_order_arc_1359  1
    order_2_13  connected_order_arc_1380  1
    order_2_13  connected_order_arc_1401  1
    order_2_13  connected_order_arc_1422  1
    order_2_13  connected_order_arc_1443  1
    order_2_13  connected_order_arc_1464  1
    order_2_13  connected_order_arc_1485  1
    order_2_13  order_active_lb_1518  1
    order_2_13  order_active_ub_1519  1
    order_2_13  fixed_segment_relative_order_1572  1
    visit_2_14  out_degree_1523  -1
    visit_2_14  in_degree_1524  -1
    visit_2_14  order_active_lb_1525  -1
    visit_2_14  order_active_ub_1526  -11
    visit_2_14  service_visit_def_1527  -1
    order_2_14  connected_order_arc_1275  1
    order_2_14  connected_order_arc_1296  1
    order_2_14  connected_order_arc_1317  1
    order_2_14  connected_order_arc_1334  -1
    order_2_14  connected_order_arc_1336  -1
    order_2_14  connected_order_arc_1338  -1
    order_2_14  connected_order_arc_1340  -1
    order_2_14  connected_order_arc_1342  -1
    order_2_14  connected_order_arc_1344  -1
    order_2_14  connected_order_arc_1346  -1
    order_2_14  connected_order_arc_1348  -1
    order_2_14  connected_order_arc_1350  -1
    order_2_14  connected_order_arc_1352  -1
    order_2_14  connected_order_arc_1361  1
    order_2_14  connected_order_arc_1382  1
    order_2_14  connected_order_arc_1403  1
    order_2_14  connected_order_arc_1424  1
    order_2_14  connected_order_arc_1445  1
    order_2_14  connected_order_arc_1466  1
    order_2_14  connected_order_arc_1487  1
    order_2_14  order_active_lb_1525  1
    order_2_14  order_active_ub_1526  1
    visit_2_15  out_degree_1529  -1
    visit_2_15  in_degree_1530  -1
    visit_2_15  order_active_lb_1531  -1
    visit_2_15  order_active_ub_1532  -11
    visit_2_15  service_visit_def_1533  -1
    order_2_15  connected_order_arc_1277  1
    order_2_15  connected_order_arc_1298  1
    order_2_15  connected_order_arc_1319  1
    order_2_15  connected_order_arc_1340  1
    order_2_15  connected_order_arc_1355  -1
    order_2_15  connected_order_arc_1357  -1
    order_2_15  connected_order_arc_1359  -1
    order_2_15  connected_order_arc_1361  -1
    order_2_15  connected_order_arc_1363  -1
    order_2_15  connected_order_arc_1365  -1
    order_2_15  connected_order_arc_1367  -1
    order_2_15  connected_order_arc_1369  -1
    order_2_15  connected_order_arc_1371  -1
    order_2_15  connected_order_arc_1373  -1
    order_2_15  connected_order_arc_1384  1
    order_2_15  connected_order_arc_1405  1
    order_2_15  connected_order_arc_1426  1
    order_2_15  connected_order_arc_1447  1
    order_2_15  connected_order_arc_1468  1
    order_2_15  connected_order_arc_1489  1
    order_2_15  order_active_lb_1531  1
    order_2_15  order_active_ub_1532  1
    visit_2_16  out_degree_1535  -1
    visit_2_16  in_degree_1536  -1
    visit_2_16  order_active_lb_1537  -1
    visit_2_16  order_active_ub_1538  -11
    visit_2_16  service_visit_def_1539  -1
    order_2_16  connected_order_arc_1279  1
    order_2_16  connected_order_arc_1300  1
    order_2_16  connected_order_arc_1321  1
    order_2_16  connected_order_arc_1342  1
    order_2_16  connected_order_arc_1363  1
    order_2_16  connected_order_arc_1376  -1
    order_2_16  connected_order_arc_1378  -1
    order_2_16  connected_order_arc_1380  -1
    order_2_16  connected_order_arc_1382  -1
    order_2_16  connected_order_arc_1384  -1
    order_2_16  connected_order_arc_1386  -1
    order_2_16  connected_order_arc_1388  -1
    order_2_16  connected_order_arc_1390  -1
    order_2_16  connected_order_arc_1392  -1
    order_2_16  connected_order_arc_1394  -1
    order_2_16  connected_order_arc_1407  1
    order_2_16  connected_order_arc_1428  1
    order_2_16  connected_order_arc_1449  1
    order_2_16  connected_order_arc_1470  1
    order_2_16  connected_order_arc_1491  1
    order_2_16  order_active_lb_1537  1
    order_2_16  order_active_ub_1538  1
    visit_2_17  out_degree_1541  -1
    visit_2_17  in_degree_1542  -1
    visit_2_17  order_active_lb_1543  -1
    visit_2_17  order_active_ub_1544  -11
    visit_2_17  service_visit_def_1545  -1
    order_2_17  connected_order_arc_1281  1
    order_2_17  connected_order_arc_1302  1
    order_2_17  connected_order_arc_1323  1
    order_2_17  connected_order_arc_1344  1
    order_2_17  connected_order_arc_1365  1
    order_2_17  connected_order_arc_1386  1
    order_2_17  connected_order_arc_1397  -1
    order_2_17  connected_order_arc_1399  -1
    order_2_17  connected_order_arc_1401  -1
    order_2_17  connected_order_arc_1403  -1
    order_2_17  connected_order_arc_1405  -1
    order_2_17  connected_order_arc_1407  -1
    order_2_17  connected_order_arc_1409  -1
    order_2_17  connected_order_arc_1411  -1
    order_2_17  connected_order_arc_1413  -1
    order_2_17  connected_order_arc_1415  -1
    order_2_17  connected_order_arc_1430  1
    order_2_17  connected_order_arc_1451  1
    order_2_17  connected_order_arc_1472  1
    order_2_17  connected_order_arc_1493  1
    order_2_17  order_active_lb_1543  1
    order_2_17  order_active_ub_1544  1
    visit_2_18  out_degree_1547  -1
    visit_2_18  in_degree_1548  -1
    visit_2_18  order_active_lb_1549  -1
    visit_2_18  order_active_ub_1550  -11
    visit_2_18  service_visit_def_1551  -1
    order_2_18  connected_order_arc_1283  1
    order_2_18  connected_order_arc_1304  1
    order_2_18  connected_order_arc_1325  1
    order_2_18  connected_order_arc_1346  1
    order_2_18  connected_order_arc_1367  1
    order_2_18  connected_order_arc_1388  1
    order_2_18  connected_order_arc_1409  1
    order_2_18  connected_order_arc_1418  -1
    order_2_18  connected_order_arc_1420  -1
    order_2_18  connected_order_arc_1422  -1
    order_2_18  connected_order_arc_1424  -1
    order_2_18  connected_order_arc_1426  -1
    order_2_18  connected_order_arc_1428  -1
    order_2_18  connected_order_arc_1430  -1
    order_2_18  connected_order_arc_1432  -1
    order_2_18  connected_order_arc_1434  -1
    order_2_18  connected_order_arc_1436  -1
    order_2_18  connected_order_arc_1453  1
    order_2_18  connected_order_arc_1474  1
    order_2_18  connected_order_arc_1495  1
    order_2_18  order_active_lb_1549  1
    order_2_18  order_active_ub_1550  1
    visit_2_19  out_degree_1553  -1
    visit_2_19  in_degree_1554  -1
    visit_2_19  order_active_lb_1555  -1
    visit_2_19  order_active_ub_1556  -11
    visit_2_19  service_visit_def_1557  -1
    order_2_19  connected_order_arc_1285  1
    order_2_19  connected_order_arc_1306  1
    order_2_19  connected_order_arc_1327  1
    order_2_19  connected_order_arc_1348  1
    order_2_19  connected_order_arc_1369  1
    order_2_19  connected_order_arc_1390  1
    order_2_19  connected_order_arc_1411  1
    order_2_19  connected_order_arc_1432  1
    order_2_19  connected_order_arc_1439  -1
    order_2_19  connected_order_arc_1441  -1
    order_2_19  connected_order_arc_1443  -1
    order_2_19  connected_order_arc_1445  -1
    order_2_19  connected_order_arc_1447  -1
    order_2_19  connected_order_arc_1449  -1
    order_2_19  connected_order_arc_1451  -1
    order_2_19  connected_order_arc_1453  -1
    order_2_19  connected_order_arc_1455  -1
    order_2_19  connected_order_arc_1457  -1
    order_2_19  connected_order_arc_1476  1
    order_2_19  connected_order_arc_1497  1
    order_2_19  order_active_lb_1555  1
    order_2_19  order_active_ub_1556  1
    visit_2_20  out_degree_1559  -1
    visit_2_20  in_degree_1560  -1
    visit_2_20  order_active_lb_1561  -1
    visit_2_20  order_active_ub_1562  -11
    visit_2_20  service_visit_def_1563  -1
    order_2_20  connected_order_arc_1287  1
    order_2_20  connected_order_arc_1308  1
    order_2_20  connected_order_arc_1329  1
    order_2_20  connected_order_arc_1350  1
    order_2_20  connected_order_arc_1371  1
    order_2_20  connected_order_arc_1392  1
    order_2_20  connected_order_arc_1413  1
    order_2_20  connected_order_arc_1434  1
    order_2_20  connected_order_arc_1455  1
    order_2_20  connected_order_arc_1460  -1
    order_2_20  connected_order_arc_1462  -1
    order_2_20  connected_order_arc_1464  -1
    order_2_20  connected_order_arc_1466  -1
    order_2_20  connected_order_arc_1468  -1
    order_2_20  connected_order_arc_1470  -1
    order_2_20  connected_order_arc_1472  -1
    order_2_20  connected_order_arc_1474  -1
    order_2_20  connected_order_arc_1476  -1
    order_2_20  connected_order_arc_1478  -1
    order_2_20  connected_order_arc_1499  1
    order_2_20  order_active_lb_1561  1
    order_2_20  order_active_ub_1562  1
    visit_2_21  out_degree_1565  -1
    visit_2_21  in_degree_1566  -1
    visit_2_21  order_active_lb_1567  -1
    visit_2_21  order_active_ub_1568  -11
    visit_2_21  service_visit_def_1569  -1
    order_2_21  connected_order_arc_1289  1
    order_2_21  connected_order_arc_1310  1
    order_2_21  connected_order_arc_1331  1
    order_2_21  connected_order_arc_1352  1
    order_2_21  connected_order_arc_1373  1
    order_2_21  connected_order_arc_1394  1
    order_2_21  connected_order_arc_1415  1
    order_2_21  connected_order_arc_1436  1
    order_2_21  connected_order_arc_1457  1
    order_2_21  connected_order_arc_1478  1
    order_2_21  connected_order_arc_1481  -1
    order_2_21  connected_order_arc_1483  -1
    order_2_21  connected_order_arc_1485  -1
    order_2_21  connected_order_arc_1487  -1
    order_2_21  connected_order_arc_1489  -1
    order_2_21  connected_order_arc_1491  -1
    order_2_21  connected_order_arc_1493  -1
    order_2_21  connected_order_arc_1495  -1
    order_2_21  connected_order_arc_1497  -1
    order_2_21  connected_order_arc_1499  -1
    order_2_21  order_active_lb_1567  1
    order_2_21  order_active_ub_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1257  -30
    arc_2_0_0  depot_departure_or_bypass_1500  1
    arc_2_0_0  depot_return_or_bypass_1501  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1257  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1258  -30
    arc_2_0_11  depot_departure_or_bypass_1500  1
    arc_2_0_11  in_degree_1503  1
    arc_2_0_11  original_T_including_depot_unload_1573  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1258  1
    load_2_0_11  segment_load_conservation_1506  -1
    load_2_0_11  segment_prefix_lb_1507  1
    load_2_0_11  segment_prefix_ub_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1259  -30
    arc_2_0_12  depot_departure_or_bypass_1500  1
    arc_2_0_12  in_degree_1510  1
    arc_2_0_12  original_T_including_depot_unload_1573  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1259  1
    load_2_0_12  segment_load_conservation_1513  -1
    load_2_0_12  segment_prefix_lb_1514  1
    load_2_0_12  segment_prefix_ub_1515  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1260  -30
    arc_2_0_13  depot_departure_or_bypass_1500  1
    arc_2_0_13  in_degree_1517  1
    arc_2_0_13  original_T_including_depot_unload_1573  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1260  1
    load_2_0_13  segment_load_conservation_1520  -1
    load_2_0_13  segment_prefix_lb_1521  1
    load_2_0_13  segment_prefix_ub_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1261  -30
    arc_2_0_14  depot_departure_or_bypass_1500  1
    arc_2_0_14  in_degree_1524  1
    arc_2_0_14  original_T_including_depot_unload_1573  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1261  1
    load_2_0_14  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1262  -30
    arc_2_0_15  depot_departure_or_bypass_1500  1
    arc_2_0_15  in_degree_1530  1
    arc_2_0_15  original_T_including_depot_unload_1573  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1262  1
    load_2_0_15  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1263  -30
    arc_2_0_16  depot_departure_or_bypass_1500  1
    arc_2_0_16  in_degree_1536  1
    arc_2_0_16  original_T_including_depot_unload_1573  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1263  1
    load_2_0_16  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1264  -30
    arc_2_0_17  depot_departure_or_bypass_1500  1
    arc_2_0_17  in_degree_1542  1
    arc_2_0_17  original_T_including_depot_unload_1573  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1264  1
    load_2_0_17  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1265  -30
    arc_2_0_18  depot_departure_or_bypass_1500  1
    arc_2_0_18  in_degree_1548  1
    arc_2_0_18  original_T_including_depot_unload_1573  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1265  1
    load_2_0_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1266  -30
    arc_2_0_19  depot_departure_or_bypass_1500  1
    arc_2_0_19  in_degree_1554  1
    arc_2_0_19  original_T_including_depot_unload_1573  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1266  1
    load_2_0_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1267  -30
    arc_2_0_20  depot_departure_or_bypass_1500  1
    arc_2_0_20  in_degree_1560  1
    arc_2_0_20  original_T_including_depot_unload_1573  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1267  1
    load_2_0_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1268  -30
    arc_2_0_21  depot_departure_or_bypass_1500  1
    arc_2_0_21  in_degree_1566  1
    arc_2_0_21  original_T_including_depot_unload_1573  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1268  1
    load_2_0_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1269  -30
    arc_2_11_0  depot_return_or_bypass_1501  1
    arc_2_11_0  out_degree_1502  1
    arc_2_11_0  original_T_including_depot_unload_1573  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1269  1
    load_2_11_0  segment_load_conservation_1506  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1270  -30
    arc_2_11_12  connected_order_arc_1271  -12
    arc_2_11_12  out_degree_1502  1
    arc_2_11_12  in_degree_1510  1
    arc_2_11_12  original_T_including_depot_unload_1573  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1270  1
    load_2_11_12  segment_load_conservation_1506  1
    load_2_11_12  segment_load_conservation_1513  -1
    load_2_11_12  segment_prefix_lb_1514  1
    load_2_11_12  segment_prefix_ub_1515  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1272  -30
    arc_2_11_13  connected_order_arc_1273  -12
    arc_2_11_13  out_degree_1502  1
    arc_2_11_13  in_degree_1517  1
    arc_2_11_13  original_T_including_depot_unload_1573  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1272  1
    load_2_11_13  segment_load_conservation_1506  1
    load_2_11_13  segment_load_conservation_1520  -1
    load_2_11_13  segment_prefix_lb_1521  1
    load_2_11_13  segment_prefix_ub_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1274  -30
    arc_2_11_14  connected_order_arc_1275  -12
    arc_2_11_14  out_degree_1502  1
    arc_2_11_14  in_degree_1524  1
    arc_2_11_14  original_T_including_depot_unload_1573  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1274  1
    load_2_11_14  segment_load_conservation_1506  1
    load_2_11_14  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1276  -30
    arc_2_11_15  connected_order_arc_1277  -12
    arc_2_11_15  out_degree_1502  1
    arc_2_11_15  in_degree_1530  1
    arc_2_11_15  original_T_including_depot_unload_1573  1.6748602054274218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1276  1
    load_2_11_15  segment_load_conservation_1506  1
    load_2_11_15  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1278  -30
    arc_2_11_16  connected_order_arc_1279  -12
    arc_2_11_16  out_degree_1502  1
    arc_2_11_16  in_degree_1536  1
    arc_2_11_16  original_T_including_depot_unload_1573  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1278  1
    load_2_11_16  segment_load_conservation_1506  1
    load_2_11_16  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1280  -30
    arc_2_11_17  connected_order_arc_1281  -12
    arc_2_11_17  out_degree_1502  1
    arc_2_11_17  in_degree_1542  1
    arc_2_11_17  original_T_including_depot_unload_1573  1.6813024470003036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1280  1
    load_2_11_17  segment_load_conservation_1506  1
    load_2_11_17  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1282  -30
    arc_2_11_18  connected_order_arc_1283  -12
    arc_2_11_18  out_degree_1502  1
    arc_2_11_18  in_degree_1548  1
    arc_2_11_18  original_T_including_depot_unload_1573  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1282  1
    load_2_11_18  segment_load_conservation_1506  1
    load_2_11_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1284  -30
    arc_2_11_19  connected_order_arc_1285  -12
    arc_2_11_19  out_degree_1502  1
    arc_2_11_19  in_degree_1554  1
    arc_2_11_19  original_T_including_depot_unload_1573  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1284  1
    load_2_11_19  segment_load_conservation_1506  1
    load_2_11_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1286  -30
    arc_2_11_20  connected_order_arc_1287  -12
    arc_2_11_20  out_degree_1502  1
    arc_2_11_20  in_degree_1560  1
    arc_2_11_20  original_T_including_depot_unload_1573  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1286  1
    load_2_11_20  segment_load_conservation_1506  1
    load_2_11_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1288  -30
    arc_2_11_21  connected_order_arc_1289  -12
    arc_2_11_21  out_degree_1502  1
    arc_2_11_21  in_degree_1566  1
    arc_2_11_21  original_T_including_depot_unload_1573  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1288  1
    load_2_11_21  segment_load_conservation_1506  1
    load_2_11_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1290  -30
    arc_2_12_0  depot_return_or_bypass_1501  1
    arc_2_12_0  out_degree_1509  1
    arc_2_12_0  original_T_including_depot_unload_1573  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1290  1
    load_2_12_0  segment_load_conservation_1513  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1291  -30
    arc_2_12_11  connected_order_arc_1292  -12
    arc_2_12_11  in_degree_1503  1
    arc_2_12_11  out_degree_1509  1
    arc_2_12_11  original_T_including_depot_unload_1573  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1291  1
    load_2_12_11  segment_load_conservation_1506  -1
    load_2_12_11  segment_prefix_lb_1507  1
    load_2_12_11  segment_prefix_ub_1508  1
    load_2_12_11  segment_load_conservation_1513  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1293  -30
    arc_2_12_13  connected_order_arc_1294  -12
    arc_2_12_13  out_degree_1509  1
    arc_2_12_13  in_degree_1517  1
    arc_2_12_13  original_T_including_depot_unload_1573  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1293  1
    load_2_12_13  segment_load_conservation_1513  1
    load_2_12_13  segment_load_conservation_1520  -1
    load_2_12_13  segment_prefix_lb_1521  1
    load_2_12_13  segment_prefix_ub_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1295  -30
    arc_2_12_14  connected_order_arc_1296  -12
    arc_2_12_14  out_degree_1509  1
    arc_2_12_14  in_degree_1524  1
    arc_2_12_14  original_T_including_depot_unload_1573  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1295  1
    load_2_12_14  segment_load_conservation_1513  1
    load_2_12_14  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1297  -30
    arc_2_12_15  connected_order_arc_1298  -12
    arc_2_12_15  out_degree_1509  1
    arc_2_12_15  in_degree_1530  1
    arc_2_12_15  original_T_including_depot_unload_1573  2.3329109849823212e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1297  1
    load_2_12_15  segment_load_conservation_1513  1
    load_2_12_15  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1299  -30
    arc_2_12_16  connected_order_arc_1300  -12
    arc_2_12_16  out_degree_1509  1
    arc_2_12_16  in_degree_1536  1
    arc_2_12_16  original_T_including_depot_unload_1573  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1299  1
    load_2_12_16  segment_load_conservation_1513  1
    load_2_12_16  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1301  -30
    arc_2_12_17  connected_order_arc_1302  -12
    arc_2_12_17  out_degree_1509  1
    arc_2_12_17  in_degree_1542  1
    arc_2_12_17  original_T_including_depot_unload_1573  2.2684160167710820e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1301  1
    load_2_12_17  segment_load_conservation_1513  1
    load_2_12_17  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1303  -30
    arc_2_12_18  connected_order_arc_1304  -12
    arc_2_12_18  out_degree_1509  1
    arc_2_12_18  in_degree_1548  1
    arc_2_12_18  original_T_including_depot_unload_1573  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1303  1
    load_2_12_18  segment_load_conservation_1513  1
    load_2_12_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1305  -30
    arc_2_12_19  connected_order_arc_1306  -12
    arc_2_12_19  out_degree_1509  1
    arc_2_12_19  in_degree_1554  1
    arc_2_12_19  original_T_including_depot_unload_1573  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1305  1
    load_2_12_19  segment_load_conservation_1513  1
    load_2_12_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1307  -30
    arc_2_12_20  connected_order_arc_1308  -12
    arc_2_12_20  out_degree_1509  1
    arc_2_12_20  in_degree_1560  1
    arc_2_12_20  original_T_including_depot_unload_1573  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1307  1
    load_2_12_20  segment_load_conservation_1513  1
    load_2_12_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1309  -30
    arc_2_12_21  connected_order_arc_1310  -12
    arc_2_12_21  out_degree_1509  1
    arc_2_12_21  in_degree_1566  1
    arc_2_12_21  original_T_including_depot_unload_1573  2.1566797920965496e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1309  1
    load_2_12_21  segment_load_conservation_1513  1
    load_2_12_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1311  -30
    arc_2_13_0  depot_return_or_bypass_1501  1
    arc_2_13_0  out_degree_1516  1
    arc_2_13_0  original_T_including_depot_unload_1573  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1311  1
    load_2_13_0  segment_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1312  -30
    arc_2_13_11  connected_order_arc_1313  -12
    arc_2_13_11  in_degree_1503  1
    arc_2_13_11  out_degree_1516  1
    arc_2_13_11  original_T_including_depot_unload_1573  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1312  1
    load_2_13_11  segment_load_conservation_1506  -1
    load_2_13_11  segment_prefix_lb_1507  1
    load_2_13_11  segment_prefix_ub_1508  1
    load_2_13_11  segment_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1314  -30
    arc_2_13_12  connected_order_arc_1315  -12
    arc_2_13_12  in_degree_1510  1
    arc_2_13_12  out_degree_1516  1
    arc_2_13_12  original_T_including_depot_unload_1573  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1314  1
    load_2_13_12  segment_load_conservation_1513  -1
    load_2_13_12  segment_prefix_lb_1514  1
    load_2_13_12  segment_prefix_ub_1515  1
    load_2_13_12  segment_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1316  -30
    arc_2_13_14  connected_order_arc_1317  -12
    arc_2_13_14  out_degree_1516  1
    arc_2_13_14  in_degree_1524  1
    arc_2_13_14  original_T_including_depot_unload_1573  1.8614801653445954e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1316  1
    load_2_13_14  segment_load_conservation_1520  1
    load_2_13_14  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1318  -30
    arc_2_13_15  connected_order_arc_1319  -12
    arc_2_13_15  out_degree_1516  1
    arc_2_13_15  in_degree_1530  1
    arc_2_13_15  original_T_including_depot_unload_1573  1.8134227723553629e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1318  1
    load_2_13_15  segment_load_conservation_1520  1
    load_2_13_15  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1320  -30
    arc_2_13_16  connected_order_arc_1321  -12
    arc_2_13_16  out_degree_1516  1
    arc_2_13_16  in_degree_1536  1
    arc_2_13_16  original_T_including_depot_unload_1573  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1320  1
    load_2_13_16  segment_load_conservation_1520  1
    load_2_13_16  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1322  -30
    arc_2_13_17  connected_order_arc_1323  -12
    arc_2_13_17  out_degree_1516  1
    arc_2_13_17  in_degree_1542  1
    arc_2_13_17  original_T_including_depot_unload_1573  1.8770574474563218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1322  1
    load_2_13_17  segment_load_conservation_1520  1
    load_2_13_17  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1324  -30
    arc_2_13_18  connected_order_arc_1325  -12
    arc_2_13_18  out_degree_1516  1
    arc_2_13_18  in_degree_1548  1
    arc_2_13_18  original_T_including_depot_unload_1573  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1324  1
    load_2_13_18  segment_load_conservation_1520  1
    load_2_13_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1326  -30
    arc_2_13_19  connected_order_arc_1327  -12
    arc_2_13_19  out_degree_1516  1
    arc_2_13_19  in_degree_1554  1
    arc_2_13_19  original_T_including_depot_unload_1573  2.1115837908099625e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1326  1
    load_2_13_19  segment_load_conservation_1520  1
    load_2_13_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1328  -30
    arc_2_13_20  connected_order_arc_1329  -12
    arc_2_13_20  out_degree_1516  1
    arc_2_13_20  in_degree_1560  1
    arc_2_13_20  original_T_including_depot_unload_1573  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1328  1
    load_2_13_20  segment_load_conservation_1520  1
    load_2_13_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1330  -30
    arc_2_13_21  connected_order_arc_1331  -12
    arc_2_13_21  out_degree_1516  1
    arc_2_13_21  in_degree_1566  1
    arc_2_13_21  original_T_including_depot_unload_1573  1.7791475856216737e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1330  1
    load_2_13_21  segment_load_conservation_1520  1
    load_2_13_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1332  -30
    arc_2_14_0  depot_return_or_bypass_1501  1
    arc_2_14_0  out_degree_1523  1
    arc_2_14_0  original_T_including_depot_unload_1573  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1332  1
    load_2_14_0  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1333  -30
    arc_2_14_11  connected_order_arc_1334  -12
    arc_2_14_11  in_degree_1503  1
    arc_2_14_11  out_degree_1523  1
    arc_2_14_11  original_T_including_depot_unload_1573  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1333  1
    load_2_14_11  segment_load_conservation_1506  -1
    load_2_14_11  segment_prefix_lb_1507  1
    load_2_14_11  segment_prefix_ub_1508  1
    load_2_14_11  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1335  -30
    arc_2_14_12  connected_order_arc_1336  -12
    arc_2_14_12  in_degree_1510  1
    arc_2_14_12  out_degree_1523  1
    arc_2_14_12  original_T_including_depot_unload_1573  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1335  1
    load_2_14_12  segment_load_conservation_1513  -1
    load_2_14_12  segment_prefix_lb_1514  1
    load_2_14_12  segment_prefix_ub_1515  1
    load_2_14_12  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1337  -30
    arc_2_14_13  connected_order_arc_1338  -12
    arc_2_14_13  in_degree_1517  1
    arc_2_14_13  out_degree_1523  1
    arc_2_14_13  original_T_including_depot_unload_1573  2.3310908183310389e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1337  1
    load_2_14_13  segment_load_conservation_1520  -1
    load_2_14_13  segment_prefix_lb_1521  1
    load_2_14_13  segment_prefix_ub_1522  1
    load_2_14_13  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1339  -30
    arc_2_14_15  connected_order_arc_1340  -12
    arc_2_14_15  out_degree_1523  1
    arc_2_14_15  in_degree_1530  1
    arc_2_14_15  original_T_including_depot_unload_1573  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1339  1
    load_2_14_15  free_load_conservation_1528  1
    load_2_14_15  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1341  -30
    arc_2_14_16  connected_order_arc_1342  -12
    arc_2_14_16  out_degree_1523  1
    arc_2_14_16  in_degree_1536  1
    arc_2_14_16  original_T_including_depot_unload_1573  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1341  1
    load_2_14_16  free_load_conservation_1528  1
    load_2_14_16  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1343  -30
    arc_2_14_17  connected_order_arc_1344  -12
    arc_2_14_17  out_degree_1523  1
    arc_2_14_17  in_degree_1542  1
    arc_2_14_17  original_T_including_depot_unload_1573  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1343  1
    load_2_14_17  free_load_conservation_1528  1
    load_2_14_17  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1345  -30
    arc_2_14_18  connected_order_arc_1346  -12
    arc_2_14_18  out_degree_1523  1
    arc_2_14_18  in_degree_1548  1
    arc_2_14_18  original_T_including_depot_unload_1573  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1345  1
    load_2_14_18  free_load_conservation_1528  1
    load_2_14_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1347  -30
    arc_2_14_19  connected_order_arc_1348  -12
    arc_2_14_19  out_degree_1523  1
    arc_2_14_19  in_degree_1554  1
    arc_2_14_19  original_T_including_depot_unload_1573  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1347  1
    load_2_14_19  free_load_conservation_1528  1
    load_2_14_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1349  -30
    arc_2_14_20  connected_order_arc_1350  -12
    arc_2_14_20  out_degree_1523  1
    arc_2_14_20  in_degree_1560  1
    arc_2_14_20  original_T_including_depot_unload_1573  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1349  1
    load_2_14_20  free_load_conservation_1528  1
    load_2_14_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1351  -30
    arc_2_14_21  connected_order_arc_1352  -12
    arc_2_14_21  out_degree_1523  1
    arc_2_14_21  in_degree_1566  1
    arc_2_14_21  original_T_including_depot_unload_1573  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1351  1
    load_2_14_21  free_load_conservation_1528  1
    load_2_14_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1353  -30
    arc_2_15_0  depot_return_or_bypass_1501  1
    arc_2_15_0  out_degree_1529  1
    arc_2_15_0  original_T_including_depot_unload_1573  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1353  1
    load_2_15_0  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1354  -30
    arc_2_15_11  connected_order_arc_1355  -12
    arc_2_15_11  in_degree_1503  1
    arc_2_15_11  out_degree_1529  1
    arc_2_15_11  original_T_including_depot_unload_1573  1.6748602054274218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1354  1
    load_2_15_11  segment_load_conservation_1506  -1
    load_2_15_11  segment_prefix_lb_1507  1
    load_2_15_11  segment_prefix_ub_1508  1
    load_2_15_11  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1356  -30
    arc_2_15_12  connected_order_arc_1357  -12
    arc_2_15_12  in_degree_1510  1
    arc_2_15_12  out_degree_1529  1
    arc_2_15_12  original_T_including_depot_unload_1573  2.3329109849823212e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1356  1
    load_2_15_12  segment_load_conservation_1513  -1
    load_2_15_12  segment_prefix_lb_1514  1
    load_2_15_12  segment_prefix_ub_1515  1
    load_2_15_12  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1358  -30
    arc_2_15_13  connected_order_arc_1359  -12
    arc_2_15_13  in_degree_1517  1
    arc_2_15_13  out_degree_1529  1
    arc_2_15_13  original_T_including_depot_unload_1573  2.3162349395019428e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1358  1
    load_2_15_13  segment_load_conservation_1520  -1
    load_2_15_13  segment_prefix_lb_1521  1
    load_2_15_13  segment_prefix_ub_1522  1
    load_2_15_13  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1360  -30
    arc_2_15_14  connected_order_arc_1361  -12
    arc_2_15_14  in_degree_1524  1
    arc_2_15_14  out_degree_1529  1
    arc_2_15_14  original_T_including_depot_unload_1573  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1360  1
    load_2_15_14  free_load_conservation_1528  -1
    load_2_15_14  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1362  -30
    arc_2_15_16  connected_order_arc_1363  -12
    arc_2_15_16  out_degree_1529  1
    arc_2_15_16  in_degree_1536  1
    arc_2_15_16  original_T_including_depot_unload_1573  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1362  1
    load_2_15_16  free_load_conservation_1534  1
    load_2_15_16  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1364  -30
    arc_2_15_17  connected_order_arc_1365  -12
    arc_2_15_17  out_degree_1529  1
    arc_2_15_17  in_degree_1542  1
    arc_2_15_17  original_T_including_depot_unload_1573  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1364  1
    load_2_15_17  free_load_conservation_1534  1
    load_2_15_17  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1366  -30
    arc_2_15_18  connected_order_arc_1367  -12
    arc_2_15_18  out_degree_1529  1
    arc_2_15_18  in_degree_1548  1
    arc_2_15_18  original_T_including_depot_unload_1573  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1366  1
    load_2_15_18  free_load_conservation_1534  1
    load_2_15_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1368  -30
    arc_2_15_19  connected_order_arc_1369  -12
    arc_2_15_19  out_degree_1529  1
    arc_2_15_19  in_degree_1554  1
    arc_2_15_19  original_T_including_depot_unload_1573  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1368  1
    load_2_15_19  free_load_conservation_1534  1
    load_2_15_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1370  -30
    arc_2_15_20  connected_order_arc_1371  -12
    arc_2_15_20  out_degree_1529  1
    arc_2_15_20  in_degree_1560  1
    arc_2_15_20  original_T_including_depot_unload_1573  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1370  1
    load_2_15_20  free_load_conservation_1534  1
    load_2_15_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1372  -30
    arc_2_15_21  connected_order_arc_1373  -12
    arc_2_15_21  out_degree_1529  1
    arc_2_15_21  in_degree_1566  1
    arc_2_15_21  original_T_including_depot_unload_1573  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1372  1
    load_2_15_21  free_load_conservation_1534  1
    load_2_15_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1374  -30
    arc_2_16_0  depot_return_or_bypass_1501  1
    arc_2_16_0  out_degree_1535  1
    arc_2_16_0  original_T_including_depot_unload_1573  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1374  1
    load_2_16_0  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1375  -30
    arc_2_16_11  connected_order_arc_1376  -12
    arc_2_16_11  in_degree_1503  1
    arc_2_16_11  out_degree_1535  1
    arc_2_16_11  original_T_including_depot_unload_1573  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1375  1
    load_2_16_11  segment_load_conservation_1506  -1
    load_2_16_11  segment_prefix_lb_1507  1
    load_2_16_11  segment_prefix_ub_1508  1
    load_2_16_11  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1377  -30
    arc_2_16_12  connected_order_arc_1378  -12
    arc_2_16_12  in_degree_1510  1
    arc_2_16_12  out_degree_1535  1
    arc_2_16_12  original_T_including_depot_unload_1573  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1377  1
    load_2_16_12  segment_load_conservation_1513  -1
    load_2_16_12  segment_prefix_lb_1514  1
    load_2_16_12  segment_prefix_ub_1515  1
    load_2_16_12  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1379  -30
    arc_2_16_13  connected_order_arc_1380  -12
    arc_2_16_13  in_degree_1517  1
    arc_2_16_13  out_degree_1535  1
    arc_2_16_13  original_T_including_depot_unload_1573  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1379  1
    load_2_16_13  segment_load_conservation_1520  -1
    load_2_16_13  segment_prefix_lb_1521  1
    load_2_16_13  segment_prefix_ub_1522  1
    load_2_16_13  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1381  -30
    arc_2_16_14  connected_order_arc_1382  -12
    arc_2_16_14  in_degree_1524  1
    arc_2_16_14  out_degree_1535  1
    arc_2_16_14  original_T_including_depot_unload_1573  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1381  1
    load_2_16_14  free_load_conservation_1528  -1
    load_2_16_14  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1383  -30
    arc_2_16_15  connected_order_arc_1384  -12
    arc_2_16_15  in_degree_1530  1
    arc_2_16_15  out_degree_1535  1
    arc_2_16_15  original_T_including_depot_unload_1573  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1383  1
    load_2_16_15  free_load_conservation_1534  -1
    load_2_16_15  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1385  -30
    arc_2_16_17  connected_order_arc_1386  -12
    arc_2_16_17  out_degree_1535  1
    arc_2_16_17  in_degree_1542  1
    arc_2_16_17  original_T_including_depot_unload_1573  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1385  1
    load_2_16_17  free_load_conservation_1540  1
    load_2_16_17  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1387  -30
    arc_2_16_18  connected_order_arc_1388  -12
    arc_2_16_18  out_degree_1535  1
    arc_2_16_18  in_degree_1548  1
    arc_2_16_18  original_T_including_depot_unload_1573  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1387  1
    load_2_16_18  free_load_conservation_1540  1
    load_2_16_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1389  -30
    arc_2_16_19  connected_order_arc_1390  -12
    arc_2_16_19  out_degree_1535  1
    arc_2_16_19  in_degree_1554  1
    arc_2_16_19  original_T_including_depot_unload_1573  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1389  1
    load_2_16_19  free_load_conservation_1540  1
    load_2_16_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1391  -30
    arc_2_16_20  connected_order_arc_1392  -12
    arc_2_16_20  out_degree_1535  1
    arc_2_16_20  in_degree_1560  1
    arc_2_16_20  original_T_including_depot_unload_1573  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1391  1
    load_2_16_20  free_load_conservation_1540  1
    load_2_16_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1393  -30
    arc_2_16_21  connected_order_arc_1394  -12
    arc_2_16_21  out_degree_1535  1
    arc_2_16_21  in_degree_1566  1
    arc_2_16_21  original_T_including_depot_unload_1573  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1393  1
    load_2_16_21  free_load_conservation_1540  1
    load_2_16_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1395  -30
    arc_2_17_0  depot_return_or_bypass_1501  1
    arc_2_17_0  out_degree_1541  1
    arc_2_17_0  original_T_including_depot_unload_1573  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1395  1
    load_2_17_0  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1396  -30
    arc_2_17_11  connected_order_arc_1397  -12
    arc_2_17_11  in_degree_1503  1
    arc_2_17_11  out_degree_1541  1
    arc_2_17_11  original_T_including_depot_unload_1573  1.6813024470003036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1396  1
    load_2_17_11  segment_load_conservation_1506  -1
    load_2_17_11  segment_prefix_lb_1507  1
    load_2_17_11  segment_prefix_ub_1508  1
    load_2_17_11  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1398  -30
    arc_2_17_12  connected_order_arc_1399  -12
    arc_2_17_12  in_degree_1510  1
    arc_2_17_12  out_degree_1541  1
    arc_2_17_12  original_T_including_depot_unload_1573  2.2684160167710820e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1398  1
    load_2_17_12  segment_load_conservation_1513  -1
    load_2_17_12  segment_prefix_lb_1514  1
    load_2_17_12  segment_prefix_ub_1515  1
    load_2_17_12  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1400  -30
    arc_2_17_13  connected_order_arc_1401  -12
    arc_2_17_13  in_degree_1517  1
    arc_2_17_13  out_degree_1541  1
    arc_2_17_13  original_T_including_depot_unload_1573  2.2831577662501127e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1400  1
    load_2_17_13  segment_load_conservation_1520  -1
    load_2_17_13  segment_prefix_lb_1521  1
    load_2_17_13  segment_prefix_ub_1522  1
    load_2_17_13  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1402  -30
    arc_2_17_14  connected_order_arc_1403  -12
    arc_2_17_14  in_degree_1524  1
    arc_2_17_14  out_degree_1541  1
    arc_2_17_14  original_T_including_depot_unload_1573  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1402  1
    load_2_17_14  free_load_conservation_1528  -1
    load_2_17_14  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1404  -30
    arc_2_17_15  connected_order_arc_1405  -12
    arc_2_17_15  in_degree_1530  1
    arc_2_17_15  out_degree_1541  1
    arc_2_17_15  original_T_including_depot_unload_1573  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1404  1
    load_2_17_15  free_load_conservation_1534  -1
    load_2_17_15  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1406  -30
    arc_2_17_16  connected_order_arc_1407  -12
    arc_2_17_16  in_degree_1536  1
    arc_2_17_16  out_degree_1541  1
    arc_2_17_16  original_T_including_depot_unload_1573  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1406  1
    load_2_17_16  free_load_conservation_1540  -1
    load_2_17_16  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1408  -30
    arc_2_17_18  connected_order_arc_1409  -12
    arc_2_17_18  out_degree_1541  1
    arc_2_17_18  in_degree_1548  1
    arc_2_17_18  original_T_including_depot_unload_1573  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1408  1
    load_2_17_18  free_load_conservation_1546  1
    load_2_17_18  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1410  -30
    arc_2_17_19  connected_order_arc_1411  -12
    arc_2_17_19  out_degree_1541  1
    arc_2_17_19  in_degree_1554  1
    arc_2_17_19  original_T_including_depot_unload_1573  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1410  1
    load_2_17_19  free_load_conservation_1546  1
    load_2_17_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1412  -30
    arc_2_17_20  connected_order_arc_1413  -12
    arc_2_17_20  out_degree_1541  1
    arc_2_17_20  in_degree_1560  1
    arc_2_17_20  original_T_including_depot_unload_1573  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1412  1
    load_2_17_20  free_load_conservation_1546  1
    load_2_17_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1414  -30
    arc_2_17_21  connected_order_arc_1415  -12
    arc_2_17_21  out_degree_1541  1
    arc_2_17_21  in_degree_1566  1
    arc_2_17_21  original_T_including_depot_unload_1573  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1414  1
    load_2_17_21  free_load_conservation_1546  1
    load_2_17_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1416  -30
    arc_2_18_0  depot_return_or_bypass_1501  1
    arc_2_18_0  out_degree_1547  1
    arc_2_18_0  original_T_including_depot_unload_1573  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1416  1
    load_2_18_0  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1417  -30
    arc_2_18_11  connected_order_arc_1418  -12
    arc_2_18_11  in_degree_1503  1
    arc_2_18_11  out_degree_1547  1
    arc_2_18_11  original_T_including_depot_unload_1573  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1417  1
    load_2_18_11  segment_load_conservation_1506  -1
    load_2_18_11  segment_prefix_lb_1507  1
    load_2_18_11  segment_prefix_ub_1508  1
    load_2_18_11  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1419  -30
    arc_2_18_12  connected_order_arc_1420  -12
    arc_2_18_12  in_degree_1510  1
    arc_2_18_12  out_degree_1547  1
    arc_2_18_12  original_T_including_depot_unload_1573  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1419  1
    load_2_18_12  segment_load_conservation_1513  -1
    load_2_18_12  segment_prefix_lb_1514  1
    load_2_18_12  segment_prefix_ub_1515  1
    load_2_18_12  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1421  -30
    arc_2_18_13  connected_order_arc_1422  -12
    arc_2_18_13  in_degree_1517  1
    arc_2_18_13  out_degree_1547  1
    arc_2_18_13  original_T_including_depot_unload_1573  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1421  1
    load_2_18_13  segment_load_conservation_1520  -1
    load_2_18_13  segment_prefix_lb_1521  1
    load_2_18_13  segment_prefix_ub_1522  1
    load_2_18_13  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1423  -30
    arc_2_18_14  connected_order_arc_1424  -12
    arc_2_18_14  in_degree_1524  1
    arc_2_18_14  out_degree_1547  1
    arc_2_18_14  original_T_including_depot_unload_1573  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1423  1
    load_2_18_14  free_load_conservation_1528  -1
    load_2_18_14  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1425  -30
    arc_2_18_15  connected_order_arc_1426  -12
    arc_2_18_15  in_degree_1530  1
    arc_2_18_15  out_degree_1547  1
    arc_2_18_15  original_T_including_depot_unload_1573  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1425  1
    load_2_18_15  free_load_conservation_1534  -1
    load_2_18_15  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1427  -30
    arc_2_18_16  connected_order_arc_1428  -12
    arc_2_18_16  in_degree_1536  1
    arc_2_18_16  out_degree_1547  1
    arc_2_18_16  original_T_including_depot_unload_1573  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1427  1
    load_2_18_16  free_load_conservation_1540  -1
    load_2_18_16  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1429  -30
    arc_2_18_17  connected_order_arc_1430  -12
    arc_2_18_17  in_degree_1542  1
    arc_2_18_17  out_degree_1547  1
    arc_2_18_17  original_T_including_depot_unload_1573  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1429  1
    load_2_18_17  free_load_conservation_1546  -1
    load_2_18_17  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1431  -30
    arc_2_18_19  connected_order_arc_1432  -12
    arc_2_18_19  out_degree_1547  1
    arc_2_18_19  in_degree_1554  1
    arc_2_18_19  original_T_including_depot_unload_1573  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1431  1
    load_2_18_19  free_load_conservation_1552  1
    load_2_18_19  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1433  -30
    arc_2_18_20  connected_order_arc_1434  -12
    arc_2_18_20  out_degree_1547  1
    arc_2_18_20  in_degree_1560  1
    arc_2_18_20  original_T_including_depot_unload_1573  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1433  1
    load_2_18_20  free_load_conservation_1552  1
    load_2_18_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1435  -30
    arc_2_18_21  connected_order_arc_1436  -12
    arc_2_18_21  out_degree_1547  1
    arc_2_18_21  in_degree_1566  1
    arc_2_18_21  original_T_including_depot_unload_1573  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1435  1
    load_2_18_21  free_load_conservation_1552  1
    load_2_18_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1437  -30
    arc_2_19_0  depot_return_or_bypass_1501  1
    arc_2_19_0  out_degree_1553  1
    arc_2_19_0  original_T_including_depot_unload_1573  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1437  1
    load_2_19_0  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1438  -30
    arc_2_19_11  connected_order_arc_1439  -12
    arc_2_19_11  in_degree_1503  1
    arc_2_19_11  out_degree_1553  1
    arc_2_19_11  original_T_including_depot_unload_1573  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1438  1
    load_2_19_11  segment_load_conservation_1506  -1
    load_2_19_11  segment_prefix_lb_1507  1
    load_2_19_11  segment_prefix_ub_1508  1
    load_2_19_11  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1440  -30
    arc_2_19_12  connected_order_arc_1441  -12
    arc_2_19_12  in_degree_1510  1
    arc_2_19_12  out_degree_1553  1
    arc_2_19_12  original_T_including_depot_unload_1573  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1440  1
    load_2_19_12  segment_load_conservation_1513  -1
    load_2_19_12  segment_prefix_lb_1514  1
    load_2_19_12  segment_prefix_ub_1515  1
    load_2_19_12  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1442  -30
    arc_2_19_13  connected_order_arc_1443  -12
    arc_2_19_13  in_degree_1517  1
    arc_2_19_13  out_degree_1553  1
    arc_2_19_13  original_T_including_depot_unload_1573  2.5820660682901439e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1442  1
    load_2_19_13  segment_load_conservation_1520  -1
    load_2_19_13  segment_prefix_lb_1521  1
    load_2_19_13  segment_prefix_ub_1522  1
    load_2_19_13  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1444  -30
    arc_2_19_14  connected_order_arc_1445  -12
    arc_2_19_14  in_degree_1524  1
    arc_2_19_14  out_degree_1553  1
    arc_2_19_14  original_T_including_depot_unload_1573  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1444  1
    load_2_19_14  free_load_conservation_1528  -1
    load_2_19_14  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1446  -30
    arc_2_19_15  connected_order_arc_1447  -12
    arc_2_19_15  in_degree_1530  1
    arc_2_19_15  out_degree_1553  1
    arc_2_19_15  original_T_including_depot_unload_1573  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1446  1
    load_2_19_15  free_load_conservation_1534  -1
    load_2_19_15  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1448  -30
    arc_2_19_16  connected_order_arc_1449  -12
    arc_2_19_16  in_degree_1536  1
    arc_2_19_16  out_degree_1553  1
    arc_2_19_16  original_T_including_depot_unload_1573  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1448  1
    load_2_19_16  free_load_conservation_1540  -1
    load_2_19_16  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1450  -30
    arc_2_19_17  connected_order_arc_1451  -12
    arc_2_19_17  in_degree_1542  1
    arc_2_19_17  out_degree_1553  1
    arc_2_19_17  original_T_including_depot_unload_1573  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1450  1
    load_2_19_17  free_load_conservation_1546  -1
    load_2_19_17  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1452  -30
    arc_2_19_18  connected_order_arc_1453  -12
    arc_2_19_18  in_degree_1548  1
    arc_2_19_18  out_degree_1553  1
    arc_2_19_18  original_T_including_depot_unload_1573  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1452  1
    load_2_19_18  free_load_conservation_1552  -1
    load_2_19_18  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1454  -30
    arc_2_19_20  connected_order_arc_1455  -12
    arc_2_19_20  out_degree_1553  1
    arc_2_19_20  in_degree_1560  1
    arc_2_19_20  original_T_including_depot_unload_1573  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1454  1
    load_2_19_20  free_load_conservation_1558  1
    load_2_19_20  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1456  -30
    arc_2_19_21  connected_order_arc_1457  -12
    arc_2_19_21  out_degree_1553  1
    arc_2_19_21  in_degree_1566  1
    arc_2_19_21  original_T_including_depot_unload_1573  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1456  1
    load_2_19_21  free_load_conservation_1558  1
    load_2_19_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1458  -30
    arc_2_20_0  depot_return_or_bypass_1501  1
    arc_2_20_0  out_degree_1559  1
    arc_2_20_0  original_T_including_depot_unload_1573  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1458  1
    load_2_20_0  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1459  -30
    arc_2_20_11  connected_order_arc_1460  -12
    arc_2_20_11  in_degree_1503  1
    arc_2_20_11  out_degree_1559  1
    arc_2_20_11  original_T_including_depot_unload_1573  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1459  1
    load_2_20_11  segment_load_conservation_1506  -1
    load_2_20_11  segment_prefix_lb_1507  1
    load_2_20_11  segment_prefix_ub_1508  1
    load_2_20_11  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1461  -30
    arc_2_20_12  connected_order_arc_1462  -12
    arc_2_20_12  in_degree_1510  1
    arc_2_20_12  out_degree_1559  1
    arc_2_20_12  original_T_including_depot_unload_1573  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1461  1
    load_2_20_12  segment_load_conservation_1513  -1
    load_2_20_12  segment_prefix_lb_1514  1
    load_2_20_12  segment_prefix_ub_1515  1
    load_2_20_12  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1463  -30
    arc_2_20_13  connected_order_arc_1464  -12
    arc_2_20_13  in_degree_1517  1
    arc_2_20_13  out_degree_1559  1
    arc_2_20_13  original_T_including_depot_unload_1573  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1463  1
    load_2_20_13  segment_load_conservation_1520  -1
    load_2_20_13  segment_prefix_lb_1521  1
    load_2_20_13  segment_prefix_ub_1522  1
    load_2_20_13  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1465  -30
    arc_2_20_14  connected_order_arc_1466  -12
    arc_2_20_14  in_degree_1524  1
    arc_2_20_14  out_degree_1559  1
    arc_2_20_14  original_T_including_depot_unload_1573  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1465  1
    load_2_20_14  free_load_conservation_1528  -1
    load_2_20_14  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1467  -30
    arc_2_20_15  connected_order_arc_1468  -12
    arc_2_20_15  in_degree_1530  1
    arc_2_20_15  out_degree_1559  1
    arc_2_20_15  original_T_including_depot_unload_1573  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1467  1
    load_2_20_15  free_load_conservation_1534  -1
    load_2_20_15  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1469  -30
    arc_2_20_16  connected_order_arc_1470  -12
    arc_2_20_16  in_degree_1536  1
    arc_2_20_16  out_degree_1559  1
    arc_2_20_16  original_T_including_depot_unload_1573  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1469  1
    load_2_20_16  free_load_conservation_1540  -1
    load_2_20_16  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1471  -30
    arc_2_20_17  connected_order_arc_1472  -12
    arc_2_20_17  in_degree_1542  1
    arc_2_20_17  out_degree_1559  1
    arc_2_20_17  original_T_including_depot_unload_1573  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1471  1
    load_2_20_17  free_load_conservation_1546  -1
    load_2_20_17  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1473  -30
    arc_2_20_18  connected_order_arc_1474  -12
    arc_2_20_18  in_degree_1548  1
    arc_2_20_18  out_degree_1559  1
    arc_2_20_18  original_T_including_depot_unload_1573  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1473  1
    load_2_20_18  free_load_conservation_1552  -1
    load_2_20_18  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1475  -30
    arc_2_20_19  connected_order_arc_1476  -12
    arc_2_20_19  in_degree_1554  1
    arc_2_20_19  out_degree_1559  1
    arc_2_20_19  original_T_including_depot_unload_1573  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1475  1
    load_2_20_19  free_load_conservation_1558  -1
    load_2_20_19  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1477  -30
    arc_2_20_21  connected_order_arc_1478  -12
    arc_2_20_21  out_degree_1559  1
    arc_2_20_21  in_degree_1566  1
    arc_2_20_21  original_T_including_depot_unload_1573  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1477  1
    load_2_20_21  free_load_conservation_1564  1
    load_2_20_21  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1479  -30
    arc_2_21_0  depot_return_or_bypass_1501  1
    arc_2_21_0  out_degree_1565  1
    arc_2_21_0  original_T_including_depot_unload_1573  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1479  1
    load_2_21_0  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1480  -30
    arc_2_21_11  connected_order_arc_1481  -12
    arc_2_21_11  in_degree_1503  1
    arc_2_21_11  out_degree_1565  1
    arc_2_21_11  original_T_including_depot_unload_1573  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1480  1
    load_2_21_11  segment_load_conservation_1506  -1
    load_2_21_11  segment_prefix_lb_1507  1
    load_2_21_11  segment_prefix_ub_1508  1
    load_2_21_11  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1482  -30
    arc_2_21_12  connected_order_arc_1483  -12
    arc_2_21_12  in_degree_1510  1
    arc_2_21_12  out_degree_1565  1
    arc_2_21_12  original_T_including_depot_unload_1573  2.1566797920965496e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1482  1
    load_2_21_12  segment_load_conservation_1513  -1
    load_2_21_12  segment_prefix_lb_1514  1
    load_2_21_12  segment_prefix_ub_1515  1
    load_2_21_12  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1484  -30
    arc_2_21_13  connected_order_arc_1485  -12
    arc_2_21_13  in_degree_1517  1
    arc_2_21_13  out_degree_1565  1
    arc_2_21_13  original_T_including_depot_unload_1573  2.1729620766552225e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1484  1
    load_2_21_13  segment_load_conservation_1520  -1
    load_2_21_13  segment_prefix_lb_1521  1
    load_2_21_13  segment_prefix_ub_1522  1
    load_2_21_13  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1486  -30
    arc_2_21_14  connected_order_arc_1487  -12
    arc_2_21_14  in_degree_1524  1
    arc_2_21_14  out_degree_1565  1
    arc_2_21_14  original_T_including_depot_unload_1573  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1486  1
    load_2_21_14  free_load_conservation_1528  -1
    load_2_21_14  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1488  -30
    arc_2_21_15  connected_order_arc_1489  -12
    arc_2_21_15  in_degree_1530  1
    arc_2_21_15  out_degree_1565  1
    arc_2_21_15  original_T_including_depot_unload_1573  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1488  1
    load_2_21_15  free_load_conservation_1534  -1
    load_2_21_15  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1490  -30
    arc_2_21_16  connected_order_arc_1491  -12
    arc_2_21_16  in_degree_1536  1
    arc_2_21_16  out_degree_1565  1
    arc_2_21_16  original_T_including_depot_unload_1573  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1490  1
    load_2_21_16  free_load_conservation_1540  -1
    load_2_21_16  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1492  -30
    arc_2_21_17  connected_order_arc_1493  -12
    arc_2_21_17  in_degree_1542  1
    arc_2_21_17  out_degree_1565  1
    arc_2_21_17  original_T_including_depot_unload_1573  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1492  1
    load_2_21_17  free_load_conservation_1546  -1
    load_2_21_17  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1494  -30
    arc_2_21_18  connected_order_arc_1495  -12
    arc_2_21_18  in_degree_1548  1
    arc_2_21_18  out_degree_1565  1
    arc_2_21_18  original_T_including_depot_unload_1573  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1494  1
    load_2_21_18  free_load_conservation_1552  -1
    load_2_21_18  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1496  -30
    arc_2_21_19  connected_order_arc_1497  -12
    arc_2_21_19  in_degree_1554  1
    arc_2_21_19  out_degree_1565  1
    arc_2_21_19  original_T_including_depot_unload_1573  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1496  1
    load_2_21_19  free_load_conservation_1558  -1
    load_2_21_19  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1498  -30
    arc_2_21_20  connected_order_arc_1499  -12
    arc_2_21_20  in_degree_1560  1
    arc_2_21_20  out_degree_1565  1
    arc_2_21_20  original_T_including_depot_unload_1573  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1498  1
    load_2_21_20  free_load_conservation_1564  -1
    load_2_21_20  free_load_conservation_1570  1
RHS
    RHS1      OBJ       -2.7890522252863448e-01
    RHS1      onehot_5_32  1
    RHS1      onehot_7_67  1
    RHS1      onehot_34_102  1
    RHS1      onehot_6_123  1
    RHS1      onehot_22_158  1
    RHS1      onehot_3_187  1
    RHS1      onehot_27_204  1
    RHS1      onehot_8_233  1
    RHS1      stock_ub_237  32
    RHS1      parent_nonstrict_scope_238  2.9239893120797078e-01
    RHS1      normalization_295  1
    RHS1      connected_order_arc_412  -14
    RHS1      connected_order_arc_414  -14
    RHS1      connected_order_arc_416  -14
    RHS1      connected_order_arc_418  -14
    RHS1      connected_order_arc_420  -14
    RHS1      connected_order_arc_422  -14
    RHS1      connected_order_arc_424  -14
    RHS1      connected_order_arc_426  -14
    RHS1      connected_order_arc_428  -14
    RHS1      connected_order_arc_430  -14
    RHS1      connected_order_arc_432  -14
    RHS1      connected_order_arc_434  -14
    RHS1      connected_order_arc_436  -14
    RHS1      connected_order_arc_439  -14
    RHS1      connected_order_arc_441  -14
    RHS1      connected_order_arc_443  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_447  -14
    RHS1      connected_order_arc_449  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_453  -14
    RHS1      connected_order_arc_455  -14
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_474  -14
    RHS1      connected_order_arc_476  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_480  -14
    RHS1      connected_order_arc_482  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_501  -14
    RHS1      connected_order_arc_503  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_507  -14
    RHS1      connected_order_arc_509  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_528  -14
    RHS1      connected_order_arc_530  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_534  -14
    RHS1      connected_order_arc_536  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_555  -14
    RHS1      connected_order_arc_557  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_561  -14
    RHS1      connected_order_arc_563  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_582  -14
    RHS1      connected_order_arc_584  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_588  -14
    RHS1      connected_order_arc_590  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_609  -14
    RHS1      connected_order_arc_611  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_615  -14
    RHS1      connected_order_arc_617  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_636  -14
    RHS1      connected_order_arc_638  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_642  -14
    RHS1      connected_order_arc_644  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_663  -14
    RHS1      connected_order_arc_665  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_669  -14
    RHS1      connected_order_arc_671  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_690  -14
    RHS1      connected_order_arc_692  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_696  -14
    RHS1      connected_order_arc_698  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_717  -14
    RHS1      connected_order_arc_719  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_723  -14
    RHS1      connected_order_arc_725  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_736  -14
    RHS1      connected_order_arc_738  -14
    RHS1      connected_order_arc_740  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_744  -14
    RHS1      connected_order_arc_746  -14
    RHS1      connected_order_arc_748  -14
    RHS1      connected_order_arc_750  -14
    RHS1      connected_order_arc_752  -14
    RHS1      connected_order_arc_754  -14
    RHS1      connected_order_arc_756  -14
    RHS1      connected_order_arc_758  -14
    RHS1      connected_order_arc_760  -14
    RHS1      connected_order_arc_763  -14
    RHS1      connected_order_arc_765  -14
    RHS1      connected_order_arc_767  -14
    RHS1      connected_order_arc_769  -14
    RHS1      connected_order_arc_771  -14
    RHS1      connected_order_arc_773  -14
    RHS1      connected_order_arc_775  -14
    RHS1      connected_order_arc_777  -14
    RHS1      connected_order_arc_779  -14
    RHS1      connected_order_arc_781  -14
    RHS1      connected_order_arc_783  -14
    RHS1      connected_order_arc_785  -14
    RHS1      connected_order_arc_787  -14
    RHS1      depot_departure_or_bypass_788  1
    RHS1      depot_return_or_bypass_789  1
    RHS1      segment_load_conservation_794  4
    RHS1      segment_prefix_ub_796  16
    RHS1      segment_load_conservation_801  1
    RHS1      segment_prefix_ub_803  19
    RHS1      segment_load_conservation_808  -4
    RHS1      segment_prefix_lb_809  4
    RHS1      segment_prefix_ub_810  20
    RHS1      segment_load_conservation_815  -2
    RHS1      segment_prefix_lb_816  2
    RHS1      segment_prefix_ub_817  20
    RHS1      segment_load_conservation_822  1
    RHS1      segment_prefix_ub_824  19
    RHS1      segment_load_conservation_829  1
    RHS1      segment_prefix_ub_831  14
    RHS1      fixed_segment_relative_order_880  1
    RHS1      fixed_segment_relative_order_881  1
    RHS1      fixed_segment_relative_order_882  1
    RHS1      fixed_segment_relative_order_883  1
    RHS1      fixed_segment_relative_order_884  1
    RHS1      original_T_including_depot_unload_885  4.1205718147700072e+03
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1108  -12
    RHS1      connected_order_arc_1110  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1131  -12
    RHS1      connected_order_arc_1133  -12
    RHS1      connected_order_arc_1135  -12
    RHS1      connected_order_arc_1137  -12
    RHS1      connected_order_arc_1139  -12
    RHS1      connected_order_arc_1141  -12
    RHS1      connected_order_arc_1143  -12
    RHS1      connected_order_arc_1145  -12
    RHS1      connected_order_arc_1147  -12
    RHS1      connected_order_arc_1149  -12
    RHS1      connected_order_arc_1151  -12
    RHS1      connected_order_arc_1154  -12
    RHS1      connected_order_arc_1156  -12
    RHS1      connected_order_arc_1158  -12
    RHS1      connected_order_arc_1160  -12
    RHS1      connected_order_arc_1162  -12
    RHS1      connected_order_arc_1164  -12
    RHS1      connected_order_arc_1166  -12
    RHS1      connected_order_arc_1168  -12
    RHS1      connected_order_arc_1170  -12
    RHS1      connected_order_arc_1172  -12
    RHS1      connected_order_arc_1174  -12
    RHS1      depot_departure_or_bypass_1175  1
    RHS1      depot_return_or_bypass_1176  1
    RHS1      segment_load_conservation_1181  4
    RHS1      segment_prefix_ub_1183  20
    RHS1      segment_load_conservation_1188  5
    RHS1      segment_prefix_ub_1190  20
    RHS1      segment_load_conservation_1195  -4
    RHS1      segment_prefix_lb_1196  4
    RHS1      segment_prefix_ub_1197  25
    RHS1      segment_load_conservation_1202  -5
    RHS1      segment_prefix_lb_1203  5
    RHS1      segment_prefix_ub_1204  25
    RHS1      fixed_segment_relative_order_1253  1
    RHS1      fixed_segment_relative_order_1254  1
    RHS1      fixed_segment_relative_order_1255  1
    RHS1      original_T_including_depot_unload_1256  4.0180155701548429e+03
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1436  -11
    RHS1      connected_order_arc_1439  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1447  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1453  -11
    RHS1      connected_order_arc_1455  -11
    RHS1      connected_order_arc_1457  -11
    RHS1      connected_order_arc_1460  -11
    RHS1      connected_order_arc_1462  -11
    RHS1      connected_order_arc_1464  -11
    RHS1      connected_order_arc_1466  -11
    RHS1      connected_order_arc_1468  -11
    RHS1      connected_order_arc_1470  -11
    RHS1      connected_order_arc_1472  -11
    RHS1      connected_order_arc_1474  -11
    RHS1      connected_order_arc_1476  -11
    RHS1      connected_order_arc_1478  -11
    RHS1      connected_order_arc_1481  -11
    RHS1      connected_order_arc_1483  -11
    RHS1      connected_order_arc_1485  -11
    RHS1      connected_order_arc_1487  -11
    RHS1      connected_order_arc_1489  -11
    RHS1      connected_order_arc_1491  -11
    RHS1      connected_order_arc_1493  -11
    RHS1      connected_order_arc_1495  -11
    RHS1      connected_order_arc_1497  -11
    RHS1      connected_order_arc_1499  -11
    RHS1      depot_departure_or_bypass_1500  1
    RHS1      depot_return_or_bypass_1501  1
    RHS1      segment_load_conservation_1506  2
    RHS1      segment_prefix_ub_1508  28
    RHS1      segment_load_conservation_1513  2
    RHS1      segment_prefix_ub_1515  28
    RHS1      segment_load_conservation_1520  -3
    RHS1      segment_prefix_lb_1521  4
    RHS1      segment_prefix_ub_1522  30
    RHS1      fixed_segment_relative_order_1571  1
    RHS1      fixed_segment_relative_order_1572  1
    RHS1      original_T_including_depot_unload_1573  2.8031251453030341e+03
BOUNDS
 LO BND1      t         2.5358490566012373e-02
 UP BND1      t         4.3232115285684006e-02
 UP BND1      q         4.1816696950410492e-01
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.3232115285684006e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.3232115285684006e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.3232115285684006e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.3232115285684006e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.3232115285684006e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.3232115285684006e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.3232115285684006e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.3232115285684006e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.3232115285684006e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.3232115285684006e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.3232115285684006e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.3232115285684006e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.3232115285684006e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.3232115285684006e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.3232115285684006e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.3232115285684006e-02
 UP BND1      rho_5     1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.3232115285684006e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.3232115285684006e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.3232115285684006e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.3232115285684006e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.3232115285684006e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.3232115285684006e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.3232115285684006e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.3232115285684006e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.3232115285684006e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.3232115285684006e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.3232115285684006e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.3232115285684006e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.3232115285684006e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.3232115285684006e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.3232115285684006e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.3232115285684006e-02
 UP BND1      rho_7     1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.3232115285684006e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.3232115285684006e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.3232115285684006e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.3232115285684006e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.3232115285684006e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.3232115285684006e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.3232115285684006e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.3232115285684006e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.3232115285684006e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.3232115285684006e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.3232115285684006e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.3232115285684006e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.3232115285684006e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.3232115285684006e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.3232115285684006e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.3232115285684006e-02
 UP BND1      rho_34    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.3232115285684006e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.3232115285684006e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.3232115285684006e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.3232115285684006e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.3232115285684006e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.3232115285684006e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.3232115285684006e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.3232115285684006e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.3232115285684006e-02
 UP BND1      rho_6     1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.3232115285684006e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.3232115285684006e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.3232115285684006e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.3232115285684006e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.3232115285684006e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.3232115285684006e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.3232115285684006e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.3232115285684006e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.3232115285684006e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.3232115285684006e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.3232115285684006e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.3232115285684006e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.3232115285684006e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.3232115285684006e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.3232115285684006e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.3232115285684006e-02
 UP BND1      rho_22    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.3232115285684006e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.3232115285684006e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.3232115285684006e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.3232115285684006e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.3232115285684006e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.3232115285684006e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.3232115285684006e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.3232115285684006e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.3232115285684006e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.3232115285684006e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.3232115285684006e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.3232115285684006e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.3232115285684006e-02
 UP BND1      rho_3     1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.3232115285684006e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.3232115285684006e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.3232115285684006e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.3232115285684006e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.3232115285684006e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.3232115285684006e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.3232115285684006e-02
 UP BND1      rho_27    1
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.3232115285684006e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.3232115285684006e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.3232115285684006e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.3232115285684006e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.3232115285684006e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.3232115285684006e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.3232115285684006e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.3232115285684006e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.3232115285684006e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.3232115285684006e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.3232115285684006e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.3232115285684006e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.3232115285684006e-02
 UP BND1      rho_8     1
 UP BND1      a_5_7     1
 UP BND1      a_5_34    1
 UP BND1      a_5_6     1
 UP BND1      a_5_22    1
 UP BND1      a_5_3     1
 UP BND1      a_5_27    1
 UP BND1      a_5_8     1
 UP BND1      a_7_34    1
 UP BND1      a_7_6     1
 UP BND1      a_7_22    1
 UP BND1      a_7_3     1
 UP BND1      a_7_27    1
 UP BND1      a_7_8     1
 UP BND1      a_34_6    1
 UP BND1      a_34_22   1
 UP BND1      a_34_3    1
 UP BND1      a_34_27   1
 UP BND1      a_34_8    1
 UP BND1      a_6_22    1
 UP BND1      a_6_3     1
 UP BND1      a_6_27    1
 UP BND1      a_6_8     1
 UP BND1      a_22_3    1
 UP BND1      a_22_27   1
 UP BND1      a_22_8    1
 UP BND1      a_3_27    1
 UP BND1      a_3_8     1
 UP BND1      a_27_8    1
 BV BND1      service_0_5_0
 BV BND1      service_0_5_2
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_1_5_0
 BV BND1      service_1_5_2
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_2_5_0
 BV BND1      service_2_5_2
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_12
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_1_7_0
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_12
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_2_7_0
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_12
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_6_0
 BV BND1      service_0_6_1
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_1_6_0
 BV BND1      service_1_6_1
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_2_6_0
 BV BND1      service_2_6_1
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_12
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_12
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_12
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
