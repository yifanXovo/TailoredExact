* Signature: 0xe821085247bfe4b2
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_12_32
 E  normalized_mass_12_33
 E  normalized_ratio_12_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 E  onehot_11_67
 E  normalized_mass_11_68
 E  normalized_ratio_11_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 E  onehot_18_102
 E  normalized_mass_18_103
 E  normalized_ratio_18_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 E  onehot_9_109
 E  normalized_mass_9_110
 E  normalized_ratio_9_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_17_146
 E  normalized_mass_17_147
 E  normalized_ratio_17_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 E  onehot_10_153
 E  normalized_mass_10_154
 E  normalized_ratio_10_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 E  onehot_20_188
 E  normalized_mass_20_189
 E  normalized_ratio_20_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 E  onehot_7_213
 E  normalized_mass_7_214
 E  normalized_ratio_7_215
 G  stock_lb_216
 L  stock_ub_217
 L  parent_nonstrict_scope_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 E  normalization_275
 G  full_original_Gini_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 L  arc_capacity_365
 L  arc_capacity_366
 L  arc_capacity_367
 L  arc_capacity_368
 L  arc_capacity_369
 L  arc_capacity_370
 L  arc_capacity_371
 L  arc_capacity_372
 L  arc_capacity_373
 L  arc_capacity_374
 L  arc_capacity_375
 L  arc_capacity_376
 L  arc_capacity_377
 L  arc_capacity_378
 L  arc_capacity_379
 L  arc_capacity_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 E  depot_departure_or_bypass_758
 E  depot_return_or_bypass_759
 E  out_degree_760
 E  in_degree_761
 G  order_active_lb_762
 L  order_active_ub_763
 E  segment_load_conservation_764
 G  segment_prefix_lb_765
 L  segment_prefix_ub_766
 E  out_degree_767
 E  in_degree_768
 G  order_active_lb_769
 L  order_active_ub_770
 E  segment_load_conservation_771
 G  segment_prefix_lb_772
 L  segment_prefix_ub_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  segment_load_conservation_778
 G  segment_prefix_lb_779
 L  segment_prefix_ub_780
 E  out_degree_781
 E  in_degree_782
 G  order_active_lb_783
 L  order_active_ub_784
 E  segment_load_conservation_785
 G  segment_prefix_lb_786
 L  segment_prefix_ub_787
 E  out_degree_788
 E  in_degree_789
 G  order_active_lb_790
 L  order_active_ub_791
 E  segment_load_conservation_792
 G  segment_prefix_lb_793
 L  segment_prefix_ub_794
 E  out_degree_795
 E  in_degree_796
 G  order_active_lb_797
 L  order_active_ub_798
 E  segment_load_conservation_799
 G  segment_prefix_lb_800
 L  segment_prefix_ub_801
 E  out_degree_802
 E  in_degree_803
 G  order_active_lb_804
 L  order_active_ub_805
 E  service_visit_def_806
 E  free_load_conservation_807
 E  out_degree_808
 E  in_degree_809
 G  order_active_lb_810
 L  order_active_ub_811
 E  service_visit_def_812
 E  free_load_conservation_813
 E  out_degree_814
 E  in_degree_815
 G  order_active_lb_816
 L  order_active_ub_817
 E  service_visit_def_818
 E  free_load_conservation_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  service_visit_def_824
 E  free_load_conservation_825
 E  out_degree_826
 E  in_degree_827
 G  order_active_lb_828
 L  order_active_ub_829
 E  service_visit_def_830
 E  free_load_conservation_831
 E  out_degree_832
 E  in_degree_833
 G  order_active_lb_834
 L  order_active_ub_835
 E  service_visit_def_836
 E  free_load_conservation_837
 E  out_degree_838
 E  in_degree_839
 G  order_active_lb_840
 L  order_active_ub_841
 E  service_visit_def_842
 E  free_load_conservation_843
 E  out_degree_844
 E  in_degree_845
 G  order_active_lb_846
 L  order_active_ub_847
 E  service_visit_def_848
 E  free_load_conservation_849
 G  fixed_segment_relative_order_850
 G  fixed_segment_relative_order_851
 G  fixed_segment_relative_order_852
 G  fixed_segment_relative_order_853
 G  fixed_segment_relative_order_854
 L  original_T_including_depot_unload_855
 L  arc_capacity_856
 L  arc_capacity_857
 L  arc_capacity_858
 L  arc_capacity_859
 L  arc_capacity_860
 L  arc_capacity_861
 L  arc_capacity_862
 L  arc_capacity_863
 L  arc_capacity_864
 L  arc_capacity_865
 L  arc_capacity_866
 L  arc_capacity_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 E  depot_departure_or_bypass_1057
 E  depot_return_or_bypass_1058
 E  out_degree_1059
 E  in_degree_1060
 G  order_active_lb_1061
 L  order_active_ub_1062
 E  segment_load_conservation_1063
 G  segment_prefix_lb_1064
 L  segment_prefix_ub_1065
 E  out_degree_1066
 E  in_degree_1067
 G  order_active_lb_1068
 L  order_active_ub_1069
 E  segment_load_conservation_1070
 G  segment_prefix_lb_1071
 L  segment_prefix_ub_1072
 E  out_degree_1073
 E  in_degree_1074
 G  order_active_lb_1075
 L  order_active_ub_1076
 E  service_visit_def_1077
 E  free_load_conservation_1078
 E  out_degree_1079
 E  in_degree_1080
 G  order_active_lb_1081
 L  order_active_ub_1082
 E  service_visit_def_1083
 E  free_load_conservation_1084
 E  out_degree_1085
 E  in_degree_1086
 G  order_active_lb_1087
 L  order_active_ub_1088
 E  service_visit_def_1089
 E  free_load_conservation_1090
 E  out_degree_1091
 E  in_degree_1092
 G  order_active_lb_1093
 L  order_active_ub_1094
 E  service_visit_def_1095
 E  free_load_conservation_1096
 E  out_degree_1097
 E  in_degree_1098
 G  order_active_lb_1099
 L  order_active_ub_1100
 E  service_visit_def_1101
 E  free_load_conservation_1102
 E  out_degree_1103
 E  in_degree_1104
 G  order_active_lb_1105
 L  order_active_ub_1106
 E  service_visit_def_1107
 E  free_load_conservation_1108
 E  out_degree_1109
 E  in_degree_1110
 G  order_active_lb_1111
 L  order_active_ub_1112
 E  service_visit_def_1113
 E  free_load_conservation_1114
 E  out_degree_1115
 E  in_degree_1116
 G  order_active_lb_1117
 L  order_active_ub_1118
 E  service_visit_def_1119
 E  free_load_conservation_1120
 G  fixed_segment_relative_order_1121
 L  original_T_including_depot_unload_1122
COLUMNS
    t         normalized_mass_12_33  -1
    t         normalized_mass_11_68  -1
    t         normalized_mass_18_103  -1
    t         normalized_mass_9_110  -1
    t         normalized_mass_17_147  -1
    t         normalized_mass_10_154  -1
    t         normalized_mass_20_189  -1
    t         normalized_mass_7_214  -1
    t         normalization_275  8.5535714285714288e+00
    t         full_original_Gini_276  -3.1232142857142858e+01
    q         OBJ       1
    q         parent_nonstrict_scope_218  1
    q         full_original_Gini_276  20
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_0  -4.4708595759735285e-02
    x_12_0    product_ub_1  -1.1691022964521088e-01
    x_12_0    onehot_12_32  1
    x_12_0    parent_nonstrict_scope_218  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_0  1
    w_12_0    product_ub_1  1
    w_12_0    normalized_mass_12_33  1
    w_12_0    full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_2  -4.4708595759735285e-02
    x_12_1    product_ub_3  -1.1691022964521088e-01
    x_12_1    onehot_12_32  1
    x_12_1    stock_lb_216  1
    x_12_1    stock_ub_217  1
    x_12_1    parent_nonstrict_scope_218  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_2  1
    w_12_1    product_ub_3  1
    w_12_1    normalized_mass_12_33  1
    w_12_1    normalized_ratio_12_34  -1.4285714285714285e-01
    w_12_1    full_original_Gini_276  -7.6964285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_4  -4.4708595759735285e-02
    x_12_2    product_ub_5  -1.1691022964521088e-01
    x_12_2    onehot_12_32  1
    x_12_2    stock_lb_216  2
    x_12_2    stock_ub_217  2
    x_12_2    parent_nonstrict_scope_218  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_4  1
    w_12_2    product_ub_5  1
    w_12_2    normalized_mass_12_33  1
    w_12_2    normalized_ratio_12_34  -2.8571428571428570e-01
    w_12_2    full_original_Gini_276  -6.8392857142857153e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_6  -4.4708595759735285e-02
    x_12_3    product_ub_7  -1.1691022964521088e-01
    x_12_3    onehot_12_32  1
    x_12_3    stock_lb_216  3
    x_12_3    stock_ub_217  3
    x_12_3    parent_nonstrict_scope_218  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_6  1
    w_12_3    product_ub_7  1
    w_12_3    normalized_mass_12_33  1
    w_12_3    normalized_ratio_12_34  -4.2857142857142855e-01
    w_12_3    full_original_Gini_276  -5.9821428571428568e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_8  -4.4708595759735285e-02
    x_12_4    product_ub_9  -1.1691022964521088e-01
    x_12_4    onehot_12_32  1
    x_12_4    stock_lb_216  4
    x_12_4    stock_ub_217  4
    x_12_4    parent_nonstrict_scope_218  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_8  1
    w_12_4    product_ub_9  1
    w_12_4    normalized_mass_12_33  1
    w_12_4    normalized_ratio_12_34  -5.7142857142857140e-01
    w_12_4    full_original_Gini_276  -5.4107142857142856e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_10  -4.4708595759735285e-02
    x_12_5    product_ub_11  -1.1691022964521088e-01
    x_12_5    onehot_12_32  1
    x_12_5    stock_lb_216  5
    x_12_5    stock_ub_217  5
    x_12_5    parent_nonstrict_scope_218  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_10  1
    w_12_5    product_ub_11  1
    w_12_5    normalized_mass_12_33  1
    w_12_5    normalized_ratio_12_34  -7.1428571428571419e-01
    w_12_5    full_original_Gini_276  -4.8392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_12  -4.4708595759735285e-02
    x_12_6    product_ub_13  -1.1691022964521088e-01
    x_12_6    onehot_12_32  1
    x_12_6    stock_lb_216  6
    x_12_6    stock_ub_217  6
    x_12_6    parent_nonstrict_scope_218  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_12  1
    w_12_6    product_ub_13  1
    w_12_6    normalized_mass_12_33  1
    w_12_6    normalized_ratio_12_34  -8.5714285714285710e-01
    w_12_6    full_original_Gini_276  -4.2678571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_14  -4.4708595759735285e-02
    x_12_7    product_ub_15  -1.1691022964521088e-01
    x_12_7    onehot_12_32  1
    x_12_7    stock_lb_216  7
    x_12_7    stock_ub_217  7
    x_12_7    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_14  1
    w_12_7    product_ub_15  1
    w_12_7    normalized_mass_12_33  1
    w_12_7    normalized_ratio_12_34  -1
    w_12_7    full_original_Gini_276  -3.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_16  -4.4708595759735285e-02
    x_12_8    product_ub_17  -1.1691022964521088e-01
    x_12_8    onehot_12_32  1
    x_12_8    stock_lb_216  8
    x_12_8    stock_ub_217  8
    x_12_8    parent_nonstrict_scope_218  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_16  1
    w_12_8    product_ub_17  1
    w_12_8    normalized_mass_12_33  1
    w_12_8    normalized_ratio_12_34  -1.1428571428571428e+00
    w_12_8    full_original_Gini_276  -5.1607142857142847e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_18  -4.4708595759735285e-02
    x_12_9    product_ub_19  -1.1691022964521088e-01
    x_12_9    onehot_12_32  1
    x_12_9    stock_lb_216  9
    x_12_9    stock_ub_217  9
    x_12_9    parent_nonstrict_scope_218  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_18  1
    w_12_9    product_ub_19  1
    w_12_9    normalized_mass_12_33  1
    w_12_9    normalized_ratio_12_34  -1.2857142857142856e+00
    w_12_9    full_original_Gini_276  -6.8749999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_20  -4.4708595759735285e-02
    x_12_10   product_ub_21  -1.1691022964521088e-01
    x_12_10   onehot_12_32  1
    x_12_10   stock_lb_216  10
    x_12_10   stock_ub_217  10
    x_12_10   parent_nonstrict_scope_218  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_20  1
    w_12_10   product_ub_21  1
    w_12_10   normalized_mass_12_33  1
    w_12_10   normalized_ratio_12_34  -1.4285714285714284e+00
    w_12_10   full_original_Gini_276  -8.5892857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_22  -4.4708595759735285e-02
    x_12_11   product_ub_23  -1.1691022964521088e-01
    x_12_11   onehot_12_32  1
    x_12_11   stock_lb_216  11
    x_12_11   stock_ub_217  11
    x_12_11   parent_nonstrict_scope_218  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_22  1
    w_12_11   product_ub_23  1
    w_12_11   normalized_mass_12_33  1
    w_12_11   normalized_ratio_12_34  -1.5714285714285714e+00
    w_12_11   full_original_Gini_276  -1.0303571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_24  -4.4708595759735285e-02
    x_12_12   product_ub_25  -1.1691022964521088e-01
    x_12_12   onehot_12_32  1
    x_12_12   stock_lb_216  12
    x_12_12   stock_ub_217  12
    x_12_12   parent_nonstrict_scope_218  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_24  1
    w_12_12   product_ub_25  1
    w_12_12   normalized_mass_12_33  1
    w_12_12   normalized_ratio_12_34  -1.7142857142857142e+00
    w_12_12   full_original_Gini_276  -1.2017857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_26  -4.4708595759735285e-02
    x_12_13   product_ub_27  -1.1691022964521088e-01
    x_12_13   onehot_12_32  1
    x_12_13   stock_lb_216  13
    x_12_13   stock_ub_217  13
    x_12_13   parent_nonstrict_scope_218  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_26  1
    w_12_13   product_ub_27  1
    w_12_13   normalized_mass_12_33  1
    w_12_13   normalized_ratio_12_34  -1.8571428571428570e+00
    w_12_13   full_original_Gini_276  -1.3732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_28  -4.4708595759735285e-02
    x_12_14   product_ub_29  -1.1691022964521088e-01
    x_12_14   onehot_12_32  1
    x_12_14   stock_lb_216  14
    x_12_14   stock_ub_217  14
    x_12_14   parent_nonstrict_scope_218  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_28  1
    w_12_14   product_ub_29  1
    w_12_14   normalized_mass_12_33  1
    w_12_14   normalized_ratio_12_34  -2
    w_12_14   full_original_Gini_276  -1.5446428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_30  -4.4708595759735285e-02
    x_12_15   product_ub_31  -1.1691022964521088e-01
    x_12_15   onehot_12_32  1
    x_12_15   stock_lb_216  15
    x_12_15   stock_ub_217  15
    x_12_15   parent_nonstrict_scope_218  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_30  1
    w_12_15   product_ub_31  1
    w_12_15   normalized_mass_12_33  1
    w_12_15   normalized_ratio_12_34  -2.1428571428571428e+00
    w_12_15   full_original_Gini_276  -1.7160714285714281e+01
    rho_12    normalized_ratio_12_34  1
    rho_12    block_pair_pos_243  -1
    rho_12    block_pair_neg_244  1
    rho_12    block_pair_pos_245  -1
    rho_12    block_pair_neg_246  1
    rho_12    block_pair_pos_247  -1
    rho_12    block_pair_neg_248  1
    rho_12    block_pair_pos_249  -1
    rho_12    block_pair_neg_250  1
    rho_12    block_pair_pos_251  -1
    rho_12    block_pair_neg_252  1
    rho_12    block_pair_pos_253  -1
    rho_12    block_pair_neg_254  1
    rho_12    block_pair_pos_255  -1
    rho_12    block_pair_neg_256  1
    rho_12    normalization_275  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_35  -4.4708595759735285e-02
    x_11_0    product_ub_36  -1.1691022964521088e-01
    x_11_0    onehot_11_67  1
    x_11_0    parent_nonstrict_scope_218  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_35  1
    w_11_0    product_ub_36  1
    w_11_0    normalized_mass_11_68  1
    w_11_0    full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_37  -4.4708595759735285e-02
    x_11_1    product_ub_38  -1.1691022964521088e-01
    x_11_1    onehot_11_67  1
    x_11_1    stock_lb_216  1
    x_11_1    stock_ub_217  1
    x_11_1    parent_nonstrict_scope_218  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_37  1
    w_11_1    product_ub_38  1
    w_11_1    normalized_mass_11_68  1
    w_11_1    normalized_ratio_11_69  -0.125
    w_11_1    full_original_Gini_276  -7.8035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_39  -4.4708595759735285e-02
    x_11_2    product_ub_40  -1.1691022964521088e-01
    x_11_2    onehot_11_67  1
    x_11_2    stock_lb_216  2
    x_11_2    stock_ub_217  2
    x_11_2    parent_nonstrict_scope_218  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_39  1
    w_11_2    product_ub_40  1
    w_11_2    normalized_mass_11_68  1
    w_11_2    normalized_ratio_11_69  -0.25
    w_11_2    full_original_Gini_276  -7.0535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_41  -4.4708595759735285e-02
    x_11_3    product_ub_42  -1.1691022964521088e-01
    x_11_3    onehot_11_67  1
    x_11_3    stock_lb_216  3
    x_11_3    stock_ub_217  3
    x_11_3    parent_nonstrict_scope_218  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_41  1
    w_11_3    product_ub_42  1
    w_11_3    normalized_mass_11_68  1
    w_11_3    normalized_ratio_11_69  -0.375
    w_11_3    full_original_Gini_276  -6.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_43  -4.4708595759735285e-02
    x_11_4    product_ub_44  -1.1691022964521088e-01
    x_11_4    onehot_11_67  1
    x_11_4    stock_lb_216  4
    x_11_4    stock_ub_217  4
    x_11_4    parent_nonstrict_scope_218  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_43  1
    w_11_4    product_ub_44  1
    w_11_4    normalized_mass_11_68  1
    w_11_4    normalized_ratio_11_69  -0.5
    w_11_4    full_original_Gini_276  -5.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_45  -4.4708595759735285e-02
    x_11_5    product_ub_46  -1.1691022964521088e-01
    x_11_5    onehot_11_67  1
    x_11_5    stock_lb_216  5
    x_11_5    stock_ub_217  5
    x_11_5    parent_nonstrict_scope_218  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_45  1
    w_11_5    product_ub_46  1
    w_11_5    normalized_mass_11_68  1
    w_11_5    normalized_ratio_11_69  -0.625
    w_11_5    full_original_Gini_276  -5.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_47  -4.4708595759735285e-02
    x_11_6    product_ub_48  -1.1691022964521088e-01
    x_11_6    onehot_11_67  1
    x_11_6    stock_lb_216  6
    x_11_6    stock_ub_217  6
    x_11_6    parent_nonstrict_scope_218  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_47  1
    w_11_6    product_ub_48  1
    w_11_6    normalized_mass_11_68  1
    w_11_6    normalized_ratio_11_69  -0.75
    w_11_6    full_original_Gini_276  -4.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_49  -4.4708595759735285e-02
    x_11_7    product_ub_50  -1.1691022964521088e-01
    x_11_7    onehot_11_67  1
    x_11_7    stock_lb_216  7
    x_11_7    stock_ub_217  7
    x_11_7    parent_nonstrict_scope_218  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_49  1
    w_11_7    product_ub_50  1
    w_11_7    normalized_mass_11_68  1
    w_11_7    normalized_ratio_11_69  -0.875
    w_11_7    full_original_Gini_276  -4.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_51  -4.4708595759735285e-02
    x_11_8    product_ub_52  -1.1691022964521088e-01
    x_11_8    onehot_11_67  1
    x_11_8    stock_lb_216  8
    x_11_8    stock_ub_217  8
    x_11_8    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_51  1
    w_11_8    product_ub_52  1
    w_11_8    normalized_mass_11_68  1
    w_11_8    normalized_ratio_11_69  -1
    w_11_8    full_original_Gini_276  -3.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_53  -4.4708595759735285e-02
    x_11_9    product_ub_54  -1.1691022964521088e-01
    x_11_9    onehot_11_67  1
    x_11_9    stock_lb_216  9
    x_11_9    stock_ub_217  9
    x_11_9    parent_nonstrict_scope_218  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_53  1
    w_11_9    product_ub_54  1
    w_11_9    normalized_mass_11_68  1
    w_11_9    normalized_ratio_11_69  -1.125
    w_11_9    full_original_Gini_276  -4.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_55  -4.4708595759735285e-02
    x_11_10   product_ub_56  -1.1691022964521088e-01
    x_11_10   onehot_11_67  1
    x_11_10   stock_lb_216  10
    x_11_10   stock_ub_217  10
    x_11_10   parent_nonstrict_scope_218  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_55  1
    w_11_10   product_ub_56  1
    w_11_10   normalized_mass_11_68  1
    w_11_10   normalized_ratio_11_69  -1.25
    w_11_10   full_original_Gini_276  -6.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_57  -4.4708595759735285e-02
    x_11_11   product_ub_58  -1.1691022964521088e-01
    x_11_11   onehot_11_67  1
    x_11_11   stock_lb_216  11
    x_11_11   stock_ub_217  11
    x_11_11   parent_nonstrict_scope_218  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_57  1
    w_11_11   product_ub_58  1
    w_11_11   normalized_mass_11_68  1
    w_11_11   normalized_ratio_11_69  -1.375
    w_11_11   full_original_Gini_276  -7.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_59  -4.4708595759735285e-02
    x_11_12   product_ub_60  -1.1691022964521088e-01
    x_11_12   onehot_11_67  1
    x_11_12   stock_lb_216  12
    x_11_12   stock_ub_217  12
    x_11_12   parent_nonstrict_scope_218  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_59  1
    w_11_12   product_ub_60  1
    w_11_12   normalized_mass_11_68  1
    w_11_12   normalized_ratio_11_69  -1.5
    w_11_12   full_original_Gini_276  -9.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_61  -4.4708595759735285e-02
    x_11_13   product_ub_62  -1.1691022964521088e-01
    x_11_13   onehot_11_67  1
    x_11_13   stock_lb_216  13
    x_11_13   stock_ub_217  13
    x_11_13   parent_nonstrict_scope_218  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_61  1
    w_11_13   product_ub_62  1
    w_11_13   normalized_mass_11_68  1
    w_11_13   normalized_ratio_11_69  -1.625
    w_11_13   full_original_Gini_276  -1.0946428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_63  -4.4708595759735285e-02
    x_11_14   product_ub_64  -1.1691022964521088e-01
    x_11_14   onehot_11_67  1
    x_11_14   stock_lb_216  14
    x_11_14   stock_ub_217  14
    x_11_14   parent_nonstrict_scope_218  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_63  1
    w_11_14   product_ub_64  1
    w_11_14   normalized_mass_11_68  1
    w_11_14   normalized_ratio_11_69  -1.75
    w_11_14   full_original_Gini_276  -1.2446428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_65  -4.4708595759735285e-02
    x_11_15   product_ub_66  -1.1691022964521088e-01
    x_11_15   onehot_11_67  1
    x_11_15   stock_lb_216  15
    x_11_15   stock_ub_217  15
    x_11_15   parent_nonstrict_scope_218  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_65  1
    w_11_15   product_ub_66  1
    w_11_15   normalized_mass_11_68  1
    w_11_15   normalized_ratio_11_69  -1.875
    w_11_15   full_original_Gini_276  -1.3946428571428571e+01
    rho_11    normalized_ratio_11_69  1
    rho_11    block_pair_pos_231  -1
    rho_11    block_pair_neg_232  1
    rho_11    block_pair_pos_233  -1
    rho_11    block_pair_neg_234  1
    rho_11    block_pair_pos_235  -1
    rho_11    block_pair_neg_236  1
    rho_11    block_pair_pos_237  -1
    rho_11    block_pair_neg_238  1
    rho_11    block_pair_pos_239  -1
    rho_11    block_pair_neg_240  1
    rho_11    block_pair_pos_241  -1
    rho_11    block_pair_neg_242  1
    rho_11    block_pair_pos_249  1
    rho_11    block_pair_neg_250  -1
    rho_11    normalization_275  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_70  -4.4708595759735285e-02
    x_18_0    product_ub_71  -1.1691022964521088e-01
    x_18_0    onehot_18_102  1
    x_18_0    parent_nonstrict_scope_218  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_70  1
    w_18_0    product_ub_71  1
    w_18_0    normalized_mass_18_103  1
    w_18_0    full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_72  -4.4708595759735285e-02
    x_18_1    product_ub_73  -1.1691022964521088e-01
    x_18_1    onehot_18_102  1
    x_18_1    stock_lb_216  1
    x_18_1    stock_ub_217  1
    x_18_1    parent_nonstrict_scope_218  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_72  1
    w_18_1    product_ub_73  1
    w_18_1    normalized_mass_18_103  1
    w_18_1    normalized_ratio_18_104  -1.4285714285714285e-01
    w_18_1    full_original_Gini_276  -7.6964285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_74  -4.4708595759735285e-02
    x_18_2    product_ub_75  -1.1691022964521088e-01
    x_18_2    onehot_18_102  1
    x_18_2    stock_lb_216  2
    x_18_2    stock_ub_217  2
    x_18_2    parent_nonstrict_scope_218  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_74  1
    w_18_2    product_ub_75  1
    w_18_2    normalized_mass_18_103  1
    w_18_2    normalized_ratio_18_104  -2.8571428571428570e-01
    w_18_2    full_original_Gini_276  -6.8392857142857153e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_76  -4.4708595759735285e-02
    x_18_3    product_ub_77  -1.1691022964521088e-01
    x_18_3    onehot_18_102  1
    x_18_3    stock_lb_216  3
    x_18_3    stock_ub_217  3
    x_18_3    parent_nonstrict_scope_218  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_76  1
    w_18_3    product_ub_77  1
    w_18_3    normalized_mass_18_103  1
    w_18_3    normalized_ratio_18_104  -4.2857142857142855e-01
    w_18_3    full_original_Gini_276  -5.9821428571428568e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_78  -4.4708595759735285e-02
    x_18_4    product_ub_79  -1.1691022964521088e-01
    x_18_4    onehot_18_102  1
    x_18_4    stock_lb_216  4
    x_18_4    stock_ub_217  4
    x_18_4    parent_nonstrict_scope_218  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_78  1
    w_18_4    product_ub_79  1
    w_18_4    normalized_mass_18_103  1
    w_18_4    normalized_ratio_18_104  -5.7142857142857140e-01
    w_18_4    full_original_Gini_276  -5.4107142857142856e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_80  -4.4708595759735285e-02
    x_18_5    product_ub_81  -1.1691022964521088e-01
    x_18_5    onehot_18_102  1
    x_18_5    stock_lb_216  5
    x_18_5    stock_ub_217  5
    x_18_5    parent_nonstrict_scope_218  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_80  1
    w_18_5    product_ub_81  1
    w_18_5    normalized_mass_18_103  1
    w_18_5    normalized_ratio_18_104  -7.1428571428571419e-01
    w_18_5    full_original_Gini_276  -4.8392857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_82  -4.4708595759735285e-02
    x_18_6    product_ub_83  -1.1691022964521088e-01
    x_18_6    onehot_18_102  1
    x_18_6    stock_lb_216  6
    x_18_6    stock_ub_217  6
    x_18_6    parent_nonstrict_scope_218  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_82  1
    w_18_6    product_ub_83  1
    w_18_6    normalized_mass_18_103  1
    w_18_6    normalized_ratio_18_104  -8.5714285714285710e-01
    w_18_6    full_original_Gini_276  -4.2678571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_84  -4.4708595759735285e-02
    x_18_7    product_ub_85  -1.1691022964521088e-01
    x_18_7    onehot_18_102  1
    x_18_7    stock_lb_216  7
    x_18_7    stock_ub_217  7
    x_18_7    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_84  1
    w_18_7    product_ub_85  1
    w_18_7    normalized_mass_18_103  1
    w_18_7    normalized_ratio_18_104  -1
    w_18_7    full_original_Gini_276  -3.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_86  -4.4708595759735285e-02
    x_18_8    product_ub_87  -1.1691022964521088e-01
    x_18_8    onehot_18_102  1
    x_18_8    stock_lb_216  8
    x_18_8    stock_ub_217  8
    x_18_8    parent_nonstrict_scope_218  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_86  1
    w_18_8    product_ub_87  1
    w_18_8    normalized_mass_18_103  1
    w_18_8    normalized_ratio_18_104  -1.1428571428571428e+00
    w_18_8    full_original_Gini_276  -5.1607142857142847e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_88  -4.4708595759735285e-02
    x_18_9    product_ub_89  -1.1691022964521088e-01
    x_18_9    onehot_18_102  1
    x_18_9    stock_lb_216  9
    x_18_9    stock_ub_217  9
    x_18_9    parent_nonstrict_scope_218  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_88  1
    w_18_9    product_ub_89  1
    w_18_9    normalized_mass_18_103  1
    w_18_9    normalized_ratio_18_104  -1.2857142857142856e+00
    w_18_9    full_original_Gini_276  -6.8749999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_90  -4.4708595759735285e-02
    x_18_10   product_ub_91  -1.1691022964521088e-01
    x_18_10   onehot_18_102  1
    x_18_10   stock_lb_216  10
    x_18_10   stock_ub_217  10
    x_18_10   parent_nonstrict_scope_218  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_90  1
    w_18_10   product_ub_91  1
    w_18_10   normalized_mass_18_103  1
    w_18_10   normalized_ratio_18_104  -1.4285714285714284e+00
    w_18_10   full_original_Gini_276  -8.5892857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_92  -4.4708595759735285e-02
    x_18_11   product_ub_93  -1.1691022964521088e-01
    x_18_11   onehot_18_102  1
    x_18_11   stock_lb_216  11
    x_18_11   stock_ub_217  11
    x_18_11   parent_nonstrict_scope_218  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_92  1
    w_18_11   product_ub_93  1
    w_18_11   normalized_mass_18_103  1
    w_18_11   normalized_ratio_18_104  -1.5714285714285714e+00
    w_18_11   full_original_Gini_276  -1.0303571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_94  -4.4708595759735285e-02
    x_18_12   product_ub_95  -1.1691022964521088e-01
    x_18_12   onehot_18_102  1
    x_18_12   stock_lb_216  12
    x_18_12   stock_ub_217  12
    x_18_12   parent_nonstrict_scope_218  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_94  1
    w_18_12   product_ub_95  1
    w_18_12   normalized_mass_18_103  1
    w_18_12   normalized_ratio_18_104  -1.7142857142857142e+00
    w_18_12   full_original_Gini_276  -1.2017857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_96  -4.4708595759735285e-02
    x_18_13   product_ub_97  -1.1691022964521088e-01
    x_18_13   onehot_18_102  1
    x_18_13   stock_lb_216  13
    x_18_13   stock_ub_217  13
    x_18_13   parent_nonstrict_scope_218  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_96  1
    w_18_13   product_ub_97  1
    w_18_13   normalized_mass_18_103  1
    w_18_13   normalized_ratio_18_104  -1.8571428571428570e+00
    w_18_13   full_original_Gini_276  -1.3732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_98  -4.4708595759735285e-02
    x_18_14   product_ub_99  -1.1691022964521088e-01
    x_18_14   onehot_18_102  1
    x_18_14   stock_lb_216  14
    x_18_14   stock_ub_217  14
    x_18_14   parent_nonstrict_scope_218  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_98  1
    w_18_14   product_ub_99  1
    w_18_14   normalized_mass_18_103  1
    w_18_14   normalized_ratio_18_104  -2
    w_18_14   full_original_Gini_276  -1.5446428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_100  -4.4708595759735285e-02
    x_18_15   product_ub_101  -1.1691022964521088e-01
    x_18_15   onehot_18_102  1
    x_18_15   stock_lb_216  15
    x_18_15   stock_ub_217  15
    x_18_15   parent_nonstrict_scope_218  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_100  1
    w_18_15   product_ub_101  1
    w_18_15   normalized_mass_18_103  1
    w_18_15   normalized_ratio_18_104  -2.1428571428571428e+00
    w_18_15   full_original_Gini_276  -1.7160714285714281e+01
    rho_18    normalized_ratio_18_104  1
    rho_18    block_pair_pos_239  1
    rho_18    block_pair_neg_240  -1
    rho_18    block_pair_pos_253  1
    rho_18    block_pair_neg_254  -1
    rho_18    block_pair_pos_263  -1
    rho_18    block_pair_neg_264  1
    rho_18    block_pair_pos_265  -1
    rho_18    block_pair_neg_266  1
    rho_18    block_pair_pos_267  -1
    rho_18    block_pair_neg_268  1
    rho_18    block_pair_pos_269  -1
    rho_18    block_pair_neg_270  1
    rho_18    block_pair_pos_271  -1
    rho_18    block_pair_neg_272  1
    rho_18    normalization_275  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       6.3380304899829966e-03
    x_9_0     product_lb_105  -4.4708595759735285e-02
    x_9_0     product_ub_106  -1.1691022964521088e-01
    x_9_0     onehot_9_109  1
    x_9_0     parent_nonstrict_scope_218  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_105  1
    w_9_0     product_ub_106  1
    w_9_0     normalized_mass_9_110  1
    w_9_0     full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       -6.3380304899829966e-03
    x_9_1     product_lb_107  -4.4708595759735285e-02
    x_9_1     product_ub_108  -1.1691022964521088e-01
    x_9_1     onehot_9_109  1
    x_9_1     stock_lb_216  1
    x_9_1     stock_ub_217  1
    x_9_1     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_107  1
    w_9_1     product_ub_108  1
    w_9_1     normalized_mass_9_110  1
    w_9_1     normalized_ratio_9_111  -1
    w_9_1     full_original_Gini_276  -3.6964285714285712e+00
    rho_9     normalized_ratio_9_111  1
    rho_9     block_pair_pos_219  -1
    rho_9     block_pair_neg_220  1
    rho_9     block_pair_pos_221  -1
    rho_9     block_pair_neg_222  1
    rho_9     block_pair_pos_223  -1
    rho_9     block_pair_neg_224  1
    rho_9     block_pair_pos_225  -1
    rho_9     block_pair_neg_226  1
    rho_9     block_pair_pos_233  1
    rho_9     block_pair_neg_234  -1
    rho_9     block_pair_pos_245  1
    rho_9     block_pair_neg_246  -1
    rho_9     block_pair_pos_265  1
    rho_9     block_pair_neg_266  -1
    rho_9     normalization_275  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_112  -4.4708595759735285e-02
    x_17_0    product_ub_113  -1.1691022964521088e-01
    x_17_0    onehot_17_146  1
    x_17_0    parent_nonstrict_scope_218  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_112  1
    w_17_0    product_ub_113  1
    w_17_0    normalized_mass_17_147  1
    w_17_0    full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_114  -4.4708595759735285e-02
    x_17_1    product_ub_115  -1.1691022964521088e-01
    x_17_1    onehot_17_146  1
    x_17_1    stock_lb_216  1
    x_17_1    stock_ub_217  1
    x_17_1    parent_nonstrict_scope_218  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_114  1
    w_17_1    product_ub_115  1
    w_17_1    normalized_mass_17_147  1
    w_17_1    normalized_ratio_17_148  -1.1111111111111110e-01
    w_17_1    full_original_Gini_276  -7.8869047619047610e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_116  -4.4708595759735285e-02
    x_17_2    product_ub_117  -1.1691022964521088e-01
    x_17_2    onehot_17_146  1
    x_17_2    stock_lb_216  2
    x_17_2    stock_ub_217  2
    x_17_2    parent_nonstrict_scope_218  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_116  1
    w_17_2    product_ub_117  1
    w_17_2    normalized_mass_17_147  1
    w_17_2    normalized_ratio_17_148  -2.2222222222222221e-01
    w_17_2    full_original_Gini_276  -7.2202380952380949e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_118  -4.4708595759735285e-02
    x_17_3    product_ub_119  -1.1691022964521088e-01
    x_17_3    onehot_17_146  1
    x_17_3    stock_lb_216  3
    x_17_3    stock_ub_217  3
    x_17_3    parent_nonstrict_scope_218  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_118  1
    w_17_3    product_ub_119  1
    w_17_3    normalized_mass_17_147  1
    w_17_3    normalized_ratio_17_148  -3.3333333333333331e-01
    w_17_3    full_original_Gini_276  -6.55357142857143
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_120  -4.4708595759735285e-02
    x_17_4    product_ub_121  -1.1691022964521088e-01
    x_17_4    onehot_17_146  1
    x_17_4    stock_lb_216  4
    x_17_4    stock_ub_217  4
    x_17_4    parent_nonstrict_scope_218  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_120  1
    w_17_4    product_ub_121  1
    w_17_4    normalized_mass_17_147  1
    w_17_4    normalized_ratio_17_148  -4.4444444444444442e-01
    w_17_4    full_original_Gini_276  -5.9186507936507935e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_122  -4.4708595759735285e-02
    x_17_5    product_ub_123  -1.1691022964521088e-01
    x_17_5    onehot_17_146  1
    x_17_5    stock_lb_216  5
    x_17_5    stock_ub_217  5
    x_17_5    parent_nonstrict_scope_218  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_122  1
    w_17_5    product_ub_123  1
    w_17_5    normalized_mass_17_147  1
    w_17_5    normalized_ratio_17_148  -5.5555555555555558e-01
    w_17_5    full_original_Gini_276  -5.4742063492063489e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_124  -4.4708595759735285e-02
    x_17_6    product_ub_125  -1.1691022964521088e-01
    x_17_6    onehot_17_146  1
    x_17_6    stock_lb_216  6
    x_17_6    stock_ub_217  6
    x_17_6    parent_nonstrict_scope_218  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_124  1
    w_17_6    product_ub_125  1
    w_17_6    normalized_mass_17_147  1
    w_17_6    normalized_ratio_17_148  -6.6666666666666663e-01
    w_17_6    full_original_Gini_276  -5.0297619047619051e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_126  -4.4708595759735285e-02
    x_17_7    product_ub_127  -1.1691022964521088e-01
    x_17_7    onehot_17_146  1
    x_17_7    stock_lb_216  7
    x_17_7    stock_ub_217  7
    x_17_7    parent_nonstrict_scope_218  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_126  1
    w_17_7    product_ub_127  1
    w_17_7    normalized_mass_17_147  1
    w_17_7    normalized_ratio_17_148  -7.7777777777777768e-01
    w_17_7    full_original_Gini_276  -4.5853174603174605e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_128  -4.4708595759735285e-02
    x_17_8    product_ub_129  -1.1691022964521088e-01
    x_17_8    onehot_17_146  1
    x_17_8    stock_lb_216  8
    x_17_8    stock_ub_217  8
    x_17_8    parent_nonstrict_scope_218  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_128  1
    w_17_8    product_ub_129  1
    w_17_8    normalized_mass_17_147  1
    w_17_8    normalized_ratio_17_148  -8.8888888888888884e-01
    w_17_8    full_original_Gini_276  -4.1408730158730158e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_130  -4.4708595759735285e-02
    x_17_9    product_ub_131  -1.1691022964521088e-01
    x_17_9    onehot_17_146  1
    x_17_9    stock_lb_216  9
    x_17_9    stock_ub_217  9
    x_17_9    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_130  1
    w_17_9    product_ub_131  1
    w_17_9    normalized_mass_17_147  1
    w_17_9    normalized_ratio_17_148  -1
    w_17_9    full_original_Gini_276  -3.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_132  -4.4708595759735285e-02
    x_17_10   product_ub_133  -1.1691022964521088e-01
    x_17_10   onehot_17_146  1
    x_17_10   stock_lb_216  10
    x_17_10   stock_ub_217  10
    x_17_10   parent_nonstrict_scope_218  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_132  1
    w_17_10   product_ub_133  1
    w_17_10   normalized_mass_17_147  1
    w_17_10   normalized_ratio_17_148  -1.1111111111111112e+00
    w_17_10   full_original_Gini_276  -4.8075396825396837e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_134  -4.4708595759735285e-02
    x_17_11   product_ub_135  -1.1691022964521088e-01
    x_17_11   onehot_17_146  1
    x_17_11   stock_lb_216  11
    x_17_11   stock_ub_217  11
    x_17_11   parent_nonstrict_scope_218  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_134  1
    w_17_11   product_ub_135  1
    w_17_11   normalized_mass_17_147  1
    w_17_11   normalized_ratio_17_148  -1.2222222222222221e+00
    w_17_11   full_original_Gini_276  -6.1130952380952372e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_136  -4.4708595759735285e-02
    x_17_12   product_ub_137  -1.1691022964521088e-01
    x_17_12   onehot_17_146  1
    x_17_12   stock_lb_216  12
    x_17_12   stock_ub_217  12
    x_17_12   parent_nonstrict_scope_218  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_136  1
    w_17_12   product_ub_137  1
    w_17_12   normalized_mass_17_147  1
    w_17_12   normalized_ratio_17_148  -1.3333333333333333e+00
    w_17_12   full_original_Gini_276  -7.4464285714285694e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_138  -4.4708595759735285e-02
    x_17_13   product_ub_139  -1.1691022964521088e-01
    x_17_13   onehot_17_146  1
    x_17_13   stock_lb_216  13
    x_17_13   stock_ub_217  13
    x_17_13   parent_nonstrict_scope_218  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_138  1
    w_17_13   product_ub_139  1
    w_17_13   normalized_mass_17_147  1
    w_17_13   normalized_ratio_17_148  -1.4444444444444444e+00
    w_17_13   full_original_Gini_276  -8.7797619047619051e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_140  -4.4708595759735285e-02
    x_17_14   product_ub_141  -1.1691022964521088e-01
    x_17_14   onehot_17_146  1
    x_17_14   stock_lb_216  14
    x_17_14   stock_ub_217  14
    x_17_14   parent_nonstrict_scope_218  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_140  1
    w_17_14   product_ub_141  1
    w_17_14   normalized_mass_17_147  1
    w_17_14   normalized_ratio_17_148  -1.5555555555555554e+00
    w_17_14   full_original_Gini_276  -1.0113095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_142  -4.4708595759735285e-02
    x_17_15   product_ub_143  -1.1691022964521088e-01
    x_17_15   onehot_17_146  1
    x_17_15   stock_lb_216  15
    x_17_15   stock_ub_217  15
    x_17_15   parent_nonstrict_scope_218  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_142  1
    w_17_15   product_ub_143  1
    w_17_15   normalized_mass_17_147  1
    w_17_15   normalized_ratio_17_148  -1.6666666666666665e+00
    w_17_15   full_original_Gini_276  -1.1446428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_144  -4.4708595759735285e-02
    x_17_16   product_ub_145  -1.1691022964521088e-01
    x_17_16   onehot_17_146  1
    x_17_16   stock_lb_216  16
    x_17_16   stock_ub_217  16
    x_17_16   parent_nonstrict_scope_218  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_144  1
    w_17_16   product_ub_145  1
    w_17_16   normalized_mass_17_147  1
    w_17_16   normalized_ratio_17_148  -1.7777777777777777e+00
    w_17_16   full_original_Gini_276  -1.2779761904761905e+01
    rho_17    normalized_ratio_17_148  1
    rho_17    block_pair_pos_223  1
    rho_17    block_pair_neg_224  -1
    rho_17    block_pair_pos_237  1
    rho_17    block_pair_neg_238  -1
    rho_17    block_pair_pos_251  1
    rho_17    block_pair_neg_252  -1
    rho_17    block_pair_pos_257  -1
    rho_17    block_pair_neg_258  1
    rho_17    block_pair_pos_259  -1
    rho_17    block_pair_neg_260  1
    rho_17    block_pair_pos_261  -1
    rho_17    block_pair_neg_262  1
    rho_17    block_pair_pos_269  1
    rho_17    block_pair_neg_270  -1
    rho_17    normalization_275  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       6.3380304899829966e-03
    x_10_0    product_lb_149  -4.4708595759735285e-02
    x_10_0    product_ub_150  -1.1691022964521088e-01
    x_10_0    onehot_10_153  1
    x_10_0    parent_nonstrict_scope_218  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_149  1
    w_10_0    product_ub_150  1
    w_10_0    normalized_mass_10_154  1
    w_10_0    full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       -6.3380304899829966e-03
    x_10_1    product_lb_151  -4.4708595759735285e-02
    x_10_1    product_ub_152  -1.1691022964521088e-01
    x_10_1    onehot_10_153  1
    x_10_1    stock_lb_216  1
    x_10_1    stock_ub_217  1
    x_10_1    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_151  1
    w_10_1    product_ub_152  1
    w_10_1    normalized_mass_10_154  1
    w_10_1    normalized_ratio_10_155  -1
    w_10_1    full_original_Gini_276  -3.6964285714285712e+00
    rho_10    normalized_ratio_10_155  1
    rho_10    block_pair_pos_221  1
    rho_10    block_pair_neg_222  -1
    rho_10    block_pair_pos_227  -1
    rho_10    block_pair_neg_228  1
    rho_10    block_pair_pos_229  -1
    rho_10    block_pair_neg_230  1
    rho_10    block_pair_pos_235  1
    rho_10    block_pair_neg_236  -1
    rho_10    block_pair_pos_247  1
    rho_10    block_pair_neg_248  -1
    rho_10    block_pair_pos_259  1
    rho_10    block_pair_neg_260  -1
    rho_10    block_pair_pos_267  1
    rho_10    block_pair_neg_268  -1
    rho_10    normalization_275  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_156  -4.4708595759735285e-02
    x_20_0    product_ub_157  -1.1691022964521088e-01
    x_20_0    onehot_20_188  1
    x_20_0    parent_nonstrict_scope_218  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_156  1
    w_20_0    product_ub_157  1
    w_20_0    normalized_mass_20_189  1
    w_20_0    full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_158  -4.4708595759735285e-02
    x_20_1    product_ub_159  -1.1691022964521088e-01
    x_20_1    onehot_20_188  1
    x_20_1    stock_lb_216  1
    x_20_1    stock_ub_217  1
    x_20_1    parent_nonstrict_scope_218  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_158  1
    w_20_1    product_ub_159  1
    w_20_1    normalized_mass_20_189  1
    w_20_1    normalized_ratio_20_190  -0.125
    w_20_1    full_original_Gini_276  -7.8035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_160  -4.4708595759735285e-02
    x_20_2    product_ub_161  -1.1691022964521088e-01
    x_20_2    onehot_20_188  1
    x_20_2    stock_lb_216  2
    x_20_2    stock_ub_217  2
    x_20_2    parent_nonstrict_scope_218  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_160  1
    w_20_2    product_ub_161  1
    w_20_2    normalized_mass_20_189  1
    w_20_2    normalized_ratio_20_190  -0.25
    w_20_2    full_original_Gini_276  -7.0535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_162  -4.4708595759735285e-02
    x_20_3    product_ub_163  -1.1691022964521088e-01
    x_20_3    onehot_20_188  1
    x_20_3    stock_lb_216  3
    x_20_3    stock_ub_217  3
    x_20_3    parent_nonstrict_scope_218  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_162  1
    w_20_3    product_ub_163  1
    w_20_3    normalized_mass_20_189  1
    w_20_3    normalized_ratio_20_190  -0.375
    w_20_3    full_original_Gini_276  -6.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_164  -4.4708595759735285e-02
    x_20_4    product_ub_165  -1.1691022964521088e-01
    x_20_4    onehot_20_188  1
    x_20_4    stock_lb_216  4
    x_20_4    stock_ub_217  4
    x_20_4    parent_nonstrict_scope_218  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_164  1
    w_20_4    product_ub_165  1
    w_20_4    normalized_mass_20_189  1
    w_20_4    normalized_ratio_20_190  -0.5
    w_20_4    full_original_Gini_276  -5.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_166  -4.4708595759735285e-02
    x_20_5    product_ub_167  -1.1691022964521088e-01
    x_20_5    onehot_20_188  1
    x_20_5    stock_lb_216  5
    x_20_5    stock_ub_217  5
    x_20_5    parent_nonstrict_scope_218  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_166  1
    w_20_5    product_ub_167  1
    w_20_5    normalized_mass_20_189  1
    w_20_5    normalized_ratio_20_190  -0.625
    w_20_5    full_original_Gini_276  -5.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_168  -4.4708595759735285e-02
    x_20_6    product_ub_169  -1.1691022964521088e-01
    x_20_6    onehot_20_188  1
    x_20_6    stock_lb_216  6
    x_20_6    stock_ub_217  6
    x_20_6    parent_nonstrict_scope_218  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_168  1
    w_20_6    product_ub_169  1
    w_20_6    normalized_mass_20_189  1
    w_20_6    normalized_ratio_20_190  -0.75
    w_20_6    full_original_Gini_276  -4.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_170  -4.4708595759735285e-02
    x_20_7    product_ub_171  -1.1691022964521088e-01
    x_20_7    onehot_20_188  1
    x_20_7    stock_lb_216  7
    x_20_7    stock_ub_217  7
    x_20_7    parent_nonstrict_scope_218  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_170  1
    w_20_7    product_ub_171  1
    w_20_7    normalized_mass_20_189  1
    w_20_7    normalized_ratio_20_190  -0.875
    w_20_7    full_original_Gini_276  -4.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_172  -4.4708595759735285e-02
    x_20_8    product_ub_173  -1.1691022964521088e-01
    x_20_8    onehot_20_188  1
    x_20_8    stock_lb_216  8
    x_20_8    stock_ub_217  8
    x_20_8    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_172  1
    w_20_8    product_ub_173  1
    w_20_8    normalized_mass_20_189  1
    w_20_8    normalized_ratio_20_190  -1
    w_20_8    full_original_Gini_276  -3.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_174  -4.4708595759735285e-02
    x_20_9    product_ub_175  -1.1691022964521088e-01
    x_20_9    onehot_20_188  1
    x_20_9    stock_lb_216  9
    x_20_9    stock_ub_217  9
    x_20_9    parent_nonstrict_scope_218  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_174  1
    w_20_9    product_ub_175  1
    w_20_9    normalized_mass_20_189  1
    w_20_9    normalized_ratio_20_190  -1.125
    w_20_9    full_original_Gini_276  -4.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_176  -4.4708595759735285e-02
    x_20_10   product_ub_177  -1.1691022964521088e-01
    x_20_10   onehot_20_188  1
    x_20_10   stock_lb_216  10
    x_20_10   stock_ub_217  10
    x_20_10   parent_nonstrict_scope_218  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_176  1
    w_20_10   product_ub_177  1
    w_20_10   normalized_mass_20_189  1
    w_20_10   normalized_ratio_20_190  -1.25
    w_20_10   full_original_Gini_276  -6.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_178  -4.4708595759735285e-02
    x_20_11   product_ub_179  -1.1691022964521088e-01
    x_20_11   onehot_20_188  1
    x_20_11   stock_lb_216  11
    x_20_11   stock_ub_217  11
    x_20_11   parent_nonstrict_scope_218  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_178  1
    w_20_11   product_ub_179  1
    w_20_11   normalized_mass_20_189  1
    w_20_11   normalized_ratio_20_190  -1.375
    w_20_11   full_original_Gini_276  -7.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_180  -4.4708595759735285e-02
    x_20_12   product_ub_181  -1.1691022964521088e-01
    x_20_12   onehot_20_188  1
    x_20_12   stock_lb_216  12
    x_20_12   stock_ub_217  12
    x_20_12   parent_nonstrict_scope_218  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_180  1
    w_20_12   product_ub_181  1
    w_20_12   normalized_mass_20_189  1
    w_20_12   normalized_ratio_20_190  -1.5
    w_20_12   full_original_Gini_276  -9.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_182  -4.4708595759735285e-02
    x_20_13   product_ub_183  -1.1691022964521088e-01
    x_20_13   onehot_20_188  1
    x_20_13   stock_lb_216  13
    x_20_13   stock_ub_217  13
    x_20_13   parent_nonstrict_scope_218  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_182  1
    w_20_13   product_ub_183  1
    w_20_13   normalized_mass_20_189  1
    w_20_13   normalized_ratio_20_190  -1.625
    w_20_13   full_original_Gini_276  -1.0946428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_184  -4.4708595759735285e-02
    x_20_14   product_ub_185  -1.1691022964521088e-01
    x_20_14   onehot_20_188  1
    x_20_14   stock_lb_216  14
    x_20_14   stock_ub_217  14
    x_20_14   parent_nonstrict_scope_218  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_184  1
    w_20_14   product_ub_185  1
    w_20_14   normalized_mass_20_189  1
    w_20_14   normalized_ratio_20_190  -1.75
    w_20_14   full_original_Gini_276  -1.2446428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_186  -4.4708595759735285e-02
    x_20_15   product_ub_187  -1.1691022964521088e-01
    x_20_15   onehot_20_188  1
    x_20_15   stock_lb_216  15
    x_20_15   stock_ub_217  15
    x_20_15   parent_nonstrict_scope_218  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_186  1
    w_20_15   product_ub_187  1
    w_20_15   normalized_mass_20_189  1
    w_20_15   normalized_ratio_20_190  -1.875
    w_20_15   full_original_Gini_276  -1.3946428571428571e+01
    rho_20    normalized_ratio_20_190  1
    rho_20    block_pair_pos_225  1
    rho_20    block_pair_neg_226  -1
    rho_20    block_pair_pos_229  1
    rho_20    block_pair_neg_230  -1
    rho_20    block_pair_pos_241  1
    rho_20    block_pair_neg_242  -1
    rho_20    block_pair_pos_255  1
    rho_20    block_pair_neg_256  -1
    rho_20    block_pair_pos_261  1
    rho_20    block_pair_neg_262  -1
    rho_20    block_pair_pos_271  1
    rho_20    block_pair_neg_272  -1
    rho_20    block_pair_pos_273  -1
    rho_20    block_pair_neg_274  1
    rho_20    normalization_275  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       1.9561824064893318e-02
    x_7_0     product_lb_191  -4.4708595759735285e-02
    x_7_0     product_ub_192  -1.1691022964521088e-01
    x_7_0     onehot_7_213  1
    x_7_0     parent_nonstrict_scope_218  3.9123648129786637e-02
    x_7_0     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_191  1
    w_7_0     product_ub_192  1
    w_7_0     normalized_mass_7_214  1
    w_7_0     full_original_Gini_276  -8.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       1.1737094438935995e-02
    x_7_1     product_lb_193  -4.4708595759735285e-02
    x_7_1     product_ub_194  -1.1691022964521088e-01
    x_7_1     onehot_7_213  1
    x_7_1     stock_lb_216  1
    x_7_1     stock_ub_217  1
    x_7_1     parent_nonstrict_scope_218  3.1298918503829314e-02
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_193  1
    w_7_1     product_ub_194  1
    w_7_1     normalized_mass_7_214  1
    w_7_1     normalized_ratio_7_215  -0.2
    w_7_1     full_original_Gini_276  -7.3535714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       3.9123648129786616e-03
    x_7_2     product_lb_195  -4.4708595759735285e-02
    x_7_2     product_ub_196  -1.1691022964521088e-01
    x_7_2     onehot_7_213  1
    x_7_2     stock_lb_216  2
    x_7_2     stock_ub_217  2
    x_7_2     parent_nonstrict_scope_218  2.3474188877871980e-02
    x_7_2     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_195  1
    w_7_2     product_ub_196  1
    w_7_2     normalized_mass_7_214  1
    w_7_2     normalized_ratio_7_215  -0.4
    w_7_2     full_original_Gini_276  -6.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       -3.9123648129786685e-03
    x_7_3     product_lb_197  -4.4708595759735285e-02
    x_7_3     product_ub_198  -1.1691022964521088e-01
    x_7_3     onehot_7_213  1
    x_7_3     stock_lb_216  3
    x_7_3     stock_ub_217  3
    x_7_3     parent_nonstrict_scope_218  1.5649459251914650e-02
    x_7_3     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_197  1
    w_7_3     product_ub_198  1
    w_7_3     normalized_mass_7_214  1
    w_7_3     normalized_ratio_7_215  -6.0000000000000009e-01
    w_7_3     full_original_Gini_276  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -1.1737094438935993e-02
    x_7_4     product_lb_199  -4.4708595759735285e-02
    x_7_4     product_ub_200  -1.1691022964521088e-01
    x_7_4     onehot_7_213  1
    x_7_4     stock_lb_216  4
    x_7_4     stock_ub_217  4
    x_7_4     parent_nonstrict_scope_218  7.8247296259573249e-03
    x_7_4     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_199  1
    w_7_4     product_ub_200  1
    w_7_4     normalized_mass_7_214  1
    w_7_4     normalized_ratio_7_215  -0.8
    w_7_4     full_original_Gini_276  -4.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.9561824064893318e-02
    x_7_5     product_lb_201  -4.4708595759735285e-02
    x_7_5     product_ub_202  -1.1691022964521088e-01
    x_7_5     onehot_7_213  1
    x_7_5     stock_lb_216  5
    x_7_5     stock_ub_217  5
    x_7_5     unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_201  1
    w_7_5     product_ub_202  1
    w_7_5     normalized_mass_7_214  1
    w_7_5     normalized_ratio_7_215  -1
    w_7_5     full_original_Gini_276  -3.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -1.1737094438935985e-02
    x_7_6     product_lb_203  -4.4708595759735285e-02
    x_7_6     product_ub_204  -1.1691022964521088e-01
    x_7_6     onehot_7_213  1
    x_7_6     stock_lb_216  6
    x_7_6     stock_ub_217  6
    x_7_6     parent_nonstrict_scope_218  7.8247296259573336e-03
    x_7_6     unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_203  1
    w_7_6     product_ub_204  1
    w_7_6     normalized_mass_7_214  1
    w_7_6     normalized_ratio_7_215  -1.2000000000000002e+00
    w_7_6     full_original_Gini_276  -5.8464285714285733e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -3.9123648129786581e-03
    x_7_7     product_lb_205  -4.4708595759735285e-02
    x_7_7     product_ub_206  -1.1691022964521088e-01
    x_7_7     onehot_7_213  1
    x_7_7     stock_lb_216  7
    x_7_7     stock_ub_217  7
    x_7_7     parent_nonstrict_scope_218  1.5649459251914660e-02
    x_7_7     unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_205  1
    w_7_7     product_ub_206  1
    w_7_7     normalized_mass_7_214  1
    w_7_7     normalized_ratio_7_215  -1.4000000000000001e+00
    w_7_7     full_original_Gini_276  -8.2464285714285737e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       3.9123648129786685e-03
    x_7_8     product_lb_207  -4.4708595759735285e-02
    x_7_8     product_ub_208  -1.1691022964521088e-01
    x_7_8     onehot_7_213  1
    x_7_8     stock_lb_216  8
    x_7_8     stock_ub_217  8
    x_7_8     parent_nonstrict_scope_218  2.3474188877871987e-02
    x_7_8     unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_207  1
    w_7_8     product_ub_208  1
    w_7_8     normalized_mass_7_214  1
    w_7_8     normalized_ratio_7_215  -1.6
    w_7_8     full_original_Gini_276  -1.0646428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       1.1737094438935995e-02
    x_7_9     product_lb_209  -4.4708595759735285e-02
    x_7_9     product_ub_210  -1.1691022964521088e-01
    x_7_9     onehot_7_213  1
    x_7_9     stock_lb_216  9
    x_7_9     stock_ub_217  9
    x_7_9     parent_nonstrict_scope_218  3.1298918503829314e-02
    x_7_9     unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_209  1
    w_7_9     product_ub_210  1
    w_7_9     normalized_mass_7_214  1
    w_7_9     normalized_ratio_7_215  -1.8
    w_7_9     full_original_Gini_276  -1.3046428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       1.9561824064893318e-02
    x_7_10    product_lb_211  -4.4708595759735285e-02
    x_7_10    product_ub_212  -1.1691022964521088e-01
    x_7_10    onehot_7_213  1
    x_7_10    stock_lb_216  10
    x_7_10    stock_ub_217  10
    x_7_10    parent_nonstrict_scope_218  3.9123648129786637e-02
    x_7_10    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_211  1
    w_7_10    product_ub_212  1
    w_7_10    normalized_mass_7_214  1
    w_7_10    normalized_ratio_7_215  -2
    w_7_10    full_original_Gini_276  -1.5446428571428571e+01
    rho_7     normalized_ratio_7_215  1
    rho_7     block_pair_pos_219  1
    rho_7     block_pair_neg_220  -1
    rho_7     block_pair_pos_227  1
    rho_7     block_pair_neg_228  -1
    rho_7     block_pair_pos_231  1
    rho_7     block_pair_neg_232  -1
    rho_7     block_pair_pos_243  1
    rho_7     block_pair_neg_244  -1
    rho_7     block_pair_pos_257  1
    rho_7     block_pair_neg_258  -1
    rho_7     block_pair_pos_263  1
    rho_7     block_pair_neg_264  -1
    rho_7     block_pair_pos_273  1
    rho_7     block_pair_neg_274  -1
    rho_7     normalization_275  1
    a_12_11   block_pair_pos_249  1
    a_12_11   block_pair_neg_250  1
    a_12_11   full_original_Gini_276  -1
    a_12_18   block_pair_pos_253  1
    a_12_18   block_pair_neg_254  1
    a_12_18   full_original_Gini_276  -1
    a_12_9    block_pair_pos_245  1
    a_12_9    block_pair_neg_246  1
    a_12_9    full_original_Gini_276  -1
    a_12_17   block_pair_pos_251  1
    a_12_17   block_pair_neg_252  1
    a_12_17   full_original_Gini_276  -1
    a_12_10   block_pair_pos_247  1
    a_12_10   block_pair_neg_248  1
    a_12_10   full_original_Gini_276  -1
    a_12_20   block_pair_pos_255  1
    a_12_20   block_pair_neg_256  1
    a_12_20   full_original_Gini_276  -1
    a_12_7    block_pair_pos_243  1
    a_12_7    block_pair_neg_244  1
    a_12_7    full_original_Gini_276  -1
    a_11_18   block_pair_pos_239  1
    a_11_18   block_pair_neg_240  1
    a_11_18   full_original_Gini_276  -1
    a_11_9    block_pair_pos_233  1
    a_11_9    block_pair_neg_234  1
    a_11_9    full_original_Gini_276  -1
    a_11_17   block_pair_pos_237  1
    a_11_17   block_pair_neg_238  1
    a_11_17   full_original_Gini_276  -1
    a_11_10   block_pair_pos_235  1
    a_11_10   block_pair_neg_236  1
    a_11_10   full_original_Gini_276  -1
    a_11_20   block_pair_pos_241  1
    a_11_20   block_pair_neg_242  1
    a_11_20   full_original_Gini_276  -1
    a_11_7    block_pair_pos_231  1
    a_11_7    block_pair_neg_232  1
    a_11_7    full_original_Gini_276  -1
    a_18_9    block_pair_pos_265  1
    a_18_9    block_pair_neg_266  1
    a_18_9    full_original_Gini_276  -1
    a_18_17   block_pair_pos_269  1
    a_18_17   block_pair_neg_270  1
    a_18_17   full_original_Gini_276  -1
    a_18_10   block_pair_pos_267  1
    a_18_10   block_pair_neg_268  1
    a_18_10   full_original_Gini_276  -1
    a_18_20   block_pair_pos_271  1
    a_18_20   block_pair_neg_272  1
    a_18_20   full_original_Gini_276  -1
    a_18_7    block_pair_pos_263  1
    a_18_7    block_pair_neg_264  1
    a_18_7    full_original_Gini_276  -1
    a_9_17    block_pair_pos_223  1
    a_9_17    block_pair_neg_224  1
    a_9_17    full_original_Gini_276  -1
    a_9_10    block_pair_pos_221  1
    a_9_10    block_pair_neg_222  1
    a_9_10    full_original_Gini_276  -1
    a_9_20    block_pair_pos_225  1
    a_9_20    block_pair_neg_226  1
    a_9_20    full_original_Gini_276  -1
    a_9_7     block_pair_pos_219  1
    a_9_7     block_pair_neg_220  1
    a_9_7     full_original_Gini_276  -1
    a_17_10   block_pair_pos_259  1
    a_17_10   block_pair_neg_260  1
    a_17_10   full_original_Gini_276  -1
    a_17_20   block_pair_pos_261  1
    a_17_20   block_pair_neg_262  1
    a_17_20   full_original_Gini_276  -1
    a_17_7    block_pair_pos_257  1
    a_17_7    block_pair_neg_258  1
    a_17_7    full_original_Gini_276  -1
    a_10_20   block_pair_pos_229  1
    a_10_20   block_pair_neg_230  1
    a_10_20   full_original_Gini_276  -1
    a_10_7    block_pair_pos_227  1
    a_10_7    block_pair_neg_228  1
    a_10_7    full_original_Gini_276  -1
    a_20_7    block_pair_pos_273  1
    a_20_7    block_pair_neg_274  1
    a_20_7    full_original_Gini_276  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_12_0  unique_nonzero_owner_277  1
    service_0_12_0  service_visit_def_806  1
    service_0_12_0  free_load_conservation_807  -11
    service_0_12_0  original_T_including_depot_unload_855  1320
    service_0_12_1  unique_nonzero_owner_278  1
    service_0_12_1  service_visit_def_806  1
    service_0_12_1  free_load_conservation_807  -10
    service_0_12_1  original_T_including_depot_unload_855  1200
    service_0_12_2  unique_nonzero_owner_279  1
    service_0_12_2  service_visit_def_806  1
    service_0_12_2  free_load_conservation_807  -9
    service_0_12_2  original_T_including_depot_unload_855  1080
    service_0_12_3  unique_nonzero_owner_280  1
    service_0_12_3  service_visit_def_806  1
    service_0_12_3  free_load_conservation_807  -8
    service_0_12_3  original_T_including_depot_unload_855  960
    service_0_12_4  unique_nonzero_owner_281  1
    service_0_12_4  service_visit_def_806  1
    service_0_12_4  free_load_conservation_807  -7
    service_0_12_4  original_T_including_depot_unload_855  840
    service_0_12_5  unique_nonzero_owner_282  1
    service_0_12_5  service_visit_def_806  1
    service_0_12_5  free_load_conservation_807  -6
    service_0_12_5  original_T_including_depot_unload_855  720
    service_0_12_6  unique_nonzero_owner_283  1
    service_0_12_6  service_visit_def_806  1
    service_0_12_6  free_load_conservation_807  -5
    service_0_12_6  original_T_including_depot_unload_855  600
    service_0_12_7  unique_nonzero_owner_284  1
    service_0_12_7  service_visit_def_806  1
    service_0_12_7  free_load_conservation_807  -4
    service_0_12_7  original_T_including_depot_unload_855  480
    service_0_12_8  unique_nonzero_owner_285  1
    service_0_12_8  service_visit_def_806  1
    service_0_12_8  free_load_conservation_807  -3
    service_0_12_8  original_T_including_depot_unload_855  360
    service_0_12_9  unique_nonzero_owner_286  1
    service_0_12_9  service_visit_def_806  1
    service_0_12_9  free_load_conservation_807  -2
    service_0_12_9  original_T_including_depot_unload_855  240
    service_0_12_10  unique_nonzero_owner_287  1
    service_0_12_10  service_visit_def_806  1
    service_0_12_10  free_load_conservation_807  -1
    service_0_12_10  original_T_including_depot_unload_855  120
    service_0_12_12  unique_nonzero_owner_288  1
    service_0_12_12  service_visit_def_806  1
    service_0_12_12  free_load_conservation_807  1
    service_0_12_13  unique_nonzero_owner_289  1
    service_0_12_13  service_visit_def_806  1
    service_0_12_13  free_load_conservation_807  2
    service_0_12_14  unique_nonzero_owner_290  1
    service_0_12_14  service_visit_def_806  1
    service_0_12_14  free_load_conservation_807  3
    service_0_12_15  unique_nonzero_owner_291  1
    service_0_12_15  service_visit_def_806  1
    service_0_12_15  free_load_conservation_807  4
    service_1_12_0  unique_nonzero_owner_277  1
    service_1_12_0  service_visit_def_1077  1
    service_1_12_0  free_load_conservation_1078  -11
    service_1_12_0  original_T_including_depot_unload_1122  1320
    service_1_12_1  unique_nonzero_owner_278  1
    service_1_12_1  service_visit_def_1077  1
    service_1_12_1  free_load_conservation_1078  -10
    service_1_12_1  original_T_including_depot_unload_1122  1200
    service_1_12_2  unique_nonzero_owner_279  1
    service_1_12_2  service_visit_def_1077  1
    service_1_12_2  free_load_conservation_1078  -9
    service_1_12_2  original_T_including_depot_unload_1122  1080
    service_1_12_3  unique_nonzero_owner_280  1
    service_1_12_3  service_visit_def_1077  1
    service_1_12_3  free_load_conservation_1078  -8
    service_1_12_3  original_T_including_depot_unload_1122  960
    service_1_12_4  unique_nonzero_owner_281  1
    service_1_12_4  service_visit_def_1077  1
    service_1_12_4  free_load_conservation_1078  -7
    service_1_12_4  original_T_including_depot_unload_1122  840
    service_1_12_5  unique_nonzero_owner_282  1
    service_1_12_5  service_visit_def_1077  1
    service_1_12_5  free_load_conservation_1078  -6
    service_1_12_5  original_T_including_depot_unload_1122  720
    service_1_12_6  unique_nonzero_owner_283  1
    service_1_12_6  service_visit_def_1077  1
    service_1_12_6  free_load_conservation_1078  -5
    service_1_12_6  original_T_including_depot_unload_1122  600
    service_1_12_7  unique_nonzero_owner_284  1
    service_1_12_7  service_visit_def_1077  1
    service_1_12_7  free_load_conservation_1078  -4
    service_1_12_7  original_T_including_depot_unload_1122  480
    service_1_12_8  unique_nonzero_owner_285  1
    service_1_12_8  service_visit_def_1077  1
    service_1_12_8  free_load_conservation_1078  -3
    service_1_12_8  original_T_including_depot_unload_1122  360
    service_1_12_9  unique_nonzero_owner_286  1
    service_1_12_9  service_visit_def_1077  1
    service_1_12_9  free_load_conservation_1078  -2
    service_1_12_9  original_T_including_depot_unload_1122  240
    service_1_12_10  unique_nonzero_owner_287  1
    service_1_12_10  service_visit_def_1077  1
    service_1_12_10  free_load_conservation_1078  -1
    service_1_12_10  original_T_including_depot_unload_1122  120
    service_1_12_12  unique_nonzero_owner_288  1
    service_1_12_12  service_visit_def_1077  1
    service_1_12_12  free_load_conservation_1078  1
    service_1_12_13  unique_nonzero_owner_289  1
    service_1_12_13  service_visit_def_1077  1
    service_1_12_13  free_load_conservation_1078  2
    service_1_12_14  unique_nonzero_owner_290  1
    service_1_12_14  service_visit_def_1077  1
    service_1_12_14  free_load_conservation_1078  3
    service_1_12_15  unique_nonzero_owner_291  1
    service_1_12_15  service_visit_def_1077  1
    service_1_12_15  free_load_conservation_1078  4
    service_0_11_0  unique_nonzero_owner_292  1
    service_0_11_0  service_visit_def_812  1
    service_0_11_0  free_load_conservation_813  -1
    service_0_11_0  original_T_including_depot_unload_855  120
    service_0_11_2  unique_nonzero_owner_293  1
    service_0_11_2  service_visit_def_812  1
    service_0_11_2  free_load_conservation_813  1
    service_0_11_3  unique_nonzero_owner_294  1
    service_0_11_3  service_visit_def_812  1
    service_0_11_3  free_load_conservation_813  2
    service_0_11_4  unique_nonzero_owner_295  1
    service_0_11_4  service_visit_def_812  1
    service_0_11_4  free_load_conservation_813  3
    service_0_11_5  unique_nonzero_owner_296  1
    service_0_11_5  service_visit_def_812  1
    service_0_11_5  free_load_conservation_813  4
    service_0_11_6  unique_nonzero_owner_297  1
    service_0_11_6  service_visit_def_812  1
    service_0_11_6  free_load_conservation_813  5
    service_0_11_7  unique_nonzero_owner_298  1
    service_0_11_7  service_visit_def_812  1
    service_0_11_7  free_load_conservation_813  6
    service_0_11_8  unique_nonzero_owner_299  1
    service_0_11_8  service_visit_def_812  1
    service_0_11_8  free_load_conservation_813  7
    service_0_11_9  unique_nonzero_owner_300  1
    service_0_11_9  service_visit_def_812  1
    service_0_11_9  free_load_conservation_813  8
    service_0_11_10  unique_nonzero_owner_301  1
    service_0_11_10  service_visit_def_812  1
    service_0_11_10  free_load_conservation_813  9
    service_0_11_11  unique_nonzero_owner_302  1
    service_0_11_11  service_visit_def_812  1
    service_0_11_11  free_load_conservation_813  10
    service_0_11_12  unique_nonzero_owner_303  1
    service_0_11_12  service_visit_def_812  1
    service_0_11_12  free_load_conservation_813  11
    service_0_11_13  unique_nonzero_owner_304  1
    service_0_11_13  service_visit_def_812  1
    service_0_11_13  free_load_conservation_813  12
    service_0_11_14  unique_nonzero_owner_305  1
    service_0_11_14  service_visit_def_812  1
    service_0_11_14  free_load_conservation_813  13
    service_0_11_15  unique_nonzero_owner_306  1
    service_0_11_15  service_visit_def_812  1
    service_0_11_15  free_load_conservation_813  14
    service_1_11_0  unique_nonzero_owner_292  1
    service_1_11_0  service_visit_def_1083  1
    service_1_11_0  free_load_conservation_1084  -1
    service_1_11_0  original_T_including_depot_unload_1122  120
    service_1_11_2  unique_nonzero_owner_293  1
    service_1_11_2  service_visit_def_1083  1
    service_1_11_2  free_load_conservation_1084  1
    service_1_11_3  unique_nonzero_owner_294  1
    service_1_11_3  service_visit_def_1083  1
    service_1_11_3  free_load_conservation_1084  2
    service_1_11_4  unique_nonzero_owner_295  1
    service_1_11_4  service_visit_def_1083  1
    service_1_11_4  free_load_conservation_1084  3
    service_1_11_5  unique_nonzero_owner_296  1
    service_1_11_5  service_visit_def_1083  1
    service_1_11_5  free_load_conservation_1084  4
    service_1_11_6  unique_nonzero_owner_297  1
    service_1_11_6  service_visit_def_1083  1
    service_1_11_6  free_load_conservation_1084  5
    service_1_11_7  unique_nonzero_owner_298  1
    service_1_11_7  service_visit_def_1083  1
    service_1_11_7  free_load_conservation_1084  6
    service_1_11_8  unique_nonzero_owner_299  1
    service_1_11_8  service_visit_def_1083  1
    service_1_11_8  free_load_conservation_1084  7
    service_1_11_9  unique_nonzero_owner_300  1
    service_1_11_9  service_visit_def_1083  1
    service_1_11_9  free_load_conservation_1084  8
    service_1_11_10  unique_nonzero_owner_301  1
    service_1_11_10  service_visit_def_1083  1
    service_1_11_10  free_load_conservation_1084  9
    service_1_11_11  unique_nonzero_owner_302  1
    service_1_11_11  service_visit_def_1083  1
    service_1_11_11  free_load_conservation_1084  10
    service_1_11_12  unique_nonzero_owner_303  1
    service_1_11_12  service_visit_def_1083  1
    service_1_11_12  free_load_conservation_1084  11
    service_1_11_13  unique_nonzero_owner_304  1
    service_1_11_13  service_visit_def_1083  1
    service_1_11_13  free_load_conservation_1084  12
    service_1_11_14  unique_nonzero_owner_305  1
    service_1_11_14  service_visit_def_1083  1
    service_1_11_14  free_load_conservation_1084  13
    service_1_11_15  unique_nonzero_owner_306  1
    service_1_11_15  service_visit_def_1083  1
    service_1_11_15  free_load_conservation_1084  14
    service_0_18_1  unique_nonzero_owner_307  1
    service_0_18_1  service_visit_def_818  1
    service_0_18_1  free_load_conservation_819  1
    service_0_18_2  unique_nonzero_owner_308  1
    service_0_18_2  service_visit_def_818  1
    service_0_18_2  free_load_conservation_819  2
    service_0_18_3  unique_nonzero_owner_309  1
    service_0_18_3  service_visit_def_818  1
    service_0_18_3  free_load_conservation_819  3
    service_0_18_4  unique_nonzero_owner_310  1
    service_0_18_4  service_visit_def_818  1
    service_0_18_4  free_load_conservation_819  4
    service_0_18_5  unique_nonzero_owner_311  1
    service_0_18_5  service_visit_def_818  1
    service_0_18_5  free_load_conservation_819  5
    service_0_18_6  unique_nonzero_owner_312  1
    service_0_18_6  service_visit_def_818  1
    service_0_18_6  free_load_conservation_819  6
    service_0_18_7  unique_nonzero_owner_313  1
    service_0_18_7  service_visit_def_818  1
    service_0_18_7  free_load_conservation_819  7
    service_0_18_8  unique_nonzero_owner_314  1
    service_0_18_8  service_visit_def_818  1
    service_0_18_8  free_load_conservation_819  8
    service_0_18_9  unique_nonzero_owner_315  1
    service_0_18_9  service_visit_def_818  1
    service_0_18_9  free_load_conservation_819  9
    service_0_18_10  unique_nonzero_owner_316  1
    service_0_18_10  service_visit_def_818  1
    service_0_18_10  free_load_conservation_819  10
    service_0_18_11  unique_nonzero_owner_317  1
    service_0_18_11  service_visit_def_818  1
    service_0_18_11  free_load_conservation_819  11
    service_0_18_12  unique_nonzero_owner_318  1
    service_0_18_12  service_visit_def_818  1
    service_0_18_12  free_load_conservation_819  12
    service_0_18_13  unique_nonzero_owner_319  1
    service_0_18_13  service_visit_def_818  1
    service_0_18_13  free_load_conservation_819  13
    service_0_18_14  unique_nonzero_owner_320  1
    service_0_18_14  service_visit_def_818  1
    service_0_18_14  free_load_conservation_819  14
    service_0_18_15  unique_nonzero_owner_321  1
    service_0_18_15  service_visit_def_818  1
    service_0_18_15  free_load_conservation_819  15
    service_1_18_1  unique_nonzero_owner_307  1
    service_1_18_1  service_visit_def_1089  1
    service_1_18_1  free_load_conservation_1090  1
    service_1_18_2  unique_nonzero_owner_308  1
    service_1_18_2  service_visit_def_1089  1
    service_1_18_2  free_load_conservation_1090  2
    service_1_18_3  unique_nonzero_owner_309  1
    service_1_18_3  service_visit_def_1089  1
    service_1_18_3  free_load_conservation_1090  3
    service_1_18_4  unique_nonzero_owner_310  1
    service_1_18_4  service_visit_def_1089  1
    service_1_18_4  free_load_conservation_1090  4
    service_1_18_5  unique_nonzero_owner_311  1
    service_1_18_5  service_visit_def_1089  1
    service_1_18_5  free_load_conservation_1090  5
    service_1_18_6  unique_nonzero_owner_312  1
    service_1_18_6  service_visit_def_1089  1
    service_1_18_6  free_load_conservation_1090  6
    service_1_18_7  unique_nonzero_owner_313  1
    service_1_18_7  service_visit_def_1089  1
    service_1_18_7  free_load_conservation_1090  7
    service_1_18_8  unique_nonzero_owner_314  1
    service_1_18_8  service_visit_def_1089  1
    service_1_18_8  free_load_conservation_1090  8
    service_1_18_9  unique_nonzero_owner_315  1
    service_1_18_9  service_visit_def_1089  1
    service_1_18_9  free_load_conservation_1090  9
    service_1_18_10  unique_nonzero_owner_316  1
    service_1_18_10  service_visit_def_1089  1
    service_1_18_10  free_load_conservation_1090  10
    service_1_18_11  unique_nonzero_owner_317  1
    service_1_18_11  service_visit_def_1089  1
    service_1_18_11  free_load_conservation_1090  11
    service_1_18_12  unique_nonzero_owner_318  1
    service_1_18_12  service_visit_def_1089  1
    service_1_18_12  free_load_conservation_1090  12
    service_1_18_13  unique_nonzero_owner_319  1
    service_1_18_13  service_visit_def_1089  1
    service_1_18_13  free_load_conservation_1090  13
    service_1_18_14  unique_nonzero_owner_320  1
    service_1_18_14  service_visit_def_1089  1
    service_1_18_14  free_load_conservation_1090  14
    service_1_18_15  unique_nonzero_owner_321  1
    service_1_18_15  service_visit_def_1089  1
    service_1_18_15  free_load_conservation_1090  15
    service_0_9_1  unique_nonzero_owner_322  1
    service_0_9_1  service_visit_def_824  1
    service_0_9_1  free_load_conservation_825  1
    service_1_9_1  unique_nonzero_owner_322  1
    service_1_9_1  service_visit_def_1095  1
    service_1_9_1  free_load_conservation_1096  1
    service_0_17_0  unique_nonzero_owner_323  1
    service_0_17_0  service_visit_def_830  1
    service_0_17_0  free_load_conservation_831  -3
    service_0_17_0  original_T_including_depot_unload_855  360
    service_0_17_1  unique_nonzero_owner_324  1
    service_0_17_1  service_visit_def_830  1
    service_0_17_1  free_load_conservation_831  -2
    service_0_17_1  original_T_including_depot_unload_855  240
    service_0_17_2  unique_nonzero_owner_325  1
    service_0_17_2  service_visit_def_830  1
    service_0_17_2  free_load_conservation_831  -1
    service_0_17_2  original_T_including_depot_unload_855  120
    service_0_17_4  unique_nonzero_owner_326  1
    service_0_17_4  service_visit_def_830  1
    service_0_17_4  free_load_conservation_831  1
    service_0_17_5  unique_nonzero_owner_327  1
    service_0_17_5  service_visit_def_830  1
    service_0_17_5  free_load_conservation_831  2
    service_0_17_6  unique_nonzero_owner_328  1
    service_0_17_6  service_visit_def_830  1
    service_0_17_6  free_load_conservation_831  3
    service_0_17_7  unique_nonzero_owner_329  1
    service_0_17_7  service_visit_def_830  1
    service_0_17_7  free_load_conservation_831  4
    service_0_17_8  unique_nonzero_owner_330  1
    service_0_17_8  service_visit_def_830  1
    service_0_17_8  free_load_conservation_831  5
    service_0_17_9  unique_nonzero_owner_331  1
    service_0_17_9  service_visit_def_830  1
    service_0_17_9  free_load_conservation_831  6
    service_0_17_10  unique_nonzero_owner_332  1
    service_0_17_10  service_visit_def_830  1
    service_0_17_10  free_load_conservation_831  7
    service_0_17_11  unique_nonzero_owner_333  1
    service_0_17_11  service_visit_def_830  1
    service_0_17_11  free_load_conservation_831  8
    service_0_17_12  unique_nonzero_owner_334  1
    service_0_17_12  service_visit_def_830  1
    service_0_17_12  free_load_conservation_831  9
    service_0_17_13  unique_nonzero_owner_335  1
    service_0_17_13  service_visit_def_830  1
    service_0_17_13  free_load_conservation_831  10
    service_0_17_14  unique_nonzero_owner_336  1
    service_0_17_14  service_visit_def_830  1
    service_0_17_14  free_load_conservation_831  11
    service_0_17_15  unique_nonzero_owner_337  1
    service_0_17_15  service_visit_def_830  1
    service_0_17_15  free_load_conservation_831  12
    service_0_17_16  unique_nonzero_owner_338  1
    service_0_17_16  service_visit_def_830  1
    service_0_17_16  free_load_conservation_831  13
    service_1_17_0  unique_nonzero_owner_323  1
    service_1_17_0  service_visit_def_1101  1
    service_1_17_0  free_load_conservation_1102  -3
    service_1_17_0  original_T_including_depot_unload_1122  360
    service_1_17_1  unique_nonzero_owner_324  1
    service_1_17_1  service_visit_def_1101  1
    service_1_17_1  free_load_conservation_1102  -2
    service_1_17_1  original_T_including_depot_unload_1122  240
    service_1_17_2  unique_nonzero_owner_325  1
    service_1_17_2  service_visit_def_1101  1
    service_1_17_2  free_load_conservation_1102  -1
    service_1_17_2  original_T_including_depot_unload_1122  120
    service_1_17_4  unique_nonzero_owner_326  1
    service_1_17_4  service_visit_def_1101  1
    service_1_17_4  free_load_conservation_1102  1
    service_1_17_5  unique_nonzero_owner_327  1
    service_1_17_5  service_visit_def_1101  1
    service_1_17_5  free_load_conservation_1102  2
    service_1_17_6  unique_nonzero_owner_328  1
    service_1_17_6  service_visit_def_1101  1
    service_1_17_6  free_load_conservation_1102  3
    service_1_17_7  unique_nonzero_owner_329  1
    service_1_17_7  service_visit_def_1101  1
    service_1_17_7  free_load_conservation_1102  4
    service_1_17_8  unique_nonzero_owner_330  1
    service_1_17_8  service_visit_def_1101  1
    service_1_17_8  free_load_conservation_1102  5
    service_1_17_9  unique_nonzero_owner_331  1
    service_1_17_9  service_visit_def_1101  1
    service_1_17_9  free_load_conservation_1102  6
    service_1_17_10  unique_nonzero_owner_332  1
    service_1_17_10  service_visit_def_1101  1
    service_1_17_10  free_load_conservation_1102  7
    service_1_17_11  unique_nonzero_owner_333  1
    service_1_17_11  service_visit_def_1101  1
    service_1_17_11  free_load_conservation_1102  8
    service_1_17_12  unique_nonzero_owner_334  1
    service_1_17_12  service_visit_def_1101  1
    service_1_17_12  free_load_conservation_1102  9
    service_1_17_13  unique_nonzero_owner_335  1
    service_1_17_13  service_visit_def_1101  1
    service_1_17_13  free_load_conservation_1102  10
    service_1_17_14  unique_nonzero_owner_336  1
    service_1_17_14  service_visit_def_1101  1
    service_1_17_14  free_load_conservation_1102  11
    service_1_17_15  unique_nonzero_owner_337  1
    service_1_17_15  service_visit_def_1101  1
    service_1_17_15  free_load_conservation_1102  12
    service_1_17_16  unique_nonzero_owner_338  1
    service_1_17_16  service_visit_def_1101  1
    service_1_17_16  free_load_conservation_1102  13
    service_0_10_1  unique_nonzero_owner_339  1
    service_0_10_1  service_visit_def_836  1
    service_0_10_1  free_load_conservation_837  1
    service_1_10_1  unique_nonzero_owner_339  1
    service_1_10_1  service_visit_def_1107  1
    service_1_10_1  free_load_conservation_1108  1
    service_0_20_0  unique_nonzero_owner_340  1
    service_0_20_0  service_visit_def_842  1
    service_0_20_0  free_load_conservation_843  -12
    service_0_20_0  original_T_including_depot_unload_855  1440
    service_0_20_1  unique_nonzero_owner_341  1
    service_0_20_1  service_visit_def_842  1
    service_0_20_1  free_load_conservation_843  -11
    service_0_20_1  original_T_including_depot_unload_855  1320
    service_0_20_2  unique_nonzero_owner_342  1
    service_0_20_2  service_visit_def_842  1
    service_0_20_2  free_load_conservation_843  -10
    service_0_20_2  original_T_including_depot_unload_855  1200
    service_0_20_3  unique_nonzero_owner_343  1
    service_0_20_3  service_visit_def_842  1
    service_0_20_3  free_load_conservation_843  -9
    service_0_20_3  original_T_including_depot_unload_855  1080
    service_0_20_4  unique_nonzero_owner_344  1
    service_0_20_4  service_visit_def_842  1
    service_0_20_4  free_load_conservation_843  -8
    service_0_20_4  original_T_including_depot_unload_855  960
    service_0_20_5  unique_nonzero_owner_345  1
    service_0_20_5  service_visit_def_842  1
    service_0_20_5  free_load_conservation_843  -7
    service_0_20_5  original_T_including_depot_unload_855  840
    service_0_20_6  unique_nonzero_owner_346  1
    service_0_20_6  service_visit_def_842  1
    service_0_20_6  free_load_conservation_843  -6
    service_0_20_6  original_T_including_depot_unload_855  720
    service_0_20_7  unique_nonzero_owner_347  1
    service_0_20_7  service_visit_def_842  1
    service_0_20_7  free_load_conservation_843  -5
    service_0_20_7  original_T_including_depot_unload_855  600
    service_0_20_8  unique_nonzero_owner_348  1
    service_0_20_8  service_visit_def_842  1
    service_0_20_8  free_load_conservation_843  -4
    service_0_20_8  original_T_including_depot_unload_855  480
    service_0_20_9  unique_nonzero_owner_349  1
    service_0_20_9  service_visit_def_842  1
    service_0_20_9  free_load_conservation_843  -3
    service_0_20_9  original_T_including_depot_unload_855  360
    service_0_20_10  unique_nonzero_owner_350  1
    service_0_20_10  service_visit_def_842  1
    service_0_20_10  free_load_conservation_843  -2
    service_0_20_10  original_T_including_depot_unload_855  240
    service_0_20_11  unique_nonzero_owner_351  1
    service_0_20_11  service_visit_def_842  1
    service_0_20_11  free_load_conservation_843  -1
    service_0_20_11  original_T_including_depot_unload_855  120
    service_0_20_13  unique_nonzero_owner_352  1
    service_0_20_13  service_visit_def_842  1
    service_0_20_13  free_load_conservation_843  1
    service_0_20_14  unique_nonzero_owner_353  1
    service_0_20_14  service_visit_def_842  1
    service_0_20_14  free_load_conservation_843  2
    service_0_20_15  unique_nonzero_owner_354  1
    service_0_20_15  service_visit_def_842  1
    service_0_20_15  free_load_conservation_843  3
    service_1_20_0  unique_nonzero_owner_340  1
    service_1_20_0  service_visit_def_1113  1
    service_1_20_0  free_load_conservation_1114  -12
    service_1_20_0  original_T_including_depot_unload_1122  1440
    service_1_20_1  unique_nonzero_owner_341  1
    service_1_20_1  service_visit_def_1113  1
    service_1_20_1  free_load_conservation_1114  -11
    service_1_20_1  original_T_including_depot_unload_1122  1320
    service_1_20_2  unique_nonzero_owner_342  1
    service_1_20_2  service_visit_def_1113  1
    service_1_20_2  free_load_conservation_1114  -10
    service_1_20_2  original_T_including_depot_unload_1122  1200
    service_1_20_3  unique_nonzero_owner_343  1
    service_1_20_3  service_visit_def_1113  1
    service_1_20_3  free_load_conservation_1114  -9
    service_1_20_3  original_T_including_depot_unload_1122  1080
    service_1_20_4  unique_nonzero_owner_344  1
    service_1_20_4  service_visit_def_1113  1
    service_1_20_4  free_load_conservation_1114  -8
    service_1_20_4  original_T_including_depot_unload_1122  960
    service_1_20_5  unique_nonzero_owner_345  1
    service_1_20_5  service_visit_def_1113  1
    service_1_20_5  free_load_conservation_1114  -7
    service_1_20_5  original_T_including_depot_unload_1122  840
    service_1_20_6  unique_nonzero_owner_346  1
    service_1_20_6  service_visit_def_1113  1
    service_1_20_6  free_load_conservation_1114  -6
    service_1_20_6  original_T_including_depot_unload_1122  720
    service_1_20_7  unique_nonzero_owner_347  1
    service_1_20_7  service_visit_def_1113  1
    service_1_20_7  free_load_conservation_1114  -5
    service_1_20_7  original_T_including_depot_unload_1122  600
    service_1_20_8  unique_nonzero_owner_348  1
    service_1_20_8  service_visit_def_1113  1
    service_1_20_8  free_load_conservation_1114  -4
    service_1_20_8  original_T_including_depot_unload_1122  480
    service_1_20_9  unique_nonzero_owner_349  1
    service_1_20_9  service_visit_def_1113  1
    service_1_20_9  free_load_conservation_1114  -3
    service_1_20_9  original_T_including_depot_unload_1122  360
    service_1_20_10  unique_nonzero_owner_350  1
    service_1_20_10  service_visit_def_1113  1
    service_1_20_10  free_load_conservation_1114  -2
    service_1_20_10  original_T_including_depot_unload_1122  240
    service_1_20_11  unique_nonzero_owner_351  1
    service_1_20_11  service_visit_def_1113  1
    service_1_20_11  free_load_conservation_1114  -1
    service_1_20_11  original_T_including_depot_unload_1122  120
    service_1_20_13  unique_nonzero_owner_352  1
    service_1_20_13  service_visit_def_1113  1
    service_1_20_13  free_load_conservation_1114  1
    service_1_20_14  unique_nonzero_owner_353  1
    service_1_20_14  service_visit_def_1113  1
    service_1_20_14  free_load_conservation_1114  2
    service_1_20_15  unique_nonzero_owner_354  1
    service_1_20_15  service_visit_def_1113  1
    service_1_20_15  free_load_conservation_1114  3
    service_0_7_0  unique_nonzero_owner_355  1
    service_0_7_0  service_visit_def_848  1
    service_0_7_0  free_load_conservation_849  -1
    service_0_7_0  original_T_including_depot_unload_855  120
    service_0_7_2  unique_nonzero_owner_356  1
    service_0_7_2  service_visit_def_848  1
    service_0_7_2  free_load_conservation_849  1
    service_0_7_3  unique_nonzero_owner_357  1
    service_0_7_3  service_visit_def_848  1
    service_0_7_3  free_load_conservation_849  2
    service_0_7_4  unique_nonzero_owner_358  1
    service_0_7_4  service_visit_def_848  1
    service_0_7_4  free_load_conservation_849  3
    service_0_7_5  unique_nonzero_owner_359  1
    service_0_7_5  service_visit_def_848  1
    service_0_7_5  free_load_conservation_849  4
    service_0_7_6  unique_nonzero_owner_360  1
    service_0_7_6  service_visit_def_848  1
    service_0_7_6  free_load_conservation_849  5
    service_0_7_7  unique_nonzero_owner_361  1
    service_0_7_7  service_visit_def_848  1
    service_0_7_7  free_load_conservation_849  6
    service_0_7_8  unique_nonzero_owner_362  1
    service_0_7_8  service_visit_def_848  1
    service_0_7_8  free_load_conservation_849  7
    service_0_7_9  unique_nonzero_owner_363  1
    service_0_7_9  service_visit_def_848  1
    service_0_7_9  free_load_conservation_849  8
    service_0_7_10  unique_nonzero_owner_364  1
    service_0_7_10  service_visit_def_848  1
    service_0_7_10  free_load_conservation_849  9
    service_1_7_0  unique_nonzero_owner_355  1
    service_1_7_0  service_visit_def_1119  1
    service_1_7_0  free_load_conservation_1120  -1
    service_1_7_0  original_T_including_depot_unload_1122  120
    service_1_7_2  unique_nonzero_owner_356  1
    service_1_7_2  service_visit_def_1119  1
    service_1_7_2  free_load_conservation_1120  1
    service_1_7_3  unique_nonzero_owner_357  1
    service_1_7_3  service_visit_def_1119  1
    service_1_7_3  free_load_conservation_1120  2
    service_1_7_4  unique_nonzero_owner_358  1
    service_1_7_4  service_visit_def_1119  1
    service_1_7_4  free_load_conservation_1120  3
    service_1_7_5  unique_nonzero_owner_359  1
    service_1_7_5  service_visit_def_1119  1
    service_1_7_5  free_load_conservation_1120  4
    service_1_7_6  unique_nonzero_owner_360  1
    service_1_7_6  service_visit_def_1119  1
    service_1_7_6  free_load_conservation_1120  5
    service_1_7_7  unique_nonzero_owner_361  1
    service_1_7_7  service_visit_def_1119  1
    service_1_7_7  free_load_conservation_1120  6
    service_1_7_8  unique_nonzero_owner_362  1
    service_1_7_8  service_visit_def_1119  1
    service_1_7_8  free_load_conservation_1120  7
    service_1_7_9  unique_nonzero_owner_363  1
    service_1_7_9  service_visit_def_1119  1
    service_1_7_9  free_load_conservation_1120  8
    service_1_7_10  unique_nonzero_owner_364  1
    service_1_7_10  service_visit_def_1119  1
    service_1_7_10  free_load_conservation_1120  9
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_760  -1
    visit_0_1  in_degree_761  -1
    visit_0_1  order_active_lb_762  -1
    visit_0_1  order_active_ub_763  -14
    order_0_1  connected_order_arc_382  -1
    order_0_1  connected_order_arc_384  -1
    order_0_1  connected_order_arc_386  -1
    order_0_1  connected_order_arc_388  -1
    order_0_1  connected_order_arc_390  -1
    order_0_1  connected_order_arc_392  -1
    order_0_1  connected_order_arc_394  -1
    order_0_1  connected_order_arc_396  -1
    order_0_1  connected_order_arc_398  -1
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_409  1
    order_0_1  connected_order_arc_436  1
    order_0_1  connected_order_arc_463  1
    order_0_1  connected_order_arc_490  1
    order_0_1  connected_order_arc_517  1
    order_0_1  connected_order_arc_544  1
    order_0_1  connected_order_arc_571  1
    order_0_1  connected_order_arc_598  1
    order_0_1  connected_order_arc_625  1
    order_0_1  connected_order_arc_652  1
    order_0_1  connected_order_arc_679  1
    order_0_1  connected_order_arc_706  1
    order_0_1  connected_order_arc_733  1
    order_0_1  order_active_lb_762  1
    order_0_1  order_active_ub_763  1
    order_0_1  fixed_segment_relative_order_850  -1
    visit_0_2  out_degree_767  -1
    visit_0_2  in_degree_768  -1
    visit_0_2  order_active_lb_769  -1
    visit_0_2  order_active_ub_770  -14
    order_0_2  connected_order_arc_382  1
    order_0_2  connected_order_arc_409  -1
    order_0_2  connected_order_arc_411  -1
    order_0_2  connected_order_arc_413  -1
    order_0_2  connected_order_arc_415  -1
    order_0_2  connected_order_arc_417  -1
    order_0_2  connected_order_arc_419  -1
    order_0_2  connected_order_arc_421  -1
    order_0_2  connected_order_arc_423  -1
    order_0_2  connected_order_arc_425  -1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_433  -1
    order_0_2  connected_order_arc_438  1
    order_0_2  connected_order_arc_465  1
    order_0_2  connected_order_arc_492  1
    order_0_2  connected_order_arc_519  1
    order_0_2  connected_order_arc_546  1
    order_0_2  connected_order_arc_573  1
    order_0_2  connected_order_arc_600  1
    order_0_2  connected_order_arc_627  1
    order_0_2  connected_order_arc_654  1
    order_0_2  connected_order_arc_681  1
    order_0_2  connected_order_arc_708  1
    order_0_2  connected_order_arc_735  1
    order_0_2  order_active_lb_769  1
    order_0_2  order_active_ub_770  1
    order_0_2  fixed_segment_relative_order_850  1
    order_0_2  fixed_segment_relative_order_851  -1
    visit_0_3  out_degree_774  -1
    visit_0_3  in_degree_775  -1
    visit_0_3  order_active_lb_776  -1
    visit_0_3  order_active_ub_777  -14
    order_0_3  connected_order_arc_384  1
    order_0_3  connected_order_arc_411  1
    order_0_3  connected_order_arc_436  -1
    order_0_3  connected_order_arc_438  -1
    order_0_3  connected_order_arc_440  -1
    order_0_3  connected_order_arc_442  -1
    order_0_3  connected_order_arc_444  -1
    order_0_3  connected_order_arc_446  -1
    order_0_3  connected_order_arc_448  -1
    order_0_3  connected_order_arc_450  -1
    order_0_3  connected_order_arc_452  -1
    order_0_3  connected_order_arc_454  -1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_458  -1
    order_0_3  connected_order_arc_460  -1
    order_0_3  connected_order_arc_467  1
    order_0_3  connected_order_arc_494  1
    order_0_3  connected_order_arc_521  1
    order_0_3  connected_order_arc_548  1
    order_0_3  connected_order_arc_575  1
    order_0_3  connected_order_arc_602  1
    order_0_3  connected_order_arc_629  1
    order_0_3  connected_order_arc_656  1
    order_0_3  connected_order_arc_683  1
    order_0_3  connected_order_arc_710  1
    order_0_3  connected_order_arc_737  1
    order_0_3  order_active_lb_776  1
    order_0_3  order_active_ub_777  1
    order_0_3  fixed_segment_relative_order_851  1
    order_0_3  fixed_segment_relative_order_852  -1
    visit_0_4  out_degree_781  -1
    visit_0_4  in_degree_782  -1
    visit_0_4  order_active_lb_783  -1
    visit_0_4  order_active_ub_784  -14
    order_0_4  connected_order_arc_386  1
    order_0_4  connected_order_arc_413  1
    order_0_4  connected_order_arc_440  1
    order_0_4  connected_order_arc_463  -1
    order_0_4  connected_order_arc_465  -1
    order_0_4  connected_order_arc_467  -1
    order_0_4  connected_order_arc_469  -1
    order_0_4  connected_order_arc_471  -1
    order_0_4  connected_order_arc_473  -1
    order_0_4  connected_order_arc_475  -1
    order_0_4  connected_order_arc_477  -1
    order_0_4  connected_order_arc_479  -1
    order_0_4  connected_order_arc_481  -1
    order_0_4  connected_order_arc_483  -1
    order_0_4  connected_order_arc_485  -1
    order_0_4  connected_order_arc_487  -1
    order_0_4  connected_order_arc_496  1
    order_0_4  connected_order_arc_523  1
    order_0_4  connected_order_arc_550  1
    order_0_4  connected_order_arc_577  1
    order_0_4  connected_order_arc_604  1
    order_0_4  connected_order_arc_631  1
    order_0_4  connected_order_arc_658  1
    order_0_4  connected_order_arc_685  1
    order_0_4  connected_order_arc_712  1
    order_0_4  connected_order_arc_739  1
    order_0_4  order_active_lb_783  1
    order_0_4  order_active_ub_784  1
    order_0_4  fixed_segment_relative_order_852  1
    order_0_4  fixed_segment_relative_order_853  -1
    visit_0_5  out_degree_788  -1
    visit_0_5  in_degree_789  -1
    visit_0_5  order_active_lb_790  -1
    visit_0_5  order_active_ub_791  -14
    order_0_5  connected_order_arc_388  1
    order_0_5  connected_order_arc_415  1
    order_0_5  connected_order_arc_442  1
    order_0_5  connected_order_arc_469  1
    order_0_5  connected_order_arc_490  -1
    order_0_5  connected_order_arc_492  -1
    order_0_5  connected_order_arc_494  -1
    order_0_5  connected_order_arc_496  -1
    order_0_5  connected_order_arc_498  -1
    order_0_5  connected_order_arc_500  -1
    order_0_5  connected_order_arc_502  -1
    order_0_5  connected_order_arc_504  -1
    order_0_5  connected_order_arc_506  -1
    order_0_5  connected_order_arc_508  -1
    order_0_5  connected_order_arc_510  -1
    order_0_5  connected_order_arc_512  -1
    order_0_5  connected_order_arc_514  -1
    order_0_5  connected_order_arc_525  1
    order_0_5  connected_order_arc_552  1
    order_0_5  connected_order_arc_579  1
    order_0_5  connected_order_arc_606  1
    order_0_5  connected_order_arc_633  1
    order_0_5  connected_order_arc_660  1
    order_0_5  connected_order_arc_687  1
    order_0_5  connected_order_arc_714  1
    order_0_5  connected_order_arc_741  1
    order_0_5  order_active_lb_790  1
    order_0_5  order_active_ub_791  1
    order_0_5  fixed_segment_relative_order_853  1
    order_0_5  fixed_segment_relative_order_854  -1
    visit_0_6  out_degree_795  -1
    visit_0_6  in_degree_796  -1
    visit_0_6  order_active_lb_797  -1
    visit_0_6  order_active_ub_798  -14
    order_0_6  connected_order_arc_390  1
    order_0_6  connected_order_arc_417  1
    order_0_6  connected_order_arc_444  1
    order_0_6  connected_order_arc_471  1
    order_0_6  connected_order_arc_498  1
    order_0_6  connected_order_arc_517  -1
    order_0_6  connected_order_arc_519  -1
    order_0_6  connected_order_arc_521  -1
    order_0_6  connected_order_arc_523  -1
    order_0_6  connected_order_arc_525  -1
    order_0_6  connected_order_arc_527  -1
    order_0_6  connected_order_arc_529  -1
    order_0_6  connected_order_arc_531  -1
    order_0_6  connected_order_arc_533  -1
    order_0_6  connected_order_arc_535  -1
    order_0_6  connected_order_arc_537  -1
    order_0_6  connected_order_arc_539  -1
    order_0_6  connected_order_arc_541  -1
    order_0_6  connected_order_arc_554  1
    order_0_6  connected_order_arc_581  1
    order_0_6  connected_order_arc_608  1
    order_0_6  connected_order_arc_635  1
    order_0_6  connected_order_arc_662  1
    order_0_6  connected_order_arc_689  1
    order_0_6  connected_order_arc_716  1
    order_0_6  connected_order_arc_743  1
    order_0_6  order_active_lb_797  1
    order_0_6  order_active_ub_798  1
    order_0_6  fixed_segment_relative_order_854  1
    visit_0_9  out_degree_802  -1
    visit_0_9  in_degree_803  -1
    visit_0_9  order_active_lb_804  -1
    visit_0_9  order_active_ub_805  -14
    visit_0_9  service_visit_def_806  -1
    order_0_9  connected_order_arc_392  1
    order_0_9  connected_order_arc_419  1
    order_0_9  connected_order_arc_446  1
    order_0_9  connected_order_arc_473  1
    order_0_9  connected_order_arc_500  1
    order_0_9  connected_order_arc_527  1
    order_0_9  connected_order_arc_544  -1
    order_0_9  connected_order_arc_546  -1
    order_0_9  connected_order_arc_548  -1
    order_0_9  connected_order_arc_550  -1
    order_0_9  connected_order_arc_552  -1
    order_0_9  connected_order_arc_554  -1
    order_0_9  connected_order_arc_556  -1
    order_0_9  connected_order_arc_558  -1
    order_0_9  connected_order_arc_560  -1
    order_0_9  connected_order_arc_562  -1
    order_0_9  connected_order_arc_564  -1
    order_0_9  connected_order_arc_566  -1
    order_0_9  connected_order_arc_568  -1
    order_0_9  connected_order_arc_583  1
    order_0_9  connected_order_arc_610  1
    order_0_9  connected_order_arc_637  1
    order_0_9  connected_order_arc_664  1
    order_0_9  connected_order_arc_691  1
    order_0_9  connected_order_arc_718  1
    order_0_9  connected_order_arc_745  1
    order_0_9  order_active_lb_804  1
    order_0_9  order_active_ub_805  1
    visit_0_10  out_degree_808  -1
    visit_0_10  in_degree_809  -1
    visit_0_10  order_active_lb_810  -1
    visit_0_10  order_active_ub_811  -14
    visit_0_10  service_visit_def_812  -1
    order_0_10  connected_order_arc_394  1
    order_0_10  connected_order_arc_421  1
    order_0_10  connected_order_arc_448  1
    order_0_10  connected_order_arc_475  1
    order_0_10  connected_order_arc_502  1
    order_0_10  connected_order_arc_529  1
    order_0_10  connected_order_arc_556  1
    order_0_10  connected_order_arc_571  -1
    order_0_10  connected_order_arc_573  -1
    order_0_10  connected_order_arc_575  -1
    order_0_10  connected_order_arc_577  -1
    order_0_10  connected_order_arc_579  -1
    order_0_10  connected_order_arc_581  -1
    order_0_10  connected_order_arc_583  -1
    order_0_10  connected_order_arc_585  -1
    order_0_10  connected_order_arc_587  -1
    order_0_10  connected_order_arc_589  -1
    order_0_10  connected_order_arc_591  -1
    order_0_10  connected_order_arc_593  -1
    order_0_10  connected_order_arc_595  -1
    order_0_10  connected_order_arc_612  1
    order_0_10  connected_order_arc_639  1
    order_0_10  connected_order_arc_666  1
    order_0_10  connected_order_arc_693  1
    order_0_10  connected_order_arc_720  1
    order_0_10  connected_order_arc_747  1
    order_0_10  order_active_lb_810  1
    order_0_10  order_active_ub_811  1
    visit_0_11  out_degree_814  -1
    visit_0_11  in_degree_815  -1
    visit_0_11  order_active_lb_816  -1
    visit_0_11  order_active_ub_817  -14
    visit_0_11  service_visit_def_818  -1
    order_0_11  connected_order_arc_396  1
    order_0_11  connected_order_arc_423  1
    order_0_11  connected_order_arc_450  1
    order_0_11  connected_order_arc_477  1
    order_0_11  connected_order_arc_504  1
    order_0_11  connected_order_arc_531  1
    order_0_11  connected_order_arc_558  1
    order_0_11  connected_order_arc_585  1
    order_0_11  connected_order_arc_598  -1
    order_0_11  connected_order_arc_600  -1
    order_0_11  connected_order_arc_602  -1
    order_0_11  connected_order_arc_604  -1
    order_0_11  connected_order_arc_606  -1
    order_0_11  connected_order_arc_608  -1
    order_0_11  connected_order_arc_610  -1
    order_0_11  connected_order_arc_612  -1
    order_0_11  connected_order_arc_614  -1
    order_0_11  connected_order_arc_616  -1
    order_0_11  connected_order_arc_618  -1
    order_0_11  connected_order_arc_620  -1
    order_0_11  connected_order_arc_622  -1
    order_0_11  connected_order_arc_641  1
    order_0_11  connected_order_arc_668  1
    order_0_11  connected_order_arc_695  1
    order_0_11  connected_order_arc_722  1
    order_0_11  connected_order_arc_749  1
    order_0_11  order_active_lb_816  1
    order_0_11  order_active_ub_817  1
    visit_0_12  out_degree_820  -1
    visit_0_12  in_degree_821  -1
    visit_0_12  order_active_lb_822  -1
    visit_0_12  order_active_ub_823  -14
    visit_0_12  service_visit_def_824  -1
    order_0_12  connected_order_arc_398  1
    order_0_12  connected_order_arc_425  1
    order_0_12  connected_order_arc_452  1
    order_0_12  connected_order_arc_479  1
    order_0_12  connected_order_arc_506  1
    order_0_12  connected_order_arc_533  1
    order_0_12  connected_order_arc_560  1
    order_0_12  connected_order_arc_587  1
    order_0_12  connected_order_arc_614  1
    order_0_12  connected_order_arc_625  -1
    order_0_12  connected_order_arc_627  -1
    order_0_12  connected_order_arc_629  -1
    order_0_12  connected_order_arc_631  -1
    order_0_12  connected_order_arc_633  -1
    order_0_12  connected_order_arc_635  -1
    order_0_12  connected_order_arc_637  -1
    order_0_12  connected_order_arc_639  -1
    order_0_12  connected_order_arc_641  -1
    order_0_12  connected_order_arc_643  -1
    order_0_12  connected_order_arc_645  -1
    order_0_12  connected_order_arc_647  -1
    order_0_12  connected_order_arc_649  -1
    order_0_12  connected_order_arc_670  1
    order_0_12  connected_order_arc_697  1
    order_0_12  connected_order_arc_724  1
    order_0_12  connected_order_arc_751  1
    order_0_12  order_active_lb_822  1
    order_0_12  order_active_ub_823  1
    visit_0_13  out_degree_826  -1
    visit_0_13  in_degree_827  -1
    visit_0_13  order_active_lb_828  -1
    visit_0_13  order_active_ub_829  -14
    visit_0_13  service_visit_def_830  -1
    order_0_13  connected_order_arc_400  1
    order_0_13  connected_order_arc_427  1
    order_0_13  connected_order_arc_454  1
    order_0_13  connected_order_arc_481  1
    order_0_13  connected_order_arc_508  1
    order_0_13  connected_order_arc_535  1
    order_0_13  connected_order_arc_562  1
    order_0_13  connected_order_arc_589  1
    order_0_13  connected_order_arc_616  1
    order_0_13  connected_order_arc_643  1
    order_0_13  connected_order_arc_652  -1
    order_0_13  connected_order_arc_654  -1
    order_0_13  connected_order_arc_656  -1
    order_0_13  connected_order_arc_658  -1
    order_0_13  connected_order_arc_660  -1
    order_0_13  connected_order_arc_662  -1
    order_0_13  connected_order_arc_664  -1
    order_0_13  connected_order_arc_666  -1
    order_0_13  connected_order_arc_668  -1
    order_0_13  connected_order_arc_670  -1
    order_0_13  connected_order_arc_672  -1
    order_0_13  connected_order_arc_674  -1
    order_0_13  connected_order_arc_676  -1
    order_0_13  connected_order_arc_699  1
    order_0_13  connected_order_arc_726  1
    order_0_13  connected_order_arc_753  1
    order_0_13  order_active_lb_828  1
    order_0_13  order_active_ub_829  1
    visit_0_14  out_degree_832  -1
    visit_0_14  in_degree_833  -1
    visit_0_14  order_active_lb_834  -1
    visit_0_14  order_active_ub_835  -14
    visit_0_14  service_visit_def_836  -1
    order_0_14  connected_order_arc_402  1
    order_0_14  connected_order_arc_429  1
    order_0_14  connected_order_arc_456  1
    order_0_14  connected_order_arc_483  1
    order_0_14  connected_order_arc_510  1
    order_0_14  connected_order_arc_537  1
    order_0_14  connected_order_arc_564  1
    order_0_14  connected_order_arc_591  1
    order_0_14  connected_order_arc_618  1
    order_0_14  connected_order_arc_645  1
    order_0_14  connected_order_arc_672  1
    order_0_14  connected_order_arc_679  -1
    order_0_14  connected_order_arc_681  -1
    order_0_14  connected_order_arc_683  -1
    order_0_14  connected_order_arc_685  -1
    order_0_14  connected_order_arc_687  -1
    order_0_14  connected_order_arc_689  -1
    order_0_14  connected_order_arc_691  -1
    order_0_14  connected_order_arc_693  -1
    order_0_14  connected_order_arc_695  -1
    order_0_14  connected_order_arc_697  -1
    order_0_14  connected_order_arc_699  -1
    order_0_14  connected_order_arc_701  -1
    order_0_14  connected_order_arc_703  -1
    order_0_14  connected_order_arc_728  1
    order_0_14  connected_order_arc_755  1
    order_0_14  order_active_lb_834  1
    order_0_14  order_active_ub_835  1
    visit_0_15  out_degree_838  -1
    visit_0_15  in_degree_839  -1
    visit_0_15  order_active_lb_840  -1
    visit_0_15  order_active_ub_841  -14
    visit_0_15  service_visit_def_842  -1
    order_0_15  connected_order_arc_404  1
    order_0_15  connected_order_arc_431  1
    order_0_15  connected_order_arc_458  1
    order_0_15  connected_order_arc_485  1
    order_0_15  connected_order_arc_512  1
    order_0_15  connected_order_arc_539  1
    order_0_15  connected_order_arc_566  1
    order_0_15  connected_order_arc_593  1
    order_0_15  connected_order_arc_620  1
    order_0_15  connected_order_arc_647  1
    order_0_15  connected_order_arc_674  1
    order_0_15  connected_order_arc_701  1
    order_0_15  connected_order_arc_706  -1
    order_0_15  connected_order_arc_708  -1
    order_0_15  connected_order_arc_710  -1
    order_0_15  connected_order_arc_712  -1
    order_0_15  connected_order_arc_714  -1
    order_0_15  connected_order_arc_716  -1
    order_0_15  connected_order_arc_718  -1
    order_0_15  connected_order_arc_720  -1
    order_0_15  connected_order_arc_722  -1
    order_0_15  connected_order_arc_724  -1
    order_0_15  connected_order_arc_726  -1
    order_0_15  connected_order_arc_728  -1
    order_0_15  connected_order_arc_730  -1
    order_0_15  connected_order_arc_757  1
    order_0_15  order_active_lb_840  1
    order_0_15  order_active_ub_841  1
    visit_0_16  out_degree_844  -1
    visit_0_16  in_degree_845  -1
    visit_0_16  order_active_lb_846  -1
    visit_0_16  order_active_ub_847  -14
    visit_0_16  service_visit_def_848  -1
    order_0_16  connected_order_arc_406  1
    order_0_16  connected_order_arc_433  1
    order_0_16  connected_order_arc_460  1
    order_0_16  connected_order_arc_487  1
    order_0_16  connected_order_arc_514  1
    order_0_16  connected_order_arc_541  1
    order_0_16  connected_order_arc_568  1
    order_0_16  connected_order_arc_595  1
    order_0_16  connected_order_arc_622  1
    order_0_16  connected_order_arc_649  1
    order_0_16  connected_order_arc_676  1
    order_0_16  connected_order_arc_703  1
    order_0_16  connected_order_arc_730  1
    order_0_16  connected_order_arc_733  -1
    order_0_16  connected_order_arc_735  -1
    order_0_16  connected_order_arc_737  -1
    order_0_16  connected_order_arc_739  -1
    order_0_16  connected_order_arc_741  -1
    order_0_16  connected_order_arc_743  -1
    order_0_16  connected_order_arc_745  -1
    order_0_16  connected_order_arc_747  -1
    order_0_16  connected_order_arc_749  -1
    order_0_16  connected_order_arc_751  -1
    order_0_16  connected_order_arc_753  -1
    order_0_16  connected_order_arc_755  -1
    order_0_16  connected_order_arc_757  -1
    order_0_16  order_active_lb_846  1
    order_0_16  order_active_ub_847  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_365  -30
    arc_0_0_0  depot_departure_or_bypass_758  1
    arc_0_0_0  depot_return_or_bypass_759  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_365  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_366  -30
    arc_0_0_1  depot_departure_or_bypass_758  1
    arc_0_0_1  in_degree_761  1
    arc_0_0_1  original_T_including_depot_unload_855  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_366  1
    load_0_0_1  segment_load_conservation_764  -1
    load_0_0_1  segment_prefix_lb_765  1
    load_0_0_1  segment_prefix_ub_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_367  -30
    arc_0_0_2  depot_departure_or_bypass_758  1
    arc_0_0_2  in_degree_768  1
    arc_0_0_2  original_T_including_depot_unload_855  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_367  1
    load_0_0_2  segment_load_conservation_771  -1
    load_0_0_2  segment_prefix_lb_772  1
    load_0_0_2  segment_prefix_ub_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_368  -30
    arc_0_0_3  depot_departure_or_bypass_758  1
    arc_0_0_3  in_degree_775  1
    arc_0_0_3  original_T_including_depot_unload_855  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_368  1
    load_0_0_3  segment_load_conservation_778  -1
    load_0_0_3  segment_prefix_lb_779  1
    load_0_0_3  segment_prefix_ub_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_369  -30
    arc_0_0_4  depot_departure_or_bypass_758  1
    arc_0_0_4  in_degree_782  1
    arc_0_0_4  original_T_including_depot_unload_855  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_369  1
    load_0_0_4  segment_load_conservation_785  -1
    load_0_0_4  segment_prefix_lb_786  1
    load_0_0_4  segment_prefix_ub_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_370  -30
    arc_0_0_5  depot_departure_or_bypass_758  1
    arc_0_0_5  in_degree_789  1
    arc_0_0_5  original_T_including_depot_unload_855  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_370  1
    load_0_0_5  segment_load_conservation_792  -1
    load_0_0_5  segment_prefix_lb_793  1
    load_0_0_5  segment_prefix_ub_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_371  -30
    arc_0_0_6  depot_departure_or_bypass_758  1
    arc_0_0_6  in_degree_796  1
    arc_0_0_6  original_T_including_depot_unload_855  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_371  1
    load_0_0_6  segment_load_conservation_799  -1
    load_0_0_6  segment_prefix_lb_800  1
    load_0_0_6  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_372  -30
    arc_0_0_9  depot_departure_or_bypass_758  1
    arc_0_0_9  in_degree_803  1
    arc_0_0_9  original_T_including_depot_unload_855  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_372  1
    load_0_0_9  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_373  -30
    arc_0_0_10  depot_departure_or_bypass_758  1
    arc_0_0_10  in_degree_809  1
    arc_0_0_10  original_T_including_depot_unload_855  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_373  1
    load_0_0_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_374  -30
    arc_0_0_11  depot_departure_or_bypass_758  1
    arc_0_0_11  in_degree_815  1
    arc_0_0_11  original_T_including_depot_unload_855  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_374  1
    load_0_0_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_375  -30
    arc_0_0_12  depot_departure_or_bypass_758  1
    arc_0_0_12  in_degree_821  1
    arc_0_0_12  original_T_including_depot_unload_855  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_375  1
    load_0_0_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_376  -30
    arc_0_0_13  depot_departure_or_bypass_758  1
    arc_0_0_13  in_degree_827  1
    arc_0_0_13  original_T_including_depot_unload_855  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_376  1
    load_0_0_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_377  -30
    arc_0_0_14  depot_departure_or_bypass_758  1
    arc_0_0_14  in_degree_833  1
    arc_0_0_14  original_T_including_depot_unload_855  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_377  1
    load_0_0_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_378  -30
    arc_0_0_15  depot_departure_or_bypass_758  1
    arc_0_0_15  in_degree_839  1
    arc_0_0_15  original_T_including_depot_unload_855  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_378  1
    load_0_0_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_379  -30
    arc_0_0_16  depot_departure_or_bypass_758  1
    arc_0_0_16  in_degree_845  1
    arc_0_0_16  original_T_including_depot_unload_855  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_379  1
    load_0_0_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_380  -30
    arc_0_1_0  depot_return_or_bypass_759  1
    arc_0_1_0  out_degree_760  1
    arc_0_1_0  original_T_including_depot_unload_855  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_380  1
    load_0_1_0  segment_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_381  -30
    arc_0_1_2  connected_order_arc_382  -15
    arc_0_1_2  out_degree_760  1
    arc_0_1_2  in_degree_768  1
    arc_0_1_2  original_T_including_depot_unload_855  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_381  1
    load_0_1_2  segment_load_conservation_764  1
    load_0_1_2  segment_load_conservation_771  -1
    load_0_1_2  segment_prefix_lb_772  1
    load_0_1_2  segment_prefix_ub_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_383  -30
    arc_0_1_3  connected_order_arc_384  -15
    arc_0_1_3  out_degree_760  1
    arc_0_1_3  in_degree_775  1
    arc_0_1_3  original_T_including_depot_unload_855  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_383  1
    load_0_1_3  segment_load_conservation_764  1
    load_0_1_3  segment_load_conservation_778  -1
    load_0_1_3  segment_prefix_lb_779  1
    load_0_1_3  segment_prefix_ub_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_385  -30
    arc_0_1_4  connected_order_arc_386  -15
    arc_0_1_4  out_degree_760  1
    arc_0_1_4  in_degree_782  1
    arc_0_1_4  original_T_including_depot_unload_855  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_385  1
    load_0_1_4  segment_load_conservation_764  1
    load_0_1_4  segment_load_conservation_785  -1
    load_0_1_4  segment_prefix_lb_786  1
    load_0_1_4  segment_prefix_ub_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_387  -30
    arc_0_1_5  connected_order_arc_388  -15
    arc_0_1_5  out_degree_760  1
    arc_0_1_5  in_degree_789  1
    arc_0_1_5  original_T_including_depot_unload_855  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_387  1
    load_0_1_5  segment_load_conservation_764  1
    load_0_1_5  segment_load_conservation_792  -1
    load_0_1_5  segment_prefix_lb_793  1
    load_0_1_5  segment_prefix_ub_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_389  -30
    arc_0_1_6  connected_order_arc_390  -15
    arc_0_1_6  out_degree_760  1
    arc_0_1_6  in_degree_796  1
    arc_0_1_6  original_T_including_depot_unload_855  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_389  1
    load_0_1_6  segment_load_conservation_764  1
    load_0_1_6  segment_load_conservation_799  -1
    load_0_1_6  segment_prefix_lb_800  1
    load_0_1_6  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_391  -30
    arc_0_1_9  connected_order_arc_392  -15
    arc_0_1_9  out_degree_760  1
    arc_0_1_9  in_degree_803  1
    arc_0_1_9  original_T_including_depot_unload_855  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_391  1
    load_0_1_9  segment_load_conservation_764  1
    load_0_1_9  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_393  -30
    arc_0_1_10  connected_order_arc_394  -15
    arc_0_1_10  out_degree_760  1
    arc_0_1_10  in_degree_809  1
    arc_0_1_10  original_T_including_depot_unload_855  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_393  1
    load_0_1_10  segment_load_conservation_764  1
    load_0_1_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_395  -30
    arc_0_1_11  connected_order_arc_396  -15
    arc_0_1_11  out_degree_760  1
    arc_0_1_11  in_degree_815  1
    arc_0_1_11  original_T_including_depot_unload_855  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_395  1
    load_0_1_11  segment_load_conservation_764  1
    load_0_1_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_397  -30
    arc_0_1_12  connected_order_arc_398  -15
    arc_0_1_12  out_degree_760  1
    arc_0_1_12  in_degree_821  1
    arc_0_1_12  original_T_including_depot_unload_855  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_397  1
    load_0_1_12  segment_load_conservation_764  1
    load_0_1_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_399  -30
    arc_0_1_13  connected_order_arc_400  -15
    arc_0_1_13  out_degree_760  1
    arc_0_1_13  in_degree_827  1
    arc_0_1_13  original_T_including_depot_unload_855  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_399  1
    load_0_1_13  segment_load_conservation_764  1
    load_0_1_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_401  -30
    arc_0_1_14  connected_order_arc_402  -15
    arc_0_1_14  out_degree_760  1
    arc_0_1_14  in_degree_833  1
    arc_0_1_14  original_T_including_depot_unload_855  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_401  1
    load_0_1_14  segment_load_conservation_764  1
    load_0_1_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_403  -30
    arc_0_1_15  connected_order_arc_404  -15
    arc_0_1_15  out_degree_760  1
    arc_0_1_15  in_degree_839  1
    arc_0_1_15  original_T_including_depot_unload_855  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_403  1
    load_0_1_15  segment_load_conservation_764  1
    load_0_1_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_405  -30
    arc_0_1_16  connected_order_arc_406  -15
    arc_0_1_16  out_degree_760  1
    arc_0_1_16  in_degree_845  1
    arc_0_1_16  original_T_including_depot_unload_855  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_405  1
    load_0_1_16  segment_load_conservation_764  1
    load_0_1_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_407  -30
    arc_0_2_0  depot_return_or_bypass_759  1
    arc_0_2_0  out_degree_767  1
    arc_0_2_0  original_T_including_depot_unload_855  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_407  1
    load_0_2_0  segment_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_408  -30
    arc_0_2_1  connected_order_arc_409  -15
    arc_0_2_1  in_degree_761  1
    arc_0_2_1  out_degree_767  1
    arc_0_2_1  original_T_including_depot_unload_855  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_408  1
    load_0_2_1  segment_load_conservation_764  -1
    load_0_2_1  segment_prefix_lb_765  1
    load_0_2_1  segment_prefix_ub_766  1
    load_0_2_1  segment_load_conservation_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_410  -30
    arc_0_2_3  connected_order_arc_411  -15
    arc_0_2_3  out_degree_767  1
    arc_0_2_3  in_degree_775  1
    arc_0_2_3  original_T_including_depot_unload_855  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_410  1
    load_0_2_3  segment_load_conservation_771  1
    load_0_2_3  segment_load_conservation_778  -1
    load_0_2_3  segment_prefix_lb_779  1
    load_0_2_3  segment_prefix_ub_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_412  -30
    arc_0_2_4  connected_order_arc_413  -15
    arc_0_2_4  out_degree_767  1
    arc_0_2_4  in_degree_782  1
    arc_0_2_4  original_T_including_depot_unload_855  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_412  1
    load_0_2_4  segment_load_conservation_771  1
    load_0_2_4  segment_load_conservation_785  -1
    load_0_2_4  segment_prefix_lb_786  1
    load_0_2_4  segment_prefix_ub_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_414  -30
    arc_0_2_5  connected_order_arc_415  -15
    arc_0_2_5  out_degree_767  1
    arc_0_2_5  in_degree_789  1
    arc_0_2_5  original_T_including_depot_unload_855  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_414  1
    load_0_2_5  segment_load_conservation_771  1
    load_0_2_5  segment_load_conservation_792  -1
    load_0_2_5  segment_prefix_lb_793  1
    load_0_2_5  segment_prefix_ub_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_416  -30
    arc_0_2_6  connected_order_arc_417  -15
    arc_0_2_6  out_degree_767  1
    arc_0_2_6  in_degree_796  1
    arc_0_2_6  original_T_including_depot_unload_855  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_416  1
    load_0_2_6  segment_load_conservation_771  1
    load_0_2_6  segment_load_conservation_799  -1
    load_0_2_6  segment_prefix_lb_800  1
    load_0_2_6  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_418  -30
    arc_0_2_9  connected_order_arc_419  -15
    arc_0_2_9  out_degree_767  1
    arc_0_2_9  in_degree_803  1
    arc_0_2_9  original_T_including_depot_unload_855  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_418  1
    load_0_2_9  segment_load_conservation_771  1
    load_0_2_9  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_420  -30
    arc_0_2_10  connected_order_arc_421  -15
    arc_0_2_10  out_degree_767  1
    arc_0_2_10  in_degree_809  1
    arc_0_2_10  original_T_including_depot_unload_855  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_420  1
    load_0_2_10  segment_load_conservation_771  1
    load_0_2_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_422  -30
    arc_0_2_11  connected_order_arc_423  -15
    arc_0_2_11  out_degree_767  1
    arc_0_2_11  in_degree_815  1
    arc_0_2_11  original_T_including_depot_unload_855  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_422  1
    load_0_2_11  segment_load_conservation_771  1
    load_0_2_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_424  -30
    arc_0_2_12  connected_order_arc_425  -15
    arc_0_2_12  out_degree_767  1
    arc_0_2_12  in_degree_821  1
    arc_0_2_12  original_T_including_depot_unload_855  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_424  1
    load_0_2_12  segment_load_conservation_771  1
    load_0_2_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_426  -30
    arc_0_2_13  connected_order_arc_427  -15
    arc_0_2_13  out_degree_767  1
    arc_0_2_13  in_degree_827  1
    arc_0_2_13  original_T_including_depot_unload_855  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_426  1
    load_0_2_13  segment_load_conservation_771  1
    load_0_2_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_428  -30
    arc_0_2_14  connected_order_arc_429  -15
    arc_0_2_14  out_degree_767  1
    arc_0_2_14  in_degree_833  1
    arc_0_2_14  original_T_including_depot_unload_855  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_428  1
    load_0_2_14  segment_load_conservation_771  1
    load_0_2_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_430  -30
    arc_0_2_15  connected_order_arc_431  -15
    arc_0_2_15  out_degree_767  1
    arc_0_2_15  in_degree_839  1
    arc_0_2_15  original_T_including_depot_unload_855  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_430  1
    load_0_2_15  segment_load_conservation_771  1
    load_0_2_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_432  -30
    arc_0_2_16  connected_order_arc_433  -15
    arc_0_2_16  out_degree_767  1
    arc_0_2_16  in_degree_845  1
    arc_0_2_16  original_T_including_depot_unload_855  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_432  1
    load_0_2_16  segment_load_conservation_771  1
    load_0_2_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_434  -30
    arc_0_3_0  depot_return_or_bypass_759  1
    arc_0_3_0  out_degree_774  1
    arc_0_3_0  original_T_including_depot_unload_855  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_434  1
    load_0_3_0  segment_load_conservation_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_435  -30
    arc_0_3_1  connected_order_arc_436  -15
    arc_0_3_1  in_degree_761  1
    arc_0_3_1  out_degree_774  1
    arc_0_3_1  original_T_including_depot_unload_855  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_435  1
    load_0_3_1  segment_load_conservation_764  -1
    load_0_3_1  segment_prefix_lb_765  1
    load_0_3_1  segment_prefix_ub_766  1
    load_0_3_1  segment_load_conservation_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_437  -30
    arc_0_3_2  connected_order_arc_438  -15
    arc_0_3_2  in_degree_768  1
    arc_0_3_2  out_degree_774  1
    arc_0_3_2  original_T_including_depot_unload_855  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_437  1
    load_0_3_2  segment_load_conservation_771  -1
    load_0_3_2  segment_prefix_lb_772  1
    load_0_3_2  segment_prefix_ub_773  1
    load_0_3_2  segment_load_conservation_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_439  -30
    arc_0_3_4  connected_order_arc_440  -15
    arc_0_3_4  out_degree_774  1
    arc_0_3_4  in_degree_782  1
    arc_0_3_4  original_T_including_depot_unload_855  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_439  1
    load_0_3_4  segment_load_conservation_778  1
    load_0_3_4  segment_load_conservation_785  -1
    load_0_3_4  segment_prefix_lb_786  1
    load_0_3_4  segment_prefix_ub_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_441  -30
    arc_0_3_5  connected_order_arc_442  -15
    arc_0_3_5  out_degree_774  1
    arc_0_3_5  in_degree_789  1
    arc_0_3_5  original_T_including_depot_unload_855  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_441  1
    load_0_3_5  segment_load_conservation_778  1
    load_0_3_5  segment_load_conservation_792  -1
    load_0_3_5  segment_prefix_lb_793  1
    load_0_3_5  segment_prefix_ub_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_443  -30
    arc_0_3_6  connected_order_arc_444  -15
    arc_0_3_6  out_degree_774  1
    arc_0_3_6  in_degree_796  1
    arc_0_3_6  original_T_including_depot_unload_855  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_443  1
    load_0_3_6  segment_load_conservation_778  1
    load_0_3_6  segment_load_conservation_799  -1
    load_0_3_6  segment_prefix_lb_800  1
    load_0_3_6  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_445  -30
    arc_0_3_9  connected_order_arc_446  -15
    arc_0_3_9  out_degree_774  1
    arc_0_3_9  in_degree_803  1
    arc_0_3_9  original_T_including_depot_unload_855  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_445  1
    load_0_3_9  segment_load_conservation_778  1
    load_0_3_9  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_447  -30
    arc_0_3_10  connected_order_arc_448  -15
    arc_0_3_10  out_degree_774  1
    arc_0_3_10  in_degree_809  1
    arc_0_3_10  original_T_including_depot_unload_855  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_447  1
    load_0_3_10  segment_load_conservation_778  1
    load_0_3_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_449  -30
    arc_0_3_11  connected_order_arc_450  -15
    arc_0_3_11  out_degree_774  1
    arc_0_3_11  in_degree_815  1
    arc_0_3_11  original_T_including_depot_unload_855  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_449  1
    load_0_3_11  segment_load_conservation_778  1
    load_0_3_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_451  -30
    arc_0_3_12  connected_order_arc_452  -15
    arc_0_3_12  out_degree_774  1
    arc_0_3_12  in_degree_821  1
    arc_0_3_12  original_T_including_depot_unload_855  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_451  1
    load_0_3_12  segment_load_conservation_778  1
    load_0_3_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_453  -30
    arc_0_3_13  connected_order_arc_454  -15
    arc_0_3_13  out_degree_774  1
    arc_0_3_13  in_degree_827  1
    arc_0_3_13  original_T_including_depot_unload_855  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_453  1
    load_0_3_13  segment_load_conservation_778  1
    load_0_3_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_455  -30
    arc_0_3_14  connected_order_arc_456  -15
    arc_0_3_14  out_degree_774  1
    arc_0_3_14  in_degree_833  1
    arc_0_3_14  original_T_including_depot_unload_855  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_455  1
    load_0_3_14  segment_load_conservation_778  1
    load_0_3_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_457  -30
    arc_0_3_15  connected_order_arc_458  -15
    arc_0_3_15  out_degree_774  1
    arc_0_3_15  in_degree_839  1
    arc_0_3_15  original_T_including_depot_unload_855  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_457  1
    load_0_3_15  segment_load_conservation_778  1
    load_0_3_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_459  -30
    arc_0_3_16  connected_order_arc_460  -15
    arc_0_3_16  out_degree_774  1
    arc_0_3_16  in_degree_845  1
    arc_0_3_16  original_T_including_depot_unload_855  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_459  1
    load_0_3_16  segment_load_conservation_778  1
    load_0_3_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_461  -30
    arc_0_4_0  depot_return_or_bypass_759  1
    arc_0_4_0  out_degree_781  1
    arc_0_4_0  original_T_including_depot_unload_855  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_461  1
    load_0_4_0  segment_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_462  -30
    arc_0_4_1  connected_order_arc_463  -15
    arc_0_4_1  in_degree_761  1
    arc_0_4_1  out_degree_781  1
    arc_0_4_1  original_T_including_depot_unload_855  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_462  1
    load_0_4_1  segment_load_conservation_764  -1
    load_0_4_1  segment_prefix_lb_765  1
    load_0_4_1  segment_prefix_ub_766  1
    load_0_4_1  segment_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_464  -30
    arc_0_4_2  connected_order_arc_465  -15
    arc_0_4_2  in_degree_768  1
    arc_0_4_2  out_degree_781  1
    arc_0_4_2  original_T_including_depot_unload_855  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_464  1
    load_0_4_2  segment_load_conservation_771  -1
    load_0_4_2  segment_prefix_lb_772  1
    load_0_4_2  segment_prefix_ub_773  1
    load_0_4_2  segment_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_466  -30
    arc_0_4_3  connected_order_arc_467  -15
    arc_0_4_3  in_degree_775  1
    arc_0_4_3  out_degree_781  1
    arc_0_4_3  original_T_including_depot_unload_855  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_466  1
    load_0_4_3  segment_load_conservation_778  -1
    load_0_4_3  segment_prefix_lb_779  1
    load_0_4_3  segment_prefix_ub_780  1
    load_0_4_3  segment_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_468  -30
    arc_0_4_5  connected_order_arc_469  -15
    arc_0_4_5  out_degree_781  1
    arc_0_4_5  in_degree_789  1
    arc_0_4_5  original_T_including_depot_unload_855  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_468  1
    load_0_4_5  segment_load_conservation_785  1
    load_0_4_5  segment_load_conservation_792  -1
    load_0_4_5  segment_prefix_lb_793  1
    load_0_4_5  segment_prefix_ub_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_470  -30
    arc_0_4_6  connected_order_arc_471  -15
    arc_0_4_6  out_degree_781  1
    arc_0_4_6  in_degree_796  1
    arc_0_4_6  original_T_including_depot_unload_855  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_470  1
    load_0_4_6  segment_load_conservation_785  1
    load_0_4_6  segment_load_conservation_799  -1
    load_0_4_6  segment_prefix_lb_800  1
    load_0_4_6  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_472  -30
    arc_0_4_9  connected_order_arc_473  -15
    arc_0_4_9  out_degree_781  1
    arc_0_4_9  in_degree_803  1
    arc_0_4_9  original_T_including_depot_unload_855  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_472  1
    load_0_4_9  segment_load_conservation_785  1
    load_0_4_9  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_474  -30
    arc_0_4_10  connected_order_arc_475  -15
    arc_0_4_10  out_degree_781  1
    arc_0_4_10  in_degree_809  1
    arc_0_4_10  original_T_including_depot_unload_855  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_474  1
    load_0_4_10  segment_load_conservation_785  1
    load_0_4_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_476  -30
    arc_0_4_11  connected_order_arc_477  -15
    arc_0_4_11  out_degree_781  1
    arc_0_4_11  in_degree_815  1
    arc_0_4_11  original_T_including_depot_unload_855  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_476  1
    load_0_4_11  segment_load_conservation_785  1
    load_0_4_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_478  -30
    arc_0_4_12  connected_order_arc_479  -15
    arc_0_4_12  out_degree_781  1
    arc_0_4_12  in_degree_821  1
    arc_0_4_12  original_T_including_depot_unload_855  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_478  1
    load_0_4_12  segment_load_conservation_785  1
    load_0_4_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_480  -30
    arc_0_4_13  connected_order_arc_481  -15
    arc_0_4_13  out_degree_781  1
    arc_0_4_13  in_degree_827  1
    arc_0_4_13  original_T_including_depot_unload_855  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_480  1
    load_0_4_13  segment_load_conservation_785  1
    load_0_4_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_482  -30
    arc_0_4_14  connected_order_arc_483  -15
    arc_0_4_14  out_degree_781  1
    arc_0_4_14  in_degree_833  1
    arc_0_4_14  original_T_including_depot_unload_855  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_482  1
    load_0_4_14  segment_load_conservation_785  1
    load_0_4_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_484  -30
    arc_0_4_15  connected_order_arc_485  -15
    arc_0_4_15  out_degree_781  1
    arc_0_4_15  in_degree_839  1
    arc_0_4_15  original_T_including_depot_unload_855  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_484  1
    load_0_4_15  segment_load_conservation_785  1
    load_0_4_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_486  -30
    arc_0_4_16  connected_order_arc_487  -15
    arc_0_4_16  out_degree_781  1
    arc_0_4_16  in_degree_845  1
    arc_0_4_16  original_T_including_depot_unload_855  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_486  1
    load_0_4_16  segment_load_conservation_785  1
    load_0_4_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_488  -30
    arc_0_5_0  depot_return_or_bypass_759  1
    arc_0_5_0  out_degree_788  1
    arc_0_5_0  original_T_including_depot_unload_855  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_488  1
    load_0_5_0  segment_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_489  -30
    arc_0_5_1  connected_order_arc_490  -15
    arc_0_5_1  in_degree_761  1
    arc_0_5_1  out_degree_788  1
    arc_0_5_1  original_T_including_depot_unload_855  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_489  1
    load_0_5_1  segment_load_conservation_764  -1
    load_0_5_1  segment_prefix_lb_765  1
    load_0_5_1  segment_prefix_ub_766  1
    load_0_5_1  segment_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_491  -30
    arc_0_5_2  connected_order_arc_492  -15
    arc_0_5_2  in_degree_768  1
    arc_0_5_2  out_degree_788  1
    arc_0_5_2  original_T_including_depot_unload_855  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_491  1
    load_0_5_2  segment_load_conservation_771  -1
    load_0_5_2  segment_prefix_lb_772  1
    load_0_5_2  segment_prefix_ub_773  1
    load_0_5_2  segment_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_493  -30
    arc_0_5_3  connected_order_arc_494  -15
    arc_0_5_3  in_degree_775  1
    arc_0_5_3  out_degree_788  1
    arc_0_5_3  original_T_including_depot_unload_855  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_493  1
    load_0_5_3  segment_load_conservation_778  -1
    load_0_5_3  segment_prefix_lb_779  1
    load_0_5_3  segment_prefix_ub_780  1
    load_0_5_3  segment_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_495  -30
    arc_0_5_4  connected_order_arc_496  -15
    arc_0_5_4  in_degree_782  1
    arc_0_5_4  out_degree_788  1
    arc_0_5_4  original_T_including_depot_unload_855  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_495  1
    load_0_5_4  segment_load_conservation_785  -1
    load_0_5_4  segment_prefix_lb_786  1
    load_0_5_4  segment_prefix_ub_787  1
    load_0_5_4  segment_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_497  -30
    arc_0_5_6  connected_order_arc_498  -15
    arc_0_5_6  out_degree_788  1
    arc_0_5_6  in_degree_796  1
    arc_0_5_6  original_T_including_depot_unload_855  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_497  1
    load_0_5_6  segment_load_conservation_792  1
    load_0_5_6  segment_load_conservation_799  -1
    load_0_5_6  segment_prefix_lb_800  1
    load_0_5_6  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_499  -30
    arc_0_5_9  connected_order_arc_500  -15
    arc_0_5_9  out_degree_788  1
    arc_0_5_9  in_degree_803  1
    arc_0_5_9  original_T_including_depot_unload_855  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_499  1
    load_0_5_9  segment_load_conservation_792  1
    load_0_5_9  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_501  -30
    arc_0_5_10  connected_order_arc_502  -15
    arc_0_5_10  out_degree_788  1
    arc_0_5_10  in_degree_809  1
    arc_0_5_10  original_T_including_depot_unload_855  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_501  1
    load_0_5_10  segment_load_conservation_792  1
    load_0_5_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_503  -30
    arc_0_5_11  connected_order_arc_504  -15
    arc_0_5_11  out_degree_788  1
    arc_0_5_11  in_degree_815  1
    arc_0_5_11  original_T_including_depot_unload_855  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_503  1
    load_0_5_11  segment_load_conservation_792  1
    load_0_5_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_505  -30
    arc_0_5_12  connected_order_arc_506  -15
    arc_0_5_12  out_degree_788  1
    arc_0_5_12  in_degree_821  1
    arc_0_5_12  original_T_including_depot_unload_855  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_505  1
    load_0_5_12  segment_load_conservation_792  1
    load_0_5_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_507  -30
    arc_0_5_13  connected_order_arc_508  -15
    arc_0_5_13  out_degree_788  1
    arc_0_5_13  in_degree_827  1
    arc_0_5_13  original_T_including_depot_unload_855  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_507  1
    load_0_5_13  segment_load_conservation_792  1
    load_0_5_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_509  -30
    arc_0_5_14  connected_order_arc_510  -15
    arc_0_5_14  out_degree_788  1
    arc_0_5_14  in_degree_833  1
    arc_0_5_14  original_T_including_depot_unload_855  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_509  1
    load_0_5_14  segment_load_conservation_792  1
    load_0_5_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_511  -30
    arc_0_5_15  connected_order_arc_512  -15
    arc_0_5_15  out_degree_788  1
    arc_0_5_15  in_degree_839  1
    arc_0_5_15  original_T_including_depot_unload_855  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_511  1
    load_0_5_15  segment_load_conservation_792  1
    load_0_5_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_513  -30
    arc_0_5_16  connected_order_arc_514  -15
    arc_0_5_16  out_degree_788  1
    arc_0_5_16  in_degree_845  1
    arc_0_5_16  original_T_including_depot_unload_855  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_513  1
    load_0_5_16  segment_load_conservation_792  1
    load_0_5_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_515  -30
    arc_0_6_0  depot_return_or_bypass_759  1
    arc_0_6_0  out_degree_795  1
    arc_0_6_0  original_T_including_depot_unload_855  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_515  1
    load_0_6_0  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_516  -30
    arc_0_6_1  connected_order_arc_517  -15
    arc_0_6_1  in_degree_761  1
    arc_0_6_1  out_degree_795  1
    arc_0_6_1  original_T_including_depot_unload_855  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_516  1
    load_0_6_1  segment_load_conservation_764  -1
    load_0_6_1  segment_prefix_lb_765  1
    load_0_6_1  segment_prefix_ub_766  1
    load_0_6_1  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_518  -30
    arc_0_6_2  connected_order_arc_519  -15
    arc_0_6_2  in_degree_768  1
    arc_0_6_2  out_degree_795  1
    arc_0_6_2  original_T_including_depot_unload_855  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_518  1
    load_0_6_2  segment_load_conservation_771  -1
    load_0_6_2  segment_prefix_lb_772  1
    load_0_6_2  segment_prefix_ub_773  1
    load_0_6_2  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_520  -30
    arc_0_6_3  connected_order_arc_521  -15
    arc_0_6_3  in_degree_775  1
    arc_0_6_3  out_degree_795  1
    arc_0_6_3  original_T_including_depot_unload_855  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_520  1
    load_0_6_3  segment_load_conservation_778  -1
    load_0_6_3  segment_prefix_lb_779  1
    load_0_6_3  segment_prefix_ub_780  1
    load_0_6_3  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_522  -30
    arc_0_6_4  connected_order_arc_523  -15
    arc_0_6_4  in_degree_782  1
    arc_0_6_4  out_degree_795  1
    arc_0_6_4  original_T_including_depot_unload_855  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_522  1
    load_0_6_4  segment_load_conservation_785  -1
    load_0_6_4  segment_prefix_lb_786  1
    load_0_6_4  segment_prefix_ub_787  1
    load_0_6_4  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_524  -30
    arc_0_6_5  connected_order_arc_525  -15
    arc_0_6_5  in_degree_789  1
    arc_0_6_5  out_degree_795  1
    arc_0_6_5  original_T_including_depot_unload_855  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_524  1
    load_0_6_5  segment_load_conservation_792  -1
    load_0_6_5  segment_prefix_lb_793  1
    load_0_6_5  segment_prefix_ub_794  1
    load_0_6_5  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_9  arc_capacity_526  -30
    arc_0_6_9  connected_order_arc_527  -15
    arc_0_6_9  out_degree_795  1
    arc_0_6_9  in_degree_803  1
    arc_0_6_9  original_T_including_depot_unload_855  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_9  arc_capacity_526  1
    load_0_6_9  segment_load_conservation_799  1
    load_0_6_9  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_10  arc_capacity_528  -30
    arc_0_6_10  connected_order_arc_529  -15
    arc_0_6_10  out_degree_795  1
    arc_0_6_10  in_degree_809  1
    arc_0_6_10  original_T_including_depot_unload_855  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_10  arc_capacity_528  1
    load_0_6_10  segment_load_conservation_799  1
    load_0_6_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_530  -30
    arc_0_6_11  connected_order_arc_531  -15
    arc_0_6_11  out_degree_795  1
    arc_0_6_11  in_degree_815  1
    arc_0_6_11  original_T_including_depot_unload_855  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_530  1
    load_0_6_11  segment_load_conservation_799  1
    load_0_6_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_532  -30
    arc_0_6_12  connected_order_arc_533  -15
    arc_0_6_12  out_degree_795  1
    arc_0_6_12  in_degree_821  1
    arc_0_6_12  original_T_including_depot_unload_855  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_532  1
    load_0_6_12  segment_load_conservation_799  1
    load_0_6_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_534  -30
    arc_0_6_13  connected_order_arc_535  -15
    arc_0_6_13  out_degree_795  1
    arc_0_6_13  in_degree_827  1
    arc_0_6_13  original_T_including_depot_unload_855  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_534  1
    load_0_6_13  segment_load_conservation_799  1
    load_0_6_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_536  -30
    arc_0_6_14  connected_order_arc_537  -15
    arc_0_6_14  out_degree_795  1
    arc_0_6_14  in_degree_833  1
    arc_0_6_14  original_T_including_depot_unload_855  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_536  1
    load_0_6_14  segment_load_conservation_799  1
    load_0_6_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_538  -30
    arc_0_6_15  connected_order_arc_539  -15
    arc_0_6_15  out_degree_795  1
    arc_0_6_15  in_degree_839  1
    arc_0_6_15  original_T_including_depot_unload_855  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_538  1
    load_0_6_15  segment_load_conservation_799  1
    load_0_6_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_540  -30
    arc_0_6_16  connected_order_arc_541  -15
    arc_0_6_16  out_degree_795  1
    arc_0_6_16  in_degree_845  1
    arc_0_6_16  original_T_including_depot_unload_855  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_540  1
    load_0_6_16  segment_load_conservation_799  1
    load_0_6_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_542  -30
    arc_0_9_0  depot_return_or_bypass_759  1
    arc_0_9_0  out_degree_802  1
    arc_0_9_0  original_T_including_depot_unload_855  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_542  1
    load_0_9_0  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_543  -30
    arc_0_9_1  connected_order_arc_544  -15
    arc_0_9_1  in_degree_761  1
    arc_0_9_1  out_degree_802  1
    arc_0_9_1  original_T_including_depot_unload_855  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_543  1
    load_0_9_1  segment_load_conservation_764  -1
    load_0_9_1  segment_prefix_lb_765  1
    load_0_9_1  segment_prefix_ub_766  1
    load_0_9_1  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_545  -30
    arc_0_9_2  connected_order_arc_546  -15
    arc_0_9_2  in_degree_768  1
    arc_0_9_2  out_degree_802  1
    arc_0_9_2  original_T_including_depot_unload_855  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_545  1
    load_0_9_2  segment_load_conservation_771  -1
    load_0_9_2  segment_prefix_lb_772  1
    load_0_9_2  segment_prefix_ub_773  1
    load_0_9_2  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_547  -30
    arc_0_9_3  connected_order_arc_548  -15
    arc_0_9_3  in_degree_775  1
    arc_0_9_3  out_degree_802  1
    arc_0_9_3  original_T_including_depot_unload_855  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_547  1
    load_0_9_3  segment_load_conservation_778  -1
    load_0_9_3  segment_prefix_lb_779  1
    load_0_9_3  segment_prefix_ub_780  1
    load_0_9_3  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_549  -30
    arc_0_9_4  connected_order_arc_550  -15
    arc_0_9_4  in_degree_782  1
    arc_0_9_4  out_degree_802  1
    arc_0_9_4  original_T_including_depot_unload_855  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_549  1
    load_0_9_4  segment_load_conservation_785  -1
    load_0_9_4  segment_prefix_lb_786  1
    load_0_9_4  segment_prefix_ub_787  1
    load_0_9_4  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_551  -30
    arc_0_9_5  connected_order_arc_552  -15
    arc_0_9_5  in_degree_789  1
    arc_0_9_5  out_degree_802  1
    arc_0_9_5  original_T_including_depot_unload_855  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_551  1
    load_0_9_5  segment_load_conservation_792  -1
    load_0_9_5  segment_prefix_lb_793  1
    load_0_9_5  segment_prefix_ub_794  1
    load_0_9_5  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_6  arc_capacity_553  -30
    arc_0_9_6  connected_order_arc_554  -15
    arc_0_9_6  in_degree_796  1
    arc_0_9_6  out_degree_802  1
    arc_0_9_6  original_T_including_depot_unload_855  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_6  arc_capacity_553  1
    load_0_9_6  segment_load_conservation_799  -1
    load_0_9_6  segment_prefix_lb_800  1
    load_0_9_6  segment_prefix_ub_801  1
    load_0_9_6  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_555  -30
    arc_0_9_10  connected_order_arc_556  -15
    arc_0_9_10  out_degree_802  1
    arc_0_9_10  in_degree_809  1
    arc_0_9_10  original_T_including_depot_unload_855  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_555  1
    load_0_9_10  free_load_conservation_807  1
    load_0_9_10  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_557  -30
    arc_0_9_11  connected_order_arc_558  -15
    arc_0_9_11  out_degree_802  1
    arc_0_9_11  in_degree_815  1
    arc_0_9_11  original_T_including_depot_unload_855  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_557  1
    load_0_9_11  free_load_conservation_807  1
    load_0_9_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_559  -30
    arc_0_9_12  connected_order_arc_560  -15
    arc_0_9_12  out_degree_802  1
    arc_0_9_12  in_degree_821  1
    arc_0_9_12  original_T_including_depot_unload_855  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_559  1
    load_0_9_12  free_load_conservation_807  1
    load_0_9_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_561  -30
    arc_0_9_13  connected_order_arc_562  -15
    arc_0_9_13  out_degree_802  1
    arc_0_9_13  in_degree_827  1
    arc_0_9_13  original_T_including_depot_unload_855  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_561  1
    load_0_9_13  free_load_conservation_807  1
    load_0_9_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_563  -30
    arc_0_9_14  connected_order_arc_564  -15
    arc_0_9_14  out_degree_802  1
    arc_0_9_14  in_degree_833  1
    arc_0_9_14  original_T_including_depot_unload_855  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_563  1
    load_0_9_14  free_load_conservation_807  1
    load_0_9_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_565  -30
    arc_0_9_15  connected_order_arc_566  -15
    arc_0_9_15  out_degree_802  1
    arc_0_9_15  in_degree_839  1
    arc_0_9_15  original_T_including_depot_unload_855  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_565  1
    load_0_9_15  free_load_conservation_807  1
    load_0_9_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_16  arc_capacity_567  -30
    arc_0_9_16  connected_order_arc_568  -15
    arc_0_9_16  out_degree_802  1
    arc_0_9_16  in_degree_845  1
    arc_0_9_16  original_T_including_depot_unload_855  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_16  arc_capacity_567  1
    load_0_9_16  free_load_conservation_807  1
    load_0_9_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_569  -30
    arc_0_10_0  depot_return_or_bypass_759  1
    arc_0_10_0  out_degree_808  1
    arc_0_10_0  original_T_including_depot_unload_855  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_569  1
    load_0_10_0  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_570  -30
    arc_0_10_1  connected_order_arc_571  -15
    arc_0_10_1  in_degree_761  1
    arc_0_10_1  out_degree_808  1
    arc_0_10_1  original_T_including_depot_unload_855  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_570  1
    load_0_10_1  segment_load_conservation_764  -1
    load_0_10_1  segment_prefix_lb_765  1
    load_0_10_1  segment_prefix_ub_766  1
    load_0_10_1  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_572  -30
    arc_0_10_2  connected_order_arc_573  -15
    arc_0_10_2  in_degree_768  1
    arc_0_10_2  out_degree_808  1
    arc_0_10_2  original_T_including_depot_unload_855  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_572  1
    load_0_10_2  segment_load_conservation_771  -1
    load_0_10_2  segment_prefix_lb_772  1
    load_0_10_2  segment_prefix_ub_773  1
    load_0_10_2  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_574  -30
    arc_0_10_3  connected_order_arc_575  -15
    arc_0_10_3  in_degree_775  1
    arc_0_10_3  out_degree_808  1
    arc_0_10_3  original_T_including_depot_unload_855  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_574  1
    load_0_10_3  segment_load_conservation_778  -1
    load_0_10_3  segment_prefix_lb_779  1
    load_0_10_3  segment_prefix_ub_780  1
    load_0_10_3  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_576  -30
    arc_0_10_4  connected_order_arc_577  -15
    arc_0_10_4  in_degree_782  1
    arc_0_10_4  out_degree_808  1
    arc_0_10_4  original_T_including_depot_unload_855  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_576  1
    load_0_10_4  segment_load_conservation_785  -1
    load_0_10_4  segment_prefix_lb_786  1
    load_0_10_4  segment_prefix_ub_787  1
    load_0_10_4  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_578  -30
    arc_0_10_5  connected_order_arc_579  -15
    arc_0_10_5  in_degree_789  1
    arc_0_10_5  out_degree_808  1
    arc_0_10_5  original_T_including_depot_unload_855  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_578  1
    load_0_10_5  segment_load_conservation_792  -1
    load_0_10_5  segment_prefix_lb_793  1
    load_0_10_5  segment_prefix_ub_794  1
    load_0_10_5  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_6  arc_capacity_580  -30
    arc_0_10_6  connected_order_arc_581  -15
    arc_0_10_6  in_degree_796  1
    arc_0_10_6  out_degree_808  1
    arc_0_10_6  original_T_including_depot_unload_855  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_6  arc_capacity_580  1
    load_0_10_6  segment_load_conservation_799  -1
    load_0_10_6  segment_prefix_lb_800  1
    load_0_10_6  segment_prefix_ub_801  1
    load_0_10_6  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_582  -30
    arc_0_10_9  connected_order_arc_583  -15
    arc_0_10_9  in_degree_803  1
    arc_0_10_9  out_degree_808  1
    arc_0_10_9  original_T_including_depot_unload_855  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_582  1
    load_0_10_9  free_load_conservation_807  -1
    load_0_10_9  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_584  -30
    arc_0_10_11  connected_order_arc_585  -15
    arc_0_10_11  out_degree_808  1
    arc_0_10_11  in_degree_815  1
    arc_0_10_11  original_T_including_depot_unload_855  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_584  1
    load_0_10_11  free_load_conservation_813  1
    load_0_10_11  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_586  -30
    arc_0_10_12  connected_order_arc_587  -15
    arc_0_10_12  out_degree_808  1
    arc_0_10_12  in_degree_821  1
    arc_0_10_12  original_T_including_depot_unload_855  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_586  1
    load_0_10_12  free_load_conservation_813  1
    load_0_10_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_588  -30
    arc_0_10_13  connected_order_arc_589  -15
    arc_0_10_13  out_degree_808  1
    arc_0_10_13  in_degree_827  1
    arc_0_10_13  original_T_including_depot_unload_855  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_588  1
    load_0_10_13  free_load_conservation_813  1
    load_0_10_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_590  -30
    arc_0_10_14  connected_order_arc_591  -15
    arc_0_10_14  out_degree_808  1
    arc_0_10_14  in_degree_833  1
    arc_0_10_14  original_T_including_depot_unload_855  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_590  1
    load_0_10_14  free_load_conservation_813  1
    load_0_10_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_592  -30
    arc_0_10_15  connected_order_arc_593  -15
    arc_0_10_15  out_degree_808  1
    arc_0_10_15  in_degree_839  1
    arc_0_10_15  original_T_including_depot_unload_855  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_592  1
    load_0_10_15  free_load_conservation_813  1
    load_0_10_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_16  arc_capacity_594  -30
    arc_0_10_16  connected_order_arc_595  -15
    arc_0_10_16  out_degree_808  1
    arc_0_10_16  in_degree_845  1
    arc_0_10_16  original_T_including_depot_unload_855  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_16  arc_capacity_594  1
    load_0_10_16  free_load_conservation_813  1
    load_0_10_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_596  -30
    arc_0_11_0  depot_return_or_bypass_759  1
    arc_0_11_0  out_degree_814  1
    arc_0_11_0  original_T_including_depot_unload_855  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_596  1
    load_0_11_0  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_597  -30
    arc_0_11_1  connected_order_arc_598  -15
    arc_0_11_1  in_degree_761  1
    arc_0_11_1  out_degree_814  1
    arc_0_11_1  original_T_including_depot_unload_855  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_597  1
    load_0_11_1  segment_load_conservation_764  -1
    load_0_11_1  segment_prefix_lb_765  1
    load_0_11_1  segment_prefix_ub_766  1
    load_0_11_1  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_599  -30
    arc_0_11_2  connected_order_arc_600  -15
    arc_0_11_2  in_degree_768  1
    arc_0_11_2  out_degree_814  1
    arc_0_11_2  original_T_including_depot_unload_855  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_599  1
    load_0_11_2  segment_load_conservation_771  -1
    load_0_11_2  segment_prefix_lb_772  1
    load_0_11_2  segment_prefix_ub_773  1
    load_0_11_2  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_601  -30
    arc_0_11_3  connected_order_arc_602  -15
    arc_0_11_3  in_degree_775  1
    arc_0_11_3  out_degree_814  1
    arc_0_11_3  original_T_including_depot_unload_855  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_601  1
    load_0_11_3  segment_load_conservation_778  -1
    load_0_11_3  segment_prefix_lb_779  1
    load_0_11_3  segment_prefix_ub_780  1
    load_0_11_3  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_603  -30
    arc_0_11_4  connected_order_arc_604  -15
    arc_0_11_4  in_degree_782  1
    arc_0_11_4  out_degree_814  1
    arc_0_11_4  original_T_including_depot_unload_855  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_603  1
    load_0_11_4  segment_load_conservation_785  -1
    load_0_11_4  segment_prefix_lb_786  1
    load_0_11_4  segment_prefix_ub_787  1
    load_0_11_4  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_605  -30
    arc_0_11_5  connected_order_arc_606  -15
    arc_0_11_5  in_degree_789  1
    arc_0_11_5  out_degree_814  1
    arc_0_11_5  original_T_including_depot_unload_855  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_605  1
    load_0_11_5  segment_load_conservation_792  -1
    load_0_11_5  segment_prefix_lb_793  1
    load_0_11_5  segment_prefix_ub_794  1
    load_0_11_5  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_607  -30
    arc_0_11_6  connected_order_arc_608  -15
    arc_0_11_6  in_degree_796  1
    arc_0_11_6  out_degree_814  1
    arc_0_11_6  original_T_including_depot_unload_855  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_607  1
    load_0_11_6  segment_load_conservation_799  -1
    load_0_11_6  segment_prefix_lb_800  1
    load_0_11_6  segment_prefix_ub_801  1
    load_0_11_6  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_609  -30
    arc_0_11_9  connected_order_arc_610  -15
    arc_0_11_9  in_degree_803  1
    arc_0_11_9  out_degree_814  1
    arc_0_11_9  original_T_including_depot_unload_855  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_609  1
    load_0_11_9  free_load_conservation_807  -1
    load_0_11_9  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_611  -30
    arc_0_11_10  connected_order_arc_612  -15
    arc_0_11_10  in_degree_809  1
    arc_0_11_10  out_degree_814  1
    arc_0_11_10  original_T_including_depot_unload_855  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_611  1
    load_0_11_10  free_load_conservation_813  -1
    load_0_11_10  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_613  -30
    arc_0_11_12  connected_order_arc_614  -15
    arc_0_11_12  out_degree_814  1
    arc_0_11_12  in_degree_821  1
    arc_0_11_12  original_T_including_depot_unload_855  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_613  1
    load_0_11_12  free_load_conservation_819  1
    load_0_11_12  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_615  -30
    arc_0_11_13  connected_order_arc_616  -15
    arc_0_11_13  out_degree_814  1
    arc_0_11_13  in_degree_827  1
    arc_0_11_13  original_T_including_depot_unload_855  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_615  1
    load_0_11_13  free_load_conservation_819  1
    load_0_11_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_617  -30
    arc_0_11_14  connected_order_arc_618  -15
    arc_0_11_14  out_degree_814  1
    arc_0_11_14  in_degree_833  1
    arc_0_11_14  original_T_including_depot_unload_855  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_617  1
    load_0_11_14  free_load_conservation_819  1
    load_0_11_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_619  -30
    arc_0_11_15  connected_order_arc_620  -15
    arc_0_11_15  out_degree_814  1
    arc_0_11_15  in_degree_839  1
    arc_0_11_15  original_T_including_depot_unload_855  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_619  1
    load_0_11_15  free_load_conservation_819  1
    load_0_11_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_621  -30
    arc_0_11_16  connected_order_arc_622  -15
    arc_0_11_16  out_degree_814  1
    arc_0_11_16  in_degree_845  1
    arc_0_11_16  original_T_including_depot_unload_855  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_621  1
    load_0_11_16  free_load_conservation_819  1
    load_0_11_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_623  -30
    arc_0_12_0  depot_return_or_bypass_759  1
    arc_0_12_0  out_degree_820  1
    arc_0_12_0  original_T_including_depot_unload_855  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_623  1
    load_0_12_0  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_624  -30
    arc_0_12_1  connected_order_arc_625  -15
    arc_0_12_1  in_degree_761  1
    arc_0_12_1  out_degree_820  1
    arc_0_12_1  original_T_including_depot_unload_855  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_624  1
    load_0_12_1  segment_load_conservation_764  -1
    load_0_12_1  segment_prefix_lb_765  1
    load_0_12_1  segment_prefix_ub_766  1
    load_0_12_1  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_626  -30
    arc_0_12_2  connected_order_arc_627  -15
    arc_0_12_2  in_degree_768  1
    arc_0_12_2  out_degree_820  1
    arc_0_12_2  original_T_including_depot_unload_855  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_626  1
    load_0_12_2  segment_load_conservation_771  -1
    load_0_12_2  segment_prefix_lb_772  1
    load_0_12_2  segment_prefix_ub_773  1
    load_0_12_2  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_628  -30
    arc_0_12_3  connected_order_arc_629  -15
    arc_0_12_3  in_degree_775  1
    arc_0_12_3  out_degree_820  1
    arc_0_12_3  original_T_including_depot_unload_855  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_628  1
    load_0_12_3  segment_load_conservation_778  -1
    load_0_12_3  segment_prefix_lb_779  1
    load_0_12_3  segment_prefix_ub_780  1
    load_0_12_3  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_630  -30
    arc_0_12_4  connected_order_arc_631  -15
    arc_0_12_4  in_degree_782  1
    arc_0_12_4  out_degree_820  1
    arc_0_12_4  original_T_including_depot_unload_855  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_630  1
    load_0_12_4  segment_load_conservation_785  -1
    load_0_12_4  segment_prefix_lb_786  1
    load_0_12_4  segment_prefix_ub_787  1
    load_0_12_4  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_632  -30
    arc_0_12_5  connected_order_arc_633  -15
    arc_0_12_5  in_degree_789  1
    arc_0_12_5  out_degree_820  1
    arc_0_12_5  original_T_including_depot_unload_855  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_632  1
    load_0_12_5  segment_load_conservation_792  -1
    load_0_12_5  segment_prefix_lb_793  1
    load_0_12_5  segment_prefix_ub_794  1
    load_0_12_5  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_634  -30
    arc_0_12_6  connected_order_arc_635  -15
    arc_0_12_6  in_degree_796  1
    arc_0_12_6  out_degree_820  1
    arc_0_12_6  original_T_including_depot_unload_855  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_634  1
    load_0_12_6  segment_load_conservation_799  -1
    load_0_12_6  segment_prefix_lb_800  1
    load_0_12_6  segment_prefix_ub_801  1
    load_0_12_6  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_636  -30
    arc_0_12_9  connected_order_arc_637  -15
    arc_0_12_9  in_degree_803  1
    arc_0_12_9  out_degree_820  1
    arc_0_12_9  original_T_including_depot_unload_855  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_636  1
    load_0_12_9  free_load_conservation_807  -1
    load_0_12_9  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_638  -30
    arc_0_12_10  connected_order_arc_639  -15
    arc_0_12_10  in_degree_809  1
    arc_0_12_10  out_degree_820  1
    arc_0_12_10  original_T_including_depot_unload_855  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_638  1
    load_0_12_10  free_load_conservation_813  -1
    load_0_12_10  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_640  -30
    arc_0_12_11  connected_order_arc_641  -15
    arc_0_12_11  in_degree_815  1
    arc_0_12_11  out_degree_820  1
    arc_0_12_11  original_T_including_depot_unload_855  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_640  1
    load_0_12_11  free_load_conservation_819  -1
    load_0_12_11  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_642  -30
    arc_0_12_13  connected_order_arc_643  -15
    arc_0_12_13  out_degree_820  1
    arc_0_12_13  in_degree_827  1
    arc_0_12_13  original_T_including_depot_unload_855  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_642  1
    load_0_12_13  free_load_conservation_825  1
    load_0_12_13  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_644  -30
    arc_0_12_14  connected_order_arc_645  -15
    arc_0_12_14  out_degree_820  1
    arc_0_12_14  in_degree_833  1
    arc_0_12_14  original_T_including_depot_unload_855  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_644  1
    load_0_12_14  free_load_conservation_825  1
    load_0_12_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_646  -30
    arc_0_12_15  connected_order_arc_647  -15
    arc_0_12_15  out_degree_820  1
    arc_0_12_15  in_degree_839  1
    arc_0_12_15  original_T_including_depot_unload_855  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_646  1
    load_0_12_15  free_load_conservation_825  1
    load_0_12_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_648  -30
    arc_0_12_16  connected_order_arc_649  -15
    arc_0_12_16  out_degree_820  1
    arc_0_12_16  in_degree_845  1
    arc_0_12_16  original_T_including_depot_unload_855  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_648  1
    load_0_12_16  free_load_conservation_825  1
    load_0_12_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_650  -30
    arc_0_13_0  depot_return_or_bypass_759  1
    arc_0_13_0  out_degree_826  1
    arc_0_13_0  original_T_including_depot_unload_855  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_650  1
    load_0_13_0  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_651  -30
    arc_0_13_1  connected_order_arc_652  -15
    arc_0_13_1  in_degree_761  1
    arc_0_13_1  out_degree_826  1
    arc_0_13_1  original_T_including_depot_unload_855  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_651  1
    load_0_13_1  segment_load_conservation_764  -1
    load_0_13_1  segment_prefix_lb_765  1
    load_0_13_1  segment_prefix_ub_766  1
    load_0_13_1  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_653  -30
    arc_0_13_2  connected_order_arc_654  -15
    arc_0_13_2  in_degree_768  1
    arc_0_13_2  out_degree_826  1
    arc_0_13_2  original_T_including_depot_unload_855  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_653  1
    load_0_13_2  segment_load_conservation_771  -1
    load_0_13_2  segment_prefix_lb_772  1
    load_0_13_2  segment_prefix_ub_773  1
    load_0_13_2  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_655  -30
    arc_0_13_3  connected_order_arc_656  -15
    arc_0_13_3  in_degree_775  1
    arc_0_13_3  out_degree_826  1
    arc_0_13_3  original_T_including_depot_unload_855  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_655  1
    load_0_13_3  segment_load_conservation_778  -1
    load_0_13_3  segment_prefix_lb_779  1
    load_0_13_3  segment_prefix_ub_780  1
    load_0_13_3  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_657  -30
    arc_0_13_4  connected_order_arc_658  -15
    arc_0_13_4  in_degree_782  1
    arc_0_13_4  out_degree_826  1
    arc_0_13_4  original_T_including_depot_unload_855  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_657  1
    load_0_13_4  segment_load_conservation_785  -1
    load_0_13_4  segment_prefix_lb_786  1
    load_0_13_4  segment_prefix_ub_787  1
    load_0_13_4  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_659  -30
    arc_0_13_5  connected_order_arc_660  -15
    arc_0_13_5  in_degree_789  1
    arc_0_13_5  out_degree_826  1
    arc_0_13_5  original_T_including_depot_unload_855  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_659  1
    load_0_13_5  segment_load_conservation_792  -1
    load_0_13_5  segment_prefix_lb_793  1
    load_0_13_5  segment_prefix_ub_794  1
    load_0_13_5  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_661  -30
    arc_0_13_6  connected_order_arc_662  -15
    arc_0_13_6  in_degree_796  1
    arc_0_13_6  out_degree_826  1
    arc_0_13_6  original_T_including_depot_unload_855  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_661  1
    load_0_13_6  segment_load_conservation_799  -1
    load_0_13_6  segment_prefix_lb_800  1
    load_0_13_6  segment_prefix_ub_801  1
    load_0_13_6  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_663  -30
    arc_0_13_9  connected_order_arc_664  -15
    arc_0_13_9  in_degree_803  1
    arc_0_13_9  out_degree_826  1
    arc_0_13_9  original_T_including_depot_unload_855  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_663  1
    load_0_13_9  free_load_conservation_807  -1
    load_0_13_9  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_665  -30
    arc_0_13_10  connected_order_arc_666  -15
    arc_0_13_10  in_degree_809  1
    arc_0_13_10  out_degree_826  1
    arc_0_13_10  original_T_including_depot_unload_855  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_665  1
    load_0_13_10  free_load_conservation_813  -1
    load_0_13_10  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_667  -30
    arc_0_13_11  connected_order_arc_668  -15
    arc_0_13_11  in_degree_815  1
    arc_0_13_11  out_degree_826  1
    arc_0_13_11  original_T_including_depot_unload_855  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_667  1
    load_0_13_11  free_load_conservation_819  -1
    load_0_13_11  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_669  -30
    arc_0_13_12  connected_order_arc_670  -15
    arc_0_13_12  in_degree_821  1
    arc_0_13_12  out_degree_826  1
    arc_0_13_12  original_T_including_depot_unload_855  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_669  1
    load_0_13_12  free_load_conservation_825  -1
    load_0_13_12  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_671  -30
    arc_0_13_14  connected_order_arc_672  -15
    arc_0_13_14  out_degree_826  1
    arc_0_13_14  in_degree_833  1
    arc_0_13_14  original_T_including_depot_unload_855  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_671  1
    load_0_13_14  free_load_conservation_831  1
    load_0_13_14  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_673  -30
    arc_0_13_15  connected_order_arc_674  -15
    arc_0_13_15  out_degree_826  1
    arc_0_13_15  in_degree_839  1
    arc_0_13_15  original_T_including_depot_unload_855  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_673  1
    load_0_13_15  free_load_conservation_831  1
    load_0_13_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_675  -30
    arc_0_13_16  connected_order_arc_676  -15
    arc_0_13_16  out_degree_826  1
    arc_0_13_16  in_degree_845  1
    arc_0_13_16  original_T_including_depot_unload_855  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_675  1
    load_0_13_16  free_load_conservation_831  1
    load_0_13_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_677  -30
    arc_0_14_0  depot_return_or_bypass_759  1
    arc_0_14_0  out_degree_832  1
    arc_0_14_0  original_T_including_depot_unload_855  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_677  1
    load_0_14_0  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_678  -30
    arc_0_14_1  connected_order_arc_679  -15
    arc_0_14_1  in_degree_761  1
    arc_0_14_1  out_degree_832  1
    arc_0_14_1  original_T_including_depot_unload_855  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_678  1
    load_0_14_1  segment_load_conservation_764  -1
    load_0_14_1  segment_prefix_lb_765  1
    load_0_14_1  segment_prefix_ub_766  1
    load_0_14_1  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_680  -30
    arc_0_14_2  connected_order_arc_681  -15
    arc_0_14_2  in_degree_768  1
    arc_0_14_2  out_degree_832  1
    arc_0_14_2  original_T_including_depot_unload_855  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_680  1
    load_0_14_2  segment_load_conservation_771  -1
    load_0_14_2  segment_prefix_lb_772  1
    load_0_14_2  segment_prefix_ub_773  1
    load_0_14_2  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_682  -30
    arc_0_14_3  connected_order_arc_683  -15
    arc_0_14_3  in_degree_775  1
    arc_0_14_3  out_degree_832  1
    arc_0_14_3  original_T_including_depot_unload_855  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_682  1
    load_0_14_3  segment_load_conservation_778  -1
    load_0_14_3  segment_prefix_lb_779  1
    load_0_14_3  segment_prefix_ub_780  1
    load_0_14_3  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_684  -30
    arc_0_14_4  connected_order_arc_685  -15
    arc_0_14_4  in_degree_782  1
    arc_0_14_4  out_degree_832  1
    arc_0_14_4  original_T_including_depot_unload_855  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_684  1
    load_0_14_4  segment_load_conservation_785  -1
    load_0_14_4  segment_prefix_lb_786  1
    load_0_14_4  segment_prefix_ub_787  1
    load_0_14_4  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_686  -30
    arc_0_14_5  connected_order_arc_687  -15
    arc_0_14_5  in_degree_789  1
    arc_0_14_5  out_degree_832  1
    arc_0_14_5  original_T_including_depot_unload_855  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_686  1
    load_0_14_5  segment_load_conservation_792  -1
    load_0_14_5  segment_prefix_lb_793  1
    load_0_14_5  segment_prefix_ub_794  1
    load_0_14_5  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_688  -30
    arc_0_14_6  connected_order_arc_689  -15
    arc_0_14_6  in_degree_796  1
    arc_0_14_6  out_degree_832  1
    arc_0_14_6  original_T_including_depot_unload_855  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_688  1
    load_0_14_6  segment_load_conservation_799  -1
    load_0_14_6  segment_prefix_lb_800  1
    load_0_14_6  segment_prefix_ub_801  1
    load_0_14_6  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_690  -30
    arc_0_14_9  connected_order_arc_691  -15
    arc_0_14_9  in_degree_803  1
    arc_0_14_9  out_degree_832  1
    arc_0_14_9  original_T_including_depot_unload_855  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_690  1
    load_0_14_9  free_load_conservation_807  -1
    load_0_14_9  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_692  -30
    arc_0_14_10  connected_order_arc_693  -15
    arc_0_14_10  in_degree_809  1
    arc_0_14_10  out_degree_832  1
    arc_0_14_10  original_T_including_depot_unload_855  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_692  1
    load_0_14_10  free_load_conservation_813  -1
    load_0_14_10  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_694  -30
    arc_0_14_11  connected_order_arc_695  -15
    arc_0_14_11  in_degree_815  1
    arc_0_14_11  out_degree_832  1
    arc_0_14_11  original_T_including_depot_unload_855  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_694  1
    load_0_14_11  free_load_conservation_819  -1
    load_0_14_11  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_696  -30
    arc_0_14_12  connected_order_arc_697  -15
    arc_0_14_12  in_degree_821  1
    arc_0_14_12  out_degree_832  1
    arc_0_14_12  original_T_including_depot_unload_855  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_696  1
    load_0_14_12  free_load_conservation_825  -1
    load_0_14_12  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_698  -30
    arc_0_14_13  connected_order_arc_699  -15
    arc_0_14_13  in_degree_827  1
    arc_0_14_13  out_degree_832  1
    arc_0_14_13  original_T_including_depot_unload_855  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_698  1
    load_0_14_13  free_load_conservation_831  -1
    load_0_14_13  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_700  -30
    arc_0_14_15  connected_order_arc_701  -15
    arc_0_14_15  out_degree_832  1
    arc_0_14_15  in_degree_839  1
    arc_0_14_15  original_T_including_depot_unload_855  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_700  1
    load_0_14_15  free_load_conservation_837  1
    load_0_14_15  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_702  -30
    arc_0_14_16  connected_order_arc_703  -15
    arc_0_14_16  out_degree_832  1
    arc_0_14_16  in_degree_845  1
    arc_0_14_16  original_T_including_depot_unload_855  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_702  1
    load_0_14_16  free_load_conservation_837  1
    load_0_14_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_704  -30
    arc_0_15_0  depot_return_or_bypass_759  1
    arc_0_15_0  out_degree_838  1
    arc_0_15_0  original_T_including_depot_unload_855  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_704  1
    load_0_15_0  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_705  -30
    arc_0_15_1  connected_order_arc_706  -15
    arc_0_15_1  in_degree_761  1
    arc_0_15_1  out_degree_838  1
    arc_0_15_1  original_T_including_depot_unload_855  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_705  1
    load_0_15_1  segment_load_conservation_764  -1
    load_0_15_1  segment_prefix_lb_765  1
    load_0_15_1  segment_prefix_ub_766  1
    load_0_15_1  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_707  -30
    arc_0_15_2  connected_order_arc_708  -15
    arc_0_15_2  in_degree_768  1
    arc_0_15_2  out_degree_838  1
    arc_0_15_2  original_T_including_depot_unload_855  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_707  1
    load_0_15_2  segment_load_conservation_771  -1
    load_0_15_2  segment_prefix_lb_772  1
    load_0_15_2  segment_prefix_ub_773  1
    load_0_15_2  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_709  -30
    arc_0_15_3  connected_order_arc_710  -15
    arc_0_15_3  in_degree_775  1
    arc_0_15_3  out_degree_838  1
    arc_0_15_3  original_T_including_depot_unload_855  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_709  1
    load_0_15_3  segment_load_conservation_778  -1
    load_0_15_3  segment_prefix_lb_779  1
    load_0_15_3  segment_prefix_ub_780  1
    load_0_15_3  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_711  -30
    arc_0_15_4  connected_order_arc_712  -15
    arc_0_15_4  in_degree_782  1
    arc_0_15_4  out_degree_838  1
    arc_0_15_4  original_T_including_depot_unload_855  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_711  1
    load_0_15_4  segment_load_conservation_785  -1
    load_0_15_4  segment_prefix_lb_786  1
    load_0_15_4  segment_prefix_ub_787  1
    load_0_15_4  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_713  -30
    arc_0_15_5  connected_order_arc_714  -15
    arc_0_15_5  in_degree_789  1
    arc_0_15_5  out_degree_838  1
    arc_0_15_5  original_T_including_depot_unload_855  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_713  1
    load_0_15_5  segment_load_conservation_792  -1
    load_0_15_5  segment_prefix_lb_793  1
    load_0_15_5  segment_prefix_ub_794  1
    load_0_15_5  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_715  -30
    arc_0_15_6  connected_order_arc_716  -15
    arc_0_15_6  in_degree_796  1
    arc_0_15_6  out_degree_838  1
    arc_0_15_6  original_T_including_depot_unload_855  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_715  1
    load_0_15_6  segment_load_conservation_799  -1
    load_0_15_6  segment_prefix_lb_800  1
    load_0_15_6  segment_prefix_ub_801  1
    load_0_15_6  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_717  -30
    arc_0_15_9  connected_order_arc_718  -15
    arc_0_15_9  in_degree_803  1
    arc_0_15_9  out_degree_838  1
    arc_0_15_9  original_T_including_depot_unload_855  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_717  1
    load_0_15_9  free_load_conservation_807  -1
    load_0_15_9  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_719  -30
    arc_0_15_10  connected_order_arc_720  -15
    arc_0_15_10  in_degree_809  1
    arc_0_15_10  out_degree_838  1
    arc_0_15_10  original_T_including_depot_unload_855  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_719  1
    load_0_15_10  free_load_conservation_813  -1
    load_0_15_10  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_721  -30
    arc_0_15_11  connected_order_arc_722  -15
    arc_0_15_11  in_degree_815  1
    arc_0_15_11  out_degree_838  1
    arc_0_15_11  original_T_including_depot_unload_855  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_721  1
    load_0_15_11  free_load_conservation_819  -1
    load_0_15_11  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_723  -30
    arc_0_15_12  connected_order_arc_724  -15
    arc_0_15_12  in_degree_821  1
    arc_0_15_12  out_degree_838  1
    arc_0_15_12  original_T_including_depot_unload_855  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_723  1
    load_0_15_12  free_load_conservation_825  -1
    load_0_15_12  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_725  -30
    arc_0_15_13  connected_order_arc_726  -15
    arc_0_15_13  in_degree_827  1
    arc_0_15_13  out_degree_838  1
    arc_0_15_13  original_T_including_depot_unload_855  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_725  1
    load_0_15_13  free_load_conservation_831  -1
    load_0_15_13  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_727  -30
    arc_0_15_14  connected_order_arc_728  -15
    arc_0_15_14  in_degree_833  1
    arc_0_15_14  out_degree_838  1
    arc_0_15_14  original_T_including_depot_unload_855  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_727  1
    load_0_15_14  free_load_conservation_837  -1
    load_0_15_14  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_729  -30
    arc_0_15_16  connected_order_arc_730  -15
    arc_0_15_16  out_degree_838  1
    arc_0_15_16  in_degree_845  1
    arc_0_15_16  original_T_including_depot_unload_855  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_729  1
    load_0_15_16  free_load_conservation_843  1
    load_0_15_16  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_731  -30
    arc_0_16_0  depot_return_or_bypass_759  1
    arc_0_16_0  out_degree_844  1
    arc_0_16_0  original_T_including_depot_unload_855  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_731  1
    load_0_16_0  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_732  -30
    arc_0_16_1  connected_order_arc_733  -15
    arc_0_16_1  in_degree_761  1
    arc_0_16_1  out_degree_844  1
    arc_0_16_1  original_T_including_depot_unload_855  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_732  1
    load_0_16_1  segment_load_conservation_764  -1
    load_0_16_1  segment_prefix_lb_765  1
    load_0_16_1  segment_prefix_ub_766  1
    load_0_16_1  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_734  -30
    arc_0_16_2  connected_order_arc_735  -15
    arc_0_16_2  in_degree_768  1
    arc_0_16_2  out_degree_844  1
    arc_0_16_2  original_T_including_depot_unload_855  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_734  1
    load_0_16_2  segment_load_conservation_771  -1
    load_0_16_2  segment_prefix_lb_772  1
    load_0_16_2  segment_prefix_ub_773  1
    load_0_16_2  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_736  -30
    arc_0_16_3  connected_order_arc_737  -15
    arc_0_16_3  in_degree_775  1
    arc_0_16_3  out_degree_844  1
    arc_0_16_3  original_T_including_depot_unload_855  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_736  1
    load_0_16_3  segment_load_conservation_778  -1
    load_0_16_3  segment_prefix_lb_779  1
    load_0_16_3  segment_prefix_ub_780  1
    load_0_16_3  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_738  -30
    arc_0_16_4  connected_order_arc_739  -15
    arc_0_16_4  in_degree_782  1
    arc_0_16_4  out_degree_844  1
    arc_0_16_4  original_T_including_depot_unload_855  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_738  1
    load_0_16_4  segment_load_conservation_785  -1
    load_0_16_4  segment_prefix_lb_786  1
    load_0_16_4  segment_prefix_ub_787  1
    load_0_16_4  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_740  -30
    arc_0_16_5  connected_order_arc_741  -15
    arc_0_16_5  in_degree_789  1
    arc_0_16_5  out_degree_844  1
    arc_0_16_5  original_T_including_depot_unload_855  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_740  1
    load_0_16_5  segment_load_conservation_792  -1
    load_0_16_5  segment_prefix_lb_793  1
    load_0_16_5  segment_prefix_ub_794  1
    load_0_16_5  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_742  -30
    arc_0_16_6  connected_order_arc_743  -15
    arc_0_16_6  in_degree_796  1
    arc_0_16_6  out_degree_844  1
    arc_0_16_6  original_T_including_depot_unload_855  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_742  1
    load_0_16_6  segment_load_conservation_799  -1
    load_0_16_6  segment_prefix_lb_800  1
    load_0_16_6  segment_prefix_ub_801  1
    load_0_16_6  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_9  arc_capacity_744  -30
    arc_0_16_9  connected_order_arc_745  -15
    arc_0_16_9  in_degree_803  1
    arc_0_16_9  out_degree_844  1
    arc_0_16_9  original_T_including_depot_unload_855  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_9  arc_capacity_744  1
    load_0_16_9  free_load_conservation_807  -1
    load_0_16_9  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_10  arc_capacity_746  -30
    arc_0_16_10  connected_order_arc_747  -15
    arc_0_16_10  in_degree_809  1
    arc_0_16_10  out_degree_844  1
    arc_0_16_10  original_T_including_depot_unload_855  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_10  arc_capacity_746  1
    load_0_16_10  free_load_conservation_813  -1
    load_0_16_10  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_748  -30
    arc_0_16_11  connected_order_arc_749  -15
    arc_0_16_11  in_degree_815  1
    arc_0_16_11  out_degree_844  1
    arc_0_16_11  original_T_including_depot_unload_855  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_748  1
    load_0_16_11  free_load_conservation_819  -1
    load_0_16_11  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_750  -30
    arc_0_16_12  connected_order_arc_751  -15
    arc_0_16_12  in_degree_821  1
    arc_0_16_12  out_degree_844  1
    arc_0_16_12  original_T_including_depot_unload_855  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_750  1
    load_0_16_12  free_load_conservation_825  -1
    load_0_16_12  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_752  -30
    arc_0_16_13  connected_order_arc_753  -15
    arc_0_16_13  in_degree_827  1
    arc_0_16_13  out_degree_844  1
    arc_0_16_13  original_T_including_depot_unload_855  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_752  1
    load_0_16_13  free_load_conservation_831  -1
    load_0_16_13  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_754  -30
    arc_0_16_14  connected_order_arc_755  -15
    arc_0_16_14  in_degree_833  1
    arc_0_16_14  out_degree_844  1
    arc_0_16_14  original_T_including_depot_unload_855  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_754  1
    load_0_16_14  free_load_conservation_837  -1
    load_0_16_14  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_756  -30
    arc_0_16_15  connected_order_arc_757  -15
    arc_0_16_15  in_degree_839  1
    arc_0_16_15  out_degree_844  1
    arc_0_16_15  original_T_including_depot_unload_855  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_756  1
    load_0_16_15  free_load_conservation_843  -1
    load_0_16_15  free_load_conservation_849  1
    visit_1_7  out_degree_1059  -1
    visit_1_7  in_degree_1060  -1
    visit_1_7  order_active_lb_1061  -1
    visit_1_7  order_active_ub_1062  -10
    order_1_7  connected_order_arc_869  -1
    order_1_7  connected_order_arc_871  -1
    order_1_7  connected_order_arc_873  -1
    order_1_7  connected_order_arc_875  -1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_879  -1
    order_1_7  connected_order_arc_881  -1
    order_1_7  connected_order_arc_883  -1
    order_1_7  connected_order_arc_885  -1
    order_1_7  connected_order_arc_888  1
    order_1_7  connected_order_arc_907  1
    order_1_7  connected_order_arc_926  1
    order_1_7  connected_order_arc_945  1
    order_1_7  connected_order_arc_964  1
    order_1_7  connected_order_arc_983  1
    order_1_7  connected_order_arc_1002  1
    order_1_7  connected_order_arc_1021  1
    order_1_7  connected_order_arc_1040  1
    order_1_7  order_active_lb_1061  1
    order_1_7  order_active_ub_1062  1
    order_1_7  fixed_segment_relative_order_1121  -1
    visit_1_8  out_degree_1066  -1
    visit_1_8  in_degree_1067  -1
    visit_1_8  order_active_lb_1068  -1
    visit_1_8  order_active_ub_1069  -10
    order_1_8  connected_order_arc_869  1
    order_1_8  connected_order_arc_888  -1
    order_1_8  connected_order_arc_890  -1
    order_1_8  connected_order_arc_892  -1
    order_1_8  connected_order_arc_894  -1
    order_1_8  connected_order_arc_896  -1
    order_1_8  connected_order_arc_898  -1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_904  -1
    order_1_8  connected_order_arc_909  1
    order_1_8  connected_order_arc_928  1
    order_1_8  connected_order_arc_947  1
    order_1_8  connected_order_arc_966  1
    order_1_8  connected_order_arc_985  1
    order_1_8  connected_order_arc_1004  1
    order_1_8  connected_order_arc_1023  1
    order_1_8  connected_order_arc_1042  1
    order_1_8  order_active_lb_1068  1
    order_1_8  order_active_ub_1069  1
    order_1_8  fixed_segment_relative_order_1121  1
    visit_1_9  out_degree_1073  -1
    visit_1_9  in_degree_1074  -1
    visit_1_9  order_active_lb_1075  -1
    visit_1_9  order_active_ub_1076  -10
    visit_1_9  service_visit_def_1077  -1
    order_1_9  connected_order_arc_871  1
    order_1_9  connected_order_arc_890  1
    order_1_9  connected_order_arc_907  -1
    order_1_9  connected_order_arc_909  -1
    order_1_9  connected_order_arc_911  -1
    order_1_9  connected_order_arc_913  -1
    order_1_9  connected_order_arc_915  -1
    order_1_9  connected_order_arc_917  -1
    order_1_9  connected_order_arc_919  -1
    order_1_9  connected_order_arc_921  -1
    order_1_9  connected_order_arc_923  -1
    order_1_9  connected_order_arc_930  1
    order_1_9  connected_order_arc_949  1
    order_1_9  connected_order_arc_968  1
    order_1_9  connected_order_arc_987  1
    order_1_9  connected_order_arc_1006  1
    order_1_9  connected_order_arc_1025  1
    order_1_9  connected_order_arc_1044  1
    order_1_9  order_active_lb_1075  1
    order_1_9  order_active_ub_1076  1
    visit_1_10  out_degree_1079  -1
    visit_1_10  in_degree_1080  -1
    visit_1_10  order_active_lb_1081  -1
    visit_1_10  order_active_ub_1082  -10
    visit_1_10  service_visit_def_1083  -1
    order_1_10  connected_order_arc_873  1
    order_1_10  connected_order_arc_892  1
    order_1_10  connected_order_arc_911  1
    order_1_10  connected_order_arc_926  -1
    order_1_10  connected_order_arc_928  -1
    order_1_10  connected_order_arc_930  -1
    order_1_10  connected_order_arc_932  -1
    order_1_10  connected_order_arc_934  -1
    order_1_10  connected_order_arc_936  -1
    order_1_10  connected_order_arc_938  -1
    order_1_10  connected_order_arc_940  -1
    order_1_10  connected_order_arc_942  -1
    order_1_10  connected_order_arc_951  1
    order_1_10  connected_order_arc_970  1
    order_1_10  connected_order_arc_989  1
    order_1_10  connected_order_arc_1008  1
    order_1_10  connected_order_arc_1027  1
    order_1_10  connected_order_arc_1046  1
    order_1_10  order_active_lb_1081  1
    order_1_10  order_active_ub_1082  1
    visit_1_11  out_degree_1085  -1
    visit_1_11  in_degree_1086  -1
    visit_1_11  order_active_lb_1087  -1
    visit_1_11  order_active_ub_1088  -10
    visit_1_11  service_visit_def_1089  -1
    order_1_11  connected_order_arc_875  1
    order_1_11  connected_order_arc_894  1
    order_1_11  connected_order_arc_913  1
    order_1_11  connected_order_arc_932  1
    order_1_11  connected_order_arc_945  -1
    order_1_11  connected_order_arc_947  -1
    order_1_11  connected_order_arc_949  -1
    order_1_11  connected_order_arc_951  -1
    order_1_11  connected_order_arc_953  -1
    order_1_11  connected_order_arc_955  -1
    order_1_11  connected_order_arc_957  -1
    order_1_11  connected_order_arc_959  -1
    order_1_11  connected_order_arc_961  -1
    order_1_11  connected_order_arc_972  1
    order_1_11  connected_order_arc_991  1
    order_1_11  connected_order_arc_1010  1
    order_1_11  connected_order_arc_1029  1
    order_1_11  connected_order_arc_1048  1
    order_1_11  order_active_lb_1087  1
    order_1_11  order_active_ub_1088  1
    visit_1_12  out_degree_1091  -1
    visit_1_12  in_degree_1092  -1
    visit_1_12  order_active_lb_1093  -1
    visit_1_12  order_active_ub_1094  -10
    visit_1_12  service_visit_def_1095  -1
    order_1_12  connected_order_arc_877  1
    order_1_12  connected_order_arc_896  1
    order_1_12  connected_order_arc_915  1
    order_1_12  connected_order_arc_934  1
    order_1_12  connected_order_arc_953  1
    order_1_12  connected_order_arc_964  -1
    order_1_12  connected_order_arc_966  -1
    order_1_12  connected_order_arc_968  -1
    order_1_12  connected_order_arc_970  -1
    order_1_12  connected_order_arc_972  -1
    order_1_12  connected_order_arc_974  -1
    order_1_12  connected_order_arc_976  -1
    order_1_12  connected_order_arc_978  -1
    order_1_12  connected_order_arc_980  -1
    order_1_12  connected_order_arc_993  1
    order_1_12  connected_order_arc_1012  1
    order_1_12  connected_order_arc_1031  1
    order_1_12  connected_order_arc_1050  1
    order_1_12  order_active_lb_1093  1
    order_1_12  order_active_ub_1094  1
    visit_1_13  out_degree_1097  -1
    visit_1_13  in_degree_1098  -1
    visit_1_13  order_active_lb_1099  -1
    visit_1_13  order_active_ub_1100  -10
    visit_1_13  service_visit_def_1101  -1
    order_1_13  connected_order_arc_879  1
    order_1_13  connected_order_arc_898  1
    order_1_13  connected_order_arc_917  1
    order_1_13  connected_order_arc_936  1
    order_1_13  connected_order_arc_955  1
    order_1_13  connected_order_arc_974  1
    order_1_13  connected_order_arc_983  -1
    order_1_13  connected_order_arc_985  -1
    order_1_13  connected_order_arc_987  -1
    order_1_13  connected_order_arc_989  -1
    order_1_13  connected_order_arc_991  -1
    order_1_13  connected_order_arc_993  -1
    order_1_13  connected_order_arc_995  -1
    order_1_13  connected_order_arc_997  -1
    order_1_13  connected_order_arc_999  -1
    order_1_13  connected_order_arc_1014  1
    order_1_13  connected_order_arc_1033  1
    order_1_13  connected_order_arc_1052  1
    order_1_13  order_active_lb_1099  1
    order_1_13  order_active_ub_1100  1
    visit_1_14  out_degree_1103  -1
    visit_1_14  in_degree_1104  -1
    visit_1_14  order_active_lb_1105  -1
    visit_1_14  order_active_ub_1106  -10
    visit_1_14  service_visit_def_1107  -1
    order_1_14  connected_order_arc_881  1
    order_1_14  connected_order_arc_900  1
    order_1_14  connected_order_arc_919  1
    order_1_14  connected_order_arc_938  1
    order_1_14  connected_order_arc_957  1
    order_1_14  connected_order_arc_976  1
    order_1_14  connected_order_arc_995  1
    order_1_14  connected_order_arc_1002  -1
    order_1_14  connected_order_arc_1004  -1
    order_1_14  connected_order_arc_1006  -1
    order_1_14  connected_order_arc_1008  -1
    order_1_14  connected_order_arc_1010  -1
    order_1_14  connected_order_arc_1012  -1
    order_1_14  connected_order_arc_1014  -1
    order_1_14  connected_order_arc_1016  -1
    order_1_14  connected_order_arc_1018  -1
    order_1_14  connected_order_arc_1035  1
    order_1_14  connected_order_arc_1054  1
    order_1_14  order_active_lb_1105  1
    order_1_14  order_active_ub_1106  1
    visit_1_15  out_degree_1109  -1
    visit_1_15  in_degree_1110  -1
    visit_1_15  order_active_lb_1111  -1
    visit_1_15  order_active_ub_1112  -10
    visit_1_15  service_visit_def_1113  -1
    order_1_15  connected_order_arc_883  1
    order_1_15  connected_order_arc_902  1
    order_1_15  connected_order_arc_921  1
    order_1_15  connected_order_arc_940  1
    order_1_15  connected_order_arc_959  1
    order_1_15  connected_order_arc_978  1
    order_1_15  connected_order_arc_997  1
    order_1_15  connected_order_arc_1016  1
    order_1_15  connected_order_arc_1021  -1
    order_1_15  connected_order_arc_1023  -1
    order_1_15  connected_order_arc_1025  -1
    order_1_15  connected_order_arc_1027  -1
    order_1_15  connected_order_arc_1029  -1
    order_1_15  connected_order_arc_1031  -1
    order_1_15  connected_order_arc_1033  -1
    order_1_15  connected_order_arc_1035  -1
    order_1_15  connected_order_arc_1037  -1
    order_1_15  connected_order_arc_1056  1
    order_1_15  order_active_lb_1111  1
    order_1_15  order_active_ub_1112  1
    visit_1_16  out_degree_1115  -1
    visit_1_16  in_degree_1116  -1
    visit_1_16  order_active_lb_1117  -1
    visit_1_16  order_active_ub_1118  -10
    visit_1_16  service_visit_def_1119  -1
    order_1_16  connected_order_arc_885  1
    order_1_16  connected_order_arc_904  1
    order_1_16  connected_order_arc_923  1
    order_1_16  connected_order_arc_942  1
    order_1_16  connected_order_arc_961  1
    order_1_16  connected_order_arc_980  1
    order_1_16  connected_order_arc_999  1
    order_1_16  connected_order_arc_1018  1
    order_1_16  connected_order_arc_1037  1
    order_1_16  connected_order_arc_1040  -1
    order_1_16  connected_order_arc_1042  -1
    order_1_16  connected_order_arc_1044  -1
    order_1_16  connected_order_arc_1046  -1
    order_1_16  connected_order_arc_1048  -1
    order_1_16  connected_order_arc_1050  -1
    order_1_16  connected_order_arc_1052  -1
    order_1_16  connected_order_arc_1054  -1
    order_1_16  connected_order_arc_1056  -1
    order_1_16  order_active_lb_1117  1
    order_1_16  order_active_ub_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_856  -30
    arc_1_0_0  depot_departure_or_bypass_1057  1
    arc_1_0_0  depot_return_or_bypass_1058  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_857  -30
    arc_1_0_7  depot_departure_or_bypass_1057  1
    arc_1_0_7  in_degree_1060  1
    arc_1_0_7  original_T_including_depot_unload_1122  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_857  1
    load_1_0_7  segment_load_conservation_1063  -1
    load_1_0_7  segment_prefix_lb_1064  1
    load_1_0_7  segment_prefix_ub_1065  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_858  -30
    arc_1_0_8  depot_departure_or_bypass_1057  1
    arc_1_0_8  in_degree_1067  1
    arc_1_0_8  original_T_including_depot_unload_1122  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_858  1
    load_1_0_8  segment_load_conservation_1070  -1
    load_1_0_8  segment_prefix_lb_1071  1
    load_1_0_8  segment_prefix_ub_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_859  -30
    arc_1_0_9  depot_departure_or_bypass_1057  1
    arc_1_0_9  in_degree_1074  1
    arc_1_0_9  original_T_including_depot_unload_1122  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_859  1
    load_1_0_9  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_860  -30
    arc_1_0_10  depot_departure_or_bypass_1057  1
    arc_1_0_10  in_degree_1080  1
    arc_1_0_10  original_T_including_depot_unload_1122  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_860  1
    load_1_0_10  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_861  -30
    arc_1_0_11  depot_departure_or_bypass_1057  1
    arc_1_0_11  in_degree_1086  1
    arc_1_0_11  original_T_including_depot_unload_1122  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_861  1
    load_1_0_11  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_862  -30
    arc_1_0_12  depot_departure_or_bypass_1057  1
    arc_1_0_12  in_degree_1092  1
    arc_1_0_12  original_T_including_depot_unload_1122  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_862  1
    load_1_0_12  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_863  -30
    arc_1_0_13  depot_departure_or_bypass_1057  1
    arc_1_0_13  in_degree_1098  1
    arc_1_0_13  original_T_including_depot_unload_1122  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_863  1
    load_1_0_13  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_864  -30
    arc_1_0_14  depot_departure_or_bypass_1057  1
    arc_1_0_14  in_degree_1104  1
    arc_1_0_14  original_T_including_depot_unload_1122  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_864  1
    load_1_0_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_865  -30
    arc_1_0_15  depot_departure_or_bypass_1057  1
    arc_1_0_15  in_degree_1110  1
    arc_1_0_15  original_T_including_depot_unload_1122  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_865  1
    load_1_0_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_866  -30
    arc_1_0_16  depot_departure_or_bypass_1057  1
    arc_1_0_16  in_degree_1116  1
    arc_1_0_16  original_T_including_depot_unload_1122  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_866  1
    load_1_0_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_867  -30
    arc_1_7_0  depot_return_or_bypass_1058  1
    arc_1_7_0  out_degree_1059  1
    arc_1_7_0  original_T_including_depot_unload_1122  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_867  1
    load_1_7_0  segment_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_868  -30
    arc_1_7_8  connected_order_arc_869  -11
    arc_1_7_8  out_degree_1059  1
    arc_1_7_8  in_degree_1067  1
    arc_1_7_8  original_T_including_depot_unload_1122  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_868  1
    load_1_7_8  segment_load_conservation_1063  1
    load_1_7_8  segment_load_conservation_1070  -1
    load_1_7_8  segment_prefix_lb_1071  1
    load_1_7_8  segment_prefix_ub_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_870  -30
    arc_1_7_9  connected_order_arc_871  -11
    arc_1_7_9  out_degree_1059  1
    arc_1_7_9  in_degree_1074  1
    arc_1_7_9  original_T_including_depot_unload_1122  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_870  1
    load_1_7_9  segment_load_conservation_1063  1
    load_1_7_9  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_872  -30
    arc_1_7_10  connected_order_arc_873  -11
    arc_1_7_10  out_degree_1059  1
    arc_1_7_10  in_degree_1080  1
    arc_1_7_10  original_T_including_depot_unload_1122  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_872  1
    load_1_7_10  segment_load_conservation_1063  1
    load_1_7_10  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_874  -30
    arc_1_7_11  connected_order_arc_875  -11
    arc_1_7_11  out_degree_1059  1
    arc_1_7_11  in_degree_1086  1
    arc_1_7_11  original_T_including_depot_unload_1122  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_874  1
    load_1_7_11  segment_load_conservation_1063  1
    load_1_7_11  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_876  -30
    arc_1_7_12  connected_order_arc_877  -11
    arc_1_7_12  out_degree_1059  1
    arc_1_7_12  in_degree_1092  1
    arc_1_7_12  original_T_including_depot_unload_1122  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_876  1
    load_1_7_12  segment_load_conservation_1063  1
    load_1_7_12  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_878  -30
    arc_1_7_13  connected_order_arc_879  -11
    arc_1_7_13  out_degree_1059  1
    arc_1_7_13  in_degree_1098  1
    arc_1_7_13  original_T_including_depot_unload_1122  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_878  1
    load_1_7_13  segment_load_conservation_1063  1
    load_1_7_13  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_880  -30
    arc_1_7_14  connected_order_arc_881  -11
    arc_1_7_14  out_degree_1059  1
    arc_1_7_14  in_degree_1104  1
    arc_1_7_14  original_T_including_depot_unload_1122  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_880  1
    load_1_7_14  segment_load_conservation_1063  1
    load_1_7_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_882  -30
    arc_1_7_15  connected_order_arc_883  -11
    arc_1_7_15  out_degree_1059  1
    arc_1_7_15  in_degree_1110  1
    arc_1_7_15  original_T_including_depot_unload_1122  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_882  1
    load_1_7_15  segment_load_conservation_1063  1
    load_1_7_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_884  -30
    arc_1_7_16  connected_order_arc_885  -11
    arc_1_7_16  out_degree_1059  1
    arc_1_7_16  in_degree_1116  1
    arc_1_7_16  original_T_including_depot_unload_1122  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_884  1
    load_1_7_16  segment_load_conservation_1063  1
    load_1_7_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_886  -30
    arc_1_8_0  depot_return_or_bypass_1058  1
    arc_1_8_0  out_degree_1066  1
    arc_1_8_0  original_T_including_depot_unload_1122  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_886  1
    load_1_8_0  segment_load_conservation_1070  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_887  -30
    arc_1_8_7  connected_order_arc_888  -11
    arc_1_8_7  in_degree_1060  1
    arc_1_8_7  out_degree_1066  1
    arc_1_8_7  original_T_including_depot_unload_1122  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_887  1
    load_1_8_7  segment_load_conservation_1063  -1
    load_1_8_7  segment_prefix_lb_1064  1
    load_1_8_7  segment_prefix_ub_1065  1
    load_1_8_7  segment_load_conservation_1070  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_889  -30
    arc_1_8_9  connected_order_arc_890  -11
    arc_1_8_9  out_degree_1066  1
    arc_1_8_9  in_degree_1074  1
    arc_1_8_9  original_T_including_depot_unload_1122  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_889  1
    load_1_8_9  segment_load_conservation_1070  1
    load_1_8_9  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_891  -30
    arc_1_8_10  connected_order_arc_892  -11
    arc_1_8_10  out_degree_1066  1
    arc_1_8_10  in_degree_1080  1
    arc_1_8_10  original_T_including_depot_unload_1122  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_891  1
    load_1_8_10  segment_load_conservation_1070  1
    load_1_8_10  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_893  -30
    arc_1_8_11  connected_order_arc_894  -11
    arc_1_8_11  out_degree_1066  1
    arc_1_8_11  in_degree_1086  1
    arc_1_8_11  original_T_including_depot_unload_1122  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_893  1
    load_1_8_11  segment_load_conservation_1070  1
    load_1_8_11  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_895  -30
    arc_1_8_12  connected_order_arc_896  -11
    arc_1_8_12  out_degree_1066  1
    arc_1_8_12  in_degree_1092  1
    arc_1_8_12  original_T_including_depot_unload_1122  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_895  1
    load_1_8_12  segment_load_conservation_1070  1
    load_1_8_12  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_897  -30
    arc_1_8_13  connected_order_arc_898  -11
    arc_1_8_13  out_degree_1066  1
    arc_1_8_13  in_degree_1098  1
    arc_1_8_13  original_T_including_depot_unload_1122  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_897  1
    load_1_8_13  segment_load_conservation_1070  1
    load_1_8_13  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_899  -30
    arc_1_8_14  connected_order_arc_900  -11
    arc_1_8_14  out_degree_1066  1
    arc_1_8_14  in_degree_1104  1
    arc_1_8_14  original_T_including_depot_unload_1122  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_899  1
    load_1_8_14  segment_load_conservation_1070  1
    load_1_8_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_901  -30
    arc_1_8_15  connected_order_arc_902  -11
    arc_1_8_15  out_degree_1066  1
    arc_1_8_15  in_degree_1110  1
    arc_1_8_15  original_T_including_depot_unload_1122  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_901  1
    load_1_8_15  segment_load_conservation_1070  1
    load_1_8_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_903  -30
    arc_1_8_16  connected_order_arc_904  -11
    arc_1_8_16  out_degree_1066  1
    arc_1_8_16  in_degree_1116  1
    arc_1_8_16  original_T_including_depot_unload_1122  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_903  1
    load_1_8_16  segment_load_conservation_1070  1
    load_1_8_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_905  -30
    arc_1_9_0  depot_return_or_bypass_1058  1
    arc_1_9_0  out_degree_1073  1
    arc_1_9_0  original_T_including_depot_unload_1122  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_905  1
    load_1_9_0  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_906  -30
    arc_1_9_7  connected_order_arc_907  -11
    arc_1_9_7  in_degree_1060  1
    arc_1_9_7  out_degree_1073  1
    arc_1_9_7  original_T_including_depot_unload_1122  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_906  1
    load_1_9_7  segment_load_conservation_1063  -1
    load_1_9_7  segment_prefix_lb_1064  1
    load_1_9_7  segment_prefix_ub_1065  1
    load_1_9_7  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_908  -30
    arc_1_9_8  connected_order_arc_909  -11
    arc_1_9_8  in_degree_1067  1
    arc_1_9_8  out_degree_1073  1
    arc_1_9_8  original_T_including_depot_unload_1122  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_908  1
    load_1_9_8  segment_load_conservation_1070  -1
    load_1_9_8  segment_prefix_lb_1071  1
    load_1_9_8  segment_prefix_ub_1072  1
    load_1_9_8  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_910  -30
    arc_1_9_10  connected_order_arc_911  -11
    arc_1_9_10  out_degree_1073  1
    arc_1_9_10  in_degree_1080  1
    arc_1_9_10  original_T_including_depot_unload_1122  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_910  1
    load_1_9_10  free_load_conservation_1078  1
    load_1_9_10  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_912  -30
    arc_1_9_11  connected_order_arc_913  -11
    arc_1_9_11  out_degree_1073  1
    arc_1_9_11  in_degree_1086  1
    arc_1_9_11  original_T_including_depot_unload_1122  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_912  1
    load_1_9_11  free_load_conservation_1078  1
    load_1_9_11  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_914  -30
    arc_1_9_12  connected_order_arc_915  -11
    arc_1_9_12  out_degree_1073  1
    arc_1_9_12  in_degree_1092  1
    arc_1_9_12  original_T_including_depot_unload_1122  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_914  1
    load_1_9_12  free_load_conservation_1078  1
    load_1_9_12  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_916  -30
    arc_1_9_13  connected_order_arc_917  -11
    arc_1_9_13  out_degree_1073  1
    arc_1_9_13  in_degree_1098  1
    arc_1_9_13  original_T_including_depot_unload_1122  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_916  1
    load_1_9_13  free_load_conservation_1078  1
    load_1_9_13  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_918  -30
    arc_1_9_14  connected_order_arc_919  -11
    arc_1_9_14  out_degree_1073  1
    arc_1_9_14  in_degree_1104  1
    arc_1_9_14  original_T_including_depot_unload_1122  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_918  1
    load_1_9_14  free_load_conservation_1078  1
    load_1_9_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_920  -30
    arc_1_9_15  connected_order_arc_921  -11
    arc_1_9_15  out_degree_1073  1
    arc_1_9_15  in_degree_1110  1
    arc_1_9_15  original_T_including_depot_unload_1122  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_920  1
    load_1_9_15  free_load_conservation_1078  1
    load_1_9_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_922  -30
    arc_1_9_16  connected_order_arc_923  -11
    arc_1_9_16  out_degree_1073  1
    arc_1_9_16  in_degree_1116  1
    arc_1_9_16  original_T_including_depot_unload_1122  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_922  1
    load_1_9_16  free_load_conservation_1078  1
    load_1_9_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_924  -30
    arc_1_10_0  depot_return_or_bypass_1058  1
    arc_1_10_0  out_degree_1079  1
    arc_1_10_0  original_T_including_depot_unload_1122  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_924  1
    load_1_10_0  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_925  -30
    arc_1_10_7  connected_order_arc_926  -11
    arc_1_10_7  in_degree_1060  1
    arc_1_10_7  out_degree_1079  1
    arc_1_10_7  original_T_including_depot_unload_1122  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_925  1
    load_1_10_7  segment_load_conservation_1063  -1
    load_1_10_7  segment_prefix_lb_1064  1
    load_1_10_7  segment_prefix_ub_1065  1
    load_1_10_7  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_927  -30
    arc_1_10_8  connected_order_arc_928  -11
    arc_1_10_8  in_degree_1067  1
    arc_1_10_8  out_degree_1079  1
    arc_1_10_8  original_T_including_depot_unload_1122  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_927  1
    load_1_10_8  segment_load_conservation_1070  -1
    load_1_10_8  segment_prefix_lb_1071  1
    load_1_10_8  segment_prefix_ub_1072  1
    load_1_10_8  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_929  -30
    arc_1_10_9  connected_order_arc_930  -11
    arc_1_10_9  in_degree_1074  1
    arc_1_10_9  out_degree_1079  1
    arc_1_10_9  original_T_including_depot_unload_1122  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_929  1
    load_1_10_9  free_load_conservation_1078  -1
    load_1_10_9  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_931  -30
    arc_1_10_11  connected_order_arc_932  -11
    arc_1_10_11  out_degree_1079  1
    arc_1_10_11  in_degree_1086  1
    arc_1_10_11  original_T_including_depot_unload_1122  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_931  1
    load_1_10_11  free_load_conservation_1084  1
    load_1_10_11  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_933  -30
    arc_1_10_12  connected_order_arc_934  -11
    arc_1_10_12  out_degree_1079  1
    arc_1_10_12  in_degree_1092  1
    arc_1_10_12  original_T_including_depot_unload_1122  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_933  1
    load_1_10_12  free_load_conservation_1084  1
    load_1_10_12  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_935  -30
    arc_1_10_13  connected_order_arc_936  -11
    arc_1_10_13  out_degree_1079  1
    arc_1_10_13  in_degree_1098  1
    arc_1_10_13  original_T_including_depot_unload_1122  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_935  1
    load_1_10_13  free_load_conservation_1084  1
    load_1_10_13  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_937  -30
    arc_1_10_14  connected_order_arc_938  -11
    arc_1_10_14  out_degree_1079  1
    arc_1_10_14  in_degree_1104  1
    arc_1_10_14  original_T_including_depot_unload_1122  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_937  1
    load_1_10_14  free_load_conservation_1084  1
    load_1_10_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_939  -30
    arc_1_10_15  connected_order_arc_940  -11
    arc_1_10_15  out_degree_1079  1
    arc_1_10_15  in_degree_1110  1
    arc_1_10_15  original_T_including_depot_unload_1122  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_939  1
    load_1_10_15  free_load_conservation_1084  1
    load_1_10_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_941  -30
    arc_1_10_16  connected_order_arc_942  -11
    arc_1_10_16  out_degree_1079  1
    arc_1_10_16  in_degree_1116  1
    arc_1_10_16  original_T_including_depot_unload_1122  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_941  1
    load_1_10_16  free_load_conservation_1084  1
    load_1_10_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_943  -30
    arc_1_11_0  depot_return_or_bypass_1058  1
    arc_1_11_0  out_degree_1085  1
    arc_1_11_0  original_T_including_depot_unload_1122  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_943  1
    load_1_11_0  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_944  -30
    arc_1_11_7  connected_order_arc_945  -11
    arc_1_11_7  in_degree_1060  1
    arc_1_11_7  out_degree_1085  1
    arc_1_11_7  original_T_including_depot_unload_1122  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_944  1
    load_1_11_7  segment_load_conservation_1063  -1
    load_1_11_7  segment_prefix_lb_1064  1
    load_1_11_7  segment_prefix_ub_1065  1
    load_1_11_7  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_946  -30
    arc_1_11_8  connected_order_arc_947  -11
    arc_1_11_8  in_degree_1067  1
    arc_1_11_8  out_degree_1085  1
    arc_1_11_8  original_T_including_depot_unload_1122  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_946  1
    load_1_11_8  segment_load_conservation_1070  -1
    load_1_11_8  segment_prefix_lb_1071  1
    load_1_11_8  segment_prefix_ub_1072  1
    load_1_11_8  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_948  -30
    arc_1_11_9  connected_order_arc_949  -11
    arc_1_11_9  in_degree_1074  1
    arc_1_11_9  out_degree_1085  1
    arc_1_11_9  original_T_including_depot_unload_1122  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_948  1
    load_1_11_9  free_load_conservation_1078  -1
    load_1_11_9  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_950  -30
    arc_1_11_10  connected_order_arc_951  -11
    arc_1_11_10  in_degree_1080  1
    arc_1_11_10  out_degree_1085  1
    arc_1_11_10  original_T_including_depot_unload_1122  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_950  1
    load_1_11_10  free_load_conservation_1084  -1
    load_1_11_10  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_952  -30
    arc_1_11_12  connected_order_arc_953  -11
    arc_1_11_12  out_degree_1085  1
    arc_1_11_12  in_degree_1092  1
    arc_1_11_12  original_T_including_depot_unload_1122  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_952  1
    load_1_11_12  free_load_conservation_1090  1
    load_1_11_12  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_954  -30
    arc_1_11_13  connected_order_arc_955  -11
    arc_1_11_13  out_degree_1085  1
    arc_1_11_13  in_degree_1098  1
    arc_1_11_13  original_T_including_depot_unload_1122  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_954  1
    load_1_11_13  free_load_conservation_1090  1
    load_1_11_13  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_956  -30
    arc_1_11_14  connected_order_arc_957  -11
    arc_1_11_14  out_degree_1085  1
    arc_1_11_14  in_degree_1104  1
    arc_1_11_14  original_T_including_depot_unload_1122  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_956  1
    load_1_11_14  free_load_conservation_1090  1
    load_1_11_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_958  -30
    arc_1_11_15  connected_order_arc_959  -11
    arc_1_11_15  out_degree_1085  1
    arc_1_11_15  in_degree_1110  1
    arc_1_11_15  original_T_including_depot_unload_1122  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_958  1
    load_1_11_15  free_load_conservation_1090  1
    load_1_11_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_960  -30
    arc_1_11_16  connected_order_arc_961  -11
    arc_1_11_16  out_degree_1085  1
    arc_1_11_16  in_degree_1116  1
    arc_1_11_16  original_T_including_depot_unload_1122  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_960  1
    load_1_11_16  free_load_conservation_1090  1
    load_1_11_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_962  -30
    arc_1_12_0  depot_return_or_bypass_1058  1
    arc_1_12_0  out_degree_1091  1
    arc_1_12_0  original_T_including_depot_unload_1122  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_962  1
    load_1_12_0  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_963  -30
    arc_1_12_7  connected_order_arc_964  -11
    arc_1_12_7  in_degree_1060  1
    arc_1_12_7  out_degree_1091  1
    arc_1_12_7  original_T_including_depot_unload_1122  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_963  1
    load_1_12_7  segment_load_conservation_1063  -1
    load_1_12_7  segment_prefix_lb_1064  1
    load_1_12_7  segment_prefix_ub_1065  1
    load_1_12_7  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_965  -30
    arc_1_12_8  connected_order_arc_966  -11
    arc_1_12_8  in_degree_1067  1
    arc_1_12_8  out_degree_1091  1
    arc_1_12_8  original_T_including_depot_unload_1122  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_965  1
    load_1_12_8  segment_load_conservation_1070  -1
    load_1_12_8  segment_prefix_lb_1071  1
    load_1_12_8  segment_prefix_ub_1072  1
    load_1_12_8  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_967  -30
    arc_1_12_9  connected_order_arc_968  -11
    arc_1_12_9  in_degree_1074  1
    arc_1_12_9  out_degree_1091  1
    arc_1_12_9  original_T_including_depot_unload_1122  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_967  1
    load_1_12_9  free_load_conservation_1078  -1
    load_1_12_9  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_969  -30
    arc_1_12_10  connected_order_arc_970  -11
    arc_1_12_10  in_degree_1080  1
    arc_1_12_10  out_degree_1091  1
    arc_1_12_10  original_T_including_depot_unload_1122  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_969  1
    load_1_12_10  free_load_conservation_1084  -1
    load_1_12_10  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_971  -30
    arc_1_12_11  connected_order_arc_972  -11
    arc_1_12_11  in_degree_1086  1
    arc_1_12_11  out_degree_1091  1
    arc_1_12_11  original_T_including_depot_unload_1122  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_971  1
    load_1_12_11  free_load_conservation_1090  -1
    load_1_12_11  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_973  -30
    arc_1_12_13  connected_order_arc_974  -11
    arc_1_12_13  out_degree_1091  1
    arc_1_12_13  in_degree_1098  1
    arc_1_12_13  original_T_including_depot_unload_1122  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_973  1
    load_1_12_13  free_load_conservation_1096  1
    load_1_12_13  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_975  -30
    arc_1_12_14  connected_order_arc_976  -11
    arc_1_12_14  out_degree_1091  1
    arc_1_12_14  in_degree_1104  1
    arc_1_12_14  original_T_including_depot_unload_1122  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_975  1
    load_1_12_14  free_load_conservation_1096  1
    load_1_12_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_977  -30
    arc_1_12_15  connected_order_arc_978  -11
    arc_1_12_15  out_degree_1091  1
    arc_1_12_15  in_degree_1110  1
    arc_1_12_15  original_T_including_depot_unload_1122  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_977  1
    load_1_12_15  free_load_conservation_1096  1
    load_1_12_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_979  -30
    arc_1_12_16  connected_order_arc_980  -11
    arc_1_12_16  out_degree_1091  1
    arc_1_12_16  in_degree_1116  1
    arc_1_12_16  original_T_including_depot_unload_1122  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_979  1
    load_1_12_16  free_load_conservation_1096  1
    load_1_12_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_981  -30
    arc_1_13_0  depot_return_or_bypass_1058  1
    arc_1_13_0  out_degree_1097  1
    arc_1_13_0  original_T_including_depot_unload_1122  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_981  1
    load_1_13_0  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_982  -30
    arc_1_13_7  connected_order_arc_983  -11
    arc_1_13_7  in_degree_1060  1
    arc_1_13_7  out_degree_1097  1
    arc_1_13_7  original_T_including_depot_unload_1122  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_982  1
    load_1_13_7  segment_load_conservation_1063  -1
    load_1_13_7  segment_prefix_lb_1064  1
    load_1_13_7  segment_prefix_ub_1065  1
    load_1_13_7  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_984  -30
    arc_1_13_8  connected_order_arc_985  -11
    arc_1_13_8  in_degree_1067  1
    arc_1_13_8  out_degree_1097  1
    arc_1_13_8  original_T_including_depot_unload_1122  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_984  1
    load_1_13_8  segment_load_conservation_1070  -1
    load_1_13_8  segment_prefix_lb_1071  1
    load_1_13_8  segment_prefix_ub_1072  1
    load_1_13_8  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_986  -30
    arc_1_13_9  connected_order_arc_987  -11
    arc_1_13_9  in_degree_1074  1
    arc_1_13_9  out_degree_1097  1
    arc_1_13_9  original_T_including_depot_unload_1122  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_986  1
    load_1_13_9  free_load_conservation_1078  -1
    load_1_13_9  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_988  -30
    arc_1_13_10  connected_order_arc_989  -11
    arc_1_13_10  in_degree_1080  1
    arc_1_13_10  out_degree_1097  1
    arc_1_13_10  original_T_including_depot_unload_1122  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_988  1
    load_1_13_10  free_load_conservation_1084  -1
    load_1_13_10  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_990  -30
    arc_1_13_11  connected_order_arc_991  -11
    arc_1_13_11  in_degree_1086  1
    arc_1_13_11  out_degree_1097  1
    arc_1_13_11  original_T_including_depot_unload_1122  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_990  1
    load_1_13_11  free_load_conservation_1090  -1
    load_1_13_11  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_992  -30
    arc_1_13_12  connected_order_arc_993  -11
    arc_1_13_12  in_degree_1092  1
    arc_1_13_12  out_degree_1097  1
    arc_1_13_12  original_T_including_depot_unload_1122  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_992  1
    load_1_13_12  free_load_conservation_1096  -1
    load_1_13_12  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_994  -30
    arc_1_13_14  connected_order_arc_995  -11
    arc_1_13_14  out_degree_1097  1
    arc_1_13_14  in_degree_1104  1
    arc_1_13_14  original_T_including_depot_unload_1122  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_994  1
    load_1_13_14  free_load_conservation_1102  1
    load_1_13_14  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_996  -30
    arc_1_13_15  connected_order_arc_997  -11
    arc_1_13_15  out_degree_1097  1
    arc_1_13_15  in_degree_1110  1
    arc_1_13_15  original_T_including_depot_unload_1122  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_996  1
    load_1_13_15  free_load_conservation_1102  1
    load_1_13_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_998  -30
    arc_1_13_16  connected_order_arc_999  -11
    arc_1_13_16  out_degree_1097  1
    arc_1_13_16  in_degree_1116  1
    arc_1_13_16  original_T_including_depot_unload_1122  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_998  1
    load_1_13_16  free_load_conservation_1102  1
    load_1_13_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1000  -30
    arc_1_14_0  depot_return_or_bypass_1058  1
    arc_1_14_0  out_degree_1103  1
    arc_1_14_0  original_T_including_depot_unload_1122  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1000  1
    load_1_14_0  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1001  -30
    arc_1_14_7  connected_order_arc_1002  -11
    arc_1_14_7  in_degree_1060  1
    arc_1_14_7  out_degree_1103  1
    arc_1_14_7  original_T_including_depot_unload_1122  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1001  1
    load_1_14_7  segment_load_conservation_1063  -1
    load_1_14_7  segment_prefix_lb_1064  1
    load_1_14_7  segment_prefix_ub_1065  1
    load_1_14_7  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1003  -30
    arc_1_14_8  connected_order_arc_1004  -11
    arc_1_14_8  in_degree_1067  1
    arc_1_14_8  out_degree_1103  1
    arc_1_14_8  original_T_including_depot_unload_1122  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1003  1
    load_1_14_8  segment_load_conservation_1070  -1
    load_1_14_8  segment_prefix_lb_1071  1
    load_1_14_8  segment_prefix_ub_1072  1
    load_1_14_8  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1005  -30
    arc_1_14_9  connected_order_arc_1006  -11
    arc_1_14_9  in_degree_1074  1
    arc_1_14_9  out_degree_1103  1
    arc_1_14_9  original_T_including_depot_unload_1122  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1005  1
    load_1_14_9  free_load_conservation_1078  -1
    load_1_14_9  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1007  -30
    arc_1_14_10  connected_order_arc_1008  -11
    arc_1_14_10  in_degree_1080  1
    arc_1_14_10  out_degree_1103  1
    arc_1_14_10  original_T_including_depot_unload_1122  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1007  1
    load_1_14_10  free_load_conservation_1084  -1
    load_1_14_10  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1009  -30
    arc_1_14_11  connected_order_arc_1010  -11
    arc_1_14_11  in_degree_1086  1
    arc_1_14_11  out_degree_1103  1
    arc_1_14_11  original_T_including_depot_unload_1122  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1009  1
    load_1_14_11  free_load_conservation_1090  -1
    load_1_14_11  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1011  -30
    arc_1_14_12  connected_order_arc_1012  -11
    arc_1_14_12  in_degree_1092  1
    arc_1_14_12  out_degree_1103  1
    arc_1_14_12  original_T_including_depot_unload_1122  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1011  1
    load_1_14_12  free_load_conservation_1096  -1
    load_1_14_12  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1013  -30
    arc_1_14_13  connected_order_arc_1014  -11
    arc_1_14_13  in_degree_1098  1
    arc_1_14_13  out_degree_1103  1
    arc_1_14_13  original_T_including_depot_unload_1122  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1013  1
    load_1_14_13  free_load_conservation_1102  -1
    load_1_14_13  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1015  -30
    arc_1_14_15  connected_order_arc_1016  -11
    arc_1_14_15  out_degree_1103  1
    arc_1_14_15  in_degree_1110  1
    arc_1_14_15  original_T_including_depot_unload_1122  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1015  1
    load_1_14_15  free_load_conservation_1108  1
    load_1_14_15  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1017  -30
    arc_1_14_16  connected_order_arc_1018  -11
    arc_1_14_16  out_degree_1103  1
    arc_1_14_16  in_degree_1116  1
    arc_1_14_16  original_T_including_depot_unload_1122  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1017  1
    load_1_14_16  free_load_conservation_1108  1
    load_1_14_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1019  -30
    arc_1_15_0  depot_return_or_bypass_1058  1
    arc_1_15_0  out_degree_1109  1
    arc_1_15_0  original_T_including_depot_unload_1122  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1019  1
    load_1_15_0  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1020  -30
    arc_1_15_7  connected_order_arc_1021  -11
    arc_1_15_7  in_degree_1060  1
    arc_1_15_7  out_degree_1109  1
    arc_1_15_7  original_T_including_depot_unload_1122  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1020  1
    load_1_15_7  segment_load_conservation_1063  -1
    load_1_15_7  segment_prefix_lb_1064  1
    load_1_15_7  segment_prefix_ub_1065  1
    load_1_15_7  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1022  -30
    arc_1_15_8  connected_order_arc_1023  -11
    arc_1_15_8  in_degree_1067  1
    arc_1_15_8  out_degree_1109  1
    arc_1_15_8  original_T_including_depot_unload_1122  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1022  1
    load_1_15_8  segment_load_conservation_1070  -1
    load_1_15_8  segment_prefix_lb_1071  1
    load_1_15_8  segment_prefix_ub_1072  1
    load_1_15_8  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1024  -30
    arc_1_15_9  connected_order_arc_1025  -11
    arc_1_15_9  in_degree_1074  1
    arc_1_15_9  out_degree_1109  1
    arc_1_15_9  original_T_including_depot_unload_1122  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1024  1
    load_1_15_9  free_load_conservation_1078  -1
    load_1_15_9  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1026  -30
    arc_1_15_10  connected_order_arc_1027  -11
    arc_1_15_10  in_degree_1080  1
    arc_1_15_10  out_degree_1109  1
    arc_1_15_10  original_T_including_depot_unload_1122  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1026  1
    load_1_15_10  free_load_conservation_1084  -1
    load_1_15_10  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1028  -30
    arc_1_15_11  connected_order_arc_1029  -11
    arc_1_15_11  in_degree_1086  1
    arc_1_15_11  out_degree_1109  1
    arc_1_15_11  original_T_including_depot_unload_1122  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1028  1
    load_1_15_11  free_load_conservation_1090  -1
    load_1_15_11  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1030  -30
    arc_1_15_12  connected_order_arc_1031  -11
    arc_1_15_12  in_degree_1092  1
    arc_1_15_12  out_degree_1109  1
    arc_1_15_12  original_T_including_depot_unload_1122  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1030  1
    load_1_15_12  free_load_conservation_1096  -1
    load_1_15_12  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1032  -30
    arc_1_15_13  connected_order_arc_1033  -11
    arc_1_15_13  in_degree_1098  1
    arc_1_15_13  out_degree_1109  1
    arc_1_15_13  original_T_including_depot_unload_1122  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1032  1
    load_1_15_13  free_load_conservation_1102  -1
    load_1_15_13  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1034  -30
    arc_1_15_14  connected_order_arc_1035  -11
    arc_1_15_14  in_degree_1104  1
    arc_1_15_14  out_degree_1109  1
    arc_1_15_14  original_T_including_depot_unload_1122  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1034  1
    load_1_15_14  free_load_conservation_1108  -1
    load_1_15_14  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1036  -30
    arc_1_15_16  connected_order_arc_1037  -11
    arc_1_15_16  out_degree_1109  1
    arc_1_15_16  in_degree_1116  1
    arc_1_15_16  original_T_including_depot_unload_1122  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1036  1
    load_1_15_16  free_load_conservation_1114  1
    load_1_15_16  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1038  -30
    arc_1_16_0  depot_return_or_bypass_1058  1
    arc_1_16_0  out_degree_1115  1
    arc_1_16_0  original_T_including_depot_unload_1122  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1038  1
    load_1_16_0  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1039  -30
    arc_1_16_7  connected_order_arc_1040  -11
    arc_1_16_7  in_degree_1060  1
    arc_1_16_7  out_degree_1115  1
    arc_1_16_7  original_T_including_depot_unload_1122  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1039  1
    load_1_16_7  segment_load_conservation_1063  -1
    load_1_16_7  segment_prefix_lb_1064  1
    load_1_16_7  segment_prefix_ub_1065  1
    load_1_16_7  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1041  -30
    arc_1_16_8  connected_order_arc_1042  -11
    arc_1_16_8  in_degree_1067  1
    arc_1_16_8  out_degree_1115  1
    arc_1_16_8  original_T_including_depot_unload_1122  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1041  1
    load_1_16_8  segment_load_conservation_1070  -1
    load_1_16_8  segment_prefix_lb_1071  1
    load_1_16_8  segment_prefix_ub_1072  1
    load_1_16_8  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1043  -30
    arc_1_16_9  connected_order_arc_1044  -11
    arc_1_16_9  in_degree_1074  1
    arc_1_16_9  out_degree_1115  1
    arc_1_16_9  original_T_including_depot_unload_1122  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1043  1
    load_1_16_9  free_load_conservation_1078  -1
    load_1_16_9  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1045  -30
    arc_1_16_10  connected_order_arc_1046  -11
    arc_1_16_10  in_degree_1080  1
    arc_1_16_10  out_degree_1115  1
    arc_1_16_10  original_T_including_depot_unload_1122  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1045  1
    load_1_16_10  free_load_conservation_1084  -1
    load_1_16_10  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1047  -30
    arc_1_16_11  connected_order_arc_1048  -11
    arc_1_16_11  in_degree_1086  1
    arc_1_16_11  out_degree_1115  1
    arc_1_16_11  original_T_including_depot_unload_1122  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1047  1
    load_1_16_11  free_load_conservation_1090  -1
    load_1_16_11  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1049  -30
    arc_1_16_12  connected_order_arc_1050  -11
    arc_1_16_12  in_degree_1092  1
    arc_1_16_12  out_degree_1115  1
    arc_1_16_12  original_T_including_depot_unload_1122  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1049  1
    load_1_16_12  free_load_conservation_1096  -1
    load_1_16_12  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1051  -30
    arc_1_16_13  connected_order_arc_1052  -11
    arc_1_16_13  in_degree_1098  1
    arc_1_16_13  out_degree_1115  1
    arc_1_16_13  original_T_including_depot_unload_1122  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1051  1
    load_1_16_13  free_load_conservation_1102  -1
    load_1_16_13  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1053  -30
    arc_1_16_14  connected_order_arc_1054  -11
    arc_1_16_14  in_degree_1104  1
    arc_1_16_14  out_degree_1115  1
    arc_1_16_14  original_T_including_depot_unload_1122  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1053  1
    load_1_16_14  free_load_conservation_1108  -1
    load_1_16_14  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1055  -30
    arc_1_16_15  connected_order_arc_1056  -11
    arc_1_16_15  in_degree_1110  1
    arc_1_16_15  out_degree_1115  1
    arc_1_16_15  original_T_including_depot_unload_1122  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1055  1
    load_1_16_15  free_load_conservation_1114  -1
    load_1_16_15  free_load_conservation_1120  1
RHS
    RHS1      OBJ       -3.7777779352225033e-01
    RHS1      onehot_12_32  1
    RHS1      onehot_11_67  1
    RHS1      onehot_18_102  1
    RHS1      onehot_9_109  1
    RHS1      onehot_17_146  1
    RHS1      onehot_10_153  1
    RHS1      onehot_20_188  1
    RHS1      onehot_7_213  1
    RHS1      stock_ub_217  33
    RHS1      parent_nonstrict_scope_218  0.599684495511766
    RHS1      normalization_275  1
    RHS1      connected_order_arc_382  -14
    RHS1      connected_order_arc_384  -14
    RHS1      connected_order_arc_386  -14
    RHS1      connected_order_arc_388  -14
    RHS1      connected_order_arc_390  -14
    RHS1      connected_order_arc_392  -14
    RHS1      connected_order_arc_394  -14
    RHS1      connected_order_arc_396  -14
    RHS1      connected_order_arc_398  -14
    RHS1      connected_order_arc_400  -14
    RHS1      connected_order_arc_402  -14
    RHS1      connected_order_arc_404  -14
    RHS1      connected_order_arc_406  -14
    RHS1      connected_order_arc_409  -14
    RHS1      connected_order_arc_411  -14
    RHS1      connected_order_arc_413  -14
    RHS1      connected_order_arc_415  -14
    RHS1      connected_order_arc_417  -14
    RHS1      connected_order_arc_419  -14
    RHS1      connected_order_arc_421  -14
    RHS1      connected_order_arc_423  -14
    RHS1      connected_order_arc_425  -14
    RHS1      connected_order_arc_427  -14
    RHS1      connected_order_arc_429  -14
    RHS1      connected_order_arc_431  -14
    RHS1      connected_order_arc_433  -14
    RHS1      connected_order_arc_436  -14
    RHS1      connected_order_arc_438  -14
    RHS1      connected_order_arc_440  -14
    RHS1      connected_order_arc_442  -14
    RHS1      connected_order_arc_444  -14
    RHS1      connected_order_arc_446  -14
    RHS1      connected_order_arc_448  -14
    RHS1      connected_order_arc_450  -14
    RHS1      connected_order_arc_452  -14
    RHS1      connected_order_arc_454  -14
    RHS1      connected_order_arc_456  -14
    RHS1      connected_order_arc_458  -14
    RHS1      connected_order_arc_460  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_471  -14
    RHS1      connected_order_arc_473  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_483  -14
    RHS1      connected_order_arc_485  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_498  -14
    RHS1      connected_order_arc_500  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_510  -14
    RHS1      connected_order_arc_512  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_525  -14
    RHS1      connected_order_arc_527  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_537  -14
    RHS1      connected_order_arc_539  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_552  -14
    RHS1      connected_order_arc_554  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_564  -14
    RHS1      connected_order_arc_566  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_579  -14
    RHS1      connected_order_arc_581  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_591  -14
    RHS1      connected_order_arc_593  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_606  -14
    RHS1      connected_order_arc_608  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_618  -14
    RHS1      connected_order_arc_620  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_633  -14
    RHS1      connected_order_arc_635  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_645  -14
    RHS1      connected_order_arc_647  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_660  -14
    RHS1      connected_order_arc_662  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_672  -14
    RHS1      connected_order_arc_674  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_687  -14
    RHS1      connected_order_arc_689  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_699  -14
    RHS1      connected_order_arc_701  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_714  -14
    RHS1      connected_order_arc_716  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_720  -14
    RHS1      connected_order_arc_722  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_726  -14
    RHS1      connected_order_arc_728  -14
    RHS1      connected_order_arc_730  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      connected_order_arc_741  -14
    RHS1      connected_order_arc_743  -14
    RHS1      connected_order_arc_745  -14
    RHS1      connected_order_arc_747  -14
    RHS1      connected_order_arc_749  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_753  -14
    RHS1      connected_order_arc_755  -14
    RHS1      connected_order_arc_757  -14
    RHS1      depot_departure_or_bypass_758  1
    RHS1      depot_return_or_bypass_759  1
    RHS1      segment_load_conservation_764  -1
    RHS1      segment_prefix_lb_765  1
    RHS1      segment_prefix_ub_766  30
    RHS1      segment_load_conservation_771  4
    RHS1      segment_prefix_ub_773  26
    RHS1      segment_load_conservation_778  -2
    RHS1      segment_prefix_lb_779  2
    RHS1      segment_prefix_ub_780  30
    RHS1      segment_load_conservation_785  -1
    RHS1      segment_prefix_lb_786  1
    RHS1      segment_prefix_ub_787  30
    RHS1      segment_load_conservation_792  3
    RHS1      segment_prefix_ub_794  27
    RHS1      segment_load_conservation_799  -1
    RHS1      segment_prefix_lb_800  1
    RHS1      segment_prefix_ub_801  30
    RHS1      fixed_segment_relative_order_850  1
    RHS1      fixed_segment_relative_order_851  1
    RHS1      fixed_segment_relative_order_852  1
    RHS1      fixed_segment_relative_order_853  1
    RHS1      fixed_segment_relative_order_854  1
    RHS1      original_T_including_depot_unload_855  3960
    RHS1      connected_order_arc_869  -10
    RHS1      connected_order_arc_871  -10
    RHS1      connected_order_arc_873  -10
    RHS1      connected_order_arc_875  -10
    RHS1      connected_order_arc_877  -10
    RHS1      connected_order_arc_879  -10
    RHS1      connected_order_arc_881  -10
    RHS1      connected_order_arc_883  -10
    RHS1      connected_order_arc_885  -10
    RHS1      connected_order_arc_888  -10
    RHS1      connected_order_arc_890  -10
    RHS1      connected_order_arc_892  -10
    RHS1      connected_order_arc_894  -10
    RHS1      connected_order_arc_896  -10
    RHS1      connected_order_arc_898  -10
    RHS1      connected_order_arc_900  -10
    RHS1      connected_order_arc_902  -10
    RHS1      connected_order_arc_904  -10
    RHS1      connected_order_arc_907  -10
    RHS1      connected_order_arc_909  -10
    RHS1      connected_order_arc_911  -10
    RHS1      connected_order_arc_913  -10
    RHS1      connected_order_arc_915  -10
    RHS1      connected_order_arc_917  -10
    RHS1      connected_order_arc_919  -10
    RHS1      connected_order_arc_921  -10
    RHS1      connected_order_arc_923  -10
    RHS1      connected_order_arc_926  -10
    RHS1      connected_order_arc_928  -10
    RHS1      connected_order_arc_930  -10
    RHS1      connected_order_arc_932  -10
    RHS1      connected_order_arc_934  -10
    RHS1      connected_order_arc_936  -10
    RHS1      connected_order_arc_938  -10
    RHS1      connected_order_arc_940  -10
    RHS1      connected_order_arc_942  -10
    RHS1      connected_order_arc_945  -10
    RHS1      connected_order_arc_947  -10
    RHS1      connected_order_arc_949  -10
    RHS1      connected_order_arc_951  -10
    RHS1      connected_order_arc_953  -10
    RHS1      connected_order_arc_955  -10
    RHS1      connected_order_arc_957  -10
    RHS1      connected_order_arc_959  -10
    RHS1      connected_order_arc_961  -10
    RHS1      connected_order_arc_964  -10
    RHS1      connected_order_arc_966  -10
    RHS1      connected_order_arc_968  -10
    RHS1      connected_order_arc_970  -10
    RHS1      connected_order_arc_972  -10
    RHS1      connected_order_arc_974  -10
    RHS1      connected_order_arc_976  -10
    RHS1      connected_order_arc_978  -10
    RHS1      connected_order_arc_980  -10
    RHS1      connected_order_arc_983  -10
    RHS1      connected_order_arc_985  -10
    RHS1      connected_order_arc_987  -10
    RHS1      connected_order_arc_989  -10
    RHS1      connected_order_arc_991  -10
    RHS1      connected_order_arc_993  -10
    RHS1      connected_order_arc_995  -10
    RHS1      connected_order_arc_997  -10
    RHS1      connected_order_arc_999  -10
    RHS1      connected_order_arc_1002  -10
    RHS1      connected_order_arc_1004  -10
    RHS1      connected_order_arc_1006  -10
    RHS1      connected_order_arc_1008  -10
    RHS1      connected_order_arc_1010  -10
    RHS1      connected_order_arc_1012  -10
    RHS1      connected_order_arc_1014  -10
    RHS1      connected_order_arc_1016  -10
    RHS1      connected_order_arc_1018  -10
    RHS1      connected_order_arc_1021  -10
    RHS1      connected_order_arc_1023  -10
    RHS1      connected_order_arc_1025  -10
    RHS1      connected_order_arc_1027  -10
    RHS1      connected_order_arc_1029  -10
    RHS1      connected_order_arc_1031  -10
    RHS1      connected_order_arc_1033  -10
    RHS1      connected_order_arc_1035  -10
    RHS1      connected_order_arc_1037  -10
    RHS1      connected_order_arc_1040  -10
    RHS1      connected_order_arc_1042  -10
    RHS1      connected_order_arc_1044  -10
    RHS1      connected_order_arc_1046  -10
    RHS1      connected_order_arc_1048  -10
    RHS1      connected_order_arc_1050  -10
    RHS1      connected_order_arc_1052  -10
    RHS1      connected_order_arc_1054  -10
    RHS1      connected_order_arc_1056  -10
    RHS1      depot_departure_or_bypass_1057  1
    RHS1      depot_return_or_bypass_1058  1
    RHS1      segment_load_conservation_1063  4
    RHS1      segment_prefix_ub_1065  26
    RHS1      segment_load_conservation_1070  -1
    RHS1      segment_prefix_lb_1071  1
    RHS1      segment_prefix_ub_1072  30
    RHS1      fixed_segment_relative_order_1121  1
    RHS1      original_T_including_depot_unload_1122  4320
BOUNDS
 LO BND1      t         4.4708595759735285e-02
 UP BND1      t         1.1691022964521088e-01
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_12_0  
 UP BND1      w_12_0    1.1691022964521088e-01
 BV BND1      x_12_1  
 UP BND1      w_12_1    1.1691022964521088e-01
 BV BND1      x_12_2  
 UP BND1      w_12_2    1.1691022964521088e-01
 BV BND1      x_12_3  
 UP BND1      w_12_3    1.1691022964521088e-01
 BV BND1      x_12_4  
 UP BND1      w_12_4    1.1691022964521088e-01
 BV BND1      x_12_5  
 UP BND1      w_12_5    1.1691022964521088e-01
 BV BND1      x_12_6  
 UP BND1      w_12_6    1.1691022964521088e-01
 BV BND1      x_12_7  
 UP BND1      w_12_7    1.1691022964521088e-01
 BV BND1      x_12_8  
 UP BND1      w_12_8    1.1691022964521088e-01
 BV BND1      x_12_9  
 UP BND1      w_12_9    1.1691022964521088e-01
 BV BND1      x_12_10 
 UP BND1      w_12_10   1.1691022964521088e-01
 BV BND1      x_12_11 
 UP BND1      w_12_11   1.1691022964521088e-01
 BV BND1      x_12_12 
 UP BND1      w_12_12   1.1691022964521088e-01
 BV BND1      x_12_13 
 UP BND1      w_12_13   1.1691022964521088e-01
 BV BND1      x_12_14 
 UP BND1      w_12_14   1.1691022964521088e-01
 BV BND1      x_12_15 
 UP BND1      w_12_15   1.1691022964521088e-01
 UP BND1      rho_12    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.1691022964521088e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.1691022964521088e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.1691022964521088e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.1691022964521088e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.1691022964521088e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.1691022964521088e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.1691022964521088e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.1691022964521088e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.1691022964521088e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.1691022964521088e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.1691022964521088e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.1691022964521088e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.1691022964521088e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.1691022964521088e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.1691022964521088e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.1691022964521088e-01
 UP BND1      rho_11    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.1691022964521088e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.1691022964521088e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.1691022964521088e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.1691022964521088e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.1691022964521088e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.1691022964521088e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.1691022964521088e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.1691022964521088e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.1691022964521088e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.1691022964521088e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.1691022964521088e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.1691022964521088e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.1691022964521088e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.1691022964521088e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.1691022964521088e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.1691022964521088e-01
 UP BND1      rho_18    1
 BV BND1      x_9_0   
 UP BND1      w_9_0     1.1691022964521088e-01
 BV BND1      x_9_1   
 UP BND1      w_9_1     1.1691022964521088e-01
 UP BND1      rho_9     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.1691022964521088e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.1691022964521088e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.1691022964521088e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.1691022964521088e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.1691022964521088e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.1691022964521088e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.1691022964521088e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.1691022964521088e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.1691022964521088e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.1691022964521088e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.1691022964521088e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.1691022964521088e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.1691022964521088e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.1691022964521088e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.1691022964521088e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.1691022964521088e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.1691022964521088e-01
 UP BND1      rho_17    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    1.1691022964521088e-01
 BV BND1      x_10_1  
 UP BND1      w_10_1    1.1691022964521088e-01
 UP BND1      rho_10    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.1691022964521088e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.1691022964521088e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.1691022964521088e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.1691022964521088e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.1691022964521088e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.1691022964521088e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.1691022964521088e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.1691022964521088e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.1691022964521088e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.1691022964521088e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.1691022964521088e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.1691022964521088e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.1691022964521088e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.1691022964521088e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.1691022964521088e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.1691022964521088e-01
 UP BND1      rho_20    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     1.1691022964521088e-01
 BV BND1      x_7_1   
 UP BND1      w_7_1     1.1691022964521088e-01
 BV BND1      x_7_2   
 UP BND1      w_7_2     1.1691022964521088e-01
 BV BND1      x_7_3   
 UP BND1      w_7_3     1.1691022964521088e-01
 BV BND1      x_7_4   
 UP BND1      w_7_4     1.1691022964521088e-01
 BV BND1      x_7_5   
 UP BND1      w_7_5     1.1691022964521088e-01
 BV BND1      x_7_6   
 UP BND1      w_7_6     1.1691022964521088e-01
 BV BND1      x_7_7   
 UP BND1      w_7_7     1.1691022964521088e-01
 BV BND1      x_7_8   
 UP BND1      w_7_8     1.1691022964521088e-01
 BV BND1      x_7_9   
 UP BND1      w_7_9     1.1691022964521088e-01
 BV BND1      x_7_10  
 UP BND1      w_7_10    1.1691022964521088e-01
 UP BND1      rho_7     1
 UP BND1      a_12_11   1
 UP BND1      a_12_18   1
 UP BND1      a_12_9    1
 UP BND1      a_12_17   1
 UP BND1      a_12_10   1
 UP BND1      a_12_20   1
 UP BND1      a_12_7    1
 UP BND1      a_11_18   1
 UP BND1      a_11_9    1
 UP BND1      a_11_17   1
 UP BND1      a_11_10   1
 UP BND1      a_11_20   1
 UP BND1      a_11_7    1
 UP BND1      a_18_9    1
 UP BND1      a_18_17   1
 UP BND1      a_18_10   1
 UP BND1      a_18_20   1
 UP BND1      a_18_7    1
 UP BND1      a_9_17    1
 UP BND1      a_9_10    1
 UP BND1      a_9_20    1
 UP BND1      a_9_7     1
 UP BND1      a_17_10   1
 UP BND1      a_17_20   1
 UP BND1      a_17_7    1
 UP BND1      a_10_20   1
 UP BND1      a_10_7    1
 UP BND1      a_20_7    1
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_9_1
 BV BND1      service_1_9_1
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_10_1
 BV BND1      service_1_10_1
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_1_7_0
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  14
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  14
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  14
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  14
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_9
 UP BND1      load_0_6_9  30
 BV BND1      arc_0_6_10
 UP BND1      load_0_6_10  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_6
 UP BND1      load_0_9_6  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_9_16
 UP BND1      load_0_9_16  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_6
 UP BND1      load_0_10_6  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_10_16
 UP BND1      load_0_10_16  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_9
 UP BND1      load_0_16_9  30
 BV BND1      arc_0_16_10
 UP BND1      load_0_16_10  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  30
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
ENDATA
