* Signature: 0x65029a9aa0c190d3
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_16_26
 E  normalized_mass_16_27
 E  normalized_ratio_16_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 E  onehot_11_55
 E  normalized_mass_11_56
 E  normalized_ratio_11_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 E  onehot_31_84
 E  normalized_mass_31_85
 E  normalized_ratio_31_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 E  onehot_20_113
 E  normalized_mass_20_114
 E  normalized_ratio_20_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 E  onehot_2_148
 E  normalized_mass_2_149
 E  normalized_ratio_2_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 E  onehot_21_183
 E  normalized_mass_21_184
 E  normalized_ratio_21_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 E  onehot_12_218
 E  normalized_mass_12_219
 E  normalized_ratio_12_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 E  onehot_7_257
 E  normalized_mass_7_258
 E  normalized_ratio_7_259
 G  stock_lb_260
 L  stock_ub_261
 L  parent_nonstrict_scope_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 E  normalization_319
 G  full_original_Gini_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 L  arc_capacity_437
 L  arc_capacity_438
 L  arc_capacity_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 E  depot_departure_or_bypass_824
 E  depot_return_or_bypass_825
 E  out_degree_826
 E  in_degree_827
 G  order_active_lb_828
 L  order_active_ub_829
 E  segment_load_conservation_830
 G  segment_prefix_lb_831
 L  segment_prefix_ub_832
 E  out_degree_833
 E  in_degree_834
 G  order_active_lb_835
 L  order_active_ub_836
 E  segment_load_conservation_837
 G  segment_prefix_lb_838
 L  segment_prefix_ub_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  segment_load_conservation_844
 G  segment_prefix_lb_845
 L  segment_prefix_ub_846
 E  out_degree_847
 E  in_degree_848
 G  order_active_lb_849
 L  order_active_ub_850
 E  segment_load_conservation_851
 G  segment_prefix_lb_852
 L  segment_prefix_ub_853
 E  out_degree_854
 E  in_degree_855
 G  order_active_lb_856
 L  order_active_ub_857
 E  segment_load_conservation_858
 G  segment_prefix_lb_859
 L  segment_prefix_ub_860
 E  out_degree_861
 E  in_degree_862
 G  order_active_lb_863
 L  order_active_ub_864
 E  segment_load_conservation_865
 G  segment_prefix_lb_866
 L  segment_prefix_ub_867
 E  out_degree_868
 E  in_degree_869
 G  order_active_lb_870
 L  order_active_ub_871
 E  service_visit_def_872
 E  free_load_conservation_873
 E  out_degree_874
 E  in_degree_875
 G  order_active_lb_876
 L  order_active_ub_877
 E  service_visit_def_878
 E  free_load_conservation_879
 E  out_degree_880
 E  in_degree_881
 G  order_active_lb_882
 L  order_active_ub_883
 E  service_visit_def_884
 E  free_load_conservation_885
 E  out_degree_886
 E  in_degree_887
 G  order_active_lb_888
 L  order_active_ub_889
 E  service_visit_def_890
 E  free_load_conservation_891
 E  out_degree_892
 E  in_degree_893
 G  order_active_lb_894
 L  order_active_ub_895
 E  service_visit_def_896
 E  free_load_conservation_897
 E  out_degree_898
 E  in_degree_899
 G  order_active_lb_900
 L  order_active_ub_901
 E  service_visit_def_902
 E  free_load_conservation_903
 E  out_degree_904
 E  in_degree_905
 G  order_active_lb_906
 L  order_active_ub_907
 E  service_visit_def_908
 E  free_load_conservation_909
 E  out_degree_910
 E  in_degree_911
 G  order_active_lb_912
 L  order_active_ub_913
 E  service_visit_def_914
 E  free_load_conservation_915
 G  fixed_segment_relative_order_916
 G  fixed_segment_relative_order_917
 G  fixed_segment_relative_order_918
 G  fixed_segment_relative_order_919
 G  fixed_segment_relative_order_920
 L  original_T_including_depot_unload_921
 L  arc_capacity_922
 L  arc_capacity_923
 L  arc_capacity_924
 L  arc_capacity_925
 L  arc_capacity_926
 L  arc_capacity_927
 L  arc_capacity_928
 L  arc_capacity_929
 L  arc_capacity_930
 L  arc_capacity_931
 L  arc_capacity_932
 L  arc_capacity_933
 L  arc_capacity_934
 L  arc_capacity_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 E  depot_departure_or_bypass_1211
 E  depot_return_or_bypass_1212
 E  out_degree_1213
 E  in_degree_1214
 G  order_active_lb_1215
 L  order_active_ub_1216
 E  segment_load_conservation_1217
 G  segment_prefix_lb_1218
 L  segment_prefix_ub_1219
 E  out_degree_1220
 E  in_degree_1221
 G  order_active_lb_1222
 L  order_active_ub_1223
 E  segment_load_conservation_1224
 G  segment_prefix_lb_1225
 L  segment_prefix_ub_1226
 E  out_degree_1227
 E  in_degree_1228
 G  order_active_lb_1229
 L  order_active_ub_1230
 E  segment_load_conservation_1231
 G  segment_prefix_lb_1232
 L  segment_prefix_ub_1233
 E  out_degree_1234
 E  in_degree_1235
 G  order_active_lb_1236
 L  order_active_ub_1237
 E  segment_load_conservation_1238
 G  segment_prefix_lb_1239
 L  segment_prefix_ub_1240
 E  out_degree_1241
 E  in_degree_1242
 G  order_active_lb_1243
 L  order_active_ub_1244
 E  service_visit_def_1245
 E  free_load_conservation_1246
 E  out_degree_1247
 E  in_degree_1248
 G  order_active_lb_1249
 L  order_active_ub_1250
 E  service_visit_def_1251
 E  free_load_conservation_1252
 E  out_degree_1253
 E  in_degree_1254
 G  order_active_lb_1255
 L  order_active_ub_1256
 E  service_visit_def_1257
 E  free_load_conservation_1258
 E  out_degree_1259
 E  in_degree_1260
 G  order_active_lb_1261
 L  order_active_ub_1262
 E  service_visit_def_1263
 E  free_load_conservation_1264
 E  out_degree_1265
 E  in_degree_1266
 G  order_active_lb_1267
 L  order_active_ub_1268
 E  service_visit_def_1269
 E  free_load_conservation_1270
 E  out_degree_1271
 E  in_degree_1272
 G  order_active_lb_1273
 L  order_active_ub_1274
 E  service_visit_def_1275
 E  free_load_conservation_1276
 E  out_degree_1277
 E  in_degree_1278
 G  order_active_lb_1279
 L  order_active_ub_1280
 E  service_visit_def_1281
 E  free_load_conservation_1282
 E  out_degree_1283
 E  in_degree_1284
 G  order_active_lb_1285
 L  order_active_ub_1286
 E  service_visit_def_1287
 E  free_load_conservation_1288
 G  fixed_segment_relative_order_1289
 G  fixed_segment_relative_order_1290
 G  fixed_segment_relative_order_1291
 L  original_T_including_depot_unload_1292
 L  arc_capacity_1293
 L  arc_capacity_1294
 L  arc_capacity_1295
 L  arc_capacity_1296
 L  arc_capacity_1297
 L  arc_capacity_1298
 L  arc_capacity_1299
 L  arc_capacity_1300
 L  arc_capacity_1301
 L  arc_capacity_1302
 L  arc_capacity_1303
 L  arc_capacity_1304
 L  arc_capacity_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 G  connected_order_arc_1523
 L  arc_capacity_1524
 G  connected_order_arc_1525
 L  arc_capacity_1526
 G  connected_order_arc_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 G  connected_order_arc_1531
 L  arc_capacity_1532
 G  connected_order_arc_1533
 L  arc_capacity_1534
 G  connected_order_arc_1535
 E  depot_departure_or_bypass_1536
 E  depot_return_or_bypass_1537
 E  out_degree_1538
 E  in_degree_1539
 G  order_active_lb_1540
 L  order_active_ub_1541
 E  segment_load_conservation_1542
 G  segment_prefix_lb_1543
 L  segment_prefix_ub_1544
 E  out_degree_1545
 E  in_degree_1546
 G  order_active_lb_1547
 L  order_active_ub_1548
 E  segment_load_conservation_1549
 G  segment_prefix_lb_1550
 L  segment_prefix_ub_1551
 E  out_degree_1552
 E  in_degree_1553
 G  order_active_lb_1554
 L  order_active_ub_1555
 E  segment_load_conservation_1556
 G  segment_prefix_lb_1557
 L  segment_prefix_ub_1558
 E  out_degree_1559
 E  in_degree_1560
 G  order_active_lb_1561
 L  order_active_ub_1562
 E  service_visit_def_1563
 E  free_load_conservation_1564
 E  out_degree_1565
 E  in_degree_1566
 G  order_active_lb_1567
 L  order_active_ub_1568
 E  service_visit_def_1569
 E  free_load_conservation_1570
 E  out_degree_1571
 E  in_degree_1572
 G  order_active_lb_1573
 L  order_active_ub_1574
 E  service_visit_def_1575
 E  free_load_conservation_1576
 E  out_degree_1577
 E  in_degree_1578
 G  order_active_lb_1579
 L  order_active_ub_1580
 E  service_visit_def_1581
 E  free_load_conservation_1582
 E  out_degree_1583
 E  in_degree_1584
 G  order_active_lb_1585
 L  order_active_ub_1586
 E  service_visit_def_1587
 E  free_load_conservation_1588
 E  out_degree_1589
 E  in_degree_1590
 G  order_active_lb_1591
 L  order_active_ub_1592
 E  service_visit_def_1593
 E  free_load_conservation_1594
 E  out_degree_1595
 E  in_degree_1596
 G  order_active_lb_1597
 L  order_active_ub_1598
 E  service_visit_def_1599
 E  free_load_conservation_1600
 E  out_degree_1601
 E  in_degree_1602
 G  order_active_lb_1603
 L  order_active_ub_1604
 E  service_visit_def_1605
 E  free_load_conservation_1606
 G  fixed_segment_relative_order_1607
 G  fixed_segment_relative_order_1608
 L  original_T_including_depot_unload_1609
COLUMNS
    t         normalized_mass_16_27  -1
    t         normalized_mass_11_56  -1
    t         normalized_mass_31_85  -1
    t         normalized_mass_20_114  -1
    t         normalized_mass_2_149  -1
    t         normalized_mass_21_184  -1
    t         normalized_mass_12_219  -1
    t         normalized_mass_7_258  -1
    t         normalization_319  2.3367460317460321e+01
    t         full_original_Gini_320  -6.4263492063492137e+01
    q         OBJ       1
    q         parent_nonstrict_scope_262  1
    q         full_original_Gini_320  35
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_0  -2.5146187159453565e-02
    x_16_0    product_ub_1  -4.2794552185621712e-02
    x_16_0    onehot_16_26  1
    x_16_0    parent_nonstrict_scope_262  0.054
    x_16_0    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_0  1
    w_16_0    product_ub_1  1
    w_16_0    normalized_mass_16_27  1
    w_16_0    full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_2  -2.5146187159453565e-02
    x_16_1    product_ub_3  -4.2794552185621712e-02
    x_16_1    onehot_16_26  1
    x_16_1    stock_lb_260  1
    x_16_1    stock_ub_261  1
    x_16_1    parent_nonstrict_scope_262  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_2  1
    w_16_1    product_ub_3  1
    w_16_1    normalized_mass_16_27  1
    w_16_1    normalized_ratio_16_28  -1.6666666666666666e-01
    w_16_1    full_original_Gini_320  -1.9200793650793649e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_4  -2.5146187159453565e-02
    x_16_2    product_ub_5  -4.2794552185621712e-02
    x_16_2    onehot_16_26  1
    x_16_2    stock_lb_260  2
    x_16_2    stock_ub_261  2
    x_16_2    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_4  1
    w_16_2    product_ub_5  1
    w_16_2    normalized_mass_16_27  1
    w_16_2    normalized_ratio_16_28  -3.3333333333333331e-01
    w_16_2    full_original_Gini_320  -1.5034126984126983e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_6  -2.5146187159453565e-02
    x_16_3    product_ub_7  -4.2794552185621712e-02
    x_16_3    onehot_16_26  1
    x_16_3    stock_lb_260  3
    x_16_3    stock_ub_261  3
    x_16_3    parent_nonstrict_scope_262  0.027
    x_16_3    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_6  1
    w_16_3    product_ub_7  1
    w_16_3    normalized_mass_16_27  1
    w_16_3    normalized_ratio_16_28  -0.5
    w_16_3    full_original_Gini_320  -1.1067460317460318e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_8  -2.5146187159453565e-02
    x_16_4    product_ub_9  -4.2794552185621712e-02
    x_16_4    onehot_16_26  1
    x_16_4    stock_lb_260  4
    x_16_4    stock_ub_261  4
    x_16_4    parent_nonstrict_scope_262  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_8  1
    w_16_4    product_ub_9  1
    w_16_4    normalized_mass_16_27  1
    w_16_4    normalized_ratio_16_28  -6.6666666666666663e-01
    w_16_4    full_original_Gini_320  -7.2341269841269860e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_10  -2.5146187159453565e-02
    x_16_5    product_ub_11  -4.2794552185621712e-02
    x_16_5    onehot_16_26  1
    x_16_5    stock_lb_260  5
    x_16_5    stock_ub_261  5
    x_16_5    parent_nonstrict_scope_262  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_10  1
    w_16_5    product_ub_11  1
    w_16_5    normalized_mass_16_27  1
    w_16_5    normalized_ratio_16_28  -8.3333333333333326e-01
    w_16_5    full_original_Gini_320  -3.7674603174603183e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_12  -2.5146187159453565e-02
    x_16_6    product_ub_13  -4.2794552185621712e-02
    x_16_6    onehot_16_26  1
    x_16_6    stock_lb_260  6
    x_16_6    stock_ub_261  6
    x_16_6    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_12  1
    w_16_6    product_ub_13  1
    w_16_6    normalized_mass_16_27  1
    w_16_6    normalized_ratio_16_28  -1
    w_16_6    full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_14  -2.5146187159453565e-02
    x_16_7    product_ub_15  -4.2794552185621712e-02
    x_16_7    onehot_16_26  1
    x_16_7    stock_lb_260  7
    x_16_7    stock_ub_261  7
    x_16_7    parent_nonstrict_scope_262  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_14  1
    w_16_7    product_ub_15  1
    w_16_7    normalized_mass_16_27  1
    w_16_7    normalized_ratio_16_28  -1.1666666666666665e+00
    w_16_7    full_original_Gini_320  -8.13253968253968
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_16  -2.5146187159453565e-02
    x_16_8    product_ub_17  -4.2794552185621712e-02
    x_16_8    onehot_16_26  1
    x_16_8    stock_lb_260  8
    x_16_8    stock_ub_261  8
    x_16_8    parent_nonstrict_scope_262  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_16  1
    w_16_8    product_ub_17  1
    w_16_8    normalized_mass_16_27  1
    w_16_8    normalized_ratio_16_28  -1.3333333333333333e+00
    w_16_8    full_original_Gini_320  -1.2632539682539683e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_18  -2.5146187159453565e-02
    x_16_9    product_ub_19  -4.2794552185621712e-02
    x_16_9    onehot_16_26  1
    x_16_9    stock_lb_260  9
    x_16_9    stock_ub_261  9
    x_16_9    parent_nonstrict_scope_262  0.027
    x_16_9    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_18  1
    w_16_9    product_ub_19  1
    w_16_9    normalized_mass_16_27  1
    w_16_9    normalized_ratio_16_28  -1.5
    w_16_9    full_original_Gini_320  -1.7132539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_20  -2.5146187159453565e-02
    x_16_10   product_ub_21  -4.2794552185621712e-02
    x_16_10   onehot_16_26  1
    x_16_10   stock_lb_260  10
    x_16_10   stock_ub_261  10
    x_16_10   parent_nonstrict_scope_262  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_20  1
    w_16_10   product_ub_21  1
    w_16_10   normalized_mass_16_27  1
    w_16_10   normalized_ratio_16_28  -1.6666666666666665e+00
    w_16_10   full_original_Gini_320  -2.1632539682539683e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_22  -2.5146187159453565e-02
    x_16_11   product_ub_23  -4.2794552185621712e-02
    x_16_11   onehot_16_26  1
    x_16_11   stock_lb_260  11
    x_16_11   stock_ub_261  11
    x_16_11   parent_nonstrict_scope_262  0.045
    x_16_11   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_22  1
    w_16_11   product_ub_23  1
    w_16_11   normalized_mass_16_27  1
    w_16_11   normalized_ratio_16_28  -1.8333333333333333e+00
    w_16_11   full_original_Gini_320  -2.6132539682539676e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_24  -2.5146187159453565e-02
    x_16_12   product_ub_25  -4.2794552185621712e-02
    x_16_12   onehot_16_26  1
    x_16_12   stock_lb_260  12
    x_16_12   stock_ub_261  12
    x_16_12   parent_nonstrict_scope_262  0.054
    x_16_12   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_24  1
    w_16_12   product_ub_25  1
    w_16_12   normalized_mass_16_27  1
    w_16_12   normalized_ratio_16_28  -2
    w_16_12   full_original_Gini_320  -3.0632539682539679e+01
    rho_16    normalized_ratio_16_28  1
    rho_16    block_pair_pos_283  -1
    rho_16    block_pair_neg_284  1
    rho_16    block_pair_pos_285  -1
    rho_16    block_pair_neg_286  1
    rho_16    block_pair_pos_287  -1
    rho_16    block_pair_neg_288  1
    rho_16    block_pair_pos_289  -1
    rho_16    block_pair_neg_290  1
    rho_16    block_pair_pos_291  -1
    rho_16    block_pair_neg_292  1
    rho_16    block_pair_pos_293  -1
    rho_16    block_pair_neg_294  1
    rho_16    block_pair_pos_295  -1
    rho_16    block_pair_neg_296  1
    rho_16    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1249999999999993e-02
    x_11_0    product_lb_29  -2.5146187159453565e-02
    x_11_0    product_ub_30  -4.2794552185621712e-02
    x_11_0    onehot_11_55  1
    x_11_0    parent_nonstrict_scope_262  0.0375
    x_11_0    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_29  1
    w_11_0    product_ub_30  1
    w_11_0    normalized_mass_11_56  1
    w_11_0    full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7499999999999929e-03
    x_11_1    product_lb_31  -2.5146187159453565e-02
    x_11_1    product_ub_32  -4.2794552185621712e-02
    x_11_1    onehot_11_55  1
    x_11_1    stock_lb_260  1
    x_11_1    stock_ub_261  1
    x_11_1    parent_nonstrict_scope_262  0.03
    x_11_1    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_31  1
    w_11_1    product_ub_32  1
    w_11_1    normalized_mass_11_56  1
    w_11_1    normalized_ratio_11_57  -0.2
    w_11_1    full_original_Gini_320  -1.8367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       -3.7500000000000068e-03
    x_11_2    product_lb_33  -2.5146187159453565e-02
    x_11_2    product_ub_34  -4.2794552185621712e-02
    x_11_2    onehot_11_55  1
    x_11_2    stock_lb_260  2
    x_11_2    stock_ub_261  2
    x_11_2    parent_nonstrict_scope_262  0.0225
    x_11_2    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_33  1
    w_11_2    product_ub_34  1
    w_11_2    normalized_mass_11_56  1
    w_11_2    normalized_ratio_11_57  -0.4
    w_11_2    full_original_Gini_320  -1.3367460317460315e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -1.1250000000000010e-02
    x_11_3    product_lb_35  -2.5146187159453565e-02
    x_11_3    product_ub_36  -4.2794552185621712e-02
    x_11_3    onehot_11_55  1
    x_11_3    stock_lb_260  3
    x_11_3    stock_ub_261  3
    x_11_3    parent_nonstrict_scope_262  1.4999999999999996e-02
    x_11_3    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_35  1
    w_11_3    product_ub_36  1
    w_11_3    normalized_mass_11_56  1
    w_11_3    normalized_ratio_11_57  -6.0000000000000009e-01
    w_11_3    full_original_Gini_320  -8.7674603174603174e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -1.8750000000000010e-02
    x_11_4    product_lb_37  -2.5146187159453565e-02
    x_11_4    product_ub_38  -4.2794552185621712e-02
    x_11_4    onehot_11_55  1
    x_11_4    stock_lb_260  4
    x_11_4    stock_ub_261  4
    x_11_4    parent_nonstrict_scope_262  7.4999999999999980e-03
    x_11_4    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_37  1
    w_11_4    product_ub_38  1
    w_11_4    normalized_mass_11_56  1
    w_11_4    normalized_ratio_11_57  -0.8
    w_11_4    full_original_Gini_320  -4.2674603174603174e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -2.6250000000000006e-02
    x_11_5    product_lb_39  -2.5146187159453565e-02
    x_11_5    product_ub_40  -4.2794552185621712e-02
    x_11_5    onehot_11_55  1
    x_11_5    stock_lb_260  5
    x_11_5    stock_ub_261  5
    x_11_5    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_39  1
    w_11_5    product_ub_40  1
    w_11_5    normalized_mass_11_56  1
    w_11_5    normalized_ratio_11_57  -1
    w_11_5    full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -0.01875
    x_11_6    product_lb_41  -2.5146187159453565e-02
    x_11_6    product_ub_42  -4.2794552185621712e-02
    x_11_6    onehot_11_55  1
    x_11_6    stock_lb_260  6
    x_11_6    stock_ub_261  6
    x_11_6    parent_nonstrict_scope_262  7.5000000000000067e-03
    x_11_6    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_41  1
    w_11_6    product_ub_42  1
    w_11_6    normalized_mass_11_56  1
    w_11_6    normalized_ratio_11_57  -1.2000000000000002e+00
    w_11_6    full_original_Gini_320  -9.0325396825396886e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -1.1250000000000001e-02
    x_11_7    product_lb_43  -2.5146187159453565e-02
    x_11_7    product_ub_44  -4.2794552185621712e-02
    x_11_7    onehot_11_55  1
    x_11_7    stock_lb_260  7
    x_11_7    stock_ub_261  7
    x_11_7    parent_nonstrict_scope_262  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_43  1
    w_11_7    product_ub_44  1
    w_11_7    normalized_mass_11_56  1
    w_11_7    normalized_ratio_11_57  -1.4000000000000001e+00
    w_11_7    full_original_Gini_320  -1.4432539682539687e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -3.7500000000000033e-03
    x_11_8    product_lb_45  -2.5146187159453565e-02
    x_11_8    product_ub_46  -4.2794552185621712e-02
    x_11_8    onehot_11_55  1
    x_11_8    stock_lb_260  8
    x_11_8    stock_ub_261  8
    x_11_8    parent_nonstrict_scope_262  2.2500000000000003e-02
    x_11_8    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_45  1
    w_11_8    product_ub_46  1
    w_11_8    normalized_mass_11_56  1
    w_11_8    normalized_ratio_11_57  -1.6
    w_11_8    full_original_Gini_320  -1.9832539682539686e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       3.7499999999999929e-03
    x_11_9    product_lb_47  -2.5146187159453565e-02
    x_11_9    product_ub_48  -4.2794552185621712e-02
    x_11_9    onehot_11_55  1
    x_11_9    stock_lb_260  9
    x_11_9    stock_ub_261  9
    x_11_9    parent_nonstrict_scope_262  0.03
    x_11_9    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_47  1
    w_11_9    product_ub_48  1
    w_11_9    normalized_mass_11_56  1
    w_11_9    normalized_ratio_11_57  -1.8
    w_11_9    full_original_Gini_320  -2.5232539682539688e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1249999999999993e-02
    x_11_10   product_lb_49  -2.5146187159453565e-02
    x_11_10   product_ub_50  -4.2794552185621712e-02
    x_11_10   onehot_11_55  1
    x_11_10   stock_lb_260  10
    x_11_10   stock_ub_261  10
    x_11_10   parent_nonstrict_scope_262  0.0375
    x_11_10   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_49  1
    w_11_10   product_ub_50  1
    w_11_10   normalized_mass_11_56  1
    w_11_10   normalized_ratio_11_57  -2
    w_11_10   full_original_Gini_320  -3.0632539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       0.01875
    x_11_11   product_lb_51  -2.5146187159453565e-02
    x_11_11   product_ub_52  -4.2794552185621712e-02
    x_11_11   onehot_11_55  1
    x_11_11   stock_lb_260  11
    x_11_11   stock_ub_261  11
    x_11_11   parent_nonstrict_scope_262  4.5000000000000005e-02
    x_11_11   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_51  1
    w_11_11   product_ub_52  1
    w_11_11   normalized_mass_11_56  1
    w_11_11   normalized_ratio_11_57  -2.2
    w_11_11   full_original_Gini_320  -3.6032539682539671e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_12   OBJ       2.6250000000000006e-02
    x_11_12   product_lb_53  -2.5146187159453565e-02
    x_11_12   product_ub_54  -4.2794552185621712e-02
    x_11_12   onehot_11_55  1
    x_11_12   stock_lb_260  12
    x_11_12   stock_ub_261  12
    x_11_12   parent_nonstrict_scope_262  5.2500000000000012e-02
    x_11_12   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_53  1
    w_11_12   product_ub_54  1
    w_11_12   normalized_mass_11_56  1
    w_11_12   normalized_ratio_11_57  -2.4000000000000004e+00
    w_11_12   full_original_Gini_320  -4.1432539682539684e+01
    rho_11    normalized_ratio_11_57  1
    rho_11    block_pair_pos_269  -1
    rho_11    block_pair_neg_270  1
    rho_11    block_pair_pos_271  -1
    rho_11    block_pair_neg_272  1
    rho_11    block_pair_pos_273  -1
    rho_11    block_pair_neg_274  1
    rho_11    block_pair_pos_275  -1
    rho_11    block_pair_neg_276  1
    rho_11    block_pair_pos_277  -1
    rho_11    block_pair_neg_278  1
    rho_11    block_pair_pos_279  -1
    rho_11    block_pair_neg_280  1
    rho_11    block_pair_pos_287  1
    rho_11    block_pair_neg_288  -1
    rho_11    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_58  -2.5146187159453565e-02
    x_31_0    product_ub_59  -4.2794552185621712e-02
    x_31_0    onehot_31_84  1
    x_31_0    parent_nonstrict_scope_262  0.0735
    x_31_0    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_58  1
    w_31_0    product_ub_59  1
    w_31_0    normalized_mass_31_85  1
    w_31_0    full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_60  -2.5146187159453565e-02
    x_31_1    product_ub_61  -4.2794552185621712e-02
    x_31_1    onehot_31_84  1
    x_31_1    stock_lb_260  1
    x_31_1    stock_ub_261  1
    x_31_1    parent_nonstrict_scope_262  0.063
    x_31_1    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_60  1
    w_31_1    product_ub_61  1
    w_31_1    normalized_mass_31_85  1
    w_31_1    normalized_ratio_31_86  -1.4285714285714285e-01
    w_31_1    full_original_Gini_320  -1.9796031746031751e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_62  -2.5146187159453565e-02
    x_31_2    product_ub_63  -4.2794552185621712e-02
    x_31_2    onehot_31_84  1
    x_31_2    stock_lb_260  2
    x_31_2    stock_ub_261  2
    x_31_2    parent_nonstrict_scope_262  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_62  1
    w_31_2    product_ub_63  1
    w_31_2    normalized_mass_31_85  1
    w_31_2    normalized_ratio_31_86  -2.8571428571428570e-01
    w_31_2    full_original_Gini_320  -1.6224603174603171e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_64  -2.5146187159453565e-02
    x_31_3    product_ub_65  -4.2794552185621712e-02
    x_31_3    onehot_31_84  1
    x_31_3    stock_lb_260  3
    x_31_3    stock_ub_261  3
    x_31_3    parent_nonstrict_scope_262  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_64  1
    w_31_3    product_ub_65  1
    w_31_3    normalized_mass_31_85  1
    w_31_3    normalized_ratio_31_86  -4.2857142857142855e-01
    w_31_3    full_original_Gini_320  -1.2710317460317459e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_66  -2.5146187159453565e-02
    x_31_4    product_ub_67  -4.2794552185621712e-02
    x_31_4    onehot_31_84  1
    x_31_4    stock_lb_260  4
    x_31_4    stock_ub_261  4
    x_31_4    parent_nonstrict_scope_262  0.0315
    x_31_4    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_66  1
    w_31_4    product_ub_67  1
    w_31_4    normalized_mass_31_85  1
    w_31_4    normalized_ratio_31_86  -5.7142857142857140e-01
    w_31_4    full_original_Gini_320  -9.4246031746031758e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_68  -2.5146187159453565e-02
    x_31_5    product_ub_69  -4.2794552185621712e-02
    x_31_5    onehot_31_84  1
    x_31_5    stock_lb_260  5
    x_31_5    stock_ub_261  5
    x_31_5    parent_nonstrict_scope_262  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_68  1
    w_31_5    product_ub_69  1
    w_31_5    normalized_mass_31_85  1
    w_31_5    normalized_ratio_31_86  -7.1428571428571419e-01
    w_31_5    full_original_Gini_320  -6.13888888888889
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_70  -2.5146187159453565e-02
    x_31_6    product_ub_71  -4.2794552185621712e-02
    x_31_6    onehot_31_84  1
    x_31_6    stock_lb_260  6
    x_31_6    stock_ub_261  6
    x_31_6    parent_nonstrict_scope_262  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_70  1
    w_31_6    product_ub_71  1
    w_31_6    normalized_mass_31_85  1
    w_31_6    normalized_ratio_31_86  -8.5714285714285710e-01
    w_31_6    full_original_Gini_320  -3.41031746031746
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_72  -2.5146187159453565e-02
    x_31_7    product_ub_73  -4.2794552185621712e-02
    x_31_7    onehot_31_84  1
    x_31_7    stock_lb_260  7
    x_31_7    stock_ub_261  7
    x_31_7    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_72  1
    w_31_7    product_ub_73  1
    w_31_7    normalized_mass_31_85  1
    w_31_7    normalized_ratio_31_86  -1
    w_31_7    full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_74  -2.5146187159453565e-02
    x_31_8    product_ub_75  -4.2794552185621712e-02
    x_31_8    onehot_31_84  1
    x_31_8    stock_lb_260  8
    x_31_8    stock_ub_261  8
    x_31_8    parent_nonstrict_scope_262  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_74  1
    w_31_8    product_ub_75  1
    w_31_8    normalized_mass_31_85  1
    w_31_8    normalized_ratio_31_86  -1.1428571428571428e+00
    w_31_8    full_original_Gini_320  -7.4896825396825388e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_76  -2.5146187159453565e-02
    x_31_9    product_ub_77  -4.2794552185621712e-02
    x_31_9    onehot_31_84  1
    x_31_9    stock_lb_260  9
    x_31_9    stock_ub_261  9
    x_31_9    parent_nonstrict_scope_262  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_76  1
    w_31_9    product_ub_77  1
    w_31_9    normalized_mass_31_85  1
    w_31_9    normalized_ratio_31_86  -1.2857142857142856e+00
    w_31_9    full_original_Gini_320  -1.1346825396825391e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_78  -2.5146187159453565e-02
    x_31_10   product_ub_79  -4.2794552185621712e-02
    x_31_10   onehot_31_84  1
    x_31_10   stock_lb_260  10
    x_31_10   stock_ub_261  10
    x_31_10   parent_nonstrict_scope_262  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_78  1
    w_31_10   product_ub_79  1
    w_31_10   normalized_mass_31_85  1
    w_31_10   normalized_ratio_31_86  -1.4285714285714284e+00
    w_31_10   full_original_Gini_320  -1.5203968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_80  -2.5146187159453565e-02
    x_31_11   product_ub_81  -4.2794552185621712e-02
    x_31_11   onehot_31_84  1
    x_31_11   stock_lb_260  11
    x_31_11   stock_ub_261  11
    x_31_11   parent_nonstrict_scope_262  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_80  1
    w_31_11   product_ub_81  1
    w_31_11   normalized_mass_31_85  1
    w_31_11   normalized_ratio_31_86  -1.5714285714285714e+00
    w_31_11   full_original_Gini_320  -1.9061111111111110e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_82  -2.5146187159453565e-02
    x_31_12   product_ub_83  -4.2794552185621712e-02
    x_31_12   onehot_31_84  1
    x_31_12   stock_lb_260  12
    x_31_12   stock_ub_261  12
    x_31_12   parent_nonstrict_scope_262  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_82  1
    w_31_12   product_ub_83  1
    w_31_12   normalized_mass_31_85  1
    w_31_12   normalized_ratio_31_86  -1.7142857142857142e+00
    w_31_12   full_original_Gini_320  -2.2918253968253971e+01
    rho_31    normalized_ratio_31_86  1
    rho_31    block_pair_pos_279  1
    rho_31    block_pair_neg_280  -1
    rho_31    block_pair_pos_295  1
    rho_31    block_pair_neg_296  -1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       0.027
    x_20_0    product_lb_87  -2.5146187159453565e-02
    x_20_0    product_ub_88  -4.2794552185621712e-02
    x_20_0    onehot_20_113  1
    x_20_0    parent_nonstrict_scope_262  0.054
    x_20_0    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_87  1
    w_20_0    product_ub_88  1
    w_20_0    normalized_mass_20_114  1
    w_20_0    full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       0.018
    x_20_1    product_lb_89  -2.5146187159453565e-02
    x_20_1    product_ub_90  -4.2794552185621712e-02
    x_20_1    onehot_20_113  1
    x_20_1    stock_lb_260  1
    x_20_1    stock_ub_261  1
    x_20_1    parent_nonstrict_scope_262  0.045
    x_20_1    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_89  1
    w_20_1    product_ub_90  1
    w_20_1    normalized_mass_20_114  1
    w_20_1    normalized_ratio_20_115  -1.6666666666666666e-01
    w_20_1    full_original_Gini_320  -1.9200793650793649e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       9.0000000000000045e-03
    x_20_2    product_lb_91  -2.5146187159453565e-02
    x_20_2    product_ub_92  -4.2794552185621712e-02
    x_20_2    onehot_20_113  1
    x_20_2    stock_lb_260  2
    x_20_2    stock_ub_261  2
    x_20_2    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_20_2    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_91  1
    w_20_2    product_ub_92  1
    w_20_2    normalized_mass_20_114  1
    w_20_2    normalized_ratio_20_115  -3.3333333333333331e-01
    w_20_2    full_original_Gini_320  -1.5034126984126983e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_3    product_lb_93  -2.5146187159453565e-02
    x_20_3    product_ub_94  -4.2794552185621712e-02
    x_20_3    onehot_20_113  1
    x_20_3    stock_lb_260  3
    x_20_3    stock_ub_261  3
    x_20_3    parent_nonstrict_scope_262  0.027
    x_20_3    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_93  1
    w_20_3    product_ub_94  1
    w_20_3    normalized_mass_20_114  1
    w_20_3    normalized_ratio_20_115  -0.5
    w_20_3    full_original_Gini_320  -1.1067460317460318e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_4    OBJ       -8.9999999999999976e-03
    x_20_4    product_lb_95  -2.5146187159453565e-02
    x_20_4    product_ub_96  -4.2794552185621712e-02
    x_20_4    onehot_20_113  1
    x_20_4    stock_lb_260  4
    x_20_4    stock_ub_261  4
    x_20_4    parent_nonstrict_scope_262  1.8000000000000002e-02
    x_20_4    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_95  1
    w_20_4    product_ub_96  1
    w_20_4    normalized_mass_20_114  1
    w_20_4    normalized_ratio_20_115  -6.6666666666666663e-01
    w_20_4    full_original_Gini_320  -7.2341269841269860e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.7999999999999995e-02
    x_20_5    product_lb_97  -2.5146187159453565e-02
    x_20_5    product_ub_98  -4.2794552185621712e-02
    x_20_5    onehot_20_113  1
    x_20_5    stock_lb_260  5
    x_20_5    stock_ub_261  5
    x_20_5    parent_nonstrict_scope_262  9.0000000000000045e-03
    x_20_5    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_97  1
    w_20_5    product_ub_98  1
    w_20_5    normalized_mass_20_114  1
    w_20_5    normalized_ratio_20_115  -8.3333333333333326e-01
    w_20_5    full_original_Gini_320  -3.7674603174603183e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -0.027
    x_20_6    product_lb_99  -2.5146187159453565e-02
    x_20_6    product_ub_100  -4.2794552185621712e-02
    x_20_6    onehot_20_113  1
    x_20_6    stock_lb_260  6
    x_20_6    stock_ub_261  6
    x_20_6    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_99  1
    w_20_6    product_ub_100  1
    w_20_6    normalized_mass_20_114  1
    w_20_6    normalized_ratio_20_115  -1
    w_20_6    full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -1.8000000000000009e-02
    x_20_7    product_lb_101  -2.5146187159453565e-02
    x_20_7    product_ub_102  -4.2794552185621712e-02
    x_20_7    onehot_20_113  1
    x_20_7    stock_lb_260  7
    x_20_7    stock_ub_261  7
    x_20_7    parent_nonstrict_scope_262  8.9999999999999924e-03
    x_20_7    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_101  1
    w_20_7    product_ub_102  1
    w_20_7    normalized_mass_20_114  1
    w_20_7    normalized_ratio_20_115  -1.1666666666666665e+00
    w_20_7    full_original_Gini_320  -8.13253968253968
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -9.0000000000000045e-03
    x_20_8    product_lb_103  -2.5146187159453565e-02
    x_20_8    product_ub_104  -4.2794552185621712e-02
    x_20_8    onehot_20_113  1
    x_20_8    stock_lb_260  8
    x_20_8    stock_ub_261  8
    x_20_8    parent_nonstrict_scope_262  1.7999999999999995e-02
    x_20_8    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_103  1
    w_20_8    product_ub_104  1
    w_20_8    normalized_mass_20_114  1
    w_20_8    normalized_ratio_20_115  -1.3333333333333333e+00
    w_20_8    full_original_Gini_320  -1.2632539682539683e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_9    product_lb_105  -2.5146187159453565e-02
    x_20_9    product_ub_106  -4.2794552185621712e-02
    x_20_9    onehot_20_113  1
    x_20_9    stock_lb_260  9
    x_20_9    stock_ub_261  9
    x_20_9    parent_nonstrict_scope_262  0.027
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_105  1
    w_20_9    product_ub_106  1
    w_20_9    normalized_mass_20_114  1
    w_20_9    normalized_ratio_20_115  -1.5
    w_20_9    full_original_Gini_320  -1.7132539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       0.00899999999999999
    x_20_10   product_lb_107  -2.5146187159453565e-02
    x_20_10   product_ub_108  -4.2794552185621712e-02
    x_20_10   onehot_20_113  1
    x_20_10   stock_lb_260  10
    x_20_10   stock_ub_261  10
    x_20_10   parent_nonstrict_scope_262  3.5999999999999990e-02
    x_20_10   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_107  1
    w_20_10   product_ub_108  1
    w_20_10   normalized_mass_20_114  1
    w_20_10   normalized_ratio_20_115  -1.6666666666666665e+00
    w_20_10   full_original_Gini_320  -2.1632539682539683e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       0.018
    x_20_11   product_lb_109  -2.5146187159453565e-02
    x_20_11   product_ub_110  -4.2794552185621712e-02
    x_20_11   onehot_20_113  1
    x_20_11   stock_lb_260  11
    x_20_11   stock_ub_261  11
    x_20_11   parent_nonstrict_scope_262  0.045
    x_20_11   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_109  1
    w_20_11   product_ub_110  1
    w_20_11   normalized_mass_20_114  1
    w_20_11   normalized_ratio_20_115  -1.8333333333333333e+00
    w_20_11   full_original_Gini_320  -2.6132539682539676e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_12   OBJ       0.027
    x_20_12   product_lb_111  -2.5146187159453565e-02
    x_20_12   product_ub_112  -4.2794552185621712e-02
    x_20_12   onehot_20_113  1
    x_20_12   stock_lb_260  12
    x_20_12   stock_ub_261  12
    x_20_12   parent_nonstrict_scope_262  0.054
    x_20_12   unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_111  1
    w_20_12   product_ub_112  1
    w_20_12   normalized_mass_20_114  1
    w_20_12   normalized_ratio_20_115  -2
    w_20_12   full_original_Gini_320  -3.0632539682539679e+01
    rho_20    normalized_ratio_20_115  1
    rho_20    block_pair_pos_275  1
    rho_20    block_pair_neg_276  -1
    rho_20    block_pair_pos_291  1
    rho_20    block_pair_neg_292  -1
    rho_20    block_pair_pos_297  -1
    rho_20    block_pair_neg_298  1
    rho_20    block_pair_pos_299  -1
    rho_20    block_pair_neg_300  1
    rho_20    block_pair_pos_301  -1
    rho_20    block_pair_neg_302  1
    rho_20    block_pair_pos_303  -1
    rho_20    block_pair_neg_304  1
    rho_20    block_pair_pos_315  1
    rho_20    block_pair_neg_316  -1
    rho_20    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_116  -2.5146187159453565e-02
    x_2_0     product_ub_117  -4.2794552185621712e-02
    x_2_0     onehot_2_148  1
    x_2_0     parent_nonstrict_scope_262  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_116  1
    w_2_0     product_ub_117  1
    w_2_0     normalized_mass_2_149  1
    w_2_0     full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_118  -2.5146187159453565e-02
    x_2_1     product_ub_119  -4.2794552185621712e-02
    x_2_1     onehot_2_148  1
    x_2_1     stock_lb_260  1
    x_2_1     stock_ub_261  1
    x_2_1     parent_nonstrict_scope_262  0.063
    x_2_1     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_118  1
    w_2_1     product_ub_119  1
    w_2_1     normalized_mass_2_149  1
    w_2_1     normalized_ratio_2_150  -1.4285714285714285e-01
    w_2_1     full_original_Gini_320  -1.9796031746031751e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_120  -2.5146187159453565e-02
    x_2_2     product_ub_121  -4.2794552185621712e-02
    x_2_2     onehot_2_148  1
    x_2_2     stock_lb_260  2
    x_2_2     stock_ub_261  2
    x_2_2     parent_nonstrict_scope_262  0.0525
    x_2_2     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_120  1
    w_2_2     product_ub_121  1
    w_2_2     normalized_mass_2_149  1
    w_2_2     normalized_ratio_2_150  -2.8571428571428570e-01
    w_2_2     full_original_Gini_320  -1.6224603174603171e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_122  -2.5146187159453565e-02
    x_2_3     product_ub_123  -4.2794552185621712e-02
    x_2_3     onehot_2_148  1
    x_2_3     stock_lb_260  3
    x_2_3     stock_ub_261  3
    x_2_3     parent_nonstrict_scope_262  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_122  1
    w_2_3     product_ub_123  1
    w_2_3     normalized_mass_2_149  1
    w_2_3     normalized_ratio_2_150  -4.2857142857142855e-01
    w_2_3     full_original_Gini_320  -1.2710317460317459e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_124  -2.5146187159453565e-02
    x_2_4     product_ub_125  -4.2794552185621712e-02
    x_2_4     onehot_2_148  1
    x_2_4     stock_lb_260  4
    x_2_4     stock_ub_261  4
    x_2_4     parent_nonstrict_scope_262  0.0315
    x_2_4     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_124  1
    w_2_4     product_ub_125  1
    w_2_4     normalized_mass_2_149  1
    w_2_4     normalized_ratio_2_150  -5.7142857142857140e-01
    w_2_4     full_original_Gini_320  -9.4246031746031758e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_126  -2.5146187159453565e-02
    x_2_5     product_ub_127  -4.2794552185621712e-02
    x_2_5     onehot_2_148  1
    x_2_5     stock_lb_260  5
    x_2_5     stock_ub_261  5
    x_2_5     parent_nonstrict_scope_262  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_126  1
    w_2_5     product_ub_127  1
    w_2_5     normalized_mass_2_149  1
    w_2_5     normalized_ratio_2_150  -7.1428571428571419e-01
    w_2_5     full_original_Gini_320  -6.13888888888889
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_128  -2.5146187159453565e-02
    x_2_6     product_ub_129  -4.2794552185621712e-02
    x_2_6     onehot_2_148  1
    x_2_6     stock_lb_260  6
    x_2_6     stock_ub_261  6
    x_2_6     parent_nonstrict_scope_262  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_128  1
    w_2_6     product_ub_129  1
    w_2_6     normalized_mass_2_149  1
    w_2_6     normalized_ratio_2_150  -8.5714285714285710e-01
    w_2_6     full_original_Gini_320  -3.41031746031746
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_130  -2.5146187159453565e-02
    x_2_7     product_ub_131  -4.2794552185621712e-02
    x_2_7     onehot_2_148  1
    x_2_7     stock_lb_260  7
    x_2_7     stock_ub_261  7
    x_2_7     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_130  1
    w_2_7     product_ub_131  1
    w_2_7     normalized_mass_2_149  1
    w_2_7     normalized_ratio_2_150  -1
    w_2_7     full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_132  -2.5146187159453565e-02
    x_2_8     product_ub_133  -4.2794552185621712e-02
    x_2_8     onehot_2_148  1
    x_2_8     stock_lb_260  8
    x_2_8     stock_ub_261  8
    x_2_8     parent_nonstrict_scope_262  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_132  1
    w_2_8     product_ub_133  1
    w_2_8     normalized_mass_2_149  1
    w_2_8     normalized_ratio_2_150  -1.1428571428571428e+00
    w_2_8     full_original_Gini_320  -7.4896825396825388e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_134  -2.5146187159453565e-02
    x_2_9     product_ub_135  -4.2794552185621712e-02
    x_2_9     onehot_2_148  1
    x_2_9     stock_lb_260  9
    x_2_9     stock_ub_261  9
    x_2_9     parent_nonstrict_scope_262  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_134  1
    w_2_9     product_ub_135  1
    w_2_9     normalized_mass_2_149  1
    w_2_9     normalized_ratio_2_150  -1.2857142857142856e+00
    w_2_9     full_original_Gini_320  -1.1346825396825391e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_136  -2.5146187159453565e-02
    x_2_10    product_ub_137  -4.2794552185621712e-02
    x_2_10    onehot_2_148  1
    x_2_10    stock_lb_260  10
    x_2_10    stock_ub_261  10
    x_2_10    parent_nonstrict_scope_262  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_136  1
    w_2_10    product_ub_137  1
    w_2_10    normalized_mass_2_149  1
    w_2_10    normalized_ratio_2_150  -1.4285714285714284e+00
    w_2_10    full_original_Gini_320  -1.5203968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_138  -2.5146187159453565e-02
    x_2_11    product_ub_139  -4.2794552185621712e-02
    x_2_11    onehot_2_148  1
    x_2_11    stock_lb_260  11
    x_2_11    stock_ub_261  11
    x_2_11    parent_nonstrict_scope_262  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_138  1
    w_2_11    product_ub_139  1
    w_2_11    normalized_mass_2_149  1
    w_2_11    normalized_ratio_2_150  -1.5714285714285714e+00
    w_2_11    full_original_Gini_320  -1.9061111111111110e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_140  -2.5146187159453565e-02
    x_2_12    product_ub_141  -4.2794552185621712e-02
    x_2_12    onehot_2_148  1
    x_2_12    stock_lb_260  12
    x_2_12    stock_ub_261  12
    x_2_12    parent_nonstrict_scope_262  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_140  1
    w_2_12    product_ub_141  1
    w_2_12    normalized_mass_2_149  1
    w_2_12    normalized_ratio_2_150  -1.7142857142857142e+00
    w_2_12    full_original_Gini_320  -2.2918253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_142  -2.5146187159453565e-02
    x_2_13    product_ub_143  -4.2794552185621712e-02
    x_2_13    onehot_2_148  1
    x_2_13    stock_lb_260  13
    x_2_13    stock_ub_261  13
    x_2_13    parent_nonstrict_scope_262  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_142  1
    w_2_13    product_ub_143  1
    w_2_13    normalized_mass_2_149  1
    w_2_13    normalized_ratio_2_150  -1.8571428571428570e+00
    w_2_13    full_original_Gini_320  -2.6775396825396825e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_144  -2.5146187159453565e-02
    x_2_14    product_ub_145  -4.2794552185621712e-02
    x_2_14    onehot_2_148  1
    x_2_14    stock_lb_260  14
    x_2_14    stock_ub_261  14
    x_2_14    parent_nonstrict_scope_262  0.0735
    x_2_14    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_144  1
    w_2_14    product_ub_145  1
    w_2_14    normalized_mass_2_149  1
    w_2_14    normalized_ratio_2_150  -2
    w_2_14    full_original_Gini_320  -3.0632539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_146  -2.5146187159453565e-02
    x_2_15    product_ub_147  -4.2794552185621712e-02
    x_2_15    onehot_2_148  1
    x_2_15    stock_lb_260  15
    x_2_15    stock_ub_261  15
    x_2_15    parent_nonstrict_scope_262  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_146  1
    w_2_15    product_ub_147  1
    w_2_15    normalized_mass_2_149  1
    w_2_15    normalized_ratio_2_150  -2.1428571428571428e+00
    w_2_15    full_original_Gini_320  -3.4489682539682534e+01
    rho_2     normalized_ratio_2_150  1
    rho_2     block_pair_pos_263  -1
    rho_2     block_pair_neg_264  1
    rho_2     block_pair_pos_265  -1
    rho_2     block_pair_neg_266  1
    rho_2     block_pair_pos_267  -1
    rho_2     block_pair_neg_268  1
    rho_2     block_pair_pos_269  1
    rho_2     block_pair_neg_270  -1
    rho_2     block_pair_pos_283  1
    rho_2     block_pair_neg_284  -1
    rho_2     block_pair_pos_297  1
    rho_2     block_pair_neg_298  -1
    rho_2     block_pair_pos_309  1
    rho_2     block_pair_neg_310  -1
    rho_2     normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_21_0    OBJ       0.048
    x_21_0    product_lb_151  -2.5146187159453565e-02
    x_21_0    product_ub_152  -4.2794552185621712e-02
    x_21_0    onehot_21_183  1
    x_21_0    parent_nonstrict_scope_262  0.096
    x_21_0    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_0    product_lb_151  1
    w_21_0    product_ub_152  1
    w_21_0    normalized_mass_21_184  1
    w_21_0    full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_1    OBJ       3.6000000000000004e-02
    x_21_1    product_lb_153  -2.5146187159453565e-02
    x_21_1    product_ub_154  -4.2794552185621712e-02
    x_21_1    onehot_21_183  1
    x_21_1    stock_lb_260  1
    x_21_1    stock_ub_261  1
    x_21_1    parent_nonstrict_scope_262  0.084
    MARKER    'MARKER'                 'INTEND'
    w_21_1    product_lb_153  1
    w_21_1    product_ub_154  1
    w_21_1    normalized_mass_21_184  1
    w_21_1    normalized_ratio_21_185  -0.125
    w_21_1    full_original_Gini_320  -2.0242460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_2    OBJ       2.4000000000000007e-02
    x_21_2    product_lb_155  -2.5146187159453565e-02
    x_21_2    product_ub_156  -4.2794552185621712e-02
    x_21_2    onehot_21_183  1
    x_21_2    stock_lb_260  2
    x_21_2    stock_ub_261  2
    x_21_2    parent_nonstrict_scope_262  7.2000000000000008e-02
    x_21_2    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_2    product_lb_155  1
    w_21_2    product_ub_156  1
    w_21_2    normalized_mass_21_184  1
    w_21_2    normalized_ratio_21_185  -0.25
    w_21_2    full_original_Gini_320  -1.7117460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_3    OBJ       1.1999999999999997e-02
    x_21_3    product_lb_157  -2.5146187159453565e-02
    x_21_3    product_ub_158  -4.2794552185621712e-02
    x_21_3    onehot_21_183  1
    x_21_3    stock_lb_260  3
    x_21_3    stock_ub_261  3
    x_21_3    parent_nonstrict_scope_262  0.06
    x_21_3    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_3    product_lb_157  1
    w_21_3    product_ub_158  1
    w_21_3    normalized_mass_21_184  1
    w_21_3    normalized_ratio_21_185  -0.375
    w_21_3    full_original_Gini_320  -1.3992460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_4    product_lb_159  -2.5146187159453565e-02
    x_21_4    product_ub_160  -4.2794552185621712e-02
    x_21_4    onehot_21_183  1
    x_21_4    stock_lb_260  4
    x_21_4    stock_ub_261  4
    x_21_4    parent_nonstrict_scope_262  0.048
    x_21_4    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_4    product_lb_159  1
    w_21_4    product_ub_160  1
    w_21_4    normalized_mass_21_184  1
    w_21_4    normalized_ratio_21_185  -0.5
    w_21_4    full_original_Gini_320  -1.1067460317460318e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_5    OBJ       -1.1999999999999997e-02
    x_21_5    product_lb_161  -2.5146187159453565e-02
    x_21_5    product_ub_162  -4.2794552185621712e-02
    x_21_5    onehot_21_183  1
    x_21_5    stock_lb_260  5
    x_21_5    stock_ub_261  5
    x_21_5    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_21_5    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_5    product_lb_161  1
    w_21_5    product_ub_162  1
    w_21_5    normalized_mass_21_184  1
    w_21_5    normalized_ratio_21_185  -0.625
    w_21_5    full_original_Gini_320  -8.1924603174603163e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_6    OBJ       -0.024
    x_21_6    product_lb_163  -2.5146187159453565e-02
    x_21_6    product_ub_164  -4.2794552185621712e-02
    x_21_6    onehot_21_183  1
    x_21_6    stock_lb_260  6
    x_21_6    stock_ub_261  6
    x_21_6    parent_nonstrict_scope_262  0.024
    x_21_6    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_6    product_lb_163  1
    w_21_6    product_ub_164  1
    w_21_6    normalized_mass_21_184  1
    w_21_6    normalized_ratio_21_185  -0.75
    w_21_6    full_original_Gini_320  -5.3174603174603163e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_7    OBJ       -3.6000000000000004e-02
    x_21_7    product_lb_165  -2.5146187159453565e-02
    x_21_7    product_ub_166  -4.2794552185621712e-02
    x_21_7    onehot_21_183  1
    x_21_7    stock_lb_260  7
    x_21_7    stock_ub_261  7
    x_21_7    parent_nonstrict_scope_262  0.012
    x_21_7    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_7    product_lb_165  1
    w_21_7    product_ub_166  1
    w_21_7    normalized_mass_21_184  1
    w_21_7    normalized_ratio_21_185  -0.875
    w_21_7    full_original_Gini_320  -3.2853174603174606e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_8    OBJ       -0.048
    x_21_8    product_lb_167  -2.5146187159453565e-02
    x_21_8    product_ub_168  -4.2794552185621712e-02
    x_21_8    onehot_21_183  1
    x_21_8    stock_lb_260  8
    x_21_8    stock_ub_261  8
    x_21_8    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_8    product_lb_167  1
    w_21_8    product_ub_168  1
    w_21_8    normalized_mass_21_184  1
    w_21_8    normalized_ratio_21_185  -1
    w_21_8    full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_9    OBJ       -3.6000000000000004e-02
    x_21_9    product_lb_169  -2.5146187159453565e-02
    x_21_9    product_ub_170  -4.2794552185621712e-02
    x_21_9    onehot_21_183  1
    x_21_9    stock_lb_260  9
    x_21_9    stock_ub_261  9
    x_21_9    parent_nonstrict_scope_262  0.012
    x_21_9    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_9    product_lb_169  1
    w_21_9    product_ub_170  1
    w_21_9    normalized_mass_21_184  1
    w_21_9    normalized_ratio_21_185  -1.125
    w_21_9    full_original_Gini_320  -7.0075396825396838e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_10   OBJ       -0.024
    x_21_10   product_lb_171  -2.5146187159453565e-02
    x_21_10   product_ub_172  -4.2794552185621712e-02
    x_21_10   onehot_21_183  1
    x_21_10   stock_lb_260  10
    x_21_10   stock_ub_261  10
    x_21_10   parent_nonstrict_scope_262  0.024
    x_21_10   unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_10   product_lb_171  1
    w_21_10   product_ub_172  1
    w_21_10   normalized_mass_21_184  1
    w_21_10   normalized_ratio_21_185  -1.25
    w_21_10   full_original_Gini_320  -1.0382539682539681e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_11   OBJ       -1.1999999999999997e-02
    x_21_11   product_lb_173  -2.5146187159453565e-02
    x_21_11   product_ub_174  -4.2794552185621712e-02
    x_21_11   onehot_21_183  1
    x_21_11   stock_lb_260  11
    x_21_11   stock_ub_261  11
    x_21_11   parent_nonstrict_scope_262  3.6000000000000004e-02
    x_21_11   unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_11   product_lb_173  1
    w_21_11   product_ub_174  1
    w_21_11   normalized_mass_21_184  1
    w_21_11   normalized_ratio_21_185  -1.375
    w_21_11   full_original_Gini_320  -1.3757539682539681e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_12   product_lb_175  -2.5146187159453565e-02
    x_21_12   product_ub_176  -4.2794552185621712e-02
    x_21_12   onehot_21_183  1
    x_21_12   stock_lb_260  12
    x_21_12   stock_ub_261  12
    x_21_12   parent_nonstrict_scope_262  0.048
    x_21_12   unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_12   product_lb_175  1
    w_21_12   product_ub_176  1
    w_21_12   normalized_mass_21_184  1
    w_21_12   normalized_ratio_21_185  -1.5
    w_21_12   full_original_Gini_320  -1.7132539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_13   OBJ       1.1999999999999997e-02
    x_21_13   product_lb_177  -2.5146187159453565e-02
    x_21_13   product_ub_178  -4.2794552185621712e-02
    x_21_13   onehot_21_183  1
    x_21_13   stock_lb_260  13
    x_21_13   stock_ub_261  13
    x_21_13   parent_nonstrict_scope_262  0.06
    x_21_13   unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_13   product_lb_177  1
    w_21_13   product_ub_178  1
    w_21_13   normalized_mass_21_184  1
    w_21_13   normalized_ratio_21_185  -1.625
    w_21_13   full_original_Gini_320  -2.0507539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_14   OBJ       2.4000000000000007e-02
    x_21_14   product_lb_179  -2.5146187159453565e-02
    x_21_14   product_ub_180  -4.2794552185621712e-02
    x_21_14   onehot_21_183  1
    x_21_14   stock_lb_260  14
    x_21_14   stock_ub_261  14
    x_21_14   parent_nonstrict_scope_262  7.2000000000000008e-02
    x_21_14   unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_14   product_lb_179  1
    w_21_14   product_ub_180  1
    w_21_14   normalized_mass_21_184  1
    w_21_14   normalized_ratio_21_185  -1.75
    w_21_14   full_original_Gini_320  -2.3882539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_15   OBJ       3.6000000000000004e-02
    x_21_15   product_lb_181  -2.5146187159453565e-02
    x_21_15   product_ub_182  -4.2794552185621712e-02
    x_21_15   onehot_21_183  1
    x_21_15   stock_lb_260  15
    x_21_15   stock_ub_261  15
    x_21_15   parent_nonstrict_scope_262  0.084
    x_21_15   unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_15   product_lb_181  1
    w_21_15   product_ub_182  1
    w_21_15   normalized_mass_21_184  1
    w_21_15   normalized_ratio_21_185  -1.875
    w_21_15   full_original_Gini_320  -2.7257539682539679e+01
    rho_21    normalized_ratio_21_185  1
    rho_21    block_pair_pos_267  1
    rho_21    block_pair_neg_268  -1
    rho_21    block_pair_pos_277  1
    rho_21    block_pair_neg_278  -1
    rho_21    block_pair_pos_293  1
    rho_21    block_pair_neg_294  -1
    rho_21    block_pair_pos_303  1
    rho_21    block_pair_neg_304  -1
    rho_21    block_pair_pos_305  -1
    rho_21    block_pair_neg_306  1
    rho_21    block_pair_pos_307  -1
    rho_21    block_pair_neg_308  1
    rho_21    block_pair_pos_317  1
    rho_21    block_pair_neg_318  -1
    rho_21    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       0.0315
    x_12_0    product_lb_186  -2.5146187159453565e-02
    x_12_0    product_ub_187  -4.2794552185621712e-02
    x_12_0    onehot_12_218  1
    x_12_0    parent_nonstrict_scope_262  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_186  1
    w_12_0    product_ub_187  1
    w_12_0    normalized_mass_12_219  1
    w_12_0    full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1000000000000005e-02
    x_12_1    product_lb_188  -2.5146187159453565e-02
    x_12_1    product_ub_189  -4.2794552185621712e-02
    x_12_1    onehot_12_218  1
    x_12_1    stock_lb_260  1
    x_12_1    stock_ub_261  1
    x_12_1    parent_nonstrict_scope_262  0.063
    x_12_1    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_188  1
    w_12_1    product_ub_189  1
    w_12_1    normalized_mass_12_219  1
    w_12_1    normalized_ratio_12_220  -1.4285714285714285e-01
    w_12_1    full_original_Gini_320  -1.9796031746031751e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0500000000000002e-02
    x_12_2    product_lb_190  -2.5146187159453565e-02
    x_12_2    product_ub_191  -4.2794552185621712e-02
    x_12_2    onehot_12_218  1
    x_12_2    stock_lb_260  2
    x_12_2    stock_ub_261  2
    x_12_2    parent_nonstrict_scope_262  0.0525
    x_12_2    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_190  1
    w_12_2    product_ub_191  1
    w_12_2    normalized_mass_12_219  1
    w_12_2    normalized_ratio_12_220  -2.8571428571428570e-01
    w_12_2    full_original_Gini_320  -1.6224603174603171e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_192  -2.5146187159453565e-02
    x_12_3    product_ub_193  -4.2794552185621712e-02
    x_12_3    onehot_12_218  1
    x_12_3    stock_lb_260  3
    x_12_3    stock_ub_261  3
    x_12_3    parent_nonstrict_scope_262  4.1999999999999996e-02
    x_12_3    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_192  1
    w_12_3    product_ub_193  1
    w_12_3    normalized_mass_12_219  1
    w_12_3    normalized_ratio_12_220  -4.2857142857142855e-01
    w_12_3    full_original_Gini_320  -1.2710317460317459e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0499999999999995e-02
    x_12_4    product_lb_194  -2.5146187159453565e-02
    x_12_4    product_ub_195  -4.2794552185621712e-02
    x_12_4    onehot_12_218  1
    x_12_4    stock_lb_260  4
    x_12_4    stock_ub_261  4
    x_12_4    parent_nonstrict_scope_262  0.0315
    x_12_4    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_194  1
    w_12_4    product_ub_195  1
    w_12_4    normalized_mass_12_219  1
    w_12_4    normalized_ratio_12_220  -5.7142857142857140e-01
    w_12_4    full_original_Gini_320  -9.4246031746031758e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.0999999999999991e-02
    x_12_5    product_lb_196  -2.5146187159453565e-02
    x_12_5    product_ub_197  -4.2794552185621712e-02
    x_12_5    onehot_12_218  1
    x_12_5    stock_lb_260  5
    x_12_5    stock_ub_261  5
    x_12_5    parent_nonstrict_scope_262  2.1000000000000005e-02
    x_12_5    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_196  1
    w_12_5    product_ub_197  1
    w_12_5    normalized_mass_12_219  1
    w_12_5    normalized_ratio_12_220  -7.1428571428571419e-01
    w_12_5    full_original_Gini_320  -6.13888888888889
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.1499999999999993e-02
    x_12_6    product_lb_198  -2.5146187159453565e-02
    x_12_6    product_ub_199  -4.2794552185621712e-02
    x_12_6    onehot_12_218  1
    x_12_6    stock_lb_260  6
    x_12_6    stock_ub_261  6
    x_12_6    parent_nonstrict_scope_262  1.0500000000000002e-02
    x_12_6    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_198  1
    w_12_6    product_ub_199  1
    w_12_6    normalized_mass_12_219  1
    w_12_6    normalized_ratio_12_220  -8.5714285714285710e-01
    w_12_6    full_original_Gini_320  -3.41031746031746
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.1999999999999996e-02
    x_12_7    product_lb_200  -2.5146187159453565e-02
    x_12_7    product_ub_201  -4.2794552185621712e-02
    x_12_7    onehot_12_218  1
    x_12_7    stock_lb_260  7
    x_12_7    stock_ub_261  7
    x_12_7    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_200  1
    w_12_7    product_ub_201  1
    w_12_7    normalized_mass_12_219  1
    w_12_7    normalized_ratio_12_220  -1
    w_12_7    full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -0.0315
    x_12_8    product_lb_202  -2.5146187159453565e-02
    x_12_8    product_ub_203  -4.2794552185621712e-02
    x_12_8    onehot_12_218  1
    x_12_8    stock_lb_260  8
    x_12_8    stock_ub_261  8
    x_12_8    parent_nonstrict_scope_262  1.0499999999999995e-02
    x_12_8    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_202  1
    w_12_8    product_ub_203  1
    w_12_8    normalized_mass_12_219  1
    w_12_8    normalized_ratio_12_220  -1.1428571428571428e+00
    w_12_8    full_original_Gini_320  -7.4896825396825388e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1000000000000005e-02
    x_12_9    product_lb_204  -2.5146187159453565e-02
    x_12_9    product_ub_205  -4.2794552185621712e-02
    x_12_9    onehot_12_218  1
    x_12_9    stock_lb_260  9
    x_12_9    stock_ub_261  9
    x_12_9    parent_nonstrict_scope_262  2.0999999999999991e-02
    x_12_9    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_204  1
    w_12_9    product_ub_205  1
    w_12_9    normalized_mass_12_219  1
    w_12_9    normalized_ratio_12_220  -1.2857142857142856e+00
    w_12_9    full_original_Gini_320  -1.1346825396825391e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0500000000000009e-02
    x_12_10   product_lb_206  -2.5146187159453565e-02
    x_12_10   product_ub_207  -4.2794552185621712e-02
    x_12_10   onehot_12_218  1
    x_12_10   stock_lb_260  10
    x_12_10   stock_ub_261  10
    x_12_10   parent_nonstrict_scope_262  3.1499999999999986e-02
    x_12_10   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_206  1
    w_12_10   product_ub_207  1
    w_12_10   normalized_mass_12_219  1
    w_12_10   normalized_ratio_12_220  -1.4285714285714284e+00
    w_12_10   full_original_Gini_320  -1.5203968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_208  -2.5146187159453565e-02
    x_12_11   product_ub_209  -4.2794552185621712e-02
    x_12_11   onehot_12_218  1
    x_12_11   stock_lb_260  11
    x_12_11   stock_ub_261  11
    x_12_11   parent_nonstrict_scope_262  4.1999999999999996e-02
    x_12_11   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_208  1
    w_12_11   product_ub_209  1
    w_12_11   normalized_mass_12_219  1
    w_12_11   normalized_ratio_12_220  -1.5714285714285714e+00
    w_12_11   full_original_Gini_320  -1.9061111111111110e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0499999999999995e-02
    x_12_12   product_lb_210  -2.5146187159453565e-02
    x_12_12   product_ub_211  -4.2794552185621712e-02
    x_12_12   onehot_12_218  1
    x_12_12   stock_lb_260  12
    x_12_12   stock_ub_261  12
    x_12_12   parent_nonstrict_scope_262  5.2499999999999991e-02
    x_12_12   unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_210  1
    w_12_12   product_ub_211  1
    w_12_12   normalized_mass_12_219  1
    w_12_12   normalized_ratio_12_220  -1.7142857142857142e+00
    w_12_12   full_original_Gini_320  -2.2918253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.0999999999999991e-02
    x_12_13   product_lb_212  -2.5146187159453565e-02
    x_12_13   product_ub_213  -4.2794552185621712e-02
    x_12_13   onehot_12_218  1
    x_12_13   stock_lb_260  13
    x_12_13   stock_ub_261  13
    x_12_13   parent_nonstrict_scope_262  6.2999999999999987e-02
    x_12_13   unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_212  1
    w_12_13   product_ub_213  1
    w_12_13   normalized_mass_12_219  1
    w_12_13   normalized_ratio_12_220  -1.8571428571428570e+00
    w_12_13   full_original_Gini_320  -2.6775396825396825e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       0.0315
    x_12_14   product_lb_214  -2.5146187159453565e-02
    x_12_14   product_ub_215  -4.2794552185621712e-02
    x_12_14   onehot_12_218  1
    x_12_14   stock_lb_260  14
    x_12_14   stock_ub_261  14
    x_12_14   parent_nonstrict_scope_262  0.0735
    x_12_14   unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_214  1
    w_12_14   product_ub_215  1
    w_12_14   normalized_mass_12_219  1
    w_12_14   normalized_ratio_12_220  -2
    w_12_14   full_original_Gini_320  -3.0632539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.1999999999999996e-02
    x_12_15   product_lb_216  -2.5146187159453565e-02
    x_12_15   product_ub_217  -4.2794552185621712e-02
    x_12_15   onehot_12_218  1
    x_12_15   stock_lb_260  15
    x_12_15   stock_ub_261  15
    x_12_15   parent_nonstrict_scope_262  8.3999999999999991e-02
    x_12_15   unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_216  1
    w_12_15   product_ub_217  1
    w_12_15   normalized_mass_12_219  1
    w_12_15   normalized_ratio_12_220  -2.1428571428571428e+00
    w_12_15   full_original_Gini_320  -3.4489682539682534e+01
    rho_12    normalized_ratio_12_220  1
    rho_12    block_pair_pos_265  1
    rho_12    block_pair_neg_266  -1
    rho_12    block_pair_pos_273  1
    rho_12    block_pair_neg_274  -1
    rho_12    block_pair_pos_281  -1
    rho_12    block_pair_neg_282  1
    rho_12    block_pair_pos_289  1
    rho_12    block_pair_neg_290  -1
    rho_12    block_pair_pos_301  1
    rho_12    block_pair_neg_302  -1
    rho_12    block_pair_pos_307  1
    rho_12    block_pair_neg_308  -1
    rho_12    block_pair_pos_313  1
    rho_12    block_pair_neg_314  -1
    rho_12    normalization_319  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       0.042
    x_7_0     product_lb_221  -2.5146187159453565e-02
    x_7_0     product_ub_222  -4.2794552185621712e-02
    x_7_0     onehot_7_257  1
    x_7_0     parent_nonstrict_scope_262  0.096
    x_7_0     unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_221  1
    w_7_0     product_ub_222  1
    w_7_0     normalized_mass_7_258  1
    w_7_0     full_original_Gini_320  -2.3367460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       3.0000000000000006e-02
    x_7_1     product_lb_223  -2.5146187159453565e-02
    x_7_1     product_ub_224  -4.2794552185621712e-02
    x_7_1     onehot_7_257  1
    x_7_1     stock_lb_260  1
    x_7_1     stock_ub_261  1
    x_7_1     parent_nonstrict_scope_262  0.084
    x_7_1     unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_223  1
    w_7_1     product_ub_224  1
    w_7_1     normalized_mass_7_258  1
    w_7_1     normalized_ratio_7_259  -0.125
    w_7_1     full_original_Gini_320  -2.0242460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       1.8000000000000009e-02
    x_7_2     product_lb_225  -2.5146187159453565e-02
    x_7_2     product_ub_226  -4.2794552185621712e-02
    x_7_2     onehot_7_257  1
    x_7_2     stock_lb_260  2
    x_7_2     stock_ub_261  2
    x_7_2     parent_nonstrict_scope_262  7.2000000000000008e-02
    x_7_2     unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_225  1
    w_7_2     product_ub_226  1
    w_7_2     normalized_mass_7_258  1
    w_7_2     normalized_ratio_7_259  -0.25
    w_7_2     full_original_Gini_320  -1.7117460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       5.9999999999999984e-03
    x_7_3     product_lb_227  -2.5146187159453565e-02
    x_7_3     product_ub_228  -4.2794552185621712e-02
    x_7_3     onehot_7_257  1
    x_7_3     stock_lb_260  3
    x_7_3     stock_ub_261  3
    x_7_3     parent_nonstrict_scope_262  0.06
    x_7_3     unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_227  1
    w_7_3     product_ub_228  1
    w_7_3     normalized_mass_7_258  1
    w_7_3     normalized_ratio_7_259  -0.375
    w_7_3     full_original_Gini_320  -1.3992460317460321e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -5.9999999999999984e-03
    x_7_4     product_lb_229  -2.5146187159453565e-02
    x_7_4     product_ub_230  -4.2794552185621712e-02
    x_7_4     onehot_7_257  1
    x_7_4     stock_lb_260  4
    x_7_4     stock_ub_261  4
    x_7_4     parent_nonstrict_scope_262  0.048
    x_7_4     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_229  1
    w_7_4     product_ub_230  1
    w_7_4     normalized_mass_7_258  1
    w_7_4     normalized_ratio_7_259  -0.5
    w_7_4     full_original_Gini_320  -1.1067460317460318e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.7999999999999995e-02
    x_7_5     product_lb_231  -2.5146187159453565e-02
    x_7_5     product_ub_232  -4.2794552185621712e-02
    x_7_5     onehot_7_257  1
    x_7_5     stock_lb_260  5
    x_7_5     stock_ub_261  5
    x_7_5     parent_nonstrict_scope_262  3.6000000000000004e-02
    x_7_5     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_231  1
    w_7_5     product_ub_232  1
    w_7_5     normalized_mass_7_258  1
    w_7_5     normalized_ratio_7_259  -0.625
    w_7_5     full_original_Gini_320  -8.1924603174603163e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -0.03
    x_7_6     product_lb_233  -2.5146187159453565e-02
    x_7_6     product_ub_234  -4.2794552185621712e-02
    x_7_6     onehot_7_257  1
    x_7_6     stock_lb_260  6
    x_7_6     stock_ub_261  6
    x_7_6     parent_nonstrict_scope_262  0.024
    x_7_6     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_233  1
    w_7_6     product_ub_234  1
    w_7_6     normalized_mass_7_258  1
    w_7_6     normalized_ratio_7_259  -0.75
    w_7_6     full_original_Gini_320  -5.3174603174603163e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -4.1999999999999996e-02
    x_7_7     product_lb_235  -2.5146187159453565e-02
    x_7_7     product_ub_236  -4.2794552185621712e-02
    x_7_7     onehot_7_257  1
    x_7_7     stock_lb_260  7
    x_7_7     stock_ub_261  7
    x_7_7     parent_nonstrict_scope_262  0.012
    x_7_7     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_235  1
    w_7_7     product_ub_236  1
    w_7_7     normalized_mass_7_258  1
    w_7_7     normalized_ratio_7_259  -0.875
    w_7_7     full_original_Gini_320  -3.2853174603174606e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -0.054
    x_7_8     product_lb_237  -2.5146187159453565e-02
    x_7_8     product_ub_238  -4.2794552185621712e-02
    x_7_8     onehot_7_257  1
    x_7_8     stock_lb_260  8
    x_7_8     stock_ub_261  8
    x_7_8     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_237  1
    w_7_8     product_ub_238  1
    w_7_8     normalized_mass_7_258  1
    w_7_8     normalized_ratio_7_259  -1
    w_7_8     full_original_Gini_320  -3.6325396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -4.1999999999999996e-02
    x_7_9     product_lb_239  -2.5146187159453565e-02
    x_7_9     product_ub_240  -4.2794552185621712e-02
    x_7_9     onehot_7_257  1
    x_7_9     stock_lb_260  9
    x_7_9     stock_ub_261  9
    x_7_9     parent_nonstrict_scope_262  0.012
    x_7_9     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_239  1
    w_7_9     product_ub_240  1
    w_7_9     normalized_mass_7_258  1
    w_7_9     normalized_ratio_7_259  -1.125
    w_7_9     full_original_Gini_320  -7.0075396825396838e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -0.03
    x_7_10    product_lb_241  -2.5146187159453565e-02
    x_7_10    product_ub_242  -4.2794552185621712e-02
    x_7_10    onehot_7_257  1
    x_7_10    stock_lb_260  10
    x_7_10    stock_ub_261  10
    x_7_10    parent_nonstrict_scope_262  0.024
    x_7_10    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_241  1
    w_7_10    product_ub_242  1
    w_7_10    normalized_mass_7_258  1
    w_7_10    normalized_ratio_7_259  -1.25
    w_7_10    full_original_Gini_320  -1.0382539682539681e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    OBJ       -1.7999999999999995e-02
    x_7_11    product_lb_243  -2.5146187159453565e-02
    x_7_11    product_ub_244  -4.2794552185621712e-02
    x_7_11    onehot_7_257  1
    x_7_11    stock_lb_260  11
    x_7_11    stock_ub_261  11
    x_7_11    parent_nonstrict_scope_262  3.6000000000000004e-02
    x_7_11    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_243  1
    w_7_11    product_ub_244  1
    w_7_11    normalized_mass_7_258  1
    w_7_11    normalized_ratio_7_259  -1.375
    w_7_11    full_original_Gini_320  -1.3757539682539681e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       -5.9999999999999984e-03
    x_7_12    product_lb_245  -2.5146187159453565e-02
    x_7_12    product_ub_246  -4.2794552185621712e-02
    x_7_12    onehot_7_257  1
    x_7_12    stock_lb_260  12
    x_7_12    stock_ub_261  12
    x_7_12    parent_nonstrict_scope_262  0.048
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_245  1
    w_7_12    product_ub_246  1
    w_7_12    normalized_mass_7_258  1
    w_7_12    normalized_ratio_7_259  -1.5
    w_7_12    full_original_Gini_320  -1.7132539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       5.9999999999999984e-03
    x_7_13    product_lb_247  -2.5146187159453565e-02
    x_7_13    product_ub_248  -4.2794552185621712e-02
    x_7_13    onehot_7_257  1
    x_7_13    stock_lb_260  13
    x_7_13    stock_ub_261  13
    x_7_13    parent_nonstrict_scope_262  0.06
    x_7_13    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_247  1
    w_7_13    product_ub_248  1
    w_7_13    normalized_mass_7_258  1
    w_7_13    normalized_ratio_7_259  -1.625
    w_7_13    full_original_Gini_320  -2.0507539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.8000000000000009e-02
    x_7_14    product_lb_249  -2.5146187159453565e-02
    x_7_14    product_ub_250  -4.2794552185621712e-02
    x_7_14    onehot_7_257  1
    x_7_14    stock_lb_260  14
    x_7_14    stock_ub_261  14
    x_7_14    parent_nonstrict_scope_262  7.2000000000000008e-02
    x_7_14    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_249  1
    w_7_14    product_ub_250  1
    w_7_14    normalized_mass_7_258  1
    w_7_14    normalized_ratio_7_259  -1.75
    w_7_14    full_original_Gini_320  -2.3882539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       3.0000000000000006e-02
    x_7_15    product_lb_251  -2.5146187159453565e-02
    x_7_15    product_ub_252  -4.2794552185621712e-02
    x_7_15    onehot_7_257  1
    x_7_15    stock_lb_260  15
    x_7_15    stock_ub_261  15
    x_7_15    parent_nonstrict_scope_262  0.084
    x_7_15    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_251  1
    w_7_15    product_ub_252  1
    w_7_15    normalized_mass_7_258  1
    w_7_15    normalized_ratio_7_259  -1.875
    w_7_15    full_original_Gini_320  -2.7257539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_16    OBJ       0.042
    x_7_16    product_lb_253  -2.5146187159453565e-02
    x_7_16    product_ub_254  -4.2794552185621712e-02
    x_7_16    onehot_7_257  1
    x_7_16    stock_lb_260  16
    x_7_16    stock_ub_261  16
    x_7_16    parent_nonstrict_scope_262  0.096
    x_7_16    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_16    product_lb_253  1
    w_7_16    product_ub_254  1
    w_7_16    normalized_mass_7_258  1
    w_7_16    normalized_ratio_7_259  -2
    w_7_16    full_original_Gini_320  -3.0632539682539679e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_17    OBJ       0.054
    x_7_17    product_lb_255  -2.5146187159453565e-02
    x_7_17    product_ub_256  -4.2794552185621712e-02
    x_7_17    onehot_7_257  1
    x_7_17    stock_lb_260  17
    x_7_17    stock_ub_261  17
    x_7_17    parent_nonstrict_scope_262  0.108
    x_7_17    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_17    product_lb_255  1
    w_7_17    product_ub_256  1
    w_7_17    normalized_mass_7_258  1
    w_7_17    normalized_ratio_7_259  -2.125
    w_7_17    full_original_Gini_320  -3.4007539682539679e+01
    rho_7     normalized_ratio_7_259  1
    rho_7     block_pair_pos_263  1
    rho_7     block_pair_neg_264  -1
    rho_7     block_pair_pos_271  1
    rho_7     block_pair_neg_272  -1
    rho_7     block_pair_pos_281  1
    rho_7     block_pair_neg_282  -1
    rho_7     block_pair_pos_285  1
    rho_7     block_pair_neg_286  -1
    rho_7     block_pair_pos_299  1
    rho_7     block_pair_neg_300  -1
    rho_7     block_pair_pos_305  1
    rho_7     block_pair_neg_306  -1
    rho_7     block_pair_pos_311  1
    rho_7     block_pair_neg_312  -1
    rho_7     normalization_319  1
    a_16_11   block_pair_pos_287  1
    a_16_11   block_pair_neg_288  1
    a_16_11   full_original_Gini_320  -1
    a_16_31   block_pair_pos_295  1
    a_16_31   block_pair_neg_296  1
    a_16_31   full_original_Gini_320  -1
    a_16_20   block_pair_pos_291  1
    a_16_20   block_pair_neg_292  1
    a_16_20   full_original_Gini_320  -1
    a_16_2    block_pair_pos_283  1
    a_16_2    block_pair_neg_284  1
    a_16_2    full_original_Gini_320  -1
    a_16_21   block_pair_pos_293  1
    a_16_21   block_pair_neg_294  1
    a_16_21   full_original_Gini_320  -1
    a_16_12   block_pair_pos_289  1
    a_16_12   block_pair_neg_290  1
    a_16_12   full_original_Gini_320  -1
    a_16_7    block_pair_pos_285  1
    a_16_7    block_pair_neg_286  1
    a_16_7    full_original_Gini_320  -1
    a_11_31   block_pair_pos_279  1
    a_11_31   block_pair_neg_280  1
    a_11_31   full_original_Gini_320  -1
    a_11_20   block_pair_pos_275  1
    a_11_20   block_pair_neg_276  1
    a_11_20   full_original_Gini_320  -1
    a_11_2    block_pair_pos_269  1
    a_11_2    block_pair_neg_270  1
    a_11_2    full_original_Gini_320  -1
    a_11_21   block_pair_pos_277  1
    a_11_21   block_pair_neg_278  1
    a_11_21   full_original_Gini_320  -1
    a_11_12   block_pair_pos_273  1
    a_11_12   block_pair_neg_274  1
    a_11_12   full_original_Gini_320  -1
    a_11_7    block_pair_pos_271  1
    a_11_7    block_pair_neg_272  1
    a_11_7    full_original_Gini_320  -1
    a_31_20   block_pair_pos_315  1
    a_31_20   block_pair_neg_316  1
    a_31_20   full_original_Gini_320  -1
    a_31_2    block_pair_pos_309  1
    a_31_2    block_pair_neg_310  1
    a_31_2    full_original_Gini_320  -1
    a_31_21   block_pair_pos_317  1
    a_31_21   block_pair_neg_318  1
    a_31_21   full_original_Gini_320  -1
    a_31_12   block_pair_pos_313  1
    a_31_12   block_pair_neg_314  1
    a_31_12   full_original_Gini_320  -1
    a_31_7    block_pair_pos_311  1
    a_31_7    block_pair_neg_312  1
    a_31_7    full_original_Gini_320  -1
    a_20_2    block_pair_pos_297  1
    a_20_2    block_pair_neg_298  1
    a_20_2    full_original_Gini_320  -1
    a_20_21   block_pair_pos_303  1
    a_20_21   block_pair_neg_304  1
    a_20_21   full_original_Gini_320  -1
    a_20_12   block_pair_pos_301  1
    a_20_12   block_pair_neg_302  1
    a_20_12   full_original_Gini_320  -1
    a_20_7    block_pair_pos_299  1
    a_20_7    block_pair_neg_300  1
    a_20_7    full_original_Gini_320  -1
    a_2_21    block_pair_pos_267  1
    a_2_21    block_pair_neg_268  1
    a_2_21    full_original_Gini_320  -1
    a_2_12    block_pair_pos_265  1
    a_2_12    block_pair_neg_266  1
    a_2_12    full_original_Gini_320  -1
    a_2_7     block_pair_pos_263  1
    a_2_7     block_pair_neg_264  1
    a_2_7     full_original_Gini_320  -1
    a_21_12   block_pair_pos_307  1
    a_21_12   block_pair_neg_308  1
    a_21_12   full_original_Gini_320  -1
    a_21_7    block_pair_pos_305  1
    a_21_7    block_pair_neg_306  1
    a_21_7    full_original_Gini_320  -1
    a_12_7    block_pair_pos_281  1
    a_12_7    block_pair_neg_282  1
    a_12_7    full_original_Gini_320  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_16_0  unique_nonzero_owner_321  1
    service_0_16_0  service_visit_def_872  1
    service_0_16_0  free_load_conservation_873  -1
    service_0_16_0  original_T_including_depot_unload_921  120
    service_0_16_2  unique_nonzero_owner_322  1
    service_0_16_2  service_visit_def_872  1
    service_0_16_2  free_load_conservation_873  1
    service_0_16_3  unique_nonzero_owner_323  1
    service_0_16_3  service_visit_def_872  1
    service_0_16_3  free_load_conservation_873  2
    service_0_16_4  unique_nonzero_owner_324  1
    service_0_16_4  service_visit_def_872  1
    service_0_16_4  free_load_conservation_873  3
    service_0_16_5  unique_nonzero_owner_325  1
    service_0_16_5  service_visit_def_872  1
    service_0_16_5  free_load_conservation_873  4
    service_0_16_6  unique_nonzero_owner_326  1
    service_0_16_6  service_visit_def_872  1
    service_0_16_6  free_load_conservation_873  5
    service_0_16_7  unique_nonzero_owner_327  1
    service_0_16_7  service_visit_def_872  1
    service_0_16_7  free_load_conservation_873  6
    service_0_16_8  unique_nonzero_owner_328  1
    service_0_16_8  service_visit_def_872  1
    service_0_16_8  free_load_conservation_873  7
    service_0_16_9  unique_nonzero_owner_329  1
    service_0_16_9  service_visit_def_872  1
    service_0_16_9  free_load_conservation_873  8
    service_0_16_10  unique_nonzero_owner_330  1
    service_0_16_10  service_visit_def_872  1
    service_0_16_10  free_load_conservation_873  9
    service_0_16_11  unique_nonzero_owner_331  1
    service_0_16_11  service_visit_def_872  1
    service_0_16_11  free_load_conservation_873  10
    service_0_16_12  unique_nonzero_owner_332  1
    service_0_16_12  service_visit_def_872  1
    service_0_16_12  free_load_conservation_873  11
    service_1_16_0  unique_nonzero_owner_321  1
    service_1_16_0  service_visit_def_1245  1
    service_1_16_0  free_load_conservation_1246  -1
    service_1_16_0  original_T_including_depot_unload_1292  120
    service_1_16_2  unique_nonzero_owner_322  1
    service_1_16_2  service_visit_def_1245  1
    service_1_16_2  free_load_conservation_1246  1
    service_1_16_3  unique_nonzero_owner_323  1
    service_1_16_3  service_visit_def_1245  1
    service_1_16_3  free_load_conservation_1246  2
    service_1_16_4  unique_nonzero_owner_324  1
    service_1_16_4  service_visit_def_1245  1
    service_1_16_4  free_load_conservation_1246  3
    service_1_16_5  unique_nonzero_owner_325  1
    service_1_16_5  service_visit_def_1245  1
    service_1_16_5  free_load_conservation_1246  4
    service_1_16_6  unique_nonzero_owner_326  1
    service_1_16_6  service_visit_def_1245  1
    service_1_16_6  free_load_conservation_1246  5
    service_1_16_7  unique_nonzero_owner_327  1
    service_1_16_7  service_visit_def_1245  1
    service_1_16_7  free_load_conservation_1246  6
    service_1_16_8  unique_nonzero_owner_328  1
    service_1_16_8  service_visit_def_1245  1
    service_1_16_8  free_load_conservation_1246  7
    service_1_16_9  unique_nonzero_owner_329  1
    service_1_16_9  service_visit_def_1245  1
    service_1_16_9  free_load_conservation_1246  8
    service_1_16_10  unique_nonzero_owner_330  1
    service_1_16_10  service_visit_def_1245  1
    service_1_16_10  free_load_conservation_1246  9
    service_1_16_11  unique_nonzero_owner_331  1
    service_1_16_11  service_visit_def_1245  1
    service_1_16_11  free_load_conservation_1246  10
    service_1_16_12  unique_nonzero_owner_332  1
    service_1_16_12  service_visit_def_1245  1
    service_1_16_12  free_load_conservation_1246  11
    service_2_16_0  unique_nonzero_owner_321  1
    service_2_16_0  service_visit_def_1563  1
    service_2_16_0  free_load_conservation_1564  -1
    service_2_16_0  original_T_including_depot_unload_1609  120
    service_2_16_2  unique_nonzero_owner_322  1
    service_2_16_2  service_visit_def_1563  1
    service_2_16_2  free_load_conservation_1564  1
    service_2_16_3  unique_nonzero_owner_323  1
    service_2_16_3  service_visit_def_1563  1
    service_2_16_3  free_load_conservation_1564  2
    service_2_16_4  unique_nonzero_owner_324  1
    service_2_16_4  service_visit_def_1563  1
    service_2_16_4  free_load_conservation_1564  3
    service_2_16_5  unique_nonzero_owner_325  1
    service_2_16_5  service_visit_def_1563  1
    service_2_16_5  free_load_conservation_1564  4
    service_2_16_6  unique_nonzero_owner_326  1
    service_2_16_6  service_visit_def_1563  1
    service_2_16_6  free_load_conservation_1564  5
    service_2_16_7  unique_nonzero_owner_327  1
    service_2_16_7  service_visit_def_1563  1
    service_2_16_7  free_load_conservation_1564  6
    service_2_16_8  unique_nonzero_owner_328  1
    service_2_16_8  service_visit_def_1563  1
    service_2_16_8  free_load_conservation_1564  7
    service_2_16_9  unique_nonzero_owner_329  1
    service_2_16_9  service_visit_def_1563  1
    service_2_16_9  free_load_conservation_1564  8
    service_2_16_10  unique_nonzero_owner_330  1
    service_2_16_10  service_visit_def_1563  1
    service_2_16_10  free_load_conservation_1564  9
    service_2_16_11  unique_nonzero_owner_331  1
    service_2_16_11  service_visit_def_1563  1
    service_2_16_11  free_load_conservation_1564  10
    service_2_16_12  unique_nonzero_owner_332  1
    service_2_16_12  service_visit_def_1563  1
    service_2_16_12  free_load_conservation_1564  11
    service_0_11_0  unique_nonzero_owner_333  1
    service_0_11_0  service_visit_def_878  1
    service_0_11_0  free_load_conservation_879  -7
    service_0_11_0  original_T_including_depot_unload_921  840
    service_0_11_1  unique_nonzero_owner_334  1
    service_0_11_1  service_visit_def_878  1
    service_0_11_1  free_load_conservation_879  -6
    service_0_11_1  original_T_including_depot_unload_921  720
    service_0_11_2  unique_nonzero_owner_335  1
    service_0_11_2  service_visit_def_878  1
    service_0_11_2  free_load_conservation_879  -5
    service_0_11_2  original_T_including_depot_unload_921  600
    service_0_11_3  unique_nonzero_owner_336  1
    service_0_11_3  service_visit_def_878  1
    service_0_11_3  free_load_conservation_879  -4
    service_0_11_3  original_T_including_depot_unload_921  480
    service_0_11_4  unique_nonzero_owner_337  1
    service_0_11_4  service_visit_def_878  1
    service_0_11_4  free_load_conservation_879  -3
    service_0_11_4  original_T_including_depot_unload_921  360
    service_0_11_5  unique_nonzero_owner_338  1
    service_0_11_5  service_visit_def_878  1
    service_0_11_5  free_load_conservation_879  -2
    service_0_11_5  original_T_including_depot_unload_921  240
    service_0_11_6  unique_nonzero_owner_339  1
    service_0_11_6  service_visit_def_878  1
    service_0_11_6  free_load_conservation_879  -1
    service_0_11_6  original_T_including_depot_unload_921  120
    service_0_11_8  unique_nonzero_owner_340  1
    service_0_11_8  service_visit_def_878  1
    service_0_11_8  free_load_conservation_879  1
    service_0_11_9  unique_nonzero_owner_341  1
    service_0_11_9  service_visit_def_878  1
    service_0_11_9  free_load_conservation_879  2
    service_0_11_10  unique_nonzero_owner_342  1
    service_0_11_10  service_visit_def_878  1
    service_0_11_10  free_load_conservation_879  3
    service_0_11_11  unique_nonzero_owner_343  1
    service_0_11_11  service_visit_def_878  1
    service_0_11_11  free_load_conservation_879  4
    service_0_11_12  unique_nonzero_owner_344  1
    service_0_11_12  service_visit_def_878  1
    service_0_11_12  free_load_conservation_879  5
    service_1_11_0  unique_nonzero_owner_333  1
    service_1_11_0  service_visit_def_1251  1
    service_1_11_0  free_load_conservation_1252  -7
    service_1_11_0  original_T_including_depot_unload_1292  840
    service_1_11_1  unique_nonzero_owner_334  1
    service_1_11_1  service_visit_def_1251  1
    service_1_11_1  free_load_conservation_1252  -6
    service_1_11_1  original_T_including_depot_unload_1292  720
    service_1_11_2  unique_nonzero_owner_335  1
    service_1_11_2  service_visit_def_1251  1
    service_1_11_2  free_load_conservation_1252  -5
    service_1_11_2  original_T_including_depot_unload_1292  600
    service_1_11_3  unique_nonzero_owner_336  1
    service_1_11_3  service_visit_def_1251  1
    service_1_11_3  free_load_conservation_1252  -4
    service_1_11_3  original_T_including_depot_unload_1292  480
    service_1_11_4  unique_nonzero_owner_337  1
    service_1_11_4  service_visit_def_1251  1
    service_1_11_4  free_load_conservation_1252  -3
    service_1_11_4  original_T_including_depot_unload_1292  360
    service_1_11_5  unique_nonzero_owner_338  1
    service_1_11_5  service_visit_def_1251  1
    service_1_11_5  free_load_conservation_1252  -2
    service_1_11_5  original_T_including_depot_unload_1292  240
    service_1_11_6  unique_nonzero_owner_339  1
    service_1_11_6  service_visit_def_1251  1
    service_1_11_6  free_load_conservation_1252  -1
    service_1_11_6  original_T_including_depot_unload_1292  120
    service_1_11_8  unique_nonzero_owner_340  1
    service_1_11_8  service_visit_def_1251  1
    service_1_11_8  free_load_conservation_1252  1
    service_1_11_9  unique_nonzero_owner_341  1
    service_1_11_9  service_visit_def_1251  1
    service_1_11_9  free_load_conservation_1252  2
    service_1_11_10  unique_nonzero_owner_342  1
    service_1_11_10  service_visit_def_1251  1
    service_1_11_10  free_load_conservation_1252  3
    service_1_11_11  unique_nonzero_owner_343  1
    service_1_11_11  service_visit_def_1251  1
    service_1_11_11  free_load_conservation_1252  4
    service_1_11_12  unique_nonzero_owner_344  1
    service_1_11_12  service_visit_def_1251  1
    service_1_11_12  free_load_conservation_1252  5
    service_2_11_0  unique_nonzero_owner_333  1
    service_2_11_0  service_visit_def_1569  1
    service_2_11_0  free_load_conservation_1570  -7
    service_2_11_0  original_T_including_depot_unload_1609  840
    service_2_11_1  unique_nonzero_owner_334  1
    service_2_11_1  service_visit_def_1569  1
    service_2_11_1  free_load_conservation_1570  -6
    service_2_11_1  original_T_including_depot_unload_1609  720
    service_2_11_2  unique_nonzero_owner_335  1
    service_2_11_2  service_visit_def_1569  1
    service_2_11_2  free_load_conservation_1570  -5
    service_2_11_2  original_T_including_depot_unload_1609  600
    service_2_11_3  unique_nonzero_owner_336  1
    service_2_11_3  service_visit_def_1569  1
    service_2_11_3  free_load_conservation_1570  -4
    service_2_11_3  original_T_including_depot_unload_1609  480
    service_2_11_4  unique_nonzero_owner_337  1
    service_2_11_4  service_visit_def_1569  1
    service_2_11_4  free_load_conservation_1570  -3
    service_2_11_4  original_T_including_depot_unload_1609  360
    service_2_11_5  unique_nonzero_owner_338  1
    service_2_11_5  service_visit_def_1569  1
    service_2_11_5  free_load_conservation_1570  -2
    service_2_11_5  original_T_including_depot_unload_1609  240
    service_2_11_6  unique_nonzero_owner_339  1
    service_2_11_6  service_visit_def_1569  1
    service_2_11_6  free_load_conservation_1570  -1
    service_2_11_6  original_T_including_depot_unload_1609  120
    service_2_11_8  unique_nonzero_owner_340  1
    service_2_11_8  service_visit_def_1569  1
    service_2_11_8  free_load_conservation_1570  1
    service_2_11_9  unique_nonzero_owner_341  1
    service_2_11_9  service_visit_def_1569  1
    service_2_11_9  free_load_conservation_1570  2
    service_2_11_10  unique_nonzero_owner_342  1
    service_2_11_10  service_visit_def_1569  1
    service_2_11_10  free_load_conservation_1570  3
    service_2_11_11  unique_nonzero_owner_343  1
    service_2_11_11  service_visit_def_1569  1
    service_2_11_11  free_load_conservation_1570  4
    service_2_11_12  unique_nonzero_owner_344  1
    service_2_11_12  service_visit_def_1569  1
    service_2_11_12  free_load_conservation_1570  5
    service_0_31_0  unique_nonzero_owner_345  1
    service_0_31_0  service_visit_def_884  1
    service_0_31_0  free_load_conservation_885  -2
    service_0_31_0  original_T_including_depot_unload_921  240
    service_0_31_1  unique_nonzero_owner_346  1
    service_0_31_1  service_visit_def_884  1
    service_0_31_1  free_load_conservation_885  -1
    service_0_31_1  original_T_including_depot_unload_921  120
    service_0_31_3  unique_nonzero_owner_347  1
    service_0_31_3  service_visit_def_884  1
    service_0_31_3  free_load_conservation_885  1
    service_0_31_4  unique_nonzero_owner_348  1
    service_0_31_4  service_visit_def_884  1
    service_0_31_4  free_load_conservation_885  2
    service_0_31_5  unique_nonzero_owner_349  1
    service_0_31_5  service_visit_def_884  1
    service_0_31_5  free_load_conservation_885  3
    service_0_31_6  unique_nonzero_owner_350  1
    service_0_31_6  service_visit_def_884  1
    service_0_31_6  free_load_conservation_885  4
    service_0_31_7  unique_nonzero_owner_351  1
    service_0_31_7  service_visit_def_884  1
    service_0_31_7  free_load_conservation_885  5
    service_0_31_8  unique_nonzero_owner_352  1
    service_0_31_8  service_visit_def_884  1
    service_0_31_8  free_load_conservation_885  6
    service_0_31_9  unique_nonzero_owner_353  1
    service_0_31_9  service_visit_def_884  1
    service_0_31_9  free_load_conservation_885  7
    service_0_31_10  unique_nonzero_owner_354  1
    service_0_31_10  service_visit_def_884  1
    service_0_31_10  free_load_conservation_885  8
    service_0_31_11  unique_nonzero_owner_355  1
    service_0_31_11  service_visit_def_884  1
    service_0_31_11  free_load_conservation_885  9
    service_0_31_12  unique_nonzero_owner_356  1
    service_0_31_12  service_visit_def_884  1
    service_0_31_12  free_load_conservation_885  10
    service_1_31_0  unique_nonzero_owner_345  1
    service_1_31_0  service_visit_def_1257  1
    service_1_31_0  free_load_conservation_1258  -2
    service_1_31_0  original_T_including_depot_unload_1292  240
    service_1_31_1  unique_nonzero_owner_346  1
    service_1_31_1  service_visit_def_1257  1
    service_1_31_1  free_load_conservation_1258  -1
    service_1_31_1  original_T_including_depot_unload_1292  120
    service_1_31_3  unique_nonzero_owner_347  1
    service_1_31_3  service_visit_def_1257  1
    service_1_31_3  free_load_conservation_1258  1
    service_1_31_4  unique_nonzero_owner_348  1
    service_1_31_4  service_visit_def_1257  1
    service_1_31_4  free_load_conservation_1258  2
    service_1_31_5  unique_nonzero_owner_349  1
    service_1_31_5  service_visit_def_1257  1
    service_1_31_5  free_load_conservation_1258  3
    service_1_31_6  unique_nonzero_owner_350  1
    service_1_31_6  service_visit_def_1257  1
    service_1_31_6  free_load_conservation_1258  4
    service_1_31_7  unique_nonzero_owner_351  1
    service_1_31_7  service_visit_def_1257  1
    service_1_31_7  free_load_conservation_1258  5
    service_1_31_8  unique_nonzero_owner_352  1
    service_1_31_8  service_visit_def_1257  1
    service_1_31_8  free_load_conservation_1258  6
    service_1_31_9  unique_nonzero_owner_353  1
    service_1_31_9  service_visit_def_1257  1
    service_1_31_9  free_load_conservation_1258  7
    service_1_31_10  unique_nonzero_owner_354  1
    service_1_31_10  service_visit_def_1257  1
    service_1_31_10  free_load_conservation_1258  8
    service_1_31_11  unique_nonzero_owner_355  1
    service_1_31_11  service_visit_def_1257  1
    service_1_31_11  free_load_conservation_1258  9
    service_1_31_12  unique_nonzero_owner_356  1
    service_1_31_12  service_visit_def_1257  1
    service_1_31_12  free_load_conservation_1258  10
    service_2_31_0  unique_nonzero_owner_345  1
    service_2_31_0  service_visit_def_1575  1
    service_2_31_0  free_load_conservation_1576  -2
    service_2_31_0  original_T_including_depot_unload_1609  240
    service_2_31_1  unique_nonzero_owner_346  1
    service_2_31_1  service_visit_def_1575  1
    service_2_31_1  free_load_conservation_1576  -1
    service_2_31_1  original_T_including_depot_unload_1609  120
    service_2_31_3  unique_nonzero_owner_347  1
    service_2_31_3  service_visit_def_1575  1
    service_2_31_3  free_load_conservation_1576  1
    service_2_31_4  unique_nonzero_owner_348  1
    service_2_31_4  service_visit_def_1575  1
    service_2_31_4  free_load_conservation_1576  2
    service_2_31_5  unique_nonzero_owner_349  1
    service_2_31_5  service_visit_def_1575  1
    service_2_31_5  free_load_conservation_1576  3
    service_2_31_6  unique_nonzero_owner_350  1
    service_2_31_6  service_visit_def_1575  1
    service_2_31_6  free_load_conservation_1576  4
    service_2_31_7  unique_nonzero_owner_351  1
    service_2_31_7  service_visit_def_1575  1
    service_2_31_7  free_load_conservation_1576  5
    service_2_31_8  unique_nonzero_owner_352  1
    service_2_31_8  service_visit_def_1575  1
    service_2_31_8  free_load_conservation_1576  6
    service_2_31_9  unique_nonzero_owner_353  1
    service_2_31_9  service_visit_def_1575  1
    service_2_31_9  free_load_conservation_1576  7
    service_2_31_10  unique_nonzero_owner_354  1
    service_2_31_10  service_visit_def_1575  1
    service_2_31_10  free_load_conservation_1576  8
    service_2_31_11  unique_nonzero_owner_355  1
    service_2_31_11  service_visit_def_1575  1
    service_2_31_11  free_load_conservation_1576  9
    service_2_31_12  unique_nonzero_owner_356  1
    service_2_31_12  service_visit_def_1575  1
    service_2_31_12  free_load_conservation_1576  10
    service_0_20_0  unique_nonzero_owner_357  1
    service_0_20_0  service_visit_def_890  1
    service_0_20_0  free_load_conservation_891  -9
    service_0_20_0  original_T_including_depot_unload_921  1080
    service_0_20_1  unique_nonzero_owner_358  1
    service_0_20_1  service_visit_def_890  1
    service_0_20_1  free_load_conservation_891  -8
    service_0_20_1  original_T_including_depot_unload_921  960
    service_0_20_2  unique_nonzero_owner_359  1
    service_0_20_2  service_visit_def_890  1
    service_0_20_2  free_load_conservation_891  -7
    service_0_20_2  original_T_including_depot_unload_921  840
    service_0_20_3  unique_nonzero_owner_360  1
    service_0_20_3  service_visit_def_890  1
    service_0_20_3  free_load_conservation_891  -6
    service_0_20_3  original_T_including_depot_unload_921  720
    service_0_20_4  unique_nonzero_owner_361  1
    service_0_20_4  service_visit_def_890  1
    service_0_20_4  free_load_conservation_891  -5
    service_0_20_4  original_T_including_depot_unload_921  600
    service_0_20_5  unique_nonzero_owner_362  1
    service_0_20_5  service_visit_def_890  1
    service_0_20_5  free_load_conservation_891  -4
    service_0_20_5  original_T_including_depot_unload_921  480
    service_0_20_6  unique_nonzero_owner_363  1
    service_0_20_6  service_visit_def_890  1
    service_0_20_6  free_load_conservation_891  -3
    service_0_20_6  original_T_including_depot_unload_921  360
    service_0_20_7  unique_nonzero_owner_364  1
    service_0_20_7  service_visit_def_890  1
    service_0_20_7  free_load_conservation_891  -2
    service_0_20_7  original_T_including_depot_unload_921  240
    service_0_20_8  unique_nonzero_owner_365  1
    service_0_20_8  service_visit_def_890  1
    service_0_20_8  free_load_conservation_891  -1
    service_0_20_8  original_T_including_depot_unload_921  120
    service_0_20_10  unique_nonzero_owner_366  1
    service_0_20_10  service_visit_def_890  1
    service_0_20_10  free_load_conservation_891  1
    service_0_20_11  unique_nonzero_owner_367  1
    service_0_20_11  service_visit_def_890  1
    service_0_20_11  free_load_conservation_891  2
    service_0_20_12  unique_nonzero_owner_368  1
    service_0_20_12  service_visit_def_890  1
    service_0_20_12  free_load_conservation_891  3
    service_1_20_0  unique_nonzero_owner_357  1
    service_1_20_0  service_visit_def_1263  1
    service_1_20_0  free_load_conservation_1264  -9
    service_1_20_0  original_T_including_depot_unload_1292  1080
    service_1_20_1  unique_nonzero_owner_358  1
    service_1_20_1  service_visit_def_1263  1
    service_1_20_1  free_load_conservation_1264  -8
    service_1_20_1  original_T_including_depot_unload_1292  960
    service_1_20_2  unique_nonzero_owner_359  1
    service_1_20_2  service_visit_def_1263  1
    service_1_20_2  free_load_conservation_1264  -7
    service_1_20_2  original_T_including_depot_unload_1292  840
    service_1_20_3  unique_nonzero_owner_360  1
    service_1_20_3  service_visit_def_1263  1
    service_1_20_3  free_load_conservation_1264  -6
    service_1_20_3  original_T_including_depot_unload_1292  720
    service_1_20_4  unique_nonzero_owner_361  1
    service_1_20_4  service_visit_def_1263  1
    service_1_20_4  free_load_conservation_1264  -5
    service_1_20_4  original_T_including_depot_unload_1292  600
    service_1_20_5  unique_nonzero_owner_362  1
    service_1_20_5  service_visit_def_1263  1
    service_1_20_5  free_load_conservation_1264  -4
    service_1_20_5  original_T_including_depot_unload_1292  480
    service_1_20_6  unique_nonzero_owner_363  1
    service_1_20_6  service_visit_def_1263  1
    service_1_20_6  free_load_conservation_1264  -3
    service_1_20_6  original_T_including_depot_unload_1292  360
    service_1_20_7  unique_nonzero_owner_364  1
    service_1_20_7  service_visit_def_1263  1
    service_1_20_7  free_load_conservation_1264  -2
    service_1_20_7  original_T_including_depot_unload_1292  240
    service_1_20_8  unique_nonzero_owner_365  1
    service_1_20_8  service_visit_def_1263  1
    service_1_20_8  free_load_conservation_1264  -1
    service_1_20_8  original_T_including_depot_unload_1292  120
    service_1_20_10  unique_nonzero_owner_366  1
    service_1_20_10  service_visit_def_1263  1
    service_1_20_10  free_load_conservation_1264  1
    service_1_20_11  unique_nonzero_owner_367  1
    service_1_20_11  service_visit_def_1263  1
    service_1_20_11  free_load_conservation_1264  2
    service_1_20_12  unique_nonzero_owner_368  1
    service_1_20_12  service_visit_def_1263  1
    service_1_20_12  free_load_conservation_1264  3
    service_2_20_0  unique_nonzero_owner_357  1
    service_2_20_0  service_visit_def_1581  1
    service_2_20_0  free_load_conservation_1582  -9
    service_2_20_0  original_T_including_depot_unload_1609  1080
    service_2_20_1  unique_nonzero_owner_358  1
    service_2_20_1  service_visit_def_1581  1
    service_2_20_1  free_load_conservation_1582  -8
    service_2_20_1  original_T_including_depot_unload_1609  960
    service_2_20_2  unique_nonzero_owner_359  1
    service_2_20_2  service_visit_def_1581  1
    service_2_20_2  free_load_conservation_1582  -7
    service_2_20_2  original_T_including_depot_unload_1609  840
    service_2_20_3  unique_nonzero_owner_360  1
    service_2_20_3  service_visit_def_1581  1
    service_2_20_3  free_load_conservation_1582  -6
    service_2_20_3  original_T_including_depot_unload_1609  720
    service_2_20_4  unique_nonzero_owner_361  1
    service_2_20_4  service_visit_def_1581  1
    service_2_20_4  free_load_conservation_1582  -5
    service_2_20_4  original_T_including_depot_unload_1609  600
    service_2_20_5  unique_nonzero_owner_362  1
    service_2_20_5  service_visit_def_1581  1
    service_2_20_5  free_load_conservation_1582  -4
    service_2_20_5  original_T_including_depot_unload_1609  480
    service_2_20_6  unique_nonzero_owner_363  1
    service_2_20_6  service_visit_def_1581  1
    service_2_20_6  free_load_conservation_1582  -3
    service_2_20_6  original_T_including_depot_unload_1609  360
    service_2_20_7  unique_nonzero_owner_364  1
    service_2_20_7  service_visit_def_1581  1
    service_2_20_7  free_load_conservation_1582  -2
    service_2_20_7  original_T_including_depot_unload_1609  240
    service_2_20_8  unique_nonzero_owner_365  1
    service_2_20_8  service_visit_def_1581  1
    service_2_20_8  free_load_conservation_1582  -1
    service_2_20_8  original_T_including_depot_unload_1609  120
    service_2_20_10  unique_nonzero_owner_366  1
    service_2_20_10  service_visit_def_1581  1
    service_2_20_10  free_load_conservation_1582  1
    service_2_20_11  unique_nonzero_owner_367  1
    service_2_20_11  service_visit_def_1581  1
    service_2_20_11  free_load_conservation_1582  2
    service_2_20_12  unique_nonzero_owner_368  1
    service_2_20_12  service_visit_def_1581  1
    service_2_20_12  free_load_conservation_1582  3
    service_0_2_1  unique_nonzero_owner_369  1
    service_0_2_1  service_visit_def_896  1
    service_0_2_1  free_load_conservation_897  1
    service_0_2_2  unique_nonzero_owner_370  1
    service_0_2_2  service_visit_def_896  1
    service_0_2_2  free_load_conservation_897  2
    service_0_2_3  unique_nonzero_owner_371  1
    service_0_2_3  service_visit_def_896  1
    service_0_2_3  free_load_conservation_897  3
    service_0_2_4  unique_nonzero_owner_372  1
    service_0_2_4  service_visit_def_896  1
    service_0_2_4  free_load_conservation_897  4
    service_0_2_5  unique_nonzero_owner_373  1
    service_0_2_5  service_visit_def_896  1
    service_0_2_5  free_load_conservation_897  5
    service_0_2_6  unique_nonzero_owner_374  1
    service_0_2_6  service_visit_def_896  1
    service_0_2_6  free_load_conservation_897  6
    service_0_2_7  unique_nonzero_owner_375  1
    service_0_2_7  service_visit_def_896  1
    service_0_2_7  free_load_conservation_897  7
    service_0_2_8  unique_nonzero_owner_376  1
    service_0_2_8  service_visit_def_896  1
    service_0_2_8  free_load_conservation_897  8
    service_0_2_9  unique_nonzero_owner_377  1
    service_0_2_9  service_visit_def_896  1
    service_0_2_9  free_load_conservation_897  9
    service_0_2_10  unique_nonzero_owner_378  1
    service_0_2_10  service_visit_def_896  1
    service_0_2_10  free_load_conservation_897  10
    service_0_2_11  unique_nonzero_owner_379  1
    service_0_2_11  service_visit_def_896  1
    service_0_2_11  free_load_conservation_897  11
    service_0_2_12  unique_nonzero_owner_380  1
    service_0_2_12  service_visit_def_896  1
    service_0_2_12  free_load_conservation_897  12
    service_0_2_13  unique_nonzero_owner_381  1
    service_0_2_13  service_visit_def_896  1
    service_0_2_13  free_load_conservation_897  13
    service_0_2_14  unique_nonzero_owner_382  1
    service_0_2_14  service_visit_def_896  1
    service_0_2_14  free_load_conservation_897  14
    service_0_2_15  unique_nonzero_owner_383  1
    service_0_2_15  service_visit_def_896  1
    service_0_2_15  free_load_conservation_897  15
    service_1_2_1  unique_nonzero_owner_369  1
    service_1_2_1  service_visit_def_1269  1
    service_1_2_1  free_load_conservation_1270  1
    service_1_2_2  unique_nonzero_owner_370  1
    service_1_2_2  service_visit_def_1269  1
    service_1_2_2  free_load_conservation_1270  2
    service_1_2_3  unique_nonzero_owner_371  1
    service_1_2_3  service_visit_def_1269  1
    service_1_2_3  free_load_conservation_1270  3
    service_1_2_4  unique_nonzero_owner_372  1
    service_1_2_4  service_visit_def_1269  1
    service_1_2_4  free_load_conservation_1270  4
    service_1_2_5  unique_nonzero_owner_373  1
    service_1_2_5  service_visit_def_1269  1
    service_1_2_5  free_load_conservation_1270  5
    service_1_2_6  unique_nonzero_owner_374  1
    service_1_2_6  service_visit_def_1269  1
    service_1_2_6  free_load_conservation_1270  6
    service_1_2_7  unique_nonzero_owner_375  1
    service_1_2_7  service_visit_def_1269  1
    service_1_2_7  free_load_conservation_1270  7
    service_1_2_8  unique_nonzero_owner_376  1
    service_1_2_8  service_visit_def_1269  1
    service_1_2_8  free_load_conservation_1270  8
    service_1_2_9  unique_nonzero_owner_377  1
    service_1_2_9  service_visit_def_1269  1
    service_1_2_9  free_load_conservation_1270  9
    service_1_2_10  unique_nonzero_owner_378  1
    service_1_2_10  service_visit_def_1269  1
    service_1_2_10  free_load_conservation_1270  10
    service_1_2_11  unique_nonzero_owner_379  1
    service_1_2_11  service_visit_def_1269  1
    service_1_2_11  free_load_conservation_1270  11
    service_1_2_12  unique_nonzero_owner_380  1
    service_1_2_12  service_visit_def_1269  1
    service_1_2_12  free_load_conservation_1270  12
    service_1_2_13  unique_nonzero_owner_381  1
    service_1_2_13  service_visit_def_1269  1
    service_1_2_13  free_load_conservation_1270  13
    service_1_2_14  unique_nonzero_owner_382  1
    service_1_2_14  service_visit_def_1269  1
    service_1_2_14  free_load_conservation_1270  14
    service_1_2_15  unique_nonzero_owner_383  1
    service_1_2_15  service_visit_def_1269  1
    service_1_2_15  free_load_conservation_1270  15
    service_2_2_1  unique_nonzero_owner_369  1
    service_2_2_1  service_visit_def_1587  1
    service_2_2_1  free_load_conservation_1588  1
    service_2_2_2  unique_nonzero_owner_370  1
    service_2_2_2  service_visit_def_1587  1
    service_2_2_2  free_load_conservation_1588  2
    service_2_2_3  unique_nonzero_owner_371  1
    service_2_2_3  service_visit_def_1587  1
    service_2_2_3  free_load_conservation_1588  3
    service_2_2_4  unique_nonzero_owner_372  1
    service_2_2_4  service_visit_def_1587  1
    service_2_2_4  free_load_conservation_1588  4
    service_2_2_5  unique_nonzero_owner_373  1
    service_2_2_5  service_visit_def_1587  1
    service_2_2_5  free_load_conservation_1588  5
    service_2_2_6  unique_nonzero_owner_374  1
    service_2_2_6  service_visit_def_1587  1
    service_2_2_6  free_load_conservation_1588  6
    service_2_2_7  unique_nonzero_owner_375  1
    service_2_2_7  service_visit_def_1587  1
    service_2_2_7  free_load_conservation_1588  7
    service_2_2_8  unique_nonzero_owner_376  1
    service_2_2_8  service_visit_def_1587  1
    service_2_2_8  free_load_conservation_1588  8
    service_2_2_9  unique_nonzero_owner_377  1
    service_2_2_9  service_visit_def_1587  1
    service_2_2_9  free_load_conservation_1588  9
    service_2_2_10  unique_nonzero_owner_378  1
    service_2_2_10  service_visit_def_1587  1
    service_2_2_10  free_load_conservation_1588  10
    service_2_2_11  unique_nonzero_owner_379  1
    service_2_2_11  service_visit_def_1587  1
    service_2_2_11  free_load_conservation_1588  11
    service_2_2_12  unique_nonzero_owner_380  1
    service_2_2_12  service_visit_def_1587  1
    service_2_2_12  free_load_conservation_1588  12
    service_2_2_13  unique_nonzero_owner_381  1
    service_2_2_13  service_visit_def_1587  1
    service_2_2_13  free_load_conservation_1588  13
    service_2_2_14  unique_nonzero_owner_382  1
    service_2_2_14  service_visit_def_1587  1
    service_2_2_14  free_load_conservation_1588  14
    service_2_2_15  unique_nonzero_owner_383  1
    service_2_2_15  service_visit_def_1587  1
    service_2_2_15  free_load_conservation_1588  15
    service_0_21_0  unique_nonzero_owner_384  1
    service_0_21_0  service_visit_def_902  1
    service_0_21_0  free_load_conservation_903  -1
    service_0_21_0  original_T_including_depot_unload_921  120
    service_0_21_2  unique_nonzero_owner_385  1
    service_0_21_2  service_visit_def_902  1
    service_0_21_2  free_load_conservation_903  1
    service_0_21_3  unique_nonzero_owner_386  1
    service_0_21_3  service_visit_def_902  1
    service_0_21_3  free_load_conservation_903  2
    service_0_21_4  unique_nonzero_owner_387  1
    service_0_21_4  service_visit_def_902  1
    service_0_21_4  free_load_conservation_903  3
    service_0_21_5  unique_nonzero_owner_388  1
    service_0_21_5  service_visit_def_902  1
    service_0_21_5  free_load_conservation_903  4
    service_0_21_6  unique_nonzero_owner_389  1
    service_0_21_6  service_visit_def_902  1
    service_0_21_6  free_load_conservation_903  5
    service_0_21_7  unique_nonzero_owner_390  1
    service_0_21_7  service_visit_def_902  1
    service_0_21_7  free_load_conservation_903  6
    service_0_21_8  unique_nonzero_owner_391  1
    service_0_21_8  service_visit_def_902  1
    service_0_21_8  free_load_conservation_903  7
    service_0_21_9  unique_nonzero_owner_392  1
    service_0_21_9  service_visit_def_902  1
    service_0_21_9  free_load_conservation_903  8
    service_0_21_10  unique_nonzero_owner_393  1
    service_0_21_10  service_visit_def_902  1
    service_0_21_10  free_load_conservation_903  9
    service_0_21_11  unique_nonzero_owner_394  1
    service_0_21_11  service_visit_def_902  1
    service_0_21_11  free_load_conservation_903  10
    service_0_21_12  unique_nonzero_owner_395  1
    service_0_21_12  service_visit_def_902  1
    service_0_21_12  free_load_conservation_903  11
    service_0_21_13  unique_nonzero_owner_396  1
    service_0_21_13  service_visit_def_902  1
    service_0_21_13  free_load_conservation_903  12
    service_0_21_14  unique_nonzero_owner_397  1
    service_0_21_14  service_visit_def_902  1
    service_0_21_14  free_load_conservation_903  13
    service_0_21_15  unique_nonzero_owner_398  1
    service_0_21_15  service_visit_def_902  1
    service_0_21_15  free_load_conservation_903  14
    service_1_21_0  unique_nonzero_owner_384  1
    service_1_21_0  service_visit_def_1275  1
    service_1_21_0  free_load_conservation_1276  -1
    service_1_21_0  original_T_including_depot_unload_1292  120
    service_1_21_2  unique_nonzero_owner_385  1
    service_1_21_2  service_visit_def_1275  1
    service_1_21_2  free_load_conservation_1276  1
    service_1_21_3  unique_nonzero_owner_386  1
    service_1_21_3  service_visit_def_1275  1
    service_1_21_3  free_load_conservation_1276  2
    service_1_21_4  unique_nonzero_owner_387  1
    service_1_21_4  service_visit_def_1275  1
    service_1_21_4  free_load_conservation_1276  3
    service_1_21_5  unique_nonzero_owner_388  1
    service_1_21_5  service_visit_def_1275  1
    service_1_21_5  free_load_conservation_1276  4
    service_1_21_6  unique_nonzero_owner_389  1
    service_1_21_6  service_visit_def_1275  1
    service_1_21_6  free_load_conservation_1276  5
    service_1_21_7  unique_nonzero_owner_390  1
    service_1_21_7  service_visit_def_1275  1
    service_1_21_7  free_load_conservation_1276  6
    service_1_21_8  unique_nonzero_owner_391  1
    service_1_21_8  service_visit_def_1275  1
    service_1_21_8  free_load_conservation_1276  7
    service_1_21_9  unique_nonzero_owner_392  1
    service_1_21_9  service_visit_def_1275  1
    service_1_21_9  free_load_conservation_1276  8
    service_1_21_10  unique_nonzero_owner_393  1
    service_1_21_10  service_visit_def_1275  1
    service_1_21_10  free_load_conservation_1276  9
    service_1_21_11  unique_nonzero_owner_394  1
    service_1_21_11  service_visit_def_1275  1
    service_1_21_11  free_load_conservation_1276  10
    service_1_21_12  unique_nonzero_owner_395  1
    service_1_21_12  service_visit_def_1275  1
    service_1_21_12  free_load_conservation_1276  11
    service_1_21_13  unique_nonzero_owner_396  1
    service_1_21_13  service_visit_def_1275  1
    service_1_21_13  free_load_conservation_1276  12
    service_1_21_14  unique_nonzero_owner_397  1
    service_1_21_14  service_visit_def_1275  1
    service_1_21_14  free_load_conservation_1276  13
    service_1_21_15  unique_nonzero_owner_398  1
    service_1_21_15  service_visit_def_1275  1
    service_1_21_15  free_load_conservation_1276  14
    service_2_21_0  unique_nonzero_owner_384  1
    service_2_21_0  service_visit_def_1593  1
    service_2_21_0  free_load_conservation_1594  -1
    service_2_21_0  original_T_including_depot_unload_1609  120
    service_2_21_2  unique_nonzero_owner_385  1
    service_2_21_2  service_visit_def_1593  1
    service_2_21_2  free_load_conservation_1594  1
    service_2_21_3  unique_nonzero_owner_386  1
    service_2_21_3  service_visit_def_1593  1
    service_2_21_3  free_load_conservation_1594  2
    service_2_21_4  unique_nonzero_owner_387  1
    service_2_21_4  service_visit_def_1593  1
    service_2_21_4  free_load_conservation_1594  3
    service_2_21_5  unique_nonzero_owner_388  1
    service_2_21_5  service_visit_def_1593  1
    service_2_21_5  free_load_conservation_1594  4
    service_2_21_6  unique_nonzero_owner_389  1
    service_2_21_6  service_visit_def_1593  1
    service_2_21_6  free_load_conservation_1594  5
    service_2_21_7  unique_nonzero_owner_390  1
    service_2_21_7  service_visit_def_1593  1
    service_2_21_7  free_load_conservation_1594  6
    service_2_21_8  unique_nonzero_owner_391  1
    service_2_21_8  service_visit_def_1593  1
    service_2_21_8  free_load_conservation_1594  7
    service_2_21_9  unique_nonzero_owner_392  1
    service_2_21_9  service_visit_def_1593  1
    service_2_21_9  free_load_conservation_1594  8
    service_2_21_10  unique_nonzero_owner_393  1
    service_2_21_10  service_visit_def_1593  1
    service_2_21_10  free_load_conservation_1594  9
    service_2_21_11  unique_nonzero_owner_394  1
    service_2_21_11  service_visit_def_1593  1
    service_2_21_11  free_load_conservation_1594  10
    service_2_21_12  unique_nonzero_owner_395  1
    service_2_21_12  service_visit_def_1593  1
    service_2_21_12  free_load_conservation_1594  11
    service_2_21_13  unique_nonzero_owner_396  1
    service_2_21_13  service_visit_def_1593  1
    service_2_21_13  free_load_conservation_1594  12
    service_2_21_14  unique_nonzero_owner_397  1
    service_2_21_14  service_visit_def_1593  1
    service_2_21_14  free_load_conservation_1594  13
    service_2_21_15  unique_nonzero_owner_398  1
    service_2_21_15  service_visit_def_1593  1
    service_2_21_15  free_load_conservation_1594  14
    service_0_12_1  unique_nonzero_owner_399  1
    service_0_12_1  service_visit_def_908  1
    service_0_12_1  free_load_conservation_909  1
    service_0_12_2  unique_nonzero_owner_400  1
    service_0_12_2  service_visit_def_908  1
    service_0_12_2  free_load_conservation_909  2
    service_0_12_3  unique_nonzero_owner_401  1
    service_0_12_3  service_visit_def_908  1
    service_0_12_3  free_load_conservation_909  3
    service_0_12_4  unique_nonzero_owner_402  1
    service_0_12_4  service_visit_def_908  1
    service_0_12_4  free_load_conservation_909  4
    service_0_12_5  unique_nonzero_owner_403  1
    service_0_12_5  service_visit_def_908  1
    service_0_12_5  free_load_conservation_909  5
    service_0_12_6  unique_nonzero_owner_404  1
    service_0_12_6  service_visit_def_908  1
    service_0_12_6  free_load_conservation_909  6
    service_0_12_7  unique_nonzero_owner_405  1
    service_0_12_7  service_visit_def_908  1
    service_0_12_7  free_load_conservation_909  7
    service_0_12_8  unique_nonzero_owner_406  1
    service_0_12_8  service_visit_def_908  1
    service_0_12_8  free_load_conservation_909  8
    service_0_12_9  unique_nonzero_owner_407  1
    service_0_12_9  service_visit_def_908  1
    service_0_12_9  free_load_conservation_909  9
    service_0_12_10  unique_nonzero_owner_408  1
    service_0_12_10  service_visit_def_908  1
    service_0_12_10  free_load_conservation_909  10
    service_0_12_11  unique_nonzero_owner_409  1
    service_0_12_11  service_visit_def_908  1
    service_0_12_11  free_load_conservation_909  11
    service_0_12_12  unique_nonzero_owner_410  1
    service_0_12_12  service_visit_def_908  1
    service_0_12_12  free_load_conservation_909  12
    service_0_12_13  unique_nonzero_owner_411  1
    service_0_12_13  service_visit_def_908  1
    service_0_12_13  free_load_conservation_909  13
    service_0_12_14  unique_nonzero_owner_412  1
    service_0_12_14  service_visit_def_908  1
    service_0_12_14  free_load_conservation_909  14
    service_0_12_15  unique_nonzero_owner_413  1
    service_0_12_15  service_visit_def_908  1
    service_0_12_15  free_load_conservation_909  15
    service_1_12_1  unique_nonzero_owner_399  1
    service_1_12_1  service_visit_def_1281  1
    service_1_12_1  free_load_conservation_1282  1
    service_1_12_2  unique_nonzero_owner_400  1
    service_1_12_2  service_visit_def_1281  1
    service_1_12_2  free_load_conservation_1282  2
    service_1_12_3  unique_nonzero_owner_401  1
    service_1_12_3  service_visit_def_1281  1
    service_1_12_3  free_load_conservation_1282  3
    service_1_12_4  unique_nonzero_owner_402  1
    service_1_12_4  service_visit_def_1281  1
    service_1_12_4  free_load_conservation_1282  4
    service_1_12_5  unique_nonzero_owner_403  1
    service_1_12_5  service_visit_def_1281  1
    service_1_12_5  free_load_conservation_1282  5
    service_1_12_6  unique_nonzero_owner_404  1
    service_1_12_6  service_visit_def_1281  1
    service_1_12_6  free_load_conservation_1282  6
    service_1_12_7  unique_nonzero_owner_405  1
    service_1_12_7  service_visit_def_1281  1
    service_1_12_7  free_load_conservation_1282  7
    service_1_12_8  unique_nonzero_owner_406  1
    service_1_12_8  service_visit_def_1281  1
    service_1_12_8  free_load_conservation_1282  8
    service_1_12_9  unique_nonzero_owner_407  1
    service_1_12_9  service_visit_def_1281  1
    service_1_12_9  free_load_conservation_1282  9
    service_1_12_10  unique_nonzero_owner_408  1
    service_1_12_10  service_visit_def_1281  1
    service_1_12_10  free_load_conservation_1282  10
    service_1_12_11  unique_nonzero_owner_409  1
    service_1_12_11  service_visit_def_1281  1
    service_1_12_11  free_load_conservation_1282  11
    service_1_12_12  unique_nonzero_owner_410  1
    service_1_12_12  service_visit_def_1281  1
    service_1_12_12  free_load_conservation_1282  12
    service_1_12_13  unique_nonzero_owner_411  1
    service_1_12_13  service_visit_def_1281  1
    service_1_12_13  free_load_conservation_1282  13
    service_1_12_14  unique_nonzero_owner_412  1
    service_1_12_14  service_visit_def_1281  1
    service_1_12_14  free_load_conservation_1282  14
    service_1_12_15  unique_nonzero_owner_413  1
    service_1_12_15  service_visit_def_1281  1
    service_1_12_15  free_load_conservation_1282  15
    service_2_12_1  unique_nonzero_owner_399  1
    service_2_12_1  service_visit_def_1599  1
    service_2_12_1  free_load_conservation_1600  1
    service_2_12_2  unique_nonzero_owner_400  1
    service_2_12_2  service_visit_def_1599  1
    service_2_12_2  free_load_conservation_1600  2
    service_2_12_3  unique_nonzero_owner_401  1
    service_2_12_3  service_visit_def_1599  1
    service_2_12_3  free_load_conservation_1600  3
    service_2_12_4  unique_nonzero_owner_402  1
    service_2_12_4  service_visit_def_1599  1
    service_2_12_4  free_load_conservation_1600  4
    service_2_12_5  unique_nonzero_owner_403  1
    service_2_12_5  service_visit_def_1599  1
    service_2_12_5  free_load_conservation_1600  5
    service_2_12_6  unique_nonzero_owner_404  1
    service_2_12_6  service_visit_def_1599  1
    service_2_12_6  free_load_conservation_1600  6
    service_2_12_7  unique_nonzero_owner_405  1
    service_2_12_7  service_visit_def_1599  1
    service_2_12_7  free_load_conservation_1600  7
    service_2_12_8  unique_nonzero_owner_406  1
    service_2_12_8  service_visit_def_1599  1
    service_2_12_8  free_load_conservation_1600  8
    service_2_12_9  unique_nonzero_owner_407  1
    service_2_12_9  service_visit_def_1599  1
    service_2_12_9  free_load_conservation_1600  9
    service_2_12_10  unique_nonzero_owner_408  1
    service_2_12_10  service_visit_def_1599  1
    service_2_12_10  free_load_conservation_1600  10
    service_2_12_11  unique_nonzero_owner_409  1
    service_2_12_11  service_visit_def_1599  1
    service_2_12_11  free_load_conservation_1600  11
    service_2_12_12  unique_nonzero_owner_410  1
    service_2_12_12  service_visit_def_1599  1
    service_2_12_12  free_load_conservation_1600  12
    service_2_12_13  unique_nonzero_owner_411  1
    service_2_12_13  service_visit_def_1599  1
    service_2_12_13  free_load_conservation_1600  13
    service_2_12_14  unique_nonzero_owner_412  1
    service_2_12_14  service_visit_def_1599  1
    service_2_12_14  free_load_conservation_1600  14
    service_2_12_15  unique_nonzero_owner_413  1
    service_2_12_15  service_visit_def_1599  1
    service_2_12_15  free_load_conservation_1600  15
    service_0_7_0  unique_nonzero_owner_414  1
    service_0_7_0  service_visit_def_914  1
    service_0_7_0  free_load_conservation_915  -12
    service_0_7_0  original_T_including_depot_unload_921  1440
    service_0_7_1  unique_nonzero_owner_415  1
    service_0_7_1  service_visit_def_914  1
    service_0_7_1  free_load_conservation_915  -11
    service_0_7_1  original_T_including_depot_unload_921  1320
    service_0_7_2  unique_nonzero_owner_416  1
    service_0_7_2  service_visit_def_914  1
    service_0_7_2  free_load_conservation_915  -10
    service_0_7_2  original_T_including_depot_unload_921  1200
    service_0_7_3  unique_nonzero_owner_417  1
    service_0_7_3  service_visit_def_914  1
    service_0_7_3  free_load_conservation_915  -9
    service_0_7_3  original_T_including_depot_unload_921  1080
    service_0_7_4  unique_nonzero_owner_418  1
    service_0_7_4  service_visit_def_914  1
    service_0_7_4  free_load_conservation_915  -8
    service_0_7_4  original_T_including_depot_unload_921  960
    service_0_7_5  unique_nonzero_owner_419  1
    service_0_7_5  service_visit_def_914  1
    service_0_7_5  free_load_conservation_915  -7
    service_0_7_5  original_T_including_depot_unload_921  840
    service_0_7_6  unique_nonzero_owner_420  1
    service_0_7_6  service_visit_def_914  1
    service_0_7_6  free_load_conservation_915  -6
    service_0_7_6  original_T_including_depot_unload_921  720
    service_0_7_7  unique_nonzero_owner_421  1
    service_0_7_7  service_visit_def_914  1
    service_0_7_7  free_load_conservation_915  -5
    service_0_7_7  original_T_including_depot_unload_921  600
    service_0_7_8  unique_nonzero_owner_422  1
    service_0_7_8  service_visit_def_914  1
    service_0_7_8  free_load_conservation_915  -4
    service_0_7_8  original_T_including_depot_unload_921  480
    service_0_7_9  unique_nonzero_owner_423  1
    service_0_7_9  service_visit_def_914  1
    service_0_7_9  free_load_conservation_915  -3
    service_0_7_9  original_T_including_depot_unload_921  360
    service_0_7_10  unique_nonzero_owner_424  1
    service_0_7_10  service_visit_def_914  1
    service_0_7_10  free_load_conservation_915  -2
    service_0_7_10  original_T_including_depot_unload_921  240
    service_0_7_11  unique_nonzero_owner_425  1
    service_0_7_11  service_visit_def_914  1
    service_0_7_11  free_load_conservation_915  -1
    service_0_7_11  original_T_including_depot_unload_921  120
    service_0_7_13  unique_nonzero_owner_426  1
    service_0_7_13  service_visit_def_914  1
    service_0_7_13  free_load_conservation_915  1
    service_0_7_14  unique_nonzero_owner_427  1
    service_0_7_14  service_visit_def_914  1
    service_0_7_14  free_load_conservation_915  2
    service_0_7_15  unique_nonzero_owner_428  1
    service_0_7_15  service_visit_def_914  1
    service_0_7_15  free_load_conservation_915  3
    service_0_7_16  unique_nonzero_owner_429  1
    service_0_7_16  service_visit_def_914  1
    service_0_7_16  free_load_conservation_915  4
    service_0_7_17  unique_nonzero_owner_430  1
    service_0_7_17  service_visit_def_914  1
    service_0_7_17  free_load_conservation_915  5
    service_1_7_0  unique_nonzero_owner_414  1
    service_1_7_0  service_visit_def_1287  1
    service_1_7_0  free_load_conservation_1288  -12
    service_1_7_0  original_T_including_depot_unload_1292  1440
    service_1_7_1  unique_nonzero_owner_415  1
    service_1_7_1  service_visit_def_1287  1
    service_1_7_1  free_load_conservation_1288  -11
    service_1_7_1  original_T_including_depot_unload_1292  1320
    service_1_7_2  unique_nonzero_owner_416  1
    service_1_7_2  service_visit_def_1287  1
    service_1_7_2  free_load_conservation_1288  -10
    service_1_7_2  original_T_including_depot_unload_1292  1200
    service_1_7_3  unique_nonzero_owner_417  1
    service_1_7_3  service_visit_def_1287  1
    service_1_7_3  free_load_conservation_1288  -9
    service_1_7_3  original_T_including_depot_unload_1292  1080
    service_1_7_4  unique_nonzero_owner_418  1
    service_1_7_4  service_visit_def_1287  1
    service_1_7_4  free_load_conservation_1288  -8
    service_1_7_4  original_T_including_depot_unload_1292  960
    service_1_7_5  unique_nonzero_owner_419  1
    service_1_7_5  service_visit_def_1287  1
    service_1_7_5  free_load_conservation_1288  -7
    service_1_7_5  original_T_including_depot_unload_1292  840
    service_1_7_6  unique_nonzero_owner_420  1
    service_1_7_6  service_visit_def_1287  1
    service_1_7_6  free_load_conservation_1288  -6
    service_1_7_6  original_T_including_depot_unload_1292  720
    service_1_7_7  unique_nonzero_owner_421  1
    service_1_7_7  service_visit_def_1287  1
    service_1_7_7  free_load_conservation_1288  -5
    service_1_7_7  original_T_including_depot_unload_1292  600
    service_1_7_8  unique_nonzero_owner_422  1
    service_1_7_8  service_visit_def_1287  1
    service_1_7_8  free_load_conservation_1288  -4
    service_1_7_8  original_T_including_depot_unload_1292  480
    service_1_7_9  unique_nonzero_owner_423  1
    service_1_7_9  service_visit_def_1287  1
    service_1_7_9  free_load_conservation_1288  -3
    service_1_7_9  original_T_including_depot_unload_1292  360
    service_1_7_10  unique_nonzero_owner_424  1
    service_1_7_10  service_visit_def_1287  1
    service_1_7_10  free_load_conservation_1288  -2
    service_1_7_10  original_T_including_depot_unload_1292  240
    service_1_7_11  unique_nonzero_owner_425  1
    service_1_7_11  service_visit_def_1287  1
    service_1_7_11  free_load_conservation_1288  -1
    service_1_7_11  original_T_including_depot_unload_1292  120
    service_1_7_13  unique_nonzero_owner_426  1
    service_1_7_13  service_visit_def_1287  1
    service_1_7_13  free_load_conservation_1288  1
    service_1_7_14  unique_nonzero_owner_427  1
    service_1_7_14  service_visit_def_1287  1
    service_1_7_14  free_load_conservation_1288  2
    service_1_7_15  unique_nonzero_owner_428  1
    service_1_7_15  service_visit_def_1287  1
    service_1_7_15  free_load_conservation_1288  3
    service_1_7_16  unique_nonzero_owner_429  1
    service_1_7_16  service_visit_def_1287  1
    service_1_7_16  free_load_conservation_1288  4
    service_1_7_17  unique_nonzero_owner_430  1
    service_1_7_17  service_visit_def_1287  1
    service_1_7_17  free_load_conservation_1288  5
    service_2_7_0  unique_nonzero_owner_414  1
    service_2_7_0  service_visit_def_1605  1
    service_2_7_0  free_load_conservation_1606  -12
    service_2_7_0  original_T_including_depot_unload_1609  1440
    service_2_7_1  unique_nonzero_owner_415  1
    service_2_7_1  service_visit_def_1605  1
    service_2_7_1  free_load_conservation_1606  -11
    service_2_7_1  original_T_including_depot_unload_1609  1320
    service_2_7_2  unique_nonzero_owner_416  1
    service_2_7_2  service_visit_def_1605  1
    service_2_7_2  free_load_conservation_1606  -10
    service_2_7_2  original_T_including_depot_unload_1609  1200
    service_2_7_3  unique_nonzero_owner_417  1
    service_2_7_3  service_visit_def_1605  1
    service_2_7_3  free_load_conservation_1606  -9
    service_2_7_3  original_T_including_depot_unload_1609  1080
    service_2_7_4  unique_nonzero_owner_418  1
    service_2_7_4  service_visit_def_1605  1
    service_2_7_4  free_load_conservation_1606  -8
    service_2_7_4  original_T_including_depot_unload_1609  960
    service_2_7_5  unique_nonzero_owner_419  1
    service_2_7_5  service_visit_def_1605  1
    service_2_7_5  free_load_conservation_1606  -7
    service_2_7_5  original_T_including_depot_unload_1609  840
    service_2_7_6  unique_nonzero_owner_420  1
    service_2_7_6  service_visit_def_1605  1
    service_2_7_6  free_load_conservation_1606  -6
    service_2_7_6  original_T_including_depot_unload_1609  720
    service_2_7_7  unique_nonzero_owner_421  1
    service_2_7_7  service_visit_def_1605  1
    service_2_7_7  free_load_conservation_1606  -5
    service_2_7_7  original_T_including_depot_unload_1609  600
    service_2_7_8  unique_nonzero_owner_422  1
    service_2_7_8  service_visit_def_1605  1
    service_2_7_8  free_load_conservation_1606  -4
    service_2_7_8  original_T_including_depot_unload_1609  480
    service_2_7_9  unique_nonzero_owner_423  1
    service_2_7_9  service_visit_def_1605  1
    service_2_7_9  free_load_conservation_1606  -3
    service_2_7_9  original_T_including_depot_unload_1609  360
    service_2_7_10  unique_nonzero_owner_424  1
    service_2_7_10  service_visit_def_1605  1
    service_2_7_10  free_load_conservation_1606  -2
    service_2_7_10  original_T_including_depot_unload_1609  240
    service_2_7_11  unique_nonzero_owner_425  1
    service_2_7_11  service_visit_def_1605  1
    service_2_7_11  free_load_conservation_1606  -1
    service_2_7_11  original_T_including_depot_unload_1609  120
    service_2_7_13  unique_nonzero_owner_426  1
    service_2_7_13  service_visit_def_1605  1
    service_2_7_13  free_load_conservation_1606  1
    service_2_7_14  unique_nonzero_owner_427  1
    service_2_7_14  service_visit_def_1605  1
    service_2_7_14  free_load_conservation_1606  2
    service_2_7_15  unique_nonzero_owner_428  1
    service_2_7_15  service_visit_def_1605  1
    service_2_7_15  free_load_conservation_1606  3
    service_2_7_16  unique_nonzero_owner_429  1
    service_2_7_16  service_visit_def_1605  1
    service_2_7_16  free_load_conservation_1606  4
    service_2_7_17  unique_nonzero_owner_430  1
    service_2_7_17  service_visit_def_1605  1
    service_2_7_17  free_load_conservation_1606  5
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_826  -1
    visit_0_1  in_degree_827  -1
    visit_0_1  order_active_lb_828  -1
    visit_0_1  order_active_ub_829  -14
    order_0_1  connected_order_arc_448  -1
    order_0_1  connected_order_arc_450  -1
    order_0_1  connected_order_arc_452  -1
    order_0_1  connected_order_arc_454  -1
    order_0_1  connected_order_arc_456  -1
    order_0_1  connected_order_arc_458  -1
    order_0_1  connected_order_arc_460  -1
    order_0_1  connected_order_arc_462  -1
    order_0_1  connected_order_arc_464  -1
    order_0_1  connected_order_arc_466  -1
    order_0_1  connected_order_arc_468  -1
    order_0_1  connected_order_arc_470  -1
    order_0_1  connected_order_arc_472  -1
    order_0_1  connected_order_arc_475  1
    order_0_1  connected_order_arc_502  1
    order_0_1  connected_order_arc_529  1
    order_0_1  connected_order_arc_556  1
    order_0_1  connected_order_arc_583  1
    order_0_1  connected_order_arc_610  1
    order_0_1  connected_order_arc_637  1
    order_0_1  connected_order_arc_664  1
    order_0_1  connected_order_arc_691  1
    order_0_1  connected_order_arc_718  1
    order_0_1  connected_order_arc_745  1
    order_0_1  connected_order_arc_772  1
    order_0_1  connected_order_arc_799  1
    order_0_1  order_active_lb_828  1
    order_0_1  order_active_ub_829  1
    order_0_1  fixed_segment_relative_order_916  -1
    visit_0_2  out_degree_833  -1
    visit_0_2  in_degree_834  -1
    visit_0_2  order_active_lb_835  -1
    visit_0_2  order_active_ub_836  -14
    order_0_2  connected_order_arc_448  1
    order_0_2  connected_order_arc_475  -1
    order_0_2  connected_order_arc_477  -1
    order_0_2  connected_order_arc_479  -1
    order_0_2  connected_order_arc_481  -1
    order_0_2  connected_order_arc_483  -1
    order_0_2  connected_order_arc_485  -1
    order_0_2  connected_order_arc_487  -1
    order_0_2  connected_order_arc_489  -1
    order_0_2  connected_order_arc_491  -1
    order_0_2  connected_order_arc_493  -1
    order_0_2  connected_order_arc_495  -1
    order_0_2  connected_order_arc_497  -1
    order_0_2  connected_order_arc_499  -1
    order_0_2  connected_order_arc_504  1
    order_0_2  connected_order_arc_531  1
    order_0_2  connected_order_arc_558  1
    order_0_2  connected_order_arc_585  1
    order_0_2  connected_order_arc_612  1
    order_0_2  connected_order_arc_639  1
    order_0_2  connected_order_arc_666  1
    order_0_2  connected_order_arc_693  1
    order_0_2  connected_order_arc_720  1
    order_0_2  connected_order_arc_747  1
    order_0_2  connected_order_arc_774  1
    order_0_2  connected_order_arc_801  1
    order_0_2  order_active_lb_835  1
    order_0_2  order_active_ub_836  1
    order_0_2  fixed_segment_relative_order_916  1
    order_0_2  fixed_segment_relative_order_917  -1
    visit_0_3  out_degree_840  -1
    visit_0_3  in_degree_841  -1
    visit_0_3  order_active_lb_842  -1
    visit_0_3  order_active_ub_843  -14
    order_0_3  connected_order_arc_450  1
    order_0_3  connected_order_arc_477  1
    order_0_3  connected_order_arc_502  -1
    order_0_3  connected_order_arc_504  -1
    order_0_3  connected_order_arc_506  -1
    order_0_3  connected_order_arc_508  -1
    order_0_3  connected_order_arc_510  -1
    order_0_3  connected_order_arc_512  -1
    order_0_3  connected_order_arc_514  -1
    order_0_3  connected_order_arc_516  -1
    order_0_3  connected_order_arc_518  -1
    order_0_3  connected_order_arc_520  -1
    order_0_3  connected_order_arc_522  -1
    order_0_3  connected_order_arc_524  -1
    order_0_3  connected_order_arc_526  -1
    order_0_3  connected_order_arc_533  1
    order_0_3  connected_order_arc_560  1
    order_0_3  connected_order_arc_587  1
    order_0_3  connected_order_arc_614  1
    order_0_3  connected_order_arc_641  1
    order_0_3  connected_order_arc_668  1
    order_0_3  connected_order_arc_695  1
    order_0_3  connected_order_arc_722  1
    order_0_3  connected_order_arc_749  1
    order_0_3  connected_order_arc_776  1
    order_0_3  connected_order_arc_803  1
    order_0_3  order_active_lb_842  1
    order_0_3  order_active_ub_843  1
    order_0_3  fixed_segment_relative_order_917  1
    order_0_3  fixed_segment_relative_order_918  -1
    visit_0_4  out_degree_847  -1
    visit_0_4  in_degree_848  -1
    visit_0_4  order_active_lb_849  -1
    visit_0_4  order_active_ub_850  -14
    order_0_4  connected_order_arc_452  1
    order_0_4  connected_order_arc_479  1
    order_0_4  connected_order_arc_506  1
    order_0_4  connected_order_arc_529  -1
    order_0_4  connected_order_arc_531  -1
    order_0_4  connected_order_arc_533  -1
    order_0_4  connected_order_arc_535  -1
    order_0_4  connected_order_arc_537  -1
    order_0_4  connected_order_arc_539  -1
    order_0_4  connected_order_arc_541  -1
    order_0_4  connected_order_arc_543  -1
    order_0_4  connected_order_arc_545  -1
    order_0_4  connected_order_arc_547  -1
    order_0_4  connected_order_arc_549  -1
    order_0_4  connected_order_arc_551  -1
    order_0_4  connected_order_arc_553  -1
    order_0_4  connected_order_arc_562  1
    order_0_4  connected_order_arc_589  1
    order_0_4  connected_order_arc_616  1
    order_0_4  connected_order_arc_643  1
    order_0_4  connected_order_arc_670  1
    order_0_4  connected_order_arc_697  1
    order_0_4  connected_order_arc_724  1
    order_0_4  connected_order_arc_751  1
    order_0_4  connected_order_arc_778  1
    order_0_4  connected_order_arc_805  1
    order_0_4  order_active_lb_849  1
    order_0_4  order_active_ub_850  1
    order_0_4  fixed_segment_relative_order_918  1
    order_0_4  fixed_segment_relative_order_919  -1
    visit_0_5  out_degree_854  -1
    visit_0_5  in_degree_855  -1
    visit_0_5  order_active_lb_856  -1
    visit_0_5  order_active_ub_857  -14
    order_0_5  connected_order_arc_454  1
    order_0_5  connected_order_arc_481  1
    order_0_5  connected_order_arc_508  1
    order_0_5  connected_order_arc_535  1
    order_0_5  connected_order_arc_556  -1
    order_0_5  connected_order_arc_558  -1
    order_0_5  connected_order_arc_560  -1
    order_0_5  connected_order_arc_562  -1
    order_0_5  connected_order_arc_564  -1
    order_0_5  connected_order_arc_566  -1
    order_0_5  connected_order_arc_568  -1
    order_0_5  connected_order_arc_570  -1
    order_0_5  connected_order_arc_572  -1
    order_0_5  connected_order_arc_574  -1
    order_0_5  connected_order_arc_576  -1
    order_0_5  connected_order_arc_578  -1
    order_0_5  connected_order_arc_580  -1
    order_0_5  connected_order_arc_591  1
    order_0_5  connected_order_arc_618  1
    order_0_5  connected_order_arc_645  1
    order_0_5  connected_order_arc_672  1
    order_0_5  connected_order_arc_699  1
    order_0_5  connected_order_arc_726  1
    order_0_5  connected_order_arc_753  1
    order_0_5  connected_order_arc_780  1
    order_0_5  connected_order_arc_807  1
    order_0_5  order_active_lb_856  1
    order_0_5  order_active_ub_857  1
    order_0_5  fixed_segment_relative_order_919  1
    order_0_5  fixed_segment_relative_order_920  -1
    visit_0_6  out_degree_861  -1
    visit_0_6  in_degree_862  -1
    visit_0_6  order_active_lb_863  -1
    visit_0_6  order_active_ub_864  -14
    order_0_6  connected_order_arc_456  1
    order_0_6  connected_order_arc_483  1
    order_0_6  connected_order_arc_510  1
    order_0_6  connected_order_arc_537  1
    order_0_6  connected_order_arc_564  1
    order_0_6  connected_order_arc_583  -1
    order_0_6  connected_order_arc_585  -1
    order_0_6  connected_order_arc_587  -1
    order_0_6  connected_order_arc_589  -1
    order_0_6  connected_order_arc_591  -1
    order_0_6  connected_order_arc_593  -1
    order_0_6  connected_order_arc_595  -1
    order_0_6  connected_order_arc_597  -1
    order_0_6  connected_order_arc_599  -1
    order_0_6  connected_order_arc_601  -1
    order_0_6  connected_order_arc_603  -1
    order_0_6  connected_order_arc_605  -1
    order_0_6  connected_order_arc_607  -1
    order_0_6  connected_order_arc_620  1
    order_0_6  connected_order_arc_647  1
    order_0_6  connected_order_arc_674  1
    order_0_6  connected_order_arc_701  1
    order_0_6  connected_order_arc_728  1
    order_0_6  connected_order_arc_755  1
    order_0_6  connected_order_arc_782  1
    order_0_6  connected_order_arc_809  1
    order_0_6  order_active_lb_863  1
    order_0_6  order_active_ub_864  1
    order_0_6  fixed_segment_relative_order_920  1
    visit_0_14  out_degree_868  -1
    visit_0_14  in_degree_869  -1
    visit_0_14  order_active_lb_870  -1
    visit_0_14  order_active_ub_871  -14
    visit_0_14  service_visit_def_872  -1
    order_0_14  connected_order_arc_458  1
    order_0_14  connected_order_arc_485  1
    order_0_14  connected_order_arc_512  1
    order_0_14  connected_order_arc_539  1
    order_0_14  connected_order_arc_566  1
    order_0_14  connected_order_arc_593  1
    order_0_14  connected_order_arc_610  -1
    order_0_14  connected_order_arc_612  -1
    order_0_14  connected_order_arc_614  -1
    order_0_14  connected_order_arc_616  -1
    order_0_14  connected_order_arc_618  -1
    order_0_14  connected_order_arc_620  -1
    order_0_14  connected_order_arc_622  -1
    order_0_14  connected_order_arc_624  -1
    order_0_14  connected_order_arc_626  -1
    order_0_14  connected_order_arc_628  -1
    order_0_14  connected_order_arc_630  -1
    order_0_14  connected_order_arc_632  -1
    order_0_14  connected_order_arc_634  -1
    order_0_14  connected_order_arc_649  1
    order_0_14  connected_order_arc_676  1
    order_0_14  connected_order_arc_703  1
    order_0_14  connected_order_arc_730  1
    order_0_14  connected_order_arc_757  1
    order_0_14  connected_order_arc_784  1
    order_0_14  connected_order_arc_811  1
    order_0_14  order_active_lb_870  1
    order_0_14  order_active_ub_871  1
    visit_0_15  out_degree_874  -1
    visit_0_15  in_degree_875  -1
    visit_0_15  order_active_lb_876  -1
    visit_0_15  order_active_ub_877  -14
    visit_0_15  service_visit_def_878  -1
    order_0_15  connected_order_arc_460  1
    order_0_15  connected_order_arc_487  1
    order_0_15  connected_order_arc_514  1
    order_0_15  connected_order_arc_541  1
    order_0_15  connected_order_arc_568  1
    order_0_15  connected_order_arc_595  1
    order_0_15  connected_order_arc_622  1
    order_0_15  connected_order_arc_637  -1
    order_0_15  connected_order_arc_639  -1
    order_0_15  connected_order_arc_641  -1
    order_0_15  connected_order_arc_643  -1
    order_0_15  connected_order_arc_645  -1
    order_0_15  connected_order_arc_647  -1
    order_0_15  connected_order_arc_649  -1
    order_0_15  connected_order_arc_651  -1
    order_0_15  connected_order_arc_653  -1
    order_0_15  connected_order_arc_655  -1
    order_0_15  connected_order_arc_657  -1
    order_0_15  connected_order_arc_659  -1
    order_0_15  connected_order_arc_661  -1
    order_0_15  connected_order_arc_678  1
    order_0_15  connected_order_arc_705  1
    order_0_15  connected_order_arc_732  1
    order_0_15  connected_order_arc_759  1
    order_0_15  connected_order_arc_786  1
    order_0_15  connected_order_arc_813  1
    order_0_15  order_active_lb_876  1
    order_0_15  order_active_ub_877  1
    visit_0_16  out_degree_880  -1
    visit_0_16  in_degree_881  -1
    visit_0_16  order_active_lb_882  -1
    visit_0_16  order_active_ub_883  -14
    visit_0_16  service_visit_def_884  -1
    order_0_16  connected_order_arc_462  1
    order_0_16  connected_order_arc_489  1
    order_0_16  connected_order_arc_516  1
    order_0_16  connected_order_arc_543  1
    order_0_16  connected_order_arc_570  1
    order_0_16  connected_order_arc_597  1
    order_0_16  connected_order_arc_624  1
    order_0_16  connected_order_arc_651  1
    order_0_16  connected_order_arc_664  -1
    order_0_16  connected_order_arc_666  -1
    order_0_16  connected_order_arc_668  -1
    order_0_16  connected_order_arc_670  -1
    order_0_16  connected_order_arc_672  -1
    order_0_16  connected_order_arc_674  -1
    order_0_16  connected_order_arc_676  -1
    order_0_16  connected_order_arc_678  -1
    order_0_16  connected_order_arc_680  -1
    order_0_16  connected_order_arc_682  -1
    order_0_16  connected_order_arc_684  -1
    order_0_16  connected_order_arc_686  -1
    order_0_16  connected_order_arc_688  -1
    order_0_16  connected_order_arc_707  1
    order_0_16  connected_order_arc_734  1
    order_0_16  connected_order_arc_761  1
    order_0_16  connected_order_arc_788  1
    order_0_16  connected_order_arc_815  1
    order_0_16  order_active_lb_882  1
    order_0_16  order_active_ub_883  1
    visit_0_17  out_degree_886  -1
    visit_0_17  in_degree_887  -1
    visit_0_17  order_active_lb_888  -1
    visit_0_17  order_active_ub_889  -14
    visit_0_17  service_visit_def_890  -1
    order_0_17  connected_order_arc_464  1
    order_0_17  connected_order_arc_491  1
    order_0_17  connected_order_arc_518  1
    order_0_17  connected_order_arc_545  1
    order_0_17  connected_order_arc_572  1
    order_0_17  connected_order_arc_599  1
    order_0_17  connected_order_arc_626  1
    order_0_17  connected_order_arc_653  1
    order_0_17  connected_order_arc_680  1
    order_0_17  connected_order_arc_691  -1
    order_0_17  connected_order_arc_693  -1
    order_0_17  connected_order_arc_695  -1
    order_0_17  connected_order_arc_697  -1
    order_0_17  connected_order_arc_699  -1
    order_0_17  connected_order_arc_701  -1
    order_0_17  connected_order_arc_703  -1
    order_0_17  connected_order_arc_705  -1
    order_0_17  connected_order_arc_707  -1
    order_0_17  connected_order_arc_709  -1
    order_0_17  connected_order_arc_711  -1
    order_0_17  connected_order_arc_713  -1
    order_0_17  connected_order_arc_715  -1
    order_0_17  connected_order_arc_736  1
    order_0_17  connected_order_arc_763  1
    order_0_17  connected_order_arc_790  1
    order_0_17  connected_order_arc_817  1
    order_0_17  order_active_lb_888  1
    order_0_17  order_active_ub_889  1
    visit_0_18  out_degree_892  -1
    visit_0_18  in_degree_893  -1
    visit_0_18  order_active_lb_894  -1
    visit_0_18  order_active_ub_895  -14
    visit_0_18  service_visit_def_896  -1
    order_0_18  connected_order_arc_466  1
    order_0_18  connected_order_arc_493  1
    order_0_18  connected_order_arc_520  1
    order_0_18  connected_order_arc_547  1
    order_0_18  connected_order_arc_574  1
    order_0_18  connected_order_arc_601  1
    order_0_18  connected_order_arc_628  1
    order_0_18  connected_order_arc_655  1
    order_0_18  connected_order_arc_682  1
    order_0_18  connected_order_arc_709  1
    order_0_18  connected_order_arc_718  -1
    order_0_18  connected_order_arc_720  -1
    order_0_18  connected_order_arc_722  -1
    order_0_18  connected_order_arc_724  -1
    order_0_18  connected_order_arc_726  -1
    order_0_18  connected_order_arc_728  -1
    order_0_18  connected_order_arc_730  -1
    order_0_18  connected_order_arc_732  -1
    order_0_18  connected_order_arc_734  -1
    order_0_18  connected_order_arc_736  -1
    order_0_18  connected_order_arc_738  -1
    order_0_18  connected_order_arc_740  -1
    order_0_18  connected_order_arc_742  -1
    order_0_18  connected_order_arc_765  1
    order_0_18  connected_order_arc_792  1
    order_0_18  connected_order_arc_819  1
    order_0_18  order_active_lb_894  1
    order_0_18  order_active_ub_895  1
    visit_0_19  out_degree_898  -1
    visit_0_19  in_degree_899  -1
    visit_0_19  order_active_lb_900  -1
    visit_0_19  order_active_ub_901  -14
    visit_0_19  service_visit_def_902  -1
    order_0_19  connected_order_arc_468  1
    order_0_19  connected_order_arc_495  1
    order_0_19  connected_order_arc_522  1
    order_0_19  connected_order_arc_549  1
    order_0_19  connected_order_arc_576  1
    order_0_19  connected_order_arc_603  1
    order_0_19  connected_order_arc_630  1
    order_0_19  connected_order_arc_657  1
    order_0_19  connected_order_arc_684  1
    order_0_19  connected_order_arc_711  1
    order_0_19  connected_order_arc_738  1
    order_0_19  connected_order_arc_745  -1
    order_0_19  connected_order_arc_747  -1
    order_0_19  connected_order_arc_749  -1
    order_0_19  connected_order_arc_751  -1
    order_0_19  connected_order_arc_753  -1
    order_0_19  connected_order_arc_755  -1
    order_0_19  connected_order_arc_757  -1
    order_0_19  connected_order_arc_759  -1
    order_0_19  connected_order_arc_761  -1
    order_0_19  connected_order_arc_763  -1
    order_0_19  connected_order_arc_765  -1
    order_0_19  connected_order_arc_767  -1
    order_0_19  connected_order_arc_769  -1
    order_0_19  connected_order_arc_794  1
    order_0_19  connected_order_arc_821  1
    order_0_19  order_active_lb_900  1
    order_0_19  order_active_ub_901  1
    visit_0_20  out_degree_904  -1
    visit_0_20  in_degree_905  -1
    visit_0_20  order_active_lb_906  -1
    visit_0_20  order_active_ub_907  -14
    visit_0_20  service_visit_def_908  -1
    order_0_20  connected_order_arc_470  1
    order_0_20  connected_order_arc_497  1
    order_0_20  connected_order_arc_524  1
    order_0_20  connected_order_arc_551  1
    order_0_20  connected_order_arc_578  1
    order_0_20  connected_order_arc_605  1
    order_0_20  connected_order_arc_632  1
    order_0_20  connected_order_arc_659  1
    order_0_20  connected_order_arc_686  1
    order_0_20  connected_order_arc_713  1
    order_0_20  connected_order_arc_740  1
    order_0_20  connected_order_arc_767  1
    order_0_20  connected_order_arc_772  -1
    order_0_20  connected_order_arc_774  -1
    order_0_20  connected_order_arc_776  -1
    order_0_20  connected_order_arc_778  -1
    order_0_20  connected_order_arc_780  -1
    order_0_20  connected_order_arc_782  -1
    order_0_20  connected_order_arc_784  -1
    order_0_20  connected_order_arc_786  -1
    order_0_20  connected_order_arc_788  -1
    order_0_20  connected_order_arc_790  -1
    order_0_20  connected_order_arc_792  -1
    order_0_20  connected_order_arc_794  -1
    order_0_20  connected_order_arc_796  -1
    order_0_20  connected_order_arc_823  1
    order_0_20  order_active_lb_906  1
    order_0_20  order_active_ub_907  1
    visit_0_21  out_degree_910  -1
    visit_0_21  in_degree_911  -1
    visit_0_21  order_active_lb_912  -1
    visit_0_21  order_active_ub_913  -14
    visit_0_21  service_visit_def_914  -1
    order_0_21  connected_order_arc_472  1
    order_0_21  connected_order_arc_499  1
    order_0_21  connected_order_arc_526  1
    order_0_21  connected_order_arc_553  1
    order_0_21  connected_order_arc_580  1
    order_0_21  connected_order_arc_607  1
    order_0_21  connected_order_arc_634  1
    order_0_21  connected_order_arc_661  1
    order_0_21  connected_order_arc_688  1
    order_0_21  connected_order_arc_715  1
    order_0_21  connected_order_arc_742  1
    order_0_21  connected_order_arc_769  1
    order_0_21  connected_order_arc_796  1
    order_0_21  connected_order_arc_799  -1
    order_0_21  connected_order_arc_801  -1
    order_0_21  connected_order_arc_803  -1
    order_0_21  connected_order_arc_805  -1
    order_0_21  connected_order_arc_807  -1
    order_0_21  connected_order_arc_809  -1
    order_0_21  connected_order_arc_811  -1
    order_0_21  connected_order_arc_813  -1
    order_0_21  connected_order_arc_815  -1
    order_0_21  connected_order_arc_817  -1
    order_0_21  connected_order_arc_819  -1
    order_0_21  connected_order_arc_821  -1
    order_0_21  connected_order_arc_823  -1
    order_0_21  order_active_lb_912  1
    order_0_21  order_active_ub_913  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_431  -20
    arc_0_0_0  depot_departure_or_bypass_824  1
    arc_0_0_0  depot_return_or_bypass_825  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_431  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_432  -20
    arc_0_0_1  depot_departure_or_bypass_824  1
    arc_0_0_1  in_degree_827  1
    arc_0_0_1  original_T_including_depot_unload_921  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_432  1
    load_0_0_1  segment_load_conservation_830  -1
    load_0_0_1  segment_prefix_lb_831  1
    load_0_0_1  segment_prefix_ub_832  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_433  -20
    arc_0_0_2  depot_departure_or_bypass_824  1
    arc_0_0_2  in_degree_834  1
    arc_0_0_2  original_T_including_depot_unload_921  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_433  1
    load_0_0_2  segment_load_conservation_837  -1
    load_0_0_2  segment_prefix_lb_838  1
    load_0_0_2  segment_prefix_ub_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_434  -20
    arc_0_0_3  depot_departure_or_bypass_824  1
    arc_0_0_3  in_degree_841  1
    arc_0_0_3  original_T_including_depot_unload_921  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_434  1
    load_0_0_3  segment_load_conservation_844  -1
    load_0_0_3  segment_prefix_lb_845  1
    load_0_0_3  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_435  -20
    arc_0_0_4  depot_departure_or_bypass_824  1
    arc_0_0_4  in_degree_848  1
    arc_0_0_4  original_T_including_depot_unload_921  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_435  1
    load_0_0_4  segment_load_conservation_851  -1
    load_0_0_4  segment_prefix_lb_852  1
    load_0_0_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_436  -20
    arc_0_0_5  depot_departure_or_bypass_824  1
    arc_0_0_5  in_degree_855  1
    arc_0_0_5  original_T_including_depot_unload_921  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_436  1
    load_0_0_5  segment_load_conservation_858  -1
    load_0_0_5  segment_prefix_lb_859  1
    load_0_0_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_437  -20
    arc_0_0_6  depot_departure_or_bypass_824  1
    arc_0_0_6  in_degree_862  1
    arc_0_0_6  original_T_including_depot_unload_921  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_437  1
    load_0_0_6  segment_load_conservation_865  -1
    load_0_0_6  segment_prefix_lb_866  1
    load_0_0_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_438  -20
    arc_0_0_14  depot_departure_or_bypass_824  1
    arc_0_0_14  in_degree_869  1
    arc_0_0_14  original_T_including_depot_unload_921  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_438  1
    load_0_0_14  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_439  -20
    arc_0_0_15  depot_departure_or_bypass_824  1
    arc_0_0_15  in_degree_875  1
    arc_0_0_15  original_T_including_depot_unload_921  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_439  1
    load_0_0_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_440  -20
    arc_0_0_16  depot_departure_or_bypass_824  1
    arc_0_0_16  in_degree_881  1
    arc_0_0_16  original_T_including_depot_unload_921  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_440  1
    load_0_0_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_441  -20
    arc_0_0_17  depot_departure_or_bypass_824  1
    arc_0_0_17  in_degree_887  1
    arc_0_0_17  original_T_including_depot_unload_921  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_441  1
    load_0_0_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_442  -20
    arc_0_0_18  depot_departure_or_bypass_824  1
    arc_0_0_18  in_degree_893  1
    arc_0_0_18  original_T_including_depot_unload_921  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_442  1
    load_0_0_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_443  -20
    arc_0_0_19  depot_departure_or_bypass_824  1
    arc_0_0_19  in_degree_899  1
    arc_0_0_19  original_T_including_depot_unload_921  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_443  1
    load_0_0_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_444  -20
    arc_0_0_20  depot_departure_or_bypass_824  1
    arc_0_0_20  in_degree_905  1
    arc_0_0_20  original_T_including_depot_unload_921  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_444  1
    load_0_0_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_445  -20
    arc_0_0_21  depot_departure_or_bypass_824  1
    arc_0_0_21  in_degree_911  1
    arc_0_0_21  original_T_including_depot_unload_921  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_445  1
    load_0_0_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_446  -20
    arc_0_1_0  depot_return_or_bypass_825  1
    arc_0_1_0  out_degree_826  1
    arc_0_1_0  original_T_including_depot_unload_921  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_446  1
    load_0_1_0  segment_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_447  -20
    arc_0_1_2  connected_order_arc_448  -15
    arc_0_1_2  out_degree_826  1
    arc_0_1_2  in_degree_834  1
    arc_0_1_2  original_T_including_depot_unload_921  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_447  1
    load_0_1_2  segment_load_conservation_830  1
    load_0_1_2  segment_load_conservation_837  -1
    load_0_1_2  segment_prefix_lb_838  1
    load_0_1_2  segment_prefix_ub_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_449  -20
    arc_0_1_3  connected_order_arc_450  -15
    arc_0_1_3  out_degree_826  1
    arc_0_1_3  in_degree_841  1
    arc_0_1_3  original_T_including_depot_unload_921  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_449  1
    load_0_1_3  segment_load_conservation_830  1
    load_0_1_3  segment_load_conservation_844  -1
    load_0_1_3  segment_prefix_lb_845  1
    load_0_1_3  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_451  -20
    arc_0_1_4  connected_order_arc_452  -15
    arc_0_1_4  out_degree_826  1
    arc_0_1_4  in_degree_848  1
    arc_0_1_4  original_T_including_depot_unload_921  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_451  1
    load_0_1_4  segment_load_conservation_830  1
    load_0_1_4  segment_load_conservation_851  -1
    load_0_1_4  segment_prefix_lb_852  1
    load_0_1_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_453  -20
    arc_0_1_5  connected_order_arc_454  -15
    arc_0_1_5  out_degree_826  1
    arc_0_1_5  in_degree_855  1
    arc_0_1_5  original_T_including_depot_unload_921  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_453  1
    load_0_1_5  segment_load_conservation_830  1
    load_0_1_5  segment_load_conservation_858  -1
    load_0_1_5  segment_prefix_lb_859  1
    load_0_1_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_455  -20
    arc_0_1_6  connected_order_arc_456  -15
    arc_0_1_6  out_degree_826  1
    arc_0_1_6  in_degree_862  1
    arc_0_1_6  original_T_including_depot_unload_921  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_455  1
    load_0_1_6  segment_load_conservation_830  1
    load_0_1_6  segment_load_conservation_865  -1
    load_0_1_6  segment_prefix_lb_866  1
    load_0_1_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_457  -20
    arc_0_1_14  connected_order_arc_458  -15
    arc_0_1_14  out_degree_826  1
    arc_0_1_14  in_degree_869  1
    arc_0_1_14  original_T_including_depot_unload_921  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_457  1
    load_0_1_14  segment_load_conservation_830  1
    load_0_1_14  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_459  -20
    arc_0_1_15  connected_order_arc_460  -15
    arc_0_1_15  out_degree_826  1
    arc_0_1_15  in_degree_875  1
    arc_0_1_15  original_T_including_depot_unload_921  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_459  1
    load_0_1_15  segment_load_conservation_830  1
    load_0_1_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_461  -20
    arc_0_1_16  connected_order_arc_462  -15
    arc_0_1_16  out_degree_826  1
    arc_0_1_16  in_degree_881  1
    arc_0_1_16  original_T_including_depot_unload_921  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_461  1
    load_0_1_16  segment_load_conservation_830  1
    load_0_1_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_463  -20
    arc_0_1_17  connected_order_arc_464  -15
    arc_0_1_17  out_degree_826  1
    arc_0_1_17  in_degree_887  1
    arc_0_1_17  original_T_including_depot_unload_921  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_463  1
    load_0_1_17  segment_load_conservation_830  1
    load_0_1_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_465  -20
    arc_0_1_18  connected_order_arc_466  -15
    arc_0_1_18  out_degree_826  1
    arc_0_1_18  in_degree_893  1
    arc_0_1_18  original_T_including_depot_unload_921  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_465  1
    load_0_1_18  segment_load_conservation_830  1
    load_0_1_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_467  -20
    arc_0_1_19  connected_order_arc_468  -15
    arc_0_1_19  out_degree_826  1
    arc_0_1_19  in_degree_899  1
    arc_0_1_19  original_T_including_depot_unload_921  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_467  1
    load_0_1_19  segment_load_conservation_830  1
    load_0_1_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_469  -20
    arc_0_1_20  connected_order_arc_470  -15
    arc_0_1_20  out_degree_826  1
    arc_0_1_20  in_degree_905  1
    arc_0_1_20  original_T_including_depot_unload_921  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_469  1
    load_0_1_20  segment_load_conservation_830  1
    load_0_1_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_471  -20
    arc_0_1_21  connected_order_arc_472  -15
    arc_0_1_21  out_degree_826  1
    arc_0_1_21  in_degree_911  1
    arc_0_1_21  original_T_including_depot_unload_921  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_471  1
    load_0_1_21  segment_load_conservation_830  1
    load_0_1_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_473  -20
    arc_0_2_0  depot_return_or_bypass_825  1
    arc_0_2_0  out_degree_833  1
    arc_0_2_0  original_T_including_depot_unload_921  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_473  1
    load_0_2_0  segment_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_474  -20
    arc_0_2_1  connected_order_arc_475  -15
    arc_0_2_1  in_degree_827  1
    arc_0_2_1  out_degree_833  1
    arc_0_2_1  original_T_including_depot_unload_921  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_474  1
    load_0_2_1  segment_load_conservation_830  -1
    load_0_2_1  segment_prefix_lb_831  1
    load_0_2_1  segment_prefix_ub_832  1
    load_0_2_1  segment_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_476  -20
    arc_0_2_3  connected_order_arc_477  -15
    arc_0_2_3  out_degree_833  1
    arc_0_2_3  in_degree_841  1
    arc_0_2_3  original_T_including_depot_unload_921  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_476  1
    load_0_2_3  segment_load_conservation_837  1
    load_0_2_3  segment_load_conservation_844  -1
    load_0_2_3  segment_prefix_lb_845  1
    load_0_2_3  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_478  -20
    arc_0_2_4  connected_order_arc_479  -15
    arc_0_2_4  out_degree_833  1
    arc_0_2_4  in_degree_848  1
    arc_0_2_4  original_T_including_depot_unload_921  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_478  1
    load_0_2_4  segment_load_conservation_837  1
    load_0_2_4  segment_load_conservation_851  -1
    load_0_2_4  segment_prefix_lb_852  1
    load_0_2_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_480  -20
    arc_0_2_5  connected_order_arc_481  -15
    arc_0_2_5  out_degree_833  1
    arc_0_2_5  in_degree_855  1
    arc_0_2_5  original_T_including_depot_unload_921  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_480  1
    load_0_2_5  segment_load_conservation_837  1
    load_0_2_5  segment_load_conservation_858  -1
    load_0_2_5  segment_prefix_lb_859  1
    load_0_2_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_482  -20
    arc_0_2_6  connected_order_arc_483  -15
    arc_0_2_6  out_degree_833  1
    arc_0_2_6  in_degree_862  1
    arc_0_2_6  original_T_including_depot_unload_921  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_482  1
    load_0_2_6  segment_load_conservation_837  1
    load_0_2_6  segment_load_conservation_865  -1
    load_0_2_6  segment_prefix_lb_866  1
    load_0_2_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_484  -20
    arc_0_2_14  connected_order_arc_485  -15
    arc_0_2_14  out_degree_833  1
    arc_0_2_14  in_degree_869  1
    arc_0_2_14  original_T_including_depot_unload_921  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_484  1
    load_0_2_14  segment_load_conservation_837  1
    load_0_2_14  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_486  -20
    arc_0_2_15  connected_order_arc_487  -15
    arc_0_2_15  out_degree_833  1
    arc_0_2_15  in_degree_875  1
    arc_0_2_15  original_T_including_depot_unload_921  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_486  1
    load_0_2_15  segment_load_conservation_837  1
    load_0_2_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_488  -20
    arc_0_2_16  connected_order_arc_489  -15
    arc_0_2_16  out_degree_833  1
    arc_0_2_16  in_degree_881  1
    arc_0_2_16  original_T_including_depot_unload_921  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_488  1
    load_0_2_16  segment_load_conservation_837  1
    load_0_2_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_490  -20
    arc_0_2_17  connected_order_arc_491  -15
    arc_0_2_17  out_degree_833  1
    arc_0_2_17  in_degree_887  1
    arc_0_2_17  original_T_including_depot_unload_921  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_490  1
    load_0_2_17  segment_load_conservation_837  1
    load_0_2_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_492  -20
    arc_0_2_18  connected_order_arc_493  -15
    arc_0_2_18  out_degree_833  1
    arc_0_2_18  in_degree_893  1
    arc_0_2_18  original_T_including_depot_unload_921  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_492  1
    load_0_2_18  segment_load_conservation_837  1
    load_0_2_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_494  -20
    arc_0_2_19  connected_order_arc_495  -15
    arc_0_2_19  out_degree_833  1
    arc_0_2_19  in_degree_899  1
    arc_0_2_19  original_T_including_depot_unload_921  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_494  1
    load_0_2_19  segment_load_conservation_837  1
    load_0_2_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_496  -20
    arc_0_2_20  connected_order_arc_497  -15
    arc_0_2_20  out_degree_833  1
    arc_0_2_20  in_degree_905  1
    arc_0_2_20  original_T_including_depot_unload_921  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_496  1
    load_0_2_20  segment_load_conservation_837  1
    load_0_2_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_498  -20
    arc_0_2_21  connected_order_arc_499  -15
    arc_0_2_21  out_degree_833  1
    arc_0_2_21  in_degree_911  1
    arc_0_2_21  original_T_including_depot_unload_921  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_498  1
    load_0_2_21  segment_load_conservation_837  1
    load_0_2_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_500  -20
    arc_0_3_0  depot_return_or_bypass_825  1
    arc_0_3_0  out_degree_840  1
    arc_0_3_0  original_T_including_depot_unload_921  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_500  1
    load_0_3_0  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_501  -20
    arc_0_3_1  connected_order_arc_502  -15
    arc_0_3_1  in_degree_827  1
    arc_0_3_1  out_degree_840  1
    arc_0_3_1  original_T_including_depot_unload_921  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_501  1
    load_0_3_1  segment_load_conservation_830  -1
    load_0_3_1  segment_prefix_lb_831  1
    load_0_3_1  segment_prefix_ub_832  1
    load_0_3_1  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_503  -20
    arc_0_3_2  connected_order_arc_504  -15
    arc_0_3_2  in_degree_834  1
    arc_0_3_2  out_degree_840  1
    arc_0_3_2  original_T_including_depot_unload_921  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_503  1
    load_0_3_2  segment_load_conservation_837  -1
    load_0_3_2  segment_prefix_lb_838  1
    load_0_3_2  segment_prefix_ub_839  1
    load_0_3_2  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_505  -20
    arc_0_3_4  connected_order_arc_506  -15
    arc_0_3_4  out_degree_840  1
    arc_0_3_4  in_degree_848  1
    arc_0_3_4  original_T_including_depot_unload_921  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_505  1
    load_0_3_4  segment_load_conservation_844  1
    load_0_3_4  segment_load_conservation_851  -1
    load_0_3_4  segment_prefix_lb_852  1
    load_0_3_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_507  -20
    arc_0_3_5  connected_order_arc_508  -15
    arc_0_3_5  out_degree_840  1
    arc_0_3_5  in_degree_855  1
    arc_0_3_5  original_T_including_depot_unload_921  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_507  1
    load_0_3_5  segment_load_conservation_844  1
    load_0_3_5  segment_load_conservation_858  -1
    load_0_3_5  segment_prefix_lb_859  1
    load_0_3_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_509  -20
    arc_0_3_6  connected_order_arc_510  -15
    arc_0_3_6  out_degree_840  1
    arc_0_3_6  in_degree_862  1
    arc_0_3_6  original_T_including_depot_unload_921  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_509  1
    load_0_3_6  segment_load_conservation_844  1
    load_0_3_6  segment_load_conservation_865  -1
    load_0_3_6  segment_prefix_lb_866  1
    load_0_3_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_511  -20
    arc_0_3_14  connected_order_arc_512  -15
    arc_0_3_14  out_degree_840  1
    arc_0_3_14  in_degree_869  1
    arc_0_3_14  original_T_including_depot_unload_921  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_511  1
    load_0_3_14  segment_load_conservation_844  1
    load_0_3_14  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_513  -20
    arc_0_3_15  connected_order_arc_514  -15
    arc_0_3_15  out_degree_840  1
    arc_0_3_15  in_degree_875  1
    arc_0_3_15  original_T_including_depot_unload_921  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_513  1
    load_0_3_15  segment_load_conservation_844  1
    load_0_3_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_515  -20
    arc_0_3_16  connected_order_arc_516  -15
    arc_0_3_16  out_degree_840  1
    arc_0_3_16  in_degree_881  1
    arc_0_3_16  original_T_including_depot_unload_921  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_515  1
    load_0_3_16  segment_load_conservation_844  1
    load_0_3_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_517  -20
    arc_0_3_17  connected_order_arc_518  -15
    arc_0_3_17  out_degree_840  1
    arc_0_3_17  in_degree_887  1
    arc_0_3_17  original_T_including_depot_unload_921  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_517  1
    load_0_3_17  segment_load_conservation_844  1
    load_0_3_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_519  -20
    arc_0_3_18  connected_order_arc_520  -15
    arc_0_3_18  out_degree_840  1
    arc_0_3_18  in_degree_893  1
    arc_0_3_18  original_T_including_depot_unload_921  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_519  1
    load_0_3_18  segment_load_conservation_844  1
    load_0_3_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_521  -20
    arc_0_3_19  connected_order_arc_522  -15
    arc_0_3_19  out_degree_840  1
    arc_0_3_19  in_degree_899  1
    arc_0_3_19  original_T_including_depot_unload_921  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_521  1
    load_0_3_19  segment_load_conservation_844  1
    load_0_3_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_523  -20
    arc_0_3_20  connected_order_arc_524  -15
    arc_0_3_20  out_degree_840  1
    arc_0_3_20  in_degree_905  1
    arc_0_3_20  original_T_including_depot_unload_921  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_523  1
    load_0_3_20  segment_load_conservation_844  1
    load_0_3_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_525  -20
    arc_0_3_21  connected_order_arc_526  -15
    arc_0_3_21  out_degree_840  1
    arc_0_3_21  in_degree_911  1
    arc_0_3_21  original_T_including_depot_unload_921  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_525  1
    load_0_3_21  segment_load_conservation_844  1
    load_0_3_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_527  -20
    arc_0_4_0  depot_return_or_bypass_825  1
    arc_0_4_0  out_degree_847  1
    arc_0_4_0  original_T_including_depot_unload_921  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_527  1
    load_0_4_0  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_528  -20
    arc_0_4_1  connected_order_arc_529  -15
    arc_0_4_1  in_degree_827  1
    arc_0_4_1  out_degree_847  1
    arc_0_4_1  original_T_including_depot_unload_921  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_528  1
    load_0_4_1  segment_load_conservation_830  -1
    load_0_4_1  segment_prefix_lb_831  1
    load_0_4_1  segment_prefix_ub_832  1
    load_0_4_1  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_530  -20
    arc_0_4_2  connected_order_arc_531  -15
    arc_0_4_2  in_degree_834  1
    arc_0_4_2  out_degree_847  1
    arc_0_4_2  original_T_including_depot_unload_921  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_530  1
    load_0_4_2  segment_load_conservation_837  -1
    load_0_4_2  segment_prefix_lb_838  1
    load_0_4_2  segment_prefix_ub_839  1
    load_0_4_2  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_532  -20
    arc_0_4_3  connected_order_arc_533  -15
    arc_0_4_3  in_degree_841  1
    arc_0_4_3  out_degree_847  1
    arc_0_4_3  original_T_including_depot_unload_921  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_532  1
    load_0_4_3  segment_load_conservation_844  -1
    load_0_4_3  segment_prefix_lb_845  1
    load_0_4_3  segment_prefix_ub_846  1
    load_0_4_3  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_534  -20
    arc_0_4_5  connected_order_arc_535  -15
    arc_0_4_5  out_degree_847  1
    arc_0_4_5  in_degree_855  1
    arc_0_4_5  original_T_including_depot_unload_921  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_534  1
    load_0_4_5  segment_load_conservation_851  1
    load_0_4_5  segment_load_conservation_858  -1
    load_0_4_5  segment_prefix_lb_859  1
    load_0_4_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_536  -20
    arc_0_4_6  connected_order_arc_537  -15
    arc_0_4_6  out_degree_847  1
    arc_0_4_6  in_degree_862  1
    arc_0_4_6  original_T_including_depot_unload_921  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_536  1
    load_0_4_6  segment_load_conservation_851  1
    load_0_4_6  segment_load_conservation_865  -1
    load_0_4_6  segment_prefix_lb_866  1
    load_0_4_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_538  -20
    arc_0_4_14  connected_order_arc_539  -15
    arc_0_4_14  out_degree_847  1
    arc_0_4_14  in_degree_869  1
    arc_0_4_14  original_T_including_depot_unload_921  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_538  1
    load_0_4_14  segment_load_conservation_851  1
    load_0_4_14  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_540  -20
    arc_0_4_15  connected_order_arc_541  -15
    arc_0_4_15  out_degree_847  1
    arc_0_4_15  in_degree_875  1
    arc_0_4_15  original_T_including_depot_unload_921  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_540  1
    load_0_4_15  segment_load_conservation_851  1
    load_0_4_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_542  -20
    arc_0_4_16  connected_order_arc_543  -15
    arc_0_4_16  out_degree_847  1
    arc_0_4_16  in_degree_881  1
    arc_0_4_16  original_T_including_depot_unload_921  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_542  1
    load_0_4_16  segment_load_conservation_851  1
    load_0_4_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_544  -20
    arc_0_4_17  connected_order_arc_545  -15
    arc_0_4_17  out_degree_847  1
    arc_0_4_17  in_degree_887  1
    arc_0_4_17  original_T_including_depot_unload_921  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_544  1
    load_0_4_17  segment_load_conservation_851  1
    load_0_4_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_546  -20
    arc_0_4_18  connected_order_arc_547  -15
    arc_0_4_18  out_degree_847  1
    arc_0_4_18  in_degree_893  1
    arc_0_4_18  original_T_including_depot_unload_921  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_546  1
    load_0_4_18  segment_load_conservation_851  1
    load_0_4_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_548  -20
    arc_0_4_19  connected_order_arc_549  -15
    arc_0_4_19  out_degree_847  1
    arc_0_4_19  in_degree_899  1
    arc_0_4_19  original_T_including_depot_unload_921  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_548  1
    load_0_4_19  segment_load_conservation_851  1
    load_0_4_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_550  -20
    arc_0_4_20  connected_order_arc_551  -15
    arc_0_4_20  out_degree_847  1
    arc_0_4_20  in_degree_905  1
    arc_0_4_20  original_T_including_depot_unload_921  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_550  1
    load_0_4_20  segment_load_conservation_851  1
    load_0_4_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_552  -20
    arc_0_4_21  connected_order_arc_553  -15
    arc_0_4_21  out_degree_847  1
    arc_0_4_21  in_degree_911  1
    arc_0_4_21  original_T_including_depot_unload_921  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_552  1
    load_0_4_21  segment_load_conservation_851  1
    load_0_4_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_554  -20
    arc_0_5_0  depot_return_or_bypass_825  1
    arc_0_5_0  out_degree_854  1
    arc_0_5_0  original_T_including_depot_unload_921  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_554  1
    load_0_5_0  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_555  -20
    arc_0_5_1  connected_order_arc_556  -15
    arc_0_5_1  in_degree_827  1
    arc_0_5_1  out_degree_854  1
    arc_0_5_1  original_T_including_depot_unload_921  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_555  1
    load_0_5_1  segment_load_conservation_830  -1
    load_0_5_1  segment_prefix_lb_831  1
    load_0_5_1  segment_prefix_ub_832  1
    load_0_5_1  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_557  -20
    arc_0_5_2  connected_order_arc_558  -15
    arc_0_5_2  in_degree_834  1
    arc_0_5_2  out_degree_854  1
    arc_0_5_2  original_T_including_depot_unload_921  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_557  1
    load_0_5_2  segment_load_conservation_837  -1
    load_0_5_2  segment_prefix_lb_838  1
    load_0_5_2  segment_prefix_ub_839  1
    load_0_5_2  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_559  -20
    arc_0_5_3  connected_order_arc_560  -15
    arc_0_5_3  in_degree_841  1
    arc_0_5_3  out_degree_854  1
    arc_0_5_3  original_T_including_depot_unload_921  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_559  1
    load_0_5_3  segment_load_conservation_844  -1
    load_0_5_3  segment_prefix_lb_845  1
    load_0_5_3  segment_prefix_ub_846  1
    load_0_5_3  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_561  -20
    arc_0_5_4  connected_order_arc_562  -15
    arc_0_5_4  in_degree_848  1
    arc_0_5_4  out_degree_854  1
    arc_0_5_4  original_T_including_depot_unload_921  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_561  1
    load_0_5_4  segment_load_conservation_851  -1
    load_0_5_4  segment_prefix_lb_852  1
    load_0_5_4  segment_prefix_ub_853  1
    load_0_5_4  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_563  -20
    arc_0_5_6  connected_order_arc_564  -15
    arc_0_5_6  out_degree_854  1
    arc_0_5_6  in_degree_862  1
    arc_0_5_6  original_T_including_depot_unload_921  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_563  1
    load_0_5_6  segment_load_conservation_858  1
    load_0_5_6  segment_load_conservation_865  -1
    load_0_5_6  segment_prefix_lb_866  1
    load_0_5_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_565  -20
    arc_0_5_14  connected_order_arc_566  -15
    arc_0_5_14  out_degree_854  1
    arc_0_5_14  in_degree_869  1
    arc_0_5_14  original_T_including_depot_unload_921  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_565  1
    load_0_5_14  segment_load_conservation_858  1
    load_0_5_14  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_567  -20
    arc_0_5_15  connected_order_arc_568  -15
    arc_0_5_15  out_degree_854  1
    arc_0_5_15  in_degree_875  1
    arc_0_5_15  original_T_including_depot_unload_921  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_567  1
    load_0_5_15  segment_load_conservation_858  1
    load_0_5_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_569  -20
    arc_0_5_16  connected_order_arc_570  -15
    arc_0_5_16  out_degree_854  1
    arc_0_5_16  in_degree_881  1
    arc_0_5_16  original_T_including_depot_unload_921  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_569  1
    load_0_5_16  segment_load_conservation_858  1
    load_0_5_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_571  -20
    arc_0_5_17  connected_order_arc_572  -15
    arc_0_5_17  out_degree_854  1
    arc_0_5_17  in_degree_887  1
    arc_0_5_17  original_T_including_depot_unload_921  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_571  1
    load_0_5_17  segment_load_conservation_858  1
    load_0_5_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_573  -20
    arc_0_5_18  connected_order_arc_574  -15
    arc_0_5_18  out_degree_854  1
    arc_0_5_18  in_degree_893  1
    arc_0_5_18  original_T_including_depot_unload_921  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_573  1
    load_0_5_18  segment_load_conservation_858  1
    load_0_5_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_575  -20
    arc_0_5_19  connected_order_arc_576  -15
    arc_0_5_19  out_degree_854  1
    arc_0_5_19  in_degree_899  1
    arc_0_5_19  original_T_including_depot_unload_921  1.2087821033682005e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_575  1
    load_0_5_19  segment_load_conservation_858  1
    load_0_5_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_577  -20
    arc_0_5_20  connected_order_arc_578  -15
    arc_0_5_20  out_degree_854  1
    arc_0_5_20  in_degree_905  1
    arc_0_5_20  original_T_including_depot_unload_921  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_577  1
    load_0_5_20  segment_load_conservation_858  1
    load_0_5_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_579  -20
    arc_0_5_21  connected_order_arc_580  -15
    arc_0_5_21  out_degree_854  1
    arc_0_5_21  in_degree_911  1
    arc_0_5_21  original_T_including_depot_unload_921  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_579  1
    load_0_5_21  segment_load_conservation_858  1
    load_0_5_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_581  -20
    arc_0_6_0  depot_return_or_bypass_825  1
    arc_0_6_0  out_degree_861  1
    arc_0_6_0  original_T_including_depot_unload_921  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_581  1
    load_0_6_0  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_582  -20
    arc_0_6_1  connected_order_arc_583  -15
    arc_0_6_1  in_degree_827  1
    arc_0_6_1  out_degree_861  1
    arc_0_6_1  original_T_including_depot_unload_921  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_582  1
    load_0_6_1  segment_load_conservation_830  -1
    load_0_6_1  segment_prefix_lb_831  1
    load_0_6_1  segment_prefix_ub_832  1
    load_0_6_1  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_584  -20
    arc_0_6_2  connected_order_arc_585  -15
    arc_0_6_2  in_degree_834  1
    arc_0_6_2  out_degree_861  1
    arc_0_6_2  original_T_including_depot_unload_921  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_584  1
    load_0_6_2  segment_load_conservation_837  -1
    load_0_6_2  segment_prefix_lb_838  1
    load_0_6_2  segment_prefix_ub_839  1
    load_0_6_2  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_586  -20
    arc_0_6_3  connected_order_arc_587  -15
    arc_0_6_3  in_degree_841  1
    arc_0_6_3  out_degree_861  1
    arc_0_6_3  original_T_including_depot_unload_921  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_586  1
    load_0_6_3  segment_load_conservation_844  -1
    load_0_6_3  segment_prefix_lb_845  1
    load_0_6_3  segment_prefix_ub_846  1
    load_0_6_3  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_588  -20
    arc_0_6_4  connected_order_arc_589  -15
    arc_0_6_4  in_degree_848  1
    arc_0_6_4  out_degree_861  1
    arc_0_6_4  original_T_including_depot_unload_921  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_588  1
    load_0_6_4  segment_load_conservation_851  -1
    load_0_6_4  segment_prefix_lb_852  1
    load_0_6_4  segment_prefix_ub_853  1
    load_0_6_4  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_590  -20
    arc_0_6_5  connected_order_arc_591  -15
    arc_0_6_5  in_degree_855  1
    arc_0_6_5  out_degree_861  1
    arc_0_6_5  original_T_including_depot_unload_921  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_590  1
    load_0_6_5  segment_load_conservation_858  -1
    load_0_6_5  segment_prefix_lb_859  1
    load_0_6_5  segment_prefix_ub_860  1
    load_0_6_5  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_592  -20
    arc_0_6_14  connected_order_arc_593  -15
    arc_0_6_14  out_degree_861  1
    arc_0_6_14  in_degree_869  1
    arc_0_6_14  original_T_including_depot_unload_921  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_592  1
    load_0_6_14  segment_load_conservation_865  1
    load_0_6_14  free_load_conservation_873  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_594  -20
    arc_0_6_15  connected_order_arc_595  -15
    arc_0_6_15  out_degree_861  1
    arc_0_6_15  in_degree_875  1
    arc_0_6_15  original_T_including_depot_unload_921  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_594  1
    load_0_6_15  segment_load_conservation_865  1
    load_0_6_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_596  -20
    arc_0_6_16  connected_order_arc_597  -15
    arc_0_6_16  out_degree_861  1
    arc_0_6_16  in_degree_881  1
    arc_0_6_16  original_T_including_depot_unload_921  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_596  1
    load_0_6_16  segment_load_conservation_865  1
    load_0_6_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_598  -20
    arc_0_6_17  connected_order_arc_599  -15
    arc_0_6_17  out_degree_861  1
    arc_0_6_17  in_degree_887  1
    arc_0_6_17  original_T_including_depot_unload_921  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_598  1
    load_0_6_17  segment_load_conservation_865  1
    load_0_6_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_600  -20
    arc_0_6_18  connected_order_arc_601  -15
    arc_0_6_18  out_degree_861  1
    arc_0_6_18  in_degree_893  1
    arc_0_6_18  original_T_including_depot_unload_921  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_600  1
    load_0_6_18  segment_load_conservation_865  1
    load_0_6_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_602  -20
    arc_0_6_19  connected_order_arc_603  -15
    arc_0_6_19  out_degree_861  1
    arc_0_6_19  in_degree_899  1
    arc_0_6_19  original_T_including_depot_unload_921  1.3473492742338772e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_602  1
    load_0_6_19  segment_load_conservation_865  1
    load_0_6_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_604  -20
    arc_0_6_20  connected_order_arc_605  -15
    arc_0_6_20  out_degree_861  1
    arc_0_6_20  in_degree_905  1
    arc_0_6_20  original_T_including_depot_unload_921  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_604  1
    load_0_6_20  segment_load_conservation_865  1
    load_0_6_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_606  -20
    arc_0_6_21  connected_order_arc_607  -15
    arc_0_6_21  out_degree_861  1
    arc_0_6_21  in_degree_911  1
    arc_0_6_21  original_T_including_depot_unload_921  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_606  1
    load_0_6_21  segment_load_conservation_865  1
    load_0_6_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_608  -20
    arc_0_14_0  depot_return_or_bypass_825  1
    arc_0_14_0  out_degree_868  1
    arc_0_14_0  original_T_including_depot_unload_921  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_608  1
    load_0_14_0  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_609  -20
    arc_0_14_1  connected_order_arc_610  -15
    arc_0_14_1  in_degree_827  1
    arc_0_14_1  out_degree_868  1
    arc_0_14_1  original_T_including_depot_unload_921  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_609  1
    load_0_14_1  segment_load_conservation_830  -1
    load_0_14_1  segment_prefix_lb_831  1
    load_0_14_1  segment_prefix_ub_832  1
    load_0_14_1  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_611  -20
    arc_0_14_2  connected_order_arc_612  -15
    arc_0_14_2  in_degree_834  1
    arc_0_14_2  out_degree_868  1
    arc_0_14_2  original_T_including_depot_unload_921  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_611  1
    load_0_14_2  segment_load_conservation_837  -1
    load_0_14_2  segment_prefix_lb_838  1
    load_0_14_2  segment_prefix_ub_839  1
    load_0_14_2  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_613  -20
    arc_0_14_3  connected_order_arc_614  -15
    arc_0_14_3  in_degree_841  1
    arc_0_14_3  out_degree_868  1
    arc_0_14_3  original_T_including_depot_unload_921  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_613  1
    load_0_14_3  segment_load_conservation_844  -1
    load_0_14_3  segment_prefix_lb_845  1
    load_0_14_3  segment_prefix_ub_846  1
    load_0_14_3  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_615  -20
    arc_0_14_4  connected_order_arc_616  -15
    arc_0_14_4  in_degree_848  1
    arc_0_14_4  out_degree_868  1
    arc_0_14_4  original_T_including_depot_unload_921  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_615  1
    load_0_14_4  segment_load_conservation_851  -1
    load_0_14_4  segment_prefix_lb_852  1
    load_0_14_4  segment_prefix_ub_853  1
    load_0_14_4  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_617  -20
    arc_0_14_5  connected_order_arc_618  -15
    arc_0_14_5  in_degree_855  1
    arc_0_14_5  out_degree_868  1
    arc_0_14_5  original_T_including_depot_unload_921  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_617  1
    load_0_14_5  segment_load_conservation_858  -1
    load_0_14_5  segment_prefix_lb_859  1
    load_0_14_5  segment_prefix_ub_860  1
    load_0_14_5  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_619  -20
    arc_0_14_6  connected_order_arc_620  -15
    arc_0_14_6  in_degree_862  1
    arc_0_14_6  out_degree_868  1
    arc_0_14_6  original_T_including_depot_unload_921  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_619  1
    load_0_14_6  segment_load_conservation_865  -1
    load_0_14_6  segment_prefix_lb_866  1
    load_0_14_6  segment_prefix_ub_867  1
    load_0_14_6  free_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_621  -20
    arc_0_14_15  connected_order_arc_622  -15
    arc_0_14_15  out_degree_868  1
    arc_0_14_15  in_degree_875  1
    arc_0_14_15  original_T_including_depot_unload_921  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_621  1
    load_0_14_15  free_load_conservation_873  1
    load_0_14_15  free_load_conservation_879  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_623  -20
    arc_0_14_16  connected_order_arc_624  -15
    arc_0_14_16  out_degree_868  1
    arc_0_14_16  in_degree_881  1
    arc_0_14_16  original_T_including_depot_unload_921  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_623  1
    load_0_14_16  free_load_conservation_873  1
    load_0_14_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_625  -20
    arc_0_14_17  connected_order_arc_626  -15
    arc_0_14_17  out_degree_868  1
    arc_0_14_17  in_degree_887  1
    arc_0_14_17  original_T_including_depot_unload_921  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_625  1
    load_0_14_17  free_load_conservation_873  1
    load_0_14_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_627  -20
    arc_0_14_18  connected_order_arc_628  -15
    arc_0_14_18  out_degree_868  1
    arc_0_14_18  in_degree_893  1
    arc_0_14_18  original_T_including_depot_unload_921  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_627  1
    load_0_14_18  free_load_conservation_873  1
    load_0_14_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_629  -20
    arc_0_14_19  connected_order_arc_630  -15
    arc_0_14_19  out_degree_868  1
    arc_0_14_19  in_degree_899  1
    arc_0_14_19  original_T_including_depot_unload_921  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_629  1
    load_0_14_19  free_load_conservation_873  1
    load_0_14_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_631  -20
    arc_0_14_20  connected_order_arc_632  -15
    arc_0_14_20  out_degree_868  1
    arc_0_14_20  in_degree_905  1
    arc_0_14_20  original_T_including_depot_unload_921  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_631  1
    load_0_14_20  free_load_conservation_873  1
    load_0_14_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_633  -20
    arc_0_14_21  connected_order_arc_634  -15
    arc_0_14_21  out_degree_868  1
    arc_0_14_21  in_degree_911  1
    arc_0_14_21  original_T_including_depot_unload_921  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_633  1
    load_0_14_21  free_load_conservation_873  1
    load_0_14_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_635  -20
    arc_0_15_0  depot_return_or_bypass_825  1
    arc_0_15_0  out_degree_874  1
    arc_0_15_0  original_T_including_depot_unload_921  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_635  1
    load_0_15_0  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_636  -20
    arc_0_15_1  connected_order_arc_637  -15
    arc_0_15_1  in_degree_827  1
    arc_0_15_1  out_degree_874  1
    arc_0_15_1  original_T_including_depot_unload_921  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_636  1
    load_0_15_1  segment_load_conservation_830  -1
    load_0_15_1  segment_prefix_lb_831  1
    load_0_15_1  segment_prefix_ub_832  1
    load_0_15_1  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_638  -20
    arc_0_15_2  connected_order_arc_639  -15
    arc_0_15_2  in_degree_834  1
    arc_0_15_2  out_degree_874  1
    arc_0_15_2  original_T_including_depot_unload_921  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_638  1
    load_0_15_2  segment_load_conservation_837  -1
    load_0_15_2  segment_prefix_lb_838  1
    load_0_15_2  segment_prefix_ub_839  1
    load_0_15_2  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_640  -20
    arc_0_15_3  connected_order_arc_641  -15
    arc_0_15_3  in_degree_841  1
    arc_0_15_3  out_degree_874  1
    arc_0_15_3  original_T_including_depot_unload_921  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_640  1
    load_0_15_3  segment_load_conservation_844  -1
    load_0_15_3  segment_prefix_lb_845  1
    load_0_15_3  segment_prefix_ub_846  1
    load_0_15_3  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_642  -20
    arc_0_15_4  connected_order_arc_643  -15
    arc_0_15_4  in_degree_848  1
    arc_0_15_4  out_degree_874  1
    arc_0_15_4  original_T_including_depot_unload_921  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_642  1
    load_0_15_4  segment_load_conservation_851  -1
    load_0_15_4  segment_prefix_lb_852  1
    load_0_15_4  segment_prefix_ub_853  1
    load_0_15_4  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_644  -20
    arc_0_15_5  connected_order_arc_645  -15
    arc_0_15_5  in_degree_855  1
    arc_0_15_5  out_degree_874  1
    arc_0_15_5  original_T_including_depot_unload_921  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_644  1
    load_0_15_5  segment_load_conservation_858  -1
    load_0_15_5  segment_prefix_lb_859  1
    load_0_15_5  segment_prefix_ub_860  1
    load_0_15_5  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_646  -20
    arc_0_15_6  connected_order_arc_647  -15
    arc_0_15_6  in_degree_862  1
    arc_0_15_6  out_degree_874  1
    arc_0_15_6  original_T_including_depot_unload_921  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_646  1
    load_0_15_6  segment_load_conservation_865  -1
    load_0_15_6  segment_prefix_lb_866  1
    load_0_15_6  segment_prefix_ub_867  1
    load_0_15_6  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_648  -20
    arc_0_15_14  connected_order_arc_649  -15
    arc_0_15_14  in_degree_869  1
    arc_0_15_14  out_degree_874  1
    arc_0_15_14  original_T_including_depot_unload_921  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_648  1
    load_0_15_14  free_load_conservation_873  -1
    load_0_15_14  free_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_650  -20
    arc_0_15_16  connected_order_arc_651  -15
    arc_0_15_16  out_degree_874  1
    arc_0_15_16  in_degree_881  1
    arc_0_15_16  original_T_including_depot_unload_921  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_650  1
    load_0_15_16  free_load_conservation_879  1
    load_0_15_16  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_652  -20
    arc_0_15_17  connected_order_arc_653  -15
    arc_0_15_17  out_degree_874  1
    arc_0_15_17  in_degree_887  1
    arc_0_15_17  original_T_including_depot_unload_921  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_652  1
    load_0_15_17  free_load_conservation_879  1
    load_0_15_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_654  -20
    arc_0_15_18  connected_order_arc_655  -15
    arc_0_15_18  out_degree_874  1
    arc_0_15_18  in_degree_893  1
    arc_0_15_18  original_T_including_depot_unload_921  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_654  1
    load_0_15_18  free_load_conservation_879  1
    load_0_15_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_656  -20
    arc_0_15_19  connected_order_arc_657  -15
    arc_0_15_19  out_degree_874  1
    arc_0_15_19  in_degree_899  1
    arc_0_15_19  original_T_including_depot_unload_921  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_656  1
    load_0_15_19  free_load_conservation_879  1
    load_0_15_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_658  -20
    arc_0_15_20  connected_order_arc_659  -15
    arc_0_15_20  out_degree_874  1
    arc_0_15_20  in_degree_905  1
    arc_0_15_20  original_T_including_depot_unload_921  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_658  1
    load_0_15_20  free_load_conservation_879  1
    load_0_15_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_660  -20
    arc_0_15_21  connected_order_arc_661  -15
    arc_0_15_21  out_degree_874  1
    arc_0_15_21  in_degree_911  1
    arc_0_15_21  original_T_including_depot_unload_921  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_660  1
    load_0_15_21  free_load_conservation_879  1
    load_0_15_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_662  -20
    arc_0_16_0  depot_return_or_bypass_825  1
    arc_0_16_0  out_degree_880  1
    arc_0_16_0  original_T_including_depot_unload_921  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_662  1
    load_0_16_0  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_663  -20
    arc_0_16_1  connected_order_arc_664  -15
    arc_0_16_1  in_degree_827  1
    arc_0_16_1  out_degree_880  1
    arc_0_16_1  original_T_including_depot_unload_921  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_663  1
    load_0_16_1  segment_load_conservation_830  -1
    load_0_16_1  segment_prefix_lb_831  1
    load_0_16_1  segment_prefix_ub_832  1
    load_0_16_1  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_665  -20
    arc_0_16_2  connected_order_arc_666  -15
    arc_0_16_2  in_degree_834  1
    arc_0_16_2  out_degree_880  1
    arc_0_16_2  original_T_including_depot_unload_921  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_665  1
    load_0_16_2  segment_load_conservation_837  -1
    load_0_16_2  segment_prefix_lb_838  1
    load_0_16_2  segment_prefix_ub_839  1
    load_0_16_2  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_667  -20
    arc_0_16_3  connected_order_arc_668  -15
    arc_0_16_3  in_degree_841  1
    arc_0_16_3  out_degree_880  1
    arc_0_16_3  original_T_including_depot_unload_921  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_667  1
    load_0_16_3  segment_load_conservation_844  -1
    load_0_16_3  segment_prefix_lb_845  1
    load_0_16_3  segment_prefix_ub_846  1
    load_0_16_3  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_669  -20
    arc_0_16_4  connected_order_arc_670  -15
    arc_0_16_4  in_degree_848  1
    arc_0_16_4  out_degree_880  1
    arc_0_16_4  original_T_including_depot_unload_921  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_669  1
    load_0_16_4  segment_load_conservation_851  -1
    load_0_16_4  segment_prefix_lb_852  1
    load_0_16_4  segment_prefix_ub_853  1
    load_0_16_4  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_671  -20
    arc_0_16_5  connected_order_arc_672  -15
    arc_0_16_5  in_degree_855  1
    arc_0_16_5  out_degree_880  1
    arc_0_16_5  original_T_including_depot_unload_921  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_671  1
    load_0_16_5  segment_load_conservation_858  -1
    load_0_16_5  segment_prefix_lb_859  1
    load_0_16_5  segment_prefix_ub_860  1
    load_0_16_5  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_673  -20
    arc_0_16_6  connected_order_arc_674  -15
    arc_0_16_6  in_degree_862  1
    arc_0_16_6  out_degree_880  1
    arc_0_16_6  original_T_including_depot_unload_921  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_673  1
    load_0_16_6  segment_load_conservation_865  -1
    load_0_16_6  segment_prefix_lb_866  1
    load_0_16_6  segment_prefix_ub_867  1
    load_0_16_6  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_675  -20
    arc_0_16_14  connected_order_arc_676  -15
    arc_0_16_14  in_degree_869  1
    arc_0_16_14  out_degree_880  1
    arc_0_16_14  original_T_including_depot_unload_921  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_675  1
    load_0_16_14  free_load_conservation_873  -1
    load_0_16_14  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_677  -20
    arc_0_16_15  connected_order_arc_678  -15
    arc_0_16_15  in_degree_875  1
    arc_0_16_15  out_degree_880  1
    arc_0_16_15  original_T_including_depot_unload_921  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_677  1
    load_0_16_15  free_load_conservation_879  -1
    load_0_16_15  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_679  -20
    arc_0_16_17  connected_order_arc_680  -15
    arc_0_16_17  out_degree_880  1
    arc_0_16_17  in_degree_887  1
    arc_0_16_17  original_T_including_depot_unload_921  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_679  1
    load_0_16_17  free_load_conservation_885  1
    load_0_16_17  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_681  -20
    arc_0_16_18  connected_order_arc_682  -15
    arc_0_16_18  out_degree_880  1
    arc_0_16_18  in_degree_893  1
    arc_0_16_18  original_T_including_depot_unload_921  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_681  1
    load_0_16_18  free_load_conservation_885  1
    load_0_16_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_683  -20
    arc_0_16_19  connected_order_arc_684  -15
    arc_0_16_19  out_degree_880  1
    arc_0_16_19  in_degree_899  1
    arc_0_16_19  original_T_including_depot_unload_921  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_683  1
    load_0_16_19  free_load_conservation_885  1
    load_0_16_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_685  -20
    arc_0_16_20  connected_order_arc_686  -15
    arc_0_16_20  out_degree_880  1
    arc_0_16_20  in_degree_905  1
    arc_0_16_20  original_T_including_depot_unload_921  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_685  1
    load_0_16_20  free_load_conservation_885  1
    load_0_16_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_687  -20
    arc_0_16_21  connected_order_arc_688  -15
    arc_0_16_21  out_degree_880  1
    arc_0_16_21  in_degree_911  1
    arc_0_16_21  original_T_including_depot_unload_921  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_687  1
    load_0_16_21  free_load_conservation_885  1
    load_0_16_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_689  -20
    arc_0_17_0  depot_return_or_bypass_825  1
    arc_0_17_0  out_degree_886  1
    arc_0_17_0  original_T_including_depot_unload_921  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_689  1
    load_0_17_0  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_690  -20
    arc_0_17_1  connected_order_arc_691  -15
    arc_0_17_1  in_degree_827  1
    arc_0_17_1  out_degree_886  1
    arc_0_17_1  original_T_including_depot_unload_921  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_690  1
    load_0_17_1  segment_load_conservation_830  -1
    load_0_17_1  segment_prefix_lb_831  1
    load_0_17_1  segment_prefix_ub_832  1
    load_0_17_1  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_692  -20
    arc_0_17_2  connected_order_arc_693  -15
    arc_0_17_2  in_degree_834  1
    arc_0_17_2  out_degree_886  1
    arc_0_17_2  original_T_including_depot_unload_921  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_692  1
    load_0_17_2  segment_load_conservation_837  -1
    load_0_17_2  segment_prefix_lb_838  1
    load_0_17_2  segment_prefix_ub_839  1
    load_0_17_2  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_694  -20
    arc_0_17_3  connected_order_arc_695  -15
    arc_0_17_3  in_degree_841  1
    arc_0_17_3  out_degree_886  1
    arc_0_17_3  original_T_including_depot_unload_921  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_694  1
    load_0_17_3  segment_load_conservation_844  -1
    load_0_17_3  segment_prefix_lb_845  1
    load_0_17_3  segment_prefix_ub_846  1
    load_0_17_3  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_696  -20
    arc_0_17_4  connected_order_arc_697  -15
    arc_0_17_4  in_degree_848  1
    arc_0_17_4  out_degree_886  1
    arc_0_17_4  original_T_including_depot_unload_921  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_696  1
    load_0_17_4  segment_load_conservation_851  -1
    load_0_17_4  segment_prefix_lb_852  1
    load_0_17_4  segment_prefix_ub_853  1
    load_0_17_4  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_698  -20
    arc_0_17_5  connected_order_arc_699  -15
    arc_0_17_5  in_degree_855  1
    arc_0_17_5  out_degree_886  1
    arc_0_17_5  original_T_including_depot_unload_921  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_698  1
    load_0_17_5  segment_load_conservation_858  -1
    load_0_17_5  segment_prefix_lb_859  1
    load_0_17_5  segment_prefix_ub_860  1
    load_0_17_5  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_700  -20
    arc_0_17_6  connected_order_arc_701  -15
    arc_0_17_6  in_degree_862  1
    arc_0_17_6  out_degree_886  1
    arc_0_17_6  original_T_including_depot_unload_921  1.3251252487627862e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_700  1
    load_0_17_6  segment_load_conservation_865  -1
    load_0_17_6  segment_prefix_lb_866  1
    load_0_17_6  segment_prefix_ub_867  1
    load_0_17_6  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_702  -20
    arc_0_17_14  connected_order_arc_703  -15
    arc_0_17_14  in_degree_869  1
    arc_0_17_14  out_degree_886  1
    arc_0_17_14  original_T_including_depot_unload_921  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_702  1
    load_0_17_14  free_load_conservation_873  -1
    load_0_17_14  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_704  -20
    arc_0_17_15  connected_order_arc_705  -15
    arc_0_17_15  in_degree_875  1
    arc_0_17_15  out_degree_886  1
    arc_0_17_15  original_T_including_depot_unload_921  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_704  1
    load_0_17_15  free_load_conservation_879  -1
    load_0_17_15  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_706  -20
    arc_0_17_16  connected_order_arc_707  -15
    arc_0_17_16  in_degree_881  1
    arc_0_17_16  out_degree_886  1
    arc_0_17_16  original_T_including_depot_unload_921  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_706  1
    load_0_17_16  free_load_conservation_885  -1
    load_0_17_16  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_708  -20
    arc_0_17_18  connected_order_arc_709  -15
    arc_0_17_18  out_degree_886  1
    arc_0_17_18  in_degree_893  1
    arc_0_17_18  original_T_including_depot_unload_921  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_708  1
    load_0_17_18  free_load_conservation_891  1
    load_0_17_18  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_710  -20
    arc_0_17_19  connected_order_arc_711  -15
    arc_0_17_19  out_degree_886  1
    arc_0_17_19  in_degree_899  1
    arc_0_17_19  original_T_including_depot_unload_921  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_710  1
    load_0_17_19  free_load_conservation_891  1
    load_0_17_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_712  -20
    arc_0_17_20  connected_order_arc_713  -15
    arc_0_17_20  out_degree_886  1
    arc_0_17_20  in_degree_905  1
    arc_0_17_20  original_T_including_depot_unload_921  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_712  1
    load_0_17_20  free_load_conservation_891  1
    load_0_17_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_714  -20
    arc_0_17_21  connected_order_arc_715  -15
    arc_0_17_21  out_degree_886  1
    arc_0_17_21  in_degree_911  1
    arc_0_17_21  original_T_including_depot_unload_921  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_714  1
    load_0_17_21  free_load_conservation_891  1
    load_0_17_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_716  -20
    arc_0_18_0  depot_return_or_bypass_825  1
    arc_0_18_0  out_degree_892  1
    arc_0_18_0  original_T_including_depot_unload_921  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_716  1
    load_0_18_0  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_717  -20
    arc_0_18_1  connected_order_arc_718  -15
    arc_0_18_1  in_degree_827  1
    arc_0_18_1  out_degree_892  1
    arc_0_18_1  original_T_including_depot_unload_921  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_717  1
    load_0_18_1  segment_load_conservation_830  -1
    load_0_18_1  segment_prefix_lb_831  1
    load_0_18_1  segment_prefix_ub_832  1
    load_0_18_1  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_719  -20
    arc_0_18_2  connected_order_arc_720  -15
    arc_0_18_2  in_degree_834  1
    arc_0_18_2  out_degree_892  1
    arc_0_18_2  original_T_including_depot_unload_921  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_719  1
    load_0_18_2  segment_load_conservation_837  -1
    load_0_18_2  segment_prefix_lb_838  1
    load_0_18_2  segment_prefix_ub_839  1
    load_0_18_2  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_721  -20
    arc_0_18_3  connected_order_arc_722  -15
    arc_0_18_3  in_degree_841  1
    arc_0_18_3  out_degree_892  1
    arc_0_18_3  original_T_including_depot_unload_921  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_721  1
    load_0_18_3  segment_load_conservation_844  -1
    load_0_18_3  segment_prefix_lb_845  1
    load_0_18_3  segment_prefix_ub_846  1
    load_0_18_3  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_723  -20
    arc_0_18_4  connected_order_arc_724  -15
    arc_0_18_4  in_degree_848  1
    arc_0_18_4  out_degree_892  1
    arc_0_18_4  original_T_including_depot_unload_921  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_723  1
    load_0_18_4  segment_load_conservation_851  -1
    load_0_18_4  segment_prefix_lb_852  1
    load_0_18_4  segment_prefix_ub_853  1
    load_0_18_4  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_725  -20
    arc_0_18_5  connected_order_arc_726  -15
    arc_0_18_5  in_degree_855  1
    arc_0_18_5  out_degree_892  1
    arc_0_18_5  original_T_including_depot_unload_921  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_725  1
    load_0_18_5  segment_load_conservation_858  -1
    load_0_18_5  segment_prefix_lb_859  1
    load_0_18_5  segment_prefix_ub_860  1
    load_0_18_5  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_727  -20
    arc_0_18_6  connected_order_arc_728  -15
    arc_0_18_6  in_degree_862  1
    arc_0_18_6  out_degree_892  1
    arc_0_18_6  original_T_including_depot_unload_921  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_727  1
    load_0_18_6  segment_load_conservation_865  -1
    load_0_18_6  segment_prefix_lb_866  1
    load_0_18_6  segment_prefix_ub_867  1
    load_0_18_6  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_729  -20
    arc_0_18_14  connected_order_arc_730  -15
    arc_0_18_14  in_degree_869  1
    arc_0_18_14  out_degree_892  1
    arc_0_18_14  original_T_including_depot_unload_921  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_729  1
    load_0_18_14  free_load_conservation_873  -1
    load_0_18_14  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_731  -20
    arc_0_18_15  connected_order_arc_732  -15
    arc_0_18_15  in_degree_875  1
    arc_0_18_15  out_degree_892  1
    arc_0_18_15  original_T_including_depot_unload_921  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_731  1
    load_0_18_15  free_load_conservation_879  -1
    load_0_18_15  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_733  -20
    arc_0_18_16  connected_order_arc_734  -15
    arc_0_18_16  in_degree_881  1
    arc_0_18_16  out_degree_892  1
    arc_0_18_16  original_T_including_depot_unload_921  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_733  1
    load_0_18_16  free_load_conservation_885  -1
    load_0_18_16  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_735  -20
    arc_0_18_17  connected_order_arc_736  -15
    arc_0_18_17  in_degree_887  1
    arc_0_18_17  out_degree_892  1
    arc_0_18_17  original_T_including_depot_unload_921  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_735  1
    load_0_18_17  free_load_conservation_891  -1
    load_0_18_17  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_737  -20
    arc_0_18_19  connected_order_arc_738  -15
    arc_0_18_19  out_degree_892  1
    arc_0_18_19  in_degree_899  1
    arc_0_18_19  original_T_including_depot_unload_921  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_737  1
    load_0_18_19  free_load_conservation_897  1
    load_0_18_19  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_739  -20
    arc_0_18_20  connected_order_arc_740  -15
    arc_0_18_20  out_degree_892  1
    arc_0_18_20  in_degree_905  1
    arc_0_18_20  original_T_including_depot_unload_921  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_739  1
    load_0_18_20  free_load_conservation_897  1
    load_0_18_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_741  -20
    arc_0_18_21  connected_order_arc_742  -15
    arc_0_18_21  out_degree_892  1
    arc_0_18_21  in_degree_911  1
    arc_0_18_21  original_T_including_depot_unload_921  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_741  1
    load_0_18_21  free_load_conservation_897  1
    load_0_18_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_743  -20
    arc_0_19_0  depot_return_or_bypass_825  1
    arc_0_19_0  out_degree_898  1
    arc_0_19_0  original_T_including_depot_unload_921  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_743  1
    load_0_19_0  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_744  -20
    arc_0_19_1  connected_order_arc_745  -15
    arc_0_19_1  in_degree_827  1
    arc_0_19_1  out_degree_898  1
    arc_0_19_1  original_T_including_depot_unload_921  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_744  1
    load_0_19_1  segment_load_conservation_830  -1
    load_0_19_1  segment_prefix_lb_831  1
    load_0_19_1  segment_prefix_ub_832  1
    load_0_19_1  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_746  -20
    arc_0_19_2  connected_order_arc_747  -15
    arc_0_19_2  in_degree_834  1
    arc_0_19_2  out_degree_898  1
    arc_0_19_2  original_T_including_depot_unload_921  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_746  1
    load_0_19_2  segment_load_conservation_837  -1
    load_0_19_2  segment_prefix_lb_838  1
    load_0_19_2  segment_prefix_ub_839  1
    load_0_19_2  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_748  -20
    arc_0_19_3  connected_order_arc_749  -15
    arc_0_19_3  in_degree_841  1
    arc_0_19_3  out_degree_898  1
    arc_0_19_3  original_T_including_depot_unload_921  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_748  1
    load_0_19_3  segment_load_conservation_844  -1
    load_0_19_3  segment_prefix_lb_845  1
    load_0_19_3  segment_prefix_ub_846  1
    load_0_19_3  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_750  -20
    arc_0_19_4  connected_order_arc_751  -15
    arc_0_19_4  in_degree_848  1
    arc_0_19_4  out_degree_898  1
    arc_0_19_4  original_T_including_depot_unload_921  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_750  1
    load_0_19_4  segment_load_conservation_851  -1
    load_0_19_4  segment_prefix_lb_852  1
    load_0_19_4  segment_prefix_ub_853  1
    load_0_19_4  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_752  -20
    arc_0_19_5  connected_order_arc_753  -15
    arc_0_19_5  in_degree_855  1
    arc_0_19_5  out_degree_898  1
    arc_0_19_5  original_T_including_depot_unload_921  1.2087821033682005e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_752  1
    load_0_19_5  segment_load_conservation_858  -1
    load_0_19_5  segment_prefix_lb_859  1
    load_0_19_5  segment_prefix_ub_860  1
    load_0_19_5  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_754  -20
    arc_0_19_6  connected_order_arc_755  -15
    arc_0_19_6  in_degree_862  1
    arc_0_19_6  out_degree_898  1
    arc_0_19_6  original_T_including_depot_unload_921  1.4099802576911704e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_754  1
    load_0_19_6  segment_load_conservation_865  -1
    load_0_19_6  segment_prefix_lb_866  1
    load_0_19_6  segment_prefix_ub_867  1
    load_0_19_6  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_756  -20
    arc_0_19_14  connected_order_arc_757  -15
    arc_0_19_14  in_degree_869  1
    arc_0_19_14  out_degree_898  1
    arc_0_19_14  original_T_including_depot_unload_921  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_756  1
    load_0_19_14  free_load_conservation_873  -1
    load_0_19_14  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_758  -20
    arc_0_19_15  connected_order_arc_759  -15
    arc_0_19_15  in_degree_875  1
    arc_0_19_15  out_degree_898  1
    arc_0_19_15  original_T_including_depot_unload_921  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_758  1
    load_0_19_15  free_load_conservation_879  -1
    load_0_19_15  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_760  -20
    arc_0_19_16  connected_order_arc_761  -15
    arc_0_19_16  in_degree_881  1
    arc_0_19_16  out_degree_898  1
    arc_0_19_16  original_T_including_depot_unload_921  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_760  1
    load_0_19_16  free_load_conservation_885  -1
    load_0_19_16  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_762  -20
    arc_0_19_17  connected_order_arc_763  -15
    arc_0_19_17  in_degree_887  1
    arc_0_19_17  out_degree_898  1
    arc_0_19_17  original_T_including_depot_unload_921  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_762  1
    load_0_19_17  free_load_conservation_891  -1
    load_0_19_17  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_764  -20
    arc_0_19_18  connected_order_arc_765  -15
    arc_0_19_18  in_degree_893  1
    arc_0_19_18  out_degree_898  1
    arc_0_19_18  original_T_including_depot_unload_921  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_764  1
    load_0_19_18  free_load_conservation_897  -1
    load_0_19_18  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_766  -20
    arc_0_19_20  connected_order_arc_767  -15
    arc_0_19_20  out_degree_898  1
    arc_0_19_20  in_degree_905  1
    arc_0_19_20  original_T_including_depot_unload_921  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_766  1
    load_0_19_20  free_load_conservation_903  1
    load_0_19_20  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_768  -20
    arc_0_19_21  connected_order_arc_769  -15
    arc_0_19_21  out_degree_898  1
    arc_0_19_21  in_degree_911  1
    arc_0_19_21  original_T_including_depot_unload_921  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_768  1
    load_0_19_21  free_load_conservation_903  1
    load_0_19_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_770  -20
    arc_0_20_0  depot_return_or_bypass_825  1
    arc_0_20_0  out_degree_904  1
    arc_0_20_0  original_T_including_depot_unload_921  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_770  1
    load_0_20_0  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_771  -20
    arc_0_20_1  connected_order_arc_772  -15
    arc_0_20_1  in_degree_827  1
    arc_0_20_1  out_degree_904  1
    arc_0_20_1  original_T_including_depot_unload_921  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_771  1
    load_0_20_1  segment_load_conservation_830  -1
    load_0_20_1  segment_prefix_lb_831  1
    load_0_20_1  segment_prefix_ub_832  1
    load_0_20_1  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_773  -20
    arc_0_20_2  connected_order_arc_774  -15
    arc_0_20_2  in_degree_834  1
    arc_0_20_2  out_degree_904  1
    arc_0_20_2  original_T_including_depot_unload_921  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_773  1
    load_0_20_2  segment_load_conservation_837  -1
    load_0_20_2  segment_prefix_lb_838  1
    load_0_20_2  segment_prefix_ub_839  1
    load_0_20_2  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_775  -20
    arc_0_20_3  connected_order_arc_776  -15
    arc_0_20_3  in_degree_841  1
    arc_0_20_3  out_degree_904  1
    arc_0_20_3  original_T_including_depot_unload_921  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_775  1
    load_0_20_3  segment_load_conservation_844  -1
    load_0_20_3  segment_prefix_lb_845  1
    load_0_20_3  segment_prefix_ub_846  1
    load_0_20_3  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_777  -20
    arc_0_20_4  connected_order_arc_778  -15
    arc_0_20_4  in_degree_848  1
    arc_0_20_4  out_degree_904  1
    arc_0_20_4  original_T_including_depot_unload_921  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_777  1
    load_0_20_4  segment_load_conservation_851  -1
    load_0_20_4  segment_prefix_lb_852  1
    load_0_20_4  segment_prefix_ub_853  1
    load_0_20_4  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_779  -20
    arc_0_20_5  connected_order_arc_780  -15
    arc_0_20_5  in_degree_855  1
    arc_0_20_5  out_degree_904  1
    arc_0_20_5  original_T_including_depot_unload_921  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_779  1
    load_0_20_5  segment_load_conservation_858  -1
    load_0_20_5  segment_prefix_lb_859  1
    load_0_20_5  segment_prefix_ub_860  1
    load_0_20_5  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_781  -20
    arc_0_20_6  connected_order_arc_782  -15
    arc_0_20_6  in_degree_862  1
    arc_0_20_6  out_degree_904  1
    arc_0_20_6  original_T_including_depot_unload_921  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_781  1
    load_0_20_6  segment_load_conservation_865  -1
    load_0_20_6  segment_prefix_lb_866  1
    load_0_20_6  segment_prefix_ub_867  1
    load_0_20_6  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_783  -20
    arc_0_20_14  connected_order_arc_784  -15
    arc_0_20_14  in_degree_869  1
    arc_0_20_14  out_degree_904  1
    arc_0_20_14  original_T_including_depot_unload_921  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_783  1
    load_0_20_14  free_load_conservation_873  -1
    load_0_20_14  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_785  -20
    arc_0_20_15  connected_order_arc_786  -15
    arc_0_20_15  in_degree_875  1
    arc_0_20_15  out_degree_904  1
    arc_0_20_15  original_T_including_depot_unload_921  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_785  1
    load_0_20_15  free_load_conservation_879  -1
    load_0_20_15  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_787  -20
    arc_0_20_16  connected_order_arc_788  -15
    arc_0_20_16  in_degree_881  1
    arc_0_20_16  out_degree_904  1
    arc_0_20_16  original_T_including_depot_unload_921  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_787  1
    load_0_20_16  free_load_conservation_885  -1
    load_0_20_16  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_789  -20
    arc_0_20_17  connected_order_arc_790  -15
    arc_0_20_17  in_degree_887  1
    arc_0_20_17  out_degree_904  1
    arc_0_20_17  original_T_including_depot_unload_921  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_789  1
    load_0_20_17  free_load_conservation_891  -1
    load_0_20_17  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_791  -20
    arc_0_20_18  connected_order_arc_792  -15
    arc_0_20_18  in_degree_893  1
    arc_0_20_18  out_degree_904  1
    arc_0_20_18  original_T_including_depot_unload_921  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_791  1
    load_0_20_18  free_load_conservation_897  -1
    load_0_20_18  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_793  -20
    arc_0_20_19  connected_order_arc_794  -15
    arc_0_20_19  in_degree_899  1
    arc_0_20_19  out_degree_904  1
    arc_0_20_19  original_T_including_depot_unload_921  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_793  1
    load_0_20_19  free_load_conservation_903  -1
    load_0_20_19  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_795  -20
    arc_0_20_21  connected_order_arc_796  -15
    arc_0_20_21  out_degree_904  1
    arc_0_20_21  in_degree_911  1
    arc_0_20_21  original_T_including_depot_unload_921  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_795  1
    load_0_20_21  free_load_conservation_909  1
    load_0_20_21  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_797  -20
    arc_0_21_0  depot_return_or_bypass_825  1
    arc_0_21_0  out_degree_910  1
    arc_0_21_0  original_T_including_depot_unload_921  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_797  1
    load_0_21_0  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_798  -20
    arc_0_21_1  connected_order_arc_799  -15
    arc_0_21_1  in_degree_827  1
    arc_0_21_1  out_degree_910  1
    arc_0_21_1  original_T_including_depot_unload_921  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_798  1
    load_0_21_1  segment_load_conservation_830  -1
    load_0_21_1  segment_prefix_lb_831  1
    load_0_21_1  segment_prefix_ub_832  1
    load_0_21_1  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_800  -20
    arc_0_21_2  connected_order_arc_801  -15
    arc_0_21_2  in_degree_834  1
    arc_0_21_2  out_degree_910  1
    arc_0_21_2  original_T_including_depot_unload_921  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_800  1
    load_0_21_2  segment_load_conservation_837  -1
    load_0_21_2  segment_prefix_lb_838  1
    load_0_21_2  segment_prefix_ub_839  1
    load_0_21_2  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_802  -20
    arc_0_21_3  connected_order_arc_803  -15
    arc_0_21_3  in_degree_841  1
    arc_0_21_3  out_degree_910  1
    arc_0_21_3  original_T_including_depot_unload_921  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_802  1
    load_0_21_3  segment_load_conservation_844  -1
    load_0_21_3  segment_prefix_lb_845  1
    load_0_21_3  segment_prefix_ub_846  1
    load_0_21_3  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_804  -20
    arc_0_21_4  connected_order_arc_805  -15
    arc_0_21_4  in_degree_848  1
    arc_0_21_4  out_degree_910  1
    arc_0_21_4  original_T_including_depot_unload_921  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_804  1
    load_0_21_4  segment_load_conservation_851  -1
    load_0_21_4  segment_prefix_lb_852  1
    load_0_21_4  segment_prefix_ub_853  1
    load_0_21_4  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_806  -20
    arc_0_21_5  connected_order_arc_807  -15
    arc_0_21_5  in_degree_855  1
    arc_0_21_5  out_degree_910  1
    arc_0_21_5  original_T_including_depot_unload_921  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_806  1
    load_0_21_5  segment_load_conservation_858  -1
    load_0_21_5  segment_prefix_lb_859  1
    load_0_21_5  segment_prefix_ub_860  1
    load_0_21_5  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_808  -20
    arc_0_21_6  connected_order_arc_809  -15
    arc_0_21_6  in_degree_862  1
    arc_0_21_6  out_degree_910  1
    arc_0_21_6  original_T_including_depot_unload_921  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_808  1
    load_0_21_6  segment_load_conservation_865  -1
    load_0_21_6  segment_prefix_lb_866  1
    load_0_21_6  segment_prefix_ub_867  1
    load_0_21_6  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_810  -20
    arc_0_21_14  connected_order_arc_811  -15
    arc_0_21_14  in_degree_869  1
    arc_0_21_14  out_degree_910  1
    arc_0_21_14  original_T_including_depot_unload_921  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_810  1
    load_0_21_14  free_load_conservation_873  -1
    load_0_21_14  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_812  -20
    arc_0_21_15  connected_order_arc_813  -15
    arc_0_21_15  in_degree_875  1
    arc_0_21_15  out_degree_910  1
    arc_0_21_15  original_T_including_depot_unload_921  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_812  1
    load_0_21_15  free_load_conservation_879  -1
    load_0_21_15  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_814  -20
    arc_0_21_16  connected_order_arc_815  -15
    arc_0_21_16  in_degree_881  1
    arc_0_21_16  out_degree_910  1
    arc_0_21_16  original_T_including_depot_unload_921  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_814  1
    load_0_21_16  free_load_conservation_885  -1
    load_0_21_16  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_816  -20
    arc_0_21_17  connected_order_arc_817  -15
    arc_0_21_17  in_degree_887  1
    arc_0_21_17  out_degree_910  1
    arc_0_21_17  original_T_including_depot_unload_921  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_816  1
    load_0_21_17  free_load_conservation_891  -1
    load_0_21_17  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_818  -20
    arc_0_21_18  connected_order_arc_819  -15
    arc_0_21_18  in_degree_893  1
    arc_0_21_18  out_degree_910  1
    arc_0_21_18  original_T_including_depot_unload_921  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_818  1
    load_0_21_18  free_load_conservation_897  -1
    load_0_21_18  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_820  -20
    arc_0_21_19  connected_order_arc_821  -15
    arc_0_21_19  in_degree_899  1
    arc_0_21_19  out_degree_910  1
    arc_0_21_19  original_T_including_depot_unload_921  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_820  1
    load_0_21_19  free_load_conservation_903  -1
    load_0_21_19  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_822  -20
    arc_0_21_20  connected_order_arc_823  -15
    arc_0_21_20  in_degree_905  1
    arc_0_21_20  out_degree_910  1
    arc_0_21_20  original_T_including_depot_unload_921  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_822  1
    load_0_21_20  free_load_conservation_909  -1
    load_0_21_20  free_load_conservation_915  1
    visit_1_7  out_degree_1213  -1
    visit_1_7  in_degree_1214  -1
    visit_1_7  order_active_lb_1215  -1
    visit_1_7  order_active_ub_1216  -12
    order_1_7  connected_order_arc_937  -1
    order_1_7  connected_order_arc_939  -1
    order_1_7  connected_order_arc_941  -1
    order_1_7  connected_order_arc_943  -1
    order_1_7  connected_order_arc_945  -1
    order_1_7  connected_order_arc_947  -1
    order_1_7  connected_order_arc_949  -1
    order_1_7  connected_order_arc_951  -1
    order_1_7  connected_order_arc_953  -1
    order_1_7  connected_order_arc_955  -1
    order_1_7  connected_order_arc_957  -1
    order_1_7  connected_order_arc_960  1
    order_1_7  connected_order_arc_983  1
    order_1_7  connected_order_arc_1006  1
    order_1_7  connected_order_arc_1029  1
    order_1_7  connected_order_arc_1052  1
    order_1_7  connected_order_arc_1075  1
    order_1_7  connected_order_arc_1098  1
    order_1_7  connected_order_arc_1121  1
    order_1_7  connected_order_arc_1144  1
    order_1_7  connected_order_arc_1167  1
    order_1_7  connected_order_arc_1190  1
    order_1_7  order_active_lb_1215  1
    order_1_7  order_active_ub_1216  1
    order_1_7  fixed_segment_relative_order_1289  -1
    visit_1_8  out_degree_1220  -1
    visit_1_8  in_degree_1221  -1
    visit_1_8  order_active_lb_1222  -1
    visit_1_8  order_active_ub_1223  -12
    order_1_8  connected_order_arc_937  1
    order_1_8  connected_order_arc_960  -1
    order_1_8  connected_order_arc_962  -1
    order_1_8  connected_order_arc_964  -1
    order_1_8  connected_order_arc_966  -1
    order_1_8  connected_order_arc_968  -1
    order_1_8  connected_order_arc_970  -1
    order_1_8  connected_order_arc_972  -1
    order_1_8  connected_order_arc_974  -1
    order_1_8  connected_order_arc_976  -1
    order_1_8  connected_order_arc_978  -1
    order_1_8  connected_order_arc_980  -1
    order_1_8  connected_order_arc_985  1
    order_1_8  connected_order_arc_1008  1
    order_1_8  connected_order_arc_1031  1
    order_1_8  connected_order_arc_1054  1
    order_1_8  connected_order_arc_1077  1
    order_1_8  connected_order_arc_1100  1
    order_1_8  connected_order_arc_1123  1
    order_1_8  connected_order_arc_1146  1
    order_1_8  connected_order_arc_1169  1
    order_1_8  connected_order_arc_1192  1
    order_1_8  order_active_lb_1222  1
    order_1_8  order_active_ub_1223  1
    order_1_8  fixed_segment_relative_order_1289  1
    order_1_8  fixed_segment_relative_order_1290  -1
    visit_1_9  out_degree_1227  -1
    visit_1_9  in_degree_1228  -1
    visit_1_9  order_active_lb_1229  -1
    visit_1_9  order_active_ub_1230  -12
    order_1_9  connected_order_arc_939  1
    order_1_9  connected_order_arc_962  1
    order_1_9  connected_order_arc_983  -1
    order_1_9  connected_order_arc_985  -1
    order_1_9  connected_order_arc_987  -1
    order_1_9  connected_order_arc_989  -1
    order_1_9  connected_order_arc_991  -1
    order_1_9  connected_order_arc_993  -1
    order_1_9  connected_order_arc_995  -1
    order_1_9  connected_order_arc_997  -1
    order_1_9  connected_order_arc_999  -1
    order_1_9  connected_order_arc_1001  -1
    order_1_9  connected_order_arc_1003  -1
    order_1_9  connected_order_arc_1010  1
    order_1_9  connected_order_arc_1033  1
    order_1_9  connected_order_arc_1056  1
    order_1_9  connected_order_arc_1079  1
    order_1_9  connected_order_arc_1102  1
    order_1_9  connected_order_arc_1125  1
    order_1_9  connected_order_arc_1148  1
    order_1_9  connected_order_arc_1171  1
    order_1_9  connected_order_arc_1194  1
    order_1_9  order_active_lb_1229  1
    order_1_9  order_active_ub_1230  1
    order_1_9  fixed_segment_relative_order_1290  1
    order_1_9  fixed_segment_relative_order_1291  -1
    visit_1_10  out_degree_1234  -1
    visit_1_10  in_degree_1235  -1
    visit_1_10  order_active_lb_1236  -1
    visit_1_10  order_active_ub_1237  -12
    order_1_10  connected_order_arc_941  1
    order_1_10  connected_order_arc_964  1
    order_1_10  connected_order_arc_987  1
    order_1_10  connected_order_arc_1006  -1
    order_1_10  connected_order_arc_1008  -1
    order_1_10  connected_order_arc_1010  -1
    order_1_10  connected_order_arc_1012  -1
    order_1_10  connected_order_arc_1014  -1
    order_1_10  connected_order_arc_1016  -1
    order_1_10  connected_order_arc_1018  -1
    order_1_10  connected_order_arc_1020  -1
    order_1_10  connected_order_arc_1022  -1
    order_1_10  connected_order_arc_1024  -1
    order_1_10  connected_order_arc_1026  -1
    order_1_10  connected_order_arc_1035  1
    order_1_10  connected_order_arc_1058  1
    order_1_10  connected_order_arc_1081  1
    order_1_10  connected_order_arc_1104  1
    order_1_10  connected_order_arc_1127  1
    order_1_10  connected_order_arc_1150  1
    order_1_10  connected_order_arc_1173  1
    order_1_10  connected_order_arc_1196  1
    order_1_10  order_active_lb_1236  1
    order_1_10  order_active_ub_1237  1
    order_1_10  fixed_segment_relative_order_1291  1
    visit_1_14  out_degree_1241  -1
    visit_1_14  in_degree_1242  -1
    visit_1_14  order_active_lb_1243  -1
    visit_1_14  order_active_ub_1244  -12
    visit_1_14  service_visit_def_1245  -1
    order_1_14  connected_order_arc_943  1
    order_1_14  connected_order_arc_966  1
    order_1_14  connected_order_arc_989  1
    order_1_14  connected_order_arc_1012  1
    order_1_14  connected_order_arc_1029  -1
    order_1_14  connected_order_arc_1031  -1
    order_1_14  connected_order_arc_1033  -1
    order_1_14  connected_order_arc_1035  -1
    order_1_14  connected_order_arc_1037  -1
    order_1_14  connected_order_arc_1039  -1
    order_1_14  connected_order_arc_1041  -1
    order_1_14  connected_order_arc_1043  -1
    order_1_14  connected_order_arc_1045  -1
    order_1_14  connected_order_arc_1047  -1
    order_1_14  connected_order_arc_1049  -1
    order_1_14  connected_order_arc_1060  1
    order_1_14  connected_order_arc_1083  1
    order_1_14  connected_order_arc_1106  1
    order_1_14  connected_order_arc_1129  1
    order_1_14  connected_order_arc_1152  1
    order_1_14  connected_order_arc_1175  1
    order_1_14  connected_order_arc_1198  1
    order_1_14  order_active_lb_1243  1
    order_1_14  order_active_ub_1244  1
    visit_1_15  out_degree_1247  -1
    visit_1_15  in_degree_1248  -1
    visit_1_15  order_active_lb_1249  -1
    visit_1_15  order_active_ub_1250  -12
    visit_1_15  service_visit_def_1251  -1
    order_1_15  connected_order_arc_945  1
    order_1_15  connected_order_arc_968  1
    order_1_15  connected_order_arc_991  1
    order_1_15  connected_order_arc_1014  1
    order_1_15  connected_order_arc_1037  1
    order_1_15  connected_order_arc_1052  -1
    order_1_15  connected_order_arc_1054  -1
    order_1_15  connected_order_arc_1056  -1
    order_1_15  connected_order_arc_1058  -1
    order_1_15  connected_order_arc_1060  -1
    order_1_15  connected_order_arc_1062  -1
    order_1_15  connected_order_arc_1064  -1
    order_1_15  connected_order_arc_1066  -1
    order_1_15  connected_order_arc_1068  -1
    order_1_15  connected_order_arc_1070  -1
    order_1_15  connected_order_arc_1072  -1
    order_1_15  connected_order_arc_1085  1
    order_1_15  connected_order_arc_1108  1
    order_1_15  connected_order_arc_1131  1
    order_1_15  connected_order_arc_1154  1
    order_1_15  connected_order_arc_1177  1
    order_1_15  connected_order_arc_1200  1
    order_1_15  order_active_lb_1249  1
    order_1_15  order_active_ub_1250  1
    visit_1_16  out_degree_1253  -1
    visit_1_16  in_degree_1254  -1
    visit_1_16  order_active_lb_1255  -1
    visit_1_16  order_active_ub_1256  -12
    visit_1_16  service_visit_def_1257  -1
    order_1_16  connected_order_arc_947  1
    order_1_16  connected_order_arc_970  1
    order_1_16  connected_order_arc_993  1
    order_1_16  connected_order_arc_1016  1
    order_1_16  connected_order_arc_1039  1
    order_1_16  connected_order_arc_1062  1
    order_1_16  connected_order_arc_1075  -1
    order_1_16  connected_order_arc_1077  -1
    order_1_16  connected_order_arc_1079  -1
    order_1_16  connected_order_arc_1081  -1
    order_1_16  connected_order_arc_1083  -1
    order_1_16  connected_order_arc_1085  -1
    order_1_16  connected_order_arc_1087  -1
    order_1_16  connected_order_arc_1089  -1
    order_1_16  connected_order_arc_1091  -1
    order_1_16  connected_order_arc_1093  -1
    order_1_16  connected_order_arc_1095  -1
    order_1_16  connected_order_arc_1110  1
    order_1_16  connected_order_arc_1133  1
    order_1_16  connected_order_arc_1156  1
    order_1_16  connected_order_arc_1179  1
    order_1_16  connected_order_arc_1202  1
    order_1_16  order_active_lb_1255  1
    order_1_16  order_active_ub_1256  1
    visit_1_17  out_degree_1259  -1
    visit_1_17  in_degree_1260  -1
    visit_1_17  order_active_lb_1261  -1
    visit_1_17  order_active_ub_1262  -12
    visit_1_17  service_visit_def_1263  -1
    order_1_17  connected_order_arc_949  1
    order_1_17  connected_order_arc_972  1
    order_1_17  connected_order_arc_995  1
    order_1_17  connected_order_arc_1018  1
    order_1_17  connected_order_arc_1041  1
    order_1_17  connected_order_arc_1064  1
    order_1_17  connected_order_arc_1087  1
    order_1_17  connected_order_arc_1098  -1
    order_1_17  connected_order_arc_1100  -1
    order_1_17  connected_order_arc_1102  -1
    order_1_17  connected_order_arc_1104  -1
    order_1_17  connected_order_arc_1106  -1
    order_1_17  connected_order_arc_1108  -1
    order_1_17  connected_order_arc_1110  -1
    order_1_17  connected_order_arc_1112  -1
    order_1_17  connected_order_arc_1114  -1
    order_1_17  connected_order_arc_1116  -1
    order_1_17  connected_order_arc_1118  -1
    order_1_17  connected_order_arc_1135  1
    order_1_17  connected_order_arc_1158  1
    order_1_17  connected_order_arc_1181  1
    order_1_17  connected_order_arc_1204  1
    order_1_17  order_active_lb_1261  1
    order_1_17  order_active_ub_1262  1
    visit_1_18  out_degree_1265  -1
    visit_1_18  in_degree_1266  -1
    visit_1_18  order_active_lb_1267  -1
    visit_1_18  order_active_ub_1268  -12
    visit_1_18  service_visit_def_1269  -1
    order_1_18  connected_order_arc_951  1
    order_1_18  connected_order_arc_974  1
    order_1_18  connected_order_arc_997  1
    order_1_18  connected_order_arc_1020  1
    order_1_18  connected_order_arc_1043  1
    order_1_18  connected_order_arc_1066  1
    order_1_18  connected_order_arc_1089  1
    order_1_18  connected_order_arc_1112  1
    order_1_18  connected_order_arc_1121  -1
    order_1_18  connected_order_arc_1123  -1
    order_1_18  connected_order_arc_1125  -1
    order_1_18  connected_order_arc_1127  -1
    order_1_18  connected_order_arc_1129  -1
    order_1_18  connected_order_arc_1131  -1
    order_1_18  connected_order_arc_1133  -1
    order_1_18  connected_order_arc_1135  -1
    order_1_18  connected_order_arc_1137  -1
    order_1_18  connected_order_arc_1139  -1
    order_1_18  connected_order_arc_1141  -1
    order_1_18  connected_order_arc_1160  1
    order_1_18  connected_order_arc_1183  1
    order_1_18  connected_order_arc_1206  1
    order_1_18  order_active_lb_1267  1
    order_1_18  order_active_ub_1268  1
    visit_1_19  out_degree_1271  -1
    visit_1_19  in_degree_1272  -1
    visit_1_19  order_active_lb_1273  -1
    visit_1_19  order_active_ub_1274  -12
    visit_1_19  service_visit_def_1275  -1
    order_1_19  connected_order_arc_953  1
    order_1_19  connected_order_arc_976  1
    order_1_19  connected_order_arc_999  1
    order_1_19  connected_order_arc_1022  1
    order_1_19  connected_order_arc_1045  1
    order_1_19  connected_order_arc_1068  1
    order_1_19  connected_order_arc_1091  1
    order_1_19  connected_order_arc_1114  1
    order_1_19  connected_order_arc_1137  1
    order_1_19  connected_order_arc_1144  -1
    order_1_19  connected_order_arc_1146  -1
    order_1_19  connected_order_arc_1148  -1
    order_1_19  connected_order_arc_1150  -1
    order_1_19  connected_order_arc_1152  -1
    order_1_19  connected_order_arc_1154  -1
    order_1_19  connected_order_arc_1156  -1
    order_1_19  connected_order_arc_1158  -1
    order_1_19  connected_order_arc_1160  -1
    order_1_19  connected_order_arc_1162  -1
    order_1_19  connected_order_arc_1164  -1
    order_1_19  connected_order_arc_1185  1
    order_1_19  connected_order_arc_1208  1
    order_1_19  order_active_lb_1273  1
    order_1_19  order_active_ub_1274  1
    visit_1_20  out_degree_1277  -1
    visit_1_20  in_degree_1278  -1
    visit_1_20  order_active_lb_1279  -1
    visit_1_20  order_active_ub_1280  -12
    visit_1_20  service_visit_def_1281  -1
    order_1_20  connected_order_arc_955  1
    order_1_20  connected_order_arc_978  1
    order_1_20  connected_order_arc_1001  1
    order_1_20  connected_order_arc_1024  1
    order_1_20  connected_order_arc_1047  1
    order_1_20  connected_order_arc_1070  1
    order_1_20  connected_order_arc_1093  1
    order_1_20  connected_order_arc_1116  1
    order_1_20  connected_order_arc_1139  1
    order_1_20  connected_order_arc_1162  1
    order_1_20  connected_order_arc_1167  -1
    order_1_20  connected_order_arc_1169  -1
    order_1_20  connected_order_arc_1171  -1
    order_1_20  connected_order_arc_1173  -1
    order_1_20  connected_order_arc_1175  -1
    order_1_20  connected_order_arc_1177  -1
    order_1_20  connected_order_arc_1179  -1
    order_1_20  connected_order_arc_1181  -1
    order_1_20  connected_order_arc_1183  -1
    order_1_20  connected_order_arc_1185  -1
    order_1_20  connected_order_arc_1187  -1
    order_1_20  connected_order_arc_1210  1
    order_1_20  order_active_lb_1279  1
    order_1_20  order_active_ub_1280  1
    visit_1_21  out_degree_1283  -1
    visit_1_21  in_degree_1284  -1
    visit_1_21  order_active_lb_1285  -1
    visit_1_21  order_active_ub_1286  -12
    visit_1_21  service_visit_def_1287  -1
    order_1_21  connected_order_arc_957  1
    order_1_21  connected_order_arc_980  1
    order_1_21  connected_order_arc_1003  1
    order_1_21  connected_order_arc_1026  1
    order_1_21  connected_order_arc_1049  1
    order_1_21  connected_order_arc_1072  1
    order_1_21  connected_order_arc_1095  1
    order_1_21  connected_order_arc_1118  1
    order_1_21  connected_order_arc_1141  1
    order_1_21  connected_order_arc_1164  1
    order_1_21  connected_order_arc_1187  1
    order_1_21  connected_order_arc_1190  -1
    order_1_21  connected_order_arc_1192  -1
    order_1_21  connected_order_arc_1194  -1
    order_1_21  connected_order_arc_1196  -1
    order_1_21  connected_order_arc_1198  -1
    order_1_21  connected_order_arc_1200  -1
    order_1_21  connected_order_arc_1202  -1
    order_1_21  connected_order_arc_1204  -1
    order_1_21  connected_order_arc_1206  -1
    order_1_21  connected_order_arc_1208  -1
    order_1_21  connected_order_arc_1210  -1
    order_1_21  order_active_lb_1285  1
    order_1_21  order_active_ub_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_922  -25
    arc_1_0_0  depot_departure_or_bypass_1211  1
    arc_1_0_0  depot_return_or_bypass_1212  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_922  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_923  -25
    arc_1_0_7  depot_departure_or_bypass_1211  1
    arc_1_0_7  in_degree_1214  1
    arc_1_0_7  original_T_including_depot_unload_1292  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_923  1
    load_1_0_7  segment_load_conservation_1217  -1
    load_1_0_7  segment_prefix_lb_1218  1
    load_1_0_7  segment_prefix_ub_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_924  -25
    arc_1_0_8  depot_departure_or_bypass_1211  1
    arc_1_0_8  in_degree_1221  1
    arc_1_0_8  original_T_including_depot_unload_1292  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_924  1
    load_1_0_8  segment_load_conservation_1224  -1
    load_1_0_8  segment_prefix_lb_1225  1
    load_1_0_8  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_925  -25
    arc_1_0_9  depot_departure_or_bypass_1211  1
    arc_1_0_9  in_degree_1228  1
    arc_1_0_9  original_T_including_depot_unload_1292  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_925  1
    load_1_0_9  segment_load_conservation_1231  -1
    load_1_0_9  segment_prefix_lb_1232  1
    load_1_0_9  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_926  -25
    arc_1_0_10  depot_departure_or_bypass_1211  1
    arc_1_0_10  in_degree_1235  1
    arc_1_0_10  original_T_including_depot_unload_1292  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_926  1
    load_1_0_10  segment_load_conservation_1238  -1
    load_1_0_10  segment_prefix_lb_1239  1
    load_1_0_10  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_927  -25
    arc_1_0_14  depot_departure_or_bypass_1211  1
    arc_1_0_14  in_degree_1242  1
    arc_1_0_14  original_T_including_depot_unload_1292  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_927  1
    load_1_0_14  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_928  -25
    arc_1_0_15  depot_departure_or_bypass_1211  1
    arc_1_0_15  in_degree_1248  1
    arc_1_0_15  original_T_including_depot_unload_1292  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_928  1
    load_1_0_15  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_929  -25
    arc_1_0_16  depot_departure_or_bypass_1211  1
    arc_1_0_16  in_degree_1254  1
    arc_1_0_16  original_T_including_depot_unload_1292  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_929  1
    load_1_0_16  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_930  -25
    arc_1_0_17  depot_departure_or_bypass_1211  1
    arc_1_0_17  in_degree_1260  1
    arc_1_0_17  original_T_including_depot_unload_1292  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_930  1
    load_1_0_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_931  -25
    arc_1_0_18  depot_departure_or_bypass_1211  1
    arc_1_0_18  in_degree_1266  1
    arc_1_0_18  original_T_including_depot_unload_1292  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_931  1
    load_1_0_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_932  -25
    arc_1_0_19  depot_departure_or_bypass_1211  1
    arc_1_0_19  in_degree_1272  1
    arc_1_0_19  original_T_including_depot_unload_1292  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_932  1
    load_1_0_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_933  -25
    arc_1_0_20  depot_departure_or_bypass_1211  1
    arc_1_0_20  in_degree_1278  1
    arc_1_0_20  original_T_including_depot_unload_1292  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_933  1
    load_1_0_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_934  -25
    arc_1_0_21  depot_departure_or_bypass_1211  1
    arc_1_0_21  in_degree_1284  1
    arc_1_0_21  original_T_including_depot_unload_1292  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_934  1
    load_1_0_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_935  -25
    arc_1_7_0  depot_return_or_bypass_1212  1
    arc_1_7_0  out_degree_1213  1
    arc_1_7_0  original_T_including_depot_unload_1292  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_935  1
    load_1_7_0  segment_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_936  -25
    arc_1_7_8  connected_order_arc_937  -13
    arc_1_7_8  out_degree_1213  1
    arc_1_7_8  in_degree_1221  1
    arc_1_7_8  original_T_including_depot_unload_1292  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_936  1
    load_1_7_8  segment_load_conservation_1217  1
    load_1_7_8  segment_load_conservation_1224  -1
    load_1_7_8  segment_prefix_lb_1225  1
    load_1_7_8  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_938  -25
    arc_1_7_9  connected_order_arc_939  -13
    arc_1_7_9  out_degree_1213  1
    arc_1_7_9  in_degree_1228  1
    arc_1_7_9  original_T_including_depot_unload_1292  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_938  1
    load_1_7_9  segment_load_conservation_1217  1
    load_1_7_9  segment_load_conservation_1231  -1
    load_1_7_9  segment_prefix_lb_1232  1
    load_1_7_9  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_940  -25
    arc_1_7_10  connected_order_arc_941  -13
    arc_1_7_10  out_degree_1213  1
    arc_1_7_10  in_degree_1235  1
    arc_1_7_10  original_T_including_depot_unload_1292  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_940  1
    load_1_7_10  segment_load_conservation_1217  1
    load_1_7_10  segment_load_conservation_1238  -1
    load_1_7_10  segment_prefix_lb_1239  1
    load_1_7_10  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_942  -25
    arc_1_7_14  connected_order_arc_943  -13
    arc_1_7_14  out_degree_1213  1
    arc_1_7_14  in_degree_1242  1
    arc_1_7_14  original_T_including_depot_unload_1292  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_942  1
    load_1_7_14  segment_load_conservation_1217  1
    load_1_7_14  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_944  -25
    arc_1_7_15  connected_order_arc_945  -13
    arc_1_7_15  out_degree_1213  1
    arc_1_7_15  in_degree_1248  1
    arc_1_7_15  original_T_including_depot_unload_1292  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_944  1
    load_1_7_15  segment_load_conservation_1217  1
    load_1_7_15  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_946  -25
    arc_1_7_16  connected_order_arc_947  -13
    arc_1_7_16  out_degree_1213  1
    arc_1_7_16  in_degree_1254  1
    arc_1_7_16  original_T_including_depot_unload_1292  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_946  1
    load_1_7_16  segment_load_conservation_1217  1
    load_1_7_16  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_948  -25
    arc_1_7_17  connected_order_arc_949  -13
    arc_1_7_17  out_degree_1213  1
    arc_1_7_17  in_degree_1260  1
    arc_1_7_17  original_T_including_depot_unload_1292  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_948  1
    load_1_7_17  segment_load_conservation_1217  1
    load_1_7_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_950  -25
    arc_1_7_18  connected_order_arc_951  -13
    arc_1_7_18  out_degree_1213  1
    arc_1_7_18  in_degree_1266  1
    arc_1_7_18  original_T_including_depot_unload_1292  1.2814005706654932e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_950  1
    load_1_7_18  segment_load_conservation_1217  1
    load_1_7_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_952  -25
    arc_1_7_19  connected_order_arc_953  -13
    arc_1_7_19  out_degree_1213  1
    arc_1_7_19  in_degree_1272  1
    arc_1_7_19  original_T_including_depot_unload_1292  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_952  1
    load_1_7_19  segment_load_conservation_1217  1
    load_1_7_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_954  -25
    arc_1_7_20  connected_order_arc_955  -13
    arc_1_7_20  out_degree_1213  1
    arc_1_7_20  in_degree_1278  1
    arc_1_7_20  original_T_including_depot_unload_1292  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_954  1
    load_1_7_20  segment_load_conservation_1217  1
    load_1_7_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_956  -25
    arc_1_7_21  connected_order_arc_957  -13
    arc_1_7_21  out_degree_1213  1
    arc_1_7_21  in_degree_1284  1
    arc_1_7_21  original_T_including_depot_unload_1292  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_956  1
    load_1_7_21  segment_load_conservation_1217  1
    load_1_7_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_958  -25
    arc_1_8_0  depot_return_or_bypass_1212  1
    arc_1_8_0  out_degree_1220  1
    arc_1_8_0  original_T_including_depot_unload_1292  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_958  1
    load_1_8_0  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_959  -25
    arc_1_8_7  connected_order_arc_960  -13
    arc_1_8_7  in_degree_1214  1
    arc_1_8_7  out_degree_1220  1
    arc_1_8_7  original_T_including_depot_unload_1292  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_959  1
    load_1_8_7  segment_load_conservation_1217  -1
    load_1_8_7  segment_prefix_lb_1218  1
    load_1_8_7  segment_prefix_ub_1219  1
    load_1_8_7  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_961  -25
    arc_1_8_9  connected_order_arc_962  -13
    arc_1_8_9  out_degree_1220  1
    arc_1_8_9  in_degree_1228  1
    arc_1_8_9  original_T_including_depot_unload_1292  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_961  1
    load_1_8_9  segment_load_conservation_1224  1
    load_1_8_9  segment_load_conservation_1231  -1
    load_1_8_9  segment_prefix_lb_1232  1
    load_1_8_9  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_963  -25
    arc_1_8_10  connected_order_arc_964  -13
    arc_1_8_10  out_degree_1220  1
    arc_1_8_10  in_degree_1235  1
    arc_1_8_10  original_T_including_depot_unload_1292  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_963  1
    load_1_8_10  segment_load_conservation_1224  1
    load_1_8_10  segment_load_conservation_1238  -1
    load_1_8_10  segment_prefix_lb_1239  1
    load_1_8_10  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_965  -25
    arc_1_8_14  connected_order_arc_966  -13
    arc_1_8_14  out_degree_1220  1
    arc_1_8_14  in_degree_1242  1
    arc_1_8_14  original_T_including_depot_unload_1292  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_965  1
    load_1_8_14  segment_load_conservation_1224  1
    load_1_8_14  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_967  -25
    arc_1_8_15  connected_order_arc_968  -13
    arc_1_8_15  out_degree_1220  1
    arc_1_8_15  in_degree_1248  1
    arc_1_8_15  original_T_including_depot_unload_1292  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_967  1
    load_1_8_15  segment_load_conservation_1224  1
    load_1_8_15  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_969  -25
    arc_1_8_16  connected_order_arc_970  -13
    arc_1_8_16  out_degree_1220  1
    arc_1_8_16  in_degree_1254  1
    arc_1_8_16  original_T_including_depot_unload_1292  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_969  1
    load_1_8_16  segment_load_conservation_1224  1
    load_1_8_16  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_971  -25
    arc_1_8_17  connected_order_arc_972  -13
    arc_1_8_17  out_degree_1220  1
    arc_1_8_17  in_degree_1260  1
    arc_1_8_17  original_T_including_depot_unload_1292  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_971  1
    load_1_8_17  segment_load_conservation_1224  1
    load_1_8_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_973  -25
    arc_1_8_18  connected_order_arc_974  -13
    arc_1_8_18  out_degree_1220  1
    arc_1_8_18  in_degree_1266  1
    arc_1_8_18  original_T_including_depot_unload_1292  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_973  1
    load_1_8_18  segment_load_conservation_1224  1
    load_1_8_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_975  -25
    arc_1_8_19  connected_order_arc_976  -13
    arc_1_8_19  out_degree_1220  1
    arc_1_8_19  in_degree_1272  1
    arc_1_8_19  original_T_including_depot_unload_1292  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_975  1
    load_1_8_19  segment_load_conservation_1224  1
    load_1_8_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_977  -25
    arc_1_8_20  connected_order_arc_978  -13
    arc_1_8_20  out_degree_1220  1
    arc_1_8_20  in_degree_1278  1
    arc_1_8_20  original_T_including_depot_unload_1292  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_977  1
    load_1_8_20  segment_load_conservation_1224  1
    load_1_8_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_979  -25
    arc_1_8_21  connected_order_arc_980  -13
    arc_1_8_21  out_degree_1220  1
    arc_1_8_21  in_degree_1284  1
    arc_1_8_21  original_T_including_depot_unload_1292  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_979  1
    load_1_8_21  segment_load_conservation_1224  1
    load_1_8_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_981  -25
    arc_1_9_0  depot_return_or_bypass_1212  1
    arc_1_9_0  out_degree_1227  1
    arc_1_9_0  original_T_including_depot_unload_1292  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_981  1
    load_1_9_0  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_982  -25
    arc_1_9_7  connected_order_arc_983  -13
    arc_1_9_7  in_degree_1214  1
    arc_1_9_7  out_degree_1227  1
    arc_1_9_7  original_T_including_depot_unload_1292  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_982  1
    load_1_9_7  segment_load_conservation_1217  -1
    load_1_9_7  segment_prefix_lb_1218  1
    load_1_9_7  segment_prefix_ub_1219  1
    load_1_9_7  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_984  -25
    arc_1_9_8  connected_order_arc_985  -13
    arc_1_9_8  in_degree_1221  1
    arc_1_9_8  out_degree_1227  1
    arc_1_9_8  original_T_including_depot_unload_1292  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_984  1
    load_1_9_8  segment_load_conservation_1224  -1
    load_1_9_8  segment_prefix_lb_1225  1
    load_1_9_8  segment_prefix_ub_1226  1
    load_1_9_8  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_986  -25
    arc_1_9_10  connected_order_arc_987  -13
    arc_1_9_10  out_degree_1227  1
    arc_1_9_10  in_degree_1235  1
    arc_1_9_10  original_T_including_depot_unload_1292  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_986  1
    load_1_9_10  segment_load_conservation_1231  1
    load_1_9_10  segment_load_conservation_1238  -1
    load_1_9_10  segment_prefix_lb_1239  1
    load_1_9_10  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_988  -25
    arc_1_9_14  connected_order_arc_989  -13
    arc_1_9_14  out_degree_1227  1
    arc_1_9_14  in_degree_1242  1
    arc_1_9_14  original_T_including_depot_unload_1292  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_988  1
    load_1_9_14  segment_load_conservation_1231  1
    load_1_9_14  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_990  -25
    arc_1_9_15  connected_order_arc_991  -13
    arc_1_9_15  out_degree_1227  1
    arc_1_9_15  in_degree_1248  1
    arc_1_9_15  original_T_including_depot_unload_1292  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_990  1
    load_1_9_15  segment_load_conservation_1231  1
    load_1_9_15  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_992  -25
    arc_1_9_16  connected_order_arc_993  -13
    arc_1_9_16  out_degree_1227  1
    arc_1_9_16  in_degree_1254  1
    arc_1_9_16  original_T_including_depot_unload_1292  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_992  1
    load_1_9_16  segment_load_conservation_1231  1
    load_1_9_16  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_994  -25
    arc_1_9_17  connected_order_arc_995  -13
    arc_1_9_17  out_degree_1227  1
    arc_1_9_17  in_degree_1260  1
    arc_1_9_17  original_T_including_depot_unload_1292  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_994  1
    load_1_9_17  segment_load_conservation_1231  1
    load_1_9_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_996  -25
    arc_1_9_18  connected_order_arc_997  -13
    arc_1_9_18  out_degree_1227  1
    arc_1_9_18  in_degree_1266  1
    arc_1_9_18  original_T_including_depot_unload_1292  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_996  1
    load_1_9_18  segment_load_conservation_1231  1
    load_1_9_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_998  -25
    arc_1_9_19  connected_order_arc_999  -13
    arc_1_9_19  out_degree_1227  1
    arc_1_9_19  in_degree_1272  1
    arc_1_9_19  original_T_including_depot_unload_1292  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_998  1
    load_1_9_19  segment_load_conservation_1231  1
    load_1_9_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_1000  -25
    arc_1_9_20  connected_order_arc_1001  -13
    arc_1_9_20  out_degree_1227  1
    arc_1_9_20  in_degree_1278  1
    arc_1_9_20  original_T_including_depot_unload_1292  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_1000  1
    load_1_9_20  segment_load_conservation_1231  1
    load_1_9_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_1002  -25
    arc_1_9_21  connected_order_arc_1003  -13
    arc_1_9_21  out_degree_1227  1
    arc_1_9_21  in_degree_1284  1
    arc_1_9_21  original_T_including_depot_unload_1292  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_1002  1
    load_1_9_21  segment_load_conservation_1231  1
    load_1_9_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1004  -25
    arc_1_10_0  depot_return_or_bypass_1212  1
    arc_1_10_0  out_degree_1234  1
    arc_1_10_0  original_T_including_depot_unload_1292  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1004  1
    load_1_10_0  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_1005  -25
    arc_1_10_7  connected_order_arc_1006  -13
    arc_1_10_7  in_degree_1214  1
    arc_1_10_7  out_degree_1234  1
    arc_1_10_7  original_T_including_depot_unload_1292  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_1005  1
    load_1_10_7  segment_load_conservation_1217  -1
    load_1_10_7  segment_prefix_lb_1218  1
    load_1_10_7  segment_prefix_ub_1219  1
    load_1_10_7  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_1007  -25
    arc_1_10_8  connected_order_arc_1008  -13
    arc_1_10_8  in_degree_1221  1
    arc_1_10_8  out_degree_1234  1
    arc_1_10_8  original_T_including_depot_unload_1292  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_1007  1
    load_1_10_8  segment_load_conservation_1224  -1
    load_1_10_8  segment_prefix_lb_1225  1
    load_1_10_8  segment_prefix_ub_1226  1
    load_1_10_8  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1009  -25
    arc_1_10_9  connected_order_arc_1010  -13
    arc_1_10_9  in_degree_1228  1
    arc_1_10_9  out_degree_1234  1
    arc_1_10_9  original_T_including_depot_unload_1292  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1009  1
    load_1_10_9  segment_load_conservation_1231  -1
    load_1_10_9  segment_prefix_lb_1232  1
    load_1_10_9  segment_prefix_ub_1233  1
    load_1_10_9  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_1011  -25
    arc_1_10_14  connected_order_arc_1012  -13
    arc_1_10_14  out_degree_1234  1
    arc_1_10_14  in_degree_1242  1
    arc_1_10_14  original_T_including_depot_unload_1292  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_1011  1
    load_1_10_14  segment_load_conservation_1238  1
    load_1_10_14  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1013  -25
    arc_1_10_15  connected_order_arc_1014  -13
    arc_1_10_15  out_degree_1234  1
    arc_1_10_15  in_degree_1248  1
    arc_1_10_15  original_T_including_depot_unload_1292  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1013  1
    load_1_10_15  segment_load_conservation_1238  1
    load_1_10_15  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1015  -25
    arc_1_10_16  connected_order_arc_1016  -13
    arc_1_10_16  out_degree_1234  1
    arc_1_10_16  in_degree_1254  1
    arc_1_10_16  original_T_including_depot_unload_1292  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1015  1
    load_1_10_16  segment_load_conservation_1238  1
    load_1_10_16  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1017  -25
    arc_1_10_17  connected_order_arc_1018  -13
    arc_1_10_17  out_degree_1234  1
    arc_1_10_17  in_degree_1260  1
    arc_1_10_17  original_T_including_depot_unload_1292  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1017  1
    load_1_10_17  segment_load_conservation_1238  1
    load_1_10_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1019  -25
    arc_1_10_18  connected_order_arc_1020  -13
    arc_1_10_18  out_degree_1234  1
    arc_1_10_18  in_degree_1266  1
    arc_1_10_18  original_T_including_depot_unload_1292  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1019  1
    load_1_10_18  segment_load_conservation_1238  1
    load_1_10_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1021  -25
    arc_1_10_19  connected_order_arc_1022  -13
    arc_1_10_19  out_degree_1234  1
    arc_1_10_19  in_degree_1272  1
    arc_1_10_19  original_T_including_depot_unload_1292  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1021  1
    load_1_10_19  segment_load_conservation_1238  1
    load_1_10_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1023  -25
    arc_1_10_20  connected_order_arc_1024  -13
    arc_1_10_20  out_degree_1234  1
    arc_1_10_20  in_degree_1278  1
    arc_1_10_20  original_T_including_depot_unload_1292  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1023  1
    load_1_10_20  segment_load_conservation_1238  1
    load_1_10_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1025  -25
    arc_1_10_21  connected_order_arc_1026  -13
    arc_1_10_21  out_degree_1234  1
    arc_1_10_21  in_degree_1284  1
    arc_1_10_21  original_T_including_depot_unload_1292  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1025  1
    load_1_10_21  segment_load_conservation_1238  1
    load_1_10_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1027  -25
    arc_1_14_0  depot_return_or_bypass_1212  1
    arc_1_14_0  out_degree_1241  1
    arc_1_14_0  original_T_including_depot_unload_1292  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1027  1
    load_1_14_0  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1028  -25
    arc_1_14_7  connected_order_arc_1029  -13
    arc_1_14_7  in_degree_1214  1
    arc_1_14_7  out_degree_1241  1
    arc_1_14_7  original_T_including_depot_unload_1292  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1028  1
    load_1_14_7  segment_load_conservation_1217  -1
    load_1_14_7  segment_prefix_lb_1218  1
    load_1_14_7  segment_prefix_ub_1219  1
    load_1_14_7  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1030  -25
    arc_1_14_8  connected_order_arc_1031  -13
    arc_1_14_8  in_degree_1221  1
    arc_1_14_8  out_degree_1241  1
    arc_1_14_8  original_T_including_depot_unload_1292  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1030  1
    load_1_14_8  segment_load_conservation_1224  -1
    load_1_14_8  segment_prefix_lb_1225  1
    load_1_14_8  segment_prefix_ub_1226  1
    load_1_14_8  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1032  -25
    arc_1_14_9  connected_order_arc_1033  -13
    arc_1_14_9  in_degree_1228  1
    arc_1_14_9  out_degree_1241  1
    arc_1_14_9  original_T_including_depot_unload_1292  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1032  1
    load_1_14_9  segment_load_conservation_1231  -1
    load_1_14_9  segment_prefix_lb_1232  1
    load_1_14_9  segment_prefix_ub_1233  1
    load_1_14_9  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1034  -25
    arc_1_14_10  connected_order_arc_1035  -13
    arc_1_14_10  in_degree_1235  1
    arc_1_14_10  out_degree_1241  1
    arc_1_14_10  original_T_including_depot_unload_1292  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1034  1
    load_1_14_10  segment_load_conservation_1238  -1
    load_1_14_10  segment_prefix_lb_1239  1
    load_1_14_10  segment_prefix_ub_1240  1
    load_1_14_10  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1036  -25
    arc_1_14_15  connected_order_arc_1037  -13
    arc_1_14_15  out_degree_1241  1
    arc_1_14_15  in_degree_1248  1
    arc_1_14_15  original_T_including_depot_unload_1292  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1036  1
    load_1_14_15  free_load_conservation_1246  1
    load_1_14_15  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1038  -25
    arc_1_14_16  connected_order_arc_1039  -13
    arc_1_14_16  out_degree_1241  1
    arc_1_14_16  in_degree_1254  1
    arc_1_14_16  original_T_including_depot_unload_1292  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1038  1
    load_1_14_16  free_load_conservation_1246  1
    load_1_14_16  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1040  -25
    arc_1_14_17  connected_order_arc_1041  -13
    arc_1_14_17  out_degree_1241  1
    arc_1_14_17  in_degree_1260  1
    arc_1_14_17  original_T_including_depot_unload_1292  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1040  1
    load_1_14_17  free_load_conservation_1246  1
    load_1_14_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1042  -25
    arc_1_14_18  connected_order_arc_1043  -13
    arc_1_14_18  out_degree_1241  1
    arc_1_14_18  in_degree_1266  1
    arc_1_14_18  original_T_including_depot_unload_1292  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1042  1
    load_1_14_18  free_load_conservation_1246  1
    load_1_14_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1044  -25
    arc_1_14_19  connected_order_arc_1045  -13
    arc_1_14_19  out_degree_1241  1
    arc_1_14_19  in_degree_1272  1
    arc_1_14_19  original_T_including_depot_unload_1292  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1044  1
    load_1_14_19  free_load_conservation_1246  1
    load_1_14_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1046  -25
    arc_1_14_20  connected_order_arc_1047  -13
    arc_1_14_20  out_degree_1241  1
    arc_1_14_20  in_degree_1278  1
    arc_1_14_20  original_T_including_depot_unload_1292  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1046  1
    load_1_14_20  free_load_conservation_1246  1
    load_1_14_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_1048  -25
    arc_1_14_21  connected_order_arc_1049  -13
    arc_1_14_21  out_degree_1241  1
    arc_1_14_21  in_degree_1284  1
    arc_1_14_21  original_T_including_depot_unload_1292  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_1048  1
    load_1_14_21  free_load_conservation_1246  1
    load_1_14_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1050  -25
    arc_1_15_0  depot_return_or_bypass_1212  1
    arc_1_15_0  out_degree_1247  1
    arc_1_15_0  original_T_including_depot_unload_1292  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1050  1
    load_1_15_0  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1051  -25
    arc_1_15_7  connected_order_arc_1052  -13
    arc_1_15_7  in_degree_1214  1
    arc_1_15_7  out_degree_1247  1
    arc_1_15_7  original_T_including_depot_unload_1292  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1051  1
    load_1_15_7  segment_load_conservation_1217  -1
    load_1_15_7  segment_prefix_lb_1218  1
    load_1_15_7  segment_prefix_ub_1219  1
    load_1_15_7  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1053  -25
    arc_1_15_8  connected_order_arc_1054  -13
    arc_1_15_8  in_degree_1221  1
    arc_1_15_8  out_degree_1247  1
    arc_1_15_8  original_T_including_depot_unload_1292  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1053  1
    load_1_15_8  segment_load_conservation_1224  -1
    load_1_15_8  segment_prefix_lb_1225  1
    load_1_15_8  segment_prefix_ub_1226  1
    load_1_15_8  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1055  -25
    arc_1_15_9  connected_order_arc_1056  -13
    arc_1_15_9  in_degree_1228  1
    arc_1_15_9  out_degree_1247  1
    arc_1_15_9  original_T_including_depot_unload_1292  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1055  1
    load_1_15_9  segment_load_conservation_1231  -1
    load_1_15_9  segment_prefix_lb_1232  1
    load_1_15_9  segment_prefix_ub_1233  1
    load_1_15_9  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1057  -25
    arc_1_15_10  connected_order_arc_1058  -13
    arc_1_15_10  in_degree_1235  1
    arc_1_15_10  out_degree_1247  1
    arc_1_15_10  original_T_including_depot_unload_1292  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1057  1
    load_1_15_10  segment_load_conservation_1238  -1
    load_1_15_10  segment_prefix_lb_1239  1
    load_1_15_10  segment_prefix_ub_1240  1
    load_1_15_10  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1059  -25
    arc_1_15_14  connected_order_arc_1060  -13
    arc_1_15_14  in_degree_1242  1
    arc_1_15_14  out_degree_1247  1
    arc_1_15_14  original_T_including_depot_unload_1292  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1059  1
    load_1_15_14  free_load_conservation_1246  -1
    load_1_15_14  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1061  -25
    arc_1_15_16  connected_order_arc_1062  -13
    arc_1_15_16  out_degree_1247  1
    arc_1_15_16  in_degree_1254  1
    arc_1_15_16  original_T_including_depot_unload_1292  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1061  1
    load_1_15_16  free_load_conservation_1252  1
    load_1_15_16  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1063  -25
    arc_1_15_17  connected_order_arc_1064  -13
    arc_1_15_17  out_degree_1247  1
    arc_1_15_17  in_degree_1260  1
    arc_1_15_17  original_T_including_depot_unload_1292  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1063  1
    load_1_15_17  free_load_conservation_1252  1
    load_1_15_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1065  -25
    arc_1_15_18  connected_order_arc_1066  -13
    arc_1_15_18  out_degree_1247  1
    arc_1_15_18  in_degree_1266  1
    arc_1_15_18  original_T_including_depot_unload_1292  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1065  1
    load_1_15_18  free_load_conservation_1252  1
    load_1_15_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1067  -25
    arc_1_15_19  connected_order_arc_1068  -13
    arc_1_15_19  out_degree_1247  1
    arc_1_15_19  in_degree_1272  1
    arc_1_15_19  original_T_including_depot_unload_1292  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1067  1
    load_1_15_19  free_load_conservation_1252  1
    load_1_15_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1069  -25
    arc_1_15_20  connected_order_arc_1070  -13
    arc_1_15_20  out_degree_1247  1
    arc_1_15_20  in_degree_1278  1
    arc_1_15_20  original_T_including_depot_unload_1292  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1069  1
    load_1_15_20  free_load_conservation_1252  1
    load_1_15_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1071  -25
    arc_1_15_21  connected_order_arc_1072  -13
    arc_1_15_21  out_degree_1247  1
    arc_1_15_21  in_degree_1284  1
    arc_1_15_21  original_T_including_depot_unload_1292  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1071  1
    load_1_15_21  free_load_conservation_1252  1
    load_1_15_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1073  -25
    arc_1_16_0  depot_return_or_bypass_1212  1
    arc_1_16_0  out_degree_1253  1
    arc_1_16_0  original_T_including_depot_unload_1292  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1073  1
    load_1_16_0  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1074  -25
    arc_1_16_7  connected_order_arc_1075  -13
    arc_1_16_7  in_degree_1214  1
    arc_1_16_7  out_degree_1253  1
    arc_1_16_7  original_T_including_depot_unload_1292  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1074  1
    load_1_16_7  segment_load_conservation_1217  -1
    load_1_16_7  segment_prefix_lb_1218  1
    load_1_16_7  segment_prefix_ub_1219  1
    load_1_16_7  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1076  -25
    arc_1_16_8  connected_order_arc_1077  -13
    arc_1_16_8  in_degree_1221  1
    arc_1_16_8  out_degree_1253  1
    arc_1_16_8  original_T_including_depot_unload_1292  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1076  1
    load_1_16_8  segment_load_conservation_1224  -1
    load_1_16_8  segment_prefix_lb_1225  1
    load_1_16_8  segment_prefix_ub_1226  1
    load_1_16_8  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1078  -25
    arc_1_16_9  connected_order_arc_1079  -13
    arc_1_16_9  in_degree_1228  1
    arc_1_16_9  out_degree_1253  1
    arc_1_16_9  original_T_including_depot_unload_1292  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1078  1
    load_1_16_9  segment_load_conservation_1231  -1
    load_1_16_9  segment_prefix_lb_1232  1
    load_1_16_9  segment_prefix_ub_1233  1
    load_1_16_9  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1080  -25
    arc_1_16_10  connected_order_arc_1081  -13
    arc_1_16_10  in_degree_1235  1
    arc_1_16_10  out_degree_1253  1
    arc_1_16_10  original_T_including_depot_unload_1292  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1080  1
    load_1_16_10  segment_load_conservation_1238  -1
    load_1_16_10  segment_prefix_lb_1239  1
    load_1_16_10  segment_prefix_ub_1240  1
    load_1_16_10  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1082  -25
    arc_1_16_14  connected_order_arc_1083  -13
    arc_1_16_14  in_degree_1242  1
    arc_1_16_14  out_degree_1253  1
    arc_1_16_14  original_T_including_depot_unload_1292  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1082  1
    load_1_16_14  free_load_conservation_1246  -1
    load_1_16_14  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1084  -25
    arc_1_16_15  connected_order_arc_1085  -13
    arc_1_16_15  in_degree_1248  1
    arc_1_16_15  out_degree_1253  1
    arc_1_16_15  original_T_including_depot_unload_1292  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1084  1
    load_1_16_15  free_load_conservation_1252  -1
    load_1_16_15  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1086  -25
    arc_1_16_17  connected_order_arc_1087  -13
    arc_1_16_17  out_degree_1253  1
    arc_1_16_17  in_degree_1260  1
    arc_1_16_17  original_T_including_depot_unload_1292  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1086  1
    load_1_16_17  free_load_conservation_1258  1
    load_1_16_17  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1088  -25
    arc_1_16_18  connected_order_arc_1089  -13
    arc_1_16_18  out_degree_1253  1
    arc_1_16_18  in_degree_1266  1
    arc_1_16_18  original_T_including_depot_unload_1292  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1088  1
    load_1_16_18  free_load_conservation_1258  1
    load_1_16_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1090  -25
    arc_1_16_19  connected_order_arc_1091  -13
    arc_1_16_19  out_degree_1253  1
    arc_1_16_19  in_degree_1272  1
    arc_1_16_19  original_T_including_depot_unload_1292  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1090  1
    load_1_16_19  free_load_conservation_1258  1
    load_1_16_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1092  -25
    arc_1_16_20  connected_order_arc_1093  -13
    arc_1_16_20  out_degree_1253  1
    arc_1_16_20  in_degree_1278  1
    arc_1_16_20  original_T_including_depot_unload_1292  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1092  1
    load_1_16_20  free_load_conservation_1258  1
    load_1_16_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1094  -25
    arc_1_16_21  connected_order_arc_1095  -13
    arc_1_16_21  out_degree_1253  1
    arc_1_16_21  in_degree_1284  1
    arc_1_16_21  original_T_including_depot_unload_1292  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1094  1
    load_1_16_21  free_load_conservation_1258  1
    load_1_16_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1096  -25
    arc_1_17_0  depot_return_or_bypass_1212  1
    arc_1_17_0  out_degree_1259  1
    arc_1_17_0  original_T_including_depot_unload_1292  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1096  1
    load_1_17_0  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1097  -25
    arc_1_17_7  connected_order_arc_1098  -13
    arc_1_17_7  in_degree_1214  1
    arc_1_17_7  out_degree_1259  1
    arc_1_17_7  original_T_including_depot_unload_1292  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1097  1
    load_1_17_7  segment_load_conservation_1217  -1
    load_1_17_7  segment_prefix_lb_1218  1
    load_1_17_7  segment_prefix_ub_1219  1
    load_1_17_7  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1099  -25
    arc_1_17_8  connected_order_arc_1100  -13
    arc_1_17_8  in_degree_1221  1
    arc_1_17_8  out_degree_1259  1
    arc_1_17_8  original_T_including_depot_unload_1292  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1099  1
    load_1_17_8  segment_load_conservation_1224  -1
    load_1_17_8  segment_prefix_lb_1225  1
    load_1_17_8  segment_prefix_ub_1226  1
    load_1_17_8  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1101  -25
    arc_1_17_9  connected_order_arc_1102  -13
    arc_1_17_9  in_degree_1228  1
    arc_1_17_9  out_degree_1259  1
    arc_1_17_9  original_T_including_depot_unload_1292  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1101  1
    load_1_17_9  segment_load_conservation_1231  -1
    load_1_17_9  segment_prefix_lb_1232  1
    load_1_17_9  segment_prefix_ub_1233  1
    load_1_17_9  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1103  -25
    arc_1_17_10  connected_order_arc_1104  -13
    arc_1_17_10  in_degree_1235  1
    arc_1_17_10  out_degree_1259  1
    arc_1_17_10  original_T_including_depot_unload_1292  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1103  1
    load_1_17_10  segment_load_conservation_1238  -1
    load_1_17_10  segment_prefix_lb_1239  1
    load_1_17_10  segment_prefix_ub_1240  1
    load_1_17_10  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1105  -25
    arc_1_17_14  connected_order_arc_1106  -13
    arc_1_17_14  in_degree_1242  1
    arc_1_17_14  out_degree_1259  1
    arc_1_17_14  original_T_including_depot_unload_1292  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1105  1
    load_1_17_14  free_load_conservation_1246  -1
    load_1_17_14  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1107  -25
    arc_1_17_15  connected_order_arc_1108  -13
    arc_1_17_15  in_degree_1248  1
    arc_1_17_15  out_degree_1259  1
    arc_1_17_15  original_T_including_depot_unload_1292  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1107  1
    load_1_17_15  free_load_conservation_1252  -1
    load_1_17_15  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1109  -25
    arc_1_17_16  connected_order_arc_1110  -13
    arc_1_17_16  in_degree_1254  1
    arc_1_17_16  out_degree_1259  1
    arc_1_17_16  original_T_including_depot_unload_1292  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1109  1
    load_1_17_16  free_load_conservation_1258  -1
    load_1_17_16  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1111  -25
    arc_1_17_18  connected_order_arc_1112  -13
    arc_1_17_18  out_degree_1259  1
    arc_1_17_18  in_degree_1266  1
    arc_1_17_18  original_T_including_depot_unload_1292  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1111  1
    load_1_17_18  free_load_conservation_1264  1
    load_1_17_18  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1113  -25
    arc_1_17_19  connected_order_arc_1114  -13
    arc_1_17_19  out_degree_1259  1
    arc_1_17_19  in_degree_1272  1
    arc_1_17_19  original_T_including_depot_unload_1292  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1113  1
    load_1_17_19  free_load_conservation_1264  1
    load_1_17_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1115  -25
    arc_1_17_20  connected_order_arc_1116  -13
    arc_1_17_20  out_degree_1259  1
    arc_1_17_20  in_degree_1278  1
    arc_1_17_20  original_T_including_depot_unload_1292  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1115  1
    load_1_17_20  free_load_conservation_1264  1
    load_1_17_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1117  -25
    arc_1_17_21  connected_order_arc_1118  -13
    arc_1_17_21  out_degree_1259  1
    arc_1_17_21  in_degree_1284  1
    arc_1_17_21  original_T_including_depot_unload_1292  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1117  1
    load_1_17_21  free_load_conservation_1264  1
    load_1_17_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1119  -25
    arc_1_18_0  depot_return_or_bypass_1212  1
    arc_1_18_0  out_degree_1265  1
    arc_1_18_0  original_T_including_depot_unload_1292  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1119  1
    load_1_18_0  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1120  -25
    arc_1_18_7  connected_order_arc_1121  -13
    arc_1_18_7  in_degree_1214  1
    arc_1_18_7  out_degree_1265  1
    arc_1_18_7  original_T_including_depot_unload_1292  1.2814005706654932e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1120  1
    load_1_18_7  segment_load_conservation_1217  -1
    load_1_18_7  segment_prefix_lb_1218  1
    load_1_18_7  segment_prefix_ub_1219  1
    load_1_18_7  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1122  -25
    arc_1_18_8  connected_order_arc_1123  -13
    arc_1_18_8  in_degree_1221  1
    arc_1_18_8  out_degree_1265  1
    arc_1_18_8  original_T_including_depot_unload_1292  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1122  1
    load_1_18_8  segment_load_conservation_1224  -1
    load_1_18_8  segment_prefix_lb_1225  1
    load_1_18_8  segment_prefix_ub_1226  1
    load_1_18_8  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1124  -25
    arc_1_18_9  connected_order_arc_1125  -13
    arc_1_18_9  in_degree_1228  1
    arc_1_18_9  out_degree_1265  1
    arc_1_18_9  original_T_including_depot_unload_1292  1.7225744515697754e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1124  1
    load_1_18_9  segment_load_conservation_1231  -1
    load_1_18_9  segment_prefix_lb_1232  1
    load_1_18_9  segment_prefix_ub_1233  1
    load_1_18_9  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1126  -25
    arc_1_18_10  connected_order_arc_1127  -13
    arc_1_18_10  in_degree_1235  1
    arc_1_18_10  out_degree_1265  1
    arc_1_18_10  original_T_including_depot_unload_1292  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1126  1
    load_1_18_10  segment_load_conservation_1238  -1
    load_1_18_10  segment_prefix_lb_1239  1
    load_1_18_10  segment_prefix_ub_1240  1
    load_1_18_10  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1128  -25
    arc_1_18_14  connected_order_arc_1129  -13
    arc_1_18_14  in_degree_1242  1
    arc_1_18_14  out_degree_1265  1
    arc_1_18_14  original_T_including_depot_unload_1292  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1128  1
    load_1_18_14  free_load_conservation_1246  -1
    load_1_18_14  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1130  -25
    arc_1_18_15  connected_order_arc_1131  -13
    arc_1_18_15  in_degree_1248  1
    arc_1_18_15  out_degree_1265  1
    arc_1_18_15  original_T_including_depot_unload_1292  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1130  1
    load_1_18_15  free_load_conservation_1252  -1
    load_1_18_15  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1132  -25
    arc_1_18_16  connected_order_arc_1133  -13
    arc_1_18_16  in_degree_1254  1
    arc_1_18_16  out_degree_1265  1
    arc_1_18_16  original_T_including_depot_unload_1292  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1132  1
    load_1_18_16  free_load_conservation_1258  -1
    load_1_18_16  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1134  -25
    arc_1_18_17  connected_order_arc_1135  -13
    arc_1_18_17  in_degree_1260  1
    arc_1_18_17  out_degree_1265  1
    arc_1_18_17  original_T_including_depot_unload_1292  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1134  1
    load_1_18_17  free_load_conservation_1264  -1
    load_1_18_17  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1136  -25
    arc_1_18_19  connected_order_arc_1137  -13
    arc_1_18_19  out_degree_1265  1
    arc_1_18_19  in_degree_1272  1
    arc_1_18_19  original_T_including_depot_unload_1292  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1136  1
    load_1_18_19  free_load_conservation_1270  1
    load_1_18_19  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1138  -25
    arc_1_18_20  connected_order_arc_1139  -13
    arc_1_18_20  out_degree_1265  1
    arc_1_18_20  in_degree_1278  1
    arc_1_18_20  original_T_including_depot_unload_1292  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1138  1
    load_1_18_20  free_load_conservation_1270  1
    load_1_18_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1140  -25
    arc_1_18_21  connected_order_arc_1141  -13
    arc_1_18_21  out_degree_1265  1
    arc_1_18_21  in_degree_1284  1
    arc_1_18_21  original_T_including_depot_unload_1292  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1140  1
    load_1_18_21  free_load_conservation_1270  1
    load_1_18_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1142  -25
    arc_1_19_0  depot_return_or_bypass_1212  1
    arc_1_19_0  out_degree_1271  1
    arc_1_19_0  original_T_including_depot_unload_1292  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1142  1
    load_1_19_0  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1143  -25
    arc_1_19_7  connected_order_arc_1144  -13
    arc_1_19_7  in_degree_1214  1
    arc_1_19_7  out_degree_1271  1
    arc_1_19_7  original_T_including_depot_unload_1292  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1143  1
    load_1_19_7  segment_load_conservation_1217  -1
    load_1_19_7  segment_prefix_lb_1218  1
    load_1_19_7  segment_prefix_ub_1219  1
    load_1_19_7  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1145  -25
    arc_1_19_8  connected_order_arc_1146  -13
    arc_1_19_8  in_degree_1221  1
    arc_1_19_8  out_degree_1271  1
    arc_1_19_8  original_T_including_depot_unload_1292  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1145  1
    load_1_19_8  segment_load_conservation_1224  -1
    load_1_19_8  segment_prefix_lb_1225  1
    load_1_19_8  segment_prefix_ub_1226  1
    load_1_19_8  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1147  -25
    arc_1_19_9  connected_order_arc_1148  -13
    arc_1_19_9  in_degree_1228  1
    arc_1_19_9  out_degree_1271  1
    arc_1_19_9  original_T_including_depot_unload_1292  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1147  1
    load_1_19_9  segment_load_conservation_1231  -1
    load_1_19_9  segment_prefix_lb_1232  1
    load_1_19_9  segment_prefix_ub_1233  1
    load_1_19_9  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1149  -25
    arc_1_19_10  connected_order_arc_1150  -13
    arc_1_19_10  in_degree_1235  1
    arc_1_19_10  out_degree_1271  1
    arc_1_19_10  original_T_including_depot_unload_1292  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1149  1
    load_1_19_10  segment_load_conservation_1238  -1
    load_1_19_10  segment_prefix_lb_1239  1
    load_1_19_10  segment_prefix_ub_1240  1
    load_1_19_10  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1151  -25
    arc_1_19_14  connected_order_arc_1152  -13
    arc_1_19_14  in_degree_1242  1
    arc_1_19_14  out_degree_1271  1
    arc_1_19_14  original_T_including_depot_unload_1292  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1151  1
    load_1_19_14  free_load_conservation_1246  -1
    load_1_19_14  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1153  -25
    arc_1_19_15  connected_order_arc_1154  -13
    arc_1_19_15  in_degree_1248  1
    arc_1_19_15  out_degree_1271  1
    arc_1_19_15  original_T_including_depot_unload_1292  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1153  1
    load_1_19_15  free_load_conservation_1252  -1
    load_1_19_15  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1155  -25
    arc_1_19_16  connected_order_arc_1156  -13
    arc_1_19_16  in_degree_1254  1
    arc_1_19_16  out_degree_1271  1
    arc_1_19_16  original_T_including_depot_unload_1292  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1155  1
    load_1_19_16  free_load_conservation_1258  -1
    load_1_19_16  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1157  -25
    arc_1_19_17  connected_order_arc_1158  -13
    arc_1_19_17  in_degree_1260  1
    arc_1_19_17  out_degree_1271  1
    arc_1_19_17  original_T_including_depot_unload_1292  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1157  1
    load_1_19_17  free_load_conservation_1264  -1
    load_1_19_17  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1159  -25
    arc_1_19_18  connected_order_arc_1160  -13
    arc_1_19_18  in_degree_1266  1
    arc_1_19_18  out_degree_1271  1
    arc_1_19_18  original_T_including_depot_unload_1292  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1159  1
    load_1_19_18  free_load_conservation_1270  -1
    load_1_19_18  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1161  -25
    arc_1_19_20  connected_order_arc_1162  -13
    arc_1_19_20  out_degree_1271  1
    arc_1_19_20  in_degree_1278  1
    arc_1_19_20  original_T_including_depot_unload_1292  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1161  1
    load_1_19_20  free_load_conservation_1276  1
    load_1_19_20  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1163  -25
    arc_1_19_21  connected_order_arc_1164  -13
    arc_1_19_21  out_degree_1271  1
    arc_1_19_21  in_degree_1284  1
    arc_1_19_21  original_T_including_depot_unload_1292  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1163  1
    load_1_19_21  free_load_conservation_1276  1
    load_1_19_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1165  -25
    arc_1_20_0  depot_return_or_bypass_1212  1
    arc_1_20_0  out_degree_1277  1
    arc_1_20_0  original_T_including_depot_unload_1292  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1165  1
    load_1_20_0  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1166  -25
    arc_1_20_7  connected_order_arc_1167  -13
    arc_1_20_7  in_degree_1214  1
    arc_1_20_7  out_degree_1277  1
    arc_1_20_7  original_T_including_depot_unload_1292  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1166  1
    load_1_20_7  segment_load_conservation_1217  -1
    load_1_20_7  segment_prefix_lb_1218  1
    load_1_20_7  segment_prefix_ub_1219  1
    load_1_20_7  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1168  -25
    arc_1_20_8  connected_order_arc_1169  -13
    arc_1_20_8  in_degree_1221  1
    arc_1_20_8  out_degree_1277  1
    arc_1_20_8  original_T_including_depot_unload_1292  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1168  1
    load_1_20_8  segment_load_conservation_1224  -1
    load_1_20_8  segment_prefix_lb_1225  1
    load_1_20_8  segment_prefix_ub_1226  1
    load_1_20_8  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1170  -25
    arc_1_20_9  connected_order_arc_1171  -13
    arc_1_20_9  in_degree_1228  1
    arc_1_20_9  out_degree_1277  1
    arc_1_20_9  original_T_including_depot_unload_1292  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1170  1
    load_1_20_9  segment_load_conservation_1231  -1
    load_1_20_9  segment_prefix_lb_1232  1
    load_1_20_9  segment_prefix_ub_1233  1
    load_1_20_9  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1172  -25
    arc_1_20_10  connected_order_arc_1173  -13
    arc_1_20_10  in_degree_1235  1
    arc_1_20_10  out_degree_1277  1
    arc_1_20_10  original_T_including_depot_unload_1292  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1172  1
    load_1_20_10  segment_load_conservation_1238  -1
    load_1_20_10  segment_prefix_lb_1239  1
    load_1_20_10  segment_prefix_ub_1240  1
    load_1_20_10  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1174  -25
    arc_1_20_14  connected_order_arc_1175  -13
    arc_1_20_14  in_degree_1242  1
    arc_1_20_14  out_degree_1277  1
    arc_1_20_14  original_T_including_depot_unload_1292  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1174  1
    load_1_20_14  free_load_conservation_1246  -1
    load_1_20_14  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1176  -25
    arc_1_20_15  connected_order_arc_1177  -13
    arc_1_20_15  in_degree_1248  1
    arc_1_20_15  out_degree_1277  1
    arc_1_20_15  original_T_including_depot_unload_1292  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1176  1
    load_1_20_15  free_load_conservation_1252  -1
    load_1_20_15  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1178  -25
    arc_1_20_16  connected_order_arc_1179  -13
    arc_1_20_16  in_degree_1254  1
    arc_1_20_16  out_degree_1277  1
    arc_1_20_16  original_T_including_depot_unload_1292  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1178  1
    load_1_20_16  free_load_conservation_1258  -1
    load_1_20_16  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1180  -25
    arc_1_20_17  connected_order_arc_1181  -13
    arc_1_20_17  in_degree_1260  1
    arc_1_20_17  out_degree_1277  1
    arc_1_20_17  original_T_including_depot_unload_1292  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1180  1
    load_1_20_17  free_load_conservation_1264  -1
    load_1_20_17  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1182  -25
    arc_1_20_18  connected_order_arc_1183  -13
    arc_1_20_18  in_degree_1266  1
    arc_1_20_18  out_degree_1277  1
    arc_1_20_18  original_T_including_depot_unload_1292  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1182  1
    load_1_20_18  free_load_conservation_1270  -1
    load_1_20_18  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1184  -25
    arc_1_20_19  connected_order_arc_1185  -13
    arc_1_20_19  in_degree_1272  1
    arc_1_20_19  out_degree_1277  1
    arc_1_20_19  original_T_including_depot_unload_1292  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1184  1
    load_1_20_19  free_load_conservation_1276  -1
    load_1_20_19  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1186  -25
    arc_1_20_21  connected_order_arc_1187  -13
    arc_1_20_21  out_degree_1277  1
    arc_1_20_21  in_degree_1284  1
    arc_1_20_21  original_T_including_depot_unload_1292  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1186  1
    load_1_20_21  free_load_conservation_1282  1
    load_1_20_21  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1188  -25
    arc_1_21_0  depot_return_or_bypass_1212  1
    arc_1_21_0  out_degree_1283  1
    arc_1_21_0  original_T_including_depot_unload_1292  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1188  1
    load_1_21_0  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1189  -25
    arc_1_21_7  connected_order_arc_1190  -13
    arc_1_21_7  in_degree_1214  1
    arc_1_21_7  out_degree_1283  1
    arc_1_21_7  original_T_including_depot_unload_1292  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1189  1
    load_1_21_7  segment_load_conservation_1217  -1
    load_1_21_7  segment_prefix_lb_1218  1
    load_1_21_7  segment_prefix_ub_1219  1
    load_1_21_7  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1191  -25
    arc_1_21_8  connected_order_arc_1192  -13
    arc_1_21_8  in_degree_1221  1
    arc_1_21_8  out_degree_1283  1
    arc_1_21_8  original_T_including_depot_unload_1292  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1191  1
    load_1_21_8  segment_load_conservation_1224  -1
    load_1_21_8  segment_prefix_lb_1225  1
    load_1_21_8  segment_prefix_ub_1226  1
    load_1_21_8  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1193  -25
    arc_1_21_9  connected_order_arc_1194  -13
    arc_1_21_9  in_degree_1228  1
    arc_1_21_9  out_degree_1283  1
    arc_1_21_9  original_T_including_depot_unload_1292  1.3082661182285894e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1193  1
    load_1_21_9  segment_load_conservation_1231  -1
    load_1_21_9  segment_prefix_lb_1232  1
    load_1_21_9  segment_prefix_ub_1233  1
    load_1_21_9  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1195  -25
    arc_1_21_10  connected_order_arc_1196  -13
    arc_1_21_10  in_degree_1235  1
    arc_1_21_10  out_degree_1283  1
    arc_1_21_10  original_T_including_depot_unload_1292  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1195  1
    load_1_21_10  segment_load_conservation_1238  -1
    load_1_21_10  segment_prefix_lb_1239  1
    load_1_21_10  segment_prefix_ub_1240  1
    load_1_21_10  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1197  -25
    arc_1_21_14  connected_order_arc_1198  -13
    arc_1_21_14  in_degree_1242  1
    arc_1_21_14  out_degree_1283  1
    arc_1_21_14  original_T_including_depot_unload_1292  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1197  1
    load_1_21_14  free_load_conservation_1246  -1
    load_1_21_14  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1199  -25
    arc_1_21_15  connected_order_arc_1200  -13
    arc_1_21_15  in_degree_1248  1
    arc_1_21_15  out_degree_1283  1
    arc_1_21_15  original_T_including_depot_unload_1292  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1199  1
    load_1_21_15  free_load_conservation_1252  -1
    load_1_21_15  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1201  -25
    arc_1_21_16  connected_order_arc_1202  -13
    arc_1_21_16  in_degree_1254  1
    arc_1_21_16  out_degree_1283  1
    arc_1_21_16  original_T_including_depot_unload_1292  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1201  1
    load_1_21_16  free_load_conservation_1258  -1
    load_1_21_16  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1203  -25
    arc_1_21_17  connected_order_arc_1204  -13
    arc_1_21_17  in_degree_1260  1
    arc_1_21_17  out_degree_1283  1
    arc_1_21_17  original_T_including_depot_unload_1292  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1203  1
    load_1_21_17  free_load_conservation_1264  -1
    load_1_21_17  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1205  -25
    arc_1_21_18  connected_order_arc_1206  -13
    arc_1_21_18  in_degree_1266  1
    arc_1_21_18  out_degree_1283  1
    arc_1_21_18  original_T_including_depot_unload_1292  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1205  1
    load_1_21_18  free_load_conservation_1270  -1
    load_1_21_18  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1207  -25
    arc_1_21_19  connected_order_arc_1208  -13
    arc_1_21_19  in_degree_1272  1
    arc_1_21_19  out_degree_1283  1
    arc_1_21_19  original_T_including_depot_unload_1292  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1207  1
    load_1_21_19  free_load_conservation_1276  -1
    load_1_21_19  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1209  -25
    arc_1_21_20  connected_order_arc_1210  -13
    arc_1_21_20  in_degree_1278  1
    arc_1_21_20  out_degree_1283  1
    arc_1_21_20  original_T_including_depot_unload_1292  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1209  1
    load_1_21_20  free_load_conservation_1282  -1
    load_1_21_20  free_load_conservation_1288  1
    visit_2_11  out_degree_1538  -1
    visit_2_11  in_degree_1539  -1
    visit_2_11  order_active_lb_1540  -1
    visit_2_11  order_active_ub_1541  -11
    order_2_11  connected_order_arc_1307  -1
    order_2_11  connected_order_arc_1309  -1
    order_2_11  connected_order_arc_1311  -1
    order_2_11  connected_order_arc_1313  -1
    order_2_11  connected_order_arc_1315  -1
    order_2_11  connected_order_arc_1317  -1
    order_2_11  connected_order_arc_1319  -1
    order_2_11  connected_order_arc_1321  -1
    order_2_11  connected_order_arc_1323  -1
    order_2_11  connected_order_arc_1325  -1
    order_2_11  connected_order_arc_1328  1
    order_2_11  connected_order_arc_1349  1
    order_2_11  connected_order_arc_1370  1
    order_2_11  connected_order_arc_1391  1
    order_2_11  connected_order_arc_1412  1
    order_2_11  connected_order_arc_1433  1
    order_2_11  connected_order_arc_1454  1
    order_2_11  connected_order_arc_1475  1
    order_2_11  connected_order_arc_1496  1
    order_2_11  connected_order_arc_1517  1
    order_2_11  order_active_lb_1540  1
    order_2_11  order_active_ub_1541  1
    order_2_11  fixed_segment_relative_order_1607  -1
    visit_2_12  out_degree_1545  -1
    visit_2_12  in_degree_1546  -1
    visit_2_12  order_active_lb_1547  -1
    visit_2_12  order_active_ub_1548  -11
    order_2_12  connected_order_arc_1307  1
    order_2_12  connected_order_arc_1328  -1
    order_2_12  connected_order_arc_1330  -1
    order_2_12  connected_order_arc_1332  -1
    order_2_12  connected_order_arc_1334  -1
    order_2_12  connected_order_arc_1336  -1
    order_2_12  connected_order_arc_1338  -1
    order_2_12  connected_order_arc_1340  -1
    order_2_12  connected_order_arc_1342  -1
    order_2_12  connected_order_arc_1344  -1
    order_2_12  connected_order_arc_1346  -1
    order_2_12  connected_order_arc_1351  1
    order_2_12  connected_order_arc_1372  1
    order_2_12  connected_order_arc_1393  1
    order_2_12  connected_order_arc_1414  1
    order_2_12  connected_order_arc_1435  1
    order_2_12  connected_order_arc_1456  1
    order_2_12  connected_order_arc_1477  1
    order_2_12  connected_order_arc_1498  1
    order_2_12  connected_order_arc_1519  1
    order_2_12  order_active_lb_1547  1
    order_2_12  order_active_ub_1548  1
    order_2_12  fixed_segment_relative_order_1607  1
    order_2_12  fixed_segment_relative_order_1608  -1
    visit_2_13  out_degree_1552  -1
    visit_2_13  in_degree_1553  -1
    visit_2_13  order_active_lb_1554  -1
    visit_2_13  order_active_ub_1555  -11
    order_2_13  connected_order_arc_1309  1
    order_2_13  connected_order_arc_1330  1
    order_2_13  connected_order_arc_1349  -1
    order_2_13  connected_order_arc_1351  -1
    order_2_13  connected_order_arc_1353  -1
    order_2_13  connected_order_arc_1355  -1
    order_2_13  connected_order_arc_1357  -1
    order_2_13  connected_order_arc_1359  -1
    order_2_13  connected_order_arc_1361  -1
    order_2_13  connected_order_arc_1363  -1
    order_2_13  connected_order_arc_1365  -1
    order_2_13  connected_order_arc_1367  -1
    order_2_13  connected_order_arc_1374  1
    order_2_13  connected_order_arc_1395  1
    order_2_13  connected_order_arc_1416  1
    order_2_13  connected_order_arc_1437  1
    order_2_13  connected_order_arc_1458  1
    order_2_13  connected_order_arc_1479  1
    order_2_13  connected_order_arc_1500  1
    order_2_13  connected_order_arc_1521  1
    order_2_13  order_active_lb_1554  1
    order_2_13  order_active_ub_1555  1
    order_2_13  fixed_segment_relative_order_1608  1
    visit_2_14  out_degree_1559  -1
    visit_2_14  in_degree_1560  -1
    visit_2_14  order_active_lb_1561  -1
    visit_2_14  order_active_ub_1562  -11
    visit_2_14  service_visit_def_1563  -1
    order_2_14  connected_order_arc_1311  1
    order_2_14  connected_order_arc_1332  1
    order_2_14  connected_order_arc_1353  1
    order_2_14  connected_order_arc_1370  -1
    order_2_14  connected_order_arc_1372  -1
    order_2_14  connected_order_arc_1374  -1
    order_2_14  connected_order_arc_1376  -1
    order_2_14  connected_order_arc_1378  -1
    order_2_14  connected_order_arc_1380  -1
    order_2_14  connected_order_arc_1382  -1
    order_2_14  connected_order_arc_1384  -1
    order_2_14  connected_order_arc_1386  -1
    order_2_14  connected_order_arc_1388  -1
    order_2_14  connected_order_arc_1397  1
    order_2_14  connected_order_arc_1418  1
    order_2_14  connected_order_arc_1439  1
    order_2_14  connected_order_arc_1460  1
    order_2_14  connected_order_arc_1481  1
    order_2_14  connected_order_arc_1502  1
    order_2_14  connected_order_arc_1523  1
    order_2_14  order_active_lb_1561  1
    order_2_14  order_active_ub_1562  1
    visit_2_15  out_degree_1565  -1
    visit_2_15  in_degree_1566  -1
    visit_2_15  order_active_lb_1567  -1
    visit_2_15  order_active_ub_1568  -11
    visit_2_15  service_visit_def_1569  -1
    order_2_15  connected_order_arc_1313  1
    order_2_15  connected_order_arc_1334  1
    order_2_15  connected_order_arc_1355  1
    order_2_15  connected_order_arc_1376  1
    order_2_15  connected_order_arc_1391  -1
    order_2_15  connected_order_arc_1393  -1
    order_2_15  connected_order_arc_1395  -1
    order_2_15  connected_order_arc_1397  -1
    order_2_15  connected_order_arc_1399  -1
    order_2_15  connected_order_arc_1401  -1
    order_2_15  connected_order_arc_1403  -1
    order_2_15  connected_order_arc_1405  -1
    order_2_15  connected_order_arc_1407  -1
    order_2_15  connected_order_arc_1409  -1
    order_2_15  connected_order_arc_1420  1
    order_2_15  connected_order_arc_1441  1
    order_2_15  connected_order_arc_1462  1
    order_2_15  connected_order_arc_1483  1
    order_2_15  connected_order_arc_1504  1
    order_2_15  connected_order_arc_1525  1
    order_2_15  order_active_lb_1567  1
    order_2_15  order_active_ub_1568  1
    visit_2_16  out_degree_1571  -1
    visit_2_16  in_degree_1572  -1
    visit_2_16  order_active_lb_1573  -1
    visit_2_16  order_active_ub_1574  -11
    visit_2_16  service_visit_def_1575  -1
    order_2_16  connected_order_arc_1315  1
    order_2_16  connected_order_arc_1336  1
    order_2_16  connected_order_arc_1357  1
    order_2_16  connected_order_arc_1378  1
    order_2_16  connected_order_arc_1399  1
    order_2_16  connected_order_arc_1412  -1
    order_2_16  connected_order_arc_1414  -1
    order_2_16  connected_order_arc_1416  -1
    order_2_16  connected_order_arc_1418  -1
    order_2_16  connected_order_arc_1420  -1
    order_2_16  connected_order_arc_1422  -1
    order_2_16  connected_order_arc_1424  -1
    order_2_16  connected_order_arc_1426  -1
    order_2_16  connected_order_arc_1428  -1
    order_2_16  connected_order_arc_1430  -1
    order_2_16  connected_order_arc_1443  1
    order_2_16  connected_order_arc_1464  1
    order_2_16  connected_order_arc_1485  1
    order_2_16  connected_order_arc_1506  1
    order_2_16  connected_order_arc_1527  1
    order_2_16  order_active_lb_1573  1
    order_2_16  order_active_ub_1574  1
    visit_2_17  out_degree_1577  -1
    visit_2_17  in_degree_1578  -1
    visit_2_17  order_active_lb_1579  -1
    visit_2_17  order_active_ub_1580  -11
    visit_2_17  service_visit_def_1581  -1
    order_2_17  connected_order_arc_1317  1
    order_2_17  connected_order_arc_1338  1
    order_2_17  connected_order_arc_1359  1
    order_2_17  connected_order_arc_1380  1
    order_2_17  connected_order_arc_1401  1
    order_2_17  connected_order_arc_1422  1
    order_2_17  connected_order_arc_1433  -1
    order_2_17  connected_order_arc_1435  -1
    order_2_17  connected_order_arc_1437  -1
    order_2_17  connected_order_arc_1439  -1
    order_2_17  connected_order_arc_1441  -1
    order_2_17  connected_order_arc_1443  -1
    order_2_17  connected_order_arc_1445  -1
    order_2_17  connected_order_arc_1447  -1
    order_2_17  connected_order_arc_1449  -1
    order_2_17  connected_order_arc_1451  -1
    order_2_17  connected_order_arc_1466  1
    order_2_17  connected_order_arc_1487  1
    order_2_17  connected_order_arc_1508  1
    order_2_17  connected_order_arc_1529  1
    order_2_17  order_active_lb_1579  1
    order_2_17  order_active_ub_1580  1
    visit_2_18  out_degree_1583  -1
    visit_2_18  in_degree_1584  -1
    visit_2_18  order_active_lb_1585  -1
    visit_2_18  order_active_ub_1586  -11
    visit_2_18  service_visit_def_1587  -1
    order_2_18  connected_order_arc_1319  1
    order_2_18  connected_order_arc_1340  1
    order_2_18  connected_order_arc_1361  1
    order_2_18  connected_order_arc_1382  1
    order_2_18  connected_order_arc_1403  1
    order_2_18  connected_order_arc_1424  1
    order_2_18  connected_order_arc_1445  1
    order_2_18  connected_order_arc_1454  -1
    order_2_18  connected_order_arc_1456  -1
    order_2_18  connected_order_arc_1458  -1
    order_2_18  connected_order_arc_1460  -1
    order_2_18  connected_order_arc_1462  -1
    order_2_18  connected_order_arc_1464  -1
    order_2_18  connected_order_arc_1466  -1
    order_2_18  connected_order_arc_1468  -1
    order_2_18  connected_order_arc_1470  -1
    order_2_18  connected_order_arc_1472  -1
    order_2_18  connected_order_arc_1489  1
    order_2_18  connected_order_arc_1510  1
    order_2_18  connected_order_arc_1531  1
    order_2_18  order_active_lb_1585  1
    order_2_18  order_active_ub_1586  1
    visit_2_19  out_degree_1589  -1
    visit_2_19  in_degree_1590  -1
    visit_2_19  order_active_lb_1591  -1
    visit_2_19  order_active_ub_1592  -11
    visit_2_19  service_visit_def_1593  -1
    order_2_19  connected_order_arc_1321  1
    order_2_19  connected_order_arc_1342  1
    order_2_19  connected_order_arc_1363  1
    order_2_19  connected_order_arc_1384  1
    order_2_19  connected_order_arc_1405  1
    order_2_19  connected_order_arc_1426  1
    order_2_19  connected_order_arc_1447  1
    order_2_19  connected_order_arc_1468  1
    order_2_19  connected_order_arc_1475  -1
    order_2_19  connected_order_arc_1477  -1
    order_2_19  connected_order_arc_1479  -1
    order_2_19  connected_order_arc_1481  -1
    order_2_19  connected_order_arc_1483  -1
    order_2_19  connected_order_arc_1485  -1
    order_2_19  connected_order_arc_1487  -1
    order_2_19  connected_order_arc_1489  -1
    order_2_19  connected_order_arc_1491  -1
    order_2_19  connected_order_arc_1493  -1
    order_2_19  connected_order_arc_1512  1
    order_2_19  connected_order_arc_1533  1
    order_2_19  order_active_lb_1591  1
    order_2_19  order_active_ub_1592  1
    visit_2_20  out_degree_1595  -1
    visit_2_20  in_degree_1596  -1
    visit_2_20  order_active_lb_1597  -1
    visit_2_20  order_active_ub_1598  -11
    visit_2_20  service_visit_def_1599  -1
    order_2_20  connected_order_arc_1323  1
    order_2_20  connected_order_arc_1344  1
    order_2_20  connected_order_arc_1365  1
    order_2_20  connected_order_arc_1386  1
    order_2_20  connected_order_arc_1407  1
    order_2_20  connected_order_arc_1428  1
    order_2_20  connected_order_arc_1449  1
    order_2_20  connected_order_arc_1470  1
    order_2_20  connected_order_arc_1491  1
    order_2_20  connected_order_arc_1496  -1
    order_2_20  connected_order_arc_1498  -1
    order_2_20  connected_order_arc_1500  -1
    order_2_20  connected_order_arc_1502  -1
    order_2_20  connected_order_arc_1504  -1
    order_2_20  connected_order_arc_1506  -1
    order_2_20  connected_order_arc_1508  -1
    order_2_20  connected_order_arc_1510  -1
    order_2_20  connected_order_arc_1512  -1
    order_2_20  connected_order_arc_1514  -1
    order_2_20  connected_order_arc_1535  1
    order_2_20  order_active_lb_1597  1
    order_2_20  order_active_ub_1598  1
    visit_2_21  out_degree_1601  -1
    visit_2_21  in_degree_1602  -1
    visit_2_21  order_active_lb_1603  -1
    visit_2_21  order_active_ub_1604  -11
    visit_2_21  service_visit_def_1605  -1
    order_2_21  connected_order_arc_1325  1
    order_2_21  connected_order_arc_1346  1
    order_2_21  connected_order_arc_1367  1
    order_2_21  connected_order_arc_1388  1
    order_2_21  connected_order_arc_1409  1
    order_2_21  connected_order_arc_1430  1
    order_2_21  connected_order_arc_1451  1
    order_2_21  connected_order_arc_1472  1
    order_2_21  connected_order_arc_1493  1
    order_2_21  connected_order_arc_1514  1
    order_2_21  connected_order_arc_1517  -1
    order_2_21  connected_order_arc_1519  -1
    order_2_21  connected_order_arc_1521  -1
    order_2_21  connected_order_arc_1523  -1
    order_2_21  connected_order_arc_1525  -1
    order_2_21  connected_order_arc_1527  -1
    order_2_21  connected_order_arc_1529  -1
    order_2_21  connected_order_arc_1531  -1
    order_2_21  connected_order_arc_1533  -1
    order_2_21  connected_order_arc_1535  -1
    order_2_21  order_active_lb_1603  1
    order_2_21  order_active_ub_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1293  -30
    arc_2_0_0  depot_departure_or_bypass_1536  1
    arc_2_0_0  depot_return_or_bypass_1537  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1293  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1294  -30
    arc_2_0_11  depot_departure_or_bypass_1536  1
    arc_2_0_11  in_degree_1539  1
    arc_2_0_11  original_T_including_depot_unload_1609  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1294  1
    load_2_0_11  segment_load_conservation_1542  -1
    load_2_0_11  segment_prefix_lb_1543  1
    load_2_0_11  segment_prefix_ub_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1295  -30
    arc_2_0_12  depot_departure_or_bypass_1536  1
    arc_2_0_12  in_degree_1546  1
    arc_2_0_12  original_T_including_depot_unload_1609  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1295  1
    load_2_0_12  segment_load_conservation_1549  -1
    load_2_0_12  segment_prefix_lb_1550  1
    load_2_0_12  segment_prefix_ub_1551  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1296  -30
    arc_2_0_13  depot_departure_or_bypass_1536  1
    arc_2_0_13  in_degree_1553  1
    arc_2_0_13  original_T_including_depot_unload_1609  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1296  1
    load_2_0_13  segment_load_conservation_1556  -1
    load_2_0_13  segment_prefix_lb_1557  1
    load_2_0_13  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1297  -30
    arc_2_0_14  depot_departure_or_bypass_1536  1
    arc_2_0_14  in_degree_1560  1
    arc_2_0_14  original_T_including_depot_unload_1609  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1297  1
    load_2_0_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1298  -30
    arc_2_0_15  depot_departure_or_bypass_1536  1
    arc_2_0_15  in_degree_1566  1
    arc_2_0_15  original_T_including_depot_unload_1609  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1298  1
    load_2_0_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1299  -30
    arc_2_0_16  depot_departure_or_bypass_1536  1
    arc_2_0_16  in_degree_1572  1
    arc_2_0_16  original_T_including_depot_unload_1609  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1299  1
    load_2_0_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1300  -30
    arc_2_0_17  depot_departure_or_bypass_1536  1
    arc_2_0_17  in_degree_1578  1
    arc_2_0_17  original_T_including_depot_unload_1609  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1300  1
    load_2_0_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1301  -30
    arc_2_0_18  depot_departure_or_bypass_1536  1
    arc_2_0_18  in_degree_1584  1
    arc_2_0_18  original_T_including_depot_unload_1609  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1301  1
    load_2_0_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1302  -30
    arc_2_0_19  depot_departure_or_bypass_1536  1
    arc_2_0_19  in_degree_1590  1
    arc_2_0_19  original_T_including_depot_unload_1609  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1302  1
    load_2_0_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1303  -30
    arc_2_0_20  depot_departure_or_bypass_1536  1
    arc_2_0_20  in_degree_1596  1
    arc_2_0_20  original_T_including_depot_unload_1609  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1303  1
    load_2_0_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1304  -30
    arc_2_0_21  depot_departure_or_bypass_1536  1
    arc_2_0_21  in_degree_1602  1
    arc_2_0_21  original_T_including_depot_unload_1609  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1304  1
    load_2_0_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1305  -30
    arc_2_11_0  depot_return_or_bypass_1537  1
    arc_2_11_0  out_degree_1538  1
    arc_2_11_0  original_T_including_depot_unload_1609  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1305  1
    load_2_11_0  segment_load_conservation_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1306  -30
    arc_2_11_12  connected_order_arc_1307  -12
    arc_2_11_12  out_degree_1538  1
    arc_2_11_12  in_degree_1546  1
    arc_2_11_12  original_T_including_depot_unload_1609  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1306  1
    load_2_11_12  segment_load_conservation_1542  1
    load_2_11_12  segment_load_conservation_1549  -1
    load_2_11_12  segment_prefix_lb_1550  1
    load_2_11_12  segment_prefix_ub_1551  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1308  -30
    arc_2_11_13  connected_order_arc_1309  -12
    arc_2_11_13  out_degree_1538  1
    arc_2_11_13  in_degree_1553  1
    arc_2_11_13  original_T_including_depot_unload_1609  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1308  1
    load_2_11_13  segment_load_conservation_1542  1
    load_2_11_13  segment_load_conservation_1556  -1
    load_2_11_13  segment_prefix_lb_1557  1
    load_2_11_13  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1310  -30
    arc_2_11_14  connected_order_arc_1311  -12
    arc_2_11_14  out_degree_1538  1
    arc_2_11_14  in_degree_1560  1
    arc_2_11_14  original_T_including_depot_unload_1609  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1310  1
    load_2_11_14  segment_load_conservation_1542  1
    load_2_11_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1312  -30
    arc_2_11_15  connected_order_arc_1313  -12
    arc_2_11_15  out_degree_1538  1
    arc_2_11_15  in_degree_1566  1
    arc_2_11_15  original_T_including_depot_unload_1609  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1312  1
    load_2_11_15  segment_load_conservation_1542  1
    load_2_11_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1314  -30
    arc_2_11_16  connected_order_arc_1315  -12
    arc_2_11_16  out_degree_1538  1
    arc_2_11_16  in_degree_1572  1
    arc_2_11_16  original_T_including_depot_unload_1609  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1314  1
    load_2_11_16  segment_load_conservation_1542  1
    load_2_11_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1316  -30
    arc_2_11_17  connected_order_arc_1317  -12
    arc_2_11_17  out_degree_1538  1
    arc_2_11_17  in_degree_1578  1
    arc_2_11_17  original_T_including_depot_unload_1609  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1316  1
    load_2_11_17  segment_load_conservation_1542  1
    load_2_11_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1318  -30
    arc_2_11_18  connected_order_arc_1319  -12
    arc_2_11_18  out_degree_1538  1
    arc_2_11_18  in_degree_1584  1
    arc_2_11_18  original_T_including_depot_unload_1609  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1318  1
    load_2_11_18  segment_load_conservation_1542  1
    load_2_11_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1320  -30
    arc_2_11_19  connected_order_arc_1321  -12
    arc_2_11_19  out_degree_1538  1
    arc_2_11_19  in_degree_1590  1
    arc_2_11_19  original_T_including_depot_unload_1609  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1320  1
    load_2_11_19  segment_load_conservation_1542  1
    load_2_11_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1322  -30
    arc_2_11_20  connected_order_arc_1323  -12
    arc_2_11_20  out_degree_1538  1
    arc_2_11_20  in_degree_1596  1
    arc_2_11_20  original_T_including_depot_unload_1609  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1322  1
    load_2_11_20  segment_load_conservation_1542  1
    load_2_11_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1324  -30
    arc_2_11_21  connected_order_arc_1325  -12
    arc_2_11_21  out_degree_1538  1
    arc_2_11_21  in_degree_1602  1
    arc_2_11_21  original_T_including_depot_unload_1609  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1324  1
    load_2_11_21  segment_load_conservation_1542  1
    load_2_11_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1326  -30
    arc_2_12_0  depot_return_or_bypass_1537  1
    arc_2_12_0  out_degree_1545  1
    arc_2_12_0  original_T_including_depot_unload_1609  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1326  1
    load_2_12_0  segment_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1327  -30
    arc_2_12_11  connected_order_arc_1328  -12
    arc_2_12_11  in_degree_1539  1
    arc_2_12_11  out_degree_1545  1
    arc_2_12_11  original_T_including_depot_unload_1609  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1327  1
    load_2_12_11  segment_load_conservation_1542  -1
    load_2_12_11  segment_prefix_lb_1543  1
    load_2_12_11  segment_prefix_ub_1544  1
    load_2_12_11  segment_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1329  -30
    arc_2_12_13  connected_order_arc_1330  -12
    arc_2_12_13  out_degree_1545  1
    arc_2_12_13  in_degree_1553  1
    arc_2_12_13  original_T_including_depot_unload_1609  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1329  1
    load_2_12_13  segment_load_conservation_1549  1
    load_2_12_13  segment_load_conservation_1556  -1
    load_2_12_13  segment_prefix_lb_1557  1
    load_2_12_13  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1331  -30
    arc_2_12_14  connected_order_arc_1332  -12
    arc_2_12_14  out_degree_1545  1
    arc_2_12_14  in_degree_1560  1
    arc_2_12_14  original_T_including_depot_unload_1609  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1331  1
    load_2_12_14  segment_load_conservation_1549  1
    load_2_12_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1333  -30
    arc_2_12_15  connected_order_arc_1334  -12
    arc_2_12_15  out_degree_1545  1
    arc_2_12_15  in_degree_1566  1
    arc_2_12_15  original_T_including_depot_unload_1609  1.2686001679750689e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1333  1
    load_2_12_15  segment_load_conservation_1549  1
    load_2_12_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1335  -30
    arc_2_12_16  connected_order_arc_1336  -12
    arc_2_12_16  out_degree_1545  1
    arc_2_12_16  in_degree_1572  1
    arc_2_12_16  original_T_including_depot_unload_1609  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1335  1
    load_2_12_16  segment_load_conservation_1549  1
    load_2_12_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1337  -30
    arc_2_12_17  connected_order_arc_1338  -12
    arc_2_12_17  out_degree_1545  1
    arc_2_12_17  in_degree_1578  1
    arc_2_12_17  original_T_including_depot_unload_1609  1.6461188122693993e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1337  1
    load_2_12_17  segment_load_conservation_1549  1
    load_2_12_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1339  -30
    arc_2_12_18  connected_order_arc_1340  -12
    arc_2_12_18  out_degree_1545  1
    arc_2_12_18  in_degree_1584  1
    arc_2_12_18  original_T_including_depot_unload_1609  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1339  1
    load_2_12_18  segment_load_conservation_1549  1
    load_2_12_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1341  -30
    arc_2_12_19  connected_order_arc_1342  -12
    arc_2_12_19  out_degree_1545  1
    arc_2_12_19  in_degree_1590  1
    arc_2_12_19  original_T_including_depot_unload_1609  1.6809955292555005e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1341  1
    load_2_12_19  segment_load_conservation_1549  1
    load_2_12_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1343  -30
    arc_2_12_20  connected_order_arc_1344  -12
    arc_2_12_20  out_degree_1545  1
    arc_2_12_20  in_degree_1596  1
    arc_2_12_20  original_T_including_depot_unload_1609  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1343  1
    load_2_12_20  segment_load_conservation_1549  1
    load_2_12_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1345  -30
    arc_2_12_21  connected_order_arc_1346  -12
    arc_2_12_21  out_degree_1545  1
    arc_2_12_21  in_degree_1602  1
    arc_2_12_21  original_T_including_depot_unload_1609  1.0510800781097112e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1345  1
    load_2_12_21  segment_load_conservation_1549  1
    load_2_12_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1347  -30
    arc_2_13_0  depot_return_or_bypass_1537  1
    arc_2_13_0  out_degree_1552  1
    arc_2_13_0  original_T_including_depot_unload_1609  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1347  1
    load_2_13_0  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1348  -30
    arc_2_13_11  connected_order_arc_1349  -12
    arc_2_13_11  in_degree_1539  1
    arc_2_13_11  out_degree_1552  1
    arc_2_13_11  original_T_including_depot_unload_1609  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1348  1
    load_2_13_11  segment_load_conservation_1542  -1
    load_2_13_11  segment_prefix_lb_1543  1
    load_2_13_11  segment_prefix_ub_1544  1
    load_2_13_11  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1350  -30
    arc_2_13_12  connected_order_arc_1351  -12
    arc_2_13_12  in_degree_1546  1
    arc_2_13_12  out_degree_1552  1
    arc_2_13_12  original_T_including_depot_unload_1609  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1350  1
    load_2_13_12  segment_load_conservation_1549  -1
    load_2_13_12  segment_prefix_lb_1550  1
    load_2_13_12  segment_prefix_ub_1551  1
    load_2_13_12  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1352  -30
    arc_2_13_14  connected_order_arc_1353  -12
    arc_2_13_14  out_degree_1552  1
    arc_2_13_14  in_degree_1560  1
    arc_2_13_14  original_T_including_depot_unload_1609  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1352  1
    load_2_13_14  segment_load_conservation_1556  1
    load_2_13_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1354  -30
    arc_2_13_15  connected_order_arc_1355  -12
    arc_2_13_15  out_degree_1552  1
    arc_2_13_15  in_degree_1566  1
    arc_2_13_15  original_T_including_depot_unload_1609  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1354  1
    load_2_13_15  segment_load_conservation_1556  1
    load_2_13_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1356  -30
    arc_2_13_16  connected_order_arc_1357  -12
    arc_2_13_16  out_degree_1552  1
    arc_2_13_16  in_degree_1572  1
    arc_2_13_16  original_T_including_depot_unload_1609  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1356  1
    load_2_13_16  segment_load_conservation_1556  1
    load_2_13_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1358  -30
    arc_2_13_17  connected_order_arc_1359  -12
    arc_2_13_17  out_degree_1552  1
    arc_2_13_17  in_degree_1578  1
    arc_2_13_17  original_T_including_depot_unload_1609  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1358  1
    load_2_13_17  segment_load_conservation_1556  1
    load_2_13_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1360  -30
    arc_2_13_18  connected_order_arc_1361  -12
    arc_2_13_18  out_degree_1552  1
    arc_2_13_18  in_degree_1584  1
    arc_2_13_18  original_T_including_depot_unload_1609  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1360  1
    load_2_13_18  segment_load_conservation_1556  1
    load_2_13_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1362  -30
    arc_2_13_19  connected_order_arc_1363  -12
    arc_2_13_19  out_degree_1552  1
    arc_2_13_19  in_degree_1590  1
    arc_2_13_19  original_T_including_depot_unload_1609  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1362  1
    load_2_13_19  segment_load_conservation_1556  1
    load_2_13_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1364  -30
    arc_2_13_20  connected_order_arc_1365  -12
    arc_2_13_20  out_degree_1552  1
    arc_2_13_20  in_degree_1596  1
    arc_2_13_20  original_T_including_depot_unload_1609  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1364  1
    load_2_13_20  segment_load_conservation_1556  1
    load_2_13_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1366  -30
    arc_2_13_21  connected_order_arc_1367  -12
    arc_2_13_21  out_degree_1552  1
    arc_2_13_21  in_degree_1602  1
    arc_2_13_21  original_T_including_depot_unload_1609  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1366  1
    load_2_13_21  segment_load_conservation_1556  1
    load_2_13_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1368  -30
    arc_2_14_0  depot_return_or_bypass_1537  1
    arc_2_14_0  out_degree_1559  1
    arc_2_14_0  original_T_including_depot_unload_1609  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1368  1
    load_2_14_0  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1369  -30
    arc_2_14_11  connected_order_arc_1370  -12
    arc_2_14_11  in_degree_1539  1
    arc_2_14_11  out_degree_1559  1
    arc_2_14_11  original_T_including_depot_unload_1609  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1369  1
    load_2_14_11  segment_load_conservation_1542  -1
    load_2_14_11  segment_prefix_lb_1543  1
    load_2_14_11  segment_prefix_ub_1544  1
    load_2_14_11  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1371  -30
    arc_2_14_12  connected_order_arc_1372  -12
    arc_2_14_12  in_degree_1546  1
    arc_2_14_12  out_degree_1559  1
    arc_2_14_12  original_T_including_depot_unload_1609  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1371  1
    load_2_14_12  segment_load_conservation_1549  -1
    load_2_14_12  segment_prefix_lb_1550  1
    load_2_14_12  segment_prefix_ub_1551  1
    load_2_14_12  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1373  -30
    arc_2_14_13  connected_order_arc_1374  -12
    arc_2_14_13  in_degree_1553  1
    arc_2_14_13  out_degree_1559  1
    arc_2_14_13  original_T_including_depot_unload_1609  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1373  1
    load_2_14_13  segment_load_conservation_1556  -1
    load_2_14_13  segment_prefix_lb_1557  1
    load_2_14_13  segment_prefix_ub_1558  1
    load_2_14_13  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1375  -30
    arc_2_14_15  connected_order_arc_1376  -12
    arc_2_14_15  out_degree_1559  1
    arc_2_14_15  in_degree_1566  1
    arc_2_14_15  original_T_including_depot_unload_1609  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1375  1
    load_2_14_15  free_load_conservation_1564  1
    load_2_14_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1377  -30
    arc_2_14_16  connected_order_arc_1378  -12
    arc_2_14_16  out_degree_1559  1
    arc_2_14_16  in_degree_1572  1
    arc_2_14_16  original_T_including_depot_unload_1609  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1377  1
    load_2_14_16  free_load_conservation_1564  1
    load_2_14_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1379  -30
    arc_2_14_17  connected_order_arc_1380  -12
    arc_2_14_17  out_degree_1559  1
    arc_2_14_17  in_degree_1578  1
    arc_2_14_17  original_T_including_depot_unload_1609  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1379  1
    load_2_14_17  free_load_conservation_1564  1
    load_2_14_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1381  -30
    arc_2_14_18  connected_order_arc_1382  -12
    arc_2_14_18  out_degree_1559  1
    arc_2_14_18  in_degree_1584  1
    arc_2_14_18  original_T_including_depot_unload_1609  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1381  1
    load_2_14_18  free_load_conservation_1564  1
    load_2_14_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1383  -30
    arc_2_14_19  connected_order_arc_1384  -12
    arc_2_14_19  out_degree_1559  1
    arc_2_14_19  in_degree_1590  1
    arc_2_14_19  original_T_including_depot_unload_1609  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1383  1
    load_2_14_19  free_load_conservation_1564  1
    load_2_14_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1385  -30
    arc_2_14_20  connected_order_arc_1386  -12
    arc_2_14_20  out_degree_1559  1
    arc_2_14_20  in_degree_1596  1
    arc_2_14_20  original_T_including_depot_unload_1609  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1385  1
    load_2_14_20  free_load_conservation_1564  1
    load_2_14_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1387  -30
    arc_2_14_21  connected_order_arc_1388  -12
    arc_2_14_21  out_degree_1559  1
    arc_2_14_21  in_degree_1602  1
    arc_2_14_21  original_T_including_depot_unload_1609  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1387  1
    load_2_14_21  free_load_conservation_1564  1
    load_2_14_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1389  -30
    arc_2_15_0  depot_return_or_bypass_1537  1
    arc_2_15_0  out_degree_1565  1
    arc_2_15_0  original_T_including_depot_unload_1609  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1389  1
    load_2_15_0  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1390  -30
    arc_2_15_11  connected_order_arc_1391  -12
    arc_2_15_11  in_degree_1539  1
    arc_2_15_11  out_degree_1565  1
    arc_2_15_11  original_T_including_depot_unload_1609  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1390  1
    load_2_15_11  segment_load_conservation_1542  -1
    load_2_15_11  segment_prefix_lb_1543  1
    load_2_15_11  segment_prefix_ub_1544  1
    load_2_15_11  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1392  -30
    arc_2_15_12  connected_order_arc_1393  -12
    arc_2_15_12  in_degree_1546  1
    arc_2_15_12  out_degree_1565  1
    arc_2_15_12  original_T_including_depot_unload_1609  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1392  1
    load_2_15_12  segment_load_conservation_1549  -1
    load_2_15_12  segment_prefix_lb_1550  1
    load_2_15_12  segment_prefix_ub_1551  1
    load_2_15_12  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1394  -30
    arc_2_15_13  connected_order_arc_1395  -12
    arc_2_15_13  in_degree_1553  1
    arc_2_15_13  out_degree_1565  1
    arc_2_15_13  original_T_including_depot_unload_1609  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1394  1
    load_2_15_13  segment_load_conservation_1556  -1
    load_2_15_13  segment_prefix_lb_1557  1
    load_2_15_13  segment_prefix_ub_1558  1
    load_2_15_13  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1396  -30
    arc_2_15_14  connected_order_arc_1397  -12
    arc_2_15_14  in_degree_1560  1
    arc_2_15_14  out_degree_1565  1
    arc_2_15_14  original_T_including_depot_unload_1609  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1396  1
    load_2_15_14  free_load_conservation_1564  -1
    load_2_15_14  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1398  -30
    arc_2_15_16  connected_order_arc_1399  -12
    arc_2_15_16  out_degree_1565  1
    arc_2_15_16  in_degree_1572  1
    arc_2_15_16  original_T_including_depot_unload_1609  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1398  1
    load_2_15_16  free_load_conservation_1570  1
    load_2_15_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1400  -30
    arc_2_15_17  connected_order_arc_1401  -12
    arc_2_15_17  out_degree_1565  1
    arc_2_15_17  in_degree_1578  1
    arc_2_15_17  original_T_including_depot_unload_1609  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1400  1
    load_2_15_17  free_load_conservation_1570  1
    load_2_15_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1402  -30
    arc_2_15_18  connected_order_arc_1403  -12
    arc_2_15_18  out_degree_1565  1
    arc_2_15_18  in_degree_1584  1
    arc_2_15_18  original_T_including_depot_unload_1609  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1402  1
    load_2_15_18  free_load_conservation_1570  1
    load_2_15_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1404  -30
    arc_2_15_19  connected_order_arc_1405  -12
    arc_2_15_19  out_degree_1565  1
    arc_2_15_19  in_degree_1590  1
    arc_2_15_19  original_T_including_depot_unload_1609  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1404  1
    load_2_15_19  free_load_conservation_1570  1
    load_2_15_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1406  -30
    arc_2_15_20  connected_order_arc_1407  -12
    arc_2_15_20  out_degree_1565  1
    arc_2_15_20  in_degree_1596  1
    arc_2_15_20  original_T_including_depot_unload_1609  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1406  1
    load_2_15_20  free_load_conservation_1570  1
    load_2_15_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1408  -30
    arc_2_15_21  connected_order_arc_1409  -12
    arc_2_15_21  out_degree_1565  1
    arc_2_15_21  in_degree_1602  1
    arc_2_15_21  original_T_including_depot_unload_1609  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1408  1
    load_2_15_21  free_load_conservation_1570  1
    load_2_15_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1410  -30
    arc_2_16_0  depot_return_or_bypass_1537  1
    arc_2_16_0  out_degree_1571  1
    arc_2_16_0  original_T_including_depot_unload_1609  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1410  1
    load_2_16_0  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1411  -30
    arc_2_16_11  connected_order_arc_1412  -12
    arc_2_16_11  in_degree_1539  1
    arc_2_16_11  out_degree_1571  1
    arc_2_16_11  original_T_including_depot_unload_1609  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1411  1
    load_2_16_11  segment_load_conservation_1542  -1
    load_2_16_11  segment_prefix_lb_1543  1
    load_2_16_11  segment_prefix_ub_1544  1
    load_2_16_11  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1413  -30
    arc_2_16_12  connected_order_arc_1414  -12
    arc_2_16_12  in_degree_1546  1
    arc_2_16_12  out_degree_1571  1
    arc_2_16_12  original_T_including_depot_unload_1609  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1413  1
    load_2_16_12  segment_load_conservation_1549  -1
    load_2_16_12  segment_prefix_lb_1550  1
    load_2_16_12  segment_prefix_ub_1551  1
    load_2_16_12  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1415  -30
    arc_2_16_13  connected_order_arc_1416  -12
    arc_2_16_13  in_degree_1553  1
    arc_2_16_13  out_degree_1571  1
    arc_2_16_13  original_T_including_depot_unload_1609  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1415  1
    load_2_16_13  segment_load_conservation_1556  -1
    load_2_16_13  segment_prefix_lb_1557  1
    load_2_16_13  segment_prefix_ub_1558  1
    load_2_16_13  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1417  -30
    arc_2_16_14  connected_order_arc_1418  -12
    arc_2_16_14  in_degree_1560  1
    arc_2_16_14  out_degree_1571  1
    arc_2_16_14  original_T_including_depot_unload_1609  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1417  1
    load_2_16_14  free_load_conservation_1564  -1
    load_2_16_14  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1419  -30
    arc_2_16_15  connected_order_arc_1420  -12
    arc_2_16_15  in_degree_1566  1
    arc_2_16_15  out_degree_1571  1
    arc_2_16_15  original_T_including_depot_unload_1609  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1419  1
    load_2_16_15  free_load_conservation_1570  -1
    load_2_16_15  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1421  -30
    arc_2_16_17  connected_order_arc_1422  -12
    arc_2_16_17  out_degree_1571  1
    arc_2_16_17  in_degree_1578  1
    arc_2_16_17  original_T_including_depot_unload_1609  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1421  1
    load_2_16_17  free_load_conservation_1576  1
    load_2_16_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1423  -30
    arc_2_16_18  connected_order_arc_1424  -12
    arc_2_16_18  out_degree_1571  1
    arc_2_16_18  in_degree_1584  1
    arc_2_16_18  original_T_including_depot_unload_1609  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1423  1
    load_2_16_18  free_load_conservation_1576  1
    load_2_16_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1425  -30
    arc_2_16_19  connected_order_arc_1426  -12
    arc_2_16_19  out_degree_1571  1
    arc_2_16_19  in_degree_1590  1
    arc_2_16_19  original_T_including_depot_unload_1609  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1425  1
    load_2_16_19  free_load_conservation_1576  1
    load_2_16_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1427  -30
    arc_2_16_20  connected_order_arc_1428  -12
    arc_2_16_20  out_degree_1571  1
    arc_2_16_20  in_degree_1596  1
    arc_2_16_20  original_T_including_depot_unload_1609  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1427  1
    load_2_16_20  free_load_conservation_1576  1
    load_2_16_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1429  -30
    arc_2_16_21  connected_order_arc_1430  -12
    arc_2_16_21  out_degree_1571  1
    arc_2_16_21  in_degree_1602  1
    arc_2_16_21  original_T_including_depot_unload_1609  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1429  1
    load_2_16_21  free_load_conservation_1576  1
    load_2_16_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1431  -30
    arc_2_17_0  depot_return_or_bypass_1537  1
    arc_2_17_0  out_degree_1577  1
    arc_2_17_0  original_T_including_depot_unload_1609  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1431  1
    load_2_17_0  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1432  -30
    arc_2_17_11  connected_order_arc_1433  -12
    arc_2_17_11  in_degree_1539  1
    arc_2_17_11  out_degree_1577  1
    arc_2_17_11  original_T_including_depot_unload_1609  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1432  1
    load_2_17_11  segment_load_conservation_1542  -1
    load_2_17_11  segment_prefix_lb_1543  1
    load_2_17_11  segment_prefix_ub_1544  1
    load_2_17_11  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1434  -30
    arc_2_17_12  connected_order_arc_1435  -12
    arc_2_17_12  in_degree_1546  1
    arc_2_17_12  out_degree_1577  1
    arc_2_17_12  original_T_including_depot_unload_1609  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1434  1
    load_2_17_12  segment_load_conservation_1549  -1
    load_2_17_12  segment_prefix_lb_1550  1
    load_2_17_12  segment_prefix_ub_1551  1
    load_2_17_12  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1436  -30
    arc_2_17_13  connected_order_arc_1437  -12
    arc_2_17_13  in_degree_1553  1
    arc_2_17_13  out_degree_1577  1
    arc_2_17_13  original_T_including_depot_unload_1609  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1436  1
    load_2_17_13  segment_load_conservation_1556  -1
    load_2_17_13  segment_prefix_lb_1557  1
    load_2_17_13  segment_prefix_ub_1558  1
    load_2_17_13  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1438  -30
    arc_2_17_14  connected_order_arc_1439  -12
    arc_2_17_14  in_degree_1560  1
    arc_2_17_14  out_degree_1577  1
    arc_2_17_14  original_T_including_depot_unload_1609  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1438  1
    load_2_17_14  free_load_conservation_1564  -1
    load_2_17_14  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1440  -30
    arc_2_17_15  connected_order_arc_1441  -12
    arc_2_17_15  in_degree_1566  1
    arc_2_17_15  out_degree_1577  1
    arc_2_17_15  original_T_including_depot_unload_1609  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1440  1
    load_2_17_15  free_load_conservation_1570  -1
    load_2_17_15  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1442  -30
    arc_2_17_16  connected_order_arc_1443  -12
    arc_2_17_16  in_degree_1572  1
    arc_2_17_16  out_degree_1577  1
    arc_2_17_16  original_T_including_depot_unload_1609  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1442  1
    load_2_17_16  free_load_conservation_1576  -1
    load_2_17_16  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1444  -30
    arc_2_17_18  connected_order_arc_1445  -12
    arc_2_17_18  out_degree_1577  1
    arc_2_17_18  in_degree_1584  1
    arc_2_17_18  original_T_including_depot_unload_1609  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1444  1
    load_2_17_18  free_load_conservation_1582  1
    load_2_17_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1446  -30
    arc_2_17_19  connected_order_arc_1447  -12
    arc_2_17_19  out_degree_1577  1
    arc_2_17_19  in_degree_1590  1
    arc_2_17_19  original_T_including_depot_unload_1609  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1446  1
    load_2_17_19  free_load_conservation_1582  1
    load_2_17_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1448  -30
    arc_2_17_20  connected_order_arc_1449  -12
    arc_2_17_20  out_degree_1577  1
    arc_2_17_20  in_degree_1596  1
    arc_2_17_20  original_T_including_depot_unload_1609  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1448  1
    load_2_17_20  free_load_conservation_1582  1
    load_2_17_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1450  -30
    arc_2_17_21  connected_order_arc_1451  -12
    arc_2_17_21  out_degree_1577  1
    arc_2_17_21  in_degree_1602  1
    arc_2_17_21  original_T_including_depot_unload_1609  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1450  1
    load_2_17_21  free_load_conservation_1582  1
    load_2_17_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1452  -30
    arc_2_18_0  depot_return_or_bypass_1537  1
    arc_2_18_0  out_degree_1583  1
    arc_2_18_0  original_T_including_depot_unload_1609  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1452  1
    load_2_18_0  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1453  -30
    arc_2_18_11  connected_order_arc_1454  -12
    arc_2_18_11  in_degree_1539  1
    arc_2_18_11  out_degree_1583  1
    arc_2_18_11  original_T_including_depot_unload_1609  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1453  1
    load_2_18_11  segment_load_conservation_1542  -1
    load_2_18_11  segment_prefix_lb_1543  1
    load_2_18_11  segment_prefix_ub_1544  1
    load_2_18_11  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1455  -30
    arc_2_18_12  connected_order_arc_1456  -12
    arc_2_18_12  in_degree_1546  1
    arc_2_18_12  out_degree_1583  1
    arc_2_18_12  original_T_including_depot_unload_1609  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1455  1
    load_2_18_12  segment_load_conservation_1549  -1
    load_2_18_12  segment_prefix_lb_1550  1
    load_2_18_12  segment_prefix_ub_1551  1
    load_2_18_12  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1457  -30
    arc_2_18_13  connected_order_arc_1458  -12
    arc_2_18_13  in_degree_1553  1
    arc_2_18_13  out_degree_1583  1
    arc_2_18_13  original_T_including_depot_unload_1609  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1457  1
    load_2_18_13  segment_load_conservation_1556  -1
    load_2_18_13  segment_prefix_lb_1557  1
    load_2_18_13  segment_prefix_ub_1558  1
    load_2_18_13  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1459  -30
    arc_2_18_14  connected_order_arc_1460  -12
    arc_2_18_14  in_degree_1560  1
    arc_2_18_14  out_degree_1583  1
    arc_2_18_14  original_T_including_depot_unload_1609  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1459  1
    load_2_18_14  free_load_conservation_1564  -1
    load_2_18_14  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1461  -30
    arc_2_18_15  connected_order_arc_1462  -12
    arc_2_18_15  in_degree_1566  1
    arc_2_18_15  out_degree_1583  1
    arc_2_18_15  original_T_including_depot_unload_1609  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1461  1
    load_2_18_15  free_load_conservation_1570  -1
    load_2_18_15  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1463  -30
    arc_2_18_16  connected_order_arc_1464  -12
    arc_2_18_16  in_degree_1572  1
    arc_2_18_16  out_degree_1583  1
    arc_2_18_16  original_T_including_depot_unload_1609  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1463  1
    load_2_18_16  free_load_conservation_1576  -1
    load_2_18_16  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1465  -30
    arc_2_18_17  connected_order_arc_1466  -12
    arc_2_18_17  in_degree_1578  1
    arc_2_18_17  out_degree_1583  1
    arc_2_18_17  original_T_including_depot_unload_1609  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1465  1
    load_2_18_17  free_load_conservation_1582  -1
    load_2_18_17  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1467  -30
    arc_2_18_19  connected_order_arc_1468  -12
    arc_2_18_19  out_degree_1583  1
    arc_2_18_19  in_degree_1590  1
    arc_2_18_19  original_T_including_depot_unload_1609  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1467  1
    load_2_18_19  free_load_conservation_1588  1
    load_2_18_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1469  -30
    arc_2_18_20  connected_order_arc_1470  -12
    arc_2_18_20  out_degree_1583  1
    arc_2_18_20  in_degree_1596  1
    arc_2_18_20  original_T_including_depot_unload_1609  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1469  1
    load_2_18_20  free_load_conservation_1588  1
    load_2_18_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1471  -30
    arc_2_18_21  connected_order_arc_1472  -12
    arc_2_18_21  out_degree_1583  1
    arc_2_18_21  in_degree_1602  1
    arc_2_18_21  original_T_including_depot_unload_1609  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1471  1
    load_2_18_21  free_load_conservation_1588  1
    load_2_18_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1473  -30
    arc_2_19_0  depot_return_or_bypass_1537  1
    arc_2_19_0  out_degree_1589  1
    arc_2_19_0  original_T_including_depot_unload_1609  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1473  1
    load_2_19_0  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1474  -30
    arc_2_19_11  connected_order_arc_1475  -12
    arc_2_19_11  in_degree_1539  1
    arc_2_19_11  out_degree_1589  1
    arc_2_19_11  original_T_including_depot_unload_1609  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1474  1
    load_2_19_11  segment_load_conservation_1542  -1
    load_2_19_11  segment_prefix_lb_1543  1
    load_2_19_11  segment_prefix_ub_1544  1
    load_2_19_11  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1476  -30
    arc_2_19_12  connected_order_arc_1477  -12
    arc_2_19_12  in_degree_1546  1
    arc_2_19_12  out_degree_1589  1
    arc_2_19_12  original_T_including_depot_unload_1609  1.5942479163822793e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1476  1
    load_2_19_12  segment_load_conservation_1549  -1
    load_2_19_12  segment_prefix_lb_1550  1
    load_2_19_12  segment_prefix_ub_1551  1
    load_2_19_12  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1478  -30
    arc_2_19_13  connected_order_arc_1479  -12
    arc_2_19_13  in_degree_1553  1
    arc_2_19_13  out_degree_1589  1
    arc_2_19_13  original_T_including_depot_unload_1609  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1478  1
    load_2_19_13  segment_load_conservation_1556  -1
    load_2_19_13  segment_prefix_lb_1557  1
    load_2_19_13  segment_prefix_ub_1558  1
    load_2_19_13  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1480  -30
    arc_2_19_14  connected_order_arc_1481  -12
    arc_2_19_14  in_degree_1560  1
    arc_2_19_14  out_degree_1589  1
    arc_2_19_14  original_T_including_depot_unload_1609  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1480  1
    load_2_19_14  free_load_conservation_1564  -1
    load_2_19_14  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1482  -30
    arc_2_19_15  connected_order_arc_1483  -12
    arc_2_19_15  in_degree_1566  1
    arc_2_19_15  out_degree_1589  1
    arc_2_19_15  original_T_including_depot_unload_1609  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1482  1
    load_2_19_15  free_load_conservation_1570  -1
    load_2_19_15  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1484  -30
    arc_2_19_16  connected_order_arc_1485  -12
    arc_2_19_16  in_degree_1572  1
    arc_2_19_16  out_degree_1589  1
    arc_2_19_16  original_T_including_depot_unload_1609  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1484  1
    load_2_19_16  free_load_conservation_1576  -1
    load_2_19_16  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1486  -30
    arc_2_19_17  connected_order_arc_1487  -12
    arc_2_19_17  in_degree_1578  1
    arc_2_19_17  out_degree_1589  1
    arc_2_19_17  original_T_including_depot_unload_1609  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1486  1
    load_2_19_17  free_load_conservation_1582  -1
    load_2_19_17  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1488  -30
    arc_2_19_18  connected_order_arc_1489  -12
    arc_2_19_18  in_degree_1584  1
    arc_2_19_18  out_degree_1589  1
    arc_2_19_18  original_T_including_depot_unload_1609  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1488  1
    load_2_19_18  free_load_conservation_1588  -1
    load_2_19_18  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1490  -30
    arc_2_19_20  connected_order_arc_1491  -12
    arc_2_19_20  out_degree_1589  1
    arc_2_19_20  in_degree_1596  1
    arc_2_19_20  original_T_including_depot_unload_1609  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1490  1
    load_2_19_20  free_load_conservation_1594  1
    load_2_19_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1492  -30
    arc_2_19_21  connected_order_arc_1493  -12
    arc_2_19_21  out_degree_1589  1
    arc_2_19_21  in_degree_1602  1
    arc_2_19_21  original_T_including_depot_unload_1609  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1492  1
    load_2_19_21  free_load_conservation_1594  1
    load_2_19_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1494  -30
    arc_2_20_0  depot_return_or_bypass_1537  1
    arc_2_20_0  out_degree_1595  1
    arc_2_20_0  original_T_including_depot_unload_1609  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1494  1
    load_2_20_0  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1495  -30
    arc_2_20_11  connected_order_arc_1496  -12
    arc_2_20_11  in_degree_1539  1
    arc_2_20_11  out_degree_1595  1
    arc_2_20_11  original_T_including_depot_unload_1609  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1495  1
    load_2_20_11  segment_load_conservation_1542  -1
    load_2_20_11  segment_prefix_lb_1543  1
    load_2_20_11  segment_prefix_ub_1544  1
    load_2_20_11  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1497  -30
    arc_2_20_12  connected_order_arc_1498  -12
    arc_2_20_12  in_degree_1546  1
    arc_2_20_12  out_degree_1595  1
    arc_2_20_12  original_T_including_depot_unload_1609  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1497  1
    load_2_20_12  segment_load_conservation_1549  -1
    load_2_20_12  segment_prefix_lb_1550  1
    load_2_20_12  segment_prefix_ub_1551  1
    load_2_20_12  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1499  -30
    arc_2_20_13  connected_order_arc_1500  -12
    arc_2_20_13  in_degree_1553  1
    arc_2_20_13  out_degree_1595  1
    arc_2_20_13  original_T_including_depot_unload_1609  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1499  1
    load_2_20_13  segment_load_conservation_1556  -1
    load_2_20_13  segment_prefix_lb_1557  1
    load_2_20_13  segment_prefix_ub_1558  1
    load_2_20_13  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1501  -30
    arc_2_20_14  connected_order_arc_1502  -12
    arc_2_20_14  in_degree_1560  1
    arc_2_20_14  out_degree_1595  1
    arc_2_20_14  original_T_including_depot_unload_1609  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1501  1
    load_2_20_14  free_load_conservation_1564  -1
    load_2_20_14  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1503  -30
    arc_2_20_15  connected_order_arc_1504  -12
    arc_2_20_15  in_degree_1566  1
    arc_2_20_15  out_degree_1595  1
    arc_2_20_15  original_T_including_depot_unload_1609  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1503  1
    load_2_20_15  free_load_conservation_1570  -1
    load_2_20_15  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1505  -30
    arc_2_20_16  connected_order_arc_1506  -12
    arc_2_20_16  in_degree_1572  1
    arc_2_20_16  out_degree_1595  1
    arc_2_20_16  original_T_including_depot_unload_1609  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1505  1
    load_2_20_16  free_load_conservation_1576  -1
    load_2_20_16  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1507  -30
    arc_2_20_17  connected_order_arc_1508  -12
    arc_2_20_17  in_degree_1578  1
    arc_2_20_17  out_degree_1595  1
    arc_2_20_17  original_T_including_depot_unload_1609  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1507  1
    load_2_20_17  free_load_conservation_1582  -1
    load_2_20_17  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1509  -30
    arc_2_20_18  connected_order_arc_1510  -12
    arc_2_20_18  in_degree_1584  1
    arc_2_20_18  out_degree_1595  1
    arc_2_20_18  original_T_including_depot_unload_1609  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1509  1
    load_2_20_18  free_load_conservation_1588  -1
    load_2_20_18  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1511  -30
    arc_2_20_19  connected_order_arc_1512  -12
    arc_2_20_19  in_degree_1590  1
    arc_2_20_19  out_degree_1595  1
    arc_2_20_19  original_T_including_depot_unload_1609  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1511  1
    load_2_20_19  free_load_conservation_1594  -1
    load_2_20_19  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1513  -30
    arc_2_20_21  connected_order_arc_1514  -12
    arc_2_20_21  out_degree_1595  1
    arc_2_20_21  in_degree_1602  1
    arc_2_20_21  original_T_including_depot_unload_1609  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1513  1
    load_2_20_21  free_load_conservation_1600  1
    load_2_20_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1515  -30
    arc_2_21_0  depot_return_or_bypass_1537  1
    arc_2_21_0  out_degree_1601  1
    arc_2_21_0  original_T_including_depot_unload_1609  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1515  1
    load_2_21_0  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1516  -30
    arc_2_21_11  connected_order_arc_1517  -12
    arc_2_21_11  in_degree_1539  1
    arc_2_21_11  out_degree_1601  1
    arc_2_21_11  original_T_including_depot_unload_1609  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1516  1
    load_2_21_11  segment_load_conservation_1542  -1
    load_2_21_11  segment_prefix_lb_1543  1
    load_2_21_11  segment_prefix_ub_1544  1
    load_2_21_11  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1518  -30
    arc_2_21_12  connected_order_arc_1519  -12
    arc_2_21_12  in_degree_1546  1
    arc_2_21_12  out_degree_1601  1
    arc_2_21_12  original_T_including_depot_unload_1609  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1518  1
    load_2_21_12  segment_load_conservation_1549  -1
    load_2_21_12  segment_prefix_lb_1550  1
    load_2_21_12  segment_prefix_ub_1551  1
    load_2_21_12  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1520  -30
    arc_2_21_13  connected_order_arc_1521  -12
    arc_2_21_13  in_degree_1553  1
    arc_2_21_13  out_degree_1601  1
    arc_2_21_13  original_T_including_depot_unload_1609  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1520  1
    load_2_21_13  segment_load_conservation_1556  -1
    load_2_21_13  segment_prefix_lb_1557  1
    load_2_21_13  segment_prefix_ub_1558  1
    load_2_21_13  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1522  -30
    arc_2_21_14  connected_order_arc_1523  -12
    arc_2_21_14  in_degree_1560  1
    arc_2_21_14  out_degree_1601  1
    arc_2_21_14  original_T_including_depot_unload_1609  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1522  1
    load_2_21_14  free_load_conservation_1564  -1
    load_2_21_14  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1524  -30
    arc_2_21_15  connected_order_arc_1525  -12
    arc_2_21_15  in_degree_1566  1
    arc_2_21_15  out_degree_1601  1
    arc_2_21_15  original_T_including_depot_unload_1609  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1524  1
    load_2_21_15  free_load_conservation_1570  -1
    load_2_21_15  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1526  -30
    arc_2_21_16  connected_order_arc_1527  -12
    arc_2_21_16  in_degree_1572  1
    arc_2_21_16  out_degree_1601  1
    arc_2_21_16  original_T_including_depot_unload_1609  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1526  1
    load_2_21_16  free_load_conservation_1576  -1
    load_2_21_16  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1528  -30
    arc_2_21_17  connected_order_arc_1529  -12
    arc_2_21_17  in_degree_1578  1
    arc_2_21_17  out_degree_1601  1
    arc_2_21_17  original_T_including_depot_unload_1609  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1528  1
    load_2_21_17  free_load_conservation_1582  -1
    load_2_21_17  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1530  -30
    arc_2_21_18  connected_order_arc_1531  -12
    arc_2_21_18  in_degree_1584  1
    arc_2_21_18  out_degree_1601  1
    arc_2_21_18  original_T_including_depot_unload_1609  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1530  1
    load_2_21_18  free_load_conservation_1588  -1
    load_2_21_18  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1532  -30
    arc_2_21_19  connected_order_arc_1533  -12
    arc_2_21_19  in_degree_1590  1
    arc_2_21_19  out_degree_1601  1
    arc_2_21_19  original_T_including_depot_unload_1609  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1532  1
    load_2_21_19  free_load_conservation_1594  -1
    load_2_21_19  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1534  -30
    arc_2_21_20  connected_order_arc_1535  -12
    arc_2_21_20  in_degree_1596  1
    arc_2_21_20  out_degree_1601  1
    arc_2_21_20  original_T_including_depot_unload_1609  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1534  1
    load_2_21_20  free_load_conservation_1600  -1
    load_2_21_20  free_load_conservation_1606  1
RHS
    RHS1      OBJ       -0.4815
    RHS1      onehot_16_26  1
    RHS1      onehot_11_55  1
    RHS1      onehot_31_84  1
    RHS1      onehot_20_113  1
    RHS1      onehot_2_148  1
    RHS1      onehot_21_183  1
    RHS1      onehot_12_218  1
    RHS1      onehot_7_257  1
    RHS1      stock_ub_261  39
    RHS1      parent_nonstrict_scope_262  2.7179151326287809e-01
    RHS1      normalization_319  1
    RHS1      connected_order_arc_448  -14
    RHS1      connected_order_arc_450  -14
    RHS1      connected_order_arc_452  -14
    RHS1      connected_order_arc_454  -14
    RHS1      connected_order_arc_456  -14
    RHS1      connected_order_arc_458  -14
    RHS1      connected_order_arc_460  -14
    RHS1      connected_order_arc_462  -14
    RHS1      connected_order_arc_464  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_483  -14
    RHS1      connected_order_arc_485  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_489  -14
    RHS1      connected_order_arc_491  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_510  -14
    RHS1      connected_order_arc_512  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_516  -14
    RHS1      connected_order_arc_518  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_537  -14
    RHS1      connected_order_arc_539  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_543  -14
    RHS1      connected_order_arc_545  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_564  -14
    RHS1      connected_order_arc_566  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_570  -14
    RHS1      connected_order_arc_572  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_591  -14
    RHS1      connected_order_arc_593  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_597  -14
    RHS1      connected_order_arc_599  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_618  -14
    RHS1      connected_order_arc_620  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_624  -14
    RHS1      connected_order_arc_626  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_645  -14
    RHS1      connected_order_arc_647  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_651  -14
    RHS1      connected_order_arc_653  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_672  -14
    RHS1      connected_order_arc_674  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_678  -14
    RHS1      connected_order_arc_680  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_699  -14
    RHS1      connected_order_arc_701  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_705  -14
    RHS1      connected_order_arc_707  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_720  -14
    RHS1      connected_order_arc_722  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_726  -14
    RHS1      connected_order_arc_728  -14
    RHS1      connected_order_arc_730  -14
    RHS1      connected_order_arc_732  -14
    RHS1      connected_order_arc_734  -14
    RHS1      connected_order_arc_736  -14
    RHS1      connected_order_arc_738  -14
    RHS1      connected_order_arc_740  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_745  -14
    RHS1      connected_order_arc_747  -14
    RHS1      connected_order_arc_749  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_753  -14
    RHS1      connected_order_arc_755  -14
    RHS1      connected_order_arc_757  -14
    RHS1      connected_order_arc_759  -14
    RHS1      connected_order_arc_761  -14
    RHS1      connected_order_arc_763  -14
    RHS1      connected_order_arc_765  -14
    RHS1      connected_order_arc_767  -14
    RHS1      connected_order_arc_769  -14
    RHS1      connected_order_arc_772  -14
    RHS1      connected_order_arc_774  -14
    RHS1      connected_order_arc_776  -14
    RHS1      connected_order_arc_778  -14
    RHS1      connected_order_arc_780  -14
    RHS1      connected_order_arc_782  -14
    RHS1      connected_order_arc_784  -14
    RHS1      connected_order_arc_786  -14
    RHS1      connected_order_arc_788  -14
    RHS1      connected_order_arc_790  -14
    RHS1      connected_order_arc_792  -14
    RHS1      connected_order_arc_794  -14
    RHS1      connected_order_arc_796  -14
    RHS1      connected_order_arc_799  -14
    RHS1      connected_order_arc_801  -14
    RHS1      connected_order_arc_803  -14
    RHS1      connected_order_arc_805  -14
    RHS1      connected_order_arc_807  -14
    RHS1      connected_order_arc_809  -14
    RHS1      connected_order_arc_811  -14
    RHS1      connected_order_arc_813  -14
    RHS1      connected_order_arc_815  -14
    RHS1      connected_order_arc_817  -14
    RHS1      connected_order_arc_819  -14
    RHS1      connected_order_arc_821  -14
    RHS1      connected_order_arc_823  -14
    RHS1      depot_departure_or_bypass_824  1
    RHS1      depot_return_or_bypass_825  1
    RHS1      segment_load_conservation_830  5
    RHS1      segment_prefix_ub_832  15
    RHS1      segment_load_conservation_837  5
    RHS1      segment_prefix_ub_839  15
    RHS1      segment_load_conservation_844  5
    RHS1      segment_prefix_ub_846  15
    RHS1      segment_load_conservation_851  -8
    RHS1      segment_prefix_lb_852  8
    RHS1      segment_prefix_ub_853  20
    RHS1      segment_load_conservation_858  -3
    RHS1      segment_prefix_lb_859  3
    RHS1      segment_prefix_ub_860  20
    RHS1      segment_load_conservation_865  -3
    RHS1      segment_prefix_lb_866  3
    RHS1      segment_prefix_ub_867  9
    RHS1      fixed_segment_relative_order_916  1
    RHS1      fixed_segment_relative_order_917  1
    RHS1      fixed_segment_relative_order_918  1
    RHS1      fixed_segment_relative_order_919  1
    RHS1      fixed_segment_relative_order_920  1
    RHS1      original_T_including_depot_unload_921  3.0387045443215020e+03
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1106  -12
    RHS1      connected_order_arc_1108  -12
    RHS1      connected_order_arc_1110  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1127  -12
    RHS1      connected_order_arc_1129  -12
    RHS1      connected_order_arc_1131  -12
    RHS1      connected_order_arc_1133  -12
    RHS1      connected_order_arc_1135  -12
    RHS1      connected_order_arc_1137  -12
    RHS1      connected_order_arc_1139  -12
    RHS1      connected_order_arc_1141  -12
    RHS1      connected_order_arc_1144  -12
    RHS1      connected_order_arc_1146  -12
    RHS1      connected_order_arc_1148  -12
    RHS1      connected_order_arc_1150  -12
    RHS1      connected_order_arc_1152  -12
    RHS1      connected_order_arc_1154  -12
    RHS1      connected_order_arc_1156  -12
    RHS1      connected_order_arc_1158  -12
    RHS1      connected_order_arc_1160  -12
    RHS1      connected_order_arc_1162  -12
    RHS1      connected_order_arc_1164  -12
    RHS1      connected_order_arc_1167  -12
    RHS1      connected_order_arc_1169  -12
    RHS1      connected_order_arc_1171  -12
    RHS1      connected_order_arc_1173  -12
    RHS1      connected_order_arc_1175  -12
    RHS1      connected_order_arc_1177  -12
    RHS1      connected_order_arc_1179  -12
    RHS1      connected_order_arc_1181  -12
    RHS1      connected_order_arc_1183  -12
    RHS1      connected_order_arc_1185  -12
    RHS1      connected_order_arc_1187  -12
    RHS1      connected_order_arc_1190  -12
    RHS1      connected_order_arc_1192  -12
    RHS1      connected_order_arc_1194  -12
    RHS1      connected_order_arc_1196  -12
    RHS1      connected_order_arc_1198  -12
    RHS1      connected_order_arc_1200  -12
    RHS1      connected_order_arc_1202  -12
    RHS1      connected_order_arc_1204  -12
    RHS1      connected_order_arc_1206  -12
    RHS1      connected_order_arc_1208  -12
    RHS1      connected_order_arc_1210  -12
    RHS1      depot_departure_or_bypass_1211  1
    RHS1      depot_return_or_bypass_1212  1
    RHS1      segment_load_conservation_1217  3
    RHS1      segment_prefix_ub_1219  22
    RHS1      segment_load_conservation_1224  5
    RHS1      segment_prefix_ub_1226  20
    RHS1      segment_load_conservation_1231  3
    RHS1      segment_prefix_lb_1232  8
    RHS1      segment_prefix_ub_1233  22
    RHS1      segment_load_conservation_1238  -5
    RHS1      segment_prefix_lb_1239  5
    RHS1      segment_prefix_ub_1240  25
    RHS1      fixed_segment_relative_order_1289  1
    RHS1      fixed_segment_relative_order_1290  1
    RHS1      fixed_segment_relative_order_1291  1
    RHS1      original_T_including_depot_unload_1292  3.9452834399673739e+03
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1412  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1433  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1439  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1447  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1454  -11
    RHS1      connected_order_arc_1456  -11
    RHS1      connected_order_arc_1458  -11
    RHS1      connected_order_arc_1460  -11
    RHS1      connected_order_arc_1462  -11
    RHS1      connected_order_arc_1464  -11
    RHS1      connected_order_arc_1466  -11
    RHS1      connected_order_arc_1468  -11
    RHS1      connected_order_arc_1470  -11
    RHS1      connected_order_arc_1472  -11
    RHS1      connected_order_arc_1475  -11
    RHS1      connected_order_arc_1477  -11
    RHS1      connected_order_arc_1479  -11
    RHS1      connected_order_arc_1481  -11
    RHS1      connected_order_arc_1483  -11
    RHS1      connected_order_arc_1485  -11
    RHS1      connected_order_arc_1487  -11
    RHS1      connected_order_arc_1489  -11
    RHS1      connected_order_arc_1491  -11
    RHS1      connected_order_arc_1493  -11
    RHS1      connected_order_arc_1496  -11
    RHS1      connected_order_arc_1498  -11
    RHS1      connected_order_arc_1500  -11
    RHS1      connected_order_arc_1502  -11
    RHS1      connected_order_arc_1504  -11
    RHS1      connected_order_arc_1506  -11
    RHS1      connected_order_arc_1508  -11
    RHS1      connected_order_arc_1510  -11
    RHS1      connected_order_arc_1512  -11
    RHS1      connected_order_arc_1514  -11
    RHS1      connected_order_arc_1517  -11
    RHS1      connected_order_arc_1519  -11
    RHS1      connected_order_arc_1521  -11
    RHS1      connected_order_arc_1523  -11
    RHS1      connected_order_arc_1525  -11
    RHS1      connected_order_arc_1527  -11
    RHS1      connected_order_arc_1529  -11
    RHS1      connected_order_arc_1531  -11
    RHS1      connected_order_arc_1533  -11
    RHS1      connected_order_arc_1535  -11
    RHS1      depot_departure_or_bypass_1536  1
    RHS1      depot_return_or_bypass_1537  1
    RHS1      segment_load_conservation_1542  5
    RHS1      segment_prefix_ub_1544  23
    RHS1      segment_prefix_lb_1550  5
    RHS1      segment_prefix_ub_1551  30
    RHS1      segment_load_conservation_1556  -5
    RHS1      segment_prefix_lb_1557  5
    RHS1      segment_prefix_ub_1558  30
    RHS1      fixed_segment_relative_order_1607  1
    RHS1      fixed_segment_relative_order_1608  1
    RHS1      original_T_including_depot_unload_1609  3.1667242031869819e+03
BOUNDS
 LO BND1      t         2.5146187159453565e-02
 UP BND1      t         4.2794552185621712e-02
 UP BND1      q         4.5029151326287808e-01
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.2794552185621712e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.2794552185621712e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.2794552185621712e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.2794552185621712e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.2794552185621712e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.2794552185621712e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.2794552185621712e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.2794552185621712e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.2794552185621712e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.2794552185621712e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.2794552185621712e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.2794552185621712e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.2794552185621712e-02
 UP BND1      rho_16    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.2794552185621712e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.2794552185621712e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.2794552185621712e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.2794552185621712e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.2794552185621712e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.2794552185621712e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.2794552185621712e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.2794552185621712e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.2794552185621712e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.2794552185621712e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.2794552185621712e-02
 BV BND1      x_11_11 
 UP BND1      w_11_11   4.2794552185621712e-02
 BV BND1      x_11_12 
 UP BND1      w_11_12   4.2794552185621712e-02
 UP BND1      rho_11    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2794552185621712e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2794552185621712e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2794552185621712e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2794552185621712e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2794552185621712e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2794552185621712e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2794552185621712e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2794552185621712e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2794552185621712e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2794552185621712e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2794552185621712e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2794552185621712e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2794552185621712e-02
 UP BND1      rho_31    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    4.2794552185621712e-02
 BV BND1      x_20_1  
 UP BND1      w_20_1    4.2794552185621712e-02
 BV BND1      x_20_2  
 UP BND1      w_20_2    4.2794552185621712e-02
 BV BND1      x_20_3  
 UP BND1      w_20_3    4.2794552185621712e-02
 BV BND1      x_20_4  
 UP BND1      w_20_4    4.2794552185621712e-02
 BV BND1      x_20_5  
 UP BND1      w_20_5    4.2794552185621712e-02
 BV BND1      x_20_6  
 UP BND1      w_20_6    4.2794552185621712e-02
 BV BND1      x_20_7  
 UP BND1      w_20_7    4.2794552185621712e-02
 BV BND1      x_20_8  
 UP BND1      w_20_8    4.2794552185621712e-02
 BV BND1      x_20_9  
 UP BND1      w_20_9    4.2794552185621712e-02
 BV BND1      x_20_10 
 UP BND1      w_20_10   4.2794552185621712e-02
 BV BND1      x_20_11 
 UP BND1      w_20_11   4.2794552185621712e-02
 BV BND1      x_20_12 
 UP BND1      w_20_12   4.2794552185621712e-02
 UP BND1      rho_20    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.2794552185621712e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.2794552185621712e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.2794552185621712e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.2794552185621712e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.2794552185621712e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.2794552185621712e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.2794552185621712e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.2794552185621712e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.2794552185621712e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.2794552185621712e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.2794552185621712e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.2794552185621712e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.2794552185621712e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.2794552185621712e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.2794552185621712e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.2794552185621712e-02
 UP BND1      rho_2     1
 BV BND1      x_21_0  
 UP BND1      w_21_0    4.2794552185621712e-02
 BV BND1      x_21_1  
 UP BND1      w_21_1    4.2794552185621712e-02
 BV BND1      x_21_2  
 UP BND1      w_21_2    4.2794552185621712e-02
 BV BND1      x_21_3  
 UP BND1      w_21_3    4.2794552185621712e-02
 BV BND1      x_21_4  
 UP BND1      w_21_4    4.2794552185621712e-02
 BV BND1      x_21_5  
 UP BND1      w_21_5    4.2794552185621712e-02
 BV BND1      x_21_6  
 UP BND1      w_21_6    4.2794552185621712e-02
 BV BND1      x_21_7  
 UP BND1      w_21_7    4.2794552185621712e-02
 BV BND1      x_21_8  
 UP BND1      w_21_8    4.2794552185621712e-02
 BV BND1      x_21_9  
 UP BND1      w_21_9    4.2794552185621712e-02
 BV BND1      x_21_10 
 UP BND1      w_21_10   4.2794552185621712e-02
 BV BND1      x_21_11 
 UP BND1      w_21_11   4.2794552185621712e-02
 BV BND1      x_21_12 
 UP BND1      w_21_12   4.2794552185621712e-02
 BV BND1      x_21_13 
 UP BND1      w_21_13   4.2794552185621712e-02
 BV BND1      x_21_14 
 UP BND1      w_21_14   4.2794552185621712e-02
 BV BND1      x_21_15 
 UP BND1      w_21_15   4.2794552185621712e-02
 UP BND1      rho_21    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.2794552185621712e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.2794552185621712e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.2794552185621712e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.2794552185621712e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.2794552185621712e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.2794552185621712e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.2794552185621712e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.2794552185621712e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.2794552185621712e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.2794552185621712e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.2794552185621712e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.2794552185621712e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.2794552185621712e-02
 BV BND1      x_12_13 
 UP BND1      w_12_13   4.2794552185621712e-02
 BV BND1      x_12_14 
 UP BND1      w_12_14   4.2794552185621712e-02
 BV BND1      x_12_15 
 UP BND1      w_12_15   4.2794552185621712e-02
 UP BND1      rho_12    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.2794552185621712e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.2794552185621712e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.2794552185621712e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.2794552185621712e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.2794552185621712e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.2794552185621712e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.2794552185621712e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.2794552185621712e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.2794552185621712e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.2794552185621712e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.2794552185621712e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.2794552185621712e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.2794552185621712e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.2794552185621712e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.2794552185621712e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.2794552185621712e-02
 BV BND1      x_7_16  
 UP BND1      w_7_16    4.2794552185621712e-02
 BV BND1      x_7_17  
 UP BND1      w_7_17    4.2794552185621712e-02
 UP BND1      rho_7     1
 UP BND1      a_16_11   1
 UP BND1      a_16_31   1
 UP BND1      a_16_20   1
 UP BND1      a_16_2    1
 UP BND1      a_16_21   1
 UP BND1      a_16_12   1
 UP BND1      a_16_7    1
 UP BND1      a_11_31   1
 UP BND1      a_11_20   1
 UP BND1      a_11_2    1
 UP BND1      a_11_21   1
 UP BND1      a_11_12   1
 UP BND1      a_11_7    1
 UP BND1      a_31_20   1
 UP BND1      a_31_2    1
 UP BND1      a_31_21   1
 UP BND1      a_31_12   1
 UP BND1      a_31_7    1
 UP BND1      a_20_2    1
 UP BND1      a_20_21   1
 UP BND1      a_20_12   1
 UP BND1      a_20_7    1
 UP BND1      a_2_21    1
 UP BND1      a_2_12    1
 UP BND1      a_2_7     1
 UP BND1      a_21_12   1
 UP BND1      a_21_7    1
 UP BND1      a_12_7    1
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_8
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 BV BND1      service_2_11_11
 BV BND1      service_2_11_12
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_12
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_12
 BV BND1      service_2_20_0
 BV BND1      service_2_20_1
 BV BND1      service_2_20_2
 BV BND1      service_2_20_3
 BV BND1      service_2_20_4
 BV BND1      service_2_20_5
 BV BND1      service_2_20_6
 BV BND1      service_2_20_7
 BV BND1      service_2_20_8
 BV BND1      service_2_20_10
 BV BND1      service_2_20_11
 BV BND1      service_2_20_12
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_21_0
 BV BND1      service_0_21_2
 BV BND1      service_0_21_3
 BV BND1      service_0_21_4
 BV BND1      service_0_21_5
 BV BND1      service_0_21_6
 BV BND1      service_0_21_7
 BV BND1      service_0_21_8
 BV BND1      service_0_21_9
 BV BND1      service_0_21_10
 BV BND1      service_0_21_11
 BV BND1      service_0_21_12
 BV BND1      service_0_21_13
 BV BND1      service_0_21_14
 BV BND1      service_0_21_15
 BV BND1      service_1_21_0
 BV BND1      service_1_21_2
 BV BND1      service_1_21_3
 BV BND1      service_1_21_4
 BV BND1      service_1_21_5
 BV BND1      service_1_21_6
 BV BND1      service_1_21_7
 BV BND1      service_1_21_8
 BV BND1      service_1_21_9
 BV BND1      service_1_21_10
 BV BND1      service_1_21_11
 BV BND1      service_1_21_12
 BV BND1      service_1_21_13
 BV BND1      service_1_21_14
 BV BND1      service_1_21_15
 BV BND1      service_2_21_0
 BV BND1      service_2_21_2
 BV BND1      service_2_21_3
 BV BND1      service_2_21_4
 BV BND1      service_2_21_5
 BV BND1      service_2_21_6
 BV BND1      service_2_21_7
 BV BND1      service_2_21_8
 BV BND1      service_2_21_9
 BV BND1      service_2_21_10
 BV BND1      service_2_21_11
 BV BND1      service_2_21_12
 BV BND1      service_2_21_13
 BV BND1      service_2_21_14
 BV BND1      service_2_21_15
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_2_12_1
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_2_12_13
 BV BND1      service_2_12_14
 BV BND1      service_2_12_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_1
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_0_7_16
 BV BND1      service_0_7_17
 BV BND1      service_1_7_0
 BV BND1      service_1_7_1
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_1_7_16
 BV BND1      service_1_7_17
 BV BND1      service_2_7_0
 BV BND1      service_2_7_1
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_2_7_16
 BV BND1      service_2_7_17
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
