* Signature: 0xd5d5a08506007c7e
NAME 
ROWS
 N  OBJ
 E  dual_column_0
 E  dual_column_1
 E  dual_column_2
 E  dual_column_3
 E  dual_column_4
 E  dual_column_5
 E  dual_column_6
 E  dual_column_7
 E  dual_column_8
 E  dual_column_9
 E  dual_column_10
 E  dual_column_11
 E  dual_column_12
 E  dual_column_13
 E  dual_column_14
 E  dual_column_15
 E  dual_column_16
 E  dual_column_17
 E  dual_column_18
 E  dual_column_19
 E  dual_column_20
 E  dual_column_21
 E  dual_column_22
 E  dual_column_23
 E  dual_column_24
 E  dual_column_25
 E  dual_column_26
 E  dual_column_27
 E  dual_column_28
 E  dual_column_29
 E  dual_column_30
 E  dual_column_31
 E  dual_column_32
 E  dual_column_33
 E  dual_column_34
 E  dual_column_35
 E  dual_column_36
 E  dual_column_37
 E  dual_column_38
 E  dual_column_39
 E  dual_column_40
 E  dual_column_41
 E  dual_column_42
 E  dual_column_43
 E  dual_column_44
 E  dual_column_45
 E  dual_column_46
 G  near_optimal_dual_band
 G  R48     
 G  R49     
 G  R50     
 G  R51     
 G  R52     
 G  R53     
 G  R54     
 G  R55     
 G  R56     
 G  R57     
 G  R58     
 G  R59     
 G  R60     
 G  R61     
 G  R62     
 G  R63     
 G  R64     
 G  R65     
 G  R66     
 G  R67     
 G  R68     
 G  R69     
 G  R70     
 G  R71     
 G  R72     
 G  R73     
COLUMNS
    pi_0      dual_column_20  1
    pi_1      dual_column_0  -0.75
    pi_1      dual_column_20  1
    pi_2      dual_column_21  1
    pi_3      dual_column_1  -0.75
    pi_3      dual_column_21  1
    pi_4      dual_column_22  1
    pi_5      dual_column_2  -0.75
    pi_5      dual_column_22  1
    pi_6      dual_column_23  1
    pi_7      dual_column_3  -0.75
    pi_7      dual_column_23  1
    pi_8      dual_column_24  1
    pi_9      dual_column_4  -0.75
    pi_9      dual_column_24  1
    pi_10     dual_column_0  1
    pi_10     dual_column_1  1
    pi_10     dual_column_2  1
    pi_10     dual_column_3  1
    pi_10     dual_column_4  1
    pi_10     near_optimal_dual_band  1
    pi_11     dual_column_1  -1
    pi_11     dual_column_2  -2
    pi_11     dual_column_3  -3
    pi_11     dual_column_4  -4
    pi_11     dual_column_16  1
    pi_12     dual_column_16  -1
    pi_12     dual_column_17  1
    pi_13     dual_column_17  -1
    pi_13     dual_column_18  1
    pi_13     near_optimal_dual_band  -1
    pi_14     dual_column_17  1
    pi_14     dual_column_18  1
    pi_14     near_optimal_dual_band  1
    pi_15     dual_column_15  -1
    pi_15     dual_column_20  1
    pi_15     dual_column_21  1
    pi_15     dual_column_22  1
    pi_15     dual_column_23  1
    pi_15     dual_column_24  1
    pi_16     dual_column_19  1
    pi_16     dual_column_21  -1
    pi_16     dual_column_22  -2
    pi_16     dual_column_23  -3
    pi_16     dual_column_24  -4
    pi_17     dual_column_29  1
    pi_18     dual_column_5  -0.75
    pi_18     dual_column_29  1
    pi_19     dual_column_30  1
    pi_20     dual_column_6  -0.75
    pi_20     dual_column_30  1
    pi_21     dual_column_31  1
    pi_22     dual_column_7  -0.75
    pi_22     dual_column_31  1
    pi_23     dual_column_32  1
    pi_24     dual_column_8  -0.75
    pi_24     dual_column_32  1
    pi_25     dual_column_33  1
    pi_26     dual_column_9  -0.75
    pi_26     dual_column_33  1
    pi_27     dual_column_5  1
    pi_27     dual_column_6  1
    pi_27     dual_column_7  1
    pi_27     dual_column_8  1
    pi_27     dual_column_9  1
    pi_27     near_optimal_dual_band  1
    pi_28     dual_column_6  -1
    pi_28     dual_column_7  -2
    pi_28     dual_column_8  -3
    pi_28     dual_column_9  -4
    pi_28     dual_column_25  1
    pi_29     dual_column_25  -0.5
    pi_29     dual_column_26  1
    pi_30     dual_column_26  -1
    pi_30     dual_column_27  1
    pi_30     near_optimal_dual_band  -1
    pi_31     dual_column_26  1
    pi_31     dual_column_27  1
    pi_31     near_optimal_dual_band  1
    pi_32     dual_column_15  -1
    pi_32     dual_column_29  1
    pi_32     dual_column_30  1
    pi_32     dual_column_31  1
    pi_32     dual_column_32  1
    pi_32     dual_column_33  1
    pi_33     dual_column_28  1
    pi_33     dual_column_30  -1
    pi_33     dual_column_31  -2
    pi_33     dual_column_32  -3
    pi_33     dual_column_33  -4
    pi_34     dual_column_38  1
    pi_35     dual_column_10  -0.75
    pi_35     dual_column_38  1
    pi_36     dual_column_39  1
    pi_37     dual_column_11  -0.75
    pi_37     dual_column_39  1
    pi_38     dual_column_40  1
    pi_39     dual_column_12  -0.75
    pi_39     dual_column_40  1
    pi_40     dual_column_41  1
    pi_41     dual_column_13  -0.75
    pi_41     dual_column_41  1
    pi_42     dual_column_42  1
    pi_43     dual_column_14  -0.75
    pi_43     dual_column_42  1
    pi_44     dual_column_10  1
    pi_44     dual_column_11  1
    pi_44     dual_column_12  1
    pi_44     dual_column_13  1
    pi_44     dual_column_14  1
    pi_44     near_optimal_dual_band  1
    pi_45     dual_column_11  -1
    pi_45     dual_column_12  -2
    pi_45     dual_column_13  -3
    pi_45     dual_column_14  -4
    pi_45     dual_column_34  1
    pi_46     dual_column_34  -0.25
    pi_46     dual_column_35  1
    pi_47     dual_column_35  -1
    pi_47     dual_column_36  1
    pi_47     near_optimal_dual_band  -1
    pi_48     dual_column_35  1
    pi_48     dual_column_36  1
    pi_48     near_optimal_dual_band  1
    pi_49     dual_column_15  -1
    pi_49     dual_column_38  1
    pi_49     dual_column_39  1
    pi_49     dual_column_40  1
    pi_49     dual_column_41  1
    pi_49     dual_column_42  1
    pi_50     dual_column_37  1
    pi_50     dual_column_39  -1
    pi_50     dual_column_40  -2
    pi_50     dual_column_41  -3
    pi_50     dual_column_42  -4
    pi_51     dual_column_17  -1
    pi_51     dual_column_26  1
    pi_51     dual_column_43  1
    pi_52     dual_column_17  1
    pi_52     dual_column_26  -1
    pi_52     dual_column_43  1
    pi_53     dual_column_17  -1
    pi_53     dual_column_35  1
    pi_53     dual_column_44  1
    pi_54     dual_column_17  1
    pi_54     dual_column_35  -1
    pi_54     dual_column_44  1
    pi_55     dual_column_26  -1
    pi_55     dual_column_35  1
    pi_55     dual_column_45  1
    pi_56     dual_column_26  1
    pi_56     dual_column_35  -1
    pi_56     dual_column_45  1
    pi_57     dual_column_19  -3
    pi_57     dual_column_28  -1.5
    pi_57     dual_column_37  -0.75
    pi_57     dual_column_43  1
    pi_57     dual_column_44  1
    pi_57     dual_column_45  1
    pi_58     dual_column_16  1
    pi_58     dual_column_25  1
    pi_58     dual_column_34  1
    pi_58     near_optimal_dual_band  2
    pi_59     dual_column_16  1
    pi_59     dual_column_25  1
    pi_59     dual_column_34  1
    pi_59     near_optimal_dual_band  5
    pi_60     dual_column_0  -0.125
    pi_60     dual_column_2  -0.125
    pi_60     dual_column_3  -0.25
    pi_60     dual_column_4  -0.375
    pi_60     dual_column_5  -0.125
    pi_60     dual_column_6  -0.0625
    pi_60     dual_column_8  -0.0625
    pi_60     dual_column_9  -0.125
    pi_60     dual_column_10  -0.125
    pi_60     dual_column_11  -0.09375
    pi_60     dual_column_12  -0.0625
    pi_60     dual_column_13  -0.03125
    pi_60     dual_column_18  0.125
    pi_60     dual_column_27  0.125
    pi_60     dual_column_36  0.125
    pi_61     dual_column_0  -1
    pi_61     dual_column_5  -1
    pi_61     dual_column_10  -1
    pi_61     dual_column_15  3
    pi_62     dual_column_2  -7.1428571428571419e-01
    pi_62     dual_column_3  -1.25
    pi_62     dual_column_4  -1.6666666666666665e+00
    pi_62     dual_column_8  -2.8571428571428570e-01
    pi_62     dual_column_9  -1
    pi_62     dual_column_14  -0.5
    pi_62     dual_column_15  3
    pi_63     dual_column_15  -2
    pi_63     dual_column_19  1
    pi_63     dual_column_28  1
    pi_63     dual_column_37  1
    pi_64     dual_column_15  -5
    pi_64     dual_column_16  -0.75
    pi_64     dual_column_19  1
    pi_64     dual_column_25  -0.75
    pi_64     dual_column_28  1
    pi_64     dual_column_34  -0.75
    pi_64     dual_column_37  1
    pi_64     near_optimal_dual_band  -3.75
    pi_65     dual_column_15  -2
    pi_65     dual_column_16  -0.75
    pi_65     dual_column_19  1
    pi_65     dual_column_25  -0.75
    pi_65     dual_column_28  1
    pi_65     dual_column_34  -0.75
    pi_65     dual_column_37  1
    pi_65     near_optimal_dual_band  -1.5
    pi_66     dual_column_15  -5
    pi_66     dual_column_19  1
    pi_66     dual_column_28  1
    pi_66     dual_column_37  1
    pi_67     dual_column_1  -0.5
    pi_67     dual_column_2  -2
    pi_67     dual_column_3  -4
    pi_67     dual_column_4  -6
    pi_67     dual_column_7  -0.5
    pi_67     dual_column_8  -1
    pi_67     dual_column_9  -2
    pi_67     dual_column_13  -0.25
    pi_67     dual_column_14  -0.5
    pi_67     dual_column_43  1
    pi_67     dual_column_44  1
    pi_67     dual_column_45  1
    pi_68     dual_column_2  -1.5
    pi_68     dual_column_3  -3.5
    pi_68     dual_column_4  -5.5
    pi_68     dual_column_6  0.5
    pi_68     dual_column_8  -0.5
    pi_68     dual_column_9  -1.5
    pi_68     dual_column_11  0.25
    pi_68     dual_column_12  0.5
    pi_68     dual_column_13  0.25
    pi_68     dual_column_43  1
    pi_68     dual_column_44  1
    pi_68     dual_column_45  1
    pi_68     near_optimal_dual_band  1.5
    pi_69     dual_column_1  1
    pi_69     dual_column_2  1
    pi_69     dual_column_3  1
    pi_69     dual_column_4  1
    pi_69     dual_column_6  1
    pi_69     dual_column_7  1
    pi_69     dual_column_8  1
    pi_69     dual_column_9  1
    pi_69     dual_column_11  1
    pi_69     dual_column_12  1
    pi_69     dual_column_13  1
    pi_69     dual_column_14  1
    pi_69     near_optimal_dual_band  1
    pi_70     dual_column_1  1
    pi_70     dual_column_2  1
    pi_70     dual_column_3  1
    pi_70     dual_column_4  1
    pi_70     dual_column_6  1
    pi_70     dual_column_7  1
    pi_70     dual_column_8  1
    pi_70     dual_column_9  1
    pi_70     dual_column_11  1
    pi_70     dual_column_12  1
    pi_70     dual_column_13  1
    pi_70     dual_column_14  1
    pi_70     near_optimal_dual_band  3
    pi_71     dual_column_1  1
    pi_71     dual_column_2  1
    pi_71     dual_column_3  1
    pi_71     dual_column_4  1
    pi_71     dual_column_6  1
    pi_71     dual_column_7  1
    pi_71     dual_column_8  1
    pi_71     dual_column_9  1
    pi_71     dual_column_12  1
    pi_71     dual_column_13  1
    pi_71     dual_column_14  1
    pi_71     near_optimal_dual_band  1
    pi_72     dual_column_1  1
    pi_72     dual_column_2  1
    pi_72     dual_column_3  1
    pi_72     dual_column_4  1
    pi_72     dual_column_6  1
    pi_72     dual_column_7  1
    pi_72     dual_column_8  1
    pi_72     dual_column_9  1
    pi_72     dual_column_12  1
    pi_72     dual_column_13  1
    pi_72     dual_column_14  1
    pi_72     near_optimal_dual_band  3
    pi_73     dual_column_1  1
    pi_73     dual_column_2  1
    pi_73     dual_column_3  1
    pi_73     dual_column_4  1
    pi_73     dual_column_7  1
    pi_73     dual_column_8  1
    pi_73     dual_column_9  1
    pi_73     dual_column_13  1
    pi_73     dual_column_14  1
    pi_74     dual_column_1  1
    pi_74     dual_column_2  1
    pi_74     dual_column_3  1
    pi_74     dual_column_4  1
    pi_74     dual_column_7  1
    pi_74     dual_column_8  1
    pi_74     dual_column_9  1
    pi_74     dual_column_13  1
    pi_74     dual_column_14  1
    pi_74     near_optimal_dual_band  2
    pi_75     dual_column_1  1
    pi_75     dual_column_2  1
    pi_75     dual_column_3  1
    pi_75     dual_column_4  1
    pi_75     dual_column_7  1
    pi_75     dual_column_8  1
    pi_75     dual_column_9  1
    pi_75     dual_column_14  1
    pi_76     dual_column_1  1
    pi_76     dual_column_2  1
    pi_76     dual_column_3  1
    pi_76     dual_column_4  1
    pi_76     dual_column_7  1
    pi_76     dual_column_8  1
    pi_76     dual_column_9  1
    pi_76     dual_column_14  1
    pi_76     near_optimal_dual_band  2
    pi_77     dual_column_2  1
    pi_77     dual_column_3  1
    pi_77     dual_column_4  1
    pi_77     dual_column_8  1
    pi_77     dual_column_9  1
    pi_78     dual_column_2  1
    pi_78     dual_column_3  1
    pi_78     dual_column_4  1
    pi_78     dual_column_8  1
    pi_78     dual_column_9  1
    pi_78     near_optimal_dual_band  2
    pi_79     dual_column_2  1
    pi_79     dual_column_3  1
    pi_79     dual_column_4  1
    pi_79     dual_column_9  1
    pi_80     dual_column_2  1
    pi_80     dual_column_3  1
    pi_80     dual_column_4  1
    pi_80     dual_column_9  1
    pi_80     near_optimal_dual_band  1
    pi_81     dual_column_3  1
    pi_81     dual_column_4  1
    pi_82     dual_column_3  1
    pi_82     dual_column_4  1
    pi_82     near_optimal_dual_band  1
    pi_83     dual_column_4  1
    pi_84     dual_column_4  1
    pi_84     near_optimal_dual_band  1
    pi_85     dual_column_15  -1
    pi_85     dual_column_21  1
    pi_85     dual_column_22  1
    pi_85     dual_column_23  1
    pi_85     dual_column_24  1
    pi_85     dual_column_30  1
    pi_85     dual_column_31  1
    pi_85     dual_column_32  1
    pi_85     dual_column_33  1
    pi_85     dual_column_39  1
    pi_85     dual_column_40  1
    pi_85     dual_column_41  1
    pi_85     dual_column_42  1
    pi_86     dual_column_1  -0.75
    pi_86     dual_column_2  -0.75
    pi_86     dual_column_3  -0.75
    pi_86     dual_column_4  -0.75
    pi_86     dual_column_6  -0.75
    pi_86     dual_column_7  -0.75
    pi_86     dual_column_8  -0.75
    pi_86     dual_column_9  -0.75
    pi_86     dual_column_11  -0.75
    pi_86     dual_column_12  -0.75
    pi_86     dual_column_13  -0.75
    pi_86     dual_column_14  -0.75
    pi_86     dual_column_15  -3
    pi_86     dual_column_21  1
    pi_86     dual_column_22  1
    pi_86     dual_column_23  1
    pi_86     dual_column_24  1
    pi_86     dual_column_30  1
    pi_86     dual_column_31  1
    pi_86     dual_column_32  1
    pi_86     dual_column_33  1
    pi_86     dual_column_39  1
    pi_86     dual_column_40  1
    pi_86     dual_column_41  1
    pi_86     dual_column_42  1
    pi_86     near_optimal_dual_band  -2.25
    pi_87     dual_column_1  -0.75
    pi_87     dual_column_2  -0.75
    pi_87     dual_column_3  -0.75
    pi_87     dual_column_4  -0.75
    pi_87     dual_column_6  -0.75
    pi_87     dual_column_7  -0.75
    pi_87     dual_column_8  -0.75
    pi_87     dual_column_9  -0.75
    pi_87     dual_column_11  -0.75
    pi_87     dual_column_12  -0.75
    pi_87     dual_column_13  -0.75
    pi_87     dual_column_14  -0.75
    pi_87     dual_column_15  -1
    pi_87     dual_column_21  1
    pi_87     dual_column_22  1
    pi_87     dual_column_23  1
    pi_87     dual_column_24  1
    pi_87     dual_column_30  1
    pi_87     dual_column_31  1
    pi_87     dual_column_32  1
    pi_87     dual_column_33  1
    pi_87     dual_column_39  1
    pi_87     dual_column_40  1
    pi_87     dual_column_41  1
    pi_87     dual_column_42  1
    pi_87     near_optimal_dual_band  -0.75
    pi_88     dual_column_15  -3
    pi_88     dual_column_21  1
    pi_88     dual_column_22  1
    pi_88     dual_column_23  1
    pi_88     dual_column_24  1
    pi_88     dual_column_30  1
    pi_88     dual_column_31  1
    pi_88     dual_column_32  1
    pi_88     dual_column_33  1
    pi_88     dual_column_39  1
    pi_88     dual_column_40  1
    pi_88     dual_column_41  1
    pi_88     dual_column_42  1
    pi_89     dual_column_15  -1
    pi_89     dual_column_21  1
    pi_89     dual_column_22  1
    pi_89     dual_column_23  1
    pi_89     dual_column_24  1
    pi_89     dual_column_30  1
    pi_89     dual_column_31  1
    pi_89     dual_column_32  1
    pi_89     dual_column_33  1
    pi_89     dual_column_40  1
    pi_89     dual_column_41  1
    pi_89     dual_column_42  1
    pi_90     dual_column_1  -0.75
    pi_90     dual_column_2  -0.75
    pi_90     dual_column_3  -0.75
    pi_90     dual_column_4  -0.75
    pi_90     dual_column_6  -0.75
    pi_90     dual_column_7  -0.75
    pi_90     dual_column_8  -0.75
    pi_90     dual_column_9  -0.75
    pi_90     dual_column_12  -0.75
    pi_90     dual_column_13  -0.75
    pi_90     dual_column_14  -0.75
    pi_90     dual_column_15  -3
    pi_90     dual_column_21  1
    pi_90     dual_column_22  1
    pi_90     dual_column_23  1
    pi_90     dual_column_24  1
    pi_90     dual_column_30  1
    pi_90     dual_column_31  1
    pi_90     dual_column_32  1
    pi_90     dual_column_33  1
    pi_90     dual_column_40  1
    pi_90     dual_column_41  1
    pi_90     dual_column_42  1
    pi_90     near_optimal_dual_band  -2.25
    pi_91     dual_column_1  -0.75
    pi_91     dual_column_2  -0.75
    pi_91     dual_column_3  -0.75
    pi_91     dual_column_4  -0.75
    pi_91     dual_column_6  -0.75
    pi_91     dual_column_7  -0.75
    pi_91     dual_column_8  -0.75
    pi_91     dual_column_9  -0.75
    pi_91     dual_column_12  -0.75
    pi_91     dual_column_13  -0.75
    pi_91     dual_column_14  -0.75
    pi_91     dual_column_15  -1
    pi_91     dual_column_21  1
    pi_91     dual_column_22  1
    pi_91     dual_column_23  1
    pi_91     dual_column_24  1
    pi_91     dual_column_30  1
    pi_91     dual_column_31  1
    pi_91     dual_column_32  1
    pi_91     dual_column_33  1
    pi_91     dual_column_40  1
    pi_91     dual_column_41  1
    pi_91     dual_column_42  1
    pi_91     near_optimal_dual_band  -0.75
    pi_92     dual_column_15  -3
    pi_92     dual_column_21  1
    pi_92     dual_column_22  1
    pi_92     dual_column_23  1
    pi_92     dual_column_24  1
    pi_92     dual_column_30  1
    pi_92     dual_column_31  1
    pi_92     dual_column_32  1
    pi_92     dual_column_33  1
    pi_92     dual_column_40  1
    pi_92     dual_column_41  1
    pi_92     dual_column_42  1
    pi_93     dual_column_21  1
    pi_93     dual_column_22  1
    pi_93     dual_column_23  1
    pi_93     dual_column_24  1
    pi_93     dual_column_31  1
    pi_93     dual_column_32  1
    pi_93     dual_column_33  1
    pi_93     dual_column_41  1
    pi_93     dual_column_42  1
    pi_94     dual_column_1  -0.75
    pi_94     dual_column_2  -0.75
    pi_94     dual_column_3  -0.75
    pi_94     dual_column_4  -0.75
    pi_94     dual_column_7  -0.75
    pi_94     dual_column_8  -0.75
    pi_94     dual_column_9  -0.75
    pi_94     dual_column_13  -0.75
    pi_94     dual_column_14  -0.75
    pi_94     dual_column_15  -2
    pi_94     dual_column_21  1
    pi_94     dual_column_22  1
    pi_94     dual_column_23  1
    pi_94     dual_column_24  1
    pi_94     dual_column_31  1
    pi_94     dual_column_32  1
    pi_94     dual_column_33  1
    pi_94     dual_column_41  1
    pi_94     dual_column_42  1
    pi_94     near_optimal_dual_band  -1.5
    pi_95     dual_column_1  -0.75
    pi_95     dual_column_2  -0.75
    pi_95     dual_column_3  -0.75
    pi_95     dual_column_4  -0.75
    pi_95     dual_column_7  -0.75
    pi_95     dual_column_8  -0.75
    pi_95     dual_column_9  -0.75
    pi_95     dual_column_13  -0.75
    pi_95     dual_column_14  -0.75
    pi_95     dual_column_21  1
    pi_95     dual_column_22  1
    pi_95     dual_column_23  1
    pi_95     dual_column_24  1
    pi_95     dual_column_31  1
    pi_95     dual_column_32  1
    pi_95     dual_column_33  1
    pi_95     dual_column_41  1
    pi_95     dual_column_42  1
    pi_96     dual_column_15  -2
    pi_96     dual_column_21  1
    pi_96     dual_column_22  1
    pi_96     dual_column_23  1
    pi_96     dual_column_24  1
    pi_96     dual_column_31  1
    pi_96     dual_column_32  1
    pi_96     dual_column_33  1
    pi_96     dual_column_41  1
    pi_96     dual_column_42  1
    pi_97     dual_column_21  1
    pi_97     dual_column_22  1
    pi_97     dual_column_23  1
    pi_97     dual_column_24  1
    pi_97     dual_column_31  1
    pi_97     dual_column_32  1
    pi_97     dual_column_33  1
    pi_97     dual_column_42  1
    pi_98     dual_column_1  -0.75
    pi_98     dual_column_2  -0.75
    pi_98     dual_column_3  -0.75
    pi_98     dual_column_4  -0.75
    pi_98     dual_column_7  -0.75
    pi_98     dual_column_8  -0.75
    pi_98     dual_column_9  -0.75
    pi_98     dual_column_14  -0.75
    pi_98     dual_column_15  -2
    pi_98     dual_column_21  1
    pi_98     dual_column_22  1
    pi_98     dual_column_23  1
    pi_98     dual_column_24  1
    pi_98     dual_column_31  1
    pi_98     dual_column_32  1
    pi_98     dual_column_33  1
    pi_98     dual_column_42  1
    pi_98     near_optimal_dual_band  -1.5
    pi_99     dual_column_1  -0.75
    pi_99     dual_column_2  -0.75
    pi_99     dual_column_3  -0.75
    pi_99     dual_column_4  -0.75
    pi_99     dual_column_7  -0.75
    pi_99     dual_column_8  -0.75
    pi_99     dual_column_9  -0.75
    pi_99     dual_column_14  -0.75
    pi_99     dual_column_21  1
    pi_99     dual_column_22  1
    pi_99     dual_column_23  1
    pi_99     dual_column_24  1
    pi_99     dual_column_31  1
    pi_99     dual_column_32  1
    pi_99     dual_column_33  1
    pi_99     dual_column_42  1
    pi_100    dual_column_15  -2
    pi_100    dual_column_21  1
    pi_100    dual_column_22  1
    pi_100    dual_column_23  1
    pi_100    dual_column_24  1
    pi_100    dual_column_31  1
    pi_100    dual_column_32  1
    pi_100    dual_column_33  1
    pi_100    dual_column_42  1
    pi_101    dual_column_22  1
    pi_101    dual_column_23  1
    pi_101    dual_column_24  1
    pi_101    dual_column_32  1
    pi_101    dual_column_33  1
    pi_102    dual_column_2  -0.75
    pi_102    dual_column_3  -0.75
    pi_102    dual_column_4  -0.75
    pi_102    dual_column_8  -0.75
    pi_102    dual_column_9  -0.75
    pi_102    dual_column_15  -2
    pi_102    dual_column_22  1
    pi_102    dual_column_23  1
    pi_102    dual_column_24  1
    pi_102    dual_column_32  1
    pi_102    dual_column_33  1
    pi_102    near_optimal_dual_band  -1.5
    pi_103    dual_column_2  -0.75
    pi_103    dual_column_3  -0.75
    pi_103    dual_column_4  -0.75
    pi_103    dual_column_8  -0.75
    pi_103    dual_column_9  -0.75
    pi_103    dual_column_22  1
    pi_103    dual_column_23  1
    pi_103    dual_column_24  1
    pi_103    dual_column_32  1
    pi_103    dual_column_33  1
    pi_104    dual_column_15  -2
    pi_104    dual_column_22  1
    pi_104    dual_column_23  1
    pi_104    dual_column_24  1
    pi_104    dual_column_32  1
    pi_104    dual_column_33  1
    pi_105    dual_column_22  1
    pi_105    dual_column_23  1
    pi_105    dual_column_24  1
    pi_105    dual_column_33  1
    pi_106    dual_column_2  -0.75
    pi_106    dual_column_3  -0.75
    pi_106    dual_column_4  -0.75
    pi_106    dual_column_9  -0.75
    pi_106    dual_column_15  -1
    pi_106    dual_column_22  1
    pi_106    dual_column_23  1
    pi_106    dual_column_24  1
    pi_106    dual_column_33  1
    pi_106    near_optimal_dual_band  -0.75
    pi_107    dual_column_2  -0.75
    pi_107    dual_column_3  -0.75
    pi_107    dual_column_4  -0.75
    pi_107    dual_column_9  -0.75
    pi_107    dual_column_22  1
    pi_107    dual_column_23  1
    pi_107    dual_column_24  1
    pi_107    dual_column_33  1
    pi_108    dual_column_15  -1
    pi_108    dual_column_22  1
    pi_108    dual_column_23  1
    pi_108    dual_column_24  1
    pi_108    dual_column_33  1
    pi_109    dual_column_23  1
    pi_109    dual_column_24  1
    pi_110    dual_column_3  -0.75
    pi_110    dual_column_4  -0.75
    pi_110    dual_column_15  -1
    pi_110    dual_column_23  1
    pi_110    dual_column_24  1
    pi_110    near_optimal_dual_band  -0.75
    pi_111    dual_column_3  -0.75
    pi_111    dual_column_4  -0.75
    pi_111    dual_column_23  1
    pi_111    dual_column_24  1
    pi_112    dual_column_15  -1
    pi_112    dual_column_23  1
    pi_112    dual_column_24  1
    pi_113    dual_column_24  1
    pi_114    dual_column_4  -0.75
    pi_114    dual_column_15  -1
    pi_114    dual_column_24  1
    pi_114    near_optimal_dual_band  -0.75
    pi_115    dual_column_4  -0.75
    pi_115    dual_column_24  1
    pi_116    dual_column_15  -1
    pi_116    dual_column_24  1
    pi_117    dual_column_46  1
    pi_117    near_optimal_dual_band  1
    pi_118    dual_column_1  -1
    pi_118    R48       -1
    pi_118    R49       1
    pi_119    dual_column_2  -1
    pi_119    R50       -1
    pi_119    R51       1
    pi_120    dual_column_3  -1
    pi_120    R52       -1
    pi_120    R53       1
    pi_121    dual_column_4  -1
    pi_121    dual_column_46  1
    pi_121    R54       -1
    pi_121    R55       1
    pi_122    dual_column_6  -1
    pi_122    R56       -1
    pi_122    R57       1
    pi_123    dual_column_7  -1
    pi_123    R58       -1
    pi_123    R59       1
    pi_124    dual_column_8  -1
    pi_124    R60       -1
    pi_124    R61       1
    pi_125    dual_column_9  -1
    pi_125    R62       -1
    pi_125    R63       1
    pi_126    dual_column_11  -1
    pi_126    R64       -1
    pi_126    R65       1
    pi_127    dual_column_12  -1
    pi_127    R66       -1
    pi_127    R67       1
    pi_128    dual_column_13  -1
    pi_128    R68       -1
    pi_128    R69       1
    pi_129    dual_column_14  -1
    pi_129    R70       -1
    pi_129    R71       1
    pi_130    dual_column_15  1
    pi_130    dual_column_46  -6.6666666666666674e-01
    pi_130    near_optimal_dual_band  1e-08
    pi_130    R72       -1
    pi_130    R73       1
    lb_0      dual_column_0  1
    ub_0      dual_column_0  1
    ub_0      near_optimal_dual_band  1
    lb_1      dual_column_1  1
    ub_1      dual_column_1  1
    ub_1      near_optimal_dual_band  1
    lb_2      dual_column_2  1
    ub_2      dual_column_2  1
    ub_2      near_optimal_dual_band  1
    lb_3      dual_column_3  1
    ub_3      dual_column_3  1
    ub_3      near_optimal_dual_band  1
    lb_4      dual_column_4  1
    ub_4      dual_column_4  1
    ub_4      near_optimal_dual_band  1
    lb_5      dual_column_5  1
    ub_5      dual_column_5  1
    ub_5      near_optimal_dual_band  1
    lb_6      dual_column_6  1
    ub_6      dual_column_6  1
    ub_6      near_optimal_dual_band  1
    lb_7      dual_column_7  1
    ub_7      dual_column_7  1
    ub_7      near_optimal_dual_band  1
    lb_8      dual_column_8  1
    ub_8      dual_column_8  1
    ub_8      near_optimal_dual_band  1
    lb_9      dual_column_9  1
    ub_9      dual_column_9  1
    ub_9      near_optimal_dual_band  1
    lb_10     dual_column_10  1
    ub_10     dual_column_10  1
    ub_10     near_optimal_dual_band  1
    lb_11     dual_column_11  1
    ub_11     dual_column_11  1
    ub_11     near_optimal_dual_band  1
    lb_12     dual_column_12  1
    ub_12     dual_column_12  1
    ub_12     near_optimal_dual_band  1
    lb_13     dual_column_13  1
    ub_13     dual_column_13  1
    ub_13     near_optimal_dual_band  1
    lb_14     dual_column_14  1
    ub_14     dual_column_14  1
    ub_14     near_optimal_dual_band  1
    lb_15     dual_column_15  1
    ub_15     dual_column_15  1
    ub_15     near_optimal_dual_band  0.75
    lb_16     dual_column_16  1
    ub_16     dual_column_16  1
    ub_16     near_optimal_dual_band  4
    lb_17     dual_column_17  1
    lb_18     dual_column_18  1
    lb_19     dual_column_19  1
    lb_20     dual_column_20  1
    lb_21     dual_column_21  1
    lb_22     dual_column_22  1
    lb_23     dual_column_23  1
    lb_24     dual_column_24  1
    lb_25     dual_column_25  1
    ub_25     dual_column_25  1
    ub_25     near_optimal_dual_band  4
    lb_26     dual_column_26  1
    lb_27     dual_column_27  1
    lb_28     dual_column_28  1
    lb_29     dual_column_29  1
    lb_30     dual_column_30  1
    lb_31     dual_column_31  1
    lb_32     dual_column_32  1
    lb_33     dual_column_33  1
    lb_34     dual_column_34  1
    ub_34     dual_column_34  1
    ub_34     near_optimal_dual_band  4
    lb_35     dual_column_35  1
    lb_36     dual_column_36  1
    lb_37     dual_column_37  1
    lb_38     dual_column_38  1
    lb_39     dual_column_39  1
    lb_40     dual_column_40  1
    lb_41     dual_column_41  1
    lb_42     dual_column_42  1
    lb_43     dual_column_43  1
    lb_44     dual_column_44  1
    lb_45     dual_column_45  1
    lb_46     dual_column_46  1
    dev_1_1   OBJ       1
    dev_1_1   R48       1
    dev_1_1   R49       1
    dev_1_2   OBJ       1
    dev_1_2   R50       1
    dev_1_2   R51       1
    dev_1_3   OBJ       1
    dev_1_3   R52       1
    dev_1_3   R53       1
    dev_1_4   OBJ       1
    dev_1_4   R54       1
    dev_1_4   R55       1
    dev_2_1   OBJ       1
    dev_2_1   R56       1
    dev_2_1   R57       1
    dev_2_2   OBJ       1
    dev_2_2   R58       1
    dev_2_2   R59       1
    dev_2_3   OBJ       1
    dev_2_3   R60       1
    dev_2_3   R61       1
    dev_2_4   OBJ       1
    dev_2_4   R62       1
    dev_2_4   R63       1
    dev_3_1   OBJ       1
    dev_3_1   R64       1
    dev_3_1   R65       1
    dev_3_2   OBJ       1
    dev_3_2   R66       1
    dev_3_2   R67       1
    dev_3_3   OBJ       1
    dev_3_3   R68       1
    dev_3_3   R69       1
    dev_3_4   OBJ       1
    dev_3_4   R70       1
    dev_3_4   R71       1
    dev_beta  OBJ       1
    dev_beta  R72       1
    dev_beta  R73       1
RHS
    RHS1      dual_column_15  1
    RHS1      dual_column_18  0.125
    RHS1      dual_column_27  0.125
    RHS1      dual_column_36  0.125
    RHS1      near_optimal_dual_band  7.4375000500000010e-01
    RHS1      R48       -0.125
    RHS1      R49       0.125
    RHS1      R52       0.125
    RHS1      R53       -0.125
    RHS1      R54       0.25
    RHS1      R55       -0.25
    RHS1      R56       -0.0625
    RHS1      R57       0.0625
    RHS1      R58       -0.125
    RHS1      R59       0.125
    RHS1      R60       -0.0625
    RHS1      R61       0.0625
    RHS1      R64       -0.03125
    RHS1      R65       0.03125
    RHS1      R66       -0.0625
    RHS1      R67       0.0625
    RHS1      R68       -0.09375
    RHS1      R69       0.09375
    RHS1      R70       -0.125
    RHS1      R71       0.125
    RHS1      R72       -1
    RHS1      R73       1
BOUNDS
 MI BND1      pi_1    
 UP BND1      pi_1      0
 MI BND1      pi_3    
 UP BND1      pi_3      0
 MI BND1      pi_5    
 UP BND1      pi_5      0
 MI BND1      pi_7    
 UP BND1      pi_7      0
 MI BND1      pi_9    
 UP BND1      pi_9      0
 FR BND1      pi_10   
 FR BND1      pi_11   
 FR BND1      pi_12   
 FR BND1      pi_15   
 FR BND1      pi_16   
 MI BND1      pi_18   
 UP BND1      pi_18     0
 MI BND1      pi_20   
 UP BND1      pi_20     0
 MI BND1      pi_22   
 UP BND1      pi_22     0
 MI BND1      pi_24   
 UP BND1      pi_24     0
 MI BND1      pi_26   
 UP BND1      pi_26     0
 FR BND1      pi_27   
 FR BND1      pi_28   
 FR BND1      pi_29   
 FR BND1      pi_32   
 FR BND1      pi_33   
 MI BND1      pi_35   
 UP BND1      pi_35     0
 MI BND1      pi_37   
 UP BND1      pi_37     0
 MI BND1      pi_39   
 UP BND1      pi_39     0
 MI BND1      pi_41   
 UP BND1      pi_41     0
 MI BND1      pi_43   
 UP BND1      pi_43     0
 FR BND1      pi_44   
 FR BND1      pi_45   
 FR BND1      pi_46   
 FR BND1      pi_49   
 FR BND1      pi_50   
 MI BND1      pi_57   
 UP BND1      pi_57     0
 MI BND1      pi_59   
 UP BND1      pi_59     0
 MI BND1      pi_65   
 UP BND1      pi_65     0
 MI BND1      pi_66   
 UP BND1      pi_66     0
 MI BND1      pi_70   
 UP BND1      pi_70     0
 MI BND1      pi_72   
 UP BND1      pi_72     0
 MI BND1      pi_74   
 UP BND1      pi_74     0
 MI BND1      pi_76   
 UP BND1      pi_76     0
 MI BND1      pi_78   
 UP BND1      pi_78     0
 MI BND1      pi_80   
 UP BND1      pi_80     0
 MI BND1      pi_82   
 UP BND1      pi_82     0
 MI BND1      pi_84   
 UP BND1      pi_84     0
 MI BND1      pi_87   
 UP BND1      pi_87     0
 MI BND1      pi_88   
 UP BND1      pi_88     0
 MI BND1      pi_91   
 UP BND1      pi_91     0
 MI BND1      pi_92   
 UP BND1      pi_92     0
 MI BND1      pi_95   
 UP BND1      pi_95     0
 MI BND1      pi_96   
 UP BND1      pi_96     0
 MI BND1      pi_99   
 UP BND1      pi_99     0
 MI BND1      pi_100  
 UP BND1      pi_100    0
 MI BND1      pi_103  
 UP BND1      pi_103    0
 MI BND1      pi_104  
 UP BND1      pi_104    0
 MI BND1      pi_107  
 UP BND1      pi_107    0
 MI BND1      pi_108  
 UP BND1      pi_108    0
 MI BND1      pi_111  
 UP BND1      pi_111    0
 MI BND1      pi_112  
 UP BND1      pi_112    0
 MI BND1      pi_115  
 UP BND1      pi_115    0
 MI BND1      pi_116  
 UP BND1      pi_116    0
 FR BND1      pi_117  
 FR BND1      pi_118  
 FR BND1      pi_119  
 FR BND1      pi_120  
 FR BND1      pi_121  
 FR BND1      pi_122  
 FR BND1      pi_123  
 FR BND1      pi_124  
 FR BND1      pi_125  
 FR BND1      pi_126  
 FR BND1      pi_127  
 FR BND1      pi_128  
 FR BND1      pi_129  
 MI BND1      ub_0    
 UP BND1      ub_0      0
 MI BND1      ub_1    
 UP BND1      ub_1      0
 MI BND1      ub_2    
 UP BND1      ub_2      0
 MI BND1      ub_3    
 UP BND1      ub_3      0
 MI BND1      ub_4    
 UP BND1      ub_4      0
 MI BND1      ub_5    
 UP BND1      ub_5      0
 MI BND1      ub_6    
 UP BND1      ub_6      0
 MI BND1      ub_7    
 UP BND1      ub_7      0
 MI BND1      ub_8    
 UP BND1      ub_8      0
 MI BND1      ub_9    
 UP BND1      ub_9      0
 MI BND1      ub_10   
 UP BND1      ub_10     0
 MI BND1      ub_11   
 UP BND1      ub_11     0
 MI BND1      ub_12   
 UP BND1      ub_12     0
 MI BND1      ub_13   
 UP BND1      ub_13     0
 MI BND1      ub_14   
 UP BND1      ub_14     0
 MI BND1      ub_15   
 UP BND1      ub_15     0
 MI BND1      ub_16   
 UP BND1      ub_16     0
 MI BND1      ub_25   
 UP BND1      ub_25     0
 MI BND1      ub_34   
 UP BND1      ub_34     0
ENDATA
