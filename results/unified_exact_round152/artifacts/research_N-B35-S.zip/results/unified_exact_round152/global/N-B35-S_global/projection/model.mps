* Signature: 0x8d117c1e082e1a65
NAME 
ROWS
 N  OBJ
 E  R0      
 E  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 E  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 E  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 E  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 E  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 E  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 E  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 E  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 E  R91     
 E  R92     
 E  R93     
 E  R94     
 E  R95     
 E  R96     
 E  R97     
 E  R98     
 E  R99     
 E  R100    
 E  R101    
 E  R102    
 E  R103    
 E  R104    
 E  R105    
 E  R106    
 E  R107    
 E  R108    
 E  R109    
 E  R110    
 E  R111    
 E  R112    
 E  R113    
 E  R114    
 E  R115    
 E  R116    
 E  R117    
 E  R118    
 E  R119    
 E  R120    
 E  R121    
 E  R122    
 E  R123    
 E  R124    
 E  R125    
 E  R126    
 E  R127    
 E  R128    
 E  R129    
 E  R130    
 E  R131    
 E  R132    
 E  R133    
 E  R134    
 E  R135    
 E  R136    
 E  R137    
 E  R138    
 E  R139    
 E  R140    
 E  R141    
 E  R142    
 E  R143    
 E  R144    
 E  R145    
 E  R146    
 E  R147    
 E  R148    
 E  R149    
 E  R150    
 E  R151    
 E  R152    
 E  R153    
 E  R154    
 E  R155    
 E  R156    
 E  R157    
 E  R158    
 E  R159    
 E  R160    
 E  R161    
 E  R162    
 E  R163    
 E  R164    
 E  R165    
 E  R166    
 E  R167    
 E  R168    
 E  R169    
 E  R170    
 E  R171    
 E  R172    
 E  R173    
 E  R174    
 E  R175    
 E  R176    
 E  R177    
 E  R178    
 E  R179    
 E  R180    
 E  R181    
 E  R182    
 E  R183    
 E  R184    
 E  R185    
 E  R186    
 E  R187    
 E  R188    
 E  R189    
 E  R190    
 E  R191    
 E  R192    
 E  R193    
 E  R194    
 E  R195    
 E  R196    
 E  R197    
 E  R198    
 E  R199    
 E  R200    
 E  R201    
 E  R202    
 E  R203    
 E  R204    
 E  R205    
 E  R206    
 E  R207    
 E  R208    
 E  R209    
 E  R210    
 E  R211    
 E  R212    
 E  R213    
 E  R214    
 E  R215    
 E  R216    
 E  R217    
 E  R218    
 E  R219    
 E  R220    
 E  R221    
 E  R222    
 E  R223    
 E  R224    
 E  R225    
 E  R226    
 E  R227    
 E  R228    
 E  R229    
 E  R230    
 E  R231    
 E  R232    
 E  R233    
 E  R234    
 E  R235    
 E  R236    
 E  R237    
 E  R238    
 E  R239    
 E  R240    
 E  R241    
 E  R242    
 E  R243    
 E  R244    
 E  R245    
 E  R246    
 E  R247    
 E  R248    
 E  R249    
 E  R250    
 E  R251    
 E  R252    
 E  R253    
 E  R254    
 E  R255    
 E  R256    
 E  R257    
 E  R258    
 E  R259    
 E  R260    
 E  R261    
 E  R262    
 E  R263    
 E  R264    
 E  R265    
 E  R266    
 E  R267    
 E  R268    
 E  R269    
 E  R270    
 E  R271    
 E  R272    
 E  R273    
 E  R274    
 E  R275    
 E  R276    
 E  R277    
 E  R278    
 E  R279    
 E  R280    
 E  R281    
 E  R282    
 E  R283    
 E  R284    
 E  R285    
 E  R286    
 E  R287    
 E  R288    
 E  R289    
 E  R290    
 E  R291    
 E  R292    
 E  R293    
 E  R294    
 E  R295    
 E  R296    
 E  R297    
 E  R298    
 E  R299    
 E  R300    
 E  R301    
 E  R302    
 E  R303    
 E  R304    
 E  R305    
 E  R306    
 E  R307    
 E  R308    
 E  R309    
 E  R310    
 E  R311    
 E  R312    
 E  R313    
 E  R314    
 E  R315    
 E  R316    
 E  R317    
 E  R318    
 E  R319    
 E  R320    
 E  R321    
 E  R322    
 E  R323    
 E  R324    
 E  R325    
 E  R326    
 E  R327    
 E  R328    
 E  R329    
 E  R330    
 E  R331    
 E  R332    
 E  R333    
 E  R334    
 E  R335    
 E  R336    
 E  R337    
 E  R338    
 E  R339    
 E  R340    
 E  R341    
 E  R342    
 E  R343    
 E  R344    
 E  R345    
 E  R346    
 E  R347    
 E  R348    
 E  R349    
 E  R350    
 E  R351    
 E  R352    
 E  R353    
 E  R354    
 E  R355    
 E  R356    
 E  R357    
 E  R358    
 E  R359    
 E  R360    
 E  R361    
 E  R362    
 E  R363    
 E  R364    
 E  R365    
 E  R366    
 E  R367    
 E  R368    
 E  R369    
 E  R370    
 E  R371    
 E  R372    
 E  R373    
 E  R374    
 E  R375    
 E  R376    
 E  R377    
 E  R378    
 E  R379    
 E  R380    
 E  R381    
 E  R382    
 E  R383    
 E  R384    
 E  R385    
 E  R386    
 E  R387    
 E  R388    
 E  R389    
 E  R390    
 E  R391    
 E  R392    
 E  R393    
 E  R394    
 E  R395    
 E  R396    
 E  R397    
 E  R398    
 E  R399    
 E  R400    
 E  R401    
 E  R402    
 E  R403    
 E  R404    
 E  R405    
 E  R406    
 E  R407    
 E  R408    
 E  R409    
 E  R410    
 E  R411    
 E  R412    
 E  R413    
 E  R414    
 E  R415    
 E  R416    
 E  R417    
 E  R418    
 E  R419    
 E  R420    
 E  R421    
 E  R422    
 E  R423    
 E  R424    
 E  R425    
 E  R426    
 E  R427    
 E  R428    
 E  R429    
 E  R430    
 E  R431    
 E  R432    
 E  R433    
 E  R434    
 E  R435    
 E  R436    
 E  R437    
 E  R438    
 E  R439    
 E  R440    
 E  R441    
 E  R442    
 E  R443    
 E  R444    
 E  R445    
 E  R446    
 E  R447    
 E  R448    
 E  R449    
 E  R450    
 E  R451    
 E  R452    
 E  R453    
 E  R454    
 E  R455    
 E  R456    
 E  R457    
 E  R458    
 E  R459    
 E  R460    
 E  R461    
 E  R462    
 E  R463    
 E  R464    
 E  R465    
 E  R466    
 E  R467    
 E  R468    
 E  R469    
 E  R470    
 E  R471    
 E  R472    
 E  R473    
 E  R474    
 E  R475    
 E  R476    
 E  R477    
 E  R478    
 E  R479    
 E  R480    
 E  R481    
 E  R482    
 E  R483    
 E  R484    
 E  R485    
 E  R486    
 E  R487    
 E  R488    
 E  R489    
 E  R490    
 E  R491    
 E  R492    
 E  R493    
 E  R494    
 E  R495    
 E  R496    
 E  R497    
 E  R498    
 E  R499    
 E  R500    
 E  R501    
 E  R502    
 E  R503    
 E  R504    
 E  R505    
 E  R506    
 E  R507    
 E  R508    
 E  R509    
 E  R510    
 E  R511    
 E  R512    
 E  R513    
 E  R514    
 E  R515    
 E  R516    
 E  R517    
 E  R518    
 E  R519    
 E  R520    
 E  R521    
 E  R522    
 E  R523    
 E  R524    
 E  R525    
 E  R526    
 E  R527    
 E  R528    
 E  R529    
 E  R530    
 E  R531    
 E  R532    
 E  R533    
 E  R534    
 E  R535    
 E  R536    
 E  R537    
 E  R538    
 E  R539    
 E  R540    
 E  R541    
 E  R542    
 E  R543    
 E  R544    
 E  R545    
 E  R546    
 E  R547    
 E  R548    
 E  R549    
 E  R550    
 E  R551    
 E  R552    
 E  R553    
 E  R554    
 E  R555    
 E  R556    
 E  R557    
 E  R558    
 E  R559    
 E  R560    
 E  R561    
 E  R562    
 E  R563    
 E  R564    
 E  R565    
 E  R566    
 E  R567    
 E  R568    
 E  R569    
 E  R570    
 E  R571    
 E  R572    
 E  R573    
 E  R574    
 E  R575    
 E  R576    
 E  R577    
 E  R578    
 E  R579    
 E  R580    
 E  R581    
 E  R582    
 E  R583    
 E  R584    
 E  R585    
 E  R586    
 E  R587    
 E  R588    
 E  R589    
 E  R590    
 E  R591    
 E  R592    
 E  R593    
 E  R594    
 E  R595    
 E  R596    
 E  R597    
 E  R598    
 E  R599    
 E  R600    
 E  R601    
 E  R602    
 E  R603    
 E  R604    
 E  R605    
 E  R606    
 E  R607    
 E  R608    
 E  R609    
 E  R610    
 E  R611    
 E  R612    
 E  R613    
 E  R614    
 E  R615    
 E  R616    
 E  R617    
 E  R618    
 E  R619    
 E  R620    
 E  R621    
 E  R622    
 E  R623    
 E  R624    
 E  R625    
 E  R626    
 E  R627    
 E  R628    
 E  R629    
 E  R630    
 E  R631    
 E  R632    
 E  R633    
 E  R634    
 E  R635    
 E  R636    
 E  R637    
 E  R638    
 E  R639    
 E  R640    
 E  R641    
 E  R642    
 E  R643    
 E  R644    
 E  R645    
 E  R646    
 E  R647    
 E  R648    
 E  R649    
 E  R650    
 E  R651    
 E  R652    
 E  R653    
 E  R654    
 E  R655    
 E  R656    
 E  R657    
 E  R658    
 E  R659    
 E  R660    
 E  R661    
 E  R662    
 E  R663    
 E  R664    
 E  R665    
 E  R666    
 E  R667    
 E  R668    
 E  R669    
 E  R670    
 E  R671    
 E  R672    
 E  R673    
 E  R674    
 E  R675    
 E  R676    
 E  R677    
 E  R678    
 E  R679    
 E  R680    
 E  R681    
 E  R682    
 E  R683    
 E  R684    
 E  R685    
 E  R686    
 E  R687    
 E  R688    
 E  R689    
 E  R690    
 E  R691    
 E  R692    
 E  R693    
 E  R694    
 E  R695    
 E  R696    
 E  R697    
 E  R698    
 E  R699    
 E  R700    
 E  R701    
 E  R702    
 E  R703    
 E  R704    
 E  R705    
 E  R706    
 E  R707    
 E  R708    
 E  R709    
 E  R710    
 E  R711    
 E  R712    
 E  R713    
 E  R714    
 E  R715    
 E  R716    
 E  R717    
 E  R718    
 E  R719    
 E  R720    
 E  R721    
 E  R722    
 E  R723    
 E  R724    
 E  R725    
 E  R726    
 E  R727    
 E  R728    
 E  R729    
 E  R730    
 E  R731    
 E  R732    
 E  R733    
 E  R734    
 E  R735    
 E  R736    
 E  R737    
 E  R738    
 E  R739    
 E  R740    
 E  R741    
 E  R742    
 E  R743    
 E  R744    
 E  R745    
 E  R746    
 E  R747    
 E  R748    
 E  R749    
 E  R750    
 E  R751    
 E  R752    
 E  R753    
 E  R754    
 E  R755    
 E  R756    
 E  R757    
 E  R758    
 E  R759    
 E  R760    
 E  R761    
 E  R762    
 E  R763    
 E  R764    
 E  R765    
 E  R766    
 E  R767    
 E  R768    
 E  R769    
 E  R770    
 E  R771    
 E  R772    
 E  R773    
 E  R774    
 E  R775    
 E  R776    
 E  R777    
 E  R778    
 E  R779    
 E  R780    
 E  R781    
 E  R782    
 E  R783    
 E  R784    
 E  R785    
 E  R786    
 E  R787    
 E  R788    
 E  R789    
 E  R790    
 E  R791    
 E  R792    
 E  R793    
 E  R794    
 E  R795    
 E  R796    
 E  R797    
 E  R798    
 E  R799    
 E  R800    
 E  R801    
 E  R802    
 E  R803    
 E  R804    
 E  R805    
 E  R806    
 E  R807    
 E  R808    
 E  R809    
 E  R810    
 E  R811    
 E  R812    
 E  R813    
 E  R814    
 E  R815    
 E  R816    
 E  R817    
 E  R818    
 E  R819    
 E  R820    
 E  R821    
 E  R822    
 E  R823    
 E  R824    
 E  R825    
 E  R826    
 E  R827    
 E  R828    
 E  R829    
 E  R830    
 E  R831    
 E  R832    
 E  R833    
 E  R834    
 E  R835    
 E  R836    
 E  R837    
 E  R838    
 E  R839    
 E  R840    
 E  R841    
 E  R842    
 E  R843    
 E  R844    
 E  R845    
 E  R846    
 E  R847    
 E  R848    
 E  R849    
 E  R850    
 E  R851    
 E  R852    
 E  R853    
 E  R854    
 E  R855    
 E  R856    
 E  R857    
 E  R858    
 E  R859    
 E  R860    
 E  R861    
 E  R862    
 E  R863    
 E  R864    
 E  R865    
 E  R866    
 E  R867    
 E  R868    
 E  R869    
 E  R870    
 E  R871    
 E  R872    
 E  R873    
 E  R874    
 E  R875    
 E  R876    
 E  R877    
 E  R878    
 E  R879    
 E  R880    
 E  R881    
 E  R882    
 E  R883    
 E  R884    
 E  R885    
 E  R886    
 E  R887    
 E  R888    
 E  R889    
 E  R890    
 E  R891    
 E  R892    
 E  R893    
 E  R894    
 E  R895    
 E  R896    
 E  R897    
 E  R898    
 E  R899    
 E  R900    
 E  R901    
 E  R902    
 E  R903    
 E  R904    
 E  R905    
 E  R906    
 E  R907    
 E  R908    
 E  R909    
 E  R910    
 E  R911    
 E  R912    
 E  R913    
 E  R914    
 E  R915    
 E  R916    
 E  R917    
 E  R918    
 E  R919    
 E  R920    
 E  R921    
 E  R922    
 E  R923    
 E  R924    
 E  R925    
 E  R926    
 E  R927    
 E  R928    
 E  R929    
 E  R930    
 E  R931    
 E  R932    
 E  R933    
 E  R934    
 E  R935    
 E  R936    
 E  R937    
 E  R938    
 E  R939    
 E  R940    
 E  R941    
 E  R942    
 E  R943    
 E  R944    
 E  R945    
 E  R946    
 E  R947    
 E  R948    
 E  R949    
 E  R950    
 E  R951    
 E  R952    
 E  R953    
 E  R954    
 E  R955    
 E  R956    
 E  R957    
 E  R958    
 E  R959    
 E  R960    
 E  R961    
 E  R962    
 E  R963    
 E  R964    
 E  R965    
 E  R966    
 E  R967    
 E  R968    
 E  R969    
 E  R970    
 E  R971    
 E  R972    
 E  R973    
 E  R974    
 E  R975    
 E  R976    
 E  R977    
 E  R978    
 E  R979    
 E  R980    
 E  R981    
 E  R982    
 E  R983    
 E  R984    
 E  R985    
 E  R986    
 E  R987    
 E  R988    
 E  R989    
 E  R990    
 E  R991    
 E  R992    
 E  R993    
 E  R994    
 E  R995    
 E  R996    
 E  R997    
 E  R998    
 E  R999    
 E  R1000   
 E  R1001   
 E  R1002   
 E  R1003   
 E  R1004   
 E  R1005   
 E  R1006   
 E  R1007   
 E  R1008   
 E  R1009   
 E  R1010   
 E  R1011   
 E  R1012   
 E  R1013   
 E  R1014   
 E  R1015   
 E  R1016   
 E  R1017   
 E  R1018   
 E  R1019   
 E  R1020   
 E  R1021   
 E  R1022   
 E  R1023   
 E  R1024   
 E  R1025   
 E  R1026   
 E  R1027   
 E  R1028   
 E  R1029   
 E  R1030   
 E  R1031   
 E  R1032   
 E  R1033   
 E  R1034   
 E  R1035   
 E  R1036   
 E  R1037   
 E  R1038   
 E  R1039   
 E  R1040   
 E  R1041   
 E  R1042   
 E  R1043   
 E  R1044   
 E  R1045   
 E  R1046   
 E  R1047   
 E  R1048   
 E  R1049   
 E  R1050   
 E  R1051   
 E  R1052   
 E  R1053   
 E  R1054   
 E  R1055   
 E  R1056   
 E  R1057   
 E  R1058   
 E  R1059   
 E  R1060   
 E  R1061   
 E  R1062   
 E  R1063   
 E  R1064   
 E  R1065   
 E  R1066   
 E  R1067   
 E  R1068   
 E  R1069   
 E  R1070   
 E  R1071   
 E  R1072   
 E  R1073   
 E  R1074   
 E  R1075   
 E  R1076   
 E  R1077   
 E  R1078   
 E  R1079   
 E  R1080   
 E  R1081   
 E  R1082   
 E  R1083   
 E  R1084   
 E  R1085   
 E  R1086   
 E  R1087   
 E  R1088   
 E  R1089   
 E  R1090   
 E  R1091   
 E  R1092   
 E  R1093   
 E  R1094   
 E  R1095   
 E  R1096   
 E  R1097   
 E  R1098   
 E  R1099   
 E  R1100   
 E  R1101   
 E  R1102   
 E  R1103   
 E  R1104   
 E  R1105   
 E  R1106   
 E  R1107   
 E  R1108   
 E  R1109   
 E  R1110   
 E  R1111   
 E  R1112   
 E  R1113   
 E  R1114   
 E  R1115   
 E  R1116   
 E  R1117   
 E  R1118   
 E  R1119   
 E  R1120   
 E  R1121   
 E  R1122   
 E  R1123   
 E  R1124   
 E  R1125   
 E  R1126   
 E  R1127   
 E  R1128   
 E  R1129   
 E  R1130   
 E  R1131   
 E  R1132   
 E  R1133   
 E  R1134   
 E  R1135   
 E  R1136   
 E  R1137   
 E  R1138   
 E  R1139   
 E  R1140   
 E  R1141   
 E  R1142   
 E  R1143   
 E  R1144   
 E  R1145   
 E  R1146   
 E  R1147   
 E  R1148   
 E  R1149   
 E  R1150   
 E  R1151   
 E  R1152   
 E  R1153   
 E  R1154   
 E  R1155   
 E  R1156   
 E  R1157   
 E  R1158   
 E  R1159   
 E  R1160   
 E  R1161   
 E  R1162   
 E  R1163   
 E  R1164   
 E  R1165   
 E  R1166   
 E  R1167   
 E  R1168   
 E  R1169   
 E  R1170   
 E  R1171   
 E  R1172   
 E  R1173   
 E  R1174   
 E  R1175   
 E  R1176   
 E  R1177   
 E  R1178   
 E  R1179   
 E  R1180   
 E  R1181   
 E  R1182   
 E  R1183   
 E  R1184   
 E  R1185   
 E  R1186   
 E  R1187   
 E  R1188   
 E  R1189   
 E  R1190   
 E  R1191   
 E  R1192   
 E  R1193   
 E  R1194   
 E  R1195   
 E  R1196   
 E  R1197   
 E  R1198   
 E  R1199   
 E  R1200   
 E  R1201   
 E  R1202   
 E  R1203   
 E  R1204   
 E  R1205   
 E  R1206   
 E  R1207   
 E  R1208   
 E  R1209   
 E  R1210   
 E  R1211   
 E  R1212   
 E  R1213   
 E  R1214   
 E  R1215   
 E  R1216   
 E  R1217   
 E  R1218   
 E  R1219   
 E  R1220   
 E  R1221   
 E  R1222   
 E  R1223   
 E  R1224   
 E  R1225   
 E  R1226   
 E  R1227   
 E  R1228   
 E  R1229   
 E  R1230   
 E  R1231   
 E  R1232   
 E  R1233   
 E  R1234   
 E  R1235   
 E  R1236   
 E  R1237   
 E  R1238   
 E  R1239   
 E  R1240   
 E  R1241   
 E  R1242   
 E  R1243   
 E  R1244   
 E  R1245   
 E  R1246   
 E  R1247   
 E  R1248   
 E  R1249   
 E  R1250   
 E  R1251   
 E  R1252   
 E  R1253   
 E  R1254   
 E  R1255   
 E  R1256   
 E  R1257   
 E  R1258   
 E  R1259   
 E  R1260   
 E  R1261   
 E  R1262   
 E  R1263   
 E  R1264   
 E  R1265   
 E  R1266   
 E  R1267   
 E  R1268   
 E  R1269   
 E  R1270   
 E  R1271   
 E  R1272   
 E  R1273   
 E  R1274   
 E  R1275   
 E  R1276   
 E  R1277   
 E  R1278   
 E  R1279   
 E  R1280   
 E  R1281   
 E  R1282   
 E  R1283   
 E  R1284   
 E  R1285   
 E  R1286   
 E  R1287   
 E  R1288   
 E  R1289   
 E  R1290   
 E  R1291   
 E  R1292   
 E  R1293   
 E  R1294   
 E  R1295   
 E  R1296   
 E  R1297   
 E  R1298   
 E  R1299   
 E  R1300   
 E  R1301   
 E  R1302   
 E  R1303   
 E  R1304   
 E  R1305   
 E  R1306   
 E  R1307   
 E  R1308   
 E  R1309   
 E  R1310   
 E  R1311   
 E  R1312   
 E  R1313   
 E  R1314   
 E  R1315   
 E  R1316   
 E  R1317   
 E  R1318   
 E  R1319   
 E  R1320   
 E  R1321   
 E  R1322   
 E  R1323   
 E  R1324   
 E  R1325   
 E  R1326   
 E  R1327   
 E  R1328   
 E  R1329   
 E  R1330   
 E  R1331   
 E  R1332   
 E  R1333   
 E  R1334   
 E  R1335   
 E  R1336   
 E  R1337   
 E  R1338   
 E  R1339   
 E  R1340   
 E  R1341   
 E  R1342   
 E  R1343   
 E  R1344   
 E  R1345   
 E  R1346   
 E  R1347   
 E  R1348   
 E  R1349   
 E  R1350   
 E  R1351   
 E  R1352   
 E  R1353   
 E  R1354   
 E  R1355   
 E  R1356   
 E  R1357   
 E  R1358   
 E  R1359   
 E  R1360   
 E  R1361   
 E  R1362   
 E  R1363   
 E  R1364   
 E  R1365   
 E  R1366   
 E  R1367   
 E  R1368   
 E  R1369   
 E  R1370   
 E  R1371   
 E  R1372   
 E  R1373   
 E  R1374   
 E  R1375   
 E  R1376   
 E  R1377   
 E  R1378   
 E  R1379   
 E  R1380   
 E  R1381   
 E  R1382   
 E  R1383   
 E  R1384   
 E  R1385   
 E  R1386   
 E  R1387   
 E  R1388   
 E  R1389   
 E  R1390   
 E  R1391   
 E  R1392   
 E  R1393   
 E  R1394   
 E  R1395   
 E  R1396   
 E  R1397   
 E  R1398   
 E  R1399   
 E  R1400   
 E  R1401   
 E  R1402   
 E  R1403   
 E  R1404   
 E  R1405   
 E  R1406   
 E  R1407   
 E  R1408   
 E  R1409   
 E  R1410   
 E  R1411   
 E  R1412   
 E  R1413   
 E  R1414   
 E  R1415   
 E  R1416   
 E  R1417   
 E  R1418   
 E  R1419   
 E  R1420   
 E  R1421   
 E  R1422   
 E  R1423   
 E  R1424   
 E  R1425   
 E  R1426   
 E  R1427   
 E  R1428   
 E  R1429   
 E  R1430   
 E  R1431   
 E  R1432   
 E  R1433   
 E  R1434   
 E  R1435   
 E  R1436   
 E  R1437   
 E  R1438   
 E  R1439   
 E  R1440   
 E  R1441   
 E  R1442   
 E  R1443   
 E  R1444   
 E  R1445   
 E  R1446   
 E  R1447   
 E  R1448   
 E  R1449   
 E  R1450   
 E  R1451   
 E  R1452   
 E  R1453   
 E  R1454   
 E  R1455   
 E  R1456   
 E  R1457   
 E  R1458   
 E  R1459   
 E  R1460   
 E  R1461   
 E  R1462   
 E  R1463   
 E  R1464   
 E  R1465   
 E  R1466   
 E  R1467   
 E  R1468   
 E  R1469   
 E  R1470   
 E  R1471   
 E  R1472   
 E  R1473   
 E  R1474   
 E  R1475   
 E  R1476   
 E  R1477   
 E  R1478   
 E  R1479   
 E  R1480   
 E  R1481   
 E  R1482   
 E  R1483   
 E  R1484   
 E  R1485   
 E  R1486   
 E  R1487   
 E  R1488   
 E  R1489   
 E  R1490   
 E  R1491   
 E  R1492   
 E  R1493   
 E  R1494   
 E  R1495   
 E  R1496   
 E  R1497   
 E  R1498   
 E  R1499   
 E  R1500   
 E  R1501   
 E  R1502   
 E  R1503   
 E  R1504   
 E  R1505   
 E  R1506   
 E  R1507   
 E  R1508   
 E  R1509   
 E  R1510   
 E  R1511   
 E  R1512   
 E  R1513   
 E  R1514   
 E  R1515   
 E  R1516   
 E  R1517   
 E  R1518   
 E  R1519   
 E  R1520   
 E  R1521   
 E  R1522   
 E  R1523   
 E  R1524   
 E  R1525   
 E  R1526   
 E  R1527   
 E  R1528   
 E  R1529   
 E  R1530   
 E  R1531   
 E  R1532   
 E  R1533   
 E  R1534   
 E  R1535   
 E  R1536   
 E  R1537   
 E  R1538   
 E  R1539   
 E  R1540   
 E  R1541   
 E  R1542   
 E  R1543   
 E  R1544   
 E  R1545   
 E  R1546   
 E  R1547   
 E  R1548   
 E  R1549   
 E  R1550   
 E  R1551   
 E  R1552   
 E  R1553   
 E  R1554   
 E  R1555   
 E  R1556   
 E  R1557   
 E  R1558   
 E  R1559   
 E  R1560   
 E  R1561   
 E  R1562   
 E  R1563   
 E  R1564   
 E  R1565   
 E  R1566   
 E  R1567   
 E  R1568   
 E  R1569   
 E  R1570   
 E  R1571   
 E  R1572   
 E  R1573   
 E  R1574   
 E  R1575   
 E  R1576   
 E  R1577   
 E  R1578   
 E  R1579   
 E  R1580   
 E  R1581   
 E  R1582   
 E  R1583   
 E  R1584   
 E  R1585   
 E  R1586   
 E  R1587   
 E  R1588   
 E  R1589   
 E  R1590   
 E  R1591   
 E  R1592   
 E  R1593   
 E  R1594   
 E  R1595   
 E  R1596   
 E  R1597   
 E  R1598   
 E  R1599   
 E  R1600   
 E  R1601   
 E  R1602   
 E  R1603   
 E  R1604   
 E  R1605   
 E  R1606   
 E  R1607   
 E  R1608   
 E  R1609   
 E  R1610   
 E  R1611   
 E  R1612   
 E  R1613   
 E  R1614   
 E  R1615   
 E  R1616   
 E  R1617   
 E  R1618   
 E  R1619   
 E  R1620   
 E  R1621   
 E  R1622   
 E  R1623   
 E  R1624   
 E  R1625   
 E  R1626   
 E  R1627   
 E  R1628   
 E  R1629   
 E  R1630   
 E  R1631   
 E  R1632   
 E  R1633   
 E  R1634   
 E  R1635   
 E  R1636   
 E  R1637   
 E  R1638   
 E  R1639   
 E  R1640   
 E  R1641   
 E  R1642   
 E  R1643   
 E  R1644   
 E  R1645   
 E  R1646   
 E  R1647   
 E  R1648   
 E  R1649   
 E  R1650   
 E  R1651   
 E  R1652   
 E  R1653   
 E  R1654   
 E  R1655   
 E  R1656   
 E  R1657   
 E  R1658   
 E  R1659   
 E  R1660   
 E  R1661   
 E  R1662   
 E  R1663   
 E  R1664   
 E  R1665   
 E  R1666   
 E  R1667   
 E  R1668   
 E  R1669   
 E  R1670   
 E  R1671   
 E  R1672   
 E  R1673   
 E  R1674   
 E  R1675   
 E  R1676   
 E  R1677   
 E  R1678   
 E  R1679   
 E  R1680   
 E  R1681   
 E  R1682   
 E  R1683   
 E  R1684   
 E  R1685   
 E  R1686   
 E  R1687   
 E  R1688   
 E  R1689   
 E  R1690   
 E  R1691   
 E  R1692   
 E  R1693   
 E  R1694   
 E  R1695   
 E  R1696   
 E  R1697   
 E  R1698   
 E  R1699   
 E  R1700   
 E  R1701   
 E  R1702   
 E  R1703   
 E  R1704   
 E  R1705   
 E  R1706   
 E  R1707   
 E  R1708   
 E  R1709   
 E  R1710   
 E  R1711   
 E  R1712   
 E  R1713   
 E  R1714   
 E  R1715   
 E  R1716   
 E  R1717   
 E  R1718   
 E  R1719   
 E  R1720   
 E  R1721   
 E  R1722   
 E  R1723   
 E  R1724   
 E  R1725   
 E  R1726   
 E  R1727   
 E  R1728   
 E  R1729   
 E  R1730   
 E  R1731   
 E  R1732   
 E  R1733   
 E  R1734   
 E  R1735   
 E  R1736   
 E  R1737   
 E  R1738   
 E  R1739   
 E  R1740   
 E  R1741   
 E  R1742   
 E  R1743   
 E  R1744   
 E  R1745   
 E  R1746   
 E  R1747   
 E  R1748   
 E  R1749   
 E  R1750   
 E  R1751   
 E  R1752   
 E  R1753   
 E  R1754   
 E  R1755   
 E  R1756   
 E  R1757   
 E  R1758   
 E  R1759   
 E  R1760   
 E  R1761   
 E  R1762   
 E  R1763   
 E  R1764   
 E  R1765   
 E  R1766   
 E  R1767   
 E  R1768   
 E  R1769   
 E  R1770   
 E  R1771   
 E  R1772   
 E  R1773   
 E  R1774   
 E  R1775   
 E  R1776   
 E  R1777   
 E  R1778   
 E  R1779   
 E  R1780   
 E  R1781   
 E  R1782   
 E  R1783   
 E  R1784   
 E  R1785   
 E  R1786   
 E  R1787   
 E  R1788   
 E  R1789   
 E  R1790   
 E  R1791   
 E  R1792   
 E  R1793   
 E  R1794   
 E  R1795   
 E  R1796   
 E  R1797   
 E  R1798   
 E  R1799   
 E  R1800   
 E  R1801   
 E  R1802   
 E  R1803   
 E  R1804   
 E  R1805   
 E  R1806   
 E  R1807   
 E  R1808   
 E  R1809   
 E  R1810   
 E  R1811   
 E  R1812   
 E  R1813   
 E  R1814   
 E  R1815   
 E  R1816   
 E  R1817   
 E  R1818   
 E  R1819   
 E  R1820   
 E  R1821   
 E  R1822   
 E  R1823   
 E  R1824   
 E  R1825   
 E  R1826   
 E  R1827   
 E  R1828   
 E  R1829   
 E  R1830   
 E  R1831   
 E  R1832   
 E  R1833   
 E  R1834   
 E  R1835   
 E  R1836   
 E  R1837   
 E  R1838   
 E  R1839   
 E  R1840   
 E  R1841   
 E  R1842   
 E  marginal_1_2
 E  marginal_1_8
 E  marginal_1_10
 E  marginal_2_6
 E  marginal_2_7
 E  marginal_3_6
 E  marginal_3_7
 E  marginal_4_6
 E  marginal_4_7
 E  marginal_5_2
 E  marginal_5_4
 E  marginal_5_8
 E  marginal_6_1
 E  marginal_6_5
 E  marginal_7_5
 E  marginal_7_8
 E  marginal_8_5
 E  marginal_8_7
 E  marginal_8_10
 E  marginal_9_3
 E  marginal_9_5
 E  marginal_10_5
 E  marginal_10_6
 E  marginal_10_10
 E  marginal_11_2
 E  marginal_11_5
 E  marginal_12_4
 E  marginal_12_7
 E  marginal_13_4
 E  marginal_13_7
 E  marginal_13_8
 E  marginal_14_2
 E  marginal_14_8
 E  marginal_15_3
 E  marginal_15_8
 E  marginal_16_3
 E  marginal_16_6
 E  marginal_17_7
 E  marginal_17_9
 E  marginal_18_5
 E  marginal_18_6
 E  marginal_18_9
 E  marginal_19_2
 E  marginal_19_4
 E  marginal_20_3
 E  marginal_20_6
 E  marginal_21_1
 E  marginal_21_4
 E  marginal_21_7
 E  marginal_22_5
 E  marginal_22_6
 E  marginal_23_3
 E  marginal_23_4
 E  marginal_23_5
 E  marginal_24_4
 E  marginal_24_7
 E  marginal_24_8
 E  marginal_25_6
 E  marginal_25_7
 E  marginal_26_3
 E  marginal_26_4
 E  marginal_27_6
 E  marginal_27_7
 E  marginal_28_6
 E  marginal_28_8
 E  marginal_29_6
 E  marginal_29_8
 E  marginal_30_3
 E  marginal_30_4
 E  marginal_31_2
 E  marginal_31_7
 E  marginal_32_3
 E  marginal_32_5
 E  marginal_33_6
 E  marginal_33_7
 E  marginal_34_1
 E  marginal_34_5
 E  marginal_35_4
 E  marginal_35_8
COLUMNS
    f[0,0,2]  R0        1
    f[0,0,2]  R2        1
    f[0,0,2]  marginal_1_2  1
    f[0,0,8]  R0        1
    f[0,0,8]  R1        1
    f[0,0,8]  marginal_1_8  1
    f[0,0,10]  R0        1
    f[0,0,10]  R3        1
    f[0,0,10]  marginal_1_10  1
    f[1,2,6]  R2        -1
    f[1,2,6]  R4        1
    f[1,2,6]  marginal_2_6  1
    f[1,2,7]  R2        -1
    f[1,2,7]  R5        1
    f[1,2,7]  marginal_2_7  1
    f[1,8,6]  R1        -1
    f[1,8,6]  R6        1
    f[1,8,6]  marginal_2_6  1
    f[1,8,7]  R1        -1
    f[1,8,7]  R7        1
    f[1,8,7]  marginal_2_7  1
    f[1,10,6]  R3        -1
    f[1,10,6]  R8        1
    f[1,10,6]  marginal_2_6  1
    f[1,10,7]  R3        -1
    f[1,10,7]  R9        1
    f[1,10,7]  marginal_2_7  1
    f[2,8,6]  R4        -1
    f[2,8,6]  R10       1
    f[2,8,6]  marginal_3_6  1
    f[2,8,7]  R4        -1
    f[2,8,7]  R11       1
    f[2,8,7]  marginal_3_7  1
    f[2,9,6]  R5        -1
    f[2,9,6]  R11       1
    f[2,9,6]  marginal_3_6  1
    f[2,9,7]  R5        -1
    f[2,9,7]  R12       1
    f[2,9,7]  marginal_3_7  1
    f[2,14,6]  R6        -1
    f[2,14,6]  R13       1
    f[2,14,6]  marginal_3_6  1
    f[2,14,7]  R6        -1
    f[2,14,7]  R14       1
    f[2,14,7]  marginal_3_7  1
    f[2,15,6]  R7        -1
    f[2,15,6]  R14       1
    f[2,15,6]  marginal_3_6  1
    f[2,15,7]  R7        -1
    f[2,15,7]  R15       1
    f[2,15,7]  marginal_3_7  1
    f[2,16,6]  R8        -1
    f[2,16,6]  R15       1
    f[2,16,6]  marginal_3_6  1
    f[2,16,7]  R8        -1
    f[2,16,7]  R16       1
    f[2,16,7]  marginal_3_7  1
    f[2,17,6]  R9        -1
    f[2,17,6]  R16       1
    f[2,17,6]  marginal_3_6  1
    f[2,17,7]  R9        -1
    f[2,17,7]  R17       1
    f[2,17,7]  marginal_3_7  1
    f[3,14,6]  R10       -1
    f[3,14,6]  R18       1
    f[3,14,6]  marginal_4_6  1
    f[3,14,7]  R10       -1
    f[3,14,7]  R19       1
    f[3,14,7]  marginal_4_7  1
    f[3,15,6]  R11       -1
    f[3,15,6]  R19       1
    f[3,15,6]  marginal_4_6  1
    f[3,15,7]  R11       -1
    f[3,15,7]  R20       1
    f[3,15,7]  marginal_4_7  1
    f[3,16,6]  R12       -1
    f[3,16,6]  R20       1
    f[3,16,6]  marginal_4_6  1
    f[3,16,7]  R12       -1
    f[3,16,7]  R21       1
    f[3,16,7]  marginal_4_7  1
    f[3,20,6]  R13       -1
    f[3,20,6]  R22       1
    f[3,20,6]  marginal_4_6  1
    f[3,20,7]  R13       -1
    f[3,20,7]  R23       1
    f[3,20,7]  marginal_4_7  1
    f[3,21,6]  R14       -1
    f[3,21,6]  R23       1
    f[3,21,6]  marginal_4_6  1
    f[3,21,7]  R14       -1
    f[3,21,7]  R24       1
    f[3,21,7]  marginal_4_7  1
    f[3,22,6]  R15       -1
    f[3,22,6]  R24       1
    f[3,22,6]  marginal_4_6  1
    f[3,22,7]  R15       -1
    f[3,22,7]  R25       1
    f[3,22,7]  marginal_4_7  1
    f[3,23,6]  R16       -1
    f[3,23,6]  R25       1
    f[3,23,6]  marginal_4_6  1
    f[3,23,7]  R16       -1
    f[3,23,7]  R26       1
    f[3,23,7]  marginal_4_7  1
    f[3,24,6]  R17       -1
    f[3,24,6]  R26       1
    f[3,24,6]  marginal_4_6  1
    f[3,24,7]  R17       -1
    f[3,24,7]  R27       1
    f[3,24,7]  marginal_4_7  1
    f[4,20,2]  R18       -1
    f[4,20,2]  R36       1
    f[4,20,2]  marginal_5_2  1
    f[4,20,4]  R18       -1
    f[4,20,4]  R38       1
    f[4,20,4]  marginal_5_4  1
    f[4,20,8]  R18       -1
    f[4,20,8]  R42       1
    f[4,20,8]  marginal_5_8  1
    f[4,21,2]  R19       -1
    f[4,21,2]  R37       1
    f[4,21,2]  marginal_5_2  1
    f[4,21,4]  R19       -1
    f[4,21,4]  R39       1
    f[4,21,4]  marginal_5_4  1
    f[4,21,8]  R19       -1
    f[4,21,8]  R43       1
    f[4,21,8]  marginal_5_8  1
    f[4,22,2]  R20       -1
    f[4,22,2]  R38       1
    f[4,22,2]  marginal_5_2  1
    f[4,22,4]  R20       -1
    f[4,22,4]  R40       1
    f[4,22,4]  marginal_5_4  1
    f[4,22,8]  R20       -1
    f[4,22,8]  R44       1
    f[4,22,8]  marginal_5_8  1
    f[4,23,2]  R21       -1
    f[4,23,2]  R39       1
    f[4,23,2]  marginal_5_2  1
    f[4,23,4]  R21       -1
    f[4,23,4]  R41       1
    f[4,23,4]  marginal_5_4  1
    f[4,23,8]  R21       -1
    f[4,23,8]  R45       1
    f[4,23,8]  marginal_5_8  1
    f[4,26,2]  R22       -1
    f[4,26,2]  R42       1
    f[4,26,2]  marginal_5_2  1
    f[4,26,4]  R22       -1
    f[4,26,4]  R44       1
    f[4,26,4]  marginal_5_4  1
    f[4,26,8]  R22       -1
    f[4,26,8]  R30       1
    f[4,26,8]  marginal_5_8  1
    f[4,27,2]  R23       -1
    f[4,27,2]  R43       1
    f[4,27,2]  marginal_5_2  1
    f[4,27,4]  R23       -1
    f[4,27,4]  R45       1
    f[4,27,4]  marginal_5_4  1
    f[4,27,8]  R23       -1
    f[4,27,8]  R31       1
    f[4,27,8]  marginal_5_8  1
    f[4,28,2]  R24       -1
    f[4,28,2]  R44       1
    f[4,28,2]  marginal_5_2  1
    f[4,28,4]  R24       -1
    f[4,28,4]  R28       1
    f[4,28,4]  marginal_5_4  1
    f[4,28,8]  R24       -1
    f[4,28,8]  R32       1
    f[4,28,8]  marginal_5_8  1
    f[4,29,2]  R25       -1
    f[4,29,2]  R45       1
    f[4,29,2]  marginal_5_2  1
    f[4,29,4]  R25       -1
    f[4,29,4]  R29       1
    f[4,29,4]  marginal_5_4  1
    f[4,29,8]  R25       -1
    f[4,29,8]  R33       1
    f[4,29,8]  marginal_5_8  1
    f[4,30,2]  R26       -1
    f[4,30,2]  R28       1
    f[4,30,2]  marginal_5_2  1
    f[4,30,4]  R26       -1
    f[4,30,4]  R30       1
    f[4,30,4]  marginal_5_4  1
    f[4,30,8]  R26       -1
    f[4,30,8]  R34       1
    f[4,30,8]  marginal_5_8  1
    f[4,31,2]  R27       -1
    f[4,31,2]  R29       1
    f[4,31,2]  marginal_5_2  1
    f[4,31,4]  R27       -1
    f[4,31,4]  R31       1
    f[4,31,4]  marginal_5_4  1
    f[4,31,8]  R27       -1
    f[4,31,8]  R35       1
    f[4,31,8]  marginal_5_8  1
    f[5,22,1]  R36       -1
    f[5,22,1]  R46       1
    f[5,22,1]  marginal_6_1  1
    f[5,22,5]  R36       -1
    f[5,22,5]  R50       1
    f[5,22,5]  marginal_6_5  1
    f[5,23,1]  R37       -1
    f[5,23,1]  R47       1
    f[5,23,1]  marginal_6_1  1
    f[5,23,5]  R37       -1
    f[5,23,5]  R51       1
    f[5,23,5]  marginal_6_5  1
    f[5,24,1]  R38       -1
    f[5,24,1]  R48       1
    f[5,24,1]  marginal_6_1  1
    f[5,24,5]  R38       -1
    f[5,24,5]  R52       1
    f[5,24,5]  marginal_6_5  1
    f[5,25,1]  R39       -1
    f[5,25,1]  R49       1
    f[5,25,1]  marginal_6_1  1
    f[5,25,5]  R39       -1
    f[5,25,5]  R53       1
    f[5,25,5]  marginal_6_5  1
    f[5,26,1]  R40       -1
    f[5,26,1]  R50       1
    f[5,26,1]  marginal_6_1  1
    f[5,26,5]  R40       -1
    f[5,26,5]  R54       1
    f[5,26,5]  marginal_6_5  1
    f[5,27,1]  R41       -1
    f[5,27,1]  R51       1
    f[5,27,1]  marginal_6_1  1
    f[5,27,5]  R41       -1
    f[5,27,5]  R55       1
    f[5,27,5]  marginal_6_5  1
    f[5,28,1]  R42       -1
    f[5,28,1]  R52       1
    f[5,28,1]  marginal_6_1  1
    f[5,28,5]  R42       -1
    f[5,28,5]  R56       1
    f[5,28,5]  marginal_6_5  1
    f[5,29,1]  R43       -1
    f[5,29,1]  R53       1
    f[5,29,1]  marginal_6_1  1
    f[5,29,5]  R43       -1
    f[5,29,5]  R57       1
    f[5,29,5]  marginal_6_5  1
    f[5,30,1]  R44       -1
    f[5,30,1]  R54       1
    f[5,30,1]  marginal_6_1  1
    f[5,30,5]  R44       -1
    f[5,30,5]  R58       1
    f[5,30,5]  marginal_6_5  1
    f[5,31,1]  R45       -1
    f[5,31,1]  R55       1
    f[5,31,1]  marginal_6_1  1
    f[5,31,5]  R45       -1
    f[5,31,5]  R59       1
    f[5,31,5]  marginal_6_5  1
    f[5,32,1]  R28       -1
    f[5,32,1]  R56       1
    f[5,32,1]  marginal_6_1  1
    f[5,32,5]  R28       -1
    f[5,32,5]  R60       1
    f[5,32,5]  marginal_6_5  1
    f[5,33,1]  R29       -1
    f[5,33,1]  R57       1
    f[5,33,1]  marginal_6_1  1
    f[5,33,5]  R29       -1
    f[5,33,5]  R61       1
    f[5,33,5]  marginal_6_5  1
    f[5,34,1]  R30       -1
    f[5,34,1]  R58       1
    f[5,34,1]  marginal_6_1  1
    f[5,34,5]  R30       -1
    f[5,34,5]  R62       1
    f[5,34,5]  marginal_6_5  1
    f[5,35,1]  R31       -1
    f[5,35,1]  R59       1
    f[5,35,1]  marginal_6_1  1
    f[5,35,5]  R31       -1
    f[5,35,5]  R63       1
    f[5,35,5]  marginal_6_5  1
    f[5,36,1]  R32       -1
    f[5,36,1]  R60       1
    f[5,36,1]  marginal_6_1  1
    f[5,36,5]  R32       -1
    f[5,36,5]  R64       1
    f[5,36,5]  marginal_6_5  1
    f[5,37,1]  R33       -1
    f[5,37,1]  R61       1
    f[5,37,1]  marginal_6_1  1
    f[5,37,5]  R33       -1
    f[5,37,5]  R65       1
    f[5,37,5]  marginal_6_5  1
    f[5,38,1]  R34       -1
    f[5,38,1]  R62       1
    f[5,38,1]  marginal_6_1  1
    f[5,38,5]  R34       -1
    f[5,38,5]  R66       1
    f[5,38,5]  marginal_6_5  1
    f[5,39,1]  R35       -1
    f[5,39,1]  R63       1
    f[5,39,1]  marginal_6_1  1
    f[5,39,5]  R35       -1
    f[5,39,5]  R67       1
    f[5,39,5]  marginal_6_5  1
    f[6,23,5]  R46       -1
    f[6,23,5]  R68       1
    f[6,23,5]  marginal_7_5  1
    f[6,23,8]  R46       -1
    f[6,23,8]  R71       1
    f[6,23,8]  marginal_7_8  1
    f[6,24,5]  R47       -1
    f[6,24,5]  R69       1
    f[6,24,5]  marginal_7_5  1
    f[6,24,8]  R47       -1
    f[6,24,8]  R72       1
    f[6,24,8]  marginal_7_8  1
    f[6,25,5]  R48       -1
    f[6,25,5]  R70       1
    f[6,25,5]  marginal_7_5  1
    f[6,25,8]  R48       -1
    f[6,25,8]  R73       1
    f[6,25,8]  marginal_7_8  1
    f[6,26,5]  R49       -1
    f[6,26,5]  R71       1
    f[6,26,5]  marginal_7_5  1
    f[6,26,8]  R49       -1
    f[6,26,8]  R74       1
    f[6,26,8]  marginal_7_8  1
    f[6,27,5]  R50       -1
    f[6,27,5]  R72       1
    f[6,27,5]  marginal_7_5  1
    f[6,27,8]  R50       -1
    f[6,27,8]  R75       1
    f[6,27,8]  marginal_7_8  1
    f[6,28,5]  R51       -1
    f[6,28,5]  R73       1
    f[6,28,5]  marginal_7_5  1
    f[6,28,8]  R51       -1
    f[6,28,8]  R76       1
    f[6,28,8]  marginal_7_8  1
    f[6,29,5]  R52       -1
    f[6,29,5]  R74       1
    f[6,29,5]  marginal_7_5  1
    f[6,29,8]  R52       -1
    f[6,29,8]  R77       1
    f[6,29,8]  marginal_7_8  1
    f[6,30,5]  R53       -1
    f[6,30,5]  R75       1
    f[6,30,5]  marginal_7_5  1
    f[6,30,8]  R53       -1
    f[6,30,8]  R78       1
    f[6,30,8]  marginal_7_8  1
    f[6,31,5]  R54       -1
    f[6,31,5]  R76       1
    f[6,31,5]  marginal_7_5  1
    f[6,31,8]  R54       -1
    f[6,31,8]  R79       1
    f[6,31,8]  marginal_7_8  1
    f[6,32,5]  R55       -1
    f[6,32,5]  R77       1
    f[6,32,5]  marginal_7_5  1
    f[6,32,8]  R55       -1
    f[6,32,8]  R80       1
    f[6,32,8]  marginal_7_8  1
    f[6,33,5]  R56       -1
    f[6,33,5]  R78       1
    f[6,33,5]  marginal_7_5  1
    f[6,33,8]  R56       -1
    f[6,33,8]  R81       1
    f[6,33,8]  marginal_7_8  1
    f[6,34,5]  R57       -1
    f[6,34,5]  R79       1
    f[6,34,5]  marginal_7_5  1
    f[6,34,8]  R57       -1
    f[6,34,8]  R82       1
    f[6,34,8]  marginal_7_8  1
    f[6,35,5]  R58       -1
    f[6,35,5]  R80       1
    f[6,35,5]  marginal_7_5  1
    f[6,35,8]  R58       -1
    f[6,35,8]  R83       1
    f[6,35,8]  marginal_7_8  1
    f[6,36,5]  R59       -1
    f[6,36,5]  R81       1
    f[6,36,5]  marginal_7_5  1
    f[6,36,8]  R59       -1
    f[6,36,8]  R84       1
    f[6,36,8]  marginal_7_8  1
    f[6,37,5]  R60       -1
    f[6,37,5]  R82       1
    f[6,37,5]  marginal_7_5  1
    f[6,37,8]  R60       -1
    f[6,37,8]  R85       1
    f[6,37,8]  marginal_7_8  1
    f[6,38,5]  R61       -1
    f[6,38,5]  R83       1
    f[6,38,5]  marginal_7_5  1
    f[6,38,8]  R61       -1
    f[6,38,8]  R86       1
    f[6,38,8]  marginal_7_8  1
    f[6,39,5]  R62       -1
    f[6,39,5]  R84       1
    f[6,39,5]  marginal_7_5  1
    f[6,39,8]  R62       -1
    f[6,39,8]  R87       1
    f[6,39,8]  marginal_7_8  1
    f[6,40,5]  R63       -1
    f[6,40,5]  R85       1
    f[6,40,5]  marginal_7_5  1
    f[6,40,8]  R63       -1
    f[6,40,8]  R88       1
    f[6,40,8]  marginal_7_8  1
    f[6,41,5]  R64       -1
    f[6,41,5]  R86       1
    f[6,41,5]  marginal_7_5  1
    f[6,41,8]  R64       -1
    f[6,41,8]  R89       1
    f[6,41,8]  marginal_7_8  1
    f[6,42,5]  R65       -1
    f[6,42,5]  R87       1
    f[6,42,5]  marginal_7_5  1
    f[6,42,8]  R65       -1
    f[6,42,8]  R90       1
    f[6,42,8]  marginal_7_8  1
    f[6,43,5]  R66       -1
    f[6,43,5]  R88       1
    f[6,43,5]  marginal_7_5  1
    f[6,43,8]  R66       -1
    f[6,43,8]  R91       1
    f[6,43,8]  marginal_7_8  1
    f[6,44,5]  R67       -1
    f[6,44,5]  R89       1
    f[6,44,5]  marginal_7_5  1
    f[6,44,8]  R67       -1
    f[6,44,8]  R92       1
    f[6,44,8]  marginal_7_8  1
    f[7,28,5]  R68       -1
    f[7,28,5]  R93       1
    f[7,28,5]  marginal_8_5  1
    f[7,28,7]  R68       -1
    f[7,28,7]  R95       1
    f[7,28,7]  marginal_8_7  1
    f[7,28,10]  R68       -1
    f[7,28,10]  R98       1
    f[7,28,10]  marginal_8_10  1
    f[7,29,5]  R69       -1
    f[7,29,5]  R94       1
    f[7,29,5]  marginal_8_5  1
    f[7,29,7]  R69       -1
    f[7,29,7]  R96       1
    f[7,29,7]  marginal_8_7  1
    f[7,29,10]  R69       -1
    f[7,29,10]  R99       1
    f[7,29,10]  marginal_8_10  1
    f[7,30,5]  R70       -1
    f[7,30,5]  R95       1
    f[7,30,5]  marginal_8_5  1
    f[7,30,7]  R70       -1
    f[7,30,7]  R97       1
    f[7,30,7]  marginal_8_7  1
    f[7,30,10]  R70       -1
    f[7,30,10]  R100      1
    f[7,30,10]  marginal_8_10  1
    f[7,31,5]  R71       -1
    f[7,31,5]  R96       1
    f[7,31,5]  marginal_8_5  1
    f[7,31,7]  R71       -1
    f[7,31,7]  R98       1
    f[7,31,7]  marginal_8_7  1
    f[7,31,10]  R71       -1
    f[7,31,10]  R101      1
    f[7,31,10]  marginal_8_10  1
    f[7,32,5]  R72       -1
    f[7,32,5]  R97       1
    f[7,32,5]  marginal_8_5  1
    f[7,32,7]  R72       -1
    f[7,32,7]  R99       1
    f[7,32,7]  marginal_8_7  1
    f[7,32,10]  R72       -1
    f[7,32,10]  R102      1
    f[7,32,10]  marginal_8_10  1
    f[7,33,5]  R73       -1
    f[7,33,5]  R98       1
    f[7,33,5]  marginal_8_5  1
    f[7,33,7]  R73       -1
    f[7,33,7]  R100      1
    f[7,33,7]  marginal_8_7  1
    f[7,33,10]  R73       -1
    f[7,33,10]  R103      1
    f[7,33,10]  marginal_8_10  1
    f[7,34,5]  R74       -1
    f[7,34,5]  R99       1
    f[7,34,5]  marginal_8_5  1
    f[7,34,7]  R74       -1
    f[7,34,7]  R101      1
    f[7,34,7]  marginal_8_7  1
    f[7,34,10]  R74       -1
    f[7,34,10]  R104      1
    f[7,34,10]  marginal_8_10  1
    f[7,35,5]  R75       -1
    f[7,35,5]  R100      1
    f[7,35,5]  marginal_8_5  1
    f[7,35,7]  R75       -1
    f[7,35,7]  R102      1
    f[7,35,7]  marginal_8_7  1
    f[7,35,10]  R75       -1
    f[7,35,10]  R105      1
    f[7,35,10]  marginal_8_10  1
    f[7,36,5]  R76       -1
    f[7,36,5]  R101      1
    f[7,36,5]  marginal_8_5  1
    f[7,36,7]  R76       -1
    f[7,36,7]  R103      1
    f[7,36,7]  marginal_8_7  1
    f[7,36,10]  R76       -1
    f[7,36,10]  R106      1
    f[7,36,10]  marginal_8_10  1
    f[7,37,5]  R77       -1
    f[7,37,5]  R102      1
    f[7,37,5]  marginal_8_5  1
    f[7,37,7]  R77       -1
    f[7,37,7]  R104      1
    f[7,37,7]  marginal_8_7  1
    f[7,37,10]  R77       -1
    f[7,37,10]  R107      1
    f[7,37,10]  marginal_8_10  1
    f[7,38,5]  R78       -1
    f[7,38,5]  R103      1
    f[7,38,5]  marginal_8_5  1
    f[7,38,7]  R78       -1
    f[7,38,7]  R105      1
    f[7,38,7]  marginal_8_7  1
    f[7,38,10]  R78       -1
    f[7,38,10]  R108      1
    f[7,38,10]  marginal_8_10  1
    f[7,39,5]  R79       -1
    f[7,39,5]  R104      1
    f[7,39,5]  marginal_8_5  1
    f[7,39,7]  R79       -1
    f[7,39,7]  R106      1
    f[7,39,7]  marginal_8_7  1
    f[7,39,10]  R79       -1
    f[7,39,10]  R109      1
    f[7,39,10]  marginal_8_10  1
    f[7,40,5]  R80       -1
    f[7,40,5]  R105      1
    f[7,40,5]  marginal_8_5  1
    f[7,40,7]  R80       -1
    f[7,40,7]  R107      1
    f[7,40,7]  marginal_8_7  1
    f[7,40,10]  R80       -1
    f[7,40,10]  R110      1
    f[7,40,10]  marginal_8_10  1
    f[7,41,5]  R81       -1
    f[7,41,5]  R106      1
    f[7,41,5]  marginal_8_5  1
    f[7,41,7]  R81       -1
    f[7,41,7]  R108      1
    f[7,41,7]  marginal_8_7  1
    f[7,41,10]  R81       -1
    f[7,41,10]  R111      1
    f[7,41,10]  marginal_8_10  1
    f[7,42,5]  R82       -1
    f[7,42,5]  R107      1
    f[7,42,5]  marginal_8_5  1
    f[7,42,7]  R82       -1
    f[7,42,7]  R109      1
    f[7,42,7]  marginal_8_7  1
    f[7,42,10]  R82       -1
    f[7,42,10]  R112      1
    f[7,42,10]  marginal_8_10  1
    f[7,43,5]  R83       -1
    f[7,43,5]  R108      1
    f[7,43,5]  marginal_8_5  1
    f[7,43,7]  R83       -1
    f[7,43,7]  R110      1
    f[7,43,7]  marginal_8_7  1
    f[7,43,10]  R83       -1
    f[7,43,10]  R113      1
    f[7,43,10]  marginal_8_10  1
    f[7,44,5]  R84       -1
    f[7,44,5]  R109      1
    f[7,44,5]  marginal_8_5  1
    f[7,44,7]  R84       -1
    f[7,44,7]  R111      1
    f[7,44,7]  marginal_8_7  1
    f[7,44,10]  R84       -1
    f[7,44,10]  R114      1
    f[7,44,10]  marginal_8_10  1
    f[7,45,5]  R85       -1
    f[7,45,5]  R110      1
    f[7,45,5]  marginal_8_5  1
    f[7,45,7]  R85       -1
    f[7,45,7]  R112      1
    f[7,45,7]  marginal_8_7  1
    f[7,45,10]  R85       -1
    f[7,45,10]  R115      1
    f[7,45,10]  marginal_8_10  1
    f[7,46,5]  R86       -1
    f[7,46,5]  R111      1
    f[7,46,5]  marginal_8_5  1
    f[7,46,7]  R86       -1
    f[7,46,7]  R113      1
    f[7,46,7]  marginal_8_7  1
    f[7,46,10]  R86       -1
    f[7,46,10]  R116      1
    f[7,46,10]  marginal_8_10  1
    f[7,47,5]  R87       -1
    f[7,47,5]  R112      1
    f[7,47,5]  marginal_8_5  1
    f[7,47,7]  R87       -1
    f[7,47,7]  R114      1
    f[7,47,7]  marginal_8_7  1
    f[7,47,10]  R87       -1
    f[7,47,10]  R117      1
    f[7,47,10]  marginal_8_10  1
    f[7,48,5]  R88       -1
    f[7,48,5]  R113      1
    f[7,48,5]  marginal_8_5  1
    f[7,48,7]  R88       -1
    f[7,48,7]  R115      1
    f[7,48,7]  marginal_8_7  1
    f[7,48,10]  R88       -1
    f[7,48,10]  R118      1
    f[7,48,10]  marginal_8_10  1
    f[7,49,5]  R89       -1
    f[7,49,5]  R114      1
    f[7,49,5]  marginal_8_5  1
    f[7,49,7]  R89       -1
    f[7,49,7]  R116      1
    f[7,49,7]  marginal_8_7  1
    f[7,49,10]  R89       -1
    f[7,49,10]  R119      1
    f[7,49,10]  marginal_8_10  1
    f[7,50,5]  R90       -1
    f[7,50,5]  R115      1
    f[7,50,5]  marginal_8_5  1
    f[7,50,7]  R90       -1
    f[7,50,7]  R117      1
    f[7,50,7]  marginal_8_7  1
    f[7,50,10]  R90       -1
    f[7,50,10]  R120      1
    f[7,50,10]  marginal_8_10  1
    f[7,51,5]  R91       -1
    f[7,51,5]  R116      1
    f[7,51,5]  marginal_8_5  1
    f[7,51,7]  R91       -1
    f[7,51,7]  R118      1
    f[7,51,7]  marginal_8_7  1
    f[7,51,10]  R91       -1
    f[7,51,10]  R121      1
    f[7,51,10]  marginal_8_10  1
    f[7,52,5]  R92       -1
    f[7,52,5]  R117      1
    f[7,52,5]  marginal_8_5  1
    f[7,52,7]  R92       -1
    f[7,52,7]  R119      1
    f[7,52,7]  marginal_8_7  1
    f[7,52,10]  R92       -1
    f[7,52,10]  R122      1
    f[7,52,10]  marginal_8_10  1
    f[8,33,3]  R93       -1
    f[8,33,3]  R123      1
    f[8,33,3]  marginal_9_3  1
    f[8,33,5]  R93       -1
    f[8,33,5]  R125      1
    f[8,33,5]  marginal_9_5  1
    f[8,34,3]  R94       -1
    f[8,34,3]  R124      1
    f[8,34,3]  marginal_9_3  1
    f[8,34,5]  R94       -1
    f[8,34,5]  R126      1
    f[8,34,5]  marginal_9_5  1
    f[8,35,3]  R95       -1
    f[8,35,3]  R125      1
    f[8,35,3]  marginal_9_3  1
    f[8,35,5]  R95       -1
    f[8,35,5]  R127      1
    f[8,35,5]  marginal_9_5  1
    f[8,36,3]  R96       -1
    f[8,36,3]  R126      1
    f[8,36,3]  marginal_9_3  1
    f[8,36,5]  R96       -1
    f[8,36,5]  R128      1
    f[8,36,5]  marginal_9_5  1
    f[8,37,3]  R97       -1
    f[8,37,3]  R127      1
    f[8,37,3]  marginal_9_3  1
    f[8,37,5]  R97       -1
    f[8,37,5]  R129      1
    f[8,37,5]  marginal_9_5  1
    f[8,38,3]  R98       -1
    f[8,38,3]  R128      1
    f[8,38,3]  marginal_9_3  1
    f[8,38,5]  R98       -1
    f[8,38,5]  R130      1
    f[8,38,5]  marginal_9_5  1
    f[8,39,3]  R99       -1
    f[8,39,3]  R129      1
    f[8,39,3]  marginal_9_3  1
    f[8,39,5]  R99       -1
    f[8,39,5]  R131      1
    f[8,39,5]  marginal_9_5  1
    f[8,40,3]  R100      -1
    f[8,40,3]  R130      1
    f[8,40,3]  marginal_9_3  1
    f[8,40,5]  R100      -1
    f[8,40,5]  R132      1
    f[8,40,5]  marginal_9_5  1
    f[8,41,3]  R101      -1
    f[8,41,3]  R131      1
    f[8,41,3]  marginal_9_3  1
    f[8,41,5]  R101      -1
    f[8,41,5]  R133      1
    f[8,41,5]  marginal_9_5  1
    f[8,42,3]  R102      -1
    f[8,42,3]  R132      1
    f[8,42,3]  marginal_9_3  1
    f[8,42,5]  R102      -1
    f[8,42,5]  R134      1
    f[8,42,5]  marginal_9_5  1
    f[8,43,3]  R103      -1
    f[8,43,3]  R133      1
    f[8,43,3]  marginal_9_3  1
    f[8,43,5]  R103      -1
    f[8,43,5]  R135      1
    f[8,43,5]  marginal_9_5  1
    f[8,44,3]  R104      -1
    f[8,44,3]  R134      1
    f[8,44,3]  marginal_9_3  1
    f[8,44,5]  R104      -1
    f[8,44,5]  R136      1
    f[8,44,5]  marginal_9_5  1
    f[8,45,3]  R105      -1
    f[8,45,3]  R135      1
    f[8,45,3]  marginal_9_3  1
    f[8,45,5]  R105      -1
    f[8,45,5]  R137      1
    f[8,45,5]  marginal_9_5  1
    f[8,46,3]  R106      -1
    f[8,46,3]  R136      1
    f[8,46,3]  marginal_9_3  1
    f[8,46,5]  R106      -1
    f[8,46,5]  R138      1
    f[8,46,5]  marginal_9_5  1
    f[8,47,3]  R107      -1
    f[8,47,3]  R137      1
    f[8,47,3]  marginal_9_3  1
    f[8,47,5]  R107      -1
    f[8,47,5]  R139      1
    f[8,47,5]  marginal_9_5  1
    f[8,48,3]  R108      -1
    f[8,48,3]  R138      1
    f[8,48,3]  marginal_9_3  1
    f[8,48,5]  R108      -1
    f[8,48,5]  R140      1
    f[8,48,5]  marginal_9_5  1
    f[8,49,3]  R109      -1
    f[8,49,3]  R139      1
    f[8,49,3]  marginal_9_3  1
    f[8,49,5]  R109      -1
    f[8,49,5]  R141      1
    f[8,49,5]  marginal_9_5  1
    f[8,50,3]  R110      -1
    f[8,50,3]  R140      1
    f[8,50,3]  marginal_9_3  1
    f[8,50,5]  R110      -1
    f[8,50,5]  R142      1
    f[8,50,5]  marginal_9_5  1
    f[8,51,3]  R111      -1
    f[8,51,3]  R141      1
    f[8,51,3]  marginal_9_3  1
    f[8,51,5]  R111      -1
    f[8,51,5]  R143      1
    f[8,51,5]  marginal_9_5  1
    f[8,52,3]  R112      -1
    f[8,52,3]  R142      1
    f[8,52,3]  marginal_9_3  1
    f[8,52,5]  R112      -1
    f[8,52,5]  R144      1
    f[8,52,5]  marginal_9_5  1
    f[8,53,3]  R113      -1
    f[8,53,3]  R143      1
    f[8,53,3]  marginal_9_3  1
    f[8,53,5]  R113      -1
    f[8,53,5]  R145      1
    f[8,53,5]  marginal_9_5  1
    f[8,54,3]  R114      -1
    f[8,54,3]  R144      1
    f[8,54,3]  marginal_9_3  1
    f[8,54,5]  R114      -1
    f[8,54,5]  R146      1
    f[8,54,5]  marginal_9_5  1
    f[8,55,3]  R115      -1
    f[8,55,3]  R145      1
    f[8,55,3]  marginal_9_3  1
    f[8,55,5]  R115      -1
    f[8,55,5]  R147      1
    f[8,55,5]  marginal_9_5  1
    f[8,56,3]  R116      -1
    f[8,56,3]  R146      1
    f[8,56,3]  marginal_9_3  1
    f[8,56,5]  R116      -1
    f[8,56,5]  R148      1
    f[8,56,5]  marginal_9_5  1
    f[8,57,3]  R117      -1
    f[8,57,3]  R147      1
    f[8,57,3]  marginal_9_3  1
    f[8,57,5]  R117      -1
    f[8,57,5]  R149      1
    f[8,57,5]  marginal_9_5  1
    f[8,58,3]  R118      -1
    f[8,58,3]  R148      1
    f[8,58,3]  marginal_9_3  1
    f[8,58,5]  R118      -1
    f[8,58,5]  R150      1
    f[8,58,5]  marginal_9_5  1
    f[8,59,3]  R119      -1
    f[8,59,3]  R149      1
    f[8,59,3]  marginal_9_3  1
    f[8,59,5]  R119      -1
    f[8,59,5]  R151      1
    f[8,59,5]  marginal_9_5  1
    f[8,60,3]  R120      -1
    f[8,60,3]  R150      1
    f[8,60,3]  marginal_9_3  1
    f[8,60,5]  R120      -1
    f[8,60,5]  R152      1
    f[8,60,5]  marginal_9_5  1
    f[8,61,3]  R121      -1
    f[8,61,3]  R151      1
    f[8,61,3]  marginal_9_3  1
    f[8,61,5]  R121      -1
    f[8,61,5]  R153      1
    f[8,61,5]  marginal_9_5  1
    f[8,62,3]  R122      -1
    f[8,62,3]  R152      1
    f[8,62,3]  marginal_9_3  1
    f[8,62,5]  R122      -1
    f[8,62,5]  R154      1
    f[8,62,5]  marginal_9_5  1
    f[9,36,5]  R123      -1
    f[9,36,5]  R155      1
    f[9,36,5]  marginal_10_5  1
    f[9,36,6]  R123      -1
    f[9,36,6]  R156      1
    f[9,36,6]  marginal_10_6  1
    f[9,36,10]  R123      -1
    f[9,36,10]  R160      1
    f[9,36,10]  marginal_10_10  1
    f[9,37,5]  R124      -1
    f[9,37,5]  R156      1
    f[9,37,5]  marginal_10_5  1
    f[9,37,6]  R124      -1
    f[9,37,6]  R157      1
    f[9,37,6]  marginal_10_6  1
    f[9,37,10]  R124      -1
    f[9,37,10]  R161      1
    f[9,37,10]  marginal_10_10  1
    f[9,38,5]  R125      -1
    f[9,38,5]  R157      1
    f[9,38,5]  marginal_10_5  1
    f[9,38,6]  R125      -1
    f[9,38,6]  R158      1
    f[9,38,6]  marginal_10_6  1
    f[9,38,10]  R125      -1
    f[9,38,10]  R162      1
    f[9,38,10]  marginal_10_10  1
    f[9,39,5]  R126      -1
    f[9,39,5]  R158      1
    f[9,39,5]  marginal_10_5  1
    f[9,39,6]  R126      -1
    f[9,39,6]  R159      1
    f[9,39,6]  marginal_10_6  1
    f[9,39,10]  R126      -1
    f[9,39,10]  R163      1
    f[9,39,10]  marginal_10_10  1
    f[9,40,5]  R127      -1
    f[9,40,5]  R159      1
    f[9,40,5]  marginal_10_5  1
    f[9,40,6]  R127      -1
    f[9,40,6]  R160      1
    f[9,40,6]  marginal_10_6  1
    f[9,40,10]  R127      -1
    f[9,40,10]  R164      1
    f[9,40,10]  marginal_10_10  1
    f[9,41,5]  R128      -1
    f[9,41,5]  R160      1
    f[9,41,5]  marginal_10_5  1
    f[9,41,6]  R128      -1
    f[9,41,6]  R161      1
    f[9,41,6]  marginal_10_6  1
    f[9,41,10]  R128      -1
    f[9,41,10]  R165      1
    f[9,41,10]  marginal_10_10  1
    f[9,42,5]  R129      -1
    f[9,42,5]  R161      1
    f[9,42,5]  marginal_10_5  1
    f[9,42,6]  R129      -1
    f[9,42,6]  R162      1
    f[9,42,6]  marginal_10_6  1
    f[9,42,10]  R129      -1
    f[9,42,10]  R166      1
    f[9,42,10]  marginal_10_10  1
    f[9,43,5]  R130      -1
    f[9,43,5]  R162      1
    f[9,43,5]  marginal_10_5  1
    f[9,43,6]  R130      -1
    f[9,43,6]  R163      1
    f[9,43,6]  marginal_10_6  1
    f[9,43,10]  R130      -1
    f[9,43,10]  R167      1
    f[9,43,10]  marginal_10_10  1
    f[9,44,5]  R131      -1
    f[9,44,5]  R163      1
    f[9,44,5]  marginal_10_5  1
    f[9,44,6]  R131      -1
    f[9,44,6]  R164      1
    f[9,44,6]  marginal_10_6  1
    f[9,44,10]  R131      -1
    f[9,44,10]  R168      1
    f[9,44,10]  marginal_10_10  1
    f[9,45,5]  R132      -1
    f[9,45,5]  R164      1
    f[9,45,5]  marginal_10_5  1
    f[9,45,6]  R132      -1
    f[9,45,6]  R165      1
    f[9,45,6]  marginal_10_6  1
    f[9,45,10]  R132      -1
    f[9,45,10]  R169      1
    f[9,45,10]  marginal_10_10  1
    f[9,46,5]  R133      -1
    f[9,46,5]  R165      1
    f[9,46,5]  marginal_10_5  1
    f[9,46,6]  R133      -1
    f[9,46,6]  R166      1
    f[9,46,6]  marginal_10_6  1
    f[9,46,10]  R133      -1
    f[9,46,10]  R170      1
    f[9,46,10]  marginal_10_10  1
    f[9,47,5]  R134      -1
    f[9,47,5]  R166      1
    f[9,47,5]  marginal_10_5  1
    f[9,47,6]  R134      -1
    f[9,47,6]  R167      1
    f[9,47,6]  marginal_10_6  1
    f[9,47,10]  R134      -1
    f[9,47,10]  R171      1
    f[9,47,10]  marginal_10_10  1
    f[9,48,5]  R135      -1
    f[9,48,5]  R167      1
    f[9,48,5]  marginal_10_5  1
    f[9,48,6]  R135      -1
    f[9,48,6]  R168      1
    f[9,48,6]  marginal_10_6  1
    f[9,48,10]  R135      -1
    f[9,48,10]  R172      1
    f[9,48,10]  marginal_10_10  1
    f[9,49,5]  R136      -1
    f[9,49,5]  R168      1
    f[9,49,5]  marginal_10_5  1
    f[9,49,6]  R136      -1
    f[9,49,6]  R169      1
    f[9,49,6]  marginal_10_6  1
    f[9,49,10]  R136      -1
    f[9,49,10]  R173      1
    f[9,49,10]  marginal_10_10  1
    f[9,50,5]  R137      -1
    f[9,50,5]  R169      1
    f[9,50,5]  marginal_10_5  1
    f[9,50,6]  R137      -1
    f[9,50,6]  R170      1
    f[9,50,6]  marginal_10_6  1
    f[9,50,10]  R137      -1
    f[9,50,10]  R174      1
    f[9,50,10]  marginal_10_10  1
    f[9,51,5]  R138      -1
    f[9,51,5]  R170      1
    f[9,51,5]  marginal_10_5  1
    f[9,51,6]  R138      -1
    f[9,51,6]  R171      1
    f[9,51,6]  marginal_10_6  1
    f[9,51,10]  R138      -1
    f[9,51,10]  R175      1
    f[9,51,10]  marginal_10_10  1
    f[9,52,5]  R139      -1
    f[9,52,5]  R171      1
    f[9,52,5]  marginal_10_5  1
    f[9,52,6]  R139      -1
    f[9,52,6]  R172      1
    f[9,52,6]  marginal_10_6  1
    f[9,52,10]  R139      -1
    f[9,52,10]  R176      1
    f[9,52,10]  marginal_10_10  1
    f[9,53,5]  R140      -1
    f[9,53,5]  R172      1
    f[9,53,5]  marginal_10_5  1
    f[9,53,6]  R140      -1
    f[9,53,6]  R173      1
    f[9,53,6]  marginal_10_6  1
    f[9,53,10]  R140      -1
    f[9,53,10]  R177      1
    f[9,53,10]  marginal_10_10  1
    f[9,54,5]  R141      -1
    f[9,54,5]  R173      1
    f[9,54,5]  marginal_10_5  1
    f[9,54,6]  R141      -1
    f[9,54,6]  R174      1
    f[9,54,6]  marginal_10_6  1
    f[9,54,10]  R141      -1
    f[9,54,10]  R178      1
    f[9,54,10]  marginal_10_10  1
    f[9,55,5]  R142      -1
    f[9,55,5]  R174      1
    f[9,55,5]  marginal_10_5  1
    f[9,55,6]  R142      -1
    f[9,55,6]  R175      1
    f[9,55,6]  marginal_10_6  1
    f[9,55,10]  R142      -1
    f[9,55,10]  R179      1
    f[9,55,10]  marginal_10_10  1
    f[9,56,5]  R143      -1
    f[9,56,5]  R175      1
    f[9,56,5]  marginal_10_5  1
    f[9,56,6]  R143      -1
    f[9,56,6]  R176      1
    f[9,56,6]  marginal_10_6  1
    f[9,56,10]  R143      -1
    f[9,56,10]  R180      1
    f[9,56,10]  marginal_10_10  1
    f[9,57,5]  R144      -1
    f[9,57,5]  R176      1
    f[9,57,5]  marginal_10_5  1
    f[9,57,6]  R144      -1
    f[9,57,6]  R177      1
    f[9,57,6]  marginal_10_6  1
    f[9,57,10]  R144      -1
    f[9,57,10]  R181      1
    f[9,57,10]  marginal_10_10  1
    f[9,58,5]  R145      -1
    f[9,58,5]  R177      1
    f[9,58,5]  marginal_10_5  1
    f[9,58,6]  R145      -1
    f[9,58,6]  R178      1
    f[9,58,6]  marginal_10_6  1
    f[9,58,10]  R145      -1
    f[9,58,10]  R182      1
    f[9,58,10]  marginal_10_10  1
    f[9,59,5]  R146      -1
    f[9,59,5]  R178      1
    f[9,59,5]  marginal_10_5  1
    f[9,59,6]  R146      -1
    f[9,59,6]  R179      1
    f[9,59,6]  marginal_10_6  1
    f[9,59,10]  R146      -1
    f[9,59,10]  R183      1
    f[9,59,10]  marginal_10_10  1
    f[9,60,5]  R147      -1
    f[9,60,5]  R179      1
    f[9,60,5]  marginal_10_5  1
    f[9,60,6]  R147      -1
    f[9,60,6]  R180      1
    f[9,60,6]  marginal_10_6  1
    f[9,60,10]  R147      -1
    f[9,60,10]  R184      1
    f[9,60,10]  marginal_10_10  1
    f[9,61,5]  R148      -1
    f[9,61,5]  R180      1
    f[9,61,5]  marginal_10_5  1
    f[9,61,6]  R148      -1
    f[9,61,6]  R181      1
    f[9,61,6]  marginal_10_6  1
    f[9,61,10]  R148      -1
    f[9,61,10]  R185      1
    f[9,61,10]  marginal_10_10  1
    f[9,62,5]  R149      -1
    f[9,62,5]  R181      1
    f[9,62,5]  marginal_10_5  1
    f[9,62,6]  R149      -1
    f[9,62,6]  R182      1
    f[9,62,6]  marginal_10_6  1
    f[9,62,10]  R149      -1
    f[9,62,10]  R186      1
    f[9,62,10]  marginal_10_10  1
    f[9,63,5]  R150      -1
    f[9,63,5]  R182      1
    f[9,63,5]  marginal_10_5  1
    f[9,63,6]  R150      -1
    f[9,63,6]  R183      1
    f[9,63,6]  marginal_10_6  1
    f[9,63,10]  R150      -1
    f[9,63,10]  R187      1
    f[9,63,10]  marginal_10_10  1
    f[9,64,5]  R151      -1
    f[9,64,5]  R183      1
    f[9,64,5]  marginal_10_5  1
    f[9,64,6]  R151      -1
    f[9,64,6]  R184      1
    f[9,64,6]  marginal_10_6  1
    f[9,64,10]  R151      -1
    f[9,64,10]  R188      1
    f[9,64,10]  marginal_10_10  1
    f[9,65,5]  R152      -1
    f[9,65,5]  R184      1
    f[9,65,5]  marginal_10_5  1
    f[9,65,6]  R152      -1
    f[9,65,6]  R185      1
    f[9,65,6]  marginal_10_6  1
    f[9,65,10]  R152      -1
    f[9,65,10]  R189      1
    f[9,65,10]  marginal_10_10  1
    f[9,66,5]  R153      -1
    f[9,66,5]  R185      1
    f[9,66,5]  marginal_10_5  1
    f[9,66,6]  R153      -1
    f[9,66,6]  R186      1
    f[9,66,6]  marginal_10_6  1
    f[9,66,10]  R153      -1
    f[9,66,10]  R190      1
    f[9,66,10]  marginal_10_10  1
    f[9,67,5]  R154      -1
    f[9,67,5]  R186      1
    f[9,67,5]  marginal_10_5  1
    f[9,67,6]  R154      -1
    f[9,67,6]  R187      1
    f[9,67,6]  marginal_10_6  1
    f[9,67,10]  R154      -1
    f[9,67,10]  R191      1
    f[9,67,10]  marginal_10_10  1
    f[10,41,2]  R155      -1
    f[10,41,2]  R192      1
    f[10,41,2]  marginal_11_2  1
    f[10,41,5]  R155      -1
    f[10,41,5]  R195      1
    f[10,41,5]  marginal_11_5  1
    f[10,42,2]  R156      -1
    f[10,42,2]  R193      1
    f[10,42,2]  marginal_11_2  1
    f[10,42,5]  R156      -1
    f[10,42,5]  R196      1
    f[10,42,5]  marginal_11_5  1
    f[10,43,2]  R157      -1
    f[10,43,2]  R194      1
    f[10,43,2]  marginal_11_2  1
    f[10,43,5]  R157      -1
    f[10,43,5]  R197      1
    f[10,43,5]  marginal_11_5  1
    f[10,44,2]  R158      -1
    f[10,44,2]  R195      1
    f[10,44,2]  marginal_11_2  1
    f[10,44,5]  R158      -1
    f[10,44,5]  R198      1
    f[10,44,5]  marginal_11_5  1
    f[10,45,2]  R159      -1
    f[10,45,2]  R196      1
    f[10,45,2]  marginal_11_2  1
    f[10,45,5]  R159      -1
    f[10,45,5]  R199      1
    f[10,45,5]  marginal_11_5  1
    f[10,46,2]  R160      -1
    f[10,46,2]  R197      1
    f[10,46,2]  marginal_11_2  1
    f[10,46,5]  R160      -1
    f[10,46,5]  R200      1
    f[10,46,5]  marginal_11_5  1
    f[10,47,2]  R161      -1
    f[10,47,2]  R198      1
    f[10,47,2]  marginal_11_2  1
    f[10,47,5]  R161      -1
    f[10,47,5]  R201      1
    f[10,47,5]  marginal_11_5  1
    f[10,48,2]  R162      -1
    f[10,48,2]  R199      1
    f[10,48,2]  marginal_11_2  1
    f[10,48,5]  R162      -1
    f[10,48,5]  R202      1
    f[10,48,5]  marginal_11_5  1
    f[10,49,2]  R163      -1
    f[10,49,2]  R200      1
    f[10,49,2]  marginal_11_2  1
    f[10,49,5]  R163      -1
    f[10,49,5]  R203      1
    f[10,49,5]  marginal_11_5  1
    f[10,50,2]  R164      -1
    f[10,50,2]  R201      1
    f[10,50,2]  marginal_11_2  1
    f[10,50,5]  R164      -1
    f[10,50,5]  R204      1
    f[10,50,5]  marginal_11_5  1
    f[10,51,2]  R165      -1
    f[10,51,2]  R202      1
    f[10,51,2]  marginal_11_2  1
    f[10,51,5]  R165      -1
    f[10,51,5]  R205      1
    f[10,51,5]  marginal_11_5  1
    f[10,52,2]  R166      -1
    f[10,52,2]  R203      1
    f[10,52,2]  marginal_11_2  1
    f[10,52,5]  R166      -1
    f[10,52,5]  R206      1
    f[10,52,5]  marginal_11_5  1
    f[10,53,2]  R167      -1
    f[10,53,2]  R204      1
    f[10,53,2]  marginal_11_2  1
    f[10,53,5]  R167      -1
    f[10,53,5]  R207      1
    f[10,53,5]  marginal_11_5  1
    f[10,54,2]  R168      -1
    f[10,54,2]  R205      1
    f[10,54,2]  marginal_11_2  1
    f[10,54,5]  R168      -1
    f[10,54,5]  R208      1
    f[10,54,5]  marginal_11_5  1
    f[10,55,2]  R169      -1
    f[10,55,2]  R206      1
    f[10,55,2]  marginal_11_2  1
    f[10,55,5]  R169      -1
    f[10,55,5]  R209      1
    f[10,55,5]  marginal_11_5  1
    f[10,56,2]  R170      -1
    f[10,56,2]  R207      1
    f[10,56,2]  marginal_11_2  1
    f[10,56,5]  R170      -1
    f[10,56,5]  R210      1
    f[10,56,5]  marginal_11_5  1
    f[10,57,2]  R171      -1
    f[10,57,2]  R208      1
    f[10,57,2]  marginal_11_2  1
    f[10,57,5]  R171      -1
    f[10,57,5]  R211      1
    f[10,57,5]  marginal_11_5  1
    f[10,58,2]  R172      -1
    f[10,58,2]  R209      1
    f[10,58,2]  marginal_11_2  1
    f[10,58,5]  R172      -1
    f[10,58,5]  R212      1
    f[10,58,5]  marginal_11_5  1
    f[10,59,2]  R173      -1
    f[10,59,2]  R210      1
    f[10,59,2]  marginal_11_2  1
    f[10,59,5]  R173      -1
    f[10,59,5]  R213      1
    f[10,59,5]  marginal_11_5  1
    f[10,60,2]  R174      -1
    f[10,60,2]  R211      1
    f[10,60,2]  marginal_11_2  1
    f[10,60,5]  R174      -1
    f[10,60,5]  R214      1
    f[10,60,5]  marginal_11_5  1
    f[10,61,2]  R175      -1
    f[10,61,2]  R212      1
    f[10,61,2]  marginal_11_2  1
    f[10,61,5]  R175      -1
    f[10,61,5]  R215      1
    f[10,61,5]  marginal_11_5  1
    f[10,62,2]  R176      -1
    f[10,62,2]  R213      1
    f[10,62,2]  marginal_11_2  1
    f[10,62,5]  R176      -1
    f[10,62,5]  R216      1
    f[10,62,5]  marginal_11_5  1
    f[10,63,2]  R177      -1
    f[10,63,2]  R214      1
    f[10,63,2]  marginal_11_2  1
    f[10,63,5]  R177      -1
    f[10,63,5]  R217      1
    f[10,63,5]  marginal_11_5  1
    f[10,64,2]  R178      -1
    f[10,64,2]  R215      1
    f[10,64,2]  marginal_11_2  1
    f[10,64,5]  R178      -1
    f[10,64,5]  R218      1
    f[10,64,5]  marginal_11_5  1
    f[10,65,2]  R179      -1
    f[10,65,2]  R216      1
    f[10,65,2]  marginal_11_2  1
    f[10,65,5]  R179      -1
    f[10,65,5]  R219      1
    f[10,65,5]  marginal_11_5  1
    f[10,66,2]  R180      -1
    f[10,66,2]  R217      1
    f[10,66,2]  marginal_11_2  1
    f[10,66,5]  R180      -1
    f[10,66,5]  R220      1
    f[10,66,5]  marginal_11_5  1
    f[10,67,2]  R181      -1
    f[10,67,2]  R218      1
    f[10,67,2]  marginal_11_2  1
    f[10,67,5]  R181      -1
    f[10,67,5]  R221      1
    f[10,67,5]  marginal_11_5  1
    f[10,68,2]  R182      -1
    f[10,68,2]  R219      1
    f[10,68,2]  marginal_11_2  1
    f[10,68,5]  R182      -1
    f[10,68,5]  R222      1
    f[10,68,5]  marginal_11_5  1
    f[10,69,2]  R183      -1
    f[10,69,2]  R220      1
    f[10,69,2]  marginal_11_2  1
    f[10,69,5]  R183      -1
    f[10,69,5]  R223      1
    f[10,69,5]  marginal_11_5  1
    f[10,70,2]  R184      -1
    f[10,70,2]  R221      1
    f[10,70,2]  marginal_11_2  1
    f[10,70,5]  R184      -1
    f[10,70,5]  R224      1
    f[10,70,5]  marginal_11_5  1
    f[10,71,2]  R185      -1
    f[10,71,2]  R222      1
    f[10,71,2]  marginal_11_2  1
    f[10,71,5]  R185      -1
    f[10,71,5]  R225      1
    f[10,71,5]  marginal_11_5  1
    f[10,72,2]  R186      -1
    f[10,72,2]  R223      1
    f[10,72,2]  marginal_11_2  1
    f[10,72,5]  R186      -1
    f[10,72,5]  R226      1
    f[10,72,5]  marginal_11_5  1
    f[10,73,2]  R187      -1
    f[10,73,2]  R224      1
    f[10,73,2]  marginal_11_2  1
    f[10,73,5]  R187      -1
    f[10,73,5]  R227      1
    f[10,73,5]  marginal_11_5  1
    f[10,74,2]  R188      -1
    f[10,74,2]  R225      1
    f[10,74,2]  marginal_11_2  1
    f[10,74,5]  R188      -1
    f[10,74,5]  R228      1
    f[10,74,5]  marginal_11_5  1
    f[10,75,2]  R189      -1
    f[10,75,2]  R226      1
    f[10,75,2]  marginal_11_2  1
    f[10,75,5]  R189      -1
    f[10,75,5]  R229      1
    f[10,75,5]  marginal_11_5  1
    f[10,76,2]  R190      -1
    f[10,76,2]  R227      1
    f[10,76,2]  marginal_11_2  1
    f[10,76,5]  R190      -1
    f[10,76,5]  R230      1
    f[10,76,5]  marginal_11_5  1
    f[10,77,2]  R191      -1
    f[10,77,2]  R228      1
    f[10,77,2]  marginal_11_2  1
    f[10,77,5]  R191      -1
    f[10,77,5]  R231      1
    f[10,77,5]  marginal_11_5  1
    f[11,43,4]  R192      -1
    f[11,43,4]  R232      1
    f[11,43,4]  marginal_12_4  1
    f[11,43,7]  R192      -1
    f[11,43,7]  R235      1
    f[11,43,7]  marginal_12_7  1
    f[11,44,4]  R193      -1
    f[11,44,4]  R233      1
    f[11,44,4]  marginal_12_4  1
    f[11,44,7]  R193      -1
    f[11,44,7]  R236      1
    f[11,44,7]  marginal_12_7  1
    f[11,45,4]  R194      -1
    f[11,45,4]  R234      1
    f[11,45,4]  marginal_12_4  1
    f[11,45,7]  R194      -1
    f[11,45,7]  R237      1
    f[11,45,7]  marginal_12_7  1
    f[11,46,4]  R195      -1
    f[11,46,4]  R235      1
    f[11,46,4]  marginal_12_4  1
    f[11,46,7]  R195      -1
    f[11,46,7]  R238      1
    f[11,46,7]  marginal_12_7  1
    f[11,47,4]  R196      -1
    f[11,47,4]  R236      1
    f[11,47,4]  marginal_12_4  1
    f[11,47,7]  R196      -1
    f[11,47,7]  R239      1
    f[11,47,7]  marginal_12_7  1
    f[11,48,4]  R197      -1
    f[11,48,4]  R237      1
    f[11,48,4]  marginal_12_4  1
    f[11,48,7]  R197      -1
    f[11,48,7]  R240      1
    f[11,48,7]  marginal_12_7  1
    f[11,49,4]  R198      -1
    f[11,49,4]  R238      1
    f[11,49,4]  marginal_12_4  1
    f[11,49,7]  R198      -1
    f[11,49,7]  R241      1
    f[11,49,7]  marginal_12_7  1
    f[11,50,4]  R199      -1
    f[11,50,4]  R239      1
    f[11,50,4]  marginal_12_4  1
    f[11,50,7]  R199      -1
    f[11,50,7]  R242      1
    f[11,50,7]  marginal_12_7  1
    f[11,51,4]  R200      -1
    f[11,51,4]  R240      1
    f[11,51,4]  marginal_12_4  1
    f[11,51,7]  R200      -1
    f[11,51,7]  R243      1
    f[11,51,7]  marginal_12_7  1
    f[11,52,4]  R201      -1
    f[11,52,4]  R241      1
    f[11,52,4]  marginal_12_4  1
    f[11,52,7]  R201      -1
    f[11,52,7]  R244      1
    f[11,52,7]  marginal_12_7  1
    f[11,53,4]  R202      -1
    f[11,53,4]  R242      1
    f[11,53,4]  marginal_12_4  1
    f[11,53,7]  R202      -1
    f[11,53,7]  R245      1
    f[11,53,7]  marginal_12_7  1
    f[11,54,4]  R203      -1
    f[11,54,4]  R243      1
    f[11,54,4]  marginal_12_4  1
    f[11,54,7]  R203      -1
    f[11,54,7]  R246      1
    f[11,54,7]  marginal_12_7  1
    f[11,55,4]  R204      -1
    f[11,55,4]  R244      1
    f[11,55,4]  marginal_12_4  1
    f[11,55,7]  R204      -1
    f[11,55,7]  R247      1
    f[11,55,7]  marginal_12_7  1
    f[11,56,4]  R205      -1
    f[11,56,4]  R245      1
    f[11,56,4]  marginal_12_4  1
    f[11,56,7]  R205      -1
    f[11,56,7]  R248      1
    f[11,56,7]  marginal_12_7  1
    f[11,57,4]  R206      -1
    f[11,57,4]  R246      1
    f[11,57,4]  marginal_12_4  1
    f[11,57,7]  R206      -1
    f[11,57,7]  R249      1
    f[11,57,7]  marginal_12_7  1
    f[11,58,4]  R207      -1
    f[11,58,4]  R247      1
    f[11,58,4]  marginal_12_4  1
    f[11,58,7]  R207      -1
    f[11,58,7]  R250      1
    f[11,58,7]  marginal_12_7  1
    f[11,59,4]  R208      -1
    f[11,59,4]  R248      1
    f[11,59,4]  marginal_12_4  1
    f[11,59,7]  R208      -1
    f[11,59,7]  R251      1
    f[11,59,7]  marginal_12_7  1
    f[11,60,4]  R209      -1
    f[11,60,4]  R249      1
    f[11,60,4]  marginal_12_4  1
    f[11,60,7]  R209      -1
    f[11,60,7]  R252      1
    f[11,60,7]  marginal_12_7  1
    f[11,61,4]  R210      -1
    f[11,61,4]  R250      1
    f[11,61,4]  marginal_12_4  1
    f[11,61,7]  R210      -1
    f[11,61,7]  R253      1
    f[11,61,7]  marginal_12_7  1
    f[11,62,4]  R211      -1
    f[11,62,4]  R251      1
    f[11,62,4]  marginal_12_4  1
    f[11,62,7]  R211      -1
    f[11,62,7]  R254      1
    f[11,62,7]  marginal_12_7  1
    f[11,63,4]  R212      -1
    f[11,63,4]  R252      1
    f[11,63,4]  marginal_12_4  1
    f[11,63,7]  R212      -1
    f[11,63,7]  R255      1
    f[11,63,7]  marginal_12_7  1
    f[11,64,4]  R213      -1
    f[11,64,4]  R253      1
    f[11,64,4]  marginal_12_4  1
    f[11,64,7]  R213      -1
    f[11,64,7]  R256      1
    f[11,64,7]  marginal_12_7  1
    f[11,65,4]  R214      -1
    f[11,65,4]  R254      1
    f[11,65,4]  marginal_12_4  1
    f[11,65,7]  R214      -1
    f[11,65,7]  R257      1
    f[11,65,7]  marginal_12_7  1
    f[11,66,4]  R215      -1
    f[11,66,4]  R255      1
    f[11,66,4]  marginal_12_4  1
    f[11,66,7]  R215      -1
    f[11,66,7]  R258      1
    f[11,66,7]  marginal_12_7  1
    f[11,67,4]  R216      -1
    f[11,67,4]  R256      1
    f[11,67,4]  marginal_12_4  1
    f[11,67,7]  R216      -1
    f[11,67,7]  R259      1
    f[11,67,7]  marginal_12_7  1
    f[11,68,4]  R217      -1
    f[11,68,4]  R257      1
    f[11,68,4]  marginal_12_4  1
    f[11,68,7]  R217      -1
    f[11,68,7]  R260      1
    f[11,68,7]  marginal_12_7  1
    f[11,69,4]  R218      -1
    f[11,69,4]  R258      1
    f[11,69,4]  marginal_12_4  1
    f[11,69,7]  R218      -1
    f[11,69,7]  R261      1
    f[11,69,7]  marginal_12_7  1
    f[11,70,4]  R219      -1
    f[11,70,4]  R259      1
    f[11,70,4]  marginal_12_4  1
    f[11,70,7]  R219      -1
    f[11,70,7]  R262      1
    f[11,70,7]  marginal_12_7  1
    f[11,71,4]  R220      -1
    f[11,71,4]  R260      1
    f[11,71,4]  marginal_12_4  1
    f[11,71,7]  R220      -1
    f[11,71,7]  R263      1
    f[11,71,7]  marginal_12_7  1
    f[11,72,4]  R221      -1
    f[11,72,4]  R261      1
    f[11,72,4]  marginal_12_4  1
    f[11,72,7]  R221      -1
    f[11,72,7]  R264      1
    f[11,72,7]  marginal_12_7  1
    f[11,73,4]  R222      -1
    f[11,73,4]  R262      1
    f[11,73,4]  marginal_12_4  1
    f[11,73,7]  R222      -1
    f[11,73,7]  R265      1
    f[11,73,7]  marginal_12_7  1
    f[11,74,4]  R223      -1
    f[11,74,4]  R263      1
    f[11,74,4]  marginal_12_4  1
    f[11,74,7]  R223      -1
    f[11,74,7]  R266      1
    f[11,74,7]  marginal_12_7  1
    f[11,75,4]  R224      -1
    f[11,75,4]  R264      1
    f[11,75,4]  marginal_12_4  1
    f[11,75,7]  R224      -1
    f[11,75,7]  R267      1
    f[11,75,7]  marginal_12_7  1
    f[11,76,4]  R225      -1
    f[11,76,4]  R265      1
    f[11,76,4]  marginal_12_4  1
    f[11,76,7]  R225      -1
    f[11,76,7]  R268      1
    f[11,76,7]  marginal_12_7  1
    f[11,77,4]  R226      -1
    f[11,77,4]  R266      1
    f[11,77,4]  marginal_12_4  1
    f[11,77,7]  R226      -1
    f[11,77,7]  R269      1
    f[11,77,7]  marginal_12_7  1
    f[11,78,4]  R227      -1
    f[11,78,4]  R267      1
    f[11,78,4]  marginal_12_4  1
    f[11,78,7]  R227      -1
    f[11,78,7]  R270      1
    f[11,78,7]  marginal_12_7  1
    f[11,79,4]  R228      -1
    f[11,79,4]  R268      1
    f[11,79,4]  marginal_12_4  1
    f[11,79,7]  R228      -1
    f[11,79,7]  R271      1
    f[11,79,7]  marginal_12_7  1
    f[11,80,4]  R229      -1
    f[11,80,4]  R269      1
    f[11,80,4]  marginal_12_4  1
    f[11,80,7]  R229      -1
    f[11,80,7]  R272      1
    f[11,80,7]  marginal_12_7  1
    f[11,81,4]  R230      -1
    f[11,81,4]  R270      1
    f[11,81,4]  marginal_12_4  1
    f[11,81,7]  R230      -1
    f[11,81,7]  R273      1
    f[11,81,7]  marginal_12_7  1
    f[11,82,4]  R231      -1
    f[11,82,4]  R271      1
    f[11,82,4]  marginal_12_4  1
    f[11,82,7]  R231      -1
    f[11,82,7]  R274      1
    f[11,82,7]  marginal_12_7  1
    f[12,47,4]  R232      -1
    f[12,47,4]  R275      1
    f[12,47,4]  marginal_13_4  1
    f[12,47,7]  R232      -1
    f[12,47,7]  R278      1
    f[12,47,7]  marginal_13_7  1
    f[12,47,8]  R232      -1
    f[12,47,8]  R279      1
    f[12,47,8]  marginal_13_8  1
    f[12,48,4]  R233      -1
    f[12,48,4]  R276      1
    f[12,48,4]  marginal_13_4  1
    f[12,48,7]  R233      -1
    f[12,48,7]  R279      1
    f[12,48,7]  marginal_13_7  1
    f[12,48,8]  R233      -1
    f[12,48,8]  R280      1
    f[12,48,8]  marginal_13_8  1
    f[12,49,4]  R234      -1
    f[12,49,4]  R277      1
    f[12,49,4]  marginal_13_4  1
    f[12,49,7]  R234      -1
    f[12,49,7]  R280      1
    f[12,49,7]  marginal_13_7  1
    f[12,49,8]  R234      -1
    f[12,49,8]  R281      1
    f[12,49,8]  marginal_13_8  1
    f[12,50,4]  R235      -1
    f[12,50,4]  R278      1
    f[12,50,4]  marginal_13_4  1
    f[12,50,7]  R235      -1
    f[12,50,7]  R281      1
    f[12,50,7]  marginal_13_7  1
    f[12,50,8]  R235      -1
    f[12,50,8]  R282      1
    f[12,50,8]  marginal_13_8  1
    f[12,51,4]  R236      -1
    f[12,51,4]  R279      1
    f[12,51,4]  marginal_13_4  1
    f[12,51,7]  R236      -1
    f[12,51,7]  R282      1
    f[12,51,7]  marginal_13_7  1
    f[12,51,8]  R236      -1
    f[12,51,8]  R283      1
    f[12,51,8]  marginal_13_8  1
    f[12,52,4]  R237      -1
    f[12,52,4]  R280      1
    f[12,52,4]  marginal_13_4  1
    f[12,52,7]  R237      -1
    f[12,52,7]  R283      1
    f[12,52,7]  marginal_13_7  1
    f[12,52,8]  R237      -1
    f[12,52,8]  R284      1
    f[12,52,8]  marginal_13_8  1
    f[12,53,4]  R238      -1
    f[12,53,4]  R281      1
    f[12,53,4]  marginal_13_4  1
    f[12,53,7]  R238      -1
    f[12,53,7]  R284      1
    f[12,53,7]  marginal_13_7  1
    f[12,53,8]  R238      -1
    f[12,53,8]  R285      1
    f[12,53,8]  marginal_13_8  1
    f[12,54,4]  R239      -1
    f[12,54,4]  R282      1
    f[12,54,4]  marginal_13_4  1
    f[12,54,7]  R239      -1
    f[12,54,7]  R285      1
    f[12,54,7]  marginal_13_7  1
    f[12,54,8]  R239      -1
    f[12,54,8]  R286      1
    f[12,54,8]  marginal_13_8  1
    f[12,55,4]  R240      -1
    f[12,55,4]  R283      1
    f[12,55,4]  marginal_13_4  1
    f[12,55,7]  R240      -1
    f[12,55,7]  R286      1
    f[12,55,7]  marginal_13_7  1
    f[12,55,8]  R240      -1
    f[12,55,8]  R287      1
    f[12,55,8]  marginal_13_8  1
    f[12,56,4]  R241      -1
    f[12,56,4]  R284      1
    f[12,56,4]  marginal_13_4  1
    f[12,56,7]  R241      -1
    f[12,56,7]  R287      1
    f[12,56,7]  marginal_13_7  1
    f[12,56,8]  R241      -1
    f[12,56,8]  R288      1
    f[12,56,8]  marginal_13_8  1
    f[12,57,4]  R242      -1
    f[12,57,4]  R285      1
    f[12,57,4]  marginal_13_4  1
    f[12,57,7]  R242      -1
    f[12,57,7]  R288      1
    f[12,57,7]  marginal_13_7  1
    f[12,57,8]  R242      -1
    f[12,57,8]  R289      1
    f[12,57,8]  marginal_13_8  1
    f[12,58,4]  R243      -1
    f[12,58,4]  R286      1
    f[12,58,4]  marginal_13_4  1
    f[12,58,7]  R243      -1
    f[12,58,7]  R289      1
    f[12,58,7]  marginal_13_7  1
    f[12,58,8]  R243      -1
    f[12,58,8]  R290      1
    f[12,58,8]  marginal_13_8  1
    f[12,59,4]  R244      -1
    f[12,59,4]  R287      1
    f[12,59,4]  marginal_13_4  1
    f[12,59,7]  R244      -1
    f[12,59,7]  R290      1
    f[12,59,7]  marginal_13_7  1
    f[12,59,8]  R244      -1
    f[12,59,8]  R291      1
    f[12,59,8]  marginal_13_8  1
    f[12,60,4]  R245      -1
    f[12,60,4]  R288      1
    f[12,60,4]  marginal_13_4  1
    f[12,60,7]  R245      -1
    f[12,60,7]  R291      1
    f[12,60,7]  marginal_13_7  1
    f[12,60,8]  R245      -1
    f[12,60,8]  R292      1
    f[12,60,8]  marginal_13_8  1
    f[12,61,4]  R246      -1
    f[12,61,4]  R289      1
    f[12,61,4]  marginal_13_4  1
    f[12,61,7]  R246      -1
    f[12,61,7]  R292      1
    f[12,61,7]  marginal_13_7  1
    f[12,61,8]  R246      -1
    f[12,61,8]  R293      1
    f[12,61,8]  marginal_13_8  1
    f[12,62,4]  R247      -1
    f[12,62,4]  R290      1
    f[12,62,4]  marginal_13_4  1
    f[12,62,7]  R247      -1
    f[12,62,7]  R293      1
    f[12,62,7]  marginal_13_7  1
    f[12,62,8]  R247      -1
    f[12,62,8]  R294      1
    f[12,62,8]  marginal_13_8  1
    f[12,63,4]  R248      -1
    f[12,63,4]  R291      1
    f[12,63,4]  marginal_13_4  1
    f[12,63,7]  R248      -1
    f[12,63,7]  R294      1
    f[12,63,7]  marginal_13_7  1
    f[12,63,8]  R248      -1
    f[12,63,8]  R295      1
    f[12,63,8]  marginal_13_8  1
    f[12,64,4]  R249      -1
    f[12,64,4]  R292      1
    f[12,64,4]  marginal_13_4  1
    f[12,64,7]  R249      -1
    f[12,64,7]  R295      1
    f[12,64,7]  marginal_13_7  1
    f[12,64,8]  R249      -1
    f[12,64,8]  R296      1
    f[12,64,8]  marginal_13_8  1
    f[12,65,4]  R250      -1
    f[12,65,4]  R293      1
    f[12,65,4]  marginal_13_4  1
    f[12,65,7]  R250      -1
    f[12,65,7]  R296      1
    f[12,65,7]  marginal_13_7  1
    f[12,65,8]  R250      -1
    f[12,65,8]  R297      1
    f[12,65,8]  marginal_13_8  1
    f[12,66,4]  R251      -1
    f[12,66,4]  R294      1
    f[12,66,4]  marginal_13_4  1
    f[12,66,7]  R251      -1
    f[12,66,7]  R297      1
    f[12,66,7]  marginal_13_7  1
    f[12,66,8]  R251      -1
    f[12,66,8]  R298      1
    f[12,66,8]  marginal_13_8  1
    f[12,67,4]  R252      -1
    f[12,67,4]  R295      1
    f[12,67,4]  marginal_13_4  1
    f[12,67,7]  R252      -1
    f[12,67,7]  R298      1
    f[12,67,7]  marginal_13_7  1
    f[12,67,8]  R252      -1
    f[12,67,8]  R299      1
    f[12,67,8]  marginal_13_8  1
    f[12,68,4]  R253      -1
    f[12,68,4]  R296      1
    f[12,68,4]  marginal_13_4  1
    f[12,68,7]  R253      -1
    f[12,68,7]  R299      1
    f[12,68,7]  marginal_13_7  1
    f[12,68,8]  R253      -1
    f[12,68,8]  R300      1
    f[12,68,8]  marginal_13_8  1
    f[12,69,4]  R254      -1
    f[12,69,4]  R297      1
    f[12,69,4]  marginal_13_4  1
    f[12,69,7]  R254      -1
    f[12,69,7]  R300      1
    f[12,69,7]  marginal_13_7  1
    f[12,69,8]  R254      -1
    f[12,69,8]  R301      1
    f[12,69,8]  marginal_13_8  1
    f[12,70,4]  R255      -1
    f[12,70,4]  R298      1
    f[12,70,4]  marginal_13_4  1
    f[12,70,7]  R255      -1
    f[12,70,7]  R301      1
    f[12,70,7]  marginal_13_7  1
    f[12,70,8]  R255      -1
    f[12,70,8]  R302      1
    f[12,70,8]  marginal_13_8  1
    f[12,71,4]  R256      -1
    f[12,71,4]  R299      1
    f[12,71,4]  marginal_13_4  1
    f[12,71,7]  R256      -1
    f[12,71,7]  R302      1
    f[12,71,7]  marginal_13_7  1
    f[12,71,8]  R256      -1
    f[12,71,8]  R303      1
    f[12,71,8]  marginal_13_8  1
    f[12,72,4]  R257      -1
    f[12,72,4]  R300      1
    f[12,72,4]  marginal_13_4  1
    f[12,72,7]  R257      -1
    f[12,72,7]  R303      1
    f[12,72,7]  marginal_13_7  1
    f[12,72,8]  R257      -1
    f[12,72,8]  R304      1
    f[12,72,8]  marginal_13_8  1
    f[12,73,4]  R258      -1
    f[12,73,4]  R301      1
    f[12,73,4]  marginal_13_4  1
    f[12,73,7]  R258      -1
    f[12,73,7]  R304      1
    f[12,73,7]  marginal_13_7  1
    f[12,73,8]  R258      -1
    f[12,73,8]  R305      1
    f[12,73,8]  marginal_13_8  1
    f[12,74,4]  R259      -1
    f[12,74,4]  R302      1
    f[12,74,4]  marginal_13_4  1
    f[12,74,7]  R259      -1
    f[12,74,7]  R305      1
    f[12,74,7]  marginal_13_7  1
    f[12,74,8]  R259      -1
    f[12,74,8]  R306      1
    f[12,74,8]  marginal_13_8  1
    f[12,75,4]  R260      -1
    f[12,75,4]  R303      1
    f[12,75,4]  marginal_13_4  1
    f[12,75,7]  R260      -1
    f[12,75,7]  R306      1
    f[12,75,7]  marginal_13_7  1
    f[12,75,8]  R260      -1
    f[12,75,8]  R307      1
    f[12,75,8]  marginal_13_8  1
    f[12,76,4]  R261      -1
    f[12,76,4]  R304      1
    f[12,76,4]  marginal_13_4  1
    f[12,76,7]  R261      -1
    f[12,76,7]  R307      1
    f[12,76,7]  marginal_13_7  1
    f[12,76,8]  R261      -1
    f[12,76,8]  R308      1
    f[12,76,8]  marginal_13_8  1
    f[12,77,4]  R262      -1
    f[12,77,4]  R305      1
    f[12,77,4]  marginal_13_4  1
    f[12,77,7]  R262      -1
    f[12,77,7]  R308      1
    f[12,77,7]  marginal_13_7  1
    f[12,77,8]  R262      -1
    f[12,77,8]  R309      1
    f[12,77,8]  marginal_13_8  1
    f[12,78,4]  R263      -1
    f[12,78,4]  R306      1
    f[12,78,4]  marginal_13_4  1
    f[12,78,7]  R263      -1
    f[12,78,7]  R309      1
    f[12,78,7]  marginal_13_7  1
    f[12,78,8]  R263      -1
    f[12,78,8]  R310      1
    f[12,78,8]  marginal_13_8  1
    f[12,79,4]  R264      -1
    f[12,79,4]  R307      1
    f[12,79,4]  marginal_13_4  1
    f[12,79,7]  R264      -1
    f[12,79,7]  R310      1
    f[12,79,7]  marginal_13_7  1
    f[12,79,8]  R264      -1
    f[12,79,8]  R311      1
    f[12,79,8]  marginal_13_8  1
    f[12,80,4]  R265      -1
    f[12,80,4]  R308      1
    f[12,80,4]  marginal_13_4  1
    f[12,80,7]  R265      -1
    f[12,80,7]  R311      1
    f[12,80,7]  marginal_13_7  1
    f[12,80,8]  R265      -1
    f[12,80,8]  R312      1
    f[12,80,8]  marginal_13_8  1
    f[12,81,4]  R266      -1
    f[12,81,4]  R309      1
    f[12,81,4]  marginal_13_4  1
    f[12,81,7]  R266      -1
    f[12,81,7]  R312      1
    f[12,81,7]  marginal_13_7  1
    f[12,81,8]  R266      -1
    f[12,81,8]  R313      1
    f[12,81,8]  marginal_13_8  1
    f[12,82,4]  R267      -1
    f[12,82,4]  R310      1
    f[12,82,4]  marginal_13_4  1
    f[12,82,7]  R267      -1
    f[12,82,7]  R313      1
    f[12,82,7]  marginal_13_7  1
    f[12,82,8]  R267      -1
    f[12,82,8]  R314      1
    f[12,82,8]  marginal_13_8  1
    f[12,83,4]  R268      -1
    f[12,83,4]  R311      1
    f[12,83,4]  marginal_13_4  1
    f[12,83,7]  R268      -1
    f[12,83,7]  R314      1
    f[12,83,7]  marginal_13_7  1
    f[12,83,8]  R268      -1
    f[12,83,8]  R315      1
    f[12,83,8]  marginal_13_8  1
    f[12,84,4]  R269      -1
    f[12,84,4]  R312      1
    f[12,84,4]  marginal_13_4  1
    f[12,84,7]  R269      -1
    f[12,84,7]  R315      1
    f[12,84,7]  marginal_13_7  1
    f[12,84,8]  R269      -1
    f[12,84,8]  R316      1
    f[12,84,8]  marginal_13_8  1
    f[12,85,4]  R270      -1
    f[12,85,4]  R313      1
    f[12,85,4]  marginal_13_4  1
    f[12,85,7]  R270      -1
    f[12,85,7]  R316      1
    f[12,85,7]  marginal_13_7  1
    f[12,85,8]  R270      -1
    f[12,85,8]  R317      1
    f[12,85,8]  marginal_13_8  1
    f[12,86,4]  R271      -1
    f[12,86,4]  R314      1
    f[12,86,4]  marginal_13_4  1
    f[12,86,7]  R271      -1
    f[12,86,7]  R317      1
    f[12,86,7]  marginal_13_7  1
    f[12,86,8]  R271      -1
    f[12,86,8]  R318      1
    f[12,86,8]  marginal_13_8  1
    f[12,87,4]  R272      -1
    f[12,87,4]  R315      1
    f[12,87,4]  marginal_13_4  1
    f[12,87,7]  R272      -1
    f[12,87,7]  R318      1
    f[12,87,7]  marginal_13_7  1
    f[12,87,8]  R272      -1
    f[12,87,8]  R319      1
    f[12,87,8]  marginal_13_8  1
    f[12,88,4]  R273      -1
    f[12,88,4]  R316      1
    f[12,88,4]  marginal_13_4  1
    f[12,88,7]  R273      -1
    f[12,88,7]  R319      1
    f[12,88,7]  marginal_13_7  1
    f[12,88,8]  R273      -1
    f[12,88,8]  R320      1
    f[12,88,8]  marginal_13_8  1
    f[12,89,4]  R274      -1
    f[12,89,4]  R317      1
    f[12,89,4]  marginal_13_4  1
    f[12,89,7]  R274      -1
    f[12,89,7]  R320      1
    f[12,89,7]  marginal_13_7  1
    f[12,89,8]  R274      -1
    f[12,89,8]  R321      1
    f[12,89,8]  marginal_13_8  1
    f[13,51,2]  R275      -1
    f[13,51,2]  R322      1
    f[13,51,2]  marginal_14_2  1
    f[13,51,8]  R275      -1
    f[13,51,8]  R328      1
    f[13,51,8]  marginal_14_8  1
    f[13,52,2]  R276      -1
    f[13,52,2]  R323      1
    f[13,52,2]  marginal_14_2  1
    f[13,52,8]  R276      -1
    f[13,52,8]  R329      1
    f[13,52,8]  marginal_14_8  1
    f[13,53,2]  R277      -1
    f[13,53,2]  R324      1
    f[13,53,2]  marginal_14_2  1
    f[13,53,8]  R277      -1
    f[13,53,8]  R330      1
    f[13,53,8]  marginal_14_8  1
    f[13,54,2]  R278      -1
    f[13,54,2]  R325      1
    f[13,54,2]  marginal_14_2  1
    f[13,54,8]  R278      -1
    f[13,54,8]  R331      1
    f[13,54,8]  marginal_14_8  1
    f[13,55,2]  R279      -1
    f[13,55,2]  R326      1
    f[13,55,2]  marginal_14_2  1
    f[13,55,8]  R279      -1
    f[13,55,8]  R332      1
    f[13,55,8]  marginal_14_8  1
    f[13,56,2]  R280      -1
    f[13,56,2]  R327      1
    f[13,56,2]  marginal_14_2  1
    f[13,56,8]  R280      -1
    f[13,56,8]  R333      1
    f[13,56,8]  marginal_14_8  1
    f[13,57,2]  R281      -1
    f[13,57,2]  R328      1
    f[13,57,2]  marginal_14_2  1
    f[13,57,8]  R281      -1
    f[13,57,8]  R334      1
    f[13,57,8]  marginal_14_8  1
    f[13,58,2]  R282      -1
    f[13,58,2]  R329      1
    f[13,58,2]  marginal_14_2  1
    f[13,58,8]  R282      -1
    f[13,58,8]  R335      1
    f[13,58,8]  marginal_14_8  1
    f[13,59,2]  R283      -1
    f[13,59,2]  R330      1
    f[13,59,2]  marginal_14_2  1
    f[13,59,8]  R283      -1
    f[13,59,8]  R336      1
    f[13,59,8]  marginal_14_8  1
    f[13,60,2]  R284      -1
    f[13,60,2]  R331      1
    f[13,60,2]  marginal_14_2  1
    f[13,60,8]  R284      -1
    f[13,60,8]  R337      1
    f[13,60,8]  marginal_14_8  1
    f[13,61,2]  R285      -1
    f[13,61,2]  R332      1
    f[13,61,2]  marginal_14_2  1
    f[13,61,8]  R285      -1
    f[13,61,8]  R338      1
    f[13,61,8]  marginal_14_8  1
    f[13,62,2]  R286      -1
    f[13,62,2]  R333      1
    f[13,62,2]  marginal_14_2  1
    f[13,62,8]  R286      -1
    f[13,62,8]  R339      1
    f[13,62,8]  marginal_14_8  1
    f[13,63,2]  R287      -1
    f[13,63,2]  R334      1
    f[13,63,2]  marginal_14_2  1
    f[13,63,8]  R287      -1
    f[13,63,8]  R340      1
    f[13,63,8]  marginal_14_8  1
    f[13,64,2]  R288      -1
    f[13,64,2]  R335      1
    f[13,64,2]  marginal_14_2  1
    f[13,64,8]  R288      -1
    f[13,64,8]  R341      1
    f[13,64,8]  marginal_14_8  1
    f[13,65,2]  R289      -1
    f[13,65,2]  R336      1
    f[13,65,2]  marginal_14_2  1
    f[13,65,8]  R289      -1
    f[13,65,8]  R342      1
    f[13,65,8]  marginal_14_8  1
    f[13,66,2]  R290      -1
    f[13,66,2]  R337      1
    f[13,66,2]  marginal_14_2  1
    f[13,66,8]  R290      -1
    f[13,66,8]  R343      1
    f[13,66,8]  marginal_14_8  1
    f[13,67,2]  R291      -1
    f[13,67,2]  R338      1
    f[13,67,2]  marginal_14_2  1
    f[13,67,8]  R291      -1
    f[13,67,8]  R344      1
    f[13,67,8]  marginal_14_8  1
    f[13,68,2]  R292      -1
    f[13,68,2]  R339      1
    f[13,68,2]  marginal_14_2  1
    f[13,68,8]  R292      -1
    f[13,68,8]  R345      1
    f[13,68,8]  marginal_14_8  1
    f[13,69,2]  R293      -1
    f[13,69,2]  R340      1
    f[13,69,2]  marginal_14_2  1
    f[13,69,8]  R293      -1
    f[13,69,8]  R346      1
    f[13,69,8]  marginal_14_8  1
    f[13,70,2]  R294      -1
    f[13,70,2]  R341      1
    f[13,70,2]  marginal_14_2  1
    f[13,70,8]  R294      -1
    f[13,70,8]  R347      1
    f[13,70,8]  marginal_14_8  1
    f[13,71,2]  R295      -1
    f[13,71,2]  R342      1
    f[13,71,2]  marginal_14_2  1
    f[13,71,8]  R295      -1
    f[13,71,8]  R348      1
    f[13,71,8]  marginal_14_8  1
    f[13,72,2]  R296      -1
    f[13,72,2]  R343      1
    f[13,72,2]  marginal_14_2  1
    f[13,72,8]  R296      -1
    f[13,72,8]  R349      1
    f[13,72,8]  marginal_14_8  1
    f[13,73,2]  R297      -1
    f[13,73,2]  R344      1
    f[13,73,2]  marginal_14_2  1
    f[13,73,8]  R297      -1
    f[13,73,8]  R350      1
    f[13,73,8]  marginal_14_8  1
    f[13,74,2]  R298      -1
    f[13,74,2]  R345      1
    f[13,74,2]  marginal_14_2  1
    f[13,74,8]  R298      -1
    f[13,74,8]  R351      1
    f[13,74,8]  marginal_14_8  1
    f[13,75,2]  R299      -1
    f[13,75,2]  R346      1
    f[13,75,2]  marginal_14_2  1
    f[13,75,8]  R299      -1
    f[13,75,8]  R352      1
    f[13,75,8]  marginal_14_8  1
    f[13,76,2]  R300      -1
    f[13,76,2]  R347      1
    f[13,76,2]  marginal_14_2  1
    f[13,76,8]  R300      -1
    f[13,76,8]  R353      1
    f[13,76,8]  marginal_14_8  1
    f[13,77,2]  R301      -1
    f[13,77,2]  R348      1
    f[13,77,2]  marginal_14_2  1
    f[13,77,8]  R301      -1
    f[13,77,8]  R354      1
    f[13,77,8]  marginal_14_8  1
    f[13,78,2]  R302      -1
    f[13,78,2]  R349      1
    f[13,78,2]  marginal_14_2  1
    f[13,78,8]  R302      -1
    f[13,78,8]  R355      1
    f[13,78,8]  marginal_14_8  1
    f[13,79,2]  R303      -1
    f[13,79,2]  R350      1
    f[13,79,2]  marginal_14_2  1
    f[13,79,8]  R303      -1
    f[13,79,8]  R356      1
    f[13,79,8]  marginal_14_8  1
    f[13,80,2]  R304      -1
    f[13,80,2]  R351      1
    f[13,80,2]  marginal_14_2  1
    f[13,80,8]  R304      -1
    f[13,80,8]  R357      1
    f[13,80,8]  marginal_14_8  1
    f[13,81,2]  R305      -1
    f[13,81,2]  R352      1
    f[13,81,2]  marginal_14_2  1
    f[13,81,8]  R305      -1
    f[13,81,8]  R358      1
    f[13,81,8]  marginal_14_8  1
    f[13,82,2]  R306      -1
    f[13,82,2]  R353      1
    f[13,82,2]  marginal_14_2  1
    f[13,82,8]  R306      -1
    f[13,82,8]  R359      1
    f[13,82,8]  marginal_14_8  1
    f[13,83,2]  R307      -1
    f[13,83,2]  R354      1
    f[13,83,2]  marginal_14_2  1
    f[13,83,8]  R307      -1
    f[13,83,8]  R360      1
    f[13,83,8]  marginal_14_8  1
    f[13,84,2]  R308      -1
    f[13,84,2]  R355      1
    f[13,84,2]  marginal_14_2  1
    f[13,84,8]  R308      -1
    f[13,84,8]  R361      1
    f[13,84,8]  marginal_14_8  1
    f[13,85,2]  R309      -1
    f[13,85,2]  R356      1
    f[13,85,2]  marginal_14_2  1
    f[13,85,8]  R309      -1
    f[13,85,8]  R362      1
    f[13,85,8]  marginal_14_8  1
    f[13,86,2]  R310      -1
    f[13,86,2]  R357      1
    f[13,86,2]  marginal_14_2  1
    f[13,86,8]  R310      -1
    f[13,86,8]  R363      1
    f[13,86,8]  marginal_14_8  1
    f[13,87,2]  R311      -1
    f[13,87,2]  R358      1
    f[13,87,2]  marginal_14_2  1
    f[13,87,8]  R311      -1
    f[13,87,8]  R364      1
    f[13,87,8]  marginal_14_8  1
    f[13,88,2]  R312      -1
    f[13,88,2]  R359      1
    f[13,88,2]  marginal_14_2  1
    f[13,88,8]  R312      -1
    f[13,88,8]  R365      1
    f[13,88,8]  marginal_14_8  1
    f[13,89,2]  R313      -1
    f[13,89,2]  R360      1
    f[13,89,2]  marginal_14_2  1
    f[13,89,8]  R313      -1
    f[13,89,8]  R366      1
    f[13,89,8]  marginal_14_8  1
    f[13,90,2]  R314      -1
    f[13,90,2]  R361      1
    f[13,90,2]  marginal_14_2  1
    f[13,90,8]  R314      -1
    f[13,90,8]  R367      1
    f[13,90,8]  marginal_14_8  1
    f[13,91,2]  R315      -1
    f[13,91,2]  R362      1
    f[13,91,2]  marginal_14_2  1
    f[13,91,8]  R315      -1
    f[13,91,8]  R368      1
    f[13,91,8]  marginal_14_8  1
    f[13,92,2]  R316      -1
    f[13,92,2]  R363      1
    f[13,92,2]  marginal_14_2  1
    f[13,92,8]  R316      -1
    f[13,92,8]  R369      1
    f[13,92,8]  marginal_14_8  1
    f[13,93,2]  R317      -1
    f[13,93,2]  R364      1
    f[13,93,2]  marginal_14_2  1
    f[13,93,8]  R317      -1
    f[13,93,8]  R370      1
    f[13,93,8]  marginal_14_8  1
    f[13,94,2]  R318      -1
    f[13,94,2]  R365      1
    f[13,94,2]  marginal_14_2  1
    f[13,94,8]  R318      -1
    f[13,94,8]  R371      1
    f[13,94,8]  marginal_14_8  1
    f[13,95,2]  R319      -1
    f[13,95,2]  R366      1
    f[13,95,2]  marginal_14_2  1
    f[13,95,8]  R319      -1
    f[13,95,8]  R372      1
    f[13,95,8]  marginal_14_8  1
    f[13,96,2]  R320      -1
    f[13,96,2]  R367      1
    f[13,96,2]  marginal_14_2  1
    f[13,96,8]  R320      -1
    f[13,96,8]  R373      1
    f[13,96,8]  marginal_14_8  1
    f[13,97,2]  R321      -1
    f[13,97,2]  R368      1
    f[13,97,2]  marginal_14_2  1
    f[13,97,8]  R321      -1
    f[13,97,8]  R374      1
    f[13,97,8]  marginal_14_8  1
    f[14,53,3]  R322      -1
    f[14,53,3]  R375      1
    f[14,53,3]  marginal_15_3  1
    f[14,53,8]  R322      -1
    f[14,53,8]  R380      1
    f[14,53,8]  marginal_15_8  1
    f[14,54,3]  R323      -1
    f[14,54,3]  R376      1
    f[14,54,3]  marginal_15_3  1
    f[14,54,8]  R323      -1
    f[14,54,8]  R381      1
    f[14,54,8]  marginal_15_8  1
    f[14,55,3]  R324      -1
    f[14,55,3]  R377      1
    f[14,55,3]  marginal_15_3  1
    f[14,55,8]  R324      -1
    f[14,55,8]  R382      1
    f[14,55,8]  marginal_15_8  1
    f[14,56,3]  R325      -1
    f[14,56,3]  R378      1
    f[14,56,3]  marginal_15_3  1
    f[14,56,8]  R325      -1
    f[14,56,8]  R383      1
    f[14,56,8]  marginal_15_8  1
    f[14,57,3]  R326      -1
    f[14,57,3]  R379      1
    f[14,57,3]  marginal_15_3  1
    f[14,57,8]  R326      -1
    f[14,57,8]  R384      1
    f[14,57,8]  marginal_15_8  1
    f[14,58,3]  R327      -1
    f[14,58,3]  R380      1
    f[14,58,3]  marginal_15_3  1
    f[14,58,8]  R327      -1
    f[14,58,8]  R385      1
    f[14,58,8]  marginal_15_8  1
    f[14,59,3]  R328      -1
    f[14,59,3]  R381      1
    f[14,59,3]  marginal_15_3  1
    f[14,59,8]  R328      -1
    f[14,59,8]  R386      1
    f[14,59,8]  marginal_15_8  1
    f[14,60,3]  R329      -1
    f[14,60,3]  R382      1
    f[14,60,3]  marginal_15_3  1
    f[14,60,8]  R329      -1
    f[14,60,8]  R387      1
    f[14,60,8]  marginal_15_8  1
    f[14,61,3]  R330      -1
    f[14,61,3]  R383      1
    f[14,61,3]  marginal_15_3  1
    f[14,61,8]  R330      -1
    f[14,61,8]  R388      1
    f[14,61,8]  marginal_15_8  1
    f[14,62,3]  R331      -1
    f[14,62,3]  R384      1
    f[14,62,3]  marginal_15_3  1
    f[14,62,8]  R331      -1
    f[14,62,8]  R389      1
    f[14,62,8]  marginal_15_8  1
    f[14,63,3]  R332      -1
    f[14,63,3]  R385      1
    f[14,63,3]  marginal_15_3  1
    f[14,63,8]  R332      -1
    f[14,63,8]  R390      1
    f[14,63,8]  marginal_15_8  1
    f[14,64,3]  R333      -1
    f[14,64,3]  R386      1
    f[14,64,3]  marginal_15_3  1
    f[14,64,8]  R333      -1
    f[14,64,8]  R391      1
    f[14,64,8]  marginal_15_8  1
    f[14,65,3]  R334      -1
    f[14,65,3]  R387      1
    f[14,65,3]  marginal_15_3  1
    f[14,65,8]  R334      -1
    f[14,65,8]  R392      1
    f[14,65,8]  marginal_15_8  1
    f[14,66,3]  R335      -1
    f[14,66,3]  R388      1
    f[14,66,3]  marginal_15_3  1
    f[14,66,8]  R335      -1
    f[14,66,8]  R393      1
    f[14,66,8]  marginal_15_8  1
    f[14,67,3]  R336      -1
    f[14,67,3]  R389      1
    f[14,67,3]  marginal_15_3  1
    f[14,67,8]  R336      -1
    f[14,67,8]  R394      1
    f[14,67,8]  marginal_15_8  1
    f[14,68,3]  R337      -1
    f[14,68,3]  R390      1
    f[14,68,3]  marginal_15_3  1
    f[14,68,8]  R337      -1
    f[14,68,8]  R395      1
    f[14,68,8]  marginal_15_8  1
    f[14,69,3]  R338      -1
    f[14,69,3]  R391      1
    f[14,69,3]  marginal_15_3  1
    f[14,69,8]  R338      -1
    f[14,69,8]  R396      1
    f[14,69,8]  marginal_15_8  1
    f[14,70,3]  R339      -1
    f[14,70,3]  R392      1
    f[14,70,3]  marginal_15_3  1
    f[14,70,8]  R339      -1
    f[14,70,8]  R397      1
    f[14,70,8]  marginal_15_8  1
    f[14,71,3]  R340      -1
    f[14,71,3]  R393      1
    f[14,71,3]  marginal_15_3  1
    f[14,71,8]  R340      -1
    f[14,71,8]  R398      1
    f[14,71,8]  marginal_15_8  1
    f[14,72,3]  R341      -1
    f[14,72,3]  R394      1
    f[14,72,3]  marginal_15_3  1
    f[14,72,8]  R341      -1
    f[14,72,8]  R399      1
    f[14,72,8]  marginal_15_8  1
    f[14,73,3]  R342      -1
    f[14,73,3]  R395      1
    f[14,73,3]  marginal_15_3  1
    f[14,73,8]  R342      -1
    f[14,73,8]  R400      1
    f[14,73,8]  marginal_15_8  1
    f[14,74,3]  R343      -1
    f[14,74,3]  R396      1
    f[14,74,3]  marginal_15_3  1
    f[14,74,8]  R343      -1
    f[14,74,8]  R401      1
    f[14,74,8]  marginal_15_8  1
    f[14,75,3]  R344      -1
    f[14,75,3]  R397      1
    f[14,75,3]  marginal_15_3  1
    f[14,75,8]  R344      -1
    f[14,75,8]  R402      1
    f[14,75,8]  marginal_15_8  1
    f[14,76,3]  R345      -1
    f[14,76,3]  R398      1
    f[14,76,3]  marginal_15_3  1
    f[14,76,8]  R345      -1
    f[14,76,8]  R403      1
    f[14,76,8]  marginal_15_8  1
    f[14,77,3]  R346      -1
    f[14,77,3]  R399      1
    f[14,77,3]  marginal_15_3  1
    f[14,77,8]  R346      -1
    f[14,77,8]  R404      1
    f[14,77,8]  marginal_15_8  1
    f[14,78,3]  R347      -1
    f[14,78,3]  R400      1
    f[14,78,3]  marginal_15_3  1
    f[14,78,8]  R347      -1
    f[14,78,8]  R405      1
    f[14,78,8]  marginal_15_8  1
    f[14,79,3]  R348      -1
    f[14,79,3]  R401      1
    f[14,79,3]  marginal_15_3  1
    f[14,79,8]  R348      -1
    f[14,79,8]  R406      1
    f[14,79,8]  marginal_15_8  1
    f[14,80,3]  R349      -1
    f[14,80,3]  R402      1
    f[14,80,3]  marginal_15_3  1
    f[14,80,8]  R349      -1
    f[14,80,8]  R407      1
    f[14,80,8]  marginal_15_8  1
    f[14,81,3]  R350      -1
    f[14,81,3]  R403      1
    f[14,81,3]  marginal_15_3  1
    f[14,81,8]  R350      -1
    f[14,81,8]  R408      1
    f[14,81,8]  marginal_15_8  1
    f[14,82,3]  R351      -1
    f[14,82,3]  R404      1
    f[14,82,3]  marginal_15_3  1
    f[14,82,8]  R351      -1
    f[14,82,8]  R409      1
    f[14,82,8]  marginal_15_8  1
    f[14,83,3]  R352      -1
    f[14,83,3]  R405      1
    f[14,83,3]  marginal_15_3  1
    f[14,83,8]  R352      -1
    f[14,83,8]  R410      1
    f[14,83,8]  marginal_15_8  1
    f[14,84,3]  R353      -1
    f[14,84,3]  R406      1
    f[14,84,3]  marginal_15_3  1
    f[14,84,8]  R353      -1
    f[14,84,8]  R411      1
    f[14,84,8]  marginal_15_8  1
    f[14,85,3]  R354      -1
    f[14,85,3]  R407      1
    f[14,85,3]  marginal_15_3  1
    f[14,85,8]  R354      -1
    f[14,85,8]  R412      1
    f[14,85,8]  marginal_15_8  1
    f[14,86,3]  R355      -1
    f[14,86,3]  R408      1
    f[14,86,3]  marginal_15_3  1
    f[14,86,8]  R355      -1
    f[14,86,8]  R413      1
    f[14,86,8]  marginal_15_8  1
    f[14,87,3]  R356      -1
    f[14,87,3]  R409      1
    f[14,87,3]  marginal_15_3  1
    f[14,87,8]  R356      -1
    f[14,87,8]  R414      1
    f[14,87,8]  marginal_15_8  1
    f[14,88,3]  R357      -1
    f[14,88,3]  R410      1
    f[14,88,3]  marginal_15_3  1
    f[14,88,8]  R357      -1
    f[14,88,8]  R415      1
    f[14,88,8]  marginal_15_8  1
    f[14,89,3]  R358      -1
    f[14,89,3]  R411      1
    f[14,89,3]  marginal_15_3  1
    f[14,89,8]  R358      -1
    f[14,89,8]  R416      1
    f[14,89,8]  marginal_15_8  1
    f[14,90,3]  R359      -1
    f[14,90,3]  R412      1
    f[14,90,3]  marginal_15_3  1
    f[14,90,8]  R359      -1
    f[14,90,8]  R417      1
    f[14,90,8]  marginal_15_8  1
    f[14,91,3]  R360      -1
    f[14,91,3]  R413      1
    f[14,91,3]  marginal_15_3  1
    f[14,91,8]  R360      -1
    f[14,91,8]  R418      1
    f[14,91,8]  marginal_15_8  1
    f[14,92,3]  R361      -1
    f[14,92,3]  R414      1
    f[14,92,3]  marginal_15_3  1
    f[14,92,8]  R361      -1
    f[14,92,8]  R419      1
    f[14,92,8]  marginal_15_8  1
    f[14,93,3]  R362      -1
    f[14,93,3]  R415      1
    f[14,93,3]  marginal_15_3  1
    f[14,93,8]  R362      -1
    f[14,93,8]  R420      1
    f[14,93,8]  marginal_15_8  1
    f[14,94,3]  R363      -1
    f[14,94,3]  R416      1
    f[14,94,3]  marginal_15_3  1
    f[14,94,8]  R363      -1
    f[14,94,8]  R421      1
    f[14,94,8]  marginal_15_8  1
    f[14,95,3]  R364      -1
    f[14,95,3]  R417      1
    f[14,95,3]  marginal_15_3  1
    f[14,95,8]  R364      -1
    f[14,95,8]  R422      1
    f[14,95,8]  marginal_15_8  1
    f[14,96,3]  R365      -1
    f[14,96,3]  R418      1
    f[14,96,3]  marginal_15_3  1
    f[14,96,8]  R365      -1
    f[14,96,8]  R423      1
    f[14,96,8]  marginal_15_8  1
    f[14,97,3]  R366      -1
    f[14,97,3]  R419      1
    f[14,97,3]  marginal_15_3  1
    f[14,97,8]  R366      -1
    f[14,97,8]  R424      1
    f[14,97,8]  marginal_15_8  1
    f[14,98,3]  R367      -1
    f[14,98,3]  R420      1
    f[14,98,3]  marginal_15_3  1
    f[14,98,8]  R367      -1
    f[14,98,8]  R425      1
    f[14,98,8]  marginal_15_8  1
    f[14,99,3]  R368      -1
    f[14,99,3]  R421      1
    f[14,99,3]  marginal_15_3  1
    f[14,99,8]  R368      -1
    f[14,99,8]  R426      1
    f[14,99,8]  marginal_15_8  1
    f[14,100,3]  R369      -1
    f[14,100,3]  R422      1
    f[14,100,3]  marginal_15_3  1
    f[14,100,8]  R369      -1
    f[14,100,8]  R427      1
    f[14,100,8]  marginal_15_8  1
    f[14,101,3]  R370      -1
    f[14,101,3]  R423      1
    f[14,101,3]  marginal_15_3  1
    f[14,101,8]  R370      -1
    f[14,101,8]  R428      1
    f[14,101,8]  marginal_15_8  1
    f[14,102,3]  R371      -1
    f[14,102,3]  R424      1
    f[14,102,3]  marginal_15_3  1
    f[14,102,8]  R371      -1
    f[14,102,8]  R429      1
    f[14,102,8]  marginal_15_8  1
    f[14,103,3]  R372      -1
    f[14,103,3]  R425      1
    f[14,103,3]  marginal_15_3  1
    f[14,103,8]  R372      -1
    f[14,103,8]  R430      1
    f[14,103,8]  marginal_15_8  1
    f[14,104,3]  R373      -1
    f[14,104,3]  R426      1
    f[14,104,3]  marginal_15_3  1
    f[14,104,8]  R373      -1
    f[14,104,8]  R431      1
    f[14,104,8]  marginal_15_8  1
    f[14,105,3]  R374      -1
    f[14,105,3]  R427      1
    f[14,105,3]  marginal_15_3  1
    f[14,105,8]  R374      -1
    f[14,105,8]  R432      1
    f[14,105,8]  marginal_15_8  1
    f[15,56,3]  R375      -1
    f[15,56,3]  R433      1
    f[15,56,3]  marginal_16_3  1
    f[15,56,6]  R375      -1
    f[15,56,6]  R436      1
    f[15,56,6]  marginal_16_6  1
    f[15,57,3]  R376      -1
    f[15,57,3]  R434      1
    f[15,57,3]  marginal_16_3  1
    f[15,57,6]  R376      -1
    f[15,57,6]  R437      1
    f[15,57,6]  marginal_16_6  1
    f[15,58,3]  R377      -1
    f[15,58,3]  R435      1
    f[15,58,3]  marginal_16_3  1
    f[15,58,6]  R377      -1
    f[15,58,6]  R438      1
    f[15,58,6]  marginal_16_6  1
    f[15,59,3]  R378      -1
    f[15,59,3]  R436      1
    f[15,59,3]  marginal_16_3  1
    f[15,59,6]  R378      -1
    f[15,59,6]  R439      1
    f[15,59,6]  marginal_16_6  1
    f[15,60,3]  R379      -1
    f[15,60,3]  R437      1
    f[15,60,3]  marginal_16_3  1
    f[15,60,6]  R379      -1
    f[15,60,6]  R440      1
    f[15,60,6]  marginal_16_6  1
    f[15,61,3]  R380      -1
    f[15,61,3]  R438      1
    f[15,61,3]  marginal_16_3  1
    f[15,61,6]  R380      -1
    f[15,61,6]  R441      1
    f[15,61,6]  marginal_16_6  1
    f[15,62,3]  R381      -1
    f[15,62,3]  R439      1
    f[15,62,3]  marginal_16_3  1
    f[15,62,6]  R381      -1
    f[15,62,6]  R442      1
    f[15,62,6]  marginal_16_6  1
    f[15,63,3]  R382      -1
    f[15,63,3]  R440      1
    f[15,63,3]  marginal_16_3  1
    f[15,63,6]  R382      -1
    f[15,63,6]  R443      1
    f[15,63,6]  marginal_16_6  1
    f[15,64,3]  R383      -1
    f[15,64,3]  R441      1
    f[15,64,3]  marginal_16_3  1
    f[15,64,6]  R383      -1
    f[15,64,6]  R444      1
    f[15,64,6]  marginal_16_6  1
    f[15,65,3]  R384      -1
    f[15,65,3]  R442      1
    f[15,65,3]  marginal_16_3  1
    f[15,65,6]  R384      -1
    f[15,65,6]  R445      1
    f[15,65,6]  marginal_16_6  1
    f[15,66,3]  R385      -1
    f[15,66,3]  R443      1
    f[15,66,3]  marginal_16_3  1
    f[15,66,6]  R385      -1
    f[15,66,6]  R446      1
    f[15,66,6]  marginal_16_6  1
    f[15,67,3]  R386      -1
    f[15,67,3]  R444      1
    f[15,67,3]  marginal_16_3  1
    f[15,67,6]  R386      -1
    f[15,67,6]  R447      1
    f[15,67,6]  marginal_16_6  1
    f[15,68,3]  R387      -1
    f[15,68,3]  R445      1
    f[15,68,3]  marginal_16_3  1
    f[15,68,6]  R387      -1
    f[15,68,6]  R448      1
    f[15,68,6]  marginal_16_6  1
    f[15,69,3]  R388      -1
    f[15,69,3]  R446      1
    f[15,69,3]  marginal_16_3  1
    f[15,69,6]  R388      -1
    f[15,69,6]  R449      1
    f[15,69,6]  marginal_16_6  1
    f[15,70,3]  R389      -1
    f[15,70,3]  R447      1
    f[15,70,3]  marginal_16_3  1
    f[15,70,6]  R389      -1
    f[15,70,6]  R450      1
    f[15,70,6]  marginal_16_6  1
    f[15,71,3]  R390      -1
    f[15,71,3]  R448      1
    f[15,71,3]  marginal_16_3  1
    f[15,71,6]  R390      -1
    f[15,71,6]  R451      1
    f[15,71,6]  marginal_16_6  1
    f[15,72,3]  R391      -1
    f[15,72,3]  R449      1
    f[15,72,3]  marginal_16_3  1
    f[15,72,6]  R391      -1
    f[15,72,6]  R452      1
    f[15,72,6]  marginal_16_6  1
    f[15,73,3]  R392      -1
    f[15,73,3]  R450      1
    f[15,73,3]  marginal_16_3  1
    f[15,73,6]  R392      -1
    f[15,73,6]  R453      1
    f[15,73,6]  marginal_16_6  1
    f[15,74,3]  R393      -1
    f[15,74,3]  R451      1
    f[15,74,3]  marginal_16_3  1
    f[15,74,6]  R393      -1
    f[15,74,6]  R454      1
    f[15,74,6]  marginal_16_6  1
    f[15,75,3]  R394      -1
    f[15,75,3]  R452      1
    f[15,75,3]  marginal_16_3  1
    f[15,75,6]  R394      -1
    f[15,75,6]  R455      1
    f[15,75,6]  marginal_16_6  1
    f[15,76,3]  R395      -1
    f[15,76,3]  R453      1
    f[15,76,3]  marginal_16_3  1
    f[15,76,6]  R395      -1
    f[15,76,6]  R456      1
    f[15,76,6]  marginal_16_6  1
    f[15,77,3]  R396      -1
    f[15,77,3]  R454      1
    f[15,77,3]  marginal_16_3  1
    f[15,77,6]  R396      -1
    f[15,77,6]  R457      1
    f[15,77,6]  marginal_16_6  1
    f[15,78,3]  R397      -1
    f[15,78,3]  R455      1
    f[15,78,3]  marginal_16_3  1
    f[15,78,6]  R397      -1
    f[15,78,6]  R458      1
    f[15,78,6]  marginal_16_6  1
    f[15,79,3]  R398      -1
    f[15,79,3]  R456      1
    f[15,79,3]  marginal_16_3  1
    f[15,79,6]  R398      -1
    f[15,79,6]  R459      1
    f[15,79,6]  marginal_16_6  1
    f[15,80,3]  R399      -1
    f[15,80,3]  R457      1
    f[15,80,3]  marginal_16_3  1
    f[15,80,6]  R399      -1
    f[15,80,6]  R460      1
    f[15,80,6]  marginal_16_6  1
    f[15,81,3]  R400      -1
    f[15,81,3]  R458      1
    f[15,81,3]  marginal_16_3  1
    f[15,81,6]  R400      -1
    f[15,81,6]  R461      1
    f[15,81,6]  marginal_16_6  1
    f[15,82,3]  R401      -1
    f[15,82,3]  R459      1
    f[15,82,3]  marginal_16_3  1
    f[15,82,6]  R401      -1
    f[15,82,6]  R462      1
    f[15,82,6]  marginal_16_6  1
    f[15,83,3]  R402      -1
    f[15,83,3]  R460      1
    f[15,83,3]  marginal_16_3  1
    f[15,83,6]  R402      -1
    f[15,83,6]  R463      1
    f[15,83,6]  marginal_16_6  1
    f[15,84,3]  R403      -1
    f[15,84,3]  R461      1
    f[15,84,3]  marginal_16_3  1
    f[15,84,6]  R403      -1
    f[15,84,6]  R464      1
    f[15,84,6]  marginal_16_6  1
    f[15,85,3]  R404      -1
    f[15,85,3]  R462      1
    f[15,85,3]  marginal_16_3  1
    f[15,85,6]  R404      -1
    f[15,85,6]  R465      1
    f[15,85,6]  marginal_16_6  1
    f[15,86,3]  R405      -1
    f[15,86,3]  R463      1
    f[15,86,3]  marginal_16_3  1
    f[15,86,6]  R405      -1
    f[15,86,6]  R466      1
    f[15,86,6]  marginal_16_6  1
    f[15,87,3]  R406      -1
    f[15,87,3]  R464      1
    f[15,87,3]  marginal_16_3  1
    f[15,87,6]  R406      -1
    f[15,87,6]  R467      1
    f[15,87,6]  marginal_16_6  1
    f[15,88,3]  R407      -1
    f[15,88,3]  R465      1
    f[15,88,3]  marginal_16_3  1
    f[15,88,6]  R407      -1
    f[15,88,6]  R468      1
    f[15,88,6]  marginal_16_6  1
    f[15,89,3]  R408      -1
    f[15,89,3]  R466      1
    f[15,89,3]  marginal_16_3  1
    f[15,89,6]  R408      -1
    f[15,89,6]  R469      1
    f[15,89,6]  marginal_16_6  1
    f[15,90,3]  R409      -1
    f[15,90,3]  R467      1
    f[15,90,3]  marginal_16_3  1
    f[15,90,6]  R409      -1
    f[15,90,6]  R470      1
    f[15,90,6]  marginal_16_6  1
    f[15,91,3]  R410      -1
    f[15,91,3]  R468      1
    f[15,91,3]  marginal_16_3  1
    f[15,91,6]  R410      -1
    f[15,91,6]  R471      1
    f[15,91,6]  marginal_16_6  1
    f[15,92,3]  R411      -1
    f[15,92,3]  R469      1
    f[15,92,3]  marginal_16_3  1
    f[15,92,6]  R411      -1
    f[15,92,6]  R472      1
    f[15,92,6]  marginal_16_6  1
    f[15,93,3]  R412      -1
    f[15,93,3]  R470      1
    f[15,93,3]  marginal_16_3  1
    f[15,93,6]  R412      -1
    f[15,93,6]  R473      1
    f[15,93,6]  marginal_16_6  1
    f[15,94,3]  R413      -1
    f[15,94,3]  R471      1
    f[15,94,3]  marginal_16_3  1
    f[15,94,6]  R413      -1
    f[15,94,6]  R474      1
    f[15,94,6]  marginal_16_6  1
    f[15,95,3]  R414      -1
    f[15,95,3]  R472      1
    f[15,95,3]  marginal_16_3  1
    f[15,95,6]  R414      -1
    f[15,95,6]  R475      1
    f[15,95,6]  marginal_16_6  1
    f[15,96,3]  R415      -1
    f[15,96,3]  R473      1
    f[15,96,3]  marginal_16_3  1
    f[15,96,6]  R415      -1
    f[15,96,6]  R476      1
    f[15,96,6]  marginal_16_6  1
    f[15,97,3]  R416      -1
    f[15,97,3]  R474      1
    f[15,97,3]  marginal_16_3  1
    f[15,97,6]  R416      -1
    f[15,97,6]  R477      1
    f[15,97,6]  marginal_16_6  1
    f[15,98,3]  R417      -1
    f[15,98,3]  R475      1
    f[15,98,3]  marginal_16_3  1
    f[15,98,6]  R417      -1
    f[15,98,6]  R478      1
    f[15,98,6]  marginal_16_6  1
    f[15,99,3]  R418      -1
    f[15,99,3]  R476      1
    f[15,99,3]  marginal_16_3  1
    f[15,99,6]  R418      -1
    f[15,99,6]  R479      1
    f[15,99,6]  marginal_16_6  1
    f[15,100,3]  R419      -1
    f[15,100,3]  R477      1
    f[15,100,3]  marginal_16_3  1
    f[15,100,6]  R419      -1
    f[15,100,6]  R480      1
    f[15,100,6]  marginal_16_6  1
    f[15,101,3]  R420      -1
    f[15,101,3]  R478      1
    f[15,101,3]  marginal_16_3  1
    f[15,101,6]  R420      -1
    f[15,101,6]  R481      1
    f[15,101,6]  marginal_16_6  1
    f[15,102,3]  R421      -1
    f[15,102,3]  R479      1
    f[15,102,3]  marginal_16_3  1
    f[15,102,6]  R421      -1
    f[15,102,6]  R482      1
    f[15,102,6]  marginal_16_6  1
    f[15,103,3]  R422      -1
    f[15,103,3]  R480      1
    f[15,103,3]  marginal_16_3  1
    f[15,103,6]  R422      -1
    f[15,103,6]  R483      1
    f[15,103,6]  marginal_16_6  1
    f[15,104,3]  R423      -1
    f[15,104,3]  R481      1
    f[15,104,3]  marginal_16_3  1
    f[15,104,6]  R423      -1
    f[15,104,6]  R484      1
    f[15,104,6]  marginal_16_6  1
    f[15,105,3]  R424      -1
    f[15,105,3]  R482      1
    f[15,105,3]  marginal_16_3  1
    f[15,105,6]  R424      -1
    f[15,105,6]  R485      1
    f[15,105,6]  marginal_16_6  1
    f[15,106,3]  R425      -1
    f[15,106,3]  R483      1
    f[15,106,3]  marginal_16_3  1
    f[15,106,6]  R425      -1
    f[15,106,6]  R486      1
    f[15,106,6]  marginal_16_6  1
    f[15,107,3]  R426      -1
    f[15,107,3]  R484      1
    f[15,107,3]  marginal_16_3  1
    f[15,107,6]  R426      -1
    f[15,107,6]  R487      1
    f[15,107,6]  marginal_16_6  1
    f[15,108,3]  R427      -1
    f[15,108,3]  R485      1
    f[15,108,3]  marginal_16_3  1
    f[15,108,6]  R427      -1
    f[15,108,6]  R488      1
    f[15,108,6]  marginal_16_6  1
    f[15,109,3]  R428      -1
    f[15,109,3]  R486      1
    f[15,109,3]  marginal_16_3  1
    f[15,109,6]  R428      -1
    f[15,109,6]  R489      1
    f[15,109,6]  marginal_16_6  1
    f[15,110,3]  R429      -1
    f[15,110,3]  R487      1
    f[15,110,3]  marginal_16_3  1
    f[15,110,6]  R429      -1
    f[15,110,6]  R490      1
    f[15,110,6]  marginal_16_6  1
    f[15,111,3]  R430      -1
    f[15,111,3]  R488      1
    f[15,111,3]  marginal_16_3  1
    f[15,111,6]  R430      -1
    f[15,111,6]  R491      1
    f[15,111,6]  marginal_16_6  1
    f[15,112,3]  R431      -1
    f[15,112,3]  R489      1
    f[15,112,3]  marginal_16_3  1
    f[15,112,6]  R431      -1
    f[15,112,6]  R492      1
    f[15,112,6]  marginal_16_6  1
    f[15,113,3]  R432      -1
    f[15,113,3]  R490      1
    f[15,113,3]  marginal_16_3  1
    f[15,113,6]  R432      -1
    f[15,113,6]  R493      1
    f[15,113,6]  marginal_16_6  1
    f[16,59,7]  R433      -1
    f[16,59,7]  R495      1
    f[16,59,7]  marginal_17_7  1
    f[16,59,9]  R433      -1
    f[16,59,9]  R497      1
    f[16,59,9]  marginal_17_9  1
    f[16,60,7]  R434      -1
    f[16,60,7]  R496      1
    f[16,60,7]  marginal_17_7  1
    f[16,60,9]  R434      -1
    f[16,60,9]  R498      1
    f[16,60,9]  marginal_17_9  1
    f[16,61,7]  R435      -1
    f[16,61,7]  R497      1
    f[16,61,7]  marginal_17_7  1
    f[16,61,9]  R435      -1
    f[16,61,9]  R499      1
    f[16,61,9]  marginal_17_9  1
    f[16,62,7]  R436      -1
    f[16,62,7]  R498      1
    f[16,62,7]  marginal_17_7  1
    f[16,62,9]  R436      -1
    f[16,62,9]  R500      1
    f[16,62,9]  marginal_17_9  1
    f[16,63,7]  R437      -1
    f[16,63,7]  R499      1
    f[16,63,7]  marginal_17_7  1
    f[16,63,9]  R437      -1
    f[16,63,9]  R501      1
    f[16,63,9]  marginal_17_9  1
    f[16,64,7]  R438      -1
    f[16,64,7]  R500      1
    f[16,64,7]  marginal_17_7  1
    f[16,64,9]  R438      -1
    f[16,64,9]  R502      1
    f[16,64,9]  marginal_17_9  1
    f[16,65,7]  R439      -1
    f[16,65,7]  R501      1
    f[16,65,7]  marginal_17_7  1
    f[16,65,9]  R439      -1
    f[16,65,9]  R503      1
    f[16,65,9]  marginal_17_9  1
    f[16,66,7]  R440      -1
    f[16,66,7]  R502      1
    f[16,66,7]  marginal_17_7  1
    f[16,66,9]  R440      -1
    f[16,66,9]  R504      1
    f[16,66,9]  marginal_17_9  1
    f[16,67,7]  R441      -1
    f[16,67,7]  R503      1
    f[16,67,7]  marginal_17_7  1
    f[16,67,9]  R441      -1
    f[16,67,9]  R505      1
    f[16,67,9]  marginal_17_9  1
    f[16,68,7]  R442      -1
    f[16,68,7]  R504      1
    f[16,68,7]  marginal_17_7  1
    f[16,68,9]  R442      -1
    f[16,68,9]  R506      1
    f[16,68,9]  marginal_17_9  1
    f[16,69,7]  R443      -1
    f[16,69,7]  R505      1
    f[16,69,7]  marginal_17_7  1
    f[16,69,9]  R443      -1
    f[16,69,9]  R507      1
    f[16,69,9]  marginal_17_9  1
    f[16,70,7]  R444      -1
    f[16,70,7]  R506      1
    f[16,70,7]  marginal_17_7  1
    f[16,70,9]  R444      -1
    f[16,70,9]  R508      1
    f[16,70,9]  marginal_17_9  1
    f[16,71,7]  R445      -1
    f[16,71,7]  R507      1
    f[16,71,7]  marginal_17_7  1
    f[16,71,9]  R445      -1
    f[16,71,9]  R509      1
    f[16,71,9]  marginal_17_9  1
    f[16,72,7]  R446      -1
    f[16,72,7]  R508      1
    f[16,72,7]  marginal_17_7  1
    f[16,72,9]  R446      -1
    f[16,72,9]  R510      1
    f[16,72,9]  marginal_17_9  1
    f[16,73,7]  R447      -1
    f[16,73,7]  R509      1
    f[16,73,7]  marginal_17_7  1
    f[16,73,9]  R447      -1
    f[16,73,9]  R511      1
    f[16,73,9]  marginal_17_9  1
    f[16,74,7]  R448      -1
    f[16,74,7]  R510      1
    f[16,74,7]  marginal_17_7  1
    f[16,74,9]  R448      -1
    f[16,74,9]  R512      1
    f[16,74,9]  marginal_17_9  1
    f[16,75,7]  R449      -1
    f[16,75,7]  R511      1
    f[16,75,7]  marginal_17_7  1
    f[16,75,9]  R449      -1
    f[16,75,9]  R513      1
    f[16,75,9]  marginal_17_9  1
    f[16,76,7]  R450      -1
    f[16,76,7]  R512      1
    f[16,76,7]  marginal_17_7  1
    f[16,76,9]  R450      -1
    f[16,76,9]  R514      1
    f[16,76,9]  marginal_17_9  1
    f[16,77,7]  R451      -1
    f[16,77,7]  R513      1
    f[16,77,7]  marginal_17_7  1
    f[16,77,9]  R451      -1
    f[16,77,9]  R515      1
    f[16,77,9]  marginal_17_9  1
    f[16,78,7]  R452      -1
    f[16,78,7]  R514      1
    f[16,78,7]  marginal_17_7  1
    f[16,78,9]  R452      -1
    f[16,78,9]  R516      1
    f[16,78,9]  marginal_17_9  1
    f[16,79,7]  R453      -1
    f[16,79,7]  R515      1
    f[16,79,7]  marginal_17_7  1
    f[16,79,9]  R453      -1
    f[16,79,9]  R517      1
    f[16,79,9]  marginal_17_9  1
    f[16,80,7]  R454      -1
    f[16,80,7]  R516      1
    f[16,80,7]  marginal_17_7  1
    f[16,80,9]  R454      -1
    f[16,80,9]  R518      1
    f[16,80,9]  marginal_17_9  1
    f[16,81,7]  R455      -1
    f[16,81,7]  R517      1
    f[16,81,7]  marginal_17_7  1
    f[16,81,9]  R455      -1
    f[16,81,9]  R519      1
    f[16,81,9]  marginal_17_9  1
    f[16,82,7]  R456      -1
    f[16,82,7]  R518      1
    f[16,82,7]  marginal_17_7  1
    f[16,82,9]  R456      -1
    f[16,82,9]  R520      1
    f[16,82,9]  marginal_17_9  1
    f[16,83,7]  R457      -1
    f[16,83,7]  R519      1
    f[16,83,7]  marginal_17_7  1
    f[16,83,9]  R457      -1
    f[16,83,9]  R521      1
    f[16,83,9]  marginal_17_9  1
    f[16,84,7]  R458      -1
    f[16,84,7]  R520      1
    f[16,84,7]  marginal_17_7  1
    f[16,84,9]  R458      -1
    f[16,84,9]  R522      1
    f[16,84,9]  marginal_17_9  1
    f[16,85,7]  R459      -1
    f[16,85,7]  R521      1
    f[16,85,7]  marginal_17_7  1
    f[16,85,9]  R459      -1
    f[16,85,9]  R523      1
    f[16,85,9]  marginal_17_9  1
    f[16,86,7]  R460      -1
    f[16,86,7]  R522      1
    f[16,86,7]  marginal_17_7  1
    f[16,86,9]  R460      -1
    f[16,86,9]  R524      1
    f[16,86,9]  marginal_17_9  1
    f[16,87,7]  R461      -1
    f[16,87,7]  R523      1
    f[16,87,7]  marginal_17_7  1
    f[16,87,9]  R461      -1
    f[16,87,9]  R525      1
    f[16,87,9]  marginal_17_9  1
    f[16,88,7]  R462      -1
    f[16,88,7]  R524      1
    f[16,88,7]  marginal_17_7  1
    f[16,88,9]  R462      -1
    f[16,88,9]  R526      1
    f[16,88,9]  marginal_17_9  1
    f[16,89,7]  R463      -1
    f[16,89,7]  R525      1
    f[16,89,7]  marginal_17_7  1
    f[16,89,9]  R463      -1
    f[16,89,9]  R527      1
    f[16,89,9]  marginal_17_9  1
    f[16,90,7]  R464      -1
    f[16,90,7]  R526      1
    f[16,90,7]  marginal_17_7  1
    f[16,90,9]  R464      -1
    f[16,90,9]  R528      1
    f[16,90,9]  marginal_17_9  1
    f[16,91,7]  R465      -1
    f[16,91,7]  R527      1
    f[16,91,7]  marginal_17_7  1
    f[16,91,9]  R465      -1
    f[16,91,9]  R529      1
    f[16,91,9]  marginal_17_9  1
    f[16,92,7]  R466      -1
    f[16,92,7]  R528      1
    f[16,92,7]  marginal_17_7  1
    f[16,92,9]  R466      -1
    f[16,92,9]  R530      1
    f[16,92,9]  marginal_17_9  1
    f[16,93,7]  R467      -1
    f[16,93,7]  R529      1
    f[16,93,7]  marginal_17_7  1
    f[16,93,9]  R467      -1
    f[16,93,9]  R531      1
    f[16,93,9]  marginal_17_9  1
    f[16,94,7]  R468      -1
    f[16,94,7]  R530      1
    f[16,94,7]  marginal_17_7  1
    f[16,94,9]  R468      -1
    f[16,94,9]  R532      1
    f[16,94,9]  marginal_17_9  1
    f[16,95,7]  R469      -1
    f[16,95,7]  R531      1
    f[16,95,7]  marginal_17_7  1
    f[16,95,9]  R469      -1
    f[16,95,9]  R533      1
    f[16,95,9]  marginal_17_9  1
    f[16,96,7]  R470      -1
    f[16,96,7]  R532      1
    f[16,96,7]  marginal_17_7  1
    f[16,96,9]  R470      -1
    f[16,96,9]  R534      1
    f[16,96,9]  marginal_17_9  1
    f[16,97,7]  R471      -1
    f[16,97,7]  R533      1
    f[16,97,7]  marginal_17_7  1
    f[16,97,9]  R471      -1
    f[16,97,9]  R535      1
    f[16,97,9]  marginal_17_9  1
    f[16,98,7]  R472      -1
    f[16,98,7]  R534      1
    f[16,98,7]  marginal_17_7  1
    f[16,98,9]  R472      -1
    f[16,98,9]  R536      1
    f[16,98,9]  marginal_17_9  1
    f[16,99,7]  R473      -1
    f[16,99,7]  R535      1
    f[16,99,7]  marginal_17_7  1
    f[16,99,9]  R473      -1
    f[16,99,9]  R537      1
    f[16,99,9]  marginal_17_9  1
    f[16,100,7]  R474      -1
    f[16,100,7]  R536      1
    f[16,100,7]  marginal_17_7  1
    f[16,100,9]  R474      -1
    f[16,100,9]  R538      1
    f[16,100,9]  marginal_17_9  1
    f[16,101,7]  R475      -1
    f[16,101,7]  R537      1
    f[16,101,7]  marginal_17_7  1
    f[16,101,9]  R475      -1
    f[16,101,9]  R539      1
    f[16,101,9]  marginal_17_9  1
    f[16,102,7]  R476      -1
    f[16,102,7]  R538      1
    f[16,102,7]  marginal_17_7  1
    f[16,102,9]  R476      -1
    f[16,102,9]  R540      1
    f[16,102,9]  marginal_17_9  1
    f[16,103,7]  R477      -1
    f[16,103,7]  R539      1
    f[16,103,7]  marginal_17_7  1
    f[16,103,9]  R477      -1
    f[16,103,9]  R541      1
    f[16,103,9]  marginal_17_9  1
    f[16,104,7]  R478      -1
    f[16,104,7]  R540      1
    f[16,104,7]  marginal_17_7  1
    f[16,104,9]  R478      -1
    f[16,104,9]  R542      1
    f[16,104,9]  marginal_17_9  1
    f[16,105,7]  R479      -1
    f[16,105,7]  R541      1
    f[16,105,7]  marginal_17_7  1
    f[16,105,9]  R479      -1
    f[16,105,9]  R543      1
    f[16,105,9]  marginal_17_9  1
    f[16,106,7]  R480      -1
    f[16,106,7]  R542      1
    f[16,106,7]  marginal_17_7  1
    f[16,106,9]  R480      -1
    f[16,106,9]  R544      1
    f[16,106,9]  marginal_17_9  1
    f[16,107,7]  R481      -1
    f[16,107,7]  R543      1
    f[16,107,7]  marginal_17_7  1
    f[16,107,9]  R481      -1
    f[16,107,9]  R545      1
    f[16,107,9]  marginal_17_9  1
    f[16,108,7]  R482      -1
    f[16,108,7]  R544      1
    f[16,108,7]  marginal_17_7  1
    f[16,108,9]  R482      -1
    f[16,108,9]  R546      1
    f[16,108,9]  marginal_17_9  1
    f[16,109,7]  R483      -1
    f[16,109,7]  R545      1
    f[16,109,7]  marginal_17_7  1
    f[16,109,9]  R483      -1
    f[16,109,9]  R547      1
    f[16,109,9]  marginal_17_9  1
    f[16,110,7]  R484      -1
    f[16,110,7]  R546      1
    f[16,110,7]  marginal_17_7  1
    f[16,110,9]  R484      -1
    f[16,110,9]  R548      1
    f[16,110,9]  marginal_17_9  1
    f[16,111,7]  R485      -1
    f[16,111,7]  R547      1
    f[16,111,7]  marginal_17_7  1
    f[16,111,9]  R485      -1
    f[16,111,9]  R549      1
    f[16,111,9]  marginal_17_9  1
    f[16,112,7]  R486      -1
    f[16,112,7]  R548      1
    f[16,112,7]  marginal_17_7  1
    f[16,112,9]  R486      -1
    f[16,112,9]  R550      1
    f[16,112,9]  marginal_17_9  1
    f[16,113,7]  R487      -1
    f[16,113,7]  R549      1
    f[16,113,7]  marginal_17_7  1
    f[16,113,9]  R487      -1
    f[16,113,9]  R551      1
    f[16,113,9]  marginal_17_9  1
    f[16,114,7]  R488      -1
    f[16,114,7]  R550      1
    f[16,114,7]  marginal_17_7  1
    f[16,114,9]  R488      -1
    f[16,114,9]  R552      1
    f[16,114,9]  marginal_17_9  1
    f[16,115,7]  R489      -1
    f[16,115,7]  R551      1
    f[16,115,7]  marginal_17_7  1
    f[16,115,9]  R489      -1
    f[16,115,9]  R553      1
    f[16,115,9]  marginal_17_9  1
    f[16,116,7]  R490      -1
    f[16,116,7]  R552      1
    f[16,116,7]  marginal_17_7  1
    f[16,116,9]  R490      -1
    f[16,116,9]  R554      1
    f[16,116,9]  marginal_17_9  1
    f[16,117,7]  R491      -1
    f[16,117,7]  R553      1
    f[16,117,7]  marginal_17_7  1
    f[16,117,9]  R491      -1
    f[16,117,9]  R555      1
    f[16,117,9]  marginal_17_9  1
    f[16,118,7]  R492      -1
    f[16,118,7]  R554      1
    f[16,118,7]  marginal_17_7  1
    f[16,118,9]  R492      -1
    f[16,118,9]  R556      1
    f[16,118,9]  marginal_17_9  1
    f[16,119,7]  R493      -1
    f[16,119,7]  R555      1
    f[16,119,7]  marginal_17_7  1
    f[16,119,9]  R493      -1
    f[16,119,9]  R494      1
    f[16,119,9]  marginal_17_9  1
    f[17,66,5]  R495      -1
    f[17,66,5]  R567      1
    f[17,66,5]  marginal_18_5  1
    f[17,66,6]  R495      -1
    f[17,66,6]  R568      1
    f[17,66,6]  marginal_18_6  1
    f[17,66,9]  R495      -1
    f[17,66,9]  R571      1
    f[17,66,9]  marginal_18_9  1
    f[17,67,5]  R496      -1
    f[17,67,5]  R568      1
    f[17,67,5]  marginal_18_5  1
    f[17,67,6]  R496      -1
    f[17,67,6]  R569      1
    f[17,67,6]  marginal_18_6  1
    f[17,67,9]  R496      -1
    f[17,67,9]  R572      1
    f[17,67,9]  marginal_18_9  1
    f[17,68,5]  R497      -1
    f[17,68,5]  R569      1
    f[17,68,5]  marginal_18_5  1
    f[17,68,6]  R497      -1
    f[17,68,6]  R570      1
    f[17,68,6]  marginal_18_6  1
    f[17,68,9]  R497      -1
    f[17,68,9]  R573      1
    f[17,68,9]  marginal_18_9  1
    f[17,69,5]  R498      -1
    f[17,69,5]  R570      1
    f[17,69,5]  marginal_18_5  1
    f[17,69,6]  R498      -1
    f[17,69,6]  R571      1
    f[17,69,6]  marginal_18_6  1
    f[17,69,9]  R498      -1
    f[17,69,9]  R574      1
    f[17,69,9]  marginal_18_9  1
    f[17,70,5]  R499      -1
    f[17,70,5]  R571      1
    f[17,70,5]  marginal_18_5  1
    f[17,70,6]  R499      -1
    f[17,70,6]  R572      1
    f[17,70,6]  marginal_18_6  1
    f[17,70,9]  R499      -1
    f[17,70,9]  R575      1
    f[17,70,9]  marginal_18_9  1
    f[17,71,5]  R500      -1
    f[17,71,5]  R572      1
    f[17,71,5]  marginal_18_5  1
    f[17,71,6]  R500      -1
    f[17,71,6]  R573      1
    f[17,71,6]  marginal_18_6  1
    f[17,71,9]  R500      -1
    f[17,71,9]  R576      1
    f[17,71,9]  marginal_18_9  1
    f[17,72,5]  R501      -1
    f[17,72,5]  R573      1
    f[17,72,5]  marginal_18_5  1
    f[17,72,6]  R501      -1
    f[17,72,6]  R574      1
    f[17,72,6]  marginal_18_6  1
    f[17,72,9]  R501      -1
    f[17,72,9]  R577      1
    f[17,72,9]  marginal_18_9  1
    f[17,73,5]  R502      -1
    f[17,73,5]  R574      1
    f[17,73,5]  marginal_18_5  1
    f[17,73,6]  R502      -1
    f[17,73,6]  R575      1
    f[17,73,6]  marginal_18_6  1
    f[17,73,9]  R502      -1
    f[17,73,9]  R578      1
    f[17,73,9]  marginal_18_9  1
    f[17,74,5]  R503      -1
    f[17,74,5]  R575      1
    f[17,74,5]  marginal_18_5  1
    f[17,74,6]  R503      -1
    f[17,74,6]  R576      1
    f[17,74,6]  marginal_18_6  1
    f[17,74,9]  R503      -1
    f[17,74,9]  R579      1
    f[17,74,9]  marginal_18_9  1
    f[17,75,5]  R504      -1
    f[17,75,5]  R576      1
    f[17,75,5]  marginal_18_5  1
    f[17,75,6]  R504      -1
    f[17,75,6]  R577      1
    f[17,75,6]  marginal_18_6  1
    f[17,75,9]  R504      -1
    f[17,75,9]  R580      1
    f[17,75,9]  marginal_18_9  1
    f[17,76,5]  R505      -1
    f[17,76,5]  R577      1
    f[17,76,5]  marginal_18_5  1
    f[17,76,6]  R505      -1
    f[17,76,6]  R578      1
    f[17,76,6]  marginal_18_6  1
    f[17,76,9]  R505      -1
    f[17,76,9]  R581      1
    f[17,76,9]  marginal_18_9  1
    f[17,77,5]  R506      -1
    f[17,77,5]  R578      1
    f[17,77,5]  marginal_18_5  1
    f[17,77,6]  R506      -1
    f[17,77,6]  R579      1
    f[17,77,6]  marginal_18_6  1
    f[17,77,9]  R506      -1
    f[17,77,9]  R582      1
    f[17,77,9]  marginal_18_9  1
    f[17,78,5]  R507      -1
    f[17,78,5]  R579      1
    f[17,78,5]  marginal_18_5  1
    f[17,78,6]  R507      -1
    f[17,78,6]  R580      1
    f[17,78,6]  marginal_18_6  1
    f[17,78,9]  R507      -1
    f[17,78,9]  R583      1
    f[17,78,9]  marginal_18_9  1
    f[17,79,5]  R508      -1
    f[17,79,5]  R580      1
    f[17,79,5]  marginal_18_5  1
    f[17,79,6]  R508      -1
    f[17,79,6]  R581      1
    f[17,79,6]  marginal_18_6  1
    f[17,79,9]  R508      -1
    f[17,79,9]  R584      1
    f[17,79,9]  marginal_18_9  1
    f[17,80,5]  R509      -1
    f[17,80,5]  R581      1
    f[17,80,5]  marginal_18_5  1
    f[17,80,6]  R509      -1
    f[17,80,6]  R582      1
    f[17,80,6]  marginal_18_6  1
    f[17,80,9]  R509      -1
    f[17,80,9]  R585      1
    f[17,80,9]  marginal_18_9  1
    f[17,81,5]  R510      -1
    f[17,81,5]  R582      1
    f[17,81,5]  marginal_18_5  1
    f[17,81,6]  R510      -1
    f[17,81,6]  R583      1
    f[17,81,6]  marginal_18_6  1
    f[17,81,9]  R510      -1
    f[17,81,9]  R586      1
    f[17,81,9]  marginal_18_9  1
    f[17,82,5]  R511      -1
    f[17,82,5]  R583      1
    f[17,82,5]  marginal_18_5  1
    f[17,82,6]  R511      -1
    f[17,82,6]  R584      1
    f[17,82,6]  marginal_18_6  1
    f[17,82,9]  R511      -1
    f[17,82,9]  R587      1
    f[17,82,9]  marginal_18_9  1
    f[17,83,5]  R512      -1
    f[17,83,5]  R584      1
    f[17,83,5]  marginal_18_5  1
    f[17,83,6]  R512      -1
    f[17,83,6]  R585      1
    f[17,83,6]  marginal_18_6  1
    f[17,83,9]  R512      -1
    f[17,83,9]  R588      1
    f[17,83,9]  marginal_18_9  1
    f[17,84,5]  R513      -1
    f[17,84,5]  R585      1
    f[17,84,5]  marginal_18_5  1
    f[17,84,6]  R513      -1
    f[17,84,6]  R586      1
    f[17,84,6]  marginal_18_6  1
    f[17,84,9]  R513      -1
    f[17,84,9]  R589      1
    f[17,84,9]  marginal_18_9  1
    f[17,85,5]  R514      -1
    f[17,85,5]  R586      1
    f[17,85,5]  marginal_18_5  1
    f[17,85,6]  R514      -1
    f[17,85,6]  R587      1
    f[17,85,6]  marginal_18_6  1
    f[17,85,9]  R514      -1
    f[17,85,9]  R590      1
    f[17,85,9]  marginal_18_9  1
    f[17,86,5]  R515      -1
    f[17,86,5]  R587      1
    f[17,86,5]  marginal_18_5  1
    f[17,86,6]  R515      -1
    f[17,86,6]  R588      1
    f[17,86,6]  marginal_18_6  1
    f[17,86,9]  R515      -1
    f[17,86,9]  R591      1
    f[17,86,9]  marginal_18_9  1
    f[17,87,5]  R516      -1
    f[17,87,5]  R588      1
    f[17,87,5]  marginal_18_5  1
    f[17,87,6]  R516      -1
    f[17,87,6]  R589      1
    f[17,87,6]  marginal_18_6  1
    f[17,87,9]  R516      -1
    f[17,87,9]  R592      1
    f[17,87,9]  marginal_18_9  1
    f[17,88,5]  R517      -1
    f[17,88,5]  R589      1
    f[17,88,5]  marginal_18_5  1
    f[17,88,6]  R517      -1
    f[17,88,6]  R590      1
    f[17,88,6]  marginal_18_6  1
    f[17,88,9]  R517      -1
    f[17,88,9]  R593      1
    f[17,88,9]  marginal_18_9  1
    f[17,89,5]  R518      -1
    f[17,89,5]  R590      1
    f[17,89,5]  marginal_18_5  1
    f[17,89,6]  R518      -1
    f[17,89,6]  R591      1
    f[17,89,6]  marginal_18_6  1
    f[17,89,9]  R518      -1
    f[17,89,9]  R594      1
    f[17,89,9]  marginal_18_9  1
    f[17,90,5]  R519      -1
    f[17,90,5]  R591      1
    f[17,90,5]  marginal_18_5  1
    f[17,90,6]  R519      -1
    f[17,90,6]  R592      1
    f[17,90,6]  marginal_18_6  1
    f[17,90,9]  R519      -1
    f[17,90,9]  R595      1
    f[17,90,9]  marginal_18_9  1
    f[17,91,5]  R520      -1
    f[17,91,5]  R592      1
    f[17,91,5]  marginal_18_5  1
    f[17,91,6]  R520      -1
    f[17,91,6]  R593      1
    f[17,91,6]  marginal_18_6  1
    f[17,91,9]  R520      -1
    f[17,91,9]  R596      1
    f[17,91,9]  marginal_18_9  1
    f[17,92,5]  R521      -1
    f[17,92,5]  R593      1
    f[17,92,5]  marginal_18_5  1
    f[17,92,6]  R521      -1
    f[17,92,6]  R594      1
    f[17,92,6]  marginal_18_6  1
    f[17,92,9]  R521      -1
    f[17,92,9]  R597      1
    f[17,92,9]  marginal_18_9  1
    f[17,93,5]  R522      -1
    f[17,93,5]  R594      1
    f[17,93,5]  marginal_18_5  1
    f[17,93,6]  R522      -1
    f[17,93,6]  R595      1
    f[17,93,6]  marginal_18_6  1
    f[17,93,9]  R522      -1
    f[17,93,9]  R598      1
    f[17,93,9]  marginal_18_9  1
    f[17,94,5]  R523      -1
    f[17,94,5]  R595      1
    f[17,94,5]  marginal_18_5  1
    f[17,94,6]  R523      -1
    f[17,94,6]  R596      1
    f[17,94,6]  marginal_18_6  1
    f[17,94,9]  R523      -1
    f[17,94,9]  R599      1
    f[17,94,9]  marginal_18_9  1
    f[17,95,5]  R524      -1
    f[17,95,5]  R596      1
    f[17,95,5]  marginal_18_5  1
    f[17,95,6]  R524      -1
    f[17,95,6]  R597      1
    f[17,95,6]  marginal_18_6  1
    f[17,95,9]  R524      -1
    f[17,95,9]  R600      1
    f[17,95,9]  marginal_18_9  1
    f[17,96,5]  R525      -1
    f[17,96,5]  R597      1
    f[17,96,5]  marginal_18_5  1
    f[17,96,6]  R525      -1
    f[17,96,6]  R598      1
    f[17,96,6]  marginal_18_6  1
    f[17,96,9]  R525      -1
    f[17,96,9]  R601      1
    f[17,96,9]  marginal_18_9  1
    f[17,97,5]  R526      -1
    f[17,97,5]  R598      1
    f[17,97,5]  marginal_18_5  1
    f[17,97,6]  R526      -1
    f[17,97,6]  R599      1
    f[17,97,6]  marginal_18_6  1
    f[17,97,9]  R526      -1
    f[17,97,9]  R602      1
    f[17,97,9]  marginal_18_9  1
    f[17,98,5]  R527      -1
    f[17,98,5]  R599      1
    f[17,98,5]  marginal_18_5  1
    f[17,98,6]  R527      -1
    f[17,98,6]  R600      1
    f[17,98,6]  marginal_18_6  1
    f[17,98,9]  R527      -1
    f[17,98,9]  R603      1
    f[17,98,9]  marginal_18_9  1
    f[17,99,5]  R528      -1
    f[17,99,5]  R600      1
    f[17,99,5]  marginal_18_5  1
    f[17,99,6]  R528      -1
    f[17,99,6]  R601      1
    f[17,99,6]  marginal_18_6  1
    f[17,99,9]  R528      -1
    f[17,99,9]  R604      1
    f[17,99,9]  marginal_18_9  1
    f[17,100,5]  R529      -1
    f[17,100,5]  R601      1
    f[17,100,5]  marginal_18_5  1
    f[17,100,6]  R529      -1
    f[17,100,6]  R602      1
    f[17,100,6]  marginal_18_6  1
    f[17,100,9]  R529      -1
    f[17,100,9]  R605      1
    f[17,100,9]  marginal_18_9  1
    f[17,101,5]  R530      -1
    f[17,101,5]  R602      1
    f[17,101,5]  marginal_18_5  1
    f[17,101,6]  R530      -1
    f[17,101,6]  R603      1
    f[17,101,6]  marginal_18_6  1
    f[17,101,9]  R530      -1
    f[17,101,9]  R606      1
    f[17,101,9]  marginal_18_9  1
    f[17,102,5]  R531      -1
    f[17,102,5]  R603      1
    f[17,102,5]  marginal_18_5  1
    f[17,102,6]  R531      -1
    f[17,102,6]  R604      1
    f[17,102,6]  marginal_18_6  1
    f[17,102,9]  R531      -1
    f[17,102,9]  R607      1
    f[17,102,9]  marginal_18_9  1
    f[17,103,5]  R532      -1
    f[17,103,5]  R604      1
    f[17,103,5]  marginal_18_5  1
    f[17,103,6]  R532      -1
    f[17,103,6]  R605      1
    f[17,103,6]  marginal_18_6  1
    f[17,103,9]  R532      -1
    f[17,103,9]  R608      1
    f[17,103,9]  marginal_18_9  1
    f[17,104,5]  R533      -1
    f[17,104,5]  R605      1
    f[17,104,5]  marginal_18_5  1
    f[17,104,6]  R533      -1
    f[17,104,6]  R606      1
    f[17,104,6]  marginal_18_6  1
    f[17,104,9]  R533      -1
    f[17,104,9]  R609      1
    f[17,104,9]  marginal_18_9  1
    f[17,105,5]  R534      -1
    f[17,105,5]  R606      1
    f[17,105,5]  marginal_18_5  1
    f[17,105,6]  R534      -1
    f[17,105,6]  R607      1
    f[17,105,6]  marginal_18_6  1
    f[17,105,9]  R534      -1
    f[17,105,9]  R610      1
    f[17,105,9]  marginal_18_9  1
    f[17,106,5]  R535      -1
    f[17,106,5]  R607      1
    f[17,106,5]  marginal_18_5  1
    f[17,106,6]  R535      -1
    f[17,106,6]  R608      1
    f[17,106,6]  marginal_18_6  1
    f[17,106,9]  R535      -1
    f[17,106,9]  R611      1
    f[17,106,9]  marginal_18_9  1
    f[17,107,5]  R536      -1
    f[17,107,5]  R608      1
    f[17,107,5]  marginal_18_5  1
    f[17,107,6]  R536      -1
    f[17,107,6]  R609      1
    f[17,107,6]  marginal_18_6  1
    f[17,107,9]  R536      -1
    f[17,107,9]  R612      1
    f[17,107,9]  marginal_18_9  1
    f[17,108,5]  R537      -1
    f[17,108,5]  R609      1
    f[17,108,5]  marginal_18_5  1
    f[17,108,6]  R537      -1
    f[17,108,6]  R610      1
    f[17,108,6]  marginal_18_6  1
    f[17,108,9]  R537      -1
    f[17,108,9]  R613      1
    f[17,108,9]  marginal_18_9  1
    f[17,109,5]  R538      -1
    f[17,109,5]  R610      1
    f[17,109,5]  marginal_18_5  1
    f[17,109,6]  R538      -1
    f[17,109,6]  R611      1
    f[17,109,6]  marginal_18_6  1
    f[17,109,9]  R538      -1
    f[17,109,9]  R614      1
    f[17,109,9]  marginal_18_9  1
    f[17,110,5]  R539      -1
    f[17,110,5]  R611      1
    f[17,110,5]  marginal_18_5  1
    f[17,110,6]  R539      -1
    f[17,110,6]  R612      1
    f[17,110,6]  marginal_18_6  1
    f[17,110,9]  R539      -1
    f[17,110,9]  R615      1
    f[17,110,9]  marginal_18_9  1
    f[17,111,5]  R540      -1
    f[17,111,5]  R612      1
    f[17,111,5]  marginal_18_5  1
    f[17,111,6]  R540      -1
    f[17,111,6]  R613      1
    f[17,111,6]  marginal_18_6  1
    f[17,111,9]  R540      -1
    f[17,111,9]  R616      1
    f[17,111,9]  marginal_18_9  1
    f[17,112,5]  R541      -1
    f[17,112,5]  R613      1
    f[17,112,5]  marginal_18_5  1
    f[17,112,6]  R541      -1
    f[17,112,6]  R614      1
    f[17,112,6]  marginal_18_6  1
    f[17,112,9]  R541      -1
    f[17,112,9]  R617      1
    f[17,112,9]  marginal_18_9  1
    f[17,113,5]  R542      -1
    f[17,113,5]  R614      1
    f[17,113,5]  marginal_18_5  1
    f[17,113,6]  R542      -1
    f[17,113,6]  R615      1
    f[17,113,6]  marginal_18_6  1
    f[17,113,9]  R542      -1
    f[17,113,9]  R618      1
    f[17,113,9]  marginal_18_9  1
    f[17,114,5]  R543      -1
    f[17,114,5]  R615      1
    f[17,114,5]  marginal_18_5  1
    f[17,114,6]  R543      -1
    f[17,114,6]  R616      1
    f[17,114,6]  marginal_18_6  1
    f[17,114,9]  R543      -1
    f[17,114,9]  R619      1
    f[17,114,9]  marginal_18_9  1
    f[17,115,5]  R544      -1
    f[17,115,5]  R616      1
    f[17,115,5]  marginal_18_5  1
    f[17,115,6]  R544      -1
    f[17,115,6]  R617      1
    f[17,115,6]  marginal_18_6  1
    f[17,115,9]  R544      -1
    f[17,115,9]  R620      1
    f[17,115,9]  marginal_18_9  1
    f[17,116,5]  R545      -1
    f[17,116,5]  R617      1
    f[17,116,5]  marginal_18_5  1
    f[17,116,6]  R545      -1
    f[17,116,6]  R618      1
    f[17,116,6]  marginal_18_6  1
    f[17,116,9]  R545      -1
    f[17,116,9]  R621      1
    f[17,116,9]  marginal_18_9  1
    f[17,117,5]  R546      -1
    f[17,117,5]  R618      1
    f[17,117,5]  marginal_18_5  1
    f[17,117,6]  R546      -1
    f[17,117,6]  R619      1
    f[17,117,6]  marginal_18_6  1
    f[17,117,9]  R546      -1
    f[17,117,9]  R622      1
    f[17,117,9]  marginal_18_9  1
    f[17,118,5]  R547      -1
    f[17,118,5]  R619      1
    f[17,118,5]  marginal_18_5  1
    f[17,118,6]  R547      -1
    f[17,118,6]  R620      1
    f[17,118,6]  marginal_18_6  1
    f[17,118,9]  R547      -1
    f[17,118,9]  R623      1
    f[17,118,9]  marginal_18_9  1
    f[17,119,5]  R548      -1
    f[17,119,5]  R620      1
    f[17,119,5]  marginal_18_5  1
    f[17,119,6]  R548      -1
    f[17,119,6]  R621      1
    f[17,119,6]  marginal_18_6  1
    f[17,119,9]  R548      -1
    f[17,119,9]  R557      1
    f[17,119,9]  marginal_18_9  1
    f[17,120,5]  R549      -1
    f[17,120,5]  R621      1
    f[17,120,5]  marginal_18_5  1
    f[17,120,6]  R549      -1
    f[17,120,6]  R622      1
    f[17,120,6]  marginal_18_6  1
    f[17,120,9]  R549      -1
    f[17,120,9]  R558      1
    f[17,120,9]  marginal_18_9  1
    f[17,121,5]  R550      -1
    f[17,121,5]  R622      1
    f[17,121,5]  marginal_18_5  1
    f[17,121,6]  R550      -1
    f[17,121,6]  R623      1
    f[17,121,6]  marginal_18_6  1
    f[17,121,9]  R550      -1
    f[17,121,9]  R559      1
    f[17,121,9]  marginal_18_9  1
    f[17,122,5]  R551      -1
    f[17,122,5]  R623      1
    f[17,122,5]  marginal_18_5  1
    f[17,122,6]  R551      -1
    f[17,122,6]  R557      1
    f[17,122,6]  marginal_18_6  1
    f[17,122,9]  R551      -1
    f[17,122,9]  R560      1
    f[17,122,9]  marginal_18_9  1
    f[17,123,5]  R552      -1
    f[17,123,5]  R557      1
    f[17,123,5]  marginal_18_5  1
    f[17,123,6]  R552      -1
    f[17,123,6]  R558      1
    f[17,123,6]  marginal_18_6  1
    f[17,123,9]  R552      -1
    f[17,123,9]  R561      1
    f[17,123,9]  marginal_18_9  1
    f[17,124,5]  R553      -1
    f[17,124,5]  R558      1
    f[17,124,5]  marginal_18_5  1
    f[17,124,6]  R553      -1
    f[17,124,6]  R559      1
    f[17,124,6]  marginal_18_6  1
    f[17,124,9]  R553      -1
    f[17,124,9]  R562      1
    f[17,124,9]  marginal_18_9  1
    f[17,125,5]  R554      -1
    f[17,125,5]  R559      1
    f[17,125,5]  marginal_18_5  1
    f[17,125,6]  R554      -1
    f[17,125,6]  R560      1
    f[17,125,6]  marginal_18_6  1
    f[17,125,9]  R554      -1
    f[17,125,9]  R563      1
    f[17,125,9]  marginal_18_9  1
    f[17,126,5]  R555      -1
    f[17,126,5]  R560      1
    f[17,126,5]  marginal_18_5  1
    f[17,126,6]  R555      -1
    f[17,126,6]  R561      1
    f[17,126,6]  marginal_18_6  1
    f[17,126,9]  R555      -1
    f[17,126,9]  R564      1
    f[17,126,9]  marginal_18_9  1
    f[17,127,5]  R556      -1
    f[17,127,5]  R561      1
    f[17,127,5]  marginal_18_5  1
    f[17,127,6]  R556      -1
    f[17,127,6]  R562      1
    f[17,127,6]  marginal_18_6  1
    f[17,127,9]  R556      -1
    f[17,127,9]  R565      1
    f[17,127,9]  marginal_18_9  1
    f[17,128,5]  R494      -1
    f[17,128,5]  R562      1
    f[17,128,5]  marginal_18_5  1
    f[17,128,6]  R494      -1
    f[17,128,6]  R563      1
    f[17,128,6]  marginal_18_6  1
    f[17,128,9]  R494      -1
    f[17,128,9]  R566      1
    f[17,128,9]  marginal_18_9  1
    f[18,71,2]  R567      -1
    f[18,71,2]  R638      1
    f[18,71,2]  marginal_19_2  1
    f[18,71,4]  R567      -1
    f[18,71,4]  R640      1
    f[18,71,4]  marginal_19_4  1
    f[18,72,2]  R568      -1
    f[18,72,2]  R639      1
    f[18,72,2]  marginal_19_2  1
    f[18,72,4]  R568      -1
    f[18,72,4]  R641      1
    f[18,72,4]  marginal_19_4  1
    f[18,73,2]  R569      -1
    f[18,73,2]  R640      1
    f[18,73,2]  marginal_19_2  1
    f[18,73,4]  R569      -1
    f[18,73,4]  R642      1
    f[18,73,4]  marginal_19_4  1
    f[18,74,2]  R570      -1
    f[18,74,2]  R641      1
    f[18,74,2]  marginal_19_2  1
    f[18,74,4]  R570      -1
    f[18,74,4]  R643      1
    f[18,74,4]  marginal_19_4  1
    f[18,75,2]  R571      -1
    f[18,75,2]  R642      1
    f[18,75,2]  marginal_19_2  1
    f[18,75,4]  R571      -1
    f[18,75,4]  R644      1
    f[18,75,4]  marginal_19_4  1
    f[18,76,2]  R572      -1
    f[18,76,2]  R643      1
    f[18,76,2]  marginal_19_2  1
    f[18,76,4]  R572      -1
    f[18,76,4]  R645      1
    f[18,76,4]  marginal_19_4  1
    f[18,77,2]  R573      -1
    f[18,77,2]  R644      1
    f[18,77,2]  marginal_19_2  1
    f[18,77,4]  R573      -1
    f[18,77,4]  R646      1
    f[18,77,4]  marginal_19_4  1
    f[18,78,2]  R574      -1
    f[18,78,2]  R645      1
    f[18,78,2]  marginal_19_2  1
    f[18,78,4]  R574      -1
    f[18,78,4]  R647      1
    f[18,78,4]  marginal_19_4  1
    f[18,79,2]  R575      -1
    f[18,79,2]  R646      1
    f[18,79,2]  marginal_19_2  1
    f[18,79,4]  R575      -1
    f[18,79,4]  R648      1
    f[18,79,4]  marginal_19_4  1
    f[18,80,2]  R576      -1
    f[18,80,2]  R647      1
    f[18,80,2]  marginal_19_2  1
    f[18,80,4]  R576      -1
    f[18,80,4]  R649      1
    f[18,80,4]  marginal_19_4  1
    f[18,81,2]  R577      -1
    f[18,81,2]  R648      1
    f[18,81,2]  marginal_19_2  1
    f[18,81,4]  R577      -1
    f[18,81,4]  R650      1
    f[18,81,4]  marginal_19_4  1
    f[18,82,2]  R578      -1
    f[18,82,2]  R649      1
    f[18,82,2]  marginal_19_2  1
    f[18,82,4]  R578      -1
    f[18,82,4]  R651      1
    f[18,82,4]  marginal_19_4  1
    f[18,83,2]  R579      -1
    f[18,83,2]  R650      1
    f[18,83,2]  marginal_19_2  1
    f[18,83,4]  R579      -1
    f[18,83,4]  R652      1
    f[18,83,4]  marginal_19_4  1
    f[18,84,2]  R580      -1
    f[18,84,2]  R651      1
    f[18,84,2]  marginal_19_2  1
    f[18,84,4]  R580      -1
    f[18,84,4]  R653      1
    f[18,84,4]  marginal_19_4  1
    f[18,85,2]  R581      -1
    f[18,85,2]  R652      1
    f[18,85,2]  marginal_19_2  1
    f[18,85,4]  R581      -1
    f[18,85,4]  R654      1
    f[18,85,4]  marginal_19_4  1
    f[18,86,2]  R582      -1
    f[18,86,2]  R653      1
    f[18,86,2]  marginal_19_2  1
    f[18,86,4]  R582      -1
    f[18,86,4]  R655      1
    f[18,86,4]  marginal_19_4  1
    f[18,87,2]  R583      -1
    f[18,87,2]  R654      1
    f[18,87,2]  marginal_19_2  1
    f[18,87,4]  R583      -1
    f[18,87,4]  R656      1
    f[18,87,4]  marginal_19_4  1
    f[18,88,2]  R584      -1
    f[18,88,2]  R655      1
    f[18,88,2]  marginal_19_2  1
    f[18,88,4]  R584      -1
    f[18,88,4]  R657      1
    f[18,88,4]  marginal_19_4  1
    f[18,89,2]  R585      -1
    f[18,89,2]  R656      1
    f[18,89,2]  marginal_19_2  1
    f[18,89,4]  R585      -1
    f[18,89,4]  R658      1
    f[18,89,4]  marginal_19_4  1
    f[18,90,2]  R586      -1
    f[18,90,2]  R657      1
    f[18,90,2]  marginal_19_2  1
    f[18,90,4]  R586      -1
    f[18,90,4]  R659      1
    f[18,90,4]  marginal_19_4  1
    f[18,91,2]  R587      -1
    f[18,91,2]  R658      1
    f[18,91,2]  marginal_19_2  1
    f[18,91,4]  R587      -1
    f[18,91,4]  R660      1
    f[18,91,4]  marginal_19_4  1
    f[18,92,2]  R588      -1
    f[18,92,2]  R659      1
    f[18,92,2]  marginal_19_2  1
    f[18,92,4]  R588      -1
    f[18,92,4]  R661      1
    f[18,92,4]  marginal_19_4  1
    f[18,93,2]  R589      -1
    f[18,93,2]  R660      1
    f[18,93,2]  marginal_19_2  1
    f[18,93,4]  R589      -1
    f[18,93,4]  R662      1
    f[18,93,4]  marginal_19_4  1
    f[18,94,2]  R590      -1
    f[18,94,2]  R661      1
    f[18,94,2]  marginal_19_2  1
    f[18,94,4]  R590      -1
    f[18,94,4]  R663      1
    f[18,94,4]  marginal_19_4  1
    f[18,95,2]  R591      -1
    f[18,95,2]  R662      1
    f[18,95,2]  marginal_19_2  1
    f[18,95,4]  R591      -1
    f[18,95,4]  R664      1
    f[18,95,4]  marginal_19_4  1
    f[18,96,2]  R592      -1
    f[18,96,2]  R663      1
    f[18,96,2]  marginal_19_2  1
    f[18,96,4]  R592      -1
    f[18,96,4]  R665      1
    f[18,96,4]  marginal_19_4  1
    f[18,97,2]  R593      -1
    f[18,97,2]  R664      1
    f[18,97,2]  marginal_19_2  1
    f[18,97,4]  R593      -1
    f[18,97,4]  R666      1
    f[18,97,4]  marginal_19_4  1
    f[18,98,2]  R594      -1
    f[18,98,2]  R665      1
    f[18,98,2]  marginal_19_2  1
    f[18,98,4]  R594      -1
    f[18,98,4]  R667      1
    f[18,98,4]  marginal_19_4  1
    f[18,99,2]  R595      -1
    f[18,99,2]  R666      1
    f[18,99,2]  marginal_19_2  1
    f[18,99,4]  R595      -1
    f[18,99,4]  R668      1
    f[18,99,4]  marginal_19_4  1
    f[18,100,2]  R596      -1
    f[18,100,2]  R667      1
    f[18,100,2]  marginal_19_2  1
    f[18,100,4]  R596      -1
    f[18,100,4]  R669      1
    f[18,100,4]  marginal_19_4  1
    f[18,101,2]  R597      -1
    f[18,101,2]  R668      1
    f[18,101,2]  marginal_19_2  1
    f[18,101,4]  R597      -1
    f[18,101,4]  R670      1
    f[18,101,4]  marginal_19_4  1
    f[18,102,2]  R598      -1
    f[18,102,2]  R669      1
    f[18,102,2]  marginal_19_2  1
    f[18,102,4]  R598      -1
    f[18,102,4]  R671      1
    f[18,102,4]  marginal_19_4  1
    f[18,103,2]  R599      -1
    f[18,103,2]  R670      1
    f[18,103,2]  marginal_19_2  1
    f[18,103,4]  R599      -1
    f[18,103,4]  R672      1
    f[18,103,4]  marginal_19_4  1
    f[18,104,2]  R600      -1
    f[18,104,2]  R671      1
    f[18,104,2]  marginal_19_2  1
    f[18,104,4]  R600      -1
    f[18,104,4]  R673      1
    f[18,104,4]  marginal_19_4  1
    f[18,105,2]  R601      -1
    f[18,105,2]  R672      1
    f[18,105,2]  marginal_19_2  1
    f[18,105,4]  R601      -1
    f[18,105,4]  R674      1
    f[18,105,4]  marginal_19_4  1
    f[18,106,2]  R602      -1
    f[18,106,2]  R673      1
    f[18,106,2]  marginal_19_2  1
    f[18,106,4]  R602      -1
    f[18,106,4]  R675      1
    f[18,106,4]  marginal_19_4  1
    f[18,107,2]  R603      -1
    f[18,107,2]  R674      1
    f[18,107,2]  marginal_19_2  1
    f[18,107,4]  R603      -1
    f[18,107,4]  R676      1
    f[18,107,4]  marginal_19_4  1
    f[18,108,2]  R604      -1
    f[18,108,2]  R675      1
    f[18,108,2]  marginal_19_2  1
    f[18,108,4]  R604      -1
    f[18,108,4]  R677      1
    f[18,108,4]  marginal_19_4  1
    f[18,109,2]  R605      -1
    f[18,109,2]  R676      1
    f[18,109,2]  marginal_19_2  1
    f[18,109,4]  R605      -1
    f[18,109,4]  R678      1
    f[18,109,4]  marginal_19_4  1
    f[18,110,2]  R606      -1
    f[18,110,2]  R677      1
    f[18,110,2]  marginal_19_2  1
    f[18,110,4]  R606      -1
    f[18,110,4]  R679      1
    f[18,110,4]  marginal_19_4  1
    f[18,111,2]  R607      -1
    f[18,111,2]  R678      1
    f[18,111,2]  marginal_19_2  1
    f[18,111,4]  R607      -1
    f[18,111,4]  R680      1
    f[18,111,4]  marginal_19_4  1
    f[18,112,2]  R608      -1
    f[18,112,2]  R679      1
    f[18,112,2]  marginal_19_2  1
    f[18,112,4]  R608      -1
    f[18,112,4]  R681      1
    f[18,112,4]  marginal_19_4  1
    f[18,113,2]  R609      -1
    f[18,113,2]  R680      1
    f[18,113,2]  marginal_19_2  1
    f[18,113,4]  R609      -1
    f[18,113,4]  R682      1
    f[18,113,4]  marginal_19_4  1
    f[18,114,2]  R610      -1
    f[18,114,2]  R681      1
    f[18,114,2]  marginal_19_2  1
    f[18,114,4]  R610      -1
    f[18,114,4]  R683      1
    f[18,114,4]  marginal_19_4  1
    f[18,115,2]  R611      -1
    f[18,115,2]  R682      1
    f[18,115,2]  marginal_19_2  1
    f[18,115,4]  R611      -1
    f[18,115,4]  R684      1
    f[18,115,4]  marginal_19_4  1
    f[18,116,2]  R612      -1
    f[18,116,2]  R683      1
    f[18,116,2]  marginal_19_2  1
    f[18,116,4]  R612      -1
    f[18,116,4]  R685      1
    f[18,116,4]  marginal_19_4  1
    f[18,117,2]  R613      -1
    f[18,117,2]  R684      1
    f[18,117,2]  marginal_19_2  1
    f[18,117,4]  R613      -1
    f[18,117,4]  R686      1
    f[18,117,4]  marginal_19_4  1
    f[18,118,2]  R614      -1
    f[18,118,2]  R685      1
    f[18,118,2]  marginal_19_2  1
    f[18,118,4]  R614      -1
    f[18,118,4]  R687      1
    f[18,118,4]  marginal_19_4  1
    f[18,119,2]  R615      -1
    f[18,119,2]  R686      1
    f[18,119,2]  marginal_19_2  1
    f[18,119,4]  R615      -1
    f[18,119,4]  R688      1
    f[18,119,4]  marginal_19_4  1
    f[18,120,2]  R616      -1
    f[18,120,2]  R687      1
    f[18,120,2]  marginal_19_2  1
    f[18,120,4]  R616      -1
    f[18,120,4]  R689      1
    f[18,120,4]  marginal_19_4  1
    f[18,121,2]  R617      -1
    f[18,121,2]  R688      1
    f[18,121,2]  marginal_19_2  1
    f[18,121,4]  R617      -1
    f[18,121,4]  R690      1
    f[18,121,4]  marginal_19_4  1
    f[18,122,2]  R618      -1
    f[18,122,2]  R689      1
    f[18,122,2]  marginal_19_2  1
    f[18,122,4]  R618      -1
    f[18,122,4]  R691      1
    f[18,122,4]  marginal_19_4  1
    f[18,123,2]  R619      -1
    f[18,123,2]  R690      1
    f[18,123,2]  marginal_19_2  1
    f[18,123,4]  R619      -1
    f[18,123,4]  R692      1
    f[18,123,4]  marginal_19_4  1
    f[18,124,2]  R620      -1
    f[18,124,2]  R691      1
    f[18,124,2]  marginal_19_2  1
    f[18,124,4]  R620      -1
    f[18,124,4]  R624      1
    f[18,124,4]  marginal_19_4  1
    f[18,125,2]  R621      -1
    f[18,125,2]  R692      1
    f[18,125,2]  marginal_19_2  1
    f[18,125,4]  R621      -1
    f[18,125,4]  R625      1
    f[18,125,4]  marginal_19_4  1
    f[18,126,2]  R622      -1
    f[18,126,2]  R624      1
    f[18,126,2]  marginal_19_2  1
    f[18,126,4]  R622      -1
    f[18,126,4]  R626      1
    f[18,126,4]  marginal_19_4  1
    f[18,127,2]  R623      -1
    f[18,127,2]  R625      1
    f[18,127,2]  marginal_19_2  1
    f[18,127,4]  R623      -1
    f[18,127,4]  R627      1
    f[18,127,4]  marginal_19_4  1
    f[18,128,2]  R557      -1
    f[18,128,2]  R626      1
    f[18,128,2]  marginal_19_2  1
    f[18,128,4]  R557      -1
    f[18,128,4]  R628      1
    f[18,128,4]  marginal_19_4  1
    f[18,129,2]  R558      -1
    f[18,129,2]  R627      1
    f[18,129,2]  marginal_19_2  1
    f[18,129,4]  R558      -1
    f[18,129,4]  R629      1
    f[18,129,4]  marginal_19_4  1
    f[18,130,2]  R559      -1
    f[18,130,2]  R628      1
    f[18,130,2]  marginal_19_2  1
    f[18,130,4]  R559      -1
    f[18,130,4]  R630      1
    f[18,130,4]  marginal_19_4  1
    f[18,131,2]  R560      -1
    f[18,131,2]  R629      1
    f[18,131,2]  marginal_19_2  1
    f[18,131,4]  R560      -1
    f[18,131,4]  R631      1
    f[18,131,4]  marginal_19_4  1
    f[18,132,2]  R561      -1
    f[18,132,2]  R630      1
    f[18,132,2]  marginal_19_2  1
    f[18,132,4]  R561      -1
    f[18,132,4]  R632      1
    f[18,132,4]  marginal_19_4  1
    f[18,133,2]  R562      -1
    f[18,133,2]  R631      1
    f[18,133,2]  marginal_19_2  1
    f[18,133,4]  R562      -1
    f[18,133,4]  R633      1
    f[18,133,4]  marginal_19_4  1
    f[18,134,2]  R563      -1
    f[18,134,2]  R632      1
    f[18,134,2]  marginal_19_2  1
    f[18,134,4]  R563      -1
    f[18,134,4]  R634      1
    f[18,134,4]  marginal_19_4  1
    f[18,135,2]  R564      -1
    f[18,135,2]  R633      1
    f[18,135,2]  marginal_19_2  1
    f[18,135,4]  R564      -1
    f[18,135,4]  R635      1
    f[18,135,4]  marginal_19_4  1
    f[18,136,2]  R565      -1
    f[18,136,2]  R634      1
    f[18,136,2]  marginal_19_2  1
    f[18,136,4]  R565      -1
    f[18,136,4]  R636      1
    f[18,136,4]  marginal_19_4  1
    f[18,137,2]  R566      -1
    f[18,137,2]  R635      1
    f[18,137,2]  marginal_19_2  1
    f[18,137,4]  R566      -1
    f[18,137,4]  R637      1
    f[18,137,4]  marginal_19_4  1
    f[19,73,3]  R638      -1
    f[19,73,3]  R713      1
    f[19,73,3]  marginal_20_3  1
    f[19,73,6]  R638      -1
    f[19,73,6]  R716      1
    f[19,73,6]  marginal_20_6  1
    f[19,74,3]  R639      -1
    f[19,74,3]  R714      1
    f[19,74,3]  marginal_20_3  1
    f[19,74,6]  R639      -1
    f[19,74,6]  R717      1
    f[19,74,6]  marginal_20_6  1
    f[19,75,3]  R640      -1
    f[19,75,3]  R715      1
    f[19,75,3]  marginal_20_3  1
    f[19,75,6]  R640      -1
    f[19,75,6]  R718      1
    f[19,75,6]  marginal_20_6  1
    f[19,76,3]  R641      -1
    f[19,76,3]  R716      1
    f[19,76,3]  marginal_20_3  1
    f[19,76,6]  R641      -1
    f[19,76,6]  R719      1
    f[19,76,6]  marginal_20_6  1
    f[19,77,3]  R642      -1
    f[19,77,3]  R717      1
    f[19,77,3]  marginal_20_3  1
    f[19,77,6]  R642      -1
    f[19,77,6]  R720      1
    f[19,77,6]  marginal_20_6  1
    f[19,78,3]  R643      -1
    f[19,78,3]  R718      1
    f[19,78,3]  marginal_20_3  1
    f[19,78,6]  R643      -1
    f[19,78,6]  R721      1
    f[19,78,6]  marginal_20_6  1
    f[19,79,3]  R644      -1
    f[19,79,3]  R719      1
    f[19,79,3]  marginal_20_3  1
    f[19,79,6]  R644      -1
    f[19,79,6]  R722      1
    f[19,79,6]  marginal_20_6  1
    f[19,80,3]  R645      -1
    f[19,80,3]  R720      1
    f[19,80,3]  marginal_20_3  1
    f[19,80,6]  R645      -1
    f[19,80,6]  R723      1
    f[19,80,6]  marginal_20_6  1
    f[19,81,3]  R646      -1
    f[19,81,3]  R721      1
    f[19,81,3]  marginal_20_3  1
    f[19,81,6]  R646      -1
    f[19,81,6]  R724      1
    f[19,81,6]  marginal_20_6  1
    f[19,82,3]  R647      -1
    f[19,82,3]  R722      1
    f[19,82,3]  marginal_20_3  1
    f[19,82,6]  R647      -1
    f[19,82,6]  R725      1
    f[19,82,6]  marginal_20_6  1
    f[19,83,3]  R648      -1
    f[19,83,3]  R723      1
    f[19,83,3]  marginal_20_3  1
    f[19,83,6]  R648      -1
    f[19,83,6]  R726      1
    f[19,83,6]  marginal_20_6  1
    f[19,84,3]  R649      -1
    f[19,84,3]  R724      1
    f[19,84,3]  marginal_20_3  1
    f[19,84,6]  R649      -1
    f[19,84,6]  R727      1
    f[19,84,6]  marginal_20_6  1
    f[19,85,3]  R650      -1
    f[19,85,3]  R725      1
    f[19,85,3]  marginal_20_3  1
    f[19,85,6]  R650      -1
    f[19,85,6]  R728      1
    f[19,85,6]  marginal_20_6  1
    f[19,86,3]  R651      -1
    f[19,86,3]  R726      1
    f[19,86,3]  marginal_20_3  1
    f[19,86,6]  R651      -1
    f[19,86,6]  R729      1
    f[19,86,6]  marginal_20_6  1
    f[19,87,3]  R652      -1
    f[19,87,3]  R727      1
    f[19,87,3]  marginal_20_3  1
    f[19,87,6]  R652      -1
    f[19,87,6]  R730      1
    f[19,87,6]  marginal_20_6  1
    f[19,88,3]  R653      -1
    f[19,88,3]  R728      1
    f[19,88,3]  marginal_20_3  1
    f[19,88,6]  R653      -1
    f[19,88,6]  R731      1
    f[19,88,6]  marginal_20_6  1
    f[19,89,3]  R654      -1
    f[19,89,3]  R729      1
    f[19,89,3]  marginal_20_3  1
    f[19,89,6]  R654      -1
    f[19,89,6]  R732      1
    f[19,89,6]  marginal_20_6  1
    f[19,90,3]  R655      -1
    f[19,90,3]  R730      1
    f[19,90,3]  marginal_20_3  1
    f[19,90,6]  R655      -1
    f[19,90,6]  R733      1
    f[19,90,6]  marginal_20_6  1
    f[19,91,3]  R656      -1
    f[19,91,3]  R731      1
    f[19,91,3]  marginal_20_3  1
    f[19,91,6]  R656      -1
    f[19,91,6]  R734      1
    f[19,91,6]  marginal_20_6  1
    f[19,92,3]  R657      -1
    f[19,92,3]  R732      1
    f[19,92,3]  marginal_20_3  1
    f[19,92,6]  R657      -1
    f[19,92,6]  R735      1
    f[19,92,6]  marginal_20_6  1
    f[19,93,3]  R658      -1
    f[19,93,3]  R733      1
    f[19,93,3]  marginal_20_3  1
    f[19,93,6]  R658      -1
    f[19,93,6]  R736      1
    f[19,93,6]  marginal_20_6  1
    f[19,94,3]  R659      -1
    f[19,94,3]  R734      1
    f[19,94,3]  marginal_20_3  1
    f[19,94,6]  R659      -1
    f[19,94,6]  R737      1
    f[19,94,6]  marginal_20_6  1
    f[19,95,3]  R660      -1
    f[19,95,3]  R735      1
    f[19,95,3]  marginal_20_3  1
    f[19,95,6]  R660      -1
    f[19,95,6]  R738      1
    f[19,95,6]  marginal_20_6  1
    f[19,96,3]  R661      -1
    f[19,96,3]  R736      1
    f[19,96,3]  marginal_20_3  1
    f[19,96,6]  R661      -1
    f[19,96,6]  R739      1
    f[19,96,6]  marginal_20_6  1
    f[19,97,3]  R662      -1
    f[19,97,3]  R737      1
    f[19,97,3]  marginal_20_3  1
    f[19,97,6]  R662      -1
    f[19,97,6]  R740      1
    f[19,97,6]  marginal_20_6  1
    f[19,98,3]  R663      -1
    f[19,98,3]  R738      1
    f[19,98,3]  marginal_20_3  1
    f[19,98,6]  R663      -1
    f[19,98,6]  R741      1
    f[19,98,6]  marginal_20_6  1
    f[19,99,3]  R664      -1
    f[19,99,3]  R739      1
    f[19,99,3]  marginal_20_3  1
    f[19,99,6]  R664      -1
    f[19,99,6]  R742      1
    f[19,99,6]  marginal_20_6  1
    f[19,100,3]  R665      -1
    f[19,100,3]  R740      1
    f[19,100,3]  marginal_20_3  1
    f[19,100,6]  R665      -1
    f[19,100,6]  R743      1
    f[19,100,6]  marginal_20_6  1
    f[19,101,3]  R666      -1
    f[19,101,3]  R741      1
    f[19,101,3]  marginal_20_3  1
    f[19,101,6]  R666      -1
    f[19,101,6]  R744      1
    f[19,101,6]  marginal_20_6  1
    f[19,102,3]  R667      -1
    f[19,102,3]  R742      1
    f[19,102,3]  marginal_20_3  1
    f[19,102,6]  R667      -1
    f[19,102,6]  R745      1
    f[19,102,6]  marginal_20_6  1
    f[19,103,3]  R668      -1
    f[19,103,3]  R743      1
    f[19,103,3]  marginal_20_3  1
    f[19,103,6]  R668      -1
    f[19,103,6]  R746      1
    f[19,103,6]  marginal_20_6  1
    f[19,104,3]  R669      -1
    f[19,104,3]  R744      1
    f[19,104,3]  marginal_20_3  1
    f[19,104,6]  R669      -1
    f[19,104,6]  R747      1
    f[19,104,6]  marginal_20_6  1
    f[19,105,3]  R670      -1
    f[19,105,3]  R745      1
    f[19,105,3]  marginal_20_3  1
    f[19,105,6]  R670      -1
    f[19,105,6]  R748      1
    f[19,105,6]  marginal_20_6  1
    f[19,106,3]  R671      -1
    f[19,106,3]  R746      1
    f[19,106,3]  marginal_20_3  1
    f[19,106,6]  R671      -1
    f[19,106,6]  R749      1
    f[19,106,6]  marginal_20_6  1
    f[19,107,3]  R672      -1
    f[19,107,3]  R747      1
    f[19,107,3]  marginal_20_3  1
    f[19,107,6]  R672      -1
    f[19,107,6]  R750      1
    f[19,107,6]  marginal_20_6  1
    f[19,108,3]  R673      -1
    f[19,108,3]  R748      1
    f[19,108,3]  marginal_20_3  1
    f[19,108,6]  R673      -1
    f[19,108,6]  R751      1
    f[19,108,6]  marginal_20_6  1
    f[19,109,3]  R674      -1
    f[19,109,3]  R749      1
    f[19,109,3]  marginal_20_3  1
    f[19,109,6]  R674      -1
    f[19,109,6]  R752      1
    f[19,109,6]  marginal_20_6  1
    f[19,110,3]  R675      -1
    f[19,110,3]  R750      1
    f[19,110,3]  marginal_20_3  1
    f[19,110,6]  R675      -1
    f[19,110,6]  R753      1
    f[19,110,6]  marginal_20_6  1
    f[19,111,3]  R676      -1
    f[19,111,3]  R751      1
    f[19,111,3]  marginal_20_3  1
    f[19,111,6]  R676      -1
    f[19,111,6]  R754      1
    f[19,111,6]  marginal_20_6  1
    f[19,112,3]  R677      -1
    f[19,112,3]  R752      1
    f[19,112,3]  marginal_20_3  1
    f[19,112,6]  R677      -1
    f[19,112,6]  R755      1
    f[19,112,6]  marginal_20_6  1
    f[19,113,3]  R678      -1
    f[19,113,3]  R753      1
    f[19,113,3]  marginal_20_3  1
    f[19,113,6]  R678      -1
    f[19,113,6]  R756      1
    f[19,113,6]  marginal_20_6  1
    f[19,114,3]  R679      -1
    f[19,114,3]  R754      1
    f[19,114,3]  marginal_20_3  1
    f[19,114,6]  R679      -1
    f[19,114,6]  R757      1
    f[19,114,6]  marginal_20_6  1
    f[19,115,3]  R680      -1
    f[19,115,3]  R755      1
    f[19,115,3]  marginal_20_3  1
    f[19,115,6]  R680      -1
    f[19,115,6]  R758      1
    f[19,115,6]  marginal_20_6  1
    f[19,116,3]  R681      -1
    f[19,116,3]  R756      1
    f[19,116,3]  marginal_20_3  1
    f[19,116,6]  R681      -1
    f[19,116,6]  R759      1
    f[19,116,6]  marginal_20_6  1
    f[19,117,3]  R682      -1
    f[19,117,3]  R757      1
    f[19,117,3]  marginal_20_3  1
    f[19,117,6]  R682      -1
    f[19,117,6]  R760      1
    f[19,117,6]  marginal_20_6  1
    f[19,118,3]  R683      -1
    f[19,118,3]  R758      1
    f[19,118,3]  marginal_20_3  1
    f[19,118,6]  R683      -1
    f[19,118,6]  R761      1
    f[19,118,6]  marginal_20_6  1
    f[19,119,3]  R684      -1
    f[19,119,3]  R759      1
    f[19,119,3]  marginal_20_3  1
    f[19,119,6]  R684      -1
    f[19,119,6]  R762      1
    f[19,119,6]  marginal_20_6  1
    f[19,120,3]  R685      -1
    f[19,120,3]  R760      1
    f[19,120,3]  marginal_20_3  1
    f[19,120,6]  R685      -1
    f[19,120,6]  R763      1
    f[19,120,6]  marginal_20_6  1
    f[19,121,3]  R686      -1
    f[19,121,3]  R761      1
    f[19,121,3]  marginal_20_3  1
    f[19,121,6]  R686      -1
    f[19,121,6]  R764      1
    f[19,121,6]  marginal_20_6  1
    f[19,122,3]  R687      -1
    f[19,122,3]  R762      1
    f[19,122,3]  marginal_20_3  1
    f[19,122,6]  R687      -1
    f[19,122,6]  R693      1
    f[19,122,6]  marginal_20_6  1
    f[19,123,3]  R688      -1
    f[19,123,3]  R763      1
    f[19,123,3]  marginal_20_3  1
    f[19,123,6]  R688      -1
    f[19,123,6]  R694      1
    f[19,123,6]  marginal_20_6  1
    f[19,124,3]  R689      -1
    f[19,124,3]  R764      1
    f[19,124,3]  marginal_20_3  1
    f[19,124,6]  R689      -1
    f[19,124,6]  R695      1
    f[19,124,6]  marginal_20_6  1
    f[19,125,3]  R690      -1
    f[19,125,3]  R693      1
    f[19,125,3]  marginal_20_3  1
    f[19,125,6]  R690      -1
    f[19,125,6]  R696      1
    f[19,125,6]  marginal_20_6  1
    f[19,126,3]  R691      -1
    f[19,126,3]  R694      1
    f[19,126,3]  marginal_20_3  1
    f[19,126,6]  R691      -1
    f[19,126,6]  R697      1
    f[19,126,6]  marginal_20_6  1
    f[19,127,3]  R692      -1
    f[19,127,3]  R695      1
    f[19,127,3]  marginal_20_3  1
    f[19,127,6]  R692      -1
    f[19,127,6]  R698      1
    f[19,127,6]  marginal_20_6  1
    f[19,128,3]  R624      -1
    f[19,128,3]  R696      1
    f[19,128,3]  marginal_20_3  1
    f[19,128,6]  R624      -1
    f[19,128,6]  R699      1
    f[19,128,6]  marginal_20_6  1
    f[19,129,3]  R625      -1
    f[19,129,3]  R697      1
    f[19,129,3]  marginal_20_3  1
    f[19,129,6]  R625      -1
    f[19,129,6]  R700      1
    f[19,129,6]  marginal_20_6  1
    f[19,130,3]  R626      -1
    f[19,130,3]  R698      1
    f[19,130,3]  marginal_20_3  1
    f[19,130,6]  R626      -1
    f[19,130,6]  R701      1
    f[19,130,6]  marginal_20_6  1
    f[19,131,3]  R627      -1
    f[19,131,3]  R699      1
    f[19,131,3]  marginal_20_3  1
    f[19,131,6]  R627      -1
    f[19,131,6]  R702      1
    f[19,131,6]  marginal_20_6  1
    f[19,132,3]  R628      -1
    f[19,132,3]  R700      1
    f[19,132,3]  marginal_20_3  1
    f[19,132,6]  R628      -1
    f[19,132,6]  R703      1
    f[19,132,6]  marginal_20_6  1
    f[19,133,3]  R629      -1
    f[19,133,3]  R701      1
    f[19,133,3]  marginal_20_3  1
    f[19,133,6]  R629      -1
    f[19,133,6]  R704      1
    f[19,133,6]  marginal_20_6  1
    f[19,134,3]  R630      -1
    f[19,134,3]  R702      1
    f[19,134,3]  marginal_20_3  1
    f[19,134,6]  R630      -1
    f[19,134,6]  R705      1
    f[19,134,6]  marginal_20_6  1
    f[19,135,3]  R631      -1
    f[19,135,3]  R703      1
    f[19,135,3]  marginal_20_3  1
    f[19,135,6]  R631      -1
    f[19,135,6]  R706      1
    f[19,135,6]  marginal_20_6  1
    f[19,136,3]  R632      -1
    f[19,136,3]  R704      1
    f[19,136,3]  marginal_20_3  1
    f[19,136,6]  R632      -1
    f[19,136,6]  R707      1
    f[19,136,6]  marginal_20_6  1
    f[19,137,3]  R633      -1
    f[19,137,3]  R705      1
    f[19,137,3]  marginal_20_3  1
    f[19,137,6]  R633      -1
    f[19,137,6]  R708      1
    f[19,137,6]  marginal_20_6  1
    f[19,138,3]  R634      -1
    f[19,138,3]  R706      1
    f[19,138,3]  marginal_20_3  1
    f[19,138,6]  R634      -1
    f[19,138,6]  R709      1
    f[19,138,6]  marginal_20_6  1
    f[19,139,3]  R635      -1
    f[19,139,3]  R707      1
    f[19,139,3]  marginal_20_3  1
    f[19,139,6]  R635      -1
    f[19,139,6]  R710      1
    f[19,139,6]  marginal_20_6  1
    f[19,140,3]  R636      -1
    f[19,140,3]  R708      1
    f[19,140,3]  marginal_20_3  1
    f[19,140,6]  R636      -1
    f[19,140,6]  R711      1
    f[19,140,6]  marginal_20_6  1
    f[19,141,3]  R637      -1
    f[19,141,3]  R709      1
    f[19,141,3]  marginal_20_3  1
    f[19,141,6]  R637      -1
    f[19,141,6]  R712      1
    f[19,141,6]  marginal_20_6  1
    f[20,76,1]  R713      -1
    f[20,76,1]  R765      1
    f[20,76,1]  marginal_21_1  1
    f[20,76,4]  R713      -1
    f[20,76,4]  R768      1
    f[20,76,4]  marginal_21_4  1
    f[20,76,7]  R713      -1
    f[20,76,7]  R771      1
    f[20,76,7]  marginal_21_7  1
    f[20,77,1]  R714      -1
    f[20,77,1]  R766      1
    f[20,77,1]  marginal_21_1  1
    f[20,77,4]  R714      -1
    f[20,77,4]  R769      1
    f[20,77,4]  marginal_21_4  1
    f[20,77,7]  R714      -1
    f[20,77,7]  R772      1
    f[20,77,7]  marginal_21_7  1
    f[20,78,1]  R715      -1
    f[20,78,1]  R767      1
    f[20,78,1]  marginal_21_1  1
    f[20,78,4]  R715      -1
    f[20,78,4]  R770      1
    f[20,78,4]  marginal_21_4  1
    f[20,78,7]  R715      -1
    f[20,78,7]  R773      1
    f[20,78,7]  marginal_21_7  1
    f[20,79,1]  R716      -1
    f[20,79,1]  R768      1
    f[20,79,1]  marginal_21_1  1
    f[20,79,4]  R716      -1
    f[20,79,4]  R771      1
    f[20,79,4]  marginal_21_4  1
    f[20,79,7]  R716      -1
    f[20,79,7]  R774      1
    f[20,79,7]  marginal_21_7  1
    f[20,80,1]  R717      -1
    f[20,80,1]  R769      1
    f[20,80,1]  marginal_21_1  1
    f[20,80,4]  R717      -1
    f[20,80,4]  R772      1
    f[20,80,4]  marginal_21_4  1
    f[20,80,7]  R717      -1
    f[20,80,7]  R775      1
    f[20,80,7]  marginal_21_7  1
    f[20,81,1]  R718      -1
    f[20,81,1]  R770      1
    f[20,81,1]  marginal_21_1  1
    f[20,81,4]  R718      -1
    f[20,81,4]  R773      1
    f[20,81,4]  marginal_21_4  1
    f[20,81,7]  R718      -1
    f[20,81,7]  R776      1
    f[20,81,7]  marginal_21_7  1
    f[20,82,1]  R719      -1
    f[20,82,1]  R771      1
    f[20,82,1]  marginal_21_1  1
    f[20,82,4]  R719      -1
    f[20,82,4]  R774      1
    f[20,82,4]  marginal_21_4  1
    f[20,82,7]  R719      -1
    f[20,82,7]  R777      1
    f[20,82,7]  marginal_21_7  1
    f[20,83,1]  R720      -1
    f[20,83,1]  R772      1
    f[20,83,1]  marginal_21_1  1
    f[20,83,4]  R720      -1
    f[20,83,4]  R775      1
    f[20,83,4]  marginal_21_4  1
    f[20,83,7]  R720      -1
    f[20,83,7]  R778      1
    f[20,83,7]  marginal_21_7  1
    f[20,84,1]  R721      -1
    f[20,84,1]  R773      1
    f[20,84,1]  marginal_21_1  1
    f[20,84,4]  R721      -1
    f[20,84,4]  R776      1
    f[20,84,4]  marginal_21_4  1
    f[20,84,7]  R721      -1
    f[20,84,7]  R779      1
    f[20,84,7]  marginal_21_7  1
    f[20,85,1]  R722      -1
    f[20,85,1]  R774      1
    f[20,85,1]  marginal_21_1  1
    f[20,85,4]  R722      -1
    f[20,85,4]  R777      1
    f[20,85,4]  marginal_21_4  1
    f[20,85,7]  R722      -1
    f[20,85,7]  R780      1
    f[20,85,7]  marginal_21_7  1
    f[20,86,1]  R723      -1
    f[20,86,1]  R775      1
    f[20,86,1]  marginal_21_1  1
    f[20,86,4]  R723      -1
    f[20,86,4]  R778      1
    f[20,86,4]  marginal_21_4  1
    f[20,86,7]  R723      -1
    f[20,86,7]  R781      1
    f[20,86,7]  marginal_21_7  1
    f[20,87,1]  R724      -1
    f[20,87,1]  R776      1
    f[20,87,1]  marginal_21_1  1
    f[20,87,4]  R724      -1
    f[20,87,4]  R779      1
    f[20,87,4]  marginal_21_4  1
    f[20,87,7]  R724      -1
    f[20,87,7]  R782      1
    f[20,87,7]  marginal_21_7  1
    f[20,88,1]  R725      -1
    f[20,88,1]  R777      1
    f[20,88,1]  marginal_21_1  1
    f[20,88,4]  R725      -1
    f[20,88,4]  R780      1
    f[20,88,4]  marginal_21_4  1
    f[20,88,7]  R725      -1
    f[20,88,7]  R783      1
    f[20,88,7]  marginal_21_7  1
    f[20,89,1]  R726      -1
    f[20,89,1]  R778      1
    f[20,89,1]  marginal_21_1  1
    f[20,89,4]  R726      -1
    f[20,89,4]  R781      1
    f[20,89,4]  marginal_21_4  1
    f[20,89,7]  R726      -1
    f[20,89,7]  R784      1
    f[20,89,7]  marginal_21_7  1
    f[20,90,1]  R727      -1
    f[20,90,1]  R779      1
    f[20,90,1]  marginal_21_1  1
    f[20,90,4]  R727      -1
    f[20,90,4]  R782      1
    f[20,90,4]  marginal_21_4  1
    f[20,90,7]  R727      -1
    f[20,90,7]  R785      1
    f[20,90,7]  marginal_21_7  1
    f[20,91,1]  R728      -1
    f[20,91,1]  R780      1
    f[20,91,1]  marginal_21_1  1
    f[20,91,4]  R728      -1
    f[20,91,4]  R783      1
    f[20,91,4]  marginal_21_4  1
    f[20,91,7]  R728      -1
    f[20,91,7]  R786      1
    f[20,91,7]  marginal_21_7  1
    f[20,92,1]  R729      -1
    f[20,92,1]  R781      1
    f[20,92,1]  marginal_21_1  1
    f[20,92,4]  R729      -1
    f[20,92,4]  R784      1
    f[20,92,4]  marginal_21_4  1
    f[20,92,7]  R729      -1
    f[20,92,7]  R787      1
    f[20,92,7]  marginal_21_7  1
    f[20,93,1]  R730      -1
    f[20,93,1]  R782      1
    f[20,93,1]  marginal_21_1  1
    f[20,93,4]  R730      -1
    f[20,93,4]  R785      1
    f[20,93,4]  marginal_21_4  1
    f[20,93,7]  R730      -1
    f[20,93,7]  R788      1
    f[20,93,7]  marginal_21_7  1
    f[20,94,1]  R731      -1
    f[20,94,1]  R783      1
    f[20,94,1]  marginal_21_1  1
    f[20,94,4]  R731      -1
    f[20,94,4]  R786      1
    f[20,94,4]  marginal_21_4  1
    f[20,94,7]  R731      -1
    f[20,94,7]  R789      1
    f[20,94,7]  marginal_21_7  1
    f[20,95,1]  R732      -1
    f[20,95,1]  R784      1
    f[20,95,1]  marginal_21_1  1
    f[20,95,4]  R732      -1
    f[20,95,4]  R787      1
    f[20,95,4]  marginal_21_4  1
    f[20,95,7]  R732      -1
    f[20,95,7]  R790      1
    f[20,95,7]  marginal_21_7  1
    f[20,96,1]  R733      -1
    f[20,96,1]  R785      1
    f[20,96,1]  marginal_21_1  1
    f[20,96,4]  R733      -1
    f[20,96,4]  R788      1
    f[20,96,4]  marginal_21_4  1
    f[20,96,7]  R733      -1
    f[20,96,7]  R791      1
    f[20,96,7]  marginal_21_7  1
    f[20,97,1]  R734      -1
    f[20,97,1]  R786      1
    f[20,97,1]  marginal_21_1  1
    f[20,97,4]  R734      -1
    f[20,97,4]  R789      1
    f[20,97,4]  marginal_21_4  1
    f[20,97,7]  R734      -1
    f[20,97,7]  R792      1
    f[20,97,7]  marginal_21_7  1
    f[20,98,1]  R735      -1
    f[20,98,1]  R787      1
    f[20,98,1]  marginal_21_1  1
    f[20,98,4]  R735      -1
    f[20,98,4]  R790      1
    f[20,98,4]  marginal_21_4  1
    f[20,98,7]  R735      -1
    f[20,98,7]  R793      1
    f[20,98,7]  marginal_21_7  1
    f[20,99,1]  R736      -1
    f[20,99,1]  R788      1
    f[20,99,1]  marginal_21_1  1
    f[20,99,4]  R736      -1
    f[20,99,4]  R791      1
    f[20,99,4]  marginal_21_4  1
    f[20,99,7]  R736      -1
    f[20,99,7]  R794      1
    f[20,99,7]  marginal_21_7  1
    f[20,100,1]  R737      -1
    f[20,100,1]  R789      1
    f[20,100,1]  marginal_21_1  1
    f[20,100,4]  R737      -1
    f[20,100,4]  R792      1
    f[20,100,4]  marginal_21_4  1
    f[20,100,7]  R737      -1
    f[20,100,7]  R795      1
    f[20,100,7]  marginal_21_7  1
    f[20,101,1]  R738      -1
    f[20,101,1]  R790      1
    f[20,101,1]  marginal_21_1  1
    f[20,101,4]  R738      -1
    f[20,101,4]  R793      1
    f[20,101,4]  marginal_21_4  1
    f[20,101,7]  R738      -1
    f[20,101,7]  R796      1
    f[20,101,7]  marginal_21_7  1
    f[20,102,1]  R739      -1
    f[20,102,1]  R791      1
    f[20,102,1]  marginal_21_1  1
    f[20,102,4]  R739      -1
    f[20,102,4]  R794      1
    f[20,102,4]  marginal_21_4  1
    f[20,102,7]  R739      -1
    f[20,102,7]  R797      1
    f[20,102,7]  marginal_21_7  1
    f[20,103,1]  R740      -1
    f[20,103,1]  R792      1
    f[20,103,1]  marginal_21_1  1
    f[20,103,4]  R740      -1
    f[20,103,4]  R795      1
    f[20,103,4]  marginal_21_4  1
    f[20,103,7]  R740      -1
    f[20,103,7]  R798      1
    f[20,103,7]  marginal_21_7  1
    f[20,104,1]  R741      -1
    f[20,104,1]  R793      1
    f[20,104,1]  marginal_21_1  1
    f[20,104,4]  R741      -1
    f[20,104,4]  R796      1
    f[20,104,4]  marginal_21_4  1
    f[20,104,7]  R741      -1
    f[20,104,7]  R799      1
    f[20,104,7]  marginal_21_7  1
    f[20,105,1]  R742      -1
    f[20,105,1]  R794      1
    f[20,105,1]  marginal_21_1  1
    f[20,105,4]  R742      -1
    f[20,105,4]  R797      1
    f[20,105,4]  marginal_21_4  1
    f[20,105,7]  R742      -1
    f[20,105,7]  R800      1
    f[20,105,7]  marginal_21_7  1
    f[20,106,1]  R743      -1
    f[20,106,1]  R795      1
    f[20,106,1]  marginal_21_1  1
    f[20,106,4]  R743      -1
    f[20,106,4]  R798      1
    f[20,106,4]  marginal_21_4  1
    f[20,106,7]  R743      -1
    f[20,106,7]  R801      1
    f[20,106,7]  marginal_21_7  1
    f[20,107,1]  R744      -1
    f[20,107,1]  R796      1
    f[20,107,1]  marginal_21_1  1
    f[20,107,4]  R744      -1
    f[20,107,4]  R799      1
    f[20,107,4]  marginal_21_4  1
    f[20,107,7]  R744      -1
    f[20,107,7]  R802      1
    f[20,107,7]  marginal_21_7  1
    f[20,108,1]  R745      -1
    f[20,108,1]  R797      1
    f[20,108,1]  marginal_21_1  1
    f[20,108,4]  R745      -1
    f[20,108,4]  R800      1
    f[20,108,4]  marginal_21_4  1
    f[20,108,7]  R745      -1
    f[20,108,7]  R803      1
    f[20,108,7]  marginal_21_7  1
    f[20,109,1]  R746      -1
    f[20,109,1]  R798      1
    f[20,109,1]  marginal_21_1  1
    f[20,109,4]  R746      -1
    f[20,109,4]  R801      1
    f[20,109,4]  marginal_21_4  1
    f[20,109,7]  R746      -1
    f[20,109,7]  R804      1
    f[20,109,7]  marginal_21_7  1
    f[20,110,1]  R747      -1
    f[20,110,1]  R799      1
    f[20,110,1]  marginal_21_1  1
    f[20,110,4]  R747      -1
    f[20,110,4]  R802      1
    f[20,110,4]  marginal_21_4  1
    f[20,110,7]  R747      -1
    f[20,110,7]  R805      1
    f[20,110,7]  marginal_21_7  1
    f[20,111,1]  R748      -1
    f[20,111,1]  R800      1
    f[20,111,1]  marginal_21_1  1
    f[20,111,4]  R748      -1
    f[20,111,4]  R803      1
    f[20,111,4]  marginal_21_4  1
    f[20,111,7]  R748      -1
    f[20,111,7]  R806      1
    f[20,111,7]  marginal_21_7  1
    f[20,112,1]  R749      -1
    f[20,112,1]  R801      1
    f[20,112,1]  marginal_21_1  1
    f[20,112,4]  R749      -1
    f[20,112,4]  R804      1
    f[20,112,4]  marginal_21_4  1
    f[20,112,7]  R749      -1
    f[20,112,7]  R807      1
    f[20,112,7]  marginal_21_7  1
    f[20,113,1]  R750      -1
    f[20,113,1]  R802      1
    f[20,113,1]  marginal_21_1  1
    f[20,113,4]  R750      -1
    f[20,113,4]  R805      1
    f[20,113,4]  marginal_21_4  1
    f[20,113,7]  R750      -1
    f[20,113,7]  R808      1
    f[20,113,7]  marginal_21_7  1
    f[20,114,1]  R751      -1
    f[20,114,1]  R803      1
    f[20,114,1]  marginal_21_1  1
    f[20,114,4]  R751      -1
    f[20,114,4]  R806      1
    f[20,114,4]  marginal_21_4  1
    f[20,114,7]  R751      -1
    f[20,114,7]  R809      1
    f[20,114,7]  marginal_21_7  1
    f[20,115,1]  R752      -1
    f[20,115,1]  R804      1
    f[20,115,1]  marginal_21_1  1
    f[20,115,4]  R752      -1
    f[20,115,4]  R807      1
    f[20,115,4]  marginal_21_4  1
    f[20,115,7]  R752      -1
    f[20,115,7]  R810      1
    f[20,115,7]  marginal_21_7  1
    f[20,116,1]  R753      -1
    f[20,116,1]  R805      1
    f[20,116,1]  marginal_21_1  1
    f[20,116,4]  R753      -1
    f[20,116,4]  R808      1
    f[20,116,4]  marginal_21_4  1
    f[20,116,7]  R753      -1
    f[20,116,7]  R811      1
    f[20,116,7]  marginal_21_7  1
    f[20,117,1]  R754      -1
    f[20,117,1]  R806      1
    f[20,117,1]  marginal_21_1  1
    f[20,117,4]  R754      -1
    f[20,117,4]  R809      1
    f[20,117,4]  marginal_21_4  1
    f[20,117,7]  R754      -1
    f[20,117,7]  R812      1
    f[20,117,7]  marginal_21_7  1
    f[20,118,1]  R755      -1
    f[20,118,1]  R807      1
    f[20,118,1]  marginal_21_1  1
    f[20,118,4]  R755      -1
    f[20,118,4]  R810      1
    f[20,118,4]  marginal_21_4  1
    f[20,118,7]  R755      -1
    f[20,118,7]  R813      1
    f[20,118,7]  marginal_21_7  1
    f[20,119,1]  R756      -1
    f[20,119,1]  R808      1
    f[20,119,1]  marginal_21_1  1
    f[20,119,4]  R756      -1
    f[20,119,4]  R811      1
    f[20,119,4]  marginal_21_4  1
    f[20,119,7]  R756      -1
    f[20,119,7]  R814      1
    f[20,119,7]  marginal_21_7  1
    f[20,120,1]  R757      -1
    f[20,120,1]  R809      1
    f[20,120,1]  marginal_21_1  1
    f[20,120,4]  R757      -1
    f[20,120,4]  R812      1
    f[20,120,4]  marginal_21_4  1
    f[20,120,7]  R757      -1
    f[20,120,7]  R815      1
    f[20,120,7]  marginal_21_7  1
    f[20,121,1]  R758      -1
    f[20,121,1]  R810      1
    f[20,121,1]  marginal_21_1  1
    f[20,121,4]  R758      -1
    f[20,121,4]  R813      1
    f[20,121,4]  marginal_21_4  1
    f[20,121,7]  R758      -1
    f[20,121,7]  R816      1
    f[20,121,7]  marginal_21_7  1
    f[20,122,1]  R759      -1
    f[20,122,1]  R811      1
    f[20,122,1]  marginal_21_1  1
    f[20,122,4]  R759      -1
    f[20,122,4]  R814      1
    f[20,122,4]  marginal_21_4  1
    f[20,122,7]  R759      -1
    f[20,122,7]  R817      1
    f[20,122,7]  marginal_21_7  1
    f[20,123,1]  R760      -1
    f[20,123,1]  R812      1
    f[20,123,1]  marginal_21_1  1
    f[20,123,4]  R760      -1
    f[20,123,4]  R815      1
    f[20,123,4]  marginal_21_4  1
    f[20,123,7]  R760      -1
    f[20,123,7]  R818      1
    f[20,123,7]  marginal_21_7  1
    f[20,124,1]  R761      -1
    f[20,124,1]  R813      1
    f[20,124,1]  marginal_21_1  1
    f[20,124,4]  R761      -1
    f[20,124,4]  R816      1
    f[20,124,4]  marginal_21_4  1
    f[20,124,7]  R761      -1
    f[20,124,7]  R819      1
    f[20,124,7]  marginal_21_7  1
    f[20,125,1]  R762      -1
    f[20,125,1]  R814      1
    f[20,125,1]  marginal_21_1  1
    f[20,125,4]  R762      -1
    f[20,125,4]  R817      1
    f[20,125,4]  marginal_21_4  1
    f[20,125,7]  R762      -1
    f[20,125,7]  R820      1
    f[20,125,7]  marginal_21_7  1
    f[20,126,1]  R763      -1
    f[20,126,1]  R815      1
    f[20,126,1]  marginal_21_1  1
    f[20,126,4]  R763      -1
    f[20,126,4]  R818      1
    f[20,126,4]  marginal_21_4  1
    f[20,126,7]  R763      -1
    f[20,126,7]  R821      1
    f[20,126,7]  marginal_21_7  1
    f[20,127,1]  R764      -1
    f[20,127,1]  R816      1
    f[20,127,1]  marginal_21_1  1
    f[20,127,4]  R764      -1
    f[20,127,4]  R819      1
    f[20,127,4]  marginal_21_4  1
    f[20,127,7]  R764      -1
    f[20,127,7]  R822      1
    f[20,127,7]  marginal_21_7  1
    f[20,128,1]  R693      -1
    f[20,128,1]  R817      1
    f[20,128,1]  marginal_21_1  1
    f[20,128,4]  R693      -1
    f[20,128,4]  R820      1
    f[20,128,4]  marginal_21_4  1
    f[20,128,7]  R693      -1
    f[20,128,7]  R823      1
    f[20,128,7]  marginal_21_7  1
    f[20,129,1]  R694      -1
    f[20,129,1]  R818      1
    f[20,129,1]  marginal_21_1  1
    f[20,129,4]  R694      -1
    f[20,129,4]  R821      1
    f[20,129,4]  marginal_21_4  1
    f[20,129,7]  R694      -1
    f[20,129,7]  R824      1
    f[20,129,7]  marginal_21_7  1
    f[20,130,1]  R695      -1
    f[20,130,1]  R819      1
    f[20,130,1]  marginal_21_1  1
    f[20,130,4]  R695      -1
    f[20,130,4]  R822      1
    f[20,130,4]  marginal_21_4  1
    f[20,130,7]  R695      -1
    f[20,130,7]  R825      1
    f[20,130,7]  marginal_21_7  1
    f[20,131,1]  R696      -1
    f[20,131,1]  R820      1
    f[20,131,1]  marginal_21_1  1
    f[20,131,4]  R696      -1
    f[20,131,4]  R823      1
    f[20,131,4]  marginal_21_4  1
    f[20,131,7]  R696      -1
    f[20,131,7]  R826      1
    f[20,131,7]  marginal_21_7  1
    f[20,132,1]  R697      -1
    f[20,132,1]  R821      1
    f[20,132,1]  marginal_21_1  1
    f[20,132,4]  R697      -1
    f[20,132,4]  R824      1
    f[20,132,4]  marginal_21_4  1
    f[20,132,7]  R697      -1
    f[20,132,7]  R827      1
    f[20,132,7]  marginal_21_7  1
    f[20,133,1]  R698      -1
    f[20,133,1]  R822      1
    f[20,133,1]  marginal_21_1  1
    f[20,133,4]  R698      -1
    f[20,133,4]  R825      1
    f[20,133,4]  marginal_21_4  1
    f[20,133,7]  R698      -1
    f[20,133,7]  R828      1
    f[20,133,7]  marginal_21_7  1
    f[20,134,1]  R699      -1
    f[20,134,1]  R823      1
    f[20,134,1]  marginal_21_1  1
    f[20,134,4]  R699      -1
    f[20,134,4]  R826      1
    f[20,134,4]  marginal_21_4  1
    f[20,134,7]  R699      -1
    f[20,134,7]  R829      1
    f[20,134,7]  marginal_21_7  1
    f[20,135,1]  R700      -1
    f[20,135,1]  R824      1
    f[20,135,1]  marginal_21_1  1
    f[20,135,4]  R700      -1
    f[20,135,4]  R827      1
    f[20,135,4]  marginal_21_4  1
    f[20,135,7]  R700      -1
    f[20,135,7]  R830      1
    f[20,135,7]  marginal_21_7  1
    f[20,136,1]  R701      -1
    f[20,136,1]  R825      1
    f[20,136,1]  marginal_21_1  1
    f[20,136,4]  R701      -1
    f[20,136,4]  R828      1
    f[20,136,4]  marginal_21_4  1
    f[20,136,7]  R701      -1
    f[20,136,7]  R831      1
    f[20,136,7]  marginal_21_7  1
    f[20,137,1]  R702      -1
    f[20,137,1]  R826      1
    f[20,137,1]  marginal_21_1  1
    f[20,137,4]  R702      -1
    f[20,137,4]  R829      1
    f[20,137,4]  marginal_21_4  1
    f[20,137,7]  R702      -1
    f[20,137,7]  R832      1
    f[20,137,7]  marginal_21_7  1
    f[20,138,1]  R703      -1
    f[20,138,1]  R827      1
    f[20,138,1]  marginal_21_1  1
    f[20,138,4]  R703      -1
    f[20,138,4]  R830      1
    f[20,138,4]  marginal_21_4  1
    f[20,138,7]  R703      -1
    f[20,138,7]  R833      1
    f[20,138,7]  marginal_21_7  1
    f[20,139,1]  R704      -1
    f[20,139,1]  R828      1
    f[20,139,1]  marginal_21_1  1
    f[20,139,4]  R704      -1
    f[20,139,4]  R831      1
    f[20,139,4]  marginal_21_4  1
    f[20,139,7]  R704      -1
    f[20,139,7]  R834      1
    f[20,139,7]  marginal_21_7  1
    f[20,140,1]  R705      -1
    f[20,140,1]  R829      1
    f[20,140,1]  marginal_21_1  1
    f[20,140,4]  R705      -1
    f[20,140,4]  R832      1
    f[20,140,4]  marginal_21_4  1
    f[20,140,7]  R705      -1
    f[20,140,7]  R835      1
    f[20,140,7]  marginal_21_7  1
    f[20,141,1]  R706      -1
    f[20,141,1]  R830      1
    f[20,141,1]  marginal_21_1  1
    f[20,141,4]  R706      -1
    f[20,141,4]  R833      1
    f[20,141,4]  marginal_21_4  1
    f[20,141,7]  R706      -1
    f[20,141,7]  R836      1
    f[20,141,7]  marginal_21_7  1
    f[20,142,1]  R707      -1
    f[20,142,1]  R831      1
    f[20,142,1]  marginal_21_1  1
    f[20,142,4]  R707      -1
    f[20,142,4]  R834      1
    f[20,142,4]  marginal_21_4  1
    f[20,142,7]  R707      -1
    f[20,142,7]  R837      1
    f[20,142,7]  marginal_21_7  1
    f[20,143,1]  R708      -1
    f[20,143,1]  R832      1
    f[20,143,1]  marginal_21_1  1
    f[20,143,4]  R708      -1
    f[20,143,4]  R835      1
    f[20,143,4]  marginal_21_4  1
    f[20,143,7]  R708      -1
    f[20,143,7]  R838      1
    f[20,143,7]  marginal_21_7  1
    f[20,144,1]  R709      -1
    f[20,144,1]  R833      1
    f[20,144,1]  marginal_21_1  1
    f[20,144,4]  R709      -1
    f[20,144,4]  R836      1
    f[20,144,4]  marginal_21_4  1
    f[20,144,7]  R709      -1
    f[20,144,7]  R839      1
    f[20,144,7]  marginal_21_7  1
    f[20,145,1]  R710      -1
    f[20,145,1]  R834      1
    f[20,145,1]  marginal_21_1  1
    f[20,145,4]  R710      -1
    f[20,145,4]  R837      1
    f[20,145,4]  marginal_21_4  1
    f[20,145,7]  R710      -1
    f[20,145,7]  R840      1
    f[20,145,7]  marginal_21_7  1
    f[20,146,1]  R711      -1
    f[20,146,1]  R835      1
    f[20,146,1]  marginal_21_1  1
    f[20,146,4]  R711      -1
    f[20,146,4]  R838      1
    f[20,146,4]  marginal_21_4  1
    f[20,146,7]  R711      -1
    f[20,146,7]  R841      1
    f[20,146,7]  marginal_21_7  1
    f[20,147,1]  R712      -1
    f[20,147,1]  R836      1
    f[20,147,1]  marginal_21_1  1
    f[20,147,4]  R712      -1
    f[20,147,4]  R839      1
    f[20,147,4]  marginal_21_4  1
    f[21,77,5]  R765      -1
    f[21,77,5]  R842      1
    f[21,77,5]  marginal_22_5  1
    f[21,77,6]  R765      -1
    f[21,77,6]  R843      1
    f[21,77,6]  marginal_22_6  1
    f[21,78,5]  R766      -1
    f[21,78,5]  R843      1
    f[21,78,5]  marginal_22_5  1
    f[21,78,6]  R766      -1
    f[21,78,6]  R844      1
    f[21,78,6]  marginal_22_6  1
    f[21,79,5]  R767      -1
    f[21,79,5]  R844      1
    f[21,79,5]  marginal_22_5  1
    f[21,79,6]  R767      -1
    f[21,79,6]  R845      1
    f[21,79,6]  marginal_22_6  1
    f[21,80,5]  R768      -1
    f[21,80,5]  R845      1
    f[21,80,5]  marginal_22_5  1
    f[21,80,6]  R768      -1
    f[21,80,6]  R846      1
    f[21,80,6]  marginal_22_6  1
    f[21,81,5]  R769      -1
    f[21,81,5]  R846      1
    f[21,81,5]  marginal_22_5  1
    f[21,81,6]  R769      -1
    f[21,81,6]  R847      1
    f[21,81,6]  marginal_22_6  1
    f[21,82,5]  R770      -1
    f[21,82,5]  R847      1
    f[21,82,5]  marginal_22_5  1
    f[21,82,6]  R770      -1
    f[21,82,6]  R848      1
    f[21,82,6]  marginal_22_6  1
    f[21,83,5]  R771      -1
    f[21,83,5]  R848      1
    f[21,83,5]  marginal_22_5  1
    f[21,83,6]  R771      -1
    f[21,83,6]  R849      1
    f[21,83,6]  marginal_22_6  1
    f[21,84,5]  R772      -1
    f[21,84,5]  R849      1
    f[21,84,5]  marginal_22_5  1
    f[21,84,6]  R772      -1
    f[21,84,6]  R850      1
    f[21,84,6]  marginal_22_6  1
    f[21,85,5]  R773      -1
    f[21,85,5]  R850      1
    f[21,85,5]  marginal_22_5  1
    f[21,85,6]  R773      -1
    f[21,85,6]  R851      1
    f[21,85,6]  marginal_22_6  1
    f[21,86,5]  R774      -1
    f[21,86,5]  R851      1
    f[21,86,5]  marginal_22_5  1
    f[21,86,6]  R774      -1
    f[21,86,6]  R852      1
    f[21,86,6]  marginal_22_6  1
    f[21,87,5]  R775      -1
    f[21,87,5]  R852      1
    f[21,87,5]  marginal_22_5  1
    f[21,87,6]  R775      -1
    f[21,87,6]  R853      1
    f[21,87,6]  marginal_22_6  1
    f[21,88,5]  R776      -1
    f[21,88,5]  R853      1
    f[21,88,5]  marginal_22_5  1
    f[21,88,6]  R776      -1
    f[21,88,6]  R854      1
    f[21,88,6]  marginal_22_6  1
    f[21,89,5]  R777      -1
    f[21,89,5]  R854      1
    f[21,89,5]  marginal_22_5  1
    f[21,89,6]  R777      -1
    f[21,89,6]  R855      1
    f[21,89,6]  marginal_22_6  1
    f[21,90,5]  R778      -1
    f[21,90,5]  R855      1
    f[21,90,5]  marginal_22_5  1
    f[21,90,6]  R778      -1
    f[21,90,6]  R856      1
    f[21,90,6]  marginal_22_6  1
    f[21,91,5]  R779      -1
    f[21,91,5]  R856      1
    f[21,91,5]  marginal_22_5  1
    f[21,91,6]  R779      -1
    f[21,91,6]  R857      1
    f[21,91,6]  marginal_22_6  1
    f[21,92,5]  R780      -1
    f[21,92,5]  R857      1
    f[21,92,5]  marginal_22_5  1
    f[21,92,6]  R780      -1
    f[21,92,6]  R858      1
    f[21,92,6]  marginal_22_6  1
    f[21,93,5]  R781      -1
    f[21,93,5]  R858      1
    f[21,93,5]  marginal_22_5  1
    f[21,93,6]  R781      -1
    f[21,93,6]  R859      1
    f[21,93,6]  marginal_22_6  1
    f[21,94,5]  R782      -1
    f[21,94,5]  R859      1
    f[21,94,5]  marginal_22_5  1
    f[21,94,6]  R782      -1
    f[21,94,6]  R860      1
    f[21,94,6]  marginal_22_6  1
    f[21,95,5]  R783      -1
    f[21,95,5]  R860      1
    f[21,95,5]  marginal_22_5  1
    f[21,95,6]  R783      -1
    f[21,95,6]  R861      1
    f[21,95,6]  marginal_22_6  1
    f[21,96,5]  R784      -1
    f[21,96,5]  R861      1
    f[21,96,5]  marginal_22_5  1
    f[21,96,6]  R784      -1
    f[21,96,6]  R862      1
    f[21,96,6]  marginal_22_6  1
    f[21,97,5]  R785      -1
    f[21,97,5]  R862      1
    f[21,97,5]  marginal_22_5  1
    f[21,97,6]  R785      -1
    f[21,97,6]  R863      1
    f[21,97,6]  marginal_22_6  1
    f[21,98,5]  R786      -1
    f[21,98,5]  R863      1
    f[21,98,5]  marginal_22_5  1
    f[21,98,6]  R786      -1
    f[21,98,6]  R864      1
    f[21,98,6]  marginal_22_6  1
    f[21,99,5]  R787      -1
    f[21,99,5]  R864      1
    f[21,99,5]  marginal_22_5  1
    f[21,99,6]  R787      -1
    f[21,99,6]  R865      1
    f[21,99,6]  marginal_22_6  1
    f[21,100,5]  R788      -1
    f[21,100,5]  R865      1
    f[21,100,5]  marginal_22_5  1
    f[21,100,6]  R788      -1
    f[21,100,6]  R866      1
    f[21,100,6]  marginal_22_6  1
    f[21,101,5]  R789      -1
    f[21,101,5]  R866      1
    f[21,101,5]  marginal_22_5  1
    f[21,101,6]  R789      -1
    f[21,101,6]  R867      1
    f[21,101,6]  marginal_22_6  1
    f[21,102,5]  R790      -1
    f[21,102,5]  R867      1
    f[21,102,5]  marginal_22_5  1
    f[21,102,6]  R790      -1
    f[21,102,6]  R868      1
    f[21,102,6]  marginal_22_6  1
    f[21,103,5]  R791      -1
    f[21,103,5]  R868      1
    f[21,103,5]  marginal_22_5  1
    f[21,103,6]  R791      -1
    f[21,103,6]  R869      1
    f[21,103,6]  marginal_22_6  1
    f[21,104,5]  R792      -1
    f[21,104,5]  R869      1
    f[21,104,5]  marginal_22_5  1
    f[21,104,6]  R792      -1
    f[21,104,6]  R870      1
    f[21,104,6]  marginal_22_6  1
    f[21,105,5]  R793      -1
    f[21,105,5]  R870      1
    f[21,105,5]  marginal_22_5  1
    f[21,105,6]  R793      -1
    f[21,105,6]  R871      1
    f[21,105,6]  marginal_22_6  1
    f[21,106,5]  R794      -1
    f[21,106,5]  R871      1
    f[21,106,5]  marginal_22_5  1
    f[21,106,6]  R794      -1
    f[21,106,6]  R872      1
    f[21,106,6]  marginal_22_6  1
    f[21,107,5]  R795      -1
    f[21,107,5]  R872      1
    f[21,107,5]  marginal_22_5  1
    f[21,107,6]  R795      -1
    f[21,107,6]  R873      1
    f[21,107,6]  marginal_22_6  1
    f[21,108,5]  R796      -1
    f[21,108,5]  R873      1
    f[21,108,5]  marginal_22_5  1
    f[21,108,6]  R796      -1
    f[21,108,6]  R874      1
    f[21,108,6]  marginal_22_6  1
    f[21,109,5]  R797      -1
    f[21,109,5]  R874      1
    f[21,109,5]  marginal_22_5  1
    f[21,109,6]  R797      -1
    f[21,109,6]  R875      1
    f[21,109,6]  marginal_22_6  1
    f[21,110,5]  R798      -1
    f[21,110,5]  R875      1
    f[21,110,5]  marginal_22_5  1
    f[21,110,6]  R798      -1
    f[21,110,6]  R876      1
    f[21,110,6]  marginal_22_6  1
    f[21,111,5]  R799      -1
    f[21,111,5]  R876      1
    f[21,111,5]  marginal_22_5  1
    f[21,111,6]  R799      -1
    f[21,111,6]  R877      1
    f[21,111,6]  marginal_22_6  1
    f[21,112,5]  R800      -1
    f[21,112,5]  R877      1
    f[21,112,5]  marginal_22_5  1
    f[21,112,6]  R800      -1
    f[21,112,6]  R878      1
    f[21,112,6]  marginal_22_6  1
    f[21,113,5]  R801      -1
    f[21,113,5]  R878      1
    f[21,113,5]  marginal_22_5  1
    f[21,113,6]  R801      -1
    f[21,113,6]  R879      1
    f[21,113,6]  marginal_22_6  1
    f[21,114,5]  R802      -1
    f[21,114,5]  R879      1
    f[21,114,5]  marginal_22_5  1
    f[21,114,6]  R802      -1
    f[21,114,6]  R880      1
    f[21,114,6]  marginal_22_6  1
    f[21,115,5]  R803      -1
    f[21,115,5]  R880      1
    f[21,115,5]  marginal_22_5  1
    f[21,115,6]  R803      -1
    f[21,115,6]  R881      1
    f[21,115,6]  marginal_22_6  1
    f[21,116,5]  R804      -1
    f[21,116,5]  R881      1
    f[21,116,5]  marginal_22_5  1
    f[21,116,6]  R804      -1
    f[21,116,6]  R882      1
    f[21,116,6]  marginal_22_6  1
    f[21,117,5]  R805      -1
    f[21,117,5]  R882      1
    f[21,117,5]  marginal_22_5  1
    f[21,117,6]  R805      -1
    f[21,117,6]  R883      1
    f[21,117,6]  marginal_22_6  1
    f[21,118,5]  R806      -1
    f[21,118,5]  R883      1
    f[21,118,5]  marginal_22_5  1
    f[21,118,6]  R806      -1
    f[21,118,6]  R884      1
    f[21,118,6]  marginal_22_6  1
    f[21,119,5]  R807      -1
    f[21,119,5]  R884      1
    f[21,119,5]  marginal_22_5  1
    f[21,119,6]  R807      -1
    f[21,119,6]  R885      1
    f[21,119,6]  marginal_22_6  1
    f[21,120,5]  R808      -1
    f[21,120,5]  R885      1
    f[21,120,5]  marginal_22_5  1
    f[21,120,6]  R808      -1
    f[21,120,6]  R886      1
    f[21,120,6]  marginal_22_6  1
    f[21,121,5]  R809      -1
    f[21,121,5]  R886      1
    f[21,121,5]  marginal_22_5  1
    f[21,121,6]  R809      -1
    f[21,121,6]  R887      1
    f[21,121,6]  marginal_22_6  1
    f[21,122,5]  R810      -1
    f[21,122,5]  R887      1
    f[21,122,5]  marginal_22_5  1
    f[21,122,6]  R810      -1
    f[21,122,6]  R888      1
    f[21,122,6]  marginal_22_6  1
    f[21,123,5]  R811      -1
    f[21,123,5]  R888      1
    f[21,123,5]  marginal_22_5  1
    f[21,123,6]  R811      -1
    f[21,123,6]  R889      1
    f[21,123,6]  marginal_22_6  1
    f[21,124,5]  R812      -1
    f[21,124,5]  R889      1
    f[21,124,5]  marginal_22_5  1
    f[21,124,6]  R812      -1
    f[21,124,6]  R890      1
    f[21,124,6]  marginal_22_6  1
    f[21,125,5]  R813      -1
    f[21,125,5]  R890      1
    f[21,125,5]  marginal_22_5  1
    f[21,125,6]  R813      -1
    f[21,125,6]  R891      1
    f[21,125,6]  marginal_22_6  1
    f[21,126,5]  R814      -1
    f[21,126,5]  R891      1
    f[21,126,5]  marginal_22_5  1
    f[21,126,6]  R814      -1
    f[21,126,6]  R892      1
    f[21,126,6]  marginal_22_6  1
    f[21,127,5]  R815      -1
    f[21,127,5]  R892      1
    f[21,127,5]  marginal_22_5  1
    f[21,127,6]  R815      -1
    f[21,127,6]  R893      1
    f[21,127,6]  marginal_22_6  1
    f[21,128,5]  R816      -1
    f[21,128,5]  R893      1
    f[21,128,5]  marginal_22_5  1
    f[21,128,6]  R816      -1
    f[21,128,6]  R894      1
    f[21,128,6]  marginal_22_6  1
    f[21,129,5]  R817      -1
    f[21,129,5]  R894      1
    f[21,129,5]  marginal_22_5  1
    f[21,129,6]  R817      -1
    f[21,129,6]  R895      1
    f[21,129,6]  marginal_22_6  1
    f[21,130,5]  R818      -1
    f[21,130,5]  R895      1
    f[21,130,5]  marginal_22_5  1
    f[21,130,6]  R818      -1
    f[21,130,6]  R896      1
    f[21,130,6]  marginal_22_6  1
    f[21,131,5]  R819      -1
    f[21,131,5]  R896      1
    f[21,131,5]  marginal_22_5  1
    f[21,131,6]  R819      -1
    f[21,131,6]  R897      1
    f[21,131,6]  marginal_22_6  1
    f[21,132,5]  R820      -1
    f[21,132,5]  R897      1
    f[21,132,5]  marginal_22_5  1
    f[21,132,6]  R820      -1
    f[21,132,6]  R898      1
    f[21,132,6]  marginal_22_6  1
    f[21,133,5]  R821      -1
    f[21,133,5]  R898      1
    f[21,133,5]  marginal_22_5  1
    f[21,133,6]  R821      -1
    f[21,133,6]  R899      1
    f[21,133,6]  marginal_22_6  1
    f[21,134,5]  R822      -1
    f[21,134,5]  R899      1
    f[21,134,5]  marginal_22_5  1
    f[21,134,6]  R822      -1
    f[21,134,6]  R900      1
    f[21,134,6]  marginal_22_6  1
    f[21,135,5]  R823      -1
    f[21,135,5]  R900      1
    f[21,135,5]  marginal_22_5  1
    f[21,135,6]  R823      -1
    f[21,135,6]  R901      1
    f[21,135,6]  marginal_22_6  1
    f[21,136,5]  R824      -1
    f[21,136,5]  R901      1
    f[21,136,5]  marginal_22_5  1
    f[21,136,6]  R824      -1
    f[21,136,6]  R902      1
    f[21,136,6]  marginal_22_6  1
    f[21,137,5]  R825      -1
    f[21,137,5]  R902      1
    f[21,137,5]  marginal_22_5  1
    f[21,137,6]  R825      -1
    f[21,137,6]  R903      1
    f[21,137,6]  marginal_22_6  1
    f[21,138,5]  R826      -1
    f[21,138,5]  R903      1
    f[21,138,5]  marginal_22_5  1
    f[21,138,6]  R826      -1
    f[21,138,6]  R904      1
    f[21,138,6]  marginal_22_6  1
    f[21,139,5]  R827      -1
    f[21,139,5]  R904      1
    f[21,139,5]  marginal_22_5  1
    f[21,139,6]  R827      -1
    f[21,139,6]  R905      1
    f[21,139,6]  marginal_22_6  1
    f[21,140,5]  R828      -1
    f[21,140,5]  R905      1
    f[21,140,5]  marginal_22_5  1
    f[21,140,6]  R828      -1
    f[21,140,6]  R906      1
    f[21,140,6]  marginal_22_6  1
    f[21,141,5]  R829      -1
    f[21,141,5]  R906      1
    f[21,141,5]  marginal_22_5  1
    f[21,141,6]  R829      -1
    f[21,141,6]  R907      1
    f[21,141,6]  marginal_22_6  1
    f[21,142,5]  R830      -1
    f[21,142,5]  R907      1
    f[21,142,5]  marginal_22_5  1
    f[21,142,6]  R830      -1
    f[21,142,6]  R908      1
    f[21,142,6]  marginal_22_6  1
    f[21,143,5]  R831      -1
    f[21,143,5]  R908      1
    f[21,143,5]  marginal_22_5  1
    f[21,143,6]  R831      -1
    f[21,143,6]  R909      1
    f[21,143,6]  marginal_22_6  1
    f[21,144,5]  R832      -1
    f[21,144,5]  R909      1
    f[21,144,5]  marginal_22_5  1
    f[21,144,6]  R832      -1
    f[21,144,6]  R910      1
    f[21,144,6]  marginal_22_6  1
    f[21,145,5]  R833      -1
    f[21,145,5]  R910      1
    f[21,145,5]  marginal_22_5  1
    f[21,145,6]  R833      -1
    f[21,145,6]  R911      1
    f[21,145,6]  marginal_22_6  1
    f[21,146,5]  R834      -1
    f[21,146,5]  R911      1
    f[21,146,5]  marginal_22_5  1
    f[21,146,6]  R834      -1
    f[21,146,6]  R912      1
    f[21,146,6]  marginal_22_6  1
    f[21,147,5]  R835      -1
    f[21,147,5]  R912      1
    f[21,147,5]  marginal_22_5  1
    f[21,147,6]  R835      -1
    f[21,147,6]  R913      1
    f[21,147,6]  marginal_22_6  1
    f[21,148,5]  R836      -1
    f[21,148,5]  R913      1
    f[21,148,5]  marginal_22_5  1
    f[21,148,6]  R836      -1
    f[21,148,6]  R914      1
    f[21,148,6]  marginal_22_6  1
    f[21,149,5]  R837      -1
    f[21,149,5]  R914      1
    f[21,149,5]  marginal_22_5  1
    f[21,149,6]  R837      -1
    f[21,149,6]  R915      1
    f[21,149,6]  marginal_22_6  1
    f[21,150,5]  R838      -1
    f[21,150,5]  R915      1
    f[21,150,5]  marginal_22_5  1
    f[21,150,6]  R838      -1
    f[21,150,6]  R916      1
    f[21,150,6]  marginal_22_6  1
    f[21,151,5]  R839      -1
    f[21,151,5]  R916      1
    f[21,151,5]  marginal_22_5  1
    f[21,151,6]  R839      -1
    f[21,151,6]  R917      1
    f[21,151,6]  marginal_22_6  1
    f[21,152,5]  R840      -1
    f[21,152,5]  R917      1
    f[21,152,5]  marginal_22_5  1
    f[21,152,6]  R840      -1
    f[21,152,6]  R918      1
    f[21,152,6]  marginal_22_6  1
    f[21,153,5]  R841      -1
    f[21,153,5]  R918      1
    f[21,153,5]  marginal_22_5  1
    f[22,82,3]  R842      -1
    f[22,82,3]  R919      1
    f[22,82,3]  marginal_23_3  1
    f[22,82,4]  R842      -1
    f[22,82,4]  R920      1
    f[22,82,4]  marginal_23_4  1
    f[22,82,5]  R842      -1
    f[22,82,5]  R921      1
    f[22,82,5]  marginal_23_5  1
    f[22,83,3]  R843      -1
    f[22,83,3]  R920      1
    f[22,83,3]  marginal_23_3  1
    f[22,83,4]  R843      -1
    f[22,83,4]  R921      1
    f[22,83,4]  marginal_23_4  1
    f[22,83,5]  R843      -1
    f[22,83,5]  R922      1
    f[22,83,5]  marginal_23_5  1
    f[22,84,3]  R844      -1
    f[22,84,3]  R921      1
    f[22,84,3]  marginal_23_3  1
    f[22,84,4]  R844      -1
    f[22,84,4]  R922      1
    f[22,84,4]  marginal_23_4  1
    f[22,84,5]  R844      -1
    f[22,84,5]  R923      1
    f[22,84,5]  marginal_23_5  1
    f[22,85,3]  R845      -1
    f[22,85,3]  R922      1
    f[22,85,3]  marginal_23_3  1
    f[22,85,4]  R845      -1
    f[22,85,4]  R923      1
    f[22,85,4]  marginal_23_4  1
    f[22,85,5]  R845      -1
    f[22,85,5]  R924      1
    f[22,85,5]  marginal_23_5  1
    f[22,86,3]  R846      -1
    f[22,86,3]  R923      1
    f[22,86,3]  marginal_23_3  1
    f[22,86,4]  R846      -1
    f[22,86,4]  R924      1
    f[22,86,4]  marginal_23_4  1
    f[22,86,5]  R846      -1
    f[22,86,5]  R925      1
    f[22,86,5]  marginal_23_5  1
    f[22,87,3]  R847      -1
    f[22,87,3]  R924      1
    f[22,87,3]  marginal_23_3  1
    f[22,87,4]  R847      -1
    f[22,87,4]  R925      1
    f[22,87,4]  marginal_23_4  1
    f[22,87,5]  R847      -1
    f[22,87,5]  R926      1
    f[22,87,5]  marginal_23_5  1
    f[22,88,3]  R848      -1
    f[22,88,3]  R925      1
    f[22,88,3]  marginal_23_3  1
    f[22,88,4]  R848      -1
    f[22,88,4]  R926      1
    f[22,88,4]  marginal_23_4  1
    f[22,88,5]  R848      -1
    f[22,88,5]  R927      1
    f[22,88,5]  marginal_23_5  1
    f[22,89,3]  R849      -1
    f[22,89,3]  R926      1
    f[22,89,3]  marginal_23_3  1
    f[22,89,4]  R849      -1
    f[22,89,4]  R927      1
    f[22,89,4]  marginal_23_4  1
    f[22,89,5]  R849      -1
    f[22,89,5]  R928      1
    f[22,89,5]  marginal_23_5  1
    f[22,90,3]  R850      -1
    f[22,90,3]  R927      1
    f[22,90,3]  marginal_23_3  1
    f[22,90,4]  R850      -1
    f[22,90,4]  R928      1
    f[22,90,4]  marginal_23_4  1
    f[22,90,5]  R850      -1
    f[22,90,5]  R929      1
    f[22,90,5]  marginal_23_5  1
    f[22,91,3]  R851      -1
    f[22,91,3]  R928      1
    f[22,91,3]  marginal_23_3  1
    f[22,91,4]  R851      -1
    f[22,91,4]  R929      1
    f[22,91,4]  marginal_23_4  1
    f[22,91,5]  R851      -1
    f[22,91,5]  R930      1
    f[22,91,5]  marginal_23_5  1
    f[22,92,3]  R852      -1
    f[22,92,3]  R929      1
    f[22,92,3]  marginal_23_3  1
    f[22,92,4]  R852      -1
    f[22,92,4]  R930      1
    f[22,92,4]  marginal_23_4  1
    f[22,92,5]  R852      -1
    f[22,92,5]  R931      1
    f[22,92,5]  marginal_23_5  1
    f[22,93,3]  R853      -1
    f[22,93,3]  R930      1
    f[22,93,3]  marginal_23_3  1
    f[22,93,4]  R853      -1
    f[22,93,4]  R931      1
    f[22,93,4]  marginal_23_4  1
    f[22,93,5]  R853      -1
    f[22,93,5]  R932      1
    f[22,93,5]  marginal_23_5  1
    f[22,94,3]  R854      -1
    f[22,94,3]  R931      1
    f[22,94,3]  marginal_23_3  1
    f[22,94,4]  R854      -1
    f[22,94,4]  R932      1
    f[22,94,4]  marginal_23_4  1
    f[22,94,5]  R854      -1
    f[22,94,5]  R933      1
    f[22,94,5]  marginal_23_5  1
    f[22,95,3]  R855      -1
    f[22,95,3]  R932      1
    f[22,95,3]  marginal_23_3  1
    f[22,95,4]  R855      -1
    f[22,95,4]  R933      1
    f[22,95,4]  marginal_23_4  1
    f[22,95,5]  R855      -1
    f[22,95,5]  R934      1
    f[22,95,5]  marginal_23_5  1
    f[22,96,3]  R856      -1
    f[22,96,3]  R933      1
    f[22,96,3]  marginal_23_3  1
    f[22,96,4]  R856      -1
    f[22,96,4]  R934      1
    f[22,96,4]  marginal_23_4  1
    f[22,96,5]  R856      -1
    f[22,96,5]  R935      1
    f[22,96,5]  marginal_23_5  1
    f[22,97,3]  R857      -1
    f[22,97,3]  R934      1
    f[22,97,3]  marginal_23_3  1
    f[22,97,4]  R857      -1
    f[22,97,4]  R935      1
    f[22,97,4]  marginal_23_4  1
    f[22,97,5]  R857      -1
    f[22,97,5]  R936      1
    f[22,97,5]  marginal_23_5  1
    f[22,98,3]  R858      -1
    f[22,98,3]  R935      1
    f[22,98,3]  marginal_23_3  1
    f[22,98,4]  R858      -1
    f[22,98,4]  R936      1
    f[22,98,4]  marginal_23_4  1
    f[22,98,5]  R858      -1
    f[22,98,5]  R937      1
    f[22,98,5]  marginal_23_5  1
    f[22,99,3]  R859      -1
    f[22,99,3]  R936      1
    f[22,99,3]  marginal_23_3  1
    f[22,99,4]  R859      -1
    f[22,99,4]  R937      1
    f[22,99,4]  marginal_23_4  1
    f[22,99,5]  R859      -1
    f[22,99,5]  R938      1
    f[22,99,5]  marginal_23_5  1
    f[22,100,3]  R860      -1
    f[22,100,3]  R937      1
    f[22,100,3]  marginal_23_3  1
    f[22,100,4]  R860      -1
    f[22,100,4]  R938      1
    f[22,100,4]  marginal_23_4  1
    f[22,100,5]  R860      -1
    f[22,100,5]  R939      1
    f[22,100,5]  marginal_23_5  1
    f[22,101,3]  R861      -1
    f[22,101,3]  R938      1
    f[22,101,3]  marginal_23_3  1
    f[22,101,4]  R861      -1
    f[22,101,4]  R939      1
    f[22,101,4]  marginal_23_4  1
    f[22,101,5]  R861      -1
    f[22,101,5]  R940      1
    f[22,101,5]  marginal_23_5  1
    f[22,102,3]  R862      -1
    f[22,102,3]  R939      1
    f[22,102,3]  marginal_23_3  1
    f[22,102,4]  R862      -1
    f[22,102,4]  R940      1
    f[22,102,4]  marginal_23_4  1
    f[22,102,5]  R862      -1
    f[22,102,5]  R941      1
    f[22,102,5]  marginal_23_5  1
    f[22,103,3]  R863      -1
    f[22,103,3]  R940      1
    f[22,103,3]  marginal_23_3  1
    f[22,103,4]  R863      -1
    f[22,103,4]  R941      1
    f[22,103,4]  marginal_23_4  1
    f[22,103,5]  R863      -1
    f[22,103,5]  R942      1
    f[22,103,5]  marginal_23_5  1
    f[22,104,3]  R864      -1
    f[22,104,3]  R941      1
    f[22,104,3]  marginal_23_3  1
    f[22,104,4]  R864      -1
    f[22,104,4]  R942      1
    f[22,104,4]  marginal_23_4  1
    f[22,104,5]  R864      -1
    f[22,104,5]  R943      1
    f[22,104,5]  marginal_23_5  1
    f[22,105,3]  R865      -1
    f[22,105,3]  R942      1
    f[22,105,3]  marginal_23_3  1
    f[22,105,4]  R865      -1
    f[22,105,4]  R943      1
    f[22,105,4]  marginal_23_4  1
    f[22,105,5]  R865      -1
    f[22,105,5]  R944      1
    f[22,105,5]  marginal_23_5  1
    f[22,106,3]  R866      -1
    f[22,106,3]  R943      1
    f[22,106,3]  marginal_23_3  1
    f[22,106,4]  R866      -1
    f[22,106,4]  R944      1
    f[22,106,4]  marginal_23_4  1
    f[22,106,5]  R866      -1
    f[22,106,5]  R945      1
    f[22,106,5]  marginal_23_5  1
    f[22,107,3]  R867      -1
    f[22,107,3]  R944      1
    f[22,107,3]  marginal_23_3  1
    f[22,107,4]  R867      -1
    f[22,107,4]  R945      1
    f[22,107,4]  marginal_23_4  1
    f[22,107,5]  R867      -1
    f[22,107,5]  R946      1
    f[22,107,5]  marginal_23_5  1
    f[22,108,3]  R868      -1
    f[22,108,3]  R945      1
    f[22,108,3]  marginal_23_3  1
    f[22,108,4]  R868      -1
    f[22,108,4]  R946      1
    f[22,108,4]  marginal_23_4  1
    f[22,108,5]  R868      -1
    f[22,108,5]  R947      1
    f[22,108,5]  marginal_23_5  1
    f[22,109,3]  R869      -1
    f[22,109,3]  R946      1
    f[22,109,3]  marginal_23_3  1
    f[22,109,4]  R869      -1
    f[22,109,4]  R947      1
    f[22,109,4]  marginal_23_4  1
    f[22,109,5]  R869      -1
    f[22,109,5]  R948      1
    f[22,109,5]  marginal_23_5  1
    f[22,110,3]  R870      -1
    f[22,110,3]  R947      1
    f[22,110,3]  marginal_23_3  1
    f[22,110,4]  R870      -1
    f[22,110,4]  R948      1
    f[22,110,4]  marginal_23_4  1
    f[22,110,5]  R870      -1
    f[22,110,5]  R949      1
    f[22,110,5]  marginal_23_5  1
    f[22,111,3]  R871      -1
    f[22,111,3]  R948      1
    f[22,111,3]  marginal_23_3  1
    f[22,111,4]  R871      -1
    f[22,111,4]  R949      1
    f[22,111,4]  marginal_23_4  1
    f[22,111,5]  R871      -1
    f[22,111,5]  R950      1
    f[22,111,5]  marginal_23_5  1
    f[22,112,3]  R872      -1
    f[22,112,3]  R949      1
    f[22,112,3]  marginal_23_3  1
    f[22,112,4]  R872      -1
    f[22,112,4]  R950      1
    f[22,112,4]  marginal_23_4  1
    f[22,112,5]  R872      -1
    f[22,112,5]  R951      1
    f[22,112,5]  marginal_23_5  1
    f[22,113,3]  R873      -1
    f[22,113,3]  R950      1
    f[22,113,3]  marginal_23_3  1
    f[22,113,4]  R873      -1
    f[22,113,4]  R951      1
    f[22,113,4]  marginal_23_4  1
    f[22,113,5]  R873      -1
    f[22,113,5]  R952      1
    f[22,113,5]  marginal_23_5  1
    f[22,114,3]  R874      -1
    f[22,114,3]  R951      1
    f[22,114,3]  marginal_23_3  1
    f[22,114,4]  R874      -1
    f[22,114,4]  R952      1
    f[22,114,4]  marginal_23_4  1
    f[22,114,5]  R874      -1
    f[22,114,5]  R953      1
    f[22,114,5]  marginal_23_5  1
    f[22,115,3]  R875      -1
    f[22,115,3]  R952      1
    f[22,115,3]  marginal_23_3  1
    f[22,115,4]  R875      -1
    f[22,115,4]  R953      1
    f[22,115,4]  marginal_23_4  1
    f[22,115,5]  R875      -1
    f[22,115,5]  R954      1
    f[22,115,5]  marginal_23_5  1
    f[22,116,3]  R876      -1
    f[22,116,3]  R953      1
    f[22,116,3]  marginal_23_3  1
    f[22,116,4]  R876      -1
    f[22,116,4]  R954      1
    f[22,116,4]  marginal_23_4  1
    f[22,116,5]  R876      -1
    f[22,116,5]  R955      1
    f[22,116,5]  marginal_23_5  1
    f[22,117,3]  R877      -1
    f[22,117,3]  R954      1
    f[22,117,3]  marginal_23_3  1
    f[22,117,4]  R877      -1
    f[22,117,4]  R955      1
    f[22,117,4]  marginal_23_4  1
    f[22,117,5]  R877      -1
    f[22,117,5]  R956      1
    f[22,117,5]  marginal_23_5  1
    f[22,118,3]  R878      -1
    f[22,118,3]  R955      1
    f[22,118,3]  marginal_23_3  1
    f[22,118,4]  R878      -1
    f[22,118,4]  R956      1
    f[22,118,4]  marginal_23_4  1
    f[22,118,5]  R878      -1
    f[22,118,5]  R957      1
    f[22,118,5]  marginal_23_5  1
    f[22,119,3]  R879      -1
    f[22,119,3]  R956      1
    f[22,119,3]  marginal_23_3  1
    f[22,119,4]  R879      -1
    f[22,119,4]  R957      1
    f[22,119,4]  marginal_23_4  1
    f[22,119,5]  R879      -1
    f[22,119,5]  R958      1
    f[22,119,5]  marginal_23_5  1
    f[22,120,3]  R880      -1
    f[22,120,3]  R957      1
    f[22,120,3]  marginal_23_3  1
    f[22,120,4]  R880      -1
    f[22,120,4]  R958      1
    f[22,120,4]  marginal_23_4  1
    f[22,120,5]  R880      -1
    f[22,120,5]  R959      1
    f[22,120,5]  marginal_23_5  1
    f[22,121,3]  R881      -1
    f[22,121,3]  R958      1
    f[22,121,3]  marginal_23_3  1
    f[22,121,4]  R881      -1
    f[22,121,4]  R959      1
    f[22,121,4]  marginal_23_4  1
    f[22,121,5]  R881      -1
    f[22,121,5]  R960      1
    f[22,121,5]  marginal_23_5  1
    f[22,122,3]  R882      -1
    f[22,122,3]  R959      1
    f[22,122,3]  marginal_23_3  1
    f[22,122,4]  R882      -1
    f[22,122,4]  R960      1
    f[22,122,4]  marginal_23_4  1
    f[22,122,5]  R882      -1
    f[22,122,5]  R961      1
    f[22,122,5]  marginal_23_5  1
    f[22,123,3]  R883      -1
    f[22,123,3]  R960      1
    f[22,123,3]  marginal_23_3  1
    f[22,123,4]  R883      -1
    f[22,123,4]  R961      1
    f[22,123,4]  marginal_23_4  1
    f[22,123,5]  R883      -1
    f[22,123,5]  R962      1
    f[22,123,5]  marginal_23_5  1
    f[22,124,3]  R884      -1
    f[22,124,3]  R961      1
    f[22,124,3]  marginal_23_3  1
    f[22,124,4]  R884      -1
    f[22,124,4]  R962      1
    f[22,124,4]  marginal_23_4  1
    f[22,124,5]  R884      -1
    f[22,124,5]  R963      1
    f[22,124,5]  marginal_23_5  1
    f[22,125,3]  R885      -1
    f[22,125,3]  R962      1
    f[22,125,3]  marginal_23_3  1
    f[22,125,4]  R885      -1
    f[22,125,4]  R963      1
    f[22,125,4]  marginal_23_4  1
    f[22,125,5]  R885      -1
    f[22,125,5]  R964      1
    f[22,125,5]  marginal_23_5  1
    f[22,126,3]  R886      -1
    f[22,126,3]  R963      1
    f[22,126,3]  marginal_23_3  1
    f[22,126,4]  R886      -1
    f[22,126,4]  R964      1
    f[22,126,4]  marginal_23_4  1
    f[22,126,5]  R886      -1
    f[22,126,5]  R965      1
    f[22,126,5]  marginal_23_5  1
    f[22,127,3]  R887      -1
    f[22,127,3]  R964      1
    f[22,127,3]  marginal_23_3  1
    f[22,127,4]  R887      -1
    f[22,127,4]  R965      1
    f[22,127,4]  marginal_23_4  1
    f[22,127,5]  R887      -1
    f[22,127,5]  R966      1
    f[22,127,5]  marginal_23_5  1
    f[22,128,3]  R888      -1
    f[22,128,3]  R965      1
    f[22,128,3]  marginal_23_3  1
    f[22,128,4]  R888      -1
    f[22,128,4]  R966      1
    f[22,128,4]  marginal_23_4  1
    f[22,128,5]  R888      -1
    f[22,128,5]  R967      1
    f[22,128,5]  marginal_23_5  1
    f[22,129,3]  R889      -1
    f[22,129,3]  R966      1
    f[22,129,3]  marginal_23_3  1
    f[22,129,4]  R889      -1
    f[22,129,4]  R967      1
    f[22,129,4]  marginal_23_4  1
    f[22,129,5]  R889      -1
    f[22,129,5]  R968      1
    f[22,129,5]  marginal_23_5  1
    f[22,130,3]  R890      -1
    f[22,130,3]  R967      1
    f[22,130,3]  marginal_23_3  1
    f[22,130,4]  R890      -1
    f[22,130,4]  R968      1
    f[22,130,4]  marginal_23_4  1
    f[22,130,5]  R890      -1
    f[22,130,5]  R969      1
    f[22,130,5]  marginal_23_5  1
    f[22,131,3]  R891      -1
    f[22,131,3]  R968      1
    f[22,131,3]  marginal_23_3  1
    f[22,131,4]  R891      -1
    f[22,131,4]  R969      1
    f[22,131,4]  marginal_23_4  1
    f[22,131,5]  R891      -1
    f[22,131,5]  R970      1
    f[22,131,5]  marginal_23_5  1
    f[22,132,3]  R892      -1
    f[22,132,3]  R969      1
    f[22,132,3]  marginal_23_3  1
    f[22,132,4]  R892      -1
    f[22,132,4]  R970      1
    f[22,132,4]  marginal_23_4  1
    f[22,132,5]  R892      -1
    f[22,132,5]  R971      1
    f[22,132,5]  marginal_23_5  1
    f[22,133,3]  R893      -1
    f[22,133,3]  R970      1
    f[22,133,3]  marginal_23_3  1
    f[22,133,4]  R893      -1
    f[22,133,4]  R971      1
    f[22,133,4]  marginal_23_4  1
    f[22,133,5]  R893      -1
    f[22,133,5]  R972      1
    f[22,133,5]  marginal_23_5  1
    f[22,134,3]  R894      -1
    f[22,134,3]  R971      1
    f[22,134,3]  marginal_23_3  1
    f[22,134,4]  R894      -1
    f[22,134,4]  R972      1
    f[22,134,4]  marginal_23_4  1
    f[22,134,5]  R894      -1
    f[22,134,5]  R973      1
    f[22,134,5]  marginal_23_5  1
    f[22,135,3]  R895      -1
    f[22,135,3]  R972      1
    f[22,135,3]  marginal_23_3  1
    f[22,135,4]  R895      -1
    f[22,135,4]  R973      1
    f[22,135,4]  marginal_23_4  1
    f[22,135,5]  R895      -1
    f[22,135,5]  R974      1
    f[22,135,5]  marginal_23_5  1
    f[22,136,3]  R896      -1
    f[22,136,3]  R973      1
    f[22,136,3]  marginal_23_3  1
    f[22,136,4]  R896      -1
    f[22,136,4]  R974      1
    f[22,136,4]  marginal_23_4  1
    f[22,136,5]  R896      -1
    f[22,136,5]  R975      1
    f[22,136,5]  marginal_23_5  1
    f[22,137,3]  R897      -1
    f[22,137,3]  R974      1
    f[22,137,3]  marginal_23_3  1
    f[22,137,4]  R897      -1
    f[22,137,4]  R975      1
    f[22,137,4]  marginal_23_4  1
    f[22,137,5]  R897      -1
    f[22,137,5]  R976      1
    f[22,137,5]  marginal_23_5  1
    f[22,138,3]  R898      -1
    f[22,138,3]  R975      1
    f[22,138,3]  marginal_23_3  1
    f[22,138,4]  R898      -1
    f[22,138,4]  R976      1
    f[22,138,4]  marginal_23_4  1
    f[22,138,5]  R898      -1
    f[22,138,5]  R977      1
    f[22,138,5]  marginal_23_5  1
    f[22,139,3]  R899      -1
    f[22,139,3]  R976      1
    f[22,139,3]  marginal_23_3  1
    f[22,139,4]  R899      -1
    f[22,139,4]  R977      1
    f[22,139,4]  marginal_23_4  1
    f[22,139,5]  R899      -1
    f[22,139,5]  R978      1
    f[22,139,5]  marginal_23_5  1
    f[22,140,3]  R900      -1
    f[22,140,3]  R977      1
    f[22,140,3]  marginal_23_3  1
    f[22,140,4]  R900      -1
    f[22,140,4]  R978      1
    f[22,140,4]  marginal_23_4  1
    f[22,140,5]  R900      -1
    f[22,140,5]  R979      1
    f[22,140,5]  marginal_23_5  1
    f[22,141,3]  R901      -1
    f[22,141,3]  R978      1
    f[22,141,3]  marginal_23_3  1
    f[22,141,4]  R901      -1
    f[22,141,4]  R979      1
    f[22,141,4]  marginal_23_4  1
    f[22,141,5]  R901      -1
    f[22,141,5]  R980      1
    f[22,141,5]  marginal_23_5  1
    f[22,142,3]  R902      -1
    f[22,142,3]  R979      1
    f[22,142,3]  marginal_23_3  1
    f[22,142,4]  R902      -1
    f[22,142,4]  R980      1
    f[22,142,4]  marginal_23_4  1
    f[22,142,5]  R902      -1
    f[22,142,5]  R981      1
    f[22,142,5]  marginal_23_5  1
    f[22,143,3]  R903      -1
    f[22,143,3]  R980      1
    f[22,143,3]  marginal_23_3  1
    f[22,143,4]  R903      -1
    f[22,143,4]  R981      1
    f[22,143,4]  marginal_23_4  1
    f[22,143,5]  R903      -1
    f[22,143,5]  R982      1
    f[22,143,5]  marginal_23_5  1
    f[22,144,3]  R904      -1
    f[22,144,3]  R981      1
    f[22,144,3]  marginal_23_3  1
    f[22,144,4]  R904      -1
    f[22,144,4]  R982      1
    f[22,144,4]  marginal_23_4  1
    f[22,144,5]  R904      -1
    f[22,144,5]  R983      1
    f[22,144,5]  marginal_23_5  1
    f[22,145,3]  R905      -1
    f[22,145,3]  R982      1
    f[22,145,3]  marginal_23_3  1
    f[22,145,4]  R905      -1
    f[22,145,4]  R983      1
    f[22,145,4]  marginal_23_4  1
    f[22,145,5]  R905      -1
    f[22,145,5]  R984      1
    f[22,145,5]  marginal_23_5  1
    f[22,146,3]  R906      -1
    f[22,146,3]  R983      1
    f[22,146,3]  marginal_23_3  1
    f[22,146,4]  R906      -1
    f[22,146,4]  R984      1
    f[22,146,4]  marginal_23_4  1
    f[22,146,5]  R906      -1
    f[22,146,5]  R985      1
    f[22,146,5]  marginal_23_5  1
    f[22,147,3]  R907      -1
    f[22,147,3]  R984      1
    f[22,147,3]  marginal_23_3  1
    f[22,147,4]  R907      -1
    f[22,147,4]  R985      1
    f[22,147,4]  marginal_23_4  1
    f[22,147,5]  R907      -1
    f[22,147,5]  R986      1
    f[22,147,5]  marginal_23_5  1
    f[22,148,3]  R908      -1
    f[22,148,3]  R985      1
    f[22,148,3]  marginal_23_3  1
    f[22,148,4]  R908      -1
    f[22,148,4]  R986      1
    f[22,148,4]  marginal_23_4  1
    f[22,148,5]  R908      -1
    f[22,148,5]  R987      1
    f[22,148,5]  marginal_23_5  1
    f[22,149,3]  R909      -1
    f[22,149,3]  R986      1
    f[22,149,3]  marginal_23_3  1
    f[22,149,4]  R909      -1
    f[22,149,4]  R987      1
    f[22,149,4]  marginal_23_4  1
    f[22,149,5]  R909      -1
    f[22,149,5]  R988      1
    f[22,149,5]  marginal_23_5  1
    f[22,150,3]  R910      -1
    f[22,150,3]  R987      1
    f[22,150,3]  marginal_23_3  1
    f[22,150,4]  R910      -1
    f[22,150,4]  R988      1
    f[22,150,4]  marginal_23_4  1
    f[22,150,5]  R910      -1
    f[22,150,5]  R989      1
    f[22,150,5]  marginal_23_5  1
    f[22,151,3]  R911      -1
    f[22,151,3]  R988      1
    f[22,151,3]  marginal_23_3  1
    f[22,151,4]  R911      -1
    f[22,151,4]  R989      1
    f[22,151,4]  marginal_23_4  1
    f[22,151,5]  R911      -1
    f[22,151,5]  R990      1
    f[22,151,5]  marginal_23_5  1
    f[22,152,3]  R912      -1
    f[22,152,3]  R989      1
    f[22,152,3]  marginal_23_3  1
    f[22,152,4]  R912      -1
    f[22,152,4]  R990      1
    f[22,152,4]  marginal_23_4  1
    f[22,152,5]  R912      -1
    f[22,152,5]  R991      1
    f[22,152,5]  marginal_23_5  1
    f[22,153,3]  R913      -1
    f[22,153,3]  R990      1
    f[22,153,3]  marginal_23_3  1
    f[22,153,4]  R913      -1
    f[22,153,4]  R991      1
    f[22,153,4]  marginal_23_4  1
    f[22,153,5]  R913      -1
    f[22,153,5]  R992      1
    f[22,153,5]  marginal_23_5  1
    f[22,154,3]  R914      -1
    f[22,154,3]  R991      1
    f[22,154,3]  marginal_23_3  1
    f[22,154,4]  R914      -1
    f[22,154,4]  R992      1
    f[22,154,4]  marginal_23_4  1
    f[22,154,5]  R914      -1
    f[22,154,5]  R993      1
    f[22,154,5]  marginal_23_5  1
    f[22,155,3]  R915      -1
    f[22,155,3]  R992      1
    f[22,155,3]  marginal_23_3  1
    f[22,155,4]  R915      -1
    f[22,155,4]  R993      1
    f[22,155,4]  marginal_23_4  1
    f[22,155,5]  R915      -1
    f[22,155,5]  R994      1
    f[22,155,5]  marginal_23_5  1
    f[22,156,3]  R916      -1
    f[22,156,3]  R993      1
    f[22,156,3]  marginal_23_3  1
    f[22,156,4]  R916      -1
    f[22,156,4]  R994      1
    f[22,156,4]  marginal_23_4  1
    f[22,156,5]  R916      -1
    f[22,156,5]  R995      1
    f[22,156,5]  marginal_23_5  1
    f[22,157,3]  R917      -1
    f[22,157,3]  R994      1
    f[22,157,3]  marginal_23_3  1
    f[22,157,4]  R917      -1
    f[22,157,4]  R995      1
    f[22,157,4]  marginal_23_4  1
    f[22,158,3]  R918      -1
    f[22,158,3]  R995      1
    f[22,158,3]  marginal_23_3  1
    f[23,85,4]  R919      -1
    f[23,85,4]  R996      1
    f[23,85,4]  marginal_24_4  1
    f[23,85,7]  R919      -1
    f[23,85,7]  R999      1
    f[23,85,7]  marginal_24_7  1
    f[23,85,8]  R919      -1
    f[23,85,8]  R1000     1
    f[23,85,8]  marginal_24_8  1
    f[23,86,4]  R920      -1
    f[23,86,4]  R997      1
    f[23,86,4]  marginal_24_4  1
    f[23,86,7]  R920      -1
    f[23,86,7]  R1000     1
    f[23,86,7]  marginal_24_7  1
    f[23,86,8]  R920      -1
    f[23,86,8]  R1001     1
    f[23,86,8]  marginal_24_8  1
    f[23,87,4]  R921      -1
    f[23,87,4]  R998      1
    f[23,87,4]  marginal_24_4  1
    f[23,87,7]  R921      -1
    f[23,87,7]  R1001     1
    f[23,87,7]  marginal_24_7  1
    f[23,87,8]  R921      -1
    f[23,87,8]  R1002     1
    f[23,87,8]  marginal_24_8  1
    f[23,88,4]  R922      -1
    f[23,88,4]  R999      1
    f[23,88,4]  marginal_24_4  1
    f[23,88,7]  R922      -1
    f[23,88,7]  R1002     1
    f[23,88,7]  marginal_24_7  1
    f[23,88,8]  R922      -1
    f[23,88,8]  R1003     1
    f[23,88,8]  marginal_24_8  1
    f[23,89,4]  R923      -1
    f[23,89,4]  R1000     1
    f[23,89,4]  marginal_24_4  1
    f[23,89,7]  R923      -1
    f[23,89,7]  R1003     1
    f[23,89,7]  marginal_24_7  1
    f[23,89,8]  R923      -1
    f[23,89,8]  R1004     1
    f[23,89,8]  marginal_24_8  1
    f[23,90,4]  R924      -1
    f[23,90,4]  R1001     1
    f[23,90,4]  marginal_24_4  1
    f[23,90,7]  R924      -1
    f[23,90,7]  R1004     1
    f[23,90,7]  marginal_24_7  1
    f[23,90,8]  R924      -1
    f[23,90,8]  R1005     1
    f[23,90,8]  marginal_24_8  1
    f[23,91,4]  R925      -1
    f[23,91,4]  R1002     1
    f[23,91,4]  marginal_24_4  1
    f[23,91,7]  R925      -1
    f[23,91,7]  R1005     1
    f[23,91,7]  marginal_24_7  1
    f[23,91,8]  R925      -1
    f[23,91,8]  R1006     1
    f[23,91,8]  marginal_24_8  1
    f[23,92,4]  R926      -1
    f[23,92,4]  R1003     1
    f[23,92,4]  marginal_24_4  1
    f[23,92,7]  R926      -1
    f[23,92,7]  R1006     1
    f[23,92,7]  marginal_24_7  1
    f[23,92,8]  R926      -1
    f[23,92,8]  R1007     1
    f[23,92,8]  marginal_24_8  1
    f[23,93,4]  R927      -1
    f[23,93,4]  R1004     1
    f[23,93,4]  marginal_24_4  1
    f[23,93,7]  R927      -1
    f[23,93,7]  R1007     1
    f[23,93,7]  marginal_24_7  1
    f[23,93,8]  R927      -1
    f[23,93,8]  R1008     1
    f[23,93,8]  marginal_24_8  1
    f[23,94,4]  R928      -1
    f[23,94,4]  R1005     1
    f[23,94,4]  marginal_24_4  1
    f[23,94,7]  R928      -1
    f[23,94,7]  R1008     1
    f[23,94,7]  marginal_24_7  1
    f[23,94,8]  R928      -1
    f[23,94,8]  R1009     1
    f[23,94,8]  marginal_24_8  1
    f[23,95,4]  R929      -1
    f[23,95,4]  R1006     1
    f[23,95,4]  marginal_24_4  1
    f[23,95,7]  R929      -1
    f[23,95,7]  R1009     1
    f[23,95,7]  marginal_24_7  1
    f[23,95,8]  R929      -1
    f[23,95,8]  R1010     1
    f[23,95,8]  marginal_24_8  1
    f[23,96,4]  R930      -1
    f[23,96,4]  R1007     1
    f[23,96,4]  marginal_24_4  1
    f[23,96,7]  R930      -1
    f[23,96,7]  R1010     1
    f[23,96,7]  marginal_24_7  1
    f[23,96,8]  R930      -1
    f[23,96,8]  R1011     1
    f[23,96,8]  marginal_24_8  1
    f[23,97,4]  R931      -1
    f[23,97,4]  R1008     1
    f[23,97,4]  marginal_24_4  1
    f[23,97,7]  R931      -1
    f[23,97,7]  R1011     1
    f[23,97,7]  marginal_24_7  1
    f[23,97,8]  R931      -1
    f[23,97,8]  R1012     1
    f[23,97,8]  marginal_24_8  1
    f[23,98,4]  R932      -1
    f[23,98,4]  R1009     1
    f[23,98,4]  marginal_24_4  1
    f[23,98,7]  R932      -1
    f[23,98,7]  R1012     1
    f[23,98,7]  marginal_24_7  1
    f[23,98,8]  R932      -1
    f[23,98,8]  R1013     1
    f[23,98,8]  marginal_24_8  1
    f[23,99,4]  R933      -1
    f[23,99,4]  R1010     1
    f[23,99,4]  marginal_24_4  1
    f[23,99,7]  R933      -1
    f[23,99,7]  R1013     1
    f[23,99,7]  marginal_24_7  1
    f[23,99,8]  R933      -1
    f[23,99,8]  R1014     1
    f[23,99,8]  marginal_24_8  1
    f[23,100,4]  R934      -1
    f[23,100,4]  R1011     1
    f[23,100,4]  marginal_24_4  1
    f[23,100,7]  R934      -1
    f[23,100,7]  R1014     1
    f[23,100,7]  marginal_24_7  1
    f[23,100,8]  R934      -1
    f[23,100,8]  R1015     1
    f[23,100,8]  marginal_24_8  1
    f[23,101,4]  R935      -1
    f[23,101,4]  R1012     1
    f[23,101,4]  marginal_24_4  1
    f[23,101,7]  R935      -1
    f[23,101,7]  R1015     1
    f[23,101,7]  marginal_24_7  1
    f[23,101,8]  R935      -1
    f[23,101,8]  R1016     1
    f[23,101,8]  marginal_24_8  1
    f[23,102,4]  R936      -1
    f[23,102,4]  R1013     1
    f[23,102,4]  marginal_24_4  1
    f[23,102,7]  R936      -1
    f[23,102,7]  R1016     1
    f[23,102,7]  marginal_24_7  1
    f[23,102,8]  R936      -1
    f[23,102,8]  R1017     1
    f[23,102,8]  marginal_24_8  1
    f[23,103,4]  R937      -1
    f[23,103,4]  R1014     1
    f[23,103,4]  marginal_24_4  1
    f[23,103,7]  R937      -1
    f[23,103,7]  R1017     1
    f[23,103,7]  marginal_24_7  1
    f[23,103,8]  R937      -1
    f[23,103,8]  R1018     1
    f[23,103,8]  marginal_24_8  1
    f[23,104,4]  R938      -1
    f[23,104,4]  R1015     1
    f[23,104,4]  marginal_24_4  1
    f[23,104,7]  R938      -1
    f[23,104,7]  R1018     1
    f[23,104,7]  marginal_24_7  1
    f[23,104,8]  R938      -1
    f[23,104,8]  R1019     1
    f[23,104,8]  marginal_24_8  1
    f[23,105,4]  R939      -1
    f[23,105,4]  R1016     1
    f[23,105,4]  marginal_24_4  1
    f[23,105,7]  R939      -1
    f[23,105,7]  R1019     1
    f[23,105,7]  marginal_24_7  1
    f[23,105,8]  R939      -1
    f[23,105,8]  R1020     1
    f[23,105,8]  marginal_24_8  1
    f[23,106,4]  R940      -1
    f[23,106,4]  R1017     1
    f[23,106,4]  marginal_24_4  1
    f[23,106,7]  R940      -1
    f[23,106,7]  R1020     1
    f[23,106,7]  marginal_24_7  1
    f[23,106,8]  R940      -1
    f[23,106,8]  R1021     1
    f[23,106,8]  marginal_24_8  1
    f[23,107,4]  R941      -1
    f[23,107,4]  R1018     1
    f[23,107,4]  marginal_24_4  1
    f[23,107,7]  R941      -1
    f[23,107,7]  R1021     1
    f[23,107,7]  marginal_24_7  1
    f[23,107,8]  R941      -1
    f[23,107,8]  R1022     1
    f[23,107,8]  marginal_24_8  1
    f[23,108,4]  R942      -1
    f[23,108,4]  R1019     1
    f[23,108,4]  marginal_24_4  1
    f[23,108,7]  R942      -1
    f[23,108,7]  R1022     1
    f[23,108,7]  marginal_24_7  1
    f[23,108,8]  R942      -1
    f[23,108,8]  R1023     1
    f[23,108,8]  marginal_24_8  1
    f[23,109,4]  R943      -1
    f[23,109,4]  R1020     1
    f[23,109,4]  marginal_24_4  1
    f[23,109,7]  R943      -1
    f[23,109,7]  R1023     1
    f[23,109,7]  marginal_24_7  1
    f[23,109,8]  R943      -1
    f[23,109,8]  R1024     1
    f[23,109,8]  marginal_24_8  1
    f[23,110,4]  R944      -1
    f[23,110,4]  R1021     1
    f[23,110,4]  marginal_24_4  1
    f[23,110,7]  R944      -1
    f[23,110,7]  R1024     1
    f[23,110,7]  marginal_24_7  1
    f[23,110,8]  R944      -1
    f[23,110,8]  R1025     1
    f[23,110,8]  marginal_24_8  1
    f[23,111,4]  R945      -1
    f[23,111,4]  R1022     1
    f[23,111,4]  marginal_24_4  1
    f[23,111,7]  R945      -1
    f[23,111,7]  R1025     1
    f[23,111,7]  marginal_24_7  1
    f[23,111,8]  R945      -1
    f[23,111,8]  R1026     1
    f[23,111,8]  marginal_24_8  1
    f[23,112,4]  R946      -1
    f[23,112,4]  R1023     1
    f[23,112,4]  marginal_24_4  1
    f[23,112,7]  R946      -1
    f[23,112,7]  R1026     1
    f[23,112,7]  marginal_24_7  1
    f[23,112,8]  R946      -1
    f[23,112,8]  R1027     1
    f[23,112,8]  marginal_24_8  1
    f[23,113,4]  R947      -1
    f[23,113,4]  R1024     1
    f[23,113,4]  marginal_24_4  1
    f[23,113,7]  R947      -1
    f[23,113,7]  R1027     1
    f[23,113,7]  marginal_24_7  1
    f[23,113,8]  R947      -1
    f[23,113,8]  R1028     1
    f[23,113,8]  marginal_24_8  1
    f[23,114,4]  R948      -1
    f[23,114,4]  R1025     1
    f[23,114,4]  marginal_24_4  1
    f[23,114,7]  R948      -1
    f[23,114,7]  R1028     1
    f[23,114,7]  marginal_24_7  1
    f[23,114,8]  R948      -1
    f[23,114,8]  R1029     1
    f[23,114,8]  marginal_24_8  1
    f[23,115,4]  R949      -1
    f[23,115,4]  R1026     1
    f[23,115,4]  marginal_24_4  1
    f[23,115,7]  R949      -1
    f[23,115,7]  R1029     1
    f[23,115,7]  marginal_24_7  1
    f[23,115,8]  R949      -1
    f[23,115,8]  R1030     1
    f[23,115,8]  marginal_24_8  1
    f[23,116,4]  R950      -1
    f[23,116,4]  R1027     1
    f[23,116,4]  marginal_24_4  1
    f[23,116,7]  R950      -1
    f[23,116,7]  R1030     1
    f[23,116,7]  marginal_24_7  1
    f[23,116,8]  R950      -1
    f[23,116,8]  R1031     1
    f[23,116,8]  marginal_24_8  1
    f[23,117,4]  R951      -1
    f[23,117,4]  R1028     1
    f[23,117,4]  marginal_24_4  1
    f[23,117,7]  R951      -1
    f[23,117,7]  R1031     1
    f[23,117,7]  marginal_24_7  1
    f[23,117,8]  R951      -1
    f[23,117,8]  R1032     1
    f[23,117,8]  marginal_24_8  1
    f[23,118,4]  R952      -1
    f[23,118,4]  R1029     1
    f[23,118,4]  marginal_24_4  1
    f[23,118,7]  R952      -1
    f[23,118,7]  R1032     1
    f[23,118,7]  marginal_24_7  1
    f[23,118,8]  R952      -1
    f[23,118,8]  R1033     1
    f[23,118,8]  marginal_24_8  1
    f[23,119,4]  R953      -1
    f[23,119,4]  R1030     1
    f[23,119,4]  marginal_24_4  1
    f[23,119,7]  R953      -1
    f[23,119,7]  R1033     1
    f[23,119,7]  marginal_24_7  1
    f[23,119,8]  R953      -1
    f[23,119,8]  R1034     1
    f[23,119,8]  marginal_24_8  1
    f[23,120,4]  R954      -1
    f[23,120,4]  R1031     1
    f[23,120,4]  marginal_24_4  1
    f[23,120,7]  R954      -1
    f[23,120,7]  R1034     1
    f[23,120,7]  marginal_24_7  1
    f[23,120,8]  R954      -1
    f[23,120,8]  R1035     1
    f[23,120,8]  marginal_24_8  1
    f[23,121,4]  R955      -1
    f[23,121,4]  R1032     1
    f[23,121,4]  marginal_24_4  1
    f[23,121,7]  R955      -1
    f[23,121,7]  R1035     1
    f[23,121,7]  marginal_24_7  1
    f[23,121,8]  R955      -1
    f[23,121,8]  R1036     1
    f[23,121,8]  marginal_24_8  1
    f[23,122,4]  R956      -1
    f[23,122,4]  R1033     1
    f[23,122,4]  marginal_24_4  1
    f[23,122,7]  R956      -1
    f[23,122,7]  R1036     1
    f[23,122,7]  marginal_24_7  1
    f[23,122,8]  R956      -1
    f[23,122,8]  R1037     1
    f[23,122,8]  marginal_24_8  1
    f[23,123,4]  R957      -1
    f[23,123,4]  R1034     1
    f[23,123,4]  marginal_24_4  1
    f[23,123,7]  R957      -1
    f[23,123,7]  R1037     1
    f[23,123,7]  marginal_24_7  1
    f[23,123,8]  R957      -1
    f[23,123,8]  R1038     1
    f[23,123,8]  marginal_24_8  1
    f[23,124,4]  R958      -1
    f[23,124,4]  R1035     1
    f[23,124,4]  marginal_24_4  1
    f[23,124,7]  R958      -1
    f[23,124,7]  R1038     1
    f[23,124,7]  marginal_24_7  1
    f[23,124,8]  R958      -1
    f[23,124,8]  R1039     1
    f[23,124,8]  marginal_24_8  1
    f[23,125,4]  R959      -1
    f[23,125,4]  R1036     1
    f[23,125,4]  marginal_24_4  1
    f[23,125,7]  R959      -1
    f[23,125,7]  R1039     1
    f[23,125,7]  marginal_24_7  1
    f[23,125,8]  R959      -1
    f[23,125,8]  R1040     1
    f[23,125,8]  marginal_24_8  1
    f[23,126,4]  R960      -1
    f[23,126,4]  R1037     1
    f[23,126,4]  marginal_24_4  1
    f[23,126,7]  R960      -1
    f[23,126,7]  R1040     1
    f[23,126,7]  marginal_24_7  1
    f[23,126,8]  R960      -1
    f[23,126,8]  R1041     1
    f[23,126,8]  marginal_24_8  1
    f[23,127,4]  R961      -1
    f[23,127,4]  R1038     1
    f[23,127,4]  marginal_24_4  1
    f[23,127,7]  R961      -1
    f[23,127,7]  R1041     1
    f[23,127,7]  marginal_24_7  1
    f[23,127,8]  R961      -1
    f[23,127,8]  R1042     1
    f[23,127,8]  marginal_24_8  1
    f[23,128,4]  R962      -1
    f[23,128,4]  R1039     1
    f[23,128,4]  marginal_24_4  1
    f[23,128,7]  R962      -1
    f[23,128,7]  R1042     1
    f[23,128,7]  marginal_24_7  1
    f[23,128,8]  R962      -1
    f[23,128,8]  R1043     1
    f[23,128,8]  marginal_24_8  1
    f[23,129,4]  R963      -1
    f[23,129,4]  R1040     1
    f[23,129,4]  marginal_24_4  1
    f[23,129,7]  R963      -1
    f[23,129,7]  R1043     1
    f[23,129,7]  marginal_24_7  1
    f[23,129,8]  R963      -1
    f[23,129,8]  R1044     1
    f[23,129,8]  marginal_24_8  1
    f[23,130,4]  R964      -1
    f[23,130,4]  R1041     1
    f[23,130,4]  marginal_24_4  1
    f[23,130,7]  R964      -1
    f[23,130,7]  R1044     1
    f[23,130,7]  marginal_24_7  1
    f[23,130,8]  R964      -1
    f[23,130,8]  R1045     1
    f[23,130,8]  marginal_24_8  1
    f[23,131,4]  R965      -1
    f[23,131,4]  R1042     1
    f[23,131,4]  marginal_24_4  1
    f[23,131,7]  R965      -1
    f[23,131,7]  R1045     1
    f[23,131,7]  marginal_24_7  1
    f[23,131,8]  R965      -1
    f[23,131,8]  R1046     1
    f[23,131,8]  marginal_24_8  1
    f[23,132,4]  R966      -1
    f[23,132,4]  R1043     1
    f[23,132,4]  marginal_24_4  1
    f[23,132,7]  R966      -1
    f[23,132,7]  R1046     1
    f[23,132,7]  marginal_24_7  1
    f[23,132,8]  R966      -1
    f[23,132,8]  R1047     1
    f[23,132,8]  marginal_24_8  1
    f[23,133,4]  R967      -1
    f[23,133,4]  R1044     1
    f[23,133,4]  marginal_24_4  1
    f[23,133,7]  R967      -1
    f[23,133,7]  R1047     1
    f[23,133,7]  marginal_24_7  1
    f[23,133,8]  R967      -1
    f[23,133,8]  R1048     1
    f[23,133,8]  marginal_24_8  1
    f[23,134,4]  R968      -1
    f[23,134,4]  R1045     1
    f[23,134,4]  marginal_24_4  1
    f[23,134,7]  R968      -1
    f[23,134,7]  R1048     1
    f[23,134,7]  marginal_24_7  1
    f[23,134,8]  R968      -1
    f[23,134,8]  R1049     1
    f[23,134,8]  marginal_24_8  1
    f[23,135,4]  R969      -1
    f[23,135,4]  R1046     1
    f[23,135,4]  marginal_24_4  1
    f[23,135,7]  R969      -1
    f[23,135,7]  R1049     1
    f[23,135,7]  marginal_24_7  1
    f[23,135,8]  R969      -1
    f[23,135,8]  R1050     1
    f[23,135,8]  marginal_24_8  1
    f[23,136,4]  R970      -1
    f[23,136,4]  R1047     1
    f[23,136,4]  marginal_24_4  1
    f[23,136,7]  R970      -1
    f[23,136,7]  R1050     1
    f[23,136,7]  marginal_24_7  1
    f[23,136,8]  R970      -1
    f[23,136,8]  R1051     1
    f[23,136,8]  marginal_24_8  1
    f[23,137,4]  R971      -1
    f[23,137,4]  R1048     1
    f[23,137,4]  marginal_24_4  1
    f[23,137,7]  R971      -1
    f[23,137,7]  R1051     1
    f[23,137,7]  marginal_24_7  1
    f[23,137,8]  R971      -1
    f[23,137,8]  R1052     1
    f[23,137,8]  marginal_24_8  1
    f[23,138,4]  R972      -1
    f[23,138,4]  R1049     1
    f[23,138,4]  marginal_24_4  1
    f[23,138,7]  R972      -1
    f[23,138,7]  R1052     1
    f[23,138,7]  marginal_24_7  1
    f[23,138,8]  R972      -1
    f[23,138,8]  R1053     1
    f[23,138,8]  marginal_24_8  1
    f[23,139,4]  R973      -1
    f[23,139,4]  R1050     1
    f[23,139,4]  marginal_24_4  1
    f[23,139,7]  R973      -1
    f[23,139,7]  R1053     1
    f[23,139,7]  marginal_24_7  1
    f[23,139,8]  R973      -1
    f[23,139,8]  R1054     1
    f[23,139,8]  marginal_24_8  1
    f[23,140,4]  R974      -1
    f[23,140,4]  R1051     1
    f[23,140,4]  marginal_24_4  1
    f[23,140,7]  R974      -1
    f[23,140,7]  R1054     1
    f[23,140,7]  marginal_24_7  1
    f[23,140,8]  R974      -1
    f[23,140,8]  R1055     1
    f[23,140,8]  marginal_24_8  1
    f[23,141,4]  R975      -1
    f[23,141,4]  R1052     1
    f[23,141,4]  marginal_24_4  1
    f[23,141,7]  R975      -1
    f[23,141,7]  R1055     1
    f[23,141,7]  marginal_24_7  1
    f[23,141,8]  R975      -1
    f[23,141,8]  R1056     1
    f[23,141,8]  marginal_24_8  1
    f[23,142,4]  R976      -1
    f[23,142,4]  R1053     1
    f[23,142,4]  marginal_24_4  1
    f[23,142,7]  R976      -1
    f[23,142,7]  R1056     1
    f[23,142,7]  marginal_24_7  1
    f[23,142,8]  R976      -1
    f[23,142,8]  R1057     1
    f[23,142,8]  marginal_24_8  1
    f[23,143,4]  R977      -1
    f[23,143,4]  R1054     1
    f[23,143,4]  marginal_24_4  1
    f[23,143,7]  R977      -1
    f[23,143,7]  R1057     1
    f[23,143,7]  marginal_24_7  1
    f[23,143,8]  R977      -1
    f[23,143,8]  R1058     1
    f[23,143,8]  marginal_24_8  1
    f[23,144,4]  R978      -1
    f[23,144,4]  R1055     1
    f[23,144,4]  marginal_24_4  1
    f[23,144,7]  R978      -1
    f[23,144,7]  R1058     1
    f[23,144,7]  marginal_24_7  1
    f[23,144,8]  R978      -1
    f[23,144,8]  R1059     1
    f[23,144,8]  marginal_24_8  1
    f[23,145,4]  R979      -1
    f[23,145,4]  R1056     1
    f[23,145,4]  marginal_24_4  1
    f[23,145,7]  R979      -1
    f[23,145,7]  R1059     1
    f[23,145,7]  marginal_24_7  1
    f[23,145,8]  R979      -1
    f[23,145,8]  R1060     1
    f[23,145,8]  marginal_24_8  1
    f[23,146,4]  R980      -1
    f[23,146,4]  R1057     1
    f[23,146,4]  marginal_24_4  1
    f[23,146,7]  R980      -1
    f[23,146,7]  R1060     1
    f[23,146,7]  marginal_24_7  1
    f[23,146,8]  R980      -1
    f[23,146,8]  R1061     1
    f[23,146,8]  marginal_24_8  1
    f[23,147,4]  R981      -1
    f[23,147,4]  R1058     1
    f[23,147,4]  marginal_24_4  1
    f[23,147,7]  R981      -1
    f[23,147,7]  R1061     1
    f[23,147,7]  marginal_24_7  1
    f[23,147,8]  R981      -1
    f[23,147,8]  R1062     1
    f[23,147,8]  marginal_24_8  1
    f[23,148,4]  R982      -1
    f[23,148,4]  R1059     1
    f[23,148,4]  marginal_24_4  1
    f[23,148,7]  R982      -1
    f[23,148,7]  R1062     1
    f[23,148,7]  marginal_24_7  1
    f[23,148,8]  R982      -1
    f[23,148,8]  R1063     1
    f[23,148,8]  marginal_24_8  1
    f[23,149,4]  R983      -1
    f[23,149,4]  R1060     1
    f[23,149,4]  marginal_24_4  1
    f[23,149,7]  R983      -1
    f[23,149,7]  R1063     1
    f[23,149,7]  marginal_24_7  1
    f[23,149,8]  R983      -1
    f[23,149,8]  R1064     1
    f[23,149,8]  marginal_24_8  1
    f[23,150,4]  R984      -1
    f[23,150,4]  R1061     1
    f[23,150,4]  marginal_24_4  1
    f[23,150,7]  R984      -1
    f[23,150,7]  R1064     1
    f[23,150,7]  marginal_24_7  1
    f[23,150,8]  R984      -1
    f[23,150,8]  R1065     1
    f[23,150,8]  marginal_24_8  1
    f[23,151,4]  R985      -1
    f[23,151,4]  R1062     1
    f[23,151,4]  marginal_24_4  1
    f[23,151,7]  R985      -1
    f[23,151,7]  R1065     1
    f[23,151,7]  marginal_24_7  1
    f[23,151,8]  R985      -1
    f[23,151,8]  R1066     1
    f[23,151,8]  marginal_24_8  1
    f[23,152,4]  R986      -1
    f[23,152,4]  R1063     1
    f[23,152,4]  marginal_24_4  1
    f[23,152,7]  R986      -1
    f[23,152,7]  R1066     1
    f[23,152,7]  marginal_24_7  1
    f[23,152,8]  R986      -1
    f[23,152,8]  R1067     1
    f[23,152,8]  marginal_24_8  1
    f[23,153,4]  R987      -1
    f[23,153,4]  R1064     1
    f[23,153,4]  marginal_24_4  1
    f[23,153,7]  R987      -1
    f[23,153,7]  R1067     1
    f[23,153,7]  marginal_24_7  1
    f[23,153,8]  R987      -1
    f[23,153,8]  R1068     1
    f[23,153,8]  marginal_24_8  1
    f[23,154,4]  R988      -1
    f[23,154,4]  R1065     1
    f[23,154,4]  marginal_24_4  1
    f[23,154,7]  R988      -1
    f[23,154,7]  R1068     1
    f[23,154,7]  marginal_24_7  1
    f[23,154,8]  R988      -1
    f[23,154,8]  R1069     1
    f[23,154,8]  marginal_24_8  1
    f[23,155,4]  R989      -1
    f[23,155,4]  R1066     1
    f[23,155,4]  marginal_24_4  1
    f[23,155,7]  R989      -1
    f[23,155,7]  R1069     1
    f[23,155,7]  marginal_24_7  1
    f[23,155,8]  R989      -1
    f[23,155,8]  R1070     1
    f[23,155,8]  marginal_24_8  1
    f[23,156,4]  R990      -1
    f[23,156,4]  R1067     1
    f[23,156,4]  marginal_24_4  1
    f[23,156,7]  R990      -1
    f[23,156,7]  R1070     1
    f[23,156,7]  marginal_24_7  1
    f[23,156,8]  R990      -1
    f[23,156,8]  R1071     1
    f[23,156,8]  marginal_24_8  1
    f[23,157,4]  R991      -1
    f[23,157,4]  R1068     1
    f[23,157,4]  marginal_24_4  1
    f[23,157,7]  R991      -1
    f[23,157,7]  R1071     1
    f[23,157,7]  marginal_24_7  1
    f[23,157,8]  R991      -1
    f[23,157,8]  R1072     1
    f[23,157,8]  marginal_24_8  1
    f[23,158,4]  R992      -1
    f[23,158,4]  R1069     1
    f[23,158,4]  marginal_24_4  1
    f[23,158,7]  R992      -1
    f[23,158,7]  R1072     1
    f[23,158,7]  marginal_24_7  1
    f[23,159,4]  R993      -1
    f[23,159,4]  R1070     1
    f[23,159,4]  marginal_24_4  1
    f[23,160,4]  R994      -1
    f[23,160,4]  R1071     1
    f[23,160,4]  marginal_24_4  1
    f[23,161,4]  R995      -1
    f[23,161,4]  R1072     1
    f[23,161,4]  marginal_24_4  1
    f[24,89,6]  R996      -1
    f[24,89,6]  R1073     1
    f[24,89,6]  marginal_25_6  1
    f[24,89,7]  R996      -1
    f[24,89,7]  R1074     1
    f[24,89,7]  marginal_25_7  1
    f[24,90,6]  R997      -1
    f[24,90,6]  R1074     1
    f[24,90,6]  marginal_25_6  1
    f[24,90,7]  R997      -1
    f[24,90,7]  R1075     1
    f[24,90,7]  marginal_25_7  1
    f[24,91,6]  R998      -1
    f[24,91,6]  R1075     1
    f[24,91,6]  marginal_25_6  1
    f[24,91,7]  R998      -1
    f[24,91,7]  R1076     1
    f[24,91,7]  marginal_25_7  1
    f[24,92,6]  R999      -1
    f[24,92,6]  R1076     1
    f[24,92,6]  marginal_25_6  1
    f[24,92,7]  R999      -1
    f[24,92,7]  R1077     1
    f[24,92,7]  marginal_25_7  1
    f[24,93,6]  R1000     -1
    f[24,93,6]  R1077     1
    f[24,93,6]  marginal_25_6  1
    f[24,93,7]  R1000     -1
    f[24,93,7]  R1078     1
    f[24,93,7]  marginal_25_7  1
    f[24,94,6]  R1001     -1
    f[24,94,6]  R1078     1
    f[24,94,6]  marginal_25_6  1
    f[24,94,7]  R1001     -1
    f[24,94,7]  R1079     1
    f[24,94,7]  marginal_25_7  1
    f[24,95,6]  R1002     -1
    f[24,95,6]  R1079     1
    f[24,95,6]  marginal_25_6  1
    f[24,95,7]  R1002     -1
    f[24,95,7]  R1080     1
    f[24,95,7]  marginal_25_7  1
    f[24,96,6]  R1003     -1
    f[24,96,6]  R1080     1
    f[24,96,6]  marginal_25_6  1
    f[24,96,7]  R1003     -1
    f[24,96,7]  R1081     1
    f[24,96,7]  marginal_25_7  1
    f[24,97,6]  R1004     -1
    f[24,97,6]  R1081     1
    f[24,97,6]  marginal_25_6  1
    f[24,97,7]  R1004     -1
    f[24,97,7]  R1082     1
    f[24,97,7]  marginal_25_7  1
    f[24,98,6]  R1005     -1
    f[24,98,6]  R1082     1
    f[24,98,6]  marginal_25_6  1
    f[24,98,7]  R1005     -1
    f[24,98,7]  R1083     1
    f[24,98,7]  marginal_25_7  1
    f[24,99,6]  R1006     -1
    f[24,99,6]  R1083     1
    f[24,99,6]  marginal_25_6  1
    f[24,99,7]  R1006     -1
    f[24,99,7]  R1084     1
    f[24,99,7]  marginal_25_7  1
    f[24,100,6]  R1007     -1
    f[24,100,6]  R1084     1
    f[24,100,6]  marginal_25_6  1
    f[24,100,7]  R1007     -1
    f[24,100,7]  R1085     1
    f[24,100,7]  marginal_25_7  1
    f[24,101,6]  R1008     -1
    f[24,101,6]  R1085     1
    f[24,101,6]  marginal_25_6  1
    f[24,101,7]  R1008     -1
    f[24,101,7]  R1086     1
    f[24,101,7]  marginal_25_7  1
    f[24,102,6]  R1009     -1
    f[24,102,6]  R1086     1
    f[24,102,6]  marginal_25_6  1
    f[24,102,7]  R1009     -1
    f[24,102,7]  R1087     1
    f[24,102,7]  marginal_25_7  1
    f[24,103,6]  R1010     -1
    f[24,103,6]  R1087     1
    f[24,103,6]  marginal_25_6  1
    f[24,103,7]  R1010     -1
    f[24,103,7]  R1088     1
    f[24,103,7]  marginal_25_7  1
    f[24,104,6]  R1011     -1
    f[24,104,6]  R1088     1
    f[24,104,6]  marginal_25_6  1
    f[24,104,7]  R1011     -1
    f[24,104,7]  R1089     1
    f[24,104,7]  marginal_25_7  1
    f[24,105,6]  R1012     -1
    f[24,105,6]  R1089     1
    f[24,105,6]  marginal_25_6  1
    f[24,105,7]  R1012     -1
    f[24,105,7]  R1090     1
    f[24,105,7]  marginal_25_7  1
    f[24,106,6]  R1013     -1
    f[24,106,6]  R1090     1
    f[24,106,6]  marginal_25_6  1
    f[24,106,7]  R1013     -1
    f[24,106,7]  R1091     1
    f[24,106,7]  marginal_25_7  1
    f[24,107,6]  R1014     -1
    f[24,107,6]  R1091     1
    f[24,107,6]  marginal_25_6  1
    f[24,107,7]  R1014     -1
    f[24,107,7]  R1092     1
    f[24,107,7]  marginal_25_7  1
    f[24,108,6]  R1015     -1
    f[24,108,6]  R1092     1
    f[24,108,6]  marginal_25_6  1
    f[24,108,7]  R1015     -1
    f[24,108,7]  R1093     1
    f[24,108,7]  marginal_25_7  1
    f[24,109,6]  R1016     -1
    f[24,109,6]  R1093     1
    f[24,109,6]  marginal_25_6  1
    f[24,109,7]  R1016     -1
    f[24,109,7]  R1094     1
    f[24,109,7]  marginal_25_7  1
    f[24,110,6]  R1017     -1
    f[24,110,6]  R1094     1
    f[24,110,6]  marginal_25_6  1
    f[24,110,7]  R1017     -1
    f[24,110,7]  R1095     1
    f[24,110,7]  marginal_25_7  1
    f[24,111,6]  R1018     -1
    f[24,111,6]  R1095     1
    f[24,111,6]  marginal_25_6  1
    f[24,111,7]  R1018     -1
    f[24,111,7]  R1096     1
    f[24,111,7]  marginal_25_7  1
    f[24,112,6]  R1019     -1
    f[24,112,6]  R1096     1
    f[24,112,6]  marginal_25_6  1
    f[24,112,7]  R1019     -1
    f[24,112,7]  R1097     1
    f[24,112,7]  marginal_25_7  1
    f[24,113,6]  R1020     -1
    f[24,113,6]  R1097     1
    f[24,113,6]  marginal_25_6  1
    f[24,113,7]  R1020     -1
    f[24,113,7]  R1098     1
    f[24,113,7]  marginal_25_7  1
    f[24,114,6]  R1021     -1
    f[24,114,6]  R1098     1
    f[24,114,6]  marginal_25_6  1
    f[24,114,7]  R1021     -1
    f[24,114,7]  R1099     1
    f[24,114,7]  marginal_25_7  1
    f[24,115,6]  R1022     -1
    f[24,115,6]  R1099     1
    f[24,115,6]  marginal_25_6  1
    f[24,115,7]  R1022     -1
    f[24,115,7]  R1100     1
    f[24,115,7]  marginal_25_7  1
    f[24,116,6]  R1023     -1
    f[24,116,6]  R1100     1
    f[24,116,6]  marginal_25_6  1
    f[24,116,7]  R1023     -1
    f[24,116,7]  R1101     1
    f[24,116,7]  marginal_25_7  1
    f[24,117,6]  R1024     -1
    f[24,117,6]  R1101     1
    f[24,117,6]  marginal_25_6  1
    f[24,117,7]  R1024     -1
    f[24,117,7]  R1102     1
    f[24,117,7]  marginal_25_7  1
    f[24,118,6]  R1025     -1
    f[24,118,6]  R1102     1
    f[24,118,6]  marginal_25_6  1
    f[24,118,7]  R1025     -1
    f[24,118,7]  R1103     1
    f[24,118,7]  marginal_25_7  1
    f[24,119,6]  R1026     -1
    f[24,119,6]  R1103     1
    f[24,119,6]  marginal_25_6  1
    f[24,119,7]  R1026     -1
    f[24,119,7]  R1104     1
    f[24,119,7]  marginal_25_7  1
    f[24,120,6]  R1027     -1
    f[24,120,6]  R1104     1
    f[24,120,6]  marginal_25_6  1
    f[24,120,7]  R1027     -1
    f[24,120,7]  R1105     1
    f[24,120,7]  marginal_25_7  1
    f[24,121,6]  R1028     -1
    f[24,121,6]  R1105     1
    f[24,121,6]  marginal_25_6  1
    f[24,121,7]  R1028     -1
    f[24,121,7]  R1106     1
    f[24,121,7]  marginal_25_7  1
    f[24,122,6]  R1029     -1
    f[24,122,6]  R1106     1
    f[24,122,6]  marginal_25_6  1
    f[24,122,7]  R1029     -1
    f[24,122,7]  R1107     1
    f[24,122,7]  marginal_25_7  1
    f[24,123,6]  R1030     -1
    f[24,123,6]  R1107     1
    f[24,123,6]  marginal_25_6  1
    f[24,123,7]  R1030     -1
    f[24,123,7]  R1108     1
    f[24,123,7]  marginal_25_7  1
    f[24,124,6]  R1031     -1
    f[24,124,6]  R1108     1
    f[24,124,6]  marginal_25_6  1
    f[24,124,7]  R1031     -1
    f[24,124,7]  R1109     1
    f[24,124,7]  marginal_25_7  1
    f[24,125,6]  R1032     -1
    f[24,125,6]  R1109     1
    f[24,125,6]  marginal_25_6  1
    f[24,125,7]  R1032     -1
    f[24,125,7]  R1110     1
    f[24,125,7]  marginal_25_7  1
    f[24,126,6]  R1033     -1
    f[24,126,6]  R1110     1
    f[24,126,6]  marginal_25_6  1
    f[24,126,7]  R1033     -1
    f[24,126,7]  R1111     1
    f[24,126,7]  marginal_25_7  1
    f[24,127,6]  R1034     -1
    f[24,127,6]  R1111     1
    f[24,127,6]  marginal_25_6  1
    f[24,127,7]  R1034     -1
    f[24,127,7]  R1112     1
    f[24,127,7]  marginal_25_7  1
    f[24,128,6]  R1035     -1
    f[24,128,6]  R1112     1
    f[24,128,6]  marginal_25_6  1
    f[24,128,7]  R1035     -1
    f[24,128,7]  R1113     1
    f[24,128,7]  marginal_25_7  1
    f[24,129,6]  R1036     -1
    f[24,129,6]  R1113     1
    f[24,129,6]  marginal_25_6  1
    f[24,129,7]  R1036     -1
    f[24,129,7]  R1114     1
    f[24,129,7]  marginal_25_7  1
    f[24,130,6]  R1037     -1
    f[24,130,6]  R1114     1
    f[24,130,6]  marginal_25_6  1
    f[24,130,7]  R1037     -1
    f[24,130,7]  R1115     1
    f[24,130,7]  marginal_25_7  1
    f[24,131,6]  R1038     -1
    f[24,131,6]  R1115     1
    f[24,131,6]  marginal_25_6  1
    f[24,131,7]  R1038     -1
    f[24,131,7]  R1116     1
    f[24,131,7]  marginal_25_7  1
    f[24,132,6]  R1039     -1
    f[24,132,6]  R1116     1
    f[24,132,6]  marginal_25_6  1
    f[24,132,7]  R1039     -1
    f[24,132,7]  R1117     1
    f[24,132,7]  marginal_25_7  1
    f[24,133,6]  R1040     -1
    f[24,133,6]  R1117     1
    f[24,133,6]  marginal_25_6  1
    f[24,133,7]  R1040     -1
    f[24,133,7]  R1118     1
    f[24,133,7]  marginal_25_7  1
    f[24,134,6]  R1041     -1
    f[24,134,6]  R1118     1
    f[24,134,6]  marginal_25_6  1
    f[24,134,7]  R1041     -1
    f[24,134,7]  R1119     1
    f[24,134,7]  marginal_25_7  1
    f[24,135,6]  R1042     -1
    f[24,135,6]  R1119     1
    f[24,135,6]  marginal_25_6  1
    f[24,135,7]  R1042     -1
    f[24,135,7]  R1120     1
    f[24,135,7]  marginal_25_7  1
    f[24,136,6]  R1043     -1
    f[24,136,6]  R1120     1
    f[24,136,6]  marginal_25_6  1
    f[24,136,7]  R1043     -1
    f[24,136,7]  R1121     1
    f[24,136,7]  marginal_25_7  1
    f[24,137,6]  R1044     -1
    f[24,137,6]  R1121     1
    f[24,137,6]  marginal_25_6  1
    f[24,137,7]  R1044     -1
    f[24,137,7]  R1122     1
    f[24,137,7]  marginal_25_7  1
    f[24,138,6]  R1045     -1
    f[24,138,6]  R1122     1
    f[24,138,6]  marginal_25_6  1
    f[24,138,7]  R1045     -1
    f[24,138,7]  R1123     1
    f[24,138,7]  marginal_25_7  1
    f[24,139,6]  R1046     -1
    f[24,139,6]  R1123     1
    f[24,139,6]  marginal_25_6  1
    f[24,139,7]  R1046     -1
    f[24,139,7]  R1124     1
    f[24,139,7]  marginal_25_7  1
    f[24,140,6]  R1047     -1
    f[24,140,6]  R1124     1
    f[24,140,6]  marginal_25_6  1
    f[24,140,7]  R1047     -1
    f[24,140,7]  R1125     1
    f[24,140,7]  marginal_25_7  1
    f[24,141,6]  R1048     -1
    f[24,141,6]  R1125     1
    f[24,141,6]  marginal_25_6  1
    f[24,141,7]  R1048     -1
    f[24,141,7]  R1126     1
    f[24,141,7]  marginal_25_7  1
    f[24,142,6]  R1049     -1
    f[24,142,6]  R1126     1
    f[24,142,6]  marginal_25_6  1
    f[24,142,7]  R1049     -1
    f[24,142,7]  R1127     1
    f[24,142,7]  marginal_25_7  1
    f[24,143,6]  R1050     -1
    f[24,143,6]  R1127     1
    f[24,143,6]  marginal_25_6  1
    f[24,143,7]  R1050     -1
    f[24,143,7]  R1128     1
    f[24,143,7]  marginal_25_7  1
    f[24,144,6]  R1051     -1
    f[24,144,6]  R1128     1
    f[24,144,6]  marginal_25_6  1
    f[24,144,7]  R1051     -1
    f[24,144,7]  R1129     1
    f[24,144,7]  marginal_25_7  1
    f[24,145,6]  R1052     -1
    f[24,145,6]  R1129     1
    f[24,145,6]  marginal_25_6  1
    f[24,145,7]  R1052     -1
    f[24,145,7]  R1130     1
    f[24,145,7]  marginal_25_7  1
    f[24,146,6]  R1053     -1
    f[24,146,6]  R1130     1
    f[24,146,6]  marginal_25_6  1
    f[24,146,7]  R1053     -1
    f[24,146,7]  R1131     1
    f[24,146,7]  marginal_25_7  1
    f[24,147,6]  R1054     -1
    f[24,147,6]  R1131     1
    f[24,147,6]  marginal_25_6  1
    f[24,147,7]  R1054     -1
    f[24,147,7]  R1132     1
    f[24,147,7]  marginal_25_7  1
    f[24,148,6]  R1055     -1
    f[24,148,6]  R1132     1
    f[24,148,6]  marginal_25_6  1
    f[24,148,7]  R1055     -1
    f[24,148,7]  R1133     1
    f[24,148,7]  marginal_25_7  1
    f[24,149,6]  R1056     -1
    f[24,149,6]  R1133     1
    f[24,149,6]  marginal_25_6  1
    f[24,149,7]  R1056     -1
    f[24,149,7]  R1134     1
    f[24,149,7]  marginal_25_7  1
    f[24,150,6]  R1057     -1
    f[24,150,6]  R1134     1
    f[24,150,6]  marginal_25_6  1
    f[24,150,7]  R1057     -1
    f[24,150,7]  R1135     1
    f[24,150,7]  marginal_25_7  1
    f[24,151,6]  R1058     -1
    f[24,151,6]  R1135     1
    f[24,151,6]  marginal_25_6  1
    f[24,151,7]  R1058     -1
    f[24,151,7]  R1136     1
    f[24,151,7]  marginal_25_7  1
    f[24,152,6]  R1059     -1
    f[24,152,6]  R1136     1
    f[24,152,6]  marginal_25_6  1
    f[24,152,7]  R1059     -1
    f[24,152,7]  R1137     1
    f[24,152,7]  marginal_25_7  1
    f[24,153,6]  R1060     -1
    f[24,153,6]  R1137     1
    f[24,153,6]  marginal_25_6  1
    f[24,153,7]  R1060     -1
    f[24,153,7]  R1138     1
    f[24,153,7]  marginal_25_7  1
    f[24,154,6]  R1061     -1
    f[24,154,6]  R1138     1
    f[24,154,6]  marginal_25_6  1
    f[24,154,7]  R1061     -1
    f[24,154,7]  R1139     1
    f[24,154,7]  marginal_25_7  1
    f[24,155,6]  R1062     -1
    f[24,155,6]  R1139     1
    f[24,155,6]  marginal_25_6  1
    f[24,155,7]  R1062     -1
    f[24,155,7]  R1140     1
    f[24,155,7]  marginal_25_7  1
    f[24,156,6]  R1063     -1
    f[24,156,6]  R1140     1
    f[24,156,6]  marginal_25_6  1
    f[24,156,7]  R1063     -1
    f[24,156,7]  R1141     1
    f[24,156,7]  marginal_25_7  1
    f[24,157,6]  R1064     -1
    f[24,157,6]  R1141     1
    f[24,157,6]  marginal_25_6  1
    f[24,157,7]  R1064     -1
    f[24,157,7]  R1142     1
    f[24,157,7]  marginal_25_7  1
    f[24,158,6]  R1065     -1
    f[24,158,6]  R1142     1
    f[24,158,6]  marginal_25_6  1
    f[24,158,7]  R1065     -1
    f[24,158,7]  R1143     1
    f[24,158,7]  marginal_25_7  1
    f[24,159,6]  R1066     -1
    f[24,159,6]  R1143     1
    f[24,159,6]  marginal_25_6  1
    f[24,159,7]  R1066     -1
    f[24,159,7]  R1144     1
    f[24,159,7]  marginal_25_7  1
    f[24,160,6]  R1067     -1
    f[24,160,6]  R1144     1
    f[24,160,6]  marginal_25_6  1
    f[24,160,7]  R1067     -1
    f[24,160,7]  R1145     1
    f[24,160,7]  marginal_25_7  1
    f[24,161,6]  R1068     -1
    f[24,161,6]  R1145     1
    f[24,161,6]  marginal_25_6  1
    f[24,161,7]  R1068     -1
    f[24,161,7]  R1146     1
    f[24,161,7]  marginal_25_7  1
    f[24,162,6]  R1069     -1
    f[24,162,6]  R1146     1
    f[24,162,6]  marginal_25_6  1
    f[24,162,7]  R1069     -1
    f[24,162,7]  R1147     1
    f[24,162,7]  marginal_25_7  1
    f[24,163,6]  R1070     -1
    f[24,163,6]  R1147     1
    f[24,163,6]  marginal_25_6  1
    f[24,163,7]  R1070     -1
    f[24,163,7]  R1148     1
    f[24,163,7]  marginal_25_7  1
    f[24,164,6]  R1071     -1
    f[24,164,6]  R1148     1
    f[24,164,6]  marginal_25_6  1
    f[24,164,7]  R1071     -1
    f[24,164,7]  R1149     1
    f[24,164,7]  marginal_25_7  1
    f[24,165,6]  R1072     -1
    f[24,165,6]  R1149     1
    f[24,165,6]  marginal_25_6  1
    f[25,95,3]  R1073     -1
    f[25,95,3]  R1150     1
    f[25,95,3]  marginal_26_3  1
    f[25,95,4]  R1073     -1
    f[25,95,4]  R1151     1
    f[25,95,4]  marginal_26_4  1
    f[25,96,3]  R1074     -1
    f[25,96,3]  R1151     1
    f[25,96,3]  marginal_26_3  1
    f[25,96,4]  R1074     -1
    f[25,96,4]  R1152     1
    f[25,96,4]  marginal_26_4  1
    f[25,97,3]  R1075     -1
    f[25,97,3]  R1152     1
    f[25,97,3]  marginal_26_3  1
    f[25,97,4]  R1075     -1
    f[25,97,4]  R1153     1
    f[25,97,4]  marginal_26_4  1
    f[25,98,3]  R1076     -1
    f[25,98,3]  R1153     1
    f[25,98,3]  marginal_26_3  1
    f[25,98,4]  R1076     -1
    f[25,98,4]  R1154     1
    f[25,98,4]  marginal_26_4  1
    f[25,99,3]  R1077     -1
    f[25,99,3]  R1154     1
    f[25,99,3]  marginal_26_3  1
    f[25,99,4]  R1077     -1
    f[25,99,4]  R1155     1
    f[25,99,4]  marginal_26_4  1
    f[25,100,3]  R1078     -1
    f[25,100,3]  R1155     1
    f[25,100,3]  marginal_26_3  1
    f[25,100,4]  R1078     -1
    f[25,100,4]  R1156     1
    f[25,100,4]  marginal_26_4  1
    f[25,101,3]  R1079     -1
    f[25,101,3]  R1156     1
    f[25,101,3]  marginal_26_3  1
    f[25,101,4]  R1079     -1
    f[25,101,4]  R1157     1
    f[25,101,4]  marginal_26_4  1
    f[25,102,3]  R1080     -1
    f[25,102,3]  R1157     1
    f[25,102,3]  marginal_26_3  1
    f[25,102,4]  R1080     -1
    f[25,102,4]  R1158     1
    f[25,102,4]  marginal_26_4  1
    f[25,103,3]  R1081     -1
    f[25,103,3]  R1158     1
    f[25,103,3]  marginal_26_3  1
    f[25,103,4]  R1081     -1
    f[25,103,4]  R1159     1
    f[25,103,4]  marginal_26_4  1
    f[25,104,3]  R1082     -1
    f[25,104,3]  R1159     1
    f[25,104,3]  marginal_26_3  1
    f[25,104,4]  R1082     -1
    f[25,104,4]  R1160     1
    f[25,104,4]  marginal_26_4  1
    f[25,105,3]  R1083     -1
    f[25,105,3]  R1160     1
    f[25,105,3]  marginal_26_3  1
    f[25,105,4]  R1083     -1
    f[25,105,4]  R1161     1
    f[25,105,4]  marginal_26_4  1
    f[25,106,3]  R1084     -1
    f[25,106,3]  R1161     1
    f[25,106,3]  marginal_26_3  1
    f[25,106,4]  R1084     -1
    f[25,106,4]  R1162     1
    f[25,106,4]  marginal_26_4  1
    f[25,107,3]  R1085     -1
    f[25,107,3]  R1162     1
    f[25,107,3]  marginal_26_3  1
    f[25,107,4]  R1085     -1
    f[25,107,4]  R1163     1
    f[25,107,4]  marginal_26_4  1
    f[25,108,3]  R1086     -1
    f[25,108,3]  R1163     1
    f[25,108,3]  marginal_26_3  1
    f[25,108,4]  R1086     -1
    f[25,108,4]  R1164     1
    f[25,108,4]  marginal_26_4  1
    f[25,109,3]  R1087     -1
    f[25,109,3]  R1164     1
    f[25,109,3]  marginal_26_3  1
    f[25,109,4]  R1087     -1
    f[25,109,4]  R1165     1
    f[25,109,4]  marginal_26_4  1
    f[25,110,3]  R1088     -1
    f[25,110,3]  R1165     1
    f[25,110,3]  marginal_26_3  1
    f[25,110,4]  R1088     -1
    f[25,110,4]  R1166     1
    f[25,110,4]  marginal_26_4  1
    f[25,111,3]  R1089     -1
    f[25,111,3]  R1166     1
    f[25,111,3]  marginal_26_3  1
    f[25,111,4]  R1089     -1
    f[25,111,4]  R1167     1
    f[25,111,4]  marginal_26_4  1
    f[25,112,3]  R1090     -1
    f[25,112,3]  R1167     1
    f[25,112,3]  marginal_26_3  1
    f[25,112,4]  R1090     -1
    f[25,112,4]  R1168     1
    f[25,112,4]  marginal_26_4  1
    f[25,113,3]  R1091     -1
    f[25,113,3]  R1168     1
    f[25,113,3]  marginal_26_3  1
    f[25,113,4]  R1091     -1
    f[25,113,4]  R1169     1
    f[25,113,4]  marginal_26_4  1
    f[25,114,3]  R1092     -1
    f[25,114,3]  R1169     1
    f[25,114,3]  marginal_26_3  1
    f[25,114,4]  R1092     -1
    f[25,114,4]  R1170     1
    f[25,114,4]  marginal_26_4  1
    f[25,115,3]  R1093     -1
    f[25,115,3]  R1170     1
    f[25,115,3]  marginal_26_3  1
    f[25,115,4]  R1093     -1
    f[25,115,4]  R1171     1
    f[25,115,4]  marginal_26_4  1
    f[25,116,3]  R1094     -1
    f[25,116,3]  R1171     1
    f[25,116,3]  marginal_26_3  1
    f[25,116,4]  R1094     -1
    f[25,116,4]  R1172     1
    f[25,116,4]  marginal_26_4  1
    f[25,117,3]  R1095     -1
    f[25,117,3]  R1172     1
    f[25,117,3]  marginal_26_3  1
    f[25,117,4]  R1095     -1
    f[25,117,4]  R1173     1
    f[25,117,4]  marginal_26_4  1
    f[25,118,3]  R1096     -1
    f[25,118,3]  R1173     1
    f[25,118,3]  marginal_26_3  1
    f[25,118,4]  R1096     -1
    f[25,118,4]  R1174     1
    f[25,118,4]  marginal_26_4  1
    f[25,119,3]  R1097     -1
    f[25,119,3]  R1174     1
    f[25,119,3]  marginal_26_3  1
    f[25,119,4]  R1097     -1
    f[25,119,4]  R1175     1
    f[25,119,4]  marginal_26_4  1
    f[25,120,3]  R1098     -1
    f[25,120,3]  R1175     1
    f[25,120,3]  marginal_26_3  1
    f[25,120,4]  R1098     -1
    f[25,120,4]  R1176     1
    f[25,120,4]  marginal_26_4  1
    f[25,121,3]  R1099     -1
    f[25,121,3]  R1176     1
    f[25,121,3]  marginal_26_3  1
    f[25,121,4]  R1099     -1
    f[25,121,4]  R1177     1
    f[25,121,4]  marginal_26_4  1
    f[25,122,3]  R1100     -1
    f[25,122,3]  R1177     1
    f[25,122,3]  marginal_26_3  1
    f[25,122,4]  R1100     -1
    f[25,122,4]  R1178     1
    f[25,122,4]  marginal_26_4  1
    f[25,123,3]  R1101     -1
    f[25,123,3]  R1178     1
    f[25,123,3]  marginal_26_3  1
    f[25,123,4]  R1101     -1
    f[25,123,4]  R1179     1
    f[25,123,4]  marginal_26_4  1
    f[25,124,3]  R1102     -1
    f[25,124,3]  R1179     1
    f[25,124,3]  marginal_26_3  1
    f[25,124,4]  R1102     -1
    f[25,124,4]  R1180     1
    f[25,124,4]  marginal_26_4  1
    f[25,125,3]  R1103     -1
    f[25,125,3]  R1180     1
    f[25,125,3]  marginal_26_3  1
    f[25,125,4]  R1103     -1
    f[25,125,4]  R1181     1
    f[25,125,4]  marginal_26_4  1
    f[25,126,3]  R1104     -1
    f[25,126,3]  R1181     1
    f[25,126,3]  marginal_26_3  1
    f[25,126,4]  R1104     -1
    f[25,126,4]  R1182     1
    f[25,126,4]  marginal_26_4  1
    f[25,127,3]  R1105     -1
    f[25,127,3]  R1182     1
    f[25,127,3]  marginal_26_3  1
    f[25,127,4]  R1105     -1
    f[25,127,4]  R1183     1
    f[25,127,4]  marginal_26_4  1
    f[25,128,3]  R1106     -1
    f[25,128,3]  R1183     1
    f[25,128,3]  marginal_26_3  1
    f[25,128,4]  R1106     -1
    f[25,128,4]  R1184     1
    f[25,128,4]  marginal_26_4  1
    f[25,129,3]  R1107     -1
    f[25,129,3]  R1184     1
    f[25,129,3]  marginal_26_3  1
    f[25,129,4]  R1107     -1
    f[25,129,4]  R1185     1
    f[25,129,4]  marginal_26_4  1
    f[25,130,3]  R1108     -1
    f[25,130,3]  R1185     1
    f[25,130,3]  marginal_26_3  1
    f[25,130,4]  R1108     -1
    f[25,130,4]  R1186     1
    f[25,130,4]  marginal_26_4  1
    f[25,131,3]  R1109     -1
    f[25,131,3]  R1186     1
    f[25,131,3]  marginal_26_3  1
    f[25,131,4]  R1109     -1
    f[25,131,4]  R1187     1
    f[25,131,4]  marginal_26_4  1
    f[25,132,3]  R1110     -1
    f[25,132,3]  R1187     1
    f[25,132,3]  marginal_26_3  1
    f[25,132,4]  R1110     -1
    f[25,132,4]  R1188     1
    f[25,132,4]  marginal_26_4  1
    f[25,133,3]  R1111     -1
    f[25,133,3]  R1188     1
    f[25,133,3]  marginal_26_3  1
    f[25,133,4]  R1111     -1
    f[25,133,4]  R1189     1
    f[25,133,4]  marginal_26_4  1
    f[25,134,3]  R1112     -1
    f[25,134,3]  R1189     1
    f[25,134,3]  marginal_26_3  1
    f[25,134,4]  R1112     -1
    f[25,134,4]  R1190     1
    f[25,134,4]  marginal_26_4  1
    f[25,135,3]  R1113     -1
    f[25,135,3]  R1190     1
    f[25,135,3]  marginal_26_3  1
    f[25,135,4]  R1113     -1
    f[25,135,4]  R1191     1
    f[25,135,4]  marginal_26_4  1
    f[25,136,3]  R1114     -1
    f[25,136,3]  R1191     1
    f[25,136,3]  marginal_26_3  1
    f[25,136,4]  R1114     -1
    f[25,136,4]  R1192     1
    f[25,136,4]  marginal_26_4  1
    f[25,137,3]  R1115     -1
    f[25,137,3]  R1192     1
    f[25,137,3]  marginal_26_3  1
    f[25,137,4]  R1115     -1
    f[25,137,4]  R1193     1
    f[25,137,4]  marginal_26_4  1
    f[25,138,3]  R1116     -1
    f[25,138,3]  R1193     1
    f[25,138,3]  marginal_26_3  1
    f[25,138,4]  R1116     -1
    f[25,138,4]  R1194     1
    f[25,138,4]  marginal_26_4  1
    f[25,139,3]  R1117     -1
    f[25,139,3]  R1194     1
    f[25,139,3]  marginal_26_3  1
    f[25,139,4]  R1117     -1
    f[25,139,4]  R1195     1
    f[25,139,4]  marginal_26_4  1
    f[25,140,3]  R1118     -1
    f[25,140,3]  R1195     1
    f[25,140,3]  marginal_26_3  1
    f[25,140,4]  R1118     -1
    f[25,140,4]  R1196     1
    f[25,140,4]  marginal_26_4  1
    f[25,141,3]  R1119     -1
    f[25,141,3]  R1196     1
    f[25,141,3]  marginal_26_3  1
    f[25,141,4]  R1119     -1
    f[25,141,4]  R1197     1
    f[25,141,4]  marginal_26_4  1
    f[25,142,3]  R1120     -1
    f[25,142,3]  R1197     1
    f[25,142,3]  marginal_26_3  1
    f[25,142,4]  R1120     -1
    f[25,142,4]  R1198     1
    f[25,142,4]  marginal_26_4  1
    f[25,143,3]  R1121     -1
    f[25,143,3]  R1198     1
    f[25,143,3]  marginal_26_3  1
    f[25,143,4]  R1121     -1
    f[25,143,4]  R1199     1
    f[25,143,4]  marginal_26_4  1
    f[25,144,3]  R1122     -1
    f[25,144,3]  R1199     1
    f[25,144,3]  marginal_26_3  1
    f[25,144,4]  R1122     -1
    f[25,144,4]  R1200     1
    f[25,144,4]  marginal_26_4  1
    f[25,145,3]  R1123     -1
    f[25,145,3]  R1200     1
    f[25,145,3]  marginal_26_3  1
    f[25,145,4]  R1123     -1
    f[25,145,4]  R1201     1
    f[25,145,4]  marginal_26_4  1
    f[25,146,3]  R1124     -1
    f[25,146,3]  R1201     1
    f[25,146,3]  marginal_26_3  1
    f[25,146,4]  R1124     -1
    f[25,146,4]  R1202     1
    f[25,146,4]  marginal_26_4  1
    f[25,147,3]  R1125     -1
    f[25,147,3]  R1202     1
    f[25,147,3]  marginal_26_3  1
    f[25,147,4]  R1125     -1
    f[25,147,4]  R1203     1
    f[25,147,4]  marginal_26_4  1
    f[25,148,3]  R1126     -1
    f[25,148,3]  R1203     1
    f[25,148,3]  marginal_26_3  1
    f[25,148,4]  R1126     -1
    f[25,148,4]  R1204     1
    f[25,148,4]  marginal_26_4  1
    f[25,149,3]  R1127     -1
    f[25,149,3]  R1204     1
    f[25,149,3]  marginal_26_3  1
    f[25,149,4]  R1127     -1
    f[25,149,4]  R1205     1
    f[25,149,4]  marginal_26_4  1
    f[25,150,3]  R1128     -1
    f[25,150,3]  R1205     1
    f[25,150,3]  marginal_26_3  1
    f[25,150,4]  R1128     -1
    f[25,150,4]  R1206     1
    f[25,150,4]  marginal_26_4  1
    f[25,151,3]  R1129     -1
    f[25,151,3]  R1206     1
    f[25,151,3]  marginal_26_3  1
    f[25,151,4]  R1129     -1
    f[25,151,4]  R1207     1
    f[25,151,4]  marginal_26_4  1
    f[25,152,3]  R1130     -1
    f[25,152,3]  R1207     1
    f[25,152,3]  marginal_26_3  1
    f[25,152,4]  R1130     -1
    f[25,152,4]  R1208     1
    f[25,152,4]  marginal_26_4  1
    f[25,153,3]  R1131     -1
    f[25,153,3]  R1208     1
    f[25,153,3]  marginal_26_3  1
    f[25,153,4]  R1131     -1
    f[25,153,4]  R1209     1
    f[25,153,4]  marginal_26_4  1
    f[25,154,3]  R1132     -1
    f[25,154,3]  R1209     1
    f[25,154,3]  marginal_26_3  1
    f[25,154,4]  R1132     -1
    f[25,154,4]  R1210     1
    f[25,154,4]  marginal_26_4  1
    f[25,155,3]  R1133     -1
    f[25,155,3]  R1210     1
    f[25,155,3]  marginal_26_3  1
    f[25,155,4]  R1133     -1
    f[25,155,4]  R1211     1
    f[25,155,4]  marginal_26_4  1
    f[25,156,3]  R1134     -1
    f[25,156,3]  R1211     1
    f[25,156,3]  marginal_26_3  1
    f[25,156,4]  R1134     -1
    f[25,156,4]  R1212     1
    f[25,156,4]  marginal_26_4  1
    f[25,157,3]  R1135     -1
    f[25,157,3]  R1212     1
    f[25,157,3]  marginal_26_3  1
    f[25,157,4]  R1135     -1
    f[25,157,4]  R1213     1
    f[25,157,4]  marginal_26_4  1
    f[25,158,3]  R1136     -1
    f[25,158,3]  R1213     1
    f[25,158,3]  marginal_26_3  1
    f[25,158,4]  R1136     -1
    f[25,158,4]  R1214     1
    f[25,158,4]  marginal_26_4  1
    f[25,159,3]  R1137     -1
    f[25,159,3]  R1214     1
    f[25,159,3]  marginal_26_3  1
    f[25,159,4]  R1137     -1
    f[25,159,4]  R1215     1
    f[25,159,4]  marginal_26_4  1
    f[25,160,3]  R1138     -1
    f[25,160,3]  R1215     1
    f[25,160,3]  marginal_26_3  1
    f[25,160,4]  R1138     -1
    f[25,160,4]  R1216     1
    f[25,160,4]  marginal_26_4  1
    f[25,161,3]  R1139     -1
    f[25,161,3]  R1216     1
    f[25,161,3]  marginal_26_3  1
    f[25,161,4]  R1139     -1
    f[25,161,4]  R1217     1
    f[25,161,4]  marginal_26_4  1
    f[25,162,3]  R1140     -1
    f[25,162,3]  R1217     1
    f[25,162,3]  marginal_26_3  1
    f[25,162,4]  R1140     -1
    f[25,162,4]  R1218     1
    f[25,162,4]  marginal_26_4  1
    f[25,163,3]  R1141     -1
    f[25,163,3]  R1218     1
    f[25,163,3]  marginal_26_3  1
    f[25,163,4]  R1141     -1
    f[25,163,4]  R1219     1
    f[25,163,4]  marginal_26_4  1
    f[25,164,3]  R1142     -1
    f[25,164,3]  R1219     1
    f[25,164,3]  marginal_26_3  1
    f[25,164,4]  R1142     -1
    f[25,164,4]  R1220     1
    f[25,164,4]  marginal_26_4  1
    f[25,165,3]  R1143     -1
    f[25,165,3]  R1220     1
    f[25,165,3]  marginal_26_3  1
    f[25,165,4]  R1143     -1
    f[25,165,4]  R1221     1
    f[25,165,4]  marginal_26_4  1
    f[25,166,3]  R1144     -1
    f[25,166,3]  R1221     1
    f[25,166,3]  marginal_26_3  1
    f[25,166,4]  R1144     -1
    f[25,166,4]  R1222     1
    f[25,166,4]  marginal_26_4  1
    f[25,167,3]  R1145     -1
    f[25,167,3]  R1222     1
    f[25,167,3]  marginal_26_3  1
    f[25,167,4]  R1145     -1
    f[25,167,4]  R1223     1
    f[25,167,4]  marginal_26_4  1
    f[25,168,3]  R1146     -1
    f[25,168,3]  R1223     1
    f[25,168,3]  marginal_26_3  1
    f[25,168,4]  R1146     -1
    f[25,168,4]  R1224     1
    f[25,168,4]  marginal_26_4  1
    f[25,169,3]  R1147     -1
    f[25,169,3]  R1224     1
    f[25,169,3]  marginal_26_3  1
    f[25,169,4]  R1147     -1
    f[25,169,4]  R1225     1
    f[25,169,4]  marginal_26_4  1
    f[25,170,3]  R1148     -1
    f[25,170,3]  R1225     1
    f[25,170,3]  marginal_26_3  1
    f[25,170,4]  R1148     -1
    f[25,170,4]  R1226     1
    f[25,170,4]  marginal_26_4  1
    f[25,171,3]  R1149     -1
    f[25,171,3]  R1226     1
    f[25,171,3]  marginal_26_3  1
    f[26,98,6]  R1150     -1
    f[26,98,6]  R1227     1
    f[26,98,6]  marginal_27_6  1
    f[26,98,7]  R1150     -1
    f[26,98,7]  R1228     1
    f[26,98,7]  marginal_27_7  1
    f[26,99,6]  R1151     -1
    f[26,99,6]  R1228     1
    f[26,99,6]  marginal_27_6  1
    f[26,99,7]  R1151     -1
    f[26,99,7]  R1229     1
    f[26,99,7]  marginal_27_7  1
    f[26,100,6]  R1152     -1
    f[26,100,6]  R1229     1
    f[26,100,6]  marginal_27_6  1
    f[26,100,7]  R1152     -1
    f[26,100,7]  R1230     1
    f[26,100,7]  marginal_27_7  1
    f[26,101,6]  R1153     -1
    f[26,101,6]  R1230     1
    f[26,101,6]  marginal_27_6  1
    f[26,101,7]  R1153     -1
    f[26,101,7]  R1231     1
    f[26,101,7]  marginal_27_7  1
    f[26,102,6]  R1154     -1
    f[26,102,6]  R1231     1
    f[26,102,6]  marginal_27_6  1
    f[26,102,7]  R1154     -1
    f[26,102,7]  R1232     1
    f[26,102,7]  marginal_27_7  1
    f[26,103,6]  R1155     -1
    f[26,103,6]  R1232     1
    f[26,103,6]  marginal_27_6  1
    f[26,103,7]  R1155     -1
    f[26,103,7]  R1233     1
    f[26,103,7]  marginal_27_7  1
    f[26,104,6]  R1156     -1
    f[26,104,6]  R1233     1
    f[26,104,6]  marginal_27_6  1
    f[26,104,7]  R1156     -1
    f[26,104,7]  R1234     1
    f[26,104,7]  marginal_27_7  1
    f[26,105,6]  R1157     -1
    f[26,105,6]  R1234     1
    f[26,105,6]  marginal_27_6  1
    f[26,105,7]  R1157     -1
    f[26,105,7]  R1235     1
    f[26,105,7]  marginal_27_7  1
    f[26,106,6]  R1158     -1
    f[26,106,6]  R1235     1
    f[26,106,6]  marginal_27_6  1
    f[26,106,7]  R1158     -1
    f[26,106,7]  R1236     1
    f[26,106,7]  marginal_27_7  1
    f[26,107,6]  R1159     -1
    f[26,107,6]  R1236     1
    f[26,107,6]  marginal_27_6  1
    f[26,107,7]  R1159     -1
    f[26,107,7]  R1237     1
    f[26,107,7]  marginal_27_7  1
    f[26,108,6]  R1160     -1
    f[26,108,6]  R1237     1
    f[26,108,6]  marginal_27_6  1
    f[26,108,7]  R1160     -1
    f[26,108,7]  R1238     1
    f[26,108,7]  marginal_27_7  1
    f[26,109,6]  R1161     -1
    f[26,109,6]  R1238     1
    f[26,109,6]  marginal_27_6  1
    f[26,109,7]  R1161     -1
    f[26,109,7]  R1239     1
    f[26,109,7]  marginal_27_7  1
    f[26,110,6]  R1162     -1
    f[26,110,6]  R1239     1
    f[26,110,6]  marginal_27_6  1
    f[26,110,7]  R1162     -1
    f[26,110,7]  R1240     1
    f[26,110,7]  marginal_27_7  1
    f[26,111,6]  R1163     -1
    f[26,111,6]  R1240     1
    f[26,111,6]  marginal_27_6  1
    f[26,111,7]  R1163     -1
    f[26,111,7]  R1241     1
    f[26,111,7]  marginal_27_7  1
    f[26,112,6]  R1164     -1
    f[26,112,6]  R1241     1
    f[26,112,6]  marginal_27_6  1
    f[26,112,7]  R1164     -1
    f[26,112,7]  R1242     1
    f[26,112,7]  marginal_27_7  1
    f[26,113,6]  R1165     -1
    f[26,113,6]  R1242     1
    f[26,113,6]  marginal_27_6  1
    f[26,113,7]  R1165     -1
    f[26,113,7]  R1243     1
    f[26,113,7]  marginal_27_7  1
    f[26,114,6]  R1166     -1
    f[26,114,6]  R1243     1
    f[26,114,6]  marginal_27_6  1
    f[26,114,7]  R1166     -1
    f[26,114,7]  R1244     1
    f[26,114,7]  marginal_27_7  1
    f[26,115,6]  R1167     -1
    f[26,115,6]  R1244     1
    f[26,115,6]  marginal_27_6  1
    f[26,115,7]  R1167     -1
    f[26,115,7]  R1245     1
    f[26,115,7]  marginal_27_7  1
    f[26,116,6]  R1168     -1
    f[26,116,6]  R1245     1
    f[26,116,6]  marginal_27_6  1
    f[26,116,7]  R1168     -1
    f[26,116,7]  R1246     1
    f[26,116,7]  marginal_27_7  1
    f[26,117,6]  R1169     -1
    f[26,117,6]  R1246     1
    f[26,117,6]  marginal_27_6  1
    f[26,117,7]  R1169     -1
    f[26,117,7]  R1247     1
    f[26,117,7]  marginal_27_7  1
    f[26,118,6]  R1170     -1
    f[26,118,6]  R1247     1
    f[26,118,6]  marginal_27_6  1
    f[26,118,7]  R1170     -1
    f[26,118,7]  R1248     1
    f[26,118,7]  marginal_27_7  1
    f[26,119,6]  R1171     -1
    f[26,119,6]  R1248     1
    f[26,119,6]  marginal_27_6  1
    f[26,119,7]  R1171     -1
    f[26,119,7]  R1249     1
    f[26,119,7]  marginal_27_7  1
    f[26,120,6]  R1172     -1
    f[26,120,6]  R1249     1
    f[26,120,6]  marginal_27_6  1
    f[26,120,7]  R1172     -1
    f[26,120,7]  R1250     1
    f[26,120,7]  marginal_27_7  1
    f[26,121,6]  R1173     -1
    f[26,121,6]  R1250     1
    f[26,121,6]  marginal_27_6  1
    f[26,121,7]  R1173     -1
    f[26,121,7]  R1251     1
    f[26,121,7]  marginal_27_7  1
    f[26,122,6]  R1174     -1
    f[26,122,6]  R1251     1
    f[26,122,6]  marginal_27_6  1
    f[26,122,7]  R1174     -1
    f[26,122,7]  R1252     1
    f[26,122,7]  marginal_27_7  1
    f[26,123,6]  R1175     -1
    f[26,123,6]  R1252     1
    f[26,123,6]  marginal_27_6  1
    f[26,123,7]  R1175     -1
    f[26,123,7]  R1253     1
    f[26,123,7]  marginal_27_7  1
    f[26,124,6]  R1176     -1
    f[26,124,6]  R1253     1
    f[26,124,6]  marginal_27_6  1
    f[26,124,7]  R1176     -1
    f[26,124,7]  R1254     1
    f[26,124,7]  marginal_27_7  1
    f[26,125,6]  R1177     -1
    f[26,125,6]  R1254     1
    f[26,125,6]  marginal_27_6  1
    f[26,125,7]  R1177     -1
    f[26,125,7]  R1255     1
    f[26,125,7]  marginal_27_7  1
    f[26,126,6]  R1178     -1
    f[26,126,6]  R1255     1
    f[26,126,6]  marginal_27_6  1
    f[26,126,7]  R1178     -1
    f[26,126,7]  R1256     1
    f[26,126,7]  marginal_27_7  1
    f[26,127,6]  R1179     -1
    f[26,127,6]  R1256     1
    f[26,127,6]  marginal_27_6  1
    f[26,127,7]  R1179     -1
    f[26,127,7]  R1257     1
    f[26,127,7]  marginal_27_7  1
    f[26,128,6]  R1180     -1
    f[26,128,6]  R1257     1
    f[26,128,6]  marginal_27_6  1
    f[26,128,7]  R1180     -1
    f[26,128,7]  R1258     1
    f[26,128,7]  marginal_27_7  1
    f[26,129,6]  R1181     -1
    f[26,129,6]  R1258     1
    f[26,129,6]  marginal_27_6  1
    f[26,129,7]  R1181     -1
    f[26,129,7]  R1259     1
    f[26,129,7]  marginal_27_7  1
    f[26,130,6]  R1182     -1
    f[26,130,6]  R1259     1
    f[26,130,6]  marginal_27_6  1
    f[26,130,7]  R1182     -1
    f[26,130,7]  R1260     1
    f[26,130,7]  marginal_27_7  1
    f[26,131,6]  R1183     -1
    f[26,131,6]  R1260     1
    f[26,131,6]  marginal_27_6  1
    f[26,131,7]  R1183     -1
    f[26,131,7]  R1261     1
    f[26,131,7]  marginal_27_7  1
    f[26,132,6]  R1184     -1
    f[26,132,6]  R1261     1
    f[26,132,6]  marginal_27_6  1
    f[26,132,7]  R1184     -1
    f[26,132,7]  R1262     1
    f[26,132,7]  marginal_27_7  1
    f[26,133,6]  R1185     -1
    f[26,133,6]  R1262     1
    f[26,133,6]  marginal_27_6  1
    f[26,133,7]  R1185     -1
    f[26,133,7]  R1263     1
    f[26,133,7]  marginal_27_7  1
    f[26,134,6]  R1186     -1
    f[26,134,6]  R1263     1
    f[26,134,6]  marginal_27_6  1
    f[26,134,7]  R1186     -1
    f[26,134,7]  R1264     1
    f[26,134,7]  marginal_27_7  1
    f[26,135,6]  R1187     -1
    f[26,135,6]  R1264     1
    f[26,135,6]  marginal_27_6  1
    f[26,135,7]  R1187     -1
    f[26,135,7]  R1265     1
    f[26,135,7]  marginal_27_7  1
    f[26,136,6]  R1188     -1
    f[26,136,6]  R1265     1
    f[26,136,6]  marginal_27_6  1
    f[26,136,7]  R1188     -1
    f[26,136,7]  R1266     1
    f[26,136,7]  marginal_27_7  1
    f[26,137,6]  R1189     -1
    f[26,137,6]  R1266     1
    f[26,137,6]  marginal_27_6  1
    f[26,137,7]  R1189     -1
    f[26,137,7]  R1267     1
    f[26,137,7]  marginal_27_7  1
    f[26,138,6]  R1190     -1
    f[26,138,6]  R1267     1
    f[26,138,6]  marginal_27_6  1
    f[26,138,7]  R1190     -1
    f[26,138,7]  R1268     1
    f[26,138,7]  marginal_27_7  1
    f[26,139,6]  R1191     -1
    f[26,139,6]  R1268     1
    f[26,139,6]  marginal_27_6  1
    f[26,139,7]  R1191     -1
    f[26,139,7]  R1269     1
    f[26,139,7]  marginal_27_7  1
    f[26,140,6]  R1192     -1
    f[26,140,6]  R1269     1
    f[26,140,6]  marginal_27_6  1
    f[26,140,7]  R1192     -1
    f[26,140,7]  R1270     1
    f[26,140,7]  marginal_27_7  1
    f[26,141,6]  R1193     -1
    f[26,141,6]  R1270     1
    f[26,141,6]  marginal_27_6  1
    f[26,141,7]  R1193     -1
    f[26,141,7]  R1271     1
    f[26,141,7]  marginal_27_7  1
    f[26,142,6]  R1194     -1
    f[26,142,6]  R1271     1
    f[26,142,6]  marginal_27_6  1
    f[26,142,7]  R1194     -1
    f[26,142,7]  R1272     1
    f[26,142,7]  marginal_27_7  1
    f[26,143,6]  R1195     -1
    f[26,143,6]  R1272     1
    f[26,143,6]  marginal_27_6  1
    f[26,143,7]  R1195     -1
    f[26,143,7]  R1273     1
    f[26,143,7]  marginal_27_7  1
    f[26,144,6]  R1196     -1
    f[26,144,6]  R1273     1
    f[26,144,6]  marginal_27_6  1
    f[26,144,7]  R1196     -1
    f[26,144,7]  R1274     1
    f[26,144,7]  marginal_27_7  1
    f[26,145,6]  R1197     -1
    f[26,145,6]  R1274     1
    f[26,145,6]  marginal_27_6  1
    f[26,145,7]  R1197     -1
    f[26,145,7]  R1275     1
    f[26,145,7]  marginal_27_7  1
    f[26,146,6]  R1198     -1
    f[26,146,6]  R1275     1
    f[26,146,6]  marginal_27_6  1
    f[26,146,7]  R1198     -1
    f[26,146,7]  R1276     1
    f[26,146,7]  marginal_27_7  1
    f[26,147,6]  R1199     -1
    f[26,147,6]  R1276     1
    f[26,147,6]  marginal_27_6  1
    f[26,147,7]  R1199     -1
    f[26,147,7]  R1277     1
    f[26,147,7]  marginal_27_7  1
    f[26,148,6]  R1200     -1
    f[26,148,6]  R1277     1
    f[26,148,6]  marginal_27_6  1
    f[26,148,7]  R1200     -1
    f[26,148,7]  R1278     1
    f[26,148,7]  marginal_27_7  1
    f[26,149,6]  R1201     -1
    f[26,149,6]  R1278     1
    f[26,149,6]  marginal_27_6  1
    f[26,149,7]  R1201     -1
    f[26,149,7]  R1279     1
    f[26,149,7]  marginal_27_7  1
    f[26,150,6]  R1202     -1
    f[26,150,6]  R1279     1
    f[26,150,6]  marginal_27_6  1
    f[26,150,7]  R1202     -1
    f[26,150,7]  R1280     1
    f[26,150,7]  marginal_27_7  1
    f[26,151,6]  R1203     -1
    f[26,151,6]  R1280     1
    f[26,151,6]  marginal_27_6  1
    f[26,151,7]  R1203     -1
    f[26,151,7]  R1281     1
    f[26,151,7]  marginal_27_7  1
    f[26,152,6]  R1204     -1
    f[26,152,6]  R1281     1
    f[26,152,6]  marginal_27_6  1
    f[26,152,7]  R1204     -1
    f[26,152,7]  R1282     1
    f[26,152,7]  marginal_27_7  1
    f[26,153,6]  R1205     -1
    f[26,153,6]  R1282     1
    f[26,153,6]  marginal_27_6  1
    f[26,153,7]  R1205     -1
    f[26,153,7]  R1283     1
    f[26,153,7]  marginal_27_7  1
    f[26,154,6]  R1206     -1
    f[26,154,6]  R1283     1
    f[26,154,6]  marginal_27_6  1
    f[26,154,7]  R1206     -1
    f[26,154,7]  R1284     1
    f[26,154,7]  marginal_27_7  1
    f[26,155,6]  R1207     -1
    f[26,155,6]  R1284     1
    f[26,155,6]  marginal_27_6  1
    f[26,155,7]  R1207     -1
    f[26,155,7]  R1285     1
    f[26,155,7]  marginal_27_7  1
    f[26,156,6]  R1208     -1
    f[26,156,6]  R1285     1
    f[26,156,6]  marginal_27_6  1
    f[26,156,7]  R1208     -1
    f[26,156,7]  R1286     1
    f[26,156,7]  marginal_27_7  1
    f[26,157,6]  R1209     -1
    f[26,157,6]  R1286     1
    f[26,157,6]  marginal_27_6  1
    f[26,157,7]  R1209     -1
    f[26,157,7]  R1287     1
    f[26,157,7]  marginal_27_7  1
    f[26,158,6]  R1210     -1
    f[26,158,6]  R1287     1
    f[26,158,6]  marginal_27_6  1
    f[26,158,7]  R1210     -1
    f[26,158,7]  R1288     1
    f[26,158,7]  marginal_27_7  1
    f[26,159,6]  R1211     -1
    f[26,159,6]  R1288     1
    f[26,159,6]  marginal_27_6  1
    f[26,159,7]  R1211     -1
    f[26,159,7]  R1289     1
    f[26,159,7]  marginal_27_7  1
    f[26,160,6]  R1212     -1
    f[26,160,6]  R1289     1
    f[26,160,6]  marginal_27_6  1
    f[26,160,7]  R1212     -1
    f[26,160,7]  R1290     1
    f[26,160,7]  marginal_27_7  1
    f[26,161,6]  R1213     -1
    f[26,161,6]  R1290     1
    f[26,161,6]  marginal_27_6  1
    f[26,161,7]  R1213     -1
    f[26,161,7]  R1291     1
    f[26,161,7]  marginal_27_7  1
    f[26,162,6]  R1214     -1
    f[26,162,6]  R1291     1
    f[26,162,6]  marginal_27_6  1
    f[26,162,7]  R1214     -1
    f[26,162,7]  R1292     1
    f[26,162,7]  marginal_27_7  1
    f[26,163,6]  R1215     -1
    f[26,163,6]  R1292     1
    f[26,163,6]  marginal_27_6  1
    f[26,163,7]  R1215     -1
    f[26,163,7]  R1293     1
    f[26,163,7]  marginal_27_7  1
    f[26,164,6]  R1216     -1
    f[26,164,6]  R1293     1
    f[26,164,6]  marginal_27_6  1
    f[26,164,7]  R1216     -1
    f[26,164,7]  R1294     1
    f[26,164,7]  marginal_27_7  1
    f[26,165,6]  R1217     -1
    f[26,165,6]  R1294     1
    f[26,165,6]  marginal_27_6  1
    f[26,165,7]  R1217     -1
    f[26,165,7]  R1295     1
    f[26,165,7]  marginal_27_7  1
    f[26,166,6]  R1218     -1
    f[26,166,6]  R1295     1
    f[26,166,6]  marginal_27_6  1
    f[26,166,7]  R1218     -1
    f[26,166,7]  R1296     1
    f[26,166,7]  marginal_27_7  1
    f[26,167,6]  R1219     -1
    f[26,167,6]  R1296     1
    f[26,167,6]  marginal_27_6  1
    f[26,167,7]  R1219     -1
    f[26,167,7]  R1297     1
    f[26,167,7]  marginal_27_7  1
    f[26,168,6]  R1220     -1
    f[26,168,6]  R1297     1
    f[26,168,6]  marginal_27_6  1
    f[26,168,7]  R1220     -1
    f[26,168,7]  R1298     1
    f[26,168,7]  marginal_27_7  1
    f[26,169,6]  R1221     -1
    f[26,169,6]  R1298     1
    f[26,169,6]  marginal_27_6  1
    f[26,169,7]  R1221     -1
    f[26,169,7]  R1299     1
    f[26,169,7]  marginal_27_7  1
    f[26,170,6]  R1222     -1
    f[26,170,6]  R1299     1
    f[26,170,6]  marginal_27_6  1
    f[26,170,7]  R1222     -1
    f[26,170,7]  R1300     1
    f[26,170,7]  marginal_27_7  1
    f[26,171,6]  R1223     -1
    f[26,171,6]  R1300     1
    f[26,171,6]  marginal_27_6  1
    f[26,171,7]  R1223     -1
    f[26,171,7]  R1301     1
    f[26,171,7]  marginal_27_7  1
    f[26,172,6]  R1224     -1
    f[26,172,6]  R1301     1
    f[26,172,6]  marginal_27_6  1
    f[26,172,7]  R1224     -1
    f[26,172,7]  R1302     1
    f[26,172,7]  marginal_27_7  1
    f[26,173,6]  R1225     -1
    f[26,173,6]  R1302     1
    f[26,173,6]  marginal_27_6  1
    f[26,173,7]  R1225     -1
    f[26,173,7]  R1303     1
    f[26,173,7]  marginal_27_7  1
    f[26,174,6]  R1226     -1
    f[26,174,6]  R1303     1
    f[26,174,6]  marginal_27_6  1
    f[27,104,6]  R1227     -1
    f[27,104,6]  R1304     1
    f[27,104,6]  marginal_28_6  1
    f[27,104,8]  R1227     -1
    f[27,104,8]  R1306     1
    f[27,104,8]  marginal_28_8  1
    f[27,105,6]  R1228     -1
    f[27,105,6]  R1305     1
    f[27,105,6]  marginal_28_6  1
    f[27,105,8]  R1228     -1
    f[27,105,8]  R1307     1
    f[27,105,8]  marginal_28_8  1
    f[27,106,6]  R1229     -1
    f[27,106,6]  R1306     1
    f[27,106,6]  marginal_28_6  1
    f[27,106,8]  R1229     -1
    f[27,106,8]  R1308     1
    f[27,106,8]  marginal_28_8  1
    f[27,107,6]  R1230     -1
    f[27,107,6]  R1307     1
    f[27,107,6]  marginal_28_6  1
    f[27,107,8]  R1230     -1
    f[27,107,8]  R1309     1
    f[27,107,8]  marginal_28_8  1
    f[27,108,6]  R1231     -1
    f[27,108,6]  R1308     1
    f[27,108,6]  marginal_28_6  1
    f[27,108,8]  R1231     -1
    f[27,108,8]  R1310     1
    f[27,108,8]  marginal_28_8  1
    f[27,109,6]  R1232     -1
    f[27,109,6]  R1309     1
    f[27,109,6]  marginal_28_6  1
    f[27,109,8]  R1232     -1
    f[27,109,8]  R1311     1
    f[27,109,8]  marginal_28_8  1
    f[27,110,6]  R1233     -1
    f[27,110,6]  R1310     1
    f[27,110,6]  marginal_28_6  1
    f[27,110,8]  R1233     -1
    f[27,110,8]  R1312     1
    f[27,110,8]  marginal_28_8  1
    f[27,111,6]  R1234     -1
    f[27,111,6]  R1311     1
    f[27,111,6]  marginal_28_6  1
    f[27,111,8]  R1234     -1
    f[27,111,8]  R1313     1
    f[27,111,8]  marginal_28_8  1
    f[27,112,6]  R1235     -1
    f[27,112,6]  R1312     1
    f[27,112,6]  marginal_28_6  1
    f[27,112,8]  R1235     -1
    f[27,112,8]  R1314     1
    f[27,112,8]  marginal_28_8  1
    f[27,113,6]  R1236     -1
    f[27,113,6]  R1313     1
    f[27,113,6]  marginal_28_6  1
    f[27,113,8]  R1236     -1
    f[27,113,8]  R1315     1
    f[27,113,8]  marginal_28_8  1
    f[27,114,6]  R1237     -1
    f[27,114,6]  R1314     1
    f[27,114,6]  marginal_28_6  1
    f[27,114,8]  R1237     -1
    f[27,114,8]  R1316     1
    f[27,114,8]  marginal_28_8  1
    f[27,115,6]  R1238     -1
    f[27,115,6]  R1315     1
    f[27,115,6]  marginal_28_6  1
    f[27,115,8]  R1238     -1
    f[27,115,8]  R1317     1
    f[27,115,8]  marginal_28_8  1
    f[27,116,6]  R1239     -1
    f[27,116,6]  R1316     1
    f[27,116,6]  marginal_28_6  1
    f[27,116,8]  R1239     -1
    f[27,116,8]  R1318     1
    f[27,116,8]  marginal_28_8  1
    f[27,117,6]  R1240     -1
    f[27,117,6]  R1317     1
    f[27,117,6]  marginal_28_6  1
    f[27,117,8]  R1240     -1
    f[27,117,8]  R1319     1
    f[27,117,8]  marginal_28_8  1
    f[27,118,6]  R1241     -1
    f[27,118,6]  R1318     1
    f[27,118,6]  marginal_28_6  1
    f[27,118,8]  R1241     -1
    f[27,118,8]  R1320     1
    f[27,118,8]  marginal_28_8  1
    f[27,119,6]  R1242     -1
    f[27,119,6]  R1319     1
    f[27,119,6]  marginal_28_6  1
    f[27,119,8]  R1242     -1
    f[27,119,8]  R1321     1
    f[27,119,8]  marginal_28_8  1
    f[27,120,6]  R1243     -1
    f[27,120,6]  R1320     1
    f[27,120,6]  marginal_28_6  1
    f[27,120,8]  R1243     -1
    f[27,120,8]  R1322     1
    f[27,120,8]  marginal_28_8  1
    f[27,121,6]  R1244     -1
    f[27,121,6]  R1321     1
    f[27,121,6]  marginal_28_6  1
    f[27,121,8]  R1244     -1
    f[27,121,8]  R1323     1
    f[27,121,8]  marginal_28_8  1
    f[27,122,6]  R1245     -1
    f[27,122,6]  R1322     1
    f[27,122,6]  marginal_28_6  1
    f[27,122,8]  R1245     -1
    f[27,122,8]  R1324     1
    f[27,122,8]  marginal_28_8  1
    f[27,123,6]  R1246     -1
    f[27,123,6]  R1323     1
    f[27,123,6]  marginal_28_6  1
    f[27,123,8]  R1246     -1
    f[27,123,8]  R1325     1
    f[27,123,8]  marginal_28_8  1
    f[27,124,6]  R1247     -1
    f[27,124,6]  R1324     1
    f[27,124,6]  marginal_28_6  1
    f[27,124,8]  R1247     -1
    f[27,124,8]  R1326     1
    f[27,124,8]  marginal_28_8  1
    f[27,125,6]  R1248     -1
    f[27,125,6]  R1325     1
    f[27,125,6]  marginal_28_6  1
    f[27,125,8]  R1248     -1
    f[27,125,8]  R1327     1
    f[27,125,8]  marginal_28_8  1
    f[27,126,6]  R1249     -1
    f[27,126,6]  R1326     1
    f[27,126,6]  marginal_28_6  1
    f[27,126,8]  R1249     -1
    f[27,126,8]  R1328     1
    f[27,126,8]  marginal_28_8  1
    f[27,127,6]  R1250     -1
    f[27,127,6]  R1327     1
    f[27,127,6]  marginal_28_6  1
    f[27,127,8]  R1250     -1
    f[27,127,8]  R1329     1
    f[27,127,8]  marginal_28_8  1
    f[27,128,6]  R1251     -1
    f[27,128,6]  R1328     1
    f[27,128,6]  marginal_28_6  1
    f[27,128,8]  R1251     -1
    f[27,128,8]  R1330     1
    f[27,128,8]  marginal_28_8  1
    f[27,129,6]  R1252     -1
    f[27,129,6]  R1329     1
    f[27,129,6]  marginal_28_6  1
    f[27,129,8]  R1252     -1
    f[27,129,8]  R1331     1
    f[27,129,8]  marginal_28_8  1
    f[27,130,6]  R1253     -1
    f[27,130,6]  R1330     1
    f[27,130,6]  marginal_28_6  1
    f[27,130,8]  R1253     -1
    f[27,130,8]  R1332     1
    f[27,130,8]  marginal_28_8  1
    f[27,131,6]  R1254     -1
    f[27,131,6]  R1331     1
    f[27,131,6]  marginal_28_6  1
    f[27,131,8]  R1254     -1
    f[27,131,8]  R1333     1
    f[27,131,8]  marginal_28_8  1
    f[27,132,6]  R1255     -1
    f[27,132,6]  R1332     1
    f[27,132,6]  marginal_28_6  1
    f[27,132,8]  R1255     -1
    f[27,132,8]  R1334     1
    f[27,132,8]  marginal_28_8  1
    f[27,133,6]  R1256     -1
    f[27,133,6]  R1333     1
    f[27,133,6]  marginal_28_6  1
    f[27,133,8]  R1256     -1
    f[27,133,8]  R1335     1
    f[27,133,8]  marginal_28_8  1
    f[27,134,6]  R1257     -1
    f[27,134,6]  R1334     1
    f[27,134,6]  marginal_28_6  1
    f[27,134,8]  R1257     -1
    f[27,134,8]  R1336     1
    f[27,134,8]  marginal_28_8  1
    f[27,135,6]  R1258     -1
    f[27,135,6]  R1335     1
    f[27,135,6]  marginal_28_6  1
    f[27,135,8]  R1258     -1
    f[27,135,8]  R1337     1
    f[27,135,8]  marginal_28_8  1
    f[27,136,6]  R1259     -1
    f[27,136,6]  R1336     1
    f[27,136,6]  marginal_28_6  1
    f[27,136,8]  R1259     -1
    f[27,136,8]  R1338     1
    f[27,136,8]  marginal_28_8  1
    f[27,137,6]  R1260     -1
    f[27,137,6]  R1337     1
    f[27,137,6]  marginal_28_6  1
    f[27,137,8]  R1260     -1
    f[27,137,8]  R1339     1
    f[27,137,8]  marginal_28_8  1
    f[27,138,6]  R1261     -1
    f[27,138,6]  R1338     1
    f[27,138,6]  marginal_28_6  1
    f[27,138,8]  R1261     -1
    f[27,138,8]  R1340     1
    f[27,138,8]  marginal_28_8  1
    f[27,139,6]  R1262     -1
    f[27,139,6]  R1339     1
    f[27,139,6]  marginal_28_6  1
    f[27,139,8]  R1262     -1
    f[27,139,8]  R1341     1
    f[27,139,8]  marginal_28_8  1
    f[27,140,6]  R1263     -1
    f[27,140,6]  R1340     1
    f[27,140,6]  marginal_28_6  1
    f[27,140,8]  R1263     -1
    f[27,140,8]  R1342     1
    f[27,140,8]  marginal_28_8  1
    f[27,141,6]  R1264     -1
    f[27,141,6]  R1341     1
    f[27,141,6]  marginal_28_6  1
    f[27,141,8]  R1264     -1
    f[27,141,8]  R1343     1
    f[27,141,8]  marginal_28_8  1
    f[27,142,6]  R1265     -1
    f[27,142,6]  R1342     1
    f[27,142,6]  marginal_28_6  1
    f[27,142,8]  R1265     -1
    f[27,142,8]  R1344     1
    f[27,142,8]  marginal_28_8  1
    f[27,143,6]  R1266     -1
    f[27,143,6]  R1343     1
    f[27,143,6]  marginal_28_6  1
    f[27,143,8]  R1266     -1
    f[27,143,8]  R1345     1
    f[27,143,8]  marginal_28_8  1
    f[27,144,6]  R1267     -1
    f[27,144,6]  R1344     1
    f[27,144,6]  marginal_28_6  1
    f[27,144,8]  R1267     -1
    f[27,144,8]  R1346     1
    f[27,144,8]  marginal_28_8  1
    f[27,145,6]  R1268     -1
    f[27,145,6]  R1345     1
    f[27,145,6]  marginal_28_6  1
    f[27,145,8]  R1268     -1
    f[27,145,8]  R1347     1
    f[27,145,8]  marginal_28_8  1
    f[27,146,6]  R1269     -1
    f[27,146,6]  R1346     1
    f[27,146,6]  marginal_28_6  1
    f[27,146,8]  R1269     -1
    f[27,146,8]  R1348     1
    f[27,146,8]  marginal_28_8  1
    f[27,147,6]  R1270     -1
    f[27,147,6]  R1347     1
    f[27,147,6]  marginal_28_6  1
    f[27,147,8]  R1270     -1
    f[27,147,8]  R1349     1
    f[27,147,8]  marginal_28_8  1
    f[27,148,6]  R1271     -1
    f[27,148,6]  R1348     1
    f[27,148,6]  marginal_28_6  1
    f[27,148,8]  R1271     -1
    f[27,148,8]  R1350     1
    f[27,148,8]  marginal_28_8  1
    f[27,149,6]  R1272     -1
    f[27,149,6]  R1349     1
    f[27,149,6]  marginal_28_6  1
    f[27,149,8]  R1272     -1
    f[27,149,8]  R1351     1
    f[27,149,8]  marginal_28_8  1
    f[27,150,6]  R1273     -1
    f[27,150,6]  R1350     1
    f[27,150,6]  marginal_28_6  1
    f[27,150,8]  R1273     -1
    f[27,150,8]  R1352     1
    f[27,150,8]  marginal_28_8  1
    f[27,151,6]  R1274     -1
    f[27,151,6]  R1351     1
    f[27,151,6]  marginal_28_6  1
    f[27,151,8]  R1274     -1
    f[27,151,8]  R1353     1
    f[27,151,8]  marginal_28_8  1
    f[27,152,6]  R1275     -1
    f[27,152,6]  R1352     1
    f[27,152,6]  marginal_28_6  1
    f[27,152,8]  R1275     -1
    f[27,152,8]  R1354     1
    f[27,152,8]  marginal_28_8  1
    f[27,153,6]  R1276     -1
    f[27,153,6]  R1353     1
    f[27,153,6]  marginal_28_6  1
    f[27,153,8]  R1276     -1
    f[27,153,8]  R1355     1
    f[27,153,8]  marginal_28_8  1
    f[27,154,6]  R1277     -1
    f[27,154,6]  R1354     1
    f[27,154,6]  marginal_28_6  1
    f[27,154,8]  R1277     -1
    f[27,154,8]  R1356     1
    f[27,154,8]  marginal_28_8  1
    f[27,155,6]  R1278     -1
    f[27,155,6]  R1355     1
    f[27,155,6]  marginal_28_6  1
    f[27,155,8]  R1278     -1
    f[27,155,8]  R1357     1
    f[27,155,8]  marginal_28_8  1
    f[27,156,6]  R1279     -1
    f[27,156,6]  R1356     1
    f[27,156,6]  marginal_28_6  1
    f[27,156,8]  R1279     -1
    f[27,156,8]  R1358     1
    f[27,156,8]  marginal_28_8  1
    f[27,157,6]  R1280     -1
    f[27,157,6]  R1357     1
    f[27,157,6]  marginal_28_6  1
    f[27,157,8]  R1280     -1
    f[27,157,8]  R1359     1
    f[27,157,8]  marginal_28_8  1
    f[27,158,6]  R1281     -1
    f[27,158,6]  R1358     1
    f[27,158,6]  marginal_28_6  1
    f[27,158,8]  R1281     -1
    f[27,158,8]  R1360     1
    f[27,158,8]  marginal_28_8  1
    f[27,159,6]  R1282     -1
    f[27,159,6]  R1359     1
    f[27,159,6]  marginal_28_6  1
    f[27,159,8]  R1282     -1
    f[27,159,8]  R1361     1
    f[27,159,8]  marginal_28_8  1
    f[27,160,6]  R1283     -1
    f[27,160,6]  R1360     1
    f[27,160,6]  marginal_28_6  1
    f[27,160,8]  R1283     -1
    f[27,160,8]  R1362     1
    f[27,160,8]  marginal_28_8  1
    f[27,161,6]  R1284     -1
    f[27,161,6]  R1361     1
    f[27,161,6]  marginal_28_6  1
    f[27,161,8]  R1284     -1
    f[27,161,8]  R1363     1
    f[27,161,8]  marginal_28_8  1
    f[27,162,6]  R1285     -1
    f[27,162,6]  R1362     1
    f[27,162,6]  marginal_28_6  1
    f[27,162,8]  R1285     -1
    f[27,162,8]  R1364     1
    f[27,162,8]  marginal_28_8  1
    f[27,163,6]  R1286     -1
    f[27,163,6]  R1363     1
    f[27,163,6]  marginal_28_6  1
    f[27,163,8]  R1286     -1
    f[27,163,8]  R1365     1
    f[27,163,8]  marginal_28_8  1
    f[27,164,6]  R1287     -1
    f[27,164,6]  R1364     1
    f[27,164,6]  marginal_28_6  1
    f[27,164,8]  R1287     -1
    f[27,164,8]  R1366     1
    f[27,164,8]  marginal_28_8  1
    f[27,165,6]  R1288     -1
    f[27,165,6]  R1365     1
    f[27,165,6]  marginal_28_6  1
    f[27,165,8]  R1288     -1
    f[27,165,8]  R1367     1
    f[27,165,8]  marginal_28_8  1
    f[27,166,6]  R1289     -1
    f[27,166,6]  R1366     1
    f[27,166,6]  marginal_28_6  1
    f[27,166,8]  R1289     -1
    f[27,166,8]  R1368     1
    f[27,166,8]  marginal_28_8  1
    f[27,167,6]  R1290     -1
    f[27,167,6]  R1367     1
    f[27,167,6]  marginal_28_6  1
    f[27,167,8]  R1290     -1
    f[27,167,8]  R1369     1
    f[27,167,8]  marginal_28_8  1
    f[27,168,6]  R1291     -1
    f[27,168,6]  R1368     1
    f[27,168,6]  marginal_28_6  1
    f[27,168,8]  R1291     -1
    f[27,168,8]  R1370     1
    f[27,168,8]  marginal_28_8  1
    f[27,169,6]  R1292     -1
    f[27,169,6]  R1369     1
    f[27,169,6]  marginal_28_6  1
    f[27,169,8]  R1292     -1
    f[27,169,8]  R1371     1
    f[27,169,8]  marginal_28_8  1
    f[27,170,6]  R1293     -1
    f[27,170,6]  R1370     1
    f[27,170,6]  marginal_28_6  1
    f[27,170,8]  R1293     -1
    f[27,170,8]  R1372     1
    f[27,170,8]  marginal_28_8  1
    f[27,171,6]  R1294     -1
    f[27,171,6]  R1371     1
    f[27,171,6]  marginal_28_6  1
    f[27,171,8]  R1294     -1
    f[27,171,8]  R1373     1
    f[27,171,8]  marginal_28_8  1
    f[27,172,6]  R1295     -1
    f[27,172,6]  R1372     1
    f[27,172,6]  marginal_28_6  1
    f[27,172,8]  R1295     -1
    f[27,172,8]  R1374     1
    f[27,172,8]  marginal_28_8  1
    f[27,173,6]  R1296     -1
    f[27,173,6]  R1373     1
    f[27,173,6]  marginal_28_6  1
    f[27,173,8]  R1296     -1
    f[27,173,8]  R1375     1
    f[27,173,8]  marginal_28_8  1
    f[27,174,6]  R1297     -1
    f[27,174,6]  R1374     1
    f[27,174,6]  marginal_28_6  1
    f[27,174,8]  R1297     -1
    f[27,174,8]  R1376     1
    f[27,174,8]  marginal_28_8  1
    f[27,175,6]  R1298     -1
    f[27,175,6]  R1375     1
    f[27,175,6]  marginal_28_6  1
    f[27,175,8]  R1298     -1
    f[27,175,8]  R1377     1
    f[27,175,8]  marginal_28_8  1
    f[27,176,6]  R1299     -1
    f[27,176,6]  R1376     1
    f[27,176,6]  marginal_28_6  1
    f[27,176,8]  R1299     -1
    f[27,176,8]  R1378     1
    f[27,176,8]  marginal_28_8  1
    f[27,177,6]  R1300     -1
    f[27,177,6]  R1377     1
    f[27,177,6]  marginal_28_6  1
    f[27,177,8]  R1300     -1
    f[27,177,8]  R1379     1
    f[27,177,8]  marginal_28_8  1
    f[27,178,6]  R1301     -1
    f[27,178,6]  R1378     1
    f[27,178,6]  marginal_28_6  1
    f[27,178,8]  R1301     -1
    f[27,178,8]  R1380     1
    f[27,178,8]  marginal_28_8  1
    f[27,179,6]  R1302     -1
    f[27,179,6]  R1379     1
    f[27,179,6]  marginal_28_6  1
    f[27,180,6]  R1303     -1
    f[27,180,6]  R1380     1
    f[27,180,6]  marginal_28_6  1
    f[28,110,6]  R1304     -1
    f[28,110,6]  R1381     1
    f[28,110,6]  marginal_29_6  1
    f[28,110,8]  R1304     -1
    f[28,110,8]  R1383     1
    f[28,110,8]  marginal_29_8  1
    f[28,111,6]  R1305     -1
    f[28,111,6]  R1382     1
    f[28,111,6]  marginal_29_6  1
    f[28,111,8]  R1305     -1
    f[28,111,8]  R1384     1
    f[28,111,8]  marginal_29_8  1
    f[28,112,6]  R1306     -1
    f[28,112,6]  R1383     1
    f[28,112,6]  marginal_29_6  1
    f[28,112,8]  R1306     -1
    f[28,112,8]  R1385     1
    f[28,112,8]  marginal_29_8  1
    f[28,113,6]  R1307     -1
    f[28,113,6]  R1384     1
    f[28,113,6]  marginal_29_6  1
    f[28,113,8]  R1307     -1
    f[28,113,8]  R1386     1
    f[28,113,8]  marginal_29_8  1
    f[28,114,6]  R1308     -1
    f[28,114,6]  R1385     1
    f[28,114,6]  marginal_29_6  1
    f[28,114,8]  R1308     -1
    f[28,114,8]  R1387     1
    f[28,114,8]  marginal_29_8  1
    f[28,115,6]  R1309     -1
    f[28,115,6]  R1386     1
    f[28,115,6]  marginal_29_6  1
    f[28,115,8]  R1309     -1
    f[28,115,8]  R1388     1
    f[28,115,8]  marginal_29_8  1
    f[28,116,6]  R1310     -1
    f[28,116,6]  R1387     1
    f[28,116,6]  marginal_29_6  1
    f[28,116,8]  R1310     -1
    f[28,116,8]  R1389     1
    f[28,116,8]  marginal_29_8  1
    f[28,117,6]  R1311     -1
    f[28,117,6]  R1388     1
    f[28,117,6]  marginal_29_6  1
    f[28,117,8]  R1311     -1
    f[28,117,8]  R1390     1
    f[28,117,8]  marginal_29_8  1
    f[28,118,6]  R1312     -1
    f[28,118,6]  R1389     1
    f[28,118,6]  marginal_29_6  1
    f[28,118,8]  R1312     -1
    f[28,118,8]  R1391     1
    f[28,118,8]  marginal_29_8  1
    f[28,119,6]  R1313     -1
    f[28,119,6]  R1390     1
    f[28,119,6]  marginal_29_6  1
    f[28,119,8]  R1313     -1
    f[28,119,8]  R1392     1
    f[28,119,8]  marginal_29_8  1
    f[28,120,6]  R1314     -1
    f[28,120,6]  R1391     1
    f[28,120,6]  marginal_29_6  1
    f[28,120,8]  R1314     -1
    f[28,120,8]  R1393     1
    f[28,120,8]  marginal_29_8  1
    f[28,121,6]  R1315     -1
    f[28,121,6]  R1392     1
    f[28,121,6]  marginal_29_6  1
    f[28,121,8]  R1315     -1
    f[28,121,8]  R1394     1
    f[28,121,8]  marginal_29_8  1
    f[28,122,6]  R1316     -1
    f[28,122,6]  R1393     1
    f[28,122,6]  marginal_29_6  1
    f[28,122,8]  R1316     -1
    f[28,122,8]  R1395     1
    f[28,122,8]  marginal_29_8  1
    f[28,123,6]  R1317     -1
    f[28,123,6]  R1394     1
    f[28,123,6]  marginal_29_6  1
    f[28,123,8]  R1317     -1
    f[28,123,8]  R1396     1
    f[28,123,8]  marginal_29_8  1
    f[28,124,6]  R1318     -1
    f[28,124,6]  R1395     1
    f[28,124,6]  marginal_29_6  1
    f[28,124,8]  R1318     -1
    f[28,124,8]  R1397     1
    f[28,124,8]  marginal_29_8  1
    f[28,125,6]  R1319     -1
    f[28,125,6]  R1396     1
    f[28,125,6]  marginal_29_6  1
    f[28,125,8]  R1319     -1
    f[28,125,8]  R1398     1
    f[28,125,8]  marginal_29_8  1
    f[28,126,6]  R1320     -1
    f[28,126,6]  R1397     1
    f[28,126,6]  marginal_29_6  1
    f[28,126,8]  R1320     -1
    f[28,126,8]  R1399     1
    f[28,126,8]  marginal_29_8  1
    f[28,127,6]  R1321     -1
    f[28,127,6]  R1398     1
    f[28,127,6]  marginal_29_6  1
    f[28,127,8]  R1321     -1
    f[28,127,8]  R1400     1
    f[28,127,8]  marginal_29_8  1
    f[28,128,6]  R1322     -1
    f[28,128,6]  R1399     1
    f[28,128,6]  marginal_29_6  1
    f[28,128,8]  R1322     -1
    f[28,128,8]  R1401     1
    f[28,128,8]  marginal_29_8  1
    f[28,129,6]  R1323     -1
    f[28,129,6]  R1400     1
    f[28,129,6]  marginal_29_6  1
    f[28,129,8]  R1323     -1
    f[28,129,8]  R1402     1
    f[28,129,8]  marginal_29_8  1
    f[28,130,6]  R1324     -1
    f[28,130,6]  R1401     1
    f[28,130,6]  marginal_29_6  1
    f[28,130,8]  R1324     -1
    f[28,130,8]  R1403     1
    f[28,130,8]  marginal_29_8  1
    f[28,131,6]  R1325     -1
    f[28,131,6]  R1402     1
    f[28,131,6]  marginal_29_6  1
    f[28,131,8]  R1325     -1
    f[28,131,8]  R1404     1
    f[28,131,8]  marginal_29_8  1
    f[28,132,6]  R1326     -1
    f[28,132,6]  R1403     1
    f[28,132,6]  marginal_29_6  1
    f[28,132,8]  R1326     -1
    f[28,132,8]  R1405     1
    f[28,132,8]  marginal_29_8  1
    f[28,133,6]  R1327     -1
    f[28,133,6]  R1404     1
    f[28,133,6]  marginal_29_6  1
    f[28,133,8]  R1327     -1
    f[28,133,8]  R1406     1
    f[28,133,8]  marginal_29_8  1
    f[28,134,6]  R1328     -1
    f[28,134,6]  R1405     1
    f[28,134,6]  marginal_29_6  1
    f[28,134,8]  R1328     -1
    f[28,134,8]  R1407     1
    f[28,134,8]  marginal_29_8  1
    f[28,135,6]  R1329     -1
    f[28,135,6]  R1406     1
    f[28,135,6]  marginal_29_6  1
    f[28,135,8]  R1329     -1
    f[28,135,8]  R1408     1
    f[28,135,8]  marginal_29_8  1
    f[28,136,6]  R1330     -1
    f[28,136,6]  R1407     1
    f[28,136,6]  marginal_29_6  1
    f[28,136,8]  R1330     -1
    f[28,136,8]  R1409     1
    f[28,136,8]  marginal_29_8  1
    f[28,137,6]  R1331     -1
    f[28,137,6]  R1408     1
    f[28,137,6]  marginal_29_6  1
    f[28,137,8]  R1331     -1
    f[28,137,8]  R1410     1
    f[28,137,8]  marginal_29_8  1
    f[28,138,6]  R1332     -1
    f[28,138,6]  R1409     1
    f[28,138,6]  marginal_29_6  1
    f[28,138,8]  R1332     -1
    f[28,138,8]  R1411     1
    f[28,138,8]  marginal_29_8  1
    f[28,139,6]  R1333     -1
    f[28,139,6]  R1410     1
    f[28,139,6]  marginal_29_6  1
    f[28,139,8]  R1333     -1
    f[28,139,8]  R1412     1
    f[28,139,8]  marginal_29_8  1
    f[28,140,6]  R1334     -1
    f[28,140,6]  R1411     1
    f[28,140,6]  marginal_29_6  1
    f[28,140,8]  R1334     -1
    f[28,140,8]  R1413     1
    f[28,140,8]  marginal_29_8  1
    f[28,141,6]  R1335     -1
    f[28,141,6]  R1412     1
    f[28,141,6]  marginal_29_6  1
    f[28,141,8]  R1335     -1
    f[28,141,8]  R1414     1
    f[28,141,8]  marginal_29_8  1
    f[28,142,6]  R1336     -1
    f[28,142,6]  R1413     1
    f[28,142,6]  marginal_29_6  1
    f[28,142,8]  R1336     -1
    f[28,142,8]  R1415     1
    f[28,142,8]  marginal_29_8  1
    f[28,143,6]  R1337     -1
    f[28,143,6]  R1414     1
    f[28,143,6]  marginal_29_6  1
    f[28,143,8]  R1337     -1
    f[28,143,8]  R1416     1
    f[28,143,8]  marginal_29_8  1
    f[28,144,6]  R1338     -1
    f[28,144,6]  R1415     1
    f[28,144,6]  marginal_29_6  1
    f[28,144,8]  R1338     -1
    f[28,144,8]  R1417     1
    f[28,144,8]  marginal_29_8  1
    f[28,145,6]  R1339     -1
    f[28,145,6]  R1416     1
    f[28,145,6]  marginal_29_6  1
    f[28,145,8]  R1339     -1
    f[28,145,8]  R1418     1
    f[28,145,8]  marginal_29_8  1
    f[28,146,6]  R1340     -1
    f[28,146,6]  R1417     1
    f[28,146,6]  marginal_29_6  1
    f[28,146,8]  R1340     -1
    f[28,146,8]  R1419     1
    f[28,146,8]  marginal_29_8  1
    f[28,147,6]  R1341     -1
    f[28,147,6]  R1418     1
    f[28,147,6]  marginal_29_6  1
    f[28,147,8]  R1341     -1
    f[28,147,8]  R1420     1
    f[28,147,8]  marginal_29_8  1
    f[28,148,6]  R1342     -1
    f[28,148,6]  R1419     1
    f[28,148,6]  marginal_29_6  1
    f[28,148,8]  R1342     -1
    f[28,148,8]  R1421     1
    f[28,148,8]  marginal_29_8  1
    f[28,149,6]  R1343     -1
    f[28,149,6]  R1420     1
    f[28,149,6]  marginal_29_6  1
    f[28,149,8]  R1343     -1
    f[28,149,8]  R1422     1
    f[28,149,8]  marginal_29_8  1
    f[28,150,6]  R1344     -1
    f[28,150,6]  R1421     1
    f[28,150,6]  marginal_29_6  1
    f[28,150,8]  R1344     -1
    f[28,150,8]  R1423     1
    f[28,150,8]  marginal_29_8  1
    f[28,151,6]  R1345     -1
    f[28,151,6]  R1422     1
    f[28,151,6]  marginal_29_6  1
    f[28,151,8]  R1345     -1
    f[28,151,8]  R1424     1
    f[28,151,8]  marginal_29_8  1
    f[28,152,6]  R1346     -1
    f[28,152,6]  R1423     1
    f[28,152,6]  marginal_29_6  1
    f[28,152,8]  R1346     -1
    f[28,152,8]  R1425     1
    f[28,152,8]  marginal_29_8  1
    f[28,153,6]  R1347     -1
    f[28,153,6]  R1424     1
    f[28,153,6]  marginal_29_6  1
    f[28,153,8]  R1347     -1
    f[28,153,8]  R1426     1
    f[28,153,8]  marginal_29_8  1
    f[28,154,6]  R1348     -1
    f[28,154,6]  R1425     1
    f[28,154,6]  marginal_29_6  1
    f[28,154,8]  R1348     -1
    f[28,154,8]  R1427     1
    f[28,154,8]  marginal_29_8  1
    f[28,155,6]  R1349     -1
    f[28,155,6]  R1426     1
    f[28,155,6]  marginal_29_6  1
    f[28,155,8]  R1349     -1
    f[28,155,8]  R1428     1
    f[28,155,8]  marginal_29_8  1
    f[28,156,6]  R1350     -1
    f[28,156,6]  R1427     1
    f[28,156,6]  marginal_29_6  1
    f[28,156,8]  R1350     -1
    f[28,156,8]  R1429     1
    f[28,156,8]  marginal_29_8  1
    f[28,157,6]  R1351     -1
    f[28,157,6]  R1428     1
    f[28,157,6]  marginal_29_6  1
    f[28,157,8]  R1351     -1
    f[28,157,8]  R1430     1
    f[28,157,8]  marginal_29_8  1
    f[28,158,6]  R1352     -1
    f[28,158,6]  R1429     1
    f[28,158,6]  marginal_29_6  1
    f[28,158,8]  R1352     -1
    f[28,158,8]  R1431     1
    f[28,158,8]  marginal_29_8  1
    f[28,159,6]  R1353     -1
    f[28,159,6]  R1430     1
    f[28,159,6]  marginal_29_6  1
    f[28,159,8]  R1353     -1
    f[28,159,8]  R1432     1
    f[28,159,8]  marginal_29_8  1
    f[28,160,6]  R1354     -1
    f[28,160,6]  R1431     1
    f[28,160,6]  marginal_29_6  1
    f[28,160,8]  R1354     -1
    f[28,160,8]  R1433     1
    f[28,160,8]  marginal_29_8  1
    f[28,161,6]  R1355     -1
    f[28,161,6]  R1432     1
    f[28,161,6]  marginal_29_6  1
    f[28,161,8]  R1355     -1
    f[28,161,8]  R1434     1
    f[28,161,8]  marginal_29_8  1
    f[28,162,6]  R1356     -1
    f[28,162,6]  R1433     1
    f[28,162,6]  marginal_29_6  1
    f[28,162,8]  R1356     -1
    f[28,162,8]  R1435     1
    f[28,162,8]  marginal_29_8  1
    f[28,163,6]  R1357     -1
    f[28,163,6]  R1434     1
    f[28,163,6]  marginal_29_6  1
    f[28,163,8]  R1357     -1
    f[28,163,8]  R1436     1
    f[28,163,8]  marginal_29_8  1
    f[28,164,6]  R1358     -1
    f[28,164,6]  R1435     1
    f[28,164,6]  marginal_29_6  1
    f[28,164,8]  R1358     -1
    f[28,164,8]  R1437     1
    f[28,164,8]  marginal_29_8  1
    f[28,165,6]  R1359     -1
    f[28,165,6]  R1436     1
    f[28,165,6]  marginal_29_6  1
    f[28,165,8]  R1359     -1
    f[28,165,8]  R1438     1
    f[28,165,8]  marginal_29_8  1
    f[28,166,6]  R1360     -1
    f[28,166,6]  R1437     1
    f[28,166,6]  marginal_29_6  1
    f[28,166,8]  R1360     -1
    f[28,166,8]  R1439     1
    f[28,166,8]  marginal_29_8  1
    f[28,167,6]  R1361     -1
    f[28,167,6]  R1438     1
    f[28,167,6]  marginal_29_6  1
    f[28,167,8]  R1361     -1
    f[28,167,8]  R1440     1
    f[28,167,8]  marginal_29_8  1
    f[28,168,6]  R1362     -1
    f[28,168,6]  R1439     1
    f[28,168,6]  marginal_29_6  1
    f[28,168,8]  R1362     -1
    f[28,168,8]  R1441     1
    f[28,168,8]  marginal_29_8  1
    f[28,169,6]  R1363     -1
    f[28,169,6]  R1440     1
    f[28,169,6]  marginal_29_6  1
    f[28,169,8]  R1363     -1
    f[28,169,8]  R1442     1
    f[28,169,8]  marginal_29_8  1
    f[28,170,6]  R1364     -1
    f[28,170,6]  R1441     1
    f[28,170,6]  marginal_29_6  1
    f[28,170,8]  R1364     -1
    f[28,170,8]  R1443     1
    f[28,170,8]  marginal_29_8  1
    f[28,171,6]  R1365     -1
    f[28,171,6]  R1442     1
    f[28,171,6]  marginal_29_6  1
    f[28,171,8]  R1365     -1
    f[28,171,8]  R1444     1
    f[28,171,8]  marginal_29_8  1
    f[28,172,6]  R1366     -1
    f[28,172,6]  R1443     1
    f[28,172,6]  marginal_29_6  1
    f[28,172,8]  R1366     -1
    f[28,172,8]  R1445     1
    f[28,172,8]  marginal_29_8  1
    f[28,173,6]  R1367     -1
    f[28,173,6]  R1444     1
    f[28,173,6]  marginal_29_6  1
    f[28,173,8]  R1367     -1
    f[28,173,8]  R1446     1
    f[28,173,8]  marginal_29_8  1
    f[28,174,6]  R1368     -1
    f[28,174,6]  R1445     1
    f[28,174,6]  marginal_29_6  1
    f[28,174,8]  R1368     -1
    f[28,174,8]  R1447     1
    f[28,174,8]  marginal_29_8  1
    f[28,175,6]  R1369     -1
    f[28,175,6]  R1446     1
    f[28,175,6]  marginal_29_6  1
    f[28,175,8]  R1369     -1
    f[28,175,8]  R1448     1
    f[28,175,8]  marginal_29_8  1
    f[28,176,6]  R1370     -1
    f[28,176,6]  R1447     1
    f[28,176,6]  marginal_29_6  1
    f[28,176,8]  R1370     -1
    f[28,176,8]  R1449     1
    f[28,176,8]  marginal_29_8  1
    f[28,177,6]  R1371     -1
    f[28,177,6]  R1448     1
    f[28,177,6]  marginal_29_6  1
    f[28,177,8]  R1371     -1
    f[28,177,8]  R1450     1
    f[28,177,8]  marginal_29_8  1
    f[28,178,6]  R1372     -1
    f[28,178,6]  R1449     1
    f[28,178,6]  marginal_29_6  1
    f[28,178,8]  R1372     -1
    f[28,178,8]  R1451     1
    f[28,178,8]  marginal_29_8  1
    f[28,179,6]  R1373     -1
    f[28,179,6]  R1450     1
    f[28,179,6]  marginal_29_6  1
    f[28,179,8]  R1373     -1
    f[28,179,8]  R1452     1
    f[28,179,8]  marginal_29_8  1
    f[28,180,6]  R1374     -1
    f[28,180,6]  R1451     1
    f[28,180,6]  marginal_29_6  1
    f[28,180,8]  R1374     -1
    f[28,180,8]  R1453     1
    f[28,180,8]  marginal_29_8  1
    f[28,181,6]  R1375     -1
    f[28,181,6]  R1452     1
    f[28,181,6]  marginal_29_6  1
    f[28,181,8]  R1375     -1
    f[28,181,8]  R1454     1
    f[28,181,8]  marginal_29_8  1
    f[28,182,6]  R1376     -1
    f[28,182,6]  R1453     1
    f[28,182,6]  marginal_29_6  1
    f[28,182,8]  R1376     -1
    f[28,182,8]  R1455     1
    f[28,182,8]  marginal_29_8  1
    f[28,183,6]  R1377     -1
    f[28,183,6]  R1454     1
    f[28,183,6]  marginal_29_6  1
    f[28,183,8]  R1377     -1
    f[28,183,8]  R1456     1
    f[28,183,8]  marginal_29_8  1
    f[28,184,6]  R1378     -1
    f[28,184,6]  R1455     1
    f[28,184,6]  marginal_29_6  1
    f[28,184,8]  R1378     -1
    f[28,184,8]  R1457     1
    f[28,184,8]  marginal_29_8  1
    f[28,185,6]  R1379     -1
    f[28,185,6]  R1456     1
    f[28,185,6]  marginal_29_6  1
    f[28,186,6]  R1380     -1
    f[28,186,6]  R1457     1
    f[28,186,6]  marginal_29_6  1
    f[29,116,3]  R1381     -1
    f[29,116,3]  R1458     1
    f[29,116,3]  marginal_30_3  1
    f[29,116,4]  R1381     -1
    f[29,116,4]  R1459     1
    f[29,116,4]  marginal_30_4  1
    f[29,117,3]  R1382     -1
    f[29,117,3]  R1459     1
    f[29,117,3]  marginal_30_3  1
    f[29,117,4]  R1382     -1
    f[29,117,4]  R1460     1
    f[29,117,4]  marginal_30_4  1
    f[29,118,3]  R1383     -1
    f[29,118,3]  R1460     1
    f[29,118,3]  marginal_30_3  1
    f[29,118,4]  R1383     -1
    f[29,118,4]  R1461     1
    f[29,118,4]  marginal_30_4  1
    f[29,119,3]  R1384     -1
    f[29,119,3]  R1461     1
    f[29,119,3]  marginal_30_3  1
    f[29,119,4]  R1384     -1
    f[29,119,4]  R1462     1
    f[29,119,4]  marginal_30_4  1
    f[29,120,3]  R1385     -1
    f[29,120,3]  R1462     1
    f[29,120,3]  marginal_30_3  1
    f[29,120,4]  R1385     -1
    f[29,120,4]  R1463     1
    f[29,120,4]  marginal_30_4  1
    f[29,121,3]  R1386     -1
    f[29,121,3]  R1463     1
    f[29,121,3]  marginal_30_3  1
    f[29,121,4]  R1386     -1
    f[29,121,4]  R1464     1
    f[29,121,4]  marginal_30_4  1
    f[29,122,3]  R1387     -1
    f[29,122,3]  R1464     1
    f[29,122,3]  marginal_30_3  1
    f[29,122,4]  R1387     -1
    f[29,122,4]  R1465     1
    f[29,122,4]  marginal_30_4  1
    f[29,123,3]  R1388     -1
    f[29,123,3]  R1465     1
    f[29,123,3]  marginal_30_3  1
    f[29,123,4]  R1388     -1
    f[29,123,4]  R1466     1
    f[29,123,4]  marginal_30_4  1
    f[29,124,3]  R1389     -1
    f[29,124,3]  R1466     1
    f[29,124,3]  marginal_30_3  1
    f[29,124,4]  R1389     -1
    f[29,124,4]  R1467     1
    f[29,124,4]  marginal_30_4  1
    f[29,125,3]  R1390     -1
    f[29,125,3]  R1467     1
    f[29,125,3]  marginal_30_3  1
    f[29,125,4]  R1390     -1
    f[29,125,4]  R1468     1
    f[29,125,4]  marginal_30_4  1
    f[29,126,3]  R1391     -1
    f[29,126,3]  R1468     1
    f[29,126,3]  marginal_30_3  1
    f[29,126,4]  R1391     -1
    f[29,126,4]  R1469     1
    f[29,126,4]  marginal_30_4  1
    f[29,127,3]  R1392     -1
    f[29,127,3]  R1469     1
    f[29,127,3]  marginal_30_3  1
    f[29,127,4]  R1392     -1
    f[29,127,4]  R1470     1
    f[29,127,4]  marginal_30_4  1
    f[29,128,3]  R1393     -1
    f[29,128,3]  R1470     1
    f[29,128,3]  marginal_30_3  1
    f[29,128,4]  R1393     -1
    f[29,128,4]  R1471     1
    f[29,128,4]  marginal_30_4  1
    f[29,129,3]  R1394     -1
    f[29,129,3]  R1471     1
    f[29,129,3]  marginal_30_3  1
    f[29,129,4]  R1394     -1
    f[29,129,4]  R1472     1
    f[29,129,4]  marginal_30_4  1
    f[29,130,3]  R1395     -1
    f[29,130,3]  R1472     1
    f[29,130,3]  marginal_30_3  1
    f[29,130,4]  R1395     -1
    f[29,130,4]  R1473     1
    f[29,130,4]  marginal_30_4  1
    f[29,131,3]  R1396     -1
    f[29,131,3]  R1473     1
    f[29,131,3]  marginal_30_3  1
    f[29,131,4]  R1396     -1
    f[29,131,4]  R1474     1
    f[29,131,4]  marginal_30_4  1
    f[29,132,3]  R1397     -1
    f[29,132,3]  R1474     1
    f[29,132,3]  marginal_30_3  1
    f[29,132,4]  R1397     -1
    f[29,132,4]  R1475     1
    f[29,132,4]  marginal_30_4  1
    f[29,133,3]  R1398     -1
    f[29,133,3]  R1475     1
    f[29,133,3]  marginal_30_3  1
    f[29,133,4]  R1398     -1
    f[29,133,4]  R1476     1
    f[29,133,4]  marginal_30_4  1
    f[29,134,3]  R1399     -1
    f[29,134,3]  R1476     1
    f[29,134,3]  marginal_30_3  1
    f[29,134,4]  R1399     -1
    f[29,134,4]  R1477     1
    f[29,134,4]  marginal_30_4  1
    f[29,135,3]  R1400     -1
    f[29,135,3]  R1477     1
    f[29,135,3]  marginal_30_3  1
    f[29,135,4]  R1400     -1
    f[29,135,4]  R1478     1
    f[29,135,4]  marginal_30_4  1
    f[29,136,3]  R1401     -1
    f[29,136,3]  R1478     1
    f[29,136,3]  marginal_30_3  1
    f[29,136,4]  R1401     -1
    f[29,136,4]  R1479     1
    f[29,136,4]  marginal_30_4  1
    f[29,137,3]  R1402     -1
    f[29,137,3]  R1479     1
    f[29,137,3]  marginal_30_3  1
    f[29,137,4]  R1402     -1
    f[29,137,4]  R1480     1
    f[29,137,4]  marginal_30_4  1
    f[29,138,3]  R1403     -1
    f[29,138,3]  R1480     1
    f[29,138,3]  marginal_30_3  1
    f[29,138,4]  R1403     -1
    f[29,138,4]  R1481     1
    f[29,138,4]  marginal_30_4  1
    f[29,139,3]  R1404     -1
    f[29,139,3]  R1481     1
    f[29,139,3]  marginal_30_3  1
    f[29,139,4]  R1404     -1
    f[29,139,4]  R1482     1
    f[29,139,4]  marginal_30_4  1
    f[29,140,3]  R1405     -1
    f[29,140,3]  R1482     1
    f[29,140,3]  marginal_30_3  1
    f[29,140,4]  R1405     -1
    f[29,140,4]  R1483     1
    f[29,140,4]  marginal_30_4  1
    f[29,141,3]  R1406     -1
    f[29,141,3]  R1483     1
    f[29,141,3]  marginal_30_3  1
    f[29,141,4]  R1406     -1
    f[29,141,4]  R1484     1
    f[29,141,4]  marginal_30_4  1
    f[29,142,3]  R1407     -1
    f[29,142,3]  R1484     1
    f[29,142,3]  marginal_30_3  1
    f[29,142,4]  R1407     -1
    f[29,142,4]  R1485     1
    f[29,142,4]  marginal_30_4  1
    f[29,143,3]  R1408     -1
    f[29,143,3]  R1485     1
    f[29,143,3]  marginal_30_3  1
    f[29,143,4]  R1408     -1
    f[29,143,4]  R1486     1
    f[29,143,4]  marginal_30_4  1
    f[29,144,3]  R1409     -1
    f[29,144,3]  R1486     1
    f[29,144,3]  marginal_30_3  1
    f[29,144,4]  R1409     -1
    f[29,144,4]  R1487     1
    f[29,144,4]  marginal_30_4  1
    f[29,145,3]  R1410     -1
    f[29,145,3]  R1487     1
    f[29,145,3]  marginal_30_3  1
    f[29,145,4]  R1410     -1
    f[29,145,4]  R1488     1
    f[29,145,4]  marginal_30_4  1
    f[29,146,3]  R1411     -1
    f[29,146,3]  R1488     1
    f[29,146,3]  marginal_30_3  1
    f[29,146,4]  R1411     -1
    f[29,146,4]  R1489     1
    f[29,146,4]  marginal_30_4  1
    f[29,147,3]  R1412     -1
    f[29,147,3]  R1489     1
    f[29,147,3]  marginal_30_3  1
    f[29,147,4]  R1412     -1
    f[29,147,4]  R1490     1
    f[29,147,4]  marginal_30_4  1
    f[29,148,3]  R1413     -1
    f[29,148,3]  R1490     1
    f[29,148,3]  marginal_30_3  1
    f[29,148,4]  R1413     -1
    f[29,148,4]  R1491     1
    f[29,148,4]  marginal_30_4  1
    f[29,149,3]  R1414     -1
    f[29,149,3]  R1491     1
    f[29,149,3]  marginal_30_3  1
    f[29,149,4]  R1414     -1
    f[29,149,4]  R1492     1
    f[29,149,4]  marginal_30_4  1
    f[29,150,3]  R1415     -1
    f[29,150,3]  R1492     1
    f[29,150,3]  marginal_30_3  1
    f[29,150,4]  R1415     -1
    f[29,150,4]  R1493     1
    f[29,150,4]  marginal_30_4  1
    f[29,151,3]  R1416     -1
    f[29,151,3]  R1493     1
    f[29,151,3]  marginal_30_3  1
    f[29,151,4]  R1416     -1
    f[29,151,4]  R1494     1
    f[29,151,4]  marginal_30_4  1
    f[29,152,3]  R1417     -1
    f[29,152,3]  R1494     1
    f[29,152,3]  marginal_30_3  1
    f[29,152,4]  R1417     -1
    f[29,152,4]  R1495     1
    f[29,152,4]  marginal_30_4  1
    f[29,153,3]  R1418     -1
    f[29,153,3]  R1495     1
    f[29,153,3]  marginal_30_3  1
    f[29,153,4]  R1418     -1
    f[29,153,4]  R1496     1
    f[29,153,4]  marginal_30_4  1
    f[29,154,3]  R1419     -1
    f[29,154,3]  R1496     1
    f[29,154,3]  marginal_30_3  1
    f[29,154,4]  R1419     -1
    f[29,154,4]  R1497     1
    f[29,154,4]  marginal_30_4  1
    f[29,155,3]  R1420     -1
    f[29,155,3]  R1497     1
    f[29,155,3]  marginal_30_3  1
    f[29,155,4]  R1420     -1
    f[29,155,4]  R1498     1
    f[29,155,4]  marginal_30_4  1
    f[29,156,3]  R1421     -1
    f[29,156,3]  R1498     1
    f[29,156,3]  marginal_30_3  1
    f[29,156,4]  R1421     -1
    f[29,156,4]  R1499     1
    f[29,156,4]  marginal_30_4  1
    f[29,157,3]  R1422     -1
    f[29,157,3]  R1499     1
    f[29,157,3]  marginal_30_3  1
    f[29,157,4]  R1422     -1
    f[29,157,4]  R1500     1
    f[29,157,4]  marginal_30_4  1
    f[29,158,3]  R1423     -1
    f[29,158,3]  R1500     1
    f[29,158,3]  marginal_30_3  1
    f[29,158,4]  R1423     -1
    f[29,158,4]  R1501     1
    f[29,158,4]  marginal_30_4  1
    f[29,159,3]  R1424     -1
    f[29,159,3]  R1501     1
    f[29,159,3]  marginal_30_3  1
    f[29,159,4]  R1424     -1
    f[29,159,4]  R1502     1
    f[29,159,4]  marginal_30_4  1
    f[29,160,3]  R1425     -1
    f[29,160,3]  R1502     1
    f[29,160,3]  marginal_30_3  1
    f[29,160,4]  R1425     -1
    f[29,160,4]  R1503     1
    f[29,160,4]  marginal_30_4  1
    f[29,161,3]  R1426     -1
    f[29,161,3]  R1503     1
    f[29,161,3]  marginal_30_3  1
    f[29,161,4]  R1426     -1
    f[29,161,4]  R1504     1
    f[29,161,4]  marginal_30_4  1
    f[29,162,3]  R1427     -1
    f[29,162,3]  R1504     1
    f[29,162,3]  marginal_30_3  1
    f[29,162,4]  R1427     -1
    f[29,162,4]  R1505     1
    f[29,162,4]  marginal_30_4  1
    f[29,163,3]  R1428     -1
    f[29,163,3]  R1505     1
    f[29,163,3]  marginal_30_3  1
    f[29,163,4]  R1428     -1
    f[29,163,4]  R1506     1
    f[29,163,4]  marginal_30_4  1
    f[29,164,3]  R1429     -1
    f[29,164,3]  R1506     1
    f[29,164,3]  marginal_30_3  1
    f[29,164,4]  R1429     -1
    f[29,164,4]  R1507     1
    f[29,164,4]  marginal_30_4  1
    f[29,165,3]  R1430     -1
    f[29,165,3]  R1507     1
    f[29,165,3]  marginal_30_3  1
    f[29,165,4]  R1430     -1
    f[29,165,4]  R1508     1
    f[29,165,4]  marginal_30_4  1
    f[29,166,3]  R1431     -1
    f[29,166,3]  R1508     1
    f[29,166,3]  marginal_30_3  1
    f[29,166,4]  R1431     -1
    f[29,166,4]  R1509     1
    f[29,166,4]  marginal_30_4  1
    f[29,167,3]  R1432     -1
    f[29,167,3]  R1509     1
    f[29,167,3]  marginal_30_3  1
    f[29,167,4]  R1432     -1
    f[29,167,4]  R1510     1
    f[29,167,4]  marginal_30_4  1
    f[29,168,3]  R1433     -1
    f[29,168,3]  R1510     1
    f[29,168,3]  marginal_30_3  1
    f[29,168,4]  R1433     -1
    f[29,168,4]  R1511     1
    f[29,168,4]  marginal_30_4  1
    f[29,169,3]  R1434     -1
    f[29,169,3]  R1511     1
    f[29,169,3]  marginal_30_3  1
    f[29,169,4]  R1434     -1
    f[29,169,4]  R1512     1
    f[29,169,4]  marginal_30_4  1
    f[29,170,3]  R1435     -1
    f[29,170,3]  R1512     1
    f[29,170,3]  marginal_30_3  1
    f[29,170,4]  R1435     -1
    f[29,170,4]  R1513     1
    f[29,170,4]  marginal_30_4  1
    f[29,171,3]  R1436     -1
    f[29,171,3]  R1513     1
    f[29,171,3]  marginal_30_3  1
    f[29,171,4]  R1436     -1
    f[29,171,4]  R1514     1
    f[29,171,4]  marginal_30_4  1
    f[29,172,3]  R1437     -1
    f[29,172,3]  R1514     1
    f[29,172,3]  marginal_30_3  1
    f[29,172,4]  R1437     -1
    f[29,172,4]  R1515     1
    f[29,172,4]  marginal_30_4  1
    f[29,173,3]  R1438     -1
    f[29,173,3]  R1515     1
    f[29,173,3]  marginal_30_3  1
    f[29,173,4]  R1438     -1
    f[29,173,4]  R1516     1
    f[29,173,4]  marginal_30_4  1
    f[29,174,3]  R1439     -1
    f[29,174,3]  R1516     1
    f[29,174,3]  marginal_30_3  1
    f[29,174,4]  R1439     -1
    f[29,174,4]  R1517     1
    f[29,174,4]  marginal_30_4  1
    f[29,175,3]  R1440     -1
    f[29,175,3]  R1517     1
    f[29,175,3]  marginal_30_3  1
    f[29,175,4]  R1440     -1
    f[29,175,4]  R1518     1
    f[29,175,4]  marginal_30_4  1
    f[29,176,3]  R1441     -1
    f[29,176,3]  R1518     1
    f[29,176,3]  marginal_30_3  1
    f[29,176,4]  R1441     -1
    f[29,176,4]  R1519     1
    f[29,176,4]  marginal_30_4  1
    f[29,177,3]  R1442     -1
    f[29,177,3]  R1519     1
    f[29,177,3]  marginal_30_3  1
    f[29,177,4]  R1442     -1
    f[29,177,4]  R1520     1
    f[29,177,4]  marginal_30_4  1
    f[29,178,3]  R1443     -1
    f[29,178,3]  R1520     1
    f[29,178,3]  marginal_30_3  1
    f[29,178,4]  R1443     -1
    f[29,178,4]  R1521     1
    f[29,178,4]  marginal_30_4  1
    f[29,179,3]  R1444     -1
    f[29,179,3]  R1521     1
    f[29,179,3]  marginal_30_3  1
    f[29,179,4]  R1444     -1
    f[29,179,4]  R1522     1
    f[29,179,4]  marginal_30_4  1
    f[29,180,3]  R1445     -1
    f[29,180,3]  R1522     1
    f[29,180,3]  marginal_30_3  1
    f[29,180,4]  R1445     -1
    f[29,180,4]  R1523     1
    f[29,180,4]  marginal_30_4  1
    f[29,181,3]  R1446     -1
    f[29,181,3]  R1523     1
    f[29,181,3]  marginal_30_3  1
    f[29,181,4]  R1446     -1
    f[29,181,4]  R1524     1
    f[29,181,4]  marginal_30_4  1
    f[29,182,3]  R1447     -1
    f[29,182,3]  R1524     1
    f[29,182,3]  marginal_30_3  1
    f[29,182,4]  R1447     -1
    f[29,182,4]  R1525     1
    f[29,182,4]  marginal_30_4  1
    f[29,183,3]  R1448     -1
    f[29,183,3]  R1525     1
    f[29,183,3]  marginal_30_3  1
    f[29,183,4]  R1448     -1
    f[29,183,4]  R1526     1
    f[29,183,4]  marginal_30_4  1
    f[29,184,3]  R1449     -1
    f[29,184,3]  R1526     1
    f[29,184,3]  marginal_30_3  1
    f[29,184,4]  R1449     -1
    f[29,184,4]  R1527     1
    f[29,184,4]  marginal_30_4  1
    f[29,185,3]  R1450     -1
    f[29,185,3]  R1527     1
    f[29,185,3]  marginal_30_3  1
    f[29,185,4]  R1450     -1
    f[29,185,4]  R1528     1
    f[29,185,4]  marginal_30_4  1
    f[29,186,3]  R1451     -1
    f[29,186,3]  R1528     1
    f[29,186,3]  marginal_30_3  1
    f[29,186,4]  R1451     -1
    f[29,186,4]  R1529     1
    f[29,186,4]  marginal_30_4  1
    f[29,187,3]  R1452     -1
    f[29,187,3]  R1529     1
    f[29,187,3]  marginal_30_3  1
    f[29,187,4]  R1452     -1
    f[29,187,4]  R1530     1
    f[29,187,4]  marginal_30_4  1
    f[29,188,3]  R1453     -1
    f[29,188,3]  R1530     1
    f[29,188,3]  marginal_30_3  1
    f[29,188,4]  R1453     -1
    f[29,188,4]  R1531     1
    f[29,188,4]  marginal_30_4  1
    f[29,189,3]  R1454     -1
    f[29,189,3]  R1531     1
    f[29,189,3]  marginal_30_3  1
    f[29,189,4]  R1454     -1
    f[29,189,4]  R1532     1
    f[29,189,4]  marginal_30_4  1
    f[29,190,3]  R1455     -1
    f[29,190,3]  R1532     1
    f[29,190,3]  marginal_30_3  1
    f[29,190,4]  R1455     -1
    f[29,190,4]  R1533     1
    f[29,190,4]  marginal_30_4  1
    f[29,191,3]  R1456     -1
    f[29,191,3]  R1533     1
    f[29,191,3]  marginal_30_3  1
    f[29,191,4]  R1456     -1
    f[29,191,4]  R1534     1
    f[29,191,4]  marginal_30_4  1
    f[29,192,3]  R1457     -1
    f[29,192,3]  R1534     1
    f[29,192,3]  marginal_30_3  1
    f[30,119,2]  R1458     -1
    f[30,119,2]  R1535     1
    f[30,119,2]  marginal_31_2  1
    f[30,119,7]  R1458     -1
    f[30,119,7]  R1540     1
    f[30,119,7]  marginal_31_7  1
    f[30,120,2]  R1459     -1
    f[30,120,2]  R1536     1
    f[30,120,2]  marginal_31_2  1
    f[30,120,7]  R1459     -1
    f[30,120,7]  R1541     1
    f[30,120,7]  marginal_31_7  1
    f[30,121,2]  R1460     -1
    f[30,121,2]  R1537     1
    f[30,121,2]  marginal_31_2  1
    f[30,121,7]  R1460     -1
    f[30,121,7]  R1542     1
    f[30,121,7]  marginal_31_7  1
    f[30,122,2]  R1461     -1
    f[30,122,2]  R1538     1
    f[30,122,2]  marginal_31_2  1
    f[30,122,7]  R1461     -1
    f[30,122,7]  R1543     1
    f[30,122,7]  marginal_31_7  1
    f[30,123,2]  R1462     -1
    f[30,123,2]  R1539     1
    f[30,123,2]  marginal_31_2  1
    f[30,123,7]  R1462     -1
    f[30,123,7]  R1544     1
    f[30,123,7]  marginal_31_7  1
    f[30,124,2]  R1463     -1
    f[30,124,2]  R1540     1
    f[30,124,2]  marginal_31_2  1
    f[30,124,7]  R1463     -1
    f[30,124,7]  R1545     1
    f[30,124,7]  marginal_31_7  1
    f[30,125,2]  R1464     -1
    f[30,125,2]  R1541     1
    f[30,125,2]  marginal_31_2  1
    f[30,125,7]  R1464     -1
    f[30,125,7]  R1546     1
    f[30,125,7]  marginal_31_7  1
    f[30,126,2]  R1465     -1
    f[30,126,2]  R1542     1
    f[30,126,2]  marginal_31_2  1
    f[30,126,7]  R1465     -1
    f[30,126,7]  R1547     1
    f[30,126,7]  marginal_31_7  1
    f[30,127,2]  R1466     -1
    f[30,127,2]  R1543     1
    f[30,127,2]  marginal_31_2  1
    f[30,127,7]  R1466     -1
    f[30,127,7]  R1548     1
    f[30,127,7]  marginal_31_7  1
    f[30,128,2]  R1467     -1
    f[30,128,2]  R1544     1
    f[30,128,2]  marginal_31_2  1
    f[30,128,7]  R1467     -1
    f[30,128,7]  R1549     1
    f[30,128,7]  marginal_31_7  1
    f[30,129,2]  R1468     -1
    f[30,129,2]  R1545     1
    f[30,129,2]  marginal_31_2  1
    f[30,129,7]  R1468     -1
    f[30,129,7]  R1550     1
    f[30,129,7]  marginal_31_7  1
    f[30,130,2]  R1469     -1
    f[30,130,2]  R1546     1
    f[30,130,2]  marginal_31_2  1
    f[30,130,7]  R1469     -1
    f[30,130,7]  R1551     1
    f[30,130,7]  marginal_31_7  1
    f[30,131,2]  R1470     -1
    f[30,131,2]  R1547     1
    f[30,131,2]  marginal_31_2  1
    f[30,131,7]  R1470     -1
    f[30,131,7]  R1552     1
    f[30,131,7]  marginal_31_7  1
    f[30,132,2]  R1471     -1
    f[30,132,2]  R1548     1
    f[30,132,2]  marginal_31_2  1
    f[30,132,7]  R1471     -1
    f[30,132,7]  R1553     1
    f[30,132,7]  marginal_31_7  1
    f[30,133,2]  R1472     -1
    f[30,133,2]  R1549     1
    f[30,133,2]  marginal_31_2  1
    f[30,133,7]  R1472     -1
    f[30,133,7]  R1554     1
    f[30,133,7]  marginal_31_7  1
    f[30,134,2]  R1473     -1
    f[30,134,2]  R1550     1
    f[30,134,2]  marginal_31_2  1
    f[30,134,7]  R1473     -1
    f[30,134,7]  R1555     1
    f[30,134,7]  marginal_31_7  1
    f[30,135,2]  R1474     -1
    f[30,135,2]  R1551     1
    f[30,135,2]  marginal_31_2  1
    f[30,135,7]  R1474     -1
    f[30,135,7]  R1556     1
    f[30,135,7]  marginal_31_7  1
    f[30,136,2]  R1475     -1
    f[30,136,2]  R1552     1
    f[30,136,2]  marginal_31_2  1
    f[30,136,7]  R1475     -1
    f[30,136,7]  R1557     1
    f[30,136,7]  marginal_31_7  1
    f[30,137,2]  R1476     -1
    f[30,137,2]  R1553     1
    f[30,137,2]  marginal_31_2  1
    f[30,137,7]  R1476     -1
    f[30,137,7]  R1558     1
    f[30,137,7]  marginal_31_7  1
    f[30,138,2]  R1477     -1
    f[30,138,2]  R1554     1
    f[30,138,2]  marginal_31_2  1
    f[30,138,7]  R1477     -1
    f[30,138,7]  R1559     1
    f[30,138,7]  marginal_31_7  1
    f[30,139,2]  R1478     -1
    f[30,139,2]  R1555     1
    f[30,139,2]  marginal_31_2  1
    f[30,139,7]  R1478     -1
    f[30,139,7]  R1560     1
    f[30,139,7]  marginal_31_7  1
    f[30,140,2]  R1479     -1
    f[30,140,2]  R1556     1
    f[30,140,2]  marginal_31_2  1
    f[30,140,7]  R1479     -1
    f[30,140,7]  R1561     1
    f[30,140,7]  marginal_31_7  1
    f[30,141,2]  R1480     -1
    f[30,141,2]  R1557     1
    f[30,141,2]  marginal_31_2  1
    f[30,141,7]  R1480     -1
    f[30,141,7]  R1562     1
    f[30,141,7]  marginal_31_7  1
    f[30,142,2]  R1481     -1
    f[30,142,2]  R1558     1
    f[30,142,2]  marginal_31_2  1
    f[30,142,7]  R1481     -1
    f[30,142,7]  R1563     1
    f[30,142,7]  marginal_31_7  1
    f[30,143,2]  R1482     -1
    f[30,143,2]  R1559     1
    f[30,143,2]  marginal_31_2  1
    f[30,143,7]  R1482     -1
    f[30,143,7]  R1564     1
    f[30,143,7]  marginal_31_7  1
    f[30,144,2]  R1483     -1
    f[30,144,2]  R1560     1
    f[30,144,2]  marginal_31_2  1
    f[30,144,7]  R1483     -1
    f[30,144,7]  R1565     1
    f[30,144,7]  marginal_31_7  1
    f[30,145,2]  R1484     -1
    f[30,145,2]  R1561     1
    f[30,145,2]  marginal_31_2  1
    f[30,145,7]  R1484     -1
    f[30,145,7]  R1566     1
    f[30,145,7]  marginal_31_7  1
    f[30,146,2]  R1485     -1
    f[30,146,2]  R1562     1
    f[30,146,2]  marginal_31_2  1
    f[30,146,7]  R1485     -1
    f[30,146,7]  R1567     1
    f[30,146,7]  marginal_31_7  1
    f[30,147,2]  R1486     -1
    f[30,147,2]  R1563     1
    f[30,147,2]  marginal_31_2  1
    f[30,147,7]  R1486     -1
    f[30,147,7]  R1568     1
    f[30,147,7]  marginal_31_7  1
    f[30,148,2]  R1487     -1
    f[30,148,2]  R1564     1
    f[30,148,2]  marginal_31_2  1
    f[30,148,7]  R1487     -1
    f[30,148,7]  R1569     1
    f[30,148,7]  marginal_31_7  1
    f[30,149,2]  R1488     -1
    f[30,149,2]  R1565     1
    f[30,149,2]  marginal_31_2  1
    f[30,149,7]  R1488     -1
    f[30,149,7]  R1570     1
    f[30,149,7]  marginal_31_7  1
    f[30,150,2]  R1489     -1
    f[30,150,2]  R1566     1
    f[30,150,2]  marginal_31_2  1
    f[30,150,7]  R1489     -1
    f[30,150,7]  R1571     1
    f[30,150,7]  marginal_31_7  1
    f[30,151,2]  R1490     -1
    f[30,151,2]  R1567     1
    f[30,151,2]  marginal_31_2  1
    f[30,151,7]  R1490     -1
    f[30,151,7]  R1572     1
    f[30,151,7]  marginal_31_7  1
    f[30,152,2]  R1491     -1
    f[30,152,2]  R1568     1
    f[30,152,2]  marginal_31_2  1
    f[30,152,7]  R1491     -1
    f[30,152,7]  R1573     1
    f[30,152,7]  marginal_31_7  1
    f[30,153,2]  R1492     -1
    f[30,153,2]  R1569     1
    f[30,153,2]  marginal_31_2  1
    f[30,153,7]  R1492     -1
    f[30,153,7]  R1574     1
    f[30,153,7]  marginal_31_7  1
    f[30,154,2]  R1493     -1
    f[30,154,2]  R1570     1
    f[30,154,2]  marginal_31_2  1
    f[30,154,7]  R1493     -1
    f[30,154,7]  R1575     1
    f[30,154,7]  marginal_31_7  1
    f[30,155,2]  R1494     -1
    f[30,155,2]  R1571     1
    f[30,155,2]  marginal_31_2  1
    f[30,155,7]  R1494     -1
    f[30,155,7]  R1576     1
    f[30,155,7]  marginal_31_7  1
    f[30,156,2]  R1495     -1
    f[30,156,2]  R1572     1
    f[30,156,2]  marginal_31_2  1
    f[30,156,7]  R1495     -1
    f[30,156,7]  R1577     1
    f[30,156,7]  marginal_31_7  1
    f[30,157,2]  R1496     -1
    f[30,157,2]  R1573     1
    f[30,157,2]  marginal_31_2  1
    f[30,157,7]  R1496     -1
    f[30,157,7]  R1578     1
    f[30,157,7]  marginal_31_7  1
    f[30,158,2]  R1497     -1
    f[30,158,2]  R1574     1
    f[30,158,2]  marginal_31_2  1
    f[30,158,7]  R1497     -1
    f[30,158,7]  R1579     1
    f[30,158,7]  marginal_31_7  1
    f[30,159,2]  R1498     -1
    f[30,159,2]  R1575     1
    f[30,159,2]  marginal_31_2  1
    f[30,159,7]  R1498     -1
    f[30,159,7]  R1580     1
    f[30,159,7]  marginal_31_7  1
    f[30,160,2]  R1499     -1
    f[30,160,2]  R1576     1
    f[30,160,2]  marginal_31_2  1
    f[30,160,7]  R1499     -1
    f[30,160,7]  R1581     1
    f[30,160,7]  marginal_31_7  1
    f[30,161,2]  R1500     -1
    f[30,161,2]  R1577     1
    f[30,161,2]  marginal_31_2  1
    f[30,161,7]  R1500     -1
    f[30,161,7]  R1582     1
    f[30,161,7]  marginal_31_7  1
    f[30,162,2]  R1501     -1
    f[30,162,2]  R1578     1
    f[30,162,2]  marginal_31_2  1
    f[30,162,7]  R1501     -1
    f[30,162,7]  R1583     1
    f[30,162,7]  marginal_31_7  1
    f[30,163,2]  R1502     -1
    f[30,163,2]  R1579     1
    f[30,163,2]  marginal_31_2  1
    f[30,163,7]  R1502     -1
    f[30,163,7]  R1584     1
    f[30,163,7]  marginal_31_7  1
    f[30,164,2]  R1503     -1
    f[30,164,2]  R1580     1
    f[30,164,2]  marginal_31_2  1
    f[30,164,7]  R1503     -1
    f[30,164,7]  R1585     1
    f[30,164,7]  marginal_31_7  1
    f[30,165,2]  R1504     -1
    f[30,165,2]  R1581     1
    f[30,165,2]  marginal_31_2  1
    f[30,165,7]  R1504     -1
    f[30,165,7]  R1586     1
    f[30,165,7]  marginal_31_7  1
    f[30,166,2]  R1505     -1
    f[30,166,2]  R1582     1
    f[30,166,2]  marginal_31_2  1
    f[30,166,7]  R1505     -1
    f[30,166,7]  R1587     1
    f[30,166,7]  marginal_31_7  1
    f[30,167,2]  R1506     -1
    f[30,167,2]  R1583     1
    f[30,167,2]  marginal_31_2  1
    f[30,167,7]  R1506     -1
    f[30,167,7]  R1588     1
    f[30,167,7]  marginal_31_7  1
    f[30,168,2]  R1507     -1
    f[30,168,2]  R1584     1
    f[30,168,2]  marginal_31_2  1
    f[30,168,7]  R1507     -1
    f[30,168,7]  R1589     1
    f[30,168,7]  marginal_31_7  1
    f[30,169,2]  R1508     -1
    f[30,169,2]  R1585     1
    f[30,169,2]  marginal_31_2  1
    f[30,169,7]  R1508     -1
    f[30,169,7]  R1590     1
    f[30,169,7]  marginal_31_7  1
    f[30,170,2]  R1509     -1
    f[30,170,2]  R1586     1
    f[30,170,2]  marginal_31_2  1
    f[30,170,7]  R1509     -1
    f[30,170,7]  R1591     1
    f[30,170,7]  marginal_31_7  1
    f[30,171,2]  R1510     -1
    f[30,171,2]  R1587     1
    f[30,171,2]  marginal_31_2  1
    f[30,171,7]  R1510     -1
    f[30,171,7]  R1592     1
    f[30,171,7]  marginal_31_7  1
    f[30,172,2]  R1511     -1
    f[30,172,2]  R1588     1
    f[30,172,2]  marginal_31_2  1
    f[30,172,7]  R1511     -1
    f[30,172,7]  R1593     1
    f[30,172,7]  marginal_31_7  1
    f[30,173,2]  R1512     -1
    f[30,173,2]  R1589     1
    f[30,173,2]  marginal_31_2  1
    f[30,173,7]  R1512     -1
    f[30,173,7]  R1594     1
    f[30,173,7]  marginal_31_7  1
    f[30,174,2]  R1513     -1
    f[30,174,2]  R1590     1
    f[30,174,2]  marginal_31_2  1
    f[30,174,7]  R1513     -1
    f[30,174,7]  R1595     1
    f[30,174,7]  marginal_31_7  1
    f[30,175,2]  R1514     -1
    f[30,175,2]  R1591     1
    f[30,175,2]  marginal_31_2  1
    f[30,175,7]  R1514     -1
    f[30,175,7]  R1596     1
    f[30,175,7]  marginal_31_7  1
    f[30,176,2]  R1515     -1
    f[30,176,2]  R1592     1
    f[30,176,2]  marginal_31_2  1
    f[30,176,7]  R1515     -1
    f[30,176,7]  R1597     1
    f[30,176,7]  marginal_31_7  1
    f[30,177,2]  R1516     -1
    f[30,177,2]  R1593     1
    f[30,177,2]  marginal_31_2  1
    f[30,177,7]  R1516     -1
    f[30,177,7]  R1598     1
    f[30,177,7]  marginal_31_7  1
    f[30,178,2]  R1517     -1
    f[30,178,2]  R1594     1
    f[30,178,2]  marginal_31_2  1
    f[30,178,7]  R1517     -1
    f[30,178,7]  R1599     1
    f[30,178,7]  marginal_31_7  1
    f[30,179,2]  R1518     -1
    f[30,179,2]  R1595     1
    f[30,179,2]  marginal_31_2  1
    f[30,179,7]  R1518     -1
    f[30,179,7]  R1600     1
    f[30,179,7]  marginal_31_7  1
    f[30,180,2]  R1519     -1
    f[30,180,2]  R1596     1
    f[30,180,2]  marginal_31_2  1
    f[30,180,7]  R1519     -1
    f[30,180,7]  R1601     1
    f[30,180,7]  marginal_31_7  1
    f[30,181,2]  R1520     -1
    f[30,181,2]  R1597     1
    f[30,181,2]  marginal_31_2  1
    f[30,181,7]  R1520     -1
    f[30,181,7]  R1602     1
    f[30,181,7]  marginal_31_7  1
    f[30,182,2]  R1521     -1
    f[30,182,2]  R1598     1
    f[30,182,2]  marginal_31_2  1
    f[30,182,7]  R1521     -1
    f[30,182,7]  R1603     1
    f[30,182,7]  marginal_31_7  1
    f[30,183,2]  R1522     -1
    f[30,183,2]  R1599     1
    f[30,183,2]  marginal_31_2  1
    f[30,183,7]  R1522     -1
    f[30,183,7]  R1604     1
    f[30,183,7]  marginal_31_7  1
    f[30,184,2]  R1523     -1
    f[30,184,2]  R1600     1
    f[30,184,2]  marginal_31_2  1
    f[30,184,7]  R1523     -1
    f[30,184,7]  R1605     1
    f[30,184,7]  marginal_31_7  1
    f[30,185,2]  R1524     -1
    f[30,185,2]  R1601     1
    f[30,185,2]  marginal_31_2  1
    f[30,185,7]  R1524     -1
    f[30,185,7]  R1606     1
    f[30,185,7]  marginal_31_7  1
    f[30,186,2]  R1525     -1
    f[30,186,2]  R1602     1
    f[30,186,2]  marginal_31_2  1
    f[30,186,7]  R1525     -1
    f[30,186,7]  R1607     1
    f[30,186,7]  marginal_31_7  1
    f[30,187,2]  R1526     -1
    f[30,187,2]  R1603     1
    f[30,187,2]  marginal_31_2  1
    f[30,187,7]  R1526     -1
    f[30,187,7]  R1608     1
    f[30,187,7]  marginal_31_7  1
    f[30,188,2]  R1527     -1
    f[30,188,2]  R1604     1
    f[30,188,2]  marginal_31_2  1
    f[30,188,7]  R1527     -1
    f[30,188,7]  R1609     1
    f[30,188,7]  marginal_31_7  1
    f[30,189,2]  R1528     -1
    f[30,189,2]  R1605     1
    f[30,189,2]  marginal_31_2  1
    f[30,189,7]  R1528     -1
    f[30,189,7]  R1610     1
    f[30,189,7]  marginal_31_7  1
    f[30,190,2]  R1529     -1
    f[30,190,2]  R1606     1
    f[30,190,2]  marginal_31_2  1
    f[30,190,7]  R1529     -1
    f[30,190,7]  R1611     1
    f[30,190,7]  marginal_31_7  1
    f[30,191,2]  R1530     -1
    f[30,191,2]  R1607     1
    f[30,191,2]  marginal_31_2  1
    f[30,192,2]  R1531     -1
    f[30,192,2]  R1608     1
    f[30,192,2]  marginal_31_2  1
    f[30,193,2]  R1532     -1
    f[30,193,2]  R1609     1
    f[30,193,2]  marginal_31_2  1
    f[30,194,2]  R1533     -1
    f[30,194,2]  R1610     1
    f[30,194,2]  marginal_31_2  1
    f[30,195,2]  R1534     -1
    f[30,195,2]  R1611     1
    f[30,195,2]  marginal_31_2  1
    f[31,121,3]  R1535     -1
    f[31,121,3]  R1612     1
    f[31,121,3]  marginal_32_3  1
    f[31,121,5]  R1535     -1
    f[31,121,5]  R1614     1
    f[31,121,5]  marginal_32_5  1
    f[31,122,3]  R1536     -1
    f[31,122,3]  R1613     1
    f[31,122,3]  marginal_32_3  1
    f[31,122,5]  R1536     -1
    f[31,122,5]  R1615     1
    f[31,122,5]  marginal_32_5  1
    f[31,123,3]  R1537     -1
    f[31,123,3]  R1614     1
    f[31,123,3]  marginal_32_3  1
    f[31,123,5]  R1537     -1
    f[31,123,5]  R1616     1
    f[31,123,5]  marginal_32_5  1
    f[31,124,3]  R1538     -1
    f[31,124,3]  R1615     1
    f[31,124,3]  marginal_32_3  1
    f[31,124,5]  R1538     -1
    f[31,124,5]  R1617     1
    f[31,124,5]  marginal_32_5  1
    f[31,125,3]  R1539     -1
    f[31,125,3]  R1616     1
    f[31,125,3]  marginal_32_3  1
    f[31,125,5]  R1539     -1
    f[31,125,5]  R1618     1
    f[31,125,5]  marginal_32_5  1
    f[31,126,3]  R1540     -1
    f[31,126,3]  R1617     1
    f[31,126,3]  marginal_32_3  1
    f[31,126,5]  R1540     -1
    f[31,126,5]  R1619     1
    f[31,126,5]  marginal_32_5  1
    f[31,127,3]  R1541     -1
    f[31,127,3]  R1618     1
    f[31,127,3]  marginal_32_3  1
    f[31,127,5]  R1541     -1
    f[31,127,5]  R1620     1
    f[31,127,5]  marginal_32_5  1
    f[31,128,3]  R1542     -1
    f[31,128,3]  R1619     1
    f[31,128,3]  marginal_32_3  1
    f[31,128,5]  R1542     -1
    f[31,128,5]  R1621     1
    f[31,128,5]  marginal_32_5  1
    f[31,129,3]  R1543     -1
    f[31,129,3]  R1620     1
    f[31,129,3]  marginal_32_3  1
    f[31,129,5]  R1543     -1
    f[31,129,5]  R1622     1
    f[31,129,5]  marginal_32_5  1
    f[31,130,3]  R1544     -1
    f[31,130,3]  R1621     1
    f[31,130,3]  marginal_32_3  1
    f[31,130,5]  R1544     -1
    f[31,130,5]  R1623     1
    f[31,130,5]  marginal_32_5  1
    f[31,131,3]  R1545     -1
    f[31,131,3]  R1622     1
    f[31,131,3]  marginal_32_3  1
    f[31,131,5]  R1545     -1
    f[31,131,5]  R1624     1
    f[31,131,5]  marginal_32_5  1
    f[31,132,3]  R1546     -1
    f[31,132,3]  R1623     1
    f[31,132,3]  marginal_32_3  1
    f[31,132,5]  R1546     -1
    f[31,132,5]  R1625     1
    f[31,132,5]  marginal_32_5  1
    f[31,133,3]  R1547     -1
    f[31,133,3]  R1624     1
    f[31,133,3]  marginal_32_3  1
    f[31,133,5]  R1547     -1
    f[31,133,5]  R1626     1
    f[31,133,5]  marginal_32_5  1
    f[31,134,3]  R1548     -1
    f[31,134,3]  R1625     1
    f[31,134,3]  marginal_32_3  1
    f[31,134,5]  R1548     -1
    f[31,134,5]  R1627     1
    f[31,134,5]  marginal_32_5  1
    f[31,135,3]  R1549     -1
    f[31,135,3]  R1626     1
    f[31,135,3]  marginal_32_3  1
    f[31,135,5]  R1549     -1
    f[31,135,5]  R1628     1
    f[31,135,5]  marginal_32_5  1
    f[31,136,3]  R1550     -1
    f[31,136,3]  R1627     1
    f[31,136,3]  marginal_32_3  1
    f[31,136,5]  R1550     -1
    f[31,136,5]  R1629     1
    f[31,136,5]  marginal_32_5  1
    f[31,137,3]  R1551     -1
    f[31,137,3]  R1628     1
    f[31,137,3]  marginal_32_3  1
    f[31,137,5]  R1551     -1
    f[31,137,5]  R1630     1
    f[31,137,5]  marginal_32_5  1
    f[31,138,3]  R1552     -1
    f[31,138,3]  R1629     1
    f[31,138,3]  marginal_32_3  1
    f[31,138,5]  R1552     -1
    f[31,138,5]  R1631     1
    f[31,138,5]  marginal_32_5  1
    f[31,139,3]  R1553     -1
    f[31,139,3]  R1630     1
    f[31,139,3]  marginal_32_3  1
    f[31,139,5]  R1553     -1
    f[31,139,5]  R1632     1
    f[31,139,5]  marginal_32_5  1
    f[31,140,3]  R1554     -1
    f[31,140,3]  R1631     1
    f[31,140,3]  marginal_32_3  1
    f[31,140,5]  R1554     -1
    f[31,140,5]  R1633     1
    f[31,140,5]  marginal_32_5  1
    f[31,141,3]  R1555     -1
    f[31,141,3]  R1632     1
    f[31,141,3]  marginal_32_3  1
    f[31,141,5]  R1555     -1
    f[31,141,5]  R1634     1
    f[31,141,5]  marginal_32_5  1
    f[31,142,3]  R1556     -1
    f[31,142,3]  R1633     1
    f[31,142,3]  marginal_32_3  1
    f[31,142,5]  R1556     -1
    f[31,142,5]  R1635     1
    f[31,142,5]  marginal_32_5  1
    f[31,143,3]  R1557     -1
    f[31,143,3]  R1634     1
    f[31,143,3]  marginal_32_3  1
    f[31,143,5]  R1557     -1
    f[31,143,5]  R1636     1
    f[31,143,5]  marginal_32_5  1
    f[31,144,3]  R1558     -1
    f[31,144,3]  R1635     1
    f[31,144,3]  marginal_32_3  1
    f[31,144,5]  R1558     -1
    f[31,144,5]  R1637     1
    f[31,144,5]  marginal_32_5  1
    f[31,145,3]  R1559     -1
    f[31,145,3]  R1636     1
    f[31,145,3]  marginal_32_3  1
    f[31,145,5]  R1559     -1
    f[31,145,5]  R1638     1
    f[31,145,5]  marginal_32_5  1
    f[31,146,3]  R1560     -1
    f[31,146,3]  R1637     1
    f[31,146,3]  marginal_32_3  1
    f[31,146,5]  R1560     -1
    f[31,146,5]  R1639     1
    f[31,146,5]  marginal_32_5  1
    f[31,147,3]  R1561     -1
    f[31,147,3]  R1638     1
    f[31,147,3]  marginal_32_3  1
    f[31,147,5]  R1561     -1
    f[31,147,5]  R1640     1
    f[31,147,5]  marginal_32_5  1
    f[31,148,3]  R1562     -1
    f[31,148,3]  R1639     1
    f[31,148,3]  marginal_32_3  1
    f[31,148,5]  R1562     -1
    f[31,148,5]  R1641     1
    f[31,148,5]  marginal_32_5  1
    f[31,149,3]  R1563     -1
    f[31,149,3]  R1640     1
    f[31,149,3]  marginal_32_3  1
    f[31,149,5]  R1563     -1
    f[31,149,5]  R1642     1
    f[31,149,5]  marginal_32_5  1
    f[31,150,3]  R1564     -1
    f[31,150,3]  R1641     1
    f[31,150,3]  marginal_32_3  1
    f[31,150,5]  R1564     -1
    f[31,150,5]  R1643     1
    f[31,150,5]  marginal_32_5  1
    f[31,151,3]  R1565     -1
    f[31,151,3]  R1642     1
    f[31,151,3]  marginal_32_3  1
    f[31,151,5]  R1565     -1
    f[31,151,5]  R1644     1
    f[31,151,5]  marginal_32_5  1
    f[31,152,3]  R1566     -1
    f[31,152,3]  R1643     1
    f[31,152,3]  marginal_32_3  1
    f[31,152,5]  R1566     -1
    f[31,152,5]  R1645     1
    f[31,152,5]  marginal_32_5  1
    f[31,153,3]  R1567     -1
    f[31,153,3]  R1644     1
    f[31,153,3]  marginal_32_3  1
    f[31,153,5]  R1567     -1
    f[31,153,5]  R1646     1
    f[31,153,5]  marginal_32_5  1
    f[31,154,3]  R1568     -1
    f[31,154,3]  R1645     1
    f[31,154,3]  marginal_32_3  1
    f[31,154,5]  R1568     -1
    f[31,154,5]  R1647     1
    f[31,154,5]  marginal_32_5  1
    f[31,155,3]  R1569     -1
    f[31,155,3]  R1646     1
    f[31,155,3]  marginal_32_3  1
    f[31,155,5]  R1569     -1
    f[31,155,5]  R1648     1
    f[31,155,5]  marginal_32_5  1
    f[31,156,3]  R1570     -1
    f[31,156,3]  R1647     1
    f[31,156,3]  marginal_32_3  1
    f[31,156,5]  R1570     -1
    f[31,156,5]  R1649     1
    f[31,156,5]  marginal_32_5  1
    f[31,157,3]  R1571     -1
    f[31,157,3]  R1648     1
    f[31,157,3]  marginal_32_3  1
    f[31,157,5]  R1571     -1
    f[31,157,5]  R1650     1
    f[31,157,5]  marginal_32_5  1
    f[31,158,3]  R1572     -1
    f[31,158,3]  R1649     1
    f[31,158,3]  marginal_32_3  1
    f[31,158,5]  R1572     -1
    f[31,158,5]  R1651     1
    f[31,158,5]  marginal_32_5  1
    f[31,159,3]  R1573     -1
    f[31,159,3]  R1650     1
    f[31,159,3]  marginal_32_3  1
    f[31,159,5]  R1573     -1
    f[31,159,5]  R1652     1
    f[31,159,5]  marginal_32_5  1
    f[31,160,3]  R1574     -1
    f[31,160,3]  R1651     1
    f[31,160,3]  marginal_32_3  1
    f[31,160,5]  R1574     -1
    f[31,160,5]  R1653     1
    f[31,160,5]  marginal_32_5  1
    f[31,161,3]  R1575     -1
    f[31,161,3]  R1652     1
    f[31,161,3]  marginal_32_3  1
    f[31,161,5]  R1575     -1
    f[31,161,5]  R1654     1
    f[31,161,5]  marginal_32_5  1
    f[31,162,3]  R1576     -1
    f[31,162,3]  R1653     1
    f[31,162,3]  marginal_32_3  1
    f[31,162,5]  R1576     -1
    f[31,162,5]  R1655     1
    f[31,162,5]  marginal_32_5  1
    f[31,163,3]  R1577     -1
    f[31,163,3]  R1654     1
    f[31,163,3]  marginal_32_3  1
    f[31,163,5]  R1577     -1
    f[31,163,5]  R1656     1
    f[31,163,5]  marginal_32_5  1
    f[31,164,3]  R1578     -1
    f[31,164,3]  R1655     1
    f[31,164,3]  marginal_32_3  1
    f[31,164,5]  R1578     -1
    f[31,164,5]  R1657     1
    f[31,164,5]  marginal_32_5  1
    f[31,165,3]  R1579     -1
    f[31,165,3]  R1656     1
    f[31,165,3]  marginal_32_3  1
    f[31,165,5]  R1579     -1
    f[31,165,5]  R1658     1
    f[31,165,5]  marginal_32_5  1
    f[31,166,3]  R1580     -1
    f[31,166,3]  R1657     1
    f[31,166,3]  marginal_32_3  1
    f[31,166,5]  R1580     -1
    f[31,166,5]  R1659     1
    f[31,166,5]  marginal_32_5  1
    f[31,167,3]  R1581     -1
    f[31,167,3]  R1658     1
    f[31,167,3]  marginal_32_3  1
    f[31,167,5]  R1581     -1
    f[31,167,5]  R1660     1
    f[31,167,5]  marginal_32_5  1
    f[31,168,3]  R1582     -1
    f[31,168,3]  R1659     1
    f[31,168,3]  marginal_32_3  1
    f[31,168,5]  R1582     -1
    f[31,168,5]  R1661     1
    f[31,168,5]  marginal_32_5  1
    f[31,169,3]  R1583     -1
    f[31,169,3]  R1660     1
    f[31,169,3]  marginal_32_3  1
    f[31,169,5]  R1583     -1
    f[31,169,5]  R1662     1
    f[31,169,5]  marginal_32_5  1
    f[31,170,3]  R1584     -1
    f[31,170,3]  R1661     1
    f[31,170,3]  marginal_32_3  1
    f[31,170,5]  R1584     -1
    f[31,170,5]  R1663     1
    f[31,170,5]  marginal_32_5  1
    f[31,171,3]  R1585     -1
    f[31,171,3]  R1662     1
    f[31,171,3]  marginal_32_3  1
    f[31,171,5]  R1585     -1
    f[31,171,5]  R1664     1
    f[31,171,5]  marginal_32_5  1
    f[31,172,3]  R1586     -1
    f[31,172,3]  R1663     1
    f[31,172,3]  marginal_32_3  1
    f[31,172,5]  R1586     -1
    f[31,172,5]  R1665     1
    f[31,172,5]  marginal_32_5  1
    f[31,173,3]  R1587     -1
    f[31,173,3]  R1664     1
    f[31,173,3]  marginal_32_3  1
    f[31,173,5]  R1587     -1
    f[31,173,5]  R1666     1
    f[31,173,5]  marginal_32_5  1
    f[31,174,3]  R1588     -1
    f[31,174,3]  R1665     1
    f[31,174,3]  marginal_32_3  1
    f[31,174,5]  R1588     -1
    f[31,174,5]  R1667     1
    f[31,174,5]  marginal_32_5  1
    f[31,175,3]  R1589     -1
    f[31,175,3]  R1666     1
    f[31,175,3]  marginal_32_3  1
    f[31,175,5]  R1589     -1
    f[31,175,5]  R1668     1
    f[31,175,5]  marginal_32_5  1
    f[31,176,3]  R1590     -1
    f[31,176,3]  R1667     1
    f[31,176,3]  marginal_32_3  1
    f[31,176,5]  R1590     -1
    f[31,176,5]  R1669     1
    f[31,176,5]  marginal_32_5  1
    f[31,177,3]  R1591     -1
    f[31,177,3]  R1668     1
    f[31,177,3]  marginal_32_3  1
    f[31,177,5]  R1591     -1
    f[31,177,5]  R1670     1
    f[31,177,5]  marginal_32_5  1
    f[31,178,3]  R1592     -1
    f[31,178,3]  R1669     1
    f[31,178,3]  marginal_32_3  1
    f[31,178,5]  R1592     -1
    f[31,178,5]  R1671     1
    f[31,178,5]  marginal_32_5  1
    f[31,179,3]  R1593     -1
    f[31,179,3]  R1670     1
    f[31,179,3]  marginal_32_3  1
    f[31,179,5]  R1593     -1
    f[31,179,5]  R1672     1
    f[31,179,5]  marginal_32_5  1
    f[31,180,3]  R1594     -1
    f[31,180,3]  R1671     1
    f[31,180,3]  marginal_32_3  1
    f[31,180,5]  R1594     -1
    f[31,180,5]  R1673     1
    f[31,180,5]  marginal_32_5  1
    f[31,181,3]  R1595     -1
    f[31,181,3]  R1672     1
    f[31,181,3]  marginal_32_3  1
    f[31,181,5]  R1595     -1
    f[31,181,5]  R1674     1
    f[31,181,5]  marginal_32_5  1
    f[31,182,3]  R1596     -1
    f[31,182,3]  R1673     1
    f[31,182,3]  marginal_32_3  1
    f[31,182,5]  R1596     -1
    f[31,182,5]  R1675     1
    f[31,182,5]  marginal_32_5  1
    f[31,183,3]  R1597     -1
    f[31,183,3]  R1674     1
    f[31,183,3]  marginal_32_3  1
    f[31,183,5]  R1597     -1
    f[31,183,5]  R1676     1
    f[31,183,5]  marginal_32_5  1
    f[31,184,3]  R1598     -1
    f[31,184,3]  R1675     1
    f[31,184,3]  marginal_32_3  1
    f[31,184,5]  R1598     -1
    f[31,184,5]  R1677     1
    f[31,184,5]  marginal_32_5  1
    f[31,185,3]  R1599     -1
    f[31,185,3]  R1676     1
    f[31,185,3]  marginal_32_3  1
    f[31,185,5]  R1599     -1
    f[31,185,5]  R1678     1
    f[31,185,5]  marginal_32_5  1
    f[31,186,3]  R1600     -1
    f[31,186,3]  R1677     1
    f[31,186,3]  marginal_32_3  1
    f[31,186,5]  R1600     -1
    f[31,186,5]  R1679     1
    f[31,186,5]  marginal_32_5  1
    f[31,187,3]  R1601     -1
    f[31,187,3]  R1678     1
    f[31,187,3]  marginal_32_3  1
    f[31,187,5]  R1601     -1
    f[31,187,5]  R1680     1
    f[31,187,5]  marginal_32_5  1
    f[31,188,3]  R1602     -1
    f[31,188,3]  R1679     1
    f[31,188,3]  marginal_32_3  1
    f[31,188,5]  R1602     -1
    f[31,188,5]  R1681     1
    f[31,188,5]  marginal_32_5  1
    f[31,189,3]  R1603     -1
    f[31,189,3]  R1680     1
    f[31,189,3]  marginal_32_3  1
    f[31,189,5]  R1603     -1
    f[31,189,5]  R1682     1
    f[31,189,5]  marginal_32_5  1
    f[31,190,3]  R1604     -1
    f[31,190,3]  R1681     1
    f[31,190,3]  marginal_32_3  1
    f[31,190,5]  R1604     -1
    f[31,190,5]  R1683     1
    f[31,190,5]  marginal_32_5  1
    f[31,191,3]  R1605     -1
    f[31,191,3]  R1682     1
    f[31,191,3]  marginal_32_3  1
    f[31,191,5]  R1605     -1
    f[31,191,5]  R1684     1
    f[31,191,5]  marginal_32_5  1
    f[31,192,3]  R1606     -1
    f[31,192,3]  R1683     1
    f[31,192,3]  marginal_32_3  1
    f[31,192,5]  R1606     -1
    f[31,192,5]  R1685     1
    f[31,192,5]  marginal_32_5  1
    f[31,193,3]  R1607     -1
    f[31,193,3]  R1684     1
    f[31,193,3]  marginal_32_3  1
    f[31,193,5]  R1607     -1
    f[31,193,5]  R1686     1
    f[31,193,5]  marginal_32_5  1
    f[31,194,3]  R1608     -1
    f[31,194,3]  R1685     1
    f[31,194,3]  marginal_32_3  1
    f[31,194,5]  R1608     -1
    f[31,194,5]  R1687     1
    f[31,194,5]  marginal_32_5  1
    f[31,195,3]  R1609     -1
    f[31,195,3]  R1686     1
    f[31,195,3]  marginal_32_3  1
    f[31,195,5]  R1609     -1
    f[31,195,5]  R1688     1
    f[31,195,5]  marginal_32_5  1
    f[31,196,3]  R1610     -1
    f[31,196,3]  R1687     1
    f[31,196,3]  marginal_32_3  1
    f[31,197,3]  R1611     -1
    f[31,197,3]  R1688     1
    f[31,197,3]  marginal_32_3  1
    f[32,124,6]  R1612     -1
    f[32,124,6]  R1689     1
    f[32,124,6]  marginal_33_6  1
    f[32,124,7]  R1612     -1
    f[32,124,7]  R1690     1
    f[32,124,7]  marginal_33_7  1
    f[32,125,6]  R1613     -1
    f[32,125,6]  R1690     1
    f[32,125,6]  marginal_33_6  1
    f[32,125,7]  R1613     -1
    f[32,125,7]  R1691     1
    f[32,125,7]  marginal_33_7  1
    f[32,126,6]  R1614     -1
    f[32,126,6]  R1691     1
    f[32,126,6]  marginal_33_6  1
    f[32,126,7]  R1614     -1
    f[32,126,7]  R1692     1
    f[32,126,7]  marginal_33_7  1
    f[32,127,6]  R1615     -1
    f[32,127,6]  R1692     1
    f[32,127,6]  marginal_33_6  1
    f[32,127,7]  R1615     -1
    f[32,127,7]  R1693     1
    f[32,127,7]  marginal_33_7  1
    f[32,128,6]  R1616     -1
    f[32,128,6]  R1693     1
    f[32,128,6]  marginal_33_6  1
    f[32,128,7]  R1616     -1
    f[32,128,7]  R1694     1
    f[32,128,7]  marginal_33_7  1
    f[32,129,6]  R1617     -1
    f[32,129,6]  R1694     1
    f[32,129,6]  marginal_33_6  1
    f[32,129,7]  R1617     -1
    f[32,129,7]  R1695     1
    f[32,129,7]  marginal_33_7  1
    f[32,130,6]  R1618     -1
    f[32,130,6]  R1695     1
    f[32,130,6]  marginal_33_6  1
    f[32,130,7]  R1618     -1
    f[32,130,7]  R1696     1
    f[32,130,7]  marginal_33_7  1
    f[32,131,6]  R1619     -1
    f[32,131,6]  R1696     1
    f[32,131,6]  marginal_33_6  1
    f[32,131,7]  R1619     -1
    f[32,131,7]  R1697     1
    f[32,131,7]  marginal_33_7  1
    f[32,132,6]  R1620     -1
    f[32,132,6]  R1697     1
    f[32,132,6]  marginal_33_6  1
    f[32,132,7]  R1620     -1
    f[32,132,7]  R1698     1
    f[32,132,7]  marginal_33_7  1
    f[32,133,6]  R1621     -1
    f[32,133,6]  R1698     1
    f[32,133,6]  marginal_33_6  1
    f[32,133,7]  R1621     -1
    f[32,133,7]  R1699     1
    f[32,133,7]  marginal_33_7  1
    f[32,134,6]  R1622     -1
    f[32,134,6]  R1699     1
    f[32,134,6]  marginal_33_6  1
    f[32,134,7]  R1622     -1
    f[32,134,7]  R1700     1
    f[32,134,7]  marginal_33_7  1
    f[32,135,6]  R1623     -1
    f[32,135,6]  R1700     1
    f[32,135,6]  marginal_33_6  1
    f[32,135,7]  R1623     -1
    f[32,135,7]  R1701     1
    f[32,135,7]  marginal_33_7  1
    f[32,136,6]  R1624     -1
    f[32,136,6]  R1701     1
    f[32,136,6]  marginal_33_6  1
    f[32,136,7]  R1624     -1
    f[32,136,7]  R1702     1
    f[32,136,7]  marginal_33_7  1
    f[32,137,6]  R1625     -1
    f[32,137,6]  R1702     1
    f[32,137,6]  marginal_33_6  1
    f[32,137,7]  R1625     -1
    f[32,137,7]  R1703     1
    f[32,137,7]  marginal_33_7  1
    f[32,138,6]  R1626     -1
    f[32,138,6]  R1703     1
    f[32,138,6]  marginal_33_6  1
    f[32,138,7]  R1626     -1
    f[32,138,7]  R1704     1
    f[32,138,7]  marginal_33_7  1
    f[32,139,6]  R1627     -1
    f[32,139,6]  R1704     1
    f[32,139,6]  marginal_33_6  1
    f[32,139,7]  R1627     -1
    f[32,139,7]  R1705     1
    f[32,139,7]  marginal_33_7  1
    f[32,140,6]  R1628     -1
    f[32,140,6]  R1705     1
    f[32,140,6]  marginal_33_6  1
    f[32,140,7]  R1628     -1
    f[32,140,7]  R1706     1
    f[32,140,7]  marginal_33_7  1
    f[32,141,6]  R1629     -1
    f[32,141,6]  R1706     1
    f[32,141,6]  marginal_33_6  1
    f[32,141,7]  R1629     -1
    f[32,141,7]  R1707     1
    f[32,141,7]  marginal_33_7  1
    f[32,142,6]  R1630     -1
    f[32,142,6]  R1707     1
    f[32,142,6]  marginal_33_6  1
    f[32,142,7]  R1630     -1
    f[32,142,7]  R1708     1
    f[32,142,7]  marginal_33_7  1
    f[32,143,6]  R1631     -1
    f[32,143,6]  R1708     1
    f[32,143,6]  marginal_33_6  1
    f[32,143,7]  R1631     -1
    f[32,143,7]  R1709     1
    f[32,143,7]  marginal_33_7  1
    f[32,144,6]  R1632     -1
    f[32,144,6]  R1709     1
    f[32,144,6]  marginal_33_6  1
    f[32,144,7]  R1632     -1
    f[32,144,7]  R1710     1
    f[32,144,7]  marginal_33_7  1
    f[32,145,6]  R1633     -1
    f[32,145,6]  R1710     1
    f[32,145,6]  marginal_33_6  1
    f[32,145,7]  R1633     -1
    f[32,145,7]  R1711     1
    f[32,145,7]  marginal_33_7  1
    f[32,146,6]  R1634     -1
    f[32,146,6]  R1711     1
    f[32,146,6]  marginal_33_6  1
    f[32,146,7]  R1634     -1
    f[32,146,7]  R1712     1
    f[32,146,7]  marginal_33_7  1
    f[32,147,6]  R1635     -1
    f[32,147,6]  R1712     1
    f[32,147,6]  marginal_33_6  1
    f[32,147,7]  R1635     -1
    f[32,147,7]  R1713     1
    f[32,147,7]  marginal_33_7  1
    f[32,148,6]  R1636     -1
    f[32,148,6]  R1713     1
    f[32,148,6]  marginal_33_6  1
    f[32,148,7]  R1636     -1
    f[32,148,7]  R1714     1
    f[32,148,7]  marginal_33_7  1
    f[32,149,6]  R1637     -1
    f[32,149,6]  R1714     1
    f[32,149,6]  marginal_33_6  1
    f[32,149,7]  R1637     -1
    f[32,149,7]  R1715     1
    f[32,149,7]  marginal_33_7  1
    f[32,150,6]  R1638     -1
    f[32,150,6]  R1715     1
    f[32,150,6]  marginal_33_6  1
    f[32,150,7]  R1638     -1
    f[32,150,7]  R1716     1
    f[32,150,7]  marginal_33_7  1
    f[32,151,6]  R1639     -1
    f[32,151,6]  R1716     1
    f[32,151,6]  marginal_33_6  1
    f[32,151,7]  R1639     -1
    f[32,151,7]  R1717     1
    f[32,151,7]  marginal_33_7  1
    f[32,152,6]  R1640     -1
    f[32,152,6]  R1717     1
    f[32,152,6]  marginal_33_6  1
    f[32,152,7]  R1640     -1
    f[32,152,7]  R1718     1
    f[32,152,7]  marginal_33_7  1
    f[32,153,6]  R1641     -1
    f[32,153,6]  R1718     1
    f[32,153,6]  marginal_33_6  1
    f[32,153,7]  R1641     -1
    f[32,153,7]  R1719     1
    f[32,153,7]  marginal_33_7  1
    f[32,154,6]  R1642     -1
    f[32,154,6]  R1719     1
    f[32,154,6]  marginal_33_6  1
    f[32,154,7]  R1642     -1
    f[32,154,7]  R1720     1
    f[32,154,7]  marginal_33_7  1
    f[32,155,6]  R1643     -1
    f[32,155,6]  R1720     1
    f[32,155,6]  marginal_33_6  1
    f[32,155,7]  R1643     -1
    f[32,155,7]  R1721     1
    f[32,155,7]  marginal_33_7  1
    f[32,156,6]  R1644     -1
    f[32,156,6]  R1721     1
    f[32,156,6]  marginal_33_6  1
    f[32,156,7]  R1644     -1
    f[32,156,7]  R1722     1
    f[32,156,7]  marginal_33_7  1
    f[32,157,6]  R1645     -1
    f[32,157,6]  R1722     1
    f[32,157,6]  marginal_33_6  1
    f[32,157,7]  R1645     -1
    f[32,157,7]  R1723     1
    f[32,157,7]  marginal_33_7  1
    f[32,158,6]  R1646     -1
    f[32,158,6]  R1723     1
    f[32,158,6]  marginal_33_6  1
    f[32,158,7]  R1646     -1
    f[32,158,7]  R1724     1
    f[32,158,7]  marginal_33_7  1
    f[32,159,6]  R1647     -1
    f[32,159,6]  R1724     1
    f[32,159,6]  marginal_33_6  1
    f[32,159,7]  R1647     -1
    f[32,159,7]  R1725     1
    f[32,159,7]  marginal_33_7  1
    f[32,160,6]  R1648     -1
    f[32,160,6]  R1725     1
    f[32,160,6]  marginal_33_6  1
    f[32,160,7]  R1648     -1
    f[32,160,7]  R1726     1
    f[32,160,7]  marginal_33_7  1
    f[32,161,6]  R1649     -1
    f[32,161,6]  R1726     1
    f[32,161,6]  marginal_33_6  1
    f[32,161,7]  R1649     -1
    f[32,161,7]  R1727     1
    f[32,161,7]  marginal_33_7  1
    f[32,162,6]  R1650     -1
    f[32,162,6]  R1727     1
    f[32,162,6]  marginal_33_6  1
    f[32,162,7]  R1650     -1
    f[32,162,7]  R1728     1
    f[32,162,7]  marginal_33_7  1
    f[32,163,6]  R1651     -1
    f[32,163,6]  R1728     1
    f[32,163,6]  marginal_33_6  1
    f[32,163,7]  R1651     -1
    f[32,163,7]  R1729     1
    f[32,163,7]  marginal_33_7  1
    f[32,164,6]  R1652     -1
    f[32,164,6]  R1729     1
    f[32,164,6]  marginal_33_6  1
    f[32,164,7]  R1652     -1
    f[32,164,7]  R1730     1
    f[32,164,7]  marginal_33_7  1
    f[32,165,6]  R1653     -1
    f[32,165,6]  R1730     1
    f[32,165,6]  marginal_33_6  1
    f[32,165,7]  R1653     -1
    f[32,165,7]  R1731     1
    f[32,165,7]  marginal_33_7  1
    f[32,166,6]  R1654     -1
    f[32,166,6]  R1731     1
    f[32,166,6]  marginal_33_6  1
    f[32,166,7]  R1654     -1
    f[32,166,7]  R1732     1
    f[32,166,7]  marginal_33_7  1
    f[32,167,6]  R1655     -1
    f[32,167,6]  R1732     1
    f[32,167,6]  marginal_33_6  1
    f[32,167,7]  R1655     -1
    f[32,167,7]  R1733     1
    f[32,167,7]  marginal_33_7  1
    f[32,168,6]  R1656     -1
    f[32,168,6]  R1733     1
    f[32,168,6]  marginal_33_6  1
    f[32,168,7]  R1656     -1
    f[32,168,7]  R1734     1
    f[32,168,7]  marginal_33_7  1
    f[32,169,6]  R1657     -1
    f[32,169,6]  R1734     1
    f[32,169,6]  marginal_33_6  1
    f[32,169,7]  R1657     -1
    f[32,169,7]  R1735     1
    f[32,169,7]  marginal_33_7  1
    f[32,170,6]  R1658     -1
    f[32,170,6]  R1735     1
    f[32,170,6]  marginal_33_6  1
    f[32,170,7]  R1658     -1
    f[32,170,7]  R1736     1
    f[32,170,7]  marginal_33_7  1
    f[32,171,6]  R1659     -1
    f[32,171,6]  R1736     1
    f[32,171,6]  marginal_33_6  1
    f[32,171,7]  R1659     -1
    f[32,171,7]  R1737     1
    f[32,171,7]  marginal_33_7  1
    f[32,172,6]  R1660     -1
    f[32,172,6]  R1737     1
    f[32,172,6]  marginal_33_6  1
    f[32,172,7]  R1660     -1
    f[32,172,7]  R1738     1
    f[32,172,7]  marginal_33_7  1
    f[32,173,6]  R1661     -1
    f[32,173,6]  R1738     1
    f[32,173,6]  marginal_33_6  1
    f[32,173,7]  R1661     -1
    f[32,173,7]  R1739     1
    f[32,173,7]  marginal_33_7  1
    f[32,174,6]  R1662     -1
    f[32,174,6]  R1739     1
    f[32,174,6]  marginal_33_6  1
    f[32,174,7]  R1662     -1
    f[32,174,7]  R1740     1
    f[32,174,7]  marginal_33_7  1
    f[32,175,6]  R1663     -1
    f[32,175,6]  R1740     1
    f[32,175,6]  marginal_33_6  1
    f[32,175,7]  R1663     -1
    f[32,175,7]  R1741     1
    f[32,175,7]  marginal_33_7  1
    f[32,176,6]  R1664     -1
    f[32,176,6]  R1741     1
    f[32,176,6]  marginal_33_6  1
    f[32,176,7]  R1664     -1
    f[32,176,7]  R1742     1
    f[32,176,7]  marginal_33_7  1
    f[32,177,6]  R1665     -1
    f[32,177,6]  R1742     1
    f[32,177,6]  marginal_33_6  1
    f[32,177,7]  R1665     -1
    f[32,177,7]  R1743     1
    f[32,177,7]  marginal_33_7  1
    f[32,178,6]  R1666     -1
    f[32,178,6]  R1743     1
    f[32,178,6]  marginal_33_6  1
    f[32,178,7]  R1666     -1
    f[32,178,7]  R1744     1
    f[32,178,7]  marginal_33_7  1
    f[32,179,6]  R1667     -1
    f[32,179,6]  R1744     1
    f[32,179,6]  marginal_33_6  1
    f[32,179,7]  R1667     -1
    f[32,179,7]  R1745     1
    f[32,179,7]  marginal_33_7  1
    f[32,180,6]  R1668     -1
    f[32,180,6]  R1745     1
    f[32,180,6]  marginal_33_6  1
    f[32,180,7]  R1668     -1
    f[32,180,7]  R1746     1
    f[32,180,7]  marginal_33_7  1
    f[32,181,6]  R1669     -1
    f[32,181,6]  R1746     1
    f[32,181,6]  marginal_33_6  1
    f[32,181,7]  R1669     -1
    f[32,181,7]  R1747     1
    f[32,181,7]  marginal_33_7  1
    f[32,182,6]  R1670     -1
    f[32,182,6]  R1747     1
    f[32,182,6]  marginal_33_6  1
    f[32,182,7]  R1670     -1
    f[32,182,7]  R1748     1
    f[32,182,7]  marginal_33_7  1
    f[32,183,6]  R1671     -1
    f[32,183,6]  R1748     1
    f[32,183,6]  marginal_33_6  1
    f[32,183,7]  R1671     -1
    f[32,183,7]  R1749     1
    f[32,183,7]  marginal_33_7  1
    f[32,184,6]  R1672     -1
    f[32,184,6]  R1749     1
    f[32,184,6]  marginal_33_6  1
    f[32,184,7]  R1672     -1
    f[32,184,7]  R1750     1
    f[32,184,7]  marginal_33_7  1
    f[32,185,6]  R1673     -1
    f[32,185,6]  R1750     1
    f[32,185,6]  marginal_33_6  1
    f[32,185,7]  R1673     -1
    f[32,185,7]  R1751     1
    f[32,185,7]  marginal_33_7  1
    f[32,186,6]  R1674     -1
    f[32,186,6]  R1751     1
    f[32,186,6]  marginal_33_6  1
    f[32,186,7]  R1674     -1
    f[32,186,7]  R1752     1
    f[32,186,7]  marginal_33_7  1
    f[32,187,6]  R1675     -1
    f[32,187,6]  R1752     1
    f[32,187,6]  marginal_33_6  1
    f[32,187,7]  R1675     -1
    f[32,187,7]  R1753     1
    f[32,187,7]  marginal_33_7  1
    f[32,188,6]  R1676     -1
    f[32,188,6]  R1753     1
    f[32,188,6]  marginal_33_6  1
    f[32,188,7]  R1676     -1
    f[32,188,7]  R1754     1
    f[32,188,7]  marginal_33_7  1
    f[32,189,6]  R1677     -1
    f[32,189,6]  R1754     1
    f[32,189,6]  marginal_33_6  1
    f[32,189,7]  R1677     -1
    f[32,189,7]  R1755     1
    f[32,189,7]  marginal_33_7  1
    f[32,190,6]  R1678     -1
    f[32,190,6]  R1755     1
    f[32,190,6]  marginal_33_6  1
    f[32,190,7]  R1678     -1
    f[32,190,7]  R1756     1
    f[32,190,7]  marginal_33_7  1
    f[32,191,6]  R1679     -1
    f[32,191,6]  R1756     1
    f[32,191,6]  marginal_33_6  1
    f[32,191,7]  R1679     -1
    f[32,191,7]  R1757     1
    f[32,191,7]  marginal_33_7  1
    f[32,192,6]  R1680     -1
    f[32,192,6]  R1757     1
    f[32,192,6]  marginal_33_6  1
    f[32,192,7]  R1680     -1
    f[32,192,7]  R1758     1
    f[32,192,7]  marginal_33_7  1
    f[32,193,6]  R1681     -1
    f[32,193,6]  R1758     1
    f[32,193,6]  marginal_33_6  1
    f[32,193,7]  R1681     -1
    f[32,193,7]  R1759     1
    f[32,193,7]  marginal_33_7  1
    f[32,194,6]  R1682     -1
    f[32,194,6]  R1759     1
    f[32,194,6]  marginal_33_6  1
    f[32,194,7]  R1682     -1
    f[32,194,7]  R1760     1
    f[32,194,7]  marginal_33_7  1
    f[32,195,6]  R1683     -1
    f[32,195,6]  R1760     1
    f[32,195,6]  marginal_33_6  1
    f[32,195,7]  R1683     -1
    f[32,195,7]  R1761     1
    f[32,195,7]  marginal_33_7  1
    f[32,196,6]  R1684     -1
    f[32,196,6]  R1761     1
    f[32,196,6]  marginal_33_6  1
    f[32,196,7]  R1684     -1
    f[32,196,7]  R1762     1
    f[32,196,7]  marginal_33_7  1
    f[32,197,6]  R1685     -1
    f[32,197,6]  R1762     1
    f[32,197,6]  marginal_33_6  1
    f[32,197,7]  R1685     -1
    f[32,197,7]  R1763     1
    f[32,197,7]  marginal_33_7  1
    f[32,198,6]  R1686     -1
    f[32,198,6]  R1763     1
    f[32,198,6]  marginal_33_6  1
    f[32,198,7]  R1686     -1
    f[32,198,7]  R1764     1
    f[32,198,7]  marginal_33_7  1
    f[32,199,6]  R1687     -1
    f[32,199,6]  R1764     1
    f[32,199,6]  marginal_33_6  1
    f[32,199,7]  R1687     -1
    f[32,199,7]  R1765     1
    f[32,199,7]  marginal_33_7  1
    f[32,200,6]  R1688     -1
    f[32,200,6]  R1765     1
    f[32,200,6]  marginal_33_6  1
    f[33,130,1]  R1689     -1
    f[33,130,1]  R1766     1
    f[33,130,1]  marginal_34_1  1
    f[33,130,5]  R1689     -1
    f[33,130,5]  R1770     1
    f[33,130,5]  marginal_34_5  1
    f[33,131,1]  R1690     -1
    f[33,131,1]  R1767     1
    f[33,131,1]  marginal_34_1  1
    f[33,131,5]  R1690     -1
    f[33,131,5]  R1771     1
    f[33,131,5]  marginal_34_5  1
    f[33,132,1]  R1691     -1
    f[33,132,1]  R1768     1
    f[33,132,1]  marginal_34_1  1
    f[33,132,5]  R1691     -1
    f[33,132,5]  R1772     1
    f[33,132,5]  marginal_34_5  1
    f[33,133,1]  R1692     -1
    f[33,133,1]  R1769     1
    f[33,133,1]  marginal_34_1  1
    f[33,133,5]  R1692     -1
    f[33,133,5]  R1773     1
    f[33,133,5]  marginal_34_5  1
    f[33,134,1]  R1693     -1
    f[33,134,1]  R1770     1
    f[33,134,1]  marginal_34_1  1
    f[33,134,5]  R1693     -1
    f[33,134,5]  R1774     1
    f[33,134,5]  marginal_34_5  1
    f[33,135,1]  R1694     -1
    f[33,135,1]  R1771     1
    f[33,135,1]  marginal_34_1  1
    f[33,135,5]  R1694     -1
    f[33,135,5]  R1775     1
    f[33,135,5]  marginal_34_5  1
    f[33,136,1]  R1695     -1
    f[33,136,1]  R1772     1
    f[33,136,1]  marginal_34_1  1
    f[33,136,5]  R1695     -1
    f[33,136,5]  R1776     1
    f[33,136,5]  marginal_34_5  1
    f[33,137,1]  R1696     -1
    f[33,137,1]  R1773     1
    f[33,137,1]  marginal_34_1  1
    f[33,137,5]  R1696     -1
    f[33,137,5]  R1777     1
    f[33,137,5]  marginal_34_5  1
    f[33,138,1]  R1697     -1
    f[33,138,1]  R1774     1
    f[33,138,1]  marginal_34_1  1
    f[33,138,5]  R1697     -1
    f[33,138,5]  R1778     1
    f[33,138,5]  marginal_34_5  1
    f[33,139,1]  R1698     -1
    f[33,139,1]  R1775     1
    f[33,139,1]  marginal_34_1  1
    f[33,139,5]  R1698     -1
    f[33,139,5]  R1779     1
    f[33,139,5]  marginal_34_5  1
    f[33,140,1]  R1699     -1
    f[33,140,1]  R1776     1
    f[33,140,1]  marginal_34_1  1
    f[33,140,5]  R1699     -1
    f[33,140,5]  R1780     1
    f[33,140,5]  marginal_34_5  1
    f[33,141,1]  R1700     -1
    f[33,141,1]  R1777     1
    f[33,141,1]  marginal_34_1  1
    f[33,141,5]  R1700     -1
    f[33,141,5]  R1781     1
    f[33,141,5]  marginal_34_5  1
    f[33,142,1]  R1701     -1
    f[33,142,1]  R1778     1
    f[33,142,1]  marginal_34_1  1
    f[33,142,5]  R1701     -1
    f[33,142,5]  R1782     1
    f[33,142,5]  marginal_34_5  1
    f[33,143,1]  R1702     -1
    f[33,143,1]  R1779     1
    f[33,143,1]  marginal_34_1  1
    f[33,143,5]  R1702     -1
    f[33,143,5]  R1783     1
    f[33,143,5]  marginal_34_5  1
    f[33,144,1]  R1703     -1
    f[33,144,1]  R1780     1
    f[33,144,1]  marginal_34_1  1
    f[33,144,5]  R1703     -1
    f[33,144,5]  R1784     1
    f[33,144,5]  marginal_34_5  1
    f[33,145,1]  R1704     -1
    f[33,145,1]  R1781     1
    f[33,145,1]  marginal_34_1  1
    f[33,145,5]  R1704     -1
    f[33,145,5]  R1785     1
    f[33,145,5]  marginal_34_5  1
    f[33,146,1]  R1705     -1
    f[33,146,1]  R1782     1
    f[33,146,1]  marginal_34_1  1
    f[33,146,5]  R1705     -1
    f[33,146,5]  R1786     1
    f[33,146,5]  marginal_34_5  1
    f[33,147,1]  R1706     -1
    f[33,147,1]  R1783     1
    f[33,147,1]  marginal_34_1  1
    f[33,147,5]  R1706     -1
    f[33,147,5]  R1787     1
    f[33,147,5]  marginal_34_5  1
    f[33,148,1]  R1707     -1
    f[33,148,1]  R1784     1
    f[33,148,1]  marginal_34_1  1
    f[33,148,5]  R1707     -1
    f[33,148,5]  R1788     1
    f[33,148,5]  marginal_34_5  1
    f[33,149,1]  R1708     -1
    f[33,149,1]  R1785     1
    f[33,149,1]  marginal_34_1  1
    f[33,149,5]  R1708     -1
    f[33,149,5]  R1789     1
    f[33,149,5]  marginal_34_5  1
    f[33,150,1]  R1709     -1
    f[33,150,1]  R1786     1
    f[33,150,1]  marginal_34_1  1
    f[33,150,5]  R1709     -1
    f[33,150,5]  R1790     1
    f[33,150,5]  marginal_34_5  1
    f[33,151,1]  R1710     -1
    f[33,151,1]  R1787     1
    f[33,151,1]  marginal_34_1  1
    f[33,151,5]  R1710     -1
    f[33,151,5]  R1791     1
    f[33,151,5]  marginal_34_5  1
    f[33,152,1]  R1711     -1
    f[33,152,1]  R1788     1
    f[33,152,1]  marginal_34_1  1
    f[33,152,5]  R1711     -1
    f[33,152,5]  R1792     1
    f[33,152,5]  marginal_34_5  1
    f[33,153,1]  R1712     -1
    f[33,153,1]  R1789     1
    f[33,153,1]  marginal_34_1  1
    f[33,153,5]  R1712     -1
    f[33,153,5]  R1793     1
    f[33,153,5]  marginal_34_5  1
    f[33,154,1]  R1713     -1
    f[33,154,1]  R1790     1
    f[33,154,1]  marginal_34_1  1
    f[33,154,5]  R1713     -1
    f[33,154,5]  R1794     1
    f[33,154,5]  marginal_34_5  1
    f[33,155,1]  R1714     -1
    f[33,155,1]  R1791     1
    f[33,155,1]  marginal_34_1  1
    f[33,155,5]  R1714     -1
    f[33,155,5]  R1795     1
    f[33,155,5]  marginal_34_5  1
    f[33,156,1]  R1715     -1
    f[33,156,1]  R1792     1
    f[33,156,1]  marginal_34_1  1
    f[33,156,5]  R1715     -1
    f[33,156,5]  R1796     1
    f[33,156,5]  marginal_34_5  1
    f[33,157,1]  R1716     -1
    f[33,157,1]  R1793     1
    f[33,157,1]  marginal_34_1  1
    f[33,157,5]  R1716     -1
    f[33,157,5]  R1797     1
    f[33,157,5]  marginal_34_5  1
    f[33,158,1]  R1717     -1
    f[33,158,1]  R1794     1
    f[33,158,1]  marginal_34_1  1
    f[33,158,5]  R1717     -1
    f[33,158,5]  R1798     1
    f[33,158,5]  marginal_34_5  1
    f[33,159,1]  R1718     -1
    f[33,159,1]  R1795     1
    f[33,159,1]  marginal_34_1  1
    f[33,159,5]  R1718     -1
    f[33,159,5]  R1799     1
    f[33,159,5]  marginal_34_5  1
    f[33,160,1]  R1719     -1
    f[33,160,1]  R1796     1
    f[33,160,1]  marginal_34_1  1
    f[33,160,5]  R1719     -1
    f[33,160,5]  R1800     1
    f[33,160,5]  marginal_34_5  1
    f[33,161,1]  R1720     -1
    f[33,161,1]  R1797     1
    f[33,161,1]  marginal_34_1  1
    f[33,161,5]  R1720     -1
    f[33,161,5]  R1801     1
    f[33,161,5]  marginal_34_5  1
    f[33,162,1]  R1721     -1
    f[33,162,1]  R1798     1
    f[33,162,1]  marginal_34_1  1
    f[33,162,5]  R1721     -1
    f[33,162,5]  R1802     1
    f[33,162,5]  marginal_34_5  1
    f[33,163,1]  R1722     -1
    f[33,163,1]  R1799     1
    f[33,163,1]  marginal_34_1  1
    f[33,163,5]  R1722     -1
    f[33,163,5]  R1803     1
    f[33,163,5]  marginal_34_5  1
    f[33,164,1]  R1723     -1
    f[33,164,1]  R1800     1
    f[33,164,1]  marginal_34_1  1
    f[33,164,5]  R1723     -1
    f[33,164,5]  R1804     1
    f[33,164,5]  marginal_34_5  1
    f[33,165,1]  R1724     -1
    f[33,165,1]  R1801     1
    f[33,165,1]  marginal_34_1  1
    f[33,165,5]  R1724     -1
    f[33,165,5]  R1805     1
    f[33,165,5]  marginal_34_5  1
    f[33,166,1]  R1725     -1
    f[33,166,1]  R1802     1
    f[33,166,1]  marginal_34_1  1
    f[33,166,5]  R1725     -1
    f[33,166,5]  R1806     1
    f[33,166,5]  marginal_34_5  1
    f[33,167,1]  R1726     -1
    f[33,167,1]  R1803     1
    f[33,167,1]  marginal_34_1  1
    f[33,167,5]  R1726     -1
    f[33,167,5]  R1807     1
    f[33,167,5]  marginal_34_5  1
    f[33,168,1]  R1727     -1
    f[33,168,1]  R1804     1
    f[33,168,1]  marginal_34_1  1
    f[33,168,5]  R1727     -1
    f[33,168,5]  R1808     1
    f[33,168,5]  marginal_34_5  1
    f[33,169,1]  R1728     -1
    f[33,169,1]  R1805     1
    f[33,169,1]  marginal_34_1  1
    f[33,169,5]  R1728     -1
    f[33,169,5]  R1809     1
    f[33,169,5]  marginal_34_5  1
    f[33,170,1]  R1729     -1
    f[33,170,1]  R1806     1
    f[33,170,1]  marginal_34_1  1
    f[33,170,5]  R1729     -1
    f[33,170,5]  R1810     1
    f[33,170,5]  marginal_34_5  1
    f[33,171,1]  R1730     -1
    f[33,171,1]  R1807     1
    f[33,171,1]  marginal_34_1  1
    f[33,171,5]  R1730     -1
    f[33,171,5]  R1811     1
    f[33,171,5]  marginal_34_5  1
    f[33,172,1]  R1731     -1
    f[33,172,1]  R1808     1
    f[33,172,1]  marginal_34_1  1
    f[33,172,5]  R1731     -1
    f[33,172,5]  R1812     1
    f[33,172,5]  marginal_34_5  1
    f[33,173,1]  R1732     -1
    f[33,173,1]  R1809     1
    f[33,173,1]  marginal_34_1  1
    f[33,173,5]  R1732     -1
    f[33,173,5]  R1813     1
    f[33,173,5]  marginal_34_5  1
    f[33,174,1]  R1733     -1
    f[33,174,1]  R1810     1
    f[33,174,1]  marginal_34_1  1
    f[33,174,5]  R1733     -1
    f[33,174,5]  R1814     1
    f[33,174,5]  marginal_34_5  1
    f[33,175,1]  R1734     -1
    f[33,175,1]  R1811     1
    f[33,175,1]  marginal_34_1  1
    f[33,175,5]  R1734     -1
    f[33,175,5]  R1815     1
    f[33,175,5]  marginal_34_5  1
    f[33,176,1]  R1735     -1
    f[33,176,1]  R1812     1
    f[33,176,1]  marginal_34_1  1
    f[33,176,5]  R1735     -1
    f[33,176,5]  R1816     1
    f[33,176,5]  marginal_34_5  1
    f[33,177,1]  R1736     -1
    f[33,177,1]  R1813     1
    f[33,177,1]  marginal_34_1  1
    f[33,177,5]  R1736     -1
    f[33,177,5]  R1817     1
    f[33,177,5]  marginal_34_5  1
    f[33,178,1]  R1737     -1
    f[33,178,1]  R1814     1
    f[33,178,1]  marginal_34_1  1
    f[33,178,5]  R1737     -1
    f[33,178,5]  R1818     1
    f[33,178,5]  marginal_34_5  1
    f[33,179,1]  R1738     -1
    f[33,179,1]  R1815     1
    f[33,179,1]  marginal_34_1  1
    f[33,179,5]  R1738     -1
    f[33,179,5]  R1819     1
    f[33,179,5]  marginal_34_5  1
    f[33,180,1]  R1739     -1
    f[33,180,1]  R1816     1
    f[33,180,1]  marginal_34_1  1
    f[33,180,5]  R1739     -1
    f[33,180,5]  R1820     1
    f[33,180,5]  marginal_34_5  1
    f[33,181,1]  R1740     -1
    f[33,181,1]  R1817     1
    f[33,181,1]  marginal_34_1  1
    f[33,181,5]  R1740     -1
    f[33,181,5]  R1821     1
    f[33,181,5]  marginal_34_5  1
    f[33,182,1]  R1741     -1
    f[33,182,1]  R1818     1
    f[33,182,1]  marginal_34_1  1
    f[33,182,5]  R1741     -1
    f[33,182,5]  R1822     1
    f[33,182,5]  marginal_34_5  1
    f[33,183,1]  R1742     -1
    f[33,183,1]  R1819     1
    f[33,183,1]  marginal_34_1  1
    f[33,183,5]  R1742     -1
    f[33,183,5]  R1823     1
    f[33,183,5]  marginal_34_5  1
    f[33,184,1]  R1743     -1
    f[33,184,1]  R1820     1
    f[33,184,1]  marginal_34_1  1
    f[33,184,5]  R1743     -1
    f[33,184,5]  R1824     1
    f[33,184,5]  marginal_34_5  1
    f[33,185,1]  R1744     -1
    f[33,185,1]  R1821     1
    f[33,185,1]  marginal_34_1  1
    f[33,185,5]  R1744     -1
    f[33,185,5]  R1825     1
    f[33,185,5]  marginal_34_5  1
    f[33,186,1]  R1745     -1
    f[33,186,1]  R1822     1
    f[33,186,1]  marginal_34_1  1
    f[33,186,5]  R1745     -1
    f[33,186,5]  R1826     1
    f[33,186,5]  marginal_34_5  1
    f[33,187,1]  R1746     -1
    f[33,187,1]  R1823     1
    f[33,187,1]  marginal_34_1  1
    f[33,187,5]  R1746     -1
    f[33,187,5]  R1827     1
    f[33,187,5]  marginal_34_5  1
    f[33,188,1]  R1747     -1
    f[33,188,1]  R1824     1
    f[33,188,1]  marginal_34_1  1
    f[33,188,5]  R1747     -1
    f[33,188,5]  R1828     1
    f[33,188,5]  marginal_34_5  1
    f[33,189,1]  R1748     -1
    f[33,189,1]  R1825     1
    f[33,189,1]  marginal_34_1  1
    f[33,189,5]  R1748     -1
    f[33,189,5]  R1829     1
    f[33,189,5]  marginal_34_5  1
    f[33,190,1]  R1749     -1
    f[33,190,1]  R1826     1
    f[33,190,1]  marginal_34_1  1
    f[33,190,5]  R1749     -1
    f[33,190,5]  R1830     1
    f[33,190,5]  marginal_34_5  1
    f[33,191,1]  R1750     -1
    f[33,191,1]  R1827     1
    f[33,191,1]  marginal_34_1  1
    f[33,191,5]  R1750     -1
    f[33,191,5]  R1831     1
    f[33,191,5]  marginal_34_5  1
    f[33,192,1]  R1751     -1
    f[33,192,1]  R1828     1
    f[33,192,1]  marginal_34_1  1
    f[33,192,5]  R1751     -1
    f[33,192,5]  R1832     1
    f[33,192,5]  marginal_34_5  1
    f[33,193,1]  R1752     -1
    f[33,193,1]  R1829     1
    f[33,193,1]  marginal_34_1  1
    f[33,193,5]  R1752     -1
    f[33,193,5]  R1833     1
    f[33,193,5]  marginal_34_5  1
    f[33,194,1]  R1753     -1
    f[33,194,1]  R1830     1
    f[33,194,1]  marginal_34_1  1
    f[33,194,5]  R1753     -1
    f[33,194,5]  R1834     1
    f[33,194,5]  marginal_34_5  1
    f[33,195,1]  R1754     -1
    f[33,195,1]  R1831     1
    f[33,195,1]  marginal_34_1  1
    f[33,195,5]  R1754     -1
    f[33,195,5]  R1835     1
    f[33,195,5]  marginal_34_5  1
    f[33,196,1]  R1755     -1
    f[33,196,1]  R1832     1
    f[33,196,1]  marginal_34_1  1
    f[33,196,5]  R1755     -1
    f[33,196,5]  R1836     1
    f[33,196,5]  marginal_34_5  1
    f[33,197,1]  R1756     -1
    f[33,197,1]  R1833     1
    f[33,197,1]  marginal_34_1  1
    f[33,197,5]  R1756     -1
    f[33,197,5]  R1837     1
    f[33,197,5]  marginal_34_5  1
    f[33,198,1]  R1757     -1
    f[33,198,1]  R1834     1
    f[33,198,1]  marginal_34_1  1
    f[33,198,5]  R1757     -1
    f[33,198,5]  R1838     1
    f[33,198,5]  marginal_34_5  1
    f[33,199,1]  R1758     -1
    f[33,199,1]  R1835     1
    f[33,199,1]  marginal_34_1  1
    f[33,199,5]  R1758     -1
    f[33,199,5]  R1839     1
    f[33,199,5]  marginal_34_5  1
    f[33,200,1]  R1759     -1
    f[33,200,1]  R1836     1
    f[33,200,1]  marginal_34_1  1
    f[33,200,5]  R1759     -1
    f[33,200,5]  R1840     1
    f[33,200,5]  marginal_34_5  1
    f[33,201,1]  R1760     -1
    f[33,201,1]  R1837     1
    f[33,201,1]  marginal_34_1  1
    f[33,201,5]  R1760     -1
    f[33,201,5]  R1841     1
    f[33,201,5]  marginal_34_5  1
    f[33,202,1]  R1761     -1
    f[33,202,1]  R1838     1
    f[33,202,1]  marginal_34_1  1
    f[33,202,5]  R1761     -1
    f[33,202,5]  R1842     1
    f[33,202,5]  marginal_34_5  1
    f[33,203,1]  R1762     -1
    f[33,203,1]  R1839     1
    f[33,203,1]  marginal_34_1  1
    f[33,204,1]  R1763     -1
    f[33,204,1]  R1840     1
    f[33,204,1]  marginal_34_1  1
    f[33,205,1]  R1764     -1
    f[33,205,1]  R1841     1
    f[33,205,1]  marginal_34_1  1
    f[33,206,1]  R1765     -1
    f[33,206,1]  R1842     1
    f[33,206,1]  marginal_34_1  1
    f[34,131,8]  R1766     -1
    f[34,131,8]  marginal_35_8  1
    f[34,132,4]  R1767     -1
    f[34,132,4]  marginal_35_4  1
    f[34,132,8]  R1767     -1
    f[34,132,8]  marginal_35_8  1
    f[34,133,4]  R1768     -1
    f[34,133,4]  marginal_35_4  1
    f[34,133,8]  R1768     -1
    f[34,133,8]  marginal_35_8  1
    f[34,134,4]  R1769     -1
    f[34,134,4]  marginal_35_4  1
    f[34,134,8]  R1769     -1
    f[34,134,8]  marginal_35_8  1
    f[34,135,4]  R1770     -1
    f[34,135,4]  marginal_35_4  1
    f[34,135,8]  R1770     -1
    f[34,135,8]  marginal_35_8  1
    f[34,136,4]  R1771     -1
    f[34,136,4]  marginal_35_4  1
    f[34,136,8]  R1771     -1
    f[34,136,8]  marginal_35_8  1
    f[34,137,4]  R1772     -1
    f[34,137,4]  marginal_35_4  1
    f[34,137,8]  R1772     -1
    f[34,137,8]  marginal_35_8  1
    f[34,138,4]  R1773     -1
    f[34,138,4]  marginal_35_4  1
    f[34,138,8]  R1773     -1
    f[34,138,8]  marginal_35_8  1
    f[34,139,4]  R1774     -1
    f[34,139,4]  marginal_35_4  1
    f[34,139,8]  R1774     -1
    f[34,139,8]  marginal_35_8  1
    f[34,140,4]  R1775     -1
    f[34,140,4]  marginal_35_4  1
    f[34,140,8]  R1775     -1
    f[34,140,8]  marginal_35_8  1
    f[34,141,4]  R1776     -1
    f[34,141,4]  marginal_35_4  1
    f[34,141,8]  R1776     -1
    f[34,141,8]  marginal_35_8  1
    f[34,142,4]  R1777     -1
    f[34,142,4]  marginal_35_4  1
    f[34,142,8]  R1777     -1
    f[34,142,8]  marginal_35_8  1
    f[34,143,4]  R1778     -1
    f[34,143,4]  marginal_35_4  1
    f[34,143,8]  R1778     -1
    f[34,143,8]  marginal_35_8  1
    f[34,144,4]  R1779     -1
    f[34,144,4]  marginal_35_4  1
    f[34,144,8]  R1779     -1
    f[34,144,8]  marginal_35_8  1
    f[34,145,4]  R1780     -1
    f[34,145,4]  marginal_35_4  1
    f[34,145,8]  R1780     -1
    f[34,145,8]  marginal_35_8  1
    f[34,146,4]  R1781     -1
    f[34,146,4]  marginal_35_4  1
    f[34,146,8]  R1781     -1
    f[34,146,8]  marginal_35_8  1
    f[34,147,4]  R1782     -1
    f[34,147,4]  marginal_35_4  1
    f[34,147,8]  R1782     -1
    f[34,147,8]  marginal_35_8  1
    f[34,148,4]  R1783     -1
    f[34,148,4]  marginal_35_4  1
    f[34,148,8]  R1783     -1
    f[34,148,8]  marginal_35_8  1
    f[34,149,4]  R1784     -1
    f[34,149,4]  marginal_35_4  1
    f[34,149,8]  R1784     -1
    f[34,149,8]  marginal_35_8  1
    f[34,150,4]  R1785     -1
    f[34,150,4]  marginal_35_4  1
    f[34,150,8]  R1785     -1
    f[34,150,8]  marginal_35_8  1
    f[34,151,4]  R1786     -1
    f[34,151,4]  marginal_35_4  1
    f[34,151,8]  R1786     -1
    f[34,151,8]  marginal_35_8  1
    f[34,152,4]  R1787     -1
    f[34,152,4]  marginal_35_4  1
    f[34,152,8]  R1787     -1
    f[34,152,8]  marginal_35_8  1
    f[34,153,4]  R1788     -1
    f[34,153,4]  marginal_35_4  1
    f[34,153,8]  R1788     -1
    f[34,153,8]  marginal_35_8  1
    f[34,154,4]  R1789     -1
    f[34,154,4]  marginal_35_4  1
    f[34,154,8]  R1789     -1
    f[34,154,8]  marginal_35_8  1
    f[34,155,4]  R1790     -1
    f[34,155,4]  marginal_35_4  1
    f[34,155,8]  R1790     -1
    f[34,155,8]  marginal_35_8  1
    f[34,156,4]  R1791     -1
    f[34,156,4]  marginal_35_4  1
    f[34,156,8]  R1791     -1
    f[34,156,8]  marginal_35_8  1
    f[34,157,4]  R1792     -1
    f[34,157,4]  marginal_35_4  1
    f[34,157,8]  R1792     -1
    f[34,157,8]  marginal_35_8  1
    f[34,158,4]  R1793     -1
    f[34,158,4]  marginal_35_4  1
    f[34,158,8]  R1793     -1
    f[34,158,8]  marginal_35_8  1
    f[34,159,4]  R1794     -1
    f[34,159,4]  marginal_35_4  1
    f[34,159,8]  R1794     -1
    f[34,159,8]  marginal_35_8  1
    f[34,160,4]  R1795     -1
    f[34,160,4]  marginal_35_4  1
    f[34,160,8]  R1795     -1
    f[34,160,8]  marginal_35_8  1
    f[34,161,4]  R1796     -1
    f[34,161,4]  marginal_35_4  1
    f[34,161,8]  R1796     -1
    f[34,161,8]  marginal_35_8  1
    f[34,162,4]  R1797     -1
    f[34,162,4]  marginal_35_4  1
    f[34,162,8]  R1797     -1
    f[34,162,8]  marginal_35_8  1
    f[34,163,4]  R1798     -1
    f[34,163,4]  marginal_35_4  1
    f[34,163,8]  R1798     -1
    f[34,163,8]  marginal_35_8  1
    f[34,164,4]  R1799     -1
    f[34,164,4]  marginal_35_4  1
    f[34,164,8]  R1799     -1
    f[34,164,8]  marginal_35_8  1
    f[34,165,4]  R1800     -1
    f[34,165,4]  marginal_35_4  1
    f[34,165,8]  R1800     -1
    f[34,165,8]  marginal_35_8  1
    f[34,166,4]  R1801     -1
    f[34,166,4]  marginal_35_4  1
    f[34,166,8]  R1801     -1
    f[34,166,8]  marginal_35_8  1
    f[34,167,4]  R1802     -1
    f[34,167,4]  marginal_35_4  1
    f[34,167,8]  R1802     -1
    f[34,167,8]  marginal_35_8  1
    f[34,168,4]  R1803     -1
    f[34,168,4]  marginal_35_4  1
    f[34,168,8]  R1803     -1
    f[34,168,8]  marginal_35_8  1
    f[34,169,4]  R1804     -1
    f[34,169,4]  marginal_35_4  1
    f[34,169,8]  R1804     -1
    f[34,169,8]  marginal_35_8  1
    f[34,170,4]  R1805     -1
    f[34,170,4]  marginal_35_4  1
    f[34,170,8]  R1805     -1
    f[34,170,8]  marginal_35_8  1
    f[34,171,4]  R1806     -1
    f[34,171,4]  marginal_35_4  1
    f[34,171,8]  R1806     -1
    f[34,171,8]  marginal_35_8  1
    f[34,172,4]  R1807     -1
    f[34,172,4]  marginal_35_4  1
    f[34,172,8]  R1807     -1
    f[34,172,8]  marginal_35_8  1
    f[34,173,4]  R1808     -1
    f[34,173,4]  marginal_35_4  1
    f[34,173,8]  R1808     -1
    f[34,173,8]  marginal_35_8  1
    f[34,174,4]  R1809     -1
    f[34,174,4]  marginal_35_4  1
    f[34,174,8]  R1809     -1
    f[34,174,8]  marginal_35_8  1
    f[34,175,4]  R1810     -1
    f[34,175,4]  marginal_35_4  1
    f[34,175,8]  R1810     -1
    f[34,175,8]  marginal_35_8  1
    f[34,176,4]  R1811     -1
    f[34,176,4]  marginal_35_4  1
    f[34,176,8]  R1811     -1
    f[34,176,8]  marginal_35_8  1
    f[34,177,4]  R1812     -1
    f[34,177,4]  marginal_35_4  1
    f[34,177,8]  R1812     -1
    f[34,177,8]  marginal_35_8  1
    f[34,178,4]  R1813     -1
    f[34,178,4]  marginal_35_4  1
    f[34,178,8]  R1813     -1
    f[34,178,8]  marginal_35_8  1
    f[34,179,4]  R1814     -1
    f[34,179,4]  marginal_35_4  1
    f[34,179,8]  R1814     -1
    f[34,179,8]  marginal_35_8  1
    f[34,180,4]  R1815     -1
    f[34,180,4]  marginal_35_4  1
    f[34,180,8]  R1815     -1
    f[34,180,8]  marginal_35_8  1
    f[34,181,4]  R1816     -1
    f[34,181,4]  marginal_35_4  1
    f[34,181,8]  R1816     -1
    f[34,181,8]  marginal_35_8  1
    f[34,182,4]  R1817     -1
    f[34,182,4]  marginal_35_4  1
    f[34,182,8]  R1817     -1
    f[34,182,8]  marginal_35_8  1
    f[34,183,4]  R1818     -1
    f[34,183,4]  marginal_35_4  1
    f[34,183,8]  R1818     -1
    f[34,183,8]  marginal_35_8  1
    f[34,184,4]  R1819     -1
    f[34,184,4]  marginal_35_4  1
    f[34,184,8]  R1819     -1
    f[34,184,8]  marginal_35_8  1
    f[34,185,4]  R1820     -1
    f[34,185,4]  marginal_35_4  1
    f[34,185,8]  R1820     -1
    f[34,185,8]  marginal_35_8  1
    f[34,186,4]  R1821     -1
    f[34,186,4]  marginal_35_4  1
    f[34,186,8]  R1821     -1
    f[34,186,8]  marginal_35_8  1
    f[34,187,4]  R1822     -1
    f[34,187,4]  marginal_35_4  1
    f[34,187,8]  R1822     -1
    f[34,187,8]  marginal_35_8  1
    f[34,188,4]  R1823     -1
    f[34,188,4]  marginal_35_4  1
    f[34,188,8]  R1823     -1
    f[34,188,8]  marginal_35_8  1
    f[34,189,4]  R1824     -1
    f[34,189,4]  marginal_35_4  1
    f[34,189,8]  R1824     -1
    f[34,189,8]  marginal_35_8  1
    f[34,190,4]  R1825     -1
    f[34,190,4]  marginal_35_4  1
    f[34,190,8]  R1825     -1
    f[34,190,8]  marginal_35_8  1
    f[34,191,4]  R1826     -1
    f[34,191,4]  marginal_35_4  1
    f[34,191,8]  R1826     -1
    f[34,191,8]  marginal_35_8  1
    f[34,192,4]  R1827     -1
    f[34,192,4]  marginal_35_4  1
    f[34,192,8]  R1827     -1
    f[34,192,8]  marginal_35_8  1
    f[34,193,4]  R1828     -1
    f[34,193,4]  marginal_35_4  1
    f[34,193,8]  R1828     -1
    f[34,193,8]  marginal_35_8  1
    f[34,194,4]  R1829     -1
    f[34,194,4]  marginal_35_4  1
    f[34,194,8]  R1829     -1
    f[34,194,8]  marginal_35_8  1
    f[34,195,4]  R1830     -1
    f[34,195,4]  marginal_35_4  1
    f[34,195,8]  R1830     -1
    f[34,195,8]  marginal_35_8  1
    f[34,196,4]  R1831     -1
    f[34,196,4]  marginal_35_4  1
    f[34,196,8]  R1831     -1
    f[34,196,8]  marginal_35_8  1
    f[34,197,4]  R1832     -1
    f[34,197,4]  marginal_35_4  1
    f[34,197,8]  R1832     -1
    f[34,197,8]  marginal_35_8  1
    f[34,198,4]  R1833     -1
    f[34,198,4]  marginal_35_4  1
    f[34,198,8]  R1833     -1
    f[34,198,8]  marginal_35_8  1
    f[34,199,4]  R1834     -1
    f[34,199,4]  marginal_35_4  1
    f[34,199,8]  R1834     -1
    f[34,199,8]  marginal_35_8  1
    f[34,200,4]  R1835     -1
    f[34,200,4]  marginal_35_4  1
    f[34,200,8]  R1835     -1
    f[34,200,8]  marginal_35_8  1
    f[34,201,4]  R1836     -1
    f[34,201,4]  marginal_35_4  1
    f[34,201,8]  R1836     -1
    f[34,201,8]  marginal_35_8  1
    f[34,202,4]  R1837     -1
    f[34,202,4]  marginal_35_4  1
    f[34,202,8]  R1837     -1
    f[34,202,8]  marginal_35_8  1
    f[34,203,4]  R1838     -1
    f[34,203,4]  marginal_35_4  1
    f[34,203,8]  R1838     -1
    f[34,203,8]  marginal_35_8  1
    f[34,204,4]  R1839     -1
    f[34,204,4]  marginal_35_4  1
    f[34,205,4]  R1840     -1
    f[34,205,4]  marginal_35_4  1
    f[34,206,4]  R1841     -1
    f[34,206,4]  marginal_35_4  1
    f[34,207,4]  R1842     -1
    f[34,207,4]  marginal_35_4  1
RHS
    RHS1      R0        1
    RHS1      marginal_1_2  2.3577480013138991e-02
    RHS1      marginal_1_8  5.9591334901644011e-01
    RHS1      marginal_1_10  3.8050917097042092e-01
    RHS1      marginal_2_6  9.6631257669659387e-01
    RHS1      marginal_2_7  3.3687423303406128e-02
    RHS1      marginal_3_6  1.0435723051039414e-01
    RHS1      marginal_3_7  8.9564276948960586e-01
    RHS1      marginal_4_6  9.6631257669659476e-01
    RHS1      marginal_4_7  3.3687423303405239e-02
    RHS1      marginal_5_2  0.0854774977875351
    RHS1      marginal_5_4  1.4787306094629565e-01
    RHS1      marginal_5_8  7.6664944126616930e-01
    RHS1      marginal_6_1  2.4810003791506871e-01
    RHS1      marginal_6_5  7.5189996208493137e-01
    RHS1      marginal_7_5  3.6811907683679762e-01
    RHS1      marginal_7_8  6.3188092316320232e-01
    RHS1      marginal_8_5  2.3577480013138991e-02
    RHS1      marginal_8_7  1.2321408376449954e-01
    RHS1      marginal_8_10  8.5320843622236153e-01
    RHS1      marginal_9_3  0.345111634534498
    RHS1      marginal_9_5  0.654888365465502
    RHS1      marginal_10_5  2.3577480013138991e-02
    RHS1      marginal_10_6  3.1563978451807406e-01
    RHS1      marginal_10_10  0.660782735468787
    RHS1      marginal_11_2  2.3007442302299855e-01
    RHS1      marginal_11_5  7.6992557697700148e-01
    RHS1      marginal_12_4  3.2210419223219794e-01
    RHS1      marginal_12_7  6.7789580776780212e-01
    RHS1      marginal_13_4  4.2644903507844077e-02
    RHS1      marginal_13_7  9.3377761647901691e-01
    RHS1      marginal_13_8  2.3577480013138991e-02
    RHS1      marginal_14_2  1.8405953841839909e-01
    RHS1      marginal_14_8  8.1594046158160083e-01
    RHS1      marginal_15_3  4.8480376864838526e-02
    RHS1      marginal_15_8  9.5151962313516147e-01
    RHS1      marginal_16_3  2.7608930762759815e-01
    RHS1      marginal_16_6  7.2391069237240191e-01
    RHS1      marginal_17_7  6.2120094216209631e-01
    RHS1      marginal_17_9  3.7879905783790363e-01
    RHS1      marginal_18_5  2.3577480013138991e-02
    RHS1      marginal_18_6  3.8269732142387891e-01
    RHS1      marginal_18_9  5.9372519856298211e-01
    RHS1      marginal_19_2  3.9696006066410994e-01
    RHS1      marginal_19_4  6.0303993933589006e-01
    RHS1      marginal_20_3  2.7608930762759815e-01
    RHS1      marginal_20_6  7.2391069237240191e-01
    RHS1      marginal_21_1  4.3864200792997909e-05
    RHS1      marginal_21_4  3.4698015101878421e-02
    RHS1      marginal_21_7  9.6525812069732864e-01
    RHS1      marginal_22_5  8.2826792288279449e-01
    RHS1      marginal_22_6  1.7173207711720551e-01
    RHS1      marginal_23_3  0.0159776316734135
    RHS1      marginal_23_4  9.6044488831344754e-01
    RHS1      marginal_23_5  2.3577480013138991e-02
    RHS1      marginal_24_4  4.2644903507844077e-02
    RHS1      marginal_24_7  9.3377761647901691e-01
    RHS1      marginal_24_8  2.3577480013138991e-02
    RHS1      marginal_25_6  9.6631257669659387e-01
    RHS1      marginal_25_7  3.3687423303406128e-02
    RHS1      marginal_26_3  7.9392012132821987e-01
    RHS1      marginal_26_4  2.0607987867178013e-01
    RHS1      marginal_27_6  0.966312576696593
    RHS1      marginal_27_7  3.3687423303407016e-02
    RHS1      marginal_28_6  5.5217861525519663e-01
    RHS1      marginal_28_8  4.4782138474480337e-01
    RHS1      marginal_29_6  5.5217861525519663e-01
    RHS1      marginal_29_8  4.4782138474480337e-01
    RHS1      marginal_30_3  7.9392012132821987e-01
    RHS1      marginal_30_4  2.0607987867178013e-01
    RHS1      marginal_31_2  1.9326251533931876e-01
    RHS1      marginal_31_7  8.0673748466068118e-01
    RHS1      marginal_32_3  4.9620007583013725e-01
    RHS1      marginal_32_5  5.0379992416986275e-01
    RHS1      marginal_33_6  9.6631257669659376e-01
    RHS1      marginal_33_7  3.3687423303406239e-02
    RHS1      marginal_34_1  2.4810003791506871e-01
    RHS1      marginal_34_5  7.5189996208493137e-01
    RHS1      marginal_35_4  2.7608930762759831e-01
    RHS1      marginal_35_8  7.2391069237240169e-01
BOUNDS
ENDATA
