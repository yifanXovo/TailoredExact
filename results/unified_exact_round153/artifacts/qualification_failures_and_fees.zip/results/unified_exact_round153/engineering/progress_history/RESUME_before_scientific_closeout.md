# Round153 live handoff — 2026-11-04 05:01 UTC

The entire user-adopted /goal remains active and incomplete. Follow goal.md, WORKSPACE_POLICY.md and the immutable fee records. New experiment capacity is 115200 seconds; every new experiment/necessary verification is serial and metered via round153_common.py. Build and writing/public I/O are separate. Protect E:/codes/ExactEBRP. All new assets remain under E:/codes/ExactEBRP-work. No destructive cleanup is needed.

Branch codex/round153-coupled-objective-hull starts at verified R152 ed058861e5eb094bc22d468a71a791bf558b51ac. Commits 78e19d8e6 and 36d085cc7012690b8ab38d7ace70f487f54aec7e exist locally, not pushed. Intended PR base is verified unmerged R152 branch; recheck actual main absorption and PR214 before delivery. Stable R137 entry/profile unchanged.

References are complete for all three domains: both NC and TS1-4, old eight/final/floor union, direct-g and free Q. Direct values: NB35 .392978953518639; K35 .278864453932931; NC20 .174769124713578. All three current-Q optima admit common legal inventory distributions under numerical primal policy. This projection witness is not Gamma minimum. Independent Fraction strict fixture checks 169 rows/68 vars and fixed-marginal gap41/1080; it is not a full-routing strict example, and old global-floor gap does not transfer.

NB35 meaningful full-hull interval is CLOSED [.3960430527066062,.39604655895626023], width3.50625e-6. Source coupled/N-B35-S_floor_closed, complete upper witness initial_v2/best_primal.json.gz. One initial owned interruption is preserved and pending pricing has no bound. Targeted floor costs6.8013s. All uppers here are strengthened-LP value uppers, not physical BRP U.

K35 sequence: initial17, AP stabilized27, level/AP6, level/zero9, price_deep5 completed prices; latest deep price cap300 and804columns. Individual corrected L .2814024125183089; free-Q reinstatement of64 supports gives L .2818261599167829; U remains .28749181051555994 and primal qualifications pass. Selected state coupled/K-35-U_support_checkpoint (and identical bounds after saved_direction_bins4). Price intervals .0025--.0035 motivated exhaustive positive-S partition research.

PartitionedOracle (round153_partitioned.py) is research-only; frozen pricing/common untouched. Four-bin small controls passed3965+188 actual row checks, signed/beta0/zero/child-domain brackets. Independent reviewer admitted the fixed saved-direction comparison. K35_saved_direction_bins4_v1 closed277.5027773s: old price[.017981042399616738,.021497885206771004], new[.01494051998711571,.021471812805363297]. Third interval is bottleneck; whole lower did not improve. refined_certificate reuses exact C_Q/aK once, retains stronger old price lower and cumulative bound, adds only true legal stocks. Reviewer verified current source Q/scope; automatic source-plan binding and complete_domain assertions were added afterward for future uses. Coupled mode level_zero_pool_bins4 is available and reviewed, but conditional gate requires useful full-price improvement before using it.

ACTIVE shell session14490, fee NC20_level_zero_deep_01, reservation3900: round153_coupled.py N-C20-U level_zero_deep 3600 120 .00001 true E:/codes/ExactEBRP-work/worktrees/paper-current/results/unified_exact_round153/coupled/N-C20-U_initial level_zero_pool. Independent review admitted this targeted continuation. Initial interval[.17476912471357703,.19083794336522952],157columns. Wait for completion or a reasoned graceful completed-call checkpoint before any other Native/build/heavy I/O. This domain still needs a meaningful endpoint. Do not infer negative from a wide interval.

Last closed experiment sum5450.847844099859 seconds; separate compilation80.10179629991762. Durable fees are authority. No other owned experiment. Full panel NOT STARTED.

Production candidate J is fully compiled and qualified, defaultOFF, same new PE B/J, ownH/current canonical source, cold beta1,d=h, hard-totalDP then Seed0Threads1/NodeLimit4096/original absolute Native gap1e-4. Only global method deadline, no internal time switch. Sole formal row G+sum omega e>=floor; no formal new columns/AP/GD/RN. Actual row/matrix/Start/scope/exit/lifecycle qualification passed; failures retained. Candidate v2 PE E:/codes/ExactEBRP-work/build-cache/round153/v2/ExactEBRP.exe SHA44e593db8e3442925ce7dbd7bc16c077e79ab1646c7507b72541d8e697b996f7. Candidate source commit36d085cc7012690b8ab38d7ace70f487f54aec7e; preliminary build identities retained.

Full matrix frozen and independently ACCEPTED in review/confirmation_admission.json. Matrix SHA d81767d4adfe9ec20a2f5bfcc6cd26450773f2f93fe3231459603c523210374e. Helper manifest SHA24be18f4d03fae8ed8b21d14f2974b761a5e043dbf84f67715ed1ba632647504. Do not edit frozen campaign/common/pricing/read/online/old dependencies. Research coupled/stabilize/partitioned/refine/attribution/audit/reports/delivery are not frozen. Four roles B thenJ: NB35,K35,RB35-T1 each2400/arm; NC20 certificate1200/arm. RB historical lambda .055125275219827186, not .15. Run campaign.py run 8 directly (already meters each arm), not inside common wrapper. No outcome-dependent replacement.

Draft final support tools: round153_reports.py science/complete/costs; audit.py finite exact arithmetic/provenance/three selected Q primal checks, no Optimize; delivery.py current-only zip carriers, fixed public anonymous restore and zero-delete closeout. These are not final-tested yet. Audit now supports hierarchical partition price checks and saved-direction refinements. Manuscript/math/history drafts exist; update final tables and remaining domains/production outcomes.

Remaining: meaningful NC20/K35 targeted endpoints, final free-Q support attribution; all8 admitted complete arms; final candidate_decision, reports/cost/source/reuse indices, math/paper/history/RESUME, finite audit and independent final review; pack only new evidence with fixed old references, normal commit/push English Draft PR/readback, one finite anonymous restore, bounded cleanup record. Do not mark goal complete or end at a research checkpoint.

## Live override — 2026-11-04 05:29 UTC

Prior active session14490 closed normally at a completed-price checkpoint: NC20_level_zero_deep_01 cost798.4992307000794s,7prices,218cols, L.17754649106669154. Same-Q support checkpoint cost8.791848100023344s, L.17755417689205186, U.19083794336522952.
K35_saved_direction_bins16_v1 then closed458.9215760000516s, no improvement (weak central S intervals). K35_paid_partition_overlay_v1 failed0.39205799996852875s on JSON integer/string dictionary key comparison before a claim. Fixed expected s_bounds metadata canonicalization; v2 passed1.9963143998757005s,0Native, combined all prior bounds but same cumulative interval[.2818261599167829,.28749181051555994],1036cols. Select coupled/K-35-U_paid_partition_overlay_v2 as newest K state.

NOW ACTIVE shell session8303, fee NC20_level_zero_continue_01, reservation3000: coupled N-C20-U level_zero_continued 2700 120 .00001 true .../N-C20-U_support_checkpoint level_zero_pool. First completed iteration has L.1794922765112552, U.19083794336522952; do not treat this as final. Last closed G1 sum6719.448871299857s; build80.10179629991762s. Keep this run serial; no Native/build/heavy I/O overlap.

Next K design and interface independently ACCEPTED in review/k35_targeted_deepening_review.md: same original price_deep/iter00003 direction, single S part, Native cap3600 via round153_refine.py (reservation4000+); source prior newest overlay. Its current true-price upper allows only about.283685 corrected lower, still leaves.00381 hull width even if price closes. Then consider/research near-optimal zero_pool mode,7200outer/300price/1e-4, from all new columns/bounds. Coupled zero_pool now verified: stabilize=true,level=false,all_pool=true,centerzero,ordinary monolithic Oracle,band=min(1e-7,tol/10); SHA7bdb6eb0957f4f9571a0d728ad07e30f055e3a301d0952e7310fc9ce509ee6c9. Frozen production helpers unchanged. No new small Native qualification required.

New overlay script audits all source parent/child arithmetic and SHA before 0Native common-refinement lower merge. Handles point/zero domains and uses same C_Q/aK once. Auditor now checks DP/S, actual written MPS objective coefficient transport, statuses/returns, beta/d/pi/Q/SHA chains, and acyclic overlay provenance. Reports distinguish descriptive controller-recorded trajectories from qualified endpoints; common-target trace times are not individually qualified or T_cert. Final execution of these audits/report scripts still pending. Entry dry-launch checker authored, not run. New docs/round153_research.md and paper_review reading-order link are draft/current-status, need final outcome update.

## Live override — 2026-11-04 06:02 UTC

All earlier active jobs have closed. NC20_level_zero_continue_01 ended at a
completed-price checkpoint after 9 prices, 1132.2917793998495 seconds,
278 columns and interval [.1794922765112552,.1906059418573794]. This remains
unresolved. Entry dry-check entry_v1 passed, 8 launch vectors, fee1.2032523s.

The new research-only normalized CDF extension reuses R88 mathematics and
retains every original price constraint. Small qualification transport_v1
PASS, fee .3882578s, 3 Native calls, 49-positive and mixed-zero controls.
Independent review admitted two probes. NC20 iter00008/120s gives the worse
price lower -.035067987203901786, outer123.9079813s; K35 iter00003/300s gives
the worse price lower .013152182179157394, outer305.5870648s. Both retain
the old valid lowers; neither justifies a coupled or production CDF switch.
Latest closed states are coupled/N-C20-U_saved_direction_transport and
coupled/K-35-U_saved_direction_transport. Full-hull bounds remain NC20 above
and K35 [.2818261599167829,.28749181051555994],1036 columns.

ACTIVE shell session80308, K35_saved_direction_long_v1, reservation4100:
round153_refine.py K-35-U saved_direction_long
results/unified_exact_round153/coupled/K-35-U_saved_direction_transport
results/unified_exact_round153/coupled/K-35-U_price_deep/iter00003 3600 1 partition.
Started about05:56 UTC. Do not start another timed job, compile or heavy I/O.
Last closed G1 total8282.827206899412 seconds; builds80.10179629991762s.

After this closes: independently admitted K35 zero_pool continuation
7200outer/300price/1e-4 from all new evidence. NC20 reviewer admitted same
saved iter00008 single-range1800s price followed by zero_pool5400/300/1e-5.
No Native requalification needed for these reviewed existing interfaces.
Then final same-Q support_close for both roles and complete the frozen8-arm
campaign (not started), final reports/audits/review and Draft PR delivery.

Audit.py is being strengthened by static review: exact replay of original-Q
finite bound derivations, independent every-iteration C_Q and true minK/aK,
selected free-Q support LP lower/primal and final lower-source binding.
It will use6 model reads,0Optimize in the final metered audit. Not yet run.
Docs current_mainline/research_index now link R153 as current research;
all final decisions and outcome tables still need completion. Nothing in
the frozen production source/helper/matrix chain was edited.

## Live override — 2026-11-04 06:42 UTC

The same session80308 / K35_saved_direction_long_v1 is still active,
approximately2700/3600 Native seconds completed. No new experiment has
run concurrently. The ledger remains8282.827206899412 closed G1 seconds
plus this pending outer receipt; builds remain80.10179629991762seconds.

New research-only scripts/round153_graphcut.py is written and statically
reviewed, but NOT executed or qualified. Accepted source SHA is
6cb2fa990c259e15d5faf696c4626f1c86165dbef55489de3ab9a72f3ca986c4.
Review: review/cut_pricing_design_review.md. It derives valid positive-S
slice lower bounds by Lagrangian relaxation of hard totals/S/Gupper and
exact integer-flow minimization of ordered-label absolute differences.
All states remain; relaxed label vectors are not stock uppers. Signed
floor rounding at2^40, full capacity/conservation checks and flow=cut
prove the lower. Candidate LP objectives only select multipliers.
R88 CDF and R54/R63 historical min-cut uses are explicitly acknowledged.

After the current long price closes, next admitted command is:
PY -B scripts/round153_common.py graphcut_qualification_v1 600 round153_graphcut.py qualify graphcut_v1
where PY is E:/codes/ExactEBRP/build/research/round88-ot/venv/Scripts/python.exe.
The qualifier covers all Cartesian label energies, beta0/positive,
signed p/r and eta, fixed/holed states, zero, and three rejected bad flows.
If same-source PASS, admitted probes use round153_refine.py implementation
graphcut,parts16,cap600, outer900 or1200 each: NC20 original
level_zero_continued/iter00008 from saved_direction_transport; K35 original
price_deep/iter00003 from the newly completed saved_direction_long.
Use distinct labels saved_direction_graphcut. Preserve stronger old bounds
and all legal stocks. These do not replace the admitted NC20 single-range
1800s price or K35/NC20 zero_pool7200/5400s studies. No automatic coupled
factory or production switch is admitted by a small qualification alone.

Final audit.py now independently replays original-Q bound derivations,
each C_Q and true prefix minK/aK, reference/direct lower, final all-support
dual/primal, and matching old support duals zero-extended onto that current
matrix. Every ordinary price now binds full scope and d=-pi. Six Native
model reads,0Optimize. A graph-only audit branch checks exact flows and
candidate LP call/model/return identity; ordinary no-Native=DP rules remain.
All are source-reviewed but final audit has NOT executed. Graph qualification
and probe output checks will be metered before any use.

New round153_finalize.py runs audit+science/research/complete tables+frozen
source identities under one common outer receipt; cost report runs only
after that receipt closes. Source snapshot inventory explicitly records
which fees have snapshots and does not claim universal coverage. Reports
separate candidate-selection LP calls from full-price Native calls, and
actual measured candidate source from the inherited endpoint base commit.
All frozen production files remain unchanged. final_report.md is explicitly
a working report; final result tables, decision, full panel, final review,
pack/public PR/recovery/zero-delete closeout remain outstanding.

## Live override — after the 06:57 UTC queue transition

K35_saved_direction_long_v1 CLOSED cleanly, outer3601.784241599962s,
621815nodes. Price[.020410302194370473,.021471812805363297] raises Gamma L
to.2826236515522649; U.28749181051555994, width.004868158963295066.
Session80308 has ended.

ACTIVE supervisor shell session20037 runs scripts/round153_followthrough.py.
The queue is independently admitted in review/followthrough_sequence_review.md.
It is serial and stops on failure. It already completed graphcut qualification
and both admitted graph probes, then started NC20_saved_direction_long_v1
at06:57:15 UTC (1800 Native cap,2200 outer reservation). Do not separately
start any queued child, Native, compile or heavy I/O. Monitor
followthrough_status.json and the current fee/result metadata; the queue
automatically continues to K35 zero_pool7200/300, NC20 zero_pool5400/300,
both deepened_support_envelope free-Q closes, then the frozen eight-arm
campaign. Its end is not a claim that the scientific goal/delivery is done.

Graphcut qualifier PASSED in1.50053820014s:3744 full Cartesian energy checks,
3 altered flows rejected,6 complete-price controls,22 candidate LP calls.
The accepted source remains6cb2fa990c259e15d5faf696c4626f1c86165dbef55489de3ab9a72f3ca986c4.
NC20 graph probe completed16 slices,64 exact flows/64 candidate LPs in
10.837436700007s, price[-.05657158567373699,.00726560247528965], cumulative
Gamma interval unchanged,282 columns. K35 graph probe completed16 slices,
73flows/73LPs in13.800380900037s, price[.010065412826406828,.021471812805363297],
cumulative post-long-price interval unchanged,1043 columns. Both are weaker
attained cut bounds. Keep their legal columns and earlier stronger bounds;
no graph coupled/production adoption. Do not attribute the difference solely
to inevitable relaxation loss: finite denominator/parameter search effects
were not isolated. Independent result/scope readback is in
review/graphcut_probe_readback.md. Last closed G1 total11910.749804299558s;
builds80.10179629991762s. Current NC20 long fee remains additional/pending.

New reproducibility.md documents only-new-carrier recovery, source/version
semantics, numerical policies and the untimed prelaunch metadata/identity
hashing gap. reports.py now explicitly asserts endpoint.source_commit is
the delivery base and separately reports the measured candidate source.
followthrough.py requires clean receipts (exit0, observed, no timeout or
supervisor failure), reserves pending work+16800+validation margins, and
does not nest a campaign fee. All mathematical/production/source guards
remain as reviewed. Final audit/postprocessing/review and all delivery
steps are still pending after the queue finishes and outcomes are assessed.

## Execution update, 2026-11-04 07:28 UTC

NC20 saved-direction long price is now closed: outer648.6849454001058s,
price[.007047380424300334,.007048488148771115], complete-hull lower
.1833218484555365 and upper.1906059418573794. Closed G1 is
12559.434749699663s, builds80.10179629991762s. The registered supervisor
exec session20037 continues K35_near_optimal_zero_pool_v1, started07:08:04
UTC; do not launch queued stages or production separately. Its first three
completed iterations have1043→1073 columns and upper.2874822144241067.
The existing lower.2826236515522649 persists. The ongoing fee is additional.

scripts/round153_primal_pool.py and primal_pool_plan.md are a new CONDITIONAL
upper-only discovery diagnostic, not executed or qualified yet. Independent
static review is requested; qualification and any probes must use common.run
serially after the registered queue. The final audit/reports now have support
for its separately identified evidence. No frozen core/candidate/production
file was changed. Do not mistake this proposed extension for a completed
scientific result or let it interfere with all eight admitted arms.

## Conditional discovery review and monitoring update

Independent review now admits the SAME-SOURCE small discovery qualification:
review/primal_pool_design_review.md. Final primal_pool source SHA is
ef8190f6b6aa12730d4f6ab82658345fbb44d1358f45cfed363b8b59afa95da5.
It includes up to512 single negative columns plus up to64 complementary
one-/two-site exchange pairs (both children retained), at most640 new columns
per sweep. Integer hard totals are screened before pair selection; all new
stocks and strict pair f-sum improvements are checked by Fraction. The
explicit interval targets are K35 .0001 and NC20 .00001. A qualified feasible
upper from a nonoptimal master is retained before stopping. It has NOT been
executed. After queue closure, first run common.run for qualification:
round153_primal_pool.py qualify primal_pool_v1 (reserve300). Conditional
probe CLI is run ROLE primal_pool RESULTS_COUPLED_SOURCE 1200 TOLERANCE;
reserve1600 per role, inspect remaining intervals first. No new lower is
claimed. The mathematical account and primal_pool_plan.md explain scope,
paired marginal identity and R75/R76 historical attribution.

Queue supervisor remains exec20037. Read-only metadata monitor exec33561
uses temp/round153/monitor_queue.py (no Native/import of research runtime,
no mutation of evidence) and exits when the queue closes. Its current
campaign endpoint glob is shallow, so use frozen matrix destinations for
complete endpoint monitoring. K35 has completed iterations0–8,1111 columns,
L .2826236515522649, U .2873261633063073 at elapsed2853.6149231s. Continue
the existing queue; no concurrent experiment/qualification/archive/build.

finalize.py now calls untimed prelaunch source/identity checks a disclosed
measurement gap, not zero-cost pure I/O; independent static addendum accepted.
reports.py additionally binds phase outputs to direct outer launch/receipt
records, preserving raw decisions such as NB initial_v2's RUNNING while
showing its closed nonzero exit. Native call artifacts without a saved
return are separately counted; they imply no bound and no live-process
claim. Static review of that display addition was requested. Final audit,
reports, review, publication and bounded recovery/cleanup remain pending.

## Latest queue transition, 2026-11-04 08:06 UTC

K35_near_optimal_zero_pool_v1 closed exit0/observed true in
3485.355966599891s. Eleven completed prices,1043→1114 columns, final
[.2826236515522649,.2873261633063073], width.004702511754042404.
No new column on the last price; true price upper/intercept both≈.0808703,
but lower.06092685437735434. It remains pricing-unresolved. Closed G1 now
16044.790716299554s (sum final ledger later); builds unchanged80.1017963s.
The SAME supervisor20037 started NC20_near_optimal_zero_pool_v1 at
08:06:09 UTC. Monitor33561 continues. Research support closes and all eight
full arms follow automatically. Do not start any separately.

reports.py phase-receipt display is independently accepted at SHA
7fe0a81824d7848abbdf870acf92e263dca5bcf3661f1a51b703e383471ddc81.
Its per-directory Optimize artifacts explicitly exclude separately stored
support_LP/qualification/inherited records and are not a Native census.
Finalizer explanatory-field correction accepted at SHA
e91eb37e7d4d65b0cc9b1285c62cdea4f57f2d92d1d31e9ba1c118115a2ab2fe.
Conditional primal-pool source and the independent gate remain unchanged.

The metadata monitor is now exec82582, started with the direct ordinary
primary Python runtime. The old R88-venv monitor's observed child PID95508
was stopped after exact command/birth checks; its launcher93196 exited too.
This avoids a false match in the unchanged production foreign-heavy gate.
No Native or experimental process was touched. The updated monitor also
reads complete endpoints at */raw/*/round135_endpoint.json. Queue20037 is
unchanged. New scripts/round153_afterqueue.py is waiting for independent
STATIC review, NOT launched yet; it would wait for the eight-arm queue to
close and then execute only the already reviewed conditional same-source
small qualifier and open-gap primal probes, with fresh budget guards.

## Automatic conditional continuation is now waiting

afterqueue_sequence_review.md ACCEPT_STATIC_AFTERQUEUE_ORCHESTRATION at
source48bb9d6da7553d3595788e4ec09acffe3a3d7aeab3124e456e7145ce803dbc4b.
The wrapper is NOW RUNNING as exec75277 under direct ordinary primary Python,
currently metadata-only WAITING_FOR_REGISTERED_QUEUE. It explicitly rejects
the R88-venv interpreter and any enclosing ROUND140_METERED_PARENT_LABEL.
It automatically waits for queue20037, all8 verified frozen endpoints,
matching matrix, stop_after8 and no unclosed fee. It then tests the actual
two support-envelope intervals and runs the accepted small qualification
and required1200-second primal probes serially through common.run. Do NOT
launch those diagnostic stages manually or perform heavy final I/O when
the first queue closes without first checking afterqueue_status.json.
Final scientific assessment, possible justified additional refinement,
finite final audit, independent review and delivery remain root work.

scripts/round153_figures.py is prepared but NOT executed. After all scientific
work/audit closes and candidate_decision.study_complete is true, it formats
the audited scientific_table.json into figures/coupled_value_intervals.svg
and .png, with outward decimal endpoint labels and explicit LP-only scope.
Use direct primary Python -B. It reuses the existing read-only matplotlib
dependencies at WORK/build-cache/round137/python-packages, with all new font
cache under WORK/temp/round153/matplotlib. No installation or Native is
needed. Its separately reported documentation time goes to figure_creation.json;
view the PNG before delivery and then embed the figure in the final report.
Do not run figure/archive/heavy formatting while a research/complete fee is open.

## Full panel has started, 2026-11-04 09:33 UTC

NC20_near_optimal_zero_pool_v1 closed normally in5203.679151499877s:
17 completed prices,283→427 legal columns, final
[.1833218484555365,.18995680056588546], width.006634952110348952.
The final upper improved; this near-optimal phase did not improve its
inherited long-price lower. Its ordinary offline cap is not a scientific
negative conclusion.

The paid free-Q support envelopes then closed: K35 fee12.962473300052807s,
81 supports, raises lower to.2828596948801647, upper.2873261633063073,
width.004466468426142567,1114 columns. NC20 fee9.119002499850467s,
48 supports, retains the above interval and427 columns. Selected paths for
the conditional probes are coupled/ROLE_deepened_support_envelope; their
support_LP counterparts are valid current free-Q evidence. Closed G1 is now
21270.551343599334s; builds80.10179629991762s. Current complete-arm fees
are additional. Source receipt totals remain the accounting authority.

Supervisor20037 has entered frozen_eight_position_campaign. active_position
is1, fee confirmation_001, arm R153_001_N-B35-S_S0_B. The raw destination
has a process-start marker, own-H artifacts and live Native/progress files;
no error receipt was present. All8 complete arms follow automatically.
Monitor82582 remains read-only. Afterqueue75277 is still metadata-only
waiting and will run its accepted conditional probes after every arm and
verification closes. Do not launch any overlapping computation or heavy I/O.

reports.py now also copies/sums saved price Native Work and nodes, with
candidate-selection LP Work separate and no addition to outer fees. This
small display addition postdates the previous static report hash and should
be included in final source/claim review. Figure formatting remains unrun.

## First sealed complete endpoint and static reporting fixes

Position 1 closed normally with outer fee 2374.3298696998972 seconds:
N-B35-S B has U=.450291503262878, L=.38931060164210607, certificate=false,
T_cert=null, T_produce=2371.4973439250607, T_verify=2.7657256999518722,
T_total=2374.2630696250126. Closed G1 is now 23644.88121329923 seconds.
Position 2, R153_002_N-B35-S_S0_J, started at 2026-11-04T10:12:50 UTC.
The same supervisors remain active: 20037 campaign, 82582 read-only monitor,
75277 metadata wait followed by conditional primal probes. Do not restart
them or launch overlapping computation.

Independent static review now accepts reports.py and figures.py after
two label corrections: H hashes compare semantic traces/canonical fleets,
not raw fleet-file bytes; the plot's horizontal intervals are offsets from
each numerical reference upper, not complete gain intervals. See
review/report_render_static_review.md for accepted source hashes. No table
execution or figure rendering has occurred.

review/post_primal_continuation_design.md gives a conditional research
assessment. In particular, the NC20 old long-price direction is already
nearly closed and cannot substantially improve its fixed CQ/aK certificate.
Latest near-optimal directions still have large uncertain price gaps.
After the primal probes, refresh their feasible price uppers using all new
stocks before choosing any further long price. A fixed-direction ceiling
does not bound z_Gamma or the combined support family.

scripts/round153_direction_screen.py has been written but NOT executed.
It screens four preselected old/latest directions only after afterqueue
is REVIEWED_DIAGNOSTICS_CLOSED, using true feasible stocks and exact
Fraction arithmetic. It needs one common.run receipt (reserve 300 seconds),
not an unmetered direct call. Its output is a candidate screen, with zero
Optimize/Native model reads and no new lower or RMP upper claim; Q bytes
are read for their identity hash. Static review accepted source
d496c7a9e968952b7e0469274c158c32ca03012e3aa8efacaa842edf073eb761
in review/direction_screen_static_review.md. No extra experiment is
automatically registered by this file. Final continuation selection remains
dependent on the actual primal results and this paid screen.

## First complete pair sealed; position 3 active

Position 2 closed normally: N-B35-S J has U=.46039474835411914,
L=.39595640872409654, certificate=false, T_cert=null,
T_produce=2371.372241345467, T_verify=6.677003200165927,
T_total=2378.049244545633. Its fee is 2378.1284487000667 seconds.
J improves the supported lower but worsens physical U and final signed
gap against the sealed B. This ordinary mixed/loss outcome does not change
the admitted role order or full windows. Both own-H runs completed; their
semantic-trace and canonical-fleet hashes agree, with independent costs.
J's own helper cost 14.6320539 seconds inside T_produce and generated
floor .3959564087240911; no offline data or diagnostic formal blocks were used.

Closed G1=26023.0096619993 seconds; compilation remains separately
80.10179629991762 seconds. Position 3, R153_003_K-35-U_S0_B, started
2026-11-04T10:52:30 UTC. Supervisors 20037/82582/75277 remain in their
previous roles. Continue monitoring; no additional calculation or heavy I/O
may overlap the frozen full panel or the later automatic primal probes.

## Position 3 sealed; position 4 active

K35 B closed with U=.6928543586313136, L=.5654063360835149,
certificate=false and T_cert=null. T_produce=2372.0561557335313,
T_verify=2.754693099996075, T_total=2374.8108488335274; its outer fee
is 2374.9481723001227 seconds. Closed G1=28397.95783429942 seconds.
Position 4, R153_004_K-35-U_S0_J, started 2026-11-04T11:32:05 UTC.
All three supervisors remain active in the same roles. Full-method
physical U/L and the offline strengthened-LP value intervals are separate
objects and must not be mixed. There are no other new experimental results.

## Position 4 sealed; position 5 active

K35 J closed with U=.6613267950806627, L=.539723389341635,
certificate=false, T_cert=null, T_produce=2371.3968823824544,
T_verify=5.125982100144029, T_total=2376.5228644825984.
Its outer fee is 2376.5916002001613 seconds. Compared with the same-PE B,
J improves physical U and slightly narrows absolute gap, but has a weaker
supported L. The candidate therefore has mixed effects across the first
two paired roles; no remaining role or window changes.

Closed G1=30774.549434499582 seconds. Position 5,
R153_005_R-B35-S-T1_S0_B, started 2026-11-04T12:11:42 UTC.
The eight-arm campaign, read-only monitor and afterqueue supervisor remain
sessions 20037, 82582 and 75277. All later probes and the direction screen
are still pending. Read their actual final states before any final audit,
plot, archive or commit.

## Position 5 sealed; position 6 active

R-B35-S-T1 B closed with U=.59151763477047, L=.45590389125187164,
certificate=false, T_cert=null, T_produce=2376.287360158516,
T_verify=2.8131878999993205, T_total=2379.1005480585154.
Its outer fee is 2379.1701336000115 seconds. Closed G1 is
33153.719568099594 seconds; builds remain separately 80.10179629991762.
Position 6, R153_006_R-B35-S-T1_S0_J, started
2026-11-04T12:51:21 UTC. Frozen settings and all three supervisors remain
unchanged. After this J, the NC20 B/J pair still must finish. Primal probes,
the accepted direction screen, final assessment/audit and delivery remain.

## Position 6 sealed; position 7 active

R-B35-S-T1 J closed with U=.6160491838984286, L=.46109737289145863,
certificate=false, T_cert=null, T_produce=2371.455770601984,
T_verify=5.09102619998157, T_total=2376.5467968019657.
Its outer fee is 2376.618468400091 seconds. Its supported L is slightly
higher than B, but physical U and final gap are worse. The helper's saved
internal calculation is 9.677815499948338 seconds, returning floor
.14243319962421927; it completed before normal full search, without a
candidate change. The formal helper-process time remains in the root audit.

Closed G1=35530.338036499685 seconds. All six difficult-role arms are
sealed and open (T_cert null). Position 7, R153_007_N-C20-U_S0_B, started
2026-11-04T13:30:58 UTC. The final NC20 B/J pair is still running/pending;
afterqueue75277 will automatically perform its reviewed primal probes
only after both endpoints and their verifications close. Monitor20037 and
82582 as before, then wait for75277 too. Do not treat campaign closure
alone as permission for final audit, figures, packing or commit.

## Position 7 certified; position 8 active

NC20 B closed with U=.24550506918249843, L=.24550506918245227,
certificate=true, T_cert=T_produce=266.70201131957583,
T_verify=3.2588613000698388, T_total=269.96087261964567.
The outer fee is270.0301557998173 seconds; closed G1 is
35800.3681922995 seconds. Position 8, R153_008_N-C20-U_S0_J, started
2026-11-04T13:35:28 UTC. afterqueue75277 was still waiting at that read.
It must be allowed to run its reviewed diagnostics after the final full
arm closes; campaign completion is not study completion.

## Full eight-arm panel closed; primal diagnostic now active

The original followthrough queue is REGISTERED_QUEUE_CLOSED at
2026-11-04T13:40:00 UTC. Sessions20037 and82582 exited normally. Do not
poll or relaunch them. All8 endpoint/verification gates passed with the
frozen candidate, roles and complete normal windows.

NC20 J has the same U=.24550506918249843 and L=.24550506918245227 as B,
certificate=true, T_cert=T_produce=267.25418481137604,
T_verify=3.9983099000528455, T_total=271.2524947114289. Its outer fee is
271.32853860012256 seconds. At complete-panel closure, G1 was
36071.696730899625 seconds (research21270.551343599334;
native14801.14538730029), plus separate builds80.10179629991762.
The complete candidate has mixed outcomes: K35 improves physical U while
NB35 and RB35 worsen it; NC20 retains the same certificate with about
.55 seconds longer T_cert. All six hard arms remain open. No default
promotion or universal negative conclusion is inferred.

afterqueue75277 is still RUNNING. Its small primal_pool_qualification_v1
passed with outer fee .25877160020172596 seconds. It then started
K35U_primal_pool_v1 at2026-11-04T13:40:06 UTC, followed automatically by
NC20U_primal_pool_v1. Closed G1 after qualification=36071.955502499826.
Do not overlap this supervisor with any other calculation or heavy I/O.
After it closes, execute the statically accepted direction screen through
one common.run fee, inspect actual probe/ceiling results, and decide the
narrow conditional continuation before final audit/delivery.

The independent reviewer has been asked to inspect the sealed full-panel
component using small JSON records only while the primal probes run. Final
whole-study review still follows the paid final audit and completed reports.

## Full-endpoint source-field correction

Actual independent readback of all8 complete endpoints found
source_commit=36d085cc7012690b8ab38d7ace70f487f54aec7e, equal to each
frozen identity's measured_source_commit. This supersedes the earlier
RESUME/report assumption that the full endpoint field denoted delivery base.
Only an earlier own_root_v2 qualification had that legacy/base meaning.
The full campaign has its own explicitly synchronized measured source.
reports.complete() now asserts equality with measured_source_commit and
retains delivery_base_commit separately; reproducibility.md is corrected.
No sealed endpoint, identity, production source or measured data is edited.
The old static report acceptance must be read with this actual-data finding
and the forthcoming complete_panel_review correction record.

## Primal serialization failure; all old supervisors have stopped

Session75277 exited1 after K35U_primal_pool_v1 failed. Sessions20037/82582
had already exited0. There is now NO active automatic experiment supervisor.
The original afterqueue status is FAILED_STOPPED and must not be rewritten.
The K35 fee closed with observed exit1, no timeout or supervisor failure,
and280.0080881998874 seconds. Closed G1=36351.963590699714 seconds.

Failure: Master.primal() computed an exact expected-f Fraction but str()
exceeded Python's4300-digit limit. Fifteen completed sweeps and8794 legal
columns remain saved; U=.28732616330431715 changes only about2e-12 from
the incoming upper. The next LP returned before serialization failed.
Keep raw RUNNING decision and partial evidence; do not call it completed.
NC20 primal has not started and neither its fee nor result directory exists.

New code/plan are written but UNEXECUTED pending independent static review:
- scripts/round153_exact_worker.py SHA f40ea001ea1a56bc2eb11536aa49574e2606356098751653a365d0030497d40d;
  process-local sys.set_int_max_str_digits(0), exact roundtrip qualification,
  then runpy of unchanged primal/coupled/finalize under the existing outer.
- primal_recovery_plan.json keeps failure identities and selects K35
  primal_pool_resume_v2 from the saved pool (900 internal/1300 outer),
  then original NC20 primal_pool (1200/1600). Use new K fee label and folder.
- direction_screen.py SHA b1511c0184866e39c141f620daace03f4fa962f4bf298bea2886112d3748908c;
  now requires (label, selection_plan), checks successful closed receipts
  and final probe states from the explicit plan, preserving old failed status.
- reports.py SHA ea59e5854b33911935757cc5d7fca9fd09753ade1318b57a6a03859a06f3dfa2;
  correct measured-source assertion and wrapper-argv fee mapping.

After review/exact_text_recovery_review.md accepts, run one common.run
qualification: exact_text_qualification_v1 / reserve300 /
round153_exact_worker.py qualify exact_text_v1. On PASS, serial recovery
uses common.run with worker arguments execute, <same fee label>,
round153_primal_pool.py, exact_text_v1, run, <role>, <result label>,
<resume path>, <internal seconds>, <tolerance>. The unchanged primal's
default qualification remains primal_pool_v1 (source EF).
Do not restart afterqueue48bb or overwrite its failure/initial plan.

The complete-panel independent component review is now accepted in
review/complete_panel_review.md; it verifies the8 identity/receipt chains,
four actual mixed comparisons and14801.1453873 outer seconds. It does not
accept the still unfinished primal/recovery or final whole-study conclusion.

## Exact-text qualification passed; K35 recovery active

review/exact_text_recovery_review.md formally accepts the runtime repair
and recovery plan. Worker f40ea001... and reports ea59e585... are unchanged;
the accepted screen SHA is now
ddc5b681f71de8116b194b7e5134586f72d958007ad66a7d463f39ad5df6cf16,
after adding actual runtime/launch/role/result/resume/cap/qualification binding.

exact_text_qualification_v1 PASS:10002-character Fraction text/JSON/gzip
roundtrip, no Optimize or Native model reads, process-local conversion limit
4300→0, outer .11462330003269017 seconds. Closed G1=36352.07821399975.

Active exec session30539 is the ONLY experiment: common.run fee
K35U_primal_pool_resume_v2, reserve1300, exact_worker execute of unchanged
primal_pool.py, role K-35-U, label primal_pool_resume_v2, resume the failed
primal_pool's saved8794-column result, internal900, tolerance.0001.
Poll30539 to normal closure before launching NC20. NC20 has NOT started.
Use its planned fee NC20U_primal_pool_v1, outer1600, worker exact_text_v1,
role N-C20-U label primal_pool, resume N-C20-U_deepened_support_envelope,
internal1200, tolerance.00001. No automatic supervisor remains.

After both successful closes, run common.run direction_screen_v1/reserve300
with round153_direction_screen.py post_primal_v1
results/unified_exact_round153/primal_recovery_plan.json. Then assess actual
upper changes and updated fixed-direction ceilings before choosing any
further price or updated-level continuation. Final audit should use the
qualified exact worker too, preserving its large-Fraction evidence.

## K35 recovery closed normally; NC20 primal active

Session30539 exited0. K35U_primal_pool_resume_v2 cost
873.2554401999805 outer seconds, completed49 sweeps and reached33882
legal columns. Its decision is offline_capacity_checkpoint; final interval
is[.2828596948801647,.28732616330431715], width.004466468424152437.
The only upper change across initial/recovery phases is about2e-12,
which is not a material gain. The many new legal columns do not certify
full price convergence. Raw64 completed sweeps span the failed15 and
successful49; their costs remain distinct, with no replay of the first15.
Closed G1=37225.33365419973 seconds, separate builds80.10179629991762.

The ONLY active experiment is session91550: NC20U_primal_pool_v1,
outer1600, exact_worker with qualification exact_text_v1, unchanged
primal_pool.py, role N-C20-U, label primal_pool, resume
N-C20-U_deepened_support_envelope, internal1200, tolerance.00001.
Wait for this session's actual successful closure, then run the paid
direction screen with the recovery plan. No other automatic queue exists.

## Primal probes and screen closed; K35 fixed-direction deepening active

NC20 session91550 exited0 with outer1178.8796639000066 seconds,
106 sweeps and54187 columns. Interval remains
[.1833218484555365,.1899568005655939], width.006634952110057379;
the upper change is only about3e-13. Both large feasible-column probes
therefore have no material primal gain, without claiming full pricing
or neighborhood exhaustion.

direction_screen_v1 then passed its exact finite-stock/runtime/launch
bindings in28.63474899996072 outer seconds, with0 Optimize/Native reads.
See diagnostics/post_primal_v1/result.json. Closed G1=38432.848067099694;
separate builds80.10179629991762. K latest iter10 still has mU=aK=
.08087030469130901 and fixed-certificate ceiling.2873260533067223.
NC latest iter16's mU falls to.039555519359850036, with ceiling
.18544776474345698; its old tightly priced direction has ceiling
.1833229561800073. These are fixed-CQ/aK ceilings, not hull/support-family
uppers. New lower bounds are not created by the stock screen.

review/post_primal_two_step_review.md formally accepts the concrete
post_primal_deepening_plan.json (planSHA
dd67c9e5d2cd62610793c7db633a08f80d3cce4f473c9d0a50599699b534c0f4).
refine and support_close now explicitly clear inherited primal-only
flags/sweep lists while retaining prior_results, correcting a real metadata
interface issue. Frozen EF primal,7b coupled,8ed pricer and production
remain unchanged. Accepted refine SHA starts22ead341, attribution1d11ac11.

The ONLY active experiment is session63906: fee
K35_post_primal_fixed_long_v1, outer1600, round153_refine.py,
K-35-U/post_primal_fixed_long, resume K-35-U_primal_pool_resume_v2,
saved direction K-35-U_near_optimal_zero_pool/iter00010,
1200 Native seconds, parts1, implementation partition. This is a qualified
full positive-S slice plus separate zero branch, not a claim of identical
MPS bytes or a resumed solver tree.

After63906 closes, perform the registered K support_close, then NC20
post_primal_level through exact_worker (1800 internal, price300, outer2200,
level_zero_pool, old_joint=true, all54187 prior stocks), then NC support_close.
All argv and labels are in the accepted plan; no automatic supervisor exists.
If a final price supplies useful new negative columns, consider one qualified
RMP primal refresh before declaring the upper mechanism exhausted; only its
numerical primal can improve U, never L. That thin interface is not yet written.
Further cap extensions/grids are not automatically authorized by this plan;
assess actual gains, price residuals and remaining potential after these steps.

## 2026-11-04 15:22 UTC: K closed; NC followthrough active

This entry supersedes the preceding active-session description. Session63906
closed normally: K35_post_primal_fixed_long_v1 cost1214.6429355000146 seconds,
price [.07003842216867079,.08087030469130901],225606nodes, fixed-certificate
lower .27649417078408406. No new columns (33882 unchanged). The following
K35_post_primal_support_envelope_v1 closed in13.33865370019339 seconds,
82support rows, final accumulated interval
[.2828596948801659,.28732616330431715]. K refresh is skipped under its actual
no-new-stock condition. Independent k35_endpoint_assessment.md accepts a
quantified unresolved stage endpoint, subject to final paid audit. Its price
bound was still progressing late; do not claim plateau, target closure or
no remaining potential.

The ONLY active experiment is session45909, NC20_post_primal_level_v1,
launched 15:08UTC through the qualified exact_worker, exactly as the accepted
post_primal_deepening_plan.json. It has1800 internal seconds,300 per full
price,2200 outer reservation,level_zero_pool,old_joint=true and all54187
incoming legal stocks. Its first two completed prices add12 columns without
changing [.1833218484555365,.1899568005655939]. Wait for its actual receipt;
do not take partial RUNNING state as a finished phase.

Next run NC20_post_primal_support_envelope_v1 as registered. If its final
price adds columns not yet evaluated in an RMP, the now-written and
independently accepted round153_refresh.py may perform one complete-Q LP
with180 Native seconds/400 outer, directly through common.run. It is the
last phase of that domain's current chain; keep the preceding support result
as separate support evidence. Exact_worker allowlist is unchanged. No added
price or lower is produced by refresh. See primal_refresh_plan.json and
review/primal_refresh_static_review.md. The final audit now also checks its
inheritance metadata and retains the existing independent selected primal
checks (six model reads total,zero Optimize).

candidate_decision.json is a DRAFT with study_complete=false and NC/final
audit/review pending. The complete eight-arm outcomes have been transcribed
into final_report/manuscript, but these are not final delivery documents yet.
After science seals: finalize decision paths/outcomes, commit explicitly
scoped completed code, perform the paid exact-worker final audit/report
pipeline, close its fee, write costs, finalize prose/figures and independent
review, then current-only pack/normal push/Draft PR/readback/one bounded
anonymous recovery/zero-delete cleanup/final metadata push. No goal completion
until all required delivery is observed. CLOSED G1 before NC is
39660.8296562999 seconds; separate compilation80.10179629991762 seconds.
