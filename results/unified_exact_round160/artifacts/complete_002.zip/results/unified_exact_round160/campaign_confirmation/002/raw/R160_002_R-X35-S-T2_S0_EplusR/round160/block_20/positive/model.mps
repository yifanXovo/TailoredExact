* Signature: 0x116ac7866ce619a1
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_3_26
 E  normalized_mass_3_27
 E  normalized_ratio_3_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 E  onehot_4_61
 E  normalized_mass_4_62
 E  normalized_ratio_4_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 E  onehot_34_96
 E  normalized_mass_34_97
 E  normalized_ratio_34_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 E  onehot_5_131
 E  normalized_mass_5_132
 E  normalized_ratio_5_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 E  onehot_29_156
 E  normalized_mass_29_157
 E  normalized_ratio_29_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 E  onehot_7_191
 E  normalized_mass_7_192
 E  normalized_ratio_7_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 E  onehot_27_208
 E  normalized_mass_27_209
 E  normalized_ratio_27_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 E  onehot_2_243
 E  normalized_mass_2_244
 E  normalized_ratio_2_245
 G  stock_lb_246
 L  stock_ub_247
 L  parent_nonstrict_scope_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 E  normalization_305
 G  full_original_Gini_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 L  arc_capacity_410
 L  arc_capacity_411
 L  arc_capacity_412
 L  arc_capacity_413
 L  arc_capacity_414
 L  arc_capacity_415
 L  arc_capacity_416
 L  arc_capacity_417
 L  arc_capacity_418
 L  arc_capacity_419
 L  arc_capacity_420
 L  arc_capacity_421
 L  arc_capacity_422
 L  arc_capacity_423
 L  arc_capacity_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 E  depot_departure_or_bypass_749
 E  depot_return_or_bypass_750
 E  out_degree_751
 E  in_degree_752
 G  order_active_lb_753
 L  order_active_ub_754
 E  segment_load_conservation_755
 G  segment_prefix_lb_756
 L  segment_prefix_ub_757
 E  out_degree_758
 E  in_degree_759
 G  order_active_lb_760
 L  order_active_ub_761
 E  segment_load_conservation_762
 G  segment_prefix_lb_763
 L  segment_prefix_ub_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  segment_load_conservation_769
 G  segment_prefix_lb_770
 L  segment_prefix_ub_771
 E  out_degree_772
 E  in_degree_773
 G  order_active_lb_774
 L  order_active_ub_775
 E  segment_load_conservation_776
 G  segment_prefix_lb_777
 L  segment_prefix_ub_778
 E  out_degree_779
 E  in_degree_780
 G  order_active_lb_781
 L  order_active_ub_782
 E  segment_load_conservation_783
 G  segment_prefix_lb_784
 L  segment_prefix_ub_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 E  out_degree_792
 E  in_degree_793
 G  order_active_lb_794
 L  order_active_ub_795
 E  service_visit_def_796
 E  free_load_conservation_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  service_visit_def_802
 E  free_load_conservation_803
 E  out_degree_804
 E  in_degree_805
 G  order_active_lb_806
 L  order_active_ub_807
 E  service_visit_def_808
 E  free_load_conservation_809
 E  out_degree_810
 E  in_degree_811
 G  order_active_lb_812
 L  order_active_ub_813
 E  service_visit_def_814
 E  free_load_conservation_815
 E  out_degree_816
 E  in_degree_817
 G  order_active_lb_818
 L  order_active_ub_819
 E  service_visit_def_820
 E  free_load_conservation_821
 E  out_degree_822
 E  in_degree_823
 G  order_active_lb_824
 L  order_active_ub_825
 E  service_visit_def_826
 E  free_load_conservation_827
 E  out_degree_828
 E  in_degree_829
 G  order_active_lb_830
 L  order_active_ub_831
 E  service_visit_def_832
 E  free_load_conservation_833
 G  fixed_segment_relative_order_834
 G  fixed_segment_relative_order_835
 G  fixed_segment_relative_order_836
 G  fixed_segment_relative_order_837
 L  original_T_including_depot_unload_838
 L  arc_capacity_839
 L  arc_capacity_840
 L  arc_capacity_841
 L  arc_capacity_842
 L  arc_capacity_843
 L  arc_capacity_844
 L  arc_capacity_845
 L  arc_capacity_846
 L  arc_capacity_847
 L  arc_capacity_848
 L  arc_capacity_849
 L  arc_capacity_850
 L  arc_capacity_851
 L  arc_capacity_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 E  depot_departure_or_bypass_1128
 E  depot_return_or_bypass_1129
 E  out_degree_1130
 E  in_degree_1131
 G  order_active_lb_1132
 L  order_active_ub_1133
 E  segment_load_conservation_1134
 G  segment_prefix_lb_1135
 L  segment_prefix_ub_1136
 E  out_degree_1137
 E  in_degree_1138
 G  order_active_lb_1139
 L  order_active_ub_1140
 E  segment_load_conservation_1141
 G  segment_prefix_lb_1142
 L  segment_prefix_ub_1143
 E  out_degree_1144
 E  in_degree_1145
 G  order_active_lb_1146
 L  order_active_ub_1147
 E  segment_load_conservation_1148
 G  segment_prefix_lb_1149
 L  segment_prefix_ub_1150
 E  out_degree_1151
 E  in_degree_1152
 G  order_active_lb_1153
 L  order_active_ub_1154
 E  segment_load_conservation_1155
 G  segment_prefix_lb_1156
 L  segment_prefix_ub_1157
 E  out_degree_1158
 E  in_degree_1159
 G  order_active_lb_1160
 L  order_active_ub_1161
 E  service_visit_def_1162
 E  free_load_conservation_1163
 E  out_degree_1164
 E  in_degree_1165
 G  order_active_lb_1166
 L  order_active_ub_1167
 E  service_visit_def_1168
 E  free_load_conservation_1169
 E  out_degree_1170
 E  in_degree_1171
 G  order_active_lb_1172
 L  order_active_ub_1173
 E  service_visit_def_1174
 E  free_load_conservation_1175
 E  out_degree_1176
 E  in_degree_1177
 G  order_active_lb_1178
 L  order_active_ub_1179
 E  service_visit_def_1180
 E  free_load_conservation_1181
 E  out_degree_1182
 E  in_degree_1183
 G  order_active_lb_1184
 L  order_active_ub_1185
 E  service_visit_def_1186
 E  free_load_conservation_1187
 E  out_degree_1188
 E  in_degree_1189
 G  order_active_lb_1190
 L  order_active_ub_1191
 E  service_visit_def_1192
 E  free_load_conservation_1193
 E  out_degree_1194
 E  in_degree_1195
 G  order_active_lb_1196
 L  order_active_ub_1197
 E  service_visit_def_1198
 E  free_load_conservation_1199
 E  out_degree_1200
 E  in_degree_1201
 G  order_active_lb_1202
 L  order_active_ub_1203
 E  service_visit_def_1204
 E  free_load_conservation_1205
 G  fixed_segment_relative_order_1206
 G  fixed_segment_relative_order_1207
 G  fixed_segment_relative_order_1208
 L  original_T_including_depot_unload_1209
 L  arc_capacity_1210
 L  arc_capacity_1211
 L  arc_capacity_1212
 L  arc_capacity_1213
 L  arc_capacity_1214
 L  arc_capacity_1215
 L  arc_capacity_1216
 L  arc_capacity_1217
 L  arc_capacity_1218
 L  arc_capacity_1219
 L  arc_capacity_1220
 L  arc_capacity_1221
 L  arc_capacity_1222
 L  arc_capacity_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 E  depot_departure_or_bypass_1499
 E  depot_return_or_bypass_1500
 E  out_degree_1501
 E  in_degree_1502
 G  order_active_lb_1503
 L  order_active_ub_1504
 E  segment_load_conservation_1505
 G  segment_prefix_lb_1506
 L  segment_prefix_ub_1507
 E  out_degree_1508
 E  in_degree_1509
 G  order_active_lb_1510
 L  order_active_ub_1511
 E  segment_load_conservation_1512
 G  segment_prefix_lb_1513
 L  segment_prefix_ub_1514
 E  out_degree_1515
 E  in_degree_1516
 G  order_active_lb_1517
 L  order_active_ub_1518
 E  segment_load_conservation_1519
 G  segment_prefix_lb_1520
 L  segment_prefix_ub_1521
 E  out_degree_1522
 E  in_degree_1523
 G  order_active_lb_1524
 L  order_active_ub_1525
 E  segment_load_conservation_1526
 G  segment_prefix_lb_1527
 L  segment_prefix_ub_1528
 E  out_degree_1529
 E  in_degree_1530
 G  order_active_lb_1531
 L  order_active_ub_1532
 E  service_visit_def_1533
 E  free_load_conservation_1534
 E  out_degree_1535
 E  in_degree_1536
 G  order_active_lb_1537
 L  order_active_ub_1538
 E  service_visit_def_1539
 E  free_load_conservation_1540
 E  out_degree_1541
 E  in_degree_1542
 G  order_active_lb_1543
 L  order_active_ub_1544
 E  service_visit_def_1545
 E  free_load_conservation_1546
 E  out_degree_1547
 E  in_degree_1548
 G  order_active_lb_1549
 L  order_active_ub_1550
 E  service_visit_def_1551
 E  free_load_conservation_1552
 E  out_degree_1553
 E  in_degree_1554
 G  order_active_lb_1555
 L  order_active_ub_1556
 E  service_visit_def_1557
 E  free_load_conservation_1558
 E  out_degree_1559
 E  in_degree_1560
 G  order_active_lb_1561
 L  order_active_ub_1562
 E  service_visit_def_1563
 E  free_load_conservation_1564
 E  out_degree_1565
 E  in_degree_1566
 G  order_active_lb_1567
 L  order_active_ub_1568
 E  service_visit_def_1569
 E  free_load_conservation_1570
 E  out_degree_1571
 E  in_degree_1572
 G  order_active_lb_1573
 L  order_active_ub_1574
 E  service_visit_def_1575
 E  free_load_conservation_1576
 G  fixed_segment_relative_order_1577
 G  fixed_segment_relative_order_1578
 G  fixed_segment_relative_order_1579
 L  original_T_including_depot_unload_1580
COLUMNS
    t         normalized_mass_3_27  -1
    t         normalized_mass_4_62  -1
    t         normalized_mass_34_97  -1
    t         normalized_mass_5_132  -1
    t         normalized_mass_29_157  -1
    t         normalized_mass_7_192  -1
    t         normalized_mass_27_209  -1
    t         normalized_mass_2_244  -1
    t         normalization_305  2.3022619047619049e+01
    t         full_original_Gini_306  -8.9880952380952422e+01
    q         OBJ       1
    q         parent_nonstrict_scope_248  1
    q         full_original_Gini_306  35
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       1.6756644912833352e-02
    x_3_0     product_lb_0  -2.5336309344246841e-02
    x_3_0     product_ub_1  -4.3435544754167235e-02
    x_3_0     onehot_3_26  1
    x_3_0     parent_nonstrict_scope_248  0.0335132898256667
    x_3_0     unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_0  1
    w_3_0     product_ub_1  1
    w_3_0     normalized_mass_3_27  1
    w_3_0     full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       1.1171096608555569e-02
    x_3_1     product_lb_2  -2.5336309344246841e-02
    x_3_1     product_ub_3  -4.3435544754167235e-02
    x_3_1     onehot_3_26  1
    x_3_1     stock_lb_246  1
    x_3_1     stock_ub_247  1
    x_3_1     parent_nonstrict_scope_248  2.7927741521388921e-02
    x_3_1     unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_2  1
    w_3_1     product_ub_3  1
    w_3_1     normalized_mass_3_27  1
    w_3_1     normalized_ratio_3_28  -1.6666666666666666e-01
    w_3_1     full_original_Gini_306  -1.8855952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       5.5855483042777862e-03
    x_3_2     product_lb_4  -2.5336309344246841e-02
    x_3_2     product_ub_5  -4.3435544754167235e-02
    x_3_2     onehot_3_26  1
    x_3_2     stock_lb_246  2
    x_3_2     stock_ub_247  2
    x_3_2     parent_nonstrict_scope_248  2.2342193217111138e-02
    x_3_2     unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_4  1
    w_3_2     product_ub_5  1
    w_3_2     normalized_mass_3_27  1
    w_3_2     normalized_ratio_3_28  -3.3333333333333331e-01
    w_3_2     full_original_Gini_306  -1.4689285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     product_lb_6  -2.5336309344246841e-02
    x_3_3     product_ub_7  -4.3435544754167235e-02
    x_3_3     onehot_3_26  1
    x_3_3     stock_lb_246  3
    x_3_3     stock_ub_247  3
    x_3_3     parent_nonstrict_scope_248  1.6756644912833352e-02
    x_3_3     unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_6  1
    w_3_3     product_ub_7  1
    w_3_3     normalized_mass_3_27  1
    w_3_3     normalized_ratio_3_28  -0.5
    w_3_3     full_original_Gini_306  -1.0855952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.5855483042777827e-03
    x_3_4     product_lb_8  -2.5336309344246841e-02
    x_3_4     product_ub_9  -4.3435544754167235e-02
    x_3_4     onehot_3_26  1
    x_3_4     stock_lb_246  4
    x_3_4     stock_ub_247  4
    x_3_4     parent_nonstrict_scope_248  1.1171096608555569e-02
    x_3_4     unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_8  1
    w_3_4     product_ub_9  1
    w_3_4     normalized_mass_3_27  1
    w_3_4     normalized_ratio_3_28  -6.6666666666666663e-01
    w_3_4     full_original_Gini_306  -7.0226190476190471e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.1171096608555565e-02
    x_3_5     product_lb_10  -2.5336309344246841e-02
    x_3_5     product_ub_11  -4.3435544754167235e-02
    x_3_5     onehot_3_26  1
    x_3_5     stock_lb_246  5
    x_3_5     stock_ub_247  5
    x_3_5     parent_nonstrict_scope_248  5.5855483042777862e-03
    x_3_5     unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_10  1
    w_3_5     product_ub_11  1
    w_3_5     normalized_mass_3_27  1
    w_3_5     normalized_ratio_3_28  -8.3333333333333326e-01
    w_3_5     full_original_Gini_306  -4.8940476190476190e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -1.6756644912833352e-02
    x_3_6     product_lb_12  -2.5336309344246841e-02
    x_3_6     product_ub_13  -4.3435544754167235e-02
    x_3_6     onehot_3_26  1
    x_3_6     stock_lb_246  6
    x_3_6     stock_ub_247  6
    x_3_6     unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_12  1
    w_3_6     product_ub_13  1
    w_3_6     normalized_mass_3_27  1
    w_3_6     normalized_ratio_3_28  -1
    w_3_6     full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -1.1171096608555572e-02
    x_3_7     product_lb_14  -2.5336309344246841e-02
    x_3_7     product_ub_15  -4.3435544754167235e-02
    x_3_7     onehot_3_26  1
    x_3_7     stock_lb_246  7
    x_3_7     stock_ub_247  7
    x_3_7     parent_nonstrict_scope_248  5.5855483042777793e-03
    x_3_7     unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_14  1
    w_3_7     product_ub_15  1
    w_3_7     normalized_mass_3_27  1
    w_3_7     normalized_ratio_3_28  -1.1666666666666665e+00
    w_3_7     full_original_Gini_306  -9.1440476190476137e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.5855483042777862e-03
    x_3_8     product_lb_16  -2.5336309344246841e-02
    x_3_8     product_ub_17  -4.3435544754167235e-02
    x_3_8     onehot_3_26  1
    x_3_8     stock_lb_246  8
    x_3_8     stock_ub_247  8
    x_3_8     parent_nonstrict_scope_248  1.1171096608555565e-02
    x_3_8     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_16  1
    w_3_8     product_ub_17  1
    w_3_8     normalized_mass_3_27  1
    w_3_8     normalized_ratio_3_28  -1.3333333333333333e+00
    w_3_8     full_original_Gini_306  -1.3310714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_9     product_lb_18  -2.5336309344246841e-02
    x_3_9     product_ub_19  -4.3435544754167235e-02
    x_3_9     onehot_3_26  1
    x_3_9     stock_lb_246  9
    x_3_9     stock_ub_247  9
    x_3_9     parent_nonstrict_scope_248  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_18  1
    w_3_9     product_ub_19  1
    w_3_9     normalized_mass_3_27  1
    w_3_9     normalized_ratio_3_28  -1.5
    w_3_9     full_original_Gini_306  -1.7477380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       5.5855483042777793e-03
    x_3_10    product_lb_20  -2.5336309344246841e-02
    x_3_10    product_ub_21  -4.3435544754167235e-02
    x_3_10    onehot_3_26  1
    x_3_10    stock_lb_246  10
    x_3_10    stock_ub_247  10
    x_3_10    parent_nonstrict_scope_248  2.2342193217111131e-02
    x_3_10    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_20  1
    w_3_10    product_ub_21  1
    w_3_10    normalized_mass_3_27  1
    w_3_10    normalized_ratio_3_28  -1.6666666666666665e+00
    w_3_10    full_original_Gini_306  -2.1977380952380948e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       1.1171096608555565e-02
    x_3_11    product_lb_22  -2.5336309344246841e-02
    x_3_11    product_ub_23  -4.3435544754167235e-02
    x_3_11    onehot_3_26  1
    x_3_11    stock_lb_246  11
    x_3_11    stock_ub_247  11
    x_3_11    parent_nonstrict_scope_248  2.7927741521388917e-02
    x_3_11    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_22  1
    w_3_11    product_ub_23  1
    w_3_11    normalized_mass_3_27  1
    w_3_11    normalized_ratio_3_28  -1.8333333333333333e+00
    w_3_11    full_original_Gini_306  -2.6477380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       1.6756644912833352e-02
    x_3_12    product_lb_24  -2.5336309344246841e-02
    x_3_12    product_ub_25  -4.3435544754167235e-02
    x_3_12    onehot_3_26  1
    x_3_12    stock_lb_246  12
    x_3_12    stock_ub_247  12
    x_3_12    parent_nonstrict_scope_248  0.0335132898256667
    x_3_12    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_24  1
    w_3_12    product_ub_25  1
    w_3_12    normalized_mass_3_27  1
    w_3_12    normalized_ratio_3_28  -2
    w_3_12    full_original_Gini_306  -3.0977380952380951e+01
    rho_3     normalized_ratio_3_28  1
    rho_3     block_pair_pos_249  -1
    rho_3     block_pair_neg_250  1
    rho_3     block_pair_pos_251  -1
    rho_3     block_pair_neg_252  1
    rho_3     block_pair_pos_253  -1
    rho_3     block_pair_neg_254  1
    rho_3     block_pair_pos_255  -1
    rho_3     block_pair_neg_256  1
    rho_3     block_pair_pos_257  -1
    rho_3     block_pair_neg_258  1
    rho_3     block_pair_pos_259  -1
    rho_3     block_pair_neg_260  1
    rho_3     block_pair_pos_261  -1
    rho_3     block_pair_neg_262  1
    rho_3     normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       1.9549429837111887e-02
    x_4_0     product_lb_29  -2.5336309344246841e-02
    x_4_0     product_ub_30  -4.3435544754167235e-02
    x_4_0     onehot_4_61  1
    x_4_0     parent_nonstrict_scope_248  0.0456153362865944
    x_4_0     unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_29  1
    w_4_0     product_ub_30  1
    w_4_0     normalized_mass_4_62  1
    w_4_0     full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       1.3032953224741260e-02
    x_4_1     product_lb_31  -2.5336309344246841e-02
    x_4_1     product_ub_32  -4.3435544754167235e-02
    x_4_1     onehot_4_61  1
    x_4_1     stock_lb_246  1
    x_4_1     stock_ub_247  1
    x_4_1     parent_nonstrict_scope_248  3.9098859674223774e-02
    x_4_1     unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_31  1
    w_4_1     product_ub_32  1
    w_4_1     normalized_mass_4_62  1
    w_4_1     normalized_ratio_4_63  -1.4285714285714285e-01
    w_4_1     full_original_Gini_306  -1.9451190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       6.5164766123706336e-03
    x_4_2     product_lb_33  -2.5336309344246841e-02
    x_4_2     product_ub_34  -4.3435544754167235e-02
    x_4_2     onehot_4_61  1
    x_4_2     stock_lb_246  2
    x_4_2     stock_ub_247  2
    x_4_2     parent_nonstrict_scope_248  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_33  1
    w_4_2     product_ub_34  1
    w_4_2     normalized_mass_4_62  1
    w_4_2     normalized_ratio_4_63  -2.8571428571428570e-01
    w_4_2     full_original_Gini_306  -15.8797619047619
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_35  -2.5336309344246841e-02
    x_4_3     product_ub_36  -4.3435544754167235e-02
    x_4_3     onehot_4_61  1
    x_4_3     stock_lb_246  3
    x_4_3     stock_ub_247  3
    x_4_3     parent_nonstrict_scope_248  2.6065906449482514e-02
    x_4_3     unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_35  1
    w_4_3     product_ub_36  1
    w_4_3     normalized_mass_4_62  1
    w_4_3     normalized_ratio_4_63  -4.2857142857142855e-01
    w_4_3     full_original_Gini_306  -1.2498809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -6.5164766123706266e-03
    x_4_4     product_lb_37  -2.5336309344246841e-02
    x_4_4     product_ub_38  -4.3435544754167235e-02
    x_4_4     onehot_4_61  1
    x_4_4     stock_lb_246  4
    x_4_4     stock_ub_247  4
    x_4_4     parent_nonstrict_scope_248  1.9549429837111887e-02
    x_4_4     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_37  1
    w_4_4     product_ub_38  1
    w_4_4     normalized_mass_4_62  1
    w_4_4     normalized_ratio_4_63  -5.7142857142857140e-01
    w_4_4     full_original_Gini_306  -9.21309523809524
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -1.3032953224741252e-02
    x_4_5     product_lb_39  -2.5336309344246841e-02
    x_4_5     product_ub_40  -4.3435544754167235e-02
    x_4_5     onehot_4_61  1
    x_4_5     stock_lb_246  5
    x_4_5     stock_ub_247  5
    x_4_5     parent_nonstrict_scope_248  1.3032953224741262e-02
    x_4_5     unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_39  1
    w_4_5     product_ub_40  1
    w_4_5     normalized_mass_4_62  1
    w_4_5     normalized_ratio_4_63  -7.1428571428571419e-01
    w_4_5     full_original_Gini_306  -6.0226190476190462e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -1.9549429837111883e-02
    x_4_6     product_lb_41  -2.5336309344246841e-02
    x_4_6     product_ub_42  -4.3435544754167235e-02
    x_4_6     onehot_4_61  1
    x_4_6     stock_lb_246  6
    x_4_6     stock_ub_247  6
    x_4_6     parent_nonstrict_scope_248  6.5164766123706310e-03
    x_4_6     unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_41  1
    w_4_6     product_ub_42  1
    w_4_6     normalized_mass_4_62  1
    w_4_6     normalized_ratio_4_63  -8.5714285714285710e-01
    w_4_6     full_original_Gini_306  -4.8702380952380944e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -2.6065906449482514e-02
    x_4_7     product_lb_43  -2.5336309344246841e-02
    x_4_7     product_ub_44  -4.3435544754167235e-02
    x_4_7     onehot_4_61  1
    x_4_7     stock_lb_246  7
    x_4_7     stock_ub_247  7
    x_4_7     unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_43  1
    w_4_7     product_ub_44  1
    w_4_7     normalized_mass_4_62  1
    w_4_7     normalized_ratio_4_63  -1
    w_4_7     full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -1.9549429837111887e-02
    x_4_8     product_lb_45  -2.5336309344246841e-02
    x_4_8     product_ub_46  -4.3435544754167235e-02
    x_4_8     onehot_4_61  1
    x_4_8     stock_lb_246  8
    x_4_8     stock_ub_247  8
    x_4_8     parent_nonstrict_scope_248  6.5164766123706258e-03
    x_4_8     unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_45  1
    w_4_8     product_ub_46  1
    w_4_8     normalized_mass_4_62  1
    w_4_8     normalized_ratio_4_63  -1.1428571428571428e+00
    w_4_8     full_original_Gini_306  -8.54880952380952
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -1.3032953224741262e-02
    x_4_9     product_lb_47  -2.5336309344246841e-02
    x_4_9     product_ub_48  -4.3435544754167235e-02
    x_4_9     onehot_4_61  1
    x_4_9     stock_lb_246  9
    x_4_9     stock_ub_247  9
    x_4_9     parent_nonstrict_scope_248  1.3032953224741252e-02
    x_4_9     unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_47  1
    w_4_9     product_ub_48  1
    w_4_9     normalized_mass_4_62  1
    w_4_9     normalized_ratio_4_63  -1.2857142857142856e+00
    w_4_9     full_original_Gini_306  -1.2120238095238090e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -6.5164766123706371e-03
    x_4_10    product_lb_49  -2.5336309344246841e-02
    x_4_10    product_ub_50  -4.3435544754167235e-02
    x_4_10    onehot_4_61  1
    x_4_10    stock_lb_246  10
    x_4_10    stock_ub_247  10
    x_4_10    parent_nonstrict_scope_248  1.9549429837111876e-02
    x_4_10    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_49  1
    w_4_10    product_ub_50  1
    w_4_10    normalized_mass_4_62  1
    w_4_10    normalized_ratio_4_63  -1.4285714285714284e+00
    w_4_10    full_original_Gini_306  -1.5691666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_51  -2.5336309344246841e-02
    x_4_11    product_ub_52  -4.3435544754167235e-02
    x_4_11    onehot_4_61  1
    x_4_11    stock_lb_246  11
    x_4_11    stock_ub_247  11
    x_4_11    parent_nonstrict_scope_248  2.6065906449482514e-02
    x_4_11    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_51  1
    w_4_11    product_ub_52  1
    w_4_11    normalized_mass_4_62  1
    w_4_11    normalized_ratio_4_63  -1.5714285714285714e+00
    w_4_11    full_original_Gini_306  -1.9405952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       6.5164766123706266e-03
    x_4_12    product_lb_53  -2.5336309344246841e-02
    x_4_12    product_ub_54  -4.3435544754167235e-02
    x_4_12    onehot_4_61  1
    x_4_12    stock_lb_246  12
    x_4_12    stock_ub_247  12
    x_4_12    parent_nonstrict_scope_248  3.2582383061853140e-02
    x_4_12    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_53  1
    w_4_12    product_ub_54  1
    w_4_12    normalized_mass_4_62  1
    w_4_12    normalized_ratio_4_63  -1.7142857142857142e+00
    w_4_12    full_original_Gini_306  -2.3263095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       1.3032953224741253e-02
    x_4_13    product_lb_55  -2.5336309344246841e-02
    x_4_13    product_ub_56  -4.3435544754167235e-02
    x_4_13    onehot_4_61  1
    x_4_13    stock_lb_246  13
    x_4_13    stock_ub_247  13
    x_4_13    parent_nonstrict_scope_248  3.9098859674223767e-02
    x_4_13    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_55  1
    w_4_13    product_ub_56  1
    w_4_13    normalized_mass_4_62  1
    w_4_13    normalized_ratio_4_63  -1.8571428571428570e+00
    w_4_13    full_original_Gini_306  -2.7120238095238097e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       1.9549429837111887e-02
    x_4_14    product_lb_57  -2.5336309344246841e-02
    x_4_14    product_ub_58  -4.3435544754167235e-02
    x_4_14    onehot_4_61  1
    x_4_14    stock_lb_246  14
    x_4_14    stock_ub_247  14
    x_4_14    parent_nonstrict_scope_248  0.0456153362865944
    x_4_14    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_57  1
    w_4_14    product_ub_58  1
    w_4_14    normalized_mass_4_62  1
    w_4_14    normalized_ratio_4_63  -2
    w_4_14    full_original_Gini_306  -3.0977380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       2.6065906449482514e-02
    x_4_15    product_lb_59  -2.5336309344246841e-02
    x_4_15    product_ub_60  -4.3435544754167235e-02
    x_4_15    onehot_4_61  1
    x_4_15    stock_lb_246  15
    x_4_15    stock_ub_247  15
    x_4_15    parent_nonstrict_scope_248  5.2131812898965027e-02
    x_4_15    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_59  1
    w_4_15    product_ub_60  1
    w_4_15    normalized_mass_4_62  1
    w_4_15    normalized_ratio_4_63  -2.1428571428571428e+00
    w_4_15    full_original_Gini_306  -34.8345238095238
    rho_4     normalized_ratio_4_63  1
    rho_4     block_pair_pos_251  1
    rho_4     block_pair_neg_252  -1
    rho_4     block_pair_pos_263  -1
    rho_4     block_pair_neg_264  1
    rho_4     block_pair_pos_265  -1
    rho_4     block_pair_neg_266  1
    rho_4     block_pair_pos_267  -1
    rho_4     block_pair_neg_268  1
    rho_4     block_pair_pos_269  -1
    rho_4     block_pair_neg_270  1
    rho_4     block_pair_pos_271  -1
    rho_4     block_pair_neg_272  1
    rho_4     block_pair_pos_273  -1
    rho_4     block_pair_neg_274  1
    rho_4     normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_64  -2.5336309344246841e-02
    x_34_0    product_ub_65  -4.3435544754167235e-02
    x_34_0    onehot_34_96  1
    x_34_0    parent_nonstrict_scope_248  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_64  1
    w_34_0    product_ub_65  1
    w_34_0    normalized_mass_34_97  1
    w_34_0    full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_66  -2.5336309344246841e-02
    x_34_1    product_ub_67  -4.3435544754167235e-02
    x_34_1    onehot_34_96  1
    x_34_1    stock_lb_246  1
    x_34_1    stock_ub_247  1
    x_34_1    parent_nonstrict_scope_248  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_66  1
    w_34_1    product_ub_67  1
    w_34_1    normalized_mass_34_97  1
    w_34_1    normalized_ratio_34_98  -0.125
    w_34_1    full_original_Gini_306  -1.9897619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_68  -2.5336309344246841e-02
    x_34_2    product_ub_69  -4.3435544754167235e-02
    x_34_2    onehot_34_96  1
    x_34_2    stock_lb_246  2
    x_34_2    stock_ub_247  2
    x_34_2    parent_nonstrict_scope_248  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_68  1
    w_34_2    product_ub_69  1
    w_34_2    normalized_mass_34_97  1
    w_34_2    normalized_ratio_34_98  -0.25
    w_34_2    full_original_Gini_306  -1.6772619047619045e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_70  -2.5336309344246841e-02
    x_34_3    product_ub_71  -4.3435544754167235e-02
    x_34_3    onehot_34_96  1
    x_34_3    stock_lb_246  3
    x_34_3    stock_ub_247  3
    x_34_3    parent_nonstrict_scope_248  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_70  1
    w_34_3    product_ub_71  1
    w_34_3    normalized_mass_34_97  1
    w_34_3    normalized_ratio_34_98  -0.375
    w_34_3    full_original_Gini_306  -1.3730952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_72  -2.5336309344246841e-02
    x_34_4    product_ub_73  -4.3435544754167235e-02
    x_34_4    onehot_34_96  1
    x_34_4    stock_lb_246  4
    x_34_4    stock_ub_247  4
    x_34_4    parent_nonstrict_scope_248  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_72  1
    w_34_4    product_ub_73  1
    w_34_4    normalized_mass_34_97  1
    w_34_4    normalized_ratio_34_98  -0.5
    w_34_4    full_original_Gini_306  -1.0855952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_74  -2.5336309344246841e-02
    x_34_5    product_ub_75  -4.3435544754167235e-02
    x_34_5    onehot_34_96  1
    x_34_5    stock_lb_246  5
    x_34_5    stock_ub_247  5
    x_34_5    parent_nonstrict_scope_248  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_74  1
    w_34_5    product_ub_75  1
    w_34_5    normalized_mass_34_97  1
    w_34_5    normalized_ratio_34_98  -0.625
    w_34_5    full_original_Gini_306  -7.9809523809523810e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_76  -2.5336309344246841e-02
    x_34_6    product_ub_77  -4.3435544754167235e-02
    x_34_6    onehot_34_96  1
    x_34_6    stock_lb_246  6
    x_34_6    stock_ub_247  6
    x_34_6    parent_nonstrict_scope_248  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_76  1
    w_34_6    product_ub_77  1
    w_34_6    normalized_mass_34_97  1
    w_34_6    normalized_ratio_34_98  -0.75
    w_34_6    full_original_Gini_306  -5.3440476190476192e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_78  -2.5336309344246841e-02
    x_34_7    product_ub_79  -4.3435544754167235e-02
    x_34_7    onehot_34_96  1
    x_34_7    stock_lb_246  7
    x_34_7    stock_ub_247  7
    x_34_7    parent_nonstrict_scope_248  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_78  1
    w_34_7    product_ub_79  1
    w_34_7    normalized_mass_34_97  1
    w_34_7    normalized_ratio_34_98  -0.875
    w_34_7    full_original_Gini_306  -4.8523809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_80  -2.5336309344246841e-02
    x_34_8    product_ub_81  -4.3435544754167235e-02
    x_34_8    onehot_34_96  1
    x_34_8    stock_lb_246  8
    x_34_8    stock_ub_247  8
    x_34_8    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_80  1
    w_34_8    product_ub_81  1
    w_34_8    normalized_mass_34_97  1
    w_34_8    normalized_ratio_34_98  -1
    w_34_8    full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_82  -2.5336309344246841e-02
    x_34_9    product_ub_83  -4.3435544754167235e-02
    x_34_9    onehot_34_96  1
    x_34_9    stock_lb_246  9
    x_34_9    stock_ub_247  9
    x_34_9    parent_nonstrict_scope_248  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_82  1
    w_34_9    product_ub_83  1
    w_34_9    normalized_mass_34_97  1
    w_34_9    normalized_ratio_34_98  -1.125
    w_34_9    full_original_Gini_306  -8.1023809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_84  -2.5336309344246841e-02
    x_34_10   product_ub_85  -4.3435544754167235e-02
    x_34_10   onehot_34_96  1
    x_34_10   stock_lb_246  10
    x_34_10   stock_ub_247  10
    x_34_10   parent_nonstrict_scope_248  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_84  1
    w_34_10   product_ub_85  1
    w_34_10   normalized_mass_34_97  1
    w_34_10   normalized_ratio_34_98  -1.25
    w_34_10   full_original_Gini_306  -1.1227380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_86  -2.5336309344246841e-02
    x_34_11   product_ub_87  -4.3435544754167235e-02
    x_34_11   onehot_34_96  1
    x_34_11   stock_lb_246  11
    x_34_11   stock_ub_247  11
    x_34_11   parent_nonstrict_scope_248  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_86  1
    w_34_11   product_ub_87  1
    w_34_11   normalized_mass_34_97  1
    w_34_11   normalized_ratio_34_98  -1.375
    w_34_11   full_original_Gini_306  -1.4352380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_88  -2.5336309344246841e-02
    x_34_12   product_ub_89  -4.3435544754167235e-02
    x_34_12   onehot_34_96  1
    x_34_12   stock_lb_246  12
    x_34_12   stock_ub_247  12
    x_34_12   parent_nonstrict_scope_248  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_88  1
    w_34_12   product_ub_89  1
    w_34_12   normalized_mass_34_97  1
    w_34_12   normalized_ratio_34_98  -1.5
    w_34_12   full_original_Gini_306  -1.7477380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_90  -2.5336309344246841e-02
    x_34_13   product_ub_91  -4.3435544754167235e-02
    x_34_13   onehot_34_96  1
    x_34_13   stock_lb_246  13
    x_34_13   stock_ub_247  13
    x_34_13   parent_nonstrict_scope_248  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_90  1
    w_34_13   product_ub_91  1
    w_34_13   normalized_mass_34_97  1
    w_34_13   normalized_ratio_34_98  -1.625
    w_34_13   full_original_Gini_306  -2.0852380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_92  -2.5336309344246841e-02
    x_34_14   product_ub_93  -4.3435544754167235e-02
    x_34_14   onehot_34_96  1
    x_34_14   stock_lb_246  14
    x_34_14   stock_ub_247  14
    x_34_14   parent_nonstrict_scope_248  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_92  1
    w_34_14   product_ub_93  1
    w_34_14   normalized_mass_34_97  1
    w_34_14   normalized_ratio_34_98  -1.75
    w_34_14   full_original_Gini_306  -2.4227380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_94  -2.5336309344246841e-02
    x_34_15   product_ub_95  -4.3435544754167235e-02
    x_34_15   onehot_34_96  1
    x_34_15   stock_lb_246  15
    x_34_15   stock_ub_247  15
    x_34_15   parent_nonstrict_scope_248  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_94  1
    w_34_15   product_ub_95  1
    w_34_15   normalized_mass_34_97  1
    w_34_15   normalized_ratio_34_98  -1.875
    w_34_15   full_original_Gini_306  -2.7602380952380951e+01
    rho_34    normalized_ratio_34_98  1
    rho_34    block_pair_pos_261  1
    rho_34    block_pair_neg_262  -1
    rho_34    block_pair_pos_273  1
    rho_34    block_pair_neg_274  -1
    rho_34    block_pair_pos_295  -1
    rho_34    block_pair_neg_296  1
    rho_34    block_pair_pos_297  -1
    rho_34    block_pair_neg_298  1
    rho_34    block_pair_pos_299  -1
    rho_34    block_pair_neg_300  1
    rho_34    block_pair_pos_301  -1
    rho_34    block_pair_neg_302  1
    rho_34    block_pair_pos_303  -1
    rho_34    block_pair_neg_304  1
    rho_34    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       1.9549429837111887e-02
    x_5_0     product_lb_99  -2.5336309344246841e-02
    x_5_0     product_ub_100  -4.3435544754167235e-02
    x_5_0     onehot_5_131  1
    x_5_0     parent_nonstrict_scope_248  0.0456153362865944
    x_5_0     unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_99  1
    w_5_0     product_ub_100  1
    w_5_0     normalized_mass_5_132  1
    w_5_0     full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       1.3032953224741260e-02
    x_5_1     product_lb_101  -2.5336309344246841e-02
    x_5_1     product_ub_102  -4.3435544754167235e-02
    x_5_1     onehot_5_131  1
    x_5_1     stock_lb_246  1
    x_5_1     stock_ub_247  1
    x_5_1     parent_nonstrict_scope_248  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_101  1
    w_5_1     product_ub_102  1
    w_5_1     normalized_mass_5_132  1
    w_5_1     normalized_ratio_5_133  -1.4285714285714285e-01
    w_5_1     full_original_Gini_306  -1.9451190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.5164766123706336e-03
    x_5_2     product_lb_103  -2.5336309344246841e-02
    x_5_2     product_ub_104  -4.3435544754167235e-02
    x_5_2     onehot_5_131  1
    x_5_2     stock_lb_246  2
    x_5_2     stock_ub_247  2
    x_5_2     parent_nonstrict_scope_248  3.2582383061853147e-02
    x_5_2     unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_103  1
    w_5_2     product_ub_104  1
    w_5_2     normalized_mass_5_132  1
    w_5_2     normalized_ratio_5_133  -2.8571428571428570e-01
    w_5_2     full_original_Gini_306  -15.8797619047619
    MARKER    'MARKER'                 'INTORG'
    x_5_3     product_lb_105  -2.5336309344246841e-02
    x_5_3     product_ub_106  -4.3435544754167235e-02
    x_5_3     onehot_5_131  1
    x_5_3     stock_lb_246  3
    x_5_3     stock_ub_247  3
    x_5_3     parent_nonstrict_scope_248  2.6065906449482514e-02
    x_5_3     unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_105  1
    w_5_3     product_ub_106  1
    w_5_3     normalized_mass_5_132  1
    w_5_3     normalized_ratio_5_133  -4.2857142857142855e-01
    w_5_3     full_original_Gini_306  -1.2498809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     OBJ       -6.5164766123706266e-03
    x_5_4     product_lb_107  -2.5336309344246841e-02
    x_5_4     product_ub_108  -4.3435544754167235e-02
    x_5_4     onehot_5_131  1
    x_5_4     stock_lb_246  4
    x_5_4     stock_ub_247  4
    x_5_4     parent_nonstrict_scope_248  1.9549429837111887e-02
    x_5_4     unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_107  1
    w_5_4     product_ub_108  1
    w_5_4     normalized_mass_5_132  1
    w_5_4     normalized_ratio_5_133  -5.7142857142857140e-01
    w_5_4     full_original_Gini_306  -9.21309523809524
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.3032953224741252e-02
    x_5_5     product_lb_109  -2.5336309344246841e-02
    x_5_5     product_ub_110  -4.3435544754167235e-02
    x_5_5     onehot_5_131  1
    x_5_5     stock_lb_246  5
    x_5_5     stock_ub_247  5
    x_5_5     parent_nonstrict_scope_248  1.3032953224741262e-02
    x_5_5     unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_109  1
    w_5_5     product_ub_110  1
    w_5_5     normalized_mass_5_132  1
    w_5_5     normalized_ratio_5_133  -7.1428571428571419e-01
    w_5_5     full_original_Gini_306  -6.0226190476190462e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -1.9549429837111883e-02
    x_5_6     product_lb_111  -2.5336309344246841e-02
    x_5_6     product_ub_112  -4.3435544754167235e-02
    x_5_6     onehot_5_131  1
    x_5_6     stock_lb_246  6
    x_5_6     stock_ub_247  6
    x_5_6     parent_nonstrict_scope_248  6.5164766123706310e-03
    x_5_6     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_111  1
    w_5_6     product_ub_112  1
    w_5_6     normalized_mass_5_132  1
    w_5_6     normalized_ratio_5_133  -8.5714285714285710e-01
    w_5_6     full_original_Gini_306  -4.8702380952380944e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -2.6065906449482514e-02
    x_5_7     product_lb_113  -2.5336309344246841e-02
    x_5_7     product_ub_114  -4.3435544754167235e-02
    x_5_7     onehot_5_131  1
    x_5_7     stock_lb_246  7
    x_5_7     stock_ub_247  7
    x_5_7     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_113  1
    w_5_7     product_ub_114  1
    w_5_7     normalized_mass_5_132  1
    w_5_7     normalized_ratio_5_133  -1
    w_5_7     full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -1.9549429837111887e-02
    x_5_8     product_lb_115  -2.5336309344246841e-02
    x_5_8     product_ub_116  -4.3435544754167235e-02
    x_5_8     onehot_5_131  1
    x_5_8     stock_lb_246  8
    x_5_8     stock_ub_247  8
    x_5_8     parent_nonstrict_scope_248  6.5164766123706258e-03
    x_5_8     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_115  1
    w_5_8     product_ub_116  1
    w_5_8     normalized_mass_5_132  1
    w_5_8     normalized_ratio_5_133  -1.1428571428571428e+00
    w_5_8     full_original_Gini_306  -8.54880952380952
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -1.3032953224741262e-02
    x_5_9     product_lb_117  -2.5336309344246841e-02
    x_5_9     product_ub_118  -4.3435544754167235e-02
    x_5_9     onehot_5_131  1
    x_5_9     stock_lb_246  9
    x_5_9     stock_ub_247  9
    x_5_9     parent_nonstrict_scope_248  1.3032953224741252e-02
    x_5_9     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_117  1
    w_5_9     product_ub_118  1
    w_5_9     normalized_mass_5_132  1
    w_5_9     normalized_ratio_5_133  -1.2857142857142856e+00
    w_5_9     full_original_Gini_306  -1.2120238095238090e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -6.5164766123706371e-03
    x_5_10    product_lb_119  -2.5336309344246841e-02
    x_5_10    product_ub_120  -4.3435544754167235e-02
    x_5_10    onehot_5_131  1
    x_5_10    stock_lb_246  10
    x_5_10    stock_ub_247  10
    x_5_10    parent_nonstrict_scope_248  1.9549429837111876e-02
    x_5_10    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_119  1
    w_5_10    product_ub_120  1
    w_5_10    normalized_mass_5_132  1
    w_5_10    normalized_ratio_5_133  -1.4285714285714284e+00
    w_5_10    full_original_Gini_306  -1.5691666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_11    product_lb_121  -2.5336309344246841e-02
    x_5_11    product_ub_122  -4.3435544754167235e-02
    x_5_11    onehot_5_131  1
    x_5_11    stock_lb_246  11
    x_5_11    stock_ub_247  11
    x_5_11    parent_nonstrict_scope_248  2.6065906449482514e-02
    x_5_11    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_121  1
    w_5_11    product_ub_122  1
    w_5_11    normalized_mass_5_132  1
    w_5_11    normalized_ratio_5_133  -1.5714285714285714e+00
    w_5_11    full_original_Gini_306  -1.9405952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    OBJ       6.5164766123706266e-03
    x_5_12    product_lb_123  -2.5336309344246841e-02
    x_5_12    product_ub_124  -4.3435544754167235e-02
    x_5_12    onehot_5_131  1
    x_5_12    stock_lb_246  12
    x_5_12    stock_ub_247  12
    x_5_12    parent_nonstrict_scope_248  3.2582383061853140e-02
    x_5_12    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_123  1
    w_5_12    product_ub_124  1
    w_5_12    normalized_mass_5_132  1
    w_5_12    normalized_ratio_5_133  -1.7142857142857142e+00
    w_5_12    full_original_Gini_306  -2.3263095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.3032953224741253e-02
    x_5_13    product_lb_125  -2.5336309344246841e-02
    x_5_13    product_ub_126  -4.3435544754167235e-02
    x_5_13    onehot_5_131  1
    x_5_13    stock_lb_246  13
    x_5_13    stock_ub_247  13
    x_5_13    parent_nonstrict_scope_248  3.9098859674223767e-02
    x_5_13    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_125  1
    w_5_13    product_ub_126  1
    w_5_13    normalized_mass_5_132  1
    w_5_13    normalized_ratio_5_133  -1.8571428571428570e+00
    w_5_13    full_original_Gini_306  -2.7120238095238097e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       1.9549429837111887e-02
    x_5_14    product_lb_127  -2.5336309344246841e-02
    x_5_14    product_ub_128  -4.3435544754167235e-02
    x_5_14    onehot_5_131  1
    x_5_14    stock_lb_246  14
    x_5_14    stock_ub_247  14
    x_5_14    parent_nonstrict_scope_248  0.0456153362865944
    x_5_14    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_127  1
    w_5_14    product_ub_128  1
    w_5_14    normalized_mass_5_132  1
    w_5_14    normalized_ratio_5_133  -2
    w_5_14    full_original_Gini_306  -3.0977380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       2.6065906449482514e-02
    x_5_15    product_lb_129  -2.5336309344246841e-02
    x_5_15    product_ub_130  -4.3435544754167235e-02
    x_5_15    onehot_5_131  1
    x_5_15    stock_lb_246  15
    x_5_15    stock_ub_247  15
    x_5_15    parent_nonstrict_scope_248  5.2131812898965027e-02
    x_5_15    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_129  1
    w_5_15    product_ub_130  1
    w_5_15    normalized_mass_5_132  1
    w_5_15    normalized_ratio_5_133  -2.1428571428571428e+00
    w_5_15    full_original_Gini_306  -34.8345238095238
    rho_5     normalized_ratio_5_133  1
    rho_5     block_pair_pos_253  1
    rho_5     block_pair_neg_254  -1
    rho_5     block_pair_pos_265  1
    rho_5     block_pair_neg_266  -1
    rho_5     block_pair_pos_275  -1
    rho_5     block_pair_neg_276  1
    rho_5     block_pair_pos_277  -1
    rho_5     block_pair_neg_278  1
    rho_5     block_pair_pos_279  -1
    rho_5     block_pair_neg_280  1
    rho_5     block_pair_pos_281  -1
    rho_5     block_pair_neg_282  1
    rho_5     block_pair_pos_297  1
    rho_5     block_pair_neg_298  -1
    rho_5     normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_134  -2.5336309344246841e-02
    x_29_0    product_ub_135  -4.3435544754167235e-02
    x_29_0    onehot_29_156  1
    x_29_0    parent_nonstrict_scope_248  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_134  1
    w_29_0    product_ub_135  1
    w_29_0    normalized_mass_29_157  1
    w_29_0    full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_136  -2.5336309344246841e-02
    x_29_1    product_ub_137  -4.3435544754167235e-02
    x_29_1    onehot_29_156  1
    x_29_1    stock_lb_246  1
    x_29_1    stock_ub_247  1
    x_29_1    parent_nonstrict_scope_248  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_136  1
    w_29_1    product_ub_137  1
    w_29_1    normalized_mass_29_157  1
    w_29_1    normalized_ratio_29_158  -0.2
    w_29_1    full_original_Gini_306  -1.8022619047619052e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_138  -2.5336309344246841e-02
    x_29_2    product_ub_139  -4.3435544754167235e-02
    x_29_2    onehot_29_156  1
    x_29_2    stock_lb_246  2
    x_29_2    stock_ub_247  2
    x_29_2    parent_nonstrict_scope_248  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_138  1
    w_29_2    product_ub_139  1
    w_29_2    normalized_mass_29_157  1
    w_29_2    normalized_ratio_29_158  -0.4
    w_29_2    full_original_Gini_306  -1.3155952380952378e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_140  -2.5336309344246841e-02
    x_29_3    product_ub_141  -4.3435544754167235e-02
    x_29_3    onehot_29_156  1
    x_29_3    stock_lb_246  3
    x_29_3    stock_ub_247  3
    x_29_3    parent_nonstrict_scope_248  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_140  1
    w_29_3    product_ub_141  1
    w_29_3    normalized_mass_29_157  1
    w_29_3    normalized_ratio_29_158  -6.0000000000000009e-01
    w_29_3    full_original_Gini_306  -8.55595238095238
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_142  -2.5336309344246841e-02
    x_29_4    product_ub_143  -4.3435544754167235e-02
    x_29_4    onehot_29_156  1
    x_29_4    stock_lb_246  4
    x_29_4    stock_ub_247  4
    x_29_4    parent_nonstrict_scope_248  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_142  1
    w_29_4    product_ub_143  1
    w_29_4    normalized_mass_29_157  1
    w_29_4    normalized_ratio_29_158  -0.8
    w_29_4    full_original_Gini_306  -4.9940476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_144  -2.5336309344246841e-02
    x_29_5    product_ub_145  -4.3435544754167235e-02
    x_29_5    onehot_29_156  1
    x_29_5    stock_lb_246  5
    x_29_5    stock_ub_247  5
    x_29_5    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_144  1
    w_29_5    product_ub_145  1
    w_29_5    normalized_mass_29_157  1
    w_29_5    normalized_ratio_29_158  -1
    w_29_5    full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_146  -2.5336309344246841e-02
    x_29_6    product_ub_147  -4.3435544754167235e-02
    x_29_6    onehot_29_156  1
    x_29_6    stock_lb_246  6
    x_29_6    stock_ub_247  6
    x_29_6    parent_nonstrict_scope_248  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_146  1
    w_29_6    product_ub_147  1
    w_29_6    normalized_mass_29_157  1
    w_29_6    normalized_ratio_29_158  -1.2000000000000002e+00
    w_29_6    full_original_Gini_306  -9.9773809523809547e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_148  -2.5336309344246841e-02
    x_29_7    product_ub_149  -4.3435544754167235e-02
    x_29_7    onehot_29_156  1
    x_29_7    stock_lb_246  7
    x_29_7    stock_ub_247  7
    x_29_7    parent_nonstrict_scope_248  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_148  1
    w_29_7    product_ub_149  1
    w_29_7    normalized_mass_29_157  1
    w_29_7    normalized_ratio_29_158  -1.4000000000000001e+00
    w_29_7    full_original_Gini_306  -1.4977380952380958e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_150  -2.5336309344246841e-02
    x_29_8    product_ub_151  -4.3435544754167235e-02
    x_29_8    onehot_29_156  1
    x_29_8    stock_lb_246  8
    x_29_8    stock_ub_247  8
    x_29_8    parent_nonstrict_scope_248  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_150  1
    w_29_8    product_ub_151  1
    w_29_8    normalized_mass_29_157  1
    w_29_8    normalized_ratio_29_158  -1.6
    w_29_8    full_original_Gini_306  -2.0177380952380954e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_152  -2.5336309344246841e-02
    x_29_9    product_ub_153  -4.3435544754167235e-02
    x_29_9    onehot_29_156  1
    x_29_9    stock_lb_246  9
    x_29_9    stock_ub_247  9
    x_29_9    parent_nonstrict_scope_248  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_152  1
    w_29_9    product_ub_153  1
    w_29_9    normalized_mass_29_157  1
    w_29_9    normalized_ratio_29_158  -1.8
    w_29_9    full_original_Gini_306  -2.5577380952380960e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_154  -2.5336309344246841e-02
    x_29_10   product_ub_155  -4.3435544754167235e-02
    x_29_10   onehot_29_156  1
    x_29_10   stock_lb_246  10
    x_29_10   stock_ub_247  10
    x_29_10   parent_nonstrict_scope_248  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_154  1
    w_29_10   product_ub_155  1
    w_29_10   normalized_mass_29_157  1
    w_29_10   normalized_ratio_29_158  -2
    w_29_10   full_original_Gini_306  -3.0977380952380951e+01
    rho_29    normalized_ratio_29_158  1
    rho_29    block_pair_pos_259  1
    rho_29    block_pair_neg_260  -1
    rho_29    block_pair_pos_271  1
    rho_29    block_pair_neg_272  -1
    rho_29    block_pair_pos_281  1
    rho_29    block_pair_neg_282  -1
    rho_29    block_pair_pos_289  -1
    rho_29    block_pair_neg_290  1
    rho_29    block_pair_pos_291  -1
    rho_29    block_pair_neg_292  1
    rho_29    block_pair_pos_293  -1
    rho_29    block_pair_neg_294  1
    rho_29    block_pair_pos_303  1
    rho_29    block_pair_neg_304  -1
    rho_29    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       1.9549429837111887e-02
    x_7_0     product_lb_159  -2.5336309344246841e-02
    x_7_0     product_ub_160  -4.3435544754167235e-02
    x_7_0     onehot_7_191  1
    x_7_0     parent_nonstrict_scope_248  0.0456153362865944
    x_7_0     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_159  1
    w_7_0     product_ub_160  1
    w_7_0     normalized_mass_7_192  1
    w_7_0     full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       1.3032953224741260e-02
    x_7_1     product_lb_161  -2.5336309344246841e-02
    x_7_1     product_ub_162  -4.3435544754167235e-02
    x_7_1     onehot_7_191  1
    x_7_1     stock_lb_246  1
    x_7_1     stock_ub_247  1
    x_7_1     parent_nonstrict_scope_248  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_161  1
    w_7_1     product_ub_162  1
    w_7_1     normalized_mass_7_192  1
    w_7_1     normalized_ratio_7_193  -1.4285714285714285e-01
    w_7_1     full_original_Gini_306  -1.9451190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       6.5164766123706336e-03
    x_7_2     product_lb_163  -2.5336309344246841e-02
    x_7_2     product_ub_164  -4.3435544754167235e-02
    x_7_2     onehot_7_191  1
    x_7_2     stock_lb_246  2
    x_7_2     stock_ub_247  2
    x_7_2     parent_nonstrict_scope_248  3.2582383061853147e-02
    x_7_2     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_163  1
    w_7_2     product_ub_164  1
    w_7_2     normalized_mass_7_192  1
    w_7_2     normalized_ratio_7_193  -2.8571428571428570e-01
    w_7_2     full_original_Gini_306  -15.8797619047619
    MARKER    'MARKER'                 'INTORG'
    x_7_3     product_lb_165  -2.5336309344246841e-02
    x_7_3     product_ub_166  -4.3435544754167235e-02
    x_7_3     onehot_7_191  1
    x_7_3     stock_lb_246  3
    x_7_3     stock_ub_247  3
    x_7_3     parent_nonstrict_scope_248  2.6065906449482514e-02
    x_7_3     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_165  1
    w_7_3     product_ub_166  1
    w_7_3     normalized_mass_7_192  1
    w_7_3     normalized_ratio_7_193  -4.2857142857142855e-01
    w_7_3     full_original_Gini_306  -1.2498809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -6.5164766123706266e-03
    x_7_4     product_lb_167  -2.5336309344246841e-02
    x_7_4     product_ub_168  -4.3435544754167235e-02
    x_7_4     onehot_7_191  1
    x_7_4     stock_lb_246  4
    x_7_4     stock_ub_247  4
    x_7_4     parent_nonstrict_scope_248  1.9549429837111887e-02
    x_7_4     unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_167  1
    w_7_4     product_ub_168  1
    w_7_4     normalized_mass_7_192  1
    w_7_4     normalized_ratio_7_193  -5.7142857142857140e-01
    w_7_4     full_original_Gini_306  -9.21309523809524
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.3032953224741252e-02
    x_7_5     product_lb_169  -2.5336309344246841e-02
    x_7_5     product_ub_170  -4.3435544754167235e-02
    x_7_5     onehot_7_191  1
    x_7_5     stock_lb_246  5
    x_7_5     stock_ub_247  5
    x_7_5     parent_nonstrict_scope_248  1.3032953224741262e-02
    x_7_5     unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_169  1
    w_7_5     product_ub_170  1
    w_7_5     normalized_mass_7_192  1
    w_7_5     normalized_ratio_7_193  -7.1428571428571419e-01
    w_7_5     full_original_Gini_306  -6.0226190476190462e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -1.9549429837111883e-02
    x_7_6     product_lb_171  -2.5336309344246841e-02
    x_7_6     product_ub_172  -4.3435544754167235e-02
    x_7_6     onehot_7_191  1
    x_7_6     stock_lb_246  6
    x_7_6     stock_ub_247  6
    x_7_6     parent_nonstrict_scope_248  6.5164766123706310e-03
    x_7_6     unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_171  1
    w_7_6     product_ub_172  1
    w_7_6     normalized_mass_7_192  1
    w_7_6     normalized_ratio_7_193  -8.5714285714285710e-01
    w_7_6     full_original_Gini_306  -4.8702380952380944e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -2.6065906449482514e-02
    x_7_7     product_lb_173  -2.5336309344246841e-02
    x_7_7     product_ub_174  -4.3435544754167235e-02
    x_7_7     onehot_7_191  1
    x_7_7     stock_lb_246  7
    x_7_7     stock_ub_247  7
    x_7_7     unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_173  1
    w_7_7     product_ub_174  1
    w_7_7     normalized_mass_7_192  1
    w_7_7     normalized_ratio_7_193  -1
    w_7_7     full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -1.9549429837111887e-02
    x_7_8     product_lb_175  -2.5336309344246841e-02
    x_7_8     product_ub_176  -4.3435544754167235e-02
    x_7_8     onehot_7_191  1
    x_7_8     stock_lb_246  8
    x_7_8     stock_ub_247  8
    x_7_8     parent_nonstrict_scope_248  6.5164766123706258e-03
    x_7_8     unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_175  1
    w_7_8     product_ub_176  1
    w_7_8     normalized_mass_7_192  1
    w_7_8     normalized_ratio_7_193  -1.1428571428571428e+00
    w_7_8     full_original_Gini_306  -8.54880952380952
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -1.3032953224741262e-02
    x_7_9     product_lb_177  -2.5336309344246841e-02
    x_7_9     product_ub_178  -4.3435544754167235e-02
    x_7_9     onehot_7_191  1
    x_7_9     stock_lb_246  9
    x_7_9     stock_ub_247  9
    x_7_9     parent_nonstrict_scope_248  1.3032953224741252e-02
    x_7_9     unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_177  1
    w_7_9     product_ub_178  1
    w_7_9     normalized_mass_7_192  1
    w_7_9     normalized_ratio_7_193  -1.2857142857142856e+00
    w_7_9     full_original_Gini_306  -1.2120238095238090e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -6.5164766123706371e-03
    x_7_10    product_lb_179  -2.5336309344246841e-02
    x_7_10    product_ub_180  -4.3435544754167235e-02
    x_7_10    onehot_7_191  1
    x_7_10    stock_lb_246  10
    x_7_10    stock_ub_247  10
    x_7_10    parent_nonstrict_scope_248  1.9549429837111876e-02
    x_7_10    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_179  1
    w_7_10    product_ub_180  1
    w_7_10    normalized_mass_7_192  1
    w_7_10    normalized_ratio_7_193  -1.4285714285714284e+00
    w_7_10    full_original_Gini_306  -1.5691666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    product_lb_181  -2.5336309344246841e-02
    x_7_11    product_ub_182  -4.3435544754167235e-02
    x_7_11    onehot_7_191  1
    x_7_11    stock_lb_246  11
    x_7_11    stock_ub_247  11
    x_7_11    parent_nonstrict_scope_248  2.6065906449482514e-02
    x_7_11    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_181  1
    w_7_11    product_ub_182  1
    w_7_11    normalized_mass_7_192  1
    w_7_11    normalized_ratio_7_193  -1.5714285714285714e+00
    w_7_11    full_original_Gini_306  -1.9405952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       6.5164766123706266e-03
    x_7_12    product_lb_183  -2.5336309344246841e-02
    x_7_12    product_ub_184  -4.3435544754167235e-02
    x_7_12    onehot_7_191  1
    x_7_12    stock_lb_246  12
    x_7_12    stock_ub_247  12
    x_7_12    parent_nonstrict_scope_248  3.2582383061853140e-02
    x_7_12    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_183  1
    w_7_12    product_ub_184  1
    w_7_12    normalized_mass_7_192  1
    w_7_12    normalized_ratio_7_193  -1.7142857142857142e+00
    w_7_12    full_original_Gini_306  -2.3263095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       1.3032953224741253e-02
    x_7_13    product_lb_185  -2.5336309344246841e-02
    x_7_13    product_ub_186  -4.3435544754167235e-02
    x_7_13    onehot_7_191  1
    x_7_13    stock_lb_246  13
    x_7_13    stock_ub_247  13
    x_7_13    parent_nonstrict_scope_248  3.9098859674223767e-02
    x_7_13    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_185  1
    w_7_13    product_ub_186  1
    w_7_13    normalized_mass_7_192  1
    w_7_13    normalized_ratio_7_193  -1.8571428571428570e+00
    w_7_13    full_original_Gini_306  -2.7120238095238097e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.9549429837111887e-02
    x_7_14    product_lb_187  -2.5336309344246841e-02
    x_7_14    product_ub_188  -4.3435544754167235e-02
    x_7_14    onehot_7_191  1
    x_7_14    stock_lb_246  14
    x_7_14    stock_ub_247  14
    x_7_14    parent_nonstrict_scope_248  0.0456153362865944
    x_7_14    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_187  1
    w_7_14    product_ub_188  1
    w_7_14    normalized_mass_7_192  1
    w_7_14    normalized_ratio_7_193  -2
    w_7_14    full_original_Gini_306  -3.0977380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       2.6065906449482514e-02
    x_7_15    product_lb_189  -2.5336309344246841e-02
    x_7_15    product_ub_190  -4.3435544754167235e-02
    x_7_15    onehot_7_191  1
    x_7_15    stock_lb_246  15
    x_7_15    stock_ub_247  15
    x_7_15    parent_nonstrict_scope_248  5.2131812898965027e-02
    x_7_15    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_189  1
    w_7_15    product_ub_190  1
    w_7_15    normalized_mass_7_192  1
    w_7_15    normalized_ratio_7_193  -2.1428571428571428e+00
    w_7_15    full_original_Gini_306  -34.8345238095238
    rho_7     normalized_ratio_7_193  1
    rho_7     block_pair_pos_255  1
    rho_7     block_pair_neg_256  -1
    rho_7     block_pair_pos_267  1
    rho_7     block_pair_neg_268  -1
    rho_7     block_pair_pos_277  1
    rho_7     block_pair_neg_278  -1
    rho_7     block_pair_pos_283  -1
    rho_7     block_pair_neg_284  1
    rho_7     block_pair_pos_285  -1
    rho_7     block_pair_neg_286  1
    rho_7     block_pair_pos_291  1
    rho_7     block_pair_neg_292  -1
    rho_7     block_pair_pos_299  1
    rho_7     block_pair_neg_300  -1
    rho_7     normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_194  -2.5336309344246841e-02
    x_27_0    product_ub_195  -4.3435544754167235e-02
    x_27_0    onehot_27_208  1
    x_27_0    parent_nonstrict_scope_248  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_194  1
    w_27_0    product_ub_195  1
    w_27_0    normalized_mass_27_209  1
    w_27_0    full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_196  -2.5336309344246841e-02
    x_27_1    product_ub_197  -4.3435544754167235e-02
    x_27_1    onehot_27_208  1
    x_27_1    stock_lb_246  1
    x_27_1    stock_ub_247  1
    x_27_1    parent_nonstrict_scope_248  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_196  1
    w_27_1    product_ub_197  1
    w_27_1    normalized_mass_27_209  1
    w_27_1    normalized_ratio_27_210  -3.3333333333333331e-01
    w_27_1    full_original_Gini_306  -1.4689285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_198  -2.5336309344246841e-02
    x_27_2    product_ub_199  -4.3435544754167235e-02
    x_27_2    onehot_27_208  1
    x_27_2    stock_lb_246  2
    x_27_2    stock_ub_247  2
    x_27_2    parent_nonstrict_scope_248  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_198  1
    w_27_2    product_ub_199  1
    w_27_2    normalized_mass_27_209  1
    w_27_2    normalized_ratio_27_210  -6.6666666666666663e-01
    w_27_2    full_original_Gini_306  -7.0226190476190471e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_200  -2.5336309344246841e-02
    x_27_3    product_ub_201  -4.3435544754167235e-02
    x_27_3    onehot_27_208  1
    x_27_3    stock_lb_246  3
    x_27_3    stock_ub_247  3
    x_27_3    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_200  1
    w_27_3    product_ub_201  1
    w_27_3    normalized_mass_27_209  1
    w_27_3    normalized_ratio_27_210  -1
    w_27_3    full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_202  -2.5336309344246841e-02
    x_27_4    product_ub_203  -4.3435544754167235e-02
    x_27_4    onehot_27_208  1
    x_27_4    stock_lb_246  4
    x_27_4    stock_ub_247  4
    x_27_4    parent_nonstrict_scope_248  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_202  1
    w_27_4    product_ub_203  1
    w_27_4    normalized_mass_27_209  1
    w_27_4    normalized_ratio_27_210  -1.3333333333333333e+00
    w_27_4    full_original_Gini_306  -1.3310714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_204  -2.5336309344246841e-02
    x_27_5    product_ub_205  -4.3435544754167235e-02
    x_27_5    onehot_27_208  1
    x_27_5    stock_lb_246  5
    x_27_5    stock_ub_247  5
    x_27_5    parent_nonstrict_scope_248  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_204  1
    w_27_5    product_ub_205  1
    w_27_5    normalized_mass_27_209  1
    w_27_5    normalized_ratio_27_210  -1.6666666666666665e+00
    w_27_5    full_original_Gini_306  -2.1977380952380948e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_206  -2.5336309344246841e-02
    x_27_6    product_ub_207  -4.3435544754167235e-02
    x_27_6    onehot_27_208  1
    x_27_6    stock_lb_246  6
    x_27_6    stock_ub_247  6
    x_27_6    parent_nonstrict_scope_248  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_206  1
    w_27_6    product_ub_207  1
    w_27_6    normalized_mass_27_209  1
    w_27_6    normalized_ratio_27_210  -2
    w_27_6    full_original_Gini_306  -3.0977380952380951e+01
    rho_27    normalized_ratio_27_210  1
    rho_27    block_pair_pos_257  1
    rho_27    block_pair_neg_258  -1
    rho_27    block_pair_pos_269  1
    rho_27    block_pair_neg_270  -1
    rho_27    block_pair_pos_279  1
    rho_27    block_pair_neg_280  -1
    rho_27    block_pair_pos_285  1
    rho_27    block_pair_neg_286  -1
    rho_27    block_pair_pos_287  -1
    rho_27    block_pair_neg_288  1
    rho_27    block_pair_pos_293  1
    rho_27    block_pair_neg_294  -1
    rho_27    block_pair_pos_301  1
    rho_27    block_pair_neg_302  -1
    rho_27    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       1.9549429837111887e-02
    x_2_0     product_lb_211  -2.5336309344246841e-02
    x_2_0     product_ub_212  -4.3435544754167235e-02
    x_2_0     onehot_2_243  1
    x_2_0     parent_nonstrict_scope_248  0.0456153362865944
    x_2_0     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_211  1
    w_2_0     product_ub_212  1
    w_2_0     normalized_mass_2_244  1
    w_2_0     full_original_Gini_306  -2.3022619047619049e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       1.3032953224741260e-02
    x_2_1     product_lb_213  -2.5336309344246841e-02
    x_2_1     product_ub_214  -4.3435544754167235e-02
    x_2_1     onehot_2_243  1
    x_2_1     stock_lb_246  1
    x_2_1     stock_ub_247  1
    x_2_1     parent_nonstrict_scope_248  3.9098859674223774e-02
    x_2_1     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_213  1
    w_2_1     product_ub_214  1
    w_2_1     normalized_mass_2_244  1
    w_2_1     normalized_ratio_2_245  -1.4285714285714285e-01
    w_2_1     full_original_Gini_306  -1.9451190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       6.5164766123706336e-03
    x_2_2     product_lb_215  -2.5336309344246841e-02
    x_2_2     product_ub_216  -4.3435544754167235e-02
    x_2_2     onehot_2_243  1
    x_2_2     stock_lb_246  2
    x_2_2     stock_ub_247  2
    x_2_2     parent_nonstrict_scope_248  3.2582383061853147e-02
    x_2_2     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_215  1
    w_2_2     product_ub_216  1
    w_2_2     normalized_mass_2_244  1
    w_2_2     normalized_ratio_2_245  -2.8571428571428570e-01
    w_2_2     full_original_Gini_306  -15.8797619047619
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_217  -2.5336309344246841e-02
    x_2_3     product_ub_218  -4.3435544754167235e-02
    x_2_3     onehot_2_243  1
    x_2_3     stock_lb_246  3
    x_2_3     stock_ub_247  3
    x_2_3     parent_nonstrict_scope_248  2.6065906449482514e-02
    x_2_3     unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_217  1
    w_2_3     product_ub_218  1
    w_2_3     normalized_mass_2_244  1
    w_2_3     normalized_ratio_2_245  -4.2857142857142855e-01
    w_2_3     full_original_Gini_306  -1.2498809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -6.5164766123706266e-03
    x_2_4     product_lb_219  -2.5336309344246841e-02
    x_2_4     product_ub_220  -4.3435544754167235e-02
    x_2_4     onehot_2_243  1
    x_2_4     stock_lb_246  4
    x_2_4     stock_ub_247  4
    x_2_4     parent_nonstrict_scope_248  1.9549429837111887e-02
    x_2_4     unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_219  1
    w_2_4     product_ub_220  1
    w_2_4     normalized_mass_2_244  1
    w_2_4     normalized_ratio_2_245  -5.7142857142857140e-01
    w_2_4     full_original_Gini_306  -9.21309523809524
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -1.3032953224741252e-02
    x_2_5     product_lb_221  -2.5336309344246841e-02
    x_2_5     product_ub_222  -4.3435544754167235e-02
    x_2_5     onehot_2_243  1
    x_2_5     stock_lb_246  5
    x_2_5     stock_ub_247  5
    x_2_5     parent_nonstrict_scope_248  1.3032953224741262e-02
    x_2_5     unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_221  1
    w_2_5     product_ub_222  1
    w_2_5     normalized_mass_2_244  1
    w_2_5     normalized_ratio_2_245  -7.1428571428571419e-01
    w_2_5     full_original_Gini_306  -6.0226190476190462e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -1.9549429837111883e-02
    x_2_6     product_lb_223  -2.5336309344246841e-02
    x_2_6     product_ub_224  -4.3435544754167235e-02
    x_2_6     onehot_2_243  1
    x_2_6     stock_lb_246  6
    x_2_6     stock_ub_247  6
    x_2_6     parent_nonstrict_scope_248  6.5164766123706310e-03
    x_2_6     unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_223  1
    w_2_6     product_ub_224  1
    w_2_6     normalized_mass_2_244  1
    w_2_6     normalized_ratio_2_245  -8.5714285714285710e-01
    w_2_6     full_original_Gini_306  -4.8702380952380944e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -2.6065906449482514e-02
    x_2_7     product_lb_225  -2.5336309344246841e-02
    x_2_7     product_ub_226  -4.3435544754167235e-02
    x_2_7     onehot_2_243  1
    x_2_7     stock_lb_246  7
    x_2_7     stock_ub_247  7
    x_2_7     unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_225  1
    w_2_7     product_ub_226  1
    w_2_7     normalized_mass_2_244  1
    w_2_7     normalized_ratio_2_245  -1
    w_2_7     full_original_Gini_306  -4.9773809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -1.9549429837111887e-02
    x_2_8     product_lb_227  -2.5336309344246841e-02
    x_2_8     product_ub_228  -4.3435544754167235e-02
    x_2_8     onehot_2_243  1
    x_2_8     stock_lb_246  8
    x_2_8     stock_ub_247  8
    x_2_8     parent_nonstrict_scope_248  6.5164766123706258e-03
    x_2_8     unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_227  1
    w_2_8     product_ub_228  1
    w_2_8     normalized_mass_2_244  1
    w_2_8     normalized_ratio_2_245  -1.1428571428571428e+00
    w_2_8     full_original_Gini_306  -8.54880952380952
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -1.3032953224741262e-02
    x_2_9     product_lb_229  -2.5336309344246841e-02
    x_2_9     product_ub_230  -4.3435544754167235e-02
    x_2_9     onehot_2_243  1
    x_2_9     stock_lb_246  9
    x_2_9     stock_ub_247  9
    x_2_9     parent_nonstrict_scope_248  1.3032953224741252e-02
    x_2_9     unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_229  1
    w_2_9     product_ub_230  1
    w_2_9     normalized_mass_2_244  1
    w_2_9     normalized_ratio_2_245  -1.2857142857142856e+00
    w_2_9     full_original_Gini_306  -1.2120238095238090e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -6.5164766123706371e-03
    x_2_10    product_lb_231  -2.5336309344246841e-02
    x_2_10    product_ub_232  -4.3435544754167235e-02
    x_2_10    onehot_2_243  1
    x_2_10    stock_lb_246  10
    x_2_10    stock_ub_247  10
    x_2_10    parent_nonstrict_scope_248  1.9549429837111876e-02
    x_2_10    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_231  1
    w_2_10    product_ub_232  1
    w_2_10    normalized_mass_2_244  1
    w_2_10    normalized_ratio_2_245  -1.4285714285714284e+00
    w_2_10    full_original_Gini_306  -1.5691666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_233  -2.5336309344246841e-02
    x_2_11    product_ub_234  -4.3435544754167235e-02
    x_2_11    onehot_2_243  1
    x_2_11    stock_lb_246  11
    x_2_11    stock_ub_247  11
    x_2_11    parent_nonstrict_scope_248  2.6065906449482514e-02
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_233  1
    w_2_11    product_ub_234  1
    w_2_11    normalized_mass_2_244  1
    w_2_11    normalized_ratio_2_245  -1.5714285714285714e+00
    w_2_11    full_original_Gini_306  -1.9405952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       6.5164766123706266e-03
    x_2_12    product_lb_235  -2.5336309344246841e-02
    x_2_12    product_ub_236  -4.3435544754167235e-02
    x_2_12    onehot_2_243  1
    x_2_12    stock_lb_246  12
    x_2_12    stock_ub_247  12
    x_2_12    parent_nonstrict_scope_248  3.2582383061853140e-02
    x_2_12    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_235  1
    w_2_12    product_ub_236  1
    w_2_12    normalized_mass_2_244  1
    w_2_12    normalized_ratio_2_245  -1.7142857142857142e+00
    w_2_12    full_original_Gini_306  -2.3263095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       1.3032953224741253e-02
    x_2_13    product_lb_237  -2.5336309344246841e-02
    x_2_13    product_ub_238  -4.3435544754167235e-02
    x_2_13    onehot_2_243  1
    x_2_13    stock_lb_246  13
    x_2_13    stock_ub_247  13
    x_2_13    parent_nonstrict_scope_248  3.9098859674223767e-02
    x_2_13    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_237  1
    w_2_13    product_ub_238  1
    w_2_13    normalized_mass_2_244  1
    w_2_13    normalized_ratio_2_245  -1.8571428571428570e+00
    w_2_13    full_original_Gini_306  -2.7120238095238097e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       1.9549429837111887e-02
    x_2_14    product_lb_239  -2.5336309344246841e-02
    x_2_14    product_ub_240  -4.3435544754167235e-02
    x_2_14    onehot_2_243  1
    x_2_14    stock_lb_246  14
    x_2_14    stock_ub_247  14
    x_2_14    parent_nonstrict_scope_248  0.0456153362865944
    x_2_14    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_239  1
    w_2_14    product_ub_240  1
    w_2_14    normalized_mass_2_244  1
    w_2_14    normalized_ratio_2_245  -2
    w_2_14    full_original_Gini_306  -3.0977380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       2.6065906449482514e-02
    x_2_15    product_lb_241  -2.5336309344246841e-02
    x_2_15    product_ub_242  -4.3435544754167235e-02
    x_2_15    onehot_2_243  1
    x_2_15    stock_lb_246  15
    x_2_15    stock_ub_247  15
    x_2_15    parent_nonstrict_scope_248  5.2131812898965027e-02
    x_2_15    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_241  1
    w_2_15    product_ub_242  1
    w_2_15    normalized_mass_2_244  1
    w_2_15    normalized_ratio_2_245  -2.1428571428571428e+00
    w_2_15    full_original_Gini_306  -34.8345238095238
    rho_2     normalized_ratio_2_245  1
    rho_2     block_pair_pos_249  1
    rho_2     block_pair_neg_250  -1
    rho_2     block_pair_pos_263  1
    rho_2     block_pair_neg_264  -1
    rho_2     block_pair_pos_275  1
    rho_2     block_pair_neg_276  -1
    rho_2     block_pair_pos_283  1
    rho_2     block_pair_neg_284  -1
    rho_2     block_pair_pos_287  1
    rho_2     block_pair_neg_288  -1
    rho_2     block_pair_pos_289  1
    rho_2     block_pair_neg_290  -1
    rho_2     block_pair_pos_295  1
    rho_2     block_pair_neg_296  -1
    rho_2     normalization_305  1
    a_3_4     block_pair_pos_251  1
    a_3_4     block_pair_neg_252  1
    a_3_4     full_original_Gini_306  -1
    a_3_34    block_pair_pos_261  1
    a_3_34    block_pair_neg_262  1
    a_3_34    full_original_Gini_306  -1
    a_3_5     block_pair_pos_253  1
    a_3_5     block_pair_neg_254  1
    a_3_5     full_original_Gini_306  -1
    a_3_29    block_pair_pos_259  1
    a_3_29    block_pair_neg_260  1
    a_3_29    full_original_Gini_306  -1
    a_3_7     block_pair_pos_255  1
    a_3_7     block_pair_neg_256  1
    a_3_7     full_original_Gini_306  -1
    a_3_27    block_pair_pos_257  1
    a_3_27    block_pair_neg_258  1
    a_3_27    full_original_Gini_306  -1
    a_3_2     block_pair_pos_249  1
    a_3_2     block_pair_neg_250  1
    a_3_2     full_original_Gini_306  -1
    a_4_34    block_pair_pos_273  1
    a_4_34    block_pair_neg_274  1
    a_4_34    full_original_Gini_306  -1
    a_4_5     block_pair_pos_265  1
    a_4_5     block_pair_neg_266  1
    a_4_5     full_original_Gini_306  -1
    a_4_29    block_pair_pos_271  1
    a_4_29    block_pair_neg_272  1
    a_4_29    full_original_Gini_306  -1
    a_4_7     block_pair_pos_267  1
    a_4_7     block_pair_neg_268  1
    a_4_7     full_original_Gini_306  -1
    a_4_27    block_pair_pos_269  1
    a_4_27    block_pair_neg_270  1
    a_4_27    full_original_Gini_306  -1
    a_4_2     block_pair_pos_263  1
    a_4_2     block_pair_neg_264  1
    a_4_2     full_original_Gini_306  -1
    a_34_5    block_pair_pos_297  1
    a_34_5    block_pair_neg_298  1
    a_34_5    full_original_Gini_306  -1
    a_34_29   block_pair_pos_303  1
    a_34_29   block_pair_neg_304  1
    a_34_29   full_original_Gini_306  -1
    a_34_7    block_pair_pos_299  1
    a_34_7    block_pair_neg_300  1
    a_34_7    full_original_Gini_306  -1
    a_34_27   block_pair_pos_301  1
    a_34_27   block_pair_neg_302  1
    a_34_27   full_original_Gini_306  -1
    a_34_2    block_pair_pos_295  1
    a_34_2    block_pair_neg_296  1
    a_34_2    full_original_Gini_306  -1
    a_5_29    block_pair_pos_281  1
    a_5_29    block_pair_neg_282  1
    a_5_29    full_original_Gini_306  -1
    a_5_7     block_pair_pos_277  1
    a_5_7     block_pair_neg_278  1
    a_5_7     full_original_Gini_306  -1
    a_5_27    block_pair_pos_279  1
    a_5_27    block_pair_neg_280  1
    a_5_27    full_original_Gini_306  -1
    a_5_2     block_pair_pos_275  1
    a_5_2     block_pair_neg_276  1
    a_5_2     full_original_Gini_306  -1
    a_29_7    block_pair_pos_291  1
    a_29_7    block_pair_neg_292  1
    a_29_7    full_original_Gini_306  -1
    a_29_27   block_pair_pos_293  1
    a_29_27   block_pair_neg_294  1
    a_29_27   full_original_Gini_306  -1
    a_29_2    block_pair_pos_289  1
    a_29_2    block_pair_neg_290  1
    a_29_2    full_original_Gini_306  -1
    a_7_27    block_pair_pos_285  1
    a_7_27    block_pair_neg_286  1
    a_7_27    full_original_Gini_306  -1
    a_7_2     block_pair_pos_283  1
    a_7_2     block_pair_neg_284  1
    a_7_2     full_original_Gini_306  -1
    a_27_2    block_pair_pos_287  1
    a_27_2    block_pair_neg_288  1
    a_27_2    full_original_Gini_306  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_3_0  unique_nonzero_owner_307  1
    service_0_3_0  service_visit_def_790  1
    service_0_3_0  free_load_conservation_791  -9
    service_0_3_0  original_T_including_depot_unload_838  1080
    service_0_3_1  unique_nonzero_owner_308  1
    service_0_3_1  service_visit_def_790  1
    service_0_3_1  free_load_conservation_791  -8
    service_0_3_1  original_T_including_depot_unload_838  960
    service_0_3_2  unique_nonzero_owner_309  1
    service_0_3_2  service_visit_def_790  1
    service_0_3_2  free_load_conservation_791  -7
    service_0_3_2  original_T_including_depot_unload_838  840
    service_0_3_3  unique_nonzero_owner_310  1
    service_0_3_3  service_visit_def_790  1
    service_0_3_3  free_load_conservation_791  -6
    service_0_3_3  original_T_including_depot_unload_838  720
    service_0_3_4  unique_nonzero_owner_311  1
    service_0_3_4  service_visit_def_790  1
    service_0_3_4  free_load_conservation_791  -5
    service_0_3_4  original_T_including_depot_unload_838  600
    service_0_3_5  unique_nonzero_owner_312  1
    service_0_3_5  service_visit_def_790  1
    service_0_3_5  free_load_conservation_791  -4
    service_0_3_5  original_T_including_depot_unload_838  480
    service_0_3_6  unique_nonzero_owner_313  1
    service_0_3_6  service_visit_def_790  1
    service_0_3_6  free_load_conservation_791  -3
    service_0_3_6  original_T_including_depot_unload_838  360
    service_0_3_7  unique_nonzero_owner_314  1
    service_0_3_7  service_visit_def_790  1
    service_0_3_7  free_load_conservation_791  -2
    service_0_3_7  original_T_including_depot_unload_838  240
    service_0_3_8  unique_nonzero_owner_315  1
    service_0_3_8  service_visit_def_790  1
    service_0_3_8  free_load_conservation_791  -1
    service_0_3_8  original_T_including_depot_unload_838  120
    service_0_3_10  unique_nonzero_owner_316  1
    service_0_3_10  service_visit_def_790  1
    service_0_3_10  free_load_conservation_791  1
    service_0_3_11  unique_nonzero_owner_317  1
    service_0_3_11  service_visit_def_790  1
    service_0_3_11  free_load_conservation_791  2
    service_0_3_12  unique_nonzero_owner_318  1
    service_0_3_12  service_visit_def_790  1
    service_0_3_12  free_load_conservation_791  3
    service_1_3_0  unique_nonzero_owner_307  1
    service_1_3_0  service_visit_def_1162  1
    service_1_3_0  free_load_conservation_1163  -9
    service_1_3_0  original_T_including_depot_unload_1209  1080
    service_1_3_1  unique_nonzero_owner_308  1
    service_1_3_1  service_visit_def_1162  1
    service_1_3_1  free_load_conservation_1163  -8
    service_1_3_1  original_T_including_depot_unload_1209  960
    service_1_3_2  unique_nonzero_owner_309  1
    service_1_3_2  service_visit_def_1162  1
    service_1_3_2  free_load_conservation_1163  -7
    service_1_3_2  original_T_including_depot_unload_1209  840
    service_1_3_3  unique_nonzero_owner_310  1
    service_1_3_3  service_visit_def_1162  1
    service_1_3_3  free_load_conservation_1163  -6
    service_1_3_3  original_T_including_depot_unload_1209  720
    service_1_3_4  unique_nonzero_owner_311  1
    service_1_3_4  service_visit_def_1162  1
    service_1_3_4  free_load_conservation_1163  -5
    service_1_3_4  original_T_including_depot_unload_1209  600
    service_1_3_5  unique_nonzero_owner_312  1
    service_1_3_5  service_visit_def_1162  1
    service_1_3_5  free_load_conservation_1163  -4
    service_1_3_5  original_T_including_depot_unload_1209  480
    service_1_3_6  unique_nonzero_owner_313  1
    service_1_3_6  service_visit_def_1162  1
    service_1_3_6  free_load_conservation_1163  -3
    service_1_3_6  original_T_including_depot_unload_1209  360
    service_1_3_7  unique_nonzero_owner_314  1
    service_1_3_7  service_visit_def_1162  1
    service_1_3_7  free_load_conservation_1163  -2
    service_1_3_7  original_T_including_depot_unload_1209  240
    service_1_3_8  unique_nonzero_owner_315  1
    service_1_3_8  service_visit_def_1162  1
    service_1_3_8  free_load_conservation_1163  -1
    service_1_3_8  original_T_including_depot_unload_1209  120
    service_1_3_10  unique_nonzero_owner_316  1
    service_1_3_10  service_visit_def_1162  1
    service_1_3_10  free_load_conservation_1163  1
    service_1_3_11  unique_nonzero_owner_317  1
    service_1_3_11  service_visit_def_1162  1
    service_1_3_11  free_load_conservation_1163  2
    service_1_3_12  unique_nonzero_owner_318  1
    service_1_3_12  service_visit_def_1162  1
    service_1_3_12  free_load_conservation_1163  3
    service_2_3_0  unique_nonzero_owner_307  1
    service_2_3_0  service_visit_def_1533  1
    service_2_3_0  free_load_conservation_1534  -9
    service_2_3_0  original_T_including_depot_unload_1580  1080
    service_2_3_1  unique_nonzero_owner_308  1
    service_2_3_1  service_visit_def_1533  1
    service_2_3_1  free_load_conservation_1534  -8
    service_2_3_1  original_T_including_depot_unload_1580  960
    service_2_3_2  unique_nonzero_owner_309  1
    service_2_3_2  service_visit_def_1533  1
    service_2_3_2  free_load_conservation_1534  -7
    service_2_3_2  original_T_including_depot_unload_1580  840
    service_2_3_3  unique_nonzero_owner_310  1
    service_2_3_3  service_visit_def_1533  1
    service_2_3_3  free_load_conservation_1534  -6
    service_2_3_3  original_T_including_depot_unload_1580  720
    service_2_3_4  unique_nonzero_owner_311  1
    service_2_3_4  service_visit_def_1533  1
    service_2_3_4  free_load_conservation_1534  -5
    service_2_3_4  original_T_including_depot_unload_1580  600
    service_2_3_5  unique_nonzero_owner_312  1
    service_2_3_5  service_visit_def_1533  1
    service_2_3_5  free_load_conservation_1534  -4
    service_2_3_5  original_T_including_depot_unload_1580  480
    service_2_3_6  unique_nonzero_owner_313  1
    service_2_3_6  service_visit_def_1533  1
    service_2_3_6  free_load_conservation_1534  -3
    service_2_3_6  original_T_including_depot_unload_1580  360
    service_2_3_7  unique_nonzero_owner_314  1
    service_2_3_7  service_visit_def_1533  1
    service_2_3_7  free_load_conservation_1534  -2
    service_2_3_7  original_T_including_depot_unload_1580  240
    service_2_3_8  unique_nonzero_owner_315  1
    service_2_3_8  service_visit_def_1533  1
    service_2_3_8  free_load_conservation_1534  -1
    service_2_3_8  original_T_including_depot_unload_1580  120
    service_2_3_10  unique_nonzero_owner_316  1
    service_2_3_10  service_visit_def_1533  1
    service_2_3_10  free_load_conservation_1534  1
    service_2_3_11  unique_nonzero_owner_317  1
    service_2_3_11  service_visit_def_1533  1
    service_2_3_11  free_load_conservation_1534  2
    service_2_3_12  unique_nonzero_owner_318  1
    service_2_3_12  service_visit_def_1533  1
    service_2_3_12  free_load_conservation_1534  3
    service_0_4_0  unique_nonzero_owner_319  1
    service_0_4_0  service_visit_def_796  1
    service_0_4_0  free_load_conservation_797  -2
    service_0_4_0  original_T_including_depot_unload_838  240
    service_0_4_1  unique_nonzero_owner_320  1
    service_0_4_1  service_visit_def_796  1
    service_0_4_1  free_load_conservation_797  -1
    service_0_4_1  original_T_including_depot_unload_838  120
    service_0_4_3  unique_nonzero_owner_321  1
    service_0_4_3  service_visit_def_796  1
    service_0_4_3  free_load_conservation_797  1
    service_0_4_4  unique_nonzero_owner_322  1
    service_0_4_4  service_visit_def_796  1
    service_0_4_4  free_load_conservation_797  2
    service_0_4_5  unique_nonzero_owner_323  1
    service_0_4_5  service_visit_def_796  1
    service_0_4_5  free_load_conservation_797  3
    service_0_4_6  unique_nonzero_owner_324  1
    service_0_4_6  service_visit_def_796  1
    service_0_4_6  free_load_conservation_797  4
    service_0_4_7  unique_nonzero_owner_325  1
    service_0_4_7  service_visit_def_796  1
    service_0_4_7  free_load_conservation_797  5
    service_0_4_8  unique_nonzero_owner_326  1
    service_0_4_8  service_visit_def_796  1
    service_0_4_8  free_load_conservation_797  6
    service_0_4_9  unique_nonzero_owner_327  1
    service_0_4_9  service_visit_def_796  1
    service_0_4_9  free_load_conservation_797  7
    service_0_4_10  unique_nonzero_owner_328  1
    service_0_4_10  service_visit_def_796  1
    service_0_4_10  free_load_conservation_797  8
    service_0_4_11  unique_nonzero_owner_329  1
    service_0_4_11  service_visit_def_796  1
    service_0_4_11  free_load_conservation_797  9
    service_0_4_12  unique_nonzero_owner_330  1
    service_0_4_12  service_visit_def_796  1
    service_0_4_12  free_load_conservation_797  10
    service_0_4_13  unique_nonzero_owner_331  1
    service_0_4_13  service_visit_def_796  1
    service_0_4_13  free_load_conservation_797  11
    service_0_4_14  unique_nonzero_owner_332  1
    service_0_4_14  service_visit_def_796  1
    service_0_4_14  free_load_conservation_797  12
    service_0_4_15  unique_nonzero_owner_333  1
    service_0_4_15  service_visit_def_796  1
    service_0_4_15  free_load_conservation_797  13
    service_1_4_0  unique_nonzero_owner_319  1
    service_1_4_0  service_visit_def_1168  1
    service_1_4_0  free_load_conservation_1169  -2
    service_1_4_0  original_T_including_depot_unload_1209  240
    service_1_4_1  unique_nonzero_owner_320  1
    service_1_4_1  service_visit_def_1168  1
    service_1_4_1  free_load_conservation_1169  -1
    service_1_4_1  original_T_including_depot_unload_1209  120
    service_1_4_3  unique_nonzero_owner_321  1
    service_1_4_3  service_visit_def_1168  1
    service_1_4_3  free_load_conservation_1169  1
    service_1_4_4  unique_nonzero_owner_322  1
    service_1_4_4  service_visit_def_1168  1
    service_1_4_4  free_load_conservation_1169  2
    service_1_4_5  unique_nonzero_owner_323  1
    service_1_4_5  service_visit_def_1168  1
    service_1_4_5  free_load_conservation_1169  3
    service_1_4_6  unique_nonzero_owner_324  1
    service_1_4_6  service_visit_def_1168  1
    service_1_4_6  free_load_conservation_1169  4
    service_1_4_7  unique_nonzero_owner_325  1
    service_1_4_7  service_visit_def_1168  1
    service_1_4_7  free_load_conservation_1169  5
    service_1_4_8  unique_nonzero_owner_326  1
    service_1_4_8  service_visit_def_1168  1
    service_1_4_8  free_load_conservation_1169  6
    service_1_4_9  unique_nonzero_owner_327  1
    service_1_4_9  service_visit_def_1168  1
    service_1_4_9  free_load_conservation_1169  7
    service_1_4_10  unique_nonzero_owner_328  1
    service_1_4_10  service_visit_def_1168  1
    service_1_4_10  free_load_conservation_1169  8
    service_1_4_11  unique_nonzero_owner_329  1
    service_1_4_11  service_visit_def_1168  1
    service_1_4_11  free_load_conservation_1169  9
    service_1_4_12  unique_nonzero_owner_330  1
    service_1_4_12  service_visit_def_1168  1
    service_1_4_12  free_load_conservation_1169  10
    service_1_4_13  unique_nonzero_owner_331  1
    service_1_4_13  service_visit_def_1168  1
    service_1_4_13  free_load_conservation_1169  11
    service_1_4_14  unique_nonzero_owner_332  1
    service_1_4_14  service_visit_def_1168  1
    service_1_4_14  free_load_conservation_1169  12
    service_1_4_15  unique_nonzero_owner_333  1
    service_1_4_15  service_visit_def_1168  1
    service_1_4_15  free_load_conservation_1169  13
    service_2_4_0  unique_nonzero_owner_319  1
    service_2_4_0  service_visit_def_1539  1
    service_2_4_0  free_load_conservation_1540  -2
    service_2_4_0  original_T_including_depot_unload_1580  240
    service_2_4_1  unique_nonzero_owner_320  1
    service_2_4_1  service_visit_def_1539  1
    service_2_4_1  free_load_conservation_1540  -1
    service_2_4_1  original_T_including_depot_unload_1580  120
    service_2_4_3  unique_nonzero_owner_321  1
    service_2_4_3  service_visit_def_1539  1
    service_2_4_3  free_load_conservation_1540  1
    service_2_4_4  unique_nonzero_owner_322  1
    service_2_4_4  service_visit_def_1539  1
    service_2_4_4  free_load_conservation_1540  2
    service_2_4_5  unique_nonzero_owner_323  1
    service_2_4_5  service_visit_def_1539  1
    service_2_4_5  free_load_conservation_1540  3
    service_2_4_6  unique_nonzero_owner_324  1
    service_2_4_6  service_visit_def_1539  1
    service_2_4_6  free_load_conservation_1540  4
    service_2_4_7  unique_nonzero_owner_325  1
    service_2_4_7  service_visit_def_1539  1
    service_2_4_7  free_load_conservation_1540  5
    service_2_4_8  unique_nonzero_owner_326  1
    service_2_4_8  service_visit_def_1539  1
    service_2_4_8  free_load_conservation_1540  6
    service_2_4_9  unique_nonzero_owner_327  1
    service_2_4_9  service_visit_def_1539  1
    service_2_4_9  free_load_conservation_1540  7
    service_2_4_10  unique_nonzero_owner_328  1
    service_2_4_10  service_visit_def_1539  1
    service_2_4_10  free_load_conservation_1540  8
    service_2_4_11  unique_nonzero_owner_329  1
    service_2_4_11  service_visit_def_1539  1
    service_2_4_11  free_load_conservation_1540  9
    service_2_4_12  unique_nonzero_owner_330  1
    service_2_4_12  service_visit_def_1539  1
    service_2_4_12  free_load_conservation_1540  10
    service_2_4_13  unique_nonzero_owner_331  1
    service_2_4_13  service_visit_def_1539  1
    service_2_4_13  free_load_conservation_1540  11
    service_2_4_14  unique_nonzero_owner_332  1
    service_2_4_14  service_visit_def_1539  1
    service_2_4_14  free_load_conservation_1540  12
    service_2_4_15  unique_nonzero_owner_333  1
    service_2_4_15  service_visit_def_1539  1
    service_2_4_15  free_load_conservation_1540  13
    service_0_34_0  unique_nonzero_owner_334  1
    service_0_34_0  service_visit_def_802  1
    service_0_34_0  free_load_conservation_803  -2
    service_0_34_0  original_T_including_depot_unload_838  240
    service_0_34_1  unique_nonzero_owner_335  1
    service_0_34_1  service_visit_def_802  1
    service_0_34_1  free_load_conservation_803  -1
    service_0_34_1  original_T_including_depot_unload_838  120
    service_0_34_3  unique_nonzero_owner_336  1
    service_0_34_3  service_visit_def_802  1
    service_0_34_3  free_load_conservation_803  1
    service_0_34_4  unique_nonzero_owner_337  1
    service_0_34_4  service_visit_def_802  1
    service_0_34_4  free_load_conservation_803  2
    service_0_34_5  unique_nonzero_owner_338  1
    service_0_34_5  service_visit_def_802  1
    service_0_34_5  free_load_conservation_803  3
    service_0_34_6  unique_nonzero_owner_339  1
    service_0_34_6  service_visit_def_802  1
    service_0_34_6  free_load_conservation_803  4
    service_0_34_7  unique_nonzero_owner_340  1
    service_0_34_7  service_visit_def_802  1
    service_0_34_7  free_load_conservation_803  5
    service_0_34_8  unique_nonzero_owner_341  1
    service_0_34_8  service_visit_def_802  1
    service_0_34_8  free_load_conservation_803  6
    service_0_34_9  unique_nonzero_owner_342  1
    service_0_34_9  service_visit_def_802  1
    service_0_34_9  free_load_conservation_803  7
    service_0_34_10  unique_nonzero_owner_343  1
    service_0_34_10  service_visit_def_802  1
    service_0_34_10  free_load_conservation_803  8
    service_0_34_11  unique_nonzero_owner_344  1
    service_0_34_11  service_visit_def_802  1
    service_0_34_11  free_load_conservation_803  9
    service_0_34_12  unique_nonzero_owner_345  1
    service_0_34_12  service_visit_def_802  1
    service_0_34_12  free_load_conservation_803  10
    service_0_34_13  unique_nonzero_owner_346  1
    service_0_34_13  service_visit_def_802  1
    service_0_34_13  free_load_conservation_803  11
    service_0_34_14  unique_nonzero_owner_347  1
    service_0_34_14  service_visit_def_802  1
    service_0_34_14  free_load_conservation_803  12
    service_0_34_15  unique_nonzero_owner_348  1
    service_0_34_15  service_visit_def_802  1
    service_0_34_15  free_load_conservation_803  13
    service_1_34_0  unique_nonzero_owner_334  1
    service_1_34_0  service_visit_def_1174  1
    service_1_34_0  free_load_conservation_1175  -2
    service_1_34_0  original_T_including_depot_unload_1209  240
    service_1_34_1  unique_nonzero_owner_335  1
    service_1_34_1  service_visit_def_1174  1
    service_1_34_1  free_load_conservation_1175  -1
    service_1_34_1  original_T_including_depot_unload_1209  120
    service_1_34_3  unique_nonzero_owner_336  1
    service_1_34_3  service_visit_def_1174  1
    service_1_34_3  free_load_conservation_1175  1
    service_1_34_4  unique_nonzero_owner_337  1
    service_1_34_4  service_visit_def_1174  1
    service_1_34_4  free_load_conservation_1175  2
    service_1_34_5  unique_nonzero_owner_338  1
    service_1_34_5  service_visit_def_1174  1
    service_1_34_5  free_load_conservation_1175  3
    service_1_34_6  unique_nonzero_owner_339  1
    service_1_34_6  service_visit_def_1174  1
    service_1_34_6  free_load_conservation_1175  4
    service_1_34_7  unique_nonzero_owner_340  1
    service_1_34_7  service_visit_def_1174  1
    service_1_34_7  free_load_conservation_1175  5
    service_1_34_8  unique_nonzero_owner_341  1
    service_1_34_8  service_visit_def_1174  1
    service_1_34_8  free_load_conservation_1175  6
    service_1_34_9  unique_nonzero_owner_342  1
    service_1_34_9  service_visit_def_1174  1
    service_1_34_9  free_load_conservation_1175  7
    service_1_34_10  unique_nonzero_owner_343  1
    service_1_34_10  service_visit_def_1174  1
    service_1_34_10  free_load_conservation_1175  8
    service_1_34_11  unique_nonzero_owner_344  1
    service_1_34_11  service_visit_def_1174  1
    service_1_34_11  free_load_conservation_1175  9
    service_1_34_12  unique_nonzero_owner_345  1
    service_1_34_12  service_visit_def_1174  1
    service_1_34_12  free_load_conservation_1175  10
    service_1_34_13  unique_nonzero_owner_346  1
    service_1_34_13  service_visit_def_1174  1
    service_1_34_13  free_load_conservation_1175  11
    service_1_34_14  unique_nonzero_owner_347  1
    service_1_34_14  service_visit_def_1174  1
    service_1_34_14  free_load_conservation_1175  12
    service_1_34_15  unique_nonzero_owner_348  1
    service_1_34_15  service_visit_def_1174  1
    service_1_34_15  free_load_conservation_1175  13
    service_2_34_0  unique_nonzero_owner_334  1
    service_2_34_0  service_visit_def_1545  1
    service_2_34_0  free_load_conservation_1546  -2
    service_2_34_0  original_T_including_depot_unload_1580  240
    service_2_34_1  unique_nonzero_owner_335  1
    service_2_34_1  service_visit_def_1545  1
    service_2_34_1  free_load_conservation_1546  -1
    service_2_34_1  original_T_including_depot_unload_1580  120
    service_2_34_3  unique_nonzero_owner_336  1
    service_2_34_3  service_visit_def_1545  1
    service_2_34_3  free_load_conservation_1546  1
    service_2_34_4  unique_nonzero_owner_337  1
    service_2_34_4  service_visit_def_1545  1
    service_2_34_4  free_load_conservation_1546  2
    service_2_34_5  unique_nonzero_owner_338  1
    service_2_34_5  service_visit_def_1545  1
    service_2_34_5  free_load_conservation_1546  3
    service_2_34_6  unique_nonzero_owner_339  1
    service_2_34_6  service_visit_def_1545  1
    service_2_34_6  free_load_conservation_1546  4
    service_2_34_7  unique_nonzero_owner_340  1
    service_2_34_7  service_visit_def_1545  1
    service_2_34_7  free_load_conservation_1546  5
    service_2_34_8  unique_nonzero_owner_341  1
    service_2_34_8  service_visit_def_1545  1
    service_2_34_8  free_load_conservation_1546  6
    service_2_34_9  unique_nonzero_owner_342  1
    service_2_34_9  service_visit_def_1545  1
    service_2_34_9  free_load_conservation_1546  7
    service_2_34_10  unique_nonzero_owner_343  1
    service_2_34_10  service_visit_def_1545  1
    service_2_34_10  free_load_conservation_1546  8
    service_2_34_11  unique_nonzero_owner_344  1
    service_2_34_11  service_visit_def_1545  1
    service_2_34_11  free_load_conservation_1546  9
    service_2_34_12  unique_nonzero_owner_345  1
    service_2_34_12  service_visit_def_1545  1
    service_2_34_12  free_load_conservation_1546  10
    service_2_34_13  unique_nonzero_owner_346  1
    service_2_34_13  service_visit_def_1545  1
    service_2_34_13  free_load_conservation_1546  11
    service_2_34_14  unique_nonzero_owner_347  1
    service_2_34_14  service_visit_def_1545  1
    service_2_34_14  free_load_conservation_1546  12
    service_2_34_15  unique_nonzero_owner_348  1
    service_2_34_15  service_visit_def_1545  1
    service_2_34_15  free_load_conservation_1546  13
    service_0_5_0  unique_nonzero_owner_349  1
    service_0_5_0  service_visit_def_808  1
    service_0_5_0  free_load_conservation_809  -1
    service_0_5_0  original_T_including_depot_unload_838  120
    service_0_5_2  unique_nonzero_owner_350  1
    service_0_5_2  service_visit_def_808  1
    service_0_5_2  free_load_conservation_809  1
    service_0_5_3  unique_nonzero_owner_351  1
    service_0_5_3  service_visit_def_808  1
    service_0_5_3  free_load_conservation_809  2
    service_0_5_4  unique_nonzero_owner_352  1
    service_0_5_4  service_visit_def_808  1
    service_0_5_4  free_load_conservation_809  3
    service_0_5_5  unique_nonzero_owner_353  1
    service_0_5_5  service_visit_def_808  1
    service_0_5_5  free_load_conservation_809  4
    service_0_5_6  unique_nonzero_owner_354  1
    service_0_5_6  service_visit_def_808  1
    service_0_5_6  free_load_conservation_809  5
    service_0_5_7  unique_nonzero_owner_355  1
    service_0_5_7  service_visit_def_808  1
    service_0_5_7  free_load_conservation_809  6
    service_0_5_8  unique_nonzero_owner_356  1
    service_0_5_8  service_visit_def_808  1
    service_0_5_8  free_load_conservation_809  7
    service_0_5_9  unique_nonzero_owner_357  1
    service_0_5_9  service_visit_def_808  1
    service_0_5_9  free_load_conservation_809  8
    service_0_5_10  unique_nonzero_owner_358  1
    service_0_5_10  service_visit_def_808  1
    service_0_5_10  free_load_conservation_809  9
    service_0_5_11  unique_nonzero_owner_359  1
    service_0_5_11  service_visit_def_808  1
    service_0_5_11  free_load_conservation_809  10
    service_0_5_12  unique_nonzero_owner_360  1
    service_0_5_12  service_visit_def_808  1
    service_0_5_12  free_load_conservation_809  11
    service_0_5_13  unique_nonzero_owner_361  1
    service_0_5_13  service_visit_def_808  1
    service_0_5_13  free_load_conservation_809  12
    service_0_5_14  unique_nonzero_owner_362  1
    service_0_5_14  service_visit_def_808  1
    service_0_5_14  free_load_conservation_809  13
    service_0_5_15  unique_nonzero_owner_363  1
    service_0_5_15  service_visit_def_808  1
    service_0_5_15  free_load_conservation_809  14
    service_1_5_0  unique_nonzero_owner_349  1
    service_1_5_0  service_visit_def_1180  1
    service_1_5_0  free_load_conservation_1181  -1
    service_1_5_0  original_T_including_depot_unload_1209  120
    service_1_5_2  unique_nonzero_owner_350  1
    service_1_5_2  service_visit_def_1180  1
    service_1_5_2  free_load_conservation_1181  1
    service_1_5_3  unique_nonzero_owner_351  1
    service_1_5_3  service_visit_def_1180  1
    service_1_5_3  free_load_conservation_1181  2
    service_1_5_4  unique_nonzero_owner_352  1
    service_1_5_4  service_visit_def_1180  1
    service_1_5_4  free_load_conservation_1181  3
    service_1_5_5  unique_nonzero_owner_353  1
    service_1_5_5  service_visit_def_1180  1
    service_1_5_5  free_load_conservation_1181  4
    service_1_5_6  unique_nonzero_owner_354  1
    service_1_5_6  service_visit_def_1180  1
    service_1_5_6  free_load_conservation_1181  5
    service_1_5_7  unique_nonzero_owner_355  1
    service_1_5_7  service_visit_def_1180  1
    service_1_5_7  free_load_conservation_1181  6
    service_1_5_8  unique_nonzero_owner_356  1
    service_1_5_8  service_visit_def_1180  1
    service_1_5_8  free_load_conservation_1181  7
    service_1_5_9  unique_nonzero_owner_357  1
    service_1_5_9  service_visit_def_1180  1
    service_1_5_9  free_load_conservation_1181  8
    service_1_5_10  unique_nonzero_owner_358  1
    service_1_5_10  service_visit_def_1180  1
    service_1_5_10  free_load_conservation_1181  9
    service_1_5_11  unique_nonzero_owner_359  1
    service_1_5_11  service_visit_def_1180  1
    service_1_5_11  free_load_conservation_1181  10
    service_1_5_12  unique_nonzero_owner_360  1
    service_1_5_12  service_visit_def_1180  1
    service_1_5_12  free_load_conservation_1181  11
    service_1_5_13  unique_nonzero_owner_361  1
    service_1_5_13  service_visit_def_1180  1
    service_1_5_13  free_load_conservation_1181  12
    service_1_5_14  unique_nonzero_owner_362  1
    service_1_5_14  service_visit_def_1180  1
    service_1_5_14  free_load_conservation_1181  13
    service_1_5_15  unique_nonzero_owner_363  1
    service_1_5_15  service_visit_def_1180  1
    service_1_5_15  free_load_conservation_1181  14
    service_2_5_0  unique_nonzero_owner_349  1
    service_2_5_0  service_visit_def_1551  1
    service_2_5_0  free_load_conservation_1552  -1
    service_2_5_0  original_T_including_depot_unload_1580  120
    service_2_5_2  unique_nonzero_owner_350  1
    service_2_5_2  service_visit_def_1551  1
    service_2_5_2  free_load_conservation_1552  1
    service_2_5_3  unique_nonzero_owner_351  1
    service_2_5_3  service_visit_def_1551  1
    service_2_5_3  free_load_conservation_1552  2
    service_2_5_4  unique_nonzero_owner_352  1
    service_2_5_4  service_visit_def_1551  1
    service_2_5_4  free_load_conservation_1552  3
    service_2_5_5  unique_nonzero_owner_353  1
    service_2_5_5  service_visit_def_1551  1
    service_2_5_5  free_load_conservation_1552  4
    service_2_5_6  unique_nonzero_owner_354  1
    service_2_5_6  service_visit_def_1551  1
    service_2_5_6  free_load_conservation_1552  5
    service_2_5_7  unique_nonzero_owner_355  1
    service_2_5_7  service_visit_def_1551  1
    service_2_5_7  free_load_conservation_1552  6
    service_2_5_8  unique_nonzero_owner_356  1
    service_2_5_8  service_visit_def_1551  1
    service_2_5_8  free_load_conservation_1552  7
    service_2_5_9  unique_nonzero_owner_357  1
    service_2_5_9  service_visit_def_1551  1
    service_2_5_9  free_load_conservation_1552  8
    service_2_5_10  unique_nonzero_owner_358  1
    service_2_5_10  service_visit_def_1551  1
    service_2_5_10  free_load_conservation_1552  9
    service_2_5_11  unique_nonzero_owner_359  1
    service_2_5_11  service_visit_def_1551  1
    service_2_5_11  free_load_conservation_1552  10
    service_2_5_12  unique_nonzero_owner_360  1
    service_2_5_12  service_visit_def_1551  1
    service_2_5_12  free_load_conservation_1552  11
    service_2_5_13  unique_nonzero_owner_361  1
    service_2_5_13  service_visit_def_1551  1
    service_2_5_13  free_load_conservation_1552  12
    service_2_5_14  unique_nonzero_owner_362  1
    service_2_5_14  service_visit_def_1551  1
    service_2_5_14  free_load_conservation_1552  13
    service_2_5_15  unique_nonzero_owner_363  1
    service_2_5_15  service_visit_def_1551  1
    service_2_5_15  free_load_conservation_1552  14
    service_0_29_0  unique_nonzero_owner_364  1
    service_0_29_0  service_visit_def_814  1
    service_0_29_0  free_load_conservation_815  -1
    service_0_29_0  original_T_including_depot_unload_838  120
    service_0_29_2  unique_nonzero_owner_365  1
    service_0_29_2  service_visit_def_814  1
    service_0_29_2  free_load_conservation_815  1
    service_0_29_3  unique_nonzero_owner_366  1
    service_0_29_3  service_visit_def_814  1
    service_0_29_3  free_load_conservation_815  2
    service_0_29_4  unique_nonzero_owner_367  1
    service_0_29_4  service_visit_def_814  1
    service_0_29_4  free_load_conservation_815  3
    service_0_29_5  unique_nonzero_owner_368  1
    service_0_29_5  service_visit_def_814  1
    service_0_29_5  free_load_conservation_815  4
    service_0_29_6  unique_nonzero_owner_369  1
    service_0_29_6  service_visit_def_814  1
    service_0_29_6  free_load_conservation_815  5
    service_0_29_7  unique_nonzero_owner_370  1
    service_0_29_7  service_visit_def_814  1
    service_0_29_7  free_load_conservation_815  6
    service_0_29_8  unique_nonzero_owner_371  1
    service_0_29_8  service_visit_def_814  1
    service_0_29_8  free_load_conservation_815  7
    service_0_29_9  unique_nonzero_owner_372  1
    service_0_29_9  service_visit_def_814  1
    service_0_29_9  free_load_conservation_815  8
    service_0_29_10  unique_nonzero_owner_373  1
    service_0_29_10  service_visit_def_814  1
    service_0_29_10  free_load_conservation_815  9
    service_1_29_0  unique_nonzero_owner_364  1
    service_1_29_0  service_visit_def_1186  1
    service_1_29_0  free_load_conservation_1187  -1
    service_1_29_0  original_T_including_depot_unload_1209  120
    service_1_29_2  unique_nonzero_owner_365  1
    service_1_29_2  service_visit_def_1186  1
    service_1_29_2  free_load_conservation_1187  1
    service_1_29_3  unique_nonzero_owner_366  1
    service_1_29_3  service_visit_def_1186  1
    service_1_29_3  free_load_conservation_1187  2
    service_1_29_4  unique_nonzero_owner_367  1
    service_1_29_4  service_visit_def_1186  1
    service_1_29_4  free_load_conservation_1187  3
    service_1_29_5  unique_nonzero_owner_368  1
    service_1_29_5  service_visit_def_1186  1
    service_1_29_5  free_load_conservation_1187  4
    service_1_29_6  unique_nonzero_owner_369  1
    service_1_29_6  service_visit_def_1186  1
    service_1_29_6  free_load_conservation_1187  5
    service_1_29_7  unique_nonzero_owner_370  1
    service_1_29_7  service_visit_def_1186  1
    service_1_29_7  free_load_conservation_1187  6
    service_1_29_8  unique_nonzero_owner_371  1
    service_1_29_8  service_visit_def_1186  1
    service_1_29_8  free_load_conservation_1187  7
    service_1_29_9  unique_nonzero_owner_372  1
    service_1_29_9  service_visit_def_1186  1
    service_1_29_9  free_load_conservation_1187  8
    service_1_29_10  unique_nonzero_owner_373  1
    service_1_29_10  service_visit_def_1186  1
    service_1_29_10  free_load_conservation_1187  9
    service_2_29_0  unique_nonzero_owner_364  1
    service_2_29_0  service_visit_def_1557  1
    service_2_29_0  free_load_conservation_1558  -1
    service_2_29_0  original_T_including_depot_unload_1580  120
    service_2_29_2  unique_nonzero_owner_365  1
    service_2_29_2  service_visit_def_1557  1
    service_2_29_2  free_load_conservation_1558  1
    service_2_29_3  unique_nonzero_owner_366  1
    service_2_29_3  service_visit_def_1557  1
    service_2_29_3  free_load_conservation_1558  2
    service_2_29_4  unique_nonzero_owner_367  1
    service_2_29_4  service_visit_def_1557  1
    service_2_29_4  free_load_conservation_1558  3
    service_2_29_5  unique_nonzero_owner_368  1
    service_2_29_5  service_visit_def_1557  1
    service_2_29_5  free_load_conservation_1558  4
    service_2_29_6  unique_nonzero_owner_369  1
    service_2_29_6  service_visit_def_1557  1
    service_2_29_6  free_load_conservation_1558  5
    service_2_29_7  unique_nonzero_owner_370  1
    service_2_29_7  service_visit_def_1557  1
    service_2_29_7  free_load_conservation_1558  6
    service_2_29_8  unique_nonzero_owner_371  1
    service_2_29_8  service_visit_def_1557  1
    service_2_29_8  free_load_conservation_1558  7
    service_2_29_9  unique_nonzero_owner_372  1
    service_2_29_9  service_visit_def_1557  1
    service_2_29_9  free_load_conservation_1558  8
    service_2_29_10  unique_nonzero_owner_373  1
    service_2_29_10  service_visit_def_1557  1
    service_2_29_10  free_load_conservation_1558  9
    service_0_7_0  unique_nonzero_owner_374  1
    service_0_7_0  service_visit_def_820  1
    service_0_7_0  free_load_conservation_821  -1
    service_0_7_0  original_T_including_depot_unload_838  120
    service_0_7_2  unique_nonzero_owner_375  1
    service_0_7_2  service_visit_def_820  1
    service_0_7_2  free_load_conservation_821  1
    service_0_7_3  unique_nonzero_owner_376  1
    service_0_7_3  service_visit_def_820  1
    service_0_7_3  free_load_conservation_821  2
    service_0_7_4  unique_nonzero_owner_377  1
    service_0_7_4  service_visit_def_820  1
    service_0_7_4  free_load_conservation_821  3
    service_0_7_5  unique_nonzero_owner_378  1
    service_0_7_5  service_visit_def_820  1
    service_0_7_5  free_load_conservation_821  4
    service_0_7_6  unique_nonzero_owner_379  1
    service_0_7_6  service_visit_def_820  1
    service_0_7_6  free_load_conservation_821  5
    service_0_7_7  unique_nonzero_owner_380  1
    service_0_7_7  service_visit_def_820  1
    service_0_7_7  free_load_conservation_821  6
    service_0_7_8  unique_nonzero_owner_381  1
    service_0_7_8  service_visit_def_820  1
    service_0_7_8  free_load_conservation_821  7
    service_0_7_9  unique_nonzero_owner_382  1
    service_0_7_9  service_visit_def_820  1
    service_0_7_9  free_load_conservation_821  8
    service_0_7_10  unique_nonzero_owner_383  1
    service_0_7_10  service_visit_def_820  1
    service_0_7_10  free_load_conservation_821  9
    service_0_7_11  unique_nonzero_owner_384  1
    service_0_7_11  service_visit_def_820  1
    service_0_7_11  free_load_conservation_821  10
    service_0_7_12  unique_nonzero_owner_385  1
    service_0_7_12  service_visit_def_820  1
    service_0_7_12  free_load_conservation_821  11
    service_0_7_13  unique_nonzero_owner_386  1
    service_0_7_13  service_visit_def_820  1
    service_0_7_13  free_load_conservation_821  12
    service_0_7_14  unique_nonzero_owner_387  1
    service_0_7_14  service_visit_def_820  1
    service_0_7_14  free_load_conservation_821  13
    service_0_7_15  unique_nonzero_owner_388  1
    service_0_7_15  service_visit_def_820  1
    service_0_7_15  free_load_conservation_821  14
    service_1_7_0  unique_nonzero_owner_374  1
    service_1_7_0  service_visit_def_1192  1
    service_1_7_0  free_load_conservation_1193  -1
    service_1_7_0  original_T_including_depot_unload_1209  120
    service_1_7_2  unique_nonzero_owner_375  1
    service_1_7_2  service_visit_def_1192  1
    service_1_7_2  free_load_conservation_1193  1
    service_1_7_3  unique_nonzero_owner_376  1
    service_1_7_3  service_visit_def_1192  1
    service_1_7_3  free_load_conservation_1193  2
    service_1_7_4  unique_nonzero_owner_377  1
    service_1_7_4  service_visit_def_1192  1
    service_1_7_4  free_load_conservation_1193  3
    service_1_7_5  unique_nonzero_owner_378  1
    service_1_7_5  service_visit_def_1192  1
    service_1_7_5  free_load_conservation_1193  4
    service_1_7_6  unique_nonzero_owner_379  1
    service_1_7_6  service_visit_def_1192  1
    service_1_7_6  free_load_conservation_1193  5
    service_1_7_7  unique_nonzero_owner_380  1
    service_1_7_7  service_visit_def_1192  1
    service_1_7_7  free_load_conservation_1193  6
    service_1_7_8  unique_nonzero_owner_381  1
    service_1_7_8  service_visit_def_1192  1
    service_1_7_8  free_load_conservation_1193  7
    service_1_7_9  unique_nonzero_owner_382  1
    service_1_7_9  service_visit_def_1192  1
    service_1_7_9  free_load_conservation_1193  8
    service_1_7_10  unique_nonzero_owner_383  1
    service_1_7_10  service_visit_def_1192  1
    service_1_7_10  free_load_conservation_1193  9
    service_1_7_11  unique_nonzero_owner_384  1
    service_1_7_11  service_visit_def_1192  1
    service_1_7_11  free_load_conservation_1193  10
    service_1_7_12  unique_nonzero_owner_385  1
    service_1_7_12  service_visit_def_1192  1
    service_1_7_12  free_load_conservation_1193  11
    service_1_7_13  unique_nonzero_owner_386  1
    service_1_7_13  service_visit_def_1192  1
    service_1_7_13  free_load_conservation_1193  12
    service_1_7_14  unique_nonzero_owner_387  1
    service_1_7_14  service_visit_def_1192  1
    service_1_7_14  free_load_conservation_1193  13
    service_1_7_15  unique_nonzero_owner_388  1
    service_1_7_15  service_visit_def_1192  1
    service_1_7_15  free_load_conservation_1193  14
    service_2_7_0  unique_nonzero_owner_374  1
    service_2_7_0  service_visit_def_1563  1
    service_2_7_0  free_load_conservation_1564  -1
    service_2_7_0  original_T_including_depot_unload_1580  120
    service_2_7_2  unique_nonzero_owner_375  1
    service_2_7_2  service_visit_def_1563  1
    service_2_7_2  free_load_conservation_1564  1
    service_2_7_3  unique_nonzero_owner_376  1
    service_2_7_3  service_visit_def_1563  1
    service_2_7_3  free_load_conservation_1564  2
    service_2_7_4  unique_nonzero_owner_377  1
    service_2_7_4  service_visit_def_1563  1
    service_2_7_4  free_load_conservation_1564  3
    service_2_7_5  unique_nonzero_owner_378  1
    service_2_7_5  service_visit_def_1563  1
    service_2_7_5  free_load_conservation_1564  4
    service_2_7_6  unique_nonzero_owner_379  1
    service_2_7_6  service_visit_def_1563  1
    service_2_7_6  free_load_conservation_1564  5
    service_2_7_7  unique_nonzero_owner_380  1
    service_2_7_7  service_visit_def_1563  1
    service_2_7_7  free_load_conservation_1564  6
    service_2_7_8  unique_nonzero_owner_381  1
    service_2_7_8  service_visit_def_1563  1
    service_2_7_8  free_load_conservation_1564  7
    service_2_7_9  unique_nonzero_owner_382  1
    service_2_7_9  service_visit_def_1563  1
    service_2_7_9  free_load_conservation_1564  8
    service_2_7_10  unique_nonzero_owner_383  1
    service_2_7_10  service_visit_def_1563  1
    service_2_7_10  free_load_conservation_1564  9
    service_2_7_11  unique_nonzero_owner_384  1
    service_2_7_11  service_visit_def_1563  1
    service_2_7_11  free_load_conservation_1564  10
    service_2_7_12  unique_nonzero_owner_385  1
    service_2_7_12  service_visit_def_1563  1
    service_2_7_12  free_load_conservation_1564  11
    service_2_7_13  unique_nonzero_owner_386  1
    service_2_7_13  service_visit_def_1563  1
    service_2_7_13  free_load_conservation_1564  12
    service_2_7_14  unique_nonzero_owner_387  1
    service_2_7_14  service_visit_def_1563  1
    service_2_7_14  free_load_conservation_1564  13
    service_2_7_15  unique_nonzero_owner_388  1
    service_2_7_15  service_visit_def_1563  1
    service_2_7_15  free_load_conservation_1564  14
    service_0_27_1  unique_nonzero_owner_389  1
    service_0_27_1  service_visit_def_826  1
    service_0_27_1  free_load_conservation_827  1
    service_0_27_2  unique_nonzero_owner_390  1
    service_0_27_2  service_visit_def_826  1
    service_0_27_2  free_load_conservation_827  2
    service_0_27_3  unique_nonzero_owner_391  1
    service_0_27_3  service_visit_def_826  1
    service_0_27_3  free_load_conservation_827  3
    service_0_27_4  unique_nonzero_owner_392  1
    service_0_27_4  service_visit_def_826  1
    service_0_27_4  free_load_conservation_827  4
    service_0_27_5  unique_nonzero_owner_393  1
    service_0_27_5  service_visit_def_826  1
    service_0_27_5  free_load_conservation_827  5
    service_0_27_6  unique_nonzero_owner_394  1
    service_0_27_6  service_visit_def_826  1
    service_0_27_6  free_load_conservation_827  6
    service_1_27_1  unique_nonzero_owner_389  1
    service_1_27_1  service_visit_def_1198  1
    service_1_27_1  free_load_conservation_1199  1
    service_1_27_2  unique_nonzero_owner_390  1
    service_1_27_2  service_visit_def_1198  1
    service_1_27_2  free_load_conservation_1199  2
    service_1_27_3  unique_nonzero_owner_391  1
    service_1_27_3  service_visit_def_1198  1
    service_1_27_3  free_load_conservation_1199  3
    service_1_27_4  unique_nonzero_owner_392  1
    service_1_27_4  service_visit_def_1198  1
    service_1_27_4  free_load_conservation_1199  4
    service_1_27_5  unique_nonzero_owner_393  1
    service_1_27_5  service_visit_def_1198  1
    service_1_27_5  free_load_conservation_1199  5
    service_1_27_6  unique_nonzero_owner_394  1
    service_1_27_6  service_visit_def_1198  1
    service_1_27_6  free_load_conservation_1199  6
    service_2_27_1  unique_nonzero_owner_389  1
    service_2_27_1  service_visit_def_1569  1
    service_2_27_1  free_load_conservation_1570  1
    service_2_27_2  unique_nonzero_owner_390  1
    service_2_27_2  service_visit_def_1569  1
    service_2_27_2  free_load_conservation_1570  2
    service_2_27_3  unique_nonzero_owner_391  1
    service_2_27_3  service_visit_def_1569  1
    service_2_27_3  free_load_conservation_1570  3
    service_2_27_4  unique_nonzero_owner_392  1
    service_2_27_4  service_visit_def_1569  1
    service_2_27_4  free_load_conservation_1570  4
    service_2_27_5  unique_nonzero_owner_393  1
    service_2_27_5  service_visit_def_1569  1
    service_2_27_5  free_load_conservation_1570  5
    service_2_27_6  unique_nonzero_owner_394  1
    service_2_27_6  service_visit_def_1569  1
    service_2_27_6  free_load_conservation_1570  6
    service_0_2_0  unique_nonzero_owner_395  1
    service_0_2_0  service_visit_def_832  1
    service_0_2_0  free_load_conservation_833  -11
    service_0_2_0  original_T_including_depot_unload_838  1320
    service_0_2_1  unique_nonzero_owner_396  1
    service_0_2_1  service_visit_def_832  1
    service_0_2_1  free_load_conservation_833  -10
    service_0_2_1  original_T_including_depot_unload_838  1200
    service_0_2_2  unique_nonzero_owner_397  1
    service_0_2_2  service_visit_def_832  1
    service_0_2_2  free_load_conservation_833  -9
    service_0_2_2  original_T_including_depot_unload_838  1080
    service_0_2_3  unique_nonzero_owner_398  1
    service_0_2_3  service_visit_def_832  1
    service_0_2_3  free_load_conservation_833  -8
    service_0_2_3  original_T_including_depot_unload_838  960
    service_0_2_4  unique_nonzero_owner_399  1
    service_0_2_4  service_visit_def_832  1
    service_0_2_4  free_load_conservation_833  -7
    service_0_2_4  original_T_including_depot_unload_838  840
    service_0_2_5  unique_nonzero_owner_400  1
    service_0_2_5  service_visit_def_832  1
    service_0_2_5  free_load_conservation_833  -6
    service_0_2_5  original_T_including_depot_unload_838  720
    service_0_2_6  unique_nonzero_owner_401  1
    service_0_2_6  service_visit_def_832  1
    service_0_2_6  free_load_conservation_833  -5
    service_0_2_6  original_T_including_depot_unload_838  600
    service_0_2_7  unique_nonzero_owner_402  1
    service_0_2_7  service_visit_def_832  1
    service_0_2_7  free_load_conservation_833  -4
    service_0_2_7  original_T_including_depot_unload_838  480
    service_0_2_8  unique_nonzero_owner_403  1
    service_0_2_8  service_visit_def_832  1
    service_0_2_8  free_load_conservation_833  -3
    service_0_2_8  original_T_including_depot_unload_838  360
    service_0_2_9  unique_nonzero_owner_404  1
    service_0_2_9  service_visit_def_832  1
    service_0_2_9  free_load_conservation_833  -2
    service_0_2_9  original_T_including_depot_unload_838  240
    service_0_2_10  unique_nonzero_owner_405  1
    service_0_2_10  service_visit_def_832  1
    service_0_2_10  free_load_conservation_833  -1
    service_0_2_10  original_T_including_depot_unload_838  120
    service_0_2_12  unique_nonzero_owner_406  1
    service_0_2_12  service_visit_def_832  1
    service_0_2_12  free_load_conservation_833  1
    service_0_2_13  unique_nonzero_owner_407  1
    service_0_2_13  service_visit_def_832  1
    service_0_2_13  free_load_conservation_833  2
    service_0_2_14  unique_nonzero_owner_408  1
    service_0_2_14  service_visit_def_832  1
    service_0_2_14  free_load_conservation_833  3
    service_0_2_15  unique_nonzero_owner_409  1
    service_0_2_15  service_visit_def_832  1
    service_0_2_15  free_load_conservation_833  4
    service_1_2_0  unique_nonzero_owner_395  1
    service_1_2_0  service_visit_def_1204  1
    service_1_2_0  free_load_conservation_1205  -11
    service_1_2_0  original_T_including_depot_unload_1209  1320
    service_1_2_1  unique_nonzero_owner_396  1
    service_1_2_1  service_visit_def_1204  1
    service_1_2_1  free_load_conservation_1205  -10
    service_1_2_1  original_T_including_depot_unload_1209  1200
    service_1_2_2  unique_nonzero_owner_397  1
    service_1_2_2  service_visit_def_1204  1
    service_1_2_2  free_load_conservation_1205  -9
    service_1_2_2  original_T_including_depot_unload_1209  1080
    service_1_2_3  unique_nonzero_owner_398  1
    service_1_2_3  service_visit_def_1204  1
    service_1_2_3  free_load_conservation_1205  -8
    service_1_2_3  original_T_including_depot_unload_1209  960
    service_1_2_4  unique_nonzero_owner_399  1
    service_1_2_4  service_visit_def_1204  1
    service_1_2_4  free_load_conservation_1205  -7
    service_1_2_4  original_T_including_depot_unload_1209  840
    service_1_2_5  unique_nonzero_owner_400  1
    service_1_2_5  service_visit_def_1204  1
    service_1_2_5  free_load_conservation_1205  -6
    service_1_2_5  original_T_including_depot_unload_1209  720
    service_1_2_6  unique_nonzero_owner_401  1
    service_1_2_6  service_visit_def_1204  1
    service_1_2_6  free_load_conservation_1205  -5
    service_1_2_6  original_T_including_depot_unload_1209  600
    service_1_2_7  unique_nonzero_owner_402  1
    service_1_2_7  service_visit_def_1204  1
    service_1_2_7  free_load_conservation_1205  -4
    service_1_2_7  original_T_including_depot_unload_1209  480
    service_1_2_8  unique_nonzero_owner_403  1
    service_1_2_8  service_visit_def_1204  1
    service_1_2_8  free_load_conservation_1205  -3
    service_1_2_8  original_T_including_depot_unload_1209  360
    service_1_2_9  unique_nonzero_owner_404  1
    service_1_2_9  service_visit_def_1204  1
    service_1_2_9  free_load_conservation_1205  -2
    service_1_2_9  original_T_including_depot_unload_1209  240
    service_1_2_10  unique_nonzero_owner_405  1
    service_1_2_10  service_visit_def_1204  1
    service_1_2_10  free_load_conservation_1205  -1
    service_1_2_10  original_T_including_depot_unload_1209  120
    service_1_2_12  unique_nonzero_owner_406  1
    service_1_2_12  service_visit_def_1204  1
    service_1_2_12  free_load_conservation_1205  1
    service_1_2_13  unique_nonzero_owner_407  1
    service_1_2_13  service_visit_def_1204  1
    service_1_2_13  free_load_conservation_1205  2
    service_1_2_14  unique_nonzero_owner_408  1
    service_1_2_14  service_visit_def_1204  1
    service_1_2_14  free_load_conservation_1205  3
    service_1_2_15  unique_nonzero_owner_409  1
    service_1_2_15  service_visit_def_1204  1
    service_1_2_15  free_load_conservation_1205  4
    service_2_2_0  unique_nonzero_owner_395  1
    service_2_2_0  service_visit_def_1575  1
    service_2_2_0  free_load_conservation_1576  -11
    service_2_2_0  original_T_including_depot_unload_1580  1320
    service_2_2_1  unique_nonzero_owner_396  1
    service_2_2_1  service_visit_def_1575  1
    service_2_2_1  free_load_conservation_1576  -10
    service_2_2_1  original_T_including_depot_unload_1580  1200
    service_2_2_2  unique_nonzero_owner_397  1
    service_2_2_2  service_visit_def_1575  1
    service_2_2_2  free_load_conservation_1576  -9
    service_2_2_2  original_T_including_depot_unload_1580  1080
    service_2_2_3  unique_nonzero_owner_398  1
    service_2_2_3  service_visit_def_1575  1
    service_2_2_3  free_load_conservation_1576  -8
    service_2_2_3  original_T_including_depot_unload_1580  960
    service_2_2_4  unique_nonzero_owner_399  1
    service_2_2_4  service_visit_def_1575  1
    service_2_2_4  free_load_conservation_1576  -7
    service_2_2_4  original_T_including_depot_unload_1580  840
    service_2_2_5  unique_nonzero_owner_400  1
    service_2_2_5  service_visit_def_1575  1
    service_2_2_5  free_load_conservation_1576  -6
    service_2_2_5  original_T_including_depot_unload_1580  720
    service_2_2_6  unique_nonzero_owner_401  1
    service_2_2_6  service_visit_def_1575  1
    service_2_2_6  free_load_conservation_1576  -5
    service_2_2_6  original_T_including_depot_unload_1580  600
    service_2_2_7  unique_nonzero_owner_402  1
    service_2_2_7  service_visit_def_1575  1
    service_2_2_7  free_load_conservation_1576  -4
    service_2_2_7  original_T_including_depot_unload_1580  480
    service_2_2_8  unique_nonzero_owner_403  1
    service_2_2_8  service_visit_def_1575  1
    service_2_2_8  free_load_conservation_1576  -3
    service_2_2_8  original_T_including_depot_unload_1580  360
    service_2_2_9  unique_nonzero_owner_404  1
    service_2_2_9  service_visit_def_1575  1
    service_2_2_9  free_load_conservation_1576  -2
    service_2_2_9  original_T_including_depot_unload_1580  240
    service_2_2_10  unique_nonzero_owner_405  1
    service_2_2_10  service_visit_def_1575  1
    service_2_2_10  free_load_conservation_1576  -1
    service_2_2_10  original_T_including_depot_unload_1580  120
    service_2_2_12  unique_nonzero_owner_406  1
    service_2_2_12  service_visit_def_1575  1
    service_2_2_12  free_load_conservation_1576  1
    service_2_2_13  unique_nonzero_owner_407  1
    service_2_2_13  service_visit_def_1575  1
    service_2_2_13  free_load_conservation_1576  2
    service_2_2_14  unique_nonzero_owner_408  1
    service_2_2_14  service_visit_def_1575  1
    service_2_2_14  free_load_conservation_1576  3
    service_2_2_15  unique_nonzero_owner_409  1
    service_2_2_15  service_visit_def_1575  1
    service_2_2_15  free_load_conservation_1576  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_751  -1
    visit_0_1  in_degree_752  -1
    visit_0_1  order_active_lb_753  -1
    visit_0_1  order_active_ub_754  -13
    order_0_1  connected_order_arc_426  -1
    order_0_1  connected_order_arc_428  -1
    order_0_1  connected_order_arc_430  -1
    order_0_1  connected_order_arc_432  -1
    order_0_1  connected_order_arc_434  -1
    order_0_1  connected_order_arc_436  -1
    order_0_1  connected_order_arc_438  -1
    order_0_1  connected_order_arc_440  -1
    order_0_1  connected_order_arc_442  -1
    order_0_1  connected_order_arc_444  -1
    order_0_1  connected_order_arc_446  -1
    order_0_1  connected_order_arc_448  -1
    order_0_1  connected_order_arc_451  1
    order_0_1  connected_order_arc_476  1
    order_0_1  connected_order_arc_501  1
    order_0_1  connected_order_arc_526  1
    order_0_1  connected_order_arc_551  1
    order_0_1  connected_order_arc_576  1
    order_0_1  connected_order_arc_601  1
    order_0_1  connected_order_arc_626  1
    order_0_1  connected_order_arc_651  1
    order_0_1  connected_order_arc_676  1
    order_0_1  connected_order_arc_701  1
    order_0_1  connected_order_arc_726  1
    order_0_1  order_active_lb_753  1
    order_0_1  order_active_ub_754  1
    order_0_1  fixed_segment_relative_order_834  -1
    visit_0_2  out_degree_758  -1
    visit_0_2  in_degree_759  -1
    visit_0_2  order_active_lb_760  -1
    visit_0_2  order_active_ub_761  -13
    order_0_2  connected_order_arc_426  1
    order_0_2  connected_order_arc_451  -1
    order_0_2  connected_order_arc_453  -1
    order_0_2  connected_order_arc_455  -1
    order_0_2  connected_order_arc_457  -1
    order_0_2  connected_order_arc_459  -1
    order_0_2  connected_order_arc_461  -1
    order_0_2  connected_order_arc_463  -1
    order_0_2  connected_order_arc_465  -1
    order_0_2  connected_order_arc_467  -1
    order_0_2  connected_order_arc_469  -1
    order_0_2  connected_order_arc_471  -1
    order_0_2  connected_order_arc_473  -1
    order_0_2  connected_order_arc_478  1
    order_0_2  connected_order_arc_503  1
    order_0_2  connected_order_arc_528  1
    order_0_2  connected_order_arc_553  1
    order_0_2  connected_order_arc_578  1
    order_0_2  connected_order_arc_603  1
    order_0_2  connected_order_arc_628  1
    order_0_2  connected_order_arc_653  1
    order_0_2  connected_order_arc_678  1
    order_0_2  connected_order_arc_703  1
    order_0_2  connected_order_arc_728  1
    order_0_2  order_active_lb_760  1
    order_0_2  order_active_ub_761  1
    order_0_2  fixed_segment_relative_order_834  1
    order_0_2  fixed_segment_relative_order_835  -1
    visit_0_3  out_degree_765  -1
    visit_0_3  in_degree_766  -1
    visit_0_3  order_active_lb_767  -1
    visit_0_3  order_active_ub_768  -13
    order_0_3  connected_order_arc_428  1
    order_0_3  connected_order_arc_453  1
    order_0_3  connected_order_arc_476  -1
    order_0_3  connected_order_arc_478  -1
    order_0_3  connected_order_arc_480  -1
    order_0_3  connected_order_arc_482  -1
    order_0_3  connected_order_arc_484  -1
    order_0_3  connected_order_arc_486  -1
    order_0_3  connected_order_arc_488  -1
    order_0_3  connected_order_arc_490  -1
    order_0_3  connected_order_arc_492  -1
    order_0_3  connected_order_arc_494  -1
    order_0_3  connected_order_arc_496  -1
    order_0_3  connected_order_arc_498  -1
    order_0_3  connected_order_arc_505  1
    order_0_3  connected_order_arc_530  1
    order_0_3  connected_order_arc_555  1
    order_0_3  connected_order_arc_580  1
    order_0_3  connected_order_arc_605  1
    order_0_3  connected_order_arc_630  1
    order_0_3  connected_order_arc_655  1
    order_0_3  connected_order_arc_680  1
    order_0_3  connected_order_arc_705  1
    order_0_3  connected_order_arc_730  1
    order_0_3  order_active_lb_767  1
    order_0_3  order_active_ub_768  1
    order_0_3  fixed_segment_relative_order_835  1
    order_0_3  fixed_segment_relative_order_836  -1
    visit_0_4  out_degree_772  -1
    visit_0_4  in_degree_773  -1
    visit_0_4  order_active_lb_774  -1
    visit_0_4  order_active_ub_775  -13
    order_0_4  connected_order_arc_430  1
    order_0_4  connected_order_arc_455  1
    order_0_4  connected_order_arc_480  1
    order_0_4  connected_order_arc_501  -1
    order_0_4  connected_order_arc_503  -1
    order_0_4  connected_order_arc_505  -1
    order_0_4  connected_order_arc_507  -1
    order_0_4  connected_order_arc_509  -1
    order_0_4  connected_order_arc_511  -1
    order_0_4  connected_order_arc_513  -1
    order_0_4  connected_order_arc_515  -1
    order_0_4  connected_order_arc_517  -1
    order_0_4  connected_order_arc_519  -1
    order_0_4  connected_order_arc_521  -1
    order_0_4  connected_order_arc_523  -1
    order_0_4  connected_order_arc_532  1
    order_0_4  connected_order_arc_557  1
    order_0_4  connected_order_arc_582  1
    order_0_4  connected_order_arc_607  1
    order_0_4  connected_order_arc_632  1
    order_0_4  connected_order_arc_657  1
    order_0_4  connected_order_arc_682  1
    order_0_4  connected_order_arc_707  1
    order_0_4  connected_order_arc_732  1
    order_0_4  order_active_lb_774  1
    order_0_4  order_active_ub_775  1
    order_0_4  fixed_segment_relative_order_836  1
    order_0_4  fixed_segment_relative_order_837  -1
    visit_0_5  out_degree_779  -1
    visit_0_5  in_degree_780  -1
    visit_0_5  order_active_lb_781  -1
    visit_0_5  order_active_ub_782  -13
    order_0_5  connected_order_arc_432  1
    order_0_5  connected_order_arc_457  1
    order_0_5  connected_order_arc_482  1
    order_0_5  connected_order_arc_507  1
    order_0_5  connected_order_arc_526  -1
    order_0_5  connected_order_arc_528  -1
    order_0_5  connected_order_arc_530  -1
    order_0_5  connected_order_arc_532  -1
    order_0_5  connected_order_arc_534  -1
    order_0_5  connected_order_arc_536  -1
    order_0_5  connected_order_arc_538  -1
    order_0_5  connected_order_arc_540  -1
    order_0_5  connected_order_arc_542  -1
    order_0_5  connected_order_arc_544  -1
    order_0_5  connected_order_arc_546  -1
    order_0_5  connected_order_arc_548  -1
    order_0_5  connected_order_arc_559  1
    order_0_5  connected_order_arc_584  1
    order_0_5  connected_order_arc_609  1
    order_0_5  connected_order_arc_634  1
    order_0_5  connected_order_arc_659  1
    order_0_5  connected_order_arc_684  1
    order_0_5  connected_order_arc_709  1
    order_0_5  connected_order_arc_734  1
    order_0_5  order_active_lb_781  1
    order_0_5  order_active_ub_782  1
    order_0_5  fixed_segment_relative_order_837  1
    visit_0_14  out_degree_786  -1
    visit_0_14  in_degree_787  -1
    visit_0_14  order_active_lb_788  -1
    visit_0_14  order_active_ub_789  -13
    visit_0_14  service_visit_def_790  -1
    order_0_14  connected_order_arc_434  1
    order_0_14  connected_order_arc_459  1
    order_0_14  connected_order_arc_484  1
    order_0_14  connected_order_arc_509  1
    order_0_14  connected_order_arc_534  1
    order_0_14  connected_order_arc_551  -1
    order_0_14  connected_order_arc_553  -1
    order_0_14  connected_order_arc_555  -1
    order_0_14  connected_order_arc_557  -1
    order_0_14  connected_order_arc_559  -1
    order_0_14  connected_order_arc_561  -1
    order_0_14  connected_order_arc_563  -1
    order_0_14  connected_order_arc_565  -1
    order_0_14  connected_order_arc_567  -1
    order_0_14  connected_order_arc_569  -1
    order_0_14  connected_order_arc_571  -1
    order_0_14  connected_order_arc_573  -1
    order_0_14  connected_order_arc_586  1
    order_0_14  connected_order_arc_611  1
    order_0_14  connected_order_arc_636  1
    order_0_14  connected_order_arc_661  1
    order_0_14  connected_order_arc_686  1
    order_0_14  connected_order_arc_711  1
    order_0_14  connected_order_arc_736  1
    order_0_14  order_active_lb_788  1
    order_0_14  order_active_ub_789  1
    visit_0_15  out_degree_792  -1
    visit_0_15  in_degree_793  -1
    visit_0_15  order_active_lb_794  -1
    visit_0_15  order_active_ub_795  -13
    visit_0_15  service_visit_def_796  -1
    order_0_15  connected_order_arc_436  1
    order_0_15  connected_order_arc_461  1
    order_0_15  connected_order_arc_486  1
    order_0_15  connected_order_arc_511  1
    order_0_15  connected_order_arc_536  1
    order_0_15  connected_order_arc_561  1
    order_0_15  connected_order_arc_576  -1
    order_0_15  connected_order_arc_578  -1
    order_0_15  connected_order_arc_580  -1
    order_0_15  connected_order_arc_582  -1
    order_0_15  connected_order_arc_584  -1
    order_0_15  connected_order_arc_586  -1
    order_0_15  connected_order_arc_588  -1
    order_0_15  connected_order_arc_590  -1
    order_0_15  connected_order_arc_592  -1
    order_0_15  connected_order_arc_594  -1
    order_0_15  connected_order_arc_596  -1
    order_0_15  connected_order_arc_598  -1
    order_0_15  connected_order_arc_613  1
    order_0_15  connected_order_arc_638  1
    order_0_15  connected_order_arc_663  1
    order_0_15  connected_order_arc_688  1
    order_0_15  connected_order_arc_713  1
    order_0_15  connected_order_arc_738  1
    order_0_15  order_active_lb_794  1
    order_0_15  order_active_ub_795  1
    visit_0_16  out_degree_798  -1
    visit_0_16  in_degree_799  -1
    visit_0_16  order_active_lb_800  -1
    visit_0_16  order_active_ub_801  -13
    visit_0_16  service_visit_def_802  -1
    order_0_16  connected_order_arc_438  1
    order_0_16  connected_order_arc_463  1
    order_0_16  connected_order_arc_488  1
    order_0_16  connected_order_arc_513  1
    order_0_16  connected_order_arc_538  1
    order_0_16  connected_order_arc_563  1
    order_0_16  connected_order_arc_588  1
    order_0_16  connected_order_arc_601  -1
    order_0_16  connected_order_arc_603  -1
    order_0_16  connected_order_arc_605  -1
    order_0_16  connected_order_arc_607  -1
    order_0_16  connected_order_arc_609  -1
    order_0_16  connected_order_arc_611  -1
    order_0_16  connected_order_arc_613  -1
    order_0_16  connected_order_arc_615  -1
    order_0_16  connected_order_arc_617  -1
    order_0_16  connected_order_arc_619  -1
    order_0_16  connected_order_arc_621  -1
    order_0_16  connected_order_arc_623  -1
    order_0_16  connected_order_arc_640  1
    order_0_16  connected_order_arc_665  1
    order_0_16  connected_order_arc_690  1
    order_0_16  connected_order_arc_715  1
    order_0_16  connected_order_arc_740  1
    order_0_16  order_active_lb_800  1
    order_0_16  order_active_ub_801  1
    visit_0_17  out_degree_804  -1
    visit_0_17  in_degree_805  -1
    visit_0_17  order_active_lb_806  -1
    visit_0_17  order_active_ub_807  -13
    visit_0_17  service_visit_def_808  -1
    order_0_17  connected_order_arc_440  1
    order_0_17  connected_order_arc_465  1
    order_0_17  connected_order_arc_490  1
    order_0_17  connected_order_arc_515  1
    order_0_17  connected_order_arc_540  1
    order_0_17  connected_order_arc_565  1
    order_0_17  connected_order_arc_590  1
    order_0_17  connected_order_arc_615  1
    order_0_17  connected_order_arc_626  -1
    order_0_17  connected_order_arc_628  -1
    order_0_17  connected_order_arc_630  -1
    order_0_17  connected_order_arc_632  -1
    order_0_17  connected_order_arc_634  -1
    order_0_17  connected_order_arc_636  -1
    order_0_17  connected_order_arc_638  -1
    order_0_17  connected_order_arc_640  -1
    order_0_17  connected_order_arc_642  -1
    order_0_17  connected_order_arc_644  -1
    order_0_17  connected_order_arc_646  -1
    order_0_17  connected_order_arc_648  -1
    order_0_17  connected_order_arc_667  1
    order_0_17  connected_order_arc_692  1
    order_0_17  connected_order_arc_717  1
    order_0_17  connected_order_arc_742  1
    order_0_17  order_active_lb_806  1
    order_0_17  order_active_ub_807  1
    visit_0_18  out_degree_810  -1
    visit_0_18  in_degree_811  -1
    visit_0_18  order_active_lb_812  -1
    visit_0_18  order_active_ub_813  -13
    visit_0_18  service_visit_def_814  -1
    order_0_18  connected_order_arc_442  1
    order_0_18  connected_order_arc_467  1
    order_0_18  connected_order_arc_492  1
    order_0_18  connected_order_arc_517  1
    order_0_18  connected_order_arc_542  1
    order_0_18  connected_order_arc_567  1
    order_0_18  connected_order_arc_592  1
    order_0_18  connected_order_arc_617  1
    order_0_18  connected_order_arc_642  1
    order_0_18  connected_order_arc_651  -1
    order_0_18  connected_order_arc_653  -1
    order_0_18  connected_order_arc_655  -1
    order_0_18  connected_order_arc_657  -1
    order_0_18  connected_order_arc_659  -1
    order_0_18  connected_order_arc_661  -1
    order_0_18  connected_order_arc_663  -1
    order_0_18  connected_order_arc_665  -1
    order_0_18  connected_order_arc_667  -1
    order_0_18  connected_order_arc_669  -1
    order_0_18  connected_order_arc_671  -1
    order_0_18  connected_order_arc_673  -1
    order_0_18  connected_order_arc_694  1
    order_0_18  connected_order_arc_719  1
    order_0_18  connected_order_arc_744  1
    order_0_18  order_active_lb_812  1
    order_0_18  order_active_ub_813  1
    visit_0_19  out_degree_816  -1
    visit_0_19  in_degree_817  -1
    visit_0_19  order_active_lb_818  -1
    visit_0_19  order_active_ub_819  -13
    visit_0_19  service_visit_def_820  -1
    order_0_19  connected_order_arc_444  1
    order_0_19  connected_order_arc_469  1
    order_0_19  connected_order_arc_494  1
    order_0_19  connected_order_arc_519  1
    order_0_19  connected_order_arc_544  1
    order_0_19  connected_order_arc_569  1
    order_0_19  connected_order_arc_594  1
    order_0_19  connected_order_arc_619  1
    order_0_19  connected_order_arc_644  1
    order_0_19  connected_order_arc_669  1
    order_0_19  connected_order_arc_676  -1
    order_0_19  connected_order_arc_678  -1
    order_0_19  connected_order_arc_680  -1
    order_0_19  connected_order_arc_682  -1
    order_0_19  connected_order_arc_684  -1
    order_0_19  connected_order_arc_686  -1
    order_0_19  connected_order_arc_688  -1
    order_0_19  connected_order_arc_690  -1
    order_0_19  connected_order_arc_692  -1
    order_0_19  connected_order_arc_694  -1
    order_0_19  connected_order_arc_696  -1
    order_0_19  connected_order_arc_698  -1
    order_0_19  connected_order_arc_721  1
    order_0_19  connected_order_arc_746  1
    order_0_19  order_active_lb_818  1
    order_0_19  order_active_ub_819  1
    visit_0_20  out_degree_822  -1
    visit_0_20  in_degree_823  -1
    visit_0_20  order_active_lb_824  -1
    visit_0_20  order_active_ub_825  -13
    visit_0_20  service_visit_def_826  -1
    order_0_20  connected_order_arc_446  1
    order_0_20  connected_order_arc_471  1
    order_0_20  connected_order_arc_496  1
    order_0_20  connected_order_arc_521  1
    order_0_20  connected_order_arc_546  1
    order_0_20  connected_order_arc_571  1
    order_0_20  connected_order_arc_596  1
    order_0_20  connected_order_arc_621  1
    order_0_20  connected_order_arc_646  1
    order_0_20  connected_order_arc_671  1
    order_0_20  connected_order_arc_696  1
    order_0_20  connected_order_arc_701  -1
    order_0_20  connected_order_arc_703  -1
    order_0_20  connected_order_arc_705  -1
    order_0_20  connected_order_arc_707  -1
    order_0_20  connected_order_arc_709  -1
    order_0_20  connected_order_arc_711  -1
    order_0_20  connected_order_arc_713  -1
    order_0_20  connected_order_arc_715  -1
    order_0_20  connected_order_arc_717  -1
    order_0_20  connected_order_arc_719  -1
    order_0_20  connected_order_arc_721  -1
    order_0_20  connected_order_arc_723  -1
    order_0_20  connected_order_arc_748  1
    order_0_20  order_active_lb_824  1
    order_0_20  order_active_ub_825  1
    visit_0_21  out_degree_828  -1
    visit_0_21  in_degree_829  -1
    visit_0_21  order_active_lb_830  -1
    visit_0_21  order_active_ub_831  -13
    visit_0_21  service_visit_def_832  -1
    order_0_21  connected_order_arc_448  1
    order_0_21  connected_order_arc_473  1
    order_0_21  connected_order_arc_498  1
    order_0_21  connected_order_arc_523  1
    order_0_21  connected_order_arc_548  1
    order_0_21  connected_order_arc_573  1
    order_0_21  connected_order_arc_598  1
    order_0_21  connected_order_arc_623  1
    order_0_21  connected_order_arc_648  1
    order_0_21  connected_order_arc_673  1
    order_0_21  connected_order_arc_698  1
    order_0_21  connected_order_arc_723  1
    order_0_21  connected_order_arc_726  -1
    order_0_21  connected_order_arc_728  -1
    order_0_21  connected_order_arc_730  -1
    order_0_21  connected_order_arc_732  -1
    order_0_21  connected_order_arc_734  -1
    order_0_21  connected_order_arc_736  -1
    order_0_21  connected_order_arc_738  -1
    order_0_21  connected_order_arc_740  -1
    order_0_21  connected_order_arc_742  -1
    order_0_21  connected_order_arc_744  -1
    order_0_21  connected_order_arc_746  -1
    order_0_21  connected_order_arc_748  -1
    order_0_21  order_active_lb_830  1
    order_0_21  order_active_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_410  -20
    arc_0_0_0  depot_departure_or_bypass_749  1
    arc_0_0_0  depot_return_or_bypass_750  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_410  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_411  -20
    arc_0_0_1  depot_departure_or_bypass_749  1
    arc_0_0_1  in_degree_752  1
    arc_0_0_1  original_T_including_depot_unload_838  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_411  1
    load_0_0_1  segment_load_conservation_755  -1
    load_0_0_1  segment_prefix_lb_756  1
    load_0_0_1  segment_prefix_ub_757  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_412  -20
    arc_0_0_2  depot_departure_or_bypass_749  1
    arc_0_0_2  in_degree_759  1
    arc_0_0_2  original_T_including_depot_unload_838  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_412  1
    load_0_0_2  segment_load_conservation_762  -1
    load_0_0_2  segment_prefix_lb_763  1
    load_0_0_2  segment_prefix_ub_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_413  -20
    arc_0_0_3  depot_departure_or_bypass_749  1
    arc_0_0_3  in_degree_766  1
    arc_0_0_3  original_T_including_depot_unload_838  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_413  1
    load_0_0_3  segment_load_conservation_769  -1
    load_0_0_3  segment_prefix_lb_770  1
    load_0_0_3  segment_prefix_ub_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_414  -20
    arc_0_0_4  depot_departure_or_bypass_749  1
    arc_0_0_4  in_degree_773  1
    arc_0_0_4  original_T_including_depot_unload_838  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_414  1
    load_0_0_4  segment_load_conservation_776  -1
    load_0_0_4  segment_prefix_lb_777  1
    load_0_0_4  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_415  -20
    arc_0_0_5  depot_departure_or_bypass_749  1
    arc_0_0_5  in_degree_780  1
    arc_0_0_5  original_T_including_depot_unload_838  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_415  1
    load_0_0_5  segment_load_conservation_783  -1
    load_0_0_5  segment_prefix_lb_784  1
    load_0_0_5  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_416  -20
    arc_0_0_14  depot_departure_or_bypass_749  1
    arc_0_0_14  in_degree_787  1
    arc_0_0_14  original_T_including_depot_unload_838  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_416  1
    load_0_0_14  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_417  -20
    arc_0_0_15  depot_departure_or_bypass_749  1
    arc_0_0_15  in_degree_793  1
    arc_0_0_15  original_T_including_depot_unload_838  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_417  1
    load_0_0_15  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_418  -20
    arc_0_0_16  depot_departure_or_bypass_749  1
    arc_0_0_16  in_degree_799  1
    arc_0_0_16  original_T_including_depot_unload_838  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_418  1
    load_0_0_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_419  -20
    arc_0_0_17  depot_departure_or_bypass_749  1
    arc_0_0_17  in_degree_805  1
    arc_0_0_17  original_T_including_depot_unload_838  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_419  1
    load_0_0_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_420  -20
    arc_0_0_18  depot_departure_or_bypass_749  1
    arc_0_0_18  in_degree_811  1
    arc_0_0_18  original_T_including_depot_unload_838  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_420  1
    load_0_0_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_421  -20
    arc_0_0_19  depot_departure_or_bypass_749  1
    arc_0_0_19  in_degree_817  1
    arc_0_0_19  original_T_including_depot_unload_838  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_421  1
    load_0_0_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_422  -20
    arc_0_0_20  depot_departure_or_bypass_749  1
    arc_0_0_20  in_degree_823  1
    arc_0_0_20  original_T_including_depot_unload_838  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_422  1
    load_0_0_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_423  -20
    arc_0_0_21  depot_departure_or_bypass_749  1
    arc_0_0_21  in_degree_829  1
    arc_0_0_21  original_T_including_depot_unload_838  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_423  1
    load_0_0_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_424  -20
    arc_0_1_0  depot_return_or_bypass_750  1
    arc_0_1_0  out_degree_751  1
    arc_0_1_0  original_T_including_depot_unload_838  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_424  1
    load_0_1_0  segment_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_425  -20
    arc_0_1_2  connected_order_arc_426  -14
    arc_0_1_2  out_degree_751  1
    arc_0_1_2  in_degree_759  1
    arc_0_1_2  original_T_including_depot_unload_838  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_425  1
    load_0_1_2  segment_load_conservation_755  1
    load_0_1_2  segment_load_conservation_762  -1
    load_0_1_2  segment_prefix_lb_763  1
    load_0_1_2  segment_prefix_ub_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_427  -20
    arc_0_1_3  connected_order_arc_428  -14
    arc_0_1_3  out_degree_751  1
    arc_0_1_3  in_degree_766  1
    arc_0_1_3  original_T_including_depot_unload_838  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_427  1
    load_0_1_3  segment_load_conservation_755  1
    load_0_1_3  segment_load_conservation_769  -1
    load_0_1_3  segment_prefix_lb_770  1
    load_0_1_3  segment_prefix_ub_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_429  -20
    arc_0_1_4  connected_order_arc_430  -14
    arc_0_1_4  out_degree_751  1
    arc_0_1_4  in_degree_773  1
    arc_0_1_4  original_T_including_depot_unload_838  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_429  1
    load_0_1_4  segment_load_conservation_755  1
    load_0_1_4  segment_load_conservation_776  -1
    load_0_1_4  segment_prefix_lb_777  1
    load_0_1_4  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_431  -20
    arc_0_1_5  connected_order_arc_432  -14
    arc_0_1_5  out_degree_751  1
    arc_0_1_5  in_degree_780  1
    arc_0_1_5  original_T_including_depot_unload_838  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_431  1
    load_0_1_5  segment_load_conservation_755  1
    load_0_1_5  segment_load_conservation_783  -1
    load_0_1_5  segment_prefix_lb_784  1
    load_0_1_5  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_433  -20
    arc_0_1_14  connected_order_arc_434  -14
    arc_0_1_14  out_degree_751  1
    arc_0_1_14  in_degree_787  1
    arc_0_1_14  original_T_including_depot_unload_838  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_433  1
    load_0_1_14  segment_load_conservation_755  1
    load_0_1_14  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_435  -20
    arc_0_1_15  connected_order_arc_436  -14
    arc_0_1_15  out_degree_751  1
    arc_0_1_15  in_degree_793  1
    arc_0_1_15  original_T_including_depot_unload_838  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_435  1
    load_0_1_15  segment_load_conservation_755  1
    load_0_1_15  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_437  -20
    arc_0_1_16  connected_order_arc_438  -14
    arc_0_1_16  out_degree_751  1
    arc_0_1_16  in_degree_799  1
    arc_0_1_16  original_T_including_depot_unload_838  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_437  1
    load_0_1_16  segment_load_conservation_755  1
    load_0_1_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_439  -20
    arc_0_1_17  connected_order_arc_440  -14
    arc_0_1_17  out_degree_751  1
    arc_0_1_17  in_degree_805  1
    arc_0_1_17  original_T_including_depot_unload_838  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_439  1
    load_0_1_17  segment_load_conservation_755  1
    load_0_1_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_441  -20
    arc_0_1_18  connected_order_arc_442  -14
    arc_0_1_18  out_degree_751  1
    arc_0_1_18  in_degree_811  1
    arc_0_1_18  original_T_including_depot_unload_838  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_441  1
    load_0_1_18  segment_load_conservation_755  1
    load_0_1_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_443  -20
    arc_0_1_19  connected_order_arc_444  -14
    arc_0_1_19  out_degree_751  1
    arc_0_1_19  in_degree_817  1
    arc_0_1_19  original_T_including_depot_unload_838  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_443  1
    load_0_1_19  segment_load_conservation_755  1
    load_0_1_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_445  -20
    arc_0_1_20  connected_order_arc_446  -14
    arc_0_1_20  out_degree_751  1
    arc_0_1_20  in_degree_823  1
    arc_0_1_20  original_T_including_depot_unload_838  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_445  1
    load_0_1_20  segment_load_conservation_755  1
    load_0_1_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_447  -20
    arc_0_1_21  connected_order_arc_448  -14
    arc_0_1_21  out_degree_751  1
    arc_0_1_21  in_degree_829  1
    arc_0_1_21  original_T_including_depot_unload_838  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_447  1
    load_0_1_21  segment_load_conservation_755  1
    load_0_1_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_449  -20
    arc_0_2_0  depot_return_or_bypass_750  1
    arc_0_2_0  out_degree_758  1
    arc_0_2_0  original_T_including_depot_unload_838  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_449  1
    load_0_2_0  segment_load_conservation_762  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_450  -20
    arc_0_2_1  connected_order_arc_451  -14
    arc_0_2_1  in_degree_752  1
    arc_0_2_1  out_degree_758  1
    arc_0_2_1  original_T_including_depot_unload_838  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_450  1
    load_0_2_1  segment_load_conservation_755  -1
    load_0_2_1  segment_prefix_lb_756  1
    load_0_2_1  segment_prefix_ub_757  1
    load_0_2_1  segment_load_conservation_762  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_452  -20
    arc_0_2_3  connected_order_arc_453  -14
    arc_0_2_3  out_degree_758  1
    arc_0_2_3  in_degree_766  1
    arc_0_2_3  original_T_including_depot_unload_838  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_452  1
    load_0_2_3  segment_load_conservation_762  1
    load_0_2_3  segment_load_conservation_769  -1
    load_0_2_3  segment_prefix_lb_770  1
    load_0_2_3  segment_prefix_ub_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_454  -20
    arc_0_2_4  connected_order_arc_455  -14
    arc_0_2_4  out_degree_758  1
    arc_0_2_4  in_degree_773  1
    arc_0_2_4  original_T_including_depot_unload_838  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_454  1
    load_0_2_4  segment_load_conservation_762  1
    load_0_2_4  segment_load_conservation_776  -1
    load_0_2_4  segment_prefix_lb_777  1
    load_0_2_4  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_456  -20
    arc_0_2_5  connected_order_arc_457  -14
    arc_0_2_5  out_degree_758  1
    arc_0_2_5  in_degree_780  1
    arc_0_2_5  original_T_including_depot_unload_838  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_456  1
    load_0_2_5  segment_load_conservation_762  1
    load_0_2_5  segment_load_conservation_783  -1
    load_0_2_5  segment_prefix_lb_784  1
    load_0_2_5  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_458  -20
    arc_0_2_14  connected_order_arc_459  -14
    arc_0_2_14  out_degree_758  1
    arc_0_2_14  in_degree_787  1
    arc_0_2_14  original_T_including_depot_unload_838  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_458  1
    load_0_2_14  segment_load_conservation_762  1
    load_0_2_14  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_460  -20
    arc_0_2_15  connected_order_arc_461  -14
    arc_0_2_15  out_degree_758  1
    arc_0_2_15  in_degree_793  1
    arc_0_2_15  original_T_including_depot_unload_838  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_460  1
    load_0_2_15  segment_load_conservation_762  1
    load_0_2_15  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_462  -20
    arc_0_2_16  connected_order_arc_463  -14
    arc_0_2_16  out_degree_758  1
    arc_0_2_16  in_degree_799  1
    arc_0_2_16  original_T_including_depot_unload_838  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_462  1
    load_0_2_16  segment_load_conservation_762  1
    load_0_2_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_464  -20
    arc_0_2_17  connected_order_arc_465  -14
    arc_0_2_17  out_degree_758  1
    arc_0_2_17  in_degree_805  1
    arc_0_2_17  original_T_including_depot_unload_838  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_464  1
    load_0_2_17  segment_load_conservation_762  1
    load_0_2_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_466  -20
    arc_0_2_18  connected_order_arc_467  -14
    arc_0_2_18  out_degree_758  1
    arc_0_2_18  in_degree_811  1
    arc_0_2_18  original_T_including_depot_unload_838  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_466  1
    load_0_2_18  segment_load_conservation_762  1
    load_0_2_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_468  -20
    arc_0_2_19  connected_order_arc_469  -14
    arc_0_2_19  out_degree_758  1
    arc_0_2_19  in_degree_817  1
    arc_0_2_19  original_T_including_depot_unload_838  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_468  1
    load_0_2_19  segment_load_conservation_762  1
    load_0_2_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_470  -20
    arc_0_2_20  connected_order_arc_471  -14
    arc_0_2_20  out_degree_758  1
    arc_0_2_20  in_degree_823  1
    arc_0_2_20  original_T_including_depot_unload_838  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_470  1
    load_0_2_20  segment_load_conservation_762  1
    load_0_2_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_472  -20
    arc_0_2_21  connected_order_arc_473  -14
    arc_0_2_21  out_degree_758  1
    arc_0_2_21  in_degree_829  1
    arc_0_2_21  original_T_including_depot_unload_838  8.9557394138123709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_472  1
    load_0_2_21  segment_load_conservation_762  1
    load_0_2_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_474  -20
    arc_0_3_0  depot_return_or_bypass_750  1
    arc_0_3_0  out_degree_765  1
    arc_0_3_0  original_T_including_depot_unload_838  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_474  1
    load_0_3_0  segment_load_conservation_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_475  -20
    arc_0_3_1  connected_order_arc_476  -14
    arc_0_3_1  in_degree_752  1
    arc_0_3_1  out_degree_765  1
    arc_0_3_1  original_T_including_depot_unload_838  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_475  1
    load_0_3_1  segment_load_conservation_755  -1
    load_0_3_1  segment_prefix_lb_756  1
    load_0_3_1  segment_prefix_ub_757  1
    load_0_3_1  segment_load_conservation_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_477  -20
    arc_0_3_2  connected_order_arc_478  -14
    arc_0_3_2  in_degree_759  1
    arc_0_3_2  out_degree_765  1
    arc_0_3_2  original_T_including_depot_unload_838  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_477  1
    load_0_3_2  segment_load_conservation_762  -1
    load_0_3_2  segment_prefix_lb_763  1
    load_0_3_2  segment_prefix_ub_764  1
    load_0_3_2  segment_load_conservation_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_479  -20
    arc_0_3_4  connected_order_arc_480  -14
    arc_0_3_4  out_degree_765  1
    arc_0_3_4  in_degree_773  1
    arc_0_3_4  original_T_including_depot_unload_838  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_479  1
    load_0_3_4  segment_load_conservation_769  1
    load_0_3_4  segment_load_conservation_776  -1
    load_0_3_4  segment_prefix_lb_777  1
    load_0_3_4  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_481  -20
    arc_0_3_5  connected_order_arc_482  -14
    arc_0_3_5  out_degree_765  1
    arc_0_3_5  in_degree_780  1
    arc_0_3_5  original_T_including_depot_unload_838  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_481  1
    load_0_3_5  segment_load_conservation_769  1
    load_0_3_5  segment_load_conservation_783  -1
    load_0_3_5  segment_prefix_lb_784  1
    load_0_3_5  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_483  -20
    arc_0_3_14  connected_order_arc_484  -14
    arc_0_3_14  out_degree_765  1
    arc_0_3_14  in_degree_787  1
    arc_0_3_14  original_T_including_depot_unload_838  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_483  1
    load_0_3_14  segment_load_conservation_769  1
    load_0_3_14  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_485  -20
    arc_0_3_15  connected_order_arc_486  -14
    arc_0_3_15  out_degree_765  1
    arc_0_3_15  in_degree_793  1
    arc_0_3_15  original_T_including_depot_unload_838  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_485  1
    load_0_3_15  segment_load_conservation_769  1
    load_0_3_15  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_487  -20
    arc_0_3_16  connected_order_arc_488  -14
    arc_0_3_16  out_degree_765  1
    arc_0_3_16  in_degree_799  1
    arc_0_3_16  original_T_including_depot_unload_838  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_487  1
    load_0_3_16  segment_load_conservation_769  1
    load_0_3_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_489  -20
    arc_0_3_17  connected_order_arc_490  -14
    arc_0_3_17  out_degree_765  1
    arc_0_3_17  in_degree_805  1
    arc_0_3_17  original_T_including_depot_unload_838  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_489  1
    load_0_3_17  segment_load_conservation_769  1
    load_0_3_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_491  -20
    arc_0_3_18  connected_order_arc_492  -14
    arc_0_3_18  out_degree_765  1
    arc_0_3_18  in_degree_811  1
    arc_0_3_18  original_T_including_depot_unload_838  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_491  1
    load_0_3_18  segment_load_conservation_769  1
    load_0_3_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_493  -20
    arc_0_3_19  connected_order_arc_494  -14
    arc_0_3_19  out_degree_765  1
    arc_0_3_19  in_degree_817  1
    arc_0_3_19  original_T_including_depot_unload_838  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_493  1
    load_0_3_19  segment_load_conservation_769  1
    load_0_3_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_495  -20
    arc_0_3_20  connected_order_arc_496  -14
    arc_0_3_20  out_degree_765  1
    arc_0_3_20  in_degree_823  1
    arc_0_3_20  original_T_including_depot_unload_838  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_495  1
    load_0_3_20  segment_load_conservation_769  1
    load_0_3_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_497  -20
    arc_0_3_21  connected_order_arc_498  -14
    arc_0_3_21  out_degree_765  1
    arc_0_3_21  in_degree_829  1
    arc_0_3_21  original_T_including_depot_unload_838  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_497  1
    load_0_3_21  segment_load_conservation_769  1
    load_0_3_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_499  -20
    arc_0_4_0  depot_return_or_bypass_750  1
    arc_0_4_0  out_degree_772  1
    arc_0_4_0  original_T_including_depot_unload_838  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_499  1
    load_0_4_0  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_500  -20
    arc_0_4_1  connected_order_arc_501  -14
    arc_0_4_1  in_degree_752  1
    arc_0_4_1  out_degree_772  1
    arc_0_4_1  original_T_including_depot_unload_838  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_500  1
    load_0_4_1  segment_load_conservation_755  -1
    load_0_4_1  segment_prefix_lb_756  1
    load_0_4_1  segment_prefix_ub_757  1
    load_0_4_1  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_502  -20
    arc_0_4_2  connected_order_arc_503  -14
    arc_0_4_2  in_degree_759  1
    arc_0_4_2  out_degree_772  1
    arc_0_4_2  original_T_including_depot_unload_838  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_502  1
    load_0_4_2  segment_load_conservation_762  -1
    load_0_4_2  segment_prefix_lb_763  1
    load_0_4_2  segment_prefix_ub_764  1
    load_0_4_2  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_504  -20
    arc_0_4_3  connected_order_arc_505  -14
    arc_0_4_3  in_degree_766  1
    arc_0_4_3  out_degree_772  1
    arc_0_4_3  original_T_including_depot_unload_838  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_504  1
    load_0_4_3  segment_load_conservation_769  -1
    load_0_4_3  segment_prefix_lb_770  1
    load_0_4_3  segment_prefix_ub_771  1
    load_0_4_3  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_506  -20
    arc_0_4_5  connected_order_arc_507  -14
    arc_0_4_5  out_degree_772  1
    arc_0_4_5  in_degree_780  1
    arc_0_4_5  original_T_including_depot_unload_838  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_506  1
    load_0_4_5  segment_load_conservation_776  1
    load_0_4_5  segment_load_conservation_783  -1
    load_0_4_5  segment_prefix_lb_784  1
    load_0_4_5  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_508  -20
    arc_0_4_14  connected_order_arc_509  -14
    arc_0_4_14  out_degree_772  1
    arc_0_4_14  in_degree_787  1
    arc_0_4_14  original_T_including_depot_unload_838  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_508  1
    load_0_4_14  segment_load_conservation_776  1
    load_0_4_14  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_510  -20
    arc_0_4_15  connected_order_arc_511  -14
    arc_0_4_15  out_degree_772  1
    arc_0_4_15  in_degree_793  1
    arc_0_4_15  original_T_including_depot_unload_838  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_510  1
    load_0_4_15  segment_load_conservation_776  1
    load_0_4_15  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_512  -20
    arc_0_4_16  connected_order_arc_513  -14
    arc_0_4_16  out_degree_772  1
    arc_0_4_16  in_degree_799  1
    arc_0_4_16  original_T_including_depot_unload_838  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_512  1
    load_0_4_16  segment_load_conservation_776  1
    load_0_4_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_514  -20
    arc_0_4_17  connected_order_arc_515  -14
    arc_0_4_17  out_degree_772  1
    arc_0_4_17  in_degree_805  1
    arc_0_4_17  original_T_including_depot_unload_838  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_514  1
    load_0_4_17  segment_load_conservation_776  1
    load_0_4_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_516  -20
    arc_0_4_18  connected_order_arc_517  -14
    arc_0_4_18  out_degree_772  1
    arc_0_4_18  in_degree_811  1
    arc_0_4_18  original_T_including_depot_unload_838  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_516  1
    load_0_4_18  segment_load_conservation_776  1
    load_0_4_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_518  -20
    arc_0_4_19  connected_order_arc_519  -14
    arc_0_4_19  out_degree_772  1
    arc_0_4_19  in_degree_817  1
    arc_0_4_19  original_T_including_depot_unload_838  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_518  1
    load_0_4_19  segment_load_conservation_776  1
    load_0_4_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_520  -20
    arc_0_4_20  connected_order_arc_521  -14
    arc_0_4_20  out_degree_772  1
    arc_0_4_20  in_degree_823  1
    arc_0_4_20  original_T_including_depot_unload_838  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_520  1
    load_0_4_20  segment_load_conservation_776  1
    load_0_4_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_522  -20
    arc_0_4_21  connected_order_arc_523  -14
    arc_0_4_21  out_degree_772  1
    arc_0_4_21  in_degree_829  1
    arc_0_4_21  original_T_including_depot_unload_838  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_522  1
    load_0_4_21  segment_load_conservation_776  1
    load_0_4_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_524  -20
    arc_0_5_0  depot_return_or_bypass_750  1
    arc_0_5_0  out_degree_779  1
    arc_0_5_0  original_T_including_depot_unload_838  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_524  1
    load_0_5_0  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_525  -20
    arc_0_5_1  connected_order_arc_526  -14
    arc_0_5_1  in_degree_752  1
    arc_0_5_1  out_degree_779  1
    arc_0_5_1  original_T_including_depot_unload_838  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_525  1
    load_0_5_1  segment_load_conservation_755  -1
    load_0_5_1  segment_prefix_lb_756  1
    load_0_5_1  segment_prefix_ub_757  1
    load_0_5_1  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_527  -20
    arc_0_5_2  connected_order_arc_528  -14
    arc_0_5_2  in_degree_759  1
    arc_0_5_2  out_degree_779  1
    arc_0_5_2  original_T_including_depot_unload_838  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_527  1
    load_0_5_2  segment_load_conservation_762  -1
    load_0_5_2  segment_prefix_lb_763  1
    load_0_5_2  segment_prefix_ub_764  1
    load_0_5_2  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_529  -20
    arc_0_5_3  connected_order_arc_530  -14
    arc_0_5_3  in_degree_766  1
    arc_0_5_3  out_degree_779  1
    arc_0_5_3  original_T_including_depot_unload_838  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_529  1
    load_0_5_3  segment_load_conservation_769  -1
    load_0_5_3  segment_prefix_lb_770  1
    load_0_5_3  segment_prefix_ub_771  1
    load_0_5_3  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_531  -20
    arc_0_5_4  connected_order_arc_532  -14
    arc_0_5_4  in_degree_773  1
    arc_0_5_4  out_degree_779  1
    arc_0_5_4  original_T_including_depot_unload_838  1035.83277530205
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_531  1
    load_0_5_4  segment_load_conservation_776  -1
    load_0_5_4  segment_prefix_lb_777  1
    load_0_5_4  segment_prefix_ub_778  1
    load_0_5_4  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_533  -20
    arc_0_5_14  connected_order_arc_534  -14
    arc_0_5_14  out_degree_779  1
    arc_0_5_14  in_degree_787  1
    arc_0_5_14  original_T_including_depot_unload_838  1.3663551195332984e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_533  1
    load_0_5_14  segment_load_conservation_783  1
    load_0_5_14  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_535  -20
    arc_0_5_15  connected_order_arc_536  -14
    arc_0_5_15  out_degree_779  1
    arc_0_5_15  in_degree_793  1
    arc_0_5_15  original_T_including_depot_unload_838  1.2450286067313011e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_535  1
    load_0_5_15  segment_load_conservation_783  1
    load_0_5_15  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_537  -20
    arc_0_5_16  connected_order_arc_538  -14
    arc_0_5_16  out_degree_779  1
    arc_0_5_16  in_degree_799  1
    arc_0_5_16  original_T_including_depot_unload_838  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_537  1
    load_0_5_16  segment_load_conservation_783  1
    load_0_5_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_539  -20
    arc_0_5_17  connected_order_arc_540  -14
    arc_0_5_17  out_degree_779  1
    arc_0_5_17  in_degree_805  1
    arc_0_5_17  original_T_including_depot_unload_838  1.1301442107738828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_539  1
    load_0_5_17  segment_load_conservation_783  1
    load_0_5_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_541  -20
    arc_0_5_18  connected_order_arc_542  -14
    arc_0_5_18  out_degree_779  1
    arc_0_5_18  in_degree_811  1
    arc_0_5_18  original_T_including_depot_unload_838  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_541  1
    load_0_5_18  segment_load_conservation_783  1
    load_0_5_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_543  -20
    arc_0_5_19  connected_order_arc_544  -14
    arc_0_5_19  out_degree_779  1
    arc_0_5_19  in_degree_817  1
    arc_0_5_19  original_T_including_depot_unload_838  1.1516424799836650e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_543  1
    load_0_5_19  segment_load_conservation_783  1
    load_0_5_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_545  -20
    arc_0_5_20  connected_order_arc_546  -14
    arc_0_5_20  out_degree_779  1
    arc_0_5_20  in_degree_823  1
    arc_0_5_20  original_T_including_depot_unload_838  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_545  1
    load_0_5_20  segment_load_conservation_783  1
    load_0_5_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_547  -20
    arc_0_5_21  connected_order_arc_548  -14
    arc_0_5_21  out_degree_779  1
    arc_0_5_21  in_degree_829  1
    arc_0_5_21  original_T_including_depot_unload_838  1.6719633410042259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_547  1
    load_0_5_21  segment_load_conservation_783  1
    load_0_5_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_549  -20
    arc_0_14_0  depot_return_or_bypass_750  1
    arc_0_14_0  out_degree_786  1
    arc_0_14_0  original_T_including_depot_unload_838  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_549  1
    load_0_14_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_550  -20
    arc_0_14_1  connected_order_arc_551  -14
    arc_0_14_1  in_degree_752  1
    arc_0_14_1  out_degree_786  1
    arc_0_14_1  original_T_including_depot_unload_838  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_550  1
    load_0_14_1  segment_load_conservation_755  -1
    load_0_14_1  segment_prefix_lb_756  1
    load_0_14_1  segment_prefix_ub_757  1
    load_0_14_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_552  -20
    arc_0_14_2  connected_order_arc_553  -14
    arc_0_14_2  in_degree_759  1
    arc_0_14_2  out_degree_786  1
    arc_0_14_2  original_T_including_depot_unload_838  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_552  1
    load_0_14_2  segment_load_conservation_762  -1
    load_0_14_2  segment_prefix_lb_763  1
    load_0_14_2  segment_prefix_ub_764  1
    load_0_14_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_554  -20
    arc_0_14_3  connected_order_arc_555  -14
    arc_0_14_3  in_degree_766  1
    arc_0_14_3  out_degree_786  1
    arc_0_14_3  original_T_including_depot_unload_838  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_554  1
    load_0_14_3  segment_load_conservation_769  -1
    load_0_14_3  segment_prefix_lb_770  1
    load_0_14_3  segment_prefix_ub_771  1
    load_0_14_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_556  -20
    arc_0_14_4  connected_order_arc_557  -14
    arc_0_14_4  in_degree_773  1
    arc_0_14_4  out_degree_786  1
    arc_0_14_4  original_T_including_depot_unload_838  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_556  1
    load_0_14_4  segment_load_conservation_776  -1
    load_0_14_4  segment_prefix_lb_777  1
    load_0_14_4  segment_prefix_ub_778  1
    load_0_14_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_558  -20
    arc_0_14_5  connected_order_arc_559  -14
    arc_0_14_5  in_degree_780  1
    arc_0_14_5  out_degree_786  1
    arc_0_14_5  original_T_including_depot_unload_838  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_558  1
    load_0_14_5  segment_load_conservation_783  -1
    load_0_14_5  segment_prefix_lb_784  1
    load_0_14_5  segment_prefix_ub_785  1
    load_0_14_5  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_560  -20
    arc_0_14_15  connected_order_arc_561  -14
    arc_0_14_15  out_degree_786  1
    arc_0_14_15  in_degree_793  1
    arc_0_14_15  original_T_including_depot_unload_838  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_560  1
    load_0_14_15  free_load_conservation_791  1
    load_0_14_15  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_562  -20
    arc_0_14_16  connected_order_arc_563  -14
    arc_0_14_16  out_degree_786  1
    arc_0_14_16  in_degree_799  1
    arc_0_14_16  original_T_including_depot_unload_838  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_562  1
    load_0_14_16  free_load_conservation_791  1
    load_0_14_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_564  -20
    arc_0_14_17  connected_order_arc_565  -14
    arc_0_14_17  out_degree_786  1
    arc_0_14_17  in_degree_805  1
    arc_0_14_17  original_T_including_depot_unload_838  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_564  1
    load_0_14_17  free_load_conservation_791  1
    load_0_14_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_566  -20
    arc_0_14_18  connected_order_arc_567  -14
    arc_0_14_18  out_degree_786  1
    arc_0_14_18  in_degree_811  1
    arc_0_14_18  original_T_including_depot_unload_838  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_566  1
    load_0_14_18  free_load_conservation_791  1
    load_0_14_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_568  -20
    arc_0_14_19  connected_order_arc_569  -14
    arc_0_14_19  out_degree_786  1
    arc_0_14_19  in_degree_817  1
    arc_0_14_19  original_T_including_depot_unload_838  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_568  1
    load_0_14_19  free_load_conservation_791  1
    load_0_14_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_570  -20
    arc_0_14_20  connected_order_arc_571  -14
    arc_0_14_20  out_degree_786  1
    arc_0_14_20  in_degree_823  1
    arc_0_14_20  original_T_including_depot_unload_838  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_570  1
    load_0_14_20  free_load_conservation_791  1
    load_0_14_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_572  -20
    arc_0_14_21  connected_order_arc_573  -14
    arc_0_14_21  out_degree_786  1
    arc_0_14_21  in_degree_829  1
    arc_0_14_21  original_T_including_depot_unload_838  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_572  1
    load_0_14_21  free_load_conservation_791  1
    load_0_14_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_574  -20
    arc_0_15_0  depot_return_or_bypass_750  1
    arc_0_15_0  out_degree_792  1
    arc_0_15_0  original_T_including_depot_unload_838  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_574  1
    load_0_15_0  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_575  -20
    arc_0_15_1  connected_order_arc_576  -14
    arc_0_15_1  in_degree_752  1
    arc_0_15_1  out_degree_792  1
    arc_0_15_1  original_T_including_depot_unload_838  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_575  1
    load_0_15_1  segment_load_conservation_755  -1
    load_0_15_1  segment_prefix_lb_756  1
    load_0_15_1  segment_prefix_ub_757  1
    load_0_15_1  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_577  -20
    arc_0_15_2  connected_order_arc_578  -14
    arc_0_15_2  in_degree_759  1
    arc_0_15_2  out_degree_792  1
    arc_0_15_2  original_T_including_depot_unload_838  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_577  1
    load_0_15_2  segment_load_conservation_762  -1
    load_0_15_2  segment_prefix_lb_763  1
    load_0_15_2  segment_prefix_ub_764  1
    load_0_15_2  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_579  -20
    arc_0_15_3  connected_order_arc_580  -14
    arc_0_15_3  in_degree_766  1
    arc_0_15_3  out_degree_792  1
    arc_0_15_3  original_T_including_depot_unload_838  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_579  1
    load_0_15_3  segment_load_conservation_769  -1
    load_0_15_3  segment_prefix_lb_770  1
    load_0_15_3  segment_prefix_ub_771  1
    load_0_15_3  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_581  -20
    arc_0_15_4  connected_order_arc_582  -14
    arc_0_15_4  in_degree_773  1
    arc_0_15_4  out_degree_792  1
    arc_0_15_4  original_T_including_depot_unload_838  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_581  1
    load_0_15_4  segment_load_conservation_776  -1
    load_0_15_4  segment_prefix_lb_777  1
    load_0_15_4  segment_prefix_ub_778  1
    load_0_15_4  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_583  -20
    arc_0_15_5  connected_order_arc_584  -14
    arc_0_15_5  in_degree_780  1
    arc_0_15_5  out_degree_792  1
    arc_0_15_5  original_T_including_depot_unload_838  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_583  1
    load_0_15_5  segment_load_conservation_783  -1
    load_0_15_5  segment_prefix_lb_784  1
    load_0_15_5  segment_prefix_ub_785  1
    load_0_15_5  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_585  -20
    arc_0_15_14  connected_order_arc_586  -14
    arc_0_15_14  in_degree_787  1
    arc_0_15_14  out_degree_792  1
    arc_0_15_14  original_T_including_depot_unload_838  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_585  1
    load_0_15_14  free_load_conservation_791  -1
    load_0_15_14  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_587  -20
    arc_0_15_16  connected_order_arc_588  -14
    arc_0_15_16  out_degree_792  1
    arc_0_15_16  in_degree_799  1
    arc_0_15_16  original_T_including_depot_unload_838  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_587  1
    load_0_15_16  free_load_conservation_797  1
    load_0_15_16  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_589  -20
    arc_0_15_17  connected_order_arc_590  -14
    arc_0_15_17  out_degree_792  1
    arc_0_15_17  in_degree_805  1
    arc_0_15_17  original_T_including_depot_unload_838  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_589  1
    load_0_15_17  free_load_conservation_797  1
    load_0_15_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_591  -20
    arc_0_15_18  connected_order_arc_592  -14
    arc_0_15_18  out_degree_792  1
    arc_0_15_18  in_degree_811  1
    arc_0_15_18  original_T_including_depot_unload_838  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_591  1
    load_0_15_18  free_load_conservation_797  1
    load_0_15_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_593  -20
    arc_0_15_19  connected_order_arc_594  -14
    arc_0_15_19  out_degree_792  1
    arc_0_15_19  in_degree_817  1
    arc_0_15_19  original_T_including_depot_unload_838  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_593  1
    load_0_15_19  free_load_conservation_797  1
    load_0_15_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_595  -20
    arc_0_15_20  connected_order_arc_596  -14
    arc_0_15_20  out_degree_792  1
    arc_0_15_20  in_degree_823  1
    arc_0_15_20  original_T_including_depot_unload_838  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_595  1
    load_0_15_20  free_load_conservation_797  1
    load_0_15_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_597  -20
    arc_0_15_21  connected_order_arc_598  -14
    arc_0_15_21  out_degree_792  1
    arc_0_15_21  in_degree_829  1
    arc_0_15_21  original_T_including_depot_unload_838  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_597  1
    load_0_15_21  free_load_conservation_797  1
    load_0_15_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_599  -20
    arc_0_16_0  depot_return_or_bypass_750  1
    arc_0_16_0  out_degree_798  1
    arc_0_16_0  original_T_including_depot_unload_838  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_599  1
    load_0_16_0  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_600  -20
    arc_0_16_1  connected_order_arc_601  -14
    arc_0_16_1  in_degree_752  1
    arc_0_16_1  out_degree_798  1
    arc_0_16_1  original_T_including_depot_unload_838  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_600  1
    load_0_16_1  segment_load_conservation_755  -1
    load_0_16_1  segment_prefix_lb_756  1
    load_0_16_1  segment_prefix_ub_757  1
    load_0_16_1  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_602  -20
    arc_0_16_2  connected_order_arc_603  -14
    arc_0_16_2  in_degree_759  1
    arc_0_16_2  out_degree_798  1
    arc_0_16_2  original_T_including_depot_unload_838  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_602  1
    load_0_16_2  segment_load_conservation_762  -1
    load_0_16_2  segment_prefix_lb_763  1
    load_0_16_2  segment_prefix_ub_764  1
    load_0_16_2  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_604  -20
    arc_0_16_3  connected_order_arc_605  -14
    arc_0_16_3  in_degree_766  1
    arc_0_16_3  out_degree_798  1
    arc_0_16_3  original_T_including_depot_unload_838  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_604  1
    load_0_16_3  segment_load_conservation_769  -1
    load_0_16_3  segment_prefix_lb_770  1
    load_0_16_3  segment_prefix_ub_771  1
    load_0_16_3  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_606  -20
    arc_0_16_4  connected_order_arc_607  -14
    arc_0_16_4  in_degree_773  1
    arc_0_16_4  out_degree_798  1
    arc_0_16_4  original_T_including_depot_unload_838  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_606  1
    load_0_16_4  segment_load_conservation_776  -1
    load_0_16_4  segment_prefix_lb_777  1
    load_0_16_4  segment_prefix_ub_778  1
    load_0_16_4  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_608  -20
    arc_0_16_5  connected_order_arc_609  -14
    arc_0_16_5  in_degree_780  1
    arc_0_16_5  out_degree_798  1
    arc_0_16_5  original_T_including_depot_unload_838  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_608  1
    load_0_16_5  segment_load_conservation_783  -1
    load_0_16_5  segment_prefix_lb_784  1
    load_0_16_5  segment_prefix_ub_785  1
    load_0_16_5  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_610  -20
    arc_0_16_14  connected_order_arc_611  -14
    arc_0_16_14  in_degree_787  1
    arc_0_16_14  out_degree_798  1
    arc_0_16_14  original_T_including_depot_unload_838  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_610  1
    load_0_16_14  free_load_conservation_791  -1
    load_0_16_14  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_612  -20
    arc_0_16_15  connected_order_arc_613  -14
    arc_0_16_15  in_degree_793  1
    arc_0_16_15  out_degree_798  1
    arc_0_16_15  original_T_including_depot_unload_838  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_612  1
    load_0_16_15  free_load_conservation_797  -1
    load_0_16_15  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_614  -20
    arc_0_16_17  connected_order_arc_615  -14
    arc_0_16_17  out_degree_798  1
    arc_0_16_17  in_degree_805  1
    arc_0_16_17  original_T_including_depot_unload_838  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_614  1
    load_0_16_17  free_load_conservation_803  1
    load_0_16_17  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_616  -20
    arc_0_16_18  connected_order_arc_617  -14
    arc_0_16_18  out_degree_798  1
    arc_0_16_18  in_degree_811  1
    arc_0_16_18  original_T_including_depot_unload_838  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_616  1
    load_0_16_18  free_load_conservation_803  1
    load_0_16_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_618  -20
    arc_0_16_19  connected_order_arc_619  -14
    arc_0_16_19  out_degree_798  1
    arc_0_16_19  in_degree_817  1
    arc_0_16_19  original_T_including_depot_unload_838  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_618  1
    load_0_16_19  free_load_conservation_803  1
    load_0_16_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_620  -20
    arc_0_16_20  connected_order_arc_621  -14
    arc_0_16_20  out_degree_798  1
    arc_0_16_20  in_degree_823  1
    arc_0_16_20  original_T_including_depot_unload_838  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_620  1
    load_0_16_20  free_load_conservation_803  1
    load_0_16_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_622  -20
    arc_0_16_21  connected_order_arc_623  -14
    arc_0_16_21  out_degree_798  1
    arc_0_16_21  in_degree_829  1
    arc_0_16_21  original_T_including_depot_unload_838  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_622  1
    load_0_16_21  free_load_conservation_803  1
    load_0_16_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_624  -20
    arc_0_17_0  depot_return_or_bypass_750  1
    arc_0_17_0  out_degree_804  1
    arc_0_17_0  original_T_including_depot_unload_838  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_624  1
    load_0_17_0  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_625  -20
    arc_0_17_1  connected_order_arc_626  -14
    arc_0_17_1  in_degree_752  1
    arc_0_17_1  out_degree_804  1
    arc_0_17_1  original_T_including_depot_unload_838  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_625  1
    load_0_17_1  segment_load_conservation_755  -1
    load_0_17_1  segment_prefix_lb_756  1
    load_0_17_1  segment_prefix_ub_757  1
    load_0_17_1  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_627  -20
    arc_0_17_2  connected_order_arc_628  -14
    arc_0_17_2  in_degree_759  1
    arc_0_17_2  out_degree_804  1
    arc_0_17_2  original_T_including_depot_unload_838  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_627  1
    load_0_17_2  segment_load_conservation_762  -1
    load_0_17_2  segment_prefix_lb_763  1
    load_0_17_2  segment_prefix_ub_764  1
    load_0_17_2  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_629  -20
    arc_0_17_3  connected_order_arc_630  -14
    arc_0_17_3  in_degree_766  1
    arc_0_17_3  out_degree_804  1
    arc_0_17_3  original_T_including_depot_unload_838  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_629  1
    load_0_17_3  segment_load_conservation_769  -1
    load_0_17_3  segment_prefix_lb_770  1
    load_0_17_3  segment_prefix_ub_771  1
    load_0_17_3  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_631  -20
    arc_0_17_4  connected_order_arc_632  -14
    arc_0_17_4  in_degree_773  1
    arc_0_17_4  out_degree_804  1
    arc_0_17_4  original_T_including_depot_unload_838  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_631  1
    load_0_17_4  segment_load_conservation_776  -1
    load_0_17_4  segment_prefix_lb_777  1
    load_0_17_4  segment_prefix_ub_778  1
    load_0_17_4  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_633  -20
    arc_0_17_5  connected_order_arc_634  -14
    arc_0_17_5  in_degree_780  1
    arc_0_17_5  out_degree_804  1
    arc_0_17_5  original_T_including_depot_unload_838  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_633  1
    load_0_17_5  segment_load_conservation_783  -1
    load_0_17_5  segment_prefix_lb_784  1
    load_0_17_5  segment_prefix_ub_785  1
    load_0_17_5  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_635  -20
    arc_0_17_14  connected_order_arc_636  -14
    arc_0_17_14  in_degree_787  1
    arc_0_17_14  out_degree_804  1
    arc_0_17_14  original_T_including_depot_unload_838  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_635  1
    load_0_17_14  free_load_conservation_791  -1
    load_0_17_14  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_637  -20
    arc_0_17_15  connected_order_arc_638  -14
    arc_0_17_15  in_degree_793  1
    arc_0_17_15  out_degree_804  1
    arc_0_17_15  original_T_including_depot_unload_838  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_637  1
    load_0_17_15  free_load_conservation_797  -1
    load_0_17_15  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_639  -20
    arc_0_17_16  connected_order_arc_640  -14
    arc_0_17_16  in_degree_799  1
    arc_0_17_16  out_degree_804  1
    arc_0_17_16  original_T_including_depot_unload_838  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_639  1
    load_0_17_16  free_load_conservation_803  -1
    load_0_17_16  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_641  -20
    arc_0_17_18  connected_order_arc_642  -14
    arc_0_17_18  out_degree_804  1
    arc_0_17_18  in_degree_811  1
    arc_0_17_18  original_T_including_depot_unload_838  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_641  1
    load_0_17_18  free_load_conservation_809  1
    load_0_17_18  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_643  -20
    arc_0_17_19  connected_order_arc_644  -14
    arc_0_17_19  out_degree_804  1
    arc_0_17_19  in_degree_817  1
    arc_0_17_19  original_T_including_depot_unload_838  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_643  1
    load_0_17_19  free_load_conservation_809  1
    load_0_17_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_645  -20
    arc_0_17_20  connected_order_arc_646  -14
    arc_0_17_20  out_degree_804  1
    arc_0_17_20  in_degree_823  1
    arc_0_17_20  original_T_including_depot_unload_838  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_645  1
    load_0_17_20  free_load_conservation_809  1
    load_0_17_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_647  -20
    arc_0_17_21  connected_order_arc_648  -14
    arc_0_17_21  out_degree_804  1
    arc_0_17_21  in_degree_829  1
    arc_0_17_21  original_T_including_depot_unload_838  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_647  1
    load_0_17_21  free_load_conservation_809  1
    load_0_17_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_649  -20
    arc_0_18_0  depot_return_or_bypass_750  1
    arc_0_18_0  out_degree_810  1
    arc_0_18_0  original_T_including_depot_unload_838  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_649  1
    load_0_18_0  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_650  -20
    arc_0_18_1  connected_order_arc_651  -14
    arc_0_18_1  in_degree_752  1
    arc_0_18_1  out_degree_810  1
    arc_0_18_1  original_T_including_depot_unload_838  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_650  1
    load_0_18_1  segment_load_conservation_755  -1
    load_0_18_1  segment_prefix_lb_756  1
    load_0_18_1  segment_prefix_ub_757  1
    load_0_18_1  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_652  -20
    arc_0_18_2  connected_order_arc_653  -14
    arc_0_18_2  in_degree_759  1
    arc_0_18_2  out_degree_810  1
    arc_0_18_2  original_T_including_depot_unload_838  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_652  1
    load_0_18_2  segment_load_conservation_762  -1
    load_0_18_2  segment_prefix_lb_763  1
    load_0_18_2  segment_prefix_ub_764  1
    load_0_18_2  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_654  -20
    arc_0_18_3  connected_order_arc_655  -14
    arc_0_18_3  in_degree_766  1
    arc_0_18_3  out_degree_810  1
    arc_0_18_3  original_T_including_depot_unload_838  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_654  1
    load_0_18_3  segment_load_conservation_769  -1
    load_0_18_3  segment_prefix_lb_770  1
    load_0_18_3  segment_prefix_ub_771  1
    load_0_18_3  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_656  -20
    arc_0_18_4  connected_order_arc_657  -14
    arc_0_18_4  in_degree_773  1
    arc_0_18_4  out_degree_810  1
    arc_0_18_4  original_T_including_depot_unload_838  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_656  1
    load_0_18_4  segment_load_conservation_776  -1
    load_0_18_4  segment_prefix_lb_777  1
    load_0_18_4  segment_prefix_ub_778  1
    load_0_18_4  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_658  -20
    arc_0_18_5  connected_order_arc_659  -14
    arc_0_18_5  in_degree_780  1
    arc_0_18_5  out_degree_810  1
    arc_0_18_5  original_T_including_depot_unload_838  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_658  1
    load_0_18_5  segment_load_conservation_783  -1
    load_0_18_5  segment_prefix_lb_784  1
    load_0_18_5  segment_prefix_ub_785  1
    load_0_18_5  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_660  -20
    arc_0_18_14  connected_order_arc_661  -14
    arc_0_18_14  in_degree_787  1
    arc_0_18_14  out_degree_810  1
    arc_0_18_14  original_T_including_depot_unload_838  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_660  1
    load_0_18_14  free_load_conservation_791  -1
    load_0_18_14  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_662  -20
    arc_0_18_15  connected_order_arc_663  -14
    arc_0_18_15  in_degree_793  1
    arc_0_18_15  out_degree_810  1
    arc_0_18_15  original_T_including_depot_unload_838  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_662  1
    load_0_18_15  free_load_conservation_797  -1
    load_0_18_15  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_664  -20
    arc_0_18_16  connected_order_arc_665  -14
    arc_0_18_16  in_degree_799  1
    arc_0_18_16  out_degree_810  1
    arc_0_18_16  original_T_including_depot_unload_838  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_664  1
    load_0_18_16  free_load_conservation_803  -1
    load_0_18_16  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_666  -20
    arc_0_18_17  connected_order_arc_667  -14
    arc_0_18_17  in_degree_805  1
    arc_0_18_17  out_degree_810  1
    arc_0_18_17  original_T_including_depot_unload_838  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_666  1
    load_0_18_17  free_load_conservation_809  -1
    load_0_18_17  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_668  -20
    arc_0_18_19  connected_order_arc_669  -14
    arc_0_18_19  out_degree_810  1
    arc_0_18_19  in_degree_817  1
    arc_0_18_19  original_T_including_depot_unload_838  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_668  1
    load_0_18_19  free_load_conservation_815  1
    load_0_18_19  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_670  -20
    arc_0_18_20  connected_order_arc_671  -14
    arc_0_18_20  out_degree_810  1
    arc_0_18_20  in_degree_823  1
    arc_0_18_20  original_T_including_depot_unload_838  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_670  1
    load_0_18_20  free_load_conservation_815  1
    load_0_18_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_672  -20
    arc_0_18_21  connected_order_arc_673  -14
    arc_0_18_21  out_degree_810  1
    arc_0_18_21  in_degree_829  1
    arc_0_18_21  original_T_including_depot_unload_838  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_672  1
    load_0_18_21  free_load_conservation_815  1
    load_0_18_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_674  -20
    arc_0_19_0  depot_return_or_bypass_750  1
    arc_0_19_0  out_degree_816  1
    arc_0_19_0  original_T_including_depot_unload_838  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_674  1
    load_0_19_0  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_675  -20
    arc_0_19_1  connected_order_arc_676  -14
    arc_0_19_1  in_degree_752  1
    arc_0_19_1  out_degree_816  1
    arc_0_19_1  original_T_including_depot_unload_838  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_675  1
    load_0_19_1  segment_load_conservation_755  -1
    load_0_19_1  segment_prefix_lb_756  1
    load_0_19_1  segment_prefix_ub_757  1
    load_0_19_1  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_677  -20
    arc_0_19_2  connected_order_arc_678  -14
    arc_0_19_2  in_degree_759  1
    arc_0_19_2  out_degree_816  1
    arc_0_19_2  original_T_including_depot_unload_838  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_677  1
    load_0_19_2  segment_load_conservation_762  -1
    load_0_19_2  segment_prefix_lb_763  1
    load_0_19_2  segment_prefix_ub_764  1
    load_0_19_2  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_679  -20
    arc_0_19_3  connected_order_arc_680  -14
    arc_0_19_3  in_degree_766  1
    arc_0_19_3  out_degree_816  1
    arc_0_19_3  original_T_including_depot_unload_838  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_679  1
    load_0_19_3  segment_load_conservation_769  -1
    load_0_19_3  segment_prefix_lb_770  1
    load_0_19_3  segment_prefix_ub_771  1
    load_0_19_3  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_681  -20
    arc_0_19_4  connected_order_arc_682  -14
    arc_0_19_4  in_degree_773  1
    arc_0_19_4  out_degree_816  1
    arc_0_19_4  original_T_including_depot_unload_838  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_681  1
    load_0_19_4  segment_load_conservation_776  -1
    load_0_19_4  segment_prefix_lb_777  1
    load_0_19_4  segment_prefix_ub_778  1
    load_0_19_4  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_683  -20
    arc_0_19_5  connected_order_arc_684  -14
    arc_0_19_5  in_degree_780  1
    arc_0_19_5  out_degree_816  1
    arc_0_19_5  original_T_including_depot_unload_838  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_683  1
    load_0_19_5  segment_load_conservation_783  -1
    load_0_19_5  segment_prefix_lb_784  1
    load_0_19_5  segment_prefix_ub_785  1
    load_0_19_5  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_685  -20
    arc_0_19_14  connected_order_arc_686  -14
    arc_0_19_14  in_degree_787  1
    arc_0_19_14  out_degree_816  1
    arc_0_19_14  original_T_including_depot_unload_838  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_685  1
    load_0_19_14  free_load_conservation_791  -1
    load_0_19_14  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_687  -20
    arc_0_19_15  connected_order_arc_688  -14
    arc_0_19_15  in_degree_793  1
    arc_0_19_15  out_degree_816  1
    arc_0_19_15  original_T_including_depot_unload_838  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_687  1
    load_0_19_15  free_load_conservation_797  -1
    load_0_19_15  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_689  -20
    arc_0_19_16  connected_order_arc_690  -14
    arc_0_19_16  in_degree_799  1
    arc_0_19_16  out_degree_816  1
    arc_0_19_16  original_T_including_depot_unload_838  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_689  1
    load_0_19_16  free_load_conservation_803  -1
    load_0_19_16  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_691  -20
    arc_0_19_17  connected_order_arc_692  -14
    arc_0_19_17  in_degree_805  1
    arc_0_19_17  out_degree_816  1
    arc_0_19_17  original_T_including_depot_unload_838  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_691  1
    load_0_19_17  free_load_conservation_809  -1
    load_0_19_17  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_693  -20
    arc_0_19_18  connected_order_arc_694  -14
    arc_0_19_18  in_degree_811  1
    arc_0_19_18  out_degree_816  1
    arc_0_19_18  original_T_including_depot_unload_838  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_693  1
    load_0_19_18  free_load_conservation_815  -1
    load_0_19_18  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_695  -20
    arc_0_19_20  connected_order_arc_696  -14
    arc_0_19_20  out_degree_816  1
    arc_0_19_20  in_degree_823  1
    arc_0_19_20  original_T_including_depot_unload_838  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_695  1
    load_0_19_20  free_load_conservation_821  1
    load_0_19_20  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_697  -20
    arc_0_19_21  connected_order_arc_698  -14
    arc_0_19_21  out_degree_816  1
    arc_0_19_21  in_degree_829  1
    arc_0_19_21  original_T_including_depot_unload_838  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_697  1
    load_0_19_21  free_load_conservation_821  1
    load_0_19_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_699  -20
    arc_0_20_0  depot_return_or_bypass_750  1
    arc_0_20_0  out_degree_822  1
    arc_0_20_0  original_T_including_depot_unload_838  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_699  1
    load_0_20_0  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_700  -20
    arc_0_20_1  connected_order_arc_701  -14
    arc_0_20_1  in_degree_752  1
    arc_0_20_1  out_degree_822  1
    arc_0_20_1  original_T_including_depot_unload_838  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_700  1
    load_0_20_1  segment_load_conservation_755  -1
    load_0_20_1  segment_prefix_lb_756  1
    load_0_20_1  segment_prefix_ub_757  1
    load_0_20_1  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_702  -20
    arc_0_20_2  connected_order_arc_703  -14
    arc_0_20_2  in_degree_759  1
    arc_0_20_2  out_degree_822  1
    arc_0_20_2  original_T_including_depot_unload_838  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_702  1
    load_0_20_2  segment_load_conservation_762  -1
    load_0_20_2  segment_prefix_lb_763  1
    load_0_20_2  segment_prefix_ub_764  1
    load_0_20_2  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_704  -20
    arc_0_20_3  connected_order_arc_705  -14
    arc_0_20_3  in_degree_766  1
    arc_0_20_3  out_degree_822  1
    arc_0_20_3  original_T_including_depot_unload_838  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_704  1
    load_0_20_3  segment_load_conservation_769  -1
    load_0_20_3  segment_prefix_lb_770  1
    load_0_20_3  segment_prefix_ub_771  1
    load_0_20_3  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_706  -20
    arc_0_20_4  connected_order_arc_707  -14
    arc_0_20_4  in_degree_773  1
    arc_0_20_4  out_degree_822  1
    arc_0_20_4  original_T_including_depot_unload_838  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_706  1
    load_0_20_4  segment_load_conservation_776  -1
    load_0_20_4  segment_prefix_lb_777  1
    load_0_20_4  segment_prefix_ub_778  1
    load_0_20_4  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_708  -20
    arc_0_20_5  connected_order_arc_709  -14
    arc_0_20_5  in_degree_780  1
    arc_0_20_5  out_degree_822  1
    arc_0_20_5  original_T_including_depot_unload_838  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_708  1
    load_0_20_5  segment_load_conservation_783  -1
    load_0_20_5  segment_prefix_lb_784  1
    load_0_20_5  segment_prefix_ub_785  1
    load_0_20_5  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_710  -20
    arc_0_20_14  connected_order_arc_711  -14
    arc_0_20_14  in_degree_787  1
    arc_0_20_14  out_degree_822  1
    arc_0_20_14  original_T_including_depot_unload_838  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_710  1
    load_0_20_14  free_load_conservation_791  -1
    load_0_20_14  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_712  -20
    arc_0_20_15  connected_order_arc_713  -14
    arc_0_20_15  in_degree_793  1
    arc_0_20_15  out_degree_822  1
    arc_0_20_15  original_T_including_depot_unload_838  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_712  1
    load_0_20_15  free_load_conservation_797  -1
    load_0_20_15  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_714  -20
    arc_0_20_16  connected_order_arc_715  -14
    arc_0_20_16  in_degree_799  1
    arc_0_20_16  out_degree_822  1
    arc_0_20_16  original_T_including_depot_unload_838  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_714  1
    load_0_20_16  free_load_conservation_803  -1
    load_0_20_16  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_716  -20
    arc_0_20_17  connected_order_arc_717  -14
    arc_0_20_17  in_degree_805  1
    arc_0_20_17  out_degree_822  1
    arc_0_20_17  original_T_including_depot_unload_838  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_716  1
    load_0_20_17  free_load_conservation_809  -1
    load_0_20_17  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_718  -20
    arc_0_20_18  connected_order_arc_719  -14
    arc_0_20_18  in_degree_811  1
    arc_0_20_18  out_degree_822  1
    arc_0_20_18  original_T_including_depot_unload_838  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_718  1
    load_0_20_18  free_load_conservation_815  -1
    load_0_20_18  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_720  -20
    arc_0_20_19  connected_order_arc_721  -14
    arc_0_20_19  in_degree_817  1
    arc_0_20_19  out_degree_822  1
    arc_0_20_19  original_T_including_depot_unload_838  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_720  1
    load_0_20_19  free_load_conservation_821  -1
    load_0_20_19  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_722  -20
    arc_0_20_21  connected_order_arc_723  -14
    arc_0_20_21  out_degree_822  1
    arc_0_20_21  in_degree_829  1
    arc_0_20_21  original_T_including_depot_unload_838  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_722  1
    load_0_20_21  free_load_conservation_827  1
    load_0_20_21  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_724  -20
    arc_0_21_0  depot_return_or_bypass_750  1
    arc_0_21_0  out_degree_828  1
    arc_0_21_0  original_T_including_depot_unload_838  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_724  1
    load_0_21_0  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_725  -20
    arc_0_21_1  connected_order_arc_726  -14
    arc_0_21_1  in_degree_752  1
    arc_0_21_1  out_degree_828  1
    arc_0_21_1  original_T_including_depot_unload_838  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_725  1
    load_0_21_1  segment_load_conservation_755  -1
    load_0_21_1  segment_prefix_lb_756  1
    load_0_21_1  segment_prefix_ub_757  1
    load_0_21_1  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_727  -20
    arc_0_21_2  connected_order_arc_728  -14
    arc_0_21_2  in_degree_759  1
    arc_0_21_2  out_degree_828  1
    arc_0_21_2  original_T_including_depot_unload_838  8.9619134786808888e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_727  1
    load_0_21_2  segment_load_conservation_762  -1
    load_0_21_2  segment_prefix_lb_763  1
    load_0_21_2  segment_prefix_ub_764  1
    load_0_21_2  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_729  -20
    arc_0_21_3  connected_order_arc_730  -14
    arc_0_21_3  in_degree_766  1
    arc_0_21_3  out_degree_828  1
    arc_0_21_3  original_T_including_depot_unload_838  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_729  1
    load_0_21_3  segment_load_conservation_769  -1
    load_0_21_3  segment_prefix_lb_770  1
    load_0_21_3  segment_prefix_ub_771  1
    load_0_21_3  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_731  -20
    arc_0_21_4  connected_order_arc_732  -14
    arc_0_21_4  in_degree_773  1
    arc_0_21_4  out_degree_828  1
    arc_0_21_4  original_T_including_depot_unload_838  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_731  1
    load_0_21_4  segment_load_conservation_776  -1
    load_0_21_4  segment_prefix_lb_777  1
    load_0_21_4  segment_prefix_ub_778  1
    load_0_21_4  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_733  -20
    arc_0_21_5  connected_order_arc_734  -14
    arc_0_21_5  in_degree_780  1
    arc_0_21_5  out_degree_828  1
    arc_0_21_5  original_T_including_depot_unload_838  9.0007741891713113e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_733  1
    load_0_21_5  segment_load_conservation_783  -1
    load_0_21_5  segment_prefix_lb_784  1
    load_0_21_5  segment_prefix_ub_785  1
    load_0_21_5  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_735  -20
    arc_0_21_14  connected_order_arc_736  -14
    arc_0_21_14  in_degree_787  1
    arc_0_21_14  out_degree_828  1
    arc_0_21_14  original_T_including_depot_unload_838  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_735  1
    load_0_21_14  free_load_conservation_791  -1
    load_0_21_14  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_737  -20
    arc_0_21_15  connected_order_arc_738  -14
    arc_0_21_15  in_degree_793  1
    arc_0_21_15  out_degree_828  1
    arc_0_21_15  original_T_including_depot_unload_838  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_737  1
    load_0_21_15  free_load_conservation_797  -1
    load_0_21_15  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_739  -20
    arc_0_21_16  connected_order_arc_740  -14
    arc_0_21_16  in_degree_799  1
    arc_0_21_16  out_degree_828  1
    arc_0_21_16  original_T_including_depot_unload_838  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_739  1
    load_0_21_16  free_load_conservation_803  -1
    load_0_21_16  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_741  -20
    arc_0_21_17  connected_order_arc_742  -14
    arc_0_21_17  in_degree_805  1
    arc_0_21_17  out_degree_828  1
    arc_0_21_17  original_T_including_depot_unload_838  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_741  1
    load_0_21_17  free_load_conservation_809  -1
    load_0_21_17  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_743  -20
    arc_0_21_18  connected_order_arc_744  -14
    arc_0_21_18  in_degree_811  1
    arc_0_21_18  out_degree_828  1
    arc_0_21_18  original_T_including_depot_unload_838  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_743  1
    load_0_21_18  free_load_conservation_815  -1
    load_0_21_18  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_745  -20
    arc_0_21_19  connected_order_arc_746  -14
    arc_0_21_19  in_degree_817  1
    arc_0_21_19  out_degree_828  1
    arc_0_21_19  original_T_including_depot_unload_838  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_745  1
    load_0_21_19  free_load_conservation_821  -1
    load_0_21_19  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_747  -20
    arc_0_21_20  connected_order_arc_748  -14
    arc_0_21_20  in_degree_823  1
    arc_0_21_20  out_degree_828  1
    arc_0_21_20  original_T_including_depot_unload_838  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_747  1
    load_0_21_20  free_load_conservation_827  -1
    load_0_21_20  free_load_conservation_833  1
    visit_1_6  out_degree_1130  -1
    visit_1_6  in_degree_1131  -1
    visit_1_6  order_active_lb_1132  -1
    visit_1_6  order_active_ub_1133  -12
    order_1_6  connected_order_arc_854  -1
    order_1_6  connected_order_arc_856  -1
    order_1_6  connected_order_arc_858  -1
    order_1_6  connected_order_arc_860  -1
    order_1_6  connected_order_arc_862  -1
    order_1_6  connected_order_arc_864  -1
    order_1_6  connected_order_arc_866  -1
    order_1_6  connected_order_arc_868  -1
    order_1_6  connected_order_arc_870  -1
    order_1_6  connected_order_arc_872  -1
    order_1_6  connected_order_arc_874  -1
    order_1_6  connected_order_arc_877  1
    order_1_6  connected_order_arc_900  1
    order_1_6  connected_order_arc_923  1
    order_1_6  connected_order_arc_946  1
    order_1_6  connected_order_arc_969  1
    order_1_6  connected_order_arc_992  1
    order_1_6  connected_order_arc_1015  1
    order_1_6  connected_order_arc_1038  1
    order_1_6  connected_order_arc_1061  1
    order_1_6  connected_order_arc_1084  1
    order_1_6  connected_order_arc_1107  1
    order_1_6  order_active_lb_1132  1
    order_1_6  order_active_ub_1133  1
    order_1_6  fixed_segment_relative_order_1206  -1
    visit_1_7  out_degree_1137  -1
    visit_1_7  in_degree_1138  -1
    visit_1_7  order_active_lb_1139  -1
    visit_1_7  order_active_ub_1140  -12
    order_1_7  connected_order_arc_854  1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_879  -1
    order_1_7  connected_order_arc_881  -1
    order_1_7  connected_order_arc_883  -1
    order_1_7  connected_order_arc_885  -1
    order_1_7  connected_order_arc_887  -1
    order_1_7  connected_order_arc_889  -1
    order_1_7  connected_order_arc_891  -1
    order_1_7  connected_order_arc_893  -1
    order_1_7  connected_order_arc_895  -1
    order_1_7  connected_order_arc_897  -1
    order_1_7  connected_order_arc_902  1
    order_1_7  connected_order_arc_925  1
    order_1_7  connected_order_arc_948  1
    order_1_7  connected_order_arc_971  1
    order_1_7  connected_order_arc_994  1
    order_1_7  connected_order_arc_1017  1
    order_1_7  connected_order_arc_1040  1
    order_1_7  connected_order_arc_1063  1
    order_1_7  connected_order_arc_1086  1
    order_1_7  connected_order_arc_1109  1
    order_1_7  order_active_lb_1139  1
    order_1_7  order_active_ub_1140  1
    order_1_7  fixed_segment_relative_order_1206  1
    order_1_7  fixed_segment_relative_order_1207  -1
    visit_1_8  out_degree_1144  -1
    visit_1_8  in_degree_1145  -1
    visit_1_8  order_active_lb_1146  -1
    visit_1_8  order_active_ub_1147  -12
    order_1_8  connected_order_arc_856  1
    order_1_8  connected_order_arc_879  1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_904  -1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_908  -1
    order_1_8  connected_order_arc_910  -1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_914  -1
    order_1_8  connected_order_arc_916  -1
    order_1_8  connected_order_arc_918  -1
    order_1_8  connected_order_arc_920  -1
    order_1_8  connected_order_arc_927  1
    order_1_8  connected_order_arc_950  1
    order_1_8  connected_order_arc_973  1
    order_1_8  connected_order_arc_996  1
    order_1_8  connected_order_arc_1019  1
    order_1_8  connected_order_arc_1042  1
    order_1_8  connected_order_arc_1065  1
    order_1_8  connected_order_arc_1088  1
    order_1_8  connected_order_arc_1111  1
    order_1_8  order_active_lb_1146  1
    order_1_8  order_active_ub_1147  1
    order_1_8  fixed_segment_relative_order_1207  1
    order_1_8  fixed_segment_relative_order_1208  -1
    visit_1_9  out_degree_1151  -1
    visit_1_9  in_degree_1152  -1
    visit_1_9  order_active_lb_1153  -1
    visit_1_9  order_active_ub_1154  -12
    order_1_9  connected_order_arc_858  1
    order_1_9  connected_order_arc_881  1
    order_1_9  connected_order_arc_904  1
    order_1_9  connected_order_arc_923  -1
    order_1_9  connected_order_arc_925  -1
    order_1_9  connected_order_arc_927  -1
    order_1_9  connected_order_arc_929  -1
    order_1_9  connected_order_arc_931  -1
    order_1_9  connected_order_arc_933  -1
    order_1_9  connected_order_arc_935  -1
    order_1_9  connected_order_arc_937  -1
    order_1_9  connected_order_arc_939  -1
    order_1_9  connected_order_arc_941  -1
    order_1_9  connected_order_arc_943  -1
    order_1_9  connected_order_arc_952  1
    order_1_9  connected_order_arc_975  1
    order_1_9  connected_order_arc_998  1
    order_1_9  connected_order_arc_1021  1
    order_1_9  connected_order_arc_1044  1
    order_1_9  connected_order_arc_1067  1
    order_1_9  connected_order_arc_1090  1
    order_1_9  connected_order_arc_1113  1
    order_1_9  order_active_lb_1153  1
    order_1_9  order_active_ub_1154  1
    order_1_9  fixed_segment_relative_order_1208  1
    visit_1_14  out_degree_1158  -1
    visit_1_14  in_degree_1159  -1
    visit_1_14  order_active_lb_1160  -1
    visit_1_14  order_active_ub_1161  -12
    visit_1_14  service_visit_def_1162  -1
    order_1_14  connected_order_arc_860  1
    order_1_14  connected_order_arc_883  1
    order_1_14  connected_order_arc_906  1
    order_1_14  connected_order_arc_929  1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_956  -1
    order_1_14  connected_order_arc_958  -1
    order_1_14  connected_order_arc_960  -1
    order_1_14  connected_order_arc_962  -1
    order_1_14  connected_order_arc_964  -1
    order_1_14  connected_order_arc_966  -1
    order_1_14  connected_order_arc_977  1
    order_1_14  connected_order_arc_1000  1
    order_1_14  connected_order_arc_1023  1
    order_1_14  connected_order_arc_1046  1
    order_1_14  connected_order_arc_1069  1
    order_1_14  connected_order_arc_1092  1
    order_1_14  connected_order_arc_1115  1
    order_1_14  order_active_lb_1160  1
    order_1_14  order_active_ub_1161  1
    visit_1_15  out_degree_1164  -1
    visit_1_15  in_degree_1165  -1
    visit_1_15  order_active_lb_1166  -1
    visit_1_15  order_active_ub_1167  -12
    visit_1_15  service_visit_def_1168  -1
    order_1_15  connected_order_arc_862  1
    order_1_15  connected_order_arc_885  1
    order_1_15  connected_order_arc_908  1
    order_1_15  connected_order_arc_931  1
    order_1_15  connected_order_arc_954  1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_987  -1
    order_1_15  connected_order_arc_989  -1
    order_1_15  connected_order_arc_1002  1
    order_1_15  connected_order_arc_1025  1
    order_1_15  connected_order_arc_1048  1
    order_1_15  connected_order_arc_1071  1
    order_1_15  connected_order_arc_1094  1
    order_1_15  connected_order_arc_1117  1
    order_1_15  order_active_lb_1166  1
    order_1_15  order_active_ub_1167  1
    visit_1_16  out_degree_1170  -1
    visit_1_16  in_degree_1171  -1
    visit_1_16  order_active_lb_1172  -1
    visit_1_16  order_active_ub_1173  -12
    visit_1_16  service_visit_def_1174  -1
    order_1_16  connected_order_arc_864  1
    order_1_16  connected_order_arc_887  1
    order_1_16  connected_order_arc_910  1
    order_1_16  connected_order_arc_933  1
    order_1_16  connected_order_arc_956  1
    order_1_16  connected_order_arc_979  1
    order_1_16  connected_order_arc_992  -1
    order_1_16  connected_order_arc_994  -1
    order_1_16  connected_order_arc_996  -1
    order_1_16  connected_order_arc_998  -1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1027  1
    order_1_16  connected_order_arc_1050  1
    order_1_16  connected_order_arc_1073  1
    order_1_16  connected_order_arc_1096  1
    order_1_16  connected_order_arc_1119  1
    order_1_16  order_active_lb_1172  1
    order_1_16  order_active_ub_1173  1
    visit_1_17  out_degree_1176  -1
    visit_1_17  in_degree_1177  -1
    visit_1_17  order_active_lb_1178  -1
    visit_1_17  order_active_ub_1179  -12
    visit_1_17  service_visit_def_1180  -1
    order_1_17  connected_order_arc_866  1
    order_1_17  connected_order_arc_889  1
    order_1_17  connected_order_arc_912  1
    order_1_17  connected_order_arc_935  1
    order_1_17  connected_order_arc_958  1
    order_1_17  connected_order_arc_981  1
    order_1_17  connected_order_arc_1004  1
    order_1_17  connected_order_arc_1015  -1
    order_1_17  connected_order_arc_1017  -1
    order_1_17  connected_order_arc_1019  -1
    order_1_17  connected_order_arc_1021  -1
    order_1_17  connected_order_arc_1023  -1
    order_1_17  connected_order_arc_1025  -1
    order_1_17  connected_order_arc_1027  -1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1033  -1
    order_1_17  connected_order_arc_1035  -1
    order_1_17  connected_order_arc_1052  1
    order_1_17  connected_order_arc_1075  1
    order_1_17  connected_order_arc_1098  1
    order_1_17  connected_order_arc_1121  1
    order_1_17  order_active_lb_1178  1
    order_1_17  order_active_ub_1179  1
    visit_1_18  out_degree_1182  -1
    visit_1_18  in_degree_1183  -1
    visit_1_18  order_active_lb_1184  -1
    visit_1_18  order_active_ub_1185  -12
    visit_1_18  service_visit_def_1186  -1
    order_1_18  connected_order_arc_868  1
    order_1_18  connected_order_arc_891  1
    order_1_18  connected_order_arc_914  1
    order_1_18  connected_order_arc_937  1
    order_1_18  connected_order_arc_960  1
    order_1_18  connected_order_arc_983  1
    order_1_18  connected_order_arc_1006  1
    order_1_18  connected_order_arc_1029  1
    order_1_18  connected_order_arc_1038  -1
    order_1_18  connected_order_arc_1040  -1
    order_1_18  connected_order_arc_1042  -1
    order_1_18  connected_order_arc_1044  -1
    order_1_18  connected_order_arc_1046  -1
    order_1_18  connected_order_arc_1048  -1
    order_1_18  connected_order_arc_1050  -1
    order_1_18  connected_order_arc_1052  -1
    order_1_18  connected_order_arc_1054  -1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1058  -1
    order_1_18  connected_order_arc_1077  1
    order_1_18  connected_order_arc_1100  1
    order_1_18  connected_order_arc_1123  1
    order_1_18  order_active_lb_1184  1
    order_1_18  order_active_ub_1185  1
    visit_1_19  out_degree_1188  -1
    visit_1_19  in_degree_1189  -1
    visit_1_19  order_active_lb_1190  -1
    visit_1_19  order_active_ub_1191  -12
    visit_1_19  service_visit_def_1192  -1
    order_1_19  connected_order_arc_870  1
    order_1_19  connected_order_arc_893  1
    order_1_19  connected_order_arc_916  1
    order_1_19  connected_order_arc_939  1
    order_1_19  connected_order_arc_962  1
    order_1_19  connected_order_arc_985  1
    order_1_19  connected_order_arc_1008  1
    order_1_19  connected_order_arc_1031  1
    order_1_19  connected_order_arc_1054  1
    order_1_19  connected_order_arc_1061  -1
    order_1_19  connected_order_arc_1063  -1
    order_1_19  connected_order_arc_1065  -1
    order_1_19  connected_order_arc_1067  -1
    order_1_19  connected_order_arc_1069  -1
    order_1_19  connected_order_arc_1071  -1
    order_1_19  connected_order_arc_1073  -1
    order_1_19  connected_order_arc_1075  -1
    order_1_19  connected_order_arc_1077  -1
    order_1_19  connected_order_arc_1079  -1
    order_1_19  connected_order_arc_1081  -1
    order_1_19  connected_order_arc_1102  1
    order_1_19  connected_order_arc_1125  1
    order_1_19  order_active_lb_1190  1
    order_1_19  order_active_ub_1191  1
    visit_1_20  out_degree_1194  -1
    visit_1_20  in_degree_1195  -1
    visit_1_20  order_active_lb_1196  -1
    visit_1_20  order_active_ub_1197  -12
    visit_1_20  service_visit_def_1198  -1
    order_1_20  connected_order_arc_872  1
    order_1_20  connected_order_arc_895  1
    order_1_20  connected_order_arc_918  1
    order_1_20  connected_order_arc_941  1
    order_1_20  connected_order_arc_964  1
    order_1_20  connected_order_arc_987  1
    order_1_20  connected_order_arc_1010  1
    order_1_20  connected_order_arc_1033  1
    order_1_20  connected_order_arc_1056  1
    order_1_20  connected_order_arc_1079  1
    order_1_20  connected_order_arc_1084  -1
    order_1_20  connected_order_arc_1086  -1
    order_1_20  connected_order_arc_1088  -1
    order_1_20  connected_order_arc_1090  -1
    order_1_20  connected_order_arc_1092  -1
    order_1_20  connected_order_arc_1094  -1
    order_1_20  connected_order_arc_1096  -1
    order_1_20  connected_order_arc_1098  -1
    order_1_20  connected_order_arc_1100  -1
    order_1_20  connected_order_arc_1102  -1
    order_1_20  connected_order_arc_1104  -1
    order_1_20  connected_order_arc_1127  1
    order_1_20  order_active_lb_1196  1
    order_1_20  order_active_ub_1197  1
    visit_1_21  out_degree_1200  -1
    visit_1_21  in_degree_1201  -1
    visit_1_21  order_active_lb_1202  -1
    visit_1_21  order_active_ub_1203  -12
    visit_1_21  service_visit_def_1204  -1
    order_1_21  connected_order_arc_874  1
    order_1_21  connected_order_arc_897  1
    order_1_21  connected_order_arc_920  1
    order_1_21  connected_order_arc_943  1
    order_1_21  connected_order_arc_966  1
    order_1_21  connected_order_arc_989  1
    order_1_21  connected_order_arc_1012  1
    order_1_21  connected_order_arc_1035  1
    order_1_21  connected_order_arc_1058  1
    order_1_21  connected_order_arc_1081  1
    order_1_21  connected_order_arc_1104  1
    order_1_21  connected_order_arc_1107  -1
    order_1_21  connected_order_arc_1109  -1
    order_1_21  connected_order_arc_1111  -1
    order_1_21  connected_order_arc_1113  -1
    order_1_21  connected_order_arc_1115  -1
    order_1_21  connected_order_arc_1117  -1
    order_1_21  connected_order_arc_1119  -1
    order_1_21  connected_order_arc_1121  -1
    order_1_21  connected_order_arc_1123  -1
    order_1_21  connected_order_arc_1125  -1
    order_1_21  connected_order_arc_1127  -1
    order_1_21  order_active_lb_1202  1
    order_1_21  order_active_ub_1203  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_839  -25
    arc_1_0_0  depot_departure_or_bypass_1128  1
    arc_1_0_0  depot_return_or_bypass_1129  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_840  -25
    arc_1_0_6  depot_departure_or_bypass_1128  1
    arc_1_0_6  in_degree_1131  1
    arc_1_0_6  original_T_including_depot_unload_1209  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_840  1
    load_1_0_6  segment_load_conservation_1134  -1
    load_1_0_6  segment_prefix_lb_1135  1
    load_1_0_6  segment_prefix_ub_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_841  -25
    arc_1_0_7  depot_departure_or_bypass_1128  1
    arc_1_0_7  in_degree_1138  1
    arc_1_0_7  original_T_including_depot_unload_1209  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_841  1
    load_1_0_7  segment_load_conservation_1141  -1
    load_1_0_7  segment_prefix_lb_1142  1
    load_1_0_7  segment_prefix_ub_1143  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_842  -25
    arc_1_0_8  depot_departure_or_bypass_1128  1
    arc_1_0_8  in_degree_1145  1
    arc_1_0_8  original_T_including_depot_unload_1209  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_842  1
    load_1_0_8  segment_load_conservation_1148  -1
    load_1_0_8  segment_prefix_lb_1149  1
    load_1_0_8  segment_prefix_ub_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_843  -25
    arc_1_0_9  depot_departure_or_bypass_1128  1
    arc_1_0_9  in_degree_1152  1
    arc_1_0_9  original_T_including_depot_unload_1209  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_843  1
    load_1_0_9  segment_load_conservation_1155  -1
    load_1_0_9  segment_prefix_lb_1156  1
    load_1_0_9  segment_prefix_ub_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_844  -25
    arc_1_0_14  depot_departure_or_bypass_1128  1
    arc_1_0_14  in_degree_1159  1
    arc_1_0_14  original_T_including_depot_unload_1209  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_844  1
    load_1_0_14  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_845  -25
    arc_1_0_15  depot_departure_or_bypass_1128  1
    arc_1_0_15  in_degree_1165  1
    arc_1_0_15  original_T_including_depot_unload_1209  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_845  1
    load_1_0_15  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_846  -25
    arc_1_0_16  depot_departure_or_bypass_1128  1
    arc_1_0_16  in_degree_1171  1
    arc_1_0_16  original_T_including_depot_unload_1209  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_846  1
    load_1_0_16  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_847  -25
    arc_1_0_17  depot_departure_or_bypass_1128  1
    arc_1_0_17  in_degree_1177  1
    arc_1_0_17  original_T_including_depot_unload_1209  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_847  1
    load_1_0_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_848  -25
    arc_1_0_18  depot_departure_or_bypass_1128  1
    arc_1_0_18  in_degree_1183  1
    arc_1_0_18  original_T_including_depot_unload_1209  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_848  1
    load_1_0_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_849  -25
    arc_1_0_19  depot_departure_or_bypass_1128  1
    arc_1_0_19  in_degree_1189  1
    arc_1_0_19  original_T_including_depot_unload_1209  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_849  1
    load_1_0_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_850  -25
    arc_1_0_20  depot_departure_or_bypass_1128  1
    arc_1_0_20  in_degree_1195  1
    arc_1_0_20  original_T_including_depot_unload_1209  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_850  1
    load_1_0_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_851  -25
    arc_1_0_21  depot_departure_or_bypass_1128  1
    arc_1_0_21  in_degree_1201  1
    arc_1_0_21  original_T_including_depot_unload_1209  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_851  1
    load_1_0_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_852  -25
    arc_1_6_0  depot_return_or_bypass_1129  1
    arc_1_6_0  out_degree_1130  1
    arc_1_6_0  original_T_including_depot_unload_1209  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_852  1
    load_1_6_0  segment_load_conservation_1134  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_853  -25
    arc_1_6_7  connected_order_arc_854  -13
    arc_1_6_7  out_degree_1130  1
    arc_1_6_7  in_degree_1138  1
    arc_1_6_7  original_T_including_depot_unload_1209  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_853  1
    load_1_6_7  segment_load_conservation_1134  1
    load_1_6_7  segment_load_conservation_1141  -1
    load_1_6_7  segment_prefix_lb_1142  1
    load_1_6_7  segment_prefix_ub_1143  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_855  -25
    arc_1_6_8  connected_order_arc_856  -13
    arc_1_6_8  out_degree_1130  1
    arc_1_6_8  in_degree_1145  1
    arc_1_6_8  original_T_including_depot_unload_1209  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_855  1
    load_1_6_8  segment_load_conservation_1134  1
    load_1_6_8  segment_load_conservation_1148  -1
    load_1_6_8  segment_prefix_lb_1149  1
    load_1_6_8  segment_prefix_ub_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_857  -25
    arc_1_6_9  connected_order_arc_858  -13
    arc_1_6_9  out_degree_1130  1
    arc_1_6_9  in_degree_1152  1
    arc_1_6_9  original_T_including_depot_unload_1209  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_857  1
    load_1_6_9  segment_load_conservation_1134  1
    load_1_6_9  segment_load_conservation_1155  -1
    load_1_6_9  segment_prefix_lb_1156  1
    load_1_6_9  segment_prefix_ub_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_859  -25
    arc_1_6_14  connected_order_arc_860  -13
    arc_1_6_14  out_degree_1130  1
    arc_1_6_14  in_degree_1159  1
    arc_1_6_14  original_T_including_depot_unload_1209  1829.33035879167
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_859  1
    load_1_6_14  segment_load_conservation_1134  1
    load_1_6_14  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_861  -25
    arc_1_6_15  connected_order_arc_862  -13
    arc_1_6_15  out_degree_1130  1
    arc_1_6_15  in_degree_1165  1
    arc_1_6_15  original_T_including_depot_unload_1209  1.9270569168668533e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_861  1
    load_1_6_15  segment_load_conservation_1134  1
    load_1_6_15  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_863  -25
    arc_1_6_16  connected_order_arc_864  -13
    arc_1_6_16  out_degree_1130  1
    arc_1_6_16  in_degree_1171  1
    arc_1_6_16  original_T_including_depot_unload_1209  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_863  1
    load_1_6_16  segment_load_conservation_1134  1
    load_1_6_16  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_865  -25
    arc_1_6_17  connected_order_arc_866  -13
    arc_1_6_17  out_degree_1130  1
    arc_1_6_17  in_degree_1177  1
    arc_1_6_17  original_T_including_depot_unload_1209  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_865  1
    load_1_6_17  segment_load_conservation_1134  1
    load_1_6_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_867  -25
    arc_1_6_18  connected_order_arc_868  -13
    arc_1_6_18  out_degree_1130  1
    arc_1_6_18  in_degree_1183  1
    arc_1_6_18  original_T_including_depot_unload_1209  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_867  1
    load_1_6_18  segment_load_conservation_1134  1
    load_1_6_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_869  -25
    arc_1_6_19  connected_order_arc_870  -13
    arc_1_6_19  out_degree_1130  1
    arc_1_6_19  in_degree_1189  1
    arc_1_6_19  original_T_including_depot_unload_1209  1.5299353443215734e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_869  1
    load_1_6_19  segment_load_conservation_1134  1
    load_1_6_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_871  -25
    arc_1_6_20  connected_order_arc_872  -13
    arc_1_6_20  out_degree_1130  1
    arc_1_6_20  in_degree_1195  1
    arc_1_6_20  original_T_including_depot_unload_1209  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_871  1
    load_1_6_20  segment_load_conservation_1134  1
    load_1_6_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_873  -25
    arc_1_6_21  connected_order_arc_874  -13
    arc_1_6_21  out_degree_1130  1
    arc_1_6_21  in_degree_1201  1
    arc_1_6_21  original_T_including_depot_unload_1209  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_873  1
    load_1_6_21  segment_load_conservation_1134  1
    load_1_6_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_875  -25
    arc_1_7_0  depot_return_or_bypass_1129  1
    arc_1_7_0  out_degree_1137  1
    arc_1_7_0  original_T_including_depot_unload_1209  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_875  1
    load_1_7_0  segment_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_876  -25
    arc_1_7_6  connected_order_arc_877  -13
    arc_1_7_6  in_degree_1131  1
    arc_1_7_6  out_degree_1137  1
    arc_1_7_6  original_T_including_depot_unload_1209  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_876  1
    load_1_7_6  segment_load_conservation_1134  -1
    load_1_7_6  segment_prefix_lb_1135  1
    load_1_7_6  segment_prefix_ub_1136  1
    load_1_7_6  segment_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_878  -25
    arc_1_7_8  connected_order_arc_879  -13
    arc_1_7_8  out_degree_1137  1
    arc_1_7_8  in_degree_1145  1
    arc_1_7_8  original_T_including_depot_unload_1209  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_878  1
    load_1_7_8  segment_load_conservation_1141  1
    load_1_7_8  segment_load_conservation_1148  -1
    load_1_7_8  segment_prefix_lb_1149  1
    load_1_7_8  segment_prefix_ub_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_880  -25
    arc_1_7_9  connected_order_arc_881  -13
    arc_1_7_9  out_degree_1137  1
    arc_1_7_9  in_degree_1152  1
    arc_1_7_9  original_T_including_depot_unload_1209  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_880  1
    load_1_7_9  segment_load_conservation_1141  1
    load_1_7_9  segment_load_conservation_1155  -1
    load_1_7_9  segment_prefix_lb_1156  1
    load_1_7_9  segment_prefix_ub_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_882  -25
    arc_1_7_14  connected_order_arc_883  -13
    arc_1_7_14  out_degree_1137  1
    arc_1_7_14  in_degree_1159  1
    arc_1_7_14  original_T_including_depot_unload_1209  7.4895433191723123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_882  1
    load_1_7_14  segment_load_conservation_1141  1
    load_1_7_14  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_884  -25
    arc_1_7_15  connected_order_arc_885  -13
    arc_1_7_15  out_degree_1137  1
    arc_1_7_15  in_degree_1165  1
    arc_1_7_15  original_T_including_depot_unload_1209  8.5386479957462541e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_884  1
    load_1_7_15  segment_load_conservation_1141  1
    load_1_7_15  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_886  -25
    arc_1_7_16  connected_order_arc_887  -13
    arc_1_7_16  out_degree_1137  1
    arc_1_7_16  in_degree_1171  1
    arc_1_7_16  original_T_including_depot_unload_1209  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_886  1
    load_1_7_16  segment_load_conservation_1141  1
    load_1_7_16  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_888  -25
    arc_1_7_17  connected_order_arc_889  -13
    arc_1_7_17  out_degree_1137  1
    arc_1_7_17  in_degree_1177  1
    arc_1_7_17  original_T_including_depot_unload_1209  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_888  1
    load_1_7_17  segment_load_conservation_1141  1
    load_1_7_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_890  -25
    arc_1_7_18  connected_order_arc_891  -13
    arc_1_7_18  out_degree_1137  1
    arc_1_7_18  in_degree_1183  1
    arc_1_7_18  original_T_including_depot_unload_1209  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_890  1
    load_1_7_18  segment_load_conservation_1141  1
    load_1_7_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_892  -25
    arc_1_7_19  connected_order_arc_893  -13
    arc_1_7_19  out_degree_1137  1
    arc_1_7_19  in_degree_1189  1
    arc_1_7_19  original_T_including_depot_unload_1209  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_892  1
    load_1_7_19  segment_load_conservation_1141  1
    load_1_7_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_894  -25
    arc_1_7_20  connected_order_arc_895  -13
    arc_1_7_20  out_degree_1137  1
    arc_1_7_20  in_degree_1195  1
    arc_1_7_20  original_T_including_depot_unload_1209  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_894  1
    load_1_7_20  segment_load_conservation_1141  1
    load_1_7_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_896  -25
    arc_1_7_21  connected_order_arc_897  -13
    arc_1_7_21  out_degree_1137  1
    arc_1_7_21  in_degree_1201  1
    arc_1_7_21  original_T_including_depot_unload_1209  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_896  1
    load_1_7_21  segment_load_conservation_1141  1
    load_1_7_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_898  -25
    arc_1_8_0  depot_return_or_bypass_1129  1
    arc_1_8_0  out_degree_1144  1
    arc_1_8_0  original_T_including_depot_unload_1209  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_898  1
    load_1_8_0  segment_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_899  -25
    arc_1_8_6  connected_order_arc_900  -13
    arc_1_8_6  in_degree_1131  1
    arc_1_8_6  out_degree_1144  1
    arc_1_8_6  original_T_including_depot_unload_1209  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_899  1
    load_1_8_6  segment_load_conservation_1134  -1
    load_1_8_6  segment_prefix_lb_1135  1
    load_1_8_6  segment_prefix_ub_1136  1
    load_1_8_6  segment_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_901  -25
    arc_1_8_7  connected_order_arc_902  -13
    arc_1_8_7  in_degree_1138  1
    arc_1_8_7  out_degree_1144  1
    arc_1_8_7  original_T_including_depot_unload_1209  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_901  1
    load_1_8_7  segment_load_conservation_1141  -1
    load_1_8_7  segment_prefix_lb_1142  1
    load_1_8_7  segment_prefix_ub_1143  1
    load_1_8_7  segment_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_903  -25
    arc_1_8_9  connected_order_arc_904  -13
    arc_1_8_9  out_degree_1144  1
    arc_1_8_9  in_degree_1152  1
    arc_1_8_9  original_T_including_depot_unload_1209  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_903  1
    load_1_8_9  segment_load_conservation_1148  1
    load_1_8_9  segment_load_conservation_1155  -1
    load_1_8_9  segment_prefix_lb_1156  1
    load_1_8_9  segment_prefix_ub_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_905  -25
    arc_1_8_14  connected_order_arc_906  -13
    arc_1_8_14  out_degree_1144  1
    arc_1_8_14  in_degree_1159  1
    arc_1_8_14  original_T_including_depot_unload_1209  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_905  1
    load_1_8_14  segment_load_conservation_1148  1
    load_1_8_14  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_907  -25
    arc_1_8_15  connected_order_arc_908  -13
    arc_1_8_15  out_degree_1144  1
    arc_1_8_15  in_degree_1165  1
    arc_1_8_15  original_T_including_depot_unload_1209  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_907  1
    load_1_8_15  segment_load_conservation_1148  1
    load_1_8_15  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_909  -25
    arc_1_8_16  connected_order_arc_910  -13
    arc_1_8_16  out_degree_1144  1
    arc_1_8_16  in_degree_1171  1
    arc_1_8_16  original_T_including_depot_unload_1209  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_909  1
    load_1_8_16  segment_load_conservation_1148  1
    load_1_8_16  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_911  -25
    arc_1_8_17  connected_order_arc_912  -13
    arc_1_8_17  out_degree_1144  1
    arc_1_8_17  in_degree_1177  1
    arc_1_8_17  original_T_including_depot_unload_1209  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_911  1
    load_1_8_17  segment_load_conservation_1148  1
    load_1_8_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_913  -25
    arc_1_8_18  connected_order_arc_914  -13
    arc_1_8_18  out_degree_1144  1
    arc_1_8_18  in_degree_1183  1
    arc_1_8_18  original_T_including_depot_unload_1209  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_913  1
    load_1_8_18  segment_load_conservation_1148  1
    load_1_8_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_915  -25
    arc_1_8_19  connected_order_arc_916  -13
    arc_1_8_19  out_degree_1144  1
    arc_1_8_19  in_degree_1189  1
    arc_1_8_19  original_T_including_depot_unload_1209  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_915  1
    load_1_8_19  segment_load_conservation_1148  1
    load_1_8_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_917  -25
    arc_1_8_20  connected_order_arc_918  -13
    arc_1_8_20  out_degree_1144  1
    arc_1_8_20  in_degree_1195  1
    arc_1_8_20  original_T_including_depot_unload_1209  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_917  1
    load_1_8_20  segment_load_conservation_1148  1
    load_1_8_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_919  -25
    arc_1_8_21  connected_order_arc_920  -13
    arc_1_8_21  out_degree_1144  1
    arc_1_8_21  in_degree_1201  1
    arc_1_8_21  original_T_including_depot_unload_1209  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_919  1
    load_1_8_21  segment_load_conservation_1148  1
    load_1_8_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_921  -25
    arc_1_9_0  depot_return_or_bypass_1129  1
    arc_1_9_0  out_degree_1151  1
    arc_1_9_0  original_T_including_depot_unload_1209  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_921  1
    load_1_9_0  segment_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_922  -25
    arc_1_9_6  connected_order_arc_923  -13
    arc_1_9_6  in_degree_1131  1
    arc_1_9_6  out_degree_1151  1
    arc_1_9_6  original_T_including_depot_unload_1209  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_922  1
    load_1_9_6  segment_load_conservation_1134  -1
    load_1_9_6  segment_prefix_lb_1135  1
    load_1_9_6  segment_prefix_ub_1136  1
    load_1_9_6  segment_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_924  -25
    arc_1_9_7  connected_order_arc_925  -13
    arc_1_9_7  in_degree_1138  1
    arc_1_9_7  out_degree_1151  1
    arc_1_9_7  original_T_including_depot_unload_1209  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_924  1
    load_1_9_7  segment_load_conservation_1141  -1
    load_1_9_7  segment_prefix_lb_1142  1
    load_1_9_7  segment_prefix_ub_1143  1
    load_1_9_7  segment_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_926  -25
    arc_1_9_8  connected_order_arc_927  -13
    arc_1_9_8  in_degree_1145  1
    arc_1_9_8  out_degree_1151  1
    arc_1_9_8  original_T_including_depot_unload_1209  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_926  1
    load_1_9_8  segment_load_conservation_1148  -1
    load_1_9_8  segment_prefix_lb_1149  1
    load_1_9_8  segment_prefix_ub_1150  1
    load_1_9_8  segment_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_928  -25
    arc_1_9_14  connected_order_arc_929  -13
    arc_1_9_14  out_degree_1151  1
    arc_1_9_14  in_degree_1159  1
    arc_1_9_14  original_T_including_depot_unload_1209  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_928  1
    load_1_9_14  segment_load_conservation_1155  1
    load_1_9_14  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_930  -25
    arc_1_9_15  connected_order_arc_931  -13
    arc_1_9_15  out_degree_1151  1
    arc_1_9_15  in_degree_1165  1
    arc_1_9_15  original_T_including_depot_unload_1209  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_930  1
    load_1_9_15  segment_load_conservation_1155  1
    load_1_9_15  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_932  -25
    arc_1_9_16  connected_order_arc_933  -13
    arc_1_9_16  out_degree_1151  1
    arc_1_9_16  in_degree_1171  1
    arc_1_9_16  original_T_including_depot_unload_1209  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_932  1
    load_1_9_16  segment_load_conservation_1155  1
    load_1_9_16  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_934  -25
    arc_1_9_17  connected_order_arc_935  -13
    arc_1_9_17  out_degree_1151  1
    arc_1_9_17  in_degree_1177  1
    arc_1_9_17  original_T_including_depot_unload_1209  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_934  1
    load_1_9_17  segment_load_conservation_1155  1
    load_1_9_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_936  -25
    arc_1_9_18  connected_order_arc_937  -13
    arc_1_9_18  out_degree_1151  1
    arc_1_9_18  in_degree_1183  1
    arc_1_9_18  original_T_including_depot_unload_1209  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_936  1
    load_1_9_18  segment_load_conservation_1155  1
    load_1_9_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_938  -25
    arc_1_9_19  connected_order_arc_939  -13
    arc_1_9_19  out_degree_1151  1
    arc_1_9_19  in_degree_1189  1
    arc_1_9_19  original_T_including_depot_unload_1209  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_938  1
    load_1_9_19  segment_load_conservation_1155  1
    load_1_9_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_940  -25
    arc_1_9_20  connected_order_arc_941  -13
    arc_1_9_20  out_degree_1151  1
    arc_1_9_20  in_degree_1195  1
    arc_1_9_20  original_T_including_depot_unload_1209  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_940  1
    load_1_9_20  segment_load_conservation_1155  1
    load_1_9_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_942  -25
    arc_1_9_21  connected_order_arc_943  -13
    arc_1_9_21  out_degree_1151  1
    arc_1_9_21  in_degree_1201  1
    arc_1_9_21  original_T_including_depot_unload_1209  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_942  1
    load_1_9_21  segment_load_conservation_1155  1
    load_1_9_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_944  -25
    arc_1_14_0  depot_return_or_bypass_1129  1
    arc_1_14_0  out_degree_1158  1
    arc_1_14_0  original_T_including_depot_unload_1209  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_944  1
    load_1_14_0  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_945  -25
    arc_1_14_6  connected_order_arc_946  -13
    arc_1_14_6  in_degree_1131  1
    arc_1_14_6  out_degree_1158  1
    arc_1_14_6  original_T_including_depot_unload_1209  1829.33035879167
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_945  1
    load_1_14_6  segment_load_conservation_1134  -1
    load_1_14_6  segment_prefix_lb_1135  1
    load_1_14_6  segment_prefix_ub_1136  1
    load_1_14_6  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_947  -25
    arc_1_14_7  connected_order_arc_948  -13
    arc_1_14_7  in_degree_1138  1
    arc_1_14_7  out_degree_1158  1
    arc_1_14_7  original_T_including_depot_unload_1209  7.4895433191723123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_947  1
    load_1_14_7  segment_load_conservation_1141  -1
    load_1_14_7  segment_prefix_lb_1142  1
    load_1_14_7  segment_prefix_ub_1143  1
    load_1_14_7  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_949  -25
    arc_1_14_8  connected_order_arc_950  -13
    arc_1_14_8  in_degree_1145  1
    arc_1_14_8  out_degree_1158  1
    arc_1_14_8  original_T_including_depot_unload_1209  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_949  1
    load_1_14_8  segment_load_conservation_1148  -1
    load_1_14_8  segment_prefix_lb_1149  1
    load_1_14_8  segment_prefix_ub_1150  1
    load_1_14_8  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_951  -25
    arc_1_14_9  connected_order_arc_952  -13
    arc_1_14_9  in_degree_1152  1
    arc_1_14_9  out_degree_1158  1
    arc_1_14_9  original_T_including_depot_unload_1209  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_951  1
    load_1_14_9  segment_load_conservation_1155  -1
    load_1_14_9  segment_prefix_lb_1156  1
    load_1_14_9  segment_prefix_ub_1157  1
    load_1_14_9  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_953  -25
    arc_1_14_15  connected_order_arc_954  -13
    arc_1_14_15  out_degree_1158  1
    arc_1_14_15  in_degree_1165  1
    arc_1_14_15  original_T_including_depot_unload_1209  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_953  1
    load_1_14_15  free_load_conservation_1163  1
    load_1_14_15  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_955  -25
    arc_1_14_16  connected_order_arc_956  -13
    arc_1_14_16  out_degree_1158  1
    arc_1_14_16  in_degree_1171  1
    arc_1_14_16  original_T_including_depot_unload_1209  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_955  1
    load_1_14_16  free_load_conservation_1163  1
    load_1_14_16  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_957  -25
    arc_1_14_17  connected_order_arc_958  -13
    arc_1_14_17  out_degree_1158  1
    arc_1_14_17  in_degree_1177  1
    arc_1_14_17  original_T_including_depot_unload_1209  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_957  1
    load_1_14_17  free_load_conservation_1163  1
    load_1_14_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_959  -25
    arc_1_14_18  connected_order_arc_960  -13
    arc_1_14_18  out_degree_1158  1
    arc_1_14_18  in_degree_1183  1
    arc_1_14_18  original_T_including_depot_unload_1209  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_959  1
    load_1_14_18  free_load_conservation_1163  1
    load_1_14_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_961  -25
    arc_1_14_19  connected_order_arc_962  -13
    arc_1_14_19  out_degree_1158  1
    arc_1_14_19  in_degree_1189  1
    arc_1_14_19  original_T_including_depot_unload_1209  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_961  1
    load_1_14_19  free_load_conservation_1163  1
    load_1_14_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_963  -25
    arc_1_14_20  connected_order_arc_964  -13
    arc_1_14_20  out_degree_1158  1
    arc_1_14_20  in_degree_1195  1
    arc_1_14_20  original_T_including_depot_unload_1209  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_963  1
    load_1_14_20  free_load_conservation_1163  1
    load_1_14_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_965  -25
    arc_1_14_21  connected_order_arc_966  -13
    arc_1_14_21  out_degree_1158  1
    arc_1_14_21  in_degree_1201  1
    arc_1_14_21  original_T_including_depot_unload_1209  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_965  1
    load_1_14_21  free_load_conservation_1163  1
    load_1_14_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_967  -25
    arc_1_15_0  depot_return_or_bypass_1129  1
    arc_1_15_0  out_degree_1164  1
    arc_1_15_0  original_T_including_depot_unload_1209  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_967  1
    load_1_15_0  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_968  -25
    arc_1_15_6  connected_order_arc_969  -13
    arc_1_15_6  in_degree_1131  1
    arc_1_15_6  out_degree_1164  1
    arc_1_15_6  original_T_including_depot_unload_1209  1.9270569168668533e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_968  1
    load_1_15_6  segment_load_conservation_1134  -1
    load_1_15_6  segment_prefix_lb_1135  1
    load_1_15_6  segment_prefix_ub_1136  1
    load_1_15_6  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_970  -25
    arc_1_15_7  connected_order_arc_971  -13
    arc_1_15_7  in_degree_1138  1
    arc_1_15_7  out_degree_1164  1
    arc_1_15_7  original_T_including_depot_unload_1209  8.5386479957462541e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_970  1
    load_1_15_7  segment_load_conservation_1141  -1
    load_1_15_7  segment_prefix_lb_1142  1
    load_1_15_7  segment_prefix_ub_1143  1
    load_1_15_7  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_972  -25
    arc_1_15_8  connected_order_arc_973  -13
    arc_1_15_8  in_degree_1145  1
    arc_1_15_8  out_degree_1164  1
    arc_1_15_8  original_T_including_depot_unload_1209  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_972  1
    load_1_15_8  segment_load_conservation_1148  -1
    load_1_15_8  segment_prefix_lb_1149  1
    load_1_15_8  segment_prefix_ub_1150  1
    load_1_15_8  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_974  -25
    arc_1_15_9  connected_order_arc_975  -13
    arc_1_15_9  in_degree_1152  1
    arc_1_15_9  out_degree_1164  1
    arc_1_15_9  original_T_including_depot_unload_1209  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_974  1
    load_1_15_9  segment_load_conservation_1155  -1
    load_1_15_9  segment_prefix_lb_1156  1
    load_1_15_9  segment_prefix_ub_1157  1
    load_1_15_9  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_976  -25
    arc_1_15_14  connected_order_arc_977  -13
    arc_1_15_14  in_degree_1159  1
    arc_1_15_14  out_degree_1164  1
    arc_1_15_14  original_T_including_depot_unload_1209  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_976  1
    load_1_15_14  free_load_conservation_1163  -1
    load_1_15_14  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_978  -25
    arc_1_15_16  connected_order_arc_979  -13
    arc_1_15_16  out_degree_1164  1
    arc_1_15_16  in_degree_1171  1
    arc_1_15_16  original_T_including_depot_unload_1209  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_978  1
    load_1_15_16  free_load_conservation_1169  1
    load_1_15_16  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_980  -25
    arc_1_15_17  connected_order_arc_981  -13
    arc_1_15_17  out_degree_1164  1
    arc_1_15_17  in_degree_1177  1
    arc_1_15_17  original_T_including_depot_unload_1209  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_980  1
    load_1_15_17  free_load_conservation_1169  1
    load_1_15_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_982  -25
    arc_1_15_18  connected_order_arc_983  -13
    arc_1_15_18  out_degree_1164  1
    arc_1_15_18  in_degree_1183  1
    arc_1_15_18  original_T_including_depot_unload_1209  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_982  1
    load_1_15_18  free_load_conservation_1169  1
    load_1_15_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_984  -25
    arc_1_15_19  connected_order_arc_985  -13
    arc_1_15_19  out_degree_1164  1
    arc_1_15_19  in_degree_1189  1
    arc_1_15_19  original_T_including_depot_unload_1209  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_984  1
    load_1_15_19  free_load_conservation_1169  1
    load_1_15_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_986  -25
    arc_1_15_20  connected_order_arc_987  -13
    arc_1_15_20  out_degree_1164  1
    arc_1_15_20  in_degree_1195  1
    arc_1_15_20  original_T_including_depot_unload_1209  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_986  1
    load_1_15_20  free_load_conservation_1169  1
    load_1_15_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_988  -25
    arc_1_15_21  connected_order_arc_989  -13
    arc_1_15_21  out_degree_1164  1
    arc_1_15_21  in_degree_1201  1
    arc_1_15_21  original_T_including_depot_unload_1209  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_988  1
    load_1_15_21  free_load_conservation_1169  1
    load_1_15_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_990  -25
    arc_1_16_0  depot_return_or_bypass_1129  1
    arc_1_16_0  out_degree_1170  1
    arc_1_16_0  original_T_including_depot_unload_1209  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_990  1
    load_1_16_0  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_991  -25
    arc_1_16_6  connected_order_arc_992  -13
    arc_1_16_6  in_degree_1131  1
    arc_1_16_6  out_degree_1170  1
    arc_1_16_6  original_T_including_depot_unload_1209  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_991  1
    load_1_16_6  segment_load_conservation_1134  -1
    load_1_16_6  segment_prefix_lb_1135  1
    load_1_16_6  segment_prefix_ub_1136  1
    load_1_16_6  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_993  -25
    arc_1_16_7  connected_order_arc_994  -13
    arc_1_16_7  in_degree_1138  1
    arc_1_16_7  out_degree_1170  1
    arc_1_16_7  original_T_including_depot_unload_1209  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_993  1
    load_1_16_7  segment_load_conservation_1141  -1
    load_1_16_7  segment_prefix_lb_1142  1
    load_1_16_7  segment_prefix_ub_1143  1
    load_1_16_7  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_995  -25
    arc_1_16_8  connected_order_arc_996  -13
    arc_1_16_8  in_degree_1145  1
    arc_1_16_8  out_degree_1170  1
    arc_1_16_8  original_T_including_depot_unload_1209  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_995  1
    load_1_16_8  segment_load_conservation_1148  -1
    load_1_16_8  segment_prefix_lb_1149  1
    load_1_16_8  segment_prefix_ub_1150  1
    load_1_16_8  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_997  -25
    arc_1_16_9  connected_order_arc_998  -13
    arc_1_16_9  in_degree_1152  1
    arc_1_16_9  out_degree_1170  1
    arc_1_16_9  original_T_including_depot_unload_1209  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_997  1
    load_1_16_9  segment_load_conservation_1155  -1
    load_1_16_9  segment_prefix_lb_1156  1
    load_1_16_9  segment_prefix_ub_1157  1
    load_1_16_9  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_999  -25
    arc_1_16_14  connected_order_arc_1000  -13
    arc_1_16_14  in_degree_1159  1
    arc_1_16_14  out_degree_1170  1
    arc_1_16_14  original_T_including_depot_unload_1209  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_999  1
    load_1_16_14  free_load_conservation_1163  -1
    load_1_16_14  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1001  -25
    arc_1_16_15  connected_order_arc_1002  -13
    arc_1_16_15  in_degree_1165  1
    arc_1_16_15  out_degree_1170  1
    arc_1_16_15  original_T_including_depot_unload_1209  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1001  1
    load_1_16_15  free_load_conservation_1169  -1
    load_1_16_15  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1003  -25
    arc_1_16_17  connected_order_arc_1004  -13
    arc_1_16_17  out_degree_1170  1
    arc_1_16_17  in_degree_1177  1
    arc_1_16_17  original_T_including_depot_unload_1209  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1003  1
    load_1_16_17  free_load_conservation_1175  1
    load_1_16_17  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1005  -25
    arc_1_16_18  connected_order_arc_1006  -13
    arc_1_16_18  out_degree_1170  1
    arc_1_16_18  in_degree_1183  1
    arc_1_16_18  original_T_including_depot_unload_1209  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1005  1
    load_1_16_18  free_load_conservation_1175  1
    load_1_16_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1007  -25
    arc_1_16_19  connected_order_arc_1008  -13
    arc_1_16_19  out_degree_1170  1
    arc_1_16_19  in_degree_1189  1
    arc_1_16_19  original_T_including_depot_unload_1209  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1007  1
    load_1_16_19  free_load_conservation_1175  1
    load_1_16_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1009  -25
    arc_1_16_20  connected_order_arc_1010  -13
    arc_1_16_20  out_degree_1170  1
    arc_1_16_20  in_degree_1195  1
    arc_1_16_20  original_T_including_depot_unload_1209  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1009  1
    load_1_16_20  free_load_conservation_1175  1
    load_1_16_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1011  -25
    arc_1_16_21  connected_order_arc_1012  -13
    arc_1_16_21  out_degree_1170  1
    arc_1_16_21  in_degree_1201  1
    arc_1_16_21  original_T_including_depot_unload_1209  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1011  1
    load_1_16_21  free_load_conservation_1175  1
    load_1_16_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1013  -25
    arc_1_17_0  depot_return_or_bypass_1129  1
    arc_1_17_0  out_degree_1176  1
    arc_1_17_0  original_T_including_depot_unload_1209  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1013  1
    load_1_17_0  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1014  -25
    arc_1_17_6  connected_order_arc_1015  -13
    arc_1_17_6  in_degree_1131  1
    arc_1_17_6  out_degree_1176  1
    arc_1_17_6  original_T_including_depot_unload_1209  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1014  1
    load_1_17_6  segment_load_conservation_1134  -1
    load_1_17_6  segment_prefix_lb_1135  1
    load_1_17_6  segment_prefix_ub_1136  1
    load_1_17_6  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1016  -25
    arc_1_17_7  connected_order_arc_1017  -13
    arc_1_17_7  in_degree_1138  1
    arc_1_17_7  out_degree_1176  1
    arc_1_17_7  original_T_including_depot_unload_1209  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1016  1
    load_1_17_7  segment_load_conservation_1141  -1
    load_1_17_7  segment_prefix_lb_1142  1
    load_1_17_7  segment_prefix_ub_1143  1
    load_1_17_7  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1018  -25
    arc_1_17_8  connected_order_arc_1019  -13
    arc_1_17_8  in_degree_1145  1
    arc_1_17_8  out_degree_1176  1
    arc_1_17_8  original_T_including_depot_unload_1209  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1018  1
    load_1_17_8  segment_load_conservation_1148  -1
    load_1_17_8  segment_prefix_lb_1149  1
    load_1_17_8  segment_prefix_ub_1150  1
    load_1_17_8  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1020  -25
    arc_1_17_9  connected_order_arc_1021  -13
    arc_1_17_9  in_degree_1152  1
    arc_1_17_9  out_degree_1176  1
    arc_1_17_9  original_T_including_depot_unload_1209  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1020  1
    load_1_17_9  segment_load_conservation_1155  -1
    load_1_17_9  segment_prefix_lb_1156  1
    load_1_17_9  segment_prefix_ub_1157  1
    load_1_17_9  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1022  -25
    arc_1_17_14  connected_order_arc_1023  -13
    arc_1_17_14  in_degree_1159  1
    arc_1_17_14  out_degree_1176  1
    arc_1_17_14  original_T_including_depot_unload_1209  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1022  1
    load_1_17_14  free_load_conservation_1163  -1
    load_1_17_14  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1024  -25
    arc_1_17_15  connected_order_arc_1025  -13
    arc_1_17_15  in_degree_1165  1
    arc_1_17_15  out_degree_1176  1
    arc_1_17_15  original_T_including_depot_unload_1209  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1024  1
    load_1_17_15  free_load_conservation_1169  -1
    load_1_17_15  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1026  -25
    arc_1_17_16  connected_order_arc_1027  -13
    arc_1_17_16  in_degree_1171  1
    arc_1_17_16  out_degree_1176  1
    arc_1_17_16  original_T_including_depot_unload_1209  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1026  1
    load_1_17_16  free_load_conservation_1175  -1
    load_1_17_16  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1028  -25
    arc_1_17_18  connected_order_arc_1029  -13
    arc_1_17_18  out_degree_1176  1
    arc_1_17_18  in_degree_1183  1
    arc_1_17_18  original_T_including_depot_unload_1209  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1028  1
    load_1_17_18  free_load_conservation_1181  1
    load_1_17_18  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1030  -25
    arc_1_17_19  connected_order_arc_1031  -13
    arc_1_17_19  out_degree_1176  1
    arc_1_17_19  in_degree_1189  1
    arc_1_17_19  original_T_including_depot_unload_1209  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1030  1
    load_1_17_19  free_load_conservation_1181  1
    load_1_17_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1032  -25
    arc_1_17_20  connected_order_arc_1033  -13
    arc_1_17_20  out_degree_1176  1
    arc_1_17_20  in_degree_1195  1
    arc_1_17_20  original_T_including_depot_unload_1209  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1032  1
    load_1_17_20  free_load_conservation_1181  1
    load_1_17_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1034  -25
    arc_1_17_21  connected_order_arc_1035  -13
    arc_1_17_21  out_degree_1176  1
    arc_1_17_21  in_degree_1201  1
    arc_1_17_21  original_T_including_depot_unload_1209  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1034  1
    load_1_17_21  free_load_conservation_1181  1
    load_1_17_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1036  -25
    arc_1_18_0  depot_return_or_bypass_1129  1
    arc_1_18_0  out_degree_1182  1
    arc_1_18_0  original_T_including_depot_unload_1209  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1036  1
    load_1_18_0  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1037  -25
    arc_1_18_6  connected_order_arc_1038  -13
    arc_1_18_6  in_degree_1131  1
    arc_1_18_6  out_degree_1182  1
    arc_1_18_6  original_T_including_depot_unload_1209  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1037  1
    load_1_18_6  segment_load_conservation_1134  -1
    load_1_18_6  segment_prefix_lb_1135  1
    load_1_18_6  segment_prefix_ub_1136  1
    load_1_18_6  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1039  -25
    arc_1_18_7  connected_order_arc_1040  -13
    arc_1_18_7  in_degree_1138  1
    arc_1_18_7  out_degree_1182  1
    arc_1_18_7  original_T_including_depot_unload_1209  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1039  1
    load_1_18_7  segment_load_conservation_1141  -1
    load_1_18_7  segment_prefix_lb_1142  1
    load_1_18_7  segment_prefix_ub_1143  1
    load_1_18_7  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1041  -25
    arc_1_18_8  connected_order_arc_1042  -13
    arc_1_18_8  in_degree_1145  1
    arc_1_18_8  out_degree_1182  1
    arc_1_18_8  original_T_including_depot_unload_1209  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1041  1
    load_1_18_8  segment_load_conservation_1148  -1
    load_1_18_8  segment_prefix_lb_1149  1
    load_1_18_8  segment_prefix_ub_1150  1
    load_1_18_8  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1043  -25
    arc_1_18_9  connected_order_arc_1044  -13
    arc_1_18_9  in_degree_1152  1
    arc_1_18_9  out_degree_1182  1
    arc_1_18_9  original_T_including_depot_unload_1209  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1043  1
    load_1_18_9  segment_load_conservation_1155  -1
    load_1_18_9  segment_prefix_lb_1156  1
    load_1_18_9  segment_prefix_ub_1157  1
    load_1_18_9  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1045  -25
    arc_1_18_14  connected_order_arc_1046  -13
    arc_1_18_14  in_degree_1159  1
    arc_1_18_14  out_degree_1182  1
    arc_1_18_14  original_T_including_depot_unload_1209  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1045  1
    load_1_18_14  free_load_conservation_1163  -1
    load_1_18_14  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1047  -25
    arc_1_18_15  connected_order_arc_1048  -13
    arc_1_18_15  in_degree_1165  1
    arc_1_18_15  out_degree_1182  1
    arc_1_18_15  original_T_including_depot_unload_1209  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1047  1
    load_1_18_15  free_load_conservation_1169  -1
    load_1_18_15  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1049  -25
    arc_1_18_16  connected_order_arc_1050  -13
    arc_1_18_16  in_degree_1171  1
    arc_1_18_16  out_degree_1182  1
    arc_1_18_16  original_T_including_depot_unload_1209  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1049  1
    load_1_18_16  free_load_conservation_1175  -1
    load_1_18_16  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1051  -25
    arc_1_18_17  connected_order_arc_1052  -13
    arc_1_18_17  in_degree_1177  1
    arc_1_18_17  out_degree_1182  1
    arc_1_18_17  original_T_including_depot_unload_1209  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1051  1
    load_1_18_17  free_load_conservation_1181  -1
    load_1_18_17  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1053  -25
    arc_1_18_19  connected_order_arc_1054  -13
    arc_1_18_19  out_degree_1182  1
    arc_1_18_19  in_degree_1189  1
    arc_1_18_19  original_T_including_depot_unload_1209  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1053  1
    load_1_18_19  free_load_conservation_1187  1
    load_1_18_19  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1055  -25
    arc_1_18_20  connected_order_arc_1056  -13
    arc_1_18_20  out_degree_1182  1
    arc_1_18_20  in_degree_1195  1
    arc_1_18_20  original_T_including_depot_unload_1209  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1055  1
    load_1_18_20  free_load_conservation_1187  1
    load_1_18_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1057  -25
    arc_1_18_21  connected_order_arc_1058  -13
    arc_1_18_21  out_degree_1182  1
    arc_1_18_21  in_degree_1201  1
    arc_1_18_21  original_T_including_depot_unload_1209  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1057  1
    load_1_18_21  free_load_conservation_1187  1
    load_1_18_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1059  -25
    arc_1_19_0  depot_return_or_bypass_1129  1
    arc_1_19_0  out_degree_1188  1
    arc_1_19_0  original_T_including_depot_unload_1209  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1059  1
    load_1_19_0  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1060  -25
    arc_1_19_6  connected_order_arc_1061  -13
    arc_1_19_6  in_degree_1131  1
    arc_1_19_6  out_degree_1188  1
    arc_1_19_6  original_T_including_depot_unload_1209  1.5299353443215734e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1060  1
    load_1_19_6  segment_load_conservation_1134  -1
    load_1_19_6  segment_prefix_lb_1135  1
    load_1_19_6  segment_prefix_ub_1136  1
    load_1_19_6  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1062  -25
    arc_1_19_7  connected_order_arc_1063  -13
    arc_1_19_7  in_degree_1138  1
    arc_1_19_7  out_degree_1188  1
    arc_1_19_7  original_T_including_depot_unload_1209  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1062  1
    load_1_19_7  segment_load_conservation_1141  -1
    load_1_19_7  segment_prefix_lb_1142  1
    load_1_19_7  segment_prefix_ub_1143  1
    load_1_19_7  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1064  -25
    arc_1_19_8  connected_order_arc_1065  -13
    arc_1_19_8  in_degree_1145  1
    arc_1_19_8  out_degree_1188  1
    arc_1_19_8  original_T_including_depot_unload_1209  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1064  1
    load_1_19_8  segment_load_conservation_1148  -1
    load_1_19_8  segment_prefix_lb_1149  1
    load_1_19_8  segment_prefix_ub_1150  1
    load_1_19_8  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1066  -25
    arc_1_19_9  connected_order_arc_1067  -13
    arc_1_19_9  in_degree_1152  1
    arc_1_19_9  out_degree_1188  1
    arc_1_19_9  original_T_including_depot_unload_1209  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1066  1
    load_1_19_9  segment_load_conservation_1155  -1
    load_1_19_9  segment_prefix_lb_1156  1
    load_1_19_9  segment_prefix_ub_1157  1
    load_1_19_9  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1068  -25
    arc_1_19_14  connected_order_arc_1069  -13
    arc_1_19_14  in_degree_1159  1
    arc_1_19_14  out_degree_1188  1
    arc_1_19_14  original_T_including_depot_unload_1209  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1068  1
    load_1_19_14  free_load_conservation_1163  -1
    load_1_19_14  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1070  -25
    arc_1_19_15  connected_order_arc_1071  -13
    arc_1_19_15  in_degree_1165  1
    arc_1_19_15  out_degree_1188  1
    arc_1_19_15  original_T_including_depot_unload_1209  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1070  1
    load_1_19_15  free_load_conservation_1169  -1
    load_1_19_15  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1072  -25
    arc_1_19_16  connected_order_arc_1073  -13
    arc_1_19_16  in_degree_1171  1
    arc_1_19_16  out_degree_1188  1
    arc_1_19_16  original_T_including_depot_unload_1209  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1072  1
    load_1_19_16  free_load_conservation_1175  -1
    load_1_19_16  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1074  -25
    arc_1_19_17  connected_order_arc_1075  -13
    arc_1_19_17  in_degree_1177  1
    arc_1_19_17  out_degree_1188  1
    arc_1_19_17  original_T_including_depot_unload_1209  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1074  1
    load_1_19_17  free_load_conservation_1181  -1
    load_1_19_17  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1076  -25
    arc_1_19_18  connected_order_arc_1077  -13
    arc_1_19_18  in_degree_1183  1
    arc_1_19_18  out_degree_1188  1
    arc_1_19_18  original_T_including_depot_unload_1209  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1076  1
    load_1_19_18  free_load_conservation_1187  -1
    load_1_19_18  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1078  -25
    arc_1_19_20  connected_order_arc_1079  -13
    arc_1_19_20  out_degree_1188  1
    arc_1_19_20  in_degree_1195  1
    arc_1_19_20  original_T_including_depot_unload_1209  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1078  1
    load_1_19_20  free_load_conservation_1193  1
    load_1_19_20  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1080  -25
    arc_1_19_21  connected_order_arc_1081  -13
    arc_1_19_21  out_degree_1188  1
    arc_1_19_21  in_degree_1201  1
    arc_1_19_21  original_T_including_depot_unload_1209  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1080  1
    load_1_19_21  free_load_conservation_1193  1
    load_1_19_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1082  -25
    arc_1_20_0  depot_return_or_bypass_1129  1
    arc_1_20_0  out_degree_1194  1
    arc_1_20_0  original_T_including_depot_unload_1209  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1082  1
    load_1_20_0  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1083  -25
    arc_1_20_6  connected_order_arc_1084  -13
    arc_1_20_6  in_degree_1131  1
    arc_1_20_6  out_degree_1194  1
    arc_1_20_6  original_T_including_depot_unload_1209  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1083  1
    load_1_20_6  segment_load_conservation_1134  -1
    load_1_20_6  segment_prefix_lb_1135  1
    load_1_20_6  segment_prefix_ub_1136  1
    load_1_20_6  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1085  -25
    arc_1_20_7  connected_order_arc_1086  -13
    arc_1_20_7  in_degree_1138  1
    arc_1_20_7  out_degree_1194  1
    arc_1_20_7  original_T_including_depot_unload_1209  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1085  1
    load_1_20_7  segment_load_conservation_1141  -1
    load_1_20_7  segment_prefix_lb_1142  1
    load_1_20_7  segment_prefix_ub_1143  1
    load_1_20_7  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1087  -25
    arc_1_20_8  connected_order_arc_1088  -13
    arc_1_20_8  in_degree_1145  1
    arc_1_20_8  out_degree_1194  1
    arc_1_20_8  original_T_including_depot_unload_1209  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1087  1
    load_1_20_8  segment_load_conservation_1148  -1
    load_1_20_8  segment_prefix_lb_1149  1
    load_1_20_8  segment_prefix_ub_1150  1
    load_1_20_8  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1089  -25
    arc_1_20_9  connected_order_arc_1090  -13
    arc_1_20_9  in_degree_1152  1
    arc_1_20_9  out_degree_1194  1
    arc_1_20_9  original_T_including_depot_unload_1209  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1089  1
    load_1_20_9  segment_load_conservation_1155  -1
    load_1_20_9  segment_prefix_lb_1156  1
    load_1_20_9  segment_prefix_ub_1157  1
    load_1_20_9  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1091  -25
    arc_1_20_14  connected_order_arc_1092  -13
    arc_1_20_14  in_degree_1159  1
    arc_1_20_14  out_degree_1194  1
    arc_1_20_14  original_T_including_depot_unload_1209  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1091  1
    load_1_20_14  free_load_conservation_1163  -1
    load_1_20_14  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1093  -25
    arc_1_20_15  connected_order_arc_1094  -13
    arc_1_20_15  in_degree_1165  1
    arc_1_20_15  out_degree_1194  1
    arc_1_20_15  original_T_including_depot_unload_1209  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1093  1
    load_1_20_15  free_load_conservation_1169  -1
    load_1_20_15  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1095  -25
    arc_1_20_16  connected_order_arc_1096  -13
    arc_1_20_16  in_degree_1171  1
    arc_1_20_16  out_degree_1194  1
    arc_1_20_16  original_T_including_depot_unload_1209  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1095  1
    load_1_20_16  free_load_conservation_1175  -1
    load_1_20_16  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1097  -25
    arc_1_20_17  connected_order_arc_1098  -13
    arc_1_20_17  in_degree_1177  1
    arc_1_20_17  out_degree_1194  1
    arc_1_20_17  original_T_including_depot_unload_1209  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1097  1
    load_1_20_17  free_load_conservation_1181  -1
    load_1_20_17  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1099  -25
    arc_1_20_18  connected_order_arc_1100  -13
    arc_1_20_18  in_degree_1183  1
    arc_1_20_18  out_degree_1194  1
    arc_1_20_18  original_T_including_depot_unload_1209  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1099  1
    load_1_20_18  free_load_conservation_1187  -1
    load_1_20_18  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1101  -25
    arc_1_20_19  connected_order_arc_1102  -13
    arc_1_20_19  in_degree_1189  1
    arc_1_20_19  out_degree_1194  1
    arc_1_20_19  original_T_including_depot_unload_1209  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1101  1
    load_1_20_19  free_load_conservation_1193  -1
    load_1_20_19  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1103  -25
    arc_1_20_21  connected_order_arc_1104  -13
    arc_1_20_21  out_degree_1194  1
    arc_1_20_21  in_degree_1201  1
    arc_1_20_21  original_T_including_depot_unload_1209  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1103  1
    load_1_20_21  free_load_conservation_1199  1
    load_1_20_21  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1105  -25
    arc_1_21_0  depot_return_or_bypass_1129  1
    arc_1_21_0  out_degree_1200  1
    arc_1_21_0  original_T_including_depot_unload_1209  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1105  1
    load_1_21_0  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1106  -25
    arc_1_21_6  connected_order_arc_1107  -13
    arc_1_21_6  in_degree_1131  1
    arc_1_21_6  out_degree_1200  1
    arc_1_21_6  original_T_including_depot_unload_1209  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1106  1
    load_1_21_6  segment_load_conservation_1134  -1
    load_1_21_6  segment_prefix_lb_1135  1
    load_1_21_6  segment_prefix_ub_1136  1
    load_1_21_6  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1108  -25
    arc_1_21_7  connected_order_arc_1109  -13
    arc_1_21_7  in_degree_1138  1
    arc_1_21_7  out_degree_1200  1
    arc_1_21_7  original_T_including_depot_unload_1209  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1108  1
    load_1_21_7  segment_load_conservation_1141  -1
    load_1_21_7  segment_prefix_lb_1142  1
    load_1_21_7  segment_prefix_ub_1143  1
    load_1_21_7  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1110  -25
    arc_1_21_8  connected_order_arc_1111  -13
    arc_1_21_8  in_degree_1145  1
    arc_1_21_8  out_degree_1200  1
    arc_1_21_8  original_T_including_depot_unload_1209  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1110  1
    load_1_21_8  segment_load_conservation_1148  -1
    load_1_21_8  segment_prefix_lb_1149  1
    load_1_21_8  segment_prefix_ub_1150  1
    load_1_21_8  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1112  -25
    arc_1_21_9  connected_order_arc_1113  -13
    arc_1_21_9  in_degree_1152  1
    arc_1_21_9  out_degree_1200  1
    arc_1_21_9  original_T_including_depot_unload_1209  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1112  1
    load_1_21_9  segment_load_conservation_1155  -1
    load_1_21_9  segment_prefix_lb_1156  1
    load_1_21_9  segment_prefix_ub_1157  1
    load_1_21_9  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1114  -25
    arc_1_21_14  connected_order_arc_1115  -13
    arc_1_21_14  in_degree_1159  1
    arc_1_21_14  out_degree_1200  1
    arc_1_21_14  original_T_including_depot_unload_1209  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1114  1
    load_1_21_14  free_load_conservation_1163  -1
    load_1_21_14  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1116  -25
    arc_1_21_15  connected_order_arc_1117  -13
    arc_1_21_15  in_degree_1165  1
    arc_1_21_15  out_degree_1200  1
    arc_1_21_15  original_T_including_depot_unload_1209  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1116  1
    load_1_21_15  free_load_conservation_1169  -1
    load_1_21_15  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1118  -25
    arc_1_21_16  connected_order_arc_1119  -13
    arc_1_21_16  in_degree_1171  1
    arc_1_21_16  out_degree_1200  1
    arc_1_21_16  original_T_including_depot_unload_1209  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1118  1
    load_1_21_16  free_load_conservation_1175  -1
    load_1_21_16  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1120  -25
    arc_1_21_17  connected_order_arc_1121  -13
    arc_1_21_17  in_degree_1177  1
    arc_1_21_17  out_degree_1200  1
    arc_1_21_17  original_T_including_depot_unload_1209  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1120  1
    load_1_21_17  free_load_conservation_1181  -1
    load_1_21_17  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1122  -25
    arc_1_21_18  connected_order_arc_1123  -13
    arc_1_21_18  in_degree_1183  1
    arc_1_21_18  out_degree_1200  1
    arc_1_21_18  original_T_including_depot_unload_1209  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1122  1
    load_1_21_18  free_load_conservation_1187  -1
    load_1_21_18  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1124  -25
    arc_1_21_19  connected_order_arc_1125  -13
    arc_1_21_19  in_degree_1189  1
    arc_1_21_19  out_degree_1200  1
    arc_1_21_19  original_T_including_depot_unload_1209  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1124  1
    load_1_21_19  free_load_conservation_1193  -1
    load_1_21_19  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1126  -25
    arc_1_21_20  connected_order_arc_1127  -13
    arc_1_21_20  in_degree_1195  1
    arc_1_21_20  out_degree_1200  1
    arc_1_21_20  original_T_including_depot_unload_1209  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1126  1
    load_1_21_20  free_load_conservation_1199  -1
    load_1_21_20  free_load_conservation_1205  1
    visit_2_10  out_degree_1501  -1
    visit_2_10  in_degree_1502  -1
    visit_2_10  order_active_lb_1503  -1
    visit_2_10  order_active_ub_1504  -12
    order_2_10  connected_order_arc_1225  -1
    order_2_10  connected_order_arc_1227  -1
    order_2_10  connected_order_arc_1229  -1
    order_2_10  connected_order_arc_1231  -1
    order_2_10  connected_order_arc_1233  -1
    order_2_10  connected_order_arc_1235  -1
    order_2_10  connected_order_arc_1237  -1
    order_2_10  connected_order_arc_1239  -1
    order_2_10  connected_order_arc_1241  -1
    order_2_10  connected_order_arc_1243  -1
    order_2_10  connected_order_arc_1245  -1
    order_2_10  connected_order_arc_1248  1
    order_2_10  connected_order_arc_1271  1
    order_2_10  connected_order_arc_1294  1
    order_2_10  connected_order_arc_1317  1
    order_2_10  connected_order_arc_1340  1
    order_2_10  connected_order_arc_1363  1
    order_2_10  connected_order_arc_1386  1
    order_2_10  connected_order_arc_1409  1
    order_2_10  connected_order_arc_1432  1
    order_2_10  connected_order_arc_1455  1
    order_2_10  connected_order_arc_1478  1
    order_2_10  order_active_lb_1503  1
    order_2_10  order_active_ub_1504  1
    order_2_10  fixed_segment_relative_order_1577  -1
    visit_2_11  out_degree_1508  -1
    visit_2_11  in_degree_1509  -1
    visit_2_11  order_active_lb_1510  -1
    visit_2_11  order_active_ub_1511  -12
    order_2_11  connected_order_arc_1225  1
    order_2_11  connected_order_arc_1248  -1
    order_2_11  connected_order_arc_1250  -1
    order_2_11  connected_order_arc_1252  -1
    order_2_11  connected_order_arc_1254  -1
    order_2_11  connected_order_arc_1256  -1
    order_2_11  connected_order_arc_1258  -1
    order_2_11  connected_order_arc_1260  -1
    order_2_11  connected_order_arc_1262  -1
    order_2_11  connected_order_arc_1264  -1
    order_2_11  connected_order_arc_1266  -1
    order_2_11  connected_order_arc_1268  -1
    order_2_11  connected_order_arc_1273  1
    order_2_11  connected_order_arc_1296  1
    order_2_11  connected_order_arc_1319  1
    order_2_11  connected_order_arc_1342  1
    order_2_11  connected_order_arc_1365  1
    order_2_11  connected_order_arc_1388  1
    order_2_11  connected_order_arc_1411  1
    order_2_11  connected_order_arc_1434  1
    order_2_11  connected_order_arc_1457  1
    order_2_11  connected_order_arc_1480  1
    order_2_11  order_active_lb_1510  1
    order_2_11  order_active_ub_1511  1
    order_2_11  fixed_segment_relative_order_1577  1
    order_2_11  fixed_segment_relative_order_1578  -1
    visit_2_12  out_degree_1515  -1
    visit_2_12  in_degree_1516  -1
    visit_2_12  order_active_lb_1517  -1
    visit_2_12  order_active_ub_1518  -12
    order_2_12  connected_order_arc_1227  1
    order_2_12  connected_order_arc_1250  1
    order_2_12  connected_order_arc_1271  -1
    order_2_12  connected_order_arc_1273  -1
    order_2_12  connected_order_arc_1275  -1
    order_2_12  connected_order_arc_1277  -1
    order_2_12  connected_order_arc_1279  -1
    order_2_12  connected_order_arc_1281  -1
    order_2_12  connected_order_arc_1283  -1
    order_2_12  connected_order_arc_1285  -1
    order_2_12  connected_order_arc_1287  -1
    order_2_12  connected_order_arc_1289  -1
    order_2_12  connected_order_arc_1291  -1
    order_2_12  connected_order_arc_1298  1
    order_2_12  connected_order_arc_1321  1
    order_2_12  connected_order_arc_1344  1
    order_2_12  connected_order_arc_1367  1
    order_2_12  connected_order_arc_1390  1
    order_2_12  connected_order_arc_1413  1
    order_2_12  connected_order_arc_1436  1
    order_2_12  connected_order_arc_1459  1
    order_2_12  connected_order_arc_1482  1
    order_2_12  order_active_lb_1517  1
    order_2_12  order_active_ub_1518  1
    order_2_12  fixed_segment_relative_order_1578  1
    order_2_12  fixed_segment_relative_order_1579  -1
    visit_2_13  out_degree_1522  -1
    visit_2_13  in_degree_1523  -1
    visit_2_13  order_active_lb_1524  -1
    visit_2_13  order_active_ub_1525  -12
    order_2_13  connected_order_arc_1229  1
    order_2_13  connected_order_arc_1252  1
    order_2_13  connected_order_arc_1275  1
    order_2_13  connected_order_arc_1294  -1
    order_2_13  connected_order_arc_1296  -1
    order_2_13  connected_order_arc_1298  -1
    order_2_13  connected_order_arc_1300  -1
    order_2_13  connected_order_arc_1302  -1
    order_2_13  connected_order_arc_1304  -1
    order_2_13  connected_order_arc_1306  -1
    order_2_13  connected_order_arc_1308  -1
    order_2_13  connected_order_arc_1310  -1
    order_2_13  connected_order_arc_1312  -1
    order_2_13  connected_order_arc_1314  -1
    order_2_13  connected_order_arc_1323  1
    order_2_13  connected_order_arc_1346  1
    order_2_13  connected_order_arc_1369  1
    order_2_13  connected_order_arc_1392  1
    order_2_13  connected_order_arc_1415  1
    order_2_13  connected_order_arc_1438  1
    order_2_13  connected_order_arc_1461  1
    order_2_13  connected_order_arc_1484  1
    order_2_13  order_active_lb_1524  1
    order_2_13  order_active_ub_1525  1
    order_2_13  fixed_segment_relative_order_1579  1
    visit_2_14  out_degree_1529  -1
    visit_2_14  in_degree_1530  -1
    visit_2_14  order_active_lb_1531  -1
    visit_2_14  order_active_ub_1532  -12
    visit_2_14  service_visit_def_1533  -1
    order_2_14  connected_order_arc_1231  1
    order_2_14  connected_order_arc_1254  1
    order_2_14  connected_order_arc_1277  1
    order_2_14  connected_order_arc_1300  1
    order_2_14  connected_order_arc_1317  -1
    order_2_14  connected_order_arc_1319  -1
    order_2_14  connected_order_arc_1321  -1
    order_2_14  connected_order_arc_1323  -1
    order_2_14  connected_order_arc_1325  -1
    order_2_14  connected_order_arc_1327  -1
    order_2_14  connected_order_arc_1329  -1
    order_2_14  connected_order_arc_1331  -1
    order_2_14  connected_order_arc_1333  -1
    order_2_14  connected_order_arc_1335  -1
    order_2_14  connected_order_arc_1337  -1
    order_2_14  connected_order_arc_1348  1
    order_2_14  connected_order_arc_1371  1
    order_2_14  connected_order_arc_1394  1
    order_2_14  connected_order_arc_1417  1
    order_2_14  connected_order_arc_1440  1
    order_2_14  connected_order_arc_1463  1
    order_2_14  connected_order_arc_1486  1
    order_2_14  order_active_lb_1531  1
    order_2_14  order_active_ub_1532  1
    visit_2_15  out_degree_1535  -1
    visit_2_15  in_degree_1536  -1
    visit_2_15  order_active_lb_1537  -1
    visit_2_15  order_active_ub_1538  -12
    visit_2_15  service_visit_def_1539  -1
    order_2_15  connected_order_arc_1233  1
    order_2_15  connected_order_arc_1256  1
    order_2_15  connected_order_arc_1279  1
    order_2_15  connected_order_arc_1302  1
    order_2_15  connected_order_arc_1325  1
    order_2_15  connected_order_arc_1340  -1
    order_2_15  connected_order_arc_1342  -1
    order_2_15  connected_order_arc_1344  -1
    order_2_15  connected_order_arc_1346  -1
    order_2_15  connected_order_arc_1348  -1
    order_2_15  connected_order_arc_1350  -1
    order_2_15  connected_order_arc_1352  -1
    order_2_15  connected_order_arc_1354  -1
    order_2_15  connected_order_arc_1356  -1
    order_2_15  connected_order_arc_1358  -1
    order_2_15  connected_order_arc_1360  -1
    order_2_15  connected_order_arc_1373  1
    order_2_15  connected_order_arc_1396  1
    order_2_15  connected_order_arc_1419  1
    order_2_15  connected_order_arc_1442  1
    order_2_15  connected_order_arc_1465  1
    order_2_15  connected_order_arc_1488  1
    order_2_15  order_active_lb_1537  1
    order_2_15  order_active_ub_1538  1
    visit_2_16  out_degree_1541  -1
    visit_2_16  in_degree_1542  -1
    visit_2_16  order_active_lb_1543  -1
    visit_2_16  order_active_ub_1544  -12
    visit_2_16  service_visit_def_1545  -1
    order_2_16  connected_order_arc_1235  1
    order_2_16  connected_order_arc_1258  1
    order_2_16  connected_order_arc_1281  1
    order_2_16  connected_order_arc_1304  1
    order_2_16  connected_order_arc_1327  1
    order_2_16  connected_order_arc_1350  1
    order_2_16  connected_order_arc_1363  -1
    order_2_16  connected_order_arc_1365  -1
    order_2_16  connected_order_arc_1367  -1
    order_2_16  connected_order_arc_1369  -1
    order_2_16  connected_order_arc_1371  -1
    order_2_16  connected_order_arc_1373  -1
    order_2_16  connected_order_arc_1375  -1
    order_2_16  connected_order_arc_1377  -1
    order_2_16  connected_order_arc_1379  -1
    order_2_16  connected_order_arc_1381  -1
    order_2_16  connected_order_arc_1383  -1
    order_2_16  connected_order_arc_1398  1
    order_2_16  connected_order_arc_1421  1
    order_2_16  connected_order_arc_1444  1
    order_2_16  connected_order_arc_1467  1
    order_2_16  connected_order_arc_1490  1
    order_2_16  order_active_lb_1543  1
    order_2_16  order_active_ub_1544  1
    visit_2_17  out_degree_1547  -1
    visit_2_17  in_degree_1548  -1
    visit_2_17  order_active_lb_1549  -1
    visit_2_17  order_active_ub_1550  -12
    visit_2_17  service_visit_def_1551  -1
    order_2_17  connected_order_arc_1237  1
    order_2_17  connected_order_arc_1260  1
    order_2_17  connected_order_arc_1283  1
    order_2_17  connected_order_arc_1306  1
    order_2_17  connected_order_arc_1329  1
    order_2_17  connected_order_arc_1352  1
    order_2_17  connected_order_arc_1375  1
    order_2_17  connected_order_arc_1386  -1
    order_2_17  connected_order_arc_1388  -1
    order_2_17  connected_order_arc_1390  -1
    order_2_17  connected_order_arc_1392  -1
    order_2_17  connected_order_arc_1394  -1
    order_2_17  connected_order_arc_1396  -1
    order_2_17  connected_order_arc_1398  -1
    order_2_17  connected_order_arc_1400  -1
    order_2_17  connected_order_arc_1402  -1
    order_2_17  connected_order_arc_1404  -1
    order_2_17  connected_order_arc_1406  -1
    order_2_17  connected_order_arc_1423  1
    order_2_17  connected_order_arc_1446  1
    order_2_17  connected_order_arc_1469  1
    order_2_17  connected_order_arc_1492  1
    order_2_17  order_active_lb_1549  1
    order_2_17  order_active_ub_1550  1
    visit_2_18  out_degree_1553  -1
    visit_2_18  in_degree_1554  -1
    visit_2_18  order_active_lb_1555  -1
    visit_2_18  order_active_ub_1556  -12
    visit_2_18  service_visit_def_1557  -1
    order_2_18  connected_order_arc_1239  1
    order_2_18  connected_order_arc_1262  1
    order_2_18  connected_order_arc_1285  1
    order_2_18  connected_order_arc_1308  1
    order_2_18  connected_order_arc_1331  1
    order_2_18  connected_order_arc_1354  1
    order_2_18  connected_order_arc_1377  1
    order_2_18  connected_order_arc_1400  1
    order_2_18  connected_order_arc_1409  -1
    order_2_18  connected_order_arc_1411  -1
    order_2_18  connected_order_arc_1413  -1
    order_2_18  connected_order_arc_1415  -1
    order_2_18  connected_order_arc_1417  -1
    order_2_18  connected_order_arc_1419  -1
    order_2_18  connected_order_arc_1421  -1
    order_2_18  connected_order_arc_1423  -1
    order_2_18  connected_order_arc_1425  -1
    order_2_18  connected_order_arc_1427  -1
    order_2_18  connected_order_arc_1429  -1
    order_2_18  connected_order_arc_1448  1
    order_2_18  connected_order_arc_1471  1
    order_2_18  connected_order_arc_1494  1
    order_2_18  order_active_lb_1555  1
    order_2_18  order_active_ub_1556  1
    visit_2_19  out_degree_1559  -1
    visit_2_19  in_degree_1560  -1
    visit_2_19  order_active_lb_1561  -1
    visit_2_19  order_active_ub_1562  -12
    visit_2_19  service_visit_def_1563  -1
    order_2_19  connected_order_arc_1241  1
    order_2_19  connected_order_arc_1264  1
    order_2_19  connected_order_arc_1287  1
    order_2_19  connected_order_arc_1310  1
    order_2_19  connected_order_arc_1333  1
    order_2_19  connected_order_arc_1356  1
    order_2_19  connected_order_arc_1379  1
    order_2_19  connected_order_arc_1402  1
    order_2_19  connected_order_arc_1425  1
    order_2_19  connected_order_arc_1432  -1
    order_2_19  connected_order_arc_1434  -1
    order_2_19  connected_order_arc_1436  -1
    order_2_19  connected_order_arc_1438  -1
    order_2_19  connected_order_arc_1440  -1
    order_2_19  connected_order_arc_1442  -1
    order_2_19  connected_order_arc_1444  -1
    order_2_19  connected_order_arc_1446  -1
    order_2_19  connected_order_arc_1448  -1
    order_2_19  connected_order_arc_1450  -1
    order_2_19  connected_order_arc_1452  -1
    order_2_19  connected_order_arc_1473  1
    order_2_19  connected_order_arc_1496  1
    order_2_19  order_active_lb_1561  1
    order_2_19  order_active_ub_1562  1
    visit_2_20  out_degree_1565  -1
    visit_2_20  in_degree_1566  -1
    visit_2_20  order_active_lb_1567  -1
    visit_2_20  order_active_ub_1568  -12
    visit_2_20  service_visit_def_1569  -1
    order_2_20  connected_order_arc_1243  1
    order_2_20  connected_order_arc_1266  1
    order_2_20  connected_order_arc_1289  1
    order_2_20  connected_order_arc_1312  1
    order_2_20  connected_order_arc_1335  1
    order_2_20  connected_order_arc_1358  1
    order_2_20  connected_order_arc_1381  1
    order_2_20  connected_order_arc_1404  1
    order_2_20  connected_order_arc_1427  1
    order_2_20  connected_order_arc_1450  1
    order_2_20  connected_order_arc_1455  -1
    order_2_20  connected_order_arc_1457  -1
    order_2_20  connected_order_arc_1459  -1
    order_2_20  connected_order_arc_1461  -1
    order_2_20  connected_order_arc_1463  -1
    order_2_20  connected_order_arc_1465  -1
    order_2_20  connected_order_arc_1467  -1
    order_2_20  connected_order_arc_1469  -1
    order_2_20  connected_order_arc_1471  -1
    order_2_20  connected_order_arc_1473  -1
    order_2_20  connected_order_arc_1475  -1
    order_2_20  connected_order_arc_1498  1
    order_2_20  order_active_lb_1567  1
    order_2_20  order_active_ub_1568  1
    visit_2_21  out_degree_1571  -1
    visit_2_21  in_degree_1572  -1
    visit_2_21  order_active_lb_1573  -1
    visit_2_21  order_active_ub_1574  -12
    visit_2_21  service_visit_def_1575  -1
    order_2_21  connected_order_arc_1245  1
    order_2_21  connected_order_arc_1268  1
    order_2_21  connected_order_arc_1291  1
    order_2_21  connected_order_arc_1314  1
    order_2_21  connected_order_arc_1337  1
    order_2_21  connected_order_arc_1360  1
    order_2_21  connected_order_arc_1383  1
    order_2_21  connected_order_arc_1406  1
    order_2_21  connected_order_arc_1429  1
    order_2_21  connected_order_arc_1452  1
    order_2_21  connected_order_arc_1475  1
    order_2_21  connected_order_arc_1478  -1
    order_2_21  connected_order_arc_1480  -1
    order_2_21  connected_order_arc_1482  -1
    order_2_21  connected_order_arc_1484  -1
    order_2_21  connected_order_arc_1486  -1
    order_2_21  connected_order_arc_1488  -1
    order_2_21  connected_order_arc_1490  -1
    order_2_21  connected_order_arc_1492  -1
    order_2_21  connected_order_arc_1494  -1
    order_2_21  connected_order_arc_1496  -1
    order_2_21  connected_order_arc_1498  -1
    order_2_21  order_active_lb_1573  1
    order_2_21  order_active_ub_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1210  -30
    arc_2_0_0  depot_departure_or_bypass_1499  1
    arc_2_0_0  depot_return_or_bypass_1500  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1211  -30
    arc_2_0_10  depot_departure_or_bypass_1499  1
    arc_2_0_10  in_degree_1502  1
    arc_2_0_10  original_T_including_depot_unload_1580  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1211  1
    load_2_0_10  segment_load_conservation_1505  -1
    load_2_0_10  segment_prefix_lb_1506  1
    load_2_0_10  segment_prefix_ub_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1212  -30
    arc_2_0_11  depot_departure_or_bypass_1499  1
    arc_2_0_11  in_degree_1509  1
    arc_2_0_11  original_T_including_depot_unload_1580  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1212  1
    load_2_0_11  segment_load_conservation_1512  -1
    load_2_0_11  segment_prefix_lb_1513  1
    load_2_0_11  segment_prefix_ub_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1213  -30
    arc_2_0_12  depot_departure_or_bypass_1499  1
    arc_2_0_12  in_degree_1516  1
    arc_2_0_12  original_T_including_depot_unload_1580  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1213  1
    load_2_0_12  segment_load_conservation_1519  -1
    load_2_0_12  segment_prefix_lb_1520  1
    load_2_0_12  segment_prefix_ub_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1214  -30
    arc_2_0_13  depot_departure_or_bypass_1499  1
    arc_2_0_13  in_degree_1523  1
    arc_2_0_13  original_T_including_depot_unload_1580  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1214  1
    load_2_0_13  segment_load_conservation_1526  -1
    load_2_0_13  segment_prefix_lb_1527  1
    load_2_0_13  segment_prefix_ub_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1215  -30
    arc_2_0_14  depot_departure_or_bypass_1499  1
    arc_2_0_14  in_degree_1530  1
    arc_2_0_14  original_T_including_depot_unload_1580  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1215  1
    load_2_0_14  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1216  -30
    arc_2_0_15  depot_departure_or_bypass_1499  1
    arc_2_0_15  in_degree_1536  1
    arc_2_0_15  original_T_including_depot_unload_1580  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1216  1
    load_2_0_15  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1217  -30
    arc_2_0_16  depot_departure_or_bypass_1499  1
    arc_2_0_16  in_degree_1542  1
    arc_2_0_16  original_T_including_depot_unload_1580  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1217  1
    load_2_0_16  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1218  -30
    arc_2_0_17  depot_departure_or_bypass_1499  1
    arc_2_0_17  in_degree_1548  1
    arc_2_0_17  original_T_including_depot_unload_1580  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1218  1
    load_2_0_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1219  -30
    arc_2_0_18  depot_departure_or_bypass_1499  1
    arc_2_0_18  in_degree_1554  1
    arc_2_0_18  original_T_including_depot_unload_1580  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1219  1
    load_2_0_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1220  -30
    arc_2_0_19  depot_departure_or_bypass_1499  1
    arc_2_0_19  in_degree_1560  1
    arc_2_0_19  original_T_including_depot_unload_1580  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1220  1
    load_2_0_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1221  -30
    arc_2_0_20  depot_departure_or_bypass_1499  1
    arc_2_0_20  in_degree_1566  1
    arc_2_0_20  original_T_including_depot_unload_1580  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1221  1
    load_2_0_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1222  -30
    arc_2_0_21  depot_departure_or_bypass_1499  1
    arc_2_0_21  in_degree_1572  1
    arc_2_0_21  original_T_including_depot_unload_1580  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1222  1
    load_2_0_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1223  -30
    arc_2_10_0  depot_return_or_bypass_1500  1
    arc_2_10_0  out_degree_1501  1
    arc_2_10_0  original_T_including_depot_unload_1580  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1223  1
    load_2_10_0  segment_load_conservation_1505  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1224  -30
    arc_2_10_11  connected_order_arc_1225  -13
    arc_2_10_11  out_degree_1501  1
    arc_2_10_11  in_degree_1509  1
    arc_2_10_11  original_T_including_depot_unload_1580  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1224  1
    load_2_10_11  segment_load_conservation_1505  1
    load_2_10_11  segment_load_conservation_1512  -1
    load_2_10_11  segment_prefix_lb_1513  1
    load_2_10_11  segment_prefix_ub_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1226  -30
    arc_2_10_12  connected_order_arc_1227  -13
    arc_2_10_12  out_degree_1501  1
    arc_2_10_12  in_degree_1516  1
    arc_2_10_12  original_T_including_depot_unload_1580  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1226  1
    load_2_10_12  segment_load_conservation_1505  1
    load_2_10_12  segment_load_conservation_1519  -1
    load_2_10_12  segment_prefix_lb_1520  1
    load_2_10_12  segment_prefix_ub_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1228  -30
    arc_2_10_13  connected_order_arc_1229  -13
    arc_2_10_13  out_degree_1501  1
    arc_2_10_13  in_degree_1523  1
    arc_2_10_13  original_T_including_depot_unload_1580  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1228  1
    load_2_10_13  segment_load_conservation_1505  1
    load_2_10_13  segment_load_conservation_1526  -1
    load_2_10_13  segment_prefix_lb_1527  1
    load_2_10_13  segment_prefix_ub_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1230  -30
    arc_2_10_14  connected_order_arc_1231  -13
    arc_2_10_14  out_degree_1501  1
    arc_2_10_14  in_degree_1530  1
    arc_2_10_14  original_T_including_depot_unload_1580  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1230  1
    load_2_10_14  segment_load_conservation_1505  1
    load_2_10_14  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1232  -30
    arc_2_10_15  connected_order_arc_1233  -13
    arc_2_10_15  out_degree_1501  1
    arc_2_10_15  in_degree_1536  1
    arc_2_10_15  original_T_including_depot_unload_1580  1.9010369513971175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1232  1
    load_2_10_15  segment_load_conservation_1505  1
    load_2_10_15  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1234  -30
    arc_2_10_16  connected_order_arc_1235  -13
    arc_2_10_16  out_degree_1501  1
    arc_2_10_16  in_degree_1542  1
    arc_2_10_16  original_T_including_depot_unload_1580  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1234  1
    load_2_10_16  segment_load_conservation_1505  1
    load_2_10_16  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1236  -30
    arc_2_10_17  connected_order_arc_1237  -13
    arc_2_10_17  out_degree_1501  1
    arc_2_10_17  in_degree_1548  1
    arc_2_10_17  original_T_including_depot_unload_1580  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1236  1
    load_2_10_17  segment_load_conservation_1505  1
    load_2_10_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1238  -30
    arc_2_10_18  connected_order_arc_1239  -13
    arc_2_10_18  out_degree_1501  1
    arc_2_10_18  in_degree_1554  1
    arc_2_10_18  original_T_including_depot_unload_1580  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1238  1
    load_2_10_18  segment_load_conservation_1505  1
    load_2_10_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1240  -30
    arc_2_10_19  connected_order_arc_1241  -13
    arc_2_10_19  out_degree_1501  1
    arc_2_10_19  in_degree_1560  1
    arc_2_10_19  original_T_including_depot_unload_1580  1.6748602054274218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1240  1
    load_2_10_19  segment_load_conservation_1505  1
    load_2_10_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1242  -30
    arc_2_10_20  connected_order_arc_1243  -13
    arc_2_10_20  out_degree_1501  1
    arc_2_10_20  in_degree_1566  1
    arc_2_10_20  original_T_including_depot_unload_1580  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1242  1
    load_2_10_20  segment_load_conservation_1505  1
    load_2_10_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1244  -30
    arc_2_10_21  connected_order_arc_1245  -13
    arc_2_10_21  out_degree_1501  1
    arc_2_10_21  in_degree_1572  1
    arc_2_10_21  original_T_including_depot_unload_1580  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1244  1
    load_2_10_21  segment_load_conservation_1505  1
    load_2_10_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1246  -30
    arc_2_11_0  depot_return_or_bypass_1500  1
    arc_2_11_0  out_degree_1508  1
    arc_2_11_0  original_T_including_depot_unload_1580  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1246  1
    load_2_11_0  segment_load_conservation_1512  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1247  -30
    arc_2_11_10  connected_order_arc_1248  -13
    arc_2_11_10  in_degree_1502  1
    arc_2_11_10  out_degree_1508  1
    arc_2_11_10  original_T_including_depot_unload_1580  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1247  1
    load_2_11_10  segment_load_conservation_1505  -1
    load_2_11_10  segment_prefix_lb_1506  1
    load_2_11_10  segment_prefix_ub_1507  1
    load_2_11_10  segment_load_conservation_1512  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1249  -30
    arc_2_11_12  connected_order_arc_1250  -13
    arc_2_11_12  out_degree_1508  1
    arc_2_11_12  in_degree_1516  1
    arc_2_11_12  original_T_including_depot_unload_1580  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1249  1
    load_2_11_12  segment_load_conservation_1512  1
    load_2_11_12  segment_load_conservation_1519  -1
    load_2_11_12  segment_prefix_lb_1520  1
    load_2_11_12  segment_prefix_ub_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1251  -30
    arc_2_11_13  connected_order_arc_1252  -13
    arc_2_11_13  out_degree_1508  1
    arc_2_11_13  in_degree_1523  1
    arc_2_11_13  original_T_including_depot_unload_1580  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1251  1
    load_2_11_13  segment_load_conservation_1512  1
    load_2_11_13  segment_load_conservation_1526  -1
    load_2_11_13  segment_prefix_lb_1527  1
    load_2_11_13  segment_prefix_ub_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1253  -30
    arc_2_11_14  connected_order_arc_1254  -13
    arc_2_11_14  out_degree_1508  1
    arc_2_11_14  in_degree_1530  1
    arc_2_11_14  original_T_including_depot_unload_1580  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1253  1
    load_2_11_14  segment_load_conservation_1512  1
    load_2_11_14  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1255  -30
    arc_2_11_15  connected_order_arc_1256  -13
    arc_2_11_15  out_degree_1508  1
    arc_2_11_15  in_degree_1536  1
    arc_2_11_15  original_T_including_depot_unload_1580  2.4817723074148175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1255  1
    load_2_11_15  segment_load_conservation_1512  1
    load_2_11_15  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1257  -30
    arc_2_11_16  connected_order_arc_1258  -13
    arc_2_11_16  out_degree_1508  1
    arc_2_11_16  in_degree_1542  1
    arc_2_11_16  original_T_including_depot_unload_1580  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1257  1
    load_2_11_16  segment_load_conservation_1512  1
    load_2_11_16  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1259  -30
    arc_2_11_17  connected_order_arc_1260  -13
    arc_2_11_17  out_degree_1508  1
    arc_2_11_17  in_degree_1548  1
    arc_2_11_17  original_T_including_depot_unload_1580  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1259  1
    load_2_11_17  segment_load_conservation_1512  1
    load_2_11_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1261  -30
    arc_2_11_18  connected_order_arc_1262  -13
    arc_2_11_18  out_degree_1508  1
    arc_2_11_18  in_degree_1554  1
    arc_2_11_18  original_T_including_depot_unload_1580  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1261  1
    load_2_11_18  segment_load_conservation_1512  1
    load_2_11_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1263  -30
    arc_2_11_19  connected_order_arc_1264  -13
    arc_2_11_19  out_degree_1508  1
    arc_2_11_19  in_degree_1560  1
    arc_2_11_19  original_T_including_depot_unload_1580  2.3329109849823212e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1263  1
    load_2_11_19  segment_load_conservation_1512  1
    load_2_11_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1265  -30
    arc_2_11_20  connected_order_arc_1266  -13
    arc_2_11_20  out_degree_1508  1
    arc_2_11_20  in_degree_1566  1
    arc_2_11_20  original_T_including_depot_unload_1580  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1265  1
    load_2_11_20  segment_load_conservation_1512  1
    load_2_11_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1267  -30
    arc_2_11_21  connected_order_arc_1268  -13
    arc_2_11_21  out_degree_1508  1
    arc_2_11_21  in_degree_1572  1
    arc_2_11_21  original_T_including_depot_unload_1580  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1267  1
    load_2_11_21  segment_load_conservation_1512  1
    load_2_11_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1269  -30
    arc_2_12_0  depot_return_or_bypass_1500  1
    arc_2_12_0  out_degree_1515  1
    arc_2_12_0  original_T_including_depot_unload_1580  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1269  1
    load_2_12_0  segment_load_conservation_1519  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1270  -30
    arc_2_12_10  connected_order_arc_1271  -13
    arc_2_12_10  in_degree_1502  1
    arc_2_12_10  out_degree_1515  1
    arc_2_12_10  original_T_including_depot_unload_1580  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1270  1
    load_2_12_10  segment_load_conservation_1505  -1
    load_2_12_10  segment_prefix_lb_1506  1
    load_2_12_10  segment_prefix_ub_1507  1
    load_2_12_10  segment_load_conservation_1519  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1272  -30
    arc_2_12_11  connected_order_arc_1273  -13
    arc_2_12_11  in_degree_1509  1
    arc_2_12_11  out_degree_1515  1
    arc_2_12_11  original_T_including_depot_unload_1580  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1272  1
    load_2_12_11  segment_load_conservation_1512  -1
    load_2_12_11  segment_prefix_lb_1513  1
    load_2_12_11  segment_prefix_ub_1514  1
    load_2_12_11  segment_load_conservation_1519  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1274  -30
    arc_2_12_13  connected_order_arc_1275  -13
    arc_2_12_13  out_degree_1515  1
    arc_2_12_13  in_degree_1523  1
    arc_2_12_13  original_T_including_depot_unload_1580  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1274  1
    load_2_12_13  segment_load_conservation_1519  1
    load_2_12_13  segment_load_conservation_1526  -1
    load_2_12_13  segment_prefix_lb_1527  1
    load_2_12_13  segment_prefix_ub_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1276  -30
    arc_2_12_14  connected_order_arc_1277  -13
    arc_2_12_14  out_degree_1515  1
    arc_2_12_14  in_degree_1530  1
    arc_2_12_14  original_T_including_depot_unload_1580  2.5456184368702352e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1276  1
    load_2_12_14  segment_load_conservation_1519  1
    load_2_12_14  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1278  -30
    arc_2_12_15  connected_order_arc_1279  -13
    arc_2_12_15  out_degree_1515  1
    arc_2_12_15  in_degree_1536  1
    arc_2_12_15  original_T_including_depot_unload_1580  2.6049598266898456e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1278  1
    load_2_12_15  segment_load_conservation_1519  1
    load_2_12_15  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1280  -30
    arc_2_12_16  connected_order_arc_1281  -13
    arc_2_12_16  out_degree_1515  1
    arc_2_12_16  in_degree_1542  1
    arc_2_12_16  original_T_including_depot_unload_1580  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1280  1
    load_2_12_16  segment_load_conservation_1519  1
    load_2_12_16  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1282  -30
    arc_2_12_17  connected_order_arc_1283  -13
    arc_2_12_17  out_degree_1515  1
    arc_2_12_17  in_degree_1548  1
    arc_2_12_17  original_T_including_depot_unload_1580  2.3225285101968207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1282  1
    load_2_12_17  segment_load_conservation_1519  1
    load_2_12_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1284  -30
    arc_2_12_18  connected_order_arc_1285  -13
    arc_2_12_18  out_degree_1515  1
    arc_2_12_18  in_degree_1554  1
    arc_2_12_18  original_T_including_depot_unload_1580  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1284  1
    load_2_12_18  segment_load_conservation_1519  1
    load_2_12_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1286  -30
    arc_2_12_19  connected_order_arc_1287  -13
    arc_2_12_19  out_degree_1515  1
    arc_2_12_19  in_degree_1560  1
    arc_2_12_19  original_T_including_depot_unload_1580  2.2374987321387907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1286  1
    load_2_12_19  segment_load_conservation_1519  1
    load_2_12_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1288  -30
    arc_2_12_20  connected_order_arc_1289  -13
    arc_2_12_20  out_degree_1515  1
    arc_2_12_20  in_degree_1566  1
    arc_2_12_20  original_T_including_depot_unload_1580  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1288  1
    load_2_12_20  segment_load_conservation_1519  1
    load_2_12_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1290  -30
    arc_2_12_21  connected_order_arc_1291  -13
    arc_2_12_21  out_degree_1515  1
    arc_2_12_21  in_degree_1572  1
    arc_2_12_21  original_T_including_depot_unload_1580  2.8379597250568327e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1290  1
    load_2_12_21  segment_load_conservation_1519  1
    load_2_12_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1292  -30
    arc_2_13_0  depot_return_or_bypass_1500  1
    arc_2_13_0  out_degree_1522  1
    arc_2_13_0  original_T_including_depot_unload_1580  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1292  1
    load_2_13_0  segment_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1293  -30
    arc_2_13_10  connected_order_arc_1294  -13
    arc_2_13_10  in_degree_1502  1
    arc_2_13_10  out_degree_1522  1
    arc_2_13_10  original_T_including_depot_unload_1580  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1293  1
    load_2_13_10  segment_load_conservation_1505  -1
    load_2_13_10  segment_prefix_lb_1506  1
    load_2_13_10  segment_prefix_ub_1507  1
    load_2_13_10  segment_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1295  -30
    arc_2_13_11  connected_order_arc_1296  -13
    arc_2_13_11  in_degree_1509  1
    arc_2_13_11  out_degree_1522  1
    arc_2_13_11  original_T_including_depot_unload_1580  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1295  1
    load_2_13_11  segment_load_conservation_1512  -1
    load_2_13_11  segment_prefix_lb_1513  1
    load_2_13_11  segment_prefix_ub_1514  1
    load_2_13_11  segment_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1297  -30
    arc_2_13_12  connected_order_arc_1298  -13
    arc_2_13_12  in_degree_1516  1
    arc_2_13_12  out_degree_1522  1
    arc_2_13_12  original_T_including_depot_unload_1580  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1297  1
    load_2_13_12  segment_load_conservation_1519  -1
    load_2_13_12  segment_prefix_lb_1520  1
    load_2_13_12  segment_prefix_ub_1521  1
    load_2_13_12  segment_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1299  -30
    arc_2_13_14  connected_order_arc_1300  -13
    arc_2_13_14  out_degree_1522  1
    arc_2_13_14  in_degree_1530  1
    arc_2_13_14  original_T_including_depot_unload_1580  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1299  1
    load_2_13_14  segment_load_conservation_1526  1
    load_2_13_14  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1301  -30
    arc_2_13_15  connected_order_arc_1302  -13
    arc_2_13_15  out_degree_1522  1
    arc_2_13_15  in_degree_1536  1
    arc_2_13_15  original_T_including_depot_unload_1580  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1301  1
    load_2_13_15  segment_load_conservation_1526  1
    load_2_13_15  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1303  -30
    arc_2_13_16  connected_order_arc_1304  -13
    arc_2_13_16  out_degree_1522  1
    arc_2_13_16  in_degree_1542  1
    arc_2_13_16  original_T_including_depot_unload_1580  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1303  1
    load_2_13_16  segment_load_conservation_1526  1
    load_2_13_16  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1305  -30
    arc_2_13_17  connected_order_arc_1306  -13
    arc_2_13_17  out_degree_1522  1
    arc_2_13_17  in_degree_1548  1
    arc_2_13_17  original_T_including_depot_unload_1580  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1305  1
    load_2_13_17  segment_load_conservation_1526  1
    load_2_13_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1307  -30
    arc_2_13_18  connected_order_arc_1308  -13
    arc_2_13_18  out_degree_1522  1
    arc_2_13_18  in_degree_1554  1
    arc_2_13_18  original_T_including_depot_unload_1580  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1307  1
    load_2_13_18  segment_load_conservation_1526  1
    load_2_13_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1309  -30
    arc_2_13_19  connected_order_arc_1310  -13
    arc_2_13_19  out_degree_1522  1
    arc_2_13_19  in_degree_1560  1
    arc_2_13_19  original_T_including_depot_unload_1580  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1309  1
    load_2_13_19  segment_load_conservation_1526  1
    load_2_13_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1311  -30
    arc_2_13_20  connected_order_arc_1312  -13
    arc_2_13_20  out_degree_1522  1
    arc_2_13_20  in_degree_1566  1
    arc_2_13_20  original_T_including_depot_unload_1580  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1311  1
    load_2_13_20  segment_load_conservation_1526  1
    load_2_13_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1313  -30
    arc_2_13_21  connected_order_arc_1314  -13
    arc_2_13_21  out_degree_1522  1
    arc_2_13_21  in_degree_1572  1
    arc_2_13_21  original_T_including_depot_unload_1580  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1313  1
    load_2_13_21  segment_load_conservation_1526  1
    load_2_13_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1315  -30
    arc_2_14_0  depot_return_or_bypass_1500  1
    arc_2_14_0  out_degree_1529  1
    arc_2_14_0  original_T_including_depot_unload_1580  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1315  1
    load_2_14_0  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1316  -30
    arc_2_14_10  connected_order_arc_1317  -13
    arc_2_14_10  in_degree_1502  1
    arc_2_14_10  out_degree_1529  1
    arc_2_14_10  original_T_including_depot_unload_1580  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1316  1
    load_2_14_10  segment_load_conservation_1505  -1
    load_2_14_10  segment_prefix_lb_1506  1
    load_2_14_10  segment_prefix_ub_1507  1
    load_2_14_10  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1318  -30
    arc_2_14_11  connected_order_arc_1319  -13
    arc_2_14_11  in_degree_1509  1
    arc_2_14_11  out_degree_1529  1
    arc_2_14_11  original_T_including_depot_unload_1580  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1318  1
    load_2_14_11  segment_load_conservation_1512  -1
    load_2_14_11  segment_prefix_lb_1513  1
    load_2_14_11  segment_prefix_ub_1514  1
    load_2_14_11  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1320  -30
    arc_2_14_12  connected_order_arc_1321  -13
    arc_2_14_12  in_degree_1516  1
    arc_2_14_12  out_degree_1529  1
    arc_2_14_12  original_T_including_depot_unload_1580  2.5820660682901439e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1320  1
    load_2_14_12  segment_load_conservation_1519  -1
    load_2_14_12  segment_prefix_lb_1520  1
    load_2_14_12  segment_prefix_ub_1521  1
    load_2_14_12  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1322  -30
    arc_2_14_13  connected_order_arc_1323  -13
    arc_2_14_13  in_degree_1523  1
    arc_2_14_13  out_degree_1529  1
    arc_2_14_13  original_T_including_depot_unload_1580  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1322  1
    load_2_14_13  segment_load_conservation_1526  -1
    load_2_14_13  segment_prefix_lb_1527  1
    load_2_14_13  segment_prefix_ub_1528  1
    load_2_14_13  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1324  -30
    arc_2_14_15  connected_order_arc_1325  -13
    arc_2_14_15  out_degree_1529  1
    arc_2_14_15  in_degree_1536  1
    arc_2_14_15  original_T_including_depot_unload_1580  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1324  1
    load_2_14_15  free_load_conservation_1534  1
    load_2_14_15  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1326  -30
    arc_2_14_16  connected_order_arc_1327  -13
    arc_2_14_16  out_degree_1529  1
    arc_2_14_16  in_degree_1542  1
    arc_2_14_16  original_T_including_depot_unload_1580  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1326  1
    load_2_14_16  free_load_conservation_1534  1
    load_2_14_16  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1328  -30
    arc_2_14_17  connected_order_arc_1329  -13
    arc_2_14_17  out_degree_1529  1
    arc_2_14_17  in_degree_1548  1
    arc_2_14_17  original_T_including_depot_unload_1580  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1328  1
    load_2_14_17  free_load_conservation_1534  1
    load_2_14_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1330  -30
    arc_2_14_18  connected_order_arc_1331  -13
    arc_2_14_18  out_degree_1529  1
    arc_2_14_18  in_degree_1554  1
    arc_2_14_18  original_T_including_depot_unload_1580  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1330  1
    load_2_14_18  free_load_conservation_1534  1
    load_2_14_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1332  -30
    arc_2_14_19  connected_order_arc_1333  -13
    arc_2_14_19  out_degree_1529  1
    arc_2_14_19  in_degree_1560  1
    arc_2_14_19  original_T_including_depot_unload_1580  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1332  1
    load_2_14_19  free_load_conservation_1534  1
    load_2_14_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1334  -30
    arc_2_14_20  connected_order_arc_1335  -13
    arc_2_14_20  out_degree_1529  1
    arc_2_14_20  in_degree_1566  1
    arc_2_14_20  original_T_including_depot_unload_1580  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1334  1
    load_2_14_20  free_load_conservation_1534  1
    load_2_14_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1336  -30
    arc_2_14_21  connected_order_arc_1337  -13
    arc_2_14_21  out_degree_1529  1
    arc_2_14_21  in_degree_1572  1
    arc_2_14_21  original_T_including_depot_unload_1580  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1336  1
    load_2_14_21  free_load_conservation_1534  1
    load_2_14_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1338  -30
    arc_2_15_0  depot_return_or_bypass_1500  1
    arc_2_15_0  out_degree_1535  1
    arc_2_15_0  original_T_including_depot_unload_1580  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1338  1
    load_2_15_0  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1339  -30
    arc_2_15_10  connected_order_arc_1340  -13
    arc_2_15_10  in_degree_1502  1
    arc_2_15_10  out_degree_1535  1
    arc_2_15_10  original_T_including_depot_unload_1580  1.9010369513971175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1339  1
    load_2_15_10  segment_load_conservation_1505  -1
    load_2_15_10  segment_prefix_lb_1506  1
    load_2_15_10  segment_prefix_ub_1507  1
    load_2_15_10  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1341  -30
    arc_2_15_11  connected_order_arc_1342  -13
    arc_2_15_11  in_degree_1509  1
    arc_2_15_11  out_degree_1535  1
    arc_2_15_11  original_T_including_depot_unload_1580  2.4817723074148175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1341  1
    load_2_15_11  segment_load_conservation_1512  -1
    load_2_15_11  segment_prefix_lb_1513  1
    load_2_15_11  segment_prefix_ub_1514  1
    load_2_15_11  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1343  -30
    arc_2_15_12  connected_order_arc_1344  -13
    arc_2_15_12  in_degree_1516  1
    arc_2_15_12  out_degree_1535  1
    arc_2_15_12  original_T_including_depot_unload_1580  2.5004905239513250e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1343  1
    load_2_15_12  segment_load_conservation_1519  -1
    load_2_15_12  segment_prefix_lb_1520  1
    load_2_15_12  segment_prefix_ub_1521  1
    load_2_15_12  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1345  -30
    arc_2_15_13  connected_order_arc_1346  -13
    arc_2_15_13  in_degree_1523  1
    arc_2_15_13  out_degree_1535  1
    arc_2_15_13  original_T_including_depot_unload_1580  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1345  1
    load_2_15_13  segment_load_conservation_1526  -1
    load_2_15_13  segment_prefix_lb_1527  1
    load_2_15_13  segment_prefix_ub_1528  1
    load_2_15_13  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1347  -30
    arc_2_15_14  connected_order_arc_1348  -13
    arc_2_15_14  in_degree_1530  1
    arc_2_15_14  out_degree_1535  1
    arc_2_15_14  original_T_including_depot_unload_1580  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1347  1
    load_2_15_14  free_load_conservation_1534  -1
    load_2_15_14  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1349  -30
    arc_2_15_16  connected_order_arc_1350  -13
    arc_2_15_16  out_degree_1535  1
    arc_2_15_16  in_degree_1542  1
    arc_2_15_16  original_T_including_depot_unload_1580  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1349  1
    load_2_15_16  free_load_conservation_1540  1
    load_2_15_16  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1351  -30
    arc_2_15_17  connected_order_arc_1352  -13
    arc_2_15_17  out_degree_1535  1
    arc_2_15_17  in_degree_1548  1
    arc_2_15_17  original_T_including_depot_unload_1580  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1351  1
    load_2_15_17  free_load_conservation_1540  1
    load_2_15_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1353  -30
    arc_2_15_18  connected_order_arc_1354  -13
    arc_2_15_18  out_degree_1535  1
    arc_2_15_18  in_degree_1554  1
    arc_2_15_18  original_T_including_depot_unload_1580  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1353  1
    load_2_15_18  free_load_conservation_1540  1
    load_2_15_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1355  -30
    arc_2_15_19  connected_order_arc_1356  -13
    arc_2_15_19  out_degree_1535  1
    arc_2_15_19  in_degree_1560  1
    arc_2_15_19  original_T_including_depot_unload_1580  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1355  1
    load_2_15_19  free_load_conservation_1540  1
    load_2_15_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1357  -30
    arc_2_15_20  connected_order_arc_1358  -13
    arc_2_15_20  out_degree_1535  1
    arc_2_15_20  in_degree_1566  1
    arc_2_15_20  original_T_including_depot_unload_1580  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1357  1
    load_2_15_20  free_load_conservation_1540  1
    load_2_15_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1359  -30
    arc_2_15_21  connected_order_arc_1360  -13
    arc_2_15_21  out_degree_1535  1
    arc_2_15_21  in_degree_1572  1
    arc_2_15_21  original_T_including_depot_unload_1580  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1359  1
    load_2_15_21  free_load_conservation_1540  1
    load_2_15_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1361  -30
    arc_2_16_0  depot_return_or_bypass_1500  1
    arc_2_16_0  out_degree_1541  1
    arc_2_16_0  original_T_including_depot_unload_1580  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1361  1
    load_2_16_0  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1362  -30
    arc_2_16_10  connected_order_arc_1363  -13
    arc_2_16_10  in_degree_1502  1
    arc_2_16_10  out_degree_1541  1
    arc_2_16_10  original_T_including_depot_unload_1580  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1362  1
    load_2_16_10  segment_load_conservation_1505  -1
    load_2_16_10  segment_prefix_lb_1506  1
    load_2_16_10  segment_prefix_ub_1507  1
    load_2_16_10  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1364  -30
    arc_2_16_11  connected_order_arc_1365  -13
    arc_2_16_11  in_degree_1509  1
    arc_2_16_11  out_degree_1541  1
    arc_2_16_11  original_T_including_depot_unload_1580  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1364  1
    load_2_16_11  segment_load_conservation_1512  -1
    load_2_16_11  segment_prefix_lb_1513  1
    load_2_16_11  segment_prefix_ub_1514  1
    load_2_16_11  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1366  -30
    arc_2_16_12  connected_order_arc_1367  -13
    arc_2_16_12  in_degree_1516  1
    arc_2_16_12  out_degree_1541  1
    arc_2_16_12  original_T_including_depot_unload_1580  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1366  1
    load_2_16_12  segment_load_conservation_1519  -1
    load_2_16_12  segment_prefix_lb_1520  1
    load_2_16_12  segment_prefix_ub_1521  1
    load_2_16_12  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1368  -30
    arc_2_16_13  connected_order_arc_1369  -13
    arc_2_16_13  in_degree_1523  1
    arc_2_16_13  out_degree_1541  1
    arc_2_16_13  original_T_including_depot_unload_1580  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1368  1
    load_2_16_13  segment_load_conservation_1526  -1
    load_2_16_13  segment_prefix_lb_1527  1
    load_2_16_13  segment_prefix_ub_1528  1
    load_2_16_13  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1370  -30
    arc_2_16_14  connected_order_arc_1371  -13
    arc_2_16_14  in_degree_1530  1
    arc_2_16_14  out_degree_1541  1
    arc_2_16_14  original_T_including_depot_unload_1580  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1370  1
    load_2_16_14  free_load_conservation_1534  -1
    load_2_16_14  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1372  -30
    arc_2_16_15  connected_order_arc_1373  -13
    arc_2_16_15  in_degree_1536  1
    arc_2_16_15  out_degree_1541  1
    arc_2_16_15  original_T_including_depot_unload_1580  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1372  1
    load_2_16_15  free_load_conservation_1540  -1
    load_2_16_15  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1374  -30
    arc_2_16_17  connected_order_arc_1375  -13
    arc_2_16_17  out_degree_1541  1
    arc_2_16_17  in_degree_1548  1
    arc_2_16_17  original_T_including_depot_unload_1580  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1374  1
    load_2_16_17  free_load_conservation_1546  1
    load_2_16_17  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1376  -30
    arc_2_16_18  connected_order_arc_1377  -13
    arc_2_16_18  out_degree_1541  1
    arc_2_16_18  in_degree_1554  1
    arc_2_16_18  original_T_including_depot_unload_1580  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1376  1
    load_2_16_18  free_load_conservation_1546  1
    load_2_16_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1378  -30
    arc_2_16_19  connected_order_arc_1379  -13
    arc_2_16_19  out_degree_1541  1
    arc_2_16_19  in_degree_1560  1
    arc_2_16_19  original_T_including_depot_unload_1580  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1378  1
    load_2_16_19  free_load_conservation_1546  1
    load_2_16_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1380  -30
    arc_2_16_20  connected_order_arc_1381  -13
    arc_2_16_20  out_degree_1541  1
    arc_2_16_20  in_degree_1566  1
    arc_2_16_20  original_T_including_depot_unload_1580  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1380  1
    load_2_16_20  free_load_conservation_1546  1
    load_2_16_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1382  -30
    arc_2_16_21  connected_order_arc_1383  -13
    arc_2_16_21  out_degree_1541  1
    arc_2_16_21  in_degree_1572  1
    arc_2_16_21  original_T_including_depot_unload_1580  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1382  1
    load_2_16_21  free_load_conservation_1546  1
    load_2_16_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1384  -30
    arc_2_17_0  depot_return_or_bypass_1500  1
    arc_2_17_0  out_degree_1547  1
    arc_2_17_0  original_T_including_depot_unload_1580  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1384  1
    load_2_17_0  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1385  -30
    arc_2_17_10  connected_order_arc_1386  -13
    arc_2_17_10  in_degree_1502  1
    arc_2_17_10  out_degree_1547  1
    arc_2_17_10  original_T_including_depot_unload_1580  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1385  1
    load_2_17_10  segment_load_conservation_1505  -1
    load_2_17_10  segment_prefix_lb_1506  1
    load_2_17_10  segment_prefix_ub_1507  1
    load_2_17_10  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1387  -30
    arc_2_17_11  connected_order_arc_1388  -13
    arc_2_17_11  in_degree_1509  1
    arc_2_17_11  out_degree_1547  1
    arc_2_17_11  original_T_including_depot_unload_1580  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1387  1
    load_2_17_11  segment_load_conservation_1512  -1
    load_2_17_11  segment_prefix_lb_1513  1
    load_2_17_11  segment_prefix_ub_1514  1
    load_2_17_11  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1389  -30
    arc_2_17_12  connected_order_arc_1390  -13
    arc_2_17_12  in_degree_1516  1
    arc_2_17_12  out_degree_1547  1
    arc_2_17_12  original_T_including_depot_unload_1580  2.3310908183310389e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1389  1
    load_2_17_12  segment_load_conservation_1519  -1
    load_2_17_12  segment_prefix_lb_1520  1
    load_2_17_12  segment_prefix_ub_1521  1
    load_2_17_12  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1391  -30
    arc_2_17_13  connected_order_arc_1392  -13
    arc_2_17_13  in_degree_1523  1
    arc_2_17_13  out_degree_1547  1
    arc_2_17_13  original_T_including_depot_unload_1580  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1391  1
    load_2_17_13  segment_load_conservation_1526  -1
    load_2_17_13  segment_prefix_lb_1527  1
    load_2_17_13  segment_prefix_ub_1528  1
    load_2_17_13  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1393  -30
    arc_2_17_14  connected_order_arc_1394  -13
    arc_2_17_14  in_degree_1530  1
    arc_2_17_14  out_degree_1547  1
    arc_2_17_14  original_T_including_depot_unload_1580  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1393  1
    load_2_17_14  free_load_conservation_1534  -1
    load_2_17_14  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1395  -30
    arc_2_17_15  connected_order_arc_1396  -13
    arc_2_17_15  in_degree_1536  1
    arc_2_17_15  out_degree_1547  1
    arc_2_17_15  original_T_including_depot_unload_1580  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1395  1
    load_2_17_15  free_load_conservation_1540  -1
    load_2_17_15  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1397  -30
    arc_2_17_16  connected_order_arc_1398  -13
    arc_2_17_16  in_degree_1542  1
    arc_2_17_16  out_degree_1547  1
    arc_2_17_16  original_T_including_depot_unload_1580  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1397  1
    load_2_17_16  free_load_conservation_1546  -1
    load_2_17_16  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1399  -30
    arc_2_17_18  connected_order_arc_1400  -13
    arc_2_17_18  out_degree_1547  1
    arc_2_17_18  in_degree_1554  1
    arc_2_17_18  original_T_including_depot_unload_1580  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1399  1
    load_2_17_18  free_load_conservation_1552  1
    load_2_17_18  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1401  -30
    arc_2_17_19  connected_order_arc_1402  -13
    arc_2_17_19  out_degree_1547  1
    arc_2_17_19  in_degree_1560  1
    arc_2_17_19  original_T_including_depot_unload_1580  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1401  1
    load_2_17_19  free_load_conservation_1552  1
    load_2_17_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1403  -30
    arc_2_17_20  connected_order_arc_1404  -13
    arc_2_17_20  out_degree_1547  1
    arc_2_17_20  in_degree_1566  1
    arc_2_17_20  original_T_including_depot_unload_1580  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1403  1
    load_2_17_20  free_load_conservation_1552  1
    load_2_17_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1405  -30
    arc_2_17_21  connected_order_arc_1406  -13
    arc_2_17_21  out_degree_1547  1
    arc_2_17_21  in_degree_1572  1
    arc_2_17_21  original_T_including_depot_unload_1580  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1405  1
    load_2_17_21  free_load_conservation_1552  1
    load_2_17_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1407  -30
    arc_2_18_0  depot_return_or_bypass_1500  1
    arc_2_18_0  out_degree_1553  1
    arc_2_18_0  original_T_including_depot_unload_1580  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1407  1
    load_2_18_0  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1408  -30
    arc_2_18_10  connected_order_arc_1409  -13
    arc_2_18_10  in_degree_1502  1
    arc_2_18_10  out_degree_1553  1
    arc_2_18_10  original_T_including_depot_unload_1580  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1408  1
    load_2_18_10  segment_load_conservation_1505  -1
    load_2_18_10  segment_prefix_lb_1506  1
    load_2_18_10  segment_prefix_ub_1507  1
    load_2_18_10  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1410  -30
    arc_2_18_11  connected_order_arc_1411  -13
    arc_2_18_11  in_degree_1509  1
    arc_2_18_11  out_degree_1553  1
    arc_2_18_11  original_T_including_depot_unload_1580  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1410  1
    load_2_18_11  segment_load_conservation_1512  -1
    load_2_18_11  segment_prefix_lb_1513  1
    load_2_18_11  segment_prefix_ub_1514  1
    load_2_18_11  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1412  -30
    arc_2_18_12  connected_order_arc_1413  -13
    arc_2_18_12  in_degree_1516  1
    arc_2_18_12  out_degree_1553  1
    arc_2_18_12  original_T_including_depot_unload_1580  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1412  1
    load_2_18_12  segment_load_conservation_1519  -1
    load_2_18_12  segment_prefix_lb_1520  1
    load_2_18_12  segment_prefix_ub_1521  1
    load_2_18_12  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1414  -30
    arc_2_18_13  connected_order_arc_1415  -13
    arc_2_18_13  in_degree_1523  1
    arc_2_18_13  out_degree_1553  1
    arc_2_18_13  original_T_including_depot_unload_1580  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1414  1
    load_2_18_13  segment_load_conservation_1526  -1
    load_2_18_13  segment_prefix_lb_1527  1
    load_2_18_13  segment_prefix_ub_1528  1
    load_2_18_13  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1416  -30
    arc_2_18_14  connected_order_arc_1417  -13
    arc_2_18_14  in_degree_1530  1
    arc_2_18_14  out_degree_1553  1
    arc_2_18_14  original_T_including_depot_unload_1580  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1416  1
    load_2_18_14  free_load_conservation_1534  -1
    load_2_18_14  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1418  -30
    arc_2_18_15  connected_order_arc_1419  -13
    arc_2_18_15  in_degree_1536  1
    arc_2_18_15  out_degree_1553  1
    arc_2_18_15  original_T_including_depot_unload_1580  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1418  1
    load_2_18_15  free_load_conservation_1540  -1
    load_2_18_15  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1420  -30
    arc_2_18_16  connected_order_arc_1421  -13
    arc_2_18_16  in_degree_1542  1
    arc_2_18_16  out_degree_1553  1
    arc_2_18_16  original_T_including_depot_unload_1580  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1420  1
    load_2_18_16  free_load_conservation_1546  -1
    load_2_18_16  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1422  -30
    arc_2_18_17  connected_order_arc_1423  -13
    arc_2_18_17  in_degree_1548  1
    arc_2_18_17  out_degree_1553  1
    arc_2_18_17  original_T_including_depot_unload_1580  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1422  1
    load_2_18_17  free_load_conservation_1552  -1
    load_2_18_17  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1424  -30
    arc_2_18_19  connected_order_arc_1425  -13
    arc_2_18_19  out_degree_1553  1
    arc_2_18_19  in_degree_1560  1
    arc_2_18_19  original_T_including_depot_unload_1580  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1424  1
    load_2_18_19  free_load_conservation_1558  1
    load_2_18_19  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1426  -30
    arc_2_18_20  connected_order_arc_1427  -13
    arc_2_18_20  out_degree_1553  1
    arc_2_18_20  in_degree_1566  1
    arc_2_18_20  original_T_including_depot_unload_1580  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1426  1
    load_2_18_20  free_load_conservation_1558  1
    load_2_18_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1428  -30
    arc_2_18_21  connected_order_arc_1429  -13
    arc_2_18_21  out_degree_1553  1
    arc_2_18_21  in_degree_1572  1
    arc_2_18_21  original_T_including_depot_unload_1580  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1428  1
    load_2_18_21  free_load_conservation_1558  1
    load_2_18_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1430  -30
    arc_2_19_0  depot_return_or_bypass_1500  1
    arc_2_19_0  out_degree_1559  1
    arc_2_19_0  original_T_including_depot_unload_1580  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1430  1
    load_2_19_0  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1431  -30
    arc_2_19_10  connected_order_arc_1432  -13
    arc_2_19_10  in_degree_1502  1
    arc_2_19_10  out_degree_1559  1
    arc_2_19_10  original_T_including_depot_unload_1580  1.6748602054274218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1431  1
    load_2_19_10  segment_load_conservation_1505  -1
    load_2_19_10  segment_prefix_lb_1506  1
    load_2_19_10  segment_prefix_ub_1507  1
    load_2_19_10  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1433  -30
    arc_2_19_11  connected_order_arc_1434  -13
    arc_2_19_11  in_degree_1509  1
    arc_2_19_11  out_degree_1559  1
    arc_2_19_11  original_T_including_depot_unload_1580  2.3329109849823212e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1433  1
    load_2_19_11  segment_load_conservation_1512  -1
    load_2_19_11  segment_prefix_lb_1513  1
    load_2_19_11  segment_prefix_ub_1514  1
    load_2_19_11  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1435  -30
    arc_2_19_12  connected_order_arc_1436  -13
    arc_2_19_12  in_degree_1516  1
    arc_2_19_12  out_degree_1559  1
    arc_2_19_12  original_T_including_depot_unload_1580  2.3162349395019428e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1435  1
    load_2_19_12  segment_load_conservation_1519  -1
    load_2_19_12  segment_prefix_lb_1520  1
    load_2_19_12  segment_prefix_ub_1521  1
    load_2_19_12  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1437  -30
    arc_2_19_13  connected_order_arc_1438  -13
    arc_2_19_13  in_degree_1523  1
    arc_2_19_13  out_degree_1559  1
    arc_2_19_13  original_T_including_depot_unload_1580  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1437  1
    load_2_19_13  segment_load_conservation_1526  -1
    load_2_19_13  segment_prefix_lb_1527  1
    load_2_19_13  segment_prefix_ub_1528  1
    load_2_19_13  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1439  -30
    arc_2_19_14  connected_order_arc_1440  -13
    arc_2_19_14  in_degree_1530  1
    arc_2_19_14  out_degree_1559  1
    arc_2_19_14  original_T_including_depot_unload_1580  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1439  1
    load_2_19_14  free_load_conservation_1534  -1
    load_2_19_14  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1441  -30
    arc_2_19_15  connected_order_arc_1442  -13
    arc_2_19_15  in_degree_1536  1
    arc_2_19_15  out_degree_1559  1
    arc_2_19_15  original_T_including_depot_unload_1580  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1441  1
    load_2_19_15  free_load_conservation_1540  -1
    load_2_19_15  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1443  -30
    arc_2_19_16  connected_order_arc_1444  -13
    arc_2_19_16  in_degree_1542  1
    arc_2_19_16  out_degree_1559  1
    arc_2_19_16  original_T_including_depot_unload_1580  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1443  1
    load_2_19_16  free_load_conservation_1546  -1
    load_2_19_16  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1445  -30
    arc_2_19_17  connected_order_arc_1446  -13
    arc_2_19_17  in_degree_1548  1
    arc_2_19_17  out_degree_1559  1
    arc_2_19_17  original_T_including_depot_unload_1580  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1445  1
    load_2_19_17  free_load_conservation_1552  -1
    load_2_19_17  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1447  -30
    arc_2_19_18  connected_order_arc_1448  -13
    arc_2_19_18  in_degree_1554  1
    arc_2_19_18  out_degree_1559  1
    arc_2_19_18  original_T_including_depot_unload_1580  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1447  1
    load_2_19_18  free_load_conservation_1558  -1
    load_2_19_18  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1449  -30
    arc_2_19_20  connected_order_arc_1450  -13
    arc_2_19_20  out_degree_1559  1
    arc_2_19_20  in_degree_1566  1
    arc_2_19_20  original_T_including_depot_unload_1580  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1449  1
    load_2_19_20  free_load_conservation_1564  1
    load_2_19_20  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1451  -30
    arc_2_19_21  connected_order_arc_1452  -13
    arc_2_19_21  out_degree_1559  1
    arc_2_19_21  in_degree_1572  1
    arc_2_19_21  original_T_including_depot_unload_1580  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1451  1
    load_2_19_21  free_load_conservation_1564  1
    load_2_19_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1453  -30
    arc_2_20_0  depot_return_or_bypass_1500  1
    arc_2_20_0  out_degree_1565  1
    arc_2_20_0  original_T_including_depot_unload_1580  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1453  1
    load_2_20_0  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1454  -30
    arc_2_20_10  connected_order_arc_1455  -13
    arc_2_20_10  in_degree_1502  1
    arc_2_20_10  out_degree_1565  1
    arc_2_20_10  original_T_including_depot_unload_1580  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1454  1
    load_2_20_10  segment_load_conservation_1505  -1
    load_2_20_10  segment_prefix_lb_1506  1
    load_2_20_10  segment_prefix_ub_1507  1
    load_2_20_10  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1456  -30
    arc_2_20_11  connected_order_arc_1457  -13
    arc_2_20_11  in_degree_1509  1
    arc_2_20_11  out_degree_1565  1
    arc_2_20_11  original_T_including_depot_unload_1580  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1456  1
    load_2_20_11  segment_load_conservation_1512  -1
    load_2_20_11  segment_prefix_lb_1513  1
    load_2_20_11  segment_prefix_ub_1514  1
    load_2_20_11  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1458  -30
    arc_2_20_12  connected_order_arc_1459  -13
    arc_2_20_12  in_degree_1516  1
    arc_2_20_12  out_degree_1565  1
    arc_2_20_12  original_T_including_depot_unload_1580  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1458  1
    load_2_20_12  segment_load_conservation_1519  -1
    load_2_20_12  segment_prefix_lb_1520  1
    load_2_20_12  segment_prefix_ub_1521  1
    load_2_20_12  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1460  -30
    arc_2_20_13  connected_order_arc_1461  -13
    arc_2_20_13  in_degree_1523  1
    arc_2_20_13  out_degree_1565  1
    arc_2_20_13  original_T_including_depot_unload_1580  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1460  1
    load_2_20_13  segment_load_conservation_1526  -1
    load_2_20_13  segment_prefix_lb_1527  1
    load_2_20_13  segment_prefix_ub_1528  1
    load_2_20_13  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1462  -30
    arc_2_20_14  connected_order_arc_1463  -13
    arc_2_20_14  in_degree_1530  1
    arc_2_20_14  out_degree_1565  1
    arc_2_20_14  original_T_including_depot_unload_1580  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1462  1
    load_2_20_14  free_load_conservation_1534  -1
    load_2_20_14  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1464  -30
    arc_2_20_15  connected_order_arc_1465  -13
    arc_2_20_15  in_degree_1536  1
    arc_2_20_15  out_degree_1565  1
    arc_2_20_15  original_T_including_depot_unload_1580  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1464  1
    load_2_20_15  free_load_conservation_1540  -1
    load_2_20_15  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1466  -30
    arc_2_20_16  connected_order_arc_1467  -13
    arc_2_20_16  in_degree_1542  1
    arc_2_20_16  out_degree_1565  1
    arc_2_20_16  original_T_including_depot_unload_1580  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1466  1
    load_2_20_16  free_load_conservation_1546  -1
    load_2_20_16  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1468  -30
    arc_2_20_17  connected_order_arc_1469  -13
    arc_2_20_17  in_degree_1548  1
    arc_2_20_17  out_degree_1565  1
    arc_2_20_17  original_T_including_depot_unload_1580  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1468  1
    load_2_20_17  free_load_conservation_1552  -1
    load_2_20_17  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1470  -30
    arc_2_20_18  connected_order_arc_1471  -13
    arc_2_20_18  in_degree_1554  1
    arc_2_20_18  out_degree_1565  1
    arc_2_20_18  original_T_including_depot_unload_1580  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1470  1
    load_2_20_18  free_load_conservation_1558  -1
    load_2_20_18  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1472  -30
    arc_2_20_19  connected_order_arc_1473  -13
    arc_2_20_19  in_degree_1560  1
    arc_2_20_19  out_degree_1565  1
    arc_2_20_19  original_T_including_depot_unload_1580  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1472  1
    load_2_20_19  free_load_conservation_1564  -1
    load_2_20_19  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1474  -30
    arc_2_20_21  connected_order_arc_1475  -13
    arc_2_20_21  out_degree_1565  1
    arc_2_20_21  in_degree_1572  1
    arc_2_20_21  original_T_including_depot_unload_1580  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1474  1
    load_2_20_21  free_load_conservation_1570  1
    load_2_20_21  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1476  -30
    arc_2_21_0  depot_return_or_bypass_1500  1
    arc_2_21_0  out_degree_1571  1
    arc_2_21_0  original_T_including_depot_unload_1580  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1476  1
    load_2_21_0  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1477  -30
    arc_2_21_10  connected_order_arc_1478  -13
    arc_2_21_10  in_degree_1502  1
    arc_2_21_10  out_degree_1571  1
    arc_2_21_10  original_T_including_depot_unload_1580  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1477  1
    load_2_21_10  segment_load_conservation_1505  -1
    load_2_21_10  segment_prefix_lb_1506  1
    load_2_21_10  segment_prefix_ub_1507  1
    load_2_21_10  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1479  -30
    arc_2_21_11  connected_order_arc_1480  -13
    arc_2_21_11  in_degree_1509  1
    arc_2_21_11  out_degree_1571  1
    arc_2_21_11  original_T_including_depot_unload_1580  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1479  1
    load_2_21_11  segment_load_conservation_1512  -1
    load_2_21_11  segment_prefix_lb_1513  1
    load_2_21_11  segment_prefix_ub_1514  1
    load_2_21_11  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1481  -30
    arc_2_21_12  connected_order_arc_1482  -13
    arc_2_21_12  in_degree_1516  1
    arc_2_21_12  out_degree_1571  1
    arc_2_21_12  original_T_including_depot_unload_1580  2.9006291140474787e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1481  1
    load_2_21_12  segment_load_conservation_1519  -1
    load_2_21_12  segment_prefix_lb_1520  1
    load_2_21_12  segment_prefix_ub_1521  1
    load_2_21_12  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1483  -30
    arc_2_21_13  connected_order_arc_1484  -13
    arc_2_21_13  in_degree_1523  1
    arc_2_21_13  out_degree_1571  1
    arc_2_21_13  original_T_including_depot_unload_1580  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1483  1
    load_2_21_13  segment_load_conservation_1526  -1
    load_2_21_13  segment_prefix_lb_1527  1
    load_2_21_13  segment_prefix_ub_1528  1
    load_2_21_13  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1485  -30
    arc_2_21_14  connected_order_arc_1486  -13
    arc_2_21_14  in_degree_1530  1
    arc_2_21_14  out_degree_1571  1
    arc_2_21_14  original_T_including_depot_unload_1580  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1485  1
    load_2_21_14  free_load_conservation_1534  -1
    load_2_21_14  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1487  -30
    arc_2_21_15  connected_order_arc_1488  -13
    arc_2_21_15  in_degree_1536  1
    arc_2_21_15  out_degree_1571  1
    arc_2_21_15  original_T_including_depot_unload_1580  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1487  1
    load_2_21_15  free_load_conservation_1540  -1
    load_2_21_15  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1489  -30
    arc_2_21_16  connected_order_arc_1490  -13
    arc_2_21_16  in_degree_1542  1
    arc_2_21_16  out_degree_1571  1
    arc_2_21_16  original_T_including_depot_unload_1580  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1489  1
    load_2_21_16  free_load_conservation_1546  -1
    load_2_21_16  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1491  -30
    arc_2_21_17  connected_order_arc_1492  -13
    arc_2_21_17  in_degree_1548  1
    arc_2_21_17  out_degree_1571  1
    arc_2_21_17  original_T_including_depot_unload_1580  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1491  1
    load_2_21_17  free_load_conservation_1552  -1
    load_2_21_17  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1493  -30
    arc_2_21_18  connected_order_arc_1494  -13
    arc_2_21_18  in_degree_1554  1
    arc_2_21_18  out_degree_1571  1
    arc_2_21_18  original_T_including_depot_unload_1580  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1493  1
    load_2_21_18  free_load_conservation_1558  -1
    load_2_21_18  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1495  -30
    arc_2_21_19  connected_order_arc_1496  -13
    arc_2_21_19  in_degree_1560  1
    arc_2_21_19  out_degree_1571  1
    arc_2_21_19  original_T_including_depot_unload_1580  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1495  1
    load_2_21_19  free_load_conservation_1564  -1
    load_2_21_19  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1497  -30
    arc_2_21_20  connected_order_arc_1498  -13
    arc_2_21_20  in_degree_1566  1
    arc_2_21_20  out_degree_1571  1
    arc_2_21_20  original_T_including_depot_unload_1580  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1497  1
    load_2_21_20  free_load_conservation_1570  -1
    load_2_21_20  free_load_conservation_1576  1
RHS
    RHS1      OBJ       -2.8123254302956308e-01
    RHS1      onehot_3_26  1
    RHS1      onehot_4_61  1
    RHS1      onehot_34_96  1
    RHS1      onehot_5_131  1
    RHS1      onehot_29_156  1
    RHS1      onehot_7_191  1
    RHS1      onehot_27_208  1
    RHS1      onehot_2_243  1
    RHS1      stock_ub_247  33
    RHS1      parent_nonstrict_scope_248  2.9206577497347719e-01
    RHS1      normalization_305  1
    RHS1      connected_order_arc_426  -13
    RHS1      connected_order_arc_428  -13
    RHS1      connected_order_arc_430  -13
    RHS1      connected_order_arc_432  -13
    RHS1      connected_order_arc_434  -13
    RHS1      connected_order_arc_436  -13
    RHS1      connected_order_arc_438  -13
    RHS1      connected_order_arc_440  -13
    RHS1      connected_order_arc_442  -13
    RHS1      connected_order_arc_444  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_453  -13
    RHS1      connected_order_arc_455  -13
    RHS1      connected_order_arc_457  -13
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_680  -13
    RHS1      connected_order_arc_682  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_698  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_703  -13
    RHS1      connected_order_arc_705  -13
    RHS1      connected_order_arc_707  -13
    RHS1      connected_order_arc_709  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      connected_order_arc_723  -13
    RHS1      connected_order_arc_726  -13
    RHS1      connected_order_arc_728  -13
    RHS1      connected_order_arc_730  -13
    RHS1      connected_order_arc_732  -13
    RHS1      connected_order_arc_734  -13
    RHS1      connected_order_arc_736  -13
    RHS1      connected_order_arc_738  -13
    RHS1      connected_order_arc_740  -13
    RHS1      connected_order_arc_742  -13
    RHS1      connected_order_arc_744  -13
    RHS1      connected_order_arc_746  -13
    RHS1      connected_order_arc_748  -13
    RHS1      depot_departure_or_bypass_749  1
    RHS1      depot_return_or_bypass_750  1
    RHS1      segment_load_conservation_755  2
    RHS1      segment_prefix_ub_757  18
    RHS1      segment_load_conservation_762  4
    RHS1      segment_prefix_ub_764  16
    RHS1      segment_load_conservation_769  3
    RHS1      segment_prefix_ub_771  17
    RHS1      segment_load_conservation_776  3
    RHS1      segment_prefix_ub_778  17
    RHS1      segment_load_conservation_783  -1
    RHS1      segment_prefix_lb_784  2
    RHS1      segment_prefix_ub_785  16
    RHS1      fixed_segment_relative_order_834  1
    RHS1      fixed_segment_relative_order_835  1
    RHS1      fixed_segment_relative_order_836  1
    RHS1      fixed_segment_relative_order_837  1
    RHS1      original_T_including_depot_unload_838  3.1113850091438644e+03
    RHS1      connected_order_arc_854  -12
    RHS1      connected_order_arc_856  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1111  -12
    RHS1      connected_order_arc_1113  -12
    RHS1      connected_order_arc_1115  -12
    RHS1      connected_order_arc_1117  -12
    RHS1      connected_order_arc_1119  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1127  -12
    RHS1      depot_departure_or_bypass_1128  1
    RHS1      depot_return_or_bypass_1129  1
    RHS1      segment_load_conservation_1134  5
    RHS1      segment_prefix_ub_1136  20
    RHS1      segment_load_conservation_1141  -1
    RHS1      segment_prefix_lb_1142  1
    RHS1      segment_prefix_ub_1143  25
    RHS1      segment_load_conservation_1148  -4
    RHS1      segment_prefix_lb_1149  4
    RHS1      segment_prefix_ub_1150  25
    RHS1      segment_load_conservation_1155  -5
    RHS1      segment_prefix_lb_1156  5
    RHS1      segment_prefix_ub_1157  25
    RHS1      fixed_segment_relative_order_1206  1
    RHS1      fixed_segment_relative_order_1207  1
    RHS1      fixed_segment_relative_order_1208  1
    RHS1      original_T_including_depot_unload_1209  5700
    RHS1      connected_order_arc_1225  -12
    RHS1      connected_order_arc_1227  -12
    RHS1      connected_order_arc_1229  -12
    RHS1      connected_order_arc_1231  -12
    RHS1      connected_order_arc_1233  -12
    RHS1      connected_order_arc_1235  -12
    RHS1      connected_order_arc_1237  -12
    RHS1      connected_order_arc_1239  -12
    RHS1      connected_order_arc_1241  -12
    RHS1      connected_order_arc_1243  -12
    RHS1      connected_order_arc_1245  -12
    RHS1      connected_order_arc_1248  -12
    RHS1      connected_order_arc_1250  -12
    RHS1      connected_order_arc_1252  -12
    RHS1      connected_order_arc_1254  -12
    RHS1      connected_order_arc_1256  -12
    RHS1      connected_order_arc_1258  -12
    RHS1      connected_order_arc_1260  -12
    RHS1      connected_order_arc_1262  -12
    RHS1      connected_order_arc_1264  -12
    RHS1      connected_order_arc_1266  -12
    RHS1      connected_order_arc_1268  -12
    RHS1      connected_order_arc_1271  -12
    RHS1      connected_order_arc_1273  -12
    RHS1      connected_order_arc_1275  -12
    RHS1      connected_order_arc_1277  -12
    RHS1      connected_order_arc_1279  -12
    RHS1      connected_order_arc_1281  -12
    RHS1      connected_order_arc_1283  -12
    RHS1      connected_order_arc_1285  -12
    RHS1      connected_order_arc_1287  -12
    RHS1      connected_order_arc_1289  -12
    RHS1      connected_order_arc_1291  -12
    RHS1      connected_order_arc_1294  -12
    RHS1      connected_order_arc_1296  -12
    RHS1      connected_order_arc_1298  -12
    RHS1      connected_order_arc_1300  -12
    RHS1      connected_order_arc_1302  -12
    RHS1      connected_order_arc_1304  -12
    RHS1      connected_order_arc_1306  -12
    RHS1      connected_order_arc_1308  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1317  -12
    RHS1      connected_order_arc_1319  -12
    RHS1      connected_order_arc_1321  -12
    RHS1      connected_order_arc_1323  -12
    RHS1      connected_order_arc_1325  -12
    RHS1      connected_order_arc_1327  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1340  -12
    RHS1      connected_order_arc_1342  -12
    RHS1      connected_order_arc_1344  -12
    RHS1      connected_order_arc_1346  -12
    RHS1      connected_order_arc_1348  -12
    RHS1      connected_order_arc_1350  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1354  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1363  -12
    RHS1      connected_order_arc_1365  -12
    RHS1      connected_order_arc_1367  -12
    RHS1      connected_order_arc_1369  -12
    RHS1      connected_order_arc_1371  -12
    RHS1      connected_order_arc_1373  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1377  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1386  -12
    RHS1      connected_order_arc_1388  -12
    RHS1      connected_order_arc_1390  -12
    RHS1      connected_order_arc_1392  -12
    RHS1      connected_order_arc_1394  -12
    RHS1      connected_order_arc_1396  -12
    RHS1      connected_order_arc_1398  -12
    RHS1      connected_order_arc_1400  -12
    RHS1      connected_order_arc_1402  -12
    RHS1      connected_order_arc_1404  -12
    RHS1      connected_order_arc_1406  -12
    RHS1      connected_order_arc_1409  -12
    RHS1      connected_order_arc_1411  -12
    RHS1      connected_order_arc_1413  -12
    RHS1      connected_order_arc_1415  -12
    RHS1      connected_order_arc_1417  -12
    RHS1      connected_order_arc_1419  -12
    RHS1      connected_order_arc_1421  -12
    RHS1      connected_order_arc_1423  -12
    RHS1      connected_order_arc_1425  -12
    RHS1      connected_order_arc_1427  -12
    RHS1      connected_order_arc_1429  -12
    RHS1      connected_order_arc_1432  -12
    RHS1      connected_order_arc_1434  -12
    RHS1      connected_order_arc_1436  -12
    RHS1      connected_order_arc_1438  -12
    RHS1      connected_order_arc_1440  -12
    RHS1      connected_order_arc_1442  -12
    RHS1      connected_order_arc_1444  -12
    RHS1      connected_order_arc_1446  -12
    RHS1      connected_order_arc_1448  -12
    RHS1      connected_order_arc_1450  -12
    RHS1      connected_order_arc_1452  -12
    RHS1      connected_order_arc_1455  -12
    RHS1      connected_order_arc_1457  -12
    RHS1      connected_order_arc_1459  -12
    RHS1      connected_order_arc_1461  -12
    RHS1      connected_order_arc_1463  -12
    RHS1      connected_order_arc_1465  -12
    RHS1      connected_order_arc_1467  -12
    RHS1      connected_order_arc_1469  -12
    RHS1      connected_order_arc_1471  -12
    RHS1      connected_order_arc_1473  -12
    RHS1      connected_order_arc_1475  -12
    RHS1      connected_order_arc_1478  -12
    RHS1      connected_order_arc_1480  -12
    RHS1      connected_order_arc_1482  -12
    RHS1      connected_order_arc_1484  -12
    RHS1      connected_order_arc_1486  -12
    RHS1      connected_order_arc_1488  -12
    RHS1      connected_order_arc_1490  -12
    RHS1      connected_order_arc_1492  -12
    RHS1      connected_order_arc_1494  -12
    RHS1      connected_order_arc_1496  -12
    RHS1      connected_order_arc_1498  -12
    RHS1      depot_departure_or_bypass_1499  1
    RHS1      depot_return_or_bypass_1500  1
    RHS1      segment_load_conservation_1505  2
    RHS1      segment_prefix_ub_1507  28
    RHS1      segment_load_conservation_1512  2
    RHS1      segment_prefix_ub_1514  28
    RHS1      segment_load_conservation_1519  -1
    RHS1      segment_prefix_lb_1520  4
    RHS1      segment_prefix_ub_1521  30
    RHS1      segment_load_conservation_1526  -3
    RHS1      segment_prefix_lb_1527  3
    RHS1      segment_prefix_ub_1528  30
    RHS1      fixed_segment_relative_order_1577  1
    RHS1      fixed_segment_relative_order_1578  1
    RHS1      fixed_segment_relative_order_1579  1
    RHS1      original_T_including_depot_unload_1580  3.5548449150211036e+03
BOUNDS
 LO BND1      t         2.5336309344246841e-02
 UP BND1      t         4.3435544754167235e-02
 UP BND1      q         4.0666271100568246e-01
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.3435544754167235e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.3435544754167235e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.3435544754167235e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.3435544754167235e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.3435544754167235e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.3435544754167235e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.3435544754167235e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.3435544754167235e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.3435544754167235e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.3435544754167235e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.3435544754167235e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.3435544754167235e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.3435544754167235e-02
 UP BND1      rho_3     1
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.3435544754167235e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.3435544754167235e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.3435544754167235e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.3435544754167235e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.3435544754167235e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.3435544754167235e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.3435544754167235e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.3435544754167235e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.3435544754167235e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.3435544754167235e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.3435544754167235e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.3435544754167235e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.3435544754167235e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.3435544754167235e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.3435544754167235e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.3435544754167235e-02
 UP BND1      rho_4     1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.3435544754167235e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.3435544754167235e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.3435544754167235e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.3435544754167235e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.3435544754167235e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.3435544754167235e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.3435544754167235e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.3435544754167235e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.3435544754167235e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.3435544754167235e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.3435544754167235e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.3435544754167235e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.3435544754167235e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.3435544754167235e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.3435544754167235e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.3435544754167235e-02
 UP BND1      rho_34    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.3435544754167235e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.3435544754167235e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.3435544754167235e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.3435544754167235e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.3435544754167235e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.3435544754167235e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.3435544754167235e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.3435544754167235e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.3435544754167235e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.3435544754167235e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.3435544754167235e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.3435544754167235e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.3435544754167235e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.3435544754167235e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.3435544754167235e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.3435544754167235e-02
 UP BND1      rho_5     1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.3435544754167235e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.3435544754167235e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.3435544754167235e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.3435544754167235e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.3435544754167235e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.3435544754167235e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.3435544754167235e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.3435544754167235e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.3435544754167235e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.3435544754167235e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.3435544754167235e-02
 UP BND1      rho_29    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.3435544754167235e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.3435544754167235e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.3435544754167235e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.3435544754167235e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.3435544754167235e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.3435544754167235e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.3435544754167235e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.3435544754167235e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.3435544754167235e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.3435544754167235e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.3435544754167235e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.3435544754167235e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.3435544754167235e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.3435544754167235e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.3435544754167235e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.3435544754167235e-02
 UP BND1      rho_7     1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.3435544754167235e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.3435544754167235e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.3435544754167235e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.3435544754167235e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.3435544754167235e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.3435544754167235e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.3435544754167235e-02
 UP BND1      rho_27    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.3435544754167235e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.3435544754167235e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.3435544754167235e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.3435544754167235e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.3435544754167235e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.3435544754167235e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.3435544754167235e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.3435544754167235e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.3435544754167235e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.3435544754167235e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.3435544754167235e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.3435544754167235e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.3435544754167235e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.3435544754167235e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.3435544754167235e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.3435544754167235e-02
 UP BND1      rho_2     1
 UP BND1      a_3_4     1
 UP BND1      a_3_34    1
 UP BND1      a_3_5     1
 UP BND1      a_3_29    1
 UP BND1      a_3_7     1
 UP BND1      a_3_27    1
 UP BND1      a_3_2     1
 UP BND1      a_4_34    1
 UP BND1      a_4_5     1
 UP BND1      a_4_29    1
 UP BND1      a_4_7     1
 UP BND1      a_4_27    1
 UP BND1      a_4_2     1
 UP BND1      a_34_5    1
 UP BND1      a_34_29   1
 UP BND1      a_34_7    1
 UP BND1      a_34_27   1
 UP BND1      a_34_2    1
 UP BND1      a_5_29    1
 UP BND1      a_5_7     1
 UP BND1      a_5_27    1
 UP BND1      a_5_2     1
 UP BND1      a_29_7    1
 UP BND1      a_29_27   1
 UP BND1      a_29_2    1
 UP BND1      a_7_27    1
 UP BND1      a_7_2     1
 UP BND1      a_27_2    1
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_12
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_12
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_12
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_11
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_11
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_11
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_5_0
 BV BND1      service_0_5_2
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_1_5_0
 BV BND1      service_1_5_2
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_2_5_0
 BV BND1      service_2_5_2
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_7_0
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_12
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_1_7_0
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_12
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_2_7_0
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_12
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_2_0
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_0
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_0
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
