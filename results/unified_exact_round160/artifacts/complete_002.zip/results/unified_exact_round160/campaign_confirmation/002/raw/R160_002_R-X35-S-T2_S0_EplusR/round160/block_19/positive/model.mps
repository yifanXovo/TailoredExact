* Signature: 0xdba931384277d21b
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_30_18
 E  normalized_mass_30_19
 E  normalized_ratio_30_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_35_53
 E  normalized_mass_35_54
 E  normalized_ratio_35_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 E  onehot_34_88
 E  normalized_mass_34_89
 E  normalized_ratio_34_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 E  onehot_24_123
 E  normalized_mass_24_124
 E  normalized_ratio_24_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 E  onehot_29_148
 E  normalized_mass_29_149
 E  normalized_ratio_29_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 E  onehot_28_165
 E  normalized_mass_28_166
 E  normalized_ratio_28_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 E  onehot_27_182
 E  normalized_mass_27_183
 E  normalized_ratio_27_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 E  onehot_33_209
 E  normalized_mass_33_210
 E  normalized_ratio_33_211
 G  stock_lb_212
 L  stock_ub_213
 L  parent_nonstrict_scope_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 E  normalization_271
 G  full_original_Gini_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 L  arc_capacity_359
 L  arc_capacity_360
 L  arc_capacity_361
 L  arc_capacity_362
 L  arc_capacity_363
 L  arc_capacity_364
 L  arc_capacity_365
 L  arc_capacity_366
 L  arc_capacity_367
 L  arc_capacity_368
 L  arc_capacity_369
 L  arc_capacity_370
 L  arc_capacity_371
 L  arc_capacity_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 E  depot_departure_or_bypass_648
 E  depot_return_or_bypass_649
 E  out_degree_650
 E  in_degree_651
 G  order_active_lb_652
 L  order_active_ub_653
 E  segment_load_conservation_654
 G  segment_prefix_lb_655
 L  segment_prefix_ub_656
 E  out_degree_657
 E  in_degree_658
 G  order_active_lb_659
 L  order_active_ub_660
 E  segment_load_conservation_661
 G  segment_prefix_lb_662
 L  segment_prefix_ub_663
 E  out_degree_664
 E  in_degree_665
 G  order_active_lb_666
 L  order_active_ub_667
 E  segment_load_conservation_668
 G  segment_prefix_lb_669
 L  segment_prefix_ub_670
 E  out_degree_671
 E  in_degree_672
 G  order_active_lb_673
 L  order_active_ub_674
 E  segment_load_conservation_675
 G  segment_prefix_lb_676
 L  segment_prefix_ub_677
 E  out_degree_678
 E  in_degree_679
 G  order_active_lb_680
 L  order_active_ub_681
 E  service_visit_def_682
 E  free_load_conservation_683
 E  out_degree_684
 E  in_degree_685
 G  order_active_lb_686
 L  order_active_ub_687
 E  service_visit_def_688
 E  free_load_conservation_689
 E  out_degree_690
 E  in_degree_691
 G  order_active_lb_692
 L  order_active_ub_693
 E  service_visit_def_694
 E  free_load_conservation_695
 E  out_degree_696
 E  in_degree_697
 G  order_active_lb_698
 L  order_active_ub_699
 E  service_visit_def_700
 E  free_load_conservation_701
 E  out_degree_702
 E  in_degree_703
 G  order_active_lb_704
 L  order_active_ub_705
 E  service_visit_def_706
 E  free_load_conservation_707
 E  out_degree_708
 E  in_degree_709
 G  order_active_lb_710
 L  order_active_ub_711
 E  service_visit_def_712
 E  free_load_conservation_713
 E  out_degree_714
 E  in_degree_715
 G  order_active_lb_716
 L  order_active_ub_717
 E  service_visit_def_718
 E  free_load_conservation_719
 E  out_degree_720
 E  in_degree_721
 G  order_active_lb_722
 L  order_active_ub_723
 E  service_visit_def_724
 E  free_load_conservation_725
 G  fixed_segment_relative_order_726
 G  fixed_segment_relative_order_727
 G  fixed_segment_relative_order_728
 L  original_T_including_depot_unload_729
 L  arc_capacity_730
 L  arc_capacity_731
 L  arc_capacity_732
 L  arc_capacity_733
 L  arc_capacity_734
 L  arc_capacity_735
 L  arc_capacity_736
 L  arc_capacity_737
 L  arc_capacity_738
 L  arc_capacity_739
 L  arc_capacity_740
 L  arc_capacity_741
 L  arc_capacity_742
 L  arc_capacity_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 E  depot_departure_or_bypass_1019
 E  depot_return_or_bypass_1020
 E  out_degree_1021
 E  in_degree_1022
 G  order_active_lb_1023
 L  order_active_ub_1024
 E  segment_load_conservation_1025
 G  segment_prefix_lb_1026
 L  segment_prefix_ub_1027
 E  out_degree_1028
 E  in_degree_1029
 G  order_active_lb_1030
 L  order_active_ub_1031
 E  segment_load_conservation_1032
 G  segment_prefix_lb_1033
 L  segment_prefix_ub_1034
 E  out_degree_1035
 E  in_degree_1036
 G  order_active_lb_1037
 L  order_active_ub_1038
 E  segment_load_conservation_1039
 G  segment_prefix_lb_1040
 L  segment_prefix_ub_1041
 E  out_degree_1042
 E  in_degree_1043
 G  order_active_lb_1044
 L  order_active_ub_1045
 E  segment_load_conservation_1046
 G  segment_prefix_lb_1047
 L  segment_prefix_ub_1048
 E  out_degree_1049
 E  in_degree_1050
 G  order_active_lb_1051
 L  order_active_ub_1052
 E  service_visit_def_1053
 E  free_load_conservation_1054
 E  out_degree_1055
 E  in_degree_1056
 G  order_active_lb_1057
 L  order_active_ub_1058
 E  service_visit_def_1059
 E  free_load_conservation_1060
 E  out_degree_1061
 E  in_degree_1062
 G  order_active_lb_1063
 L  order_active_ub_1064
 E  service_visit_def_1065
 E  free_load_conservation_1066
 E  out_degree_1067
 E  in_degree_1068
 G  order_active_lb_1069
 L  order_active_ub_1070
 E  service_visit_def_1071
 E  free_load_conservation_1072
 E  out_degree_1073
 E  in_degree_1074
 G  order_active_lb_1075
 L  order_active_ub_1076
 E  service_visit_def_1077
 E  free_load_conservation_1078
 E  out_degree_1079
 E  in_degree_1080
 G  order_active_lb_1081
 L  order_active_ub_1082
 E  service_visit_def_1083
 E  free_load_conservation_1084
 E  out_degree_1085
 E  in_degree_1086
 G  order_active_lb_1087
 L  order_active_ub_1088
 E  service_visit_def_1089
 E  free_load_conservation_1090
 E  out_degree_1091
 E  in_degree_1092
 G  order_active_lb_1093
 L  order_active_ub_1094
 E  service_visit_def_1095
 E  free_load_conservation_1096
 G  fixed_segment_relative_order_1097
 G  fixed_segment_relative_order_1098
 G  fixed_segment_relative_order_1099
 L  original_T_including_depot_unload_1100
 L  arc_capacity_1101
 L  arc_capacity_1102
 L  arc_capacity_1103
 L  arc_capacity_1104
 L  arc_capacity_1105
 L  arc_capacity_1106
 L  arc_capacity_1107
 L  arc_capacity_1108
 L  arc_capacity_1109
 L  arc_capacity_1110
 L  arc_capacity_1111
 L  arc_capacity_1112
 L  arc_capacity_1113
 L  arc_capacity_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 E  depot_departure_or_bypass_1390
 E  depot_return_or_bypass_1391
 E  out_degree_1392
 E  in_degree_1393
 G  order_active_lb_1394
 L  order_active_ub_1395
 E  segment_load_conservation_1396
 G  segment_prefix_lb_1397
 L  segment_prefix_ub_1398
 E  out_degree_1399
 E  in_degree_1400
 G  order_active_lb_1401
 L  order_active_ub_1402
 E  segment_load_conservation_1403
 G  segment_prefix_lb_1404
 L  segment_prefix_ub_1405
 E  out_degree_1406
 E  in_degree_1407
 G  order_active_lb_1408
 L  order_active_ub_1409
 E  segment_load_conservation_1410
 G  segment_prefix_lb_1411
 L  segment_prefix_ub_1412
 E  out_degree_1413
 E  in_degree_1414
 G  order_active_lb_1415
 L  order_active_ub_1416
 E  segment_load_conservation_1417
 G  segment_prefix_lb_1418
 L  segment_prefix_ub_1419
 E  out_degree_1420
 E  in_degree_1421
 G  order_active_lb_1422
 L  order_active_ub_1423
 E  service_visit_def_1424
 E  free_load_conservation_1425
 E  out_degree_1426
 E  in_degree_1427
 G  order_active_lb_1428
 L  order_active_ub_1429
 E  service_visit_def_1430
 E  free_load_conservation_1431
 E  out_degree_1432
 E  in_degree_1433
 G  order_active_lb_1434
 L  order_active_ub_1435
 E  service_visit_def_1436
 E  free_load_conservation_1437
 E  out_degree_1438
 E  in_degree_1439
 G  order_active_lb_1440
 L  order_active_ub_1441
 E  service_visit_def_1442
 E  free_load_conservation_1443
 E  out_degree_1444
 E  in_degree_1445
 G  order_active_lb_1446
 L  order_active_ub_1447
 E  service_visit_def_1448
 E  free_load_conservation_1449
 E  out_degree_1450
 E  in_degree_1451
 G  order_active_lb_1452
 L  order_active_ub_1453
 E  service_visit_def_1454
 E  free_load_conservation_1455
 E  out_degree_1456
 E  in_degree_1457
 G  order_active_lb_1458
 L  order_active_ub_1459
 E  service_visit_def_1460
 E  free_load_conservation_1461
 E  out_degree_1462
 E  in_degree_1463
 G  order_active_lb_1464
 L  order_active_ub_1465
 E  service_visit_def_1466
 E  free_load_conservation_1467
 G  fixed_segment_relative_order_1468
 G  fixed_segment_relative_order_1469
 G  fixed_segment_relative_order_1470
 L  original_T_including_depot_unload_1471
COLUMNS
    t         normalized_mass_30_19  -1
    t         normalized_mass_35_54  -1
    t         normalized_mass_34_89  -1
    t         normalized_mass_24_124  -1
    t         normalized_mass_29_149  -1
    t         normalized_mass_28_166  -1
    t         normalized_mass_27_183  -1
    t         normalized_mass_33_210  -1
    t         normalization_271  2.3651190476190479e+01
    t         full_original_Gini_272  -7.7150000000000063e+01
    q         OBJ       1
    q         parent_nonstrict_scope_214  1
    q         full_original_Gini_272  35
    MARKER    'MARKER'                 'INTORG'
    x_30_0    OBJ       7.4474103065332977e-03
    x_30_0    product_lb_0  -2.5331724969817847e-02
    x_30_0    product_ub_1  -4.2281169779072841e-02
    x_30_0    onehot_30_18  1
    x_30_0    parent_nonstrict_scope_214  1.4894820613066595e-02
    x_30_0    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_0    product_lb_0  1
    w_30_0    product_ub_1  1
    w_30_0    normalized_mass_30_19  1
    w_30_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_1    OBJ       3.7237051532666493e-03
    x_30_1    product_lb_2  -2.5331724969817847e-02
    x_30_1    product_ub_3  -4.2281169779072841e-02
    x_30_1    onehot_30_18  1
    x_30_1    stock_lb_212  1
    x_30_1    stock_ub_213  1
    x_30_1    parent_nonstrict_scope_214  1.1171115459799947e-02
    x_30_1    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_1    product_lb_2  1
    w_30_1    product_ub_3  1
    w_30_1    normalized_mass_30_19  1
    w_30_1    normalized_ratio_30_20  -0.25
    w_30_1    full_original_Gini_272  -1.7401190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_2    product_lb_4  -2.5331724969817847e-02
    x_30_2    product_ub_5  -4.2281169779072841e-02
    x_30_2    onehot_30_18  1
    x_30_2    stock_lb_212  2
    x_30_2    stock_ub_213  2
    x_30_2    parent_nonstrict_scope_214  7.4474103065332977e-03
    x_30_2    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_2    product_lb_4  1
    w_30_2    product_ub_5  1
    w_30_2    normalized_mass_30_19  1
    w_30_2    normalized_ratio_30_20  -0.5
    w_30_2    full_original_Gini_272  -1.1151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_3    OBJ       -3.7237051532666488e-03
    x_30_3    product_lb_6  -2.5331724969817847e-02
    x_30_3    product_ub_7  -4.2281169779072841e-02
    x_30_3    onehot_30_18  1
    x_30_3    stock_lb_212  3
    x_30_3    stock_ub_213  3
    x_30_3    parent_nonstrict_scope_214  3.7237051532666488e-03
    x_30_3    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_3    product_lb_6  1
    w_30_3    product_ub_7  1
    w_30_3    normalized_mass_30_19  1
    w_30_3    normalized_ratio_30_20  -0.75
    w_30_3    full_original_Gini_272  -5.1392857142857133e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_4    OBJ       -7.4474103065332977e-03
    x_30_4    product_lb_8  -2.5331724969817847e-02
    x_30_4    product_ub_9  -4.2281169779072841e-02
    x_30_4    onehot_30_18  1
    x_30_4    stock_lb_212  4
    x_30_4    stock_ub_213  4
    x_30_4    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_4    product_lb_8  1
    w_30_4    product_ub_9  1
    w_30_4    normalized_mass_30_19  1
    w_30_4    normalized_ratio_30_20  -1
    w_30_4    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_5    OBJ       -3.7237051532666488e-03
    x_30_5    product_lb_10  -2.5331724969817847e-02
    x_30_5    product_ub_11  -4.2281169779072841e-02
    x_30_5    onehot_30_18  1
    x_30_5    stock_lb_212  5
    x_30_5    stock_ub_213  5
    x_30_5    parent_nonstrict_scope_214  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_30_5    product_lb_10  1
    w_30_5    product_ub_11  1
    w_30_5    normalized_mass_30_19  1
    w_30_5    normalized_ratio_30_20  -1.25
    w_30_5    full_original_Gini_272  -1.0598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_6    product_lb_12  -2.5331724969817847e-02
    x_30_6    product_ub_13  -4.2281169779072841e-02
    x_30_6    onehot_30_18  1
    x_30_6    stock_lb_212  6
    x_30_6    stock_ub_213  6
    x_30_6    parent_nonstrict_scope_214  7.4474103065332977e-03
    x_30_6    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_6    product_lb_12  1
    w_30_6    product_ub_13  1
    w_30_6    normalized_mass_30_19  1
    w_30_6    normalized_ratio_30_20  -1.5
    w_30_6    full_original_Gini_272  -1.6848809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_7    OBJ       3.7237051532666493e-03
    x_30_7    product_lb_14  -2.5331724969817847e-02
    x_30_7    product_ub_15  -4.2281169779072841e-02
    x_30_7    onehot_30_18  1
    x_30_7    stock_lb_212  7
    x_30_7    stock_ub_213  7
    x_30_7    parent_nonstrict_scope_214  1.1171115459799947e-02
    x_30_7    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_7    product_lb_14  1
    w_30_7    product_ub_15  1
    w_30_7    normalized_mass_30_19  1
    w_30_7    normalized_ratio_30_20  -1.75
    w_30_7    full_original_Gini_272  -2.3598809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_8    OBJ       7.4474103065332977e-03
    x_30_8    product_lb_16  -2.5331724969817847e-02
    x_30_8    product_ub_17  -4.2281169779072841e-02
    x_30_8    onehot_30_18  1
    x_30_8    stock_lb_212  8
    x_30_8    stock_ub_213  8
    x_30_8    parent_nonstrict_scope_214  1.4894820613066595e-02
    x_30_8    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_8    product_lb_16  1
    w_30_8    product_ub_17  1
    w_30_8    normalized_mass_30_19  1
    w_30_8    normalized_ratio_30_20  -2
    w_30_8    full_original_Gini_272  -3.0348809523809518e+01
    rho_30    normalized_ratio_30_20  1
    rho_30    block_pair_pos_235  -1
    rho_30    block_pair_neg_236  1
    rho_30    block_pair_pos_237  -1
    rho_30    block_pair_neg_238  1
    rho_30    block_pair_pos_239  -1
    rho_30    block_pair_neg_240  1
    rho_30    block_pair_pos_241  -1
    rho_30    block_pair_neg_242  1
    rho_30    block_pair_pos_243  -1
    rho_30    block_pair_neg_244  1
    rho_30    block_pair_pos_245  -1
    rho_30    block_pair_neg_246  1
    rho_30    block_pair_pos_247  -1
    rho_30    block_pair_neg_248  1
    rho_30    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       2.9789603523644435e-02
    x_35_0    product_lb_21  -2.5331724969817847e-02
    x_35_0    product_ub_22  -4.2281169779072841e-02
    x_35_0    onehot_35_53  1
    x_35_0    parent_nonstrict_scope_214  5.9579207047288869e-02
    x_35_0    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_21  1
    w_35_0    product_ub_22  1
    w_35_0    normalized_mass_35_54  1
    w_35_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       2.2342202642733327e-02
    x_35_1    product_lb_23  -2.5331724969817847e-02
    x_35_1    product_ub_24  -4.2281169779072841e-02
    x_35_1    onehot_35_53  1
    x_35_1    stock_lb_212  1
    x_35_1    stock_ub_213  1
    x_35_1    parent_nonstrict_scope_214  5.2131806166377762e-02
    x_35_1    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_23  1
    w_35_1    product_ub_24  1
    w_35_1    normalized_mass_35_54  1
    w_35_1    normalized_ratio_35_55  -0.125
    w_35_1    full_original_Gini_272  -2.0526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       1.4894801761822219e-02
    x_35_2    product_lb_25  -2.5331724969817847e-02
    x_35_2    product_ub_26  -4.2281169779072841e-02
    x_35_2    onehot_35_53  1
    x_35_2    stock_lb_212  2
    x_35_2    stock_ub_213  2
    x_35_2    parent_nonstrict_scope_214  4.4684405285466654e-02
    x_35_2    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_25  1
    w_35_2    product_ub_26  1
    w_35_2    normalized_mass_35_54  1
    w_35_2    normalized_ratio_35_55  -0.25
    w_35_2    full_original_Gini_272  -1.7401190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       7.4474008809111113e-03
    x_35_3    product_lb_27  -2.5331724969817847e-02
    x_35_3    product_ub_28  -4.2281169779072841e-02
    x_35_3    onehot_35_53  1
    x_35_3    stock_lb_212  3
    x_35_3    stock_ub_213  3
    x_35_3    parent_nonstrict_scope_214  3.7237004404555546e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_27  1
    w_35_3    product_ub_28  1
    w_35_3    normalized_mass_35_54  1
    w_35_3    normalized_ratio_35_55  -0.375
    w_35_3    full_original_Gini_272  -1.4276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_29  -2.5331724969817847e-02
    x_35_4    product_ub_30  -4.2281169779072841e-02
    x_35_4    onehot_35_53  1
    x_35_4    stock_lb_212  4
    x_35_4    stock_ub_213  4
    x_35_4    parent_nonstrict_scope_214  2.9789603523644435e-02
    x_35_4    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_29  1
    w_35_4    product_ub_30  1
    w_35_4    normalized_mass_35_54  1
    w_35_4    normalized_ratio_35_55  -0.5
    w_35_4    full_original_Gini_272  -1.1151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -7.4474008809111078e-03
    x_35_5    product_lb_31  -2.5331724969817847e-02
    x_35_5    product_ub_32  -4.2281169779072841e-02
    x_35_5    onehot_35_53  1
    x_35_5    stock_lb_212  5
    x_35_5    stock_ub_213  5
    x_35_5    parent_nonstrict_scope_214  2.2342202642733327e-02
    x_35_5    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_31  1
    w_35_5    product_ub_32  1
    w_35_5    normalized_mass_35_54  1
    w_35_5    normalized_ratio_35_55  -0.625
    w_35_5    full_original_Gini_272  -8.0261904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -1.4894801761822217e-02
    x_35_6    product_lb_33  -2.5331724969817847e-02
    x_35_6    product_ub_34  -4.2281169779072841e-02
    x_35_6    onehot_35_53  1
    x_35_6    stock_lb_212  6
    x_35_6    stock_ub_213  6
    x_35_6    parent_nonstrict_scope_214  1.4894801761822217e-02
    x_35_6    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_33  1
    w_35_6    product_ub_34  1
    w_35_6    normalized_mass_35_54  1
    w_35_6    normalized_ratio_35_55  -0.75
    w_35_6    full_original_Gini_272  -5.1392857142857133e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -2.2342202642733327e-02
    x_35_7    product_lb_35  -2.5331724969817847e-02
    x_35_7    product_ub_36  -4.2281169779072841e-02
    x_35_7    onehot_35_53  1
    x_35_7    stock_lb_212  7
    x_35_7    stock_ub_213  7
    x_35_7    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_35_7    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_35  1
    w_35_7    product_ub_36  1
    w_35_7    normalized_mass_35_54  1
    w_35_7    normalized_ratio_35_55  -0.875
    w_35_7    full_original_Gini_272  -3.9738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -2.9789603523644435e-02
    x_35_8    product_lb_37  -2.5331724969817847e-02
    x_35_8    product_ub_38  -4.2281169779072841e-02
    x_35_8    onehot_35_53  1
    x_35_8    stock_lb_212  8
    x_35_8    stock_ub_213  8
    x_35_8    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_37  1
    w_35_8    product_ub_38  1
    w_35_8    normalized_mass_35_54  1
    w_35_8    normalized_ratio_35_55  -1
    w_35_8    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -2.2342202642733327e-02
    x_35_9    product_lb_39  -2.5331724969817847e-02
    x_35_9    product_ub_40  -4.2281169779072841e-02
    x_35_9    onehot_35_53  1
    x_35_9    stock_lb_212  9
    x_35_9    stock_ub_213  9
    x_35_9    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_35_9    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_39  1
    w_35_9    product_ub_40  1
    w_35_9    normalized_mass_35_54  1
    w_35_9    normalized_ratio_35_55  -1.125
    w_35_9    full_original_Gini_272  -7.4738095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -1.4894801761822217e-02
    x_35_10   product_lb_41  -2.5331724969817847e-02
    x_35_10   product_ub_42  -4.2281169779072841e-02
    x_35_10   onehot_35_53  1
    x_35_10   stock_lb_212  10
    x_35_10   stock_ub_213  10
    x_35_10   parent_nonstrict_scope_214  1.4894801761822217e-02
    x_35_10   unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_41  1
    w_35_10   product_ub_42  1
    w_35_10   normalized_mass_35_54  1
    w_35_10   normalized_ratio_35_55  -1.25
    w_35_10   full_original_Gini_272  -1.0598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -7.4474008809111078e-03
    x_35_11   product_lb_43  -2.5331724969817847e-02
    x_35_11   product_ub_44  -4.2281169779072841e-02
    x_35_11   onehot_35_53  1
    x_35_11   stock_lb_212  11
    x_35_11   stock_ub_213  11
    x_35_11   parent_nonstrict_scope_214  2.2342202642733327e-02
    x_35_11   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_43  1
    w_35_11   product_ub_44  1
    w_35_11   normalized_mass_35_54  1
    w_35_11   normalized_ratio_35_55  -1.375
    w_35_11   full_original_Gini_272  -1.3723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_45  -2.5331724969817847e-02
    x_35_12   product_ub_46  -4.2281169779072841e-02
    x_35_12   onehot_35_53  1
    x_35_12   stock_lb_212  12
    x_35_12   stock_ub_213  12
    x_35_12   parent_nonstrict_scope_214  2.9789603523644435e-02
    x_35_12   unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_45  1
    w_35_12   product_ub_46  1
    w_35_12   normalized_mass_35_54  1
    w_35_12   normalized_ratio_35_55  -1.5
    w_35_12   full_original_Gini_272  -1.6848809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       7.4474008809111113e-03
    x_35_13   product_lb_47  -2.5331724969817847e-02
    x_35_13   product_ub_48  -4.2281169779072841e-02
    x_35_13   onehot_35_53  1
    x_35_13   stock_lb_212  13
    x_35_13   stock_ub_213  13
    x_35_13   parent_nonstrict_scope_214  3.7237004404555546e-02
    x_35_13   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_47  1
    w_35_13   product_ub_48  1
    w_35_13   normalized_mass_35_54  1
    w_35_13   normalized_ratio_35_55  -1.625
    w_35_13   full_original_Gini_272  -2.0223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       1.4894801761822219e-02
    x_35_14   product_lb_49  -2.5331724969817847e-02
    x_35_14   product_ub_50  -4.2281169779072841e-02
    x_35_14   onehot_35_53  1
    x_35_14   stock_lb_212  14
    x_35_14   stock_ub_213  14
    x_35_14   parent_nonstrict_scope_214  4.4684405285466654e-02
    x_35_14   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_49  1
    w_35_14   product_ub_50  1
    w_35_14   normalized_mass_35_54  1
    w_35_14   normalized_ratio_35_55  -1.75
    w_35_14   full_original_Gini_272  -2.3598809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       2.2342202642733327e-02
    x_35_15   product_lb_51  -2.5331724969817847e-02
    x_35_15   product_ub_52  -4.2281169779072841e-02
    x_35_15   onehot_35_53  1
    x_35_15   stock_lb_212  15
    x_35_15   stock_ub_213  15
    x_35_15   parent_nonstrict_scope_214  5.2131806166377762e-02
    x_35_15   unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_51  1
    w_35_15   product_ub_52  1
    w_35_15   normalized_mass_35_54  1
    w_35_15   normalized_ratio_35_55  -1.875
    w_35_15   full_original_Gini_272  -2.6973809523809518e+01
    rho_35    normalized_ratio_35_55  1
    rho_35    block_pair_pos_247  1
    rho_35    block_pair_neg_248  -1
    rho_35    block_pair_pos_259  -1
    rho_35    block_pair_neg_260  1
    rho_35    block_pair_pos_261  -1
    rho_35    block_pair_neg_262  1
    rho_35    block_pair_pos_263  -1
    rho_35    block_pair_neg_264  1
    rho_35    block_pair_pos_265  -1
    rho_35    block_pair_neg_266  1
    rho_35    block_pair_pos_267  -1
    rho_35    block_pair_neg_268  1
    rho_35    block_pair_pos_269  -1
    rho_35    block_pair_neg_270  1
    rho_35    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_56  -2.5331724969817847e-02
    x_34_0    product_ub_57  -4.2281169779072841e-02
    x_34_0    onehot_34_88  1
    x_34_0    parent_nonstrict_scope_214  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_56  1
    w_34_0    product_ub_57  1
    w_34_0    normalized_mass_34_89  1
    w_34_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_58  -2.5331724969817847e-02
    x_34_1    product_ub_59  -4.2281169779072841e-02
    x_34_1    onehot_34_88  1
    x_34_1    stock_lb_212  1
    x_34_1    stock_ub_213  1
    x_34_1    parent_nonstrict_scope_214  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_58  1
    w_34_1    product_ub_59  1
    w_34_1    normalized_mass_34_89  1
    w_34_1    normalized_ratio_34_90  -0.125
    w_34_1    full_original_Gini_272  -2.0526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_60  -2.5331724969817847e-02
    x_34_2    product_ub_61  -4.2281169779072841e-02
    x_34_2    onehot_34_88  1
    x_34_2    stock_lb_212  2
    x_34_2    stock_ub_213  2
    x_34_2    parent_nonstrict_scope_214  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_60  1
    w_34_2    product_ub_61  1
    w_34_2    normalized_mass_34_89  1
    w_34_2    normalized_ratio_34_90  -0.25
    w_34_2    full_original_Gini_272  -1.7401190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_62  -2.5331724969817847e-02
    x_34_3    product_ub_63  -4.2281169779072841e-02
    x_34_3    onehot_34_88  1
    x_34_3    stock_lb_212  3
    x_34_3    stock_ub_213  3
    x_34_3    parent_nonstrict_scope_214  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_62  1
    w_34_3    product_ub_63  1
    w_34_3    normalized_mass_34_89  1
    w_34_3    normalized_ratio_34_90  -0.375
    w_34_3    full_original_Gini_272  -1.4276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_64  -2.5331724969817847e-02
    x_34_4    product_ub_65  -4.2281169779072841e-02
    x_34_4    onehot_34_88  1
    x_34_4    stock_lb_212  4
    x_34_4    stock_ub_213  4
    x_34_4    parent_nonstrict_scope_214  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_64  1
    w_34_4    product_ub_65  1
    w_34_4    normalized_mass_34_89  1
    w_34_4    normalized_ratio_34_90  -0.5
    w_34_4    full_original_Gini_272  -1.1151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_66  -2.5331724969817847e-02
    x_34_5    product_ub_67  -4.2281169779072841e-02
    x_34_5    onehot_34_88  1
    x_34_5    stock_lb_212  5
    x_34_5    stock_ub_213  5
    x_34_5    parent_nonstrict_scope_214  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_66  1
    w_34_5    product_ub_67  1
    w_34_5    normalized_mass_34_89  1
    w_34_5    normalized_ratio_34_90  -0.625
    w_34_5    full_original_Gini_272  -8.0261904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_68  -2.5331724969817847e-02
    x_34_6    product_ub_69  -4.2281169779072841e-02
    x_34_6    onehot_34_88  1
    x_34_6    stock_lb_212  6
    x_34_6    stock_ub_213  6
    x_34_6    parent_nonstrict_scope_214  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_68  1
    w_34_6    product_ub_69  1
    w_34_6    normalized_mass_34_89  1
    w_34_6    normalized_ratio_34_90  -0.75
    w_34_6    full_original_Gini_272  -5.1392857142857133e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_70  -2.5331724969817847e-02
    x_34_7    product_ub_71  -4.2281169779072841e-02
    x_34_7    onehot_34_88  1
    x_34_7    stock_lb_212  7
    x_34_7    stock_ub_213  7
    x_34_7    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_70  1
    w_34_7    product_ub_71  1
    w_34_7    normalized_mass_34_89  1
    w_34_7    normalized_ratio_34_90  -0.875
    w_34_7    full_original_Gini_272  -3.9738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_72  -2.5331724969817847e-02
    x_34_8    product_ub_73  -4.2281169779072841e-02
    x_34_8    onehot_34_88  1
    x_34_8    stock_lb_212  8
    x_34_8    stock_ub_213  8
    x_34_8    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_72  1
    w_34_8    product_ub_73  1
    w_34_8    normalized_mass_34_89  1
    w_34_8    normalized_ratio_34_90  -1
    w_34_8    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_74  -2.5331724969817847e-02
    x_34_9    product_ub_75  -4.2281169779072841e-02
    x_34_9    onehot_34_88  1
    x_34_9    stock_lb_212  9
    x_34_9    stock_ub_213  9
    x_34_9    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_74  1
    w_34_9    product_ub_75  1
    w_34_9    normalized_mass_34_89  1
    w_34_9    normalized_ratio_34_90  -1.125
    w_34_9    full_original_Gini_272  -7.4738095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_76  -2.5331724969817847e-02
    x_34_10   product_ub_77  -4.2281169779072841e-02
    x_34_10   onehot_34_88  1
    x_34_10   stock_lb_212  10
    x_34_10   stock_ub_213  10
    x_34_10   parent_nonstrict_scope_214  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_76  1
    w_34_10   product_ub_77  1
    w_34_10   normalized_mass_34_89  1
    w_34_10   normalized_ratio_34_90  -1.25
    w_34_10   full_original_Gini_272  -1.0598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_78  -2.5331724969817847e-02
    x_34_11   product_ub_79  -4.2281169779072841e-02
    x_34_11   onehot_34_88  1
    x_34_11   stock_lb_212  11
    x_34_11   stock_ub_213  11
    x_34_11   parent_nonstrict_scope_214  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_78  1
    w_34_11   product_ub_79  1
    w_34_11   normalized_mass_34_89  1
    w_34_11   normalized_ratio_34_90  -1.375
    w_34_11   full_original_Gini_272  -1.3723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_80  -2.5331724969817847e-02
    x_34_12   product_ub_81  -4.2281169779072841e-02
    x_34_12   onehot_34_88  1
    x_34_12   stock_lb_212  12
    x_34_12   stock_ub_213  12
    x_34_12   parent_nonstrict_scope_214  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_80  1
    w_34_12   product_ub_81  1
    w_34_12   normalized_mass_34_89  1
    w_34_12   normalized_ratio_34_90  -1.5
    w_34_12   full_original_Gini_272  -1.6848809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_82  -2.5331724969817847e-02
    x_34_13   product_ub_83  -4.2281169779072841e-02
    x_34_13   onehot_34_88  1
    x_34_13   stock_lb_212  13
    x_34_13   stock_ub_213  13
    x_34_13   parent_nonstrict_scope_214  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_82  1
    w_34_13   product_ub_83  1
    w_34_13   normalized_mass_34_89  1
    w_34_13   normalized_ratio_34_90  -1.625
    w_34_13   full_original_Gini_272  -2.0223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_84  -2.5331724969817847e-02
    x_34_14   product_ub_85  -4.2281169779072841e-02
    x_34_14   onehot_34_88  1
    x_34_14   stock_lb_212  14
    x_34_14   stock_ub_213  14
    x_34_14   parent_nonstrict_scope_214  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_84  1
    w_34_14   product_ub_85  1
    w_34_14   normalized_mass_34_89  1
    w_34_14   normalized_ratio_34_90  -1.75
    w_34_14   full_original_Gini_272  -2.3598809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_86  -2.5331724969817847e-02
    x_34_15   product_ub_87  -4.2281169779072841e-02
    x_34_15   onehot_34_88  1
    x_34_15   stock_lb_212  15
    x_34_15   stock_ub_213  15
    x_34_15   parent_nonstrict_scope_214  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_86  1
    w_34_15   product_ub_87  1
    w_34_15   normalized_mass_34_89  1
    w_34_15   normalized_ratio_34_90  -1.875
    w_34_15   full_original_Gini_272  -2.6973809523809518e+01
    rho_34    normalized_ratio_34_90  1
    rho_34    block_pair_pos_245  1
    rho_34    block_pair_neg_246  -1
    rho_34    block_pair_pos_249  -1
    rho_34    block_pair_neg_250  1
    rho_34    block_pair_pos_251  -1
    rho_34    block_pair_neg_252  1
    rho_34    block_pair_pos_253  -1
    rho_34    block_pair_neg_254  1
    rho_34    block_pair_pos_255  -1
    rho_34    block_pair_neg_256  1
    rho_34    block_pair_pos_257  -1
    rho_34    block_pair_neg_258  1
    rho_34    block_pair_pos_269  1
    rho_34    block_pair_neg_270  -1
    rho_34    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_24_0    OBJ       2.9789603523644435e-02
    x_24_0    product_lb_91  -2.5331724969817847e-02
    x_24_0    product_ub_92  -4.2281169779072841e-02
    x_24_0    onehot_24_123  1
    x_24_0    parent_nonstrict_scope_214  5.9579207047288869e-02
    x_24_0    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_0    product_lb_91  1
    w_24_0    product_ub_92  1
    w_24_0    normalized_mass_24_124  1
    w_24_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_1    OBJ       2.2342202642733327e-02
    x_24_1    product_lb_93  -2.5331724969817847e-02
    x_24_1    product_ub_94  -4.2281169779072841e-02
    x_24_1    onehot_24_123  1
    x_24_1    stock_lb_212  1
    x_24_1    stock_ub_213  1
    x_24_1    parent_nonstrict_scope_214  5.2131806166377762e-02
    x_24_1    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_1    product_lb_93  1
    w_24_1    product_ub_94  1
    w_24_1    normalized_mass_24_124  1
    w_24_1    normalized_ratio_24_125  -0.125
    w_24_1    full_original_Gini_272  -2.0526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_2    OBJ       1.4894801761822219e-02
    x_24_2    product_lb_95  -2.5331724969817847e-02
    x_24_2    product_ub_96  -4.2281169779072841e-02
    x_24_2    onehot_24_123  1
    x_24_2    stock_lb_212  2
    x_24_2    stock_ub_213  2
    x_24_2    parent_nonstrict_scope_214  4.4684405285466654e-02
    x_24_2    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_2    product_lb_95  1
    w_24_2    product_ub_96  1
    w_24_2    normalized_mass_24_124  1
    w_24_2    normalized_ratio_24_125  -0.25
    w_24_2    full_original_Gini_272  -1.7401190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_3    OBJ       7.4474008809111113e-03
    x_24_3    product_lb_97  -2.5331724969817847e-02
    x_24_3    product_ub_98  -4.2281169779072841e-02
    x_24_3    onehot_24_123  1
    x_24_3    stock_lb_212  3
    x_24_3    stock_ub_213  3
    x_24_3    parent_nonstrict_scope_214  3.7237004404555546e-02
    x_24_3    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_3    product_lb_97  1
    w_24_3    product_ub_98  1
    w_24_3    normalized_mass_24_124  1
    w_24_3    normalized_ratio_24_125  -0.375
    w_24_3    full_original_Gini_272  -1.4276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_4    product_lb_99  -2.5331724969817847e-02
    x_24_4    product_ub_100  -4.2281169779072841e-02
    x_24_4    onehot_24_123  1
    x_24_4    stock_lb_212  4
    x_24_4    stock_ub_213  4
    x_24_4    parent_nonstrict_scope_214  2.9789603523644435e-02
    x_24_4    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_4    product_lb_99  1
    w_24_4    product_ub_100  1
    w_24_4    normalized_mass_24_124  1
    w_24_4    normalized_ratio_24_125  -0.5
    w_24_4    full_original_Gini_272  -1.1151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_5    OBJ       -7.4474008809111078e-03
    x_24_5    product_lb_101  -2.5331724969817847e-02
    x_24_5    product_ub_102  -4.2281169779072841e-02
    x_24_5    onehot_24_123  1
    x_24_5    stock_lb_212  5
    x_24_5    stock_ub_213  5
    x_24_5    parent_nonstrict_scope_214  2.2342202642733327e-02
    x_24_5    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_5    product_lb_101  1
    w_24_5    product_ub_102  1
    w_24_5    normalized_mass_24_124  1
    w_24_5    normalized_ratio_24_125  -0.625
    w_24_5    full_original_Gini_272  -8.0261904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_6    OBJ       -1.4894801761822217e-02
    x_24_6    product_lb_103  -2.5331724969817847e-02
    x_24_6    product_ub_104  -4.2281169779072841e-02
    x_24_6    onehot_24_123  1
    x_24_6    stock_lb_212  6
    x_24_6    stock_ub_213  6
    x_24_6    parent_nonstrict_scope_214  1.4894801761822217e-02
    x_24_6    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_6    product_lb_103  1
    w_24_6    product_ub_104  1
    w_24_6    normalized_mass_24_124  1
    w_24_6    normalized_ratio_24_125  -0.75
    w_24_6    full_original_Gini_272  -5.1392857142857133e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_7    OBJ       -2.2342202642733327e-02
    x_24_7    product_lb_105  -2.5331724969817847e-02
    x_24_7    product_ub_106  -4.2281169779072841e-02
    x_24_7    onehot_24_123  1
    x_24_7    stock_lb_212  7
    x_24_7    stock_ub_213  7
    x_24_7    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_24_7    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_7    product_lb_105  1
    w_24_7    product_ub_106  1
    w_24_7    normalized_mass_24_124  1
    w_24_7    normalized_ratio_24_125  -0.875
    w_24_7    full_original_Gini_272  -3.9738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_8    OBJ       -2.9789603523644435e-02
    x_24_8    product_lb_107  -2.5331724969817847e-02
    x_24_8    product_ub_108  -4.2281169779072841e-02
    x_24_8    onehot_24_123  1
    x_24_8    stock_lb_212  8
    x_24_8    stock_ub_213  8
    x_24_8    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_8    product_lb_107  1
    w_24_8    product_ub_108  1
    w_24_8    normalized_mass_24_124  1
    w_24_8    normalized_ratio_24_125  -1
    w_24_8    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_9    OBJ       -2.2342202642733327e-02
    x_24_9    product_lb_109  -2.5331724969817847e-02
    x_24_9    product_ub_110  -4.2281169779072841e-02
    x_24_9    onehot_24_123  1
    x_24_9    stock_lb_212  9
    x_24_9    stock_ub_213  9
    x_24_9    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_24_9    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_9    product_lb_109  1
    w_24_9    product_ub_110  1
    w_24_9    normalized_mass_24_124  1
    w_24_9    normalized_ratio_24_125  -1.125
    w_24_9    full_original_Gini_272  -7.4738095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_10   OBJ       -1.4894801761822217e-02
    x_24_10   product_lb_111  -2.5331724969817847e-02
    x_24_10   product_ub_112  -4.2281169779072841e-02
    x_24_10   onehot_24_123  1
    x_24_10   stock_lb_212  10
    x_24_10   stock_ub_213  10
    x_24_10   parent_nonstrict_scope_214  1.4894801761822217e-02
    x_24_10   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_10   product_lb_111  1
    w_24_10   product_ub_112  1
    w_24_10   normalized_mass_24_124  1
    w_24_10   normalized_ratio_24_125  -1.25
    w_24_10   full_original_Gini_272  -1.0598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_11   OBJ       -7.4474008809111078e-03
    x_24_11   product_lb_113  -2.5331724969817847e-02
    x_24_11   product_ub_114  -4.2281169779072841e-02
    x_24_11   onehot_24_123  1
    x_24_11   stock_lb_212  11
    x_24_11   stock_ub_213  11
    x_24_11   parent_nonstrict_scope_214  2.2342202642733327e-02
    x_24_11   unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_11   product_lb_113  1
    w_24_11   product_ub_114  1
    w_24_11   normalized_mass_24_124  1
    w_24_11   normalized_ratio_24_125  -1.375
    w_24_11   full_original_Gini_272  -1.3723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_12   product_lb_115  -2.5331724969817847e-02
    x_24_12   product_ub_116  -4.2281169779072841e-02
    x_24_12   onehot_24_123  1
    x_24_12   stock_lb_212  12
    x_24_12   stock_ub_213  12
    x_24_12   parent_nonstrict_scope_214  2.9789603523644435e-02
    x_24_12   unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_12   product_lb_115  1
    w_24_12   product_ub_116  1
    w_24_12   normalized_mass_24_124  1
    w_24_12   normalized_ratio_24_125  -1.5
    w_24_12   full_original_Gini_272  -1.6848809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_13   OBJ       7.4474008809111113e-03
    x_24_13   product_lb_117  -2.5331724969817847e-02
    x_24_13   product_ub_118  -4.2281169779072841e-02
    x_24_13   onehot_24_123  1
    x_24_13   stock_lb_212  13
    x_24_13   stock_ub_213  13
    x_24_13   parent_nonstrict_scope_214  3.7237004404555546e-02
    MARKER    'MARKER'                 'INTEND'
    w_24_13   product_lb_117  1
    w_24_13   product_ub_118  1
    w_24_13   normalized_mass_24_124  1
    w_24_13   normalized_ratio_24_125  -1.625
    w_24_13   full_original_Gini_272  -2.0223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_14   OBJ       1.4894801761822219e-02
    x_24_14   product_lb_119  -2.5331724969817847e-02
    x_24_14   product_ub_120  -4.2281169779072841e-02
    x_24_14   onehot_24_123  1
    x_24_14   stock_lb_212  14
    x_24_14   stock_ub_213  14
    x_24_14   parent_nonstrict_scope_214  4.4684405285466654e-02
    x_24_14   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_14   product_lb_119  1
    w_24_14   product_ub_120  1
    w_24_14   normalized_mass_24_124  1
    w_24_14   normalized_ratio_24_125  -1.75
    w_24_14   full_original_Gini_272  -2.3598809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_15   OBJ       2.2342202642733327e-02
    x_24_15   product_lb_121  -2.5331724969817847e-02
    x_24_15   product_ub_122  -4.2281169779072841e-02
    x_24_15   onehot_24_123  1
    x_24_15   stock_lb_212  15
    x_24_15   stock_ub_213  15
    x_24_15   parent_nonstrict_scope_214  5.2131806166377762e-02
    x_24_15   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_15   product_lb_121  1
    w_24_15   product_ub_122  1
    w_24_15   normalized_mass_24_124  1
    w_24_15   normalized_ratio_24_125  -1.875
    w_24_15   full_original_Gini_272  -2.6973809523809518e+01
    rho_24    normalized_ratio_24_125  1
    rho_24    block_pair_pos_215  -1
    rho_24    block_pair_neg_216  1
    rho_24    block_pair_pos_217  -1
    rho_24    block_pair_neg_218  1
    rho_24    block_pair_pos_219  -1
    rho_24    block_pair_neg_220  1
    rho_24    block_pair_pos_221  -1
    rho_24    block_pair_neg_222  1
    rho_24    block_pair_pos_235  1
    rho_24    block_pair_neg_236  -1
    rho_24    block_pair_pos_249  1
    rho_24    block_pair_neg_250  -1
    rho_24    block_pair_pos_259  1
    rho_24    block_pair_neg_260  -1
    rho_24    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_126  -2.5331724969817847e-02
    x_29_0    product_ub_127  -4.2281169779072841e-02
    x_29_0    onehot_29_148  1
    x_29_0    parent_nonstrict_scope_214  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_126  1
    w_29_0    product_ub_127  1
    w_29_0    normalized_mass_29_149  1
    w_29_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_128  -2.5331724969817847e-02
    x_29_1    product_ub_129  -4.2281169779072841e-02
    x_29_1    onehot_29_148  1
    x_29_1    stock_lb_212  1
    x_29_1    stock_ub_213  1
    x_29_1    parent_nonstrict_scope_214  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_128  1
    w_29_1    product_ub_129  1
    w_29_1    normalized_mass_29_149  1
    w_29_1    normalized_ratio_29_150  -0.2
    w_29_1    full_original_Gini_272  -1.8651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_130  -2.5331724969817847e-02
    x_29_2    product_ub_131  -4.2281169779072841e-02
    x_29_2    onehot_29_148  1
    x_29_2    stock_lb_212  2
    x_29_2    stock_ub_213  2
    x_29_2    parent_nonstrict_scope_214  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_130  1
    w_29_2    product_ub_131  1
    w_29_2    normalized_mass_29_149  1
    w_29_2    normalized_ratio_29_150  -0.4
    w_29_2    full_original_Gini_272  -1.3651190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_132  -2.5331724969817847e-02
    x_29_3    product_ub_133  -4.2281169779072841e-02
    x_29_3    onehot_29_148  1
    x_29_3    stock_lb_212  3
    x_29_3    stock_ub_213  3
    x_29_3    parent_nonstrict_scope_214  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_132  1
    w_29_3    product_ub_133  1
    w_29_3    normalized_mass_29_149  1
    w_29_3    normalized_ratio_29_150  -6.0000000000000009e-01
    w_29_3    full_original_Gini_272  -8.6511904761904788e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_134  -2.5331724969817847e-02
    x_29_4    product_ub_135  -4.2281169779072841e-02
    x_29_4    onehot_29_148  1
    x_29_4    stock_lb_212  4
    x_29_4    stock_ub_213  4
    x_29_4    parent_nonstrict_scope_214  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_134  1
    w_29_4    product_ub_135  1
    w_29_4    normalized_mass_29_149  1
    w_29_4    normalized_ratio_29_150  -0.8
    w_29_4    full_original_Gini_272  -4.4892857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_136  -2.5331724969817847e-02
    x_29_5    product_ub_137  -4.2281169779072841e-02
    x_29_5    onehot_29_148  1
    x_29_5    stock_lb_212  5
    x_29_5    stock_ub_213  5
    x_29_5    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_136  1
    w_29_5    product_ub_137  1
    w_29_5    normalized_mass_29_149  1
    w_29_5    normalized_ratio_29_150  -1
    w_29_5    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_138  -2.5331724969817847e-02
    x_29_6    product_ub_139  -4.2281169779072841e-02
    x_29_6    onehot_29_148  1
    x_29_6    stock_lb_212  6
    x_29_6    stock_ub_213  6
    x_29_6    parent_nonstrict_scope_214  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_138  1
    w_29_6    product_ub_139  1
    w_29_6    normalized_mass_29_149  1
    w_29_6    normalized_ratio_29_150  -1.2000000000000002e+00
    w_29_6    full_original_Gini_272  -9.3488095238095266e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_140  -2.5331724969817847e-02
    x_29_7    product_ub_141  -4.2281169779072841e-02
    x_29_7    onehot_29_148  1
    x_29_7    stock_lb_212  7
    x_29_7    stock_ub_213  7
    x_29_7    parent_nonstrict_scope_214  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_140  1
    w_29_7    product_ub_141  1
    w_29_7    normalized_mass_29_149  1
    w_29_7    normalized_ratio_29_150  -1.4000000000000001e+00
    w_29_7    full_original_Gini_272  -1.4348809523809532e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_142  -2.5331724969817847e-02
    x_29_8    product_ub_143  -4.2281169779072841e-02
    x_29_8    onehot_29_148  1
    x_29_8    stock_lb_212  8
    x_29_8    stock_ub_213  8
    x_29_8    parent_nonstrict_scope_214  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_142  1
    w_29_8    product_ub_143  1
    w_29_8    normalized_mass_29_149  1
    w_29_8    normalized_ratio_29_150  -1.6
    w_29_8    full_original_Gini_272  -1.9548809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_144  -2.5331724969817847e-02
    x_29_9    product_ub_145  -4.2281169779072841e-02
    x_29_9    onehot_29_148  1
    x_29_9    stock_lb_212  9
    x_29_9    stock_ub_213  9
    x_29_9    parent_nonstrict_scope_214  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_144  1
    w_29_9    product_ub_145  1
    w_29_9    normalized_mass_29_149  1
    w_29_9    normalized_ratio_29_150  -1.8
    w_29_9    full_original_Gini_272  -2.4948809523809533e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_146  -2.5331724969817847e-02
    x_29_10   product_ub_147  -4.2281169779072841e-02
    x_29_10   onehot_29_148  1
    x_29_10   stock_lb_212  10
    x_29_10   stock_ub_213  10
    x_29_10   parent_nonstrict_scope_214  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_146  1
    w_29_10   product_ub_147  1
    w_29_10   normalized_mass_29_149  1
    w_29_10   normalized_ratio_29_150  -2
    w_29_10   full_original_Gini_272  -3.0348809523809518e+01
    rho_29    normalized_ratio_29_150  1
    rho_29    block_pair_pos_219  1
    rho_29    block_pair_neg_220  -1
    rho_29    block_pair_pos_229  -1
    rho_29    block_pair_neg_230  1
    rho_29    block_pair_pos_231  -1
    rho_29    block_pair_neg_232  1
    rho_29    block_pair_pos_233  -1
    rho_29    block_pair_neg_234  1
    rho_29    block_pair_pos_241  1
    rho_29    block_pair_neg_242  -1
    rho_29    block_pair_pos_255  1
    rho_29    block_pair_neg_256  -1
    rho_29    block_pair_pos_265  1
    rho_29    block_pair_neg_266  -1
    rho_29    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_28_0    OBJ       4.1891612282083379e-03
    x_28_0    product_lb_151  -2.5331724969817847e-02
    x_28_0    product_ub_152  -4.2281169779072841e-02
    x_28_0    onehot_28_165  1
    x_28_0    parent_nonstrict_scope_214  8.3783224564166758e-03
    x_28_0    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_0    product_lb_151  1
    w_28_0    product_ub_152  1
    w_28_0    normalized_mass_28_166  1
    w_28_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_1    OBJ       1.3963870760694466e-03
    x_28_1    product_lb_153  -2.5331724969817847e-02
    x_28_1    product_ub_154  -4.2281169779072841e-02
    x_28_1    onehot_28_165  1
    x_28_1    stock_lb_212  1
    x_28_1    stock_ub_213  1
    x_28_1    parent_nonstrict_scope_214  5.5855483042777845e-03
    MARKER    'MARKER'                 'INTEND'
    w_28_1    product_lb_153  1
    w_28_1    product_ub_154  1
    w_28_1    normalized_mass_28_166  1
    w_28_1    normalized_ratio_28_167  -3.3333333333333331e-01
    w_28_1    full_original_Gini_272  -1.5317857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_2    OBJ       -1.3963870760694457e-03
    x_28_2    product_lb_155  -2.5331724969817847e-02
    x_28_2    product_ub_156  -4.2281169779072841e-02
    x_28_2    onehot_28_165  1
    x_28_2    stock_lb_212  2
    x_28_2    stock_ub_213  2
    x_28_2    parent_nonstrict_scope_214  2.7927741521388922e-03
    x_28_2    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_2    product_lb_155  1
    w_28_2    product_ub_156  1
    w_28_2    normalized_mass_28_166  1
    w_28_2    normalized_ratio_28_167  -6.6666666666666663e-01
    w_28_2    full_original_Gini_272  -6.9845238095238082e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_3    OBJ       -4.1891612282083379e-03
    x_28_3    product_lb_157  -2.5331724969817847e-02
    x_28_3    product_ub_158  -4.2281169779072841e-02
    x_28_3    onehot_28_165  1
    x_28_3    stock_lb_212  3
    x_28_3    stock_ub_213  3
    x_28_3    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_3    product_lb_157  1
    w_28_3    product_ub_158  1
    w_28_3    normalized_mass_28_166  1
    w_28_3    normalized_ratio_28_167  -1
    w_28_3    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_4    OBJ       -1.3963870760694466e-03
    x_28_4    product_lb_159  -2.5331724969817847e-02
    x_28_4    product_ub_160  -4.2281169779072841e-02
    x_28_4    onehot_28_165  1
    x_28_4    stock_lb_212  4
    x_28_4    stock_ub_213  4
    x_28_4    parent_nonstrict_scope_214  2.7927741521388914e-03
    x_28_4    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_4    product_lb_159  1
    w_28_4    product_ub_160  1
    w_28_4    normalized_mass_28_166  1
    w_28_4    normalized_ratio_28_167  -1.3333333333333333e+00
    w_28_4    full_original_Gini_272  -1.2682142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_5    OBJ       1.3963870760694448e-03
    x_28_5    product_lb_161  -2.5331724969817847e-02
    x_28_5    product_ub_162  -4.2281169779072841e-02
    x_28_5    onehot_28_165  1
    x_28_5    stock_lb_212  5
    x_28_5    stock_ub_213  5
    x_28_5    parent_nonstrict_scope_214  5.5855483042777827e-03
    x_28_5    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_5    product_lb_161  1
    w_28_5    product_ub_162  1
    w_28_5    normalized_mass_28_166  1
    w_28_5    normalized_ratio_28_167  -1.6666666666666665e+00
    w_28_5    full_original_Gini_272  -2.1348809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_6    OBJ       4.1891612282083379e-03
    x_28_6    product_lb_163  -2.5331724969817847e-02
    x_28_6    product_ub_164  -4.2281169779072841e-02
    x_28_6    onehot_28_165  1
    x_28_6    stock_lb_212  6
    x_28_6    stock_ub_213  6
    x_28_6    parent_nonstrict_scope_214  8.3783224564166758e-03
    x_28_6    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_6    product_lb_163  1
    w_28_6    product_ub_164  1
    w_28_6    normalized_mass_28_166  1
    w_28_6    normalized_ratio_28_167  -2
    w_28_6    full_original_Gini_272  -3.0348809523809518e+01
    rho_28    normalized_ratio_28_167  1
    rho_28    block_pair_pos_217  1
    rho_28    block_pair_neg_218  -1
    rho_28    block_pair_pos_225  -1
    rho_28    block_pair_neg_226  1
    rho_28    block_pair_pos_227  -1
    rho_28    block_pair_neg_228  1
    rho_28    block_pair_pos_231  1
    rho_28    block_pair_neg_232  -1
    rho_28    block_pair_pos_239  1
    rho_28    block_pair_neg_240  -1
    rho_28    block_pair_pos_253  1
    rho_28    block_pair_neg_254  -1
    rho_28    block_pair_pos_263  1
    rho_28    block_pair_neg_264  -1
    rho_28    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_168  -2.5331724969817847e-02
    x_27_0    product_ub_169  -4.2281169779072841e-02
    x_27_0    onehot_27_182  1
    x_27_0    parent_nonstrict_scope_214  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_168  1
    w_27_0    product_ub_169  1
    w_27_0    normalized_mass_27_183  1
    w_27_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_170  -2.5331724969817847e-02
    x_27_1    product_ub_171  -4.2281169779072841e-02
    x_27_1    onehot_27_182  1
    x_27_1    stock_lb_212  1
    x_27_1    stock_ub_213  1
    x_27_1    parent_nonstrict_scope_214  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_170  1
    w_27_1    product_ub_171  1
    w_27_1    normalized_mass_27_183  1
    w_27_1    normalized_ratio_27_184  -3.3333333333333331e-01
    w_27_1    full_original_Gini_272  -1.5317857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_172  -2.5331724969817847e-02
    x_27_2    product_ub_173  -4.2281169779072841e-02
    x_27_2    onehot_27_182  1
    x_27_2    stock_lb_212  2
    x_27_2    stock_ub_213  2
    x_27_2    parent_nonstrict_scope_214  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_172  1
    w_27_2    product_ub_173  1
    w_27_2    normalized_mass_27_183  1
    w_27_2    normalized_ratio_27_184  -6.6666666666666663e-01
    w_27_2    full_original_Gini_272  -6.9845238095238082e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_174  -2.5331724969817847e-02
    x_27_3    product_ub_175  -4.2281169779072841e-02
    x_27_3    onehot_27_182  1
    x_27_3    stock_lb_212  3
    x_27_3    stock_ub_213  3
    x_27_3    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_174  1
    w_27_3    product_ub_175  1
    w_27_3    normalized_mass_27_183  1
    w_27_3    normalized_ratio_27_184  -1
    w_27_3    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_176  -2.5331724969817847e-02
    x_27_4    product_ub_177  -4.2281169779072841e-02
    x_27_4    onehot_27_182  1
    x_27_4    stock_lb_212  4
    x_27_4    stock_ub_213  4
    x_27_4    parent_nonstrict_scope_214  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_176  1
    w_27_4    product_ub_177  1
    w_27_4    normalized_mass_27_183  1
    w_27_4    normalized_ratio_27_184  -1.3333333333333333e+00
    w_27_4    full_original_Gini_272  -1.2682142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_178  -2.5331724969817847e-02
    x_27_5    product_ub_179  -4.2281169779072841e-02
    x_27_5    onehot_27_182  1
    x_27_5    stock_lb_212  5
    x_27_5    stock_ub_213  5
    x_27_5    parent_nonstrict_scope_214  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_178  1
    w_27_5    product_ub_179  1
    w_27_5    normalized_mass_27_183  1
    w_27_5    normalized_ratio_27_184  -1.6666666666666665e+00
    w_27_5    full_original_Gini_272  -2.1348809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_180  -2.5331724969817847e-02
    x_27_6    product_ub_181  -4.2281169779072841e-02
    x_27_6    onehot_27_182  1
    x_27_6    stock_lb_212  6
    x_27_6    stock_ub_213  6
    x_27_6    parent_nonstrict_scope_214  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_180  1
    w_27_6    product_ub_181  1
    w_27_6    normalized_mass_27_183  1
    w_27_6    normalized_ratio_27_184  -2
    w_27_6    full_original_Gini_272  -3.0348809523809518e+01
    rho_27    normalized_ratio_27_184  1
    rho_27    block_pair_pos_215  1
    rho_27    block_pair_neg_216  -1
    rho_27    block_pair_pos_223  -1
    rho_27    block_pair_neg_224  1
    rho_27    block_pair_pos_225  1
    rho_27    block_pair_neg_226  -1
    rho_27    block_pair_pos_229  1
    rho_27    block_pair_neg_230  -1
    rho_27    block_pair_pos_237  1
    rho_27    block_pair_neg_238  -1
    rho_27    block_pair_pos_251  1
    rho_27    block_pair_neg_252  -1
    rho_27    block_pair_pos_261  1
    rho_27    block_pair_neg_262  -1
    rho_27    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_33_0    OBJ       9.3092572277933064e-03
    x_33_0    product_lb_185  -2.5331724969817847e-02
    x_33_0    product_ub_186  -4.2281169779072841e-02
    x_33_0    onehot_33_209  1
    x_33_0    parent_nonstrict_scope_214  2.3273143069483273e-02
    x_33_0    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_0    product_lb_185  1
    w_33_0    product_ub_186  1
    w_33_0    normalized_mass_33_210  1
    w_33_0    full_original_Gini_272  -2.3651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_1    OBJ       4.6546286138966532e-03
    x_33_1    product_lb_187  -2.5331724969817847e-02
    x_33_1    product_ub_188  -4.2281169779072841e-02
    x_33_1    onehot_33_209  1
    x_33_1    stock_lb_212  1
    x_33_1    stock_ub_213  1
    x_33_1    parent_nonstrict_scope_214  1.8618514455586620e-02
    x_33_1    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_1    product_lb_187  1
    w_33_1    product_ub_188  1
    w_33_1    normalized_mass_33_210  1
    w_33_1    normalized_ratio_33_211  -0.2
    w_33_1    full_original_Gini_272  -1.8651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_2    OBJ       -3.4694469519536142e-18
    x_33_2    product_lb_189  -2.5331724969817847e-02
    x_33_2    product_ub_190  -4.2281169779072841e-02
    x_33_2    onehot_33_209  1
    x_33_2    stock_lb_212  2
    x_33_2    stock_ub_213  2
    x_33_2    parent_nonstrict_scope_214  1.3963885841689963e-02
    x_33_2    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_2    product_lb_189  1
    w_33_2    product_ub_190  1
    w_33_2    normalized_mass_33_210  1
    w_33_2    normalized_ratio_33_211  -0.4
    w_33_2    full_original_Gini_272  -1.3651190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_3    OBJ       -0.00465462861389666
    x_33_3    product_lb_191  -2.5331724969817847e-02
    x_33_3    product_ub_192  -4.2281169779072841e-02
    x_33_3    onehot_33_209  1
    x_33_3    stock_lb_212  3
    x_33_3    stock_ub_213  3
    x_33_3    parent_nonstrict_scope_214  9.3092572277933064e-03
    x_33_3    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_3    product_lb_191  1
    w_33_3    product_ub_192  1
    w_33_3    normalized_mass_33_210  1
    w_33_3    normalized_ratio_33_211  -6.0000000000000009e-01
    w_33_3    full_original_Gini_272  -8.6511904761904788e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_4    OBJ       -9.3092572277933133e-03
    x_33_4    product_lb_193  -2.5331724969817847e-02
    x_33_4    product_ub_194  -4.2281169779072841e-02
    x_33_4    onehot_33_209  1
    x_33_4    stock_lb_212  4
    x_33_4    stock_ub_213  4
    x_33_4    parent_nonstrict_scope_214  4.6546286138966532e-03
    x_33_4    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_4    product_lb_193  1
    w_33_4    product_ub_194  1
    w_33_4    normalized_mass_33_210  1
    w_33_4    normalized_ratio_33_211  -0.8
    w_33_4    full_original_Gini_272  -4.4892857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_5    OBJ       -1.3963885841689967e-02
    x_33_5    product_lb_195  -2.5331724969817847e-02
    x_33_5    product_ub_196  -4.2281169779072841e-02
    x_33_5    onehot_33_209  1
    x_33_5    stock_lb_212  5
    x_33_5    stock_ub_213  5
    x_33_5    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_5    product_lb_195  1
    w_33_5    product_ub_196  1
    w_33_5    normalized_mass_33_210  1
    w_33_5    normalized_ratio_33_211  -1
    w_33_5    full_original_Gini_272  -4.3488095238095239e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_6    OBJ       -9.3092572277933081e-03
    x_33_6    product_lb_197  -2.5331724969817847e-02
    x_33_6    product_ub_198  -4.2281169779072841e-02
    x_33_6    onehot_33_209  1
    x_33_6    stock_lb_212  6
    x_33_6    stock_ub_213  6
    x_33_6    parent_nonstrict_scope_214  4.6546286138966584e-03
    x_33_6    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_6    product_lb_197  1
    w_33_6    product_ub_198  1
    w_33_6    normalized_mass_33_210  1
    w_33_6    normalized_ratio_33_211  -1.2000000000000002e+00
    w_33_6    full_original_Gini_272  -9.3488095238095266e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_7    OBJ       -4.6546286138966549e-03
    x_33_7    product_lb_199  -2.5331724969817847e-02
    x_33_7    product_ub_200  -4.2281169779072841e-02
    x_33_7    onehot_33_209  1
    x_33_7    stock_lb_212  7
    x_33_7    stock_ub_213  7
    x_33_7    parent_nonstrict_scope_214  9.3092572277933116e-03
    x_33_7    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_7    product_lb_199  1
    w_33_7    product_ub_200  1
    w_33_7    normalized_mass_33_210  1
    w_33_7    normalized_ratio_33_211  -1.4000000000000001e+00
    w_33_7    full_original_Gini_272  -1.4348809523809532e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_8    product_lb_201  -2.5331724969817847e-02
    x_33_8    product_ub_202  -4.2281169779072841e-02
    x_33_8    onehot_33_209  1
    x_33_8    stock_lb_212  8
    x_33_8    stock_ub_213  8
    x_33_8    parent_nonstrict_scope_214  1.3963885841689967e-02
    MARKER    'MARKER'                 'INTEND'
    w_33_8    product_lb_201  1
    w_33_8    product_ub_202  1
    w_33_8    normalized_mass_33_210  1
    w_33_8    normalized_ratio_33_211  -1.6
    w_33_8    full_original_Gini_272  -1.9548809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_9    OBJ       4.6546286138966532e-03
    x_33_9    product_lb_203  -2.5331724969817847e-02
    x_33_9    product_ub_204  -4.2281169779072841e-02
    x_33_9    onehot_33_209  1
    x_33_9    stock_lb_212  9
    x_33_9    stock_ub_213  9
    x_33_9    parent_nonstrict_scope_214  1.8618514455586620e-02
    x_33_9    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_9    product_lb_203  1
    w_33_9    product_ub_204  1
    w_33_9    normalized_mass_33_210  1
    w_33_9    normalized_ratio_33_211  -1.8
    w_33_9    full_original_Gini_272  -2.4948809523809533e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_10   OBJ       9.3092572277933064e-03
    x_33_10   product_lb_205  -2.5331724969817847e-02
    x_33_10   product_ub_206  -4.2281169779072841e-02
    x_33_10   onehot_33_209  1
    x_33_10   stock_lb_212  10
    x_33_10   stock_ub_213  10
    x_33_10   parent_nonstrict_scope_214  2.3273143069483273e-02
    x_33_10   unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_10   product_lb_205  1
    w_33_10   product_ub_206  1
    w_33_10   normalized_mass_33_210  1
    w_33_10   normalized_ratio_33_211  -2
    w_33_10   full_original_Gini_272  -3.0348809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_11   OBJ       1.3963885841689967e-02
    x_33_11   product_lb_207  -2.5331724969817847e-02
    x_33_11   product_ub_208  -4.2281169779072841e-02
    x_33_11   onehot_33_209  1
    x_33_11   stock_lb_212  11
    x_33_11   stock_ub_213  11
    x_33_11   parent_nonstrict_scope_214  2.7927771683379933e-02
    x_33_11   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_11   product_lb_207  1
    w_33_11   product_ub_208  1
    w_33_11   normalized_mass_33_210  1
    w_33_11   normalized_ratio_33_211  -2.2
    w_33_11   full_original_Gini_272  -3.5748809523809520e+01
    rho_33    normalized_ratio_33_211  1
    rho_33    block_pair_pos_221  1
    rho_33    block_pair_neg_222  -1
    rho_33    block_pair_pos_223  1
    rho_33    block_pair_neg_224  -1
    rho_33    block_pair_pos_227  1
    rho_33    block_pair_neg_228  -1
    rho_33    block_pair_pos_233  1
    rho_33    block_pair_neg_234  -1
    rho_33    block_pair_pos_243  1
    rho_33    block_pair_neg_244  -1
    rho_33    block_pair_pos_257  1
    rho_33    block_pair_neg_258  -1
    rho_33    block_pair_pos_267  1
    rho_33    block_pair_neg_268  -1
    rho_33    normalization_271  1
    a_30_35   block_pair_pos_247  1
    a_30_35   block_pair_neg_248  1
    a_30_35   full_original_Gini_272  -1
    a_30_34   block_pair_pos_245  1
    a_30_34   block_pair_neg_246  1
    a_30_34   full_original_Gini_272  -1
    a_30_24   block_pair_pos_235  1
    a_30_24   block_pair_neg_236  1
    a_30_24   full_original_Gini_272  -1
    a_30_29   block_pair_pos_241  1
    a_30_29   block_pair_neg_242  1
    a_30_29   full_original_Gini_272  -1
    a_30_28   block_pair_pos_239  1
    a_30_28   block_pair_neg_240  1
    a_30_28   full_original_Gini_272  -1
    a_30_27   block_pair_pos_237  1
    a_30_27   block_pair_neg_238  1
    a_30_27   full_original_Gini_272  -1
    a_30_33   block_pair_pos_243  1
    a_30_33   block_pair_neg_244  1
    a_30_33   full_original_Gini_272  -1
    a_35_34   block_pair_pos_269  1
    a_35_34   block_pair_neg_270  1
    a_35_34   full_original_Gini_272  -1
    a_35_24   block_pair_pos_259  1
    a_35_24   block_pair_neg_260  1
    a_35_24   full_original_Gini_272  -1
    a_35_29   block_pair_pos_265  1
    a_35_29   block_pair_neg_266  1
    a_35_29   full_original_Gini_272  -1
    a_35_28   block_pair_pos_263  1
    a_35_28   block_pair_neg_264  1
    a_35_28   full_original_Gini_272  -1
    a_35_27   block_pair_pos_261  1
    a_35_27   block_pair_neg_262  1
    a_35_27   full_original_Gini_272  -1
    a_35_33   block_pair_pos_267  1
    a_35_33   block_pair_neg_268  1
    a_35_33   full_original_Gini_272  -1
    a_34_24   block_pair_pos_249  1
    a_34_24   block_pair_neg_250  1
    a_34_24   full_original_Gini_272  -1
    a_34_29   block_pair_pos_255  1
    a_34_29   block_pair_neg_256  1
    a_34_29   full_original_Gini_272  -1
    a_34_28   block_pair_pos_253  1
    a_34_28   block_pair_neg_254  1
    a_34_28   full_original_Gini_272  -1
    a_34_27   block_pair_pos_251  1
    a_34_27   block_pair_neg_252  1
    a_34_27   full_original_Gini_272  -1
    a_34_33   block_pair_pos_257  1
    a_34_33   block_pair_neg_258  1
    a_34_33   full_original_Gini_272  -1
    a_24_29   block_pair_pos_219  1
    a_24_29   block_pair_neg_220  1
    a_24_29   full_original_Gini_272  -1
    a_24_28   block_pair_pos_217  1
    a_24_28   block_pair_neg_218  1
    a_24_28   full_original_Gini_272  -1
    a_24_27   block_pair_pos_215  1
    a_24_27   block_pair_neg_216  1
    a_24_27   full_original_Gini_272  -1
    a_24_33   block_pair_pos_221  1
    a_24_33   block_pair_neg_222  1
    a_24_33   full_original_Gini_272  -1
    a_29_28   block_pair_pos_231  1
    a_29_28   block_pair_neg_232  1
    a_29_28   full_original_Gini_272  -1
    a_29_27   block_pair_pos_229  1
    a_29_27   block_pair_neg_230  1
    a_29_27   full_original_Gini_272  -1
    a_29_33   block_pair_pos_233  1
    a_29_33   block_pair_neg_234  1
    a_29_33   full_original_Gini_272  -1
    a_28_27   block_pair_pos_225  1
    a_28_27   block_pair_neg_226  1
    a_28_27   full_original_Gini_272  -1
    a_28_33   block_pair_pos_227  1
    a_28_33   block_pair_neg_228  1
    a_28_33   full_original_Gini_272  -1
    a_27_33   block_pair_pos_223  1
    a_27_33   block_pair_neg_224  1
    a_27_33   full_original_Gini_272  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_30_0  unique_nonzero_owner_273  1
    service_0_30_0  service_visit_def_682  1
    service_0_30_0  free_load_conservation_683  -5
    service_0_30_0  original_T_including_depot_unload_729  600
    service_0_30_1  unique_nonzero_owner_274  1
    service_0_30_1  service_visit_def_682  1
    service_0_30_1  free_load_conservation_683  -4
    service_0_30_1  original_T_including_depot_unload_729  480
    service_0_30_2  unique_nonzero_owner_275  1
    service_0_30_2  service_visit_def_682  1
    service_0_30_2  free_load_conservation_683  -3
    service_0_30_2  original_T_including_depot_unload_729  360
    service_0_30_3  unique_nonzero_owner_276  1
    service_0_30_3  service_visit_def_682  1
    service_0_30_3  free_load_conservation_683  -2
    service_0_30_3  original_T_including_depot_unload_729  240
    service_0_30_4  unique_nonzero_owner_277  1
    service_0_30_4  service_visit_def_682  1
    service_0_30_4  free_load_conservation_683  -1
    service_0_30_4  original_T_including_depot_unload_729  120
    service_0_30_6  unique_nonzero_owner_278  1
    service_0_30_6  service_visit_def_682  1
    service_0_30_6  free_load_conservation_683  1
    service_0_30_7  unique_nonzero_owner_279  1
    service_0_30_7  service_visit_def_682  1
    service_0_30_7  free_load_conservation_683  2
    service_0_30_8  unique_nonzero_owner_280  1
    service_0_30_8  service_visit_def_682  1
    service_0_30_8  free_load_conservation_683  3
    service_1_30_0  unique_nonzero_owner_273  1
    service_1_30_0  service_visit_def_1053  1
    service_1_30_0  free_load_conservation_1054  -5
    service_1_30_0  original_T_including_depot_unload_1100  600
    service_1_30_1  unique_nonzero_owner_274  1
    service_1_30_1  service_visit_def_1053  1
    service_1_30_1  free_load_conservation_1054  -4
    service_1_30_1  original_T_including_depot_unload_1100  480
    service_1_30_2  unique_nonzero_owner_275  1
    service_1_30_2  service_visit_def_1053  1
    service_1_30_2  free_load_conservation_1054  -3
    service_1_30_2  original_T_including_depot_unload_1100  360
    service_1_30_3  unique_nonzero_owner_276  1
    service_1_30_3  service_visit_def_1053  1
    service_1_30_3  free_load_conservation_1054  -2
    service_1_30_3  original_T_including_depot_unload_1100  240
    service_1_30_4  unique_nonzero_owner_277  1
    service_1_30_4  service_visit_def_1053  1
    service_1_30_4  free_load_conservation_1054  -1
    service_1_30_4  original_T_including_depot_unload_1100  120
    service_1_30_6  unique_nonzero_owner_278  1
    service_1_30_6  service_visit_def_1053  1
    service_1_30_6  free_load_conservation_1054  1
    service_1_30_7  unique_nonzero_owner_279  1
    service_1_30_7  service_visit_def_1053  1
    service_1_30_7  free_load_conservation_1054  2
    service_1_30_8  unique_nonzero_owner_280  1
    service_1_30_8  service_visit_def_1053  1
    service_1_30_8  free_load_conservation_1054  3
    service_2_30_0  unique_nonzero_owner_273  1
    service_2_30_0  service_visit_def_1424  1
    service_2_30_0  free_load_conservation_1425  -5
    service_2_30_0  original_T_including_depot_unload_1471  600
    service_2_30_1  unique_nonzero_owner_274  1
    service_2_30_1  service_visit_def_1424  1
    service_2_30_1  free_load_conservation_1425  -4
    service_2_30_1  original_T_including_depot_unload_1471  480
    service_2_30_2  unique_nonzero_owner_275  1
    service_2_30_2  service_visit_def_1424  1
    service_2_30_2  free_load_conservation_1425  -3
    service_2_30_2  original_T_including_depot_unload_1471  360
    service_2_30_3  unique_nonzero_owner_276  1
    service_2_30_3  service_visit_def_1424  1
    service_2_30_3  free_load_conservation_1425  -2
    service_2_30_3  original_T_including_depot_unload_1471  240
    service_2_30_4  unique_nonzero_owner_277  1
    service_2_30_4  service_visit_def_1424  1
    service_2_30_4  free_load_conservation_1425  -1
    service_2_30_4  original_T_including_depot_unload_1471  120
    service_2_30_6  unique_nonzero_owner_278  1
    service_2_30_6  service_visit_def_1424  1
    service_2_30_6  free_load_conservation_1425  1
    service_2_30_7  unique_nonzero_owner_279  1
    service_2_30_7  service_visit_def_1424  1
    service_2_30_7  free_load_conservation_1425  2
    service_2_30_8  unique_nonzero_owner_280  1
    service_2_30_8  service_visit_def_1424  1
    service_2_30_8  free_load_conservation_1425  3
    service_0_35_0  unique_nonzero_owner_281  1
    service_0_35_0  service_visit_def_688  1
    service_0_35_0  free_load_conservation_689  -3
    service_0_35_0  original_T_including_depot_unload_729  360
    service_0_35_1  unique_nonzero_owner_282  1
    service_0_35_1  service_visit_def_688  1
    service_0_35_1  free_load_conservation_689  -2
    service_0_35_1  original_T_including_depot_unload_729  240
    service_0_35_2  unique_nonzero_owner_283  1
    service_0_35_2  service_visit_def_688  1
    service_0_35_2  free_load_conservation_689  -1
    service_0_35_2  original_T_including_depot_unload_729  120
    service_0_35_4  unique_nonzero_owner_284  1
    service_0_35_4  service_visit_def_688  1
    service_0_35_4  free_load_conservation_689  1
    service_0_35_5  unique_nonzero_owner_285  1
    service_0_35_5  service_visit_def_688  1
    service_0_35_5  free_load_conservation_689  2
    service_0_35_6  unique_nonzero_owner_286  1
    service_0_35_6  service_visit_def_688  1
    service_0_35_6  free_load_conservation_689  3
    service_0_35_7  unique_nonzero_owner_287  1
    service_0_35_7  service_visit_def_688  1
    service_0_35_7  free_load_conservation_689  4
    service_0_35_8  unique_nonzero_owner_288  1
    service_0_35_8  service_visit_def_688  1
    service_0_35_8  free_load_conservation_689  5
    service_0_35_9  unique_nonzero_owner_289  1
    service_0_35_9  service_visit_def_688  1
    service_0_35_9  free_load_conservation_689  6
    service_0_35_10  unique_nonzero_owner_290  1
    service_0_35_10  service_visit_def_688  1
    service_0_35_10  free_load_conservation_689  7
    service_0_35_11  unique_nonzero_owner_291  1
    service_0_35_11  service_visit_def_688  1
    service_0_35_11  free_load_conservation_689  8
    service_0_35_12  unique_nonzero_owner_292  1
    service_0_35_12  service_visit_def_688  1
    service_0_35_12  free_load_conservation_689  9
    service_0_35_13  unique_nonzero_owner_293  1
    service_0_35_13  service_visit_def_688  1
    service_0_35_13  free_load_conservation_689  10
    service_0_35_14  unique_nonzero_owner_294  1
    service_0_35_14  service_visit_def_688  1
    service_0_35_14  free_load_conservation_689  11
    service_0_35_15  unique_nonzero_owner_295  1
    service_0_35_15  service_visit_def_688  1
    service_0_35_15  free_load_conservation_689  12
    service_1_35_0  unique_nonzero_owner_281  1
    service_1_35_0  service_visit_def_1059  1
    service_1_35_0  free_load_conservation_1060  -3
    service_1_35_0  original_T_including_depot_unload_1100  360
    service_1_35_1  unique_nonzero_owner_282  1
    service_1_35_1  service_visit_def_1059  1
    service_1_35_1  free_load_conservation_1060  -2
    service_1_35_1  original_T_including_depot_unload_1100  240
    service_1_35_2  unique_nonzero_owner_283  1
    service_1_35_2  service_visit_def_1059  1
    service_1_35_2  free_load_conservation_1060  -1
    service_1_35_2  original_T_including_depot_unload_1100  120
    service_1_35_4  unique_nonzero_owner_284  1
    service_1_35_4  service_visit_def_1059  1
    service_1_35_4  free_load_conservation_1060  1
    service_1_35_5  unique_nonzero_owner_285  1
    service_1_35_5  service_visit_def_1059  1
    service_1_35_5  free_load_conservation_1060  2
    service_1_35_6  unique_nonzero_owner_286  1
    service_1_35_6  service_visit_def_1059  1
    service_1_35_6  free_load_conservation_1060  3
    service_1_35_7  unique_nonzero_owner_287  1
    service_1_35_7  service_visit_def_1059  1
    service_1_35_7  free_load_conservation_1060  4
    service_1_35_8  unique_nonzero_owner_288  1
    service_1_35_8  service_visit_def_1059  1
    service_1_35_8  free_load_conservation_1060  5
    service_1_35_9  unique_nonzero_owner_289  1
    service_1_35_9  service_visit_def_1059  1
    service_1_35_9  free_load_conservation_1060  6
    service_1_35_10  unique_nonzero_owner_290  1
    service_1_35_10  service_visit_def_1059  1
    service_1_35_10  free_load_conservation_1060  7
    service_1_35_11  unique_nonzero_owner_291  1
    service_1_35_11  service_visit_def_1059  1
    service_1_35_11  free_load_conservation_1060  8
    service_1_35_12  unique_nonzero_owner_292  1
    service_1_35_12  service_visit_def_1059  1
    service_1_35_12  free_load_conservation_1060  9
    service_1_35_13  unique_nonzero_owner_293  1
    service_1_35_13  service_visit_def_1059  1
    service_1_35_13  free_load_conservation_1060  10
    service_1_35_14  unique_nonzero_owner_294  1
    service_1_35_14  service_visit_def_1059  1
    service_1_35_14  free_load_conservation_1060  11
    service_1_35_15  unique_nonzero_owner_295  1
    service_1_35_15  service_visit_def_1059  1
    service_1_35_15  free_load_conservation_1060  12
    service_2_35_0  unique_nonzero_owner_281  1
    service_2_35_0  service_visit_def_1430  1
    service_2_35_0  free_load_conservation_1431  -3
    service_2_35_0  original_T_including_depot_unload_1471  360
    service_2_35_1  unique_nonzero_owner_282  1
    service_2_35_1  service_visit_def_1430  1
    service_2_35_1  free_load_conservation_1431  -2
    service_2_35_1  original_T_including_depot_unload_1471  240
    service_2_35_2  unique_nonzero_owner_283  1
    service_2_35_2  service_visit_def_1430  1
    service_2_35_2  free_load_conservation_1431  -1
    service_2_35_2  original_T_including_depot_unload_1471  120
    service_2_35_4  unique_nonzero_owner_284  1
    service_2_35_4  service_visit_def_1430  1
    service_2_35_4  free_load_conservation_1431  1
    service_2_35_5  unique_nonzero_owner_285  1
    service_2_35_5  service_visit_def_1430  1
    service_2_35_5  free_load_conservation_1431  2
    service_2_35_6  unique_nonzero_owner_286  1
    service_2_35_6  service_visit_def_1430  1
    service_2_35_6  free_load_conservation_1431  3
    service_2_35_7  unique_nonzero_owner_287  1
    service_2_35_7  service_visit_def_1430  1
    service_2_35_7  free_load_conservation_1431  4
    service_2_35_8  unique_nonzero_owner_288  1
    service_2_35_8  service_visit_def_1430  1
    service_2_35_8  free_load_conservation_1431  5
    service_2_35_9  unique_nonzero_owner_289  1
    service_2_35_9  service_visit_def_1430  1
    service_2_35_9  free_load_conservation_1431  6
    service_2_35_10  unique_nonzero_owner_290  1
    service_2_35_10  service_visit_def_1430  1
    service_2_35_10  free_load_conservation_1431  7
    service_2_35_11  unique_nonzero_owner_291  1
    service_2_35_11  service_visit_def_1430  1
    service_2_35_11  free_load_conservation_1431  8
    service_2_35_12  unique_nonzero_owner_292  1
    service_2_35_12  service_visit_def_1430  1
    service_2_35_12  free_load_conservation_1431  9
    service_2_35_13  unique_nonzero_owner_293  1
    service_2_35_13  service_visit_def_1430  1
    service_2_35_13  free_load_conservation_1431  10
    service_2_35_14  unique_nonzero_owner_294  1
    service_2_35_14  service_visit_def_1430  1
    service_2_35_14  free_load_conservation_1431  11
    service_2_35_15  unique_nonzero_owner_295  1
    service_2_35_15  service_visit_def_1430  1
    service_2_35_15  free_load_conservation_1431  12
    service_0_34_0  unique_nonzero_owner_296  1
    service_0_34_0  service_visit_def_694  1
    service_0_34_0  free_load_conservation_695  -2
    service_0_34_0  original_T_including_depot_unload_729  240
    service_0_34_1  unique_nonzero_owner_297  1
    service_0_34_1  service_visit_def_694  1
    service_0_34_1  free_load_conservation_695  -1
    service_0_34_1  original_T_including_depot_unload_729  120
    service_0_34_3  unique_nonzero_owner_298  1
    service_0_34_3  service_visit_def_694  1
    service_0_34_3  free_load_conservation_695  1
    service_0_34_4  unique_nonzero_owner_299  1
    service_0_34_4  service_visit_def_694  1
    service_0_34_4  free_load_conservation_695  2
    service_0_34_5  unique_nonzero_owner_300  1
    service_0_34_5  service_visit_def_694  1
    service_0_34_5  free_load_conservation_695  3
    service_0_34_6  unique_nonzero_owner_301  1
    service_0_34_6  service_visit_def_694  1
    service_0_34_6  free_load_conservation_695  4
    service_0_34_7  unique_nonzero_owner_302  1
    service_0_34_7  service_visit_def_694  1
    service_0_34_7  free_load_conservation_695  5
    service_0_34_8  unique_nonzero_owner_303  1
    service_0_34_8  service_visit_def_694  1
    service_0_34_8  free_load_conservation_695  6
    service_0_34_9  unique_nonzero_owner_304  1
    service_0_34_9  service_visit_def_694  1
    service_0_34_9  free_load_conservation_695  7
    service_0_34_10  unique_nonzero_owner_305  1
    service_0_34_10  service_visit_def_694  1
    service_0_34_10  free_load_conservation_695  8
    service_0_34_11  unique_nonzero_owner_306  1
    service_0_34_11  service_visit_def_694  1
    service_0_34_11  free_load_conservation_695  9
    service_0_34_12  unique_nonzero_owner_307  1
    service_0_34_12  service_visit_def_694  1
    service_0_34_12  free_load_conservation_695  10
    service_0_34_13  unique_nonzero_owner_308  1
    service_0_34_13  service_visit_def_694  1
    service_0_34_13  free_load_conservation_695  11
    service_0_34_14  unique_nonzero_owner_309  1
    service_0_34_14  service_visit_def_694  1
    service_0_34_14  free_load_conservation_695  12
    service_0_34_15  unique_nonzero_owner_310  1
    service_0_34_15  service_visit_def_694  1
    service_0_34_15  free_load_conservation_695  13
    service_1_34_0  unique_nonzero_owner_296  1
    service_1_34_0  service_visit_def_1065  1
    service_1_34_0  free_load_conservation_1066  -2
    service_1_34_0  original_T_including_depot_unload_1100  240
    service_1_34_1  unique_nonzero_owner_297  1
    service_1_34_1  service_visit_def_1065  1
    service_1_34_1  free_load_conservation_1066  -1
    service_1_34_1  original_T_including_depot_unload_1100  120
    service_1_34_3  unique_nonzero_owner_298  1
    service_1_34_3  service_visit_def_1065  1
    service_1_34_3  free_load_conservation_1066  1
    service_1_34_4  unique_nonzero_owner_299  1
    service_1_34_4  service_visit_def_1065  1
    service_1_34_4  free_load_conservation_1066  2
    service_1_34_5  unique_nonzero_owner_300  1
    service_1_34_5  service_visit_def_1065  1
    service_1_34_5  free_load_conservation_1066  3
    service_1_34_6  unique_nonzero_owner_301  1
    service_1_34_6  service_visit_def_1065  1
    service_1_34_6  free_load_conservation_1066  4
    service_1_34_7  unique_nonzero_owner_302  1
    service_1_34_7  service_visit_def_1065  1
    service_1_34_7  free_load_conservation_1066  5
    service_1_34_8  unique_nonzero_owner_303  1
    service_1_34_8  service_visit_def_1065  1
    service_1_34_8  free_load_conservation_1066  6
    service_1_34_9  unique_nonzero_owner_304  1
    service_1_34_9  service_visit_def_1065  1
    service_1_34_9  free_load_conservation_1066  7
    service_1_34_10  unique_nonzero_owner_305  1
    service_1_34_10  service_visit_def_1065  1
    service_1_34_10  free_load_conservation_1066  8
    service_1_34_11  unique_nonzero_owner_306  1
    service_1_34_11  service_visit_def_1065  1
    service_1_34_11  free_load_conservation_1066  9
    service_1_34_12  unique_nonzero_owner_307  1
    service_1_34_12  service_visit_def_1065  1
    service_1_34_12  free_load_conservation_1066  10
    service_1_34_13  unique_nonzero_owner_308  1
    service_1_34_13  service_visit_def_1065  1
    service_1_34_13  free_load_conservation_1066  11
    service_1_34_14  unique_nonzero_owner_309  1
    service_1_34_14  service_visit_def_1065  1
    service_1_34_14  free_load_conservation_1066  12
    service_1_34_15  unique_nonzero_owner_310  1
    service_1_34_15  service_visit_def_1065  1
    service_1_34_15  free_load_conservation_1066  13
    service_2_34_0  unique_nonzero_owner_296  1
    service_2_34_0  service_visit_def_1436  1
    service_2_34_0  free_load_conservation_1437  -2
    service_2_34_0  original_T_including_depot_unload_1471  240
    service_2_34_1  unique_nonzero_owner_297  1
    service_2_34_1  service_visit_def_1436  1
    service_2_34_1  free_load_conservation_1437  -1
    service_2_34_1  original_T_including_depot_unload_1471  120
    service_2_34_3  unique_nonzero_owner_298  1
    service_2_34_3  service_visit_def_1436  1
    service_2_34_3  free_load_conservation_1437  1
    service_2_34_4  unique_nonzero_owner_299  1
    service_2_34_4  service_visit_def_1436  1
    service_2_34_4  free_load_conservation_1437  2
    service_2_34_5  unique_nonzero_owner_300  1
    service_2_34_5  service_visit_def_1436  1
    service_2_34_5  free_load_conservation_1437  3
    service_2_34_6  unique_nonzero_owner_301  1
    service_2_34_6  service_visit_def_1436  1
    service_2_34_6  free_load_conservation_1437  4
    service_2_34_7  unique_nonzero_owner_302  1
    service_2_34_7  service_visit_def_1436  1
    service_2_34_7  free_load_conservation_1437  5
    service_2_34_8  unique_nonzero_owner_303  1
    service_2_34_8  service_visit_def_1436  1
    service_2_34_8  free_load_conservation_1437  6
    service_2_34_9  unique_nonzero_owner_304  1
    service_2_34_9  service_visit_def_1436  1
    service_2_34_9  free_load_conservation_1437  7
    service_2_34_10  unique_nonzero_owner_305  1
    service_2_34_10  service_visit_def_1436  1
    service_2_34_10  free_load_conservation_1437  8
    service_2_34_11  unique_nonzero_owner_306  1
    service_2_34_11  service_visit_def_1436  1
    service_2_34_11  free_load_conservation_1437  9
    service_2_34_12  unique_nonzero_owner_307  1
    service_2_34_12  service_visit_def_1436  1
    service_2_34_12  free_load_conservation_1437  10
    service_2_34_13  unique_nonzero_owner_308  1
    service_2_34_13  service_visit_def_1436  1
    service_2_34_13  free_load_conservation_1437  11
    service_2_34_14  unique_nonzero_owner_309  1
    service_2_34_14  service_visit_def_1436  1
    service_2_34_14  free_load_conservation_1437  12
    service_2_34_15  unique_nonzero_owner_310  1
    service_2_34_15  service_visit_def_1436  1
    service_2_34_15  free_load_conservation_1437  13
    service_0_24_0  unique_nonzero_owner_311  1
    service_0_24_0  service_visit_def_700  1
    service_0_24_0  free_load_conservation_701  -13
    service_0_24_0  original_T_including_depot_unload_729  1560
    service_0_24_1  unique_nonzero_owner_312  1
    service_0_24_1  service_visit_def_700  1
    service_0_24_1  free_load_conservation_701  -12
    service_0_24_1  original_T_including_depot_unload_729  1440
    service_0_24_2  unique_nonzero_owner_313  1
    service_0_24_2  service_visit_def_700  1
    service_0_24_2  free_load_conservation_701  -11
    service_0_24_2  original_T_including_depot_unload_729  1320
    service_0_24_3  unique_nonzero_owner_314  1
    service_0_24_3  service_visit_def_700  1
    service_0_24_3  free_load_conservation_701  -10
    service_0_24_3  original_T_including_depot_unload_729  1200
    service_0_24_4  unique_nonzero_owner_315  1
    service_0_24_4  service_visit_def_700  1
    service_0_24_4  free_load_conservation_701  -9
    service_0_24_4  original_T_including_depot_unload_729  1080
    service_0_24_5  unique_nonzero_owner_316  1
    service_0_24_5  service_visit_def_700  1
    service_0_24_5  free_load_conservation_701  -8
    service_0_24_5  original_T_including_depot_unload_729  960
    service_0_24_6  unique_nonzero_owner_317  1
    service_0_24_6  service_visit_def_700  1
    service_0_24_6  free_load_conservation_701  -7
    service_0_24_6  original_T_including_depot_unload_729  840
    service_0_24_7  unique_nonzero_owner_318  1
    service_0_24_7  service_visit_def_700  1
    service_0_24_7  free_load_conservation_701  -6
    service_0_24_7  original_T_including_depot_unload_729  720
    service_0_24_8  unique_nonzero_owner_319  1
    service_0_24_8  service_visit_def_700  1
    service_0_24_8  free_load_conservation_701  -5
    service_0_24_8  original_T_including_depot_unload_729  600
    service_0_24_9  unique_nonzero_owner_320  1
    service_0_24_9  service_visit_def_700  1
    service_0_24_9  free_load_conservation_701  -4
    service_0_24_9  original_T_including_depot_unload_729  480
    service_0_24_10  unique_nonzero_owner_321  1
    service_0_24_10  service_visit_def_700  1
    service_0_24_10  free_load_conservation_701  -3
    service_0_24_10  original_T_including_depot_unload_729  360
    service_0_24_11  unique_nonzero_owner_322  1
    service_0_24_11  service_visit_def_700  1
    service_0_24_11  free_load_conservation_701  -2
    service_0_24_11  original_T_including_depot_unload_729  240
    service_0_24_12  unique_nonzero_owner_323  1
    service_0_24_12  service_visit_def_700  1
    service_0_24_12  free_load_conservation_701  -1
    service_0_24_12  original_T_including_depot_unload_729  120
    service_0_24_14  unique_nonzero_owner_324  1
    service_0_24_14  service_visit_def_700  1
    service_0_24_14  free_load_conservation_701  1
    service_0_24_15  unique_nonzero_owner_325  1
    service_0_24_15  service_visit_def_700  1
    service_0_24_15  free_load_conservation_701  2
    service_1_24_0  unique_nonzero_owner_311  1
    service_1_24_0  service_visit_def_1071  1
    service_1_24_0  free_load_conservation_1072  -13
    service_1_24_0  original_T_including_depot_unload_1100  1560
    service_1_24_1  unique_nonzero_owner_312  1
    service_1_24_1  service_visit_def_1071  1
    service_1_24_1  free_load_conservation_1072  -12
    service_1_24_1  original_T_including_depot_unload_1100  1440
    service_1_24_2  unique_nonzero_owner_313  1
    service_1_24_2  service_visit_def_1071  1
    service_1_24_2  free_load_conservation_1072  -11
    service_1_24_2  original_T_including_depot_unload_1100  1320
    service_1_24_3  unique_nonzero_owner_314  1
    service_1_24_3  service_visit_def_1071  1
    service_1_24_3  free_load_conservation_1072  -10
    service_1_24_3  original_T_including_depot_unload_1100  1200
    service_1_24_4  unique_nonzero_owner_315  1
    service_1_24_4  service_visit_def_1071  1
    service_1_24_4  free_load_conservation_1072  -9
    service_1_24_4  original_T_including_depot_unload_1100  1080
    service_1_24_5  unique_nonzero_owner_316  1
    service_1_24_5  service_visit_def_1071  1
    service_1_24_5  free_load_conservation_1072  -8
    service_1_24_5  original_T_including_depot_unload_1100  960
    service_1_24_6  unique_nonzero_owner_317  1
    service_1_24_6  service_visit_def_1071  1
    service_1_24_6  free_load_conservation_1072  -7
    service_1_24_6  original_T_including_depot_unload_1100  840
    service_1_24_7  unique_nonzero_owner_318  1
    service_1_24_7  service_visit_def_1071  1
    service_1_24_7  free_load_conservation_1072  -6
    service_1_24_7  original_T_including_depot_unload_1100  720
    service_1_24_8  unique_nonzero_owner_319  1
    service_1_24_8  service_visit_def_1071  1
    service_1_24_8  free_load_conservation_1072  -5
    service_1_24_8  original_T_including_depot_unload_1100  600
    service_1_24_9  unique_nonzero_owner_320  1
    service_1_24_9  service_visit_def_1071  1
    service_1_24_9  free_load_conservation_1072  -4
    service_1_24_9  original_T_including_depot_unload_1100  480
    service_1_24_10  unique_nonzero_owner_321  1
    service_1_24_10  service_visit_def_1071  1
    service_1_24_10  free_load_conservation_1072  -3
    service_1_24_10  original_T_including_depot_unload_1100  360
    service_1_24_11  unique_nonzero_owner_322  1
    service_1_24_11  service_visit_def_1071  1
    service_1_24_11  free_load_conservation_1072  -2
    service_1_24_11  original_T_including_depot_unload_1100  240
    service_1_24_12  unique_nonzero_owner_323  1
    service_1_24_12  service_visit_def_1071  1
    service_1_24_12  free_load_conservation_1072  -1
    service_1_24_12  original_T_including_depot_unload_1100  120
    service_1_24_14  unique_nonzero_owner_324  1
    service_1_24_14  service_visit_def_1071  1
    service_1_24_14  free_load_conservation_1072  1
    service_1_24_15  unique_nonzero_owner_325  1
    service_1_24_15  service_visit_def_1071  1
    service_1_24_15  free_load_conservation_1072  2
    service_2_24_0  unique_nonzero_owner_311  1
    service_2_24_0  service_visit_def_1442  1
    service_2_24_0  free_load_conservation_1443  -13
    service_2_24_0  original_T_including_depot_unload_1471  1560
    service_2_24_1  unique_nonzero_owner_312  1
    service_2_24_1  service_visit_def_1442  1
    service_2_24_1  free_load_conservation_1443  -12
    service_2_24_1  original_T_including_depot_unload_1471  1440
    service_2_24_2  unique_nonzero_owner_313  1
    service_2_24_2  service_visit_def_1442  1
    service_2_24_2  free_load_conservation_1443  -11
    service_2_24_2  original_T_including_depot_unload_1471  1320
    service_2_24_3  unique_nonzero_owner_314  1
    service_2_24_3  service_visit_def_1442  1
    service_2_24_3  free_load_conservation_1443  -10
    service_2_24_3  original_T_including_depot_unload_1471  1200
    service_2_24_4  unique_nonzero_owner_315  1
    service_2_24_4  service_visit_def_1442  1
    service_2_24_4  free_load_conservation_1443  -9
    service_2_24_4  original_T_including_depot_unload_1471  1080
    service_2_24_5  unique_nonzero_owner_316  1
    service_2_24_5  service_visit_def_1442  1
    service_2_24_5  free_load_conservation_1443  -8
    service_2_24_5  original_T_including_depot_unload_1471  960
    service_2_24_6  unique_nonzero_owner_317  1
    service_2_24_6  service_visit_def_1442  1
    service_2_24_6  free_load_conservation_1443  -7
    service_2_24_6  original_T_including_depot_unload_1471  840
    service_2_24_7  unique_nonzero_owner_318  1
    service_2_24_7  service_visit_def_1442  1
    service_2_24_7  free_load_conservation_1443  -6
    service_2_24_7  original_T_including_depot_unload_1471  720
    service_2_24_8  unique_nonzero_owner_319  1
    service_2_24_8  service_visit_def_1442  1
    service_2_24_8  free_load_conservation_1443  -5
    service_2_24_8  original_T_including_depot_unload_1471  600
    service_2_24_9  unique_nonzero_owner_320  1
    service_2_24_9  service_visit_def_1442  1
    service_2_24_9  free_load_conservation_1443  -4
    service_2_24_9  original_T_including_depot_unload_1471  480
    service_2_24_10  unique_nonzero_owner_321  1
    service_2_24_10  service_visit_def_1442  1
    service_2_24_10  free_load_conservation_1443  -3
    service_2_24_10  original_T_including_depot_unload_1471  360
    service_2_24_11  unique_nonzero_owner_322  1
    service_2_24_11  service_visit_def_1442  1
    service_2_24_11  free_load_conservation_1443  -2
    service_2_24_11  original_T_including_depot_unload_1471  240
    service_2_24_12  unique_nonzero_owner_323  1
    service_2_24_12  service_visit_def_1442  1
    service_2_24_12  free_load_conservation_1443  -1
    service_2_24_12  original_T_including_depot_unload_1471  120
    service_2_24_14  unique_nonzero_owner_324  1
    service_2_24_14  service_visit_def_1442  1
    service_2_24_14  free_load_conservation_1443  1
    service_2_24_15  unique_nonzero_owner_325  1
    service_2_24_15  service_visit_def_1442  1
    service_2_24_15  free_load_conservation_1443  2
    service_0_29_0  unique_nonzero_owner_326  1
    service_0_29_0  service_visit_def_706  1
    service_0_29_0  free_load_conservation_707  -1
    service_0_29_0  original_T_including_depot_unload_729  120
    service_0_29_2  unique_nonzero_owner_327  1
    service_0_29_2  service_visit_def_706  1
    service_0_29_2  free_load_conservation_707  1
    service_0_29_3  unique_nonzero_owner_328  1
    service_0_29_3  service_visit_def_706  1
    service_0_29_3  free_load_conservation_707  2
    service_0_29_4  unique_nonzero_owner_329  1
    service_0_29_4  service_visit_def_706  1
    service_0_29_4  free_load_conservation_707  3
    service_0_29_5  unique_nonzero_owner_330  1
    service_0_29_5  service_visit_def_706  1
    service_0_29_5  free_load_conservation_707  4
    service_0_29_6  unique_nonzero_owner_331  1
    service_0_29_6  service_visit_def_706  1
    service_0_29_6  free_load_conservation_707  5
    service_0_29_7  unique_nonzero_owner_332  1
    service_0_29_7  service_visit_def_706  1
    service_0_29_7  free_load_conservation_707  6
    service_0_29_8  unique_nonzero_owner_333  1
    service_0_29_8  service_visit_def_706  1
    service_0_29_8  free_load_conservation_707  7
    service_0_29_9  unique_nonzero_owner_334  1
    service_0_29_9  service_visit_def_706  1
    service_0_29_9  free_load_conservation_707  8
    service_0_29_10  unique_nonzero_owner_335  1
    service_0_29_10  service_visit_def_706  1
    service_0_29_10  free_load_conservation_707  9
    service_1_29_0  unique_nonzero_owner_326  1
    service_1_29_0  service_visit_def_1077  1
    service_1_29_0  free_load_conservation_1078  -1
    service_1_29_0  original_T_including_depot_unload_1100  120
    service_1_29_2  unique_nonzero_owner_327  1
    service_1_29_2  service_visit_def_1077  1
    service_1_29_2  free_load_conservation_1078  1
    service_1_29_3  unique_nonzero_owner_328  1
    service_1_29_3  service_visit_def_1077  1
    service_1_29_3  free_load_conservation_1078  2
    service_1_29_4  unique_nonzero_owner_329  1
    service_1_29_4  service_visit_def_1077  1
    service_1_29_4  free_load_conservation_1078  3
    service_1_29_5  unique_nonzero_owner_330  1
    service_1_29_5  service_visit_def_1077  1
    service_1_29_5  free_load_conservation_1078  4
    service_1_29_6  unique_nonzero_owner_331  1
    service_1_29_6  service_visit_def_1077  1
    service_1_29_6  free_load_conservation_1078  5
    service_1_29_7  unique_nonzero_owner_332  1
    service_1_29_7  service_visit_def_1077  1
    service_1_29_7  free_load_conservation_1078  6
    service_1_29_8  unique_nonzero_owner_333  1
    service_1_29_8  service_visit_def_1077  1
    service_1_29_8  free_load_conservation_1078  7
    service_1_29_9  unique_nonzero_owner_334  1
    service_1_29_9  service_visit_def_1077  1
    service_1_29_9  free_load_conservation_1078  8
    service_1_29_10  unique_nonzero_owner_335  1
    service_1_29_10  service_visit_def_1077  1
    service_1_29_10  free_load_conservation_1078  9
    service_2_29_0  unique_nonzero_owner_326  1
    service_2_29_0  service_visit_def_1448  1
    service_2_29_0  free_load_conservation_1449  -1
    service_2_29_0  original_T_including_depot_unload_1471  120
    service_2_29_2  unique_nonzero_owner_327  1
    service_2_29_2  service_visit_def_1448  1
    service_2_29_2  free_load_conservation_1449  1
    service_2_29_3  unique_nonzero_owner_328  1
    service_2_29_3  service_visit_def_1448  1
    service_2_29_3  free_load_conservation_1449  2
    service_2_29_4  unique_nonzero_owner_329  1
    service_2_29_4  service_visit_def_1448  1
    service_2_29_4  free_load_conservation_1449  3
    service_2_29_5  unique_nonzero_owner_330  1
    service_2_29_5  service_visit_def_1448  1
    service_2_29_5  free_load_conservation_1449  4
    service_2_29_6  unique_nonzero_owner_331  1
    service_2_29_6  service_visit_def_1448  1
    service_2_29_6  free_load_conservation_1449  5
    service_2_29_7  unique_nonzero_owner_332  1
    service_2_29_7  service_visit_def_1448  1
    service_2_29_7  free_load_conservation_1449  6
    service_2_29_8  unique_nonzero_owner_333  1
    service_2_29_8  service_visit_def_1448  1
    service_2_29_8  free_load_conservation_1449  7
    service_2_29_9  unique_nonzero_owner_334  1
    service_2_29_9  service_visit_def_1448  1
    service_2_29_9  free_load_conservation_1449  8
    service_2_29_10  unique_nonzero_owner_335  1
    service_2_29_10  service_visit_def_1448  1
    service_2_29_10  free_load_conservation_1449  9
    service_0_28_0  unique_nonzero_owner_336  1
    service_0_28_0  service_visit_def_712  1
    service_0_28_0  free_load_conservation_713  -1
    service_0_28_0  original_T_including_depot_unload_729  120
    service_0_28_2  unique_nonzero_owner_337  1
    service_0_28_2  service_visit_def_712  1
    service_0_28_2  free_load_conservation_713  1
    service_0_28_3  unique_nonzero_owner_338  1
    service_0_28_3  service_visit_def_712  1
    service_0_28_3  free_load_conservation_713  2
    service_0_28_4  unique_nonzero_owner_339  1
    service_0_28_4  service_visit_def_712  1
    service_0_28_4  free_load_conservation_713  3
    service_0_28_5  unique_nonzero_owner_340  1
    service_0_28_5  service_visit_def_712  1
    service_0_28_5  free_load_conservation_713  4
    service_0_28_6  unique_nonzero_owner_341  1
    service_0_28_6  service_visit_def_712  1
    service_0_28_6  free_load_conservation_713  5
    service_1_28_0  unique_nonzero_owner_336  1
    service_1_28_0  service_visit_def_1083  1
    service_1_28_0  free_load_conservation_1084  -1
    service_1_28_0  original_T_including_depot_unload_1100  120
    service_1_28_2  unique_nonzero_owner_337  1
    service_1_28_2  service_visit_def_1083  1
    service_1_28_2  free_load_conservation_1084  1
    service_1_28_3  unique_nonzero_owner_338  1
    service_1_28_3  service_visit_def_1083  1
    service_1_28_3  free_load_conservation_1084  2
    service_1_28_4  unique_nonzero_owner_339  1
    service_1_28_4  service_visit_def_1083  1
    service_1_28_4  free_load_conservation_1084  3
    service_1_28_5  unique_nonzero_owner_340  1
    service_1_28_5  service_visit_def_1083  1
    service_1_28_5  free_load_conservation_1084  4
    service_1_28_6  unique_nonzero_owner_341  1
    service_1_28_6  service_visit_def_1083  1
    service_1_28_6  free_load_conservation_1084  5
    service_2_28_0  unique_nonzero_owner_336  1
    service_2_28_0  service_visit_def_1454  1
    service_2_28_0  free_load_conservation_1455  -1
    service_2_28_0  original_T_including_depot_unload_1471  120
    service_2_28_2  unique_nonzero_owner_337  1
    service_2_28_2  service_visit_def_1454  1
    service_2_28_2  free_load_conservation_1455  1
    service_2_28_3  unique_nonzero_owner_338  1
    service_2_28_3  service_visit_def_1454  1
    service_2_28_3  free_load_conservation_1455  2
    service_2_28_4  unique_nonzero_owner_339  1
    service_2_28_4  service_visit_def_1454  1
    service_2_28_4  free_load_conservation_1455  3
    service_2_28_5  unique_nonzero_owner_340  1
    service_2_28_5  service_visit_def_1454  1
    service_2_28_5  free_load_conservation_1455  4
    service_2_28_6  unique_nonzero_owner_341  1
    service_2_28_6  service_visit_def_1454  1
    service_2_28_6  free_load_conservation_1455  5
    service_0_27_1  unique_nonzero_owner_342  1
    service_0_27_1  service_visit_def_718  1
    service_0_27_1  free_load_conservation_719  1
    service_0_27_2  unique_nonzero_owner_343  1
    service_0_27_2  service_visit_def_718  1
    service_0_27_2  free_load_conservation_719  2
    service_0_27_3  unique_nonzero_owner_344  1
    service_0_27_3  service_visit_def_718  1
    service_0_27_3  free_load_conservation_719  3
    service_0_27_4  unique_nonzero_owner_345  1
    service_0_27_4  service_visit_def_718  1
    service_0_27_4  free_load_conservation_719  4
    service_0_27_5  unique_nonzero_owner_346  1
    service_0_27_5  service_visit_def_718  1
    service_0_27_5  free_load_conservation_719  5
    service_0_27_6  unique_nonzero_owner_347  1
    service_0_27_6  service_visit_def_718  1
    service_0_27_6  free_load_conservation_719  6
    service_1_27_1  unique_nonzero_owner_342  1
    service_1_27_1  service_visit_def_1089  1
    service_1_27_1  free_load_conservation_1090  1
    service_1_27_2  unique_nonzero_owner_343  1
    service_1_27_2  service_visit_def_1089  1
    service_1_27_2  free_load_conservation_1090  2
    service_1_27_3  unique_nonzero_owner_344  1
    service_1_27_3  service_visit_def_1089  1
    service_1_27_3  free_load_conservation_1090  3
    service_1_27_4  unique_nonzero_owner_345  1
    service_1_27_4  service_visit_def_1089  1
    service_1_27_4  free_load_conservation_1090  4
    service_1_27_5  unique_nonzero_owner_346  1
    service_1_27_5  service_visit_def_1089  1
    service_1_27_5  free_load_conservation_1090  5
    service_1_27_6  unique_nonzero_owner_347  1
    service_1_27_6  service_visit_def_1089  1
    service_1_27_6  free_load_conservation_1090  6
    service_2_27_1  unique_nonzero_owner_342  1
    service_2_27_1  service_visit_def_1460  1
    service_2_27_1  free_load_conservation_1461  1
    service_2_27_2  unique_nonzero_owner_343  1
    service_2_27_2  service_visit_def_1460  1
    service_2_27_2  free_load_conservation_1461  2
    service_2_27_3  unique_nonzero_owner_344  1
    service_2_27_3  service_visit_def_1460  1
    service_2_27_3  free_load_conservation_1461  3
    service_2_27_4  unique_nonzero_owner_345  1
    service_2_27_4  service_visit_def_1460  1
    service_2_27_4  free_load_conservation_1461  4
    service_2_27_5  unique_nonzero_owner_346  1
    service_2_27_5  service_visit_def_1460  1
    service_2_27_5  free_load_conservation_1461  5
    service_2_27_6  unique_nonzero_owner_347  1
    service_2_27_6  service_visit_def_1460  1
    service_2_27_6  free_load_conservation_1461  6
    service_0_33_0  unique_nonzero_owner_348  1
    service_0_33_0  service_visit_def_724  1
    service_0_33_0  free_load_conservation_725  -8
    service_0_33_0  original_T_including_depot_unload_729  960
    service_0_33_1  unique_nonzero_owner_349  1
    service_0_33_1  service_visit_def_724  1
    service_0_33_1  free_load_conservation_725  -7
    service_0_33_1  original_T_including_depot_unload_729  840
    service_0_33_2  unique_nonzero_owner_350  1
    service_0_33_2  service_visit_def_724  1
    service_0_33_2  free_load_conservation_725  -6
    service_0_33_2  original_T_including_depot_unload_729  720
    service_0_33_3  unique_nonzero_owner_351  1
    service_0_33_3  service_visit_def_724  1
    service_0_33_3  free_load_conservation_725  -5
    service_0_33_3  original_T_including_depot_unload_729  600
    service_0_33_4  unique_nonzero_owner_352  1
    service_0_33_4  service_visit_def_724  1
    service_0_33_4  free_load_conservation_725  -4
    service_0_33_4  original_T_including_depot_unload_729  480
    service_0_33_5  unique_nonzero_owner_353  1
    service_0_33_5  service_visit_def_724  1
    service_0_33_5  free_load_conservation_725  -3
    service_0_33_5  original_T_including_depot_unload_729  360
    service_0_33_6  unique_nonzero_owner_354  1
    service_0_33_6  service_visit_def_724  1
    service_0_33_6  free_load_conservation_725  -2
    service_0_33_6  original_T_including_depot_unload_729  240
    service_0_33_7  unique_nonzero_owner_355  1
    service_0_33_7  service_visit_def_724  1
    service_0_33_7  free_load_conservation_725  -1
    service_0_33_7  original_T_including_depot_unload_729  120
    service_0_33_9  unique_nonzero_owner_356  1
    service_0_33_9  service_visit_def_724  1
    service_0_33_9  free_load_conservation_725  1
    service_0_33_10  unique_nonzero_owner_357  1
    service_0_33_10  service_visit_def_724  1
    service_0_33_10  free_load_conservation_725  2
    service_0_33_11  unique_nonzero_owner_358  1
    service_0_33_11  service_visit_def_724  1
    service_0_33_11  free_load_conservation_725  3
    service_1_33_0  unique_nonzero_owner_348  1
    service_1_33_0  service_visit_def_1095  1
    service_1_33_0  free_load_conservation_1096  -8
    service_1_33_0  original_T_including_depot_unload_1100  960
    service_1_33_1  unique_nonzero_owner_349  1
    service_1_33_1  service_visit_def_1095  1
    service_1_33_1  free_load_conservation_1096  -7
    service_1_33_1  original_T_including_depot_unload_1100  840
    service_1_33_2  unique_nonzero_owner_350  1
    service_1_33_2  service_visit_def_1095  1
    service_1_33_2  free_load_conservation_1096  -6
    service_1_33_2  original_T_including_depot_unload_1100  720
    service_1_33_3  unique_nonzero_owner_351  1
    service_1_33_3  service_visit_def_1095  1
    service_1_33_3  free_load_conservation_1096  -5
    service_1_33_3  original_T_including_depot_unload_1100  600
    service_1_33_4  unique_nonzero_owner_352  1
    service_1_33_4  service_visit_def_1095  1
    service_1_33_4  free_load_conservation_1096  -4
    service_1_33_4  original_T_including_depot_unload_1100  480
    service_1_33_5  unique_nonzero_owner_353  1
    service_1_33_5  service_visit_def_1095  1
    service_1_33_5  free_load_conservation_1096  -3
    service_1_33_5  original_T_including_depot_unload_1100  360
    service_1_33_6  unique_nonzero_owner_354  1
    service_1_33_6  service_visit_def_1095  1
    service_1_33_6  free_load_conservation_1096  -2
    service_1_33_6  original_T_including_depot_unload_1100  240
    service_1_33_7  unique_nonzero_owner_355  1
    service_1_33_7  service_visit_def_1095  1
    service_1_33_7  free_load_conservation_1096  -1
    service_1_33_7  original_T_including_depot_unload_1100  120
    service_1_33_9  unique_nonzero_owner_356  1
    service_1_33_9  service_visit_def_1095  1
    service_1_33_9  free_load_conservation_1096  1
    service_1_33_10  unique_nonzero_owner_357  1
    service_1_33_10  service_visit_def_1095  1
    service_1_33_10  free_load_conservation_1096  2
    service_1_33_11  unique_nonzero_owner_358  1
    service_1_33_11  service_visit_def_1095  1
    service_1_33_11  free_load_conservation_1096  3
    service_2_33_0  unique_nonzero_owner_348  1
    service_2_33_0  service_visit_def_1466  1
    service_2_33_0  free_load_conservation_1467  -8
    service_2_33_0  original_T_including_depot_unload_1471  960
    service_2_33_1  unique_nonzero_owner_349  1
    service_2_33_1  service_visit_def_1466  1
    service_2_33_1  free_load_conservation_1467  -7
    service_2_33_1  original_T_including_depot_unload_1471  840
    service_2_33_2  unique_nonzero_owner_350  1
    service_2_33_2  service_visit_def_1466  1
    service_2_33_2  free_load_conservation_1467  -6
    service_2_33_2  original_T_including_depot_unload_1471  720
    service_2_33_3  unique_nonzero_owner_351  1
    service_2_33_3  service_visit_def_1466  1
    service_2_33_3  free_load_conservation_1467  -5
    service_2_33_3  original_T_including_depot_unload_1471  600
    service_2_33_4  unique_nonzero_owner_352  1
    service_2_33_4  service_visit_def_1466  1
    service_2_33_4  free_load_conservation_1467  -4
    service_2_33_4  original_T_including_depot_unload_1471  480
    service_2_33_5  unique_nonzero_owner_353  1
    service_2_33_5  service_visit_def_1466  1
    service_2_33_5  free_load_conservation_1467  -3
    service_2_33_5  original_T_including_depot_unload_1471  360
    service_2_33_6  unique_nonzero_owner_354  1
    service_2_33_6  service_visit_def_1466  1
    service_2_33_6  free_load_conservation_1467  -2
    service_2_33_6  original_T_including_depot_unload_1471  240
    service_2_33_7  unique_nonzero_owner_355  1
    service_2_33_7  service_visit_def_1466  1
    service_2_33_7  free_load_conservation_1467  -1
    service_2_33_7  original_T_including_depot_unload_1471  120
    service_2_33_9  unique_nonzero_owner_356  1
    service_2_33_9  service_visit_def_1466  1
    service_2_33_9  free_load_conservation_1467  1
    service_2_33_10  unique_nonzero_owner_357  1
    service_2_33_10  service_visit_def_1466  1
    service_2_33_10  free_load_conservation_1467  2
    service_2_33_11  unique_nonzero_owner_358  1
    service_2_33_11  service_visit_def_1466  1
    service_2_33_11  free_load_conservation_1467  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_650  -1
    visit_0_1  in_degree_651  -1
    visit_0_1  order_active_lb_652  -1
    visit_0_1  order_active_ub_653  -12
    order_0_1  connected_order_arc_374  -1
    order_0_1  connected_order_arc_376  -1
    order_0_1  connected_order_arc_378  -1
    order_0_1  connected_order_arc_380  -1
    order_0_1  connected_order_arc_382  -1
    order_0_1  connected_order_arc_384  -1
    order_0_1  connected_order_arc_386  -1
    order_0_1  connected_order_arc_388  -1
    order_0_1  connected_order_arc_390  -1
    order_0_1  connected_order_arc_392  -1
    order_0_1  connected_order_arc_394  -1
    order_0_1  connected_order_arc_397  1
    order_0_1  connected_order_arc_420  1
    order_0_1  connected_order_arc_443  1
    order_0_1  connected_order_arc_466  1
    order_0_1  connected_order_arc_489  1
    order_0_1  connected_order_arc_512  1
    order_0_1  connected_order_arc_535  1
    order_0_1  connected_order_arc_558  1
    order_0_1  connected_order_arc_581  1
    order_0_1  connected_order_arc_604  1
    order_0_1  connected_order_arc_627  1
    order_0_1  order_active_lb_652  1
    order_0_1  order_active_ub_653  1
    order_0_1  fixed_segment_relative_order_726  -1
    visit_0_2  out_degree_657  -1
    visit_0_2  in_degree_658  -1
    visit_0_2  order_active_lb_659  -1
    visit_0_2  order_active_ub_660  -12
    order_0_2  connected_order_arc_374  1
    order_0_2  connected_order_arc_397  -1
    order_0_2  connected_order_arc_399  -1
    order_0_2  connected_order_arc_401  -1
    order_0_2  connected_order_arc_403  -1
    order_0_2  connected_order_arc_405  -1
    order_0_2  connected_order_arc_407  -1
    order_0_2  connected_order_arc_409  -1
    order_0_2  connected_order_arc_411  -1
    order_0_2  connected_order_arc_413  -1
    order_0_2  connected_order_arc_415  -1
    order_0_2  connected_order_arc_417  -1
    order_0_2  connected_order_arc_422  1
    order_0_2  connected_order_arc_445  1
    order_0_2  connected_order_arc_468  1
    order_0_2  connected_order_arc_491  1
    order_0_2  connected_order_arc_514  1
    order_0_2  connected_order_arc_537  1
    order_0_2  connected_order_arc_560  1
    order_0_2  connected_order_arc_583  1
    order_0_2  connected_order_arc_606  1
    order_0_2  connected_order_arc_629  1
    order_0_2  order_active_lb_659  1
    order_0_2  order_active_ub_660  1
    order_0_2  fixed_segment_relative_order_726  1
    order_0_2  fixed_segment_relative_order_727  -1
    visit_0_3  out_degree_664  -1
    visit_0_3  in_degree_665  -1
    visit_0_3  order_active_lb_666  -1
    visit_0_3  order_active_ub_667  -12
    order_0_3  connected_order_arc_376  1
    order_0_3  connected_order_arc_399  1
    order_0_3  connected_order_arc_420  -1
    order_0_3  connected_order_arc_422  -1
    order_0_3  connected_order_arc_424  -1
    order_0_3  connected_order_arc_426  -1
    order_0_3  connected_order_arc_428  -1
    order_0_3  connected_order_arc_430  -1
    order_0_3  connected_order_arc_432  -1
    order_0_3  connected_order_arc_434  -1
    order_0_3  connected_order_arc_436  -1
    order_0_3  connected_order_arc_438  -1
    order_0_3  connected_order_arc_440  -1
    order_0_3  connected_order_arc_447  1
    order_0_3  connected_order_arc_470  1
    order_0_3  connected_order_arc_493  1
    order_0_3  connected_order_arc_516  1
    order_0_3  connected_order_arc_539  1
    order_0_3  connected_order_arc_562  1
    order_0_3  connected_order_arc_585  1
    order_0_3  connected_order_arc_608  1
    order_0_3  connected_order_arc_631  1
    order_0_3  order_active_lb_666  1
    order_0_3  order_active_ub_667  1
    order_0_3  fixed_segment_relative_order_727  1
    order_0_3  fixed_segment_relative_order_728  -1
    visit_0_4  out_degree_671  -1
    visit_0_4  in_degree_672  -1
    visit_0_4  order_active_lb_673  -1
    visit_0_4  order_active_ub_674  -12
    order_0_4  connected_order_arc_378  1
    order_0_4  connected_order_arc_401  1
    order_0_4  connected_order_arc_424  1
    order_0_4  connected_order_arc_443  -1
    order_0_4  connected_order_arc_445  -1
    order_0_4  connected_order_arc_447  -1
    order_0_4  connected_order_arc_449  -1
    order_0_4  connected_order_arc_451  -1
    order_0_4  connected_order_arc_453  -1
    order_0_4  connected_order_arc_455  -1
    order_0_4  connected_order_arc_457  -1
    order_0_4  connected_order_arc_459  -1
    order_0_4  connected_order_arc_461  -1
    order_0_4  connected_order_arc_463  -1
    order_0_4  connected_order_arc_472  1
    order_0_4  connected_order_arc_495  1
    order_0_4  connected_order_arc_518  1
    order_0_4  connected_order_arc_541  1
    order_0_4  connected_order_arc_564  1
    order_0_4  connected_order_arc_587  1
    order_0_4  connected_order_arc_610  1
    order_0_4  connected_order_arc_633  1
    order_0_4  order_active_lb_673  1
    order_0_4  order_active_ub_674  1
    order_0_4  fixed_segment_relative_order_728  1
    visit_0_13  out_degree_678  -1
    visit_0_13  in_degree_679  -1
    visit_0_13  order_active_lb_680  -1
    visit_0_13  order_active_ub_681  -12
    visit_0_13  service_visit_def_682  -1
    order_0_13  connected_order_arc_380  1
    order_0_13  connected_order_arc_403  1
    order_0_13  connected_order_arc_426  1
    order_0_13  connected_order_arc_449  1
    order_0_13  connected_order_arc_466  -1
    order_0_13  connected_order_arc_468  -1
    order_0_13  connected_order_arc_470  -1
    order_0_13  connected_order_arc_472  -1
    order_0_13  connected_order_arc_474  -1
    order_0_13  connected_order_arc_476  -1
    order_0_13  connected_order_arc_478  -1
    order_0_13  connected_order_arc_480  -1
    order_0_13  connected_order_arc_482  -1
    order_0_13  connected_order_arc_484  -1
    order_0_13  connected_order_arc_486  -1
    order_0_13  connected_order_arc_497  1
    order_0_13  connected_order_arc_520  1
    order_0_13  connected_order_arc_543  1
    order_0_13  connected_order_arc_566  1
    order_0_13  connected_order_arc_589  1
    order_0_13  connected_order_arc_612  1
    order_0_13  connected_order_arc_635  1
    order_0_13  order_active_lb_680  1
    order_0_13  order_active_ub_681  1
    visit_0_14  out_degree_684  -1
    visit_0_14  in_degree_685  -1
    visit_0_14  order_active_lb_686  -1
    visit_0_14  order_active_ub_687  -12
    visit_0_14  service_visit_def_688  -1
    order_0_14  connected_order_arc_382  1
    order_0_14  connected_order_arc_405  1
    order_0_14  connected_order_arc_428  1
    order_0_14  connected_order_arc_451  1
    order_0_14  connected_order_arc_474  1
    order_0_14  connected_order_arc_489  -1
    order_0_14  connected_order_arc_491  -1
    order_0_14  connected_order_arc_493  -1
    order_0_14  connected_order_arc_495  -1
    order_0_14  connected_order_arc_497  -1
    order_0_14  connected_order_arc_499  -1
    order_0_14  connected_order_arc_501  -1
    order_0_14  connected_order_arc_503  -1
    order_0_14  connected_order_arc_505  -1
    order_0_14  connected_order_arc_507  -1
    order_0_14  connected_order_arc_509  -1
    order_0_14  connected_order_arc_522  1
    order_0_14  connected_order_arc_545  1
    order_0_14  connected_order_arc_568  1
    order_0_14  connected_order_arc_591  1
    order_0_14  connected_order_arc_614  1
    order_0_14  connected_order_arc_637  1
    order_0_14  order_active_lb_686  1
    order_0_14  order_active_ub_687  1
    visit_0_15  out_degree_690  -1
    visit_0_15  in_degree_691  -1
    visit_0_15  order_active_lb_692  -1
    visit_0_15  order_active_ub_693  -12
    visit_0_15  service_visit_def_694  -1
    order_0_15  connected_order_arc_384  1
    order_0_15  connected_order_arc_407  1
    order_0_15  connected_order_arc_430  1
    order_0_15  connected_order_arc_453  1
    order_0_15  connected_order_arc_476  1
    order_0_15  connected_order_arc_499  1
    order_0_15  connected_order_arc_512  -1
    order_0_15  connected_order_arc_514  -1
    order_0_15  connected_order_arc_516  -1
    order_0_15  connected_order_arc_518  -1
    order_0_15  connected_order_arc_520  -1
    order_0_15  connected_order_arc_522  -1
    order_0_15  connected_order_arc_524  -1
    order_0_15  connected_order_arc_526  -1
    order_0_15  connected_order_arc_528  -1
    order_0_15  connected_order_arc_530  -1
    order_0_15  connected_order_arc_532  -1
    order_0_15  connected_order_arc_547  1
    order_0_15  connected_order_arc_570  1
    order_0_15  connected_order_arc_593  1
    order_0_15  connected_order_arc_616  1
    order_0_15  connected_order_arc_639  1
    order_0_15  order_active_lb_692  1
    order_0_15  order_active_ub_693  1
    visit_0_16  out_degree_696  -1
    visit_0_16  in_degree_697  -1
    visit_0_16  order_active_lb_698  -1
    visit_0_16  order_active_ub_699  -12
    visit_0_16  service_visit_def_700  -1
    order_0_16  connected_order_arc_386  1
    order_0_16  connected_order_arc_409  1
    order_0_16  connected_order_arc_432  1
    order_0_16  connected_order_arc_455  1
    order_0_16  connected_order_arc_478  1
    order_0_16  connected_order_arc_501  1
    order_0_16  connected_order_arc_524  1
    order_0_16  connected_order_arc_535  -1
    order_0_16  connected_order_arc_537  -1
    order_0_16  connected_order_arc_539  -1
    order_0_16  connected_order_arc_541  -1
    order_0_16  connected_order_arc_543  -1
    order_0_16  connected_order_arc_545  -1
    order_0_16  connected_order_arc_547  -1
    order_0_16  connected_order_arc_549  -1
    order_0_16  connected_order_arc_551  -1
    order_0_16  connected_order_arc_553  -1
    order_0_16  connected_order_arc_555  -1
    order_0_16  connected_order_arc_572  1
    order_0_16  connected_order_arc_595  1
    order_0_16  connected_order_arc_618  1
    order_0_16  connected_order_arc_641  1
    order_0_16  order_active_lb_698  1
    order_0_16  order_active_ub_699  1
    visit_0_17  out_degree_702  -1
    visit_0_17  in_degree_703  -1
    visit_0_17  order_active_lb_704  -1
    visit_0_17  order_active_ub_705  -12
    visit_0_17  service_visit_def_706  -1
    order_0_17  connected_order_arc_388  1
    order_0_17  connected_order_arc_411  1
    order_0_17  connected_order_arc_434  1
    order_0_17  connected_order_arc_457  1
    order_0_17  connected_order_arc_480  1
    order_0_17  connected_order_arc_503  1
    order_0_17  connected_order_arc_526  1
    order_0_17  connected_order_arc_549  1
    order_0_17  connected_order_arc_558  -1
    order_0_17  connected_order_arc_560  -1
    order_0_17  connected_order_arc_562  -1
    order_0_17  connected_order_arc_564  -1
    order_0_17  connected_order_arc_566  -1
    order_0_17  connected_order_arc_568  -1
    order_0_17  connected_order_arc_570  -1
    order_0_17  connected_order_arc_572  -1
    order_0_17  connected_order_arc_574  -1
    order_0_17  connected_order_arc_576  -1
    order_0_17  connected_order_arc_578  -1
    order_0_17  connected_order_arc_597  1
    order_0_17  connected_order_arc_620  1
    order_0_17  connected_order_arc_643  1
    order_0_17  order_active_lb_704  1
    order_0_17  order_active_ub_705  1
    visit_0_18  out_degree_708  -1
    visit_0_18  in_degree_709  -1
    visit_0_18  order_active_lb_710  -1
    visit_0_18  order_active_ub_711  -12
    visit_0_18  service_visit_def_712  -1
    order_0_18  connected_order_arc_390  1
    order_0_18  connected_order_arc_413  1
    order_0_18  connected_order_arc_436  1
    order_0_18  connected_order_arc_459  1
    order_0_18  connected_order_arc_482  1
    order_0_18  connected_order_arc_505  1
    order_0_18  connected_order_arc_528  1
    order_0_18  connected_order_arc_551  1
    order_0_18  connected_order_arc_574  1
    order_0_18  connected_order_arc_581  -1
    order_0_18  connected_order_arc_583  -1
    order_0_18  connected_order_arc_585  -1
    order_0_18  connected_order_arc_587  -1
    order_0_18  connected_order_arc_589  -1
    order_0_18  connected_order_arc_591  -1
    order_0_18  connected_order_arc_593  -1
    order_0_18  connected_order_arc_595  -1
    order_0_18  connected_order_arc_597  -1
    order_0_18  connected_order_arc_599  -1
    order_0_18  connected_order_arc_601  -1
    order_0_18  connected_order_arc_622  1
    order_0_18  connected_order_arc_645  1
    order_0_18  order_active_lb_710  1
    order_0_18  order_active_ub_711  1
    visit_0_19  out_degree_714  -1
    visit_0_19  in_degree_715  -1
    visit_0_19  order_active_lb_716  -1
    visit_0_19  order_active_ub_717  -12
    visit_0_19  service_visit_def_718  -1
    order_0_19  connected_order_arc_392  1
    order_0_19  connected_order_arc_415  1
    order_0_19  connected_order_arc_438  1
    order_0_19  connected_order_arc_461  1
    order_0_19  connected_order_arc_484  1
    order_0_19  connected_order_arc_507  1
    order_0_19  connected_order_arc_530  1
    order_0_19  connected_order_arc_553  1
    order_0_19  connected_order_arc_576  1
    order_0_19  connected_order_arc_599  1
    order_0_19  connected_order_arc_604  -1
    order_0_19  connected_order_arc_606  -1
    order_0_19  connected_order_arc_608  -1
    order_0_19  connected_order_arc_610  -1
    order_0_19  connected_order_arc_612  -1
    order_0_19  connected_order_arc_614  -1
    order_0_19  connected_order_arc_616  -1
    order_0_19  connected_order_arc_618  -1
    order_0_19  connected_order_arc_620  -1
    order_0_19  connected_order_arc_622  -1
    order_0_19  connected_order_arc_624  -1
    order_0_19  connected_order_arc_647  1
    order_0_19  order_active_lb_716  1
    order_0_19  order_active_ub_717  1
    visit_0_20  out_degree_720  -1
    visit_0_20  in_degree_721  -1
    visit_0_20  order_active_lb_722  -1
    visit_0_20  order_active_ub_723  -12
    visit_0_20  service_visit_def_724  -1
    order_0_20  connected_order_arc_394  1
    order_0_20  connected_order_arc_417  1
    order_0_20  connected_order_arc_440  1
    order_0_20  connected_order_arc_463  1
    order_0_20  connected_order_arc_486  1
    order_0_20  connected_order_arc_509  1
    order_0_20  connected_order_arc_532  1
    order_0_20  connected_order_arc_555  1
    order_0_20  connected_order_arc_578  1
    order_0_20  connected_order_arc_601  1
    order_0_20  connected_order_arc_624  1
    order_0_20  connected_order_arc_627  -1
    order_0_20  connected_order_arc_629  -1
    order_0_20  connected_order_arc_631  -1
    order_0_20  connected_order_arc_633  -1
    order_0_20  connected_order_arc_635  -1
    order_0_20  connected_order_arc_637  -1
    order_0_20  connected_order_arc_639  -1
    order_0_20  connected_order_arc_641  -1
    order_0_20  connected_order_arc_643  -1
    order_0_20  connected_order_arc_645  -1
    order_0_20  connected_order_arc_647  -1
    order_0_20  order_active_lb_722  1
    order_0_20  order_active_ub_723  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_359  -20
    arc_0_0_0  depot_departure_or_bypass_648  1
    arc_0_0_0  depot_return_or_bypass_649  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_359  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_360  -20
    arc_0_0_1  depot_departure_or_bypass_648  1
    arc_0_0_1  in_degree_651  1
    arc_0_0_1  original_T_including_depot_unload_729  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_360  1
    load_0_0_1  segment_load_conservation_654  -1
    load_0_0_1  segment_prefix_lb_655  1
    load_0_0_1  segment_prefix_ub_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_361  -20
    arc_0_0_2  depot_departure_or_bypass_648  1
    arc_0_0_2  in_degree_658  1
    arc_0_0_2  original_T_including_depot_unload_729  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_361  1
    load_0_0_2  segment_load_conservation_661  -1
    load_0_0_2  segment_prefix_lb_662  1
    load_0_0_2  segment_prefix_ub_663  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_362  -20
    arc_0_0_3  depot_departure_or_bypass_648  1
    arc_0_0_3  in_degree_665  1
    arc_0_0_3  original_T_including_depot_unload_729  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_362  1
    load_0_0_3  segment_load_conservation_668  -1
    load_0_0_3  segment_prefix_lb_669  1
    load_0_0_3  segment_prefix_ub_670  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_363  -20
    arc_0_0_4  depot_departure_or_bypass_648  1
    arc_0_0_4  in_degree_672  1
    arc_0_0_4  original_T_including_depot_unload_729  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_363  1
    load_0_0_4  segment_load_conservation_675  -1
    load_0_0_4  segment_prefix_lb_676  1
    load_0_0_4  segment_prefix_ub_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_364  -20
    arc_0_0_13  depot_departure_or_bypass_648  1
    arc_0_0_13  in_degree_679  1
    arc_0_0_13  original_T_including_depot_unload_729  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_364  1
    load_0_0_13  free_load_conservation_683  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_365  -20
    arc_0_0_14  depot_departure_or_bypass_648  1
    arc_0_0_14  in_degree_685  1
    arc_0_0_14  original_T_including_depot_unload_729  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_365  1
    load_0_0_14  free_load_conservation_689  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_366  -20
    arc_0_0_15  depot_departure_or_bypass_648  1
    arc_0_0_15  in_degree_691  1
    arc_0_0_15  original_T_including_depot_unload_729  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_366  1
    load_0_0_15  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_367  -20
    arc_0_0_16  depot_departure_or_bypass_648  1
    arc_0_0_16  in_degree_697  1
    arc_0_0_16  original_T_including_depot_unload_729  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_367  1
    load_0_0_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_368  -20
    arc_0_0_17  depot_departure_or_bypass_648  1
    arc_0_0_17  in_degree_703  1
    arc_0_0_17  original_T_including_depot_unload_729  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_368  1
    load_0_0_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_369  -20
    arc_0_0_18  depot_departure_or_bypass_648  1
    arc_0_0_18  in_degree_709  1
    arc_0_0_18  original_T_including_depot_unload_729  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_369  1
    load_0_0_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_370  -20
    arc_0_0_19  depot_departure_or_bypass_648  1
    arc_0_0_19  in_degree_715  1
    arc_0_0_19  original_T_including_depot_unload_729  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_370  1
    load_0_0_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_371  -20
    arc_0_0_20  depot_departure_or_bypass_648  1
    arc_0_0_20  in_degree_721  1
    arc_0_0_20  original_T_including_depot_unload_729  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_371  1
    load_0_0_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_372  -20
    arc_0_1_0  depot_return_or_bypass_649  1
    arc_0_1_0  out_degree_650  1
    arc_0_1_0  original_T_including_depot_unload_729  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_372  1
    load_0_1_0  segment_load_conservation_654  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_373  -20
    arc_0_1_2  connected_order_arc_374  -13
    arc_0_1_2  out_degree_650  1
    arc_0_1_2  in_degree_658  1
    arc_0_1_2  original_T_including_depot_unload_729  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_373  1
    load_0_1_2  segment_load_conservation_654  1
    load_0_1_2  segment_load_conservation_661  -1
    load_0_1_2  segment_prefix_lb_662  1
    load_0_1_2  segment_prefix_ub_663  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_375  -20
    arc_0_1_3  connected_order_arc_376  -13
    arc_0_1_3  out_degree_650  1
    arc_0_1_3  in_degree_665  1
    arc_0_1_3  original_T_including_depot_unload_729  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_375  1
    load_0_1_3  segment_load_conservation_654  1
    load_0_1_3  segment_load_conservation_668  -1
    load_0_1_3  segment_prefix_lb_669  1
    load_0_1_3  segment_prefix_ub_670  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_377  -20
    arc_0_1_4  connected_order_arc_378  -13
    arc_0_1_4  out_degree_650  1
    arc_0_1_4  in_degree_672  1
    arc_0_1_4  original_T_including_depot_unload_729  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_377  1
    load_0_1_4  segment_load_conservation_654  1
    load_0_1_4  segment_load_conservation_675  -1
    load_0_1_4  segment_prefix_lb_676  1
    load_0_1_4  segment_prefix_ub_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_379  -20
    arc_0_1_13  connected_order_arc_380  -13
    arc_0_1_13  out_degree_650  1
    arc_0_1_13  in_degree_679  1
    arc_0_1_13  original_T_including_depot_unload_729  2.0883063288244971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_379  1
    load_0_1_13  segment_load_conservation_654  1
    load_0_1_13  free_load_conservation_683  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_381  -20
    arc_0_1_14  connected_order_arc_382  -13
    arc_0_1_14  out_degree_650  1
    arc_0_1_14  in_degree_685  1
    arc_0_1_14  original_T_including_depot_unload_729  2.0332430776353604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_381  1
    load_0_1_14  segment_load_conservation_654  1
    load_0_1_14  free_load_conservation_689  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_383  -20
    arc_0_1_15  connected_order_arc_384  -13
    arc_0_1_15  out_degree_650  1
    arc_0_1_15  in_degree_691  1
    arc_0_1_15  original_T_including_depot_unload_729  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_383  1
    load_0_1_15  segment_load_conservation_654  1
    load_0_1_15  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_385  -20
    arc_0_1_16  connected_order_arc_386  -13
    arc_0_1_16  out_degree_650  1
    arc_0_1_16  in_degree_697  1
    arc_0_1_16  original_T_including_depot_unload_729  1.5639034270630727e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_385  1
    load_0_1_16  segment_load_conservation_654  1
    load_0_1_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_387  -20
    arc_0_1_17  connected_order_arc_388  -13
    arc_0_1_17  out_degree_650  1
    arc_0_1_17  in_degree_703  1
    arc_0_1_17  original_T_including_depot_unload_729  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_387  1
    load_0_1_17  segment_load_conservation_654  1
    load_0_1_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_389  -20
    arc_0_1_18  connected_order_arc_390  -13
    arc_0_1_18  out_degree_650  1
    arc_0_1_18  in_degree_709  1
    arc_0_1_18  original_T_including_depot_unload_729  1.4285403548915413e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_389  1
    load_0_1_18  segment_load_conservation_654  1
    load_0_1_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_391  -20
    arc_0_1_19  connected_order_arc_392  -13
    arc_0_1_19  out_degree_650  1
    arc_0_1_19  in_degree_715  1
    arc_0_1_19  original_T_including_depot_unload_729  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_391  1
    load_0_1_19  segment_load_conservation_654  1
    load_0_1_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_393  -20
    arc_0_1_20  connected_order_arc_394  -13
    arc_0_1_20  out_degree_650  1
    arc_0_1_20  in_degree_721  1
    arc_0_1_20  original_T_including_depot_unload_729  1.8746346603188274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_393  1
    load_0_1_20  segment_load_conservation_654  1
    load_0_1_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_395  -20
    arc_0_2_0  depot_return_or_bypass_649  1
    arc_0_2_0  out_degree_657  1
    arc_0_2_0  original_T_including_depot_unload_729  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_395  1
    load_0_2_0  segment_load_conservation_661  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_396  -20
    arc_0_2_1  connected_order_arc_397  -13
    arc_0_2_1  in_degree_651  1
    arc_0_2_1  out_degree_657  1
    arc_0_2_1  original_T_including_depot_unload_729  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_396  1
    load_0_2_1  segment_load_conservation_654  -1
    load_0_2_1  segment_prefix_lb_655  1
    load_0_2_1  segment_prefix_ub_656  1
    load_0_2_1  segment_load_conservation_661  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_398  -20
    arc_0_2_3  connected_order_arc_399  -13
    arc_0_2_3  out_degree_657  1
    arc_0_2_3  in_degree_665  1
    arc_0_2_3  original_T_including_depot_unload_729  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_398  1
    load_0_2_3  segment_load_conservation_661  1
    load_0_2_3  segment_load_conservation_668  -1
    load_0_2_3  segment_prefix_lb_669  1
    load_0_2_3  segment_prefix_ub_670  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_400  -20
    arc_0_2_4  connected_order_arc_401  -13
    arc_0_2_4  out_degree_657  1
    arc_0_2_4  in_degree_672  1
    arc_0_2_4  original_T_including_depot_unload_729  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_400  1
    load_0_2_4  segment_load_conservation_661  1
    load_0_2_4  segment_load_conservation_675  -1
    load_0_2_4  segment_prefix_lb_676  1
    load_0_2_4  segment_prefix_ub_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_402  -20
    arc_0_2_13  connected_order_arc_403  -13
    arc_0_2_13  out_degree_657  1
    arc_0_2_13  in_degree_679  1
    arc_0_2_13  original_T_including_depot_unload_729  2.0381190522271584e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_402  1
    load_0_2_13  segment_load_conservation_661  1
    load_0_2_13  free_load_conservation_683  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_404  -20
    arc_0_2_14  connected_order_arc_405  -13
    arc_0_2_14  out_degree_657  1
    arc_0_2_14  in_degree_685  1
    arc_0_2_14  original_T_including_depot_unload_729  1.9263039852699487e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_404  1
    load_0_2_14  segment_load_conservation_661  1
    load_0_2_14  free_load_conservation_689  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_406  -20
    arc_0_2_15  connected_order_arc_407  -13
    arc_0_2_15  out_degree_657  1
    arc_0_2_15  in_degree_691  1
    arc_0_2_15  original_T_including_depot_unload_729  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_406  1
    load_0_2_15  segment_load_conservation_661  1
    load_0_2_15  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_408  -20
    arc_0_2_16  connected_order_arc_409  -13
    arc_0_2_16  out_degree_657  1
    arc_0_2_16  in_degree_697  1
    arc_0_2_16  original_T_including_depot_unload_729  1.5814425672683194e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_408  1
    load_0_2_16  segment_load_conservation_661  1
    load_0_2_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_410  -20
    arc_0_2_17  connected_order_arc_411  -13
    arc_0_2_17  out_degree_657  1
    arc_0_2_17  in_degree_703  1
    arc_0_2_17  original_T_including_depot_unload_729  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_410  1
    load_0_2_17  segment_load_conservation_661  1
    load_0_2_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_412  -20
    arc_0_2_18  connected_order_arc_413  -13
    arc_0_2_18  out_degree_657  1
    arc_0_2_18  in_degree_709  1
    arc_0_2_18  original_T_including_depot_unload_729  1.3208627731923268e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_412  1
    load_0_2_18  segment_load_conservation_661  1
    load_0_2_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_414  -20
    arc_0_2_19  connected_order_arc_415  -13
    arc_0_2_19  out_degree_657  1
    arc_0_2_19  in_degree_715  1
    arc_0_2_19  original_T_including_depot_unload_729  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_414  1
    load_0_2_19  segment_load_conservation_661  1
    load_0_2_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_416  -20
    arc_0_2_20  connected_order_arc_417  -13
    arc_0_2_20  out_degree_657  1
    arc_0_2_20  in_degree_721  1
    arc_0_2_20  original_T_including_depot_unload_729  1.7460980574235175e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_416  1
    load_0_2_20  segment_load_conservation_661  1
    load_0_2_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_418  -20
    arc_0_3_0  depot_return_or_bypass_649  1
    arc_0_3_0  out_degree_664  1
    arc_0_3_0  original_T_including_depot_unload_729  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_418  1
    load_0_3_0  segment_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_419  -20
    arc_0_3_1  connected_order_arc_420  -13
    arc_0_3_1  in_degree_651  1
    arc_0_3_1  out_degree_664  1
    arc_0_3_1  original_T_including_depot_unload_729  5.4660309215526388e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_419  1
    load_0_3_1  segment_load_conservation_654  -1
    load_0_3_1  segment_prefix_lb_655  1
    load_0_3_1  segment_prefix_ub_656  1
    load_0_3_1  segment_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_421  -20
    arc_0_3_2  connected_order_arc_422  -13
    arc_0_3_2  in_degree_658  1
    arc_0_3_2  out_degree_664  1
    arc_0_3_2  original_T_including_depot_unload_729  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_421  1
    load_0_3_2  segment_load_conservation_661  -1
    load_0_3_2  segment_prefix_lb_662  1
    load_0_3_2  segment_prefix_ub_663  1
    load_0_3_2  segment_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_423  -20
    arc_0_3_4  connected_order_arc_424  -13
    arc_0_3_4  out_degree_664  1
    arc_0_3_4  in_degree_672  1
    arc_0_3_4  original_T_including_depot_unload_729  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_423  1
    load_0_3_4  segment_load_conservation_668  1
    load_0_3_4  segment_load_conservation_675  -1
    load_0_3_4  segment_prefix_lb_676  1
    load_0_3_4  segment_prefix_ub_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_425  -20
    arc_0_3_13  connected_order_arc_426  -13
    arc_0_3_13  out_degree_664  1
    arc_0_3_13  in_degree_679  1
    arc_0_3_13  original_T_including_depot_unload_729  1.9320166886379850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_425  1
    load_0_3_13  segment_load_conservation_668  1
    load_0_3_13  free_load_conservation_683  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_427  -20
    arc_0_3_14  connected_order_arc_428  -13
    arc_0_3_14  out_degree_664  1
    arc_0_3_14  in_degree_685  1
    arc_0_3_14  original_T_including_depot_unload_729  1.7740294865208371e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_427  1
    load_0_3_14  segment_load_conservation_668  1
    load_0_3_14  free_load_conservation_689  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_429  -20
    arc_0_3_15  connected_order_arc_430  -13
    arc_0_3_15  out_degree_664  1
    arc_0_3_15  in_degree_691  1
    arc_0_3_15  original_T_including_depot_unload_729  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_429  1
    load_0_3_15  segment_load_conservation_668  1
    load_0_3_15  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_431  -20
    arc_0_3_16  connected_order_arc_432  -13
    arc_0_3_16  out_degree_664  1
    arc_0_3_16  in_degree_697  1
    arc_0_3_16  original_T_including_depot_unload_729  1.5428621806127467e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_431  1
    load_0_3_16  segment_load_conservation_668  1
    load_0_3_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_433  -20
    arc_0_3_17  connected_order_arc_434  -13
    arc_0_3_17  out_degree_664  1
    arc_0_3_17  in_degree_703  1
    arc_0_3_17  original_T_including_depot_unload_729  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_433  1
    load_0_3_17  segment_load_conservation_668  1
    load_0_3_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_435  -20
    arc_0_3_18  connected_order_arc_436  -13
    arc_0_3_18  out_degree_664  1
    arc_0_3_18  in_degree_709  1
    arc_0_3_18  original_T_including_depot_unload_729  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_435  1
    load_0_3_18  segment_load_conservation_668  1
    load_0_3_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_437  -20
    arc_0_3_19  connected_order_arc_438  -13
    arc_0_3_19  out_degree_664  1
    arc_0_3_19  in_degree_715  1
    arc_0_3_19  original_T_including_depot_unload_729  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_437  1
    load_0_3_19  segment_load_conservation_668  1
    load_0_3_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_439  -20
    arc_0_3_20  connected_order_arc_440  -13
    arc_0_3_20  out_degree_664  1
    arc_0_3_20  in_degree_721  1
    arc_0_3_20  original_T_including_depot_unload_729  1.5787929582117179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_439  1
    load_0_3_20  segment_load_conservation_668  1
    load_0_3_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_441  -20
    arc_0_4_0  depot_return_or_bypass_649  1
    arc_0_4_0  out_degree_671  1
    arc_0_4_0  original_T_including_depot_unload_729  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_441  1
    load_0_4_0  segment_load_conservation_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_442  -20
    arc_0_4_1  connected_order_arc_443  -13
    arc_0_4_1  in_degree_651  1
    arc_0_4_1  out_degree_671  1
    arc_0_4_1  original_T_including_depot_unload_729  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_442  1
    load_0_4_1  segment_load_conservation_654  -1
    load_0_4_1  segment_prefix_lb_655  1
    load_0_4_1  segment_prefix_ub_656  1
    load_0_4_1  segment_load_conservation_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_444  -20
    arc_0_4_2  connected_order_arc_445  -13
    arc_0_4_2  in_degree_658  1
    arc_0_4_2  out_degree_671  1
    arc_0_4_2  original_T_including_depot_unload_729  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_444  1
    load_0_4_2  segment_load_conservation_661  -1
    load_0_4_2  segment_prefix_lb_662  1
    load_0_4_2  segment_prefix_ub_663  1
    load_0_4_2  segment_load_conservation_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_446  -20
    arc_0_4_3  connected_order_arc_447  -13
    arc_0_4_3  in_degree_665  1
    arc_0_4_3  out_degree_671  1
    arc_0_4_3  original_T_including_depot_unload_729  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_446  1
    load_0_4_3  segment_load_conservation_668  -1
    load_0_4_3  segment_prefix_lb_669  1
    load_0_4_3  segment_prefix_ub_670  1
    load_0_4_3  segment_load_conservation_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_448  -20
    arc_0_4_13  connected_order_arc_449  -13
    arc_0_4_13  out_degree_671  1
    arc_0_4_13  in_degree_679  1
    arc_0_4_13  original_T_including_depot_unload_729  1.8670935270400330e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_448  1
    load_0_4_13  segment_load_conservation_675  1
    load_0_4_13  free_load_conservation_683  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_450  -20
    arc_0_4_14  connected_order_arc_451  -13
    arc_0_4_14  out_degree_671  1
    arc_0_4_14  in_degree_685  1
    arc_0_4_14  original_T_including_depot_unload_729  1.6849162169783858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_450  1
    load_0_4_14  segment_load_conservation_675  1
    load_0_4_14  free_load_conservation_689  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_452  -20
    arc_0_4_15  connected_order_arc_453  -13
    arc_0_4_15  out_degree_671  1
    arc_0_4_15  in_degree_691  1
    arc_0_4_15  original_T_including_depot_unload_729  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_452  1
    load_0_4_15  segment_load_conservation_675  1
    load_0_4_15  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_454  -20
    arc_0_4_16  connected_order_arc_455  -13
    arc_0_4_16  out_degree_671  1
    arc_0_4_16  in_degree_697  1
    arc_0_4_16  original_T_including_depot_unload_729  1.5168242190367512e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_454  1
    load_0_4_16  segment_load_conservation_675  1
    load_0_4_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_456  -20
    arc_0_4_17  connected_order_arc_457  -13
    arc_0_4_17  out_degree_671  1
    arc_0_4_17  in_degree_703  1
    arc_0_4_17  original_T_including_depot_unload_729  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_456  1
    load_0_4_17  segment_load_conservation_675  1
    load_0_4_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_458  -20
    arc_0_4_18  connected_order_arc_459  -13
    arc_0_4_18  out_degree_671  1
    arc_0_4_18  in_degree_709  1
    arc_0_4_18  original_T_including_depot_unload_729  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_458  1
    load_0_4_18  segment_load_conservation_675  1
    load_0_4_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_460  -20
    arc_0_4_19  connected_order_arc_461  -13
    arc_0_4_19  out_degree_671  1
    arc_0_4_19  in_degree_715  1
    arc_0_4_19  original_T_including_depot_unload_729  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_460  1
    load_0_4_19  segment_load_conservation_675  1
    load_0_4_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_462  -20
    arc_0_4_20  connected_order_arc_463  -13
    arc_0_4_20  out_degree_671  1
    arc_0_4_20  in_degree_721  1
    arc_0_4_20  original_T_including_depot_unload_729  1.4823747651994408e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_462  1
    load_0_4_20  segment_load_conservation_675  1
    load_0_4_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_464  -20
    arc_0_13_0  depot_return_or_bypass_649  1
    arc_0_13_0  out_degree_678  1
    arc_0_13_0  original_T_including_depot_unload_729  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_464  1
    load_0_13_0  free_load_conservation_683  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_465  -20
    arc_0_13_1  connected_order_arc_466  -13
    arc_0_13_1  in_degree_651  1
    arc_0_13_1  out_degree_678  1
    arc_0_13_1  original_T_including_depot_unload_729  2.1385293969918903e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_465  1
    load_0_13_1  segment_load_conservation_654  -1
    load_0_13_1  segment_prefix_lb_655  1
    load_0_13_1  segment_prefix_ub_656  1
    load_0_13_1  free_load_conservation_683  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_467  -20
    arc_0_13_2  connected_order_arc_468  -13
    arc_0_13_2  in_degree_658  1
    arc_0_13_2  out_degree_678  1
    arc_0_13_2  original_T_including_depot_unload_729  2.0400693679210435e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_467  1
    load_0_13_2  segment_load_conservation_661  -1
    load_0_13_2  segment_prefix_lb_662  1
    load_0_13_2  segment_prefix_ub_663  1
    load_0_13_2  free_load_conservation_683  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_469  -20
    arc_0_13_3  connected_order_arc_470  -13
    arc_0_13_3  in_degree_665  1
    arc_0_13_3  out_degree_678  1
    arc_0_13_3  original_T_including_depot_unload_729  1.9320166886379850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_469  1
    load_0_13_3  segment_load_conservation_668  -1
    load_0_13_3  segment_prefix_lb_669  1
    load_0_13_3  segment_prefix_ub_670  1
    load_0_13_3  free_load_conservation_683  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_471  -20
    arc_0_13_4  connected_order_arc_472  -13
    arc_0_13_4  in_degree_672  1
    arc_0_13_4  out_degree_678  1
    arc_0_13_4  original_T_including_depot_unload_729  1.8670935270400330e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_471  1
    load_0_13_4  segment_load_conservation_675  -1
    load_0_13_4  segment_prefix_lb_676  1
    load_0_13_4  segment_prefix_ub_677  1
    load_0_13_4  free_load_conservation_683  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_473  -20
    arc_0_13_14  connected_order_arc_474  -13
    arc_0_13_14  out_degree_678  1
    arc_0_13_14  in_degree_685  1
    arc_0_13_14  original_T_including_depot_unload_729  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_473  1
    load_0_13_14  free_load_conservation_683  1
    load_0_13_14  free_load_conservation_689  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_475  -20
    arc_0_13_15  connected_order_arc_476  -13
    arc_0_13_15  out_degree_678  1
    arc_0_13_15  in_degree_691  1
    arc_0_13_15  original_T_including_depot_unload_729  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_475  1
    load_0_13_15  free_load_conservation_683  1
    load_0_13_15  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_477  -20
    arc_0_13_16  connected_order_arc_478  -13
    arc_0_13_16  out_degree_678  1
    arc_0_13_16  in_degree_697  1
    arc_0_13_16  original_T_including_depot_unload_729  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_477  1
    load_0_13_16  free_load_conservation_683  1
    load_0_13_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_479  -20
    arc_0_13_17  connected_order_arc_480  -13
    arc_0_13_17  out_degree_678  1
    arc_0_13_17  in_degree_703  1
    arc_0_13_17  original_T_including_depot_unload_729  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_479  1
    load_0_13_17  free_load_conservation_683  1
    load_0_13_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_481  -20
    arc_0_13_18  connected_order_arc_482  -13
    arc_0_13_18  out_degree_678  1
    arc_0_13_18  in_degree_709  1
    arc_0_13_18  original_T_including_depot_unload_729  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_481  1
    load_0_13_18  free_load_conservation_683  1
    load_0_13_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_483  -20
    arc_0_13_19  connected_order_arc_484  -13
    arc_0_13_19  out_degree_678  1
    arc_0_13_19  in_degree_715  1
    arc_0_13_19  original_T_including_depot_unload_729  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_483  1
    load_0_13_19  free_load_conservation_683  1
    load_0_13_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_485  -20
    arc_0_13_20  connected_order_arc_486  -13
    arc_0_13_20  out_degree_678  1
    arc_0_13_20  in_degree_721  1
    arc_0_13_20  original_T_including_depot_unload_729  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_485  1
    load_0_13_20  free_load_conservation_683  1
    load_0_13_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_487  -20
    arc_0_14_0  depot_return_or_bypass_649  1
    arc_0_14_0  out_degree_684  1
    arc_0_14_0  original_T_including_depot_unload_729  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_487  1
    load_0_14_0  free_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_488  -20
    arc_0_14_1  connected_order_arc_489  -13
    arc_0_14_1  in_degree_651  1
    arc_0_14_1  out_degree_684  1
    arc_0_14_1  original_T_including_depot_unload_729  2.1282881916080823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_488  1
    load_0_14_1  segment_load_conservation_654  -1
    load_0_14_1  segment_prefix_lb_655  1
    load_0_14_1  segment_prefix_ub_656  1
    load_0_14_1  free_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_490  -20
    arc_0_14_2  connected_order_arc_491  -13
    arc_0_14_2  in_degree_658  1
    arc_0_14_2  out_degree_684  1
    arc_0_14_2  original_T_including_depot_unload_729  1.9286914187809364e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_490  1
    load_0_14_2  segment_load_conservation_661  -1
    load_0_14_2  segment_prefix_lb_662  1
    load_0_14_2  segment_prefix_ub_663  1
    load_0_14_2  free_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_492  -20
    arc_0_14_3  connected_order_arc_493  -13
    arc_0_14_3  in_degree_665  1
    arc_0_14_3  out_degree_684  1
    arc_0_14_3  original_T_including_depot_unload_729  1.7740294865208371e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_492  1
    load_0_14_3  segment_load_conservation_668  -1
    load_0_14_3  segment_prefix_lb_669  1
    load_0_14_3  segment_prefix_ub_670  1
    load_0_14_3  free_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_494  -20
    arc_0_14_4  connected_order_arc_495  -13
    arc_0_14_4  in_degree_672  1
    arc_0_14_4  out_degree_684  1
    arc_0_14_4  original_T_including_depot_unload_729  1.6849162169783858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_494  1
    load_0_14_4  segment_load_conservation_675  -1
    load_0_14_4  segment_prefix_lb_676  1
    load_0_14_4  segment_prefix_ub_677  1
    load_0_14_4  free_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_496  -20
    arc_0_14_13  connected_order_arc_497  -13
    arc_0_14_13  in_degree_679  1
    arc_0_14_13  out_degree_684  1
    arc_0_14_13  original_T_including_depot_unload_729  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_496  1
    load_0_14_13  free_load_conservation_683  -1
    load_0_14_13  free_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_498  -20
    arc_0_14_15  connected_order_arc_499  -13
    arc_0_14_15  out_degree_684  1
    arc_0_14_15  in_degree_691  1
    arc_0_14_15  original_T_including_depot_unload_729  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_498  1
    load_0_14_15  free_load_conservation_689  1
    load_0_14_15  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_500  -20
    arc_0_14_16  connected_order_arc_501  -13
    arc_0_14_16  out_degree_684  1
    arc_0_14_16  in_degree_697  1
    arc_0_14_16  original_T_including_depot_unload_729  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_500  1
    load_0_14_16  free_load_conservation_689  1
    load_0_14_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_502  -20
    arc_0_14_17  connected_order_arc_503  -13
    arc_0_14_17  out_degree_684  1
    arc_0_14_17  in_degree_703  1
    arc_0_14_17  original_T_including_depot_unload_729  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_502  1
    load_0_14_17  free_load_conservation_689  1
    load_0_14_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_504  -20
    arc_0_14_18  connected_order_arc_505  -13
    arc_0_14_18  out_degree_684  1
    arc_0_14_18  in_degree_709  1
    arc_0_14_18  original_T_including_depot_unload_729  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_504  1
    load_0_14_18  free_load_conservation_689  1
    load_0_14_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_506  -20
    arc_0_14_19  connected_order_arc_507  -13
    arc_0_14_19  out_degree_684  1
    arc_0_14_19  in_degree_715  1
    arc_0_14_19  original_T_including_depot_unload_729  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_506  1
    load_0_14_19  free_load_conservation_689  1
    load_0_14_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_508  -20
    arc_0_14_20  connected_order_arc_509  -13
    arc_0_14_20  out_degree_684  1
    arc_0_14_20  in_degree_721  1
    arc_0_14_20  original_T_including_depot_unload_729  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_508  1
    load_0_14_20  free_load_conservation_689  1
    load_0_14_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_510  -20
    arc_0_15_0  depot_return_or_bypass_649  1
    arc_0_15_0  out_degree_690  1
    arc_0_15_0  original_T_including_depot_unload_729  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_510  1
    load_0_15_0  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_511  -20
    arc_0_15_1  connected_order_arc_512  -13
    arc_0_15_1  in_degree_651  1
    arc_0_15_1  out_degree_690  1
    arc_0_15_1  original_T_including_depot_unload_729  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_511  1
    load_0_15_1  segment_load_conservation_654  -1
    load_0_15_1  segment_prefix_lb_655  1
    load_0_15_1  segment_prefix_ub_656  1
    load_0_15_1  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_513  -20
    arc_0_15_2  connected_order_arc_514  -13
    arc_0_15_2  in_degree_658  1
    arc_0_15_2  out_degree_690  1
    arc_0_15_2  original_T_including_depot_unload_729  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_513  1
    load_0_15_2  segment_load_conservation_661  -1
    load_0_15_2  segment_prefix_lb_662  1
    load_0_15_2  segment_prefix_ub_663  1
    load_0_15_2  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_515  -20
    arc_0_15_3  connected_order_arc_516  -13
    arc_0_15_3  in_degree_665  1
    arc_0_15_3  out_degree_690  1
    arc_0_15_3  original_T_including_depot_unload_729  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_515  1
    load_0_15_3  segment_load_conservation_668  -1
    load_0_15_3  segment_prefix_lb_669  1
    load_0_15_3  segment_prefix_ub_670  1
    load_0_15_3  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_517  -20
    arc_0_15_4  connected_order_arc_518  -13
    arc_0_15_4  in_degree_672  1
    arc_0_15_4  out_degree_690  1
    arc_0_15_4  original_T_including_depot_unload_729  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_517  1
    load_0_15_4  segment_load_conservation_675  -1
    load_0_15_4  segment_prefix_lb_676  1
    load_0_15_4  segment_prefix_ub_677  1
    load_0_15_4  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_519  -20
    arc_0_15_13  connected_order_arc_520  -13
    arc_0_15_13  in_degree_679  1
    arc_0_15_13  out_degree_690  1
    arc_0_15_13  original_T_including_depot_unload_729  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_519  1
    load_0_15_13  free_load_conservation_683  -1
    load_0_15_13  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_521  -20
    arc_0_15_14  connected_order_arc_522  -13
    arc_0_15_14  in_degree_685  1
    arc_0_15_14  out_degree_690  1
    arc_0_15_14  original_T_including_depot_unload_729  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_521  1
    load_0_15_14  free_load_conservation_689  -1
    load_0_15_14  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_523  -20
    arc_0_15_16  connected_order_arc_524  -13
    arc_0_15_16  out_degree_690  1
    arc_0_15_16  in_degree_697  1
    arc_0_15_16  original_T_including_depot_unload_729  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_523  1
    load_0_15_16  free_load_conservation_695  1
    load_0_15_16  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_525  -20
    arc_0_15_17  connected_order_arc_526  -13
    arc_0_15_17  out_degree_690  1
    arc_0_15_17  in_degree_703  1
    arc_0_15_17  original_T_including_depot_unload_729  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_525  1
    load_0_15_17  free_load_conservation_695  1
    load_0_15_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_527  -20
    arc_0_15_18  connected_order_arc_528  -13
    arc_0_15_18  out_degree_690  1
    arc_0_15_18  in_degree_709  1
    arc_0_15_18  original_T_including_depot_unload_729  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_527  1
    load_0_15_18  free_load_conservation_695  1
    load_0_15_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_529  -20
    arc_0_15_19  connected_order_arc_530  -13
    arc_0_15_19  out_degree_690  1
    arc_0_15_19  in_degree_715  1
    arc_0_15_19  original_T_including_depot_unload_729  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_529  1
    load_0_15_19  free_load_conservation_695  1
    load_0_15_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_531  -20
    arc_0_15_20  connected_order_arc_532  -13
    arc_0_15_20  out_degree_690  1
    arc_0_15_20  in_degree_721  1
    arc_0_15_20  original_T_including_depot_unload_729  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_531  1
    load_0_15_20  free_load_conservation_695  1
    load_0_15_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_533  -20
    arc_0_16_0  depot_return_or_bypass_649  1
    arc_0_16_0  out_degree_696  1
    arc_0_16_0  original_T_including_depot_unload_729  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_533  1
    load_0_16_0  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_534  -20
    arc_0_16_1  connected_order_arc_535  -13
    arc_0_16_1  in_degree_651  1
    arc_0_16_1  out_degree_696  1
    arc_0_16_1  original_T_including_depot_unload_729  1.5634365646683834e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_534  1
    load_0_16_1  segment_load_conservation_654  -1
    load_0_16_1  segment_prefix_lb_655  1
    load_0_16_1  segment_prefix_ub_656  1
    load_0_16_1  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_536  -20
    arc_0_16_2  connected_order_arc_537  -13
    arc_0_16_2  in_degree_658  1
    arc_0_16_2  out_degree_696  1
    arc_0_16_2  original_T_including_depot_unload_729  1.5826657352191260e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_536  1
    load_0_16_2  segment_load_conservation_661  -1
    load_0_16_2  segment_prefix_lb_662  1
    load_0_16_2  segment_prefix_ub_663  1
    load_0_16_2  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_538  -20
    arc_0_16_3  connected_order_arc_539  -13
    arc_0_16_3  in_degree_665  1
    arc_0_16_3  out_degree_696  1
    arc_0_16_3  original_T_including_depot_unload_729  1.5428621806127467e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_538  1
    load_0_16_3  segment_load_conservation_668  -1
    load_0_16_3  segment_prefix_lb_669  1
    load_0_16_3  segment_prefix_ub_670  1
    load_0_16_3  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_540  -20
    arc_0_16_4  connected_order_arc_541  -13
    arc_0_16_4  in_degree_672  1
    arc_0_16_4  out_degree_696  1
    arc_0_16_4  original_T_including_depot_unload_729  1.5168242190367512e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_540  1
    load_0_16_4  segment_load_conservation_675  -1
    load_0_16_4  segment_prefix_lb_676  1
    load_0_16_4  segment_prefix_ub_677  1
    load_0_16_4  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_542  -20
    arc_0_16_13  connected_order_arc_543  -13
    arc_0_16_13  in_degree_679  1
    arc_0_16_13  out_degree_696  1
    arc_0_16_13  original_T_including_depot_unload_729  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_542  1
    load_0_16_13  free_load_conservation_683  -1
    load_0_16_13  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_544  -20
    arc_0_16_14  connected_order_arc_545  -13
    arc_0_16_14  in_degree_685  1
    arc_0_16_14  out_degree_696  1
    arc_0_16_14  original_T_including_depot_unload_729  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_544  1
    load_0_16_14  free_load_conservation_689  -1
    load_0_16_14  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_546  -20
    arc_0_16_15  connected_order_arc_547  -13
    arc_0_16_15  in_degree_691  1
    arc_0_16_15  out_degree_696  1
    arc_0_16_15  original_T_including_depot_unload_729  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_546  1
    load_0_16_15  free_load_conservation_695  -1
    load_0_16_15  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_548  -20
    arc_0_16_17  connected_order_arc_549  -13
    arc_0_16_17  out_degree_696  1
    arc_0_16_17  in_degree_703  1
    arc_0_16_17  original_T_including_depot_unload_729  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_548  1
    load_0_16_17  free_load_conservation_701  1
    load_0_16_17  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_550  -20
    arc_0_16_18  connected_order_arc_551  -13
    arc_0_16_18  out_degree_696  1
    arc_0_16_18  in_degree_709  1
    arc_0_16_18  original_T_including_depot_unload_729  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_550  1
    load_0_16_18  free_load_conservation_701  1
    load_0_16_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_552  -20
    arc_0_16_19  connected_order_arc_553  -13
    arc_0_16_19  out_degree_696  1
    arc_0_16_19  in_degree_715  1
    arc_0_16_19  original_T_including_depot_unload_729  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_552  1
    load_0_16_19  free_load_conservation_701  1
    load_0_16_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_554  -20
    arc_0_16_20  connected_order_arc_555  -13
    arc_0_16_20  out_degree_696  1
    arc_0_16_20  in_degree_721  1
    arc_0_16_20  original_T_including_depot_unload_729  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_554  1
    load_0_16_20  free_load_conservation_701  1
    load_0_16_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_556  -20
    arc_0_17_0  depot_return_or_bypass_649  1
    arc_0_17_0  out_degree_702  1
    arc_0_17_0  original_T_including_depot_unload_729  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_556  1
    load_0_17_0  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_557  -20
    arc_0_17_1  connected_order_arc_558  -13
    arc_0_17_1  in_degree_651  1
    arc_0_17_1  out_degree_702  1
    arc_0_17_1  original_T_including_depot_unload_729  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_557  1
    load_0_17_1  segment_load_conservation_654  -1
    load_0_17_1  segment_prefix_lb_655  1
    load_0_17_1  segment_prefix_ub_656  1
    load_0_17_1  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_559  -20
    arc_0_17_2  connected_order_arc_560  -13
    arc_0_17_2  in_degree_658  1
    arc_0_17_2  out_degree_702  1
    arc_0_17_2  original_T_including_depot_unload_729  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_559  1
    load_0_17_2  segment_load_conservation_661  -1
    load_0_17_2  segment_prefix_lb_662  1
    load_0_17_2  segment_prefix_ub_663  1
    load_0_17_2  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_561  -20
    arc_0_17_3  connected_order_arc_562  -13
    arc_0_17_3  in_degree_665  1
    arc_0_17_3  out_degree_702  1
    arc_0_17_3  original_T_including_depot_unload_729  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_561  1
    load_0_17_3  segment_load_conservation_668  -1
    load_0_17_3  segment_prefix_lb_669  1
    load_0_17_3  segment_prefix_ub_670  1
    load_0_17_3  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_563  -20
    arc_0_17_4  connected_order_arc_564  -13
    arc_0_17_4  in_degree_672  1
    arc_0_17_4  out_degree_702  1
    arc_0_17_4  original_T_including_depot_unload_729  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_563  1
    load_0_17_4  segment_load_conservation_675  -1
    load_0_17_4  segment_prefix_lb_676  1
    load_0_17_4  segment_prefix_ub_677  1
    load_0_17_4  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_565  -20
    arc_0_17_13  connected_order_arc_566  -13
    arc_0_17_13  in_degree_679  1
    arc_0_17_13  out_degree_702  1
    arc_0_17_13  original_T_including_depot_unload_729  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_565  1
    load_0_17_13  free_load_conservation_683  -1
    load_0_17_13  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_567  -20
    arc_0_17_14  connected_order_arc_568  -13
    arc_0_17_14  in_degree_685  1
    arc_0_17_14  out_degree_702  1
    arc_0_17_14  original_T_including_depot_unload_729  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_567  1
    load_0_17_14  free_load_conservation_689  -1
    load_0_17_14  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_569  -20
    arc_0_17_15  connected_order_arc_570  -13
    arc_0_17_15  in_degree_691  1
    arc_0_17_15  out_degree_702  1
    arc_0_17_15  original_T_including_depot_unload_729  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_569  1
    load_0_17_15  free_load_conservation_695  -1
    load_0_17_15  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_571  -20
    arc_0_17_16  connected_order_arc_572  -13
    arc_0_17_16  in_degree_697  1
    arc_0_17_16  out_degree_702  1
    arc_0_17_16  original_T_including_depot_unload_729  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_571  1
    load_0_17_16  free_load_conservation_701  -1
    load_0_17_16  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_573  -20
    arc_0_17_18  connected_order_arc_574  -13
    arc_0_17_18  out_degree_702  1
    arc_0_17_18  in_degree_709  1
    arc_0_17_18  original_T_including_depot_unload_729  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_573  1
    load_0_17_18  free_load_conservation_707  1
    load_0_17_18  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_575  -20
    arc_0_17_19  connected_order_arc_576  -13
    arc_0_17_19  out_degree_702  1
    arc_0_17_19  in_degree_715  1
    arc_0_17_19  original_T_including_depot_unload_729  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_575  1
    load_0_17_19  free_load_conservation_707  1
    load_0_17_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_577  -20
    arc_0_17_20  connected_order_arc_578  -13
    arc_0_17_20  out_degree_702  1
    arc_0_17_20  in_degree_721  1
    arc_0_17_20  original_T_including_depot_unload_729  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_577  1
    load_0_17_20  free_load_conservation_707  1
    load_0_17_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_579  -20
    arc_0_18_0  depot_return_or_bypass_649  1
    arc_0_18_0  out_degree_708  1
    arc_0_18_0  original_T_including_depot_unload_729  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_579  1
    load_0_18_0  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_580  -20
    arc_0_18_1  connected_order_arc_581  -13
    arc_0_18_1  in_degree_651  1
    arc_0_18_1  out_degree_708  1
    arc_0_18_1  original_T_including_depot_unload_729  1.5282490775772073e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_580  1
    load_0_18_1  segment_load_conservation_654  -1
    load_0_18_1  segment_prefix_lb_655  1
    load_0_18_1  segment_prefix_ub_656  1
    load_0_18_1  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_582  -20
    arc_0_18_2  connected_order_arc_583  -13
    arc_0_18_2  in_degree_658  1
    arc_0_18_2  out_degree_708  1
    arc_0_18_2  original_T_including_depot_unload_729  1.3232349913962587e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_582  1
    load_0_18_2  segment_load_conservation_661  -1
    load_0_18_2  segment_prefix_lb_662  1
    load_0_18_2  segment_prefix_ub_663  1
    load_0_18_2  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_584  -20
    arc_0_18_3  connected_order_arc_585  -13
    arc_0_18_3  in_degree_665  1
    arc_0_18_3  out_degree_708  1
    arc_0_18_3  original_T_including_depot_unload_729  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_584  1
    load_0_18_3  segment_load_conservation_668  -1
    load_0_18_3  segment_prefix_lb_669  1
    load_0_18_3  segment_prefix_ub_670  1
    load_0_18_3  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_586  -20
    arc_0_18_4  connected_order_arc_587  -13
    arc_0_18_4  in_degree_672  1
    arc_0_18_4  out_degree_708  1
    arc_0_18_4  original_T_including_depot_unload_729  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_586  1
    load_0_18_4  segment_load_conservation_675  -1
    load_0_18_4  segment_prefix_lb_676  1
    load_0_18_4  segment_prefix_ub_677  1
    load_0_18_4  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_588  -20
    arc_0_18_13  connected_order_arc_589  -13
    arc_0_18_13  in_degree_679  1
    arc_0_18_13  out_degree_708  1
    arc_0_18_13  original_T_including_depot_unload_729  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_588  1
    load_0_18_13  free_load_conservation_683  -1
    load_0_18_13  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_590  -20
    arc_0_18_14  connected_order_arc_591  -13
    arc_0_18_14  in_degree_685  1
    arc_0_18_14  out_degree_708  1
    arc_0_18_14  original_T_including_depot_unload_729  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_590  1
    load_0_18_14  free_load_conservation_689  -1
    load_0_18_14  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_592  -20
    arc_0_18_15  connected_order_arc_593  -13
    arc_0_18_15  in_degree_691  1
    arc_0_18_15  out_degree_708  1
    arc_0_18_15  original_T_including_depot_unload_729  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_592  1
    load_0_18_15  free_load_conservation_695  -1
    load_0_18_15  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_594  -20
    arc_0_18_16  connected_order_arc_595  -13
    arc_0_18_16  in_degree_697  1
    arc_0_18_16  out_degree_708  1
    arc_0_18_16  original_T_including_depot_unload_729  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_594  1
    load_0_18_16  free_load_conservation_701  -1
    load_0_18_16  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_596  -20
    arc_0_18_17  connected_order_arc_597  -13
    arc_0_18_17  in_degree_703  1
    arc_0_18_17  out_degree_708  1
    arc_0_18_17  original_T_including_depot_unload_729  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_596  1
    load_0_18_17  free_load_conservation_707  -1
    load_0_18_17  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_598  -20
    arc_0_18_19  connected_order_arc_599  -13
    arc_0_18_19  out_degree_708  1
    arc_0_18_19  in_degree_715  1
    arc_0_18_19  original_T_including_depot_unload_729  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_598  1
    load_0_18_19  free_load_conservation_713  1
    load_0_18_19  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_600  -20
    arc_0_18_20  connected_order_arc_601  -13
    arc_0_18_20  out_degree_708  1
    arc_0_18_20  in_degree_721  1
    arc_0_18_20  original_T_including_depot_unload_729  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_600  1
    load_0_18_20  free_load_conservation_713  1
    load_0_18_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_602  -20
    arc_0_19_0  depot_return_or_bypass_649  1
    arc_0_19_0  out_degree_714  1
    arc_0_19_0  original_T_including_depot_unload_729  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_602  1
    load_0_19_0  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_603  -20
    arc_0_19_1  connected_order_arc_604  -13
    arc_0_19_1  in_degree_651  1
    arc_0_19_1  out_degree_714  1
    arc_0_19_1  original_T_including_depot_unload_729  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_603  1
    load_0_19_1  segment_load_conservation_654  -1
    load_0_19_1  segment_prefix_lb_655  1
    load_0_19_1  segment_prefix_ub_656  1
    load_0_19_1  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_605  -20
    arc_0_19_2  connected_order_arc_606  -13
    arc_0_19_2  in_degree_658  1
    arc_0_19_2  out_degree_714  1
    arc_0_19_2  original_T_including_depot_unload_729  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_605  1
    load_0_19_2  segment_load_conservation_661  -1
    load_0_19_2  segment_prefix_lb_662  1
    load_0_19_2  segment_prefix_ub_663  1
    load_0_19_2  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_607  -20
    arc_0_19_3  connected_order_arc_608  -13
    arc_0_19_3  in_degree_665  1
    arc_0_19_3  out_degree_714  1
    arc_0_19_3  original_T_including_depot_unload_729  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_607  1
    load_0_19_3  segment_load_conservation_668  -1
    load_0_19_3  segment_prefix_lb_669  1
    load_0_19_3  segment_prefix_ub_670  1
    load_0_19_3  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_609  -20
    arc_0_19_4  connected_order_arc_610  -13
    arc_0_19_4  in_degree_672  1
    arc_0_19_4  out_degree_714  1
    arc_0_19_4  original_T_including_depot_unload_729  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_609  1
    load_0_19_4  segment_load_conservation_675  -1
    load_0_19_4  segment_prefix_lb_676  1
    load_0_19_4  segment_prefix_ub_677  1
    load_0_19_4  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_611  -20
    arc_0_19_13  connected_order_arc_612  -13
    arc_0_19_13  in_degree_679  1
    arc_0_19_13  out_degree_714  1
    arc_0_19_13  original_T_including_depot_unload_729  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_611  1
    load_0_19_13  free_load_conservation_683  -1
    load_0_19_13  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_613  -20
    arc_0_19_14  connected_order_arc_614  -13
    arc_0_19_14  in_degree_685  1
    arc_0_19_14  out_degree_714  1
    arc_0_19_14  original_T_including_depot_unload_729  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_613  1
    load_0_19_14  free_load_conservation_689  -1
    load_0_19_14  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_615  -20
    arc_0_19_15  connected_order_arc_616  -13
    arc_0_19_15  in_degree_691  1
    arc_0_19_15  out_degree_714  1
    arc_0_19_15  original_T_including_depot_unload_729  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_615  1
    load_0_19_15  free_load_conservation_695  -1
    load_0_19_15  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_617  -20
    arc_0_19_16  connected_order_arc_618  -13
    arc_0_19_16  in_degree_697  1
    arc_0_19_16  out_degree_714  1
    arc_0_19_16  original_T_including_depot_unload_729  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_617  1
    load_0_19_16  free_load_conservation_701  -1
    load_0_19_16  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_619  -20
    arc_0_19_17  connected_order_arc_620  -13
    arc_0_19_17  in_degree_703  1
    arc_0_19_17  out_degree_714  1
    arc_0_19_17  original_T_including_depot_unload_729  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_619  1
    load_0_19_17  free_load_conservation_707  -1
    load_0_19_17  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_621  -20
    arc_0_19_18  connected_order_arc_622  -13
    arc_0_19_18  in_degree_709  1
    arc_0_19_18  out_degree_714  1
    arc_0_19_18  original_T_including_depot_unload_729  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_621  1
    load_0_19_18  free_load_conservation_713  -1
    load_0_19_18  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_623  -20
    arc_0_19_20  connected_order_arc_624  -13
    arc_0_19_20  out_degree_714  1
    arc_0_19_20  in_degree_721  1
    arc_0_19_20  original_T_including_depot_unload_729  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_623  1
    load_0_19_20  free_load_conservation_719  1
    load_0_19_20  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_625  -20
    arc_0_20_0  depot_return_or_bypass_649  1
    arc_0_20_0  out_degree_720  1
    arc_0_20_0  original_T_including_depot_unload_729  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_625  1
    load_0_20_0  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_626  -20
    arc_0_20_1  connected_order_arc_627  -13
    arc_0_20_1  in_degree_651  1
    arc_0_20_1  out_degree_720  1
    arc_0_20_1  original_T_including_depot_unload_729  1.9868605646773756e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_626  1
    load_0_20_1  segment_load_conservation_654  -1
    load_0_20_1  segment_prefix_lb_655  1
    load_0_20_1  segment_prefix_ub_656  1
    load_0_20_1  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_628  -20
    arc_0_20_2  connected_order_arc_629  -13
    arc_0_20_2  in_degree_658  1
    arc_0_20_2  out_degree_720  1
    arc_0_20_2  original_T_including_depot_unload_729  1.7486017219434013e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_628  1
    load_0_20_2  segment_load_conservation_661  -1
    load_0_20_2  segment_prefix_lb_662  1
    load_0_20_2  segment_prefix_ub_663  1
    load_0_20_2  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_630  -20
    arc_0_20_3  connected_order_arc_631  -13
    arc_0_20_3  in_degree_665  1
    arc_0_20_3  out_degree_720  1
    arc_0_20_3  original_T_including_depot_unload_729  1.5787929582117179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_630  1
    load_0_20_3  segment_load_conservation_668  -1
    load_0_20_3  segment_prefix_lb_669  1
    load_0_20_3  segment_prefix_ub_670  1
    load_0_20_3  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_632  -20
    arc_0_20_4  connected_order_arc_633  -13
    arc_0_20_4  in_degree_672  1
    arc_0_20_4  out_degree_720  1
    arc_0_20_4  original_T_including_depot_unload_729  1.4823747651994408e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_632  1
    load_0_20_4  segment_load_conservation_675  -1
    load_0_20_4  segment_prefix_lb_676  1
    load_0_20_4  segment_prefix_ub_677  1
    load_0_20_4  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_634  -20
    arc_0_20_13  connected_order_arc_635  -13
    arc_0_20_13  in_degree_679  1
    arc_0_20_13  out_degree_720  1
    arc_0_20_13  original_T_including_depot_unload_729  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_634  1
    load_0_20_13  free_load_conservation_683  -1
    load_0_20_13  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_636  -20
    arc_0_20_14  connected_order_arc_637  -13
    arc_0_20_14  in_degree_685  1
    arc_0_20_14  out_degree_720  1
    arc_0_20_14  original_T_including_depot_unload_729  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_636  1
    load_0_20_14  free_load_conservation_689  -1
    load_0_20_14  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_638  -20
    arc_0_20_15  connected_order_arc_639  -13
    arc_0_20_15  in_degree_691  1
    arc_0_20_15  out_degree_720  1
    arc_0_20_15  original_T_including_depot_unload_729  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_638  1
    load_0_20_15  free_load_conservation_695  -1
    load_0_20_15  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_640  -20
    arc_0_20_16  connected_order_arc_641  -13
    arc_0_20_16  in_degree_697  1
    arc_0_20_16  out_degree_720  1
    arc_0_20_16  original_T_including_depot_unload_729  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_640  1
    load_0_20_16  free_load_conservation_701  -1
    load_0_20_16  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_642  -20
    arc_0_20_17  connected_order_arc_643  -13
    arc_0_20_17  in_degree_703  1
    arc_0_20_17  out_degree_720  1
    arc_0_20_17  original_T_including_depot_unload_729  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_642  1
    load_0_20_17  free_load_conservation_707  -1
    load_0_20_17  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_644  -20
    arc_0_20_18  connected_order_arc_645  -13
    arc_0_20_18  in_degree_709  1
    arc_0_20_18  out_degree_720  1
    arc_0_20_18  original_T_including_depot_unload_729  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_644  1
    load_0_20_18  free_load_conservation_713  -1
    load_0_20_18  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_646  -20
    arc_0_20_19  connected_order_arc_647  -13
    arc_0_20_19  in_degree_715  1
    arc_0_20_19  out_degree_720  1
    arc_0_20_19  original_T_including_depot_unload_729  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_646  1
    load_0_20_19  free_load_conservation_719  -1
    load_0_20_19  free_load_conservation_725  1
    visit_1_5  out_degree_1021  -1
    visit_1_5  in_degree_1022  -1
    visit_1_5  order_active_lb_1023  -1
    visit_1_5  order_active_ub_1024  -12
    order_1_5  connected_order_arc_745  -1
    order_1_5  connected_order_arc_747  -1
    order_1_5  connected_order_arc_749  -1
    order_1_5  connected_order_arc_751  -1
    order_1_5  connected_order_arc_753  -1
    order_1_5  connected_order_arc_755  -1
    order_1_5  connected_order_arc_757  -1
    order_1_5  connected_order_arc_759  -1
    order_1_5  connected_order_arc_761  -1
    order_1_5  connected_order_arc_763  -1
    order_1_5  connected_order_arc_765  -1
    order_1_5  connected_order_arc_768  1
    order_1_5  connected_order_arc_791  1
    order_1_5  connected_order_arc_814  1
    order_1_5  connected_order_arc_837  1
    order_1_5  connected_order_arc_860  1
    order_1_5  connected_order_arc_883  1
    order_1_5  connected_order_arc_906  1
    order_1_5  connected_order_arc_929  1
    order_1_5  connected_order_arc_952  1
    order_1_5  connected_order_arc_975  1
    order_1_5  connected_order_arc_998  1
    order_1_5  order_active_lb_1023  1
    order_1_5  order_active_ub_1024  1
    order_1_5  fixed_segment_relative_order_1097  -1
    visit_1_6  out_degree_1028  -1
    visit_1_6  in_degree_1029  -1
    visit_1_6  order_active_lb_1030  -1
    visit_1_6  order_active_ub_1031  -12
    order_1_6  connected_order_arc_745  1
    order_1_6  connected_order_arc_768  -1
    order_1_6  connected_order_arc_770  -1
    order_1_6  connected_order_arc_772  -1
    order_1_6  connected_order_arc_774  -1
    order_1_6  connected_order_arc_776  -1
    order_1_6  connected_order_arc_778  -1
    order_1_6  connected_order_arc_780  -1
    order_1_6  connected_order_arc_782  -1
    order_1_6  connected_order_arc_784  -1
    order_1_6  connected_order_arc_786  -1
    order_1_6  connected_order_arc_788  -1
    order_1_6  connected_order_arc_793  1
    order_1_6  connected_order_arc_816  1
    order_1_6  connected_order_arc_839  1
    order_1_6  connected_order_arc_862  1
    order_1_6  connected_order_arc_885  1
    order_1_6  connected_order_arc_908  1
    order_1_6  connected_order_arc_931  1
    order_1_6  connected_order_arc_954  1
    order_1_6  connected_order_arc_977  1
    order_1_6  connected_order_arc_1000  1
    order_1_6  order_active_lb_1030  1
    order_1_6  order_active_ub_1031  1
    order_1_6  fixed_segment_relative_order_1097  1
    order_1_6  fixed_segment_relative_order_1098  -1
    visit_1_7  out_degree_1035  -1
    visit_1_7  in_degree_1036  -1
    visit_1_7  order_active_lb_1037  -1
    visit_1_7  order_active_ub_1038  -12
    order_1_7  connected_order_arc_747  1
    order_1_7  connected_order_arc_770  1
    order_1_7  connected_order_arc_791  -1
    order_1_7  connected_order_arc_793  -1
    order_1_7  connected_order_arc_795  -1
    order_1_7  connected_order_arc_797  -1
    order_1_7  connected_order_arc_799  -1
    order_1_7  connected_order_arc_801  -1
    order_1_7  connected_order_arc_803  -1
    order_1_7  connected_order_arc_805  -1
    order_1_7  connected_order_arc_807  -1
    order_1_7  connected_order_arc_809  -1
    order_1_7  connected_order_arc_811  -1
    order_1_7  connected_order_arc_818  1
    order_1_7  connected_order_arc_841  1
    order_1_7  connected_order_arc_864  1
    order_1_7  connected_order_arc_887  1
    order_1_7  connected_order_arc_910  1
    order_1_7  connected_order_arc_933  1
    order_1_7  connected_order_arc_956  1
    order_1_7  connected_order_arc_979  1
    order_1_7  connected_order_arc_1002  1
    order_1_7  order_active_lb_1037  1
    order_1_7  order_active_ub_1038  1
    order_1_7  fixed_segment_relative_order_1098  1
    order_1_7  fixed_segment_relative_order_1099  -1
    visit_1_8  out_degree_1042  -1
    visit_1_8  in_degree_1043  -1
    visit_1_8  order_active_lb_1044  -1
    visit_1_8  order_active_ub_1045  -12
    order_1_8  connected_order_arc_749  1
    order_1_8  connected_order_arc_772  1
    order_1_8  connected_order_arc_795  1
    order_1_8  connected_order_arc_814  -1
    order_1_8  connected_order_arc_816  -1
    order_1_8  connected_order_arc_818  -1
    order_1_8  connected_order_arc_820  -1
    order_1_8  connected_order_arc_822  -1
    order_1_8  connected_order_arc_824  -1
    order_1_8  connected_order_arc_826  -1
    order_1_8  connected_order_arc_828  -1
    order_1_8  connected_order_arc_830  -1
    order_1_8  connected_order_arc_832  -1
    order_1_8  connected_order_arc_834  -1
    order_1_8  connected_order_arc_843  1
    order_1_8  connected_order_arc_866  1
    order_1_8  connected_order_arc_889  1
    order_1_8  connected_order_arc_912  1
    order_1_8  connected_order_arc_935  1
    order_1_8  connected_order_arc_958  1
    order_1_8  connected_order_arc_981  1
    order_1_8  connected_order_arc_1004  1
    order_1_8  order_active_lb_1044  1
    order_1_8  order_active_ub_1045  1
    order_1_8  fixed_segment_relative_order_1099  1
    visit_1_13  out_degree_1049  -1
    visit_1_13  in_degree_1050  -1
    visit_1_13  order_active_lb_1051  -1
    visit_1_13  order_active_ub_1052  -12
    visit_1_13  service_visit_def_1053  -1
    order_1_13  connected_order_arc_751  1
    order_1_13  connected_order_arc_774  1
    order_1_13  connected_order_arc_797  1
    order_1_13  connected_order_arc_820  1
    order_1_13  connected_order_arc_837  -1
    order_1_13  connected_order_arc_839  -1
    order_1_13  connected_order_arc_841  -1
    order_1_13  connected_order_arc_843  -1
    order_1_13  connected_order_arc_845  -1
    order_1_13  connected_order_arc_847  -1
    order_1_13  connected_order_arc_849  -1
    order_1_13  connected_order_arc_851  -1
    order_1_13  connected_order_arc_853  -1
    order_1_13  connected_order_arc_855  -1
    order_1_13  connected_order_arc_857  -1
    order_1_13  connected_order_arc_868  1
    order_1_13  connected_order_arc_891  1
    order_1_13  connected_order_arc_914  1
    order_1_13  connected_order_arc_937  1
    order_1_13  connected_order_arc_960  1
    order_1_13  connected_order_arc_983  1
    order_1_13  connected_order_arc_1006  1
    order_1_13  order_active_lb_1051  1
    order_1_13  order_active_ub_1052  1
    visit_1_14  out_degree_1055  -1
    visit_1_14  in_degree_1056  -1
    visit_1_14  order_active_lb_1057  -1
    visit_1_14  order_active_ub_1058  -12
    visit_1_14  service_visit_def_1059  -1
    order_1_14  connected_order_arc_753  1
    order_1_14  connected_order_arc_776  1
    order_1_14  connected_order_arc_799  1
    order_1_14  connected_order_arc_822  1
    order_1_14  connected_order_arc_845  1
    order_1_14  connected_order_arc_860  -1
    order_1_14  connected_order_arc_862  -1
    order_1_14  connected_order_arc_864  -1
    order_1_14  connected_order_arc_866  -1
    order_1_14  connected_order_arc_868  -1
    order_1_14  connected_order_arc_870  -1
    order_1_14  connected_order_arc_872  -1
    order_1_14  connected_order_arc_874  -1
    order_1_14  connected_order_arc_876  -1
    order_1_14  connected_order_arc_878  -1
    order_1_14  connected_order_arc_880  -1
    order_1_14  connected_order_arc_893  1
    order_1_14  connected_order_arc_916  1
    order_1_14  connected_order_arc_939  1
    order_1_14  connected_order_arc_962  1
    order_1_14  connected_order_arc_985  1
    order_1_14  connected_order_arc_1008  1
    order_1_14  order_active_lb_1057  1
    order_1_14  order_active_ub_1058  1
    visit_1_15  out_degree_1061  -1
    visit_1_15  in_degree_1062  -1
    visit_1_15  order_active_lb_1063  -1
    visit_1_15  order_active_ub_1064  -12
    visit_1_15  service_visit_def_1065  -1
    order_1_15  connected_order_arc_755  1
    order_1_15  connected_order_arc_778  1
    order_1_15  connected_order_arc_801  1
    order_1_15  connected_order_arc_824  1
    order_1_15  connected_order_arc_847  1
    order_1_15  connected_order_arc_870  1
    order_1_15  connected_order_arc_883  -1
    order_1_15  connected_order_arc_885  -1
    order_1_15  connected_order_arc_887  -1
    order_1_15  connected_order_arc_889  -1
    order_1_15  connected_order_arc_891  -1
    order_1_15  connected_order_arc_893  -1
    order_1_15  connected_order_arc_895  -1
    order_1_15  connected_order_arc_897  -1
    order_1_15  connected_order_arc_899  -1
    order_1_15  connected_order_arc_901  -1
    order_1_15  connected_order_arc_903  -1
    order_1_15  connected_order_arc_918  1
    order_1_15  connected_order_arc_941  1
    order_1_15  connected_order_arc_964  1
    order_1_15  connected_order_arc_987  1
    order_1_15  connected_order_arc_1010  1
    order_1_15  order_active_lb_1063  1
    order_1_15  order_active_ub_1064  1
    visit_1_16  out_degree_1067  -1
    visit_1_16  in_degree_1068  -1
    visit_1_16  order_active_lb_1069  -1
    visit_1_16  order_active_ub_1070  -12
    visit_1_16  service_visit_def_1071  -1
    order_1_16  connected_order_arc_757  1
    order_1_16  connected_order_arc_780  1
    order_1_16  connected_order_arc_803  1
    order_1_16  connected_order_arc_826  1
    order_1_16  connected_order_arc_849  1
    order_1_16  connected_order_arc_872  1
    order_1_16  connected_order_arc_895  1
    order_1_16  connected_order_arc_906  -1
    order_1_16  connected_order_arc_908  -1
    order_1_16  connected_order_arc_910  -1
    order_1_16  connected_order_arc_912  -1
    order_1_16  connected_order_arc_914  -1
    order_1_16  connected_order_arc_916  -1
    order_1_16  connected_order_arc_918  -1
    order_1_16  connected_order_arc_920  -1
    order_1_16  connected_order_arc_922  -1
    order_1_16  connected_order_arc_924  -1
    order_1_16  connected_order_arc_926  -1
    order_1_16  connected_order_arc_943  1
    order_1_16  connected_order_arc_966  1
    order_1_16  connected_order_arc_989  1
    order_1_16  connected_order_arc_1012  1
    order_1_16  order_active_lb_1069  1
    order_1_16  order_active_ub_1070  1
    visit_1_17  out_degree_1073  -1
    visit_1_17  in_degree_1074  -1
    visit_1_17  order_active_lb_1075  -1
    visit_1_17  order_active_ub_1076  -12
    visit_1_17  service_visit_def_1077  -1
    order_1_17  connected_order_arc_759  1
    order_1_17  connected_order_arc_782  1
    order_1_17  connected_order_arc_805  1
    order_1_17  connected_order_arc_828  1
    order_1_17  connected_order_arc_851  1
    order_1_17  connected_order_arc_874  1
    order_1_17  connected_order_arc_897  1
    order_1_17  connected_order_arc_920  1
    order_1_17  connected_order_arc_929  -1
    order_1_17  connected_order_arc_931  -1
    order_1_17  connected_order_arc_933  -1
    order_1_17  connected_order_arc_935  -1
    order_1_17  connected_order_arc_937  -1
    order_1_17  connected_order_arc_939  -1
    order_1_17  connected_order_arc_941  -1
    order_1_17  connected_order_arc_943  -1
    order_1_17  connected_order_arc_945  -1
    order_1_17  connected_order_arc_947  -1
    order_1_17  connected_order_arc_949  -1
    order_1_17  connected_order_arc_968  1
    order_1_17  connected_order_arc_991  1
    order_1_17  connected_order_arc_1014  1
    order_1_17  order_active_lb_1075  1
    order_1_17  order_active_ub_1076  1
    visit_1_18  out_degree_1079  -1
    visit_1_18  in_degree_1080  -1
    visit_1_18  order_active_lb_1081  -1
    visit_1_18  order_active_ub_1082  -12
    visit_1_18  service_visit_def_1083  -1
    order_1_18  connected_order_arc_761  1
    order_1_18  connected_order_arc_784  1
    order_1_18  connected_order_arc_807  1
    order_1_18  connected_order_arc_830  1
    order_1_18  connected_order_arc_853  1
    order_1_18  connected_order_arc_876  1
    order_1_18  connected_order_arc_899  1
    order_1_18  connected_order_arc_922  1
    order_1_18  connected_order_arc_945  1
    order_1_18  connected_order_arc_952  -1
    order_1_18  connected_order_arc_954  -1
    order_1_18  connected_order_arc_956  -1
    order_1_18  connected_order_arc_958  -1
    order_1_18  connected_order_arc_960  -1
    order_1_18  connected_order_arc_962  -1
    order_1_18  connected_order_arc_964  -1
    order_1_18  connected_order_arc_966  -1
    order_1_18  connected_order_arc_968  -1
    order_1_18  connected_order_arc_970  -1
    order_1_18  connected_order_arc_972  -1
    order_1_18  connected_order_arc_993  1
    order_1_18  connected_order_arc_1016  1
    order_1_18  order_active_lb_1081  1
    order_1_18  order_active_ub_1082  1
    visit_1_19  out_degree_1085  -1
    visit_1_19  in_degree_1086  -1
    visit_1_19  order_active_lb_1087  -1
    visit_1_19  order_active_ub_1088  -12
    visit_1_19  service_visit_def_1089  -1
    order_1_19  connected_order_arc_763  1
    order_1_19  connected_order_arc_786  1
    order_1_19  connected_order_arc_809  1
    order_1_19  connected_order_arc_832  1
    order_1_19  connected_order_arc_855  1
    order_1_19  connected_order_arc_878  1
    order_1_19  connected_order_arc_901  1
    order_1_19  connected_order_arc_924  1
    order_1_19  connected_order_arc_947  1
    order_1_19  connected_order_arc_970  1
    order_1_19  connected_order_arc_975  -1
    order_1_19  connected_order_arc_977  -1
    order_1_19  connected_order_arc_979  -1
    order_1_19  connected_order_arc_981  -1
    order_1_19  connected_order_arc_983  -1
    order_1_19  connected_order_arc_985  -1
    order_1_19  connected_order_arc_987  -1
    order_1_19  connected_order_arc_989  -1
    order_1_19  connected_order_arc_991  -1
    order_1_19  connected_order_arc_993  -1
    order_1_19  connected_order_arc_995  -1
    order_1_19  connected_order_arc_1018  1
    order_1_19  order_active_lb_1087  1
    order_1_19  order_active_ub_1088  1
    visit_1_20  out_degree_1091  -1
    visit_1_20  in_degree_1092  -1
    visit_1_20  order_active_lb_1093  -1
    visit_1_20  order_active_ub_1094  -12
    visit_1_20  service_visit_def_1095  -1
    order_1_20  connected_order_arc_765  1
    order_1_20  connected_order_arc_788  1
    order_1_20  connected_order_arc_811  1
    order_1_20  connected_order_arc_834  1
    order_1_20  connected_order_arc_857  1
    order_1_20  connected_order_arc_880  1
    order_1_20  connected_order_arc_903  1
    order_1_20  connected_order_arc_926  1
    order_1_20  connected_order_arc_949  1
    order_1_20  connected_order_arc_972  1
    order_1_20  connected_order_arc_995  1
    order_1_20  connected_order_arc_998  -1
    order_1_20  connected_order_arc_1000  -1
    order_1_20  connected_order_arc_1002  -1
    order_1_20  connected_order_arc_1004  -1
    order_1_20  connected_order_arc_1006  -1
    order_1_20  connected_order_arc_1008  -1
    order_1_20  connected_order_arc_1010  -1
    order_1_20  connected_order_arc_1012  -1
    order_1_20  connected_order_arc_1014  -1
    order_1_20  connected_order_arc_1016  -1
    order_1_20  connected_order_arc_1018  -1
    order_1_20  order_active_lb_1093  1
    order_1_20  order_active_ub_1094  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_730  -25
    arc_1_0_0  depot_departure_or_bypass_1019  1
    arc_1_0_0  depot_return_or_bypass_1020  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_730  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_731  -25
    arc_1_0_5  depot_departure_or_bypass_1019  1
    arc_1_0_5  in_degree_1022  1
    arc_1_0_5  original_T_including_depot_unload_1100  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_731  1
    load_1_0_5  segment_load_conservation_1025  -1
    load_1_0_5  segment_prefix_lb_1026  1
    load_1_0_5  segment_prefix_ub_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_732  -25
    arc_1_0_6  depot_departure_or_bypass_1019  1
    arc_1_0_6  in_degree_1029  1
    arc_1_0_6  original_T_including_depot_unload_1100  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_732  1
    load_1_0_6  segment_load_conservation_1032  -1
    load_1_0_6  segment_prefix_lb_1033  1
    load_1_0_6  segment_prefix_ub_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_733  -25
    arc_1_0_7  depot_departure_or_bypass_1019  1
    arc_1_0_7  in_degree_1036  1
    arc_1_0_7  original_T_including_depot_unload_1100  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_733  1
    load_1_0_7  segment_load_conservation_1039  -1
    load_1_0_7  segment_prefix_lb_1040  1
    load_1_0_7  segment_prefix_ub_1041  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_734  -25
    arc_1_0_8  depot_departure_or_bypass_1019  1
    arc_1_0_8  in_degree_1043  1
    arc_1_0_8  original_T_including_depot_unload_1100  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_734  1
    load_1_0_8  segment_load_conservation_1046  -1
    load_1_0_8  segment_prefix_lb_1047  1
    load_1_0_8  segment_prefix_ub_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_735  -25
    arc_1_0_13  depot_departure_or_bypass_1019  1
    arc_1_0_13  in_degree_1050  1
    arc_1_0_13  original_T_including_depot_unload_1100  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_735  1
    load_1_0_13  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_736  -25
    arc_1_0_14  depot_departure_or_bypass_1019  1
    arc_1_0_14  in_degree_1056  1
    arc_1_0_14  original_T_including_depot_unload_1100  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_736  1
    load_1_0_14  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_737  -25
    arc_1_0_15  depot_departure_or_bypass_1019  1
    arc_1_0_15  in_degree_1062  1
    arc_1_0_15  original_T_including_depot_unload_1100  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_737  1
    load_1_0_15  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_738  -25
    arc_1_0_16  depot_departure_or_bypass_1019  1
    arc_1_0_16  in_degree_1068  1
    arc_1_0_16  original_T_including_depot_unload_1100  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_738  1
    load_1_0_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_739  -25
    arc_1_0_17  depot_departure_or_bypass_1019  1
    arc_1_0_17  in_degree_1074  1
    arc_1_0_17  original_T_including_depot_unload_1100  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_739  1
    load_1_0_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_740  -25
    arc_1_0_18  depot_departure_or_bypass_1019  1
    arc_1_0_18  in_degree_1080  1
    arc_1_0_18  original_T_including_depot_unload_1100  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_740  1
    load_1_0_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_741  -25
    arc_1_0_19  depot_departure_or_bypass_1019  1
    arc_1_0_19  in_degree_1086  1
    arc_1_0_19  original_T_including_depot_unload_1100  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_741  1
    load_1_0_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_742  -25
    arc_1_0_20  depot_departure_or_bypass_1019  1
    arc_1_0_20  in_degree_1092  1
    arc_1_0_20  original_T_including_depot_unload_1100  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_742  1
    load_1_0_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_743  -25
    arc_1_5_0  depot_return_or_bypass_1020  1
    arc_1_5_0  out_degree_1021  1
    arc_1_5_0  original_T_including_depot_unload_1100  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_743  1
    load_1_5_0  segment_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_744  -25
    arc_1_5_6  connected_order_arc_745  -13
    arc_1_5_6  out_degree_1021  1
    arc_1_5_6  in_degree_1029  1
    arc_1_5_6  original_T_including_depot_unload_1100  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_744  1
    load_1_5_6  segment_load_conservation_1025  1
    load_1_5_6  segment_load_conservation_1032  -1
    load_1_5_6  segment_prefix_lb_1033  1
    load_1_5_6  segment_prefix_ub_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_746  -25
    arc_1_5_7  connected_order_arc_747  -13
    arc_1_5_7  out_degree_1021  1
    arc_1_5_7  in_degree_1036  1
    arc_1_5_7  original_T_including_depot_unload_1100  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_746  1
    load_1_5_7  segment_load_conservation_1025  1
    load_1_5_7  segment_load_conservation_1039  -1
    load_1_5_7  segment_prefix_lb_1040  1
    load_1_5_7  segment_prefix_ub_1041  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_748  -25
    arc_1_5_8  connected_order_arc_749  -13
    arc_1_5_8  out_degree_1021  1
    arc_1_5_8  in_degree_1043  1
    arc_1_5_8  original_T_including_depot_unload_1100  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_748  1
    load_1_5_8  segment_load_conservation_1025  1
    load_1_5_8  segment_load_conservation_1046  -1
    load_1_5_8  segment_prefix_lb_1047  1
    load_1_5_8  segment_prefix_ub_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_750  -25
    arc_1_5_13  connected_order_arc_751  -13
    arc_1_5_13  out_degree_1021  1
    arc_1_5_13  in_degree_1050  1
    arc_1_5_13  original_T_including_depot_unload_1100  1.8021002410302701e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_750  1
    load_1_5_13  segment_load_conservation_1025  1
    load_1_5_13  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_752  -25
    arc_1_5_14  connected_order_arc_753  -13
    arc_1_5_14  out_degree_1021  1
    arc_1_5_14  in_degree_1056  1
    arc_1_5_14  original_T_including_depot_unload_1100  1.9888769270297350e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_752  1
    load_1_5_14  segment_load_conservation_1025  1
    load_1_5_14  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_754  -25
    arc_1_5_15  connected_order_arc_755  -13
    arc_1_5_15  out_degree_1021  1
    arc_1_5_15  in_degree_1062  1
    arc_1_5_15  original_T_including_depot_unload_1100  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_754  1
    load_1_5_15  segment_load_conservation_1025  1
    load_1_5_15  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_756  -25
    arc_1_5_16  connected_order_arc_757  -13
    arc_1_5_16  out_degree_1021  1
    arc_1_5_16  in_degree_1068  1
    arc_1_5_16  original_T_including_depot_unload_1100  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_756  1
    load_1_5_16  segment_load_conservation_1025  1
    load_1_5_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_758  -25
    arc_1_5_17  connected_order_arc_759  -13
    arc_1_5_17  out_degree_1021  1
    arc_1_5_17  in_degree_1074  1
    arc_1_5_17  original_T_including_depot_unload_1100  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_758  1
    load_1_5_17  segment_load_conservation_1025  1
    load_1_5_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_760  -25
    arc_1_5_18  connected_order_arc_761  -13
    arc_1_5_18  out_degree_1021  1
    arc_1_5_18  in_degree_1080  1
    arc_1_5_18  original_T_including_depot_unload_1100  1.4636929855741182e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_760  1
    load_1_5_18  segment_load_conservation_1025  1
    load_1_5_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_762  -25
    arc_1_5_19  connected_order_arc_763  -13
    arc_1_5_19  out_degree_1021  1
    arc_1_5_19  in_degree_1086  1
    arc_1_5_19  original_T_including_depot_unload_1100  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_762  1
    load_1_5_19  segment_load_conservation_1025  1
    load_1_5_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_20  arc_capacity_764  -25
    arc_1_5_20  connected_order_arc_765  -13
    arc_1_5_20  out_degree_1021  1
    arc_1_5_20  in_degree_1092  1
    arc_1_5_20  original_T_including_depot_unload_1100  1.9444044143793826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_20  arc_capacity_764  1
    load_1_5_20  segment_load_conservation_1025  1
    load_1_5_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_766  -25
    arc_1_6_0  depot_return_or_bypass_1020  1
    arc_1_6_0  out_degree_1028  1
    arc_1_6_0  original_T_including_depot_unload_1100  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_766  1
    load_1_6_0  segment_load_conservation_1032  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_767  -25
    arc_1_6_5  connected_order_arc_768  -13
    arc_1_6_5  in_degree_1022  1
    arc_1_6_5  out_degree_1028  1
    arc_1_6_5  original_T_including_depot_unload_1100  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_767  1
    load_1_6_5  segment_load_conservation_1025  -1
    load_1_6_5  segment_prefix_lb_1026  1
    load_1_6_5  segment_prefix_ub_1027  1
    load_1_6_5  segment_load_conservation_1032  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_769  -25
    arc_1_6_7  connected_order_arc_770  -13
    arc_1_6_7  out_degree_1028  1
    arc_1_6_7  in_degree_1036  1
    arc_1_6_7  original_T_including_depot_unload_1100  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_769  1
    load_1_6_7  segment_load_conservation_1032  1
    load_1_6_7  segment_load_conservation_1039  -1
    load_1_6_7  segment_prefix_lb_1040  1
    load_1_6_7  segment_prefix_ub_1041  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_771  -25
    arc_1_6_8  connected_order_arc_772  -13
    arc_1_6_8  out_degree_1028  1
    arc_1_6_8  in_degree_1043  1
    arc_1_6_8  original_T_including_depot_unload_1100  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_771  1
    load_1_6_8  segment_load_conservation_1032  1
    load_1_6_8  segment_load_conservation_1046  -1
    load_1_6_8  segment_prefix_lb_1047  1
    load_1_6_8  segment_prefix_ub_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_773  -25
    arc_1_6_13  connected_order_arc_774  -13
    arc_1_6_13  out_degree_1028  1
    arc_1_6_13  in_degree_1050  1
    arc_1_6_13  original_T_including_depot_unload_1100  2.8379597250568327e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_773  1
    load_1_6_13  segment_load_conservation_1032  1
    load_1_6_13  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_775  -25
    arc_1_6_14  connected_order_arc_776  -13
    arc_1_6_14  out_degree_1028  1
    arc_1_6_14  in_degree_1056  1
    arc_1_6_14  original_T_including_depot_unload_1100  2.9939628790517750e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_775  1
    load_1_6_14  segment_load_conservation_1032  1
    load_1_6_14  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_777  -25
    arc_1_6_15  connected_order_arc_778  -13
    arc_1_6_15  out_degree_1028  1
    arc_1_6_15  in_degree_1062  1
    arc_1_6_15  original_T_including_depot_unload_1100  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_777  1
    load_1_6_15  segment_load_conservation_1032  1
    load_1_6_15  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_779  -25
    arc_1_6_16  connected_order_arc_780  -13
    arc_1_6_16  out_degree_1028  1
    arc_1_6_16  in_degree_1068  1
    arc_1_6_16  original_T_including_depot_unload_1100  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_779  1
    load_1_6_16  segment_load_conservation_1032  1
    load_1_6_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_781  -25
    arc_1_6_17  connected_order_arc_782  -13
    arc_1_6_17  out_degree_1028  1
    arc_1_6_17  in_degree_1074  1
    arc_1_6_17  original_T_including_depot_unload_1100  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_781  1
    load_1_6_17  segment_load_conservation_1032  1
    load_1_6_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_783  -25
    arc_1_6_18  connected_order_arc_784  -13
    arc_1_6_18  out_degree_1028  1
    arc_1_6_18  in_degree_1080  1
    arc_1_6_18  original_T_including_depot_unload_1100  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_783  1
    load_1_6_18  segment_load_conservation_1032  1
    load_1_6_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_785  -25
    arc_1_6_19  connected_order_arc_786  -13
    arc_1_6_19  out_degree_1028  1
    arc_1_6_19  in_degree_1086  1
    arc_1_6_19  original_T_including_depot_unload_1100  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_785  1
    load_1_6_19  segment_load_conservation_1032  1
    load_1_6_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_787  -25
    arc_1_6_20  connected_order_arc_788  -13
    arc_1_6_20  out_degree_1028  1
    arc_1_6_20  in_degree_1092  1
    arc_1_6_20  original_T_including_depot_unload_1100  2.9105426006346024e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_787  1
    load_1_6_20  segment_load_conservation_1032  1
    load_1_6_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_789  -25
    arc_1_7_0  depot_return_or_bypass_1020  1
    arc_1_7_0  out_degree_1035  1
    arc_1_7_0  original_T_including_depot_unload_1100  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_789  1
    load_1_7_0  segment_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_790  -25
    arc_1_7_5  connected_order_arc_791  -13
    arc_1_7_5  in_degree_1022  1
    arc_1_7_5  out_degree_1035  1
    arc_1_7_5  original_T_including_depot_unload_1100  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_790  1
    load_1_7_5  segment_load_conservation_1025  -1
    load_1_7_5  segment_prefix_lb_1026  1
    load_1_7_5  segment_prefix_ub_1027  1
    load_1_7_5  segment_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_792  -25
    arc_1_7_6  connected_order_arc_793  -13
    arc_1_7_6  in_degree_1029  1
    arc_1_7_6  out_degree_1035  1
    arc_1_7_6  original_T_including_depot_unload_1100  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_792  1
    load_1_7_6  segment_load_conservation_1032  -1
    load_1_7_6  segment_prefix_lb_1033  1
    load_1_7_6  segment_prefix_ub_1034  1
    load_1_7_6  segment_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_794  -25
    arc_1_7_8  connected_order_arc_795  -13
    arc_1_7_8  out_degree_1035  1
    arc_1_7_8  in_degree_1043  1
    arc_1_7_8  original_T_including_depot_unload_1100  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_794  1
    load_1_7_8  segment_load_conservation_1039  1
    load_1_7_8  segment_load_conservation_1046  -1
    load_1_7_8  segment_prefix_lb_1047  1
    load_1_7_8  segment_prefix_ub_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_796  -25
    arc_1_7_13  connected_order_arc_797  -13
    arc_1_7_13  out_degree_1035  1
    arc_1_7_13  in_degree_1050  1
    arc_1_7_13  original_T_including_depot_unload_1100  1.9305399866194357e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_796  1
    load_1_7_13  segment_load_conservation_1039  1
    load_1_7_13  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_798  -25
    arc_1_7_14  connected_order_arc_799  -13
    arc_1_7_14  out_degree_1035  1
    arc_1_7_14  in_degree_1056  1
    arc_1_7_14  original_T_including_depot_unload_1100  2.0264134980919391e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_798  1
    load_1_7_14  segment_load_conservation_1039  1
    load_1_7_14  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_800  -25
    arc_1_7_15  connected_order_arc_801  -13
    arc_1_7_15  out_degree_1035  1
    arc_1_7_15  in_degree_1062  1
    arc_1_7_15  original_T_including_depot_unload_1100  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_800  1
    load_1_7_15  segment_load_conservation_1039  1
    load_1_7_15  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_802  -25
    arc_1_7_16  connected_order_arc_803  -13
    arc_1_7_16  out_degree_1035  1
    arc_1_7_16  in_degree_1068  1
    arc_1_7_16  original_T_including_depot_unload_1100  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_802  1
    load_1_7_16  segment_load_conservation_1039  1
    load_1_7_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_804  -25
    arc_1_7_17  connected_order_arc_805  -13
    arc_1_7_17  out_degree_1035  1
    arc_1_7_17  in_degree_1074  1
    arc_1_7_17  original_T_including_depot_unload_1100  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_804  1
    load_1_7_17  segment_load_conservation_1039  1
    load_1_7_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_806  -25
    arc_1_7_18  connected_order_arc_807  -13
    arc_1_7_18  out_degree_1035  1
    arc_1_7_18  in_degree_1080  1
    arc_1_7_18  original_T_including_depot_unload_1100  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_806  1
    load_1_7_18  segment_load_conservation_1039  1
    load_1_7_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_808  -25
    arc_1_7_19  connected_order_arc_809  -13
    arc_1_7_19  out_degree_1035  1
    arc_1_7_19  in_degree_1086  1
    arc_1_7_19  original_T_including_depot_unload_1100  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_808  1
    load_1_7_19  segment_load_conservation_1039  1
    load_1_7_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_810  -25
    arc_1_7_20  connected_order_arc_811  -13
    arc_1_7_20  out_degree_1035  1
    arc_1_7_20  in_degree_1092  1
    arc_1_7_20  original_T_including_depot_unload_1100  1.9370748198308336e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_810  1
    load_1_7_20  segment_load_conservation_1039  1
    load_1_7_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_812  -25
    arc_1_8_0  depot_return_or_bypass_1020  1
    arc_1_8_0  out_degree_1042  1
    arc_1_8_0  original_T_including_depot_unload_1100  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_812  1
    load_1_8_0  segment_load_conservation_1046  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_813  -25
    arc_1_8_5  connected_order_arc_814  -13
    arc_1_8_5  in_degree_1022  1
    arc_1_8_5  out_degree_1042  1
    arc_1_8_5  original_T_including_depot_unload_1100  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_813  1
    load_1_8_5  segment_load_conservation_1025  -1
    load_1_8_5  segment_prefix_lb_1026  1
    load_1_8_5  segment_prefix_ub_1027  1
    load_1_8_5  segment_load_conservation_1046  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_815  -25
    arc_1_8_6  connected_order_arc_816  -13
    arc_1_8_6  in_degree_1029  1
    arc_1_8_6  out_degree_1042  1
    arc_1_8_6  original_T_including_depot_unload_1100  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_815  1
    load_1_8_6  segment_load_conservation_1032  -1
    load_1_8_6  segment_prefix_lb_1033  1
    load_1_8_6  segment_prefix_ub_1034  1
    load_1_8_6  segment_load_conservation_1046  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_817  -25
    arc_1_8_7  connected_order_arc_818  -13
    arc_1_8_7  in_degree_1036  1
    arc_1_8_7  out_degree_1042  1
    arc_1_8_7  original_T_including_depot_unload_1100  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_817  1
    load_1_8_7  segment_load_conservation_1039  -1
    load_1_8_7  segment_prefix_lb_1040  1
    load_1_8_7  segment_prefix_ub_1041  1
    load_1_8_7  segment_load_conservation_1046  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_819  -25
    arc_1_8_13  connected_order_arc_820  -13
    arc_1_8_13  out_degree_1042  1
    arc_1_8_13  in_degree_1050  1
    arc_1_8_13  original_T_including_depot_unload_1100  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_819  1
    load_1_8_13  segment_load_conservation_1046  1
    load_1_8_13  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_821  -25
    arc_1_8_14  connected_order_arc_822  -13
    arc_1_8_14  out_degree_1042  1
    arc_1_8_14  in_degree_1056  1
    arc_1_8_14  original_T_including_depot_unload_1100  1.7203273996041773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_821  1
    load_1_8_14  segment_load_conservation_1046  1
    load_1_8_14  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_823  -25
    arc_1_8_15  connected_order_arc_824  -13
    arc_1_8_15  out_degree_1042  1
    arc_1_8_15  in_degree_1062  1
    arc_1_8_15  original_T_including_depot_unload_1100  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_823  1
    load_1_8_15  segment_load_conservation_1046  1
    load_1_8_15  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_825  -25
    arc_1_8_16  connected_order_arc_826  -13
    arc_1_8_16  out_degree_1042  1
    arc_1_8_16  in_degree_1068  1
    arc_1_8_16  original_T_including_depot_unload_1100  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_825  1
    load_1_8_16  segment_load_conservation_1046  1
    load_1_8_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_827  -25
    arc_1_8_17  connected_order_arc_828  -13
    arc_1_8_17  out_degree_1042  1
    arc_1_8_17  in_degree_1074  1
    arc_1_8_17  original_T_including_depot_unload_1100  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_827  1
    load_1_8_17  segment_load_conservation_1046  1
    load_1_8_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_829  -25
    arc_1_8_18  connected_order_arc_830  -13
    arc_1_8_18  out_degree_1042  1
    arc_1_8_18  in_degree_1080  1
    arc_1_8_18  original_T_including_depot_unload_1100  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_829  1
    load_1_8_18  segment_load_conservation_1046  1
    load_1_8_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_831  -25
    arc_1_8_19  connected_order_arc_832  -13
    arc_1_8_19  out_degree_1042  1
    arc_1_8_19  in_degree_1086  1
    arc_1_8_19  original_T_including_depot_unload_1100  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_831  1
    load_1_8_19  segment_load_conservation_1046  1
    load_1_8_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_833  -25
    arc_1_8_20  connected_order_arc_834  -13
    arc_1_8_20  out_degree_1042  1
    arc_1_8_20  in_degree_1092  1
    arc_1_8_20  original_T_including_depot_unload_1100  1.6359122202972637e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_833  1
    load_1_8_20  segment_load_conservation_1046  1
    load_1_8_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_835  -25
    arc_1_13_0  depot_return_or_bypass_1020  1
    arc_1_13_0  out_degree_1049  1
    arc_1_13_0  original_T_including_depot_unload_1100  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_835  1
    load_1_13_0  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_836  -25
    arc_1_13_5  connected_order_arc_837  -13
    arc_1_13_5  in_degree_1022  1
    arc_1_13_5  out_degree_1049  1
    arc_1_13_5  original_T_including_depot_unload_1100  1.8021002410302701e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_836  1
    load_1_13_5  segment_load_conservation_1025  -1
    load_1_13_5  segment_prefix_lb_1026  1
    load_1_13_5  segment_prefix_ub_1027  1
    load_1_13_5  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_838  -25
    arc_1_13_6  connected_order_arc_839  -13
    arc_1_13_6  in_degree_1029  1
    arc_1_13_6  out_degree_1049  1
    arc_1_13_6  original_T_including_depot_unload_1100  2.8379597250568327e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_838  1
    load_1_13_6  segment_load_conservation_1032  -1
    load_1_13_6  segment_prefix_lb_1033  1
    load_1_13_6  segment_prefix_ub_1034  1
    load_1_13_6  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_840  -25
    arc_1_13_7  connected_order_arc_841  -13
    arc_1_13_7  in_degree_1036  1
    arc_1_13_7  out_degree_1049  1
    arc_1_13_7  original_T_including_depot_unload_1100  1.9305399866194357e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_840  1
    load_1_13_7  segment_load_conservation_1039  -1
    load_1_13_7  segment_prefix_lb_1040  1
    load_1_13_7  segment_prefix_ub_1041  1
    load_1_13_7  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_842  -25
    arc_1_13_8  connected_order_arc_843  -13
    arc_1_13_8  in_degree_1043  1
    arc_1_13_8  out_degree_1049  1
    arc_1_13_8  original_T_including_depot_unload_1100  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_842  1
    load_1_13_8  segment_load_conservation_1046  -1
    load_1_13_8  segment_prefix_lb_1047  1
    load_1_13_8  segment_prefix_ub_1048  1
    load_1_13_8  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_844  -25
    arc_1_13_14  connected_order_arc_845  -13
    arc_1_13_14  out_degree_1049  1
    arc_1_13_14  in_degree_1056  1
    arc_1_13_14  original_T_including_depot_unload_1100  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_844  1
    load_1_13_14  free_load_conservation_1054  1
    load_1_13_14  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_846  -25
    arc_1_13_15  connected_order_arc_847  -13
    arc_1_13_15  out_degree_1049  1
    arc_1_13_15  in_degree_1062  1
    arc_1_13_15  original_T_including_depot_unload_1100  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_846  1
    load_1_13_15  free_load_conservation_1054  1
    load_1_13_15  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_848  -25
    arc_1_13_16  connected_order_arc_849  -13
    arc_1_13_16  out_degree_1049  1
    arc_1_13_16  in_degree_1068  1
    arc_1_13_16  original_T_including_depot_unload_1100  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_848  1
    load_1_13_16  free_load_conservation_1054  1
    load_1_13_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_850  -25
    arc_1_13_17  connected_order_arc_851  -13
    arc_1_13_17  out_degree_1049  1
    arc_1_13_17  in_degree_1074  1
    arc_1_13_17  original_T_including_depot_unload_1100  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_850  1
    load_1_13_17  free_load_conservation_1054  1
    load_1_13_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_852  -25
    arc_1_13_18  connected_order_arc_853  -13
    arc_1_13_18  out_degree_1049  1
    arc_1_13_18  in_degree_1080  1
    arc_1_13_18  original_T_including_depot_unload_1100  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_852  1
    load_1_13_18  free_load_conservation_1054  1
    load_1_13_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_854  -25
    arc_1_13_19  connected_order_arc_855  -13
    arc_1_13_19  out_degree_1049  1
    arc_1_13_19  in_degree_1086  1
    arc_1_13_19  original_T_including_depot_unload_1100  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_854  1
    load_1_13_19  free_load_conservation_1054  1
    load_1_13_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_856  -25
    arc_1_13_20  connected_order_arc_857  -13
    arc_1_13_20  out_degree_1049  1
    arc_1_13_20  in_degree_1092  1
    arc_1_13_20  original_T_including_depot_unload_1100  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_856  1
    load_1_13_20  free_load_conservation_1054  1
    load_1_13_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_858  -25
    arc_1_14_0  depot_return_or_bypass_1020  1
    arc_1_14_0  out_degree_1055  1
    arc_1_14_0  original_T_including_depot_unload_1100  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_858  1
    load_1_14_0  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_859  -25
    arc_1_14_5  connected_order_arc_860  -13
    arc_1_14_5  in_degree_1022  1
    arc_1_14_5  out_degree_1055  1
    arc_1_14_5  original_T_including_depot_unload_1100  1.9888769270297350e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_859  1
    load_1_14_5  segment_load_conservation_1025  -1
    load_1_14_5  segment_prefix_lb_1026  1
    load_1_14_5  segment_prefix_ub_1027  1
    load_1_14_5  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_861  -25
    arc_1_14_6  connected_order_arc_862  -13
    arc_1_14_6  in_degree_1029  1
    arc_1_14_6  out_degree_1055  1
    arc_1_14_6  original_T_including_depot_unload_1100  2.9939628790517750e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_861  1
    load_1_14_6  segment_load_conservation_1032  -1
    load_1_14_6  segment_prefix_lb_1033  1
    load_1_14_6  segment_prefix_ub_1034  1
    load_1_14_6  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_863  -25
    arc_1_14_7  connected_order_arc_864  -13
    arc_1_14_7  in_degree_1036  1
    arc_1_14_7  out_degree_1055  1
    arc_1_14_7  original_T_including_depot_unload_1100  2.0264134980919391e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_863  1
    load_1_14_7  segment_load_conservation_1039  -1
    load_1_14_7  segment_prefix_lb_1040  1
    load_1_14_7  segment_prefix_ub_1041  1
    load_1_14_7  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_865  -25
    arc_1_14_8  connected_order_arc_866  -13
    arc_1_14_8  in_degree_1043  1
    arc_1_14_8  out_degree_1055  1
    arc_1_14_8  original_T_including_depot_unload_1100  1.7203273996041773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_865  1
    load_1_14_8  segment_load_conservation_1046  -1
    load_1_14_8  segment_prefix_lb_1047  1
    load_1_14_8  segment_prefix_ub_1048  1
    load_1_14_8  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_867  -25
    arc_1_14_13  connected_order_arc_868  -13
    arc_1_14_13  in_degree_1050  1
    arc_1_14_13  out_degree_1055  1
    arc_1_14_13  original_T_including_depot_unload_1100  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_867  1
    load_1_14_13  free_load_conservation_1054  -1
    load_1_14_13  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_869  -25
    arc_1_14_15  connected_order_arc_870  -13
    arc_1_14_15  out_degree_1055  1
    arc_1_14_15  in_degree_1062  1
    arc_1_14_15  original_T_including_depot_unload_1100  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_869  1
    load_1_14_15  free_load_conservation_1060  1
    load_1_14_15  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_871  -25
    arc_1_14_16  connected_order_arc_872  -13
    arc_1_14_16  out_degree_1055  1
    arc_1_14_16  in_degree_1068  1
    arc_1_14_16  original_T_including_depot_unload_1100  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_871  1
    load_1_14_16  free_load_conservation_1060  1
    load_1_14_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_873  -25
    arc_1_14_17  connected_order_arc_874  -13
    arc_1_14_17  out_degree_1055  1
    arc_1_14_17  in_degree_1074  1
    arc_1_14_17  original_T_including_depot_unload_1100  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_873  1
    load_1_14_17  free_load_conservation_1060  1
    load_1_14_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_875  -25
    arc_1_14_18  connected_order_arc_876  -13
    arc_1_14_18  out_degree_1055  1
    arc_1_14_18  in_degree_1080  1
    arc_1_14_18  original_T_including_depot_unload_1100  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_875  1
    load_1_14_18  free_load_conservation_1060  1
    load_1_14_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_877  -25
    arc_1_14_19  connected_order_arc_878  -13
    arc_1_14_19  out_degree_1055  1
    arc_1_14_19  in_degree_1086  1
    arc_1_14_19  original_T_including_depot_unload_1100  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_877  1
    load_1_14_19  free_load_conservation_1060  1
    load_1_14_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_879  -25
    arc_1_14_20  connected_order_arc_880  -13
    arc_1_14_20  out_degree_1055  1
    arc_1_14_20  in_degree_1092  1
    arc_1_14_20  original_T_including_depot_unload_1100  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_879  1
    load_1_14_20  free_load_conservation_1060  1
    load_1_14_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_881  -25
    arc_1_15_0  depot_return_or_bypass_1020  1
    arc_1_15_0  out_degree_1061  1
    arc_1_15_0  original_T_including_depot_unload_1100  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_881  1
    load_1_15_0  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_882  -25
    arc_1_15_5  connected_order_arc_883  -13
    arc_1_15_5  in_degree_1022  1
    arc_1_15_5  out_degree_1061  1
    arc_1_15_5  original_T_including_depot_unload_1100  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_882  1
    load_1_15_5  segment_load_conservation_1025  -1
    load_1_15_5  segment_prefix_lb_1026  1
    load_1_15_5  segment_prefix_ub_1027  1
    load_1_15_5  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_884  -25
    arc_1_15_6  connected_order_arc_885  -13
    arc_1_15_6  in_degree_1029  1
    arc_1_15_6  out_degree_1061  1
    arc_1_15_6  original_T_including_depot_unload_1100  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_884  1
    load_1_15_6  segment_load_conservation_1032  -1
    load_1_15_6  segment_prefix_lb_1033  1
    load_1_15_6  segment_prefix_ub_1034  1
    load_1_15_6  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_886  -25
    arc_1_15_7  connected_order_arc_887  -13
    arc_1_15_7  in_degree_1036  1
    arc_1_15_7  out_degree_1061  1
    arc_1_15_7  original_T_including_depot_unload_1100  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_886  1
    load_1_15_7  segment_load_conservation_1039  -1
    load_1_15_7  segment_prefix_lb_1040  1
    load_1_15_7  segment_prefix_ub_1041  1
    load_1_15_7  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_888  -25
    arc_1_15_8  connected_order_arc_889  -13
    arc_1_15_8  in_degree_1043  1
    arc_1_15_8  out_degree_1061  1
    arc_1_15_8  original_T_including_depot_unload_1100  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_888  1
    load_1_15_8  segment_load_conservation_1046  -1
    load_1_15_8  segment_prefix_lb_1047  1
    load_1_15_8  segment_prefix_ub_1048  1
    load_1_15_8  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_890  -25
    arc_1_15_13  connected_order_arc_891  -13
    arc_1_15_13  in_degree_1050  1
    arc_1_15_13  out_degree_1061  1
    arc_1_15_13  original_T_including_depot_unload_1100  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_890  1
    load_1_15_13  free_load_conservation_1054  -1
    load_1_15_13  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_892  -25
    arc_1_15_14  connected_order_arc_893  -13
    arc_1_15_14  in_degree_1056  1
    arc_1_15_14  out_degree_1061  1
    arc_1_15_14  original_T_including_depot_unload_1100  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_892  1
    load_1_15_14  free_load_conservation_1060  -1
    load_1_15_14  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_894  -25
    arc_1_15_16  connected_order_arc_895  -13
    arc_1_15_16  out_degree_1061  1
    arc_1_15_16  in_degree_1068  1
    arc_1_15_16  original_T_including_depot_unload_1100  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_894  1
    load_1_15_16  free_load_conservation_1066  1
    load_1_15_16  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_896  -25
    arc_1_15_17  connected_order_arc_897  -13
    arc_1_15_17  out_degree_1061  1
    arc_1_15_17  in_degree_1074  1
    arc_1_15_17  original_T_including_depot_unload_1100  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_896  1
    load_1_15_17  free_load_conservation_1066  1
    load_1_15_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_898  -25
    arc_1_15_18  connected_order_arc_899  -13
    arc_1_15_18  out_degree_1061  1
    arc_1_15_18  in_degree_1080  1
    arc_1_15_18  original_T_including_depot_unload_1100  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_898  1
    load_1_15_18  free_load_conservation_1066  1
    load_1_15_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_900  -25
    arc_1_15_19  connected_order_arc_901  -13
    arc_1_15_19  out_degree_1061  1
    arc_1_15_19  in_degree_1086  1
    arc_1_15_19  original_T_including_depot_unload_1100  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_900  1
    load_1_15_19  free_load_conservation_1066  1
    load_1_15_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_902  -25
    arc_1_15_20  connected_order_arc_903  -13
    arc_1_15_20  out_degree_1061  1
    arc_1_15_20  in_degree_1092  1
    arc_1_15_20  original_T_including_depot_unload_1100  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_902  1
    load_1_15_20  free_load_conservation_1066  1
    load_1_15_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_904  -25
    arc_1_16_0  depot_return_or_bypass_1020  1
    arc_1_16_0  out_degree_1067  1
    arc_1_16_0  original_T_including_depot_unload_1100  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_904  1
    load_1_16_0  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_905  -25
    arc_1_16_5  connected_order_arc_906  -13
    arc_1_16_5  in_degree_1022  1
    arc_1_16_5  out_degree_1067  1
    arc_1_16_5  original_T_including_depot_unload_1100  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_905  1
    load_1_16_5  segment_load_conservation_1025  -1
    load_1_16_5  segment_prefix_lb_1026  1
    load_1_16_5  segment_prefix_ub_1027  1
    load_1_16_5  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_907  -25
    arc_1_16_6  connected_order_arc_908  -13
    arc_1_16_6  in_degree_1029  1
    arc_1_16_6  out_degree_1067  1
    arc_1_16_6  original_T_including_depot_unload_1100  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_907  1
    load_1_16_6  segment_load_conservation_1032  -1
    load_1_16_6  segment_prefix_lb_1033  1
    load_1_16_6  segment_prefix_ub_1034  1
    load_1_16_6  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_909  -25
    arc_1_16_7  connected_order_arc_910  -13
    arc_1_16_7  in_degree_1036  1
    arc_1_16_7  out_degree_1067  1
    arc_1_16_7  original_T_including_depot_unload_1100  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_909  1
    load_1_16_7  segment_load_conservation_1039  -1
    load_1_16_7  segment_prefix_lb_1040  1
    load_1_16_7  segment_prefix_ub_1041  1
    load_1_16_7  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_911  -25
    arc_1_16_8  connected_order_arc_912  -13
    arc_1_16_8  in_degree_1043  1
    arc_1_16_8  out_degree_1067  1
    arc_1_16_8  original_T_including_depot_unload_1100  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_911  1
    load_1_16_8  segment_load_conservation_1046  -1
    load_1_16_8  segment_prefix_lb_1047  1
    load_1_16_8  segment_prefix_ub_1048  1
    load_1_16_8  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_913  -25
    arc_1_16_13  connected_order_arc_914  -13
    arc_1_16_13  in_degree_1050  1
    arc_1_16_13  out_degree_1067  1
    arc_1_16_13  original_T_including_depot_unload_1100  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_913  1
    load_1_16_13  free_load_conservation_1054  -1
    load_1_16_13  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_915  -25
    arc_1_16_14  connected_order_arc_916  -13
    arc_1_16_14  in_degree_1056  1
    arc_1_16_14  out_degree_1067  1
    arc_1_16_14  original_T_including_depot_unload_1100  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_915  1
    load_1_16_14  free_load_conservation_1060  -1
    load_1_16_14  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_917  -25
    arc_1_16_15  connected_order_arc_918  -13
    arc_1_16_15  in_degree_1062  1
    arc_1_16_15  out_degree_1067  1
    arc_1_16_15  original_T_including_depot_unload_1100  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_917  1
    load_1_16_15  free_load_conservation_1066  -1
    load_1_16_15  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_919  -25
    arc_1_16_17  connected_order_arc_920  -13
    arc_1_16_17  out_degree_1067  1
    arc_1_16_17  in_degree_1074  1
    arc_1_16_17  original_T_including_depot_unload_1100  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_919  1
    load_1_16_17  free_load_conservation_1072  1
    load_1_16_17  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_921  -25
    arc_1_16_18  connected_order_arc_922  -13
    arc_1_16_18  out_degree_1067  1
    arc_1_16_18  in_degree_1080  1
    arc_1_16_18  original_T_including_depot_unload_1100  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_921  1
    load_1_16_18  free_load_conservation_1072  1
    load_1_16_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_923  -25
    arc_1_16_19  connected_order_arc_924  -13
    arc_1_16_19  out_degree_1067  1
    arc_1_16_19  in_degree_1086  1
    arc_1_16_19  original_T_including_depot_unload_1100  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_923  1
    load_1_16_19  free_load_conservation_1072  1
    load_1_16_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_925  -25
    arc_1_16_20  connected_order_arc_926  -13
    arc_1_16_20  out_degree_1067  1
    arc_1_16_20  in_degree_1092  1
    arc_1_16_20  original_T_including_depot_unload_1100  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_925  1
    load_1_16_20  free_load_conservation_1072  1
    load_1_16_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_927  -25
    arc_1_17_0  depot_return_or_bypass_1020  1
    arc_1_17_0  out_degree_1073  1
    arc_1_17_0  original_T_including_depot_unload_1100  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_927  1
    load_1_17_0  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_928  -25
    arc_1_17_5  connected_order_arc_929  -13
    arc_1_17_5  in_degree_1022  1
    arc_1_17_5  out_degree_1073  1
    arc_1_17_5  original_T_including_depot_unload_1100  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_928  1
    load_1_17_5  segment_load_conservation_1025  -1
    load_1_17_5  segment_prefix_lb_1026  1
    load_1_17_5  segment_prefix_ub_1027  1
    load_1_17_5  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_930  -25
    arc_1_17_6  connected_order_arc_931  -13
    arc_1_17_6  in_degree_1029  1
    arc_1_17_6  out_degree_1073  1
    arc_1_17_6  original_T_including_depot_unload_1100  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_930  1
    load_1_17_6  segment_load_conservation_1032  -1
    load_1_17_6  segment_prefix_lb_1033  1
    load_1_17_6  segment_prefix_ub_1034  1
    load_1_17_6  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_932  -25
    arc_1_17_7  connected_order_arc_933  -13
    arc_1_17_7  in_degree_1036  1
    arc_1_17_7  out_degree_1073  1
    arc_1_17_7  original_T_including_depot_unload_1100  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_932  1
    load_1_17_7  segment_load_conservation_1039  -1
    load_1_17_7  segment_prefix_lb_1040  1
    load_1_17_7  segment_prefix_ub_1041  1
    load_1_17_7  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_934  -25
    arc_1_17_8  connected_order_arc_935  -13
    arc_1_17_8  in_degree_1043  1
    arc_1_17_8  out_degree_1073  1
    arc_1_17_8  original_T_including_depot_unload_1100  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_934  1
    load_1_17_8  segment_load_conservation_1046  -1
    load_1_17_8  segment_prefix_lb_1047  1
    load_1_17_8  segment_prefix_ub_1048  1
    load_1_17_8  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_936  -25
    arc_1_17_13  connected_order_arc_937  -13
    arc_1_17_13  in_degree_1050  1
    arc_1_17_13  out_degree_1073  1
    arc_1_17_13  original_T_including_depot_unload_1100  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_936  1
    load_1_17_13  free_load_conservation_1054  -1
    load_1_17_13  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_938  -25
    arc_1_17_14  connected_order_arc_939  -13
    arc_1_17_14  in_degree_1056  1
    arc_1_17_14  out_degree_1073  1
    arc_1_17_14  original_T_including_depot_unload_1100  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_938  1
    load_1_17_14  free_load_conservation_1060  -1
    load_1_17_14  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_940  -25
    arc_1_17_15  connected_order_arc_941  -13
    arc_1_17_15  in_degree_1062  1
    arc_1_17_15  out_degree_1073  1
    arc_1_17_15  original_T_including_depot_unload_1100  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_940  1
    load_1_17_15  free_load_conservation_1066  -1
    load_1_17_15  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_942  -25
    arc_1_17_16  connected_order_arc_943  -13
    arc_1_17_16  in_degree_1068  1
    arc_1_17_16  out_degree_1073  1
    arc_1_17_16  original_T_including_depot_unload_1100  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_942  1
    load_1_17_16  free_load_conservation_1072  -1
    load_1_17_16  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_944  -25
    arc_1_17_18  connected_order_arc_945  -13
    arc_1_17_18  out_degree_1073  1
    arc_1_17_18  in_degree_1080  1
    arc_1_17_18  original_T_including_depot_unload_1100  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_944  1
    load_1_17_18  free_load_conservation_1078  1
    load_1_17_18  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_946  -25
    arc_1_17_19  connected_order_arc_947  -13
    arc_1_17_19  out_degree_1073  1
    arc_1_17_19  in_degree_1086  1
    arc_1_17_19  original_T_including_depot_unload_1100  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_946  1
    load_1_17_19  free_load_conservation_1078  1
    load_1_17_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_948  -25
    arc_1_17_20  connected_order_arc_949  -13
    arc_1_17_20  out_degree_1073  1
    arc_1_17_20  in_degree_1092  1
    arc_1_17_20  original_T_including_depot_unload_1100  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_948  1
    load_1_17_20  free_load_conservation_1078  1
    load_1_17_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_950  -25
    arc_1_18_0  depot_return_or_bypass_1020  1
    arc_1_18_0  out_degree_1079  1
    arc_1_18_0  original_T_including_depot_unload_1100  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_950  1
    load_1_18_0  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_951  -25
    arc_1_18_5  connected_order_arc_952  -13
    arc_1_18_5  in_degree_1022  1
    arc_1_18_5  out_degree_1079  1
    arc_1_18_5  original_T_including_depot_unload_1100  1.4636929855741182e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_951  1
    load_1_18_5  segment_load_conservation_1025  -1
    load_1_18_5  segment_prefix_lb_1026  1
    load_1_18_5  segment_prefix_ub_1027  1
    load_1_18_5  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_953  -25
    arc_1_18_6  connected_order_arc_954  -13
    arc_1_18_6  in_degree_1029  1
    arc_1_18_6  out_degree_1079  1
    arc_1_18_6  original_T_including_depot_unload_1100  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_953  1
    load_1_18_6  segment_load_conservation_1032  -1
    load_1_18_6  segment_prefix_lb_1033  1
    load_1_18_6  segment_prefix_ub_1034  1
    load_1_18_6  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_955  -25
    arc_1_18_7  connected_order_arc_956  -13
    arc_1_18_7  in_degree_1036  1
    arc_1_18_7  out_degree_1079  1
    arc_1_18_7  original_T_including_depot_unload_1100  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_955  1
    load_1_18_7  segment_load_conservation_1039  -1
    load_1_18_7  segment_prefix_lb_1040  1
    load_1_18_7  segment_prefix_ub_1041  1
    load_1_18_7  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_957  -25
    arc_1_18_8  connected_order_arc_958  -13
    arc_1_18_8  in_degree_1043  1
    arc_1_18_8  out_degree_1079  1
    arc_1_18_8  original_T_including_depot_unload_1100  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_957  1
    load_1_18_8  segment_load_conservation_1046  -1
    load_1_18_8  segment_prefix_lb_1047  1
    load_1_18_8  segment_prefix_ub_1048  1
    load_1_18_8  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_959  -25
    arc_1_18_13  connected_order_arc_960  -13
    arc_1_18_13  in_degree_1050  1
    arc_1_18_13  out_degree_1079  1
    arc_1_18_13  original_T_including_depot_unload_1100  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_959  1
    load_1_18_13  free_load_conservation_1054  -1
    load_1_18_13  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_961  -25
    arc_1_18_14  connected_order_arc_962  -13
    arc_1_18_14  in_degree_1056  1
    arc_1_18_14  out_degree_1079  1
    arc_1_18_14  original_T_including_depot_unload_1100  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_961  1
    load_1_18_14  free_load_conservation_1060  -1
    load_1_18_14  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_963  -25
    arc_1_18_15  connected_order_arc_964  -13
    arc_1_18_15  in_degree_1062  1
    arc_1_18_15  out_degree_1079  1
    arc_1_18_15  original_T_including_depot_unload_1100  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_963  1
    load_1_18_15  free_load_conservation_1066  -1
    load_1_18_15  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_965  -25
    arc_1_18_16  connected_order_arc_966  -13
    arc_1_18_16  in_degree_1068  1
    arc_1_18_16  out_degree_1079  1
    arc_1_18_16  original_T_including_depot_unload_1100  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_965  1
    load_1_18_16  free_load_conservation_1072  -1
    load_1_18_16  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_967  -25
    arc_1_18_17  connected_order_arc_968  -13
    arc_1_18_17  in_degree_1074  1
    arc_1_18_17  out_degree_1079  1
    arc_1_18_17  original_T_including_depot_unload_1100  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_967  1
    load_1_18_17  free_load_conservation_1078  -1
    load_1_18_17  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_969  -25
    arc_1_18_19  connected_order_arc_970  -13
    arc_1_18_19  out_degree_1079  1
    arc_1_18_19  in_degree_1086  1
    arc_1_18_19  original_T_including_depot_unload_1100  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_969  1
    load_1_18_19  free_load_conservation_1084  1
    load_1_18_19  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_971  -25
    arc_1_18_20  connected_order_arc_972  -13
    arc_1_18_20  out_degree_1079  1
    arc_1_18_20  in_degree_1092  1
    arc_1_18_20  original_T_including_depot_unload_1100  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_971  1
    load_1_18_20  free_load_conservation_1084  1
    load_1_18_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_973  -25
    arc_1_19_0  depot_return_or_bypass_1020  1
    arc_1_19_0  out_degree_1085  1
    arc_1_19_0  original_T_including_depot_unload_1100  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_973  1
    load_1_19_0  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_974  -25
    arc_1_19_5  connected_order_arc_975  -13
    arc_1_19_5  in_degree_1022  1
    arc_1_19_5  out_degree_1085  1
    arc_1_19_5  original_T_including_depot_unload_1100  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_974  1
    load_1_19_5  segment_load_conservation_1025  -1
    load_1_19_5  segment_prefix_lb_1026  1
    load_1_19_5  segment_prefix_ub_1027  1
    load_1_19_5  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_976  -25
    arc_1_19_6  connected_order_arc_977  -13
    arc_1_19_6  in_degree_1029  1
    arc_1_19_6  out_degree_1085  1
    arc_1_19_6  original_T_including_depot_unload_1100  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_976  1
    load_1_19_6  segment_load_conservation_1032  -1
    load_1_19_6  segment_prefix_lb_1033  1
    load_1_19_6  segment_prefix_ub_1034  1
    load_1_19_6  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_978  -25
    arc_1_19_7  connected_order_arc_979  -13
    arc_1_19_7  in_degree_1036  1
    arc_1_19_7  out_degree_1085  1
    arc_1_19_7  original_T_including_depot_unload_1100  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_978  1
    load_1_19_7  segment_load_conservation_1039  -1
    load_1_19_7  segment_prefix_lb_1040  1
    load_1_19_7  segment_prefix_ub_1041  1
    load_1_19_7  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_980  -25
    arc_1_19_8  connected_order_arc_981  -13
    arc_1_19_8  in_degree_1043  1
    arc_1_19_8  out_degree_1085  1
    arc_1_19_8  original_T_including_depot_unload_1100  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_980  1
    load_1_19_8  segment_load_conservation_1046  -1
    load_1_19_8  segment_prefix_lb_1047  1
    load_1_19_8  segment_prefix_ub_1048  1
    load_1_19_8  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_982  -25
    arc_1_19_13  connected_order_arc_983  -13
    arc_1_19_13  in_degree_1050  1
    arc_1_19_13  out_degree_1085  1
    arc_1_19_13  original_T_including_depot_unload_1100  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_982  1
    load_1_19_13  free_load_conservation_1054  -1
    load_1_19_13  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_984  -25
    arc_1_19_14  connected_order_arc_985  -13
    arc_1_19_14  in_degree_1056  1
    arc_1_19_14  out_degree_1085  1
    arc_1_19_14  original_T_including_depot_unload_1100  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_984  1
    load_1_19_14  free_load_conservation_1060  -1
    load_1_19_14  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_986  -25
    arc_1_19_15  connected_order_arc_987  -13
    arc_1_19_15  in_degree_1062  1
    arc_1_19_15  out_degree_1085  1
    arc_1_19_15  original_T_including_depot_unload_1100  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_986  1
    load_1_19_15  free_load_conservation_1066  -1
    load_1_19_15  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_988  -25
    arc_1_19_16  connected_order_arc_989  -13
    arc_1_19_16  in_degree_1068  1
    arc_1_19_16  out_degree_1085  1
    arc_1_19_16  original_T_including_depot_unload_1100  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_988  1
    load_1_19_16  free_load_conservation_1072  -1
    load_1_19_16  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_990  -25
    arc_1_19_17  connected_order_arc_991  -13
    arc_1_19_17  in_degree_1074  1
    arc_1_19_17  out_degree_1085  1
    arc_1_19_17  original_T_including_depot_unload_1100  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_990  1
    load_1_19_17  free_load_conservation_1078  -1
    load_1_19_17  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_992  -25
    arc_1_19_18  connected_order_arc_993  -13
    arc_1_19_18  in_degree_1080  1
    arc_1_19_18  out_degree_1085  1
    arc_1_19_18  original_T_including_depot_unload_1100  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_992  1
    load_1_19_18  free_load_conservation_1084  -1
    load_1_19_18  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_994  -25
    arc_1_19_20  connected_order_arc_995  -13
    arc_1_19_20  out_degree_1085  1
    arc_1_19_20  in_degree_1092  1
    arc_1_19_20  original_T_including_depot_unload_1100  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_994  1
    load_1_19_20  free_load_conservation_1090  1
    load_1_19_20  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_996  -25
    arc_1_20_0  depot_return_or_bypass_1020  1
    arc_1_20_0  out_degree_1091  1
    arc_1_20_0  original_T_including_depot_unload_1100  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_996  1
    load_1_20_0  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_5  arc_capacity_997  -25
    arc_1_20_5  connected_order_arc_998  -13
    arc_1_20_5  in_degree_1022  1
    arc_1_20_5  out_degree_1091  1
    arc_1_20_5  original_T_including_depot_unload_1100  1.9444044143793826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_5  arc_capacity_997  1
    load_1_20_5  segment_load_conservation_1025  -1
    load_1_20_5  segment_prefix_lb_1026  1
    load_1_20_5  segment_prefix_ub_1027  1
    load_1_20_5  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_999  -25
    arc_1_20_6  connected_order_arc_1000  -13
    arc_1_20_6  in_degree_1029  1
    arc_1_20_6  out_degree_1091  1
    arc_1_20_6  original_T_including_depot_unload_1100  2.9105426006346024e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_999  1
    load_1_20_6  segment_load_conservation_1032  -1
    load_1_20_6  segment_prefix_lb_1033  1
    load_1_20_6  segment_prefix_ub_1034  1
    load_1_20_6  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1001  -25
    arc_1_20_7  connected_order_arc_1002  -13
    arc_1_20_7  in_degree_1036  1
    arc_1_20_7  out_degree_1091  1
    arc_1_20_7  original_T_including_depot_unload_1100  1.9370748198308336e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1001  1
    load_1_20_7  segment_load_conservation_1039  -1
    load_1_20_7  segment_prefix_lb_1040  1
    load_1_20_7  segment_prefix_ub_1041  1
    load_1_20_7  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1003  -25
    arc_1_20_8  connected_order_arc_1004  -13
    arc_1_20_8  in_degree_1043  1
    arc_1_20_8  out_degree_1091  1
    arc_1_20_8  original_T_including_depot_unload_1100  1.6359122202972637e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1003  1
    load_1_20_8  segment_load_conservation_1046  -1
    load_1_20_8  segment_prefix_lb_1047  1
    load_1_20_8  segment_prefix_ub_1048  1
    load_1_20_8  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1005  -25
    arc_1_20_13  connected_order_arc_1006  -13
    arc_1_20_13  in_degree_1050  1
    arc_1_20_13  out_degree_1091  1
    arc_1_20_13  original_T_including_depot_unload_1100  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1005  1
    load_1_20_13  free_load_conservation_1054  -1
    load_1_20_13  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1007  -25
    arc_1_20_14  connected_order_arc_1008  -13
    arc_1_20_14  in_degree_1056  1
    arc_1_20_14  out_degree_1091  1
    arc_1_20_14  original_T_including_depot_unload_1100  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1007  1
    load_1_20_14  free_load_conservation_1060  -1
    load_1_20_14  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1009  -25
    arc_1_20_15  connected_order_arc_1010  -13
    arc_1_20_15  in_degree_1062  1
    arc_1_20_15  out_degree_1091  1
    arc_1_20_15  original_T_including_depot_unload_1100  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1009  1
    load_1_20_15  free_load_conservation_1066  -1
    load_1_20_15  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1011  -25
    arc_1_20_16  connected_order_arc_1012  -13
    arc_1_20_16  in_degree_1068  1
    arc_1_20_16  out_degree_1091  1
    arc_1_20_16  original_T_including_depot_unload_1100  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1011  1
    load_1_20_16  free_load_conservation_1072  -1
    load_1_20_16  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1013  -25
    arc_1_20_17  connected_order_arc_1014  -13
    arc_1_20_17  in_degree_1074  1
    arc_1_20_17  out_degree_1091  1
    arc_1_20_17  original_T_including_depot_unload_1100  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1013  1
    load_1_20_17  free_load_conservation_1078  -1
    load_1_20_17  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1015  -25
    arc_1_20_18  connected_order_arc_1016  -13
    arc_1_20_18  in_degree_1080  1
    arc_1_20_18  out_degree_1091  1
    arc_1_20_18  original_T_including_depot_unload_1100  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1015  1
    load_1_20_18  free_load_conservation_1084  -1
    load_1_20_18  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1017  -25
    arc_1_20_19  connected_order_arc_1018  -13
    arc_1_20_19  in_degree_1086  1
    arc_1_20_19  out_degree_1091  1
    arc_1_20_19  original_T_including_depot_unload_1100  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1017  1
    load_1_20_19  free_load_conservation_1090  -1
    load_1_20_19  free_load_conservation_1096  1
    visit_2_9  out_degree_1392  -1
    visit_2_9  in_degree_1393  -1
    visit_2_9  order_active_lb_1394  -1
    visit_2_9  order_active_ub_1395  -12
    order_2_9  connected_order_arc_1116  -1
    order_2_9  connected_order_arc_1118  -1
    order_2_9  connected_order_arc_1120  -1
    order_2_9  connected_order_arc_1122  -1
    order_2_9  connected_order_arc_1124  -1
    order_2_9  connected_order_arc_1126  -1
    order_2_9  connected_order_arc_1128  -1
    order_2_9  connected_order_arc_1130  -1
    order_2_9  connected_order_arc_1132  -1
    order_2_9  connected_order_arc_1134  -1
    order_2_9  connected_order_arc_1136  -1
    order_2_9  connected_order_arc_1139  1
    order_2_9  connected_order_arc_1162  1
    order_2_9  connected_order_arc_1185  1
    order_2_9  connected_order_arc_1208  1
    order_2_9  connected_order_arc_1231  1
    order_2_9  connected_order_arc_1254  1
    order_2_9  connected_order_arc_1277  1
    order_2_9  connected_order_arc_1300  1
    order_2_9  connected_order_arc_1323  1
    order_2_9  connected_order_arc_1346  1
    order_2_9  connected_order_arc_1369  1
    order_2_9  order_active_lb_1394  1
    order_2_9  order_active_ub_1395  1
    order_2_9  fixed_segment_relative_order_1468  -1
    visit_2_10  out_degree_1399  -1
    visit_2_10  in_degree_1400  -1
    visit_2_10  order_active_lb_1401  -1
    visit_2_10  order_active_ub_1402  -12
    order_2_10  connected_order_arc_1116  1
    order_2_10  connected_order_arc_1139  -1
    order_2_10  connected_order_arc_1141  -1
    order_2_10  connected_order_arc_1143  -1
    order_2_10  connected_order_arc_1145  -1
    order_2_10  connected_order_arc_1147  -1
    order_2_10  connected_order_arc_1149  -1
    order_2_10  connected_order_arc_1151  -1
    order_2_10  connected_order_arc_1153  -1
    order_2_10  connected_order_arc_1155  -1
    order_2_10  connected_order_arc_1157  -1
    order_2_10  connected_order_arc_1159  -1
    order_2_10  connected_order_arc_1164  1
    order_2_10  connected_order_arc_1187  1
    order_2_10  connected_order_arc_1210  1
    order_2_10  connected_order_arc_1233  1
    order_2_10  connected_order_arc_1256  1
    order_2_10  connected_order_arc_1279  1
    order_2_10  connected_order_arc_1302  1
    order_2_10  connected_order_arc_1325  1
    order_2_10  connected_order_arc_1348  1
    order_2_10  connected_order_arc_1371  1
    order_2_10  order_active_lb_1401  1
    order_2_10  order_active_ub_1402  1
    order_2_10  fixed_segment_relative_order_1468  1
    order_2_10  fixed_segment_relative_order_1469  -1
    visit_2_11  out_degree_1406  -1
    visit_2_11  in_degree_1407  -1
    visit_2_11  order_active_lb_1408  -1
    visit_2_11  order_active_ub_1409  -12
    order_2_11  connected_order_arc_1118  1
    order_2_11  connected_order_arc_1141  1
    order_2_11  connected_order_arc_1162  -1
    order_2_11  connected_order_arc_1164  -1
    order_2_11  connected_order_arc_1166  -1
    order_2_11  connected_order_arc_1168  -1
    order_2_11  connected_order_arc_1170  -1
    order_2_11  connected_order_arc_1172  -1
    order_2_11  connected_order_arc_1174  -1
    order_2_11  connected_order_arc_1176  -1
    order_2_11  connected_order_arc_1178  -1
    order_2_11  connected_order_arc_1180  -1
    order_2_11  connected_order_arc_1182  -1
    order_2_11  connected_order_arc_1189  1
    order_2_11  connected_order_arc_1212  1
    order_2_11  connected_order_arc_1235  1
    order_2_11  connected_order_arc_1258  1
    order_2_11  connected_order_arc_1281  1
    order_2_11  connected_order_arc_1304  1
    order_2_11  connected_order_arc_1327  1
    order_2_11  connected_order_arc_1350  1
    order_2_11  connected_order_arc_1373  1
    order_2_11  order_active_lb_1408  1
    order_2_11  order_active_ub_1409  1
    order_2_11  fixed_segment_relative_order_1469  1
    order_2_11  fixed_segment_relative_order_1470  -1
    visit_2_12  out_degree_1413  -1
    visit_2_12  in_degree_1414  -1
    visit_2_12  order_active_lb_1415  -1
    visit_2_12  order_active_ub_1416  -12
    order_2_12  connected_order_arc_1120  1
    order_2_12  connected_order_arc_1143  1
    order_2_12  connected_order_arc_1166  1
    order_2_12  connected_order_arc_1185  -1
    order_2_12  connected_order_arc_1187  -1
    order_2_12  connected_order_arc_1189  -1
    order_2_12  connected_order_arc_1191  -1
    order_2_12  connected_order_arc_1193  -1
    order_2_12  connected_order_arc_1195  -1
    order_2_12  connected_order_arc_1197  -1
    order_2_12  connected_order_arc_1199  -1
    order_2_12  connected_order_arc_1201  -1
    order_2_12  connected_order_arc_1203  -1
    order_2_12  connected_order_arc_1205  -1
    order_2_12  connected_order_arc_1214  1
    order_2_12  connected_order_arc_1237  1
    order_2_12  connected_order_arc_1260  1
    order_2_12  connected_order_arc_1283  1
    order_2_12  connected_order_arc_1306  1
    order_2_12  connected_order_arc_1329  1
    order_2_12  connected_order_arc_1352  1
    order_2_12  connected_order_arc_1375  1
    order_2_12  order_active_lb_1415  1
    order_2_12  order_active_ub_1416  1
    order_2_12  fixed_segment_relative_order_1470  1
    visit_2_13  out_degree_1420  -1
    visit_2_13  in_degree_1421  -1
    visit_2_13  order_active_lb_1422  -1
    visit_2_13  order_active_ub_1423  -12
    visit_2_13  service_visit_def_1424  -1
    order_2_13  connected_order_arc_1122  1
    order_2_13  connected_order_arc_1145  1
    order_2_13  connected_order_arc_1168  1
    order_2_13  connected_order_arc_1191  1
    order_2_13  connected_order_arc_1208  -1
    order_2_13  connected_order_arc_1210  -1
    order_2_13  connected_order_arc_1212  -1
    order_2_13  connected_order_arc_1214  -1
    order_2_13  connected_order_arc_1216  -1
    order_2_13  connected_order_arc_1218  -1
    order_2_13  connected_order_arc_1220  -1
    order_2_13  connected_order_arc_1222  -1
    order_2_13  connected_order_arc_1224  -1
    order_2_13  connected_order_arc_1226  -1
    order_2_13  connected_order_arc_1228  -1
    order_2_13  connected_order_arc_1239  1
    order_2_13  connected_order_arc_1262  1
    order_2_13  connected_order_arc_1285  1
    order_2_13  connected_order_arc_1308  1
    order_2_13  connected_order_arc_1331  1
    order_2_13  connected_order_arc_1354  1
    order_2_13  connected_order_arc_1377  1
    order_2_13  order_active_lb_1422  1
    order_2_13  order_active_ub_1423  1
    visit_2_14  out_degree_1426  -1
    visit_2_14  in_degree_1427  -1
    visit_2_14  order_active_lb_1428  -1
    visit_2_14  order_active_ub_1429  -12
    visit_2_14  service_visit_def_1430  -1
    order_2_14  connected_order_arc_1124  1
    order_2_14  connected_order_arc_1147  1
    order_2_14  connected_order_arc_1170  1
    order_2_14  connected_order_arc_1193  1
    order_2_14  connected_order_arc_1216  1
    order_2_14  connected_order_arc_1231  -1
    order_2_14  connected_order_arc_1233  -1
    order_2_14  connected_order_arc_1235  -1
    order_2_14  connected_order_arc_1237  -1
    order_2_14  connected_order_arc_1239  -1
    order_2_14  connected_order_arc_1241  -1
    order_2_14  connected_order_arc_1243  -1
    order_2_14  connected_order_arc_1245  -1
    order_2_14  connected_order_arc_1247  -1
    order_2_14  connected_order_arc_1249  -1
    order_2_14  connected_order_arc_1251  -1
    order_2_14  connected_order_arc_1264  1
    order_2_14  connected_order_arc_1287  1
    order_2_14  connected_order_arc_1310  1
    order_2_14  connected_order_arc_1333  1
    order_2_14  connected_order_arc_1356  1
    order_2_14  connected_order_arc_1379  1
    order_2_14  order_active_lb_1428  1
    order_2_14  order_active_ub_1429  1
    visit_2_15  out_degree_1432  -1
    visit_2_15  in_degree_1433  -1
    visit_2_15  order_active_lb_1434  -1
    visit_2_15  order_active_ub_1435  -12
    visit_2_15  service_visit_def_1436  -1
    order_2_15  connected_order_arc_1126  1
    order_2_15  connected_order_arc_1149  1
    order_2_15  connected_order_arc_1172  1
    order_2_15  connected_order_arc_1195  1
    order_2_15  connected_order_arc_1218  1
    order_2_15  connected_order_arc_1241  1
    order_2_15  connected_order_arc_1254  -1
    order_2_15  connected_order_arc_1256  -1
    order_2_15  connected_order_arc_1258  -1
    order_2_15  connected_order_arc_1260  -1
    order_2_15  connected_order_arc_1262  -1
    order_2_15  connected_order_arc_1264  -1
    order_2_15  connected_order_arc_1266  -1
    order_2_15  connected_order_arc_1268  -1
    order_2_15  connected_order_arc_1270  -1
    order_2_15  connected_order_arc_1272  -1
    order_2_15  connected_order_arc_1274  -1
    order_2_15  connected_order_arc_1289  1
    order_2_15  connected_order_arc_1312  1
    order_2_15  connected_order_arc_1335  1
    order_2_15  connected_order_arc_1358  1
    order_2_15  connected_order_arc_1381  1
    order_2_15  order_active_lb_1434  1
    order_2_15  order_active_ub_1435  1
    visit_2_16  out_degree_1438  -1
    visit_2_16  in_degree_1439  -1
    visit_2_16  order_active_lb_1440  -1
    visit_2_16  order_active_ub_1441  -12
    visit_2_16  service_visit_def_1442  -1
    order_2_16  connected_order_arc_1128  1
    order_2_16  connected_order_arc_1151  1
    order_2_16  connected_order_arc_1174  1
    order_2_16  connected_order_arc_1197  1
    order_2_16  connected_order_arc_1220  1
    order_2_16  connected_order_arc_1243  1
    order_2_16  connected_order_arc_1266  1
    order_2_16  connected_order_arc_1277  -1
    order_2_16  connected_order_arc_1279  -1
    order_2_16  connected_order_arc_1281  -1
    order_2_16  connected_order_arc_1283  -1
    order_2_16  connected_order_arc_1285  -1
    order_2_16  connected_order_arc_1287  -1
    order_2_16  connected_order_arc_1289  -1
    order_2_16  connected_order_arc_1291  -1
    order_2_16  connected_order_arc_1293  -1
    order_2_16  connected_order_arc_1295  -1
    order_2_16  connected_order_arc_1297  -1
    order_2_16  connected_order_arc_1314  1
    order_2_16  connected_order_arc_1337  1
    order_2_16  connected_order_arc_1360  1
    order_2_16  connected_order_arc_1383  1
    order_2_16  order_active_lb_1440  1
    order_2_16  order_active_ub_1441  1
    visit_2_17  out_degree_1444  -1
    visit_2_17  in_degree_1445  -1
    visit_2_17  order_active_lb_1446  -1
    visit_2_17  order_active_ub_1447  -12
    visit_2_17  service_visit_def_1448  -1
    order_2_17  connected_order_arc_1130  1
    order_2_17  connected_order_arc_1153  1
    order_2_17  connected_order_arc_1176  1
    order_2_17  connected_order_arc_1199  1
    order_2_17  connected_order_arc_1222  1
    order_2_17  connected_order_arc_1245  1
    order_2_17  connected_order_arc_1268  1
    order_2_17  connected_order_arc_1291  1
    order_2_17  connected_order_arc_1300  -1
    order_2_17  connected_order_arc_1302  -1
    order_2_17  connected_order_arc_1304  -1
    order_2_17  connected_order_arc_1306  -1
    order_2_17  connected_order_arc_1308  -1
    order_2_17  connected_order_arc_1310  -1
    order_2_17  connected_order_arc_1312  -1
    order_2_17  connected_order_arc_1314  -1
    order_2_17  connected_order_arc_1316  -1
    order_2_17  connected_order_arc_1318  -1
    order_2_17  connected_order_arc_1320  -1
    order_2_17  connected_order_arc_1339  1
    order_2_17  connected_order_arc_1362  1
    order_2_17  connected_order_arc_1385  1
    order_2_17  order_active_lb_1446  1
    order_2_17  order_active_ub_1447  1
    visit_2_18  out_degree_1450  -1
    visit_2_18  in_degree_1451  -1
    visit_2_18  order_active_lb_1452  -1
    visit_2_18  order_active_ub_1453  -12
    visit_2_18  service_visit_def_1454  -1
    order_2_18  connected_order_arc_1132  1
    order_2_18  connected_order_arc_1155  1
    order_2_18  connected_order_arc_1178  1
    order_2_18  connected_order_arc_1201  1
    order_2_18  connected_order_arc_1224  1
    order_2_18  connected_order_arc_1247  1
    order_2_18  connected_order_arc_1270  1
    order_2_18  connected_order_arc_1293  1
    order_2_18  connected_order_arc_1316  1
    order_2_18  connected_order_arc_1323  -1
    order_2_18  connected_order_arc_1325  -1
    order_2_18  connected_order_arc_1327  -1
    order_2_18  connected_order_arc_1329  -1
    order_2_18  connected_order_arc_1331  -1
    order_2_18  connected_order_arc_1333  -1
    order_2_18  connected_order_arc_1335  -1
    order_2_18  connected_order_arc_1337  -1
    order_2_18  connected_order_arc_1339  -1
    order_2_18  connected_order_arc_1341  -1
    order_2_18  connected_order_arc_1343  -1
    order_2_18  connected_order_arc_1364  1
    order_2_18  connected_order_arc_1387  1
    order_2_18  order_active_lb_1452  1
    order_2_18  order_active_ub_1453  1
    visit_2_19  out_degree_1456  -1
    visit_2_19  in_degree_1457  -1
    visit_2_19  order_active_lb_1458  -1
    visit_2_19  order_active_ub_1459  -12
    visit_2_19  service_visit_def_1460  -1
    order_2_19  connected_order_arc_1134  1
    order_2_19  connected_order_arc_1157  1
    order_2_19  connected_order_arc_1180  1
    order_2_19  connected_order_arc_1203  1
    order_2_19  connected_order_arc_1226  1
    order_2_19  connected_order_arc_1249  1
    order_2_19  connected_order_arc_1272  1
    order_2_19  connected_order_arc_1295  1
    order_2_19  connected_order_arc_1318  1
    order_2_19  connected_order_arc_1341  1
    order_2_19  connected_order_arc_1346  -1
    order_2_19  connected_order_arc_1348  -1
    order_2_19  connected_order_arc_1350  -1
    order_2_19  connected_order_arc_1352  -1
    order_2_19  connected_order_arc_1354  -1
    order_2_19  connected_order_arc_1356  -1
    order_2_19  connected_order_arc_1358  -1
    order_2_19  connected_order_arc_1360  -1
    order_2_19  connected_order_arc_1362  -1
    order_2_19  connected_order_arc_1364  -1
    order_2_19  connected_order_arc_1366  -1
    order_2_19  connected_order_arc_1389  1
    order_2_19  order_active_lb_1458  1
    order_2_19  order_active_ub_1459  1
    visit_2_20  out_degree_1462  -1
    visit_2_20  in_degree_1463  -1
    visit_2_20  order_active_lb_1464  -1
    visit_2_20  order_active_ub_1465  -12
    visit_2_20  service_visit_def_1466  -1
    order_2_20  connected_order_arc_1136  1
    order_2_20  connected_order_arc_1159  1
    order_2_20  connected_order_arc_1182  1
    order_2_20  connected_order_arc_1205  1
    order_2_20  connected_order_arc_1228  1
    order_2_20  connected_order_arc_1251  1
    order_2_20  connected_order_arc_1274  1
    order_2_20  connected_order_arc_1297  1
    order_2_20  connected_order_arc_1320  1
    order_2_20  connected_order_arc_1343  1
    order_2_20  connected_order_arc_1366  1
    order_2_20  connected_order_arc_1369  -1
    order_2_20  connected_order_arc_1371  -1
    order_2_20  connected_order_arc_1373  -1
    order_2_20  connected_order_arc_1375  -1
    order_2_20  connected_order_arc_1377  -1
    order_2_20  connected_order_arc_1379  -1
    order_2_20  connected_order_arc_1381  -1
    order_2_20  connected_order_arc_1383  -1
    order_2_20  connected_order_arc_1385  -1
    order_2_20  connected_order_arc_1387  -1
    order_2_20  connected_order_arc_1389  -1
    order_2_20  order_active_lb_1464  1
    order_2_20  order_active_ub_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1101  -30
    arc_2_0_0  depot_departure_or_bypass_1390  1
    arc_2_0_0  depot_return_or_bypass_1391  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1101  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1102  -30
    arc_2_0_9  depot_departure_or_bypass_1390  1
    arc_2_0_9  in_degree_1393  1
    arc_2_0_9  original_T_including_depot_unload_1471  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1102  1
    load_2_0_9  segment_load_conservation_1396  -1
    load_2_0_9  segment_prefix_lb_1397  1
    load_2_0_9  segment_prefix_ub_1398  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1103  -30
    arc_2_0_10  depot_departure_or_bypass_1390  1
    arc_2_0_10  in_degree_1400  1
    arc_2_0_10  original_T_including_depot_unload_1471  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1103  1
    load_2_0_10  segment_load_conservation_1403  -1
    load_2_0_10  segment_prefix_lb_1404  1
    load_2_0_10  segment_prefix_ub_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1104  -30
    arc_2_0_11  depot_departure_or_bypass_1390  1
    arc_2_0_11  in_degree_1407  1
    arc_2_0_11  original_T_including_depot_unload_1471  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1104  1
    load_2_0_11  segment_load_conservation_1410  -1
    load_2_0_11  segment_prefix_lb_1411  1
    load_2_0_11  segment_prefix_ub_1412  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1105  -30
    arc_2_0_12  depot_departure_or_bypass_1390  1
    arc_2_0_12  in_degree_1414  1
    arc_2_0_12  original_T_including_depot_unload_1471  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1105  1
    load_2_0_12  segment_load_conservation_1417  -1
    load_2_0_12  segment_prefix_lb_1418  1
    load_2_0_12  segment_prefix_ub_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1106  -30
    arc_2_0_13  depot_departure_or_bypass_1390  1
    arc_2_0_13  in_degree_1421  1
    arc_2_0_13  original_T_including_depot_unload_1471  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1106  1
    load_2_0_13  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1107  -30
    arc_2_0_14  depot_departure_or_bypass_1390  1
    arc_2_0_14  in_degree_1427  1
    arc_2_0_14  original_T_including_depot_unload_1471  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1107  1
    load_2_0_14  free_load_conservation_1431  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1108  -30
    arc_2_0_15  depot_departure_or_bypass_1390  1
    arc_2_0_15  in_degree_1433  1
    arc_2_0_15  original_T_including_depot_unload_1471  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1108  1
    load_2_0_15  free_load_conservation_1437  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1109  -30
    arc_2_0_16  depot_departure_or_bypass_1390  1
    arc_2_0_16  in_degree_1439  1
    arc_2_0_16  original_T_including_depot_unload_1471  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1109  1
    load_2_0_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1110  -30
    arc_2_0_17  depot_departure_or_bypass_1390  1
    arc_2_0_17  in_degree_1445  1
    arc_2_0_17  original_T_including_depot_unload_1471  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1110  1
    load_2_0_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1111  -30
    arc_2_0_18  depot_departure_or_bypass_1390  1
    arc_2_0_18  in_degree_1451  1
    arc_2_0_18  original_T_including_depot_unload_1471  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1111  1
    load_2_0_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1112  -30
    arc_2_0_19  depot_departure_or_bypass_1390  1
    arc_2_0_19  in_degree_1457  1
    arc_2_0_19  original_T_including_depot_unload_1471  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1112  1
    load_2_0_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1113  -30
    arc_2_0_20  depot_departure_or_bypass_1390  1
    arc_2_0_20  in_degree_1463  1
    arc_2_0_20  original_T_including_depot_unload_1471  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1113  1
    load_2_0_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1114  -30
    arc_2_9_0  depot_return_or_bypass_1391  1
    arc_2_9_0  out_degree_1392  1
    arc_2_9_0  original_T_including_depot_unload_1471  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1114  1
    load_2_9_0  segment_load_conservation_1396  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1115  -30
    arc_2_9_10  connected_order_arc_1116  -13
    arc_2_9_10  out_degree_1392  1
    arc_2_9_10  in_degree_1400  1
    arc_2_9_10  original_T_including_depot_unload_1471  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1115  1
    load_2_9_10  segment_load_conservation_1396  1
    load_2_9_10  segment_load_conservation_1403  -1
    load_2_9_10  segment_prefix_lb_1404  1
    load_2_9_10  segment_prefix_ub_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1117  -30
    arc_2_9_11  connected_order_arc_1118  -13
    arc_2_9_11  out_degree_1392  1
    arc_2_9_11  in_degree_1407  1
    arc_2_9_11  original_T_including_depot_unload_1471  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1117  1
    load_2_9_11  segment_load_conservation_1396  1
    load_2_9_11  segment_load_conservation_1410  -1
    load_2_9_11  segment_prefix_lb_1411  1
    load_2_9_11  segment_prefix_ub_1412  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1119  -30
    arc_2_9_12  connected_order_arc_1120  -13
    arc_2_9_12  out_degree_1392  1
    arc_2_9_12  in_degree_1414  1
    arc_2_9_12  original_T_including_depot_unload_1471  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1119  1
    load_2_9_12  segment_load_conservation_1396  1
    load_2_9_12  segment_load_conservation_1417  -1
    load_2_9_12  segment_prefix_lb_1418  1
    load_2_9_12  segment_prefix_ub_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1121  -30
    arc_2_9_13  connected_order_arc_1122  -13
    arc_2_9_13  out_degree_1392  1
    arc_2_9_13  in_degree_1421  1
    arc_2_9_13  original_T_including_depot_unload_1471  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1121  1
    load_2_9_13  segment_load_conservation_1396  1
    load_2_9_13  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1123  -30
    arc_2_9_14  connected_order_arc_1124  -13
    arc_2_9_14  out_degree_1392  1
    arc_2_9_14  in_degree_1427  1
    arc_2_9_14  original_T_including_depot_unload_1471  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1123  1
    load_2_9_14  segment_load_conservation_1396  1
    load_2_9_14  free_load_conservation_1431  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1125  -30
    arc_2_9_15  connected_order_arc_1126  -13
    arc_2_9_15  out_degree_1392  1
    arc_2_9_15  in_degree_1433  1
    arc_2_9_15  original_T_including_depot_unload_1471  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1125  1
    load_2_9_15  segment_load_conservation_1396  1
    load_2_9_15  free_load_conservation_1437  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1127  -30
    arc_2_9_16  connected_order_arc_1128  -13
    arc_2_9_16  out_degree_1392  1
    arc_2_9_16  in_degree_1439  1
    arc_2_9_16  original_T_including_depot_unload_1471  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1127  1
    load_2_9_16  segment_load_conservation_1396  1
    load_2_9_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1129  -30
    arc_2_9_17  connected_order_arc_1130  -13
    arc_2_9_17  out_degree_1392  1
    arc_2_9_17  in_degree_1445  1
    arc_2_9_17  original_T_including_depot_unload_1471  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1129  1
    load_2_9_17  segment_load_conservation_1396  1
    load_2_9_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1131  -30
    arc_2_9_18  connected_order_arc_1132  -13
    arc_2_9_18  out_degree_1392  1
    arc_2_9_18  in_degree_1451  1
    arc_2_9_18  original_T_including_depot_unload_1471  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1131  1
    load_2_9_18  segment_load_conservation_1396  1
    load_2_9_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1133  -30
    arc_2_9_19  connected_order_arc_1134  -13
    arc_2_9_19  out_degree_1392  1
    arc_2_9_19  in_degree_1457  1
    arc_2_9_19  original_T_including_depot_unload_1471  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1133  1
    load_2_9_19  segment_load_conservation_1396  1
    load_2_9_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_20  arc_capacity_1135  -30
    arc_2_9_20  connected_order_arc_1136  -13
    arc_2_9_20  out_degree_1392  1
    arc_2_9_20  in_degree_1463  1
    arc_2_9_20  original_T_including_depot_unload_1471  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_20  arc_capacity_1135  1
    load_2_9_20  segment_load_conservation_1396  1
    load_2_9_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1137  -30
    arc_2_10_0  depot_return_or_bypass_1391  1
    arc_2_10_0  out_degree_1399  1
    arc_2_10_0  original_T_including_depot_unload_1471  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1137  1
    load_2_10_0  segment_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1138  -30
    arc_2_10_9  connected_order_arc_1139  -13
    arc_2_10_9  in_degree_1393  1
    arc_2_10_9  out_degree_1399  1
    arc_2_10_9  original_T_including_depot_unload_1471  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1138  1
    load_2_10_9  segment_load_conservation_1396  -1
    load_2_10_9  segment_prefix_lb_1397  1
    load_2_10_9  segment_prefix_ub_1398  1
    load_2_10_9  segment_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1140  -30
    arc_2_10_11  connected_order_arc_1141  -13
    arc_2_10_11  out_degree_1399  1
    arc_2_10_11  in_degree_1407  1
    arc_2_10_11  original_T_including_depot_unload_1471  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1140  1
    load_2_10_11  segment_load_conservation_1403  1
    load_2_10_11  segment_load_conservation_1410  -1
    load_2_10_11  segment_prefix_lb_1411  1
    load_2_10_11  segment_prefix_ub_1412  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1142  -30
    arc_2_10_12  connected_order_arc_1143  -13
    arc_2_10_12  out_degree_1399  1
    arc_2_10_12  in_degree_1414  1
    arc_2_10_12  original_T_including_depot_unload_1471  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1142  1
    load_2_10_12  segment_load_conservation_1403  1
    load_2_10_12  segment_load_conservation_1417  -1
    load_2_10_12  segment_prefix_lb_1418  1
    load_2_10_12  segment_prefix_ub_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1144  -30
    arc_2_10_13  connected_order_arc_1145  -13
    arc_2_10_13  out_degree_1399  1
    arc_2_10_13  in_degree_1421  1
    arc_2_10_13  original_T_including_depot_unload_1471  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1144  1
    load_2_10_13  segment_load_conservation_1403  1
    load_2_10_13  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1146  -30
    arc_2_10_14  connected_order_arc_1147  -13
    arc_2_10_14  out_degree_1399  1
    arc_2_10_14  in_degree_1427  1
    arc_2_10_14  original_T_including_depot_unload_1471  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1146  1
    load_2_10_14  segment_load_conservation_1403  1
    load_2_10_14  free_load_conservation_1431  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1148  -30
    arc_2_10_15  connected_order_arc_1149  -13
    arc_2_10_15  out_degree_1399  1
    arc_2_10_15  in_degree_1433  1
    arc_2_10_15  original_T_including_depot_unload_1471  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1148  1
    load_2_10_15  segment_load_conservation_1403  1
    load_2_10_15  free_load_conservation_1437  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1150  -30
    arc_2_10_16  connected_order_arc_1151  -13
    arc_2_10_16  out_degree_1399  1
    arc_2_10_16  in_degree_1439  1
    arc_2_10_16  original_T_including_depot_unload_1471  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1150  1
    load_2_10_16  segment_load_conservation_1403  1
    load_2_10_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1152  -30
    arc_2_10_17  connected_order_arc_1153  -13
    arc_2_10_17  out_degree_1399  1
    arc_2_10_17  in_degree_1445  1
    arc_2_10_17  original_T_including_depot_unload_1471  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1152  1
    load_2_10_17  segment_load_conservation_1403  1
    load_2_10_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1154  -30
    arc_2_10_18  connected_order_arc_1155  -13
    arc_2_10_18  out_degree_1399  1
    arc_2_10_18  in_degree_1451  1
    arc_2_10_18  original_T_including_depot_unload_1471  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1154  1
    load_2_10_18  segment_load_conservation_1403  1
    load_2_10_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1156  -30
    arc_2_10_19  connected_order_arc_1157  -13
    arc_2_10_19  out_degree_1399  1
    arc_2_10_19  in_degree_1457  1
    arc_2_10_19  original_T_including_depot_unload_1471  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1156  1
    load_2_10_19  segment_load_conservation_1403  1
    load_2_10_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1158  -30
    arc_2_10_20  connected_order_arc_1159  -13
    arc_2_10_20  out_degree_1399  1
    arc_2_10_20  in_degree_1463  1
    arc_2_10_20  original_T_including_depot_unload_1471  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1158  1
    load_2_10_20  segment_load_conservation_1403  1
    load_2_10_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1160  -30
    arc_2_11_0  depot_return_or_bypass_1391  1
    arc_2_11_0  out_degree_1406  1
    arc_2_11_0  original_T_including_depot_unload_1471  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1160  1
    load_2_11_0  segment_load_conservation_1410  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1161  -30
    arc_2_11_9  connected_order_arc_1162  -13
    arc_2_11_9  in_degree_1393  1
    arc_2_11_9  out_degree_1406  1
    arc_2_11_9  original_T_including_depot_unload_1471  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1161  1
    load_2_11_9  segment_load_conservation_1396  -1
    load_2_11_9  segment_prefix_lb_1397  1
    load_2_11_9  segment_prefix_ub_1398  1
    load_2_11_9  segment_load_conservation_1410  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1163  -30
    arc_2_11_10  connected_order_arc_1164  -13
    arc_2_11_10  in_degree_1400  1
    arc_2_11_10  out_degree_1406  1
    arc_2_11_10  original_T_including_depot_unload_1471  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1163  1
    load_2_11_10  segment_load_conservation_1403  -1
    load_2_11_10  segment_prefix_lb_1404  1
    load_2_11_10  segment_prefix_ub_1405  1
    load_2_11_10  segment_load_conservation_1410  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1165  -30
    arc_2_11_12  connected_order_arc_1166  -13
    arc_2_11_12  out_degree_1406  1
    arc_2_11_12  in_degree_1414  1
    arc_2_11_12  original_T_including_depot_unload_1471  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1165  1
    load_2_11_12  segment_load_conservation_1410  1
    load_2_11_12  segment_load_conservation_1417  -1
    load_2_11_12  segment_prefix_lb_1418  1
    load_2_11_12  segment_prefix_ub_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1167  -30
    arc_2_11_13  connected_order_arc_1168  -13
    arc_2_11_13  out_degree_1406  1
    arc_2_11_13  in_degree_1421  1
    arc_2_11_13  original_T_including_depot_unload_1471  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1167  1
    load_2_11_13  segment_load_conservation_1410  1
    load_2_11_13  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1169  -30
    arc_2_11_14  connected_order_arc_1170  -13
    arc_2_11_14  out_degree_1406  1
    arc_2_11_14  in_degree_1427  1
    arc_2_11_14  original_T_including_depot_unload_1471  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1169  1
    load_2_11_14  segment_load_conservation_1410  1
    load_2_11_14  free_load_conservation_1431  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1171  -30
    arc_2_11_15  connected_order_arc_1172  -13
    arc_2_11_15  out_degree_1406  1
    arc_2_11_15  in_degree_1433  1
    arc_2_11_15  original_T_including_depot_unload_1471  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1171  1
    load_2_11_15  segment_load_conservation_1410  1
    load_2_11_15  free_load_conservation_1437  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1173  -30
    arc_2_11_16  connected_order_arc_1174  -13
    arc_2_11_16  out_degree_1406  1
    arc_2_11_16  in_degree_1439  1
    arc_2_11_16  original_T_including_depot_unload_1471  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1173  1
    load_2_11_16  segment_load_conservation_1410  1
    load_2_11_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1175  -30
    arc_2_11_17  connected_order_arc_1176  -13
    arc_2_11_17  out_degree_1406  1
    arc_2_11_17  in_degree_1445  1
    arc_2_11_17  original_T_including_depot_unload_1471  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1175  1
    load_2_11_17  segment_load_conservation_1410  1
    load_2_11_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1177  -30
    arc_2_11_18  connected_order_arc_1178  -13
    arc_2_11_18  out_degree_1406  1
    arc_2_11_18  in_degree_1451  1
    arc_2_11_18  original_T_including_depot_unload_1471  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1177  1
    load_2_11_18  segment_load_conservation_1410  1
    load_2_11_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1179  -30
    arc_2_11_19  connected_order_arc_1180  -13
    arc_2_11_19  out_degree_1406  1
    arc_2_11_19  in_degree_1457  1
    arc_2_11_19  original_T_including_depot_unload_1471  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1179  1
    load_2_11_19  segment_load_conservation_1410  1
    load_2_11_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1181  -30
    arc_2_11_20  connected_order_arc_1182  -13
    arc_2_11_20  out_degree_1406  1
    arc_2_11_20  in_degree_1463  1
    arc_2_11_20  original_T_including_depot_unload_1471  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1181  1
    load_2_11_20  segment_load_conservation_1410  1
    load_2_11_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1183  -30
    arc_2_12_0  depot_return_or_bypass_1391  1
    arc_2_12_0  out_degree_1413  1
    arc_2_12_0  original_T_including_depot_unload_1471  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1183  1
    load_2_12_0  segment_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1184  -30
    arc_2_12_9  connected_order_arc_1185  -13
    arc_2_12_9  in_degree_1393  1
    arc_2_12_9  out_degree_1413  1
    arc_2_12_9  original_T_including_depot_unload_1471  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1184  1
    load_2_12_9  segment_load_conservation_1396  -1
    load_2_12_9  segment_prefix_lb_1397  1
    load_2_12_9  segment_prefix_ub_1398  1
    load_2_12_9  segment_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1186  -30
    arc_2_12_10  connected_order_arc_1187  -13
    arc_2_12_10  in_degree_1400  1
    arc_2_12_10  out_degree_1413  1
    arc_2_12_10  original_T_including_depot_unload_1471  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1186  1
    load_2_12_10  segment_load_conservation_1403  -1
    load_2_12_10  segment_prefix_lb_1404  1
    load_2_12_10  segment_prefix_ub_1405  1
    load_2_12_10  segment_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1188  -30
    arc_2_12_11  connected_order_arc_1189  -13
    arc_2_12_11  in_degree_1407  1
    arc_2_12_11  out_degree_1413  1
    arc_2_12_11  original_T_including_depot_unload_1471  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1188  1
    load_2_12_11  segment_load_conservation_1410  -1
    load_2_12_11  segment_prefix_lb_1411  1
    load_2_12_11  segment_prefix_ub_1412  1
    load_2_12_11  segment_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1190  -30
    arc_2_12_13  connected_order_arc_1191  -13
    arc_2_12_13  out_degree_1413  1
    arc_2_12_13  in_degree_1421  1
    arc_2_12_13  original_T_including_depot_unload_1471  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1190  1
    load_2_12_13  segment_load_conservation_1417  1
    load_2_12_13  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1192  -30
    arc_2_12_14  connected_order_arc_1193  -13
    arc_2_12_14  out_degree_1413  1
    arc_2_12_14  in_degree_1427  1
    arc_2_12_14  original_T_including_depot_unload_1471  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1192  1
    load_2_12_14  segment_load_conservation_1417  1
    load_2_12_14  free_load_conservation_1431  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1194  -30
    arc_2_12_15  connected_order_arc_1195  -13
    arc_2_12_15  out_degree_1413  1
    arc_2_12_15  in_degree_1433  1
    arc_2_12_15  original_T_including_depot_unload_1471  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1194  1
    load_2_12_15  segment_load_conservation_1417  1
    load_2_12_15  free_load_conservation_1437  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1196  -30
    arc_2_12_16  connected_order_arc_1197  -13
    arc_2_12_16  out_degree_1413  1
    arc_2_12_16  in_degree_1439  1
    arc_2_12_16  original_T_including_depot_unload_1471  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1196  1
    load_2_12_16  segment_load_conservation_1417  1
    load_2_12_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1198  -30
    arc_2_12_17  connected_order_arc_1199  -13
    arc_2_12_17  out_degree_1413  1
    arc_2_12_17  in_degree_1445  1
    arc_2_12_17  original_T_including_depot_unload_1471  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1198  1
    load_2_12_17  segment_load_conservation_1417  1
    load_2_12_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1200  -30
    arc_2_12_18  connected_order_arc_1201  -13
    arc_2_12_18  out_degree_1413  1
    arc_2_12_18  in_degree_1451  1
    arc_2_12_18  original_T_including_depot_unload_1471  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1200  1
    load_2_12_18  segment_load_conservation_1417  1
    load_2_12_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1202  -30
    arc_2_12_19  connected_order_arc_1203  -13
    arc_2_12_19  out_degree_1413  1
    arc_2_12_19  in_degree_1457  1
    arc_2_12_19  original_T_including_depot_unload_1471  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1202  1
    load_2_12_19  segment_load_conservation_1417  1
    load_2_12_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1204  -30
    arc_2_12_20  connected_order_arc_1205  -13
    arc_2_12_20  out_degree_1413  1
    arc_2_12_20  in_degree_1463  1
    arc_2_12_20  original_T_including_depot_unload_1471  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1204  1
    load_2_12_20  segment_load_conservation_1417  1
    load_2_12_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1206  -30
    arc_2_13_0  depot_return_or_bypass_1391  1
    arc_2_13_0  out_degree_1420  1
    arc_2_13_0  original_T_including_depot_unload_1471  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1206  1
    load_2_13_0  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1207  -30
    arc_2_13_9  connected_order_arc_1208  -13
    arc_2_13_9  in_degree_1393  1
    arc_2_13_9  out_degree_1420  1
    arc_2_13_9  original_T_including_depot_unload_1471  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1207  1
    load_2_13_9  segment_load_conservation_1396  -1
    load_2_13_9  segment_prefix_lb_1397  1
    load_2_13_9  segment_prefix_ub_1398  1
    load_2_13_9  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1209  -30
    arc_2_13_10  connected_order_arc_1210  -13
    arc_2_13_10  in_degree_1400  1
    arc_2_13_10  out_degree_1420  1
    arc_2_13_10  original_T_including_depot_unload_1471  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1209  1
    load_2_13_10  segment_load_conservation_1403  -1
    load_2_13_10  segment_prefix_lb_1404  1
    load_2_13_10  segment_prefix_ub_1405  1
    load_2_13_10  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1211  -30
    arc_2_13_11  connected_order_arc_1212  -13
    arc_2_13_11  in_degree_1407  1
    arc_2_13_11  out_degree_1420  1
    arc_2_13_11  original_T_including_depot_unload_1471  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1211  1
    load_2_13_11  segment_load_conservation_1410  -1
    load_2_13_11  segment_prefix_lb_1411  1
    load_2_13_11  segment_prefix_ub_1412  1
    load_2_13_11  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1213  -30
    arc_2_13_12  connected_order_arc_1214  -13
    arc_2_13_12  in_degree_1414  1
    arc_2_13_12  out_degree_1420  1
    arc_2_13_12  original_T_including_depot_unload_1471  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1213  1
    load_2_13_12  segment_load_conservation_1417  -1
    load_2_13_12  segment_prefix_lb_1418  1
    load_2_13_12  segment_prefix_ub_1419  1
    load_2_13_12  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1215  -30
    arc_2_13_14  connected_order_arc_1216  -13
    arc_2_13_14  out_degree_1420  1
    arc_2_13_14  in_degree_1427  1
    arc_2_13_14  original_T_including_depot_unload_1471  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1215  1
    load_2_13_14  free_load_conservation_1425  1
    load_2_13_14  free_load_conservation_1431  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1217  -30
    arc_2_13_15  connected_order_arc_1218  -13
    arc_2_13_15  out_degree_1420  1
    arc_2_13_15  in_degree_1433  1
    arc_2_13_15  original_T_including_depot_unload_1471  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1217  1
    load_2_13_15  free_load_conservation_1425  1
    load_2_13_15  free_load_conservation_1437  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1219  -30
    arc_2_13_16  connected_order_arc_1220  -13
    arc_2_13_16  out_degree_1420  1
    arc_2_13_16  in_degree_1439  1
    arc_2_13_16  original_T_including_depot_unload_1471  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1219  1
    load_2_13_16  free_load_conservation_1425  1
    load_2_13_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1221  -30
    arc_2_13_17  connected_order_arc_1222  -13
    arc_2_13_17  out_degree_1420  1
    arc_2_13_17  in_degree_1445  1
    arc_2_13_17  original_T_including_depot_unload_1471  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1221  1
    load_2_13_17  free_load_conservation_1425  1
    load_2_13_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1223  -30
    arc_2_13_18  connected_order_arc_1224  -13
    arc_2_13_18  out_degree_1420  1
    arc_2_13_18  in_degree_1451  1
    arc_2_13_18  original_T_including_depot_unload_1471  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1223  1
    load_2_13_18  free_load_conservation_1425  1
    load_2_13_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1225  -30
    arc_2_13_19  connected_order_arc_1226  -13
    arc_2_13_19  out_degree_1420  1
    arc_2_13_19  in_degree_1457  1
    arc_2_13_19  original_T_including_depot_unload_1471  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1225  1
    load_2_13_19  free_load_conservation_1425  1
    load_2_13_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1227  -30
    arc_2_13_20  connected_order_arc_1228  -13
    arc_2_13_20  out_degree_1420  1
    arc_2_13_20  in_degree_1463  1
    arc_2_13_20  original_T_including_depot_unload_1471  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1227  1
    load_2_13_20  free_load_conservation_1425  1
    load_2_13_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1229  -30
    arc_2_14_0  depot_return_or_bypass_1391  1
    arc_2_14_0  out_degree_1426  1
    arc_2_14_0  original_T_including_depot_unload_1471  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1229  1
    load_2_14_0  free_load_conservation_1431  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1230  -30
    arc_2_14_9  connected_order_arc_1231  -13
    arc_2_14_9  in_degree_1393  1
    arc_2_14_9  out_degree_1426  1
    arc_2_14_9  original_T_including_depot_unload_1471  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1230  1
    load_2_14_9  segment_load_conservation_1396  -1
    load_2_14_9  segment_prefix_lb_1397  1
    load_2_14_9  segment_prefix_ub_1398  1
    load_2_14_9  free_load_conservation_1431  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1232  -30
    arc_2_14_10  connected_order_arc_1233  -13
    arc_2_14_10  in_degree_1400  1
    arc_2_14_10  out_degree_1426  1
    arc_2_14_10  original_T_including_depot_unload_1471  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1232  1
    load_2_14_10  segment_load_conservation_1403  -1
    load_2_14_10  segment_prefix_lb_1404  1
    load_2_14_10  segment_prefix_ub_1405  1
    load_2_14_10  free_load_conservation_1431  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1234  -30
    arc_2_14_11  connected_order_arc_1235  -13
    arc_2_14_11  in_degree_1407  1
    arc_2_14_11  out_degree_1426  1
    arc_2_14_11  original_T_including_depot_unload_1471  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1234  1
    load_2_14_11  segment_load_conservation_1410  -1
    load_2_14_11  segment_prefix_lb_1411  1
    load_2_14_11  segment_prefix_ub_1412  1
    load_2_14_11  free_load_conservation_1431  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1236  -30
    arc_2_14_12  connected_order_arc_1237  -13
    arc_2_14_12  in_degree_1414  1
    arc_2_14_12  out_degree_1426  1
    arc_2_14_12  original_T_including_depot_unload_1471  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1236  1
    load_2_14_12  segment_load_conservation_1417  -1
    load_2_14_12  segment_prefix_lb_1418  1
    load_2_14_12  segment_prefix_ub_1419  1
    load_2_14_12  free_load_conservation_1431  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1238  -30
    arc_2_14_13  connected_order_arc_1239  -13
    arc_2_14_13  in_degree_1421  1
    arc_2_14_13  out_degree_1426  1
    arc_2_14_13  original_T_including_depot_unload_1471  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1238  1
    load_2_14_13  free_load_conservation_1425  -1
    load_2_14_13  free_load_conservation_1431  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1240  -30
    arc_2_14_15  connected_order_arc_1241  -13
    arc_2_14_15  out_degree_1426  1
    arc_2_14_15  in_degree_1433  1
    arc_2_14_15  original_T_including_depot_unload_1471  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1240  1
    load_2_14_15  free_load_conservation_1431  1
    load_2_14_15  free_load_conservation_1437  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1242  -30
    arc_2_14_16  connected_order_arc_1243  -13
    arc_2_14_16  out_degree_1426  1
    arc_2_14_16  in_degree_1439  1
    arc_2_14_16  original_T_including_depot_unload_1471  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1242  1
    load_2_14_16  free_load_conservation_1431  1
    load_2_14_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1244  -30
    arc_2_14_17  connected_order_arc_1245  -13
    arc_2_14_17  out_degree_1426  1
    arc_2_14_17  in_degree_1445  1
    arc_2_14_17  original_T_including_depot_unload_1471  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1244  1
    load_2_14_17  free_load_conservation_1431  1
    load_2_14_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1246  -30
    arc_2_14_18  connected_order_arc_1247  -13
    arc_2_14_18  out_degree_1426  1
    arc_2_14_18  in_degree_1451  1
    arc_2_14_18  original_T_including_depot_unload_1471  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1246  1
    load_2_14_18  free_load_conservation_1431  1
    load_2_14_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1248  -30
    arc_2_14_19  connected_order_arc_1249  -13
    arc_2_14_19  out_degree_1426  1
    arc_2_14_19  in_degree_1457  1
    arc_2_14_19  original_T_including_depot_unload_1471  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1248  1
    load_2_14_19  free_load_conservation_1431  1
    load_2_14_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1250  -30
    arc_2_14_20  connected_order_arc_1251  -13
    arc_2_14_20  out_degree_1426  1
    arc_2_14_20  in_degree_1463  1
    arc_2_14_20  original_T_including_depot_unload_1471  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1250  1
    load_2_14_20  free_load_conservation_1431  1
    load_2_14_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1252  -30
    arc_2_15_0  depot_return_or_bypass_1391  1
    arc_2_15_0  out_degree_1432  1
    arc_2_15_0  original_T_including_depot_unload_1471  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1252  1
    load_2_15_0  free_load_conservation_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1253  -30
    arc_2_15_9  connected_order_arc_1254  -13
    arc_2_15_9  in_degree_1393  1
    arc_2_15_9  out_degree_1432  1
    arc_2_15_9  original_T_including_depot_unload_1471  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1253  1
    load_2_15_9  segment_load_conservation_1396  -1
    load_2_15_9  segment_prefix_lb_1397  1
    load_2_15_9  segment_prefix_ub_1398  1
    load_2_15_9  free_load_conservation_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1255  -30
    arc_2_15_10  connected_order_arc_1256  -13
    arc_2_15_10  in_degree_1400  1
    arc_2_15_10  out_degree_1432  1
    arc_2_15_10  original_T_including_depot_unload_1471  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1255  1
    load_2_15_10  segment_load_conservation_1403  -1
    load_2_15_10  segment_prefix_lb_1404  1
    load_2_15_10  segment_prefix_ub_1405  1
    load_2_15_10  free_load_conservation_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1257  -30
    arc_2_15_11  connected_order_arc_1258  -13
    arc_2_15_11  in_degree_1407  1
    arc_2_15_11  out_degree_1432  1
    arc_2_15_11  original_T_including_depot_unload_1471  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1257  1
    load_2_15_11  segment_load_conservation_1410  -1
    load_2_15_11  segment_prefix_lb_1411  1
    load_2_15_11  segment_prefix_ub_1412  1
    load_2_15_11  free_load_conservation_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1259  -30
    arc_2_15_12  connected_order_arc_1260  -13
    arc_2_15_12  in_degree_1414  1
    arc_2_15_12  out_degree_1432  1
    arc_2_15_12  original_T_including_depot_unload_1471  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1259  1
    load_2_15_12  segment_load_conservation_1417  -1
    load_2_15_12  segment_prefix_lb_1418  1
    load_2_15_12  segment_prefix_ub_1419  1
    load_2_15_12  free_load_conservation_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1261  -30
    arc_2_15_13  connected_order_arc_1262  -13
    arc_2_15_13  in_degree_1421  1
    arc_2_15_13  out_degree_1432  1
    arc_2_15_13  original_T_including_depot_unload_1471  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1261  1
    load_2_15_13  free_load_conservation_1425  -1
    load_2_15_13  free_load_conservation_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1263  -30
    arc_2_15_14  connected_order_arc_1264  -13
    arc_2_15_14  in_degree_1427  1
    arc_2_15_14  out_degree_1432  1
    arc_2_15_14  original_T_including_depot_unload_1471  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1263  1
    load_2_15_14  free_load_conservation_1431  -1
    load_2_15_14  free_load_conservation_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1265  -30
    arc_2_15_16  connected_order_arc_1266  -13
    arc_2_15_16  out_degree_1432  1
    arc_2_15_16  in_degree_1439  1
    arc_2_15_16  original_T_including_depot_unload_1471  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1265  1
    load_2_15_16  free_load_conservation_1437  1
    load_2_15_16  free_load_conservation_1443  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1267  -30
    arc_2_15_17  connected_order_arc_1268  -13
    arc_2_15_17  out_degree_1432  1
    arc_2_15_17  in_degree_1445  1
    arc_2_15_17  original_T_including_depot_unload_1471  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1267  1
    load_2_15_17  free_load_conservation_1437  1
    load_2_15_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1269  -30
    arc_2_15_18  connected_order_arc_1270  -13
    arc_2_15_18  out_degree_1432  1
    arc_2_15_18  in_degree_1451  1
    arc_2_15_18  original_T_including_depot_unload_1471  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1269  1
    load_2_15_18  free_load_conservation_1437  1
    load_2_15_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1271  -30
    arc_2_15_19  connected_order_arc_1272  -13
    arc_2_15_19  out_degree_1432  1
    arc_2_15_19  in_degree_1457  1
    arc_2_15_19  original_T_including_depot_unload_1471  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1271  1
    load_2_15_19  free_load_conservation_1437  1
    load_2_15_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1273  -30
    arc_2_15_20  connected_order_arc_1274  -13
    arc_2_15_20  out_degree_1432  1
    arc_2_15_20  in_degree_1463  1
    arc_2_15_20  original_T_including_depot_unload_1471  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1273  1
    load_2_15_20  free_load_conservation_1437  1
    load_2_15_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1275  -30
    arc_2_16_0  depot_return_or_bypass_1391  1
    arc_2_16_0  out_degree_1438  1
    arc_2_16_0  original_T_including_depot_unload_1471  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1275  1
    load_2_16_0  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1276  -30
    arc_2_16_9  connected_order_arc_1277  -13
    arc_2_16_9  in_degree_1393  1
    arc_2_16_9  out_degree_1438  1
    arc_2_16_9  original_T_including_depot_unload_1471  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1276  1
    load_2_16_9  segment_load_conservation_1396  -1
    load_2_16_9  segment_prefix_lb_1397  1
    load_2_16_9  segment_prefix_ub_1398  1
    load_2_16_9  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1278  -30
    arc_2_16_10  connected_order_arc_1279  -13
    arc_2_16_10  in_degree_1400  1
    arc_2_16_10  out_degree_1438  1
    arc_2_16_10  original_T_including_depot_unload_1471  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1278  1
    load_2_16_10  segment_load_conservation_1403  -1
    load_2_16_10  segment_prefix_lb_1404  1
    load_2_16_10  segment_prefix_ub_1405  1
    load_2_16_10  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1280  -30
    arc_2_16_11  connected_order_arc_1281  -13
    arc_2_16_11  in_degree_1407  1
    arc_2_16_11  out_degree_1438  1
    arc_2_16_11  original_T_including_depot_unload_1471  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1280  1
    load_2_16_11  segment_load_conservation_1410  -1
    load_2_16_11  segment_prefix_lb_1411  1
    load_2_16_11  segment_prefix_ub_1412  1
    load_2_16_11  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1282  -30
    arc_2_16_12  connected_order_arc_1283  -13
    arc_2_16_12  in_degree_1414  1
    arc_2_16_12  out_degree_1438  1
    arc_2_16_12  original_T_including_depot_unload_1471  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1282  1
    load_2_16_12  segment_load_conservation_1417  -1
    load_2_16_12  segment_prefix_lb_1418  1
    load_2_16_12  segment_prefix_ub_1419  1
    load_2_16_12  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1284  -30
    arc_2_16_13  connected_order_arc_1285  -13
    arc_2_16_13  in_degree_1421  1
    arc_2_16_13  out_degree_1438  1
    arc_2_16_13  original_T_including_depot_unload_1471  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1284  1
    load_2_16_13  free_load_conservation_1425  -1
    load_2_16_13  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1286  -30
    arc_2_16_14  connected_order_arc_1287  -13
    arc_2_16_14  in_degree_1427  1
    arc_2_16_14  out_degree_1438  1
    arc_2_16_14  original_T_including_depot_unload_1471  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1286  1
    load_2_16_14  free_load_conservation_1431  -1
    load_2_16_14  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1288  -30
    arc_2_16_15  connected_order_arc_1289  -13
    arc_2_16_15  in_degree_1433  1
    arc_2_16_15  out_degree_1438  1
    arc_2_16_15  original_T_including_depot_unload_1471  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1288  1
    load_2_16_15  free_load_conservation_1437  -1
    load_2_16_15  free_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1290  -30
    arc_2_16_17  connected_order_arc_1291  -13
    arc_2_16_17  out_degree_1438  1
    arc_2_16_17  in_degree_1445  1
    arc_2_16_17  original_T_including_depot_unload_1471  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1290  1
    load_2_16_17  free_load_conservation_1443  1
    load_2_16_17  free_load_conservation_1449  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1292  -30
    arc_2_16_18  connected_order_arc_1293  -13
    arc_2_16_18  out_degree_1438  1
    arc_2_16_18  in_degree_1451  1
    arc_2_16_18  original_T_including_depot_unload_1471  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1292  1
    load_2_16_18  free_load_conservation_1443  1
    load_2_16_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1294  -30
    arc_2_16_19  connected_order_arc_1295  -13
    arc_2_16_19  out_degree_1438  1
    arc_2_16_19  in_degree_1457  1
    arc_2_16_19  original_T_including_depot_unload_1471  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1294  1
    load_2_16_19  free_load_conservation_1443  1
    load_2_16_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1296  -30
    arc_2_16_20  connected_order_arc_1297  -13
    arc_2_16_20  out_degree_1438  1
    arc_2_16_20  in_degree_1463  1
    arc_2_16_20  original_T_including_depot_unload_1471  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1296  1
    load_2_16_20  free_load_conservation_1443  1
    load_2_16_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1298  -30
    arc_2_17_0  depot_return_or_bypass_1391  1
    arc_2_17_0  out_degree_1444  1
    arc_2_17_0  original_T_including_depot_unload_1471  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1298  1
    load_2_17_0  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1299  -30
    arc_2_17_9  connected_order_arc_1300  -13
    arc_2_17_9  in_degree_1393  1
    arc_2_17_9  out_degree_1444  1
    arc_2_17_9  original_T_including_depot_unload_1471  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1299  1
    load_2_17_9  segment_load_conservation_1396  -1
    load_2_17_9  segment_prefix_lb_1397  1
    load_2_17_9  segment_prefix_ub_1398  1
    load_2_17_9  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1301  -30
    arc_2_17_10  connected_order_arc_1302  -13
    arc_2_17_10  in_degree_1400  1
    arc_2_17_10  out_degree_1444  1
    arc_2_17_10  original_T_including_depot_unload_1471  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1301  1
    load_2_17_10  segment_load_conservation_1403  -1
    load_2_17_10  segment_prefix_lb_1404  1
    load_2_17_10  segment_prefix_ub_1405  1
    load_2_17_10  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1303  -30
    arc_2_17_11  connected_order_arc_1304  -13
    arc_2_17_11  in_degree_1407  1
    arc_2_17_11  out_degree_1444  1
    arc_2_17_11  original_T_including_depot_unload_1471  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1303  1
    load_2_17_11  segment_load_conservation_1410  -1
    load_2_17_11  segment_prefix_lb_1411  1
    load_2_17_11  segment_prefix_ub_1412  1
    load_2_17_11  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1305  -30
    arc_2_17_12  connected_order_arc_1306  -13
    arc_2_17_12  in_degree_1414  1
    arc_2_17_12  out_degree_1444  1
    arc_2_17_12  original_T_including_depot_unload_1471  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1305  1
    load_2_17_12  segment_load_conservation_1417  -1
    load_2_17_12  segment_prefix_lb_1418  1
    load_2_17_12  segment_prefix_ub_1419  1
    load_2_17_12  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1307  -30
    arc_2_17_13  connected_order_arc_1308  -13
    arc_2_17_13  in_degree_1421  1
    arc_2_17_13  out_degree_1444  1
    arc_2_17_13  original_T_including_depot_unload_1471  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1307  1
    load_2_17_13  free_load_conservation_1425  -1
    load_2_17_13  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1309  -30
    arc_2_17_14  connected_order_arc_1310  -13
    arc_2_17_14  in_degree_1427  1
    arc_2_17_14  out_degree_1444  1
    arc_2_17_14  original_T_including_depot_unload_1471  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1309  1
    load_2_17_14  free_load_conservation_1431  -1
    load_2_17_14  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1311  -30
    arc_2_17_15  connected_order_arc_1312  -13
    arc_2_17_15  in_degree_1433  1
    arc_2_17_15  out_degree_1444  1
    arc_2_17_15  original_T_including_depot_unload_1471  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1311  1
    load_2_17_15  free_load_conservation_1437  -1
    load_2_17_15  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1313  -30
    arc_2_17_16  connected_order_arc_1314  -13
    arc_2_17_16  in_degree_1439  1
    arc_2_17_16  out_degree_1444  1
    arc_2_17_16  original_T_including_depot_unload_1471  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1313  1
    load_2_17_16  free_load_conservation_1443  -1
    load_2_17_16  free_load_conservation_1449  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1315  -30
    arc_2_17_18  connected_order_arc_1316  -13
    arc_2_17_18  out_degree_1444  1
    arc_2_17_18  in_degree_1451  1
    arc_2_17_18  original_T_including_depot_unload_1471  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1315  1
    load_2_17_18  free_load_conservation_1449  1
    load_2_17_18  free_load_conservation_1455  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1317  -30
    arc_2_17_19  connected_order_arc_1318  -13
    arc_2_17_19  out_degree_1444  1
    arc_2_17_19  in_degree_1457  1
    arc_2_17_19  original_T_including_depot_unload_1471  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1317  1
    load_2_17_19  free_load_conservation_1449  1
    load_2_17_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1319  -30
    arc_2_17_20  connected_order_arc_1320  -13
    arc_2_17_20  out_degree_1444  1
    arc_2_17_20  in_degree_1463  1
    arc_2_17_20  original_T_including_depot_unload_1471  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1319  1
    load_2_17_20  free_load_conservation_1449  1
    load_2_17_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1321  -30
    arc_2_18_0  depot_return_or_bypass_1391  1
    arc_2_18_0  out_degree_1450  1
    arc_2_18_0  original_T_including_depot_unload_1471  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1321  1
    load_2_18_0  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1322  -30
    arc_2_18_9  connected_order_arc_1323  -13
    arc_2_18_9  in_degree_1393  1
    arc_2_18_9  out_degree_1450  1
    arc_2_18_9  original_T_including_depot_unload_1471  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1322  1
    load_2_18_9  segment_load_conservation_1396  -1
    load_2_18_9  segment_prefix_lb_1397  1
    load_2_18_9  segment_prefix_ub_1398  1
    load_2_18_9  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1324  -30
    arc_2_18_10  connected_order_arc_1325  -13
    arc_2_18_10  in_degree_1400  1
    arc_2_18_10  out_degree_1450  1
    arc_2_18_10  original_T_including_depot_unload_1471  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1324  1
    load_2_18_10  segment_load_conservation_1403  -1
    load_2_18_10  segment_prefix_lb_1404  1
    load_2_18_10  segment_prefix_ub_1405  1
    load_2_18_10  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1326  -30
    arc_2_18_11  connected_order_arc_1327  -13
    arc_2_18_11  in_degree_1407  1
    arc_2_18_11  out_degree_1450  1
    arc_2_18_11  original_T_including_depot_unload_1471  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1326  1
    load_2_18_11  segment_load_conservation_1410  -1
    load_2_18_11  segment_prefix_lb_1411  1
    load_2_18_11  segment_prefix_ub_1412  1
    load_2_18_11  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1328  -30
    arc_2_18_12  connected_order_arc_1329  -13
    arc_2_18_12  in_degree_1414  1
    arc_2_18_12  out_degree_1450  1
    arc_2_18_12  original_T_including_depot_unload_1471  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1328  1
    load_2_18_12  segment_load_conservation_1417  -1
    load_2_18_12  segment_prefix_lb_1418  1
    load_2_18_12  segment_prefix_ub_1419  1
    load_2_18_12  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1330  -30
    arc_2_18_13  connected_order_arc_1331  -13
    arc_2_18_13  in_degree_1421  1
    arc_2_18_13  out_degree_1450  1
    arc_2_18_13  original_T_including_depot_unload_1471  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1330  1
    load_2_18_13  free_load_conservation_1425  -1
    load_2_18_13  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1332  -30
    arc_2_18_14  connected_order_arc_1333  -13
    arc_2_18_14  in_degree_1427  1
    arc_2_18_14  out_degree_1450  1
    arc_2_18_14  original_T_including_depot_unload_1471  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1332  1
    load_2_18_14  free_load_conservation_1431  -1
    load_2_18_14  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1334  -30
    arc_2_18_15  connected_order_arc_1335  -13
    arc_2_18_15  in_degree_1433  1
    arc_2_18_15  out_degree_1450  1
    arc_2_18_15  original_T_including_depot_unload_1471  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1334  1
    load_2_18_15  free_load_conservation_1437  -1
    load_2_18_15  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1336  -30
    arc_2_18_16  connected_order_arc_1337  -13
    arc_2_18_16  in_degree_1439  1
    arc_2_18_16  out_degree_1450  1
    arc_2_18_16  original_T_including_depot_unload_1471  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1336  1
    load_2_18_16  free_load_conservation_1443  -1
    load_2_18_16  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1338  -30
    arc_2_18_17  connected_order_arc_1339  -13
    arc_2_18_17  in_degree_1445  1
    arc_2_18_17  out_degree_1450  1
    arc_2_18_17  original_T_including_depot_unload_1471  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1338  1
    load_2_18_17  free_load_conservation_1449  -1
    load_2_18_17  free_load_conservation_1455  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1340  -30
    arc_2_18_19  connected_order_arc_1341  -13
    arc_2_18_19  out_degree_1450  1
    arc_2_18_19  in_degree_1457  1
    arc_2_18_19  original_T_including_depot_unload_1471  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1340  1
    load_2_18_19  free_load_conservation_1455  1
    load_2_18_19  free_load_conservation_1461  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1342  -30
    arc_2_18_20  connected_order_arc_1343  -13
    arc_2_18_20  out_degree_1450  1
    arc_2_18_20  in_degree_1463  1
    arc_2_18_20  original_T_including_depot_unload_1471  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1342  1
    load_2_18_20  free_load_conservation_1455  1
    load_2_18_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1344  -30
    arc_2_19_0  depot_return_or_bypass_1391  1
    arc_2_19_0  out_degree_1456  1
    arc_2_19_0  original_T_including_depot_unload_1471  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1344  1
    load_2_19_0  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1345  -30
    arc_2_19_9  connected_order_arc_1346  -13
    arc_2_19_9  in_degree_1393  1
    arc_2_19_9  out_degree_1456  1
    arc_2_19_9  original_T_including_depot_unload_1471  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1345  1
    load_2_19_9  segment_load_conservation_1396  -1
    load_2_19_9  segment_prefix_lb_1397  1
    load_2_19_9  segment_prefix_ub_1398  1
    load_2_19_9  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1347  -30
    arc_2_19_10  connected_order_arc_1348  -13
    arc_2_19_10  in_degree_1400  1
    arc_2_19_10  out_degree_1456  1
    arc_2_19_10  original_T_including_depot_unload_1471  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1347  1
    load_2_19_10  segment_load_conservation_1403  -1
    load_2_19_10  segment_prefix_lb_1404  1
    load_2_19_10  segment_prefix_ub_1405  1
    load_2_19_10  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1349  -30
    arc_2_19_11  connected_order_arc_1350  -13
    arc_2_19_11  in_degree_1407  1
    arc_2_19_11  out_degree_1456  1
    arc_2_19_11  original_T_including_depot_unload_1471  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1349  1
    load_2_19_11  segment_load_conservation_1410  -1
    load_2_19_11  segment_prefix_lb_1411  1
    load_2_19_11  segment_prefix_ub_1412  1
    load_2_19_11  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1351  -30
    arc_2_19_12  connected_order_arc_1352  -13
    arc_2_19_12  in_degree_1414  1
    arc_2_19_12  out_degree_1456  1
    arc_2_19_12  original_T_including_depot_unload_1471  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1351  1
    load_2_19_12  segment_load_conservation_1417  -1
    load_2_19_12  segment_prefix_lb_1418  1
    load_2_19_12  segment_prefix_ub_1419  1
    load_2_19_12  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1353  -30
    arc_2_19_13  connected_order_arc_1354  -13
    arc_2_19_13  in_degree_1421  1
    arc_2_19_13  out_degree_1456  1
    arc_2_19_13  original_T_including_depot_unload_1471  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1353  1
    load_2_19_13  free_load_conservation_1425  -1
    load_2_19_13  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1355  -30
    arc_2_19_14  connected_order_arc_1356  -13
    arc_2_19_14  in_degree_1427  1
    arc_2_19_14  out_degree_1456  1
    arc_2_19_14  original_T_including_depot_unload_1471  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1355  1
    load_2_19_14  free_load_conservation_1431  -1
    load_2_19_14  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1357  -30
    arc_2_19_15  connected_order_arc_1358  -13
    arc_2_19_15  in_degree_1433  1
    arc_2_19_15  out_degree_1456  1
    arc_2_19_15  original_T_including_depot_unload_1471  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1357  1
    load_2_19_15  free_load_conservation_1437  -1
    load_2_19_15  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1359  -30
    arc_2_19_16  connected_order_arc_1360  -13
    arc_2_19_16  in_degree_1439  1
    arc_2_19_16  out_degree_1456  1
    arc_2_19_16  original_T_including_depot_unload_1471  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1359  1
    load_2_19_16  free_load_conservation_1443  -1
    load_2_19_16  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1361  -30
    arc_2_19_17  connected_order_arc_1362  -13
    arc_2_19_17  in_degree_1445  1
    arc_2_19_17  out_degree_1456  1
    arc_2_19_17  original_T_including_depot_unload_1471  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1361  1
    load_2_19_17  free_load_conservation_1449  -1
    load_2_19_17  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1363  -30
    arc_2_19_18  connected_order_arc_1364  -13
    arc_2_19_18  in_degree_1451  1
    arc_2_19_18  out_degree_1456  1
    arc_2_19_18  original_T_including_depot_unload_1471  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1363  1
    load_2_19_18  free_load_conservation_1455  -1
    load_2_19_18  free_load_conservation_1461  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1365  -30
    arc_2_19_20  connected_order_arc_1366  -13
    arc_2_19_20  out_degree_1456  1
    arc_2_19_20  in_degree_1463  1
    arc_2_19_20  original_T_including_depot_unload_1471  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1365  1
    load_2_19_20  free_load_conservation_1461  1
    load_2_19_20  free_load_conservation_1467  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1367  -30
    arc_2_20_0  depot_return_or_bypass_1391  1
    arc_2_20_0  out_degree_1462  1
    arc_2_20_0  original_T_including_depot_unload_1471  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1367  1
    load_2_20_0  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_9  arc_capacity_1368  -30
    arc_2_20_9  connected_order_arc_1369  -13
    arc_2_20_9  in_degree_1393  1
    arc_2_20_9  out_degree_1462  1
    arc_2_20_9  original_T_including_depot_unload_1471  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_9  arc_capacity_1368  1
    load_2_20_9  segment_load_conservation_1396  -1
    load_2_20_9  segment_prefix_lb_1397  1
    load_2_20_9  segment_prefix_ub_1398  1
    load_2_20_9  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1370  -30
    arc_2_20_10  connected_order_arc_1371  -13
    arc_2_20_10  in_degree_1400  1
    arc_2_20_10  out_degree_1462  1
    arc_2_20_10  original_T_including_depot_unload_1471  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1370  1
    load_2_20_10  segment_load_conservation_1403  -1
    load_2_20_10  segment_prefix_lb_1404  1
    load_2_20_10  segment_prefix_ub_1405  1
    load_2_20_10  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1372  -30
    arc_2_20_11  connected_order_arc_1373  -13
    arc_2_20_11  in_degree_1407  1
    arc_2_20_11  out_degree_1462  1
    arc_2_20_11  original_T_including_depot_unload_1471  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1372  1
    load_2_20_11  segment_load_conservation_1410  -1
    load_2_20_11  segment_prefix_lb_1411  1
    load_2_20_11  segment_prefix_ub_1412  1
    load_2_20_11  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1374  -30
    arc_2_20_12  connected_order_arc_1375  -13
    arc_2_20_12  in_degree_1414  1
    arc_2_20_12  out_degree_1462  1
    arc_2_20_12  original_T_including_depot_unload_1471  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1374  1
    load_2_20_12  segment_load_conservation_1417  -1
    load_2_20_12  segment_prefix_lb_1418  1
    load_2_20_12  segment_prefix_ub_1419  1
    load_2_20_12  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1376  -30
    arc_2_20_13  connected_order_arc_1377  -13
    arc_2_20_13  in_degree_1421  1
    arc_2_20_13  out_degree_1462  1
    arc_2_20_13  original_T_including_depot_unload_1471  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1376  1
    load_2_20_13  free_load_conservation_1425  -1
    load_2_20_13  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1378  -30
    arc_2_20_14  connected_order_arc_1379  -13
    arc_2_20_14  in_degree_1427  1
    arc_2_20_14  out_degree_1462  1
    arc_2_20_14  original_T_including_depot_unload_1471  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1378  1
    load_2_20_14  free_load_conservation_1431  -1
    load_2_20_14  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1380  -30
    arc_2_20_15  connected_order_arc_1381  -13
    arc_2_20_15  in_degree_1433  1
    arc_2_20_15  out_degree_1462  1
    arc_2_20_15  original_T_including_depot_unload_1471  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1380  1
    load_2_20_15  free_load_conservation_1437  -1
    load_2_20_15  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1382  -30
    arc_2_20_16  connected_order_arc_1383  -13
    arc_2_20_16  in_degree_1439  1
    arc_2_20_16  out_degree_1462  1
    arc_2_20_16  original_T_including_depot_unload_1471  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1382  1
    load_2_20_16  free_load_conservation_1443  -1
    load_2_20_16  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1384  -30
    arc_2_20_17  connected_order_arc_1385  -13
    arc_2_20_17  in_degree_1445  1
    arc_2_20_17  out_degree_1462  1
    arc_2_20_17  original_T_including_depot_unload_1471  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1384  1
    load_2_20_17  free_load_conservation_1449  -1
    load_2_20_17  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1386  -30
    arc_2_20_18  connected_order_arc_1387  -13
    arc_2_20_18  in_degree_1451  1
    arc_2_20_18  out_degree_1462  1
    arc_2_20_18  original_T_including_depot_unload_1471  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1386  1
    load_2_20_18  free_load_conservation_1455  -1
    load_2_20_18  free_load_conservation_1467  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1388  -30
    arc_2_20_19  connected_order_arc_1389  -13
    arc_2_20_19  in_degree_1457  1
    arc_2_20_19  out_degree_1462  1
    arc_2_20_19  original_T_including_depot_unload_1471  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1388  1
    load_2_20_19  free_load_conservation_1461  -1
    load_2_20_19  free_load_conservation_1467  1
RHS
    RHS1      OBJ       -2.4818470766301717e-01
    RHS1      onehot_30_18  1
    RHS1      onehot_35_53  1
    RHS1      onehot_34_88  1
    RHS1      onehot_24_123  1
    RHS1      onehot_29_148  1
    RHS1      onehot_28_165  1
    RHS1      onehot_27_182  1
    RHS1      onehot_33_209  1
    RHS1      stock_ub_213  26
    RHS1      parent_nonstrict_scope_214  2.8927300405298018e-01
    RHS1      normalization_271  1
    RHS1      connected_order_arc_374  -12
    RHS1      connected_order_arc_376  -12
    RHS1      connected_order_arc_378  -12
    RHS1      connected_order_arc_380  -12
    RHS1      connected_order_arc_382  -12
    RHS1      connected_order_arc_384  -12
    RHS1      connected_order_arc_386  -12
    RHS1      connected_order_arc_388  -12
    RHS1      connected_order_arc_390  -12
    RHS1      connected_order_arc_392  -12
    RHS1      connected_order_arc_394  -12
    RHS1      connected_order_arc_397  -12
    RHS1      connected_order_arc_399  -12
    RHS1      connected_order_arc_401  -12
    RHS1      connected_order_arc_403  -12
    RHS1      connected_order_arc_405  -12
    RHS1      connected_order_arc_407  -12
    RHS1      connected_order_arc_409  -12
    RHS1      connected_order_arc_411  -12
    RHS1      connected_order_arc_413  -12
    RHS1      connected_order_arc_415  -12
    RHS1      connected_order_arc_417  -12
    RHS1      connected_order_arc_420  -12
    RHS1      connected_order_arc_422  -12
    RHS1      connected_order_arc_424  -12
    RHS1      connected_order_arc_426  -12
    RHS1      connected_order_arc_428  -12
    RHS1      connected_order_arc_430  -12
    RHS1      connected_order_arc_432  -12
    RHS1      connected_order_arc_434  -12
    RHS1      connected_order_arc_436  -12
    RHS1      connected_order_arc_438  -12
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_443  -12
    RHS1      connected_order_arc_445  -12
    RHS1      connected_order_arc_447  -12
    RHS1      connected_order_arc_449  -12
    RHS1      connected_order_arc_451  -12
    RHS1      connected_order_arc_453  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_470  -12
    RHS1      connected_order_arc_472  -12
    RHS1      connected_order_arc_474  -12
    RHS1      connected_order_arc_476  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_493  -12
    RHS1      connected_order_arc_495  -12
    RHS1      connected_order_arc_497  -12
    RHS1      connected_order_arc_499  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_516  -12
    RHS1      connected_order_arc_518  -12
    RHS1      connected_order_arc_520  -12
    RHS1      connected_order_arc_522  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_539  -12
    RHS1      connected_order_arc_541  -12
    RHS1      connected_order_arc_543  -12
    RHS1      connected_order_arc_545  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_562  -12
    RHS1      connected_order_arc_564  -12
    RHS1      connected_order_arc_566  -12
    RHS1      connected_order_arc_568  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_585  -12
    RHS1      connected_order_arc_587  -12
    RHS1      connected_order_arc_589  -12
    RHS1      connected_order_arc_591  -12
    RHS1      connected_order_arc_593  -12
    RHS1      connected_order_arc_595  -12
    RHS1      connected_order_arc_597  -12
    RHS1      connected_order_arc_599  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_608  -12
    RHS1      connected_order_arc_610  -12
    RHS1      connected_order_arc_612  -12
    RHS1      connected_order_arc_614  -12
    RHS1      connected_order_arc_616  -12
    RHS1      connected_order_arc_618  -12
    RHS1      connected_order_arc_620  -12
    RHS1      connected_order_arc_622  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_627  -12
    RHS1      connected_order_arc_629  -12
    RHS1      connected_order_arc_631  -12
    RHS1      connected_order_arc_633  -12
    RHS1      connected_order_arc_635  -12
    RHS1      connected_order_arc_637  -12
    RHS1      connected_order_arc_639  -12
    RHS1      connected_order_arc_641  -12
    RHS1      connected_order_arc_643  -12
    RHS1      connected_order_arc_645  -12
    RHS1      connected_order_arc_647  -12
    RHS1      depot_departure_or_bypass_648  1
    RHS1      depot_return_or_bypass_649  1
    RHS1      segment_load_conservation_654  1
    RHS1      segment_prefix_ub_656  8
    RHS1      segment_load_conservation_661  1
    RHS1      segment_prefix_ub_663  15
    RHS1      segment_load_conservation_668  2
    RHS1      segment_prefix_ub_670  18
    RHS1      segment_load_conservation_675  -3
    RHS1      segment_prefix_lb_676  3
    RHS1      segment_prefix_ub_677  20
    RHS1      fixed_segment_relative_order_726  1
    RHS1      fixed_segment_relative_order_727  1
    RHS1      fixed_segment_relative_order_728  1
    RHS1      original_T_including_depot_unload_729  1.4344626971989874e+03
    RHS1      connected_order_arc_745  -12
    RHS1      connected_order_arc_747  -12
    RHS1      connected_order_arc_749  -12
    RHS1      connected_order_arc_751  -12
    RHS1      connected_order_arc_753  -12
    RHS1      connected_order_arc_755  -12
    RHS1      connected_order_arc_757  -12
    RHS1      connected_order_arc_759  -12
    RHS1      connected_order_arc_761  -12
    RHS1      connected_order_arc_763  -12
    RHS1      connected_order_arc_765  -12
    RHS1      connected_order_arc_768  -12
    RHS1      connected_order_arc_770  -12
    RHS1      connected_order_arc_772  -12
    RHS1      connected_order_arc_774  -12
    RHS1      connected_order_arc_776  -12
    RHS1      connected_order_arc_778  -12
    RHS1      connected_order_arc_780  -12
    RHS1      connected_order_arc_782  -12
    RHS1      connected_order_arc_784  -12
    RHS1      connected_order_arc_786  -12
    RHS1      connected_order_arc_788  -12
    RHS1      connected_order_arc_791  -12
    RHS1      connected_order_arc_793  -12
    RHS1      connected_order_arc_795  -12
    RHS1      connected_order_arc_797  -12
    RHS1      connected_order_arc_799  -12
    RHS1      connected_order_arc_801  -12
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_809  -12
    RHS1      connected_order_arc_811  -12
    RHS1      connected_order_arc_814  -12
    RHS1      connected_order_arc_816  -12
    RHS1      connected_order_arc_818  -12
    RHS1      connected_order_arc_820  -12
    RHS1      connected_order_arc_822  -12
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      depot_departure_or_bypass_1019  1
    RHS1      depot_return_or_bypass_1020  1
    RHS1      segment_load_conservation_1025  -1
    RHS1      segment_prefix_lb_1026  1
    RHS1      segment_prefix_ub_1027  25
    RHS1      segment_load_conservation_1032  5
    RHS1      segment_prefix_ub_1034  20
    RHS1      segment_load_conservation_1039  -4
    RHS1      segment_prefix_lb_1040  4
    RHS1      segment_prefix_ub_1041  25
    RHS1      segment_load_conservation_1046  -5
    RHS1      segment_prefix_lb_1047  5
    RHS1      segment_prefix_ub_1048  25
    RHS1      fixed_segment_relative_order_1097  1
    RHS1      fixed_segment_relative_order_1098  1
    RHS1      fixed_segment_relative_order_1099  1
    RHS1      original_T_including_depot_unload_1100  5700
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1134  -12
    RHS1      connected_order_arc_1136  -12
    RHS1      connected_order_arc_1139  -12
    RHS1      connected_order_arc_1141  -12
    RHS1      connected_order_arc_1143  -12
    RHS1      connected_order_arc_1145  -12
    RHS1      connected_order_arc_1147  -12
    RHS1      connected_order_arc_1149  -12
    RHS1      connected_order_arc_1151  -12
    RHS1      connected_order_arc_1153  -12
    RHS1      connected_order_arc_1155  -12
    RHS1      connected_order_arc_1157  -12
    RHS1      connected_order_arc_1159  -12
    RHS1      connected_order_arc_1162  -12
    RHS1      connected_order_arc_1164  -12
    RHS1      connected_order_arc_1166  -12
    RHS1      connected_order_arc_1168  -12
    RHS1      connected_order_arc_1170  -12
    RHS1      connected_order_arc_1172  -12
    RHS1      connected_order_arc_1174  -12
    RHS1      connected_order_arc_1176  -12
    RHS1      connected_order_arc_1178  -12
    RHS1      connected_order_arc_1180  -12
    RHS1      connected_order_arc_1182  -12
    RHS1      connected_order_arc_1185  -12
    RHS1      connected_order_arc_1187  -12
    RHS1      connected_order_arc_1189  -12
    RHS1      connected_order_arc_1191  -12
    RHS1      connected_order_arc_1193  -12
    RHS1      connected_order_arc_1195  -12
    RHS1      connected_order_arc_1197  -12
    RHS1      connected_order_arc_1199  -12
    RHS1      connected_order_arc_1201  -12
    RHS1      connected_order_arc_1203  -12
    RHS1      connected_order_arc_1205  -12
    RHS1      connected_order_arc_1208  -12
    RHS1      connected_order_arc_1210  -12
    RHS1      connected_order_arc_1212  -12
    RHS1      connected_order_arc_1214  -12
    RHS1      connected_order_arc_1216  -12
    RHS1      connected_order_arc_1218  -12
    RHS1      connected_order_arc_1220  -12
    RHS1      connected_order_arc_1222  -12
    RHS1      connected_order_arc_1224  -12
    RHS1      connected_order_arc_1226  -12
    RHS1      connected_order_arc_1228  -12
    RHS1      connected_order_arc_1231  -12
    RHS1      connected_order_arc_1233  -12
    RHS1      connected_order_arc_1235  -12
    RHS1      connected_order_arc_1237  -12
    RHS1      connected_order_arc_1239  -12
    RHS1      connected_order_arc_1241  -12
    RHS1      connected_order_arc_1243  -12
    RHS1      connected_order_arc_1245  -12
    RHS1      connected_order_arc_1247  -12
    RHS1      connected_order_arc_1249  -12
    RHS1      connected_order_arc_1251  -12
    RHS1      connected_order_arc_1254  -12
    RHS1      connected_order_arc_1256  -12
    RHS1      connected_order_arc_1258  -12
    RHS1      connected_order_arc_1260  -12
    RHS1      connected_order_arc_1262  -12
    RHS1      connected_order_arc_1264  -12
    RHS1      connected_order_arc_1266  -12
    RHS1      connected_order_arc_1268  -12
    RHS1      connected_order_arc_1270  -12
    RHS1      connected_order_arc_1272  -12
    RHS1      connected_order_arc_1274  -12
    RHS1      connected_order_arc_1277  -12
    RHS1      connected_order_arc_1279  -12
    RHS1      connected_order_arc_1281  -12
    RHS1      connected_order_arc_1283  -12
    RHS1      connected_order_arc_1285  -12
    RHS1      connected_order_arc_1287  -12
    RHS1      connected_order_arc_1289  -12
    RHS1      connected_order_arc_1291  -12
    RHS1      connected_order_arc_1293  -12
    RHS1      connected_order_arc_1295  -12
    RHS1      connected_order_arc_1297  -12
    RHS1      connected_order_arc_1300  -12
    RHS1      connected_order_arc_1302  -12
    RHS1      connected_order_arc_1304  -12
    RHS1      connected_order_arc_1306  -12
    RHS1      connected_order_arc_1308  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1323  -12
    RHS1      connected_order_arc_1325  -12
    RHS1      connected_order_arc_1327  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1346  -12
    RHS1      connected_order_arc_1348  -12
    RHS1      connected_order_arc_1350  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1354  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1362  -12
    RHS1      connected_order_arc_1364  -12
    RHS1      connected_order_arc_1366  -12
    RHS1      connected_order_arc_1369  -12
    RHS1      connected_order_arc_1371  -12
    RHS1      connected_order_arc_1373  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1377  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1385  -12
    RHS1      connected_order_arc_1387  -12
    RHS1      connected_order_arc_1389  -12
    RHS1      depot_departure_or_bypass_1390  1
    RHS1      depot_return_or_bypass_1391  1
    RHS1      segment_load_conservation_1396  2
    RHS1      segment_prefix_ub_1398  28
    RHS1      segment_load_conservation_1403  2
    RHS1      segment_prefix_ub_1405  28
    RHS1      segment_load_conservation_1410  -4
    RHS1      segment_prefix_lb_1411  4
    RHS1      segment_prefix_ub_1412  30
    RHS1      segment_load_conservation_1417  -3
    RHS1      segment_prefix_lb_1418  3
    RHS1      segment_prefix_ub_1419  30
    RHS1      fixed_segment_relative_order_1468  1
    RHS1      fixed_segment_relative_order_1469  1
    RHS1      fixed_segment_relative_order_1470  1
    RHS1      original_T_including_depot_unload_1471  5820
BOUNDS
 LO BND1      t         2.5331724969817847e-02
 UP BND1      t         4.2281169779072841e-02
 UP BND1      q         4.0666271100568246e-01
 BV BND1      x_30_0  
 UP BND1      w_30_0    4.2281169779072841e-02
 BV BND1      x_30_1  
 UP BND1      w_30_1    4.2281169779072841e-02
 BV BND1      x_30_2  
 UP BND1      w_30_2    4.2281169779072841e-02
 BV BND1      x_30_3  
 UP BND1      w_30_3    4.2281169779072841e-02
 BV BND1      x_30_4  
 UP BND1      w_30_4    4.2281169779072841e-02
 BV BND1      x_30_5  
 UP BND1      w_30_5    4.2281169779072841e-02
 BV BND1      x_30_6  
 UP BND1      w_30_6    4.2281169779072841e-02
 BV BND1      x_30_7  
 UP BND1      w_30_7    4.2281169779072841e-02
 BV BND1      x_30_8  
 UP BND1      w_30_8    4.2281169779072841e-02
 UP BND1      rho_30    1
 BV BND1      x_35_0  
 UP BND1      w_35_0    4.2281169779072841e-02
 BV BND1      x_35_1  
 UP BND1      w_35_1    4.2281169779072841e-02
 BV BND1      x_35_2  
 UP BND1      w_35_2    4.2281169779072841e-02
 BV BND1      x_35_3  
 UP BND1      w_35_3    4.2281169779072841e-02
 BV BND1      x_35_4  
 UP BND1      w_35_4    4.2281169779072841e-02
 BV BND1      x_35_5  
 UP BND1      w_35_5    4.2281169779072841e-02
 BV BND1      x_35_6  
 UP BND1      w_35_6    4.2281169779072841e-02
 BV BND1      x_35_7  
 UP BND1      w_35_7    4.2281169779072841e-02
 BV BND1      x_35_8  
 UP BND1      w_35_8    4.2281169779072841e-02
 BV BND1      x_35_9  
 UP BND1      w_35_9    4.2281169779072841e-02
 BV BND1      x_35_10 
 UP BND1      w_35_10   4.2281169779072841e-02
 BV BND1      x_35_11 
 UP BND1      w_35_11   4.2281169779072841e-02
 BV BND1      x_35_12 
 UP BND1      w_35_12   4.2281169779072841e-02
 BV BND1      x_35_13 
 UP BND1      w_35_13   4.2281169779072841e-02
 BV BND1      x_35_14 
 UP BND1      w_35_14   4.2281169779072841e-02
 BV BND1      x_35_15 
 UP BND1      w_35_15   4.2281169779072841e-02
 UP BND1      rho_35    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.2281169779072841e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.2281169779072841e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.2281169779072841e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.2281169779072841e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.2281169779072841e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.2281169779072841e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.2281169779072841e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.2281169779072841e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.2281169779072841e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.2281169779072841e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.2281169779072841e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.2281169779072841e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.2281169779072841e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.2281169779072841e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.2281169779072841e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.2281169779072841e-02
 UP BND1      rho_34    1
 BV BND1      x_24_0  
 UP BND1      w_24_0    4.2281169779072841e-02
 BV BND1      x_24_1  
 UP BND1      w_24_1    4.2281169779072841e-02
 BV BND1      x_24_2  
 UP BND1      w_24_2    4.2281169779072841e-02
 BV BND1      x_24_3  
 UP BND1      w_24_3    4.2281169779072841e-02
 BV BND1      x_24_4  
 UP BND1      w_24_4    4.2281169779072841e-02
 BV BND1      x_24_5  
 UP BND1      w_24_5    4.2281169779072841e-02
 BV BND1      x_24_6  
 UP BND1      w_24_6    4.2281169779072841e-02
 BV BND1      x_24_7  
 UP BND1      w_24_7    4.2281169779072841e-02
 BV BND1      x_24_8  
 UP BND1      w_24_8    4.2281169779072841e-02
 BV BND1      x_24_9  
 UP BND1      w_24_9    4.2281169779072841e-02
 BV BND1      x_24_10 
 UP BND1      w_24_10   4.2281169779072841e-02
 BV BND1      x_24_11 
 UP BND1      w_24_11   4.2281169779072841e-02
 BV BND1      x_24_12 
 UP BND1      w_24_12   4.2281169779072841e-02
 BV BND1      x_24_13 
 UP BND1      w_24_13   4.2281169779072841e-02
 BV BND1      x_24_14 
 UP BND1      w_24_14   4.2281169779072841e-02
 BV BND1      x_24_15 
 UP BND1      w_24_15   4.2281169779072841e-02
 UP BND1      rho_24    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.2281169779072841e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.2281169779072841e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.2281169779072841e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.2281169779072841e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.2281169779072841e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.2281169779072841e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.2281169779072841e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.2281169779072841e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.2281169779072841e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.2281169779072841e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.2281169779072841e-02
 UP BND1      rho_29    1
 BV BND1      x_28_0  
 UP BND1      w_28_0    4.2281169779072841e-02
 BV BND1      x_28_1  
 UP BND1      w_28_1    4.2281169779072841e-02
 BV BND1      x_28_2  
 UP BND1      w_28_2    4.2281169779072841e-02
 BV BND1      x_28_3  
 UP BND1      w_28_3    4.2281169779072841e-02
 BV BND1      x_28_4  
 UP BND1      w_28_4    4.2281169779072841e-02
 BV BND1      x_28_5  
 UP BND1      w_28_5    4.2281169779072841e-02
 BV BND1      x_28_6  
 UP BND1      w_28_6    4.2281169779072841e-02
 UP BND1      rho_28    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.2281169779072841e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.2281169779072841e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.2281169779072841e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.2281169779072841e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.2281169779072841e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.2281169779072841e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.2281169779072841e-02
 UP BND1      rho_27    1
 BV BND1      x_33_0  
 UP BND1      w_33_0    4.2281169779072841e-02
 BV BND1      x_33_1  
 UP BND1      w_33_1    4.2281169779072841e-02
 BV BND1      x_33_2  
 UP BND1      w_33_2    4.2281169779072841e-02
 BV BND1      x_33_3  
 UP BND1      w_33_3    4.2281169779072841e-02
 BV BND1      x_33_4  
 UP BND1      w_33_4    4.2281169779072841e-02
 BV BND1      x_33_5  
 UP BND1      w_33_5    4.2281169779072841e-02
 BV BND1      x_33_6  
 UP BND1      w_33_6    4.2281169779072841e-02
 BV BND1      x_33_7  
 UP BND1      w_33_7    4.2281169779072841e-02
 BV BND1      x_33_8  
 UP BND1      w_33_8    4.2281169779072841e-02
 BV BND1      x_33_9  
 UP BND1      w_33_9    4.2281169779072841e-02
 BV BND1      x_33_10 
 UP BND1      w_33_10   4.2281169779072841e-02
 BV BND1      x_33_11 
 UP BND1      w_33_11   4.2281169779072841e-02
 UP BND1      rho_33    1
 UP BND1      a_30_35   1
 UP BND1      a_30_34   1
 UP BND1      a_30_24   1
 UP BND1      a_30_29   1
 UP BND1      a_30_28   1
 UP BND1      a_30_27   1
 UP BND1      a_30_33   1
 UP BND1      a_35_34   1
 UP BND1      a_35_24   1
 UP BND1      a_35_29   1
 UP BND1      a_35_28   1
 UP BND1      a_35_27   1
 UP BND1      a_35_33   1
 UP BND1      a_34_24   1
 UP BND1      a_34_29   1
 UP BND1      a_34_28   1
 UP BND1      a_34_27   1
 UP BND1      a_34_33   1
 UP BND1      a_24_29   1
 UP BND1      a_24_28   1
 UP BND1      a_24_27   1
 UP BND1      a_24_33   1
 UP BND1      a_29_28   1
 UP BND1      a_29_27   1
 UP BND1      a_29_33   1
 UP BND1      a_28_27   1
 UP BND1      a_28_33   1
 UP BND1      a_27_33   1
 BV BND1      service_0_30_0
 BV BND1      service_0_30_1
 BV BND1      service_0_30_2
 BV BND1      service_0_30_3
 BV BND1      service_0_30_4
 BV BND1      service_0_30_6
 BV BND1      service_0_30_7
 BV BND1      service_0_30_8
 BV BND1      service_1_30_0
 BV BND1      service_1_30_1
 BV BND1      service_1_30_2
 BV BND1      service_1_30_3
 BV BND1      service_1_30_4
 BV BND1      service_1_30_6
 BV BND1      service_1_30_7
 BV BND1      service_1_30_8
 BV BND1      service_2_30_0
 BV BND1      service_2_30_1
 BV BND1      service_2_30_2
 BV BND1      service_2_30_3
 BV BND1      service_2_30_4
 BV BND1      service_2_30_6
 BV BND1      service_2_30_7
 BV BND1      service_2_30_8
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_11
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_11
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_11
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_24_0
 BV BND1      service_0_24_1
 BV BND1      service_0_24_2
 BV BND1      service_0_24_3
 BV BND1      service_0_24_4
 BV BND1      service_0_24_5
 BV BND1      service_0_24_6
 BV BND1      service_0_24_7
 BV BND1      service_0_24_8
 BV BND1      service_0_24_9
 BV BND1      service_0_24_10
 BV BND1      service_0_24_11
 BV BND1      service_0_24_12
 BV BND1      service_0_24_14
 BV BND1      service_0_24_15
 BV BND1      service_1_24_0
 BV BND1      service_1_24_1
 BV BND1      service_1_24_2
 BV BND1      service_1_24_3
 BV BND1      service_1_24_4
 BV BND1      service_1_24_5
 BV BND1      service_1_24_6
 BV BND1      service_1_24_7
 BV BND1      service_1_24_8
 BV BND1      service_1_24_9
 BV BND1      service_1_24_10
 BV BND1      service_1_24_11
 BV BND1      service_1_24_12
 BV BND1      service_1_24_14
 BV BND1      service_1_24_15
 BV BND1      service_2_24_0
 BV BND1      service_2_24_1
 BV BND1      service_2_24_2
 BV BND1      service_2_24_3
 BV BND1      service_2_24_4
 BV BND1      service_2_24_5
 BV BND1      service_2_24_6
 BV BND1      service_2_24_7
 BV BND1      service_2_24_8
 BV BND1      service_2_24_9
 BV BND1      service_2_24_10
 BV BND1      service_2_24_11
 BV BND1      service_2_24_12
 BV BND1      service_2_24_14
 BV BND1      service_2_24_15
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_28_0
 BV BND1      service_0_28_2
 BV BND1      service_0_28_3
 BV BND1      service_0_28_4
 BV BND1      service_0_28_5
 BV BND1      service_0_28_6
 BV BND1      service_1_28_0
 BV BND1      service_1_28_2
 BV BND1      service_1_28_3
 BV BND1      service_1_28_4
 BV BND1      service_1_28_5
 BV BND1      service_1_28_6
 BV BND1      service_2_28_0
 BV BND1      service_2_28_2
 BV BND1      service_2_28_3
 BV BND1      service_2_28_4
 BV BND1      service_2_28_5
 BV BND1      service_2_28_6
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_33_0
 BV BND1      service_0_33_1
 BV BND1      service_0_33_2
 BV BND1      service_0_33_3
 BV BND1      service_0_33_4
 BV BND1      service_0_33_5
 BV BND1      service_0_33_6
 BV BND1      service_0_33_7
 BV BND1      service_0_33_9
 BV BND1      service_0_33_10
 BV BND1      service_0_33_11
 BV BND1      service_1_33_0
 BV BND1      service_1_33_1
 BV BND1      service_1_33_2
 BV BND1      service_1_33_3
 BV BND1      service_1_33_4
 BV BND1      service_1_33_5
 BV BND1      service_1_33_6
 BV BND1      service_1_33_7
 BV BND1      service_1_33_9
 BV BND1      service_1_33_10
 BV BND1      service_1_33_11
 BV BND1      service_2_33_0
 BV BND1      service_2_33_1
 BV BND1      service_2_33_2
 BV BND1      service_2_33_3
 BV BND1      service_2_33_4
 BV BND1      service_2_33_5
 BV BND1      service_2_33_6
 BV BND1      service_2_33_7
 BV BND1      service_2_33_9
 BV BND1      service_2_33_10
 BV BND1      service_2_33_11
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_5_20
 UP BND1      load_1_5_20  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_5
 UP BND1      load_1_20_5  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  12
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_9_20
 UP BND1      load_2_9_20  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_9
 UP BND1      load_2_20_9  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
