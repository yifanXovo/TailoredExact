* Signature: 0xc08c20f07084dcdf
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
 L  column_13
 L  column_14
 L  column_15
 L  column_16
 L  column_17
 L  column_18
 L  column_19
 L  column_20
 L  column_21
 L  column_22
 L  column_23
 L  column_24
 L  column_25
 L  column_26
 L  column_27
 L  column_28
 L  column_29
 L  column_30
 L  column_31
 L  column_32
 L  column_33
 L  column_34
 L  column_35
 L  column_36
 L  column_37
 L  column_38
 L  column_39
 L  column_40
 L  column_41
 L  column_42
 L  column_43
 L  column_44
 L  column_45
 L  column_46
 L  column_47
 L  column_48
 L  column_49
 L  column_50
 L  column_51
 L  column_52
 L  column_53
 L  column_54
 L  column_55
 L  column_56
 L  column_57
 L  column_58
 L  column_59
 L  column_60
 L  column_61
 L  column_62
 L  column_63
 L  column_64
 L  column_65
 L  column_66
 L  column_67
 L  column_68
 L  column_69
 L  column_70
 L  column_71
 L  column_72
 L  column_73
 L  column_74
 L  column_75
 L  column_76
 L  column_77
 L  column_78
 L  column_79
 L  column_80
 L  column_81
 L  column_82
 L  column_83
 L  column_84
 L  column_85
 L  column_86
 L  column_87
 L  column_88
 L  column_89
 L  column_90
 L  column_91
 L  column_92
 L  column_93
 L  column_94
 L  column_95
 L  column_96
 L  column_97
 L  column_98
 L  column_99
 L  column_100
 L  column_101
COLUMNS
    psi[1,0]  OBJ       0
    psi[1,1]  OBJ       0
    psi[1,2]  OBJ       2.3577480013138991e-02
    psi[1,2]  column_0  1
    psi[1,2]  column_1  1
    psi[1,2]  column_2  1
    psi[1,2]  column_3  1
    psi[1,2]  column_4  1
    psi[1,2]  column_5  1
    psi[1,2]  column_6  1
    psi[1,2]  column_7  1
    psi[1,2]  column_8  1
    psi[1,2]  column_9  1
    psi[1,2]  column_10  1
    psi[1,3]  OBJ       0
    psi[1,4]  OBJ       0
    psi[1,5]  column_11  1
    psi[1,5]  column_12  1
    psi[1,5]  column_13  1
    psi[1,6]  OBJ       0
    psi[1,7]  OBJ       0
    psi[1,8]  OBJ       5.9591334901644011e-01
    psi[1,8]  column_14  1
    psi[1,8]  column_15  1
    psi[1,8]  column_16  1
    psi[1,8]  column_17  1
    psi[1,8]  column_18  1
    psi[1,8]  column_19  1
    psi[1,8]  column_20  1
    psi[1,8]  column_21  1
    psi[1,8]  column_22  1
    psi[1,8]  column_23  1
    psi[1,8]  column_24  1
    psi[1,8]  column_25  1
    psi[1,8]  column_26  1
    psi[1,8]  column_27  1
    psi[1,8]  column_28  1
    psi[1,8]  column_29  1
    psi[1,8]  column_30  1
    psi[1,8]  column_31  1
    psi[1,8]  column_32  1
    psi[1,8]  column_33  1
    psi[1,8]  column_34  1
    psi[1,8]  column_35  1
    psi[1,8]  column_36  1
    psi[1,8]  column_37  1
    psi[1,9]  column_38  1
    psi[1,9]  column_39  1
    psi[1,9]  column_40  1
    psi[1,9]  column_41  1
    psi[1,9]  column_42  1
    psi[1,9]  column_43  1
    psi[1,9]  column_44  1
    psi[1,9]  column_45  1
    psi[1,9]  column_46  1
    psi[1,9]  column_47  1
    psi[1,10]  OBJ       3.8050917097042092e-01
    psi[1,10]  column_48  1
    psi[1,10]  column_49  1
    psi[1,10]  column_50  1
    psi[1,10]  column_51  1
    psi[1,10]  column_52  1
    psi[1,10]  column_53  1
    psi[1,10]  column_54  1
    psi[1,10]  column_55  1
    psi[1,10]  column_56  1
    psi[1,10]  column_57  1
    psi[1,10]  column_58  1
    psi[1,10]  column_59  1
    psi[1,10]  column_60  1
    psi[1,10]  column_61  1
    psi[1,10]  column_62  1
    psi[1,10]  column_63  1
    psi[1,10]  column_64  1
    psi[1,10]  column_65  1
    psi[1,10]  column_66  1
    psi[1,10]  column_67  1
    psi[1,10]  column_68  1
    psi[1,10]  column_69  1
    psi[1,10]  column_70  1
    psi[1,10]  column_71  1
    psi[1,10]  column_72  1
    psi[1,10]  column_73  1
    psi[1,10]  column_74  1
    psi[1,10]  column_75  1
    psi[1,10]  column_76  1
    psi[1,10]  column_77  1
    psi[1,10]  column_78  1
    psi[1,10]  column_79  1
    psi[1,10]  column_80  1
    psi[1,10]  column_81  1
    psi[1,10]  column_82  1
    psi[1,10]  column_83  1
    psi[1,10]  column_84  1
    psi[1,10]  column_85  1
    psi[1,10]  column_86  1
    psi[1,10]  column_87  1
    psi[1,10]  column_88  1
    psi[1,10]  column_89  1
    psi[1,10]  column_90  1
    psi[1,10]  column_91  1
    psi[1,10]  column_92  1
    psi[1,10]  column_93  1
    psi[1,10]  column_94  1
    psi[1,10]  column_95  1
    psi[1,10]  column_96  1
    psi[1,10]  column_97  1
    psi[1,10]  column_98  1
    psi[1,10]  column_99  1
    psi[1,10]  column_100  1
    psi[1,10]  column_101  1
    psi[1,11]  OBJ       0
    psi[1,12]  OBJ       0
    psi[1,13]  OBJ       0
    psi[1,14]  OBJ       0
    psi[1,15]  OBJ       0
    psi[1,16]  OBJ       0
    psi[1,17]  OBJ       0
    psi[1,18]  OBJ       0
    psi[1,19]  OBJ       0
    psi[2,0]  OBJ       0
    psi[2,1]  OBJ       0
    psi[2,2]  OBJ       0
    psi[2,3]  column_0  1
    psi[2,3]  column_1  1
    psi[2,3]  column_2  1
    psi[2,3]  column_38  1
    psi[2,3]  column_39  1
    psi[2,3]  column_40  1
    psi[2,3]  column_41  1
    psi[2,3]  column_42  1
    psi[2,3]  column_43  1
    psi[2,3]  column_44  1
    psi[2,3]  column_45  1
    psi[2,3]  column_46  1
    psi[2,3]  column_48  1
    psi[2,3]  column_49  1
    psi[2,3]  column_50  1
    psi[2,3]  column_51  1
    psi[2,3]  column_52  1
    psi[2,3]  column_53  1
    psi[2,3]  column_54  1
    psi[2,3]  column_55  1
    psi[2,3]  column_56  1
    psi[2,3]  column_57  1
    psi[2,3]  column_58  1
    psi[2,3]  column_59  1
    psi[2,3]  column_60  1
    psi[2,3]  column_61  1
    psi[2,3]  column_62  1
    psi[2,3]  column_63  1
    psi[2,3]  column_64  1
    psi[2,3]  column_65  1
    psi[2,3]  column_66  1
    psi[2,4]  OBJ       0
    psi[2,5]  column_3  1
    psi[2,5]  column_4  1
    psi[2,5]  column_11  1
    psi[2,5]  column_12  1
    psi[2,5]  column_13  1
    psi[2,5]  column_14  1
    psi[2,5]  column_67  1
    psi[2,5]  column_68  1
    psi[2,6]  OBJ       9.6631257669659387e-01
    psi[2,6]  column_5  1
    psi[2,6]  column_6  1
    psi[2,6]  column_7  1
    psi[2,6]  column_8  1
    psi[2,6]  column_15  1
    psi[2,6]  column_16  1
    psi[2,6]  column_17  1
    psi[2,6]  column_18  1
    psi[2,6]  column_19  1
    psi[2,6]  column_20  1
    psi[2,6]  column_21  1
    psi[2,6]  column_22  1
    psi[2,6]  column_23  1
    psi[2,6]  column_24  1
    psi[2,6]  column_25  1
    psi[2,6]  column_26  1
    psi[2,6]  column_27  1
    psi[2,6]  column_28  1
    psi[2,6]  column_29  1
    psi[2,6]  column_30  1
    psi[2,6]  column_31  1
    psi[2,6]  column_32  1
    psi[2,6]  column_33  1
    psi[2,6]  column_69  1
    psi[2,6]  column_70  1
    psi[2,6]  column_71  1
    psi[2,6]  column_72  1
    psi[2,6]  column_73  1
    psi[2,6]  column_74  1
    psi[2,6]  column_75  1
    psi[2,6]  column_76  1
    psi[2,6]  column_77  1
    psi[2,6]  column_78  1
    psi[2,6]  column_79  1
    psi[2,6]  column_80  1
    psi[2,6]  column_81  1
    psi[2,6]  column_82  1
    psi[2,6]  column_83  1
    psi[2,6]  column_84  1
    psi[2,6]  column_85  1
    psi[2,7]  OBJ       3.3687423303406128e-02
    psi[2,7]  column_9  1
    psi[2,7]  column_10  1
    psi[2,7]  column_34  1
    psi[2,7]  column_35  1
    psi[2,7]  column_36  1
    psi[2,7]  column_37  1
    psi[2,7]  column_47  1
    psi[2,7]  column_86  1
    psi[2,7]  column_87  1
    psi[2,7]  column_88  1
    psi[2,7]  column_89  1
    psi[2,7]  column_90  1
    psi[2,7]  column_91  1
    psi[2,7]  column_92  1
    psi[2,7]  column_93  1
    psi[2,7]  column_94  1
    psi[2,7]  column_95  1
    psi[2,7]  column_96  1
    psi[2,7]  column_97  1
    psi[2,7]  column_98  1
    psi[2,7]  column_99  1
    psi[2,7]  column_100  1
    psi[2,7]  column_101  1
    psi[2,8]  OBJ       0
    psi[2,9]  OBJ       0
    psi[2,10]  OBJ       0
    psi[2,11]  OBJ       0
    psi[2,12]  OBJ       0
    psi[2,13]  OBJ       0
    psi[2,14]  OBJ       0
    psi[2,15]  OBJ       0
    psi[3,0]  OBJ       0
    psi[3,1]  OBJ       0
    psi[3,2]  OBJ       0
    psi[3,3]  column_0  1
    psi[3,3]  column_1  1
    psi[3,3]  column_38  1
    psi[3,3]  column_48  1
    psi[3,3]  column_49  1
    psi[3,3]  column_50  1
    psi[3,3]  column_51  1
    psi[3,3]  column_52  1
    psi[3,3]  column_86  1
    psi[3,4]  column_2  1
    psi[3,4]  column_39  1
    psi[3,4]  column_40  1
    psi[3,4]  column_41  1
    psi[3,4]  column_47  1
    psi[3,4]  column_53  1
    psi[3,4]  column_54  1
    psi[3,5]  column_55  1
    psi[3,5]  column_56  1
    psi[3,5]  column_57  1
    psi[3,6]  OBJ       1.0435723051039414e-01
    psi[3,6]  column_5  1
    psi[3,6]  column_6  1
    psi[3,6]  column_7  1
    psi[3,6]  column_8  1
    psi[3,6]  column_11  1
    psi[3,6]  column_12  1
    psi[3,6]  column_13  1
    psi[3,6]  column_14  1
    psi[3,6]  column_15  1
    psi[3,6]  column_16  1
    psi[3,6]  column_17  1
    psi[3,6]  column_18  1
    psi[3,6]  column_19  1
    psi[3,6]  column_67  1
    psi[3,6]  column_68  1
    psi[3,7]  OBJ       8.9564276948960586e-01
    psi[3,7]  column_20  1
    psi[3,7]  column_21  1
    psi[3,7]  column_22  1
    psi[3,7]  column_23  1
    psi[3,7]  column_24  1
    psi[3,7]  column_25  1
    psi[3,7]  column_26  1
    psi[3,7]  column_27  1
    psi[3,7]  column_28  1
    psi[3,7]  column_29  1
    psi[3,7]  column_30  1
    psi[3,7]  column_31  1
    psi[3,7]  column_32  1
    psi[3,7]  column_33  1
    psi[3,7]  column_34  1
    psi[3,7]  column_35  1
    psi[3,7]  column_36  1
    psi[3,7]  column_37  1
    psi[3,7]  column_58  1
    psi[3,7]  column_59  1
    psi[3,7]  column_60  1
    psi[3,7]  column_61  1
    psi[3,7]  column_62  1
    psi[3,7]  column_63  1
    psi[3,7]  column_64  1
    psi[3,7]  column_69  1
    psi[3,7]  column_70  1
    psi[3,7]  column_71  1
    psi[3,7]  column_72  1
    psi[3,7]  column_73  1
    psi[3,7]  column_74  1
    psi[3,7]  column_75  1
    psi[3,7]  column_76  1
    psi[3,7]  column_77  1
    psi[3,7]  column_78  1
    psi[3,7]  column_79  1
    psi[3,7]  column_80  1
    psi[3,7]  column_81  1
    psi[3,7]  column_82  1
    psi[3,7]  column_83  1
    psi[3,7]  column_84  1
    psi[3,7]  column_85  1
    psi[3,7]  column_87  1
    psi[3,7]  column_88  1
    psi[3,8]  column_3  1
    psi[3,8]  column_4  1
    psi[3,8]  column_9  1
    psi[3,8]  column_10  1
    psi[3,8]  column_42  1
    psi[3,8]  column_43  1
    psi[3,8]  column_44  1
    psi[3,8]  column_45  1
    psi[3,8]  column_46  1
    psi[3,8]  column_65  1
    psi[3,8]  column_66  1
    psi[3,8]  column_89  1
    psi[3,8]  column_90  1
    psi[3,8]  column_91  1
    psi[3,8]  column_92  1
    psi[3,8]  column_93  1
    psi[3,8]  column_94  1
    psi[3,8]  column_95  1
    psi[3,8]  column_96  1
    psi[3,8]  column_97  1
    psi[3,8]  column_98  1
    psi[3,8]  column_99  1
    psi[3,8]  column_100  1
    psi[3,8]  column_101  1
    psi[3,9]  OBJ       0
    psi[3,10]  OBJ       0
    psi[3,11]  OBJ       0
    psi[3,12]  OBJ       0
    psi[3,13]  OBJ       0
    psi[3,14]  OBJ       0
    psi[3,15]  OBJ       0
    psi[3,16]  OBJ       0
    psi[3,17]  OBJ       0
    psi[4,0]  OBJ       0
    psi[4,1]  OBJ       0
    psi[4,2]  OBJ       0
    psi[4,3]  column_0  1
    psi[4,3]  column_1  1
    psi[4,3]  column_39  1
    psi[4,3]  column_42  1
    psi[4,3]  column_43  1
    psi[4,3]  column_44  1
    psi[4,3]  column_45  1
    psi[4,3]  column_46  1
    psi[4,3]  column_48  1
    psi[4,3]  column_49  1
    psi[4,3]  column_50  1
    psi[4,3]  column_51  1
    psi[4,3]  column_53  1
    psi[4,3]  column_54  1
    psi[4,3]  column_58  1
    psi[4,3]  column_59  1
    psi[4,3]  column_65  1
    psi[4,3]  column_86  1
    psi[4,3]  column_87  1
    psi[4,4]  column_2  1
    psi[4,4]  column_3  1
    psi[4,4]  column_4  1
    psi[4,4]  column_9  1
    psi[4,4]  column_11  1
    psi[4,4]  column_12  1
    psi[4,4]  column_13  1
    psi[4,4]  column_14  1
    psi[4,4]  column_38  1
    psi[4,4]  column_40  1
    psi[4,4]  column_41  1
    psi[4,4]  column_47  1
    psi[4,4]  column_52  1
    psi[4,4]  column_66  1
    psi[4,4]  column_67  1
    psi[4,4]  column_68  1
    psi[4,4]  column_89  1
    psi[4,5]  column_55  1
    psi[4,5]  column_56  1
    psi[4,5]  column_57  1
    psi[4,5]  column_60  1
    psi[4,5]  column_61  1
    psi[4,5]  column_62  1
    psi[4,5]  column_63  1
    psi[4,6]  OBJ       9.6631257669659476e-01
    psi[4,6]  column_5  1
    psi[4,6]  column_6  1
    psi[4,6]  column_7  1
    psi[4,6]  column_8  1
    psi[4,6]  column_15  1
    psi[4,6]  column_16  1
    psi[4,6]  column_17  1
    psi[4,6]  column_18  1
    psi[4,6]  column_19  1
    psi[4,6]  column_20  1
    psi[4,6]  column_21  1
    psi[4,6]  column_22  1
    psi[4,6]  column_23  1
    psi[4,6]  column_24  1
    psi[4,6]  column_25  1
    psi[4,6]  column_26  1
    psi[4,6]  column_27  1
    psi[4,6]  column_28  1
    psi[4,6]  column_29  1
    psi[4,6]  column_30  1
    psi[4,6]  column_31  1
    psi[4,6]  column_32  1
    psi[4,6]  column_33  1
    psi[4,6]  column_34  1
    psi[4,6]  column_35  1
    psi[4,6]  column_36  1
    psi[4,6]  column_37  1
    psi[4,6]  column_64  1
    psi[4,6]  column_69  1
    psi[4,6]  column_70  1
    psi[4,6]  column_71  1
    psi[4,6]  column_72  1
    psi[4,6]  column_73  1
    psi[4,6]  column_74  1
    psi[4,6]  column_75  1
    psi[4,6]  column_76  1
    psi[4,6]  column_77  1
    psi[4,6]  column_78  1
    psi[4,6]  column_79  1
    psi[4,6]  column_80  1
    psi[4,6]  column_81  1
    psi[4,6]  column_82  1
    psi[4,6]  column_83  1
    psi[4,6]  column_84  1
    psi[4,7]  OBJ       3.3687423303405239e-02
    psi[4,7]  column_10  1
    psi[4,7]  column_85  1
    psi[4,7]  column_88  1
    psi[4,7]  column_90  1
    psi[4,7]  column_91  1
    psi[4,7]  column_92  1
    psi[4,7]  column_93  1
    psi[4,7]  column_94  1
    psi[4,7]  column_95  1
    psi[4,7]  column_96  1
    psi[4,7]  column_97  1
    psi[4,7]  column_98  1
    psi[4,7]  column_99  1
    psi[4,7]  column_100  1
    psi[4,7]  column_101  1
    psi[4,8]  OBJ       0
    psi[4,9]  OBJ       0
    psi[4,10]  OBJ       0
    psi[4,11]  OBJ       0
    psi[4,12]  OBJ       0
    psi[4,13]  OBJ       0
    psi[4,14]  OBJ       0
    psi[4,15]  OBJ       0
    psi[5,0]  OBJ       0
    psi[5,1]  OBJ       0
    psi[5,2]  OBJ       0.0854774977875351
    psi[5,2]  column_0  1
    psi[5,2]  column_1  1
    psi[5,2]  column_2  1
    psi[5,2]  column_3  1
    psi[5,2]  column_4  1
    psi[5,2]  column_9  1
    psi[5,2]  column_10  1
    psi[5,2]  column_11  1
    psi[5,2]  column_12  1
    psi[5,2]  column_14  1
    psi[5,2]  column_20  1
    psi[5,2]  column_21  1
    psi[5,2]  column_22  1
    psi[5,2]  column_38  1
    psi[5,2]  column_39  1
    psi[5,2]  column_40  1
    psi[5,2]  column_42  1
    psi[5,2]  column_48  1
    psi[5,2]  column_49  1
    psi[5,2]  column_50  1
    psi[5,2]  column_53  1
    psi[5,2]  column_55  1
    psi[5,2]  column_56  1
    psi[5,2]  column_57  1
    psi[5,2]  column_60  1
    psi[5,2]  column_64  1
    psi[5,2]  column_90  1
    psi[5,2]  column_91  1
    psi[5,2]  column_92  1
    psi[5,3]  OBJ       0
    psi[5,4]  OBJ       1.4787306094629565e-01
    psi[5,4]  column_15  1
    psi[5,4]  column_16  1
    psi[5,4]  column_17  1
    psi[5,4]  column_23  1
    psi[5,4]  column_24  1
    psi[5,4]  column_69  1
    psi[5,4]  column_70  1
    psi[5,4]  column_71  1
    psi[5,4]  column_72  1
    psi[5,4]  column_73  1
    psi[5,5]  OBJ       0
    psi[5,6]  OBJ       0
    psi[5,7]  column_41  1
    psi[5,7]  column_47  1
    psi[5,8]  OBJ       7.6664944126616930e-01
    psi[5,8]  column_5  1
    psi[5,8]  column_6  1
    psi[5,8]  column_7  1
    psi[5,8]  column_8  1
    psi[5,8]  column_13  1
    psi[5,8]  column_18  1
    psi[5,8]  column_19  1
    psi[5,8]  column_25  1
    psi[5,8]  column_26  1
    psi[5,8]  column_27  1
    psi[5,8]  column_28  1
    psi[5,8]  column_29  1
    psi[5,8]  column_30  1
    psi[5,8]  column_31  1
    psi[5,8]  column_32  1
    psi[5,8]  column_33  1
    psi[5,8]  column_34  1
    psi[5,8]  column_35  1
    psi[5,8]  column_36  1
    psi[5,8]  column_37  1
    psi[5,8]  column_43  1
    psi[5,8]  column_44  1
    psi[5,8]  column_45  1
    psi[5,8]  column_46  1
    psi[5,8]  column_51  1
    psi[5,8]  column_52  1
    psi[5,8]  column_54  1
    psi[5,8]  column_58  1
    psi[5,8]  column_59  1
    psi[5,8]  column_61  1
    psi[5,8]  column_62  1
    psi[5,8]  column_63  1
    psi[5,8]  column_65  1
    psi[5,8]  column_66  1
    psi[5,8]  column_67  1
    psi[5,8]  column_68  1
    psi[5,8]  column_74  1
    psi[5,8]  column_75  1
    psi[5,8]  column_76  1
    psi[5,8]  column_77  1
    psi[5,8]  column_78  1
    psi[5,8]  column_79  1
    psi[5,8]  column_80  1
    psi[5,8]  column_81  1
    psi[5,8]  column_82  1
    psi[5,8]  column_83  1
    psi[5,8]  column_84  1
    psi[5,8]  column_85  1
    psi[5,8]  column_86  1
    psi[5,8]  column_87  1
    psi[5,8]  column_88  1
    psi[5,8]  column_89  1
    psi[5,8]  column_93  1
    psi[5,8]  column_94  1
    psi[5,8]  column_95  1
    psi[5,8]  column_96  1
    psi[5,8]  column_97  1
    psi[5,8]  column_98  1
    psi[5,8]  column_99  1
    psi[5,8]  column_100  1
    psi[5,8]  column_101  1
    psi[5,9]  OBJ       0
    psi[5,10]  OBJ       0
    psi[5,11]  OBJ       0
    psi[5,12]  OBJ       0
    psi[5,13]  OBJ       0
    psi[5,14]  OBJ       0
    psi[5,15]  OBJ       0
    psi[5,16]  OBJ       0
    psi[6,0]  OBJ       0
    psi[6,1]  OBJ       2.4810003791506871e-01
    psi[6,1]  column_0  1
    psi[6,1]  column_1  1
    psi[6,1]  column_3  1
    psi[6,1]  column_4  1
    psi[6,1]  column_5  1
    psi[6,1]  column_6  1
    psi[6,1]  column_7  1
    psi[6,1]  column_8  1
    psi[6,1]  column_9  1
    psi[6,1]  column_11  1
    psi[6,1]  column_12  1
    psi[6,1]  column_13  1
    psi[6,1]  column_14  1
    psi[6,1]  column_25  1
    psi[6,1]  column_26  1
    psi[6,1]  column_27  1
    psi[6,1]  column_28  1
    psi[6,1]  column_29  1
    psi[6,1]  column_39  1
    psi[6,1]  column_43  1
    psi[6,1]  column_44  1
    psi[6,1]  column_45  1
    psi[6,1]  column_46  1
    psi[6,1]  column_48  1
    psi[6,1]  column_49  1
    psi[6,1]  column_50  1
    psi[6,1]  column_51  1
    psi[6,1]  column_53  1
    psi[6,1]  column_54  1
    psi[6,1]  column_58  1
    psi[6,1]  column_59  1
    psi[6,1]  column_65  1
    psi[6,1]  column_67  1
    psi[6,1]  column_87  1
    psi[6,1]  column_89  1
    psi[6,1]  column_93  1
    psi[6,1]  column_94  1
    psi[6,1]  column_95  1
    psi[6,1]  column_96  1
    psi[6,1]  column_97  1
    psi[6,1]  column_98  1
    psi[6,2]  column_38  1
    psi[6,2]  column_52  1
    psi[6,2]  column_66  1
    psi[6,2]  column_99  1
    psi[6,2]  column_100  1
    psi[6,3]  OBJ       0
    psi[6,4]  column_40  1
    psi[6,4]  column_41  1
    psi[6,4]  column_47  1
    psi[6,4]  column_55  1
    psi[6,4]  column_56  1
    psi[6,4]  column_57  1
    psi[6,5]  OBJ       7.5189996208493137e-01
    psi[6,5]  column_2  1
    psi[6,5]  column_10  1
    psi[6,5]  column_15  1
    psi[6,5]  column_16  1
    psi[6,5]  column_17  1
    psi[6,5]  column_18  1
    psi[6,5]  column_19  1
    psi[6,5]  column_20  1
    psi[6,5]  column_21  1
    psi[6,5]  column_22  1
    psi[6,5]  column_23  1
    psi[6,5]  column_24  1
    psi[6,5]  column_30  1
    psi[6,5]  column_31  1
    psi[6,5]  column_32  1
    psi[6,5]  column_33  1
    psi[6,5]  column_34  1
    psi[6,5]  column_35  1
    psi[6,5]  column_36  1
    psi[6,5]  column_37  1
    psi[6,5]  column_42  1
    psi[6,5]  column_60  1
    psi[6,5]  column_61  1
    psi[6,5]  column_62  1
    psi[6,5]  column_63  1
    psi[6,5]  column_64  1
    psi[6,5]  column_68  1
    psi[6,5]  column_69  1
    psi[6,5]  column_70  1
    psi[6,5]  column_71  1
    psi[6,5]  column_72  1
    psi[6,5]  column_73  1
    psi[6,5]  column_74  1
    psi[6,5]  column_75  1
    psi[6,5]  column_76  1
    psi[6,5]  column_77  1
    psi[6,5]  column_78  1
    psi[6,5]  column_79  1
    psi[6,5]  column_80  1
    psi[6,5]  column_81  1
    psi[6,5]  column_82  1
    psi[6,5]  column_83  1
    psi[6,5]  column_84  1
    psi[6,5]  column_85  1
    psi[6,5]  column_86  1
    psi[6,5]  column_88  1
    psi[6,5]  column_90  1
    psi[6,5]  column_91  1
    psi[6,5]  column_92  1
    psi[6,5]  column_101  1
    psi[6,6]  OBJ       0
    psi[6,7]  OBJ       0
    psi[6,8]  OBJ       0
    psi[6,9]  OBJ       0
    psi[6,10]  OBJ       0
    psi[7,0]  OBJ       0
    psi[7,1]  OBJ       0
    psi[7,2]  OBJ       0
    psi[7,3]  OBJ       0
    psi[7,4]  column_38  1
    psi[7,4]  column_39  1
    psi[7,4]  column_42  1
    psi[7,4]  column_43  1
    psi[7,4]  column_52  1
    psi[7,4]  column_99  1
    psi[7,4]  column_101  1
    psi[7,5]  OBJ       3.6811907683679762e-01
    psi[7,5]  column_2  1
    psi[7,5]  column_3  1
    psi[7,5]  column_4  1
    psi[7,5]  column_5  1
    psi[7,5]  column_6  1
    psi[7,5]  column_7  1
    psi[7,5]  column_8  1
    psi[7,5]  column_11  1
    psi[7,5]  column_12  1
    psi[7,5]  column_13  1
    psi[7,5]  column_15  1
    psi[7,5]  column_18  1
    psi[7,5]  column_19  1
    psi[7,5]  column_20  1
    psi[7,5]  column_21  1
    psi[7,5]  column_30  1
    psi[7,5]  column_40  1
    psi[7,5]  column_41  1
    psi[7,5]  column_47  1
    psi[7,5]  column_48  1
    psi[7,5]  column_49  1
    psi[7,5]  column_50  1
    psi[7,5]  column_51  1
    psi[7,5]  column_58  1
    psi[7,5]  column_59  1
    psi[7,5]  column_68  1
    psi[7,5]  column_69  1
    psi[7,5]  column_70  1
    psi[7,5]  column_71  1
    psi[7,5]  column_72  1
    psi[7,5]  column_73  1
    psi[7,5]  column_74  1
    psi[7,5]  column_75  1
    psi[7,5]  column_76  1
    psi[7,5]  column_77  1
    psi[7,5]  column_86  1
    psi[7,5]  column_87  1
    psi[7,6]  column_9  1
    psi[7,6]  column_14  1
    psi[7,6]  column_55  1
    psi[7,6]  column_56  1
    psi[7,6]  column_57  1
    psi[7,6]  column_60  1
    psi[7,6]  column_61  1
    psi[7,6]  column_67  1
    psi[7,6]  column_89  1
    psi[7,6]  column_93  1
    psi[7,7]  column_44  1
    psi[7,7]  column_45  1
    psi[7,7]  column_46  1
    psi[7,7]  column_66  1
    psi[7,7]  column_94  1
    psi[7,7]  column_95  1
    psi[7,7]  column_100  1
    psi[7,8]  OBJ       6.3188092316320232e-01
    psi[7,8]  column_0  1
    psi[7,8]  column_1  1
    psi[7,8]  column_10  1
    psi[7,8]  column_16  1
    psi[7,8]  column_17  1
    psi[7,8]  column_22  1
    psi[7,8]  column_23  1
    psi[7,8]  column_24  1
    psi[7,8]  column_25  1
    psi[7,8]  column_26  1
    psi[7,8]  column_27  1
    psi[7,8]  column_28  1
    psi[7,8]  column_29  1
    psi[7,8]  column_31  1
    psi[7,8]  column_32  1
    psi[7,8]  column_33  1
    psi[7,8]  column_34  1
    psi[7,8]  column_35  1
    psi[7,8]  column_36  1
    psi[7,8]  column_37  1
    psi[7,8]  column_53  1
    psi[7,8]  column_54  1
    psi[7,8]  column_62  1
    psi[7,8]  column_63  1
    psi[7,8]  column_64  1
    psi[7,8]  column_65  1
    psi[7,8]  column_78  1
    psi[7,8]  column_79  1
    psi[7,8]  column_80  1
    psi[7,8]  column_81  1
    psi[7,8]  column_82  1
    psi[7,8]  column_83  1
    psi[7,8]  column_84  1
    psi[7,8]  column_85  1
    psi[7,8]  column_88  1
    psi[7,8]  column_90  1
    psi[7,8]  column_91  1
    psi[7,8]  column_92  1
    psi[7,8]  column_96  1
    psi[7,8]  column_97  1
    psi[7,8]  column_98  1
    psi[7,9]  OBJ       0
    psi[7,10]  OBJ       0
    psi[7,11]  OBJ       0
    psi[7,12]  OBJ       0
    psi[7,13]  OBJ       0
    psi[7,14]  OBJ       0
    psi[7,15]  OBJ       0
    psi[7,16]  OBJ       0
    psi[7,17]  OBJ       0
    psi[8,0]  column_88  1
    psi[8,1]  OBJ       0
    psi[8,2]  OBJ       0
    psi[8,3]  OBJ       0
    psi[8,4]  OBJ       0
    psi[8,5]  OBJ       2.3577480013138991e-02
    psi[8,5]  column_0  1
    psi[8,5]  column_9  1
    psi[8,5]  column_22  1
    psi[8,5]  column_30  1
    psi[8,5]  column_48  1
    psi[8,5]  column_49  1
    psi[8,5]  column_51  1
    psi[8,6]  OBJ       0
    psi[8,7]  OBJ       1.2321408376449954e-01
    psi[8,7]  column_16  1
    psi[8,7]  column_17  1
    psi[8,7]  column_20  1
    psi[8,7]  column_40  1
    psi[8,7]  column_41  1
    psi[8,7]  column_47  1
    psi[8,7]  column_69  1
    psi[8,7]  column_70  1
    psi[8,7]  column_71  1
    psi[8,7]  column_72  1
    psi[8,7]  column_73  1
    psi[8,8]  column_38  1
    psi[8,9]  OBJ       0
    psi[8,10]  OBJ       8.5320843622236153e-01
    psi[8,10]  column_1  1
    psi[8,10]  column_2  1
    psi[8,10]  column_3  1
    psi[8,10]  column_4  1
    psi[8,10]  column_5  1
    psi[8,10]  column_6  1
    psi[8,10]  column_7  1
    psi[8,10]  column_8  1
    psi[8,10]  column_10  1
    psi[8,10]  column_11  1
    psi[8,10]  column_12  1
    psi[8,10]  column_13  1
    psi[8,10]  column_14  1
    psi[8,10]  column_15  1
    psi[8,10]  column_18  1
    psi[8,10]  column_19  1
    psi[8,10]  column_21  1
    psi[8,10]  column_23  1
    psi[8,10]  column_24  1
    psi[8,10]  column_25  1
    psi[8,10]  column_26  1
    psi[8,10]  column_27  1
    psi[8,10]  column_28  1
    psi[8,10]  column_29  1
    psi[8,10]  column_31  1
    psi[8,10]  column_32  1
    psi[8,10]  column_33  1
    psi[8,10]  column_34  1
    psi[8,10]  column_35  1
    psi[8,10]  column_36  1
    psi[8,10]  column_37  1
    psi[8,10]  column_39  1
    psi[8,10]  column_42  1
    psi[8,10]  column_43  1
    psi[8,10]  column_44  1
    psi[8,10]  column_45  1
    psi[8,10]  column_46  1
    psi[8,10]  column_50  1
    psi[8,10]  column_52  1
    psi[8,10]  column_53  1
    psi[8,10]  column_54  1
    psi[8,10]  column_55  1
    psi[8,10]  column_56  1
    psi[8,10]  column_57  1
    psi[8,10]  column_58  1
    psi[8,10]  column_59  1
    psi[8,10]  column_60  1
    psi[8,10]  column_61  1
    psi[8,10]  column_62  1
    psi[8,10]  column_63  1
    psi[8,10]  column_64  1
    psi[8,10]  column_65  1
    psi[8,10]  column_66  1
    psi[8,10]  column_67  1
    psi[8,10]  column_68  1
    psi[8,10]  column_74  1
    psi[8,10]  column_75  1
    psi[8,10]  column_76  1
    psi[8,10]  column_77  1
    psi[8,10]  column_78  1
    psi[8,10]  column_79  1
    psi[8,10]  column_80  1
    psi[8,10]  column_81  1
    psi[8,10]  column_82  1
    psi[8,10]  column_83  1
    psi[8,10]  column_84  1
    psi[8,10]  column_85  1
    psi[8,10]  column_86  1
    psi[8,10]  column_87  1
    psi[8,10]  column_89  1
    psi[8,10]  column_90  1
    psi[8,10]  column_91  1
    psi[8,10]  column_92  1
    psi[8,10]  column_93  1
    psi[8,10]  column_94  1
    psi[8,10]  column_95  1
    psi[8,10]  column_96  1
    psi[8,10]  column_97  1
    psi[8,10]  column_98  1
    psi[8,10]  column_99  1
    psi[8,10]  column_100  1
    psi[8,10]  column_101  1
    psi[8,11]  OBJ       0
    psi[8,12]  OBJ       0
    psi[8,13]  OBJ       0
    psi[8,14]  OBJ       0
    psi[8,15]  OBJ       0
    psi[8,16]  OBJ       0
    psi[8,17]  OBJ       0
    psi[8,18]  OBJ       0
    psi[8,19]  OBJ       0
    psi[8,20]  OBJ       0
    psi[8,21]  OBJ       0
    psi[9,0]  OBJ       0
    psi[9,1]  OBJ       0
    psi[9,2]  column_2  1
    psi[9,2]  column_40  1
    psi[9,2]  column_41  1
    psi[9,2]  column_47  1
    psi[9,2]  column_90  1
    psi[9,3]  OBJ       0.345111634534498
    psi[9,3]  column_0  1
    psi[9,3]  column_1  1
    psi[9,3]  column_9  1
    psi[9,3]  column_14  1
    psi[9,3]  column_18  1
    psi[9,3]  column_21  1
    psi[9,3]  column_23  1
    psi[9,3]  column_24  1
    psi[9,3]  column_25  1
    psi[9,3]  column_26  1
    psi[9,3]  column_27  1
    psi[9,3]  column_28  1
    psi[9,3]  column_31  1
    psi[9,3]  column_38  1
    psi[9,3]  column_39  1
    psi[9,3]  column_43  1
    psi[9,3]  column_44  1
    psi[9,3]  column_45  1
    psi[9,3]  column_48  1
    psi[9,3]  column_49  1
    psi[9,3]  column_50  1
    psi[9,3]  column_51  1
    psi[9,3]  column_52  1
    psi[9,3]  column_53  1
    psi[9,3]  column_54  1
    psi[9,3]  column_58  1
    psi[9,3]  column_59  1
    psi[9,3]  column_65  1
    psi[9,3]  column_66  1
    psi[9,3]  column_67  1
    psi[9,3]  column_78  1
    psi[9,3]  column_79  1
    psi[9,3]  column_80  1
    psi[9,3]  column_81  1
    psi[9,3]  column_89  1
    psi[9,3]  column_94  1
    psi[9,3]  column_95  1
    psi[9,3]  column_96  1
    psi[9,3]  column_99  1
    psi[9,3]  column_100  1
    psi[9,3]  column_101  1
    psi[9,4]  column_3  1
    psi[9,4]  column_11  1
    psi[9,4]  column_12  1
    psi[9,4]  column_13  1
    psi[9,4]  column_55  1
    psi[9,4]  column_56  1
    psi[9,4]  column_57  1
    psi[9,4]  column_61  1
    psi[9,4]  column_68  1
    psi[9,5]  OBJ       0.654888365465502
    psi[9,5]  column_4  1
    psi[9,5]  column_5  1
    psi[9,5]  column_6  1
    psi[9,5]  column_7  1
    psi[9,5]  column_8  1
    psi[9,5]  column_10  1
    psi[9,5]  column_15  1
    psi[9,5]  column_16  1
    psi[9,5]  column_17  1
    psi[9,5]  column_19  1
    psi[9,5]  column_20  1
    psi[9,5]  column_22  1
    psi[9,5]  column_29  1
    psi[9,5]  column_30  1
    psi[9,5]  column_32  1
    psi[9,5]  column_33  1
    psi[9,5]  column_34  1
    psi[9,5]  column_35  1
    psi[9,5]  column_36  1
    psi[9,5]  column_37  1
    psi[9,5]  column_42  1
    psi[9,5]  column_46  1
    psi[9,5]  column_60  1
    psi[9,5]  column_62  1
    psi[9,5]  column_63  1
    psi[9,5]  column_64  1
    psi[9,5]  column_69  1
    psi[9,5]  column_70  1
    psi[9,5]  column_71  1
    psi[9,5]  column_72  1
    psi[9,5]  column_73  1
    psi[9,5]  column_74  1
    psi[9,5]  column_75  1
    psi[9,5]  column_76  1
    psi[9,5]  column_77  1
    psi[9,5]  column_82  1
    psi[9,5]  column_83  1
    psi[9,5]  column_84  1
    psi[9,5]  column_85  1
    psi[9,5]  column_86  1
    psi[9,5]  column_87  1
    psi[9,5]  column_88  1
    psi[9,5]  column_91  1
    psi[9,5]  column_92  1
    psi[9,5]  column_93  1
    psi[9,5]  column_97  1
    psi[9,5]  column_98  1
    psi[9,6]  OBJ       0
    psi[9,7]  OBJ       0
    psi[9,8]  OBJ       0
    psi[9,9]  OBJ       0
    psi[9,10]  OBJ       0
    psi[9,11]  OBJ       0
    psi[9,12]  OBJ       0
    psi[10,0]  column_88  1
    psi[10,1]  OBJ       0
    psi[10,2]  OBJ       0
    psi[10,3]  OBJ       0
    psi[10,4]  OBJ       0
    psi[10,5]  OBJ       2.3577480013138991e-02
    psi[10,5]  column_2  1
    psi[10,5]  column_31  1
    psi[10,5]  column_40  1
    psi[10,5]  column_41  1
    psi[10,5]  column_47  1
    psi[10,6]  OBJ       3.1563978451807406e-01
    psi[10,6]  column_15  1
    psi[10,6]  column_16  1
    psi[10,6]  column_17  1
    psi[10,6]  column_19  1
    psi[10,6]  column_21  1
    psi[10,6]  column_22  1
    psi[10,6]  column_29  1
    psi[10,6]  column_30  1
    psi[10,6]  column_32  1
    psi[10,6]  column_33  1
    psi[10,6]  column_69  1
    psi[10,6]  column_70  1
    psi[10,6]  column_71  1
    psi[10,6]  column_72  1
    psi[10,6]  column_73  1
    psi[10,6]  column_78  1
    psi[10,6]  column_79  1
    psi[10,6]  column_101  1
    psi[10,7]  OBJ       0
    psi[10,8]  OBJ       0
    psi[10,9]  column_14  1
    psi[10,10]  OBJ       0.660782735468787
    psi[10,10]  column_0  1
    psi[10,10]  column_1  1
    psi[10,10]  column_3  1
    psi[10,10]  column_4  1
    psi[10,10]  column_5  1
    psi[10,10]  column_6  1
    psi[10,10]  column_7  1
    psi[10,10]  column_8  1
    psi[10,10]  column_9  1
    psi[10,10]  column_10  1
    psi[10,10]  column_11  1
    psi[10,10]  column_12  1
    psi[10,10]  column_13  1
    psi[10,10]  column_18  1
    psi[10,10]  column_20  1
    psi[10,10]  column_23  1
    psi[10,10]  column_24  1
    psi[10,10]  column_25  1
    psi[10,10]  column_26  1
    psi[10,10]  column_27  1
    psi[10,10]  column_28  1
    psi[10,10]  column_34  1
    psi[10,10]  column_35  1
    psi[10,10]  column_36  1
    psi[10,10]  column_37  1
    psi[10,10]  column_38  1
    psi[10,10]  column_39  1
    psi[10,10]  column_42  1
    psi[10,10]  column_43  1
    psi[10,10]  column_44  1
    psi[10,10]  column_45  1
    psi[10,10]  column_46  1
    psi[10,10]  column_48  1
    psi[10,10]  column_49  1
    psi[10,10]  column_50  1
    psi[10,10]  column_51  1
    psi[10,10]  column_52  1
    psi[10,10]  column_53  1
    psi[10,10]  column_54  1
    psi[10,10]  column_55  1
    psi[10,10]  column_56  1
    psi[10,10]  column_57  1
    psi[10,10]  column_58  1
    psi[10,10]  column_59  1
    psi[10,10]  column_60  1
    psi[10,10]  column_61  1
    psi[10,10]  column_62  1
    psi[10,10]  column_63  1
    psi[10,10]  column_64  1
    psi[10,10]  column_65  1
    psi[10,10]  column_66  1
    psi[10,10]  column_67  1
    psi[10,10]  column_68  1
    psi[10,10]  column_74  1
    psi[10,10]  column_75  1
    psi[10,10]  column_76  1
    psi[10,10]  column_77  1
    psi[10,10]  column_80  1
    psi[10,10]  column_81  1
    psi[10,10]  column_82  1
    psi[10,10]  column_83  1
    psi[10,10]  column_84  1
    psi[10,10]  column_85  1
    psi[10,10]  column_86  1
    psi[10,10]  column_87  1
    psi[10,10]  column_89  1
    psi[10,10]  column_90  1
    psi[10,10]  column_91  1
    psi[10,10]  column_92  1
    psi[10,10]  column_93  1
    psi[10,10]  column_94  1
    psi[10,10]  column_95  1
    psi[10,10]  column_96  1
    psi[10,10]  column_97  1
    psi[10,10]  column_98  1
    psi[10,10]  column_99  1
    psi[10,10]  column_100  1
    psi[10,11]  OBJ       0
    psi[10,12]  OBJ       0
    psi[10,13]  OBJ       0
    psi[10,14]  OBJ       0
    psi[10,15]  OBJ       0
    psi[10,16]  OBJ       0
    psi[10,17]  OBJ       0
    psi[10,18]  OBJ       0
    psi[10,19]  OBJ       0
    psi[11,0]  OBJ       0
    psi[11,1]  OBJ       0
    psi[11,2]  OBJ       2.3007442302299855e-01
    psi[11,2]  column_3  1
    psi[11,2]  column_4  1
    psi[11,2]  column_9  1
    psi[11,2]  column_11  1
    psi[11,2]  column_12  1
    psi[11,2]  column_13  1
    psi[11,2]  column_14  1
    psi[11,2]  column_15  1
    psi[11,2]  column_16  1
    psi[11,2]  column_17  1
    psi[11,2]  column_20  1
    psi[11,2]  column_30  1
    psi[11,2]  column_53  1
    psi[11,2]  column_54  1
    psi[11,2]  column_65  1
    psi[11,2]  column_67  1
    psi[11,2]  column_68  1
    psi[11,2]  column_69  1
    psi[11,2]  column_70  1
    psi[11,2]  column_71  1
    psi[11,2]  column_72  1
    psi[11,2]  column_73  1
    psi[11,2]  column_78  1
    psi[11,2]  column_80  1
    psi[11,2]  column_81  1
    psi[11,2]  column_89  1
    psi[11,2]  column_93  1
    psi[11,2]  column_94  1
    psi[11,2]  column_95  1
    psi[11,2]  column_96  1
    psi[11,2]  column_97  1
    psi[11,2]  column_98  1
    psi[11,3]  column_2  1
    psi[11,3]  column_39  1
    psi[11,3]  column_40  1
    psi[11,3]  column_41  1
    psi[11,3]  column_43  1
    psi[11,3]  column_44  1
    psi[11,3]  column_45  1
    psi[11,3]  column_46  1
    psi[11,3]  column_47  1
    psi[11,4]  column_0  1
    psi[11,4]  column_38  1
    psi[11,4]  column_48  1
    psi[11,4]  column_49  1
    psi[11,4]  column_51  1
    psi[11,4]  column_52  1
    psi[11,4]  column_55  1
    psi[11,4]  column_56  1
    psi[11,4]  column_66  1
    psi[11,4]  column_99  1
    psi[11,5]  OBJ       7.6992557697700148e-01
    psi[11,5]  column_1  1
    psi[11,5]  column_5  1
    psi[11,5]  column_6  1
    psi[11,5]  column_7  1
    psi[11,5]  column_8  1
    psi[11,5]  column_10  1
    psi[11,5]  column_18  1
    psi[11,5]  column_19  1
    psi[11,5]  column_21  1
    psi[11,5]  column_22  1
    psi[11,5]  column_23  1
    psi[11,5]  column_24  1
    psi[11,5]  column_25  1
    psi[11,5]  column_26  1
    psi[11,5]  column_27  1
    psi[11,5]  column_28  1
    psi[11,5]  column_29  1
    psi[11,5]  column_31  1
    psi[11,5]  column_32  1
    psi[11,5]  column_33  1
    psi[11,5]  column_34  1
    psi[11,5]  column_35  1
    psi[11,5]  column_36  1
    psi[11,5]  column_37  1
    psi[11,5]  column_42  1
    psi[11,5]  column_50  1
    psi[11,5]  column_57  1
    psi[11,5]  column_58  1
    psi[11,5]  column_59  1
    psi[11,5]  column_60  1
    psi[11,5]  column_61  1
    psi[11,5]  column_62  1
    psi[11,5]  column_63  1
    psi[11,5]  column_64  1
    psi[11,5]  column_74  1
    psi[11,5]  column_75  1
    psi[11,5]  column_76  1
    psi[11,5]  column_77  1
    psi[11,5]  column_79  1
    psi[11,5]  column_82  1
    psi[11,5]  column_83  1
    psi[11,5]  column_84  1
    psi[11,5]  column_85  1
    psi[11,5]  column_86  1
    psi[11,5]  column_87  1
    psi[11,5]  column_88  1
    psi[11,5]  column_90  1
    psi[11,5]  column_91  1
    psi[11,5]  column_92  1
    psi[11,5]  column_100  1
    psi[11,5]  column_101  1
    psi[11,6]  OBJ       0
    psi[11,7]  OBJ       0
    psi[11,8]  OBJ       0
    psi[11,9]  OBJ       0
    psi[11,10]  OBJ       0
    psi[11,11]  OBJ       0
    psi[11,12]  OBJ       0
    psi[12,0]  column_100  1
    psi[12,1]  OBJ       0
    psi[12,2]  OBJ       0
    psi[12,3]  column_0  1
    psi[12,3]  column_1  1
    psi[12,3]  column_48  1
    psi[12,3]  column_49  1
    psi[12,3]  column_50  1
    psi[12,3]  column_51  1
    psi[12,3]  column_53  1
    psi[12,3]  column_54  1
    psi[12,3]  column_55  1
    psi[12,3]  column_56  1
    psi[12,3]  column_57  1
    psi[12,3]  column_58  1
    psi[12,4]  OBJ       3.2210419223219794e-01
    psi[12,4]  column_2  1
    psi[12,4]  column_3  1
    psi[12,4]  column_4  1
    psi[12,4]  column_11  1
    psi[12,4]  column_12  1
    psi[12,4]  column_13  1
    psi[12,4]  column_15  1
    psi[12,4]  column_16  1
    psi[12,4]  column_17  1
    psi[12,4]  column_20  1
    psi[12,4]  column_21  1
    psi[12,4]  column_22  1
    psi[12,4]  column_30  1
    psi[12,4]  column_32  1
    psi[12,4]  column_40  1
    psi[12,4]  column_41  1
    psi[12,4]  column_47  1
    psi[12,4]  column_68  1
    psi[12,4]  column_69  1
    psi[12,4]  column_70  1
    psi[12,4]  column_71  1
    psi[12,4]  column_72  1
    psi[12,4]  column_73  1
    psi[12,4]  column_80  1
    psi[12,4]  column_81  1
    psi[12,5]  column_14  1
    psi[12,5]  column_67  1
    psi[12,5]  column_89  1
    psi[12,6]  column_38  1
    psi[12,6]  column_39  1
    psi[12,6]  column_43  1
    psi[12,6]  column_44  1
    psi[12,6]  column_52  1
    psi[12,6]  column_60  1
    psi[12,6]  column_61  1
    psi[12,6]  column_62  1
    psi[12,6]  column_63  1
    psi[12,6]  column_64  1
    psi[12,6]  column_66  1
    psi[12,7]  OBJ       6.7789580776780212e-01
    psi[12,7]  column_5  1
    psi[12,7]  column_6  1
    psi[12,7]  column_7  1
    psi[12,7]  column_8  1
    psi[12,7]  column_9  1
    psi[12,7]  column_10  1
    psi[12,7]  column_18  1
    psi[12,7]  column_19  1
    psi[12,7]  column_23  1
    psi[12,7]  column_24  1
    psi[12,7]  column_25  1
    psi[12,7]  column_26  1
    psi[12,7]  column_27  1
    psi[12,7]  column_28  1
    psi[12,7]  column_29  1
    psi[12,7]  column_31  1
    psi[12,7]  column_33  1
    psi[12,7]  column_34  1
    psi[12,7]  column_35  1
    psi[12,7]  column_36  1
    psi[12,7]  column_37  1
    psi[12,7]  column_42  1
    psi[12,7]  column_45  1
    psi[12,7]  column_46  1
    psi[12,7]  column_59  1
    psi[12,7]  column_65  1
    psi[12,7]  column_74  1
    psi[12,7]  column_75  1
    psi[12,7]  column_76  1
    psi[12,7]  column_77  1
    psi[12,7]  column_78  1
    psi[12,7]  column_79  1
    psi[12,7]  column_82  1
    psi[12,7]  column_83  1
    psi[12,7]  column_84  1
    psi[12,7]  column_85  1
    psi[12,7]  column_86  1
    psi[12,7]  column_87  1
    psi[12,7]  column_88  1
    psi[12,7]  column_90  1
    psi[12,7]  column_91  1
    psi[12,7]  column_92  1
    psi[12,7]  column_93  1
    psi[12,7]  column_94  1
    psi[12,7]  column_95  1
    psi[12,7]  column_96  1
    psi[12,7]  column_97  1
    psi[12,7]  column_98  1
    psi[12,7]  column_99  1
    psi[12,7]  column_101  1
    psi[12,8]  OBJ       0
    psi[12,9]  OBJ       0
    psi[12,10]  OBJ       0
    psi[12,11]  OBJ       0
    psi[12,12]  OBJ       0
    psi[12,13]  OBJ       0
    psi[12,14]  OBJ       0
    psi[12,15]  OBJ       0
    psi[13,0]  OBJ       0
    psi[13,1]  OBJ       0
    psi[13,2]  OBJ       0
    psi[13,3]  OBJ       0
    psi[13,4]  OBJ       4.2644903507844077e-02
    psi[13,4]  column_9  1
    psi[13,4]  column_14  1
    psi[13,4]  column_67  1
    psi[13,4]  column_82  1
    psi[13,4]  column_93  1
    psi[13,4]  column_94  1
    psi[13,5]  column_2  1
    psi[13,5]  column_3  1
    psi[13,5]  column_4  1
    psi[13,5]  column_11  1
    psi[13,5]  column_12  1
    psi[13,5]  column_13  1
    psi[13,5]  column_39  1
    psi[13,5]  column_40  1
    psi[13,5]  column_41  1
    psi[13,5]  column_43  1
    psi[13,5]  column_44  1
    psi[13,5]  column_47  1
    psi[13,5]  column_68  1
    psi[13,5]  column_97  1
    psi[13,6]  column_0  1
    psi[13,6]  column_1  1
    psi[13,6]  column_38  1
    psi[13,6]  column_48  1
    psi[13,6]  column_49  1
    psi[13,6]  column_50  1
    psi[13,6]  column_51  1
    psi[13,6]  column_52  1
    psi[13,6]  column_54  1
    psi[13,6]  column_55  1
    psi[13,6]  column_58  1
    psi[13,6]  column_66  1
    psi[13,6]  column_101  1
    psi[13,7]  OBJ       9.3377761647901691e-01
    psi[13,7]  column_5  1
    psi[13,7]  column_6  1
    psi[13,7]  column_7  1
    psi[13,7]  column_8  1
    psi[13,7]  column_15  1
    psi[13,7]  column_16  1
    psi[13,7]  column_17  1
    psi[13,7]  column_18  1
    psi[13,7]  column_20  1
    psi[13,7]  column_21  1
    psi[13,7]  column_22  1
    psi[13,7]  column_23  1
    psi[13,7]  column_24  1
    psi[13,7]  column_25  1
    psi[13,7]  column_26  1
    psi[13,7]  column_27  1
    psi[13,7]  column_28  1
    psi[13,7]  column_30  1
    psi[13,7]  column_31  1
    psi[13,7]  column_32  1
    psi[13,7]  column_33  1
    psi[13,7]  column_34  1
    psi[13,7]  column_35  1
    psi[13,7]  column_36  1
    psi[13,7]  column_37  1
    psi[13,7]  column_42  1
    psi[13,7]  column_45  1
    psi[13,7]  column_46  1
    psi[13,7]  column_53  1
    psi[13,7]  column_59  1
    psi[13,7]  column_65  1
    psi[13,7]  column_69  1
    psi[13,7]  column_70  1
    psi[13,7]  column_71  1
    psi[13,7]  column_72  1
    psi[13,7]  column_73  1
    psi[13,7]  column_74  1
    psi[13,7]  column_75  1
    psi[13,7]  column_76  1
    psi[13,7]  column_77  1
    psi[13,7]  column_78  1
    psi[13,7]  column_79  1
    psi[13,7]  column_80  1
    psi[13,7]  column_81  1
    psi[13,7]  column_83  1
    psi[13,7]  column_84  1
    psi[13,7]  column_85  1
    psi[13,7]  column_86  1
    psi[13,7]  column_87  1
    psi[13,7]  column_89  1
    psi[13,7]  column_91  1
    psi[13,7]  column_92  1
    psi[13,7]  column_95  1
    psi[13,7]  column_96  1
    psi[13,7]  column_98  1
    psi[13,8]  OBJ       2.3577480013138991e-02
    psi[13,8]  column_10  1
    psi[13,8]  column_19  1
    psi[13,8]  column_29  1
    psi[13,8]  column_56  1
    psi[13,8]  column_57  1
    psi[13,8]  column_60  1
    psi[13,8]  column_61  1
    psi[13,8]  column_62  1
    psi[13,8]  column_63  1
    psi[13,8]  column_64  1
    psi[13,8]  column_88  1
    psi[13,8]  column_90  1
    psi[13,8]  column_99  1
    psi[13,8]  column_100  1
    psi[13,9]  OBJ       0
    psi[13,10]  OBJ       0
    psi[13,11]  OBJ       0
    psi[13,12]  OBJ       0
    psi[13,13]  OBJ       0
    psi[13,14]  OBJ       0
    psi[13,15]  OBJ       0
    psi[13,16]  OBJ       0
    psi[13,17]  OBJ       0
    psi[13,18]  OBJ       0
    psi[13,19]  OBJ       0
    psi[14,0]  OBJ       0
    psi[14,1]  OBJ       0
    psi[14,2]  OBJ       1.8405953841839917e-01
    psi[14,2]  column_1  1
    psi[14,2]  column_2  1
    psi[14,2]  column_3  1
    psi[14,2]  column_4  1
    psi[14,2]  column_9  1
    psi[14,2]  column_10  1
    psi[14,2]  column_11  1
    psi[14,2]  column_14  1
    psi[14,2]  column_33  1
    psi[14,2]  column_38  1
    psi[14,2]  column_40  1
    psi[14,2]  column_50  1
    psi[14,2]  column_55  1
    psi[14,2]  column_56  1
    psi[14,2]  column_74  1
    psi[14,2]  column_75  1
    psi[14,2]  column_76  1
    psi[14,2]  column_79  1
    psi[14,2]  column_82  1
    psi[14,2]  column_90  1
    psi[14,2]  column_91  1
    psi[14,3]  OBJ       0
    psi[14,4]  OBJ       0
    psi[14,5]  OBJ       0
    psi[14,6]  OBJ       0
    psi[14,7]  column_0  1
    psi[14,7]  column_12  1
    psi[14,7]  column_13  1
    psi[14,7]  column_48  1
    psi[14,7]  column_49  1
    psi[14,7]  column_68  1
    psi[14,8]  OBJ       8.1594046158160116e-01
    psi[14,8]  column_5  1
    psi[14,8]  column_6  1
    psi[14,8]  column_7  1
    psi[14,8]  column_8  1
    psi[14,8]  column_15  1
    psi[14,8]  column_16  1
    psi[14,8]  column_17  1
    psi[14,8]  column_18  1
    psi[14,8]  column_19  1
    psi[14,8]  column_20  1
    psi[14,8]  column_21  1
    psi[14,8]  column_22  1
    psi[14,8]  column_23  1
    psi[14,8]  column_24  1
    psi[14,8]  column_25  1
    psi[14,8]  column_26  1
    psi[14,8]  column_27  1
    psi[14,8]  column_28  1
    psi[14,8]  column_29  1
    psi[14,8]  column_30  1
    psi[14,8]  column_31  1
    psi[14,8]  column_32  1
    psi[14,8]  column_34  1
    psi[14,8]  column_35  1
    psi[14,8]  column_36  1
    psi[14,8]  column_37  1
    psi[14,8]  column_39  1
    psi[14,8]  column_41  1
    psi[14,8]  column_42  1
    psi[14,8]  column_43  1
    psi[14,8]  column_44  1
    psi[14,8]  column_45  1
    psi[14,8]  column_46  1
    psi[14,8]  column_47  1
    psi[14,8]  column_51  1
    psi[14,8]  column_52  1
    psi[14,8]  column_53  1
    psi[14,8]  column_54  1
    psi[14,8]  column_57  1
    psi[14,8]  column_58  1
    psi[14,8]  column_59  1
    psi[14,8]  column_60  1
    psi[14,8]  column_61  1
    psi[14,8]  column_62  1
    psi[14,8]  column_63  1
    psi[14,8]  column_64  1
    psi[14,8]  column_65  1
    psi[14,8]  column_66  1
    psi[14,8]  column_67  1
    psi[14,8]  column_69  1
    psi[14,8]  column_70  1
    psi[14,8]  column_71  1
    psi[14,8]  column_72  1
    psi[14,8]  column_73  1
    psi[14,8]  column_77  1
    psi[14,8]  column_78  1
    psi[14,8]  column_80  1
    psi[14,8]  column_81  1
    psi[14,8]  column_83  1
    psi[14,8]  column_84  1
    psi[14,8]  column_85  1
    psi[14,8]  column_86  1
    psi[14,8]  column_87  1
    psi[14,8]  column_88  1
    psi[14,8]  column_89  1
    psi[14,8]  column_92  1
    psi[14,8]  column_93  1
    psi[14,8]  column_94  1
    psi[14,8]  column_95  1
    psi[14,8]  column_96  1
    psi[14,8]  column_97  1
    psi[14,8]  column_98  1
    psi[14,8]  column_99  1
    psi[14,8]  column_100  1
    psi[14,8]  column_101  1
    psi[14,9]  OBJ       0
    psi[14,10]  OBJ       0
    psi[14,11]  OBJ       0
    psi[14,12]  OBJ       0
    psi[14,13]  OBJ       0
    psi[14,14]  OBJ       0
    psi[14,15]  OBJ       0
    psi[15,0]  column_55  1
    psi[15,1]  OBJ       0
    psi[15,2]  OBJ       0
    psi[15,3]  OBJ       4.8480376864838526e-02
    psi[15,3]  column_0  1
    psi[15,3]  column_1  1
    psi[15,3]  column_2  1
    psi[15,3]  column_3  1
    psi[15,3]  column_4  1
    psi[15,3]  column_9  1
    psi[15,3]  column_10  1
    psi[15,3]  column_11  1
    psi[15,3]  column_12  1
    psi[15,3]  column_23  1
    psi[15,3]  column_34  1
    psi[15,3]  column_35  1
    psi[15,3]  column_40  1
    psi[15,3]  column_41  1
    psi[15,3]  column_48  1
    psi[15,3]  column_49  1
    psi[15,3]  column_50  1
    psi[15,3]  column_51  1
    psi[15,3]  column_56  1
    psi[15,3]  column_60  1
    psi[15,3]  column_86  1
    psi[15,4]  OBJ       0
    psi[15,5]  OBJ       0
    psi[15,6]  OBJ       0
    psi[15,7]  OBJ       0
    psi[15,8]  OBJ       9.5151962313516147e-01
    psi[15,8]  column_5  1
    psi[15,8]  column_6  1
    psi[15,8]  column_7  1
    psi[15,8]  column_8  1
    psi[15,8]  column_15  1
    psi[15,8]  column_16  1
    psi[15,8]  column_17  1
    psi[15,8]  column_18  1
    psi[15,8]  column_19  1
    psi[15,8]  column_20  1
    psi[15,8]  column_21  1
    psi[15,8]  column_22  1
    psi[15,8]  column_24  1
    psi[15,8]  column_25  1
    psi[15,8]  column_26  1
    psi[15,8]  column_27  1
    psi[15,8]  column_28  1
    psi[15,8]  column_29  1
    psi[15,8]  column_30  1
    psi[15,8]  column_31  1
    psi[15,8]  column_32  1
    psi[15,8]  column_33  1
    psi[15,8]  column_36  1
    psi[15,8]  column_37  1
    psi[15,8]  column_57  1
    psi[15,8]  column_61  1
    psi[15,8]  column_62  1
    psi[15,8]  column_63  1
    psi[15,8]  column_64  1
    psi[15,8]  column_69  1
    psi[15,8]  column_70  1
    psi[15,8]  column_71  1
    psi[15,8]  column_72  1
    psi[15,8]  column_73  1
    psi[15,8]  column_74  1
    psi[15,8]  column_75  1
    psi[15,8]  column_76  1
    psi[15,8]  column_77  1
    psi[15,8]  column_78  1
    psi[15,8]  column_79  1
    psi[15,8]  column_80  1
    psi[15,8]  column_81  1
    psi[15,8]  column_82  1
    psi[15,8]  column_83  1
    psi[15,8]  column_84  1
    psi[15,8]  column_85  1
    psi[15,8]  column_88  1
    psi[15,9]  column_13  1
    psi[15,9]  column_14  1
    psi[15,9]  column_38  1
    psi[15,9]  column_39  1
    psi[15,9]  column_42  1
    psi[15,9]  column_43  1
    psi[15,9]  column_44  1
    psi[15,9]  column_45  1
    psi[15,9]  column_46  1
    psi[15,9]  column_47  1
    psi[15,9]  column_52  1
    psi[15,9]  column_53  1
    psi[15,9]  column_54  1
    psi[15,9]  column_58  1
    psi[15,9]  column_59  1
    psi[15,9]  column_65  1
    psi[15,9]  column_66  1
    psi[15,9]  column_67  1
    psi[15,9]  column_68  1
    psi[15,9]  column_87  1
    psi[15,9]  column_89  1
    psi[15,9]  column_90  1
    psi[15,9]  column_91  1
    psi[15,9]  column_92  1
    psi[15,9]  column_93  1
    psi[15,9]  column_94  1
    psi[15,9]  column_95  1
    psi[15,9]  column_96  1
    psi[15,9]  column_97  1
    psi[15,9]  column_98  1
    psi[15,9]  column_99  1
    psi[15,9]  column_100  1
    psi[15,9]  column_101  1
    psi[15,10]  OBJ       0
    psi[15,11]  OBJ       0
    psi[15,12]  OBJ       0
    psi[15,13]  OBJ       0
    psi[15,14]  OBJ       0
    psi[15,15]  OBJ       0
    psi[15,16]  OBJ       0
    psi[16,0]  OBJ       0
    psi[16,1]  column_1  1
    psi[16,1]  column_2  1
    psi[16,1]  column_3  1
    psi[16,1]  column_4  1
    psi[16,1]  column_10  1
    psi[16,1]  column_39  1
    psi[16,1]  column_43  1
    psi[16,1]  column_44  1
    psi[16,1]  column_46  1
    psi[16,1]  column_50  1
    psi[16,1]  column_55  1
    psi[16,1]  column_56  1
    psi[16,1]  column_57  1
    psi[16,1]  column_62  1
    psi[16,1]  column_90  1
    psi[16,1]  column_97  1
    psi[16,1]  column_100  1
    psi[16,2]  OBJ       0
    psi[16,3]  OBJ       2.7608930762759815e-01
    psi[16,3]  column_0  1
    psi[16,3]  column_11  1
    psi[16,3]  column_12  1
    psi[16,3]  column_13  1
    psi[16,3]  column_19  1
    psi[16,3]  column_29  1
    psi[16,3]  column_31  1
    psi[16,3]  column_32  1
    psi[16,3]  column_38  1
    psi[16,3]  column_40  1
    psi[16,3]  column_41  1
    psi[16,3]  column_47  1
    psi[16,3]  column_48  1
    psi[16,3]  column_49  1
    psi[16,3]  column_51  1
    psi[16,3]  column_52  1
    psi[16,3]  column_53  1
    psi[16,3]  column_54  1
    psi[16,3]  column_58  1
    psi[16,3]  column_61  1
    psi[16,3]  column_63  1
    psi[16,3]  column_65  1
    psi[16,3]  column_66  1
    psi[16,3]  column_68  1
    psi[16,3]  column_74  1
    psi[16,3]  column_75  1
    psi[16,3]  column_76  1
    psi[16,3]  column_78  1
    psi[16,3]  column_82  1
    psi[16,3]  column_96  1
    psi[16,3]  column_99  1
    psi[16,4]  OBJ       0
    psi[16,5]  column_14  1
    psi[16,5]  column_67  1
    psi[16,5]  column_89  1
    psi[16,6]  OBJ       7.2391069237240191e-01
    psi[16,6]  column_5  1
    psi[16,6]  column_6  1
    psi[16,6]  column_7  1
    psi[16,6]  column_8  1
    psi[16,6]  column_9  1
    psi[16,6]  column_15  1
    psi[16,6]  column_16  1
    psi[16,6]  column_17  1
    psi[16,6]  column_18  1
    psi[16,6]  column_20  1
    psi[16,6]  column_21  1
    psi[16,6]  column_22  1
    psi[16,6]  column_23  1
    psi[16,6]  column_24  1
    psi[16,6]  column_25  1
    psi[16,6]  column_26  1
    psi[16,6]  column_27  1
    psi[16,6]  column_28  1
    psi[16,6]  column_30  1
    psi[16,6]  column_33  1
    psi[16,6]  column_34  1
    psi[16,6]  column_35  1
    psi[16,6]  column_36  1
    psi[16,6]  column_37  1
    psi[16,6]  column_42  1
    psi[16,6]  column_45  1
    psi[16,6]  column_59  1
    psi[16,6]  column_60  1
    psi[16,6]  column_64  1
    psi[16,6]  column_69  1
    psi[16,6]  column_70  1
    psi[16,6]  column_71  1
    psi[16,6]  column_72  1
    psi[16,6]  column_73  1
    psi[16,6]  column_77  1
    psi[16,6]  column_79  1
    psi[16,6]  column_80  1
    psi[16,6]  column_81  1
    psi[16,6]  column_83  1
    psi[16,6]  column_84  1
    psi[16,6]  column_85  1
    psi[16,6]  column_86  1
    psi[16,6]  column_87  1
    psi[16,6]  column_88  1
    psi[16,6]  column_91  1
    psi[16,6]  column_92  1
    psi[16,6]  column_93  1
    psi[16,6]  column_94  1
    psi[16,6]  column_95  1
    psi[16,6]  column_98  1
    psi[16,6]  column_101  1
    psi[16,7]  OBJ       0
    psi[16,8]  OBJ       0
    psi[16,9]  OBJ       0
    psi[16,10]  OBJ       0
    psi[16,11]  OBJ       0
    psi[16,12]  OBJ       0
    psi[17,0]  column_55  1
    psi[17,1]  OBJ       0
    psi[17,2]  OBJ       0
    psi[17,3]  column_0  1
    psi[17,3]  column_1  1
    psi[17,3]  column_2  1
    psi[17,3]  column_3  1
    psi[17,3]  column_4  1
    psi[17,3]  column_9  1
    psi[17,3]  column_11  1
    psi[17,3]  column_12  1
    psi[17,3]  column_39  1
    psi[17,3]  column_40  1
    psi[17,3]  column_41  1
    psi[17,3]  column_48  1
    psi[17,3]  column_49  1
    psi[17,3]  column_50  1
    psi[17,3]  column_56  1
    psi[17,4]  OBJ       0
    psi[17,5]  OBJ       0
    psi[17,6]  OBJ       0
    psi[17,7]  OBJ       6.2120094216209643e-01
    psi[17,7]  column_5  1
    psi[17,7]  column_6  1
    psi[17,7]  column_7  1
    psi[17,7]  column_8  1
    psi[17,7]  column_16  1
    psi[17,7]  column_17  1
    psi[17,7]  column_18  1
    psi[17,7]  column_19  1
    psi[17,7]  column_22  1
    psi[17,7]  column_23  1
    psi[17,7]  column_24  1
    psi[17,7]  column_25  1
    psi[17,7]  column_29  1
    psi[17,7]  column_30  1
    psi[17,7]  column_31  1
    psi[17,7]  column_32  1
    psi[17,7]  column_33  1
    psi[17,7]  column_34  1
    psi[17,7]  column_35  1
    psi[17,7]  column_36  1
    psi[17,7]  column_37  1
    psi[17,7]  column_69  1
    psi[17,7]  column_70  1
    psi[17,7]  column_71  1
    psi[17,7]  column_74  1
    psi[17,7]  column_75  1
    psi[17,7]  column_76  1
    psi[17,7]  column_77  1
    psi[17,7]  column_78  1
    psi[17,7]  column_79  1
    psi[17,7]  column_80  1
    psi[17,7]  column_81  1
    psi[17,7]  column_82  1
    psi[17,7]  column_83  1
    psi[17,7]  column_85  1
    psi[17,8]  OBJ       0
    psi[17,9]  OBJ       3.7879905783790374e-01
    psi[17,9]  column_10  1
    psi[17,9]  column_13  1
    psi[17,9]  column_14  1
    psi[17,9]  column_15  1
    psi[17,9]  column_20  1
    psi[17,9]  column_21  1
    psi[17,9]  column_26  1
    psi[17,9]  column_27  1
    psi[17,9]  column_28  1
    psi[17,9]  column_38  1
    psi[17,9]  column_42  1
    psi[17,9]  column_43  1
    psi[17,9]  column_44  1
    psi[17,9]  column_45  1
    psi[17,9]  column_46  1
    psi[17,9]  column_47  1
    psi[17,9]  column_51  1
    psi[17,9]  column_52  1
    psi[17,9]  column_53  1
    psi[17,9]  column_54  1
    psi[17,9]  column_57  1
    psi[17,9]  column_58  1
    psi[17,9]  column_59  1
    psi[17,9]  column_60  1
    psi[17,9]  column_61  1
    psi[17,9]  column_62  1
    psi[17,9]  column_63  1
    psi[17,9]  column_64  1
    psi[17,9]  column_65  1
    psi[17,9]  column_66  1
    psi[17,9]  column_67  1
    psi[17,9]  column_68  1
    psi[17,9]  column_72  1
    psi[17,9]  column_73  1
    psi[17,9]  column_84  1
    psi[17,9]  column_86  1
    psi[17,9]  column_87  1
    psi[17,9]  column_88  1
    psi[17,9]  column_89  1
    psi[17,9]  column_90  1
    psi[17,9]  column_91  1
    psi[17,9]  column_92  1
    psi[17,9]  column_93  1
    psi[17,9]  column_94  1
    psi[17,9]  column_95  1
    psi[17,9]  column_96  1
    psi[17,9]  column_97  1
    psi[17,9]  column_98  1
    psi[17,9]  column_99  1
    psi[17,9]  column_100  1
    psi[17,9]  column_101  1
    psi[17,10]  OBJ       0
    psi[17,11]  OBJ       0
    psi[17,12]  OBJ       0
    psi[17,13]  OBJ       0
    psi[17,14]  OBJ       0
    psi[17,15]  OBJ       0
    psi[17,16]  OBJ       0
    psi[18,0]  column_55  1
    psi[18,0]  column_88  1
    psi[18,1]  OBJ       0
    psi[18,2]  OBJ       0
    psi[18,3]  OBJ       0
    psi[18,4]  column_38  1
    psi[18,4]  column_39  1
    psi[18,4]  column_48  1
    psi[18,4]  column_49  1
    psi[18,4]  column_50  1
    psi[18,4]  column_51  1
    psi[18,4]  column_58  1
    psi[18,4]  column_59  1
    psi[18,4]  column_86  1
    psi[18,4]  column_87  1
    psi[18,5]  OBJ       2.3577480013138991e-02
    psi[18,5]  column_2  1
    psi[18,5]  column_9  1
    psi[18,5]  column_14  1
    psi[18,5]  column_23  1
    psi[18,5]  column_40  1
    psi[18,5]  column_41  1
    psi[18,5]  column_47  1
    psi[18,6]  OBJ       3.8269732142387891e-01
    psi[18,6]  column_19  1
    psi[18,6]  column_29  1
    psi[18,6]  column_31  1
    psi[18,6]  column_32  1
    psi[18,6]  column_33  1
    psi[18,6]  column_36  1
    psi[18,6]  column_37  1
    psi[18,6]  column_74  1
    psi[18,6]  column_75  1
    psi[18,6]  column_76  1
    psi[18,6]  column_77  1
    psi[18,6]  column_78  1
    psi[18,6]  column_79  1
    psi[18,6]  column_82  1
    psi[18,6]  column_83  1
    psi[18,7]  column_11  1
    psi[18,7]  column_12  1
    psi[18,7]  column_13  1
    psi[18,7]  column_56  1
    psi[18,7]  column_68  1
    psi[18,8]  OBJ       0
    psi[18,9]  OBJ       5.9372519856298211e-01
    psi[18,9]  column_0  1
    psi[18,9]  column_1  1
    psi[18,9]  column_3  1
    psi[18,9]  column_4  1
    psi[18,9]  column_5  1
    psi[18,9]  column_6  1
    psi[18,9]  column_7  1
    psi[18,9]  column_8  1
    psi[18,9]  column_10  1
    psi[18,9]  column_15  1
    psi[18,9]  column_16  1
    psi[18,9]  column_17  1
    psi[18,9]  column_18  1
    psi[18,9]  column_20  1
    psi[18,9]  column_21  1
    psi[18,9]  column_22  1
    psi[18,9]  column_24  1
    psi[18,9]  column_25  1
    psi[18,9]  column_26  1
    psi[18,9]  column_27  1
    psi[18,9]  column_28  1
    psi[18,9]  column_30  1
    psi[18,9]  column_34  1
    psi[18,9]  column_35  1
    psi[18,9]  column_42  1
    psi[18,9]  column_43  1
    psi[18,9]  column_44  1
    psi[18,9]  column_45  1
    psi[18,9]  column_46  1
    psi[18,9]  column_52  1
    psi[18,9]  column_53  1
    psi[18,9]  column_54  1
    psi[18,9]  column_57  1
    psi[18,9]  column_60  1
    psi[18,9]  column_61  1
    psi[18,9]  column_62  1
    psi[18,9]  column_63  1
    psi[18,9]  column_64  1
    psi[18,9]  column_65  1
    psi[18,9]  column_66  1
    psi[18,9]  column_67  1
    psi[18,9]  column_69  1
    psi[18,9]  column_70  1
    psi[18,9]  column_71  1
    psi[18,9]  column_72  1
    psi[18,9]  column_73  1
    psi[18,9]  column_80  1
    psi[18,9]  column_81  1
    psi[18,9]  column_84  1
    psi[18,9]  column_85  1
    psi[18,9]  column_89  1
    psi[18,9]  column_90  1
    psi[18,9]  column_91  1
    psi[18,9]  column_92  1
    psi[18,9]  column_93  1
    psi[18,9]  column_94  1
    psi[18,9]  column_95  1
    psi[18,9]  column_96  1
    psi[18,9]  column_97  1
    psi[18,9]  column_98  1
    psi[18,9]  column_99  1
    psi[18,9]  column_100  1
    psi[18,9]  column_101  1
    psi[18,10]  OBJ       0
    psi[18,11]  OBJ       0
    psi[18,12]  OBJ       0
    psi[18,13]  OBJ       0
    psi[18,14]  OBJ       0
    psi[18,15]  OBJ       0
    psi[18,16]  OBJ       0
    psi[18,17]  OBJ       0
    psi[19,0]  column_9  1
    psi[19,0]  column_14  1
    psi[19,0]  column_67  1
    psi[19,0]  column_89  1
    psi[19,0]  column_93  1
    psi[19,0]  column_94  1
    psi[19,0]  column_95  1
    psi[19,1]  OBJ       0
    psi[19,2]  OBJ       3.9696006066410994e-01
    psi[19,2]  column_3  1
    psi[19,2]  column_4  1
    psi[19,2]  column_5  1
    psi[19,2]  column_11  1
    psi[19,2]  column_12  1
    psi[19,2]  column_13  1
    psi[19,2]  column_15  1
    psi[19,2]  column_16  1
    psi[19,2]  column_17  1
    psi[19,2]  column_18  1
    psi[19,2]  column_20  1
    psi[19,2]  column_21  1
    psi[19,2]  column_22  1
    psi[19,2]  column_23  1
    psi[19,2]  column_24  1
    psi[19,2]  column_25  1
    psi[19,2]  column_30  1
    psi[19,2]  column_36  1
    psi[19,2]  column_37  1
    psi[19,2]  column_39  1
    psi[19,2]  column_43  1
    psi[19,2]  column_44  1
    psi[19,2]  column_45  1
    psi[19,2]  column_46  1
    psi[19,2]  column_53  1
    psi[19,2]  column_54  1
    psi[19,2]  column_55  1
    psi[19,2]  column_56  1
    psi[19,2]  column_57  1
    psi[19,2]  column_61  1
    psi[19,2]  column_62  1
    psi[19,2]  column_65  1
    psi[19,2]  column_68  1
    psi[19,2]  column_69  1
    psi[19,2]  column_70  1
    psi[19,2]  column_72  1
    psi[19,2]  column_73  1
    psi[19,2]  column_80  1
    psi[19,2]  column_81  1
    psi[19,2]  column_83  1
    psi[19,2]  column_84  1
    psi[19,2]  column_85  1
    psi[19,2]  column_88  1
    psi[19,2]  column_92  1
    psi[19,2]  column_96  1
    psi[19,2]  column_97  1
    psi[19,2]  column_98  1
    psi[19,3]  column_0  1
    psi[19,3]  column_1  1
    psi[19,3]  column_2  1
    psi[19,3]  column_38  1
    psi[19,3]  column_40  1
    psi[19,3]  column_41  1
    psi[19,3]  column_47  1
    psi[19,3]  column_48  1
    psi[19,3]  column_49  1
    psi[19,3]  column_50  1
    psi[19,3]  column_51  1
    psi[19,3]  column_52  1
    psi[19,3]  column_58  1
    psi[19,3]  column_66  1
    psi[19,3]  column_91  1
    psi[19,3]  column_99  1
    psi[19,3]  column_100  1
    psi[19,4]  OBJ       6.0303993933589006e-01
    psi[19,4]  column_6  1
    psi[19,4]  column_7  1
    psi[19,4]  column_8  1
    psi[19,4]  column_10  1
    psi[19,4]  column_19  1
    psi[19,4]  column_26  1
    psi[19,4]  column_27  1
    psi[19,4]  column_28  1
    psi[19,4]  column_29  1
    psi[19,4]  column_31  1
    psi[19,4]  column_32  1
    psi[19,4]  column_33  1
    psi[19,4]  column_34  1
    psi[19,4]  column_35  1
    psi[19,4]  column_42  1
    psi[19,4]  column_59  1
    psi[19,4]  column_60  1
    psi[19,4]  column_63  1
    psi[19,4]  column_64  1
    psi[19,4]  column_71  1
    psi[19,4]  column_74  1
    psi[19,4]  column_75  1
    psi[19,4]  column_76  1
    psi[19,4]  column_77  1
    psi[19,4]  column_78  1
    psi[19,4]  column_79  1
    psi[19,4]  column_82  1
    psi[19,4]  column_86  1
    psi[19,4]  column_87  1
    psi[19,4]  column_90  1
    psi[19,4]  column_101  1
    psi[19,5]  OBJ       0
    psi[19,6]  OBJ       0
    psi[19,7]  OBJ       0
    psi[19,8]  OBJ       0
    psi[20,0]  OBJ       0
    psi[20,1]  OBJ       0
    psi[20,2]  OBJ       0
    psi[20,3]  OBJ       2.7608930762759815e-01
    psi[20,3]  column_0  1
    psi[20,3]  column_1  1
    psi[20,3]  column_2  1
    psi[20,3]  column_3  1
    psi[20,3]  column_4  1
    psi[20,3]  column_11  1
    psi[20,3]  column_12  1
    psi[20,3]  column_13  1
    psi[20,3]  column_26  1
    psi[20,3]  column_27  1
    psi[20,3]  column_28  1
    psi[20,3]  column_34  1
    psi[20,3]  column_35  1
    psi[20,3]  column_36  1
    psi[20,3]  column_37  1
    psi[20,3]  column_38  1
    psi[20,3]  column_39  1
    psi[20,3]  column_40  1
    psi[20,3]  column_41  1
    psi[20,3]  column_42  1
    psi[20,3]  column_43  1
    psi[20,3]  column_44  1
    psi[20,3]  column_45  1
    psi[20,3]  column_47  1
    psi[20,3]  column_48  1
    psi[20,3]  column_49  1
    psi[20,3]  column_50  1
    psi[20,3]  column_51  1
    psi[20,3]  column_52  1
    psi[20,3]  column_55  1
    psi[20,3]  column_56  1
    psi[20,3]  column_57  1
    psi[20,3]  column_58  1
    psi[20,3]  column_61  1
    psi[20,3]  column_66  1
    psi[20,3]  column_68  1
    psi[20,3]  column_77  1
    psi[20,3]  column_83  1
    psi[20,3]  column_90  1
    psi[20,3]  column_99  1
    psi[20,4]  column_9  1
    psi[20,4]  column_14  1
    psi[20,4]  column_53  1
    psi[20,4]  column_54  1
    psi[20,4]  column_65  1
    psi[20,4]  column_67  1
    psi[20,4]  column_89  1
    psi[20,4]  column_96  1
    psi[20,5]  OBJ       0
    psi[20,6]  OBJ       7.2391069237240191e-01
    psi[20,6]  column_5  1
    psi[20,6]  column_6  1
    psi[20,6]  column_7  1
    psi[20,6]  column_8  1
    psi[20,6]  column_10  1
    psi[20,6]  column_15  1
    psi[20,6]  column_16  1
    psi[20,6]  column_17  1
    psi[20,6]  column_18  1
    psi[20,6]  column_19  1
    psi[20,6]  column_20  1
    psi[20,6]  column_21  1
    psi[20,6]  column_22  1
    psi[20,6]  column_23  1
    psi[20,6]  column_24  1
    psi[20,6]  column_25  1
    psi[20,6]  column_29  1
    psi[20,6]  column_30  1
    psi[20,6]  column_31  1
    psi[20,6]  column_32  1
    psi[20,6]  column_33  1
    psi[20,6]  column_46  1
    psi[20,6]  column_59  1
    psi[20,6]  column_60  1
    psi[20,6]  column_62  1
    psi[20,6]  column_63  1
    psi[20,6]  column_64  1
    psi[20,6]  column_69  1
    psi[20,6]  column_70  1
    psi[20,6]  column_71  1
    psi[20,6]  column_72  1
    psi[20,6]  column_73  1
    psi[20,6]  column_74  1
    psi[20,6]  column_75  1
    psi[20,6]  column_76  1
    psi[20,6]  column_78  1
    psi[20,6]  column_79  1
    psi[20,6]  column_80  1
    psi[20,6]  column_81  1
    psi[20,6]  column_82  1
    psi[20,6]  column_84  1
    psi[20,6]  column_85  1
    psi[20,6]  column_86  1
    psi[20,6]  column_87  1
    psi[20,6]  column_88  1
    psi[20,6]  column_91  1
    psi[20,6]  column_92  1
    psi[20,6]  column_93  1
    psi[20,6]  column_94  1
    psi[20,6]  column_95  1
    psi[20,6]  column_97  1
    psi[20,6]  column_98  1
    psi[20,6]  column_100  1
    psi[20,6]  column_101  1
    psi[20,7]  OBJ       0
    psi[20,8]  OBJ       0
    psi[20,9]  OBJ       0
    psi[20,10]  OBJ       0
    psi[20,11]  OBJ       0
    psi[20,12]  OBJ       0
    psi[21,0]  OBJ       0
    psi[21,1]  OBJ       4.3864200792997909e-05
    psi[21,1]  column_1  1
    psi[21,1]  column_3  1
    psi[21,1]  column_4  1
    psi[21,1]  column_50  1
    psi[21,1]  column_83  1
    psi[21,1]  column_91  1
    psi[21,1]  column_92  1
    psi[21,2]  OBJ       0
    psi[21,3]  OBJ       0
    psi[21,4]  OBJ       3.4698015101878421e-02
    psi[21,4]  column_18  1
    psi[21,4]  column_24  1
    psi[21,4]  column_25  1
    psi[21,4]  column_42  1
    psi[21,4]  column_43  1
    psi[21,4]  column_55  1
    psi[21,4]  column_80  1
    psi[21,5]  column_0  1
    psi[21,5]  column_39  1
    psi[21,5]  column_48  1
    psi[21,5]  column_49  1
    psi[21,5]  column_51  1
    psi[21,6]  column_9  1
    psi[21,6]  column_14  1
    psi[21,6]  column_38  1
    psi[21,6]  column_40  1
    psi[21,6]  column_41  1
    psi[21,6]  column_47  1
    psi[21,6]  column_52  1
    psi[21,6]  column_53  1
    psi[21,6]  column_54  1
    psi[21,6]  column_56  1
    psi[21,6]  column_57  1
    psi[21,6]  column_60  1
    psi[21,6]  column_61  1
    psi[21,6]  column_62  1
    psi[21,6]  column_63  1
    psi[21,6]  column_64  1
    psi[21,6]  column_65  1
    psi[21,6]  column_67  1
    psi[21,6]  column_89  1
    psi[21,6]  column_93  1
    psi[21,7]  OBJ       9.6525812069732864e-01
    psi[21,7]  column_5  1
    psi[21,7]  column_6  1
    psi[21,7]  column_7  1
    psi[21,7]  column_8  1
    psi[21,7]  column_11  1
    psi[21,7]  column_12  1
    psi[21,7]  column_13  1
    psi[21,7]  column_15  1
    psi[21,7]  column_16  1
    psi[21,7]  column_17  1
    psi[21,7]  column_19  1
    psi[21,7]  column_20  1
    psi[21,7]  column_21  1
    psi[21,7]  column_22  1
    psi[21,7]  column_23  1
    psi[21,7]  column_26  1
    psi[21,7]  column_27  1
    psi[21,7]  column_28  1
    psi[21,7]  column_29  1
    psi[21,7]  column_30  1
    psi[21,7]  column_31  1
    psi[21,7]  column_32  1
    psi[21,7]  column_33  1
    psi[21,7]  column_34  1
    psi[21,7]  column_35  1
    psi[21,7]  column_36  1
    psi[21,7]  column_37  1
    psi[21,7]  column_44  1
    psi[21,7]  column_45  1
    psi[21,7]  column_46  1
    psi[21,7]  column_66  1
    psi[21,7]  column_68  1
    psi[21,7]  column_69  1
    psi[21,7]  column_70  1
    psi[21,7]  column_71  1
    psi[21,7]  column_72  1
    psi[21,7]  column_73  1
    psi[21,7]  column_74  1
    psi[21,7]  column_75  1
    psi[21,7]  column_76  1
    psi[21,7]  column_77  1
    psi[21,7]  column_78  1
    psi[21,7]  column_79  1
    psi[21,7]  column_81  1
    psi[21,7]  column_82  1
    psi[21,7]  column_84  1
    psi[21,7]  column_85  1
    psi[21,7]  column_88  1
    psi[21,7]  column_94  1
    psi[21,7]  column_95  1
    psi[21,7]  column_99  1
    psi[21,7]  column_100  1
    psi[21,7]  column_101  1
    psi[21,8]  column_2  1
    psi[21,8]  column_10  1
    psi[21,8]  column_58  1
    psi[21,8]  column_59  1
    psi[21,8]  column_86  1
    psi[21,8]  column_87  1
    psi[21,8]  column_90  1
    psi[21,8]  column_96  1
    psi[21,8]  column_97  1
    psi[21,8]  column_98  1
    psi[21,9]  OBJ       0
    psi[21,10]  OBJ       0
    psi[21,11]  OBJ       0
    psi[21,12]  OBJ       0
    psi[21,13]  OBJ       0
    psi[21,14]  OBJ       0
    psi[21,15]  OBJ       0
    psi[22,0]  OBJ       0
    psi[22,1]  OBJ       0
    psi[22,2]  OBJ       0
    psi[22,3]  column_0  1
    psi[22,3]  column_1  1
    psi[22,3]  column_3  1
    psi[22,3]  column_4  1
    psi[22,3]  column_11  1
    psi[22,3]  column_12  1
    psi[22,3]  column_13  1
    psi[22,3]  column_48  1
    psi[22,3]  column_49  1
    psi[22,3]  column_50  1
    psi[22,3]  column_51  1
    psi[22,3]  column_58  1
    psi[22,3]  column_68  1
    psi[22,4]  column_38  1
    psi[22,4]  column_52  1
    psi[22,4]  column_53  1
    psi[22,4]  column_54  1
    psi[22,4]  column_65  1
    psi[22,4]  column_66  1
    psi[22,4]  column_99  1
    psi[22,5]  OBJ       8.2826792288279449e-01
    psi[22,5]  column_5  1
    psi[22,5]  column_6  1
    psi[22,5]  column_7  1
    psi[22,5]  column_8  1
    psi[22,5]  column_14  1
    psi[22,5]  column_18  1
    psi[22,5]  column_19  1
    psi[22,5]  column_20  1
    psi[22,5]  column_23  1
    psi[22,5]  column_24  1
    psi[22,5]  column_25  1
    psi[22,5]  column_26  1
    psi[22,5]  column_27  1
    psi[22,5]  column_28  1
    psi[22,5]  column_29  1
    psi[22,5]  column_31  1
    psi[22,5]  column_32  1
    psi[22,5]  column_33  1
    psi[22,5]  column_34  1
    psi[22,5]  column_35  1
    psi[22,5]  column_36  1
    psi[22,5]  column_37  1
    psi[22,5]  column_39  1
    psi[22,5]  column_40  1
    psi[22,5]  column_41  1
    psi[22,5]  column_43  1
    psi[22,5]  column_44  1
    psi[22,5]  column_47  1
    psi[22,5]  column_67  1
    psi[22,5]  column_72  1
    psi[22,5]  column_74  1
    psi[22,5]  column_75  1
    psi[22,5]  column_76  1
    psi[22,5]  column_77  1
    psi[22,5]  column_78  1
    psi[22,5]  column_79  1
    psi[22,5]  column_80  1
    psi[22,5]  column_81  1
    psi[22,5]  column_82  1
    psi[22,5]  column_83  1
    psi[22,5]  column_84  1
    psi[22,5]  column_89  1
    psi[22,6]  OBJ       1.7173207711720551e-01
    psi[22,6]  column_2  1
    psi[22,6]  column_9  1
    psi[22,6]  column_10  1
    psi[22,6]  column_15  1
    psi[22,6]  column_16  1
    psi[22,6]  column_17  1
    psi[22,6]  column_21  1
    psi[22,6]  column_22  1
    psi[22,6]  column_30  1
    psi[22,6]  column_42  1
    psi[22,6]  column_45  1
    psi[22,6]  column_46  1
    psi[22,6]  column_55  1
    psi[22,6]  column_56  1
    psi[22,6]  column_57  1
    psi[22,6]  column_59  1
    psi[22,6]  column_60  1
    psi[22,6]  column_61  1
    psi[22,6]  column_62  1
    psi[22,6]  column_63  1
    psi[22,6]  column_64  1
    psi[22,6]  column_69  1
    psi[22,6]  column_70  1
    psi[22,6]  column_71  1
    psi[22,6]  column_73  1
    psi[22,6]  column_85  1
    psi[22,6]  column_86  1
    psi[22,6]  column_87  1
    psi[22,6]  column_88  1
    psi[22,6]  column_90  1
    psi[22,6]  column_91  1
    psi[22,6]  column_92  1
    psi[22,6]  column_93  1
    psi[22,6]  column_94  1
    psi[22,6]  column_95  1
    psi[22,6]  column_96  1
    psi[22,6]  column_97  1
    psi[22,6]  column_98  1
    psi[22,6]  column_100  1
    psi[22,6]  column_101  1
    psi[22,7]  OBJ       0
    psi[22,8]  OBJ       0
    psi[22,9]  OBJ       0
    psi[22,10]  OBJ       0
    psi[22,11]  OBJ       0
    psi[22,12]  OBJ       0
    psi[23,0]  OBJ       0
    psi[23,1]  OBJ       0
    psi[23,2]  OBJ       0
    psi[23,3]  OBJ       0.0159776316734135
    psi[23,3]  column_2  1
    psi[23,3]  column_5  1
    psi[23,3]  column_9  1
    psi[23,3]  column_14  1
    psi[23,3]  column_38  1
    psi[23,3]  column_40  1
    psi[23,3]  column_41  1
    psi[23,3]  column_47  1
    psi[23,3]  column_52  1
    psi[23,3]  column_53  1
    psi[23,3]  column_54  1
    psi[23,3]  column_65  1
    psi[23,3]  column_66  1
    psi[23,3]  column_67  1
    psi[23,3]  column_89  1
    psi[23,3]  column_90  1
    psi[23,3]  column_94  1
    psi[23,3]  column_96  1
    psi[23,3]  column_98  1
    psi[23,3]  column_99  1
    psi[23,3]  column_101  1
    psi[23,4]  OBJ       9.6044488831344754e-01
    psi[23,4]  column_0  1
    psi[23,4]  column_6  1
    psi[23,4]  column_7  1
    psi[23,4]  column_8  1
    psi[23,4]  column_11  1
    psi[23,4]  column_12  1
    psi[23,4]  column_13  1
    psi[23,4]  column_15  1
    psi[23,4]  column_16  1
    psi[23,4]  column_18  1
    psi[23,4]  column_19  1
    psi[23,4]  column_20  1
    psi[23,4]  column_21  1
    psi[23,4]  column_23  1
    psi[23,4]  column_24  1
    psi[23,4]  column_25  1
    psi[23,4]  column_26  1
    psi[23,4]  column_27  1
    psi[23,4]  column_28  1
    psi[23,4]  column_29  1
    psi[23,4]  column_30  1
    psi[23,4]  column_31  1
    psi[23,4]  column_32  1
    psi[23,4]  column_33  1
    psi[23,4]  column_34  1
    psi[23,4]  column_35  1
    psi[23,4]  column_36  1
    psi[23,4]  column_37  1
    psi[23,4]  column_39  1
    psi[23,4]  column_43  1
    psi[23,4]  column_44  1
    psi[23,4]  column_45  1
    psi[23,4]  column_48  1
    psi[23,4]  column_49  1
    psi[23,4]  column_51  1
    psi[23,4]  column_55  1
    psi[23,4]  column_56  1
    psi[23,4]  column_57  1
    psi[23,4]  column_58  1
    psi[23,4]  column_60  1
    psi[23,4]  column_61  1
    psi[23,4]  column_62  1
    psi[23,4]  column_63  1
    psi[23,4]  column_64  1
    psi[23,4]  column_68  1
    psi[23,4]  column_69  1
    psi[23,4]  column_70  1
    psi[23,4]  column_71  1
    psi[23,4]  column_72  1
    psi[23,4]  column_73  1
    psi[23,4]  column_74  1
    psi[23,4]  column_75  1
    psi[23,4]  column_76  1
    psi[23,4]  column_77  1
    psi[23,4]  column_78  1
    psi[23,4]  column_79  1
    psi[23,4]  column_80  1
    psi[23,4]  column_81  1
    psi[23,4]  column_82  1
    psi[23,4]  column_83  1
    psi[23,4]  column_84  1
    psi[23,4]  column_85  1
    psi[23,5]  OBJ       2.3577480013138991e-02
    psi[23,5]  column_1  1
    psi[23,5]  column_3  1
    psi[23,5]  column_4  1
    psi[23,5]  column_10  1
    psi[23,5]  column_17  1
    psi[23,5]  column_22  1
    psi[23,5]  column_42  1
    psi[23,5]  column_46  1
    psi[23,5]  column_50  1
    psi[23,5]  column_59  1
    psi[23,5]  column_86  1
    psi[23,5]  column_87  1
    psi[23,5]  column_88  1
    psi[23,5]  column_91  1
    psi[23,5]  column_92  1
    psi[23,5]  column_93  1
    psi[23,5]  column_95  1
    psi[23,5]  column_97  1
    psi[23,5]  column_100  1
    psi[23,6]  OBJ       0
    psi[23,7]  OBJ       0
    psi[23,8]  OBJ       0
    psi[23,9]  OBJ       0
    psi[23,10]  OBJ       0
    psi[23,11]  OBJ       0
    psi[24,0]  OBJ       0
    psi[24,1]  OBJ       0
    psi[24,2]  OBJ       0
    psi[24,3]  OBJ       0
    psi[24,4]  OBJ       4.2644903507844077e-02
    psi[24,4]  column_2  1
    psi[24,4]  column_3  1
    psi[24,4]  column_4  1
    psi[24,4]  column_9  1
    psi[24,4]  column_11  1
    psi[24,4]  column_12  1
    psi[24,4]  column_13  1
    psi[24,4]  column_14  1
    psi[24,4]  column_18  1
    psi[24,4]  column_24  1
    psi[24,4]  column_38  1
    psi[24,4]  column_40  1
    psi[24,4]  column_41  1
    psi[24,4]  column_47  1
    psi[24,4]  column_52  1
    psi[24,4]  column_66  1
    psi[24,4]  column_67  1
    psi[24,4]  column_80  1
    psi[24,4]  column_81  1
    psi[24,4]  column_89  1
    psi[24,4]  column_93  1
    psi[24,4]  column_94  1
    psi[24,4]  column_95  1
    psi[24,4]  column_101  1
    psi[24,5]  column_0  1
    psi[24,5]  column_39  1
    psi[24,5]  column_43  1
    psi[24,5]  column_44  1
    psi[24,5]  column_45  1
    psi[24,5]  column_48  1
    psi[24,5]  column_49  1
    psi[24,5]  column_51  1
    psi[24,5]  column_53  1
    psi[24,5]  column_54  1
    psi[24,5]  column_55  1
    psi[24,5]  column_56  1
    psi[24,5]  column_57  1
    psi[24,5]  column_58  1
    psi[24,5]  column_60  1
    psi[24,5]  column_61  1
    psi[24,5]  column_62  1
    psi[24,5]  column_63  1
    psi[24,5]  column_64  1
    psi[24,6]  OBJ       0
    psi[24,7]  OBJ       9.3377761647901691e-01
    psi[24,7]  column_5  1
    psi[24,7]  column_6  1
    psi[24,7]  column_15  1
    psi[24,7]  column_16  1
    psi[24,7]  column_17  1
    psi[24,7]  column_20  1
    psi[24,7]  column_21  1
    psi[24,7]  column_22  1
    psi[24,7]  column_23  1
    psi[24,7]  column_25  1
    psi[24,7]  column_26  1
    psi[24,7]  column_27  1
    psi[24,7]  column_28  1
    psi[24,7]  column_29  1
    psi[24,7]  column_30  1
    psi[24,7]  column_31  1
    psi[24,7]  column_32  1
    psi[24,7]  column_33  1
    psi[24,7]  column_34  1
    psi[24,7]  column_35  1
    psi[24,7]  column_36  1
    psi[24,7]  column_37  1
    psi[24,7]  column_42  1
    psi[24,7]  column_46  1
    psi[24,7]  column_68  1
    psi[24,7]  column_69  1
    psi[24,7]  column_70  1
    psi[24,7]  column_71  1
    psi[24,7]  column_72  1
    psi[24,7]  column_73  1
    psi[24,7]  column_74  1
    psi[24,7]  column_75  1
    psi[24,7]  column_77  1
    psi[24,7]  column_78  1
    psi[24,7]  column_79  1
    psi[24,7]  column_82  1
    psi[24,7]  column_84  1
    psi[24,7]  column_85  1
    psi[24,7]  column_97  1
    psi[24,8]  OBJ       2.3577480013138991e-02
    psi[24,8]  column_1  1
    psi[24,8]  column_7  1
    psi[24,8]  column_8  1
    psi[24,8]  column_10  1
    psi[24,8]  column_19  1
    psi[24,8]  column_50  1
    psi[24,8]  column_59  1
    psi[24,8]  column_65  1
    psi[24,8]  column_76  1
    psi[24,8]  column_83  1
    psi[24,8]  column_86  1
    psi[24,8]  column_87  1
    psi[24,8]  column_88  1
    psi[24,8]  column_90  1
    psi[24,8]  column_91  1
    psi[24,8]  column_92  1
    psi[24,8]  column_96  1
    psi[24,8]  column_98  1
    psi[24,8]  column_99  1
    psi[24,8]  column_100  1
    psi[24,9]  OBJ       0
    psi[24,10]  OBJ       0
    psi[24,11]  OBJ       0
    psi[24,12]  OBJ       0
    psi[24,13]  OBJ       0
    psi[24,14]  OBJ       0
    psi[24,15]  OBJ       0
    psi[25,0]  OBJ       0
    psi[25,1]  column_0  1
    psi[25,1]  column_1  1
    psi[25,1]  column_3  1
    psi[25,1]  column_4  1
    psi[25,1]  column_9  1
    psi[25,1]  column_11  1
    psi[25,1]  column_14  1
    psi[25,1]  column_39  1
    psi[25,1]  column_43  1
    psi[25,1]  column_48  1
    psi[25,1]  column_50  1
    psi[25,1]  column_53  1
    psi[25,1]  column_67  1
    psi[25,1]  column_86  1
    psi[25,1]  column_87  1
    psi[25,1]  column_91  1
    psi[25,1]  column_93  1
    psi[25,1]  column_95  1
    psi[25,1]  column_100  1
    psi[25,2]  OBJ       0
    psi[25,3]  OBJ       0
    psi[25,4]  column_2  1
    psi[25,4]  column_38  1
    psi[25,4]  column_40  1
    psi[25,4]  column_41  1
    psi[25,4]  column_47  1
    psi[25,4]  column_52  1
    psi[25,4]  column_66  1
    psi[25,4]  column_101  1
    psi[25,5]  column_55  1
    psi[25,5]  column_56  1
    psi[25,5]  column_57  1
    psi[25,6]  OBJ       9.6631257669659387e-01
    psi[25,6]  column_5  1
    psi[25,6]  column_6  1
    psi[25,6]  column_7  1
    psi[25,6]  column_8  1
    psi[25,6]  column_12  1
    psi[25,6]  column_13  1
    psi[25,6]  column_15  1
    psi[25,6]  column_16  1
    psi[25,6]  column_17  1
    psi[25,6]  column_18  1
    psi[25,6]  column_19  1
    psi[25,6]  column_20  1
    psi[25,6]  column_21  1
    psi[25,6]  column_22  1
    psi[25,6]  column_23  1
    psi[25,6]  column_24  1
    psi[25,6]  column_25  1
    psi[25,6]  column_26  1
    psi[25,6]  column_27  1
    psi[25,6]  column_28  1
    psi[25,6]  column_29  1
    psi[25,6]  column_30  1
    psi[25,6]  column_31  1
    psi[25,6]  column_32  1
    psi[25,6]  column_33  1
    psi[25,6]  column_34  1
    psi[25,6]  column_35  1
    psi[25,6]  column_36  1
    psi[25,6]  column_37  1
    psi[25,6]  column_69  1
    psi[25,6]  column_71  1
    psi[25,6]  column_72  1
    psi[25,6]  column_73  1
    psi[25,6]  column_74  1
    psi[25,6]  column_75  1
    psi[25,6]  column_76  1
    psi[25,6]  column_77  1
    psi[25,6]  column_78  1
    psi[25,6]  column_79  1
    psi[25,6]  column_80  1
    psi[25,6]  column_81  1
    psi[25,6]  column_82  1
    psi[25,6]  column_83  1
    psi[25,6]  column_84  1
    psi[25,6]  column_85  1
    psi[25,7]  OBJ       3.3687423303406128e-02
    psi[25,7]  column_10  1
    psi[25,7]  column_42  1
    psi[25,7]  column_44  1
    psi[25,7]  column_45  1
    psi[25,7]  column_46  1
    psi[25,7]  column_49  1
    psi[25,7]  column_51  1
    psi[25,7]  column_54  1
    psi[25,7]  column_58  1
    psi[25,7]  column_59  1
    psi[25,7]  column_60  1
    psi[25,7]  column_61  1
    psi[25,7]  column_62  1
    psi[25,7]  column_63  1
    psi[25,7]  column_64  1
    psi[25,7]  column_65  1
    psi[25,7]  column_68  1
    psi[25,7]  column_70  1
    psi[25,7]  column_88  1
    psi[25,7]  column_89  1
    psi[25,7]  column_90  1
    psi[25,7]  column_92  1
    psi[25,7]  column_94  1
    psi[25,7]  column_96  1
    psi[25,7]  column_97  1
    psi[25,7]  column_98  1
    psi[25,7]  column_99  1
    psi[25,8]  OBJ       0
    psi[25,9]  OBJ       0
    psi[25,10]  OBJ       0
    psi[25,11]  OBJ       0
    psi[25,12]  OBJ       0
    psi[25,13]  OBJ       0
    psi[25,14]  OBJ       0
    psi[25,15]  OBJ       0
    psi[26,0]  column_3  1
    psi[26,0]  column_4  1
    psi[26,0]  column_11  1
    psi[26,0]  column_12  1
    psi[26,0]  column_13  1
    psi[26,0]  column_53  1
    psi[26,0]  column_54  1
    psi[26,0]  column_55  1
    psi[26,0]  column_56  1
    psi[26,0]  column_57  1
    psi[26,0]  column_60  1
    psi[26,0]  column_61  1
    psi[26,0]  column_62  1
    psi[26,0]  column_63  1
    psi[26,0]  column_64  1
    psi[26,0]  column_65  1
    psi[26,0]  column_68  1
    psi[26,0]  column_92  1
    psi[26,0]  column_96  1
    psi[26,0]  column_97  1
    psi[26,0]  column_98  1
    psi[26,1]  OBJ       0
    psi[26,2]  column_0  1
    psi[26,2]  column_1  1
    psi[26,2]  column_9  1
    psi[26,2]  column_14  1
    psi[26,2]  column_39  1
    psi[26,2]  column_43  1
    psi[26,2]  column_44  1
    psi[26,2]  column_45  1
    psi[26,2]  column_46  1
    psi[26,2]  column_48  1
    psi[26,2]  column_49  1
    psi[26,2]  column_50  1
    psi[26,2]  column_51  1
    psi[26,2]  column_58  1
    psi[26,2]  column_67  1
    psi[26,2]  column_89  1
    psi[26,2]  column_93  1
    psi[26,2]  column_94  1
    psi[26,2]  column_95  1
    psi[26,3]  OBJ       7.9392012132821987e-01
    psi[26,3]  column_2  1
    psi[26,3]  column_5  1
    psi[26,3]  column_6  1
    psi[26,3]  column_7  1
    psi[26,3]  column_8  1
    psi[26,3]  column_15  1
    psi[26,3]  column_16  1
    psi[26,3]  column_17  1
    psi[26,3]  column_18  1
    psi[26,3]  column_19  1
    psi[26,3]  column_20  1
    psi[26,3]  column_21  1
    psi[26,3]  column_22  1
    psi[26,3]  column_23  1
    psi[26,3]  column_24  1
    psi[26,3]  column_25  1
    psi[26,3]  column_26  1
    psi[26,3]  column_29  1
    psi[26,3]  column_30  1
    psi[26,3]  column_31  1
    psi[26,3]  column_32  1
    psi[26,3]  column_33  1
    psi[26,3]  column_34  1
    psi[26,3]  column_36  1
    psi[26,3]  column_38  1
    psi[26,3]  column_40  1
    psi[26,3]  column_41  1
    psi[26,3]  column_47  1
    psi[26,3]  column_52  1
    psi[26,3]  column_66  1
    psi[26,3]  column_69  1
    psi[26,3]  column_70  1
    psi[26,3]  column_71  1
    psi[26,3]  column_72  1
    psi[26,3]  column_73  1
    psi[26,3]  column_74  1
    psi[26,3]  column_75  1
    psi[26,3]  column_76  1
    psi[26,3]  column_77  1
    psi[26,3]  column_78  1
    psi[26,3]  column_79  1
    psi[26,3]  column_80  1
    psi[26,3]  column_81  1
    psi[26,3]  column_82  1
    psi[26,3]  column_83  1
    psi[26,3]  column_84  1
    psi[26,3]  column_85  1
    psi[26,3]  column_88  1
    psi[26,3]  column_99  1
    psi[26,3]  column_100  1
    psi[26,3]  column_101  1
    psi[26,4]  OBJ       2.0607987867178013e-01
    psi[26,4]  column_10  1
    psi[26,4]  column_27  1
    psi[26,4]  column_28  1
    psi[26,4]  column_35  1
    psi[26,4]  column_37  1
    psi[26,4]  column_42  1
    psi[26,4]  column_59  1
    psi[26,4]  column_86  1
    psi[26,4]  column_87  1
    psi[26,4]  column_90  1
    psi[26,4]  column_91  1
    psi[26,5]  OBJ       0
    psi[26,6]  OBJ       0
    psi[26,7]  OBJ       0
    psi[26,8]  OBJ       0
    psi[27,0]  OBJ       0
    psi[27,1]  OBJ       0
    psi[27,2]  OBJ       0
    psi[27,3]  column_0  1
    psi[27,3]  column_1  1
    psi[27,3]  column_9  1
    psi[27,3]  column_14  1
    psi[27,3]  column_38  1
    psi[27,3]  column_39  1
    psi[27,3]  column_43  1
    psi[27,3]  column_44  1
    psi[27,3]  column_48  1
    psi[27,3]  column_49  1
    psi[27,3]  column_50  1
    psi[27,3]  column_51  1
    psi[27,3]  column_52  1
    psi[27,3]  column_53  1
    psi[27,3]  column_54  1
    psi[27,3]  column_58  1
    psi[27,3]  column_59  1
    psi[27,3]  column_65  1
    psi[27,3]  column_66  1
    psi[27,3]  column_67  1
    psi[27,3]  column_87  1
    psi[27,3]  column_89  1
    psi[27,3]  column_92  1
    psi[27,3]  column_96  1
    psi[27,3]  column_99  1
    psi[27,3]  column_100  1
    psi[27,3]  column_101  1
    psi[27,4]  column_2  1
    psi[27,4]  column_40  1
    psi[27,4]  column_41  1
    psi[27,4]  column_47  1
    psi[27,5]  column_3  1
    psi[27,5]  column_4  1
    psi[27,5]  column_11  1
    psi[27,5]  column_12  1
    psi[27,5]  column_13  1
    psi[27,5]  column_55  1
    psi[27,5]  column_56  1
    psi[27,5]  column_57  1
    psi[27,5]  column_60  1
    psi[27,5]  column_61  1
    psi[27,5]  column_63  1
    psi[27,5]  column_64  1
    psi[27,5]  column_68  1
    psi[27,6]  OBJ       0.966312576696593
    psi[27,6]  column_5  1
    psi[27,6]  column_6  1
    psi[27,6]  column_7  1
    psi[27,6]  column_8  1
    psi[27,6]  column_15  1
    psi[27,6]  column_17  1
    psi[27,6]  column_18  1
    psi[27,6]  column_19  1
    psi[27,6]  column_20  1
    psi[27,6]  column_21  1
    psi[27,6]  column_22  1
    psi[27,6]  column_23  1
    psi[27,6]  column_24  1
    psi[27,6]  column_25  1
    psi[27,6]  column_26  1
    psi[27,6]  column_27  1
    psi[27,6]  column_28  1
    psi[27,6]  column_29  1
    psi[27,6]  column_31  1
    psi[27,6]  column_32  1
    psi[27,6]  column_33  1
    psi[27,6]  column_34  1
    psi[27,6]  column_36  1
    psi[27,6]  column_37  1
    psi[27,6]  column_70  1
    psi[27,6]  column_71  1
    psi[27,6]  column_72  1
    psi[27,6]  column_73  1
    psi[27,6]  column_74  1
    psi[27,6]  column_75  1
    psi[27,6]  column_76  1
    psi[27,6]  column_77  1
    psi[27,6]  column_78  1
    psi[27,6]  column_79  1
    psi[27,6]  column_80  1
    psi[27,6]  column_81  1
    psi[27,6]  column_82  1
    psi[27,6]  column_83  1
    psi[27,6]  column_84  1
    psi[27,6]  column_85  1
    psi[27,7]  OBJ       3.3687423303407016e-02
    psi[27,7]  column_10  1
    psi[27,7]  column_16  1
    psi[27,7]  column_30  1
    psi[27,7]  column_35  1
    psi[27,7]  column_42  1
    psi[27,7]  column_45  1
    psi[27,7]  column_46  1
    psi[27,7]  column_62  1
    psi[27,7]  column_69  1
    psi[27,7]  column_86  1
    psi[27,7]  column_88  1
    psi[27,7]  column_90  1
    psi[27,7]  column_91  1
    psi[27,7]  column_93  1
    psi[27,7]  column_94  1
    psi[27,7]  column_95  1
    psi[27,7]  column_97  1
    psi[27,7]  column_98  1
    psi[27,8]  OBJ       0
    psi[27,9]  OBJ       0
    psi[27,10]  OBJ       0
    psi[27,11]  OBJ       0
    psi[27,12]  OBJ       0
    psi[27,13]  OBJ       0
    psi[27,14]  OBJ       0
    psi[27,15]  OBJ       0
    psi[28,0]  OBJ       0
    psi[28,1]  OBJ       0
    psi[28,2]  OBJ       0
    psi[28,3]  OBJ       0
    psi[28,4]  column_0  1
    psi[28,4]  column_1  1
    psi[28,4]  column_48  1
    psi[28,4]  column_49  1
    psi[28,4]  column_50  1
    psi[28,4]  column_51  1
    psi[28,4]  column_53  1
    psi[28,4]  column_54  1
    psi[28,4]  column_58  1
    psi[28,4]  column_59  1
    psi[28,4]  column_86  1
    psi[28,4]  column_87  1
    psi[28,5]  column_9  1
    psi[28,5]  column_14  1
    psi[28,5]  column_39  1
    psi[28,5]  column_43  1
    psi[28,5]  column_67  1
    psi[28,6]  OBJ       5.5217861525519663e-01
    psi[28,6]  column_3  1
    psi[28,6]  column_4  1
    psi[28,6]  column_7  1
    psi[28,6]  column_11  1
    psi[28,6]  column_12  1
    psi[28,6]  column_13  1
    psi[28,6]  column_19  1
    psi[28,6]  column_25  1
    psi[28,6]  column_26  1
    psi[28,6]  column_27  1
    psi[28,6]  column_29  1
    psi[28,6]  column_31  1
    psi[28,6]  column_32  1
    psi[28,6]  column_33  1
    psi[28,6]  column_34  1
    psi[28,6]  column_36  1
    psi[28,6]  column_38  1
    psi[28,6]  column_40  1
    psi[28,6]  column_41  1
    psi[28,6]  column_47  1
    psi[28,6]  column_52  1
    psi[28,6]  column_55  1
    psi[28,6]  column_56  1
    psi[28,6]  column_57  1
    psi[28,6]  column_60  1
    psi[28,6]  column_61  1
    psi[28,6]  column_64  1
    psi[28,6]  column_68  1
    psi[28,6]  column_74  1
    psi[28,6]  column_75  1
    psi[28,6]  column_76  1
    psi[28,6]  column_77  1
    psi[28,6]  column_78  1
    psi[28,6]  column_79  1
    psi[28,6]  column_81  1
    psi[28,6]  column_83  1
    psi[28,6]  column_84  1
    psi[28,6]  column_85  1
    psi[28,6]  column_97  1
    psi[28,7]  column_65  1
    psi[28,7]  column_89  1
    psi[28,7]  column_91  1
    psi[28,7]  column_92  1
    psi[28,7]  column_96  1
    psi[28,7]  column_98  1
    psi[28,8]  OBJ       4.4782138474480337e-01
    psi[28,8]  column_2  1
    psi[28,8]  column_5  1
    psi[28,8]  column_6  1
    psi[28,8]  column_8  1
    psi[28,8]  column_10  1
    psi[28,8]  column_15  1
    psi[28,8]  column_16  1
    psi[28,8]  column_17  1
    psi[28,8]  column_18  1
    psi[28,8]  column_20  1
    psi[28,8]  column_21  1
    psi[28,8]  column_22  1
    psi[28,8]  column_23  1
    psi[28,8]  column_24  1
    psi[28,8]  column_28  1
    psi[28,8]  column_30  1
    psi[28,8]  column_35  1
    psi[28,8]  column_37  1
    psi[28,8]  column_42  1
    psi[28,8]  column_44  1
    psi[28,8]  column_45  1
    psi[28,8]  column_46  1
    psi[28,8]  column_62  1
    psi[28,8]  column_63  1
    psi[28,8]  column_66  1
    psi[28,8]  column_69  1
    psi[28,8]  column_70  1
    psi[28,8]  column_71  1
    psi[28,8]  column_72  1
    psi[28,8]  column_73  1
    psi[28,8]  column_80  1
    psi[28,8]  column_82  1
    psi[28,8]  column_88  1
    psi[28,8]  column_90  1
    psi[28,8]  column_93  1
    psi[28,8]  column_94  1
    psi[28,8]  column_95  1
    psi[28,8]  column_99  1
    psi[28,8]  column_100  1
    psi[28,8]  column_101  1
    psi[28,9]  OBJ       0
    psi[28,10]  OBJ       0
    psi[28,11]  OBJ       0
    psi[28,12]  OBJ       0
    psi[28,13]  OBJ       0
    psi[28,14]  OBJ       0
    psi[28,15]  OBJ       0
    psi[28,16]  OBJ       0
    psi[28,17]  OBJ       0
    psi[28,18]  OBJ       0
    psi[28,19]  OBJ       0
    psi[29,0]  OBJ       0
    psi[29,1]  OBJ       0
    psi[29,2]  OBJ       0
    psi[29,3]  OBJ       0
    psi[29,4]  column_0  1
    psi[29,4]  column_2  1
    psi[29,4]  column_38  1
    psi[29,4]  column_40  1
    psi[29,4]  column_41  1
    psi[29,4]  column_48  1
    psi[29,4]  column_49  1
    psi[29,4]  column_51  1
    psi[29,4]  column_52  1
    psi[29,4]  column_58  1
    psi[29,4]  column_66  1
    psi[29,4]  column_99  1
    psi[29,4]  column_101  1
    psi[29,5]  column_9  1
    psi[29,5]  column_14  1
    psi[29,5]  column_39  1
    psi[29,5]  column_43  1
    psi[29,5]  column_53  1
    psi[29,5]  column_54  1
    psi[29,5]  column_55  1
    psi[29,5]  column_56  1
    psi[29,5]  column_57  1
    psi[29,5]  column_67  1
    psi[29,6]  OBJ       5.5217861525519663e-01
    psi[29,6]  column_6  1
    psi[29,6]  column_7  1
    psi[29,6]  column_8  1
    psi[29,6]  column_11  1
    psi[29,6]  column_12  1
    psi[29,6]  column_13  1
    psi[29,6]  column_18  1
    psi[29,6]  column_19  1
    psi[29,6]  column_24  1
    psi[29,6]  column_25  1
    psi[29,6]  column_26  1
    psi[29,6]  column_27  1
    psi[29,6]  column_29  1
    psi[29,6]  column_31  1
    psi[29,6]  column_32  1
    psi[29,6]  column_33  1
    psi[29,6]  column_34  1
    psi[29,6]  column_35  1
    psi[29,6]  column_36  1
    psi[29,6]  column_68  1
    psi[29,6]  column_74  1
    psi[29,6]  column_76  1
    psi[29,6]  column_77  1
    psi[29,6]  column_78  1
    psi[29,6]  column_79  1
    psi[29,6]  column_80  1
    psi[29,6]  column_81  1
    psi[29,6]  column_82  1
    psi[29,6]  column_83  1
    psi[29,6]  column_84  1
    psi[29,6]  column_85  1
    psi[29,7]  OBJ       0
    psi[29,8]  OBJ       4.4782138474480337e-01
    psi[29,8]  column_1  1
    psi[29,8]  column_3  1
    psi[29,8]  column_4  1
    psi[29,8]  column_5  1
    psi[29,8]  column_10  1
    psi[29,8]  column_15  1
    psi[29,8]  column_16  1
    psi[29,8]  column_17  1
    psi[29,8]  column_20  1
    psi[29,8]  column_21  1
    psi[29,8]  column_22  1
    psi[29,8]  column_23  1
    psi[29,8]  column_28  1
    psi[29,8]  column_30  1
    psi[29,8]  column_37  1
    psi[29,8]  column_42  1
    psi[29,8]  column_44  1
    psi[29,8]  column_45  1
    psi[29,8]  column_46  1
    psi[29,8]  column_47  1
    psi[29,8]  column_50  1
    psi[29,8]  column_59  1
    psi[29,8]  column_60  1
    psi[29,8]  column_61  1
    psi[29,8]  column_62  1
    psi[29,8]  column_63  1
    psi[29,8]  column_64  1
    psi[29,8]  column_65  1
    psi[29,8]  column_69  1
    psi[29,8]  column_70  1
    psi[29,8]  column_71  1
    psi[29,8]  column_72  1
    psi[29,8]  column_73  1
    psi[29,8]  column_75  1
    psi[29,8]  column_86  1
    psi[29,8]  column_87  1
    psi[29,8]  column_88  1
    psi[29,8]  column_89  1
    psi[29,8]  column_90  1
    psi[29,8]  column_91  1
    psi[29,8]  column_92  1
    psi[29,8]  column_93  1
    psi[29,8]  column_94  1
    psi[29,8]  column_95  1
    psi[29,8]  column_96  1
    psi[29,8]  column_97  1
    psi[29,8]  column_98  1
    psi[29,8]  column_100  1
    psi[29,9]  OBJ       0
    psi[29,10]  OBJ       0
    psi[29,11]  OBJ       0
    psi[29,12]  OBJ       0
    psi[29,13]  OBJ       0
    psi[29,14]  OBJ       0
    psi[29,15]  OBJ       0
    psi[30,0]  OBJ       0
    psi[30,1]  OBJ       0
    psi[30,2]  column_0  1
    psi[30,2]  column_1  1
    psi[30,2]  column_3  1
    psi[30,2]  column_4  1
    psi[30,2]  column_11  1
    psi[30,2]  column_12  1
    psi[30,2]  column_13  1
    psi[30,2]  column_38  1
    psi[30,2]  column_39  1
    psi[30,2]  column_42  1
    psi[30,2]  column_43  1
    psi[30,2]  column_44  1
    psi[30,2]  column_45  1
    psi[30,2]  column_46  1
    psi[30,2]  column_48  1
    psi[30,2]  column_49  1
    psi[30,2]  column_50  1
    psi[30,2]  column_51  1
    psi[30,2]  column_52  1
    psi[30,2]  column_53  1
    psi[30,2]  column_54  1
    psi[30,2]  column_55  1
    psi[30,2]  column_56  1
    psi[30,2]  column_57  1
    psi[30,2]  column_58  1
    psi[30,2]  column_59  1
    psi[30,2]  column_61  1
    psi[30,2]  column_62  1
    psi[30,2]  column_63  1
    psi[30,2]  column_65  1
    psi[30,2]  column_66  1
    psi[30,2]  column_68  1
    psi[30,2]  column_87  1
    psi[30,2]  column_96  1
    psi[30,2]  column_97  1
    psi[30,2]  column_98  1
    psi[30,2]  column_99  1
    psi[30,2]  column_100  1
    psi[30,2]  column_101  1
    psi[30,3]  OBJ       7.9392012132821987e-01
    psi[30,3]  column_2  1
    psi[30,3]  column_5  1
    psi[30,3]  column_6  1
    psi[30,3]  column_7  1
    psi[30,3]  column_8  1
    psi[30,3]  column_9  1
    psi[30,3]  column_14  1
    psi[30,3]  column_15  1
    psi[30,3]  column_18  1
    psi[30,3]  column_19  1
    psi[30,3]  column_21  1
    psi[30,3]  column_23  1
    psi[30,3]  column_24  1
    psi[30,3]  column_25  1
    psi[30,3]  column_26  1
    psi[30,3]  column_28  1
    psi[30,3]  column_29  1
    psi[30,3]  column_31  1
    psi[30,3]  column_32  1
    psi[30,3]  column_33  1
    psi[30,3]  column_34  1
    psi[30,3]  column_35  1
    psi[30,3]  column_36  1
    psi[30,3]  column_37  1
    psi[30,3]  column_40  1
    psi[30,3]  column_41  1
    psi[30,3]  column_47  1
    psi[30,3]  column_67  1
    psi[30,3]  column_71  1
    psi[30,3]  column_73  1
    psi[30,3]  column_74  1
    psi[30,3]  column_75  1
    psi[30,3]  column_76  1
    psi[30,3]  column_77  1
    psi[30,3]  column_78  1
    psi[30,3]  column_79  1
    psi[30,3]  column_80  1
    psi[30,3]  column_81  1
    psi[30,3]  column_82  1
    psi[30,3]  column_83  1
    psi[30,3]  column_84  1
    psi[30,3]  column_85  1
    psi[30,3]  column_89  1
    psi[30,3]  column_94  1
    psi[30,4]  OBJ       2.0607987867178013e-01
    psi[30,4]  column_10  1
    psi[30,4]  column_16  1
    psi[30,4]  column_17  1
    psi[30,4]  column_20  1
    psi[30,4]  column_22  1
    psi[30,4]  column_27  1
    psi[30,4]  column_30  1
    psi[30,4]  column_60  1
    psi[30,4]  column_64  1
    psi[30,4]  column_69  1
    psi[30,4]  column_70  1
    psi[30,4]  column_72  1
    psi[30,4]  column_86  1
    psi[30,4]  column_88  1
    psi[30,4]  column_90  1
    psi[30,4]  column_91  1
    psi[30,4]  column_92  1
    psi[30,4]  column_93  1
    psi[30,4]  column_95  1
    psi[30,5]  OBJ       0
    psi[30,6]  OBJ       0
    psi[30,7]  OBJ       0
    psi[30,8]  OBJ       0
    psi[31,0]  OBJ       0
    psi[31,1]  OBJ       0
    psi[31,2]  OBJ       1.9326251533931876e-01
    psi[31,2]  column_0  1
    psi[31,2]  column_1  1
    psi[31,2]  column_2  1
    psi[31,2]  column_3  1
    psi[31,2]  column_4  1
    psi[31,2]  column_9  1
    psi[31,2]  column_11  1
    psi[31,2]  column_12  1
    psi[31,2]  column_13  1
    psi[31,2]  column_14  1
    psi[31,2]  column_28  1
    psi[31,2]  column_37  1
    psi[31,2]  column_38  1
    psi[31,2]  column_39  1
    psi[31,2]  column_40  1
    psi[31,2]  column_42  1
    psi[31,2]  column_43  1
    psi[31,2]  column_44  1
    psi[31,2]  column_46  1
    psi[31,2]  column_48  1
    psi[31,2]  column_49  1
    psi[31,2]  column_50  1
    psi[31,2]  column_52  1
    psi[31,2]  column_53  1
    psi[31,2]  column_55  1
    psi[31,2]  column_56  1
    psi[31,2]  column_57  1
    psi[31,2]  column_61  1
    psi[31,2]  column_65  1
    psi[31,2]  column_67  1
    psi[31,2]  column_84  1
    psi[31,2]  column_85  1
    psi[31,2]  column_89  1
    psi[31,2]  column_97  1
    psi[31,3]  OBJ       0
    psi[31,4]  OBJ       0
    psi[31,5]  OBJ       0
    psi[31,6]  OBJ       0
    psi[31,7]  OBJ       8.0673748466068118e-01
    psi[31,7]  column_5  1
    psi[31,7]  column_6  1
    psi[31,7]  column_7  1
    psi[31,7]  column_8  1
    psi[31,7]  column_10  1
    psi[31,7]  column_15  1
    psi[31,7]  column_16  1
    psi[31,7]  column_17  1
    psi[31,7]  column_18  1
    psi[31,7]  column_19  1
    psi[31,7]  column_20  1
    psi[31,7]  column_21  1
    psi[31,7]  column_22  1
    psi[31,7]  column_23  1
    psi[31,7]  column_24  1
    psi[31,7]  column_25  1
    psi[31,7]  column_26  1
    psi[31,7]  column_27  1
    psi[31,7]  column_29  1
    psi[31,7]  column_30  1
    psi[31,7]  column_31  1
    psi[31,7]  column_32  1
    psi[31,7]  column_33  1
    psi[31,7]  column_34  1
    psi[31,7]  column_35  1
    psi[31,7]  column_36  1
    psi[31,7]  column_41  1
    psi[31,7]  column_45  1
    psi[31,7]  column_47  1
    psi[31,7]  column_51  1
    psi[31,7]  column_54  1
    psi[31,7]  column_58  1
    psi[31,7]  column_59  1
    psi[31,7]  column_60  1
    psi[31,7]  column_62  1
    psi[31,7]  column_63  1
    psi[31,7]  column_64  1
    psi[31,7]  column_66  1
    psi[31,7]  column_68  1
    psi[31,7]  column_69  1
    psi[31,7]  column_70  1
    psi[31,7]  column_71  1
    psi[31,7]  column_72  1
    psi[31,7]  column_73  1
    psi[31,7]  column_74  1
    psi[31,7]  column_75  1
    psi[31,7]  column_76  1
    psi[31,7]  column_77  1
    psi[31,7]  column_78  1
    psi[31,7]  column_79  1
    psi[31,7]  column_80  1
    psi[31,7]  column_81  1
    psi[31,7]  column_82  1
    psi[31,7]  column_83  1
    psi[31,7]  column_86  1
    psi[31,7]  column_87  1
    psi[31,7]  column_88  1
    psi[31,7]  column_90  1
    psi[31,7]  column_91  1
    psi[31,7]  column_92  1
    psi[31,7]  column_93  1
    psi[31,7]  column_94  1
    psi[31,7]  column_95  1
    psi[31,7]  column_96  1
    psi[31,7]  column_98  1
    psi[31,7]  column_99  1
    psi[31,7]  column_100  1
    psi[31,7]  column_101  1
    psi[31,8]  OBJ       0
    psi[31,9]  OBJ       0
    psi[31,10]  OBJ       0
    psi[31,11]  OBJ       0
    psi[31,12]  OBJ       0
    psi[32,0]  column_53  1
    psi[32,0]  column_54  1
    psi[32,0]  column_65  1
    psi[32,0]  column_92  1
    psi[32,0]  column_96  1
    psi[32,0]  column_98  1
    psi[32,1]  OBJ       0
    psi[32,2]  column_2  1
    psi[32,2]  column_3  1
    psi[32,2]  column_4  1
    psi[32,2]  column_9  1
    psi[32,2]  column_10  1
    psi[32,2]  column_11  1
    psi[32,2]  column_12  1
    psi[32,2]  column_13  1
    psi[32,2]  column_14  1
    psi[32,2]  column_40  1
    psi[32,2]  column_41  1
    psi[32,2]  column_47  1
    psi[32,2]  column_67  1
    psi[32,2]  column_68  1
    psi[32,2]  column_89  1
    psi[32,2]  column_90  1
    psi[32,2]  column_94  1
    psi[32,2]  column_95  1
    psi[32,3]  OBJ       4.9620007583013725e-01
    psi[32,3]  column_6  1
    psi[32,3]  column_8  1
    psi[32,3]  column_18  1
    psi[32,3]  column_19  1
    psi[32,3]  column_24  1
    psi[32,3]  column_25  1
    psi[32,3]  column_26  1
    psi[32,3]  column_28  1
    psi[32,3]  column_34  1
    psi[32,3]  column_35  1
    psi[32,3]  column_36  1
    psi[32,3]  column_37  1
    psi[32,3]  column_38  1
    psi[32,3]  column_52  1
    psi[32,3]  column_55  1
    psi[32,3]  column_56  1
    psi[32,3]  column_57  1
    psi[32,3]  column_61  1
    psi[32,3]  column_66  1
    psi[32,3]  column_75  1
    psi[32,3]  column_76  1
    psi[32,3]  column_77  1
    psi[32,3]  column_80  1
    psi[32,3]  column_81  1
    psi[32,3]  column_82  1
    psi[32,3]  column_83  1
    psi[32,3]  column_84  1
    psi[32,3]  column_85  1
    psi[32,4]  column_0  1
    psi[32,4]  column_1  1
    psi[32,4]  column_39  1
    psi[32,4]  column_43  1
    psi[32,4]  column_44  1
    psi[32,4]  column_48  1
    psi[32,4]  column_49  1
    psi[32,4]  column_50  1
    psi[32,4]  column_51  1
    psi[32,4]  column_58  1
    psi[32,4]  column_59  1
    psi[32,4]  column_86  1
    psi[32,4]  column_87  1
    psi[32,5]  OBJ       5.0379992416986275e-01
    psi[32,5]  column_5  1
    psi[32,5]  column_7  1
    psi[32,5]  column_15  1
    psi[32,5]  column_16  1
    psi[32,5]  column_17  1
    psi[32,5]  column_20  1
    psi[32,5]  column_21  1
    psi[32,5]  column_22  1
    psi[32,5]  column_23  1
    psi[32,5]  column_27  1
    psi[32,5]  column_29  1
    psi[32,5]  column_30  1
    psi[32,5]  column_31  1
    psi[32,5]  column_32  1
    psi[32,5]  column_33  1
    psi[32,5]  column_42  1
    psi[32,5]  column_45  1
    psi[32,5]  column_46  1
    psi[32,5]  column_60  1
    psi[32,5]  column_62  1
    psi[32,5]  column_63  1
    psi[32,5]  column_64  1
    psi[32,5]  column_69  1
    psi[32,5]  column_70  1
    psi[32,5]  column_71  1
    psi[32,5]  column_72  1
    psi[32,5]  column_73  1
    psi[32,5]  column_74  1
    psi[32,5]  column_78  1
    psi[32,5]  column_79  1
    psi[32,5]  column_88  1
    psi[32,5]  column_91  1
    psi[32,5]  column_93  1
    psi[32,5]  column_97  1
    psi[32,5]  column_99  1
    psi[32,5]  column_100  1
    psi[32,5]  column_101  1
    psi[32,6]  OBJ       0
    psi[32,7]  OBJ       0
    psi[32,8]  OBJ       0
    psi[32,9]  OBJ       0
    psi[32,10]  OBJ       0
    psi[32,11]  OBJ       0
    psi[32,12]  OBJ       0
    psi[33,0]  OBJ       0
    psi[33,1]  column_1  1
    psi[33,1]  column_9  1
    psi[33,1]  column_50  1
    psi[33,1]  column_53  1
    psi[33,1]  column_54  1
    psi[33,1]  column_91  1
    psi[33,1]  column_98  1
    psi[33,2]  OBJ       0
    psi[33,3]  column_2  1
    psi[33,3]  column_38  1
    psi[33,3]  column_40  1
    psi[33,3]  column_41  1
    psi[33,3]  column_47  1
    psi[33,3]  column_52  1
    psi[33,3]  column_66  1
    psi[33,3]  column_90  1
    psi[33,4]  OBJ       0
    psi[33,5]  column_11  1
    psi[33,5]  column_12  1
    psi[33,5]  column_13  1
    psi[33,5]  column_55  1
    psi[33,5]  column_56  1
    psi[33,5]  column_57  1
    psi[33,5]  column_60  1
    psi[33,5]  column_61  1
    psi[33,5]  column_63  1
    psi[33,5]  column_64  1
    psi[33,5]  column_68  1
    psi[33,6]  OBJ       9.6631257669659376e-01
    psi[33,6]  column_5  1
    psi[33,6]  column_7  1
    psi[33,6]  column_8  1
    psi[33,6]  column_14  1
    psi[33,6]  column_15  1
    psi[33,6]  column_16  1
    psi[33,6]  column_17  1
    psi[33,6]  column_20  1
    psi[33,6]  column_21  1
    psi[33,6]  column_22  1
    psi[33,6]  column_23  1
    psi[33,6]  column_25  1
    psi[33,6]  column_26  1
    psi[33,6]  column_27  1
    psi[33,6]  column_28  1
    psi[33,6]  column_29  1
    psi[33,6]  column_30  1
    psi[33,6]  column_31  1
    psi[33,6]  column_32  1
    psi[33,6]  column_33  1
    psi[33,6]  column_34  1
    psi[33,6]  column_35  1
    psi[33,6]  column_36  1
    psi[33,6]  column_37  1
    psi[33,6]  column_67  1
    psi[33,6]  column_69  1
    psi[33,6]  column_70  1
    psi[33,6]  column_71  1
    psi[33,6]  column_72  1
    psi[33,6]  column_73  1
    psi[33,6]  column_74  1
    psi[33,6]  column_75  1
    psi[33,6]  column_77  1
    psi[33,6]  column_78  1
    psi[33,6]  column_79  1
    psi[33,6]  column_81  1
    psi[33,6]  column_82  1
    psi[33,6]  column_83  1
    psi[33,6]  column_84  1
    psi[33,6]  column_85  1
    psi[33,6]  column_89  1
    psi[33,7]  OBJ       3.3687423303406239e-02
    psi[33,7]  column_0  1
    psi[33,7]  column_3  1
    psi[33,7]  column_4  1
    psi[33,7]  column_6  1
    psi[33,7]  column_10  1
    psi[33,7]  column_18  1
    psi[33,7]  column_19  1
    psi[33,7]  column_24  1
    psi[33,7]  column_39  1
    psi[33,7]  column_42  1
    psi[33,7]  column_43  1
    psi[33,7]  column_44  1
    psi[33,7]  column_45  1
    psi[33,7]  column_46  1
    psi[33,7]  column_48  1
    psi[33,7]  column_49  1
    psi[33,7]  column_51  1
    psi[33,7]  column_58  1
    psi[33,7]  column_59  1
    psi[33,7]  column_62  1
    psi[33,7]  column_65  1
    psi[33,7]  column_76  1
    psi[33,7]  column_80  1
    psi[33,7]  column_86  1
    psi[33,7]  column_87  1
    psi[33,7]  column_88  1
    psi[33,7]  column_92  1
    psi[33,7]  column_93  1
    psi[33,7]  column_94  1
    psi[33,7]  column_95  1
    psi[33,7]  column_96  1
    psi[33,7]  column_97  1
    psi[33,7]  column_99  1
    psi[33,7]  column_100  1
    psi[33,7]  column_101  1
    psi[33,8]  OBJ       0
    psi[33,9]  OBJ       0
    psi[33,10]  OBJ       0
    psi[33,11]  OBJ       0
    psi[33,12]  OBJ       0
    psi[33,13]  OBJ       0
    psi[33,14]  OBJ       0
    psi[33,15]  OBJ       0
    psi[33,16]  OBJ       0
    psi[34,0]  OBJ       0
    psi[34,1]  OBJ       2.4810003791506871e-01
    psi[34,1]  column_0  1
    psi[34,1]  column_1  1
    psi[34,1]  column_3  1
    psi[34,1]  column_4  1
    psi[34,1]  column_9  1
    psi[34,1]  column_11  1
    psi[34,1]  column_14  1
    psi[34,1]  column_26  1
    psi[34,1]  column_27  1
    psi[34,1]  column_34  1
    psi[34,1]  column_35  1
    psi[34,1]  column_36  1
    psi[34,1]  column_37  1
    psi[34,1]  column_48  1
    psi[34,1]  column_50  1
    psi[34,1]  column_53  1
    psi[34,1]  column_54  1
    psi[34,1]  column_55  1
    psi[34,1]  column_56  1
    psi[34,1]  column_57  1
    psi[34,1]  column_61  1
    psi[34,1]  column_62  1
    psi[34,1]  column_63  1
    psi[34,1]  column_65  1
    psi[34,1]  column_67  1
    psi[34,1]  column_77  1
    psi[34,1]  column_84  1
    psi[34,1]  column_85  1
    psi[34,1]  column_89  1
    psi[34,1]  column_92  1
    psi[34,1]  column_93  1
    psi[34,1]  column_94  1
    psi[34,1]  column_95  1
    psi[34,1]  column_96  1
    psi[34,1]  column_98  1
    psi[34,2]  OBJ       0
    psi[34,3]  column_2  1
    psi[34,3]  column_12  1
    psi[34,3]  column_13  1
    psi[34,3]  column_38  1
    psi[34,3]  column_39  1
    psi[34,3]  column_40  1
    psi[34,3]  column_41  1
    psi[34,3]  column_43  1
    psi[34,3]  column_44  1
    psi[34,3]  column_45  1
    psi[34,3]  column_47  1
    psi[34,3]  column_52  1
    psi[34,3]  column_60  1
    psi[34,3]  column_64  1
    psi[34,3]  column_66  1
    psi[34,3]  column_68  1
    psi[34,3]  column_99  1
    psi[34,3]  column_100  1
    psi[34,3]  column_101  1
    psi[34,4]  OBJ       0
    psi[34,5]  OBJ       7.5189996208493137e-01
    psi[34,5]  column_5  1
    psi[34,5]  column_6  1
    psi[34,5]  column_7  1
    psi[34,5]  column_8  1
    psi[34,5]  column_10  1
    psi[34,5]  column_15  1
    psi[34,5]  column_16  1
    psi[34,5]  column_17  1
    psi[34,5]  column_18  1
    psi[34,5]  column_19  1
    psi[34,5]  column_20  1
    psi[34,5]  column_21  1
    psi[34,5]  column_22  1
    psi[34,5]  column_23  1
    psi[34,5]  column_24  1
    psi[34,5]  column_25  1
    psi[34,5]  column_28  1
    psi[34,5]  column_29  1
    psi[34,5]  column_30  1
    psi[34,5]  column_31  1
    psi[34,5]  column_32  1
    psi[34,5]  column_33  1
    psi[34,5]  column_42  1
    psi[34,5]  column_46  1
    psi[34,5]  column_49  1
    psi[34,5]  column_51  1
    psi[34,5]  column_58  1
    psi[34,5]  column_59  1
    psi[34,5]  column_69  1
    psi[34,5]  column_70  1
    psi[34,5]  column_71  1
    psi[34,5]  column_72  1
    psi[34,5]  column_73  1
    psi[34,5]  column_74  1
    psi[34,5]  column_75  1
    psi[34,5]  column_76  1
    psi[34,5]  column_78  1
    psi[34,5]  column_79  1
    psi[34,5]  column_80  1
    psi[34,5]  column_81  1
    psi[34,5]  column_82  1
    psi[34,5]  column_83  1
    psi[34,5]  column_86  1
    psi[34,5]  column_87  1
    psi[34,5]  column_88  1
    psi[34,5]  column_90  1
    psi[34,5]  column_91  1
    psi[34,5]  column_97  1
    psi[34,6]  OBJ       0
    psi[34,7]  OBJ       0
    psi[34,8]  OBJ       0
    psi[34,9]  OBJ       0
    psi[34,10]  OBJ       0
    psi[34,11]  OBJ       0
    psi[35,0]  OBJ       0
    psi[35,1]  OBJ       0
    psi[35,2]  OBJ       0
    psi[35,3]  OBJ       0
    psi[35,4]  OBJ       2.7608930762759831e-01
    psi[35,4]  column_3  1
    psi[35,4]  column_4  1
    psi[35,4]  column_11  1
    psi[35,4]  column_12  1
    psi[35,4]  column_13  1
    psi[35,4]  column_27  1
    psi[35,4]  column_28  1
    psi[35,4]  column_35  1
    psi[35,4]  column_38  1
    psi[35,4]  column_52  1
    psi[35,4]  column_68  1
    psi[35,4]  column_84  1
    psi[35,4]  column_85  1
    psi[35,4]  column_97  1
    psi[35,5]  column_0  1
    psi[35,5]  column_2  1
    psi[35,5]  column_40  1
    psi[35,5]  column_41  1
    psi[35,5]  column_47  1
    psi[35,5]  column_48  1
    psi[35,5]  column_49  1
    psi[35,5]  column_51  1
    psi[35,5]  column_53  1
    psi[35,5]  column_54  1
    psi[35,5]  column_55  1
    psi[35,5]  column_56  1
    psi[35,5]  column_57  1
    psi[35,5]  column_60  1
    psi[35,5]  column_61  1
    psi[35,5]  column_62  1
    psi[35,5]  column_63  1
    psi[35,5]  column_64  1
    psi[35,5]  column_65  1
    psi[35,5]  column_90  1
    psi[35,6]  column_14  1
    psi[35,6]  column_39  1
    psi[35,6]  column_43  1
    psi[35,6]  column_67  1
    psi[35,7]  column_10  1
    psi[35,7]  column_91  1
    psi[35,7]  column_92  1
    psi[35,7]  column_96  1
    psi[35,7]  column_98  1
    psi[35,8]  OBJ       7.2391069237240169e-01
    psi[35,8]  column_1  1
    psi[35,8]  column_5  1
    psi[35,8]  column_6  1
    psi[35,8]  column_7  1
    psi[35,8]  column_8  1
    psi[35,8]  column_9  1
    psi[35,8]  column_15  1
    psi[35,8]  column_16  1
    psi[35,8]  column_17  1
    psi[35,8]  column_18  1
    psi[35,8]  column_19  1
    psi[35,8]  column_20  1
    psi[35,8]  column_21  1
    psi[35,8]  column_22  1
    psi[35,8]  column_23  1
    psi[35,8]  column_24  1
    psi[35,8]  column_25  1
    psi[35,8]  column_26  1
    psi[35,8]  column_29  1
    psi[35,8]  column_30  1
    psi[35,8]  column_31  1
    psi[35,8]  column_32  1
    psi[35,8]  column_33  1
    psi[35,8]  column_34  1
    psi[35,8]  column_36  1
    psi[35,8]  column_37  1
    psi[35,8]  column_42  1
    psi[35,8]  column_44  1
    psi[35,8]  column_45  1
    psi[35,8]  column_46  1
    psi[35,8]  column_50  1
    psi[35,8]  column_58  1
    psi[35,8]  column_59  1
    psi[35,8]  column_66  1
    psi[35,8]  column_69  1
    psi[35,8]  column_70  1
    psi[35,8]  column_71  1
    psi[35,8]  column_72  1
    psi[35,8]  column_73  1
    psi[35,8]  column_74  1
    psi[35,8]  column_75  1
    psi[35,8]  column_76  1
    psi[35,8]  column_77  1
    psi[35,8]  column_78  1
    psi[35,8]  column_79  1
    psi[35,8]  column_80  1
    psi[35,8]  column_81  1
    psi[35,8]  column_82  1
    psi[35,8]  column_83  1
    psi[35,8]  column_86  1
    psi[35,8]  column_87  1
    psi[35,8]  column_88  1
    psi[35,8]  column_89  1
    psi[35,8]  column_93  1
    psi[35,8]  column_94  1
    psi[35,8]  column_95  1
    psi[35,8]  column_99  1
    psi[35,8]  column_100  1
    psi[35,8]  column_101  1
    psi[35,9]  OBJ       0
    psi[35,10]  OBJ       0
    psi[35,11]  OBJ       0
    psi[35,12]  OBJ       0
    psi[35,13]  OBJ       0
    psi[35,14]  OBJ       0
    psi[35,15]  OBJ       0
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
    a         column_13  1
    a         column_14  1
    a         column_15  1
    a         column_16  1
    a         column_17  1
    a         column_18  1
    a         column_19  1
    a         column_20  1
    a         column_21  1
    a         column_22  1
    a         column_23  1
    a         column_24  1
    a         column_25  1
    a         column_26  1
    a         column_27  1
    a         column_28  1
    a         column_29  1
    a         column_30  1
    a         column_31  1
    a         column_32  1
    a         column_33  1
    a         column_34  1
    a         column_35  1
    a         column_36  1
    a         column_37  1
    a         column_38  1
    a         column_39  1
    a         column_40  1
    a         column_41  1
    a         column_42  1
    a         column_43  1
    a         column_44  1
    a         column_45  1
    a         column_46  1
    a         column_47  1
    a         column_48  1
    a         column_49  1
    a         column_50  1
    a         column_51  1
    a         column_52  1
    a         column_53  1
    a         column_54  1
    a         column_55  1
    a         column_56  1
    a         column_57  1
    a         column_58  1
    a         column_59  1
    a         column_60  1
    a         column_61  1
    a         column_62  1
    a         column_63  1
    a         column_64  1
    a         column_65  1
    a         column_66  1
    a         column_67  1
    a         column_68  1
    a         column_69  1
    a         column_70  1
    a         column_71  1
    a         column_72  1
    a         column_73  1
    a         column_74  1
    a         column_75  1
    a         column_76  1
    a         column_77  1
    a         column_78  1
    a         column_79  1
    a         column_80  1
    a         column_81  1
    a         column_82  1
    a         column_83  1
    a         column_84  1
    a         column_85  1
    a         column_86  1
    a         column_87  1
    a         column_88  1
    a         column_89  1
    a         column_90  1
    a         column_91  1
    a         column_92  1
    a         column_93  1
    a         column_94  1
    a         column_95  1
    a         column_96  1
    a         column_97  1
    a         column_98  1
    a         column_99  1
    a         column_100  1
    a         column_101  1
RHS
    RHS1      column_0  2.5053398357923334e-01
    RHS1      column_1  3.2139476961394775e-01
    RHS1      column_2  2.2556215668313920e-01
    RHS1      column_3  3.1910382732816223e-01
    RHS1      column_4  3.2177982991694248e-01
    RHS1      column_5  1.1471203989189603e-01
    RHS1      column_6  1.0817628616056066e-01
    RHS1      column_7  1.0373658813938735e-01
    RHS1      column_8  1.0830887764968110e-01
    RHS1      column_9  3.0437446464261925e-01
    RHS1      column_10  1.2367670612133289e-01
    RHS1      column_11  2.5252131825528934e-01
    RHS1      column_12  2.1631708311748435e-01
    RHS1      column_13  2.0219087319658310e-01
    RHS1      column_14  2.4530180392328671e-01
    RHS1      column_15  1.0441190995357885e-01
    RHS1      column_16  1.0175634917495108e-01
    RHS1      column_17  1.0080534010247734e-01
    RHS1      column_18  1.0328138944188921e-01
    RHS1      column_19  9.0827851557651745e-02
    RHS1      column_20  1.0664002593301020e-01
    RHS1      column_21  1.0451850771209932e-01
    RHS1      column_22  9.9817394480096022e-02
    RHS1      column_23  1.0176576903589768e-01
    RHS1      column_24  1.0531948162894825e-01
    RHS1      column_25  1.0850319484199267e-01
    RHS1      column_26  1.1767528162289317e-01
    RHS1      column_27  1.1692335970468176e-01
    RHS1      column_28  1.1800671591672264e-01
    RHS1      column_29  9.7599664145869638e-02
    RHS1      column_30  1.0152812023344036e-01
    RHS1      column_31  8.6446770748729071e-02
    RHS1      column_32  8.4081718397143027e-02
    RHS1      column_33  8.5919395559931250e-02
    RHS1      column_34  1.0866343231860107e-01
    RHS1      column_35  1.1345799634651973e-01
    RHS1      column_36  0.106513215554223
    RHS1      column_37  1.1777795694590021e-01
    RHS1      column_38  1.9025345318891221e-01
    RHS1      column_39  2.3345595091692908e-01
    RHS1      column_40  1.6584553562394302e-01
    RHS1      column_41  1.5571115059044835e-01
    RHS1      column_42  1.2662862577270570e-01
    RHS1      column_43  2.2168744986509153e-01
    RHS1      column_44  1.9443263806900171e-01
    RHS1      column_45  1.4408983032836245e-01
    RHS1      column_46  1.5139761748428857e-01
    RHS1      column_47  0.153659156122113
    RHS1      column_48  2.3154056517775753e-01
    RHS1      column_49  2.1586672042014887e-01
    RHS1      column_50  3.0935194666778126e-01
    RHS1      column_51  2.0181812372973415e-01
    RHS1      column_52  1.8369562853808633e-01
    RHS1      column_53  3.0298039887015327e-01
    RHS1      column_54  2.6897375621411235e-01
    RHS1      column_55  2.9986160988000354e-01
    RHS1      column_56  2.4125049759825909e-01
    RHS1      column_57  2.2164907122811708e-01
    RHS1      column_58  1.8724366034595785e-01
    RHS1      column_59  1.3203383975923622e-01
    RHS1      column_60  1.4792014982246984e-01
    RHS1      column_61  1.8461115254098873e-01
    RHS1      column_62  1.5526115198839979e-01
    RHS1      column_63  1.4232311561204380e-01
    RHS1      column_64  1.2798862221679941e-01
    RHS1      column_65  2.4618157867369225e-01
    RHS1      column_66  1.6616184035303028e-01
    RHS1      column_67  2.3412978389114519e-01
    RHS1      column_68  1.7735126315197211e-01
    RHS1      column_69  1.0382103465519357e-01
    RHS1      column_70  1.0382103465519357e-01
    RHS1      column_71  9.6952945047713082e-02
    RHS1      column_72  1.0288515220620938e-01
    RHS1      column_73  1.0454315130236752e-01
    RHS1      column_74  9.4042867868291691e-02
    RHS1      column_75  9.8405260201852890e-02
    RHS1      column_76  1.0056622744350957e-01
    RHS1      column_77  1.0168306562064837e-01
    RHS1      column_78  9.5248729576373550e-02
    RHS1      column_79  0.0914916380426826
    RHS1      column_80  1.1446388079041142e-01
    RHS1      column_81  1.0700963339835348e-01
    RHS1      column_82  1.0262007825249954e-01
    RHS1      column_83  1.0914756355467582e-01
    RHS1      column_84  1.1716630922808698e-01
    RHS1      column_85  1.1824691756851345e-01
    RHS1      column_86  1.1809890295609413e-01
    RHS1      column_87  1.3431328003954263e-01
    RHS1      column_88  1.1513360739979447e-01
    RHS1      column_89  2.1033813599872403e-01
    RHS1      column_90  1.4150326985020126e-01
    RHS1      column_91  1.2914420485175204e-01
    RHS1      column_92  1.6244657745393404e-01
    RHS1      column_93  1.6281201523057398e-01
    RHS1      column_94  1.6986921529175053e-01
    RHS1      column_95  1.7129998392656226e-01
    RHS1      column_96  2.0018118771672239e-01
    RHS1      column_97  1.6443746383400845e-01
    RHS1      column_98  1.8538281801880130e-01
    RHS1      column_99  1.3590536851683349e-01
    RHS1      column_100  1.5581800535553506e-01
    RHS1      column_101  1.2077657259377304e-01
BOUNDS
 LO BND1      psi[1,0]  -0.05
 UP BND1      psi[1,0]  0.05
 LO BND1      psi[1,1]  -0.05
 UP BND1      psi[1,1]  0.05
 LO BND1      psi[1,2]  -0.05
 UP BND1      psi[1,2]  0.05
 LO BND1      psi[1,3]  -0.05
 UP BND1      psi[1,3]  0.05
 LO BND1      psi[1,4]  -0.05
 UP BND1      psi[1,4]  0.05
 LO BND1      psi[1,5]  -0.05
 UP BND1      psi[1,5]  0.05
 LO BND1      psi[1,6]  -0.05
 UP BND1      psi[1,6]  0.05
 LO BND1      psi[1,7]  -0.05
 UP BND1      psi[1,7]  0.05
 FX BND1      psi[1,8]  0
 LO BND1      psi[1,9]  -0.05
 UP BND1      psi[1,9]  0.05
 LO BND1      psi[1,10]  -0.05
 UP BND1      psi[1,10]  0.05
 LO BND1      psi[1,11]  -0.05
 UP BND1      psi[1,11]  0.05
 LO BND1      psi[1,12]  -0.05
 UP BND1      psi[1,12]  0.05
 LO BND1      psi[1,13]  -0.05
 UP BND1      psi[1,13]  0.05
 LO BND1      psi[1,14]  -0.05
 UP BND1      psi[1,14]  0.05
 LO BND1      psi[1,15]  -0.05
 UP BND1      psi[1,15]  0.05
 LO BND1      psi[1,16]  -0.05
 UP BND1      psi[1,16]  0.05
 LO BND1      psi[1,17]  -0.05
 UP BND1      psi[1,17]  0.05
 LO BND1      psi[1,18]  -0.05
 UP BND1      psi[1,18]  0.05
 LO BND1      psi[1,19]  -0.05
 UP BND1      psi[1,19]  0.05
 LO BND1      psi[2,0]  -0.05
 UP BND1      psi[2,0]  0.05
 LO BND1      psi[2,1]  -0.05
 UP BND1      psi[2,1]  0.05
 LO BND1      psi[2,2]  -0.05
 UP BND1      psi[2,2]  0.05
 LO BND1      psi[2,3]  -0.05
 UP BND1      psi[2,3]  0.05
 LO BND1      psi[2,4]  -0.05
 UP BND1      psi[2,4]  0.05
 LO BND1      psi[2,5]  -0.05
 UP BND1      psi[2,5]  0.05
 FX BND1      psi[2,6]  0
 LO BND1      psi[2,7]  -0.05
 UP BND1      psi[2,7]  0.05
 LO BND1      psi[2,8]  -0.05
 UP BND1      psi[2,8]  0.05
 LO BND1      psi[2,9]  -0.05
 UP BND1      psi[2,9]  0.05
 LO BND1      psi[2,10]  -0.05
 UP BND1      psi[2,10]  0.05
 LO BND1      psi[2,11]  -0.05
 UP BND1      psi[2,11]  0.05
 LO BND1      psi[2,12]  -0.05
 UP BND1      psi[2,12]  0.05
 LO BND1      psi[2,13]  -0.05
 UP BND1      psi[2,13]  0.05
 LO BND1      psi[2,14]  -0.05
 UP BND1      psi[2,14]  0.05
 LO BND1      psi[2,15]  -0.05
 UP BND1      psi[2,15]  0.05
 LO BND1      psi[3,0]  -0.05
 UP BND1      psi[3,0]  0.05
 LO BND1      psi[3,1]  -0.05
 UP BND1      psi[3,1]  0.05
 LO BND1      psi[3,2]  -0.05
 UP BND1      psi[3,2]  0.05
 LO BND1      psi[3,3]  -0.05
 UP BND1      psi[3,3]  0.05
 LO BND1      psi[3,4]  -0.05
 UP BND1      psi[3,4]  0.05
 LO BND1      psi[3,5]  -0.05
 UP BND1      psi[3,5]  0.05
 LO BND1      psi[3,6]  -0.05
 UP BND1      psi[3,6]  0.05
 FX BND1      psi[3,7]  0
 LO BND1      psi[3,8]  -0.05
 UP BND1      psi[3,8]  0.05
 LO BND1      psi[3,9]  -0.05
 UP BND1      psi[3,9]  0.05
 LO BND1      psi[3,10]  -0.05
 UP BND1      psi[3,10]  0.05
 LO BND1      psi[3,11]  -0.05
 UP BND1      psi[3,11]  0.05
 LO BND1      psi[3,12]  -0.05
 UP BND1      psi[3,12]  0.05
 LO BND1      psi[3,13]  -0.05
 UP BND1      psi[3,13]  0.05
 LO BND1      psi[3,14]  -0.05
 UP BND1      psi[3,14]  0.05
 LO BND1      psi[3,15]  -0.05
 UP BND1      psi[3,15]  0.05
 LO BND1      psi[3,16]  -0.05
 UP BND1      psi[3,16]  0.05
 LO BND1      psi[3,17]  -0.05
 UP BND1      psi[3,17]  0.05
 LO BND1      psi[4,0]  -0.05
 UP BND1      psi[4,0]  0.05
 LO BND1      psi[4,1]  -0.05
 UP BND1      psi[4,1]  0.05
 LO BND1      psi[4,2]  -0.05
 UP BND1      psi[4,2]  0.05
 LO BND1      psi[4,3]  -0.05
 UP BND1      psi[4,3]  0.05
 LO BND1      psi[4,4]  -0.05
 UP BND1      psi[4,4]  0.05
 LO BND1      psi[4,5]  -0.05
 UP BND1      psi[4,5]  0.05
 FX BND1      psi[4,6]  0
 LO BND1      psi[4,7]  -0.05
 UP BND1      psi[4,7]  0.05
 LO BND1      psi[4,8]  -0.05
 UP BND1      psi[4,8]  0.05
 LO BND1      psi[4,9]  -0.05
 UP BND1      psi[4,9]  0.05
 LO BND1      psi[4,10]  -0.05
 UP BND1      psi[4,10]  0.05
 LO BND1      psi[4,11]  -0.05
 UP BND1      psi[4,11]  0.05
 LO BND1      psi[4,12]  -0.05
 UP BND1      psi[4,12]  0.05
 LO BND1      psi[4,13]  -0.05
 UP BND1      psi[4,13]  0.05
 LO BND1      psi[4,14]  -0.05
 UP BND1      psi[4,14]  0.05
 LO BND1      psi[4,15]  -0.05
 UP BND1      psi[4,15]  0.05
 LO BND1      psi[5,0]  -0.05
 UP BND1      psi[5,0]  0.05
 LO BND1      psi[5,1]  -0.05
 UP BND1      psi[5,1]  0.05
 LO BND1      psi[5,2]  -0.05
 UP BND1      psi[5,2]  0.05
 LO BND1      psi[5,3]  -0.05
 UP BND1      psi[5,3]  0.05
 LO BND1      psi[5,4]  -0.05
 UP BND1      psi[5,4]  0.05
 LO BND1      psi[5,5]  -0.05
 UP BND1      psi[5,5]  0.05
 LO BND1      psi[5,6]  -0.05
 UP BND1      psi[5,6]  0.05
 LO BND1      psi[5,7]  -0.05
 UP BND1      psi[5,7]  0.05
 FX BND1      psi[5,8]  0
 LO BND1      psi[5,9]  -0.05
 UP BND1      psi[5,9]  0.05
 LO BND1      psi[5,10]  -0.05
 UP BND1      psi[5,10]  0.05
 LO BND1      psi[5,11]  -0.05
 UP BND1      psi[5,11]  0.05
 LO BND1      psi[5,12]  -0.05
 UP BND1      psi[5,12]  0.05
 LO BND1      psi[5,13]  -0.05
 UP BND1      psi[5,13]  0.05
 LO BND1      psi[5,14]  -0.05
 UP BND1      psi[5,14]  0.05
 LO BND1      psi[5,15]  -0.05
 UP BND1      psi[5,15]  0.05
 LO BND1      psi[5,16]  -0.05
 UP BND1      psi[5,16]  0.05
 LO BND1      psi[6,0]  -0.05
 UP BND1      psi[6,0]  0.05
 LO BND1      psi[6,1]  -0.05
 UP BND1      psi[6,1]  0.05
 LO BND1      psi[6,2]  -0.05
 UP BND1      psi[6,2]  0.05
 LO BND1      psi[6,3]  -0.05
 UP BND1      psi[6,3]  0.05
 LO BND1      psi[6,4]  -0.05
 UP BND1      psi[6,4]  0.05
 FX BND1      psi[6,5]  0
 LO BND1      psi[6,6]  -0.05
 UP BND1      psi[6,6]  0.05
 LO BND1      psi[6,7]  -0.05
 UP BND1      psi[6,7]  0.05
 LO BND1      psi[6,8]  -0.05
 UP BND1      psi[6,8]  0.05
 LO BND1      psi[6,9]  -0.05
 UP BND1      psi[6,9]  0.05
 LO BND1      psi[6,10]  -0.05
 UP BND1      psi[6,10]  0.05
 LO BND1      psi[7,0]  -0.05
 UP BND1      psi[7,0]  0.05
 LO BND1      psi[7,1]  -0.05
 UP BND1      psi[7,1]  0.05
 LO BND1      psi[7,2]  -0.05
 UP BND1      psi[7,2]  0.05
 LO BND1      psi[7,3]  -0.05
 UP BND1      psi[7,3]  0.05
 LO BND1      psi[7,4]  -0.05
 UP BND1      psi[7,4]  0.05
 LO BND1      psi[7,5]  -0.05
 UP BND1      psi[7,5]  0.05
 LO BND1      psi[7,6]  -0.05
 UP BND1      psi[7,6]  0.05
 LO BND1      psi[7,7]  -0.05
 UP BND1      psi[7,7]  0.05
 FX BND1      psi[7,8]  0
 LO BND1      psi[7,9]  -0.05
 UP BND1      psi[7,9]  0.05
 LO BND1      psi[7,10]  -0.05
 UP BND1      psi[7,10]  0.05
 LO BND1      psi[7,11]  -0.05
 UP BND1      psi[7,11]  0.05
 LO BND1      psi[7,12]  -0.05
 UP BND1      psi[7,12]  0.05
 LO BND1      psi[7,13]  -0.05
 UP BND1      psi[7,13]  0.05
 LO BND1      psi[7,14]  -0.05
 UP BND1      psi[7,14]  0.05
 LO BND1      psi[7,15]  -0.05
 UP BND1      psi[7,15]  0.05
 LO BND1      psi[7,16]  -0.05
 UP BND1      psi[7,16]  0.05
 LO BND1      psi[7,17]  -0.05
 UP BND1      psi[7,17]  0.05
 LO BND1      psi[8,0]  -0.05
 UP BND1      psi[8,0]  0.05
 LO BND1      psi[8,1]  -0.05
 UP BND1      psi[8,1]  0.05
 LO BND1      psi[8,2]  -0.05
 UP BND1      psi[8,2]  0.05
 LO BND1      psi[8,3]  -0.05
 UP BND1      psi[8,3]  0.05
 LO BND1      psi[8,4]  -0.05
 UP BND1      psi[8,4]  0.05
 LO BND1      psi[8,5]  -0.05
 UP BND1      psi[8,5]  0.05
 LO BND1      psi[8,6]  -0.05
 UP BND1      psi[8,6]  0.05
 LO BND1      psi[8,7]  -0.05
 UP BND1      psi[8,7]  0.05
 LO BND1      psi[8,8]  -0.05
 UP BND1      psi[8,8]  0.05
 LO BND1      psi[8,9]  -0.05
 UP BND1      psi[8,9]  0.05
 FX BND1      psi[8,10]  0
 LO BND1      psi[8,11]  -0.05
 UP BND1      psi[8,11]  0.05
 LO BND1      psi[8,12]  -0.05
 UP BND1      psi[8,12]  0.05
 LO BND1      psi[8,13]  -0.05
 UP BND1      psi[8,13]  0.05
 LO BND1      psi[8,14]  -0.05
 UP BND1      psi[8,14]  0.05
 LO BND1      psi[8,15]  -0.05
 UP BND1      psi[8,15]  0.05
 LO BND1      psi[8,16]  -0.05
 UP BND1      psi[8,16]  0.05
 LO BND1      psi[8,17]  -0.05
 UP BND1      psi[8,17]  0.05
 LO BND1      psi[8,18]  -0.05
 UP BND1      psi[8,18]  0.05
 LO BND1      psi[8,19]  -0.05
 UP BND1      psi[8,19]  0.05
 LO BND1      psi[8,20]  -0.05
 UP BND1      psi[8,20]  0.05
 LO BND1      psi[8,21]  -0.05
 UP BND1      psi[8,21]  0.05
 LO BND1      psi[9,0]  -0.05
 UP BND1      psi[9,0]  0.05
 LO BND1      psi[9,1]  -0.05
 UP BND1      psi[9,1]  0.05
 LO BND1      psi[9,2]  -0.05
 UP BND1      psi[9,2]  0.05
 LO BND1      psi[9,3]  -0.05
 UP BND1      psi[9,3]  0.05
 LO BND1      psi[9,4]  -0.05
 UP BND1      psi[9,4]  0.05
 FX BND1      psi[9,5]  0
 LO BND1      psi[9,6]  -0.05
 UP BND1      psi[9,6]  0.05
 LO BND1      psi[9,7]  -0.05
 UP BND1      psi[9,7]  0.05
 LO BND1      psi[9,8]  -0.05
 UP BND1      psi[9,8]  0.05
 LO BND1      psi[9,9]  -0.05
 UP BND1      psi[9,9]  0.05
 LO BND1      psi[9,10]  -0.05
 UP BND1      psi[9,10]  0.05
 LO BND1      psi[9,11]  -0.05
 UP BND1      psi[9,11]  0.05
 LO BND1      psi[9,12]  -0.05
 UP BND1      psi[9,12]  0.05
 LO BND1      psi[10,0]  -0.05
 UP BND1      psi[10,0]  0.05
 LO BND1      psi[10,1]  -0.05
 UP BND1      psi[10,1]  0.05
 LO BND1      psi[10,2]  -0.05
 UP BND1      psi[10,2]  0.05
 LO BND1      psi[10,3]  -0.05
 UP BND1      psi[10,3]  0.05
 LO BND1      psi[10,4]  -0.05
 UP BND1      psi[10,4]  0.05
 LO BND1      psi[10,5]  -0.05
 UP BND1      psi[10,5]  0.05
 LO BND1      psi[10,6]  -0.05
 UP BND1      psi[10,6]  0.05
 LO BND1      psi[10,7]  -0.05
 UP BND1      psi[10,7]  0.05
 LO BND1      psi[10,8]  -0.05
 UP BND1      psi[10,8]  0.05
 LO BND1      psi[10,9]  -0.05
 UP BND1      psi[10,9]  0.05
 FX BND1      psi[10,10]  0
 LO BND1      psi[10,11]  -0.05
 UP BND1      psi[10,11]  0.05
 LO BND1      psi[10,12]  -0.05
 UP BND1      psi[10,12]  0.05
 LO BND1      psi[10,13]  -0.05
 UP BND1      psi[10,13]  0.05
 LO BND1      psi[10,14]  -0.05
 UP BND1      psi[10,14]  0.05
 LO BND1      psi[10,15]  -0.05
 UP BND1      psi[10,15]  0.05
 LO BND1      psi[10,16]  -0.05
 UP BND1      psi[10,16]  0.05
 LO BND1      psi[10,17]  -0.05
 UP BND1      psi[10,17]  0.05
 LO BND1      psi[10,18]  -0.05
 UP BND1      psi[10,18]  0.05
 LO BND1      psi[10,19]  -0.05
 UP BND1      psi[10,19]  0.05
 LO BND1      psi[11,0]  -0.05
 UP BND1      psi[11,0]  0.05
 LO BND1      psi[11,1]  -0.05
 UP BND1      psi[11,1]  0.05
 LO BND1      psi[11,2]  -0.05
 UP BND1      psi[11,2]  0.05
 LO BND1      psi[11,3]  -0.05
 UP BND1      psi[11,3]  0.05
 LO BND1      psi[11,4]  -0.05
 UP BND1      psi[11,4]  0.05
 FX BND1      psi[11,5]  0
 LO BND1      psi[11,6]  -0.05
 UP BND1      psi[11,6]  0.05
 LO BND1      psi[11,7]  -0.05
 UP BND1      psi[11,7]  0.05
 LO BND1      psi[11,8]  -0.05
 UP BND1      psi[11,8]  0.05
 LO BND1      psi[11,9]  -0.05
 UP BND1      psi[11,9]  0.05
 LO BND1      psi[11,10]  -0.05
 UP BND1      psi[11,10]  0.05
 LO BND1      psi[11,11]  -0.05
 UP BND1      psi[11,11]  0.05
 LO BND1      psi[11,12]  -0.05
 UP BND1      psi[11,12]  0.05
 LO BND1      psi[12,0]  -0.05
 UP BND1      psi[12,0]  0.05
 LO BND1      psi[12,1]  -0.05
 UP BND1      psi[12,1]  0.05
 LO BND1      psi[12,2]  -0.05
 UP BND1      psi[12,2]  0.05
 LO BND1      psi[12,3]  -0.05
 UP BND1      psi[12,3]  0.05
 LO BND1      psi[12,4]  -0.05
 UP BND1      psi[12,4]  0.05
 LO BND1      psi[12,5]  -0.05
 UP BND1      psi[12,5]  0.05
 LO BND1      psi[12,6]  -0.05
 UP BND1      psi[12,6]  0.05
 FX BND1      psi[12,7]  0
 LO BND1      psi[12,8]  -0.05
 UP BND1      psi[12,8]  0.05
 LO BND1      psi[12,9]  -0.05
 UP BND1      psi[12,9]  0.05
 LO BND1      psi[12,10]  -0.05
 UP BND1      psi[12,10]  0.05
 LO BND1      psi[12,11]  -0.05
 UP BND1      psi[12,11]  0.05
 LO BND1      psi[12,12]  -0.05
 UP BND1      psi[12,12]  0.05
 LO BND1      psi[12,13]  -0.05
 UP BND1      psi[12,13]  0.05
 LO BND1      psi[12,14]  -0.05
 UP BND1      psi[12,14]  0.05
 LO BND1      psi[12,15]  -0.05
 UP BND1      psi[12,15]  0.05
 LO BND1      psi[13,0]  -0.05
 UP BND1      psi[13,0]  0.05
 LO BND1      psi[13,1]  -0.05
 UP BND1      psi[13,1]  0.05
 LO BND1      psi[13,2]  -0.05
 UP BND1      psi[13,2]  0.05
 LO BND1      psi[13,3]  -0.05
 UP BND1      psi[13,3]  0.05
 LO BND1      psi[13,4]  -0.05
 UP BND1      psi[13,4]  0.05
 LO BND1      psi[13,5]  -0.05
 UP BND1      psi[13,5]  0.05
 LO BND1      psi[13,6]  -0.05
 UP BND1      psi[13,6]  0.05
 FX BND1      psi[13,7]  0
 LO BND1      psi[13,8]  -0.05
 UP BND1      psi[13,8]  0.05
 LO BND1      psi[13,9]  -0.05
 UP BND1      psi[13,9]  0.05
 LO BND1      psi[13,10]  -0.05
 UP BND1      psi[13,10]  0.05
 LO BND1      psi[13,11]  -0.05
 UP BND1      psi[13,11]  0.05
 LO BND1      psi[13,12]  -0.05
 UP BND1      psi[13,12]  0.05
 LO BND1      psi[13,13]  -0.05
 UP BND1      psi[13,13]  0.05
 LO BND1      psi[13,14]  -0.05
 UP BND1      psi[13,14]  0.05
 LO BND1      psi[13,15]  -0.05
 UP BND1      psi[13,15]  0.05
 LO BND1      psi[13,16]  -0.05
 UP BND1      psi[13,16]  0.05
 LO BND1      psi[13,17]  -0.05
 UP BND1      psi[13,17]  0.05
 LO BND1      psi[13,18]  -0.05
 UP BND1      psi[13,18]  0.05
 LO BND1      psi[13,19]  -0.05
 UP BND1      psi[13,19]  0.05
 LO BND1      psi[14,0]  -0.05
 UP BND1      psi[14,0]  0.05
 LO BND1      psi[14,1]  -0.05
 UP BND1      psi[14,1]  0.05
 LO BND1      psi[14,2]  -0.05
 UP BND1      psi[14,2]  0.05
 LO BND1      psi[14,3]  -0.05
 UP BND1      psi[14,3]  0.05
 LO BND1      psi[14,4]  -0.05
 UP BND1      psi[14,4]  0.05
 LO BND1      psi[14,5]  -0.05
 UP BND1      psi[14,5]  0.05
 LO BND1      psi[14,6]  -0.05
 UP BND1      psi[14,6]  0.05
 LO BND1      psi[14,7]  -0.05
 UP BND1      psi[14,7]  0.05
 FX BND1      psi[14,8]  0
 LO BND1      psi[14,9]  -0.05
 UP BND1      psi[14,9]  0.05
 LO BND1      psi[14,10]  -0.05
 UP BND1      psi[14,10]  0.05
 LO BND1      psi[14,11]  -0.05
 UP BND1      psi[14,11]  0.05
 LO BND1      psi[14,12]  -0.05
 UP BND1      psi[14,12]  0.05
 LO BND1      psi[14,13]  -0.05
 UP BND1      psi[14,13]  0.05
 LO BND1      psi[14,14]  -0.05
 UP BND1      psi[14,14]  0.05
 LO BND1      psi[14,15]  -0.05
 UP BND1      psi[14,15]  0.05
 LO BND1      psi[15,0]  -0.05
 UP BND1      psi[15,0]  0.05
 LO BND1      psi[15,1]  -0.05
 UP BND1      psi[15,1]  0.05
 LO BND1      psi[15,2]  -0.05
 UP BND1      psi[15,2]  0.05
 LO BND1      psi[15,3]  -0.05
 UP BND1      psi[15,3]  0.05
 LO BND1      psi[15,4]  -0.05
 UP BND1      psi[15,4]  0.05
 LO BND1      psi[15,5]  -0.05
 UP BND1      psi[15,5]  0.05
 LO BND1      psi[15,6]  -0.05
 UP BND1      psi[15,6]  0.05
 LO BND1      psi[15,7]  -0.05
 UP BND1      psi[15,7]  0.05
 FX BND1      psi[15,8]  0
 LO BND1      psi[15,9]  -0.05
 UP BND1      psi[15,9]  0.05
 LO BND1      psi[15,10]  -0.05
 UP BND1      psi[15,10]  0.05
 LO BND1      psi[15,11]  -0.05
 UP BND1      psi[15,11]  0.05
 LO BND1      psi[15,12]  -0.05
 UP BND1      psi[15,12]  0.05
 LO BND1      psi[15,13]  -0.05
 UP BND1      psi[15,13]  0.05
 LO BND1      psi[15,14]  -0.05
 UP BND1      psi[15,14]  0.05
 LO BND1      psi[15,15]  -0.05
 UP BND1      psi[15,15]  0.05
 LO BND1      psi[15,16]  -0.05
 UP BND1      psi[15,16]  0.05
 LO BND1      psi[16,0]  -0.05
 UP BND1      psi[16,0]  0.05
 LO BND1      psi[16,1]  -0.05
 UP BND1      psi[16,1]  0.05
 LO BND1      psi[16,2]  -0.05
 UP BND1      psi[16,2]  0.05
 LO BND1      psi[16,3]  -0.05
 UP BND1      psi[16,3]  0.05
 LO BND1      psi[16,4]  -0.05
 UP BND1      psi[16,4]  0.05
 LO BND1      psi[16,5]  -0.05
 UP BND1      psi[16,5]  0.05
 FX BND1      psi[16,6]  0
 LO BND1      psi[16,7]  -0.05
 UP BND1      psi[16,7]  0.05
 LO BND1      psi[16,8]  -0.05
 UP BND1      psi[16,8]  0.05
 LO BND1      psi[16,9]  -0.05
 UP BND1      psi[16,9]  0.05
 LO BND1      psi[16,10]  -0.05
 UP BND1      psi[16,10]  0.05
 LO BND1      psi[16,11]  -0.05
 UP BND1      psi[16,11]  0.05
 LO BND1      psi[16,12]  -0.05
 UP BND1      psi[16,12]  0.05
 LO BND1      psi[17,0]  -0.05
 UP BND1      psi[17,0]  0.05
 LO BND1      psi[17,1]  -0.05
 UP BND1      psi[17,1]  0.05
 LO BND1      psi[17,2]  -0.05
 UP BND1      psi[17,2]  0.05
 LO BND1      psi[17,3]  -0.05
 UP BND1      psi[17,3]  0.05
 LO BND1      psi[17,4]  -0.05
 UP BND1      psi[17,4]  0.05
 LO BND1      psi[17,5]  -0.05
 UP BND1      psi[17,5]  0.05
 LO BND1      psi[17,6]  -0.05
 UP BND1      psi[17,6]  0.05
 FX BND1      psi[17,7]  0
 LO BND1      psi[17,8]  -0.05
 UP BND1      psi[17,8]  0.05
 LO BND1      psi[17,9]  -0.05
 UP BND1      psi[17,9]  0.05
 LO BND1      psi[17,10]  -0.05
 UP BND1      psi[17,10]  0.05
 LO BND1      psi[17,11]  -0.05
 UP BND1      psi[17,11]  0.05
 LO BND1      psi[17,12]  -0.05
 UP BND1      psi[17,12]  0.05
 LO BND1      psi[17,13]  -0.05
 UP BND1      psi[17,13]  0.05
 LO BND1      psi[17,14]  -0.05
 UP BND1      psi[17,14]  0.05
 LO BND1      psi[17,15]  -0.05
 UP BND1      psi[17,15]  0.05
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 LO BND1      psi[18,0]  -0.05
 UP BND1      psi[18,0]  0.05
 LO BND1      psi[18,1]  -0.05
 UP BND1      psi[18,1]  0.05
 LO BND1      psi[18,2]  -0.05
 UP BND1      psi[18,2]  0.05
 LO BND1      psi[18,3]  -0.05
 UP BND1      psi[18,3]  0.05
 LO BND1      psi[18,4]  -0.05
 UP BND1      psi[18,4]  0.05
 LO BND1      psi[18,5]  -0.05
 UP BND1      psi[18,5]  0.05
 LO BND1      psi[18,6]  -0.05
 UP BND1      psi[18,6]  0.05
 LO BND1      psi[18,7]  -0.05
 UP BND1      psi[18,7]  0.05
 LO BND1      psi[18,8]  -0.05
 UP BND1      psi[18,8]  0.05
 FX BND1      psi[18,9]  0
 LO BND1      psi[18,10]  -0.05
 UP BND1      psi[18,10]  0.05
 LO BND1      psi[18,11]  -0.05
 UP BND1      psi[18,11]  0.05
 LO BND1      psi[18,12]  -0.05
 UP BND1      psi[18,12]  0.05
 LO BND1      psi[18,13]  -0.05
 UP BND1      psi[18,13]  0.05
 LO BND1      psi[18,14]  -0.05
 UP BND1      psi[18,14]  0.05
 LO BND1      psi[18,15]  -0.05
 UP BND1      psi[18,15]  0.05
 LO BND1      psi[18,16]  -0.05
 UP BND1      psi[18,16]  0.05
 LO BND1      psi[18,17]  -0.05
 UP BND1      psi[18,17]  0.05
 LO BND1      psi[19,0]  -0.05
 UP BND1      psi[19,0]  0.05
 LO BND1      psi[19,1]  -0.05
 UP BND1      psi[19,1]  0.05
 LO BND1      psi[19,2]  -0.05
 UP BND1      psi[19,2]  0.05
 LO BND1      psi[19,3]  -0.05
 UP BND1      psi[19,3]  0.05
 FX BND1      psi[19,4]  0
 LO BND1      psi[19,5]  -0.05
 UP BND1      psi[19,5]  0.05
 LO BND1      psi[19,6]  -0.05
 UP BND1      psi[19,6]  0.05
 LO BND1      psi[19,7]  -0.05
 UP BND1      psi[19,7]  0.05
 LO BND1      psi[19,8]  -0.05
 UP BND1      psi[19,8]  0.05
 LO BND1      psi[20,0]  -0.05
 UP BND1      psi[20,0]  0.05
 LO BND1      psi[20,1]  -0.05
 UP BND1      psi[20,1]  0.05
 LO BND1      psi[20,2]  -0.05
 UP BND1      psi[20,2]  0.05
 LO BND1      psi[20,3]  -0.05
 UP BND1      psi[20,3]  0.05
 LO BND1      psi[20,4]  -0.05
 UP BND1      psi[20,4]  0.05
 LO BND1      psi[20,5]  -0.05
 UP BND1      psi[20,5]  0.05
 FX BND1      psi[20,6]  0
 LO BND1      psi[20,7]  -0.05
 UP BND1      psi[20,7]  0.05
 LO BND1      psi[20,8]  -0.05
 UP BND1      psi[20,8]  0.05
 LO BND1      psi[20,9]  -0.05
 UP BND1      psi[20,9]  0.05
 LO BND1      psi[20,10]  -0.05
 UP BND1      psi[20,10]  0.05
 LO BND1      psi[20,11]  -0.05
 UP BND1      psi[20,11]  0.05
 LO BND1      psi[20,12]  -0.05
 UP BND1      psi[20,12]  0.05
 LO BND1      psi[21,0]  -0.05
 UP BND1      psi[21,0]  0.05
 LO BND1      psi[21,1]  -0.05
 UP BND1      psi[21,1]  0.05
 LO BND1      psi[21,2]  -0.05
 UP BND1      psi[21,2]  0.05
 LO BND1      psi[21,3]  -0.05
 UP BND1      psi[21,3]  0.05
 LO BND1      psi[21,4]  -0.05
 UP BND1      psi[21,4]  0.05
 LO BND1      psi[21,5]  -0.05
 UP BND1      psi[21,5]  0.05
 LO BND1      psi[21,6]  -0.05
 UP BND1      psi[21,6]  0.05
 FX BND1      psi[21,7]  0
 LO BND1      psi[21,8]  -0.05
 UP BND1      psi[21,8]  0.05
 LO BND1      psi[21,9]  -0.05
 UP BND1      psi[21,9]  0.05
 LO BND1      psi[21,10]  -0.05
 UP BND1      psi[21,10]  0.05
 LO BND1      psi[21,11]  -0.05
 UP BND1      psi[21,11]  0.05
 LO BND1      psi[21,12]  -0.05
 UP BND1      psi[21,12]  0.05
 LO BND1      psi[21,13]  -0.05
 UP BND1      psi[21,13]  0.05
 LO BND1      psi[21,14]  -0.05
 UP BND1      psi[21,14]  0.05
 LO BND1      psi[21,15]  -0.05
 UP BND1      psi[21,15]  0.05
 LO BND1      psi[22,0]  -0.05
 UP BND1      psi[22,0]  0.05
 LO BND1      psi[22,1]  -0.05
 UP BND1      psi[22,1]  0.05
 LO BND1      psi[22,2]  -0.05
 UP BND1      psi[22,2]  0.05
 LO BND1      psi[22,3]  -0.05
 UP BND1      psi[22,3]  0.05
 LO BND1      psi[22,4]  -0.05
 UP BND1      psi[22,4]  0.05
 FX BND1      psi[22,5]  0
 LO BND1      psi[22,6]  -0.05
 UP BND1      psi[22,6]  0.05
 LO BND1      psi[22,7]  -0.05
 UP BND1      psi[22,7]  0.05
 LO BND1      psi[22,8]  -0.05
 UP BND1      psi[22,8]  0.05
 LO BND1      psi[22,9]  -0.05
 UP BND1      psi[22,9]  0.05
 LO BND1      psi[22,10]  -0.05
 UP BND1      psi[22,10]  0.05
 LO BND1      psi[22,11]  -0.05
 UP BND1      psi[22,11]  0.05
 LO BND1      psi[22,12]  -0.05
 UP BND1      psi[22,12]  0.05
 LO BND1      psi[23,0]  -0.05
 UP BND1      psi[23,0]  0.05
 LO BND1      psi[23,1]  -0.05
 UP BND1      psi[23,1]  0.05
 LO BND1      psi[23,2]  -0.05
 UP BND1      psi[23,2]  0.05
 LO BND1      psi[23,3]  -0.05
 UP BND1      psi[23,3]  0.05
 FX BND1      psi[23,4]  0
 LO BND1      psi[23,5]  -0.05
 UP BND1      psi[23,5]  0.05
 LO BND1      psi[23,6]  -0.05
 UP BND1      psi[23,6]  0.05
 LO BND1      psi[23,7]  -0.05
 UP BND1      psi[23,7]  0.05
 LO BND1      psi[23,8]  -0.05
 UP BND1      psi[23,8]  0.05
 LO BND1      psi[23,9]  -0.05
 UP BND1      psi[23,9]  0.05
 LO BND1      psi[23,10]  -0.05
 UP BND1      psi[23,10]  0.05
 LO BND1      psi[23,11]  -0.05
 UP BND1      psi[23,11]  0.05
 LO BND1      psi[24,0]  -0.05
 UP BND1      psi[24,0]  0.05
 LO BND1      psi[24,1]  -0.05
 UP BND1      psi[24,1]  0.05
 LO BND1      psi[24,2]  -0.05
 UP BND1      psi[24,2]  0.05
 LO BND1      psi[24,3]  -0.05
 UP BND1      psi[24,3]  0.05
 LO BND1      psi[24,4]  -0.05
 UP BND1      psi[24,4]  0.05
 LO BND1      psi[24,5]  -0.05
 UP BND1      psi[24,5]  0.05
 LO BND1      psi[24,6]  -0.05
 UP BND1      psi[24,6]  0.05
 FX BND1      psi[24,7]  0
 LO BND1      psi[24,8]  -0.05
 UP BND1      psi[24,8]  0.05
 LO BND1      psi[24,9]  -0.05
 UP BND1      psi[24,9]  0.05
 LO BND1      psi[24,10]  -0.05
 UP BND1      psi[24,10]  0.05
 LO BND1      psi[24,11]  -0.05
 UP BND1      psi[24,11]  0.05
 LO BND1      psi[24,12]  -0.05
 UP BND1      psi[24,12]  0.05
 LO BND1      psi[24,13]  -0.05
 UP BND1      psi[24,13]  0.05
 LO BND1      psi[24,14]  -0.05
 UP BND1      psi[24,14]  0.05
 LO BND1      psi[24,15]  -0.05
 UP BND1      psi[24,15]  0.05
 LO BND1      psi[25,0]  -0.05
 UP BND1      psi[25,0]  0.05
 LO BND1      psi[25,1]  -0.05
 UP BND1      psi[25,1]  0.05
 LO BND1      psi[25,2]  -0.05
 UP BND1      psi[25,2]  0.05
 LO BND1      psi[25,3]  -0.05
 UP BND1      psi[25,3]  0.05
 LO BND1      psi[25,4]  -0.05
 UP BND1      psi[25,4]  0.05
 LO BND1      psi[25,5]  -0.05
 UP BND1      psi[25,5]  0.05
 FX BND1      psi[25,6]  0
 LO BND1      psi[25,7]  -0.05
 UP BND1      psi[25,7]  0.05
 LO BND1      psi[25,8]  -0.05
 UP BND1      psi[25,8]  0.05
 LO BND1      psi[25,9]  -0.05
 UP BND1      psi[25,9]  0.05
 LO BND1      psi[25,10]  -0.05
 UP BND1      psi[25,10]  0.05
 LO BND1      psi[25,11]  -0.05
 UP BND1      psi[25,11]  0.05
 LO BND1      psi[25,12]  -0.05
 UP BND1      psi[25,12]  0.05
 LO BND1      psi[25,13]  -0.05
 UP BND1      psi[25,13]  0.05
 LO BND1      psi[25,14]  -0.05
 UP BND1      psi[25,14]  0.05
 LO BND1      psi[25,15]  -0.05
 UP BND1      psi[25,15]  0.05
 LO BND1      psi[26,0]  -0.05
 UP BND1      psi[26,0]  0.05
 LO BND1      psi[26,1]  -0.05
 UP BND1      psi[26,1]  0.05
 LO BND1      psi[26,2]  -0.05
 UP BND1      psi[26,2]  0.05
 FX BND1      psi[26,3]  0
 LO BND1      psi[26,4]  -0.05
 UP BND1      psi[26,4]  0.05
 LO BND1      psi[26,5]  -0.05
 UP BND1      psi[26,5]  0.05
 LO BND1      psi[26,6]  -0.05
 UP BND1      psi[26,6]  0.05
 LO BND1      psi[26,7]  -0.05
 UP BND1      psi[26,7]  0.05
 LO BND1      psi[26,8]  -0.05
 UP BND1      psi[26,8]  0.05
 LO BND1      psi[27,0]  -0.05
 UP BND1      psi[27,0]  0.05
 LO BND1      psi[27,1]  -0.05
 UP BND1      psi[27,1]  0.05
 LO BND1      psi[27,2]  -0.05
 UP BND1      psi[27,2]  0.05
 LO BND1      psi[27,3]  -0.05
 UP BND1      psi[27,3]  0.05
 LO BND1      psi[27,4]  -0.05
 UP BND1      psi[27,4]  0.05
 LO BND1      psi[27,5]  -0.05
 UP BND1      psi[27,5]  0.05
 FX BND1      psi[27,6]  0
 LO BND1      psi[27,7]  -0.05
 UP BND1      psi[27,7]  0.05
 LO BND1      psi[27,8]  -0.05
 UP BND1      psi[27,8]  0.05
 LO BND1      psi[27,9]  -0.05
 UP BND1      psi[27,9]  0.05
 LO BND1      psi[27,10]  -0.05
 UP BND1      psi[27,10]  0.05
 LO BND1      psi[27,11]  -0.05
 UP BND1      psi[27,11]  0.05
 LO BND1      psi[27,12]  -0.05
 UP BND1      psi[27,12]  0.05
 LO BND1      psi[27,13]  -0.05
 UP BND1      psi[27,13]  0.05
 LO BND1      psi[27,14]  -0.05
 UP BND1      psi[27,14]  0.05
 LO BND1      psi[27,15]  -0.05
 UP BND1      psi[27,15]  0.05
 LO BND1      psi[28,0]  -0.05
 UP BND1      psi[28,0]  0.05
 LO BND1      psi[28,1]  -0.05
 UP BND1      psi[28,1]  0.05
 LO BND1      psi[28,2]  -0.05
 UP BND1      psi[28,2]  0.05
 LO BND1      psi[28,3]  -0.05
 UP BND1      psi[28,3]  0.05
 LO BND1      psi[28,4]  -0.05
 UP BND1      psi[28,4]  0.05
 LO BND1      psi[28,5]  -0.05
 UP BND1      psi[28,5]  0.05
 FX BND1      psi[28,6]  0
 LO BND1      psi[28,7]  -0.05
 UP BND1      psi[28,7]  0.05
 LO BND1      psi[28,8]  -0.05
 UP BND1      psi[28,8]  0.05
 LO BND1      psi[28,9]  -0.05
 UP BND1      psi[28,9]  0.05
 LO BND1      psi[28,10]  -0.05
 UP BND1      psi[28,10]  0.05
 LO BND1      psi[28,11]  -0.05
 UP BND1      psi[28,11]  0.05
 LO BND1      psi[28,12]  -0.05
 UP BND1      psi[28,12]  0.05
 LO BND1      psi[28,13]  -0.05
 UP BND1      psi[28,13]  0.05
 LO BND1      psi[28,14]  -0.05
 UP BND1      psi[28,14]  0.05
 LO BND1      psi[28,15]  -0.05
 UP BND1      psi[28,15]  0.05
 LO BND1      psi[28,16]  -0.05
 UP BND1      psi[28,16]  0.05
 LO BND1      psi[28,17]  -0.05
 UP BND1      psi[28,17]  0.05
 LO BND1      psi[28,18]  -0.05
 UP BND1      psi[28,18]  0.05
 LO BND1      psi[28,19]  -0.05
 UP BND1      psi[28,19]  0.05
 LO BND1      psi[29,0]  -0.05
 UP BND1      psi[29,0]  0.05
 LO BND1      psi[29,1]  -0.05
 UP BND1      psi[29,1]  0.05
 LO BND1      psi[29,2]  -0.05
 UP BND1      psi[29,2]  0.05
 LO BND1      psi[29,3]  -0.05
 UP BND1      psi[29,3]  0.05
 LO BND1      psi[29,4]  -0.05
 UP BND1      psi[29,4]  0.05
 LO BND1      psi[29,5]  -0.05
 UP BND1      psi[29,5]  0.05
 FX BND1      psi[29,6]  0
 LO BND1      psi[29,7]  -0.05
 UP BND1      psi[29,7]  0.05
 LO BND1      psi[29,8]  -0.05
 UP BND1      psi[29,8]  0.05
 LO BND1      psi[29,9]  -0.05
 UP BND1      psi[29,9]  0.05
 LO BND1      psi[29,10]  -0.05
 UP BND1      psi[29,10]  0.05
 LO BND1      psi[29,11]  -0.05
 UP BND1      psi[29,11]  0.05
 LO BND1      psi[29,12]  -0.05
 UP BND1      psi[29,12]  0.05
 LO BND1      psi[29,13]  -0.05
 UP BND1      psi[29,13]  0.05
 LO BND1      psi[29,14]  -0.05
 UP BND1      psi[29,14]  0.05
 LO BND1      psi[29,15]  -0.05
 UP BND1      psi[29,15]  0.05
 LO BND1      psi[30,0]  -0.05
 UP BND1      psi[30,0]  0.05
 LO BND1      psi[30,1]  -0.05
 UP BND1      psi[30,1]  0.05
 LO BND1      psi[30,2]  -0.05
 UP BND1      psi[30,2]  0.05
 FX BND1      psi[30,3]  0
 LO BND1      psi[30,4]  -0.05
 UP BND1      psi[30,4]  0.05
 LO BND1      psi[30,5]  -0.05
 UP BND1      psi[30,5]  0.05
 LO BND1      psi[30,6]  -0.05
 UP BND1      psi[30,6]  0.05
 LO BND1      psi[30,7]  -0.05
 UP BND1      psi[30,7]  0.05
 LO BND1      psi[30,8]  -0.05
 UP BND1      psi[30,8]  0.05
 LO BND1      psi[31,0]  -0.05
 UP BND1      psi[31,0]  0.05
 LO BND1      psi[31,1]  -0.05
 UP BND1      psi[31,1]  0.05
 LO BND1      psi[31,2]  -0.05
 UP BND1      psi[31,2]  0.05
 LO BND1      psi[31,3]  -0.05
 UP BND1      psi[31,3]  0.05
 LO BND1      psi[31,4]  -0.05
 UP BND1      psi[31,4]  0.05
 LO BND1      psi[31,5]  -0.05
 UP BND1      psi[31,5]  0.05
 LO BND1      psi[31,6]  -0.05
 UP BND1      psi[31,6]  0.05
 FX BND1      psi[31,7]  0
 LO BND1      psi[31,8]  -0.05
 UP BND1      psi[31,8]  0.05
 LO BND1      psi[31,9]  -0.05
 UP BND1      psi[31,9]  0.05
 LO BND1      psi[31,10]  -0.05
 UP BND1      psi[31,10]  0.05
 LO BND1      psi[31,11]  -0.05
 UP BND1      psi[31,11]  0.05
 LO BND1      psi[31,12]  -0.05
 UP BND1      psi[31,12]  0.05
 LO BND1      psi[32,0]  -0.05
 UP BND1      psi[32,0]  0.05
 LO BND1      psi[32,1]  -0.05
 UP BND1      psi[32,1]  0.05
 LO BND1      psi[32,2]  -0.05
 UP BND1      psi[32,2]  0.05
 LO BND1      psi[32,3]  -0.05
 UP BND1      psi[32,3]  0.05
 LO BND1      psi[32,4]  -0.05
 UP BND1      psi[32,4]  0.05
 FX BND1      psi[32,5]  0
 LO BND1      psi[32,6]  -0.05
 UP BND1      psi[32,6]  0.05
 LO BND1      psi[32,7]  -0.05
 UP BND1      psi[32,7]  0.05
 LO BND1      psi[32,8]  -0.05
 UP BND1      psi[32,8]  0.05
 LO BND1      psi[32,9]  -0.05
 UP BND1      psi[32,9]  0.05
 LO BND1      psi[32,10]  -0.05
 UP BND1      psi[32,10]  0.05
 LO BND1      psi[32,11]  -0.05
 UP BND1      psi[32,11]  0.05
 LO BND1      psi[32,12]  -0.05
 UP BND1      psi[32,12]  0.05
 LO BND1      psi[33,0]  -0.05
 UP BND1      psi[33,0]  0.05
 LO BND1      psi[33,1]  -0.05
 UP BND1      psi[33,1]  0.05
 LO BND1      psi[33,2]  -0.05
 UP BND1      psi[33,2]  0.05
 LO BND1      psi[33,3]  -0.05
 UP BND1      psi[33,3]  0.05
 LO BND1      psi[33,4]  -0.05
 UP BND1      psi[33,4]  0.05
 LO BND1      psi[33,5]  -0.05
 UP BND1      psi[33,5]  0.05
 FX BND1      psi[33,6]  0
 LO BND1      psi[33,7]  -0.05
 UP BND1      psi[33,7]  0.05
 LO BND1      psi[33,8]  -0.05
 UP BND1      psi[33,8]  0.05
 LO BND1      psi[33,9]  -0.05
 UP BND1      psi[33,9]  0.05
 LO BND1      psi[33,10]  -0.05
 UP BND1      psi[33,10]  0.05
 LO BND1      psi[33,11]  -0.05
 UP BND1      psi[33,11]  0.05
 LO BND1      psi[33,12]  -0.05
 UP BND1      psi[33,12]  0.05
 LO BND1      psi[33,13]  -0.05
 UP BND1      psi[33,13]  0.05
 LO BND1      psi[33,14]  -0.05
 UP BND1      psi[33,14]  0.05
 LO BND1      psi[33,15]  -0.05
 UP BND1      psi[33,15]  0.05
 LO BND1      psi[33,16]  -0.05
 UP BND1      psi[33,16]  0.05
 LO BND1      psi[34,0]  -0.05
 UP BND1      psi[34,0]  0.05
 LO BND1      psi[34,1]  -0.05
 UP BND1      psi[34,1]  0.05
 LO BND1      psi[34,2]  -0.05
 UP BND1      psi[34,2]  0.05
 LO BND1      psi[34,3]  -0.05
 UP BND1      psi[34,3]  0.05
 LO BND1      psi[34,4]  -0.05
 UP BND1      psi[34,4]  0.05
 FX BND1      psi[34,5]  0
 LO BND1      psi[34,6]  -0.05
 UP BND1      psi[34,6]  0.05
 LO BND1      psi[34,7]  -0.05
 UP BND1      psi[34,7]  0.05
 LO BND1      psi[34,8]  -0.05
 UP BND1      psi[34,8]  0.05
 LO BND1      psi[34,9]  -0.05
 UP BND1      psi[34,9]  0.05
 LO BND1      psi[34,10]  -0.05
 UP BND1      psi[34,10]  0.05
 LO BND1      psi[34,11]  -0.05
 UP BND1      psi[34,11]  0.05
 LO BND1      psi[35,0]  -0.05
 UP BND1      psi[35,0]  0.05
 LO BND1      psi[35,1]  -0.05
 UP BND1      psi[35,1]  0.05
 LO BND1      psi[35,2]  -0.05
 UP BND1      psi[35,2]  0.05
 LO BND1      psi[35,3]  -0.05
 UP BND1      psi[35,3]  0.05
 LO BND1      psi[35,4]  -0.05
 UP BND1      psi[35,4]  0.05
 LO BND1      psi[35,5]  -0.05
 UP BND1      psi[35,5]  0.05
 LO BND1      psi[35,6]  -0.05
 UP BND1      psi[35,6]  0.05
 LO BND1      psi[35,7]  -0.05
 UP BND1      psi[35,7]  0.05
 FX BND1      psi[35,8]  0
 LO BND1      psi[35,9]  -0.05
 UP BND1      psi[35,9]  0.05
 LO BND1      psi[35,10]  -0.05
 UP BND1      psi[35,10]  0.05
 LO BND1      psi[35,11]  -0.05
 UP BND1      psi[35,11]  0.05
 LO BND1      psi[35,12]  -0.05
 UP BND1      psi[35,12]  0.05
 LO BND1      psi[35,13]  -0.05
 UP BND1      psi[35,13]  0.05
 LO BND1      psi[35,14]  -0.05
 UP BND1      psi[35,14]  0.05
 LO BND1      psi[35,15]  -0.05
 UP BND1      psi[35,15]  0.05
 FR BND1      a       
ENDATA
