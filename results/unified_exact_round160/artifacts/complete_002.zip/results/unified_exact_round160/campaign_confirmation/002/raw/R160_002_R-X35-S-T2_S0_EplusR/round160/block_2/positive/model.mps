* Signature: 0x505029390ae48a36
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 E  onehot_27_14
 E  normalized_mass_27_15
 E  normalized_ratio_27_16
 G  product_lb_17
 L  product_ub_18
 G  product_lb_19
 L  product_ub_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 E  onehot_25_27
 E  normalized_mass_25_28
 E  normalized_ratio_25_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 G  product_lb_40
 L  product_ub_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 E  onehot_34_62
 E  normalized_mass_34_63
 E  normalized_ratio_34_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 E  onehot_23_73
 E  normalized_mass_23_74
 E  normalized_ratio_23_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 E  onehot_22_108
 E  normalized_mass_22_109
 E  normalized_ratio_22_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 E  onehot_26_129
 E  normalized_mass_26_130
 E  normalized_ratio_26_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 E  onehot_32_172
 E  normalized_mass_32_173
 E  normalized_ratio_32_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 E  onehot_31_199
 E  normalized_mass_31_200
 E  normalized_ratio_31_201
 G  stock_lb_202
 L  stock_ub_203
 L  parent_nonstrict_scope_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 E  normalization_261
 G  full_original_Gini_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 L  arc_capacity_344
 L  arc_capacity_345
 L  arc_capacity_346
 L  arc_capacity_347
 L  arc_capacity_348
 L  arc_capacity_349
 L  arc_capacity_350
 L  arc_capacity_351
 L  arc_capacity_352
 L  arc_capacity_353
 L  arc_capacity_354
 L  arc_capacity_355
 L  arc_capacity_356
 L  arc_capacity_357
 L  arc_capacity_358
 G  connected_order_arc_359
 L  arc_capacity_360
 G  connected_order_arc_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 E  depot_departure_or_bypass_633
 E  depot_return_or_bypass_634
 E  out_degree_635
 E  in_degree_636
 G  order_active_lb_637
 L  order_active_ub_638
 E  segment_load_conservation_639
 G  segment_prefix_lb_640
 L  segment_prefix_ub_641
 E  out_degree_642
 E  in_degree_643
 G  order_active_lb_644
 L  order_active_ub_645
 E  segment_load_conservation_646
 G  segment_prefix_lb_647
 L  segment_prefix_ub_648
 E  out_degree_649
 E  in_degree_650
 G  order_active_lb_651
 L  order_active_ub_652
 E  segment_load_conservation_653
 G  segment_prefix_lb_654
 L  segment_prefix_ub_655
 E  out_degree_656
 E  in_degree_657
 G  order_active_lb_658
 L  order_active_ub_659
 E  segment_load_conservation_660
 G  segment_prefix_lb_661
 L  segment_prefix_ub_662
 E  out_degree_663
 E  in_degree_664
 G  order_active_lb_665
 L  order_active_ub_666
 E  service_visit_def_667
 E  free_load_conservation_668
 E  out_degree_669
 E  in_degree_670
 G  order_active_lb_671
 L  order_active_ub_672
 E  service_visit_def_673
 E  free_load_conservation_674
 E  out_degree_675
 E  in_degree_676
 G  order_active_lb_677
 L  order_active_ub_678
 E  service_visit_def_679
 E  free_load_conservation_680
 E  out_degree_681
 E  in_degree_682
 G  order_active_lb_683
 L  order_active_ub_684
 E  service_visit_def_685
 E  free_load_conservation_686
 E  out_degree_687
 E  in_degree_688
 G  order_active_lb_689
 L  order_active_ub_690
 E  service_visit_def_691
 E  free_load_conservation_692
 E  out_degree_693
 E  in_degree_694
 G  order_active_lb_695
 L  order_active_ub_696
 E  service_visit_def_697
 E  free_load_conservation_698
 E  out_degree_699
 E  in_degree_700
 G  order_active_lb_701
 L  order_active_ub_702
 E  service_visit_def_703
 E  free_load_conservation_704
 E  out_degree_705
 E  in_degree_706
 G  order_active_lb_707
 L  order_active_ub_708
 E  service_visit_def_709
 E  free_load_conservation_710
 G  fixed_segment_relative_order_711
 G  fixed_segment_relative_order_712
 G  fixed_segment_relative_order_713
 L  original_T_including_depot_unload_714
 L  arc_capacity_715
 L  arc_capacity_716
 L  arc_capacity_717
 L  arc_capacity_718
 L  arc_capacity_719
 L  arc_capacity_720
 L  arc_capacity_721
 L  arc_capacity_722
 L  arc_capacity_723
 L  arc_capacity_724
 L  arc_capacity_725
 L  arc_capacity_726
 L  arc_capacity_727
 L  arc_capacity_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 E  depot_departure_or_bypass_1004
 E  depot_return_or_bypass_1005
 E  out_degree_1006
 E  in_degree_1007
 G  order_active_lb_1008
 L  order_active_ub_1009
 E  segment_load_conservation_1010
 G  segment_prefix_lb_1011
 L  segment_prefix_ub_1012
 E  out_degree_1013
 E  in_degree_1014
 G  order_active_lb_1015
 L  order_active_ub_1016
 E  segment_load_conservation_1017
 G  segment_prefix_lb_1018
 L  segment_prefix_ub_1019
 E  out_degree_1020
 E  in_degree_1021
 G  order_active_lb_1022
 L  order_active_ub_1023
 E  segment_load_conservation_1024
 G  segment_prefix_lb_1025
 L  segment_prefix_ub_1026
 E  out_degree_1027
 E  in_degree_1028
 G  order_active_lb_1029
 L  order_active_ub_1030
 E  segment_load_conservation_1031
 G  segment_prefix_lb_1032
 L  segment_prefix_ub_1033
 E  out_degree_1034
 E  in_degree_1035
 G  order_active_lb_1036
 L  order_active_ub_1037
 E  service_visit_def_1038
 E  free_load_conservation_1039
 E  out_degree_1040
 E  in_degree_1041
 G  order_active_lb_1042
 L  order_active_ub_1043
 E  service_visit_def_1044
 E  free_load_conservation_1045
 E  out_degree_1046
 E  in_degree_1047
 G  order_active_lb_1048
 L  order_active_ub_1049
 E  service_visit_def_1050
 E  free_load_conservation_1051
 E  out_degree_1052
 E  in_degree_1053
 G  order_active_lb_1054
 L  order_active_ub_1055
 E  service_visit_def_1056
 E  free_load_conservation_1057
 E  out_degree_1058
 E  in_degree_1059
 G  order_active_lb_1060
 L  order_active_ub_1061
 E  service_visit_def_1062
 E  free_load_conservation_1063
 E  out_degree_1064
 E  in_degree_1065
 G  order_active_lb_1066
 L  order_active_ub_1067
 E  service_visit_def_1068
 E  free_load_conservation_1069
 E  out_degree_1070
 E  in_degree_1071
 G  order_active_lb_1072
 L  order_active_ub_1073
 E  service_visit_def_1074
 E  free_load_conservation_1075
 E  out_degree_1076
 E  in_degree_1077
 G  order_active_lb_1078
 L  order_active_ub_1079
 E  service_visit_def_1080
 E  free_load_conservation_1081
 G  fixed_segment_relative_order_1082
 G  fixed_segment_relative_order_1083
 G  fixed_segment_relative_order_1084
 L  original_T_including_depot_unload_1085
 L  arc_capacity_1086
 L  arc_capacity_1087
 L  arc_capacity_1088
 L  arc_capacity_1089
 L  arc_capacity_1090
 L  arc_capacity_1091
 L  arc_capacity_1092
 L  arc_capacity_1093
 L  arc_capacity_1094
 L  arc_capacity_1095
 L  arc_capacity_1096
 L  arc_capacity_1097
 L  arc_capacity_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 E  depot_departure_or_bypass_1329
 E  depot_return_or_bypass_1330
 E  out_degree_1331
 E  in_degree_1332
 G  order_active_lb_1333
 L  order_active_ub_1334
 E  segment_load_conservation_1335
 G  segment_prefix_lb_1336
 L  segment_prefix_ub_1337
 E  out_degree_1338
 E  in_degree_1339
 G  order_active_lb_1340
 L  order_active_ub_1341
 E  segment_load_conservation_1342
 G  segment_prefix_lb_1343
 L  segment_prefix_ub_1344
 E  out_degree_1345
 E  in_degree_1346
 G  order_active_lb_1347
 L  order_active_ub_1348
 E  segment_load_conservation_1349
 G  segment_prefix_lb_1350
 L  segment_prefix_ub_1351
 E  out_degree_1352
 E  in_degree_1353
 G  order_active_lb_1354
 L  order_active_ub_1355
 E  service_visit_def_1356
 E  free_load_conservation_1357
 E  out_degree_1358
 E  in_degree_1359
 G  order_active_lb_1360
 L  order_active_ub_1361
 E  service_visit_def_1362
 E  free_load_conservation_1363
 E  out_degree_1364
 E  in_degree_1365
 G  order_active_lb_1366
 L  order_active_ub_1367
 E  service_visit_def_1368
 E  free_load_conservation_1369
 E  out_degree_1370
 E  in_degree_1371
 G  order_active_lb_1372
 L  order_active_ub_1373
 E  service_visit_def_1374
 E  free_load_conservation_1375
 E  out_degree_1376
 E  in_degree_1377
 G  order_active_lb_1378
 L  order_active_ub_1379
 E  service_visit_def_1380
 E  free_load_conservation_1381
 E  out_degree_1382
 E  in_degree_1383
 G  order_active_lb_1384
 L  order_active_ub_1385
 E  service_visit_def_1386
 E  free_load_conservation_1387
 E  out_degree_1388
 E  in_degree_1389
 G  order_active_lb_1390
 L  order_active_ub_1391
 E  service_visit_def_1392
 E  free_load_conservation_1393
 E  out_degree_1394
 E  in_degree_1395
 G  order_active_lb_1396
 L  order_active_ub_1397
 E  service_visit_def_1398
 E  free_load_conservation_1399
 G  fixed_segment_relative_order_1400
 G  fixed_segment_relative_order_1401
 L  original_T_including_depot_unload_1402
COLUMNS
    t         normalized_mass_27_15  -1
    t         normalized_mass_25_28  -1
    t         normalized_mass_34_63  -1
    t         normalized_mass_23_74  -1
    t         normalized_mass_22_109  -1
    t         normalized_mass_26_130  -1
    t         normalized_mass_32_173  -1
    t         normalized_mass_31_200  -1
    t         normalization_261  2.3767857142857142e+01
    t         full_original_Gini_262  -7.7188095238095158e+01
    q         OBJ       1
    q         parent_nonstrict_scope_204  1
    q         full_original_Gini_262  35
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_0  -2.4551831644558458e-02
    x_27_0    product_ub_1  -4.2073628850530440e-02
    x_27_0    onehot_27_14  1
    x_27_0    parent_nonstrict_scope_204  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_0  1
    w_27_0    product_ub_1  1
    w_27_0    normalized_mass_27_15  1
    w_27_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_2  -2.4551831644558458e-02
    x_27_1    product_ub_3  -4.2073628850530440e-02
    x_27_1    onehot_27_14  1
    x_27_1    stock_lb_202  1
    x_27_1    stock_ub_203  1
    x_27_1    parent_nonstrict_scope_204  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_2  1
    w_27_1    product_ub_3  1
    w_27_1    normalized_mass_27_15  1
    w_27_1    normalized_ratio_27_16  -3.3333333333333331e-01
    w_27_1    full_original_Gini_262  -1.4767857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_4  -2.4551831644558458e-02
    x_27_2    product_ub_5  -4.2073628850530440e-02
    x_27_2    onehot_27_14  1
    x_27_2    stock_lb_202  2
    x_27_2    stock_ub_203  2
    x_27_2    parent_nonstrict_scope_204  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_4  1
    w_27_2    product_ub_5  1
    w_27_2    normalized_mass_27_15  1
    w_27_2    normalized_ratio_27_16  -6.6666666666666663e-01
    w_27_2    full_original_Gini_262  -6.7178571428571408e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_6  -2.4551831644558458e-02
    x_27_3    product_ub_7  -4.2073628850530440e-02
    x_27_3    onehot_27_14  1
    x_27_3    stock_lb_202  3
    x_27_3    stock_ub_203  3
    x_27_3    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_6  1
    w_27_3    product_ub_7  1
    w_27_3    normalized_mass_27_15  1
    w_27_3    normalized_ratio_27_16  -1
    w_27_3    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_8  -2.4551831644558458e-02
    x_27_4    product_ub_9  -4.2073628850530440e-02
    x_27_4    onehot_27_14  1
    x_27_4    stock_lb_202  4
    x_27_4    stock_ub_203  4
    x_27_4    parent_nonstrict_scope_204  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_8  1
    w_27_4    product_ub_9  1
    w_27_4    normalized_mass_27_15  1
    w_27_4    normalized_ratio_27_16  -1.3333333333333333e+00
    w_27_4    full_original_Gini_262  -1.2565476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_10  -2.4551831644558458e-02
    x_27_5    product_ub_11  -4.2073628850530440e-02
    x_27_5    onehot_27_14  1
    x_27_5    stock_lb_202  5
    x_27_5    stock_ub_203  5
    x_27_5    parent_nonstrict_scope_204  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_10  1
    w_27_5    product_ub_11  1
    w_27_5    normalized_mass_27_15  1
    w_27_5    normalized_ratio_27_16  -1.6666666666666665e+00
    w_27_5    full_original_Gini_262  -2.1232142857142854e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_12  -2.4551831644558458e-02
    x_27_6    product_ub_13  -4.2073628850530440e-02
    x_27_6    onehot_27_14  1
    x_27_6    stock_lb_202  6
    x_27_6    stock_ub_203  6
    x_27_6    parent_nonstrict_scope_204  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_12  1
    w_27_6    product_ub_13  1
    w_27_6    normalized_mass_27_15  1
    w_27_6    normalized_ratio_27_16  -2
    w_27_6    full_original_Gini_262  -3.0232142857142858e+01
    rho_27    normalized_ratio_27_16  1
    rho_27    block_pair_pos_235  -1
    rho_27    block_pair_neg_236  1
    rho_27    block_pair_pos_237  -1
    rho_27    block_pair_neg_238  1
    rho_27    block_pair_pos_239  -1
    rho_27    block_pair_neg_240  1
    rho_27    block_pair_pos_241  -1
    rho_27    block_pair_neg_242  1
    rho_27    block_pair_pos_243  -1
    rho_27    block_pair_neg_244  1
    rho_27    block_pair_pos_245  -1
    rho_27    block_pair_neg_246  1
    rho_27    block_pair_pos_247  -1
    rho_27    block_pair_neg_248  1
    rho_27    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_25_0    OBJ       3.7702488756363797e-03
    x_25_0    product_lb_17  -2.4551831644558458e-02
    x_25_0    product_ub_18  -4.2073628850530440e-02
    x_25_0    onehot_25_27  1
    x_25_0    parent_nonstrict_scope_204  7.5404977512727595e-03
    MARKER    'MARKER'                 'INTEND'
    w_25_0    product_lb_17  1
    w_25_0    product_ub_18  1
    w_25_0    normalized_mass_25_28  1
    w_25_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_1    product_lb_19  -2.4551831644558458e-02
    x_25_1    product_ub_20  -4.2073628850530440e-02
    x_25_1    onehot_25_27  1
    x_25_1    stock_lb_202  1
    x_25_1    stock_ub_203  1
    x_25_1    parent_nonstrict_scope_204  3.7702488756363797e-03
    x_25_1    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_1    product_lb_19  1
    w_25_1    product_ub_20  1
    w_25_1    normalized_mass_25_28  1
    w_25_1    normalized_ratio_25_29  -0.5
    w_25_1    full_original_Gini_262  -1.0467857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_2    OBJ       -3.7702488756363797e-03
    x_25_2    product_lb_21  -2.4551831644558458e-02
    x_25_2    product_ub_22  -4.2073628850530440e-02
    x_25_2    onehot_25_27  1
    x_25_2    stock_lb_202  2
    x_25_2    stock_ub_203  2
    x_25_2    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_2    product_lb_21  1
    w_25_2    product_ub_22  1
    w_25_2    normalized_mass_25_28  1
    w_25_2    normalized_ratio_25_29  -1
    w_25_2    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_3    product_lb_23  -2.4551831644558458e-02
    x_25_3    product_ub_24  -4.2073628850530440e-02
    x_25_3    onehot_25_27  1
    x_25_3    stock_lb_202  3
    x_25_3    stock_ub_203  3
    x_25_3    parent_nonstrict_scope_204  3.7702488756363797e-03
    x_25_3    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_3    product_lb_23  1
    w_25_3    product_ub_24  1
    w_25_3    normalized_mass_25_28  1
    w_25_3    normalized_ratio_25_29  -1.5
    w_25_3    full_original_Gini_262  -1.6732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_4    OBJ       3.7702488756363797e-03
    x_25_4    product_lb_25  -2.4551831644558458e-02
    x_25_4    product_ub_26  -4.2073628850530440e-02
    x_25_4    onehot_25_27  1
    x_25_4    stock_lb_202  4
    x_25_4    stock_ub_203  4
    x_25_4    parent_nonstrict_scope_204  7.5404977512727595e-03
    x_25_4    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_4    product_lb_25  1
    w_25_4    product_ub_26  1
    w_25_4    normalized_mass_25_28  1
    w_25_4    normalized_ratio_25_29  -2
    w_25_4    full_original_Gini_262  -3.0232142857142858e+01
    rho_25    normalized_ratio_25_29  1
    rho_25    block_pair_pos_219  -1
    rho_25    block_pair_neg_220  1
    rho_25    block_pair_pos_221  -1
    rho_25    block_pair_neg_222  1
    rho_25    block_pair_pos_223  -1
    rho_25    block_pair_neg_224  1
    rho_25    block_pair_pos_225  -1
    rho_25    block_pair_neg_226  1
    rho_25    block_pair_pos_227  -1
    rho_25    block_pair_neg_228  1
    rho_25    block_pair_pos_229  -1
    rho_25    block_pair_neg_230  1
    rho_25    block_pair_pos_239  1
    rho_25    block_pair_neg_240  -1
    rho_25    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_30  -2.4551831644558458e-02
    x_34_0    product_ub_31  -4.2073628850530440e-02
    x_34_0    onehot_34_62  1
    x_34_0    parent_nonstrict_scope_204  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_30  1
    w_34_0    product_ub_31  1
    w_34_0    normalized_mass_34_63  1
    w_34_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_32  -2.4551831644558458e-02
    x_34_1    product_ub_33  -4.2073628850530440e-02
    x_34_1    onehot_34_62  1
    x_34_1    stock_lb_202  1
    x_34_1    stock_ub_203  1
    x_34_1    parent_nonstrict_scope_204  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_32  1
    w_34_1    product_ub_33  1
    w_34_1    normalized_mass_34_63  1
    w_34_1    normalized_ratio_34_64  -0.125
    w_34_1    full_original_Gini_262  -2.0392857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_34  -2.4551831644558458e-02
    x_34_2    product_ub_35  -4.2073628850530440e-02
    x_34_2    onehot_34_62  1
    x_34_2    stock_lb_202  2
    x_34_2    stock_ub_203  2
    x_34_2    parent_nonstrict_scope_204  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_34  1
    w_34_2    product_ub_35  1
    w_34_2    normalized_mass_34_63  1
    w_34_2    normalized_ratio_34_64  -0.25
    w_34_2    full_original_Gini_262  -1.7017857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_36  -2.4551831644558458e-02
    x_34_3    product_ub_37  -4.2073628850530440e-02
    x_34_3    onehot_34_62  1
    x_34_3    stock_lb_202  3
    x_34_3    stock_ub_203  3
    x_34_3    parent_nonstrict_scope_204  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_36  1
    w_34_3    product_ub_37  1
    w_34_3    normalized_mass_34_63  1
    w_34_3    normalized_ratio_34_64  -0.375
    w_34_3    full_original_Gini_262  -1.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_38  -2.4551831644558458e-02
    x_34_4    product_ub_39  -4.2073628850530440e-02
    x_34_4    onehot_34_62  1
    x_34_4    stock_lb_202  4
    x_34_4    stock_ub_203  4
    x_34_4    parent_nonstrict_scope_204  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_38  1
    w_34_4    product_ub_39  1
    w_34_4    normalized_mass_34_63  1
    w_34_4    normalized_ratio_34_64  -0.5
    w_34_4    full_original_Gini_262  -1.0467857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_40  -2.4551831644558458e-02
    x_34_5    product_ub_41  -4.2073628850530440e-02
    x_34_5    onehot_34_62  1
    x_34_5    stock_lb_202  5
    x_34_5    stock_ub_203  5
    x_34_5    parent_nonstrict_scope_204  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_40  1
    w_34_5    product_ub_41  1
    w_34_5    normalized_mass_34_63  1
    w_34_5    normalized_ratio_34_64  -0.625
    w_34_5    full_original_Gini_262  -7.5928571428571416e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_42  -2.4551831644558458e-02
    x_34_6    product_ub_43  -4.2073628850530440e-02
    x_34_6    onehot_34_62  1
    x_34_6    stock_lb_202  6
    x_34_6    stock_ub_203  6
    x_34_6    parent_nonstrict_scope_204  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_42  1
    w_34_6    product_ub_43  1
    w_34_6    normalized_mass_34_63  1
    w_34_6    normalized_ratio_34_64  -0.75
    w_34_6    full_original_Gini_262  -5.2773809523809518e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_44  -2.4551831644558458e-02
    x_34_7    product_ub_45  -4.2073628850530440e-02
    x_34_7    onehot_34_62  1
    x_34_7    stock_lb_202  7
    x_34_7    stock_ub_203  7
    x_34_7    parent_nonstrict_scope_204  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_44  1
    w_34_7    product_ub_45  1
    w_34_7    normalized_mass_34_63  1
    w_34_7    normalized_ratio_34_64  -0.875
    w_34_7    full_original_Gini_262  -4.3571428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_46  -2.4551831644558458e-02
    x_34_8    product_ub_47  -4.2073628850530440e-02
    x_34_8    onehot_34_62  1
    x_34_8    stock_lb_202  8
    x_34_8    stock_ub_203  8
    x_34_8    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_46  1
    w_34_8    product_ub_47  1
    w_34_8    normalized_mass_34_63  1
    w_34_8    normalized_ratio_34_64  -1
    w_34_8    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_48  -2.4551831644558458e-02
    x_34_9    product_ub_49  -4.2073628850530440e-02
    x_34_9    onehot_34_62  1
    x_34_9    stock_lb_202  9
    x_34_9    stock_ub_203  9
    x_34_9    parent_nonstrict_scope_204  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_48  1
    w_34_9    product_ub_49  1
    w_34_9    normalized_mass_34_63  1
    w_34_9    normalized_ratio_34_64  -1.125
    w_34_9    full_original_Gini_262  -7.3571428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_50  -2.4551831644558458e-02
    x_34_10   product_ub_51  -4.2073628850530440e-02
    x_34_10   onehot_34_62  1
    x_34_10   stock_lb_202  10
    x_34_10   stock_ub_203  10
    x_34_10   parent_nonstrict_scope_204  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_50  1
    w_34_10   product_ub_51  1
    w_34_10   normalized_mass_34_63  1
    w_34_10   normalized_ratio_34_64  -1.25
    w_34_10   full_original_Gini_262  -1.0482142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_52  -2.4551831644558458e-02
    x_34_11   product_ub_53  -4.2073628850530440e-02
    x_34_11   onehot_34_62  1
    x_34_11   stock_lb_202  11
    x_34_11   stock_ub_203  11
    x_34_11   parent_nonstrict_scope_204  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_52  1
    w_34_11   product_ub_53  1
    w_34_11   normalized_mass_34_63  1
    w_34_11   normalized_ratio_34_64  -1.375
    w_34_11   full_original_Gini_262  -1.3607142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_54  -2.4551831644558458e-02
    x_34_12   product_ub_55  -4.2073628850530440e-02
    x_34_12   onehot_34_62  1
    x_34_12   stock_lb_202  12
    x_34_12   stock_ub_203  12
    x_34_12   parent_nonstrict_scope_204  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_54  1
    w_34_12   product_ub_55  1
    w_34_12   normalized_mass_34_63  1
    w_34_12   normalized_ratio_34_64  -1.5
    w_34_12   full_original_Gini_262  -1.6732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_56  -2.4551831644558458e-02
    x_34_13   product_ub_57  -4.2073628850530440e-02
    x_34_13   onehot_34_62  1
    x_34_13   stock_lb_202  13
    x_34_13   stock_ub_203  13
    x_34_13   parent_nonstrict_scope_204  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_56  1
    w_34_13   product_ub_57  1
    w_34_13   normalized_mass_34_63  1
    w_34_13   normalized_ratio_34_64  -1.625
    w_34_13   full_original_Gini_262  -2.0107142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_58  -2.4551831644558458e-02
    x_34_14   product_ub_59  -4.2073628850530440e-02
    x_34_14   onehot_34_62  1
    x_34_14   stock_lb_202  14
    x_34_14   stock_ub_203  14
    x_34_14   parent_nonstrict_scope_204  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_58  1
    w_34_14   product_ub_59  1
    w_34_14   normalized_mass_34_63  1
    w_34_14   normalized_ratio_34_64  -1.75
    w_34_14   full_original_Gini_262  -2.3482142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_60  -2.4551831644558458e-02
    x_34_15   product_ub_61  -4.2073628850530440e-02
    x_34_15   onehot_34_62  1
    x_34_15   stock_lb_202  15
    x_34_15   stock_ub_203  15
    x_34_15   parent_nonstrict_scope_204  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_60  1
    w_34_15   product_ub_61  1
    w_34_15   normalized_mass_34_63  1
    w_34_15   normalized_ratio_34_64  -1.875
    w_34_15   full_original_Gini_262  -2.6857142857142858e+01
    rho_34    normalized_ratio_34_64  1
    rho_34    block_pair_pos_229  1
    rho_34    block_pair_neg_230  -1
    rho_34    block_pair_pos_247  1
    rho_34    block_pair_neg_248  -1
    rho_34    block_pair_pos_251  -1
    rho_34    block_pair_neg_252  1
    rho_34    block_pair_pos_253  -1
    rho_34    block_pair_neg_254  1
    rho_34    block_pair_pos_255  -1
    rho_34    block_pair_neg_256  1
    rho_34    block_pair_pos_257  -1
    rho_34    block_pair_neg_258  1
    rho_34    block_pair_pos_259  -1
    rho_34    block_pair_neg_260  1
    rho_34    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_23_0    product_lb_65  -2.4551831644558458e-02
    x_23_0    product_ub_66  -4.2073628850530440e-02
    x_23_0    onehot_23_73  1
    x_23_0    parent_nonstrict_scope_204  7.5404977512727595e-03
    x_23_0    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_0    product_lb_65  1
    w_23_0    product_ub_66  1
    w_23_0    normalized_mass_23_74  1
    w_23_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_1    OBJ       -7.5404977512727595e-03
    x_23_1    product_lb_67  -2.4551831644558458e-02
    x_23_1    product_ub_68  -4.2073628850530440e-02
    x_23_1    onehot_23_73  1
    x_23_1    stock_lb_202  1
    x_23_1    stock_ub_203  1
    MARKER    'MARKER'                 'INTEND'
    w_23_1    product_lb_67  1
    w_23_1    product_ub_68  1
    w_23_1    normalized_mass_23_74  1
    w_23_1    normalized_ratio_23_75  -1
    w_23_1    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_2    product_lb_69  -2.4551831644558458e-02
    x_23_2    product_ub_70  -4.2073628850530440e-02
    x_23_2    onehot_23_73  1
    x_23_2    stock_lb_202  2
    x_23_2    stock_ub_203  2
    x_23_2    parent_nonstrict_scope_204  7.5404977512727595e-03
    x_23_2    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_2    product_lb_69  1
    w_23_2    product_ub_70  1
    w_23_2    normalized_mass_23_74  1
    w_23_2    normalized_ratio_23_75  -2
    w_23_2    full_original_Gini_262  -3.0232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_3    OBJ       7.5404977512727595e-03
    x_23_3    product_lb_71  -2.4551831644558458e-02
    x_23_3    product_ub_72  -4.2073628850530440e-02
    x_23_3    onehot_23_73  1
    x_23_3    stock_lb_202  3
    x_23_3    stock_ub_203  3
    x_23_3    parent_nonstrict_scope_204  1.5080995502545519e-02
    x_23_3    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_3    product_lb_71  1
    w_23_3    product_ub_72  1
    w_23_3    normalized_mass_23_74  1
    w_23_3    normalized_ratio_23_75  -3
    w_23_3    full_original_Gini_262  -5.7232142857142861e+01
    rho_23    normalized_ratio_23_75  1
    rho_23    block_pair_pos_211  -1
    rho_23    block_pair_neg_212  1
    rho_23    block_pair_pos_213  -1
    rho_23    block_pair_neg_214  1
    rho_23    block_pair_pos_215  -1
    rho_23    block_pair_neg_216  1
    rho_23    block_pair_pos_217  -1
    rho_23    block_pair_neg_218  1
    rho_23    block_pair_pos_221  1
    rho_23    block_pair_neg_222  -1
    rho_23    block_pair_pos_237  1
    rho_23    block_pair_neg_238  -1
    rho_23    block_pair_pos_253  1
    rho_23    block_pair_neg_254  -1
    rho_23    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_76  -2.4551831644558458e-02
    x_22_0    product_ub_77  -4.2073628850530440e-02
    x_22_0    onehot_22_108  1
    x_22_0    parent_nonstrict_scope_204  0.0456153362865944
    x_22_0    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_76  1
    w_22_0    product_ub_77  1
    w_22_0    normalized_mass_22_109  1
    w_22_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_78  -2.4551831644558458e-02
    x_22_1    product_ub_79  -4.2073628850530440e-02
    x_22_1    onehot_22_108  1
    x_22_1    stock_lb_202  1
    x_22_1    stock_ub_203  1
    x_22_1    parent_nonstrict_scope_204  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_78  1
    w_22_1    product_ub_79  1
    w_22_1    normalized_mass_22_109  1
    w_22_1    normalized_ratio_22_110  -1.4285714285714285e-01
    w_22_1    full_original_Gini_262  -1.9910714285714292e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_80  -2.4551831644558458e-02
    x_22_2    product_ub_81  -4.2073628850530440e-02
    x_22_2    onehot_22_108  1
    x_22_2    stock_lb_202  2
    x_22_2    stock_ub_203  2
    x_22_2    parent_nonstrict_scope_204  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_80  1
    w_22_2    product_ub_81  1
    w_22_2    normalized_mass_22_109  1
    w_22_2    normalized_ratio_22_110  -2.8571428571428570e-01
    w_22_2    full_original_Gini_262  -1.6053571428571420e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_82  -2.4551831644558458e-02
    x_22_3    product_ub_83  -4.2073628850530440e-02
    x_22_3    onehot_22_108  1
    x_22_3    stock_lb_202  3
    x_22_3    stock_ub_203  3
    x_22_3    parent_nonstrict_scope_204  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_82  1
    w_22_3    product_ub_83  1
    w_22_3    normalized_mass_22_109  1
    w_22_3    normalized_ratio_22_110  -4.2857142857142855e-01
    w_22_3    full_original_Gini_262  -1.2253571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_84  -2.4551831644558458e-02
    x_22_4    product_ub_85  -4.2073628850530440e-02
    x_22_4    onehot_22_108  1
    x_22_4    stock_lb_202  4
    x_22_4    stock_ub_203  4
    x_22_4    parent_nonstrict_scope_204  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_84  1
    w_22_4    product_ub_85  1
    w_22_4    normalized_mass_22_109  1
    w_22_4    normalized_ratio_22_110  -5.7142857142857140e-01
    w_22_4    full_original_Gini_262  -8.8250000000000028e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_86  -2.4551831644558458e-02
    x_22_5    product_ub_87  -4.2073628850530440e-02
    x_22_5    onehot_22_108  1
    x_22_5    stock_lb_202  5
    x_22_5    stock_ub_203  5
    x_22_5    parent_nonstrict_scope_204  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_86  1
    w_22_5    product_ub_87  1
    w_22_5    normalized_mass_22_109  1
    w_22_5    normalized_ratio_22_110  -7.1428571428571419e-01
    w_22_5    full_original_Gini_262  -5.8130952380952374e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_88  -2.4551831644558458e-02
    x_22_6    product_ub_89  -4.2073628850530440e-02
    x_22_6    onehot_22_108  1
    x_22_6    stock_lb_202  6
    x_22_6    stock_ub_203  6
    x_22_6    parent_nonstrict_scope_204  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_88  1
    w_22_6    product_ub_89  1
    w_22_6    normalized_mass_22_109  1
    w_22_6    normalized_ratio_22_110  -8.5714285714285710e-01
    w_22_6    full_original_Gini_262  -4.3749999999999991e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_90  -2.4551831644558458e-02
    x_22_7    product_ub_91  -4.2073628850530440e-02
    x_22_7    onehot_22_108  1
    x_22_7    stock_lb_202  7
    x_22_7    stock_ub_203  7
    x_22_7    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_90  1
    w_22_7    product_ub_91  1
    w_22_7    normalized_mass_22_109  1
    w_22_7    normalized_ratio_22_110  -1
    w_22_7    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_92  -2.4551831644558458e-02
    x_22_8    product_ub_93  -4.2073628850530440e-02
    x_22_8    onehot_22_108  1
    x_22_8    stock_lb_202  8
    x_22_8    stock_ub_203  8
    x_22_8    parent_nonstrict_scope_204  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_92  1
    w_22_8    product_ub_93  1
    w_22_8    normalized_mass_22_109  1
    w_22_8    normalized_ratio_22_110  -1.1428571428571428e+00
    w_22_8    full_original_Gini_262  -7.8035714285714235e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_94  -2.4551831644558458e-02
    x_22_9    product_ub_95  -4.2073628850530440e-02
    x_22_9    onehot_22_108  1
    x_22_9    stock_lb_202  9
    x_22_9    stock_ub_203  9
    x_22_9    parent_nonstrict_scope_204  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_94  1
    w_22_9    product_ub_95  1
    w_22_9    normalized_mass_22_109  1
    w_22_9    normalized_ratio_22_110  -1.2857142857142856e+00
    w_22_9    full_original_Gini_262  -1.1374999999999996e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_96  -2.4551831644558458e-02
    x_22_10   product_ub_97  -4.2073628850530440e-02
    x_22_10   onehot_22_108  1
    x_22_10   stock_lb_202  10
    x_22_10   stock_ub_203  10
    x_22_10   parent_nonstrict_scope_204  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_96  1
    w_22_10   product_ub_97  1
    w_22_10   normalized_mass_22_109  1
    w_22_10   normalized_ratio_22_110  -1.4285714285714284e+00
    w_22_10   full_original_Gini_262  -1.4946428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_98  -2.4551831644558458e-02
    x_22_11   product_ub_99  -4.2073628850530440e-02
    x_22_11   onehot_22_108  1
    x_22_11   stock_lb_202  11
    x_22_11   stock_ub_203  11
    x_22_11   parent_nonstrict_scope_204  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_98  1
    w_22_11   product_ub_99  1
    w_22_11   normalized_mass_22_109  1
    w_22_11   normalized_ratio_22_110  -1.5714285714285714e+00
    w_22_11   full_original_Gini_262  -1.8660714285714288e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_100  -2.4551831644558458e-02
    x_22_12   product_ub_101  -4.2073628850530440e-02
    x_22_12   onehot_22_108  1
    x_22_12   stock_lb_202  12
    x_22_12   stock_ub_203  12
    x_22_12   parent_nonstrict_scope_204  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_100  1
    w_22_12   product_ub_101  1
    w_22_12   normalized_mass_22_109  1
    w_22_12   normalized_ratio_22_110  -1.7142857142857142e+00
    w_22_12   full_original_Gini_262  -2.2517857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_102  -2.4551831644558458e-02
    x_22_13   product_ub_103  -4.2073628850530440e-02
    x_22_13   onehot_22_108  1
    x_22_13   stock_lb_202  13
    x_22_13   stock_ub_203  13
    x_22_13   parent_nonstrict_scope_204  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_102  1
    w_22_13   product_ub_103  1
    w_22_13   normalized_mass_22_109  1
    w_22_13   normalized_ratio_22_110  -1.8571428571428570e+00
    w_22_13   full_original_Gini_262  -26.375
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_104  -2.4551831644558458e-02
    x_22_14   product_ub_105  -4.2073628850530440e-02
    x_22_14   onehot_22_108  1
    x_22_14   stock_lb_202  14
    x_22_14   stock_ub_203  14
    x_22_14   parent_nonstrict_scope_204  0.0456153362865944
    x_22_14   unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_104  1
    w_22_14   product_ub_105  1
    w_22_14   normalized_mass_22_109  1
    w_22_14   normalized_ratio_22_110  -2
    w_22_14   full_original_Gini_262  -3.0232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_106  -2.4551831644558458e-02
    x_22_15   product_ub_107  -4.2073628850530440e-02
    x_22_15   onehot_22_108  1
    x_22_15   stock_lb_202  15
    x_22_15   stock_ub_203  15
    x_22_15   parent_nonstrict_scope_204  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_106  1
    w_22_15   product_ub_107  1
    w_22_15   normalized_mass_22_109  1
    w_22_15   normalized_ratio_22_110  -2.1428571428571428e+00
    w_22_15   full_original_Gini_262  -3.4089285714285715e+01
    rho_22    normalized_ratio_22_110  1
    rho_22    block_pair_pos_205  -1
    rho_22    block_pair_neg_206  1
    rho_22    block_pair_pos_207  -1
    rho_22    block_pair_neg_208  1
    rho_22    block_pair_pos_209  -1
    rho_22    block_pair_neg_210  1
    rho_22    block_pair_pos_211  1
    rho_22    block_pair_neg_212  -1
    rho_22    block_pair_pos_219  1
    rho_22    block_pair_neg_220  -1
    rho_22    block_pair_pos_235  1
    rho_22    block_pair_neg_236  -1
    rho_22    block_pair_pos_251  1
    rho_22    block_pair_neg_252  -1
    rho_22    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       7.4474103065332977e-03
    x_26_0    product_lb_111  -2.4551831644558458e-02
    x_26_0    product_ub_112  -4.2073628850530440e-02
    x_26_0    onehot_26_129  1
    x_26_0    parent_nonstrict_scope_204  1.4894820613066595e-02
    x_26_0    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_111  1
    w_26_0    product_ub_112  1
    w_26_0    normalized_mass_26_130  1
    w_26_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       3.7237051532666493e-03
    x_26_1    product_lb_113  -2.4551831644558458e-02
    x_26_1    product_ub_114  -4.2073628850530440e-02
    x_26_1    onehot_26_129  1
    x_26_1    stock_lb_202  1
    x_26_1    stock_ub_203  1
    x_26_1    parent_nonstrict_scope_204  1.1171115459799947e-02
    x_26_1    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_113  1
    w_26_1    product_ub_114  1
    w_26_1    normalized_mass_26_130  1
    w_26_1    normalized_ratio_26_131  -0.25
    w_26_1    full_original_Gini_262  -1.7017857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_115  -2.4551831644558458e-02
    x_26_2    product_ub_116  -4.2073628850530440e-02
    x_26_2    onehot_26_129  1
    x_26_2    stock_lb_202  2
    x_26_2    stock_ub_203  2
    x_26_2    parent_nonstrict_scope_204  7.4474103065332977e-03
    x_26_2    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_115  1
    w_26_2    product_ub_116  1
    w_26_2    normalized_mass_26_130  1
    w_26_2    normalized_ratio_26_131  -0.5
    w_26_2    full_original_Gini_262  -1.0467857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -3.7237051532666488e-03
    x_26_3    product_lb_117  -2.4551831644558458e-02
    x_26_3    product_ub_118  -4.2073628850530440e-02
    x_26_3    onehot_26_129  1
    x_26_3    stock_lb_202  3
    x_26_3    stock_ub_203  3
    x_26_3    parent_nonstrict_scope_204  3.7237051532666488e-03
    x_26_3    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_117  1
    w_26_3    product_ub_118  1
    w_26_3    normalized_mass_26_130  1
    w_26_3    normalized_ratio_26_131  -0.75
    w_26_3    full_original_Gini_262  -5.2773809523809518e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -7.4474103065332977e-03
    x_26_4    product_lb_119  -2.4551831644558458e-02
    x_26_4    product_ub_120  -4.2073628850530440e-02
    x_26_4    onehot_26_129  1
    x_26_4    stock_lb_202  4
    x_26_4    stock_ub_203  4
    x_26_4    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_119  1
    w_26_4    product_ub_120  1
    w_26_4    normalized_mass_26_130  1
    w_26_4    normalized_ratio_26_131  -1
    w_26_4    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -3.7237051532666488e-03
    x_26_5    product_lb_121  -2.4551831644558458e-02
    x_26_5    product_ub_122  -4.2073628850530440e-02
    x_26_5    onehot_26_129  1
    x_26_5    stock_lb_202  5
    x_26_5    stock_ub_203  5
    x_26_5    parent_nonstrict_scope_204  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_121  1
    w_26_5    product_ub_122  1
    w_26_5    normalized_mass_26_130  1
    w_26_5    normalized_ratio_26_131  -1.25
    w_26_5    full_original_Gini_262  -1.0482142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_123  -2.4551831644558458e-02
    x_26_6    product_ub_124  -4.2073628850530440e-02
    x_26_6    onehot_26_129  1
    x_26_6    stock_lb_202  6
    x_26_6    stock_ub_203  6
    x_26_6    parent_nonstrict_scope_204  7.4474103065332977e-03
    x_26_6    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_123  1
    w_26_6    product_ub_124  1
    w_26_6    normalized_mass_26_130  1
    w_26_6    normalized_ratio_26_131  -1.5
    w_26_6    full_original_Gini_262  -1.6732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       3.7237051532666493e-03
    x_26_7    product_lb_125  -2.4551831644558458e-02
    x_26_7    product_ub_126  -4.2073628850530440e-02
    x_26_7    onehot_26_129  1
    x_26_7    stock_lb_202  7
    x_26_7    stock_ub_203  7
    x_26_7    parent_nonstrict_scope_204  1.1171115459799947e-02
    x_26_7    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_125  1
    w_26_7    product_ub_126  1
    w_26_7    normalized_mass_26_130  1
    w_26_7    normalized_ratio_26_131  -1.75
    w_26_7    full_original_Gini_262  -2.3482142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       7.4474103065332977e-03
    x_26_8    product_lb_127  -2.4551831644558458e-02
    x_26_8    product_ub_128  -4.2073628850530440e-02
    x_26_8    onehot_26_129  1
    x_26_8    stock_lb_202  8
    x_26_8    stock_ub_203  8
    x_26_8    parent_nonstrict_scope_204  1.4894820613066595e-02
    x_26_8    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_127  1
    w_26_8    product_ub_128  1
    w_26_8    normalized_mass_26_130  1
    w_26_8    normalized_ratio_26_131  -2
    w_26_8    full_original_Gini_262  -3.0232142857142858e+01
    rho_26    normalized_ratio_26_131  1
    rho_26    block_pair_pos_205  1
    rho_26    block_pair_neg_206  -1
    rho_26    block_pair_pos_213  1
    rho_26    block_pair_neg_214  -1
    rho_26    block_pair_pos_223  1
    rho_26    block_pair_neg_224  -1
    rho_26    block_pair_pos_231  -1
    rho_26    block_pair_neg_232  1
    rho_26    block_pair_pos_233  -1
    rho_26    block_pair_neg_234  1
    rho_26    block_pair_pos_241  1
    rho_26    block_pair_neg_242  -1
    rho_26    block_pair_pos_255  1
    rho_26    block_pair_neg_256  -1
    rho_26    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       3.3513323338990042e-02
    x_32_0    product_lb_132  -2.4551831644558458e-02
    x_32_0    product_ub_133  -4.2073628850530440e-02
    x_32_0    onehot_32_172  1
    x_32_0    parent_nonstrict_scope_204  0.0754049775127276
    x_32_0    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_132  1
    w_32_0    product_ub_133  1
    w_32_0    normalized_mass_32_173  1
    w_32_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       2.5134992504242532e-02
    x_32_1    product_lb_134  -2.4551831644558458e-02
    x_32_1    product_ub_135  -4.2073628850530440e-02
    x_32_1    onehot_32_172  1
    x_32_1    stock_lb_202  1
    x_32_1    stock_ub_203  1
    x_32_1    parent_nonstrict_scope_204  6.7026646677980084e-02
    x_32_1    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_134  1
    w_32_1    product_ub_135  1
    w_32_1    normalized_mass_32_173  1
    w_32_1    normalized_ratio_32_174  -1.1111111111111110e-01
    w_32_1    full_original_Gini_262  -2.0767857142857146e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       1.6756661669495021e-02
    x_32_2    product_lb_136  -2.4551831644558458e-02
    x_32_2    product_ub_137  -4.2073628850530440e-02
    x_32_2    onehot_32_172  1
    x_32_2    stock_lb_202  2
    x_32_2    stock_ub_203  2
    x_32_2    parent_nonstrict_scope_204  5.8648315843232574e-02
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_136  1
    w_32_2    product_ub_137  1
    w_32_2    normalized_mass_32_173  1
    w_32_2    normalized_ratio_32_174  -2.2222222222222221e-01
    w_32_2    full_original_Gini_262  -1.7767857142857153e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       8.3783308347475174e-03
    x_32_3    product_lb_138  -2.4551831644558458e-02
    x_32_3    product_ub_139  -4.2073628850530440e-02
    x_32_3    onehot_32_172  1
    x_32_3    stock_lb_202  3
    x_32_3    stock_ub_203  3
    x_32_3    parent_nonstrict_scope_204  5.0269985008485070e-02
    x_32_3    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_138  1
    w_32_3    product_ub_139  1
    w_32_3    normalized_mass_32_173  1
    w_32_3    normalized_ratio_32_174  -3.3333333333333331e-01
    w_32_3    full_original_Gini_262  -1.4767857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_4    product_lb_140  -2.4551831644558458e-02
    x_32_4    product_ub_141  -4.2073628850530440e-02
    x_32_4    onehot_32_172  1
    x_32_4    stock_lb_202  4
    x_32_4    stock_ub_203  4
    x_32_4    parent_nonstrict_scope_204  4.1891654173737553e-02
    x_32_4    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_140  1
    w_32_4    product_ub_141  1
    w_32_4    normalized_mass_32_173  1
    w_32_4    normalized_ratio_32_174  -4.4444444444444442e-01
    w_32_4    full_original_Gini_262  -1.1856746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -0.00837833083474751
    x_32_5    product_lb_142  -2.4551831644558458e-02
    x_32_5    product_ub_143  -4.2073628850530440e-02
    x_32_5    onehot_32_172  1
    x_32_5    stock_lb_202  5
    x_32_5    stock_ub_203  5
    x_32_5    parent_nonstrict_scope_204  3.3513323338990042e-02
    x_32_5    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_142  1
    w_32_5    product_ub_143  1
    w_32_5    normalized_mass_32_173  1
    w_32_5    normalized_ratio_32_174  -5.5555555555555558e-01
    w_32_5    full_original_Gini_262  -9.1900793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -1.6756661669495018e-02
    x_32_6    product_lb_144  -2.4551831644558458e-02
    x_32_6    product_ub_145  -4.2073628850530440e-02
    x_32_6    onehot_32_172  1
    x_32_6    stock_lb_202  6
    x_32_6    stock_ub_203  6
    x_32_6    parent_nonstrict_scope_204  2.5134992504242535e-02
    x_32_6    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_144  1
    w_32_6    product_ub_145  1
    w_32_6    normalized_mass_32_173  1
    w_32_6    normalized_ratio_32_174  -6.6666666666666663e-01
    w_32_6    full_original_Gini_262  -6.7178571428571408e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -2.5134992504242525e-02
    x_32_7    product_lb_146  -2.4551831644558458e-02
    x_32_7    product_ub_147  -4.2073628850530440e-02
    x_32_7    onehot_32_172  1
    x_32_7    stock_lb_202  7
    x_32_7    stock_ub_203  7
    x_32_7    parent_nonstrict_scope_204  1.6756661669495028e-02
    x_32_7    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_146  1
    w_32_7    product_ub_147  1
    w_32_7    normalized_mass_32_173  1
    w_32_7    normalized_ratio_32_174  -7.7777777777777768e-01
    w_32_7    full_original_Gini_262  -4.9718253968253974e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.3513323338990042e-02
    x_32_8    product_lb_148  -2.4551831644558458e-02
    x_32_8    product_ub_149  -4.2073628850530440e-02
    x_32_8    onehot_32_172  1
    x_32_8    stock_lb_202  8
    x_32_8    stock_ub_203  8
    x_32_8    parent_nonstrict_scope_204  8.3783308347475140e-03
    x_32_8    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_148  1
    w_32_8    product_ub_149  1
    w_32_8    normalized_mass_32_173  1
    w_32_8    normalized_ratio_32_174  -8.8888888888888884e-01
    w_32_8    full_original_Gini_262  -4.3432539682539684e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       -4.1891654173737553e-02
    x_32_9    product_lb_150  -2.4551831644558458e-02
    x_32_9    product_ub_151  -4.2073628850530440e-02
    x_32_9    onehot_32_172  1
    x_32_9    stock_lb_202  9
    x_32_9    stock_ub_203  9
    x_32_9    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_150  1
    w_32_9    product_ub_151  1
    w_32_9    normalized_mass_32_173  1
    w_32_9    normalized_ratio_32_174  -1
    w_32_9    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       -3.3513323338990042e-02
    x_32_10   product_lb_152  -2.4551831644558458e-02
    x_32_10   product_ub_153  -4.2073628850530440e-02
    x_32_10   onehot_32_172  1
    x_32_10   stock_lb_202  10
    x_32_10   stock_ub_203  10
    x_32_10   parent_nonstrict_scope_204  8.3783308347475140e-03
    x_32_10   unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_152  1
    w_32_10   product_ub_153  1
    w_32_10   normalized_mass_32_173  1
    w_32_10   normalized_ratio_32_174  -1.1111111111111112e+00
    w_32_10   full_original_Gini_262  -7.0099206349206327e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       -2.5134992504242542e-02
    x_32_11   product_lb_154  -2.4551831644558458e-02
    x_32_11   product_ub_155  -4.2073628850530440e-02
    x_32_11   onehot_32_172  1
    x_32_11   stock_lb_202  11
    x_32_11   stock_ub_203  11
    x_32_11   parent_nonstrict_scope_204  1.6756661669495011e-02
    x_32_11   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_154  1
    w_32_11   product_ub_155  1
    w_32_11   normalized_mass_32_173  1
    w_32_11   normalized_ratio_32_174  -1.2222222222222221e+00
    w_32_11   full_original_Gini_262  -9.7876984126984112e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       -1.6756661669495028e-02
    x_32_12   product_lb_156  -2.4551831644558458e-02
    x_32_12   product_ub_157  -4.2073628850530440e-02
    x_32_12   onehot_32_172  1
    x_32_12   stock_lb_202  12
    x_32_12   stock_ub_203  12
    x_32_12   parent_nonstrict_scope_204  2.5134992504242525e-02
    x_32_12   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_156  1
    w_32_12   product_ub_157  1
    w_32_12   normalized_mass_32_173  1
    w_32_12   normalized_ratio_32_174  -1.3333333333333333e+00
    w_32_12   full_original_Gini_262  -1.2565476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_13   OBJ       -0.00837833083474751
    x_32_13   product_lb_158  -2.4551831644558458e-02
    x_32_13   product_ub_159  -4.2073628850530440e-02
    x_32_13   onehot_32_172  1
    x_32_13   stock_lb_202  13
    x_32_13   stock_ub_203  13
    x_32_13   parent_nonstrict_scope_204  3.3513323338990042e-02
    x_32_13   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_13   product_lb_158  1
    w_32_13   product_ub_159  1
    w_32_13   normalized_mass_32_173  1
    w_32_13   normalized_ratio_32_174  -1.4444444444444444e+00
    w_32_13   full_original_Gini_262  -1.5343253968253972e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_14   OBJ       -1.3877787807814457e-17
    x_32_14   product_lb_160  -2.4551831644558458e-02
    x_32_14   product_ub_161  -4.2073628850530440e-02
    x_32_14   onehot_32_172  1
    x_32_14   stock_lb_202  14
    x_32_14   stock_ub_203  14
    x_32_14   parent_nonstrict_scope_204  4.1891654173737539e-02
    x_32_14   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_14   product_lb_160  1
    w_32_14   product_ub_161  1
    w_32_14   normalized_mass_32_173  1
    w_32_14   normalized_ratio_32_174  -1.5555555555555554e+00
    w_32_14   full_original_Gini_262  -1.8232142857142854e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_15   OBJ       8.3783308347474966e-03
    x_32_15   product_lb_162  -2.4551831644558458e-02
    x_32_15   product_ub_163  -4.2073628850530440e-02
    x_32_15   onehot_32_172  1
    x_32_15   stock_lb_202  15
    x_32_15   stock_ub_203  15
    x_32_15   parent_nonstrict_scope_204  5.0269985008485049e-02
    x_32_15   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_15   product_lb_162  1
    w_32_15   product_ub_163  1
    w_32_15   normalized_mass_32_173  1
    w_32_15   normalized_ratio_32_174  -1.6666666666666665e+00
    w_32_15   full_original_Gini_262  -2.1232142857142854e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_16   OBJ       1.6756661669495014e-02
    x_32_16   product_lb_164  -2.4551831644558458e-02
    x_32_16   product_ub_165  -4.2073628850530440e-02
    x_32_16   onehot_32_172  1
    x_32_16   stock_lb_202  16
    x_32_16   stock_ub_203  16
    x_32_16   parent_nonstrict_scope_204  5.8648315843232567e-02
    x_32_16   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_16   product_lb_164  1
    w_32_16   product_ub_165  1
    w_32_16   normalized_mass_32_173  1
    w_32_16   normalized_ratio_32_174  -1.7777777777777777e+00
    w_32_16   full_original_Gini_262  -2.4232142857142865e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_17   OBJ       2.5134992504242532e-02
    x_32_17   product_lb_166  -2.4551831644558458e-02
    x_32_17   product_ub_167  -4.2073628850530440e-02
    x_32_17   onehot_32_172  1
    x_32_17   stock_lb_202  17
    x_32_17   stock_ub_203  17
    x_32_17   parent_nonstrict_scope_204  6.7026646677980084e-02
    x_32_17   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_17   product_lb_166  1
    w_32_17   product_ub_167  1
    w_32_17   normalized_mass_32_173  1
    w_32_17   normalized_ratio_32_174  -1.8888888888888888e+00
    w_32_17   full_original_Gini_262  -2.7232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_18   OBJ       3.3513323338990042e-02
    x_32_18   product_lb_168  -2.4551831644558458e-02
    x_32_18   product_ub_169  -4.2073628850530440e-02
    x_32_18   onehot_32_172  1
    x_32_18   stock_lb_202  18
    x_32_18   stock_ub_203  18
    x_32_18   parent_nonstrict_scope_204  0.0754049775127276
    x_32_18   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_18   product_lb_168  1
    w_32_18   product_ub_169  1
    w_32_18   normalized_mass_32_173  1
    w_32_18   normalized_ratio_32_174  -2
    w_32_18   full_original_Gini_262  -3.0232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_19   OBJ       4.1891654173737553e-02
    x_32_19   product_lb_170  -2.4551831644558458e-02
    x_32_19   product_ub_171  -4.2073628850530440e-02
    x_32_19   onehot_32_172  1
    x_32_19   stock_lb_202  19
    x_32_19   stock_ub_203  19
    x_32_19   parent_nonstrict_scope_204  0.0837833083474751
    x_32_19   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_19   product_lb_170  1
    w_32_19   product_ub_171  1
    w_32_19   normalized_mass_32_173  1
    w_32_19   normalized_ratio_32_174  -2.1111111111111112e+00
    w_32_19   full_original_Gini_262  -3.3232142857142854e+01
    rho_32    normalized_ratio_32_174  1
    rho_32    block_pair_pos_209  1
    rho_32    block_pair_neg_210  -1
    rho_32    block_pair_pos_217  1
    rho_32    block_pair_neg_218  -1
    rho_32    block_pair_pos_227  1
    rho_32    block_pair_neg_228  -1
    rho_32    block_pair_pos_233  1
    rho_32    block_pair_neg_234  -1
    rho_32    block_pair_pos_245  1
    rho_32    block_pair_neg_246  -1
    rho_32    block_pair_pos_249  -1
    rho_32    block_pair_neg_250  1
    rho_32    block_pair_pos_259  1
    rho_32    block_pair_neg_260  -1
    rho_32    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       1.6756644912833352e-02
    x_31_0    product_lb_175  -2.4551831644558458e-02
    x_31_0    product_ub_176  -4.2073628850530440e-02
    x_31_0    onehot_31_199  1
    x_31_0    parent_nonstrict_scope_204  0.0335132898256667
    x_31_0    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_175  1
    w_31_0    product_ub_176  1
    w_31_0    normalized_mass_31_200  1
    w_31_0    full_original_Gini_262  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       1.1171096608555569e-02
    x_31_1    product_lb_177  -2.4551831644558458e-02
    x_31_1    product_ub_178  -4.2073628850530440e-02
    x_31_1    onehot_31_199  1
    x_31_1    stock_lb_202  1
    x_31_1    stock_ub_203  1
    x_31_1    parent_nonstrict_scope_204  2.7927741521388921e-02
    x_31_1    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_177  1
    w_31_1    product_ub_178  1
    w_31_1    normalized_mass_31_200  1
    w_31_1    normalized_ratio_31_201  -1.6666666666666666e-01
    w_31_1    full_original_Gini_262  -1.9267857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       5.5855483042777862e-03
    x_31_2    product_lb_179  -2.4551831644558458e-02
    x_31_2    product_ub_180  -4.2073628850530440e-02
    x_31_2    onehot_31_199  1
    x_31_2    stock_lb_202  2
    x_31_2    stock_ub_203  2
    x_31_2    parent_nonstrict_scope_204  2.2342193217111138e-02
    x_31_2    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_179  1
    w_31_2    product_ub_180  1
    w_31_2    normalized_mass_31_200  1
    w_31_2    normalized_ratio_31_201  -3.3333333333333331e-01
    w_31_2    full_original_Gini_262  -1.4767857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    product_lb_181  -2.4551831644558458e-02
    x_31_3    product_ub_182  -4.2073628850530440e-02
    x_31_3    onehot_31_199  1
    x_31_3    stock_lb_202  3
    x_31_3    stock_ub_203  3
    x_31_3    parent_nonstrict_scope_204  1.6756644912833352e-02
    x_31_3    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_181  1
    w_31_3    product_ub_182  1
    w_31_3    normalized_mass_31_200  1
    w_31_3    normalized_ratio_31_201  -0.5
    w_31_3    full_original_Gini_262  -1.0467857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.5855483042777827e-03
    x_31_4    product_lb_183  -2.4551831644558458e-02
    x_31_4    product_ub_184  -4.2073628850530440e-02
    x_31_4    onehot_31_199  1
    x_31_4    stock_lb_202  4
    x_31_4    stock_ub_203  4
    x_31_4    parent_nonstrict_scope_204  1.1171096608555569e-02
    x_31_4    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_183  1
    w_31_4    product_ub_184  1
    w_31_4    normalized_mass_31_200  1
    w_31_4    normalized_ratio_31_201  -6.6666666666666663e-01
    w_31_4    full_original_Gini_262  -6.7178571428571408e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.1171096608555565e-02
    x_31_5    product_lb_185  -2.4551831644558458e-02
    x_31_5    product_ub_186  -4.2073628850530440e-02
    x_31_5    onehot_31_199  1
    x_31_5    stock_lb_202  5
    x_31_5    stock_ub_203  5
    x_31_5    parent_nonstrict_scope_204  5.5855483042777862e-03
    x_31_5    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_185  1
    w_31_5    product_ub_186  1
    w_31_5    normalized_mass_31_200  1
    w_31_5    normalized_ratio_31_201  -8.3333333333333326e-01
    w_31_5    full_original_Gini_262  -4.49404761904762
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -1.6756644912833352e-02
    x_31_6    product_lb_187  -2.4551831644558458e-02
    x_31_6    product_ub_188  -4.2073628850530440e-02
    x_31_6    onehot_31_199  1
    x_31_6    stock_lb_202  6
    x_31_6    stock_ub_203  6
    x_31_6    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_187  1
    w_31_6    product_ub_188  1
    w_31_6    normalized_mass_31_200  1
    w_31_6    normalized_ratio_31_201  -1
    w_31_6    full_original_Gini_262  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -1.1171096608555572e-02
    x_31_7    product_lb_189  -2.4551831644558458e-02
    x_31_7    product_ub_190  -4.2073628850530440e-02
    x_31_7    onehot_31_199  1
    x_31_7    stock_lb_202  7
    x_31_7    stock_ub_203  7
    x_31_7    parent_nonstrict_scope_204  5.5855483042777793e-03
    x_31_7    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_189  1
    w_31_7    product_ub_190  1
    w_31_7    normalized_mass_31_200  1
    w_31_7    normalized_ratio_31_201  -1.1666666666666665e+00
    w_31_7    full_original_Gini_262  -8.3988095238095166e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -5.5855483042777862e-03
    x_31_8    product_lb_191  -2.4551831644558458e-02
    x_31_8    product_ub_192  -4.2073628850530440e-02
    x_31_8    onehot_31_199  1
    x_31_8    stock_lb_202  8
    x_31_8    stock_ub_203  8
    x_31_8    parent_nonstrict_scope_204  1.1171096608555565e-02
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_191  1
    w_31_8    product_ub_192  1
    w_31_8    normalized_mass_31_200  1
    w_31_8    normalized_ratio_31_201  -1.3333333333333333e+00
    w_31_8    full_original_Gini_262  -1.2565476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_9    product_lb_193  -2.4551831644558458e-02
    x_31_9    product_ub_194  -4.2073628850530440e-02
    x_31_9    onehot_31_199  1
    x_31_9    stock_lb_202  9
    x_31_9    stock_ub_203  9
    x_31_9    parent_nonstrict_scope_204  1.6756644912833352e-02
    x_31_9    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_193  1
    w_31_9    product_ub_194  1
    w_31_9    normalized_mass_31_200  1
    w_31_9    normalized_ratio_31_201  -1.5
    w_31_9    full_original_Gini_262  -1.6732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       5.5855483042777793e-03
    x_31_10   product_lb_195  -2.4551831644558458e-02
    x_31_10   product_ub_196  -4.2073628850530440e-02
    x_31_10   onehot_31_199  1
    x_31_10   stock_lb_202  10
    x_31_10   stock_ub_203  10
    x_31_10   parent_nonstrict_scope_204  2.2342193217111131e-02
    x_31_10   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_195  1
    w_31_10   product_ub_196  1
    w_31_10   normalized_mass_31_200  1
    w_31_10   normalized_ratio_31_201  -1.6666666666666665e+00
    w_31_10   full_original_Gini_262  -2.1232142857142854e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       1.1171096608555565e-02
    x_31_11   product_lb_197  -2.4551831644558458e-02
    x_31_11   product_ub_198  -4.2073628850530440e-02
    x_31_11   onehot_31_199  1
    x_31_11   stock_lb_202  11
    x_31_11   stock_ub_203  11
    x_31_11   parent_nonstrict_scope_204  2.7927741521388917e-02
    x_31_11   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_197  1
    w_31_11   product_ub_198  1
    w_31_11   normalized_mass_31_200  1
    w_31_11   normalized_ratio_31_201  -1.8333333333333333e+00
    w_31_11   full_original_Gini_262  -2.5732142857142854e+01
    rho_31    normalized_ratio_31_201  1
    rho_31    block_pair_pos_207  1
    rho_31    block_pair_neg_208  -1
    rho_31    block_pair_pos_215  1
    rho_31    block_pair_neg_216  -1
    rho_31    block_pair_pos_225  1
    rho_31    block_pair_neg_226  -1
    rho_31    block_pair_pos_231  1
    rho_31    block_pair_neg_232  -1
    rho_31    block_pair_pos_243  1
    rho_31    block_pair_neg_244  -1
    rho_31    block_pair_pos_249  1
    rho_31    block_pair_neg_250  -1
    rho_31    block_pair_pos_257  1
    rho_31    block_pair_neg_258  -1
    rho_31    normalization_261  1
    a_27_25   block_pair_pos_239  1
    a_27_25   block_pair_neg_240  1
    a_27_25   full_original_Gini_262  -1
    a_27_34   block_pair_pos_247  1
    a_27_34   block_pair_neg_248  1
    a_27_34   full_original_Gini_262  -1
    a_27_23   block_pair_pos_237  1
    a_27_23   block_pair_neg_238  1
    a_27_23   full_original_Gini_262  -1
    a_27_22   block_pair_pos_235  1
    a_27_22   block_pair_neg_236  1
    a_27_22   full_original_Gini_262  -1
    a_27_26   block_pair_pos_241  1
    a_27_26   block_pair_neg_242  1
    a_27_26   full_original_Gini_262  -1
    a_27_32   block_pair_pos_245  1
    a_27_32   block_pair_neg_246  1
    a_27_32   full_original_Gini_262  -1
    a_27_31   block_pair_pos_243  1
    a_27_31   block_pair_neg_244  1
    a_27_31   full_original_Gini_262  -1
    a_25_34   block_pair_pos_229  1
    a_25_34   block_pair_neg_230  1
    a_25_34   full_original_Gini_262  -1
    a_25_23   block_pair_pos_221  1
    a_25_23   block_pair_neg_222  1
    a_25_23   full_original_Gini_262  -1
    a_25_22   block_pair_pos_219  1
    a_25_22   block_pair_neg_220  1
    a_25_22   full_original_Gini_262  -1
    a_25_26   block_pair_pos_223  1
    a_25_26   block_pair_neg_224  1
    a_25_26   full_original_Gini_262  -1
    a_25_32   block_pair_pos_227  1
    a_25_32   block_pair_neg_228  1
    a_25_32   full_original_Gini_262  -1
    a_25_31   block_pair_pos_225  1
    a_25_31   block_pair_neg_226  1
    a_25_31   full_original_Gini_262  -1
    a_34_23   block_pair_pos_253  1
    a_34_23   block_pair_neg_254  1
    a_34_23   full_original_Gini_262  -1
    a_34_22   block_pair_pos_251  1
    a_34_22   block_pair_neg_252  1
    a_34_22   full_original_Gini_262  -1
    a_34_26   block_pair_pos_255  1
    a_34_26   block_pair_neg_256  1
    a_34_26   full_original_Gini_262  -1
    a_34_32   block_pair_pos_259  1
    a_34_32   block_pair_neg_260  1
    a_34_32   full_original_Gini_262  -1
    a_34_31   block_pair_pos_257  1
    a_34_31   block_pair_neg_258  1
    a_34_31   full_original_Gini_262  -1
    a_23_22   block_pair_pos_211  1
    a_23_22   block_pair_neg_212  1
    a_23_22   full_original_Gini_262  -1
    a_23_26   block_pair_pos_213  1
    a_23_26   block_pair_neg_214  1
    a_23_26   full_original_Gini_262  -1
    a_23_32   block_pair_pos_217  1
    a_23_32   block_pair_neg_218  1
    a_23_32   full_original_Gini_262  -1
    a_23_31   block_pair_pos_215  1
    a_23_31   block_pair_neg_216  1
    a_23_31   full_original_Gini_262  -1
    a_22_26   block_pair_pos_205  1
    a_22_26   block_pair_neg_206  1
    a_22_26   full_original_Gini_262  -1
    a_22_32   block_pair_pos_209  1
    a_22_32   block_pair_neg_210  1
    a_22_32   full_original_Gini_262  -1
    a_22_31   block_pair_pos_207  1
    a_22_31   block_pair_neg_208  1
    a_22_31   full_original_Gini_262  -1
    a_26_32   block_pair_pos_233  1
    a_26_32   block_pair_neg_234  1
    a_26_32   full_original_Gini_262  -1
    a_26_31   block_pair_pos_231  1
    a_26_31   block_pair_neg_232  1
    a_26_31   full_original_Gini_262  -1
    a_32_31   block_pair_pos_249  1
    a_32_31   block_pair_neg_250  1
    a_32_31   full_original_Gini_262  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_27_1  unique_nonzero_owner_263  1
    service_0_27_1  service_visit_def_667  1
    service_0_27_1  free_load_conservation_668  1
    service_0_27_2  unique_nonzero_owner_264  1
    service_0_27_2  service_visit_def_667  1
    service_0_27_2  free_load_conservation_668  2
    service_0_27_3  unique_nonzero_owner_265  1
    service_0_27_3  service_visit_def_667  1
    service_0_27_3  free_load_conservation_668  3
    service_0_27_4  unique_nonzero_owner_266  1
    service_0_27_4  service_visit_def_667  1
    service_0_27_4  free_load_conservation_668  4
    service_0_27_5  unique_nonzero_owner_267  1
    service_0_27_5  service_visit_def_667  1
    service_0_27_5  free_load_conservation_668  5
    service_0_27_6  unique_nonzero_owner_268  1
    service_0_27_6  service_visit_def_667  1
    service_0_27_6  free_load_conservation_668  6
    service_1_27_1  unique_nonzero_owner_263  1
    service_1_27_1  service_visit_def_1038  1
    service_1_27_1  free_load_conservation_1039  1
    service_1_27_2  unique_nonzero_owner_264  1
    service_1_27_2  service_visit_def_1038  1
    service_1_27_2  free_load_conservation_1039  2
    service_1_27_3  unique_nonzero_owner_265  1
    service_1_27_3  service_visit_def_1038  1
    service_1_27_3  free_load_conservation_1039  3
    service_1_27_4  unique_nonzero_owner_266  1
    service_1_27_4  service_visit_def_1038  1
    service_1_27_4  free_load_conservation_1039  4
    service_1_27_5  unique_nonzero_owner_267  1
    service_1_27_5  service_visit_def_1038  1
    service_1_27_5  free_load_conservation_1039  5
    service_1_27_6  unique_nonzero_owner_268  1
    service_1_27_6  service_visit_def_1038  1
    service_1_27_6  free_load_conservation_1039  6
    service_2_27_1  unique_nonzero_owner_263  1
    service_2_27_1  service_visit_def_1356  1
    service_2_27_1  free_load_conservation_1357  1
    service_2_27_2  unique_nonzero_owner_264  1
    service_2_27_2  service_visit_def_1356  1
    service_2_27_2  free_load_conservation_1357  2
    service_2_27_3  unique_nonzero_owner_265  1
    service_2_27_3  service_visit_def_1356  1
    service_2_27_3  free_load_conservation_1357  3
    service_2_27_4  unique_nonzero_owner_266  1
    service_2_27_4  service_visit_def_1356  1
    service_2_27_4  free_load_conservation_1357  4
    service_2_27_5  unique_nonzero_owner_267  1
    service_2_27_5  service_visit_def_1356  1
    service_2_27_5  free_load_conservation_1357  5
    service_2_27_6  unique_nonzero_owner_268  1
    service_2_27_6  service_visit_def_1356  1
    service_2_27_6  free_load_conservation_1357  6
    service_0_25_1  unique_nonzero_owner_269  1
    service_0_25_1  service_visit_def_673  1
    service_0_25_1  free_load_conservation_674  1
    service_0_25_2  unique_nonzero_owner_270  1
    service_0_25_2  service_visit_def_673  1
    service_0_25_2  free_load_conservation_674  2
    service_0_25_3  unique_nonzero_owner_271  1
    service_0_25_3  service_visit_def_673  1
    service_0_25_3  free_load_conservation_674  3
    service_0_25_4  unique_nonzero_owner_272  1
    service_0_25_4  service_visit_def_673  1
    service_0_25_4  free_load_conservation_674  4
    service_1_25_1  unique_nonzero_owner_269  1
    service_1_25_1  service_visit_def_1044  1
    service_1_25_1  free_load_conservation_1045  1
    service_1_25_2  unique_nonzero_owner_270  1
    service_1_25_2  service_visit_def_1044  1
    service_1_25_2  free_load_conservation_1045  2
    service_1_25_3  unique_nonzero_owner_271  1
    service_1_25_3  service_visit_def_1044  1
    service_1_25_3  free_load_conservation_1045  3
    service_1_25_4  unique_nonzero_owner_272  1
    service_1_25_4  service_visit_def_1044  1
    service_1_25_4  free_load_conservation_1045  4
    service_2_25_1  unique_nonzero_owner_269  1
    service_2_25_1  service_visit_def_1362  1
    service_2_25_1  free_load_conservation_1363  1
    service_2_25_2  unique_nonzero_owner_270  1
    service_2_25_2  service_visit_def_1362  1
    service_2_25_2  free_load_conservation_1363  2
    service_2_25_3  unique_nonzero_owner_271  1
    service_2_25_3  service_visit_def_1362  1
    service_2_25_3  free_load_conservation_1363  3
    service_2_25_4  unique_nonzero_owner_272  1
    service_2_25_4  service_visit_def_1362  1
    service_2_25_4  free_load_conservation_1363  4
    service_0_34_0  unique_nonzero_owner_273  1
    service_0_34_0  service_visit_def_679  1
    service_0_34_0  free_load_conservation_680  -2
    service_0_34_0  original_T_including_depot_unload_714  240
    service_0_34_1  unique_nonzero_owner_274  1
    service_0_34_1  service_visit_def_679  1
    service_0_34_1  free_load_conservation_680  -1
    service_0_34_1  original_T_including_depot_unload_714  120
    service_0_34_3  unique_nonzero_owner_275  1
    service_0_34_3  service_visit_def_679  1
    service_0_34_3  free_load_conservation_680  1
    service_0_34_4  unique_nonzero_owner_276  1
    service_0_34_4  service_visit_def_679  1
    service_0_34_4  free_load_conservation_680  2
    service_0_34_5  unique_nonzero_owner_277  1
    service_0_34_5  service_visit_def_679  1
    service_0_34_5  free_load_conservation_680  3
    service_0_34_6  unique_nonzero_owner_278  1
    service_0_34_6  service_visit_def_679  1
    service_0_34_6  free_load_conservation_680  4
    service_0_34_7  unique_nonzero_owner_279  1
    service_0_34_7  service_visit_def_679  1
    service_0_34_7  free_load_conservation_680  5
    service_0_34_8  unique_nonzero_owner_280  1
    service_0_34_8  service_visit_def_679  1
    service_0_34_8  free_load_conservation_680  6
    service_0_34_9  unique_nonzero_owner_281  1
    service_0_34_9  service_visit_def_679  1
    service_0_34_9  free_load_conservation_680  7
    service_0_34_10  unique_nonzero_owner_282  1
    service_0_34_10  service_visit_def_679  1
    service_0_34_10  free_load_conservation_680  8
    service_0_34_11  unique_nonzero_owner_283  1
    service_0_34_11  service_visit_def_679  1
    service_0_34_11  free_load_conservation_680  9
    service_0_34_12  unique_nonzero_owner_284  1
    service_0_34_12  service_visit_def_679  1
    service_0_34_12  free_load_conservation_680  10
    service_0_34_13  unique_nonzero_owner_285  1
    service_0_34_13  service_visit_def_679  1
    service_0_34_13  free_load_conservation_680  11
    service_0_34_14  unique_nonzero_owner_286  1
    service_0_34_14  service_visit_def_679  1
    service_0_34_14  free_load_conservation_680  12
    service_0_34_15  unique_nonzero_owner_287  1
    service_0_34_15  service_visit_def_679  1
    service_0_34_15  free_load_conservation_680  13
    service_1_34_0  unique_nonzero_owner_273  1
    service_1_34_0  service_visit_def_1050  1
    service_1_34_0  free_load_conservation_1051  -2
    service_1_34_0  original_T_including_depot_unload_1085  240
    service_1_34_1  unique_nonzero_owner_274  1
    service_1_34_1  service_visit_def_1050  1
    service_1_34_1  free_load_conservation_1051  -1
    service_1_34_1  original_T_including_depot_unload_1085  120
    service_1_34_3  unique_nonzero_owner_275  1
    service_1_34_3  service_visit_def_1050  1
    service_1_34_3  free_load_conservation_1051  1
    service_1_34_4  unique_nonzero_owner_276  1
    service_1_34_4  service_visit_def_1050  1
    service_1_34_4  free_load_conservation_1051  2
    service_1_34_5  unique_nonzero_owner_277  1
    service_1_34_5  service_visit_def_1050  1
    service_1_34_5  free_load_conservation_1051  3
    service_1_34_6  unique_nonzero_owner_278  1
    service_1_34_6  service_visit_def_1050  1
    service_1_34_6  free_load_conservation_1051  4
    service_1_34_7  unique_nonzero_owner_279  1
    service_1_34_7  service_visit_def_1050  1
    service_1_34_7  free_load_conservation_1051  5
    service_1_34_8  unique_nonzero_owner_280  1
    service_1_34_8  service_visit_def_1050  1
    service_1_34_8  free_load_conservation_1051  6
    service_1_34_9  unique_nonzero_owner_281  1
    service_1_34_9  service_visit_def_1050  1
    service_1_34_9  free_load_conservation_1051  7
    service_1_34_10  unique_nonzero_owner_282  1
    service_1_34_10  service_visit_def_1050  1
    service_1_34_10  free_load_conservation_1051  8
    service_1_34_11  unique_nonzero_owner_283  1
    service_1_34_11  service_visit_def_1050  1
    service_1_34_11  free_load_conservation_1051  9
    service_1_34_12  unique_nonzero_owner_284  1
    service_1_34_12  service_visit_def_1050  1
    service_1_34_12  free_load_conservation_1051  10
    service_1_34_13  unique_nonzero_owner_285  1
    service_1_34_13  service_visit_def_1050  1
    service_1_34_13  free_load_conservation_1051  11
    service_1_34_14  unique_nonzero_owner_286  1
    service_1_34_14  service_visit_def_1050  1
    service_1_34_14  free_load_conservation_1051  12
    service_1_34_15  unique_nonzero_owner_287  1
    service_1_34_15  service_visit_def_1050  1
    service_1_34_15  free_load_conservation_1051  13
    service_2_34_0  unique_nonzero_owner_273  1
    service_2_34_0  service_visit_def_1368  1
    service_2_34_0  free_load_conservation_1369  -2
    service_2_34_0  original_T_including_depot_unload_1402  240
    service_2_34_1  unique_nonzero_owner_274  1
    service_2_34_1  service_visit_def_1368  1
    service_2_34_1  free_load_conservation_1369  -1
    service_2_34_1  original_T_including_depot_unload_1402  120
    service_2_34_3  unique_nonzero_owner_275  1
    service_2_34_3  service_visit_def_1368  1
    service_2_34_3  free_load_conservation_1369  1
    service_2_34_4  unique_nonzero_owner_276  1
    service_2_34_4  service_visit_def_1368  1
    service_2_34_4  free_load_conservation_1369  2
    service_2_34_5  unique_nonzero_owner_277  1
    service_2_34_5  service_visit_def_1368  1
    service_2_34_5  free_load_conservation_1369  3
    service_2_34_6  unique_nonzero_owner_278  1
    service_2_34_6  service_visit_def_1368  1
    service_2_34_6  free_load_conservation_1369  4
    service_2_34_7  unique_nonzero_owner_279  1
    service_2_34_7  service_visit_def_1368  1
    service_2_34_7  free_load_conservation_1369  5
    service_2_34_8  unique_nonzero_owner_280  1
    service_2_34_8  service_visit_def_1368  1
    service_2_34_8  free_load_conservation_1369  6
    service_2_34_9  unique_nonzero_owner_281  1
    service_2_34_9  service_visit_def_1368  1
    service_2_34_9  free_load_conservation_1369  7
    service_2_34_10  unique_nonzero_owner_282  1
    service_2_34_10  service_visit_def_1368  1
    service_2_34_10  free_load_conservation_1369  8
    service_2_34_11  unique_nonzero_owner_283  1
    service_2_34_11  service_visit_def_1368  1
    service_2_34_11  free_load_conservation_1369  9
    service_2_34_12  unique_nonzero_owner_284  1
    service_2_34_12  service_visit_def_1368  1
    service_2_34_12  free_load_conservation_1369  10
    service_2_34_13  unique_nonzero_owner_285  1
    service_2_34_13  service_visit_def_1368  1
    service_2_34_13  free_load_conservation_1369  11
    service_2_34_14  unique_nonzero_owner_286  1
    service_2_34_14  service_visit_def_1368  1
    service_2_34_14  free_load_conservation_1369  12
    service_2_34_15  unique_nonzero_owner_287  1
    service_2_34_15  service_visit_def_1368  1
    service_2_34_15  free_load_conservation_1369  13
    service_0_23_0  unique_nonzero_owner_288  1
    service_0_23_0  service_visit_def_685  1
    service_0_23_0  free_load_conservation_686  -1
    service_0_23_0  original_T_including_depot_unload_714  120
    service_0_23_2  unique_nonzero_owner_289  1
    service_0_23_2  service_visit_def_685  1
    service_0_23_2  free_load_conservation_686  1
    service_0_23_3  unique_nonzero_owner_290  1
    service_0_23_3  service_visit_def_685  1
    service_0_23_3  free_load_conservation_686  2
    service_1_23_0  unique_nonzero_owner_288  1
    service_1_23_0  service_visit_def_1056  1
    service_1_23_0  free_load_conservation_1057  -1
    service_1_23_0  original_T_including_depot_unload_1085  120
    service_1_23_2  unique_nonzero_owner_289  1
    service_1_23_2  service_visit_def_1056  1
    service_1_23_2  free_load_conservation_1057  1
    service_1_23_3  unique_nonzero_owner_290  1
    service_1_23_3  service_visit_def_1056  1
    service_1_23_3  free_load_conservation_1057  2
    service_2_23_0  unique_nonzero_owner_288  1
    service_2_23_0  service_visit_def_1374  1
    service_2_23_0  free_load_conservation_1375  -1
    service_2_23_0  original_T_including_depot_unload_1402  120
    service_2_23_2  unique_nonzero_owner_289  1
    service_2_23_2  service_visit_def_1374  1
    service_2_23_2  free_load_conservation_1375  1
    service_2_23_3  unique_nonzero_owner_290  1
    service_2_23_3  service_visit_def_1374  1
    service_2_23_3  free_load_conservation_1375  2
    service_0_22_0  unique_nonzero_owner_291  1
    service_0_22_0  service_visit_def_691  1
    service_0_22_0  free_load_conservation_692  -2
    service_0_22_0  original_T_including_depot_unload_714  240
    service_0_22_1  unique_nonzero_owner_292  1
    service_0_22_1  service_visit_def_691  1
    service_0_22_1  free_load_conservation_692  -1
    service_0_22_1  original_T_including_depot_unload_714  120
    service_0_22_3  unique_nonzero_owner_293  1
    service_0_22_3  service_visit_def_691  1
    service_0_22_3  free_load_conservation_692  1
    service_0_22_4  unique_nonzero_owner_294  1
    service_0_22_4  service_visit_def_691  1
    service_0_22_4  free_load_conservation_692  2
    service_0_22_5  unique_nonzero_owner_295  1
    service_0_22_5  service_visit_def_691  1
    service_0_22_5  free_load_conservation_692  3
    service_0_22_6  unique_nonzero_owner_296  1
    service_0_22_6  service_visit_def_691  1
    service_0_22_6  free_load_conservation_692  4
    service_0_22_7  unique_nonzero_owner_297  1
    service_0_22_7  service_visit_def_691  1
    service_0_22_7  free_load_conservation_692  5
    service_0_22_8  unique_nonzero_owner_298  1
    service_0_22_8  service_visit_def_691  1
    service_0_22_8  free_load_conservation_692  6
    service_0_22_9  unique_nonzero_owner_299  1
    service_0_22_9  service_visit_def_691  1
    service_0_22_9  free_load_conservation_692  7
    service_0_22_10  unique_nonzero_owner_300  1
    service_0_22_10  service_visit_def_691  1
    service_0_22_10  free_load_conservation_692  8
    service_0_22_11  unique_nonzero_owner_301  1
    service_0_22_11  service_visit_def_691  1
    service_0_22_11  free_load_conservation_692  9
    service_0_22_12  unique_nonzero_owner_302  1
    service_0_22_12  service_visit_def_691  1
    service_0_22_12  free_load_conservation_692  10
    service_0_22_13  unique_nonzero_owner_303  1
    service_0_22_13  service_visit_def_691  1
    service_0_22_13  free_load_conservation_692  11
    service_0_22_14  unique_nonzero_owner_304  1
    service_0_22_14  service_visit_def_691  1
    service_0_22_14  free_load_conservation_692  12
    service_0_22_15  unique_nonzero_owner_305  1
    service_0_22_15  service_visit_def_691  1
    service_0_22_15  free_load_conservation_692  13
    service_1_22_0  unique_nonzero_owner_291  1
    service_1_22_0  service_visit_def_1062  1
    service_1_22_0  free_load_conservation_1063  -2
    service_1_22_0  original_T_including_depot_unload_1085  240
    service_1_22_1  unique_nonzero_owner_292  1
    service_1_22_1  service_visit_def_1062  1
    service_1_22_1  free_load_conservation_1063  -1
    service_1_22_1  original_T_including_depot_unload_1085  120
    service_1_22_3  unique_nonzero_owner_293  1
    service_1_22_3  service_visit_def_1062  1
    service_1_22_3  free_load_conservation_1063  1
    service_1_22_4  unique_nonzero_owner_294  1
    service_1_22_4  service_visit_def_1062  1
    service_1_22_4  free_load_conservation_1063  2
    service_1_22_5  unique_nonzero_owner_295  1
    service_1_22_5  service_visit_def_1062  1
    service_1_22_5  free_load_conservation_1063  3
    service_1_22_6  unique_nonzero_owner_296  1
    service_1_22_6  service_visit_def_1062  1
    service_1_22_6  free_load_conservation_1063  4
    service_1_22_7  unique_nonzero_owner_297  1
    service_1_22_7  service_visit_def_1062  1
    service_1_22_7  free_load_conservation_1063  5
    service_1_22_8  unique_nonzero_owner_298  1
    service_1_22_8  service_visit_def_1062  1
    service_1_22_8  free_load_conservation_1063  6
    service_1_22_9  unique_nonzero_owner_299  1
    service_1_22_9  service_visit_def_1062  1
    service_1_22_9  free_load_conservation_1063  7
    service_1_22_10  unique_nonzero_owner_300  1
    service_1_22_10  service_visit_def_1062  1
    service_1_22_10  free_load_conservation_1063  8
    service_1_22_11  unique_nonzero_owner_301  1
    service_1_22_11  service_visit_def_1062  1
    service_1_22_11  free_load_conservation_1063  9
    service_1_22_12  unique_nonzero_owner_302  1
    service_1_22_12  service_visit_def_1062  1
    service_1_22_12  free_load_conservation_1063  10
    service_1_22_13  unique_nonzero_owner_303  1
    service_1_22_13  service_visit_def_1062  1
    service_1_22_13  free_load_conservation_1063  11
    service_1_22_14  unique_nonzero_owner_304  1
    service_1_22_14  service_visit_def_1062  1
    service_1_22_14  free_load_conservation_1063  12
    service_1_22_15  unique_nonzero_owner_305  1
    service_1_22_15  service_visit_def_1062  1
    service_1_22_15  free_load_conservation_1063  13
    service_2_22_0  unique_nonzero_owner_291  1
    service_2_22_0  service_visit_def_1380  1
    service_2_22_0  free_load_conservation_1381  -2
    service_2_22_0  original_T_including_depot_unload_1402  240
    service_2_22_1  unique_nonzero_owner_292  1
    service_2_22_1  service_visit_def_1380  1
    service_2_22_1  free_load_conservation_1381  -1
    service_2_22_1  original_T_including_depot_unload_1402  120
    service_2_22_3  unique_nonzero_owner_293  1
    service_2_22_3  service_visit_def_1380  1
    service_2_22_3  free_load_conservation_1381  1
    service_2_22_4  unique_nonzero_owner_294  1
    service_2_22_4  service_visit_def_1380  1
    service_2_22_4  free_load_conservation_1381  2
    service_2_22_5  unique_nonzero_owner_295  1
    service_2_22_5  service_visit_def_1380  1
    service_2_22_5  free_load_conservation_1381  3
    service_2_22_6  unique_nonzero_owner_296  1
    service_2_22_6  service_visit_def_1380  1
    service_2_22_6  free_load_conservation_1381  4
    service_2_22_7  unique_nonzero_owner_297  1
    service_2_22_7  service_visit_def_1380  1
    service_2_22_7  free_load_conservation_1381  5
    service_2_22_8  unique_nonzero_owner_298  1
    service_2_22_8  service_visit_def_1380  1
    service_2_22_8  free_load_conservation_1381  6
    service_2_22_9  unique_nonzero_owner_299  1
    service_2_22_9  service_visit_def_1380  1
    service_2_22_9  free_load_conservation_1381  7
    service_2_22_10  unique_nonzero_owner_300  1
    service_2_22_10  service_visit_def_1380  1
    service_2_22_10  free_load_conservation_1381  8
    service_2_22_11  unique_nonzero_owner_301  1
    service_2_22_11  service_visit_def_1380  1
    service_2_22_11  free_load_conservation_1381  9
    service_2_22_12  unique_nonzero_owner_302  1
    service_2_22_12  service_visit_def_1380  1
    service_2_22_12  free_load_conservation_1381  10
    service_2_22_13  unique_nonzero_owner_303  1
    service_2_22_13  service_visit_def_1380  1
    service_2_22_13  free_load_conservation_1381  11
    service_2_22_14  unique_nonzero_owner_304  1
    service_2_22_14  service_visit_def_1380  1
    service_2_22_14  free_load_conservation_1381  12
    service_2_22_15  unique_nonzero_owner_305  1
    service_2_22_15  service_visit_def_1380  1
    service_2_22_15  free_load_conservation_1381  13
    service_0_26_0  unique_nonzero_owner_306  1
    service_0_26_0  service_visit_def_697  1
    service_0_26_0  free_load_conservation_698  -5
    service_0_26_0  original_T_including_depot_unload_714  600
    service_0_26_1  unique_nonzero_owner_307  1
    service_0_26_1  service_visit_def_697  1
    service_0_26_1  free_load_conservation_698  -4
    service_0_26_1  original_T_including_depot_unload_714  480
    service_0_26_2  unique_nonzero_owner_308  1
    service_0_26_2  service_visit_def_697  1
    service_0_26_2  free_load_conservation_698  -3
    service_0_26_2  original_T_including_depot_unload_714  360
    service_0_26_3  unique_nonzero_owner_309  1
    service_0_26_3  service_visit_def_697  1
    service_0_26_3  free_load_conservation_698  -2
    service_0_26_3  original_T_including_depot_unload_714  240
    service_0_26_4  unique_nonzero_owner_310  1
    service_0_26_4  service_visit_def_697  1
    service_0_26_4  free_load_conservation_698  -1
    service_0_26_4  original_T_including_depot_unload_714  120
    service_0_26_6  unique_nonzero_owner_311  1
    service_0_26_6  service_visit_def_697  1
    service_0_26_6  free_load_conservation_698  1
    service_0_26_7  unique_nonzero_owner_312  1
    service_0_26_7  service_visit_def_697  1
    service_0_26_7  free_load_conservation_698  2
    service_0_26_8  unique_nonzero_owner_313  1
    service_0_26_8  service_visit_def_697  1
    service_0_26_8  free_load_conservation_698  3
    service_1_26_0  unique_nonzero_owner_306  1
    service_1_26_0  service_visit_def_1068  1
    service_1_26_0  free_load_conservation_1069  -5
    service_1_26_0  original_T_including_depot_unload_1085  600
    service_1_26_1  unique_nonzero_owner_307  1
    service_1_26_1  service_visit_def_1068  1
    service_1_26_1  free_load_conservation_1069  -4
    service_1_26_1  original_T_including_depot_unload_1085  480
    service_1_26_2  unique_nonzero_owner_308  1
    service_1_26_2  service_visit_def_1068  1
    service_1_26_2  free_load_conservation_1069  -3
    service_1_26_2  original_T_including_depot_unload_1085  360
    service_1_26_3  unique_nonzero_owner_309  1
    service_1_26_3  service_visit_def_1068  1
    service_1_26_3  free_load_conservation_1069  -2
    service_1_26_3  original_T_including_depot_unload_1085  240
    service_1_26_4  unique_nonzero_owner_310  1
    service_1_26_4  service_visit_def_1068  1
    service_1_26_4  free_load_conservation_1069  -1
    service_1_26_4  original_T_including_depot_unload_1085  120
    service_1_26_6  unique_nonzero_owner_311  1
    service_1_26_6  service_visit_def_1068  1
    service_1_26_6  free_load_conservation_1069  1
    service_1_26_7  unique_nonzero_owner_312  1
    service_1_26_7  service_visit_def_1068  1
    service_1_26_7  free_load_conservation_1069  2
    service_1_26_8  unique_nonzero_owner_313  1
    service_1_26_8  service_visit_def_1068  1
    service_1_26_8  free_load_conservation_1069  3
    service_2_26_0  unique_nonzero_owner_306  1
    service_2_26_0  service_visit_def_1386  1
    service_2_26_0  free_load_conservation_1387  -5
    service_2_26_0  original_T_including_depot_unload_1402  600
    service_2_26_1  unique_nonzero_owner_307  1
    service_2_26_1  service_visit_def_1386  1
    service_2_26_1  free_load_conservation_1387  -4
    service_2_26_1  original_T_including_depot_unload_1402  480
    service_2_26_2  unique_nonzero_owner_308  1
    service_2_26_2  service_visit_def_1386  1
    service_2_26_2  free_load_conservation_1387  -3
    service_2_26_2  original_T_including_depot_unload_1402  360
    service_2_26_3  unique_nonzero_owner_309  1
    service_2_26_3  service_visit_def_1386  1
    service_2_26_3  free_load_conservation_1387  -2
    service_2_26_3  original_T_including_depot_unload_1402  240
    service_2_26_4  unique_nonzero_owner_310  1
    service_2_26_4  service_visit_def_1386  1
    service_2_26_4  free_load_conservation_1387  -1
    service_2_26_4  original_T_including_depot_unload_1402  120
    service_2_26_6  unique_nonzero_owner_311  1
    service_2_26_6  service_visit_def_1386  1
    service_2_26_6  free_load_conservation_1387  1
    service_2_26_7  unique_nonzero_owner_312  1
    service_2_26_7  service_visit_def_1386  1
    service_2_26_7  free_load_conservation_1387  2
    service_2_26_8  unique_nonzero_owner_313  1
    service_2_26_8  service_visit_def_1386  1
    service_2_26_8  free_load_conservation_1387  3
    service_0_32_0  unique_nonzero_owner_314  1
    service_0_32_0  service_visit_def_703  1
    service_0_32_0  free_load_conservation_704  -2
    service_0_32_0  original_T_including_depot_unload_714  240
    service_0_32_1  unique_nonzero_owner_315  1
    service_0_32_1  service_visit_def_703  1
    service_0_32_1  free_load_conservation_704  -1
    service_0_32_1  original_T_including_depot_unload_714  120
    service_0_32_3  unique_nonzero_owner_316  1
    service_0_32_3  service_visit_def_703  1
    service_0_32_3  free_load_conservation_704  1
    service_0_32_4  unique_nonzero_owner_317  1
    service_0_32_4  service_visit_def_703  1
    service_0_32_4  free_load_conservation_704  2
    service_0_32_5  unique_nonzero_owner_318  1
    service_0_32_5  service_visit_def_703  1
    service_0_32_5  free_load_conservation_704  3
    service_0_32_6  unique_nonzero_owner_319  1
    service_0_32_6  service_visit_def_703  1
    service_0_32_6  free_load_conservation_704  4
    service_0_32_7  unique_nonzero_owner_320  1
    service_0_32_7  service_visit_def_703  1
    service_0_32_7  free_load_conservation_704  5
    service_0_32_8  unique_nonzero_owner_321  1
    service_0_32_8  service_visit_def_703  1
    service_0_32_8  free_load_conservation_704  6
    service_0_32_9  unique_nonzero_owner_322  1
    service_0_32_9  service_visit_def_703  1
    service_0_32_9  free_load_conservation_704  7
    service_0_32_10  unique_nonzero_owner_323  1
    service_0_32_10  service_visit_def_703  1
    service_0_32_10  free_load_conservation_704  8
    service_0_32_11  unique_nonzero_owner_324  1
    service_0_32_11  service_visit_def_703  1
    service_0_32_11  free_load_conservation_704  9
    service_0_32_12  unique_nonzero_owner_325  1
    service_0_32_12  service_visit_def_703  1
    service_0_32_12  free_load_conservation_704  10
    service_0_32_13  unique_nonzero_owner_326  1
    service_0_32_13  service_visit_def_703  1
    service_0_32_13  free_load_conservation_704  11
    service_0_32_14  unique_nonzero_owner_327  1
    service_0_32_14  service_visit_def_703  1
    service_0_32_14  free_load_conservation_704  12
    service_0_32_15  unique_nonzero_owner_328  1
    service_0_32_15  service_visit_def_703  1
    service_0_32_15  free_load_conservation_704  13
    service_0_32_16  unique_nonzero_owner_329  1
    service_0_32_16  service_visit_def_703  1
    service_0_32_16  free_load_conservation_704  14
    service_0_32_17  unique_nonzero_owner_330  1
    service_0_32_17  service_visit_def_703  1
    service_0_32_17  free_load_conservation_704  15
    service_0_32_18  unique_nonzero_owner_331  1
    service_0_32_18  service_visit_def_703  1
    service_0_32_18  free_load_conservation_704  16
    service_0_32_19  unique_nonzero_owner_332  1
    service_0_32_19  service_visit_def_703  1
    service_0_32_19  free_load_conservation_704  17
    service_1_32_0  unique_nonzero_owner_314  1
    service_1_32_0  service_visit_def_1074  1
    service_1_32_0  free_load_conservation_1075  -2
    service_1_32_0  original_T_including_depot_unload_1085  240
    service_1_32_1  unique_nonzero_owner_315  1
    service_1_32_1  service_visit_def_1074  1
    service_1_32_1  free_load_conservation_1075  -1
    service_1_32_1  original_T_including_depot_unload_1085  120
    service_1_32_3  unique_nonzero_owner_316  1
    service_1_32_3  service_visit_def_1074  1
    service_1_32_3  free_load_conservation_1075  1
    service_1_32_4  unique_nonzero_owner_317  1
    service_1_32_4  service_visit_def_1074  1
    service_1_32_4  free_load_conservation_1075  2
    service_1_32_5  unique_nonzero_owner_318  1
    service_1_32_5  service_visit_def_1074  1
    service_1_32_5  free_load_conservation_1075  3
    service_1_32_6  unique_nonzero_owner_319  1
    service_1_32_6  service_visit_def_1074  1
    service_1_32_6  free_load_conservation_1075  4
    service_1_32_7  unique_nonzero_owner_320  1
    service_1_32_7  service_visit_def_1074  1
    service_1_32_7  free_load_conservation_1075  5
    service_1_32_8  unique_nonzero_owner_321  1
    service_1_32_8  service_visit_def_1074  1
    service_1_32_8  free_load_conservation_1075  6
    service_1_32_9  unique_nonzero_owner_322  1
    service_1_32_9  service_visit_def_1074  1
    service_1_32_9  free_load_conservation_1075  7
    service_1_32_10  unique_nonzero_owner_323  1
    service_1_32_10  service_visit_def_1074  1
    service_1_32_10  free_load_conservation_1075  8
    service_1_32_11  unique_nonzero_owner_324  1
    service_1_32_11  service_visit_def_1074  1
    service_1_32_11  free_load_conservation_1075  9
    service_1_32_12  unique_nonzero_owner_325  1
    service_1_32_12  service_visit_def_1074  1
    service_1_32_12  free_load_conservation_1075  10
    service_1_32_13  unique_nonzero_owner_326  1
    service_1_32_13  service_visit_def_1074  1
    service_1_32_13  free_load_conservation_1075  11
    service_1_32_14  unique_nonzero_owner_327  1
    service_1_32_14  service_visit_def_1074  1
    service_1_32_14  free_load_conservation_1075  12
    service_1_32_15  unique_nonzero_owner_328  1
    service_1_32_15  service_visit_def_1074  1
    service_1_32_15  free_load_conservation_1075  13
    service_1_32_16  unique_nonzero_owner_329  1
    service_1_32_16  service_visit_def_1074  1
    service_1_32_16  free_load_conservation_1075  14
    service_1_32_17  unique_nonzero_owner_330  1
    service_1_32_17  service_visit_def_1074  1
    service_1_32_17  free_load_conservation_1075  15
    service_1_32_18  unique_nonzero_owner_331  1
    service_1_32_18  service_visit_def_1074  1
    service_1_32_18  free_load_conservation_1075  16
    service_1_32_19  unique_nonzero_owner_332  1
    service_1_32_19  service_visit_def_1074  1
    service_1_32_19  free_load_conservation_1075  17
    service_2_32_0  unique_nonzero_owner_314  1
    service_2_32_0  service_visit_def_1392  1
    service_2_32_0  free_load_conservation_1393  -2
    service_2_32_0  original_T_including_depot_unload_1402  240
    service_2_32_1  unique_nonzero_owner_315  1
    service_2_32_1  service_visit_def_1392  1
    service_2_32_1  free_load_conservation_1393  -1
    service_2_32_1  original_T_including_depot_unload_1402  120
    service_2_32_3  unique_nonzero_owner_316  1
    service_2_32_3  service_visit_def_1392  1
    service_2_32_3  free_load_conservation_1393  1
    service_2_32_4  unique_nonzero_owner_317  1
    service_2_32_4  service_visit_def_1392  1
    service_2_32_4  free_load_conservation_1393  2
    service_2_32_5  unique_nonzero_owner_318  1
    service_2_32_5  service_visit_def_1392  1
    service_2_32_5  free_load_conservation_1393  3
    service_2_32_6  unique_nonzero_owner_319  1
    service_2_32_6  service_visit_def_1392  1
    service_2_32_6  free_load_conservation_1393  4
    service_2_32_7  unique_nonzero_owner_320  1
    service_2_32_7  service_visit_def_1392  1
    service_2_32_7  free_load_conservation_1393  5
    service_2_32_8  unique_nonzero_owner_321  1
    service_2_32_8  service_visit_def_1392  1
    service_2_32_8  free_load_conservation_1393  6
    service_2_32_9  unique_nonzero_owner_322  1
    service_2_32_9  service_visit_def_1392  1
    service_2_32_9  free_load_conservation_1393  7
    service_2_32_10  unique_nonzero_owner_323  1
    service_2_32_10  service_visit_def_1392  1
    service_2_32_10  free_load_conservation_1393  8
    service_2_32_11  unique_nonzero_owner_324  1
    service_2_32_11  service_visit_def_1392  1
    service_2_32_11  free_load_conservation_1393  9
    service_2_32_12  unique_nonzero_owner_325  1
    service_2_32_12  service_visit_def_1392  1
    service_2_32_12  free_load_conservation_1393  10
    service_2_32_13  unique_nonzero_owner_326  1
    service_2_32_13  service_visit_def_1392  1
    service_2_32_13  free_load_conservation_1393  11
    service_2_32_14  unique_nonzero_owner_327  1
    service_2_32_14  service_visit_def_1392  1
    service_2_32_14  free_load_conservation_1393  12
    service_2_32_15  unique_nonzero_owner_328  1
    service_2_32_15  service_visit_def_1392  1
    service_2_32_15  free_load_conservation_1393  13
    service_2_32_16  unique_nonzero_owner_329  1
    service_2_32_16  service_visit_def_1392  1
    service_2_32_16  free_load_conservation_1393  14
    service_2_32_17  unique_nonzero_owner_330  1
    service_2_32_17  service_visit_def_1392  1
    service_2_32_17  free_load_conservation_1393  15
    service_2_32_18  unique_nonzero_owner_331  1
    service_2_32_18  service_visit_def_1392  1
    service_2_32_18  free_load_conservation_1393  16
    service_2_32_19  unique_nonzero_owner_332  1
    service_2_32_19  service_visit_def_1392  1
    service_2_32_19  free_load_conservation_1393  17
    service_0_31_0  unique_nonzero_owner_333  1
    service_0_31_0  service_visit_def_709  1
    service_0_31_0  free_load_conservation_710  -8
    service_0_31_0  original_T_including_depot_unload_714  960
    service_0_31_1  unique_nonzero_owner_334  1
    service_0_31_1  service_visit_def_709  1
    service_0_31_1  free_load_conservation_710  -7
    service_0_31_1  original_T_including_depot_unload_714  840
    service_0_31_2  unique_nonzero_owner_335  1
    service_0_31_2  service_visit_def_709  1
    service_0_31_2  free_load_conservation_710  -6
    service_0_31_2  original_T_including_depot_unload_714  720
    service_0_31_3  unique_nonzero_owner_336  1
    service_0_31_3  service_visit_def_709  1
    service_0_31_3  free_load_conservation_710  -5
    service_0_31_3  original_T_including_depot_unload_714  600
    service_0_31_4  unique_nonzero_owner_337  1
    service_0_31_4  service_visit_def_709  1
    service_0_31_4  free_load_conservation_710  -4
    service_0_31_4  original_T_including_depot_unload_714  480
    service_0_31_5  unique_nonzero_owner_338  1
    service_0_31_5  service_visit_def_709  1
    service_0_31_5  free_load_conservation_710  -3
    service_0_31_5  original_T_including_depot_unload_714  360
    service_0_31_6  unique_nonzero_owner_339  1
    service_0_31_6  service_visit_def_709  1
    service_0_31_6  free_load_conservation_710  -2
    service_0_31_6  original_T_including_depot_unload_714  240
    service_0_31_7  unique_nonzero_owner_340  1
    service_0_31_7  service_visit_def_709  1
    service_0_31_7  free_load_conservation_710  -1
    service_0_31_7  original_T_including_depot_unload_714  120
    service_0_31_9  unique_nonzero_owner_341  1
    service_0_31_9  service_visit_def_709  1
    service_0_31_9  free_load_conservation_710  1
    service_0_31_10  unique_nonzero_owner_342  1
    service_0_31_10  service_visit_def_709  1
    service_0_31_10  free_load_conservation_710  2
    service_0_31_11  unique_nonzero_owner_343  1
    service_0_31_11  service_visit_def_709  1
    service_0_31_11  free_load_conservation_710  3
    service_1_31_0  unique_nonzero_owner_333  1
    service_1_31_0  service_visit_def_1080  1
    service_1_31_0  free_load_conservation_1081  -8
    service_1_31_0  original_T_including_depot_unload_1085  960
    service_1_31_1  unique_nonzero_owner_334  1
    service_1_31_1  service_visit_def_1080  1
    service_1_31_1  free_load_conservation_1081  -7
    service_1_31_1  original_T_including_depot_unload_1085  840
    service_1_31_2  unique_nonzero_owner_335  1
    service_1_31_2  service_visit_def_1080  1
    service_1_31_2  free_load_conservation_1081  -6
    service_1_31_2  original_T_including_depot_unload_1085  720
    service_1_31_3  unique_nonzero_owner_336  1
    service_1_31_3  service_visit_def_1080  1
    service_1_31_3  free_load_conservation_1081  -5
    service_1_31_3  original_T_including_depot_unload_1085  600
    service_1_31_4  unique_nonzero_owner_337  1
    service_1_31_4  service_visit_def_1080  1
    service_1_31_4  free_load_conservation_1081  -4
    service_1_31_4  original_T_including_depot_unload_1085  480
    service_1_31_5  unique_nonzero_owner_338  1
    service_1_31_5  service_visit_def_1080  1
    service_1_31_5  free_load_conservation_1081  -3
    service_1_31_5  original_T_including_depot_unload_1085  360
    service_1_31_6  unique_nonzero_owner_339  1
    service_1_31_6  service_visit_def_1080  1
    service_1_31_6  free_load_conservation_1081  -2
    service_1_31_6  original_T_including_depot_unload_1085  240
    service_1_31_7  unique_nonzero_owner_340  1
    service_1_31_7  service_visit_def_1080  1
    service_1_31_7  free_load_conservation_1081  -1
    service_1_31_7  original_T_including_depot_unload_1085  120
    service_1_31_9  unique_nonzero_owner_341  1
    service_1_31_9  service_visit_def_1080  1
    service_1_31_9  free_load_conservation_1081  1
    service_1_31_10  unique_nonzero_owner_342  1
    service_1_31_10  service_visit_def_1080  1
    service_1_31_10  free_load_conservation_1081  2
    service_1_31_11  unique_nonzero_owner_343  1
    service_1_31_11  service_visit_def_1080  1
    service_1_31_11  free_load_conservation_1081  3
    service_2_31_0  unique_nonzero_owner_333  1
    service_2_31_0  service_visit_def_1398  1
    service_2_31_0  free_load_conservation_1399  -8
    service_2_31_0  original_T_including_depot_unload_1402  960
    service_2_31_1  unique_nonzero_owner_334  1
    service_2_31_1  service_visit_def_1398  1
    service_2_31_1  free_load_conservation_1399  -7
    service_2_31_1  original_T_including_depot_unload_1402  840
    service_2_31_2  unique_nonzero_owner_335  1
    service_2_31_2  service_visit_def_1398  1
    service_2_31_2  free_load_conservation_1399  -6
    service_2_31_2  original_T_including_depot_unload_1402  720
    service_2_31_3  unique_nonzero_owner_336  1
    service_2_31_3  service_visit_def_1398  1
    service_2_31_3  free_load_conservation_1399  -5
    service_2_31_3  original_T_including_depot_unload_1402  600
    service_2_31_4  unique_nonzero_owner_337  1
    service_2_31_4  service_visit_def_1398  1
    service_2_31_4  free_load_conservation_1399  -4
    service_2_31_4  original_T_including_depot_unload_1402  480
    service_2_31_5  unique_nonzero_owner_338  1
    service_2_31_5  service_visit_def_1398  1
    service_2_31_5  free_load_conservation_1399  -3
    service_2_31_5  original_T_including_depot_unload_1402  360
    service_2_31_6  unique_nonzero_owner_339  1
    service_2_31_6  service_visit_def_1398  1
    service_2_31_6  free_load_conservation_1399  -2
    service_2_31_6  original_T_including_depot_unload_1402  240
    service_2_31_7  unique_nonzero_owner_340  1
    service_2_31_7  service_visit_def_1398  1
    service_2_31_7  free_load_conservation_1399  -1
    service_2_31_7  original_T_including_depot_unload_1402  120
    service_2_31_9  unique_nonzero_owner_341  1
    service_2_31_9  service_visit_def_1398  1
    service_2_31_9  free_load_conservation_1399  1
    service_2_31_10  unique_nonzero_owner_342  1
    service_2_31_10  service_visit_def_1398  1
    service_2_31_10  free_load_conservation_1399  2
    service_2_31_11  unique_nonzero_owner_343  1
    service_2_31_11  service_visit_def_1398  1
    service_2_31_11  free_load_conservation_1399  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_635  -1
    visit_0_1  in_degree_636  -1
    visit_0_1  order_active_lb_637  -1
    visit_0_1  order_active_ub_638  -12
    order_0_1  connected_order_arc_359  -1
    order_0_1  connected_order_arc_361  -1
    order_0_1  connected_order_arc_363  -1
    order_0_1  connected_order_arc_365  -1
    order_0_1  connected_order_arc_367  -1
    order_0_1  connected_order_arc_369  -1
    order_0_1  connected_order_arc_371  -1
    order_0_1  connected_order_arc_373  -1
    order_0_1  connected_order_arc_375  -1
    order_0_1  connected_order_arc_377  -1
    order_0_1  connected_order_arc_379  -1
    order_0_1  connected_order_arc_382  1
    order_0_1  connected_order_arc_405  1
    order_0_1  connected_order_arc_428  1
    order_0_1  connected_order_arc_451  1
    order_0_1  connected_order_arc_474  1
    order_0_1  connected_order_arc_497  1
    order_0_1  connected_order_arc_520  1
    order_0_1  connected_order_arc_543  1
    order_0_1  connected_order_arc_566  1
    order_0_1  connected_order_arc_589  1
    order_0_1  connected_order_arc_612  1
    order_0_1  order_active_lb_637  1
    order_0_1  order_active_ub_638  1
    order_0_1  fixed_segment_relative_order_711  -1
    visit_0_2  out_degree_642  -1
    visit_0_2  in_degree_643  -1
    visit_0_2  order_active_lb_644  -1
    visit_0_2  order_active_ub_645  -12
    order_0_2  connected_order_arc_359  1
    order_0_2  connected_order_arc_382  -1
    order_0_2  connected_order_arc_384  -1
    order_0_2  connected_order_arc_386  -1
    order_0_2  connected_order_arc_388  -1
    order_0_2  connected_order_arc_390  -1
    order_0_2  connected_order_arc_392  -1
    order_0_2  connected_order_arc_394  -1
    order_0_2  connected_order_arc_396  -1
    order_0_2  connected_order_arc_398  -1
    order_0_2  connected_order_arc_400  -1
    order_0_2  connected_order_arc_402  -1
    order_0_2  connected_order_arc_407  1
    order_0_2  connected_order_arc_430  1
    order_0_2  connected_order_arc_453  1
    order_0_2  connected_order_arc_476  1
    order_0_2  connected_order_arc_499  1
    order_0_2  connected_order_arc_522  1
    order_0_2  connected_order_arc_545  1
    order_0_2  connected_order_arc_568  1
    order_0_2  connected_order_arc_591  1
    order_0_2  connected_order_arc_614  1
    order_0_2  order_active_lb_644  1
    order_0_2  order_active_ub_645  1
    order_0_2  fixed_segment_relative_order_711  1
    order_0_2  fixed_segment_relative_order_712  -1
    visit_0_3  out_degree_649  -1
    visit_0_3  in_degree_650  -1
    visit_0_3  order_active_lb_651  -1
    visit_0_3  order_active_ub_652  -12
    order_0_3  connected_order_arc_361  1
    order_0_3  connected_order_arc_384  1
    order_0_3  connected_order_arc_405  -1
    order_0_3  connected_order_arc_407  -1
    order_0_3  connected_order_arc_409  -1
    order_0_3  connected_order_arc_411  -1
    order_0_3  connected_order_arc_413  -1
    order_0_3  connected_order_arc_415  -1
    order_0_3  connected_order_arc_417  -1
    order_0_3  connected_order_arc_419  -1
    order_0_3  connected_order_arc_421  -1
    order_0_3  connected_order_arc_423  -1
    order_0_3  connected_order_arc_425  -1
    order_0_3  connected_order_arc_432  1
    order_0_3  connected_order_arc_455  1
    order_0_3  connected_order_arc_478  1
    order_0_3  connected_order_arc_501  1
    order_0_3  connected_order_arc_524  1
    order_0_3  connected_order_arc_547  1
    order_0_3  connected_order_arc_570  1
    order_0_3  connected_order_arc_593  1
    order_0_3  connected_order_arc_616  1
    order_0_3  order_active_lb_651  1
    order_0_3  order_active_ub_652  1
    order_0_3  fixed_segment_relative_order_712  1
    order_0_3  fixed_segment_relative_order_713  -1
    visit_0_4  out_degree_656  -1
    visit_0_4  in_degree_657  -1
    visit_0_4  order_active_lb_658  -1
    visit_0_4  order_active_ub_659  -12
    order_0_4  connected_order_arc_363  1
    order_0_4  connected_order_arc_386  1
    order_0_4  connected_order_arc_409  1
    order_0_4  connected_order_arc_428  -1
    order_0_4  connected_order_arc_430  -1
    order_0_4  connected_order_arc_432  -1
    order_0_4  connected_order_arc_434  -1
    order_0_4  connected_order_arc_436  -1
    order_0_4  connected_order_arc_438  -1
    order_0_4  connected_order_arc_440  -1
    order_0_4  connected_order_arc_442  -1
    order_0_4  connected_order_arc_444  -1
    order_0_4  connected_order_arc_446  -1
    order_0_4  connected_order_arc_448  -1
    order_0_4  connected_order_arc_457  1
    order_0_4  connected_order_arc_480  1
    order_0_4  connected_order_arc_503  1
    order_0_4  connected_order_arc_526  1
    order_0_4  connected_order_arc_549  1
    order_0_4  connected_order_arc_572  1
    order_0_4  connected_order_arc_595  1
    order_0_4  connected_order_arc_618  1
    order_0_4  order_active_lb_658  1
    order_0_4  order_active_ub_659  1
    order_0_4  fixed_segment_relative_order_713  1
    visit_0_12  out_degree_663  -1
    visit_0_12  in_degree_664  -1
    visit_0_12  order_active_lb_665  -1
    visit_0_12  order_active_ub_666  -12
    visit_0_12  service_visit_def_667  -1
    order_0_12  connected_order_arc_365  1
    order_0_12  connected_order_arc_388  1
    order_0_12  connected_order_arc_411  1
    order_0_12  connected_order_arc_434  1
    order_0_12  connected_order_arc_451  -1
    order_0_12  connected_order_arc_453  -1
    order_0_12  connected_order_arc_455  -1
    order_0_12  connected_order_arc_457  -1
    order_0_12  connected_order_arc_459  -1
    order_0_12  connected_order_arc_461  -1
    order_0_12  connected_order_arc_463  -1
    order_0_12  connected_order_arc_465  -1
    order_0_12  connected_order_arc_467  -1
    order_0_12  connected_order_arc_469  -1
    order_0_12  connected_order_arc_471  -1
    order_0_12  connected_order_arc_482  1
    order_0_12  connected_order_arc_505  1
    order_0_12  connected_order_arc_528  1
    order_0_12  connected_order_arc_551  1
    order_0_12  connected_order_arc_574  1
    order_0_12  connected_order_arc_597  1
    order_0_12  connected_order_arc_620  1
    order_0_12  order_active_lb_665  1
    order_0_12  order_active_ub_666  1
    visit_0_13  out_degree_669  -1
    visit_0_13  in_degree_670  -1
    visit_0_13  order_active_lb_671  -1
    visit_0_13  order_active_ub_672  -12
    visit_0_13  service_visit_def_673  -1
    order_0_13  connected_order_arc_367  1
    order_0_13  connected_order_arc_390  1
    order_0_13  connected_order_arc_413  1
    order_0_13  connected_order_arc_436  1
    order_0_13  connected_order_arc_459  1
    order_0_13  connected_order_arc_474  -1
    order_0_13  connected_order_arc_476  -1
    order_0_13  connected_order_arc_478  -1
    order_0_13  connected_order_arc_480  -1
    order_0_13  connected_order_arc_482  -1
    order_0_13  connected_order_arc_484  -1
    order_0_13  connected_order_arc_486  -1
    order_0_13  connected_order_arc_488  -1
    order_0_13  connected_order_arc_490  -1
    order_0_13  connected_order_arc_492  -1
    order_0_13  connected_order_arc_494  -1
    order_0_13  connected_order_arc_507  1
    order_0_13  connected_order_arc_530  1
    order_0_13  connected_order_arc_553  1
    order_0_13  connected_order_arc_576  1
    order_0_13  connected_order_arc_599  1
    order_0_13  connected_order_arc_622  1
    order_0_13  order_active_lb_671  1
    order_0_13  order_active_ub_672  1
    visit_0_14  out_degree_675  -1
    visit_0_14  in_degree_676  -1
    visit_0_14  order_active_lb_677  -1
    visit_0_14  order_active_ub_678  -12
    visit_0_14  service_visit_def_679  -1
    order_0_14  connected_order_arc_369  1
    order_0_14  connected_order_arc_392  1
    order_0_14  connected_order_arc_415  1
    order_0_14  connected_order_arc_438  1
    order_0_14  connected_order_arc_461  1
    order_0_14  connected_order_arc_484  1
    order_0_14  connected_order_arc_497  -1
    order_0_14  connected_order_arc_499  -1
    order_0_14  connected_order_arc_501  -1
    order_0_14  connected_order_arc_503  -1
    order_0_14  connected_order_arc_505  -1
    order_0_14  connected_order_arc_507  -1
    order_0_14  connected_order_arc_509  -1
    order_0_14  connected_order_arc_511  -1
    order_0_14  connected_order_arc_513  -1
    order_0_14  connected_order_arc_515  -1
    order_0_14  connected_order_arc_517  -1
    order_0_14  connected_order_arc_532  1
    order_0_14  connected_order_arc_555  1
    order_0_14  connected_order_arc_578  1
    order_0_14  connected_order_arc_601  1
    order_0_14  connected_order_arc_624  1
    order_0_14  order_active_lb_677  1
    order_0_14  order_active_ub_678  1
    visit_0_15  out_degree_681  -1
    visit_0_15  in_degree_682  -1
    visit_0_15  order_active_lb_683  -1
    visit_0_15  order_active_ub_684  -12
    visit_0_15  service_visit_def_685  -1
    order_0_15  connected_order_arc_371  1
    order_0_15  connected_order_arc_394  1
    order_0_15  connected_order_arc_417  1
    order_0_15  connected_order_arc_440  1
    order_0_15  connected_order_arc_463  1
    order_0_15  connected_order_arc_486  1
    order_0_15  connected_order_arc_509  1
    order_0_15  connected_order_arc_520  -1
    order_0_15  connected_order_arc_522  -1
    order_0_15  connected_order_arc_524  -1
    order_0_15  connected_order_arc_526  -1
    order_0_15  connected_order_arc_528  -1
    order_0_15  connected_order_arc_530  -1
    order_0_15  connected_order_arc_532  -1
    order_0_15  connected_order_arc_534  -1
    order_0_15  connected_order_arc_536  -1
    order_0_15  connected_order_arc_538  -1
    order_0_15  connected_order_arc_540  -1
    order_0_15  connected_order_arc_557  1
    order_0_15  connected_order_arc_580  1
    order_0_15  connected_order_arc_603  1
    order_0_15  connected_order_arc_626  1
    order_0_15  order_active_lb_683  1
    order_0_15  order_active_ub_684  1
    visit_0_16  out_degree_687  -1
    visit_0_16  in_degree_688  -1
    visit_0_16  order_active_lb_689  -1
    visit_0_16  order_active_ub_690  -12
    visit_0_16  service_visit_def_691  -1
    order_0_16  connected_order_arc_373  1
    order_0_16  connected_order_arc_396  1
    order_0_16  connected_order_arc_419  1
    order_0_16  connected_order_arc_442  1
    order_0_16  connected_order_arc_465  1
    order_0_16  connected_order_arc_488  1
    order_0_16  connected_order_arc_511  1
    order_0_16  connected_order_arc_534  1
    order_0_16  connected_order_arc_543  -1
    order_0_16  connected_order_arc_545  -1
    order_0_16  connected_order_arc_547  -1
    order_0_16  connected_order_arc_549  -1
    order_0_16  connected_order_arc_551  -1
    order_0_16  connected_order_arc_553  -1
    order_0_16  connected_order_arc_555  -1
    order_0_16  connected_order_arc_557  -1
    order_0_16  connected_order_arc_559  -1
    order_0_16  connected_order_arc_561  -1
    order_0_16  connected_order_arc_563  -1
    order_0_16  connected_order_arc_582  1
    order_0_16  connected_order_arc_605  1
    order_0_16  connected_order_arc_628  1
    order_0_16  order_active_lb_689  1
    order_0_16  order_active_ub_690  1
    visit_0_17  out_degree_693  -1
    visit_0_17  in_degree_694  -1
    visit_0_17  order_active_lb_695  -1
    visit_0_17  order_active_ub_696  -12
    visit_0_17  service_visit_def_697  -1
    order_0_17  connected_order_arc_375  1
    order_0_17  connected_order_arc_398  1
    order_0_17  connected_order_arc_421  1
    order_0_17  connected_order_arc_444  1
    order_0_17  connected_order_arc_467  1
    order_0_17  connected_order_arc_490  1
    order_0_17  connected_order_arc_513  1
    order_0_17  connected_order_arc_536  1
    order_0_17  connected_order_arc_559  1
    order_0_17  connected_order_arc_566  -1
    order_0_17  connected_order_arc_568  -1
    order_0_17  connected_order_arc_570  -1
    order_0_17  connected_order_arc_572  -1
    order_0_17  connected_order_arc_574  -1
    order_0_17  connected_order_arc_576  -1
    order_0_17  connected_order_arc_578  -1
    order_0_17  connected_order_arc_580  -1
    order_0_17  connected_order_arc_582  -1
    order_0_17  connected_order_arc_584  -1
    order_0_17  connected_order_arc_586  -1
    order_0_17  connected_order_arc_607  1
    order_0_17  connected_order_arc_630  1
    order_0_17  order_active_lb_695  1
    order_0_17  order_active_ub_696  1
    visit_0_18  out_degree_699  -1
    visit_0_18  in_degree_700  -1
    visit_0_18  order_active_lb_701  -1
    visit_0_18  order_active_ub_702  -12
    visit_0_18  service_visit_def_703  -1
    order_0_18  connected_order_arc_377  1
    order_0_18  connected_order_arc_400  1
    order_0_18  connected_order_arc_423  1
    order_0_18  connected_order_arc_446  1
    order_0_18  connected_order_arc_469  1
    order_0_18  connected_order_arc_492  1
    order_0_18  connected_order_arc_515  1
    order_0_18  connected_order_arc_538  1
    order_0_18  connected_order_arc_561  1
    order_0_18  connected_order_arc_584  1
    order_0_18  connected_order_arc_589  -1
    order_0_18  connected_order_arc_591  -1
    order_0_18  connected_order_arc_593  -1
    order_0_18  connected_order_arc_595  -1
    order_0_18  connected_order_arc_597  -1
    order_0_18  connected_order_arc_599  -1
    order_0_18  connected_order_arc_601  -1
    order_0_18  connected_order_arc_603  -1
    order_0_18  connected_order_arc_605  -1
    order_0_18  connected_order_arc_607  -1
    order_0_18  connected_order_arc_609  -1
    order_0_18  connected_order_arc_632  1
    order_0_18  order_active_lb_701  1
    order_0_18  order_active_ub_702  1
    visit_0_19  out_degree_705  -1
    visit_0_19  in_degree_706  -1
    visit_0_19  order_active_lb_707  -1
    visit_0_19  order_active_ub_708  -12
    visit_0_19  service_visit_def_709  -1
    order_0_19  connected_order_arc_379  1
    order_0_19  connected_order_arc_402  1
    order_0_19  connected_order_arc_425  1
    order_0_19  connected_order_arc_448  1
    order_0_19  connected_order_arc_471  1
    order_0_19  connected_order_arc_494  1
    order_0_19  connected_order_arc_517  1
    order_0_19  connected_order_arc_540  1
    order_0_19  connected_order_arc_563  1
    order_0_19  connected_order_arc_586  1
    order_0_19  connected_order_arc_609  1
    order_0_19  connected_order_arc_612  -1
    order_0_19  connected_order_arc_614  -1
    order_0_19  connected_order_arc_616  -1
    order_0_19  connected_order_arc_618  -1
    order_0_19  connected_order_arc_620  -1
    order_0_19  connected_order_arc_622  -1
    order_0_19  connected_order_arc_624  -1
    order_0_19  connected_order_arc_626  -1
    order_0_19  connected_order_arc_628  -1
    order_0_19  connected_order_arc_630  -1
    order_0_19  connected_order_arc_632  -1
    order_0_19  order_active_lb_707  1
    order_0_19  order_active_ub_708  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_344  -20
    arc_0_0_0  depot_departure_or_bypass_633  1
    arc_0_0_0  depot_return_or_bypass_634  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_344  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_345  -20
    arc_0_0_1  depot_departure_or_bypass_633  1
    arc_0_0_1  in_degree_636  1
    arc_0_0_1  original_T_including_depot_unload_714  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_345  1
    load_0_0_1  segment_load_conservation_639  -1
    load_0_0_1  segment_prefix_lb_640  1
    load_0_0_1  segment_prefix_ub_641  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_346  -20
    arc_0_0_2  depot_departure_or_bypass_633  1
    arc_0_0_2  in_degree_643  1
    arc_0_0_2  original_T_including_depot_unload_714  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_346  1
    load_0_0_2  segment_load_conservation_646  -1
    load_0_0_2  segment_prefix_lb_647  1
    load_0_0_2  segment_prefix_ub_648  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_347  -20
    arc_0_0_3  depot_departure_or_bypass_633  1
    arc_0_0_3  in_degree_650  1
    arc_0_0_3  original_T_including_depot_unload_714  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_347  1
    load_0_0_3  segment_load_conservation_653  -1
    load_0_0_3  segment_prefix_lb_654  1
    load_0_0_3  segment_prefix_ub_655  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_348  -20
    arc_0_0_4  depot_departure_or_bypass_633  1
    arc_0_0_4  in_degree_657  1
    arc_0_0_4  original_T_including_depot_unload_714  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_348  1
    load_0_0_4  segment_load_conservation_660  -1
    load_0_0_4  segment_prefix_lb_661  1
    load_0_0_4  segment_prefix_ub_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_349  -20
    arc_0_0_12  depot_departure_or_bypass_633  1
    arc_0_0_12  in_degree_664  1
    arc_0_0_12  original_T_including_depot_unload_714  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_349  1
    load_0_0_12  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_350  -20
    arc_0_0_13  depot_departure_or_bypass_633  1
    arc_0_0_13  in_degree_670  1
    arc_0_0_13  original_T_including_depot_unload_714  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_350  1
    load_0_0_13  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_351  -20
    arc_0_0_14  depot_departure_or_bypass_633  1
    arc_0_0_14  in_degree_676  1
    arc_0_0_14  original_T_including_depot_unload_714  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_351  1
    load_0_0_14  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_352  -20
    arc_0_0_15  depot_departure_or_bypass_633  1
    arc_0_0_15  in_degree_682  1
    arc_0_0_15  original_T_including_depot_unload_714  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_352  1
    load_0_0_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_353  -20
    arc_0_0_16  depot_departure_or_bypass_633  1
    arc_0_0_16  in_degree_688  1
    arc_0_0_16  original_T_including_depot_unload_714  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_353  1
    load_0_0_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_354  -20
    arc_0_0_17  depot_departure_or_bypass_633  1
    arc_0_0_17  in_degree_694  1
    arc_0_0_17  original_T_including_depot_unload_714  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_354  1
    load_0_0_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_355  -20
    arc_0_0_18  depot_departure_or_bypass_633  1
    arc_0_0_18  in_degree_700  1
    arc_0_0_18  original_T_including_depot_unload_714  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_355  1
    load_0_0_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_356  -20
    arc_0_0_19  depot_departure_or_bypass_633  1
    arc_0_0_19  in_degree_706  1
    arc_0_0_19  original_T_including_depot_unload_714  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_356  1
    load_0_0_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_357  -20
    arc_0_1_0  depot_return_or_bypass_634  1
    arc_0_1_0  out_degree_635  1
    arc_0_1_0  original_T_including_depot_unload_714  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_357  1
    load_0_1_0  segment_load_conservation_639  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_358  -20
    arc_0_1_2  connected_order_arc_359  -13
    arc_0_1_2  out_degree_635  1
    arc_0_1_2  in_degree_643  1
    arc_0_1_2  original_T_including_depot_unload_714  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_358  1
    load_0_1_2  segment_load_conservation_639  1
    load_0_1_2  segment_load_conservation_646  -1
    load_0_1_2  segment_prefix_lb_647  1
    load_0_1_2  segment_prefix_ub_648  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_360  -20
    arc_0_1_3  connected_order_arc_361  -13
    arc_0_1_3  out_degree_635  1
    arc_0_1_3  in_degree_650  1
    arc_0_1_3  original_T_including_depot_unload_714  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_360  1
    load_0_1_3  segment_load_conservation_639  1
    load_0_1_3  segment_load_conservation_653  -1
    load_0_1_3  segment_prefix_lb_654  1
    load_0_1_3  segment_prefix_ub_655  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_362  -20
    arc_0_1_4  connected_order_arc_363  -13
    arc_0_1_4  out_degree_635  1
    arc_0_1_4  in_degree_657  1
    arc_0_1_4  original_T_including_depot_unload_714  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_362  1
    load_0_1_4  segment_load_conservation_639  1
    load_0_1_4  segment_load_conservation_660  -1
    load_0_1_4  segment_prefix_lb_661  1
    load_0_1_4  segment_prefix_ub_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_364  -20
    arc_0_1_12  connected_order_arc_365  -13
    arc_0_1_12  out_degree_635  1
    arc_0_1_12  in_degree_664  1
    arc_0_1_12  original_T_including_depot_unload_714  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_364  1
    load_0_1_12  segment_load_conservation_639  1
    load_0_1_12  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_366  -20
    arc_0_1_13  connected_order_arc_367  -13
    arc_0_1_13  out_degree_635  1
    arc_0_1_13  in_degree_670  1
    arc_0_1_13  original_T_including_depot_unload_714  9.9507040584540334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_366  1
    load_0_1_13  segment_load_conservation_639  1
    load_0_1_13  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_368  -20
    arc_0_1_14  connected_order_arc_369  -13
    arc_0_1_14  out_degree_635  1
    arc_0_1_14  in_degree_676  1
    arc_0_1_14  original_T_including_depot_unload_714  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_368  1
    load_0_1_14  segment_load_conservation_639  1
    load_0_1_14  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_370  -20
    arc_0_1_15  connected_order_arc_371  -13
    arc_0_1_15  out_degree_635  1
    arc_0_1_15  in_degree_682  1
    arc_0_1_15  original_T_including_depot_unload_714  7.9279566508536948e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_370  1
    load_0_1_15  segment_load_conservation_639  1
    load_0_1_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_372  -20
    arc_0_1_16  connected_order_arc_373  -13
    arc_0_1_16  out_degree_635  1
    arc_0_1_16  in_degree_688  1
    arc_0_1_16  original_T_including_depot_unload_714  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_372  1
    load_0_1_16  segment_load_conservation_639  1
    load_0_1_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_374  -20
    arc_0_1_17  connected_order_arc_375  -13
    arc_0_1_17  out_degree_635  1
    arc_0_1_17  in_degree_694  1
    arc_0_1_17  original_T_including_depot_unload_714  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_374  1
    load_0_1_17  segment_load_conservation_639  1
    load_0_1_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_376  -20
    arc_0_1_18  connected_order_arc_377  -13
    arc_0_1_18  out_degree_635  1
    arc_0_1_18  in_degree_700  1
    arc_0_1_18  original_T_including_depot_unload_714  1.7489516402613351e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_376  1
    load_0_1_18  segment_load_conservation_639  1
    load_0_1_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_378  -20
    arc_0_1_19  connected_order_arc_379  -13
    arc_0_1_19  out_degree_635  1
    arc_0_1_19  in_degree_706  1
    arc_0_1_19  original_T_including_depot_unload_714  1.7224091675467555e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_378  1
    load_0_1_19  segment_load_conservation_639  1
    load_0_1_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_380  -20
    arc_0_2_0  depot_return_or_bypass_634  1
    arc_0_2_0  out_degree_642  1
    arc_0_2_0  original_T_including_depot_unload_714  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_380  1
    load_0_2_0  segment_load_conservation_646  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_381  -20
    arc_0_2_1  connected_order_arc_382  -13
    arc_0_2_1  in_degree_636  1
    arc_0_2_1  out_degree_642  1
    arc_0_2_1  original_T_including_depot_unload_714  4.9495118393852869e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_381  1
    load_0_2_1  segment_load_conservation_639  -1
    load_0_2_1  segment_prefix_lb_640  1
    load_0_2_1  segment_prefix_ub_641  1
    load_0_2_1  segment_load_conservation_646  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_383  -20
    arc_0_2_3  connected_order_arc_384  -13
    arc_0_2_3  out_degree_642  1
    arc_0_2_3  in_degree_650  1
    arc_0_2_3  original_T_including_depot_unload_714  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_383  1
    load_0_2_3  segment_load_conservation_646  1
    load_0_2_3  segment_load_conservation_653  -1
    load_0_2_3  segment_prefix_lb_654  1
    load_0_2_3  segment_prefix_ub_655  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_385  -20
    arc_0_2_4  connected_order_arc_386  -13
    arc_0_2_4  out_degree_642  1
    arc_0_2_4  in_degree_657  1
    arc_0_2_4  original_T_including_depot_unload_714  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_385  1
    load_0_2_4  segment_load_conservation_646  1
    load_0_2_4  segment_load_conservation_660  -1
    load_0_2_4  segment_prefix_lb_661  1
    load_0_2_4  segment_prefix_ub_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_387  -20
    arc_0_2_12  connected_order_arc_388  -13
    arc_0_2_12  out_degree_642  1
    arc_0_2_12  in_degree_664  1
    arc_0_2_12  original_T_including_depot_unload_714  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_387  1
    load_0_2_12  segment_load_conservation_646  1
    load_0_2_12  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_389  -20
    arc_0_2_13  connected_order_arc_390  -13
    arc_0_2_13  out_degree_642  1
    arc_0_2_13  in_degree_670  1
    arc_0_2_13  original_T_including_depot_unload_714  8.0582548325956611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_389  1
    load_0_2_13  segment_load_conservation_646  1
    load_0_2_13  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_391  -20
    arc_0_2_14  connected_order_arc_392  -13
    arc_0_2_14  out_degree_642  1
    arc_0_2_14  in_degree_676  1
    arc_0_2_14  original_T_including_depot_unload_714  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_391  1
    load_0_2_14  segment_load_conservation_646  1
    load_0_2_14  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_393  -20
    arc_0_2_15  connected_order_arc_394  -13
    arc_0_2_15  out_degree_642  1
    arc_0_2_15  in_degree_682  1
    arc_0_2_15  original_T_including_depot_unload_714  6.0704113403569352e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_393  1
    load_0_2_15  segment_load_conservation_646  1
    load_0_2_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_395  -20
    arc_0_2_16  connected_order_arc_396  -13
    arc_0_2_16  out_degree_642  1
    arc_0_2_16  in_degree_688  1
    arc_0_2_16  original_T_including_depot_unload_714  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_395  1
    load_0_2_16  segment_load_conservation_646  1
    load_0_2_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_397  -20
    arc_0_2_17  connected_order_arc_398  -13
    arc_0_2_17  out_degree_642  1
    arc_0_2_17  in_degree_694  1
    arc_0_2_17  original_T_including_depot_unload_714  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_397  1
    load_0_2_17  segment_load_conservation_646  1
    load_0_2_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_399  -20
    arc_0_2_18  connected_order_arc_400  -13
    arc_0_2_18  out_degree_642  1
    arc_0_2_18  in_degree_700  1
    arc_0_2_18  original_T_including_depot_unload_714  1.5771716839165504e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_399  1
    load_0_2_18  segment_load_conservation_646  1
    load_0_2_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_401  -20
    arc_0_2_19  connected_order_arc_402  -13
    arc_0_2_19  out_degree_642  1
    arc_0_2_19  in_degree_706  1
    arc_0_2_19  original_T_including_depot_unload_714  1.5387417148054021e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_401  1
    load_0_2_19  segment_load_conservation_646  1
    load_0_2_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_403  -20
    arc_0_3_0  depot_return_or_bypass_634  1
    arc_0_3_0  out_degree_649  1
    arc_0_3_0  original_T_including_depot_unload_714  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_403  1
    load_0_3_0  segment_load_conservation_653  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_404  -20
    arc_0_3_1  connected_order_arc_405  -13
    arc_0_3_1  in_degree_636  1
    arc_0_3_1  out_degree_649  1
    arc_0_3_1  original_T_including_depot_unload_714  6.7806925965469873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_404  1
    load_0_3_1  segment_load_conservation_639  -1
    load_0_3_1  segment_prefix_lb_640  1
    load_0_3_1  segment_prefix_ub_641  1
    load_0_3_1  segment_load_conservation_653  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_406  -20
    arc_0_3_2  connected_order_arc_407  -13
    arc_0_3_2  in_degree_643  1
    arc_0_3_2  out_degree_649  1
    arc_0_3_2  original_T_including_depot_unload_714  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_406  1
    load_0_3_2  segment_load_conservation_646  -1
    load_0_3_2  segment_prefix_lb_647  1
    load_0_3_2  segment_prefix_ub_648  1
    load_0_3_2  segment_load_conservation_653  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_408  -20
    arc_0_3_4  connected_order_arc_409  -13
    arc_0_3_4  out_degree_649  1
    arc_0_3_4  in_degree_657  1
    arc_0_3_4  original_T_including_depot_unload_714  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_408  1
    load_0_3_4  segment_load_conservation_653  1
    load_0_3_4  segment_load_conservation_660  -1
    load_0_3_4  segment_prefix_lb_661  1
    load_0_3_4  segment_prefix_ub_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_410  -20
    arc_0_3_12  connected_order_arc_411  -13
    arc_0_3_12  out_degree_649  1
    arc_0_3_12  in_degree_664  1
    arc_0_3_12  original_T_including_depot_unload_714  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_410  1
    load_0_3_12  segment_load_conservation_653  1
    load_0_3_12  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_412  -20
    arc_0_3_13  connected_order_arc_413  -13
    arc_0_3_13  out_degree_649  1
    arc_0_3_13  in_degree_670  1
    arc_0_3_13  original_T_including_depot_unload_714  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_412  1
    load_0_3_13  segment_load_conservation_653  1
    load_0_3_13  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_414  -20
    arc_0_3_14  connected_order_arc_415  -13
    arc_0_3_14  out_degree_649  1
    arc_0_3_14  in_degree_676  1
    arc_0_3_14  original_T_including_depot_unload_714  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_414  1
    load_0_3_14  segment_load_conservation_653  1
    load_0_3_14  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_416  -20
    arc_0_3_15  connected_order_arc_417  -13
    arc_0_3_15  out_degree_649  1
    arc_0_3_15  in_degree_682  1
    arc_0_3_15  original_T_including_depot_unload_714  4.1343325097934911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_416  1
    load_0_3_15  segment_load_conservation_653  1
    load_0_3_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_418  -20
    arc_0_3_16  connected_order_arc_419  -13
    arc_0_3_16  out_degree_649  1
    arc_0_3_16  in_degree_688  1
    arc_0_3_16  original_T_including_depot_unload_714  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_418  1
    load_0_3_16  segment_load_conservation_653  1
    load_0_3_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_420  -20
    arc_0_3_17  connected_order_arc_421  -13
    arc_0_3_17  out_degree_649  1
    arc_0_3_17  in_degree_694  1
    arc_0_3_17  original_T_including_depot_unload_714  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_420  1
    load_0_3_17  segment_load_conservation_653  1
    load_0_3_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_422  -20
    arc_0_3_18  connected_order_arc_423  -13
    arc_0_3_18  out_degree_649  1
    arc_0_3_18  in_degree_700  1
    arc_0_3_18  original_T_including_depot_unload_714  1.3859443171734331e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_422  1
    load_0_3_18  segment_load_conservation_653  1
    load_0_3_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_424  -20
    arc_0_3_19  connected_order_arc_425  -13
    arc_0_3_19  out_degree_649  1
    arc_0_3_19  in_degree_706  1
    arc_0_3_19  original_T_including_depot_unload_714  1.3451277357129768e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_424  1
    load_0_3_19  segment_load_conservation_653  1
    load_0_3_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_426  -20
    arc_0_4_0  depot_return_or_bypass_634  1
    arc_0_4_0  out_degree_656  1
    arc_0_4_0  original_T_including_depot_unload_714  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_426  1
    load_0_4_0  segment_load_conservation_660  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_427  -20
    arc_0_4_1  connected_order_arc_428  -13
    arc_0_4_1  in_degree_636  1
    arc_0_4_1  out_degree_656  1
    arc_0_4_1  original_T_including_depot_unload_714  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_427  1
    load_0_4_1  segment_load_conservation_639  -1
    load_0_4_1  segment_prefix_lb_640  1
    load_0_4_1  segment_prefix_ub_641  1
    load_0_4_1  segment_load_conservation_660  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_429  -20
    arc_0_4_2  connected_order_arc_430  -13
    arc_0_4_2  in_degree_643  1
    arc_0_4_2  out_degree_656  1
    arc_0_4_2  original_T_including_depot_unload_714  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_429  1
    load_0_4_2  segment_load_conservation_646  -1
    load_0_4_2  segment_prefix_lb_647  1
    load_0_4_2  segment_prefix_ub_648  1
    load_0_4_2  segment_load_conservation_660  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_431  -20
    arc_0_4_3  connected_order_arc_432  -13
    arc_0_4_3  in_degree_650  1
    arc_0_4_3  out_degree_656  1
    arc_0_4_3  original_T_including_depot_unload_714  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_431  1
    load_0_4_3  segment_load_conservation_653  -1
    load_0_4_3  segment_prefix_lb_654  1
    load_0_4_3  segment_prefix_ub_655  1
    load_0_4_3  segment_load_conservation_660  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_433  -20
    arc_0_4_12  connected_order_arc_434  -13
    arc_0_4_12  out_degree_656  1
    arc_0_4_12  in_degree_664  1
    arc_0_4_12  original_T_including_depot_unload_714  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_433  1
    load_0_4_12  segment_load_conservation_660  1
    load_0_4_12  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_435  -20
    arc_0_4_13  connected_order_arc_436  -13
    arc_0_4_13  out_degree_656  1
    arc_0_4_13  in_degree_670  1
    arc_0_4_13  original_T_including_depot_unload_714  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_435  1
    load_0_4_13  segment_load_conservation_660  1
    load_0_4_13  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_437  -20
    arc_0_4_14  connected_order_arc_438  -13
    arc_0_4_14  out_degree_656  1
    arc_0_4_14  in_degree_676  1
    arc_0_4_14  original_T_including_depot_unload_714  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_437  1
    load_0_4_14  segment_load_conservation_660  1
    load_0_4_14  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_439  -20
    arc_0_4_15  connected_order_arc_440  -13
    arc_0_4_15  out_degree_656  1
    arc_0_4_15  in_degree_682  1
    arc_0_4_15  original_T_including_depot_unload_714  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_439  1
    load_0_4_15  segment_load_conservation_660  1
    load_0_4_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_441  -20
    arc_0_4_16  connected_order_arc_442  -13
    arc_0_4_16  out_degree_656  1
    arc_0_4_16  in_degree_688  1
    arc_0_4_16  original_T_including_depot_unload_714  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_441  1
    load_0_4_16  segment_load_conservation_660  1
    load_0_4_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_443  -20
    arc_0_4_17  connected_order_arc_444  -13
    arc_0_4_17  out_degree_656  1
    arc_0_4_17  in_degree_694  1
    arc_0_4_17  original_T_including_depot_unload_714  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_443  1
    load_0_4_17  segment_load_conservation_660  1
    load_0_4_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_445  -20
    arc_0_4_18  connected_order_arc_446  -13
    arc_0_4_18  out_degree_656  1
    arc_0_4_18  in_degree_700  1
    arc_0_4_18  original_T_including_depot_unload_714  1.2799228371310815e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_445  1
    load_0_4_18  segment_load_conservation_660  1
    load_0_4_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_447  -20
    arc_0_4_19  connected_order_arc_448  -13
    arc_0_4_19  out_degree_656  1
    arc_0_4_19  in_degree_706  1
    arc_0_4_19  original_T_including_depot_unload_714  1.2401143998876444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_447  1
    load_0_4_19  segment_load_conservation_660  1
    load_0_4_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_449  -20
    arc_0_12_0  depot_return_or_bypass_634  1
    arc_0_12_0  out_degree_663  1
    arc_0_12_0  original_T_including_depot_unload_714  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_449  1
    load_0_12_0  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_450  -20
    arc_0_12_1  connected_order_arc_451  -13
    arc_0_12_1  in_degree_636  1
    arc_0_12_1  out_degree_663  1
    arc_0_12_1  original_T_including_depot_unload_714  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_450  1
    load_0_12_1  segment_load_conservation_639  -1
    load_0_12_1  segment_prefix_lb_640  1
    load_0_12_1  segment_prefix_ub_641  1
    load_0_12_1  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_452  -20
    arc_0_12_2  connected_order_arc_453  -13
    arc_0_12_2  in_degree_643  1
    arc_0_12_2  out_degree_663  1
    arc_0_12_2  original_T_including_depot_unload_714  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_452  1
    load_0_12_2  segment_load_conservation_646  -1
    load_0_12_2  segment_prefix_lb_647  1
    load_0_12_2  segment_prefix_ub_648  1
    load_0_12_2  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_454  -20
    arc_0_12_3  connected_order_arc_455  -13
    arc_0_12_3  in_degree_650  1
    arc_0_12_3  out_degree_663  1
    arc_0_12_3  original_T_including_depot_unload_714  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_454  1
    load_0_12_3  segment_load_conservation_653  -1
    load_0_12_3  segment_prefix_lb_654  1
    load_0_12_3  segment_prefix_ub_655  1
    load_0_12_3  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_456  -20
    arc_0_12_4  connected_order_arc_457  -13
    arc_0_12_4  in_degree_657  1
    arc_0_12_4  out_degree_663  1
    arc_0_12_4  original_T_including_depot_unload_714  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_456  1
    load_0_12_4  segment_load_conservation_660  -1
    load_0_12_4  segment_prefix_lb_661  1
    load_0_12_4  segment_prefix_ub_662  1
    load_0_12_4  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_458  -20
    arc_0_12_13  connected_order_arc_459  -13
    arc_0_12_13  out_degree_663  1
    arc_0_12_13  in_degree_670  1
    arc_0_12_13  original_T_including_depot_unload_714  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_458  1
    load_0_12_13  free_load_conservation_668  1
    load_0_12_13  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_460  -20
    arc_0_12_14  connected_order_arc_461  -13
    arc_0_12_14  out_degree_663  1
    arc_0_12_14  in_degree_676  1
    arc_0_12_14  original_T_including_depot_unload_714  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_460  1
    load_0_12_14  free_load_conservation_668  1
    load_0_12_14  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_462  -20
    arc_0_12_15  connected_order_arc_463  -13
    arc_0_12_15  out_degree_663  1
    arc_0_12_15  in_degree_682  1
    arc_0_12_15  original_T_including_depot_unload_714  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_462  1
    load_0_12_15  free_load_conservation_668  1
    load_0_12_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_464  -20
    arc_0_12_16  connected_order_arc_465  -13
    arc_0_12_16  out_degree_663  1
    arc_0_12_16  in_degree_688  1
    arc_0_12_16  original_T_including_depot_unload_714  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_464  1
    load_0_12_16  free_load_conservation_668  1
    load_0_12_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_466  -20
    arc_0_12_17  connected_order_arc_467  -13
    arc_0_12_17  out_degree_663  1
    arc_0_12_17  in_degree_694  1
    arc_0_12_17  original_T_including_depot_unload_714  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_466  1
    load_0_12_17  free_load_conservation_668  1
    load_0_12_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_468  -20
    arc_0_12_18  connected_order_arc_469  -13
    arc_0_12_18  out_degree_663  1
    arc_0_12_18  in_degree_700  1
    arc_0_12_18  original_T_including_depot_unload_714  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_468  1
    load_0_12_18  free_load_conservation_668  1
    load_0_12_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_470  -20
    arc_0_12_19  connected_order_arc_471  -13
    arc_0_12_19  out_degree_663  1
    arc_0_12_19  in_degree_706  1
    arc_0_12_19  original_T_including_depot_unload_714  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_470  1
    load_0_12_19  free_load_conservation_668  1
    load_0_12_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_472  -20
    arc_0_13_0  depot_return_or_bypass_634  1
    arc_0_13_0  out_degree_669  1
    arc_0_13_0  original_T_including_depot_unload_714  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_472  1
    load_0_13_0  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_473  -20
    arc_0_13_1  connected_order_arc_474  -13
    arc_0_13_1  in_degree_636  1
    arc_0_13_1  out_degree_669  1
    arc_0_13_1  original_T_including_depot_unload_714  1.2844696003118074e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_473  1
    load_0_13_1  segment_load_conservation_639  -1
    load_0_13_1  segment_prefix_lb_640  1
    load_0_13_1  segment_prefix_ub_641  1
    load_0_13_1  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_475  -20
    arc_0_13_2  connected_order_arc_476  -13
    arc_0_13_2  in_degree_643  1
    arc_0_13_2  out_degree_669  1
    arc_0_13_2  original_T_including_depot_unload_714  8.0831419223632781e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_475  1
    load_0_13_2  segment_load_conservation_646  -1
    load_0_13_2  segment_prefix_lb_647  1
    load_0_13_2  segment_prefix_ub_648  1
    load_0_13_2  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_477  -20
    arc_0_13_3  connected_order_arc_478  -13
    arc_0_13_3  in_degree_650  1
    arc_0_13_3  out_degree_669  1
    arc_0_13_3  original_T_including_depot_unload_714  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_477  1
    load_0_13_3  segment_load_conservation_653  -1
    load_0_13_3  segment_prefix_lb_654  1
    load_0_13_3  segment_prefix_ub_655  1
    load_0_13_3  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_479  -20
    arc_0_13_4  connected_order_arc_480  -13
    arc_0_13_4  in_degree_657  1
    arc_0_13_4  out_degree_669  1
    arc_0_13_4  original_T_including_depot_unload_714  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_479  1
    load_0_13_4  segment_load_conservation_660  -1
    load_0_13_4  segment_prefix_lb_661  1
    load_0_13_4  segment_prefix_ub_662  1
    load_0_13_4  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_481  -20
    arc_0_13_12  connected_order_arc_482  -13
    arc_0_13_12  in_degree_664  1
    arc_0_13_12  out_degree_669  1
    arc_0_13_12  original_T_including_depot_unload_714  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_481  1
    load_0_13_12  free_load_conservation_668  -1
    load_0_13_12  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_483  -20
    arc_0_13_14  connected_order_arc_484  -13
    arc_0_13_14  out_degree_669  1
    arc_0_13_14  in_degree_676  1
    arc_0_13_14  original_T_including_depot_unload_714  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_483  1
    load_0_13_14  free_load_conservation_674  1
    load_0_13_14  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_485  -20
    arc_0_13_15  connected_order_arc_486  -13
    arc_0_13_15  out_degree_669  1
    arc_0_13_15  in_degree_682  1
    arc_0_13_15  original_T_including_depot_unload_714  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_485  1
    load_0_13_15  free_load_conservation_674  1
    load_0_13_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_487  -20
    arc_0_13_16  connected_order_arc_488  -13
    arc_0_13_16  out_degree_669  1
    arc_0_13_16  in_degree_688  1
    arc_0_13_16  original_T_including_depot_unload_714  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_487  1
    load_0_13_16  free_load_conservation_674  1
    load_0_13_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_489  -20
    arc_0_13_17  connected_order_arc_490  -13
    arc_0_13_17  out_degree_669  1
    arc_0_13_17  in_degree_694  1
    arc_0_13_17  original_T_including_depot_unload_714  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_489  1
    load_0_13_17  free_load_conservation_674  1
    load_0_13_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_491  -20
    arc_0_13_18  connected_order_arc_492  -13
    arc_0_13_18  out_degree_669  1
    arc_0_13_18  in_degree_700  1
    arc_0_13_18  original_T_including_depot_unload_714  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_491  1
    load_0_13_18  free_load_conservation_674  1
    load_0_13_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_493  -20
    arc_0_13_19  connected_order_arc_494  -13
    arc_0_13_19  out_degree_669  1
    arc_0_13_19  in_degree_706  1
    arc_0_13_19  original_T_including_depot_unload_714  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_493  1
    load_0_13_19  free_load_conservation_674  1
    load_0_13_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_495  -20
    arc_0_14_0  depot_return_or_bypass_634  1
    arc_0_14_0  out_degree_675  1
    arc_0_14_0  original_T_including_depot_unload_714  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_495  1
    load_0_14_0  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_496  -20
    arc_0_14_1  connected_order_arc_497  -13
    arc_0_14_1  in_degree_636  1
    arc_0_14_1  out_degree_675  1
    arc_0_14_1  original_T_including_depot_unload_714  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_496  1
    load_0_14_1  segment_load_conservation_639  -1
    load_0_14_1  segment_prefix_lb_640  1
    load_0_14_1  segment_prefix_ub_641  1
    load_0_14_1  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_498  -20
    arc_0_14_2  connected_order_arc_499  -13
    arc_0_14_2  in_degree_643  1
    arc_0_14_2  out_degree_675  1
    arc_0_14_2  original_T_including_depot_unload_714  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_498  1
    load_0_14_2  segment_load_conservation_646  -1
    load_0_14_2  segment_prefix_lb_647  1
    load_0_14_2  segment_prefix_ub_648  1
    load_0_14_2  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_500  -20
    arc_0_14_3  connected_order_arc_501  -13
    arc_0_14_3  in_degree_650  1
    arc_0_14_3  out_degree_675  1
    arc_0_14_3  original_T_including_depot_unload_714  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_500  1
    load_0_14_3  segment_load_conservation_653  -1
    load_0_14_3  segment_prefix_lb_654  1
    load_0_14_3  segment_prefix_ub_655  1
    load_0_14_3  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_502  -20
    arc_0_14_4  connected_order_arc_503  -13
    arc_0_14_4  in_degree_657  1
    arc_0_14_4  out_degree_675  1
    arc_0_14_4  original_T_including_depot_unload_714  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_502  1
    load_0_14_4  segment_load_conservation_660  -1
    load_0_14_4  segment_prefix_lb_661  1
    load_0_14_4  segment_prefix_ub_662  1
    load_0_14_4  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_504  -20
    arc_0_14_12  connected_order_arc_505  -13
    arc_0_14_12  in_degree_664  1
    arc_0_14_12  out_degree_675  1
    arc_0_14_12  original_T_including_depot_unload_714  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_504  1
    load_0_14_12  free_load_conservation_668  -1
    load_0_14_12  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_506  -20
    arc_0_14_13  connected_order_arc_507  -13
    arc_0_14_13  in_degree_670  1
    arc_0_14_13  out_degree_675  1
    arc_0_14_13  original_T_including_depot_unload_714  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_506  1
    load_0_14_13  free_load_conservation_674  -1
    load_0_14_13  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_508  -20
    arc_0_14_15  connected_order_arc_509  -13
    arc_0_14_15  out_degree_675  1
    arc_0_14_15  in_degree_682  1
    arc_0_14_15  original_T_including_depot_unload_714  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_508  1
    load_0_14_15  free_load_conservation_680  1
    load_0_14_15  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_510  -20
    arc_0_14_16  connected_order_arc_511  -13
    arc_0_14_16  out_degree_675  1
    arc_0_14_16  in_degree_688  1
    arc_0_14_16  original_T_including_depot_unload_714  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_510  1
    load_0_14_16  free_load_conservation_680  1
    load_0_14_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_512  -20
    arc_0_14_17  connected_order_arc_513  -13
    arc_0_14_17  out_degree_675  1
    arc_0_14_17  in_degree_694  1
    arc_0_14_17  original_T_including_depot_unload_714  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_512  1
    load_0_14_17  free_load_conservation_680  1
    load_0_14_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_514  -20
    arc_0_14_18  connected_order_arc_515  -13
    arc_0_14_18  out_degree_675  1
    arc_0_14_18  in_degree_700  1
    arc_0_14_18  original_T_including_depot_unload_714  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_514  1
    load_0_14_18  free_load_conservation_680  1
    load_0_14_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_516  -20
    arc_0_14_19  connected_order_arc_517  -13
    arc_0_14_19  out_degree_675  1
    arc_0_14_19  in_degree_706  1
    arc_0_14_19  original_T_including_depot_unload_714  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_516  1
    load_0_14_19  free_load_conservation_680  1
    load_0_14_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_518  -20
    arc_0_15_0  depot_return_or_bypass_634  1
    arc_0_15_0  out_degree_681  1
    arc_0_15_0  original_T_including_depot_unload_714  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_518  1
    load_0_15_0  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_519  -20
    arc_0_15_1  connected_order_arc_520  -13
    arc_0_15_1  in_degree_636  1
    arc_0_15_1  out_degree_681  1
    arc_0_15_1  original_T_including_depot_unload_714  1.0804765714682671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_519  1
    load_0_15_1  segment_load_conservation_639  -1
    load_0_15_1  segment_prefix_lb_640  1
    load_0_15_1  segment_prefix_ub_641  1
    load_0_15_1  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_521  -20
    arc_0_15_2  connected_order_arc_522  -13
    arc_0_15_2  in_degree_643  1
    arc_0_15_2  out_degree_681  1
    arc_0_15_2  original_T_including_depot_unload_714  6.0957665440032713e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_521  1
    load_0_15_2  segment_load_conservation_646  -1
    load_0_15_2  segment_prefix_lb_647  1
    load_0_15_2  segment_prefix_ub_648  1
    load_0_15_2  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_523  -20
    arc_0_15_3  connected_order_arc_524  -13
    arc_0_15_3  in_degree_650  1
    arc_0_15_3  out_degree_681  1
    arc_0_15_3  original_T_including_depot_unload_714  4.1343325097934911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_523  1
    load_0_15_3  segment_load_conservation_653  -1
    load_0_15_3  segment_prefix_lb_654  1
    load_0_15_3  segment_prefix_ub_655  1
    load_0_15_3  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_525  -20
    arc_0_15_4  connected_order_arc_526  -13
    arc_0_15_4  in_degree_657  1
    arc_0_15_4  out_degree_681  1
    arc_0_15_4  original_T_including_depot_unload_714  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_525  1
    load_0_15_4  segment_load_conservation_660  -1
    load_0_15_4  segment_prefix_lb_661  1
    load_0_15_4  segment_prefix_ub_662  1
    load_0_15_4  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_527  -20
    arc_0_15_12  connected_order_arc_528  -13
    arc_0_15_12  in_degree_664  1
    arc_0_15_12  out_degree_681  1
    arc_0_15_12  original_T_including_depot_unload_714  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_527  1
    load_0_15_12  free_load_conservation_668  -1
    load_0_15_12  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_529  -20
    arc_0_15_13  connected_order_arc_530  -13
    arc_0_15_13  in_degree_670  1
    arc_0_15_13  out_degree_681  1
    arc_0_15_13  original_T_including_depot_unload_714  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_529  1
    load_0_15_13  free_load_conservation_674  -1
    load_0_15_13  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_531  -20
    arc_0_15_14  connected_order_arc_532  -13
    arc_0_15_14  in_degree_676  1
    arc_0_15_14  out_degree_681  1
    arc_0_15_14  original_T_including_depot_unload_714  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_531  1
    load_0_15_14  free_load_conservation_680  -1
    load_0_15_14  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_533  -20
    arc_0_15_16  connected_order_arc_534  -13
    arc_0_15_16  out_degree_681  1
    arc_0_15_16  in_degree_688  1
    arc_0_15_16  original_T_including_depot_unload_714  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_533  1
    load_0_15_16  free_load_conservation_686  1
    load_0_15_16  free_load_conservation_692  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_535  -20
    arc_0_15_17  connected_order_arc_536  -13
    arc_0_15_17  out_degree_681  1
    arc_0_15_17  in_degree_694  1
    arc_0_15_17  original_T_including_depot_unload_714  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_535  1
    load_0_15_17  free_load_conservation_686  1
    load_0_15_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_537  -20
    arc_0_15_18  connected_order_arc_538  -13
    arc_0_15_18  out_degree_681  1
    arc_0_15_18  in_degree_700  1
    arc_0_15_18  original_T_including_depot_unload_714  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_537  1
    load_0_15_18  free_load_conservation_686  1
    load_0_15_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_539  -20
    arc_0_15_19  connected_order_arc_540  -13
    arc_0_15_19  out_degree_681  1
    arc_0_15_19  in_degree_706  1
    arc_0_15_19  original_T_including_depot_unload_714  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_539  1
    load_0_15_19  free_load_conservation_686  1
    load_0_15_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_541  -20
    arc_0_16_0  depot_return_or_bypass_634  1
    arc_0_16_0  out_degree_687  1
    arc_0_16_0  original_T_including_depot_unload_714  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_541  1
    load_0_16_0  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_542  -20
    arc_0_16_1  connected_order_arc_543  -13
    arc_0_16_1  in_degree_636  1
    arc_0_16_1  out_degree_687  1
    arc_0_16_1  original_T_including_depot_unload_714  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_542  1
    load_0_16_1  segment_load_conservation_639  -1
    load_0_16_1  segment_prefix_lb_640  1
    load_0_16_1  segment_prefix_ub_641  1
    load_0_16_1  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_544  -20
    arc_0_16_2  connected_order_arc_545  -13
    arc_0_16_2  in_degree_643  1
    arc_0_16_2  out_degree_687  1
    arc_0_16_2  original_T_including_depot_unload_714  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_544  1
    load_0_16_2  segment_load_conservation_646  -1
    load_0_16_2  segment_prefix_lb_647  1
    load_0_16_2  segment_prefix_ub_648  1
    load_0_16_2  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_546  -20
    arc_0_16_3  connected_order_arc_547  -13
    arc_0_16_3  in_degree_650  1
    arc_0_16_3  out_degree_687  1
    arc_0_16_3  original_T_including_depot_unload_714  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_546  1
    load_0_16_3  segment_load_conservation_653  -1
    load_0_16_3  segment_prefix_lb_654  1
    load_0_16_3  segment_prefix_ub_655  1
    load_0_16_3  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_548  -20
    arc_0_16_4  connected_order_arc_549  -13
    arc_0_16_4  in_degree_657  1
    arc_0_16_4  out_degree_687  1
    arc_0_16_4  original_T_including_depot_unload_714  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_548  1
    load_0_16_4  segment_load_conservation_660  -1
    load_0_16_4  segment_prefix_lb_661  1
    load_0_16_4  segment_prefix_ub_662  1
    load_0_16_4  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_550  -20
    arc_0_16_12  connected_order_arc_551  -13
    arc_0_16_12  in_degree_664  1
    arc_0_16_12  out_degree_687  1
    arc_0_16_12  original_T_including_depot_unload_714  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_550  1
    load_0_16_12  free_load_conservation_668  -1
    load_0_16_12  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_552  -20
    arc_0_16_13  connected_order_arc_553  -13
    arc_0_16_13  in_degree_670  1
    arc_0_16_13  out_degree_687  1
    arc_0_16_13  original_T_including_depot_unload_714  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_552  1
    load_0_16_13  free_load_conservation_674  -1
    load_0_16_13  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_554  -20
    arc_0_16_14  connected_order_arc_555  -13
    arc_0_16_14  in_degree_676  1
    arc_0_16_14  out_degree_687  1
    arc_0_16_14  original_T_including_depot_unload_714  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_554  1
    load_0_16_14  free_load_conservation_680  -1
    load_0_16_14  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_556  -20
    arc_0_16_15  connected_order_arc_557  -13
    arc_0_16_15  in_degree_682  1
    arc_0_16_15  out_degree_687  1
    arc_0_16_15  original_T_including_depot_unload_714  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_556  1
    load_0_16_15  free_load_conservation_686  -1
    load_0_16_15  free_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_558  -20
    arc_0_16_17  connected_order_arc_559  -13
    arc_0_16_17  out_degree_687  1
    arc_0_16_17  in_degree_694  1
    arc_0_16_17  original_T_including_depot_unload_714  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_558  1
    load_0_16_17  free_load_conservation_692  1
    load_0_16_17  free_load_conservation_698  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_560  -20
    arc_0_16_18  connected_order_arc_561  -13
    arc_0_16_18  out_degree_687  1
    arc_0_16_18  in_degree_700  1
    arc_0_16_18  original_T_including_depot_unload_714  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_560  1
    load_0_16_18  free_load_conservation_692  1
    load_0_16_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_562  -20
    arc_0_16_19  connected_order_arc_563  -13
    arc_0_16_19  out_degree_687  1
    arc_0_16_19  in_degree_706  1
    arc_0_16_19  original_T_including_depot_unload_714  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_562  1
    load_0_16_19  free_load_conservation_692  1
    load_0_16_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_564  -20
    arc_0_17_0  depot_return_or_bypass_634  1
    arc_0_17_0  out_degree_693  1
    arc_0_17_0  original_T_including_depot_unload_714  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_564  1
    load_0_17_0  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_565  -20
    arc_0_17_1  connected_order_arc_566  -13
    arc_0_17_1  in_degree_636  1
    arc_0_17_1  out_degree_693  1
    arc_0_17_1  original_T_including_depot_unload_714  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_565  1
    load_0_17_1  segment_load_conservation_639  -1
    load_0_17_1  segment_prefix_lb_640  1
    load_0_17_1  segment_prefix_ub_641  1
    load_0_17_1  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_567  -20
    arc_0_17_2  connected_order_arc_568  -13
    arc_0_17_2  in_degree_643  1
    arc_0_17_2  out_degree_693  1
    arc_0_17_2  original_T_including_depot_unload_714  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_567  1
    load_0_17_2  segment_load_conservation_646  -1
    load_0_17_2  segment_prefix_lb_647  1
    load_0_17_2  segment_prefix_ub_648  1
    load_0_17_2  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_569  -20
    arc_0_17_3  connected_order_arc_570  -13
    arc_0_17_3  in_degree_650  1
    arc_0_17_3  out_degree_693  1
    arc_0_17_3  original_T_including_depot_unload_714  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_569  1
    load_0_17_3  segment_load_conservation_653  -1
    load_0_17_3  segment_prefix_lb_654  1
    load_0_17_3  segment_prefix_ub_655  1
    load_0_17_3  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_571  -20
    arc_0_17_4  connected_order_arc_572  -13
    arc_0_17_4  in_degree_657  1
    arc_0_17_4  out_degree_693  1
    arc_0_17_4  original_T_including_depot_unload_714  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_571  1
    load_0_17_4  segment_load_conservation_660  -1
    load_0_17_4  segment_prefix_lb_661  1
    load_0_17_4  segment_prefix_ub_662  1
    load_0_17_4  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_573  -20
    arc_0_17_12  connected_order_arc_574  -13
    arc_0_17_12  in_degree_664  1
    arc_0_17_12  out_degree_693  1
    arc_0_17_12  original_T_including_depot_unload_714  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_573  1
    load_0_17_12  free_load_conservation_668  -1
    load_0_17_12  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_575  -20
    arc_0_17_13  connected_order_arc_576  -13
    arc_0_17_13  in_degree_670  1
    arc_0_17_13  out_degree_693  1
    arc_0_17_13  original_T_including_depot_unload_714  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_575  1
    load_0_17_13  free_load_conservation_674  -1
    load_0_17_13  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_577  -20
    arc_0_17_14  connected_order_arc_578  -13
    arc_0_17_14  in_degree_676  1
    arc_0_17_14  out_degree_693  1
    arc_0_17_14  original_T_including_depot_unload_714  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_577  1
    load_0_17_14  free_load_conservation_680  -1
    load_0_17_14  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_579  -20
    arc_0_17_15  connected_order_arc_580  -13
    arc_0_17_15  in_degree_682  1
    arc_0_17_15  out_degree_693  1
    arc_0_17_15  original_T_including_depot_unload_714  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_579  1
    load_0_17_15  free_load_conservation_686  -1
    load_0_17_15  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_581  -20
    arc_0_17_16  connected_order_arc_582  -13
    arc_0_17_16  in_degree_688  1
    arc_0_17_16  out_degree_693  1
    arc_0_17_16  original_T_including_depot_unload_714  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_581  1
    load_0_17_16  free_load_conservation_692  -1
    load_0_17_16  free_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_583  -20
    arc_0_17_18  connected_order_arc_584  -13
    arc_0_17_18  out_degree_693  1
    arc_0_17_18  in_degree_700  1
    arc_0_17_18  original_T_including_depot_unload_714  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_583  1
    load_0_17_18  free_load_conservation_698  1
    load_0_17_18  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_585  -20
    arc_0_17_19  connected_order_arc_586  -13
    arc_0_17_19  out_degree_693  1
    arc_0_17_19  in_degree_706  1
    arc_0_17_19  original_T_including_depot_unload_714  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_585  1
    load_0_17_19  free_load_conservation_698  1
    load_0_17_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_587  -20
    arc_0_18_0  depot_return_or_bypass_634  1
    arc_0_18_0  out_degree_699  1
    arc_0_18_0  original_T_including_depot_unload_714  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_587  1
    load_0_18_0  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_588  -20
    arc_0_18_1  connected_order_arc_589  -13
    arc_0_18_1  in_degree_636  1
    arc_0_18_1  out_degree_699  1
    arc_0_18_1  original_T_including_depot_unload_714  2.0184394615116689e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_588  1
    load_0_18_1  segment_load_conservation_639  -1
    load_0_18_1  segment_prefix_lb_640  1
    load_0_18_1  segment_prefix_ub_641  1
    load_0_18_1  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_590  -20
    arc_0_18_2  connected_order_arc_591  -13
    arc_0_18_2  in_degree_643  1
    arc_0_18_2  out_degree_699  1
    arc_0_18_2  original_T_including_depot_unload_714  1.5797610153191811e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_590  1
    load_0_18_2  segment_load_conservation_646  -1
    load_0_18_2  segment_prefix_lb_647  1
    load_0_18_2  segment_prefix_ub_648  1
    load_0_18_2  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_592  -20
    arc_0_18_3  connected_order_arc_593  -13
    arc_0_18_3  in_degree_650  1
    arc_0_18_3  out_degree_699  1
    arc_0_18_3  original_T_including_depot_unload_714  1.3859443171734331e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_592  1
    load_0_18_3  segment_load_conservation_653  -1
    load_0_18_3  segment_prefix_lb_654  1
    load_0_18_3  segment_prefix_ub_655  1
    load_0_18_3  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_594  -20
    arc_0_18_4  connected_order_arc_595  -13
    arc_0_18_4  in_degree_657  1
    arc_0_18_4  out_degree_699  1
    arc_0_18_4  original_T_including_depot_unload_714  1.2799228371310815e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_594  1
    load_0_18_4  segment_load_conservation_660  -1
    load_0_18_4  segment_prefix_lb_661  1
    load_0_18_4  segment_prefix_ub_662  1
    load_0_18_4  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_596  -20
    arc_0_18_12  connected_order_arc_597  -13
    arc_0_18_12  in_degree_664  1
    arc_0_18_12  out_degree_699  1
    arc_0_18_12  original_T_including_depot_unload_714  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_596  1
    load_0_18_12  free_load_conservation_668  -1
    load_0_18_12  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_598  -20
    arc_0_18_13  connected_order_arc_599  -13
    arc_0_18_13  in_degree_670  1
    arc_0_18_13  out_degree_699  1
    arc_0_18_13  original_T_including_depot_unload_714  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_598  1
    load_0_18_13  free_load_conservation_674  -1
    load_0_18_13  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_600  -20
    arc_0_18_14  connected_order_arc_601  -13
    arc_0_18_14  in_degree_676  1
    arc_0_18_14  out_degree_699  1
    arc_0_18_14  original_T_including_depot_unload_714  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_600  1
    load_0_18_14  free_load_conservation_680  -1
    load_0_18_14  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_602  -20
    arc_0_18_15  connected_order_arc_603  -13
    arc_0_18_15  in_degree_682  1
    arc_0_18_15  out_degree_699  1
    arc_0_18_15  original_T_including_depot_unload_714  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_602  1
    load_0_18_15  free_load_conservation_686  -1
    load_0_18_15  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_604  -20
    arc_0_18_16  connected_order_arc_605  -13
    arc_0_18_16  in_degree_688  1
    arc_0_18_16  out_degree_699  1
    arc_0_18_16  original_T_including_depot_unload_714  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_604  1
    load_0_18_16  free_load_conservation_692  -1
    load_0_18_16  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_606  -20
    arc_0_18_17  connected_order_arc_607  -13
    arc_0_18_17  in_degree_694  1
    arc_0_18_17  out_degree_699  1
    arc_0_18_17  original_T_including_depot_unload_714  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_606  1
    load_0_18_17  free_load_conservation_698  -1
    load_0_18_17  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_608  -20
    arc_0_18_19  connected_order_arc_609  -13
    arc_0_18_19  out_degree_699  1
    arc_0_18_19  in_degree_706  1
    arc_0_18_19  original_T_including_depot_unload_714  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_608  1
    load_0_18_19  free_load_conservation_704  1
    load_0_18_19  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_610  -20
    arc_0_19_0  depot_return_or_bypass_634  1
    arc_0_19_0  out_degree_705  1
    arc_0_19_0  original_T_including_depot_unload_714  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_610  1
    load_0_19_0  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_611  -20
    arc_0_19_1  connected_order_arc_612  -13
    arc_0_19_1  in_degree_636  1
    arc_0_19_1  out_degree_705  1
    arc_0_19_1  original_T_including_depot_unload_714  2.0045579804597039e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_611  1
    load_0_19_1  segment_load_conservation_639  -1
    load_0_19_1  segment_prefix_lb_640  1
    load_0_19_1  segment_prefix_ub_641  1
    load_0_19_1  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_613  -20
    arc_0_19_2  connected_order_arc_614  -13
    arc_0_19_2  in_degree_643  1
    arc_0_19_2  out_degree_705  1
    arc_0_19_2  original_T_including_depot_unload_714  1.5412757472294663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_613  1
    load_0_19_2  segment_load_conservation_646  -1
    load_0_19_2  segment_prefix_lb_647  1
    load_0_19_2  segment_prefix_ub_648  1
    load_0_19_2  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_615  -20
    arc_0_19_3  connected_order_arc_616  -13
    arc_0_19_3  in_degree_650  1
    arc_0_19_3  out_degree_705  1
    arc_0_19_3  original_T_including_depot_unload_714  1.3451277357129768e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_615  1
    load_0_19_3  segment_load_conservation_653  -1
    load_0_19_3  segment_prefix_lb_654  1
    load_0_19_3  segment_prefix_ub_655  1
    load_0_19_3  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_617  -20
    arc_0_19_4  connected_order_arc_618  -13
    arc_0_19_4  in_degree_657  1
    arc_0_19_4  out_degree_705  1
    arc_0_19_4  original_T_including_depot_unload_714  1.2401143998876444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_617  1
    load_0_19_4  segment_load_conservation_660  -1
    load_0_19_4  segment_prefix_lb_661  1
    load_0_19_4  segment_prefix_ub_662  1
    load_0_19_4  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_619  -20
    arc_0_19_12  connected_order_arc_620  -13
    arc_0_19_12  in_degree_664  1
    arc_0_19_12  out_degree_705  1
    arc_0_19_12  original_T_including_depot_unload_714  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_619  1
    load_0_19_12  free_load_conservation_668  -1
    load_0_19_12  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_621  -20
    arc_0_19_13  connected_order_arc_622  -13
    arc_0_19_13  in_degree_670  1
    arc_0_19_13  out_degree_705  1
    arc_0_19_13  original_T_including_depot_unload_714  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_621  1
    load_0_19_13  free_load_conservation_674  -1
    load_0_19_13  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_623  -20
    arc_0_19_14  connected_order_arc_624  -13
    arc_0_19_14  in_degree_676  1
    arc_0_19_14  out_degree_705  1
    arc_0_19_14  original_T_including_depot_unload_714  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_623  1
    load_0_19_14  free_load_conservation_680  -1
    load_0_19_14  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_625  -20
    arc_0_19_15  connected_order_arc_626  -13
    arc_0_19_15  in_degree_682  1
    arc_0_19_15  out_degree_705  1
    arc_0_19_15  original_T_including_depot_unload_714  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_625  1
    load_0_19_15  free_load_conservation_686  -1
    load_0_19_15  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_627  -20
    arc_0_19_16  connected_order_arc_628  -13
    arc_0_19_16  in_degree_688  1
    arc_0_19_16  out_degree_705  1
    arc_0_19_16  original_T_including_depot_unload_714  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_627  1
    load_0_19_16  free_load_conservation_692  -1
    load_0_19_16  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_629  -20
    arc_0_19_17  connected_order_arc_630  -13
    arc_0_19_17  in_degree_694  1
    arc_0_19_17  out_degree_705  1
    arc_0_19_17  original_T_including_depot_unload_714  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_629  1
    load_0_19_17  free_load_conservation_698  -1
    load_0_19_17  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_631  -20
    arc_0_19_18  connected_order_arc_632  -13
    arc_0_19_18  in_degree_700  1
    arc_0_19_18  out_degree_705  1
    arc_0_19_18  original_T_including_depot_unload_714  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_631  1
    load_0_19_18  free_load_conservation_704  -1
    load_0_19_18  free_load_conservation_710  1
    visit_1_5  out_degree_1006  -1
    visit_1_5  in_degree_1007  -1
    visit_1_5  order_active_lb_1008  -1
    visit_1_5  order_active_ub_1009  -12
    order_1_5  connected_order_arc_730  -1
    order_1_5  connected_order_arc_732  -1
    order_1_5  connected_order_arc_734  -1
    order_1_5  connected_order_arc_736  -1
    order_1_5  connected_order_arc_738  -1
    order_1_5  connected_order_arc_740  -1
    order_1_5  connected_order_arc_742  -1
    order_1_5  connected_order_arc_744  -1
    order_1_5  connected_order_arc_746  -1
    order_1_5  connected_order_arc_748  -1
    order_1_5  connected_order_arc_750  -1
    order_1_5  connected_order_arc_753  1
    order_1_5  connected_order_arc_776  1
    order_1_5  connected_order_arc_799  1
    order_1_5  connected_order_arc_822  1
    order_1_5  connected_order_arc_845  1
    order_1_5  connected_order_arc_868  1
    order_1_5  connected_order_arc_891  1
    order_1_5  connected_order_arc_914  1
    order_1_5  connected_order_arc_937  1
    order_1_5  connected_order_arc_960  1
    order_1_5  connected_order_arc_983  1
    order_1_5  order_active_lb_1008  1
    order_1_5  order_active_ub_1009  1
    order_1_5  fixed_segment_relative_order_1082  -1
    visit_1_6  out_degree_1013  -1
    visit_1_6  in_degree_1014  -1
    visit_1_6  order_active_lb_1015  -1
    visit_1_6  order_active_ub_1016  -12
    order_1_6  connected_order_arc_730  1
    order_1_6  connected_order_arc_753  -1
    order_1_6  connected_order_arc_755  -1
    order_1_6  connected_order_arc_757  -1
    order_1_6  connected_order_arc_759  -1
    order_1_6  connected_order_arc_761  -1
    order_1_6  connected_order_arc_763  -1
    order_1_6  connected_order_arc_765  -1
    order_1_6  connected_order_arc_767  -1
    order_1_6  connected_order_arc_769  -1
    order_1_6  connected_order_arc_771  -1
    order_1_6  connected_order_arc_773  -1
    order_1_6  connected_order_arc_778  1
    order_1_6  connected_order_arc_801  1
    order_1_6  connected_order_arc_824  1
    order_1_6  connected_order_arc_847  1
    order_1_6  connected_order_arc_870  1
    order_1_6  connected_order_arc_893  1
    order_1_6  connected_order_arc_916  1
    order_1_6  connected_order_arc_939  1
    order_1_6  connected_order_arc_962  1
    order_1_6  connected_order_arc_985  1
    order_1_6  order_active_lb_1015  1
    order_1_6  order_active_ub_1016  1
    order_1_6  fixed_segment_relative_order_1082  1
    order_1_6  fixed_segment_relative_order_1083  -1
    visit_1_7  out_degree_1020  -1
    visit_1_7  in_degree_1021  -1
    visit_1_7  order_active_lb_1022  -1
    visit_1_7  order_active_ub_1023  -12
    order_1_7  connected_order_arc_732  1
    order_1_7  connected_order_arc_755  1
    order_1_7  connected_order_arc_776  -1
    order_1_7  connected_order_arc_778  -1
    order_1_7  connected_order_arc_780  -1
    order_1_7  connected_order_arc_782  -1
    order_1_7  connected_order_arc_784  -1
    order_1_7  connected_order_arc_786  -1
    order_1_7  connected_order_arc_788  -1
    order_1_7  connected_order_arc_790  -1
    order_1_7  connected_order_arc_792  -1
    order_1_7  connected_order_arc_794  -1
    order_1_7  connected_order_arc_796  -1
    order_1_7  connected_order_arc_803  1
    order_1_7  connected_order_arc_826  1
    order_1_7  connected_order_arc_849  1
    order_1_7  connected_order_arc_872  1
    order_1_7  connected_order_arc_895  1
    order_1_7  connected_order_arc_918  1
    order_1_7  connected_order_arc_941  1
    order_1_7  connected_order_arc_964  1
    order_1_7  connected_order_arc_987  1
    order_1_7  order_active_lb_1022  1
    order_1_7  order_active_ub_1023  1
    order_1_7  fixed_segment_relative_order_1083  1
    order_1_7  fixed_segment_relative_order_1084  -1
    visit_1_8  out_degree_1027  -1
    visit_1_8  in_degree_1028  -1
    visit_1_8  order_active_lb_1029  -1
    visit_1_8  order_active_ub_1030  -12
    order_1_8  connected_order_arc_734  1
    order_1_8  connected_order_arc_757  1
    order_1_8  connected_order_arc_780  1
    order_1_8  connected_order_arc_799  -1
    order_1_8  connected_order_arc_801  -1
    order_1_8  connected_order_arc_803  -1
    order_1_8  connected_order_arc_805  -1
    order_1_8  connected_order_arc_807  -1
    order_1_8  connected_order_arc_809  -1
    order_1_8  connected_order_arc_811  -1
    order_1_8  connected_order_arc_813  -1
    order_1_8  connected_order_arc_815  -1
    order_1_8  connected_order_arc_817  -1
    order_1_8  connected_order_arc_819  -1
    order_1_8  connected_order_arc_828  1
    order_1_8  connected_order_arc_851  1
    order_1_8  connected_order_arc_874  1
    order_1_8  connected_order_arc_897  1
    order_1_8  connected_order_arc_920  1
    order_1_8  connected_order_arc_943  1
    order_1_8  connected_order_arc_966  1
    order_1_8  connected_order_arc_989  1
    order_1_8  order_active_lb_1029  1
    order_1_8  order_active_ub_1030  1
    order_1_8  fixed_segment_relative_order_1084  1
    visit_1_12  out_degree_1034  -1
    visit_1_12  in_degree_1035  -1
    visit_1_12  order_active_lb_1036  -1
    visit_1_12  order_active_ub_1037  -12
    visit_1_12  service_visit_def_1038  -1
    order_1_12  connected_order_arc_736  1
    order_1_12  connected_order_arc_759  1
    order_1_12  connected_order_arc_782  1
    order_1_12  connected_order_arc_805  1
    order_1_12  connected_order_arc_822  -1
    order_1_12  connected_order_arc_824  -1
    order_1_12  connected_order_arc_826  -1
    order_1_12  connected_order_arc_828  -1
    order_1_12  connected_order_arc_830  -1
    order_1_12  connected_order_arc_832  -1
    order_1_12  connected_order_arc_834  -1
    order_1_12  connected_order_arc_836  -1
    order_1_12  connected_order_arc_838  -1
    order_1_12  connected_order_arc_840  -1
    order_1_12  connected_order_arc_842  -1
    order_1_12  connected_order_arc_853  1
    order_1_12  connected_order_arc_876  1
    order_1_12  connected_order_arc_899  1
    order_1_12  connected_order_arc_922  1
    order_1_12  connected_order_arc_945  1
    order_1_12  connected_order_arc_968  1
    order_1_12  connected_order_arc_991  1
    order_1_12  order_active_lb_1036  1
    order_1_12  order_active_ub_1037  1
    visit_1_13  out_degree_1040  -1
    visit_1_13  in_degree_1041  -1
    visit_1_13  order_active_lb_1042  -1
    visit_1_13  order_active_ub_1043  -12
    visit_1_13  service_visit_def_1044  -1
    order_1_13  connected_order_arc_738  1
    order_1_13  connected_order_arc_761  1
    order_1_13  connected_order_arc_784  1
    order_1_13  connected_order_arc_807  1
    order_1_13  connected_order_arc_830  1
    order_1_13  connected_order_arc_845  -1
    order_1_13  connected_order_arc_847  -1
    order_1_13  connected_order_arc_849  -1
    order_1_13  connected_order_arc_851  -1
    order_1_13  connected_order_arc_853  -1
    order_1_13  connected_order_arc_855  -1
    order_1_13  connected_order_arc_857  -1
    order_1_13  connected_order_arc_859  -1
    order_1_13  connected_order_arc_861  -1
    order_1_13  connected_order_arc_863  -1
    order_1_13  connected_order_arc_865  -1
    order_1_13  connected_order_arc_878  1
    order_1_13  connected_order_arc_901  1
    order_1_13  connected_order_arc_924  1
    order_1_13  connected_order_arc_947  1
    order_1_13  connected_order_arc_970  1
    order_1_13  connected_order_arc_993  1
    order_1_13  order_active_lb_1042  1
    order_1_13  order_active_ub_1043  1
    visit_1_14  out_degree_1046  -1
    visit_1_14  in_degree_1047  -1
    visit_1_14  order_active_lb_1048  -1
    visit_1_14  order_active_ub_1049  -12
    visit_1_14  service_visit_def_1050  -1
    order_1_14  connected_order_arc_740  1
    order_1_14  connected_order_arc_763  1
    order_1_14  connected_order_arc_786  1
    order_1_14  connected_order_arc_809  1
    order_1_14  connected_order_arc_832  1
    order_1_14  connected_order_arc_855  1
    order_1_14  connected_order_arc_868  -1
    order_1_14  connected_order_arc_870  -1
    order_1_14  connected_order_arc_872  -1
    order_1_14  connected_order_arc_874  -1
    order_1_14  connected_order_arc_876  -1
    order_1_14  connected_order_arc_878  -1
    order_1_14  connected_order_arc_880  -1
    order_1_14  connected_order_arc_882  -1
    order_1_14  connected_order_arc_884  -1
    order_1_14  connected_order_arc_886  -1
    order_1_14  connected_order_arc_888  -1
    order_1_14  connected_order_arc_903  1
    order_1_14  connected_order_arc_926  1
    order_1_14  connected_order_arc_949  1
    order_1_14  connected_order_arc_972  1
    order_1_14  connected_order_arc_995  1
    order_1_14  order_active_lb_1048  1
    order_1_14  order_active_ub_1049  1
    visit_1_15  out_degree_1052  -1
    visit_1_15  in_degree_1053  -1
    visit_1_15  order_active_lb_1054  -1
    visit_1_15  order_active_ub_1055  -12
    visit_1_15  service_visit_def_1056  -1
    order_1_15  connected_order_arc_742  1
    order_1_15  connected_order_arc_765  1
    order_1_15  connected_order_arc_788  1
    order_1_15  connected_order_arc_811  1
    order_1_15  connected_order_arc_834  1
    order_1_15  connected_order_arc_857  1
    order_1_15  connected_order_arc_880  1
    order_1_15  connected_order_arc_891  -1
    order_1_15  connected_order_arc_893  -1
    order_1_15  connected_order_arc_895  -1
    order_1_15  connected_order_arc_897  -1
    order_1_15  connected_order_arc_899  -1
    order_1_15  connected_order_arc_901  -1
    order_1_15  connected_order_arc_903  -1
    order_1_15  connected_order_arc_905  -1
    order_1_15  connected_order_arc_907  -1
    order_1_15  connected_order_arc_909  -1
    order_1_15  connected_order_arc_911  -1
    order_1_15  connected_order_arc_928  1
    order_1_15  connected_order_arc_951  1
    order_1_15  connected_order_arc_974  1
    order_1_15  connected_order_arc_997  1
    order_1_15  order_active_lb_1054  1
    order_1_15  order_active_ub_1055  1
    visit_1_16  out_degree_1058  -1
    visit_1_16  in_degree_1059  -1
    visit_1_16  order_active_lb_1060  -1
    visit_1_16  order_active_ub_1061  -12
    visit_1_16  service_visit_def_1062  -1
    order_1_16  connected_order_arc_744  1
    order_1_16  connected_order_arc_767  1
    order_1_16  connected_order_arc_790  1
    order_1_16  connected_order_arc_813  1
    order_1_16  connected_order_arc_836  1
    order_1_16  connected_order_arc_859  1
    order_1_16  connected_order_arc_882  1
    order_1_16  connected_order_arc_905  1
    order_1_16  connected_order_arc_914  -1
    order_1_16  connected_order_arc_916  -1
    order_1_16  connected_order_arc_918  -1
    order_1_16  connected_order_arc_920  -1
    order_1_16  connected_order_arc_922  -1
    order_1_16  connected_order_arc_924  -1
    order_1_16  connected_order_arc_926  -1
    order_1_16  connected_order_arc_928  -1
    order_1_16  connected_order_arc_930  -1
    order_1_16  connected_order_arc_932  -1
    order_1_16  connected_order_arc_934  -1
    order_1_16  connected_order_arc_953  1
    order_1_16  connected_order_arc_976  1
    order_1_16  connected_order_arc_999  1
    order_1_16  order_active_lb_1060  1
    order_1_16  order_active_ub_1061  1
    visit_1_17  out_degree_1064  -1
    visit_1_17  in_degree_1065  -1
    visit_1_17  order_active_lb_1066  -1
    visit_1_17  order_active_ub_1067  -12
    visit_1_17  service_visit_def_1068  -1
    order_1_17  connected_order_arc_746  1
    order_1_17  connected_order_arc_769  1
    order_1_17  connected_order_arc_792  1
    order_1_17  connected_order_arc_815  1
    order_1_17  connected_order_arc_838  1
    order_1_17  connected_order_arc_861  1
    order_1_17  connected_order_arc_884  1
    order_1_17  connected_order_arc_907  1
    order_1_17  connected_order_arc_930  1
    order_1_17  connected_order_arc_937  -1
    order_1_17  connected_order_arc_939  -1
    order_1_17  connected_order_arc_941  -1
    order_1_17  connected_order_arc_943  -1
    order_1_17  connected_order_arc_945  -1
    order_1_17  connected_order_arc_947  -1
    order_1_17  connected_order_arc_949  -1
    order_1_17  connected_order_arc_951  -1
    order_1_17  connected_order_arc_953  -1
    order_1_17  connected_order_arc_955  -1
    order_1_17  connected_order_arc_957  -1
    order_1_17  connected_order_arc_978  1
    order_1_17  connected_order_arc_1001  1
    order_1_17  order_active_lb_1066  1
    order_1_17  order_active_ub_1067  1
    visit_1_18  out_degree_1070  -1
    visit_1_18  in_degree_1071  -1
    visit_1_18  order_active_lb_1072  -1
    visit_1_18  order_active_ub_1073  -12
    visit_1_18  service_visit_def_1074  -1
    order_1_18  connected_order_arc_748  1
    order_1_18  connected_order_arc_771  1
    order_1_18  connected_order_arc_794  1
    order_1_18  connected_order_arc_817  1
    order_1_18  connected_order_arc_840  1
    order_1_18  connected_order_arc_863  1
    order_1_18  connected_order_arc_886  1
    order_1_18  connected_order_arc_909  1
    order_1_18  connected_order_arc_932  1
    order_1_18  connected_order_arc_955  1
    order_1_18  connected_order_arc_960  -1
    order_1_18  connected_order_arc_962  -1
    order_1_18  connected_order_arc_964  -1
    order_1_18  connected_order_arc_966  -1
    order_1_18  connected_order_arc_968  -1
    order_1_18  connected_order_arc_970  -1
    order_1_18  connected_order_arc_972  -1
    order_1_18  connected_order_arc_974  -1
    order_1_18  connected_order_arc_976  -1
    order_1_18  connected_order_arc_978  -1
    order_1_18  connected_order_arc_980  -1
    order_1_18  connected_order_arc_1003  1
    order_1_18  order_active_lb_1072  1
    order_1_18  order_active_ub_1073  1
    visit_1_19  out_degree_1076  -1
    visit_1_19  in_degree_1077  -1
    visit_1_19  order_active_lb_1078  -1
    visit_1_19  order_active_ub_1079  -12
    visit_1_19  service_visit_def_1080  -1
    order_1_19  connected_order_arc_750  1
    order_1_19  connected_order_arc_773  1
    order_1_19  connected_order_arc_796  1
    order_1_19  connected_order_arc_819  1
    order_1_19  connected_order_arc_842  1
    order_1_19  connected_order_arc_865  1
    order_1_19  connected_order_arc_888  1
    order_1_19  connected_order_arc_911  1
    order_1_19  connected_order_arc_934  1
    order_1_19  connected_order_arc_957  1
    order_1_19  connected_order_arc_980  1
    order_1_19  connected_order_arc_983  -1
    order_1_19  connected_order_arc_985  -1
    order_1_19  connected_order_arc_987  -1
    order_1_19  connected_order_arc_989  -1
    order_1_19  connected_order_arc_991  -1
    order_1_19  connected_order_arc_993  -1
    order_1_19  connected_order_arc_995  -1
    order_1_19  connected_order_arc_997  -1
    order_1_19  connected_order_arc_999  -1
    order_1_19  connected_order_arc_1001  -1
    order_1_19  connected_order_arc_1003  -1
    order_1_19  order_active_lb_1078  1
    order_1_19  order_active_ub_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_715  -25
    arc_1_0_0  depot_departure_or_bypass_1004  1
    arc_1_0_0  depot_return_or_bypass_1005  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_716  -25
    arc_1_0_5  depot_departure_or_bypass_1004  1
    arc_1_0_5  in_degree_1007  1
    arc_1_0_5  original_T_including_depot_unload_1085  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_716  1
    load_1_0_5  segment_load_conservation_1010  -1
    load_1_0_5  segment_prefix_lb_1011  1
    load_1_0_5  segment_prefix_ub_1012  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_717  -25
    arc_1_0_6  depot_departure_or_bypass_1004  1
    arc_1_0_6  in_degree_1014  1
    arc_1_0_6  original_T_including_depot_unload_1085  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_717  1
    load_1_0_6  segment_load_conservation_1017  -1
    load_1_0_6  segment_prefix_lb_1018  1
    load_1_0_6  segment_prefix_ub_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_718  -25
    arc_1_0_7  depot_departure_or_bypass_1004  1
    arc_1_0_7  in_degree_1021  1
    arc_1_0_7  original_T_including_depot_unload_1085  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_718  1
    load_1_0_7  segment_load_conservation_1024  -1
    load_1_0_7  segment_prefix_lb_1025  1
    load_1_0_7  segment_prefix_ub_1026  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_719  -25
    arc_1_0_8  depot_departure_or_bypass_1004  1
    arc_1_0_8  in_degree_1028  1
    arc_1_0_8  original_T_including_depot_unload_1085  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_719  1
    load_1_0_8  segment_load_conservation_1031  -1
    load_1_0_8  segment_prefix_lb_1032  1
    load_1_0_8  segment_prefix_ub_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_720  -25
    arc_1_0_12  depot_departure_or_bypass_1004  1
    arc_1_0_12  in_degree_1035  1
    arc_1_0_12  original_T_including_depot_unload_1085  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_720  1
    load_1_0_12  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_721  -25
    arc_1_0_13  depot_departure_or_bypass_1004  1
    arc_1_0_13  in_degree_1041  1
    arc_1_0_13  original_T_including_depot_unload_1085  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_721  1
    load_1_0_13  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_722  -25
    arc_1_0_14  depot_departure_or_bypass_1004  1
    arc_1_0_14  in_degree_1047  1
    arc_1_0_14  original_T_including_depot_unload_1085  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_722  1
    load_1_0_14  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_723  -25
    arc_1_0_15  depot_departure_or_bypass_1004  1
    arc_1_0_15  in_degree_1053  1
    arc_1_0_15  original_T_including_depot_unload_1085  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_723  1
    load_1_0_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_724  -25
    arc_1_0_16  depot_departure_or_bypass_1004  1
    arc_1_0_16  in_degree_1059  1
    arc_1_0_16  original_T_including_depot_unload_1085  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_724  1
    load_1_0_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_725  -25
    arc_1_0_17  depot_departure_or_bypass_1004  1
    arc_1_0_17  in_degree_1065  1
    arc_1_0_17  original_T_including_depot_unload_1085  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_725  1
    load_1_0_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_726  -25
    arc_1_0_18  depot_departure_or_bypass_1004  1
    arc_1_0_18  in_degree_1071  1
    arc_1_0_18  original_T_including_depot_unload_1085  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_726  1
    load_1_0_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_727  -25
    arc_1_0_19  depot_departure_or_bypass_1004  1
    arc_1_0_19  in_degree_1077  1
    arc_1_0_19  original_T_including_depot_unload_1085  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_727  1
    load_1_0_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_728  -25
    arc_1_5_0  depot_return_or_bypass_1005  1
    arc_1_5_0  out_degree_1006  1
    arc_1_5_0  original_T_including_depot_unload_1085  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_728  1
    load_1_5_0  segment_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_729  -25
    arc_1_5_6  connected_order_arc_730  -13
    arc_1_5_6  out_degree_1006  1
    arc_1_5_6  in_degree_1014  1
    arc_1_5_6  original_T_including_depot_unload_1085  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_729  1
    load_1_5_6  segment_load_conservation_1010  1
    load_1_5_6  segment_load_conservation_1017  -1
    load_1_5_6  segment_prefix_lb_1018  1
    load_1_5_6  segment_prefix_ub_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_731  -25
    arc_1_5_7  connected_order_arc_732  -13
    arc_1_5_7  out_degree_1006  1
    arc_1_5_7  in_degree_1021  1
    arc_1_5_7  original_T_including_depot_unload_1085  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_731  1
    load_1_5_7  segment_load_conservation_1010  1
    load_1_5_7  segment_load_conservation_1024  -1
    load_1_5_7  segment_prefix_lb_1025  1
    load_1_5_7  segment_prefix_ub_1026  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_733  -25
    arc_1_5_8  connected_order_arc_734  -13
    arc_1_5_8  out_degree_1006  1
    arc_1_5_8  in_degree_1028  1
    arc_1_5_8  original_T_including_depot_unload_1085  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_733  1
    load_1_5_8  segment_load_conservation_1010  1
    load_1_5_8  segment_load_conservation_1031  -1
    load_1_5_8  segment_prefix_lb_1032  1
    load_1_5_8  segment_prefix_ub_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_735  -25
    arc_1_5_12  connected_order_arc_736  -13
    arc_1_5_12  out_degree_1006  1
    arc_1_5_12  in_degree_1035  1
    arc_1_5_12  original_T_including_depot_unload_1085  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_735  1
    load_1_5_12  segment_load_conservation_1010  1
    load_1_5_12  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_737  -25
    arc_1_5_13  connected_order_arc_738  -13
    arc_1_5_13  out_degree_1006  1
    arc_1_5_13  in_degree_1041  1
    arc_1_5_13  original_T_including_depot_unload_1085  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_737  1
    load_1_5_13  segment_load_conservation_1010  1
    load_1_5_13  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_739  -25
    arc_1_5_14  connected_order_arc_740  -13
    arc_1_5_14  out_degree_1006  1
    arc_1_5_14  in_degree_1047  1
    arc_1_5_14  original_T_including_depot_unload_1085  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_739  1
    load_1_5_14  segment_load_conservation_1010  1
    load_1_5_14  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_741  -25
    arc_1_5_15  connected_order_arc_742  -13
    arc_1_5_15  out_degree_1006  1
    arc_1_5_15  in_degree_1053  1
    arc_1_5_15  original_T_including_depot_unload_1085  1.5356438916798834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_741  1
    load_1_5_15  segment_load_conservation_1010  1
    load_1_5_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_743  -25
    arc_1_5_16  connected_order_arc_744  -13
    arc_1_5_16  out_degree_1006  1
    arc_1_5_16  in_degree_1059  1
    arc_1_5_16  original_T_including_depot_unload_1085  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_743  1
    load_1_5_16  segment_load_conservation_1010  1
    load_1_5_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_745  -25
    arc_1_5_17  connected_order_arc_746  -13
    arc_1_5_17  out_degree_1006  1
    arc_1_5_17  in_degree_1065  1
    arc_1_5_17  original_T_including_depot_unload_1085  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_745  1
    load_1_5_17  segment_load_conservation_1010  1
    load_1_5_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_747  -25
    arc_1_5_18  connected_order_arc_748  -13
    arc_1_5_18  out_degree_1006  1
    arc_1_5_18  in_degree_1071  1
    arc_1_5_18  original_T_including_depot_unload_1085  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_747  1
    load_1_5_18  segment_load_conservation_1010  1
    load_1_5_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_749  -25
    arc_1_5_19  connected_order_arc_750  -13
    arc_1_5_19  out_degree_1006  1
    arc_1_5_19  in_degree_1077  1
    arc_1_5_19  original_T_including_depot_unload_1085  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_749  1
    load_1_5_19  segment_load_conservation_1010  1
    load_1_5_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_751  -25
    arc_1_6_0  depot_return_or_bypass_1005  1
    arc_1_6_0  out_degree_1013  1
    arc_1_6_0  original_T_including_depot_unload_1085  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_751  1
    load_1_6_0  segment_load_conservation_1017  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_752  -25
    arc_1_6_5  connected_order_arc_753  -13
    arc_1_6_5  in_degree_1007  1
    arc_1_6_5  out_degree_1013  1
    arc_1_6_5  original_T_including_depot_unload_1085  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_752  1
    load_1_6_5  segment_load_conservation_1010  -1
    load_1_6_5  segment_prefix_lb_1011  1
    load_1_6_5  segment_prefix_ub_1012  1
    load_1_6_5  segment_load_conservation_1017  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_754  -25
    arc_1_6_7  connected_order_arc_755  -13
    arc_1_6_7  out_degree_1013  1
    arc_1_6_7  in_degree_1021  1
    arc_1_6_7  original_T_including_depot_unload_1085  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_754  1
    load_1_6_7  segment_load_conservation_1017  1
    load_1_6_7  segment_load_conservation_1024  -1
    load_1_6_7  segment_prefix_lb_1025  1
    load_1_6_7  segment_prefix_ub_1026  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_756  -25
    arc_1_6_8  connected_order_arc_757  -13
    arc_1_6_8  out_degree_1013  1
    arc_1_6_8  in_degree_1028  1
    arc_1_6_8  original_T_including_depot_unload_1085  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_756  1
    load_1_6_8  segment_load_conservation_1017  1
    load_1_6_8  segment_load_conservation_1031  -1
    load_1_6_8  segment_prefix_lb_1032  1
    load_1_6_8  segment_prefix_ub_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_758  -25
    arc_1_6_12  connected_order_arc_759  -13
    arc_1_6_12  out_degree_1013  1
    arc_1_6_12  in_degree_1035  1
    arc_1_6_12  original_T_including_depot_unload_1085  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_758  1
    load_1_6_12  segment_load_conservation_1017  1
    load_1_6_12  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_760  -25
    arc_1_6_13  connected_order_arc_761  -13
    arc_1_6_13  out_degree_1013  1
    arc_1_6_13  in_degree_1041  1
    arc_1_6_13  original_T_including_depot_unload_1085  2.1806564621513235e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_760  1
    load_1_6_13  segment_load_conservation_1017  1
    load_1_6_13  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_762  -25
    arc_1_6_14  connected_order_arc_763  -13
    arc_1_6_14  out_degree_1013  1
    arc_1_6_14  in_degree_1047  1
    arc_1_6_14  original_T_including_depot_unload_1085  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_762  1
    load_1_6_14  segment_load_conservation_1017  1
    load_1_6_14  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_764  -25
    arc_1_6_15  connected_order_arc_765  -13
    arc_1_6_15  out_degree_1013  1
    arc_1_6_15  in_degree_1053  1
    arc_1_6_15  original_T_including_depot_unload_1085  1.9765601995118598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_764  1
    load_1_6_15  segment_load_conservation_1017  1
    load_1_6_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_766  -25
    arc_1_6_16  connected_order_arc_767  -13
    arc_1_6_16  out_degree_1013  1
    arc_1_6_16  in_degree_1059  1
    arc_1_6_16  original_T_including_depot_unload_1085  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_766  1
    load_1_6_16  segment_load_conservation_1017  1
    load_1_6_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_768  -25
    arc_1_6_17  connected_order_arc_769  -13
    arc_1_6_17  out_degree_1013  1
    arc_1_6_17  in_degree_1065  1
    arc_1_6_17  original_T_including_depot_unload_1085  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_768  1
    load_1_6_17  segment_load_conservation_1017  1
    load_1_6_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_770  -25
    arc_1_6_18  connected_order_arc_771  -13
    arc_1_6_18  out_degree_1013  1
    arc_1_6_18  in_degree_1071  1
    arc_1_6_18  original_T_including_depot_unload_1085  2.9006291140474787e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_770  1
    load_1_6_18  segment_load_conservation_1017  1
    load_1_6_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_772  -25
    arc_1_6_19  connected_order_arc_773  -13
    arc_1_6_19  out_degree_1013  1
    arc_1_6_19  in_degree_1077  1
    arc_1_6_19  original_T_including_depot_unload_1085  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_772  1
    load_1_6_19  segment_load_conservation_1017  1
    load_1_6_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_774  -25
    arc_1_7_0  depot_return_or_bypass_1005  1
    arc_1_7_0  out_degree_1020  1
    arc_1_7_0  original_T_including_depot_unload_1085  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_774  1
    load_1_7_0  segment_load_conservation_1024  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_775  -25
    arc_1_7_5  connected_order_arc_776  -13
    arc_1_7_5  in_degree_1007  1
    arc_1_7_5  out_degree_1020  1
    arc_1_7_5  original_T_including_depot_unload_1085  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_775  1
    load_1_7_5  segment_load_conservation_1010  -1
    load_1_7_5  segment_prefix_lb_1011  1
    load_1_7_5  segment_prefix_ub_1012  1
    load_1_7_5  segment_load_conservation_1024  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_777  -25
    arc_1_7_6  connected_order_arc_778  -13
    arc_1_7_6  in_degree_1014  1
    arc_1_7_6  out_degree_1020  1
    arc_1_7_6  original_T_including_depot_unload_1085  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_777  1
    load_1_7_6  segment_load_conservation_1017  -1
    load_1_7_6  segment_prefix_lb_1018  1
    load_1_7_6  segment_prefix_ub_1019  1
    load_1_7_6  segment_load_conservation_1024  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_779  -25
    arc_1_7_8  connected_order_arc_780  -13
    arc_1_7_8  out_degree_1020  1
    arc_1_7_8  in_degree_1028  1
    arc_1_7_8  original_T_including_depot_unload_1085  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_779  1
    load_1_7_8  segment_load_conservation_1024  1
    load_1_7_8  segment_load_conservation_1031  -1
    load_1_7_8  segment_prefix_lb_1032  1
    load_1_7_8  segment_prefix_ub_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_781  -25
    arc_1_7_12  connected_order_arc_782  -13
    arc_1_7_12  out_degree_1020  1
    arc_1_7_12  in_degree_1035  1
    arc_1_7_12  original_T_including_depot_unload_1085  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_781  1
    load_1_7_12  segment_load_conservation_1024  1
    load_1_7_12  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_783  -25
    arc_1_7_13  connected_order_arc_784  -13
    arc_1_7_13  out_degree_1020  1
    arc_1_7_13  in_degree_1041  1
    arc_1_7_13  original_T_including_depot_unload_1085  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_783  1
    load_1_7_13  segment_load_conservation_1024  1
    load_1_7_13  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_785  -25
    arc_1_7_14  connected_order_arc_786  -13
    arc_1_7_14  out_degree_1020  1
    arc_1_7_14  in_degree_1047  1
    arc_1_7_14  original_T_including_depot_unload_1085  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_785  1
    load_1_7_14  segment_load_conservation_1024  1
    load_1_7_14  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_787  -25
    arc_1_7_15  connected_order_arc_788  -13
    arc_1_7_15  out_degree_1020  1
    arc_1_7_15  in_degree_1053  1
    arc_1_7_15  original_T_including_depot_unload_1085  1.1150690045767951e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_787  1
    load_1_7_15  segment_load_conservation_1024  1
    load_1_7_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_789  -25
    arc_1_7_16  connected_order_arc_790  -13
    arc_1_7_16  out_degree_1020  1
    arc_1_7_16  in_degree_1059  1
    arc_1_7_16  original_T_including_depot_unload_1085  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_789  1
    load_1_7_16  segment_load_conservation_1024  1
    load_1_7_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_791  -25
    arc_1_7_17  connected_order_arc_792  -13
    arc_1_7_17  out_degree_1020  1
    arc_1_7_17  in_degree_1065  1
    arc_1_7_17  original_T_including_depot_unload_1085  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_791  1
    load_1_7_17  segment_load_conservation_1024  1
    load_1_7_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_793  -25
    arc_1_7_18  connected_order_arc_794  -13
    arc_1_7_18  out_degree_1020  1
    arc_1_7_18  in_degree_1071  1
    arc_1_7_18  original_T_including_depot_unload_1085  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_793  1
    load_1_7_18  segment_load_conservation_1024  1
    load_1_7_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_795  -25
    arc_1_7_19  connected_order_arc_796  -13
    arc_1_7_19  out_degree_1020  1
    arc_1_7_19  in_degree_1077  1
    arc_1_7_19  original_T_including_depot_unload_1085  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_795  1
    load_1_7_19  segment_load_conservation_1024  1
    load_1_7_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_797  -25
    arc_1_8_0  depot_return_or_bypass_1005  1
    arc_1_8_0  out_degree_1027  1
    arc_1_8_0  original_T_including_depot_unload_1085  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_797  1
    load_1_8_0  segment_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_798  -25
    arc_1_8_5  connected_order_arc_799  -13
    arc_1_8_5  in_degree_1007  1
    arc_1_8_5  out_degree_1027  1
    arc_1_8_5  original_T_including_depot_unload_1085  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_798  1
    load_1_8_5  segment_load_conservation_1010  -1
    load_1_8_5  segment_prefix_lb_1011  1
    load_1_8_5  segment_prefix_ub_1012  1
    load_1_8_5  segment_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_800  -25
    arc_1_8_6  connected_order_arc_801  -13
    arc_1_8_6  in_degree_1014  1
    arc_1_8_6  out_degree_1027  1
    arc_1_8_6  original_T_including_depot_unload_1085  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_800  1
    load_1_8_6  segment_load_conservation_1017  -1
    load_1_8_6  segment_prefix_lb_1018  1
    load_1_8_6  segment_prefix_ub_1019  1
    load_1_8_6  segment_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_802  -25
    arc_1_8_7  connected_order_arc_803  -13
    arc_1_8_7  in_degree_1021  1
    arc_1_8_7  out_degree_1027  1
    arc_1_8_7  original_T_including_depot_unload_1085  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_802  1
    load_1_8_7  segment_load_conservation_1024  -1
    load_1_8_7  segment_prefix_lb_1025  1
    load_1_8_7  segment_prefix_ub_1026  1
    load_1_8_7  segment_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_804  -25
    arc_1_8_12  connected_order_arc_805  -13
    arc_1_8_12  out_degree_1027  1
    arc_1_8_12  in_degree_1035  1
    arc_1_8_12  original_T_including_depot_unload_1085  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_804  1
    load_1_8_12  segment_load_conservation_1031  1
    load_1_8_12  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_806  -25
    arc_1_8_13  connected_order_arc_807  -13
    arc_1_8_13  out_degree_1027  1
    arc_1_8_13  in_degree_1041  1
    arc_1_8_13  original_T_including_depot_unload_1085  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_806  1
    load_1_8_13  segment_load_conservation_1031  1
    load_1_8_13  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_808  -25
    arc_1_8_14  connected_order_arc_809  -13
    arc_1_8_14  out_degree_1027  1
    arc_1_8_14  in_degree_1047  1
    arc_1_8_14  original_T_including_depot_unload_1085  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_808  1
    load_1_8_14  segment_load_conservation_1031  1
    load_1_8_14  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_810  -25
    arc_1_8_15  connected_order_arc_811  -13
    arc_1_8_15  out_degree_1027  1
    arc_1_8_15  in_degree_1053  1
    arc_1_8_15  original_T_including_depot_unload_1085  9.3137133767849343e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_810  1
    load_1_8_15  segment_load_conservation_1031  1
    load_1_8_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_812  -25
    arc_1_8_16  connected_order_arc_813  -13
    arc_1_8_16  out_degree_1027  1
    arc_1_8_16  in_degree_1059  1
    arc_1_8_16  original_T_including_depot_unload_1085  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_812  1
    load_1_8_16  segment_load_conservation_1031  1
    load_1_8_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_814  -25
    arc_1_8_17  connected_order_arc_815  -13
    arc_1_8_17  out_degree_1027  1
    arc_1_8_17  in_degree_1065  1
    arc_1_8_17  original_T_including_depot_unload_1085  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_814  1
    load_1_8_17  segment_load_conservation_1031  1
    load_1_8_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_816  -25
    arc_1_8_18  connected_order_arc_817  -13
    arc_1_8_18  out_degree_1027  1
    arc_1_8_18  in_degree_1071  1
    arc_1_8_18  original_T_including_depot_unload_1085  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_816  1
    load_1_8_18  segment_load_conservation_1031  1
    load_1_8_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_818  -25
    arc_1_8_19  connected_order_arc_819  -13
    arc_1_8_19  out_degree_1027  1
    arc_1_8_19  in_degree_1077  1
    arc_1_8_19  original_T_including_depot_unload_1085  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_818  1
    load_1_8_19  segment_load_conservation_1031  1
    load_1_8_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_820  -25
    arc_1_12_0  depot_return_or_bypass_1005  1
    arc_1_12_0  out_degree_1034  1
    arc_1_12_0  original_T_including_depot_unload_1085  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_820  1
    load_1_12_0  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_821  -25
    arc_1_12_5  connected_order_arc_822  -13
    arc_1_12_5  in_degree_1007  1
    arc_1_12_5  out_degree_1034  1
    arc_1_12_5  original_T_including_depot_unload_1085  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_821  1
    load_1_12_5  segment_load_conservation_1010  -1
    load_1_12_5  segment_prefix_lb_1011  1
    load_1_12_5  segment_prefix_ub_1012  1
    load_1_12_5  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_823  -25
    arc_1_12_6  connected_order_arc_824  -13
    arc_1_12_6  in_degree_1014  1
    arc_1_12_6  out_degree_1034  1
    arc_1_12_6  original_T_including_depot_unload_1085  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_823  1
    load_1_12_6  segment_load_conservation_1017  -1
    load_1_12_6  segment_prefix_lb_1018  1
    load_1_12_6  segment_prefix_ub_1019  1
    load_1_12_6  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_825  -25
    arc_1_12_7  connected_order_arc_826  -13
    arc_1_12_7  in_degree_1021  1
    arc_1_12_7  out_degree_1034  1
    arc_1_12_7  original_T_including_depot_unload_1085  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_825  1
    load_1_12_7  segment_load_conservation_1024  -1
    load_1_12_7  segment_prefix_lb_1025  1
    load_1_12_7  segment_prefix_ub_1026  1
    load_1_12_7  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_827  -25
    arc_1_12_8  connected_order_arc_828  -13
    arc_1_12_8  in_degree_1028  1
    arc_1_12_8  out_degree_1034  1
    arc_1_12_8  original_T_including_depot_unload_1085  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_827  1
    load_1_12_8  segment_load_conservation_1031  -1
    load_1_12_8  segment_prefix_lb_1032  1
    load_1_12_8  segment_prefix_ub_1033  1
    load_1_12_8  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_829  -25
    arc_1_12_13  connected_order_arc_830  -13
    arc_1_12_13  out_degree_1034  1
    arc_1_12_13  in_degree_1041  1
    arc_1_12_13  original_T_including_depot_unload_1085  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_829  1
    load_1_12_13  free_load_conservation_1039  1
    load_1_12_13  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_831  -25
    arc_1_12_14  connected_order_arc_832  -13
    arc_1_12_14  out_degree_1034  1
    arc_1_12_14  in_degree_1047  1
    arc_1_12_14  original_T_including_depot_unload_1085  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_831  1
    load_1_12_14  free_load_conservation_1039  1
    load_1_12_14  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_833  -25
    arc_1_12_15  connected_order_arc_834  -13
    arc_1_12_15  out_degree_1034  1
    arc_1_12_15  in_degree_1053  1
    arc_1_12_15  original_T_including_depot_unload_1085  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_833  1
    load_1_12_15  free_load_conservation_1039  1
    load_1_12_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_835  -25
    arc_1_12_16  connected_order_arc_836  -13
    arc_1_12_16  out_degree_1034  1
    arc_1_12_16  in_degree_1059  1
    arc_1_12_16  original_T_including_depot_unload_1085  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_835  1
    load_1_12_16  free_load_conservation_1039  1
    load_1_12_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_837  -25
    arc_1_12_17  connected_order_arc_838  -13
    arc_1_12_17  out_degree_1034  1
    arc_1_12_17  in_degree_1065  1
    arc_1_12_17  original_T_including_depot_unload_1085  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_837  1
    load_1_12_17  free_load_conservation_1039  1
    load_1_12_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_839  -25
    arc_1_12_18  connected_order_arc_840  -13
    arc_1_12_18  out_degree_1034  1
    arc_1_12_18  in_degree_1071  1
    arc_1_12_18  original_T_including_depot_unload_1085  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_839  1
    load_1_12_18  free_load_conservation_1039  1
    load_1_12_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_841  -25
    arc_1_12_19  connected_order_arc_842  -13
    arc_1_12_19  out_degree_1034  1
    arc_1_12_19  in_degree_1077  1
    arc_1_12_19  original_T_including_depot_unload_1085  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_841  1
    load_1_12_19  free_load_conservation_1039  1
    load_1_12_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_843  -25
    arc_1_13_0  depot_return_or_bypass_1005  1
    arc_1_13_0  out_degree_1040  1
    arc_1_13_0  original_T_including_depot_unload_1085  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_843  1
    load_1_13_0  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_844  -25
    arc_1_13_5  connected_order_arc_845  -13
    arc_1_13_5  in_degree_1007  1
    arc_1_13_5  out_degree_1040  1
    arc_1_13_5  original_T_including_depot_unload_1085  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_844  1
    load_1_13_5  segment_load_conservation_1010  -1
    load_1_13_5  segment_prefix_lb_1011  1
    load_1_13_5  segment_prefix_ub_1012  1
    load_1_13_5  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_846  -25
    arc_1_13_6  connected_order_arc_847  -13
    arc_1_13_6  in_degree_1014  1
    arc_1_13_6  out_degree_1040  1
    arc_1_13_6  original_T_including_depot_unload_1085  2.1806564621513235e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_846  1
    load_1_13_6  segment_load_conservation_1017  -1
    load_1_13_6  segment_prefix_lb_1018  1
    load_1_13_6  segment_prefix_ub_1019  1
    load_1_13_6  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_848  -25
    arc_1_13_7  connected_order_arc_849  -13
    arc_1_13_7  in_degree_1021  1
    arc_1_13_7  out_degree_1040  1
    arc_1_13_7  original_T_including_depot_unload_1085  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_848  1
    load_1_13_7  segment_load_conservation_1024  -1
    load_1_13_7  segment_prefix_lb_1025  1
    load_1_13_7  segment_prefix_ub_1026  1
    load_1_13_7  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_850  -25
    arc_1_13_8  connected_order_arc_851  -13
    arc_1_13_8  in_degree_1028  1
    arc_1_13_8  out_degree_1040  1
    arc_1_13_8  original_T_including_depot_unload_1085  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_850  1
    load_1_13_8  segment_load_conservation_1031  -1
    load_1_13_8  segment_prefix_lb_1032  1
    load_1_13_8  segment_prefix_ub_1033  1
    load_1_13_8  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_852  -25
    arc_1_13_12  connected_order_arc_853  -13
    arc_1_13_12  in_degree_1035  1
    arc_1_13_12  out_degree_1040  1
    arc_1_13_12  original_T_including_depot_unload_1085  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_852  1
    load_1_13_12  free_load_conservation_1039  -1
    load_1_13_12  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_854  -25
    arc_1_13_14  connected_order_arc_855  -13
    arc_1_13_14  out_degree_1040  1
    arc_1_13_14  in_degree_1047  1
    arc_1_13_14  original_T_including_depot_unload_1085  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_854  1
    load_1_13_14  free_load_conservation_1045  1
    load_1_13_14  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_856  -25
    arc_1_13_15  connected_order_arc_857  -13
    arc_1_13_15  out_degree_1040  1
    arc_1_13_15  in_degree_1053  1
    arc_1_13_15  original_T_including_depot_unload_1085  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_856  1
    load_1_13_15  free_load_conservation_1045  1
    load_1_13_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_858  -25
    arc_1_13_16  connected_order_arc_859  -13
    arc_1_13_16  out_degree_1040  1
    arc_1_13_16  in_degree_1059  1
    arc_1_13_16  original_T_including_depot_unload_1085  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_858  1
    load_1_13_16  free_load_conservation_1045  1
    load_1_13_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_860  -25
    arc_1_13_17  connected_order_arc_861  -13
    arc_1_13_17  out_degree_1040  1
    arc_1_13_17  in_degree_1065  1
    arc_1_13_17  original_T_including_depot_unload_1085  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_860  1
    load_1_13_17  free_load_conservation_1045  1
    load_1_13_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_862  -25
    arc_1_13_18  connected_order_arc_863  -13
    arc_1_13_18  out_degree_1040  1
    arc_1_13_18  in_degree_1071  1
    arc_1_13_18  original_T_including_depot_unload_1085  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_862  1
    load_1_13_18  free_load_conservation_1045  1
    load_1_13_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_864  -25
    arc_1_13_19  connected_order_arc_865  -13
    arc_1_13_19  out_degree_1040  1
    arc_1_13_19  in_degree_1077  1
    arc_1_13_19  original_T_including_depot_unload_1085  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_864  1
    load_1_13_19  free_load_conservation_1045  1
    load_1_13_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_866  -25
    arc_1_14_0  depot_return_or_bypass_1005  1
    arc_1_14_0  out_degree_1046  1
    arc_1_14_0  original_T_including_depot_unload_1085  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_866  1
    load_1_14_0  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_867  -25
    arc_1_14_5  connected_order_arc_868  -13
    arc_1_14_5  in_degree_1007  1
    arc_1_14_5  out_degree_1046  1
    arc_1_14_5  original_T_including_depot_unload_1085  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_867  1
    load_1_14_5  segment_load_conservation_1010  -1
    load_1_14_5  segment_prefix_lb_1011  1
    load_1_14_5  segment_prefix_ub_1012  1
    load_1_14_5  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_869  -25
    arc_1_14_6  connected_order_arc_870  -13
    arc_1_14_6  in_degree_1014  1
    arc_1_14_6  out_degree_1046  1
    arc_1_14_6  original_T_including_depot_unload_1085  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_869  1
    load_1_14_6  segment_load_conservation_1017  -1
    load_1_14_6  segment_prefix_lb_1018  1
    load_1_14_6  segment_prefix_ub_1019  1
    load_1_14_6  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_871  -25
    arc_1_14_7  connected_order_arc_872  -13
    arc_1_14_7  in_degree_1021  1
    arc_1_14_7  out_degree_1046  1
    arc_1_14_7  original_T_including_depot_unload_1085  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_871  1
    load_1_14_7  segment_load_conservation_1024  -1
    load_1_14_7  segment_prefix_lb_1025  1
    load_1_14_7  segment_prefix_ub_1026  1
    load_1_14_7  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_873  -25
    arc_1_14_8  connected_order_arc_874  -13
    arc_1_14_8  in_degree_1028  1
    arc_1_14_8  out_degree_1046  1
    arc_1_14_8  original_T_including_depot_unload_1085  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_873  1
    load_1_14_8  segment_load_conservation_1031  -1
    load_1_14_8  segment_prefix_lb_1032  1
    load_1_14_8  segment_prefix_ub_1033  1
    load_1_14_8  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_875  -25
    arc_1_14_12  connected_order_arc_876  -13
    arc_1_14_12  in_degree_1035  1
    arc_1_14_12  out_degree_1046  1
    arc_1_14_12  original_T_including_depot_unload_1085  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_875  1
    load_1_14_12  free_load_conservation_1039  -1
    load_1_14_12  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_877  -25
    arc_1_14_13  connected_order_arc_878  -13
    arc_1_14_13  in_degree_1041  1
    arc_1_14_13  out_degree_1046  1
    arc_1_14_13  original_T_including_depot_unload_1085  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_877  1
    load_1_14_13  free_load_conservation_1045  -1
    load_1_14_13  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_879  -25
    arc_1_14_15  connected_order_arc_880  -13
    arc_1_14_15  out_degree_1046  1
    arc_1_14_15  in_degree_1053  1
    arc_1_14_15  original_T_including_depot_unload_1085  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_879  1
    load_1_14_15  free_load_conservation_1051  1
    load_1_14_15  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_881  -25
    arc_1_14_16  connected_order_arc_882  -13
    arc_1_14_16  out_degree_1046  1
    arc_1_14_16  in_degree_1059  1
    arc_1_14_16  original_T_including_depot_unload_1085  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_881  1
    load_1_14_16  free_load_conservation_1051  1
    load_1_14_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_883  -25
    arc_1_14_17  connected_order_arc_884  -13
    arc_1_14_17  out_degree_1046  1
    arc_1_14_17  in_degree_1065  1
    arc_1_14_17  original_T_including_depot_unload_1085  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_883  1
    load_1_14_17  free_load_conservation_1051  1
    load_1_14_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_885  -25
    arc_1_14_18  connected_order_arc_886  -13
    arc_1_14_18  out_degree_1046  1
    arc_1_14_18  in_degree_1071  1
    arc_1_14_18  original_T_including_depot_unload_1085  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_885  1
    load_1_14_18  free_load_conservation_1051  1
    load_1_14_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_887  -25
    arc_1_14_19  connected_order_arc_888  -13
    arc_1_14_19  out_degree_1046  1
    arc_1_14_19  in_degree_1077  1
    arc_1_14_19  original_T_including_depot_unload_1085  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_887  1
    load_1_14_19  free_load_conservation_1051  1
    load_1_14_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_889  -25
    arc_1_15_0  depot_return_or_bypass_1005  1
    arc_1_15_0  out_degree_1052  1
    arc_1_15_0  original_T_including_depot_unload_1085  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_889  1
    load_1_15_0  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_890  -25
    arc_1_15_5  connected_order_arc_891  -13
    arc_1_15_5  in_degree_1007  1
    arc_1_15_5  out_degree_1052  1
    arc_1_15_5  original_T_including_depot_unload_1085  1.5356438916798834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_890  1
    load_1_15_5  segment_load_conservation_1010  -1
    load_1_15_5  segment_prefix_lb_1011  1
    load_1_15_5  segment_prefix_ub_1012  1
    load_1_15_5  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_892  -25
    arc_1_15_6  connected_order_arc_893  -13
    arc_1_15_6  in_degree_1014  1
    arc_1_15_6  out_degree_1052  1
    arc_1_15_6  original_T_including_depot_unload_1085  1.9765601995118598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_892  1
    load_1_15_6  segment_load_conservation_1017  -1
    load_1_15_6  segment_prefix_lb_1018  1
    load_1_15_6  segment_prefix_ub_1019  1
    load_1_15_6  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_894  -25
    arc_1_15_7  connected_order_arc_895  -13
    arc_1_15_7  in_degree_1021  1
    arc_1_15_7  out_degree_1052  1
    arc_1_15_7  original_T_including_depot_unload_1085  1.1150690045767951e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_894  1
    load_1_15_7  segment_load_conservation_1024  -1
    load_1_15_7  segment_prefix_lb_1025  1
    load_1_15_7  segment_prefix_ub_1026  1
    load_1_15_7  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_896  -25
    arc_1_15_8  connected_order_arc_897  -13
    arc_1_15_8  in_degree_1028  1
    arc_1_15_8  out_degree_1052  1
    arc_1_15_8  original_T_including_depot_unload_1085  9.3137133767849343e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_896  1
    load_1_15_8  segment_load_conservation_1031  -1
    load_1_15_8  segment_prefix_lb_1032  1
    load_1_15_8  segment_prefix_ub_1033  1
    load_1_15_8  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_898  -25
    arc_1_15_12  connected_order_arc_899  -13
    arc_1_15_12  in_degree_1035  1
    arc_1_15_12  out_degree_1052  1
    arc_1_15_12  original_T_including_depot_unload_1085  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_898  1
    load_1_15_12  free_load_conservation_1039  -1
    load_1_15_12  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_900  -25
    arc_1_15_13  connected_order_arc_901  -13
    arc_1_15_13  in_degree_1041  1
    arc_1_15_13  out_degree_1052  1
    arc_1_15_13  original_T_including_depot_unload_1085  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_900  1
    load_1_15_13  free_load_conservation_1045  -1
    load_1_15_13  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_902  -25
    arc_1_15_14  connected_order_arc_903  -13
    arc_1_15_14  in_degree_1047  1
    arc_1_15_14  out_degree_1052  1
    arc_1_15_14  original_T_including_depot_unload_1085  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_902  1
    load_1_15_14  free_load_conservation_1051  -1
    load_1_15_14  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_904  -25
    arc_1_15_16  connected_order_arc_905  -13
    arc_1_15_16  out_degree_1052  1
    arc_1_15_16  in_degree_1059  1
    arc_1_15_16  original_T_including_depot_unload_1085  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_904  1
    load_1_15_16  free_load_conservation_1057  1
    load_1_15_16  free_load_conservation_1063  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_906  -25
    arc_1_15_17  connected_order_arc_907  -13
    arc_1_15_17  out_degree_1052  1
    arc_1_15_17  in_degree_1065  1
    arc_1_15_17  original_T_including_depot_unload_1085  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_906  1
    load_1_15_17  free_load_conservation_1057  1
    load_1_15_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_908  -25
    arc_1_15_18  connected_order_arc_909  -13
    arc_1_15_18  out_degree_1052  1
    arc_1_15_18  in_degree_1071  1
    arc_1_15_18  original_T_including_depot_unload_1085  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_908  1
    load_1_15_18  free_load_conservation_1057  1
    load_1_15_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_910  -25
    arc_1_15_19  connected_order_arc_911  -13
    arc_1_15_19  out_degree_1052  1
    arc_1_15_19  in_degree_1077  1
    arc_1_15_19  original_T_including_depot_unload_1085  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_910  1
    load_1_15_19  free_load_conservation_1057  1
    load_1_15_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_912  -25
    arc_1_16_0  depot_return_or_bypass_1005  1
    arc_1_16_0  out_degree_1058  1
    arc_1_16_0  original_T_including_depot_unload_1085  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_912  1
    load_1_16_0  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_913  -25
    arc_1_16_5  connected_order_arc_914  -13
    arc_1_16_5  in_degree_1007  1
    arc_1_16_5  out_degree_1058  1
    arc_1_16_5  original_T_including_depot_unload_1085  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_913  1
    load_1_16_5  segment_load_conservation_1010  -1
    load_1_16_5  segment_prefix_lb_1011  1
    load_1_16_5  segment_prefix_ub_1012  1
    load_1_16_5  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_915  -25
    arc_1_16_6  connected_order_arc_916  -13
    arc_1_16_6  in_degree_1014  1
    arc_1_16_6  out_degree_1058  1
    arc_1_16_6  original_T_including_depot_unload_1085  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_915  1
    load_1_16_6  segment_load_conservation_1017  -1
    load_1_16_6  segment_prefix_lb_1018  1
    load_1_16_6  segment_prefix_ub_1019  1
    load_1_16_6  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_917  -25
    arc_1_16_7  connected_order_arc_918  -13
    arc_1_16_7  in_degree_1021  1
    arc_1_16_7  out_degree_1058  1
    arc_1_16_7  original_T_including_depot_unload_1085  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_917  1
    load_1_16_7  segment_load_conservation_1024  -1
    load_1_16_7  segment_prefix_lb_1025  1
    load_1_16_7  segment_prefix_ub_1026  1
    load_1_16_7  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_919  -25
    arc_1_16_8  connected_order_arc_920  -13
    arc_1_16_8  in_degree_1028  1
    arc_1_16_8  out_degree_1058  1
    arc_1_16_8  original_T_including_depot_unload_1085  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_919  1
    load_1_16_8  segment_load_conservation_1031  -1
    load_1_16_8  segment_prefix_lb_1032  1
    load_1_16_8  segment_prefix_ub_1033  1
    load_1_16_8  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_921  -25
    arc_1_16_12  connected_order_arc_922  -13
    arc_1_16_12  in_degree_1035  1
    arc_1_16_12  out_degree_1058  1
    arc_1_16_12  original_T_including_depot_unload_1085  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_921  1
    load_1_16_12  free_load_conservation_1039  -1
    load_1_16_12  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_923  -25
    arc_1_16_13  connected_order_arc_924  -13
    arc_1_16_13  in_degree_1041  1
    arc_1_16_13  out_degree_1058  1
    arc_1_16_13  original_T_including_depot_unload_1085  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_923  1
    load_1_16_13  free_load_conservation_1045  -1
    load_1_16_13  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_925  -25
    arc_1_16_14  connected_order_arc_926  -13
    arc_1_16_14  in_degree_1047  1
    arc_1_16_14  out_degree_1058  1
    arc_1_16_14  original_T_including_depot_unload_1085  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_925  1
    load_1_16_14  free_load_conservation_1051  -1
    load_1_16_14  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_927  -25
    arc_1_16_15  connected_order_arc_928  -13
    arc_1_16_15  in_degree_1053  1
    arc_1_16_15  out_degree_1058  1
    arc_1_16_15  original_T_including_depot_unload_1085  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_927  1
    load_1_16_15  free_load_conservation_1057  -1
    load_1_16_15  free_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_929  -25
    arc_1_16_17  connected_order_arc_930  -13
    arc_1_16_17  out_degree_1058  1
    arc_1_16_17  in_degree_1065  1
    arc_1_16_17  original_T_including_depot_unload_1085  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_929  1
    load_1_16_17  free_load_conservation_1063  1
    load_1_16_17  free_load_conservation_1069  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_931  -25
    arc_1_16_18  connected_order_arc_932  -13
    arc_1_16_18  out_degree_1058  1
    arc_1_16_18  in_degree_1071  1
    arc_1_16_18  original_T_including_depot_unload_1085  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_931  1
    load_1_16_18  free_load_conservation_1063  1
    load_1_16_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_933  -25
    arc_1_16_19  connected_order_arc_934  -13
    arc_1_16_19  out_degree_1058  1
    arc_1_16_19  in_degree_1077  1
    arc_1_16_19  original_T_including_depot_unload_1085  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_933  1
    load_1_16_19  free_load_conservation_1063  1
    load_1_16_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_935  -25
    arc_1_17_0  depot_return_or_bypass_1005  1
    arc_1_17_0  out_degree_1064  1
    arc_1_17_0  original_T_including_depot_unload_1085  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_935  1
    load_1_17_0  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_936  -25
    arc_1_17_5  connected_order_arc_937  -13
    arc_1_17_5  in_degree_1007  1
    arc_1_17_5  out_degree_1064  1
    arc_1_17_5  original_T_including_depot_unload_1085  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_936  1
    load_1_17_5  segment_load_conservation_1010  -1
    load_1_17_5  segment_prefix_lb_1011  1
    load_1_17_5  segment_prefix_ub_1012  1
    load_1_17_5  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_938  -25
    arc_1_17_6  connected_order_arc_939  -13
    arc_1_17_6  in_degree_1014  1
    arc_1_17_6  out_degree_1064  1
    arc_1_17_6  original_T_including_depot_unload_1085  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_938  1
    load_1_17_6  segment_load_conservation_1017  -1
    load_1_17_6  segment_prefix_lb_1018  1
    load_1_17_6  segment_prefix_ub_1019  1
    load_1_17_6  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_940  -25
    arc_1_17_7  connected_order_arc_941  -13
    arc_1_17_7  in_degree_1021  1
    arc_1_17_7  out_degree_1064  1
    arc_1_17_7  original_T_including_depot_unload_1085  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_940  1
    load_1_17_7  segment_load_conservation_1024  -1
    load_1_17_7  segment_prefix_lb_1025  1
    load_1_17_7  segment_prefix_ub_1026  1
    load_1_17_7  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_942  -25
    arc_1_17_8  connected_order_arc_943  -13
    arc_1_17_8  in_degree_1028  1
    arc_1_17_8  out_degree_1064  1
    arc_1_17_8  original_T_including_depot_unload_1085  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_942  1
    load_1_17_8  segment_load_conservation_1031  -1
    load_1_17_8  segment_prefix_lb_1032  1
    load_1_17_8  segment_prefix_ub_1033  1
    load_1_17_8  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_944  -25
    arc_1_17_12  connected_order_arc_945  -13
    arc_1_17_12  in_degree_1035  1
    arc_1_17_12  out_degree_1064  1
    arc_1_17_12  original_T_including_depot_unload_1085  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_944  1
    load_1_17_12  free_load_conservation_1039  -1
    load_1_17_12  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_946  -25
    arc_1_17_13  connected_order_arc_947  -13
    arc_1_17_13  in_degree_1041  1
    arc_1_17_13  out_degree_1064  1
    arc_1_17_13  original_T_including_depot_unload_1085  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_946  1
    load_1_17_13  free_load_conservation_1045  -1
    load_1_17_13  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_948  -25
    arc_1_17_14  connected_order_arc_949  -13
    arc_1_17_14  in_degree_1047  1
    arc_1_17_14  out_degree_1064  1
    arc_1_17_14  original_T_including_depot_unload_1085  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_948  1
    load_1_17_14  free_load_conservation_1051  -1
    load_1_17_14  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_950  -25
    arc_1_17_15  connected_order_arc_951  -13
    arc_1_17_15  in_degree_1053  1
    arc_1_17_15  out_degree_1064  1
    arc_1_17_15  original_T_including_depot_unload_1085  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_950  1
    load_1_17_15  free_load_conservation_1057  -1
    load_1_17_15  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_952  -25
    arc_1_17_16  connected_order_arc_953  -13
    arc_1_17_16  in_degree_1059  1
    arc_1_17_16  out_degree_1064  1
    arc_1_17_16  original_T_including_depot_unload_1085  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_952  1
    load_1_17_16  free_load_conservation_1063  -1
    load_1_17_16  free_load_conservation_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_954  -25
    arc_1_17_18  connected_order_arc_955  -13
    arc_1_17_18  out_degree_1064  1
    arc_1_17_18  in_degree_1071  1
    arc_1_17_18  original_T_including_depot_unload_1085  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_954  1
    load_1_17_18  free_load_conservation_1069  1
    load_1_17_18  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_956  -25
    arc_1_17_19  connected_order_arc_957  -13
    arc_1_17_19  out_degree_1064  1
    arc_1_17_19  in_degree_1077  1
    arc_1_17_19  original_T_including_depot_unload_1085  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_956  1
    load_1_17_19  free_load_conservation_1069  1
    load_1_17_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_958  -25
    arc_1_18_0  depot_return_or_bypass_1005  1
    arc_1_18_0  out_degree_1070  1
    arc_1_18_0  original_T_including_depot_unload_1085  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_958  1
    load_1_18_0  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_959  -25
    arc_1_18_5  connected_order_arc_960  -13
    arc_1_18_5  in_degree_1007  1
    arc_1_18_5  out_degree_1070  1
    arc_1_18_5  original_T_including_depot_unload_1085  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_959  1
    load_1_18_5  segment_load_conservation_1010  -1
    load_1_18_5  segment_prefix_lb_1011  1
    load_1_18_5  segment_prefix_ub_1012  1
    load_1_18_5  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_961  -25
    arc_1_18_6  connected_order_arc_962  -13
    arc_1_18_6  in_degree_1014  1
    arc_1_18_6  out_degree_1070  1
    arc_1_18_6  original_T_including_depot_unload_1085  2.9006291140474787e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_961  1
    load_1_18_6  segment_load_conservation_1017  -1
    load_1_18_6  segment_prefix_lb_1018  1
    load_1_18_6  segment_prefix_ub_1019  1
    load_1_18_6  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_963  -25
    arc_1_18_7  connected_order_arc_964  -13
    arc_1_18_7  in_degree_1021  1
    arc_1_18_7  out_degree_1070  1
    arc_1_18_7  original_T_including_depot_unload_1085  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_963  1
    load_1_18_7  segment_load_conservation_1024  -1
    load_1_18_7  segment_prefix_lb_1025  1
    load_1_18_7  segment_prefix_ub_1026  1
    load_1_18_7  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_965  -25
    arc_1_18_8  connected_order_arc_966  -13
    arc_1_18_8  in_degree_1028  1
    arc_1_18_8  out_degree_1070  1
    arc_1_18_8  original_T_including_depot_unload_1085  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_965  1
    load_1_18_8  segment_load_conservation_1031  -1
    load_1_18_8  segment_prefix_lb_1032  1
    load_1_18_8  segment_prefix_ub_1033  1
    load_1_18_8  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_967  -25
    arc_1_18_12  connected_order_arc_968  -13
    arc_1_18_12  in_degree_1035  1
    arc_1_18_12  out_degree_1070  1
    arc_1_18_12  original_T_including_depot_unload_1085  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_967  1
    load_1_18_12  free_load_conservation_1039  -1
    load_1_18_12  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_969  -25
    arc_1_18_13  connected_order_arc_970  -13
    arc_1_18_13  in_degree_1041  1
    arc_1_18_13  out_degree_1070  1
    arc_1_18_13  original_T_including_depot_unload_1085  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_969  1
    load_1_18_13  free_load_conservation_1045  -1
    load_1_18_13  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_971  -25
    arc_1_18_14  connected_order_arc_972  -13
    arc_1_18_14  in_degree_1047  1
    arc_1_18_14  out_degree_1070  1
    arc_1_18_14  original_T_including_depot_unload_1085  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_971  1
    load_1_18_14  free_load_conservation_1051  -1
    load_1_18_14  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_973  -25
    arc_1_18_15  connected_order_arc_974  -13
    arc_1_18_15  in_degree_1053  1
    arc_1_18_15  out_degree_1070  1
    arc_1_18_15  original_T_including_depot_unload_1085  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_973  1
    load_1_18_15  free_load_conservation_1057  -1
    load_1_18_15  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_975  -25
    arc_1_18_16  connected_order_arc_976  -13
    arc_1_18_16  in_degree_1059  1
    arc_1_18_16  out_degree_1070  1
    arc_1_18_16  original_T_including_depot_unload_1085  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_975  1
    load_1_18_16  free_load_conservation_1063  -1
    load_1_18_16  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_977  -25
    arc_1_18_17  connected_order_arc_978  -13
    arc_1_18_17  in_degree_1065  1
    arc_1_18_17  out_degree_1070  1
    arc_1_18_17  original_T_including_depot_unload_1085  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_977  1
    load_1_18_17  free_load_conservation_1069  -1
    load_1_18_17  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_979  -25
    arc_1_18_19  connected_order_arc_980  -13
    arc_1_18_19  out_degree_1070  1
    arc_1_18_19  in_degree_1077  1
    arc_1_18_19  original_T_including_depot_unload_1085  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_979  1
    load_1_18_19  free_load_conservation_1075  1
    load_1_18_19  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_981  -25
    arc_1_19_0  depot_return_or_bypass_1005  1
    arc_1_19_0  out_degree_1076  1
    arc_1_19_0  original_T_including_depot_unload_1085  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_981  1
    load_1_19_0  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_982  -25
    arc_1_19_5  connected_order_arc_983  -13
    arc_1_19_5  in_degree_1007  1
    arc_1_19_5  out_degree_1076  1
    arc_1_19_5  original_T_including_depot_unload_1085  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_982  1
    load_1_19_5  segment_load_conservation_1010  -1
    load_1_19_5  segment_prefix_lb_1011  1
    load_1_19_5  segment_prefix_ub_1012  1
    load_1_19_5  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_984  -25
    arc_1_19_6  connected_order_arc_985  -13
    arc_1_19_6  in_degree_1014  1
    arc_1_19_6  out_degree_1076  1
    arc_1_19_6  original_T_including_depot_unload_1085  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_984  1
    load_1_19_6  segment_load_conservation_1017  -1
    load_1_19_6  segment_prefix_lb_1018  1
    load_1_19_6  segment_prefix_ub_1019  1
    load_1_19_6  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_986  -25
    arc_1_19_7  connected_order_arc_987  -13
    arc_1_19_7  in_degree_1021  1
    arc_1_19_7  out_degree_1076  1
    arc_1_19_7  original_T_including_depot_unload_1085  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_986  1
    load_1_19_7  segment_load_conservation_1024  -1
    load_1_19_7  segment_prefix_lb_1025  1
    load_1_19_7  segment_prefix_ub_1026  1
    load_1_19_7  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_988  -25
    arc_1_19_8  connected_order_arc_989  -13
    arc_1_19_8  in_degree_1028  1
    arc_1_19_8  out_degree_1076  1
    arc_1_19_8  original_T_including_depot_unload_1085  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_988  1
    load_1_19_8  segment_load_conservation_1031  -1
    load_1_19_8  segment_prefix_lb_1032  1
    load_1_19_8  segment_prefix_ub_1033  1
    load_1_19_8  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_990  -25
    arc_1_19_12  connected_order_arc_991  -13
    arc_1_19_12  in_degree_1035  1
    arc_1_19_12  out_degree_1076  1
    arc_1_19_12  original_T_including_depot_unload_1085  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_990  1
    load_1_19_12  free_load_conservation_1039  -1
    load_1_19_12  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_992  -25
    arc_1_19_13  connected_order_arc_993  -13
    arc_1_19_13  in_degree_1041  1
    arc_1_19_13  out_degree_1076  1
    arc_1_19_13  original_T_including_depot_unload_1085  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_992  1
    load_1_19_13  free_load_conservation_1045  -1
    load_1_19_13  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_994  -25
    arc_1_19_14  connected_order_arc_995  -13
    arc_1_19_14  in_degree_1047  1
    arc_1_19_14  out_degree_1076  1
    arc_1_19_14  original_T_including_depot_unload_1085  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_994  1
    load_1_19_14  free_load_conservation_1051  -1
    load_1_19_14  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_996  -25
    arc_1_19_15  connected_order_arc_997  -13
    arc_1_19_15  in_degree_1053  1
    arc_1_19_15  out_degree_1076  1
    arc_1_19_15  original_T_including_depot_unload_1085  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_996  1
    load_1_19_15  free_load_conservation_1057  -1
    load_1_19_15  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_998  -25
    arc_1_19_16  connected_order_arc_999  -13
    arc_1_19_16  in_degree_1059  1
    arc_1_19_16  out_degree_1076  1
    arc_1_19_16  original_T_including_depot_unload_1085  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_998  1
    load_1_19_16  free_load_conservation_1063  -1
    load_1_19_16  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1000  -25
    arc_1_19_17  connected_order_arc_1001  -13
    arc_1_19_17  in_degree_1065  1
    arc_1_19_17  out_degree_1076  1
    arc_1_19_17  original_T_including_depot_unload_1085  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1000  1
    load_1_19_17  free_load_conservation_1069  -1
    load_1_19_17  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1002  -25
    arc_1_19_18  connected_order_arc_1003  -13
    arc_1_19_18  in_degree_1071  1
    arc_1_19_18  out_degree_1076  1
    arc_1_19_18  original_T_including_depot_unload_1085  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1002  1
    load_1_19_18  free_load_conservation_1075  -1
    load_1_19_18  free_load_conservation_1081  1
    visit_2_9  out_degree_1331  -1
    visit_2_9  in_degree_1332  -1
    visit_2_9  order_active_lb_1333  -1
    visit_2_9  order_active_ub_1334  -11
    order_2_9  connected_order_arc_1100  -1
    order_2_9  connected_order_arc_1102  -1
    order_2_9  connected_order_arc_1104  -1
    order_2_9  connected_order_arc_1106  -1
    order_2_9  connected_order_arc_1108  -1
    order_2_9  connected_order_arc_1110  -1
    order_2_9  connected_order_arc_1112  -1
    order_2_9  connected_order_arc_1114  -1
    order_2_9  connected_order_arc_1116  -1
    order_2_9  connected_order_arc_1118  -1
    order_2_9  connected_order_arc_1121  1
    order_2_9  connected_order_arc_1142  1
    order_2_9  connected_order_arc_1163  1
    order_2_9  connected_order_arc_1184  1
    order_2_9  connected_order_arc_1205  1
    order_2_9  connected_order_arc_1226  1
    order_2_9  connected_order_arc_1247  1
    order_2_9  connected_order_arc_1268  1
    order_2_9  connected_order_arc_1289  1
    order_2_9  connected_order_arc_1310  1
    order_2_9  order_active_lb_1333  1
    order_2_9  order_active_ub_1334  1
    order_2_9  fixed_segment_relative_order_1400  -1
    visit_2_10  out_degree_1338  -1
    visit_2_10  in_degree_1339  -1
    visit_2_10  order_active_lb_1340  -1
    visit_2_10  order_active_ub_1341  -11
    order_2_10  connected_order_arc_1100  1
    order_2_10  connected_order_arc_1121  -1
    order_2_10  connected_order_arc_1123  -1
    order_2_10  connected_order_arc_1125  -1
    order_2_10  connected_order_arc_1127  -1
    order_2_10  connected_order_arc_1129  -1
    order_2_10  connected_order_arc_1131  -1
    order_2_10  connected_order_arc_1133  -1
    order_2_10  connected_order_arc_1135  -1
    order_2_10  connected_order_arc_1137  -1
    order_2_10  connected_order_arc_1139  -1
    order_2_10  connected_order_arc_1144  1
    order_2_10  connected_order_arc_1165  1
    order_2_10  connected_order_arc_1186  1
    order_2_10  connected_order_arc_1207  1
    order_2_10  connected_order_arc_1228  1
    order_2_10  connected_order_arc_1249  1
    order_2_10  connected_order_arc_1270  1
    order_2_10  connected_order_arc_1291  1
    order_2_10  connected_order_arc_1312  1
    order_2_10  order_active_lb_1340  1
    order_2_10  order_active_ub_1341  1
    order_2_10  fixed_segment_relative_order_1400  1
    order_2_10  fixed_segment_relative_order_1401  -1
    visit_2_11  out_degree_1345  -1
    visit_2_11  in_degree_1346  -1
    visit_2_11  order_active_lb_1347  -1
    visit_2_11  order_active_ub_1348  -11
    order_2_11  connected_order_arc_1102  1
    order_2_11  connected_order_arc_1123  1
    order_2_11  connected_order_arc_1142  -1
    order_2_11  connected_order_arc_1144  -1
    order_2_11  connected_order_arc_1146  -1
    order_2_11  connected_order_arc_1148  -1
    order_2_11  connected_order_arc_1150  -1
    order_2_11  connected_order_arc_1152  -1
    order_2_11  connected_order_arc_1154  -1
    order_2_11  connected_order_arc_1156  -1
    order_2_11  connected_order_arc_1158  -1
    order_2_11  connected_order_arc_1160  -1
    order_2_11  connected_order_arc_1167  1
    order_2_11  connected_order_arc_1188  1
    order_2_11  connected_order_arc_1209  1
    order_2_11  connected_order_arc_1230  1
    order_2_11  connected_order_arc_1251  1
    order_2_11  connected_order_arc_1272  1
    order_2_11  connected_order_arc_1293  1
    order_2_11  connected_order_arc_1314  1
    order_2_11  order_active_lb_1347  1
    order_2_11  order_active_ub_1348  1
    order_2_11  fixed_segment_relative_order_1401  1
    visit_2_12  out_degree_1352  -1
    visit_2_12  in_degree_1353  -1
    visit_2_12  order_active_lb_1354  -1
    visit_2_12  order_active_ub_1355  -11
    visit_2_12  service_visit_def_1356  -1
    order_2_12  connected_order_arc_1104  1
    order_2_12  connected_order_arc_1125  1
    order_2_12  connected_order_arc_1146  1
    order_2_12  connected_order_arc_1163  -1
    order_2_12  connected_order_arc_1165  -1
    order_2_12  connected_order_arc_1167  -1
    order_2_12  connected_order_arc_1169  -1
    order_2_12  connected_order_arc_1171  -1
    order_2_12  connected_order_arc_1173  -1
    order_2_12  connected_order_arc_1175  -1
    order_2_12  connected_order_arc_1177  -1
    order_2_12  connected_order_arc_1179  -1
    order_2_12  connected_order_arc_1181  -1
    order_2_12  connected_order_arc_1190  1
    order_2_12  connected_order_arc_1211  1
    order_2_12  connected_order_arc_1232  1
    order_2_12  connected_order_arc_1253  1
    order_2_12  connected_order_arc_1274  1
    order_2_12  connected_order_arc_1295  1
    order_2_12  connected_order_arc_1316  1
    order_2_12  order_active_lb_1354  1
    order_2_12  order_active_ub_1355  1
    visit_2_13  out_degree_1358  -1
    visit_2_13  in_degree_1359  -1
    visit_2_13  order_active_lb_1360  -1
    visit_2_13  order_active_ub_1361  -11
    visit_2_13  service_visit_def_1362  -1
    order_2_13  connected_order_arc_1106  1
    order_2_13  connected_order_arc_1127  1
    order_2_13  connected_order_arc_1148  1
    order_2_13  connected_order_arc_1169  1
    order_2_13  connected_order_arc_1184  -1
    order_2_13  connected_order_arc_1186  -1
    order_2_13  connected_order_arc_1188  -1
    order_2_13  connected_order_arc_1190  -1
    order_2_13  connected_order_arc_1192  -1
    order_2_13  connected_order_arc_1194  -1
    order_2_13  connected_order_arc_1196  -1
    order_2_13  connected_order_arc_1198  -1
    order_2_13  connected_order_arc_1200  -1
    order_2_13  connected_order_arc_1202  -1
    order_2_13  connected_order_arc_1213  1
    order_2_13  connected_order_arc_1234  1
    order_2_13  connected_order_arc_1255  1
    order_2_13  connected_order_arc_1276  1
    order_2_13  connected_order_arc_1297  1
    order_2_13  connected_order_arc_1318  1
    order_2_13  order_active_lb_1360  1
    order_2_13  order_active_ub_1361  1
    visit_2_14  out_degree_1364  -1
    visit_2_14  in_degree_1365  -1
    visit_2_14  order_active_lb_1366  -1
    visit_2_14  order_active_ub_1367  -11
    visit_2_14  service_visit_def_1368  -1
    order_2_14  connected_order_arc_1108  1
    order_2_14  connected_order_arc_1129  1
    order_2_14  connected_order_arc_1150  1
    order_2_14  connected_order_arc_1171  1
    order_2_14  connected_order_arc_1192  1
    order_2_14  connected_order_arc_1205  -1
    order_2_14  connected_order_arc_1207  -1
    order_2_14  connected_order_arc_1209  -1
    order_2_14  connected_order_arc_1211  -1
    order_2_14  connected_order_arc_1213  -1
    order_2_14  connected_order_arc_1215  -1
    order_2_14  connected_order_arc_1217  -1
    order_2_14  connected_order_arc_1219  -1
    order_2_14  connected_order_arc_1221  -1
    order_2_14  connected_order_arc_1223  -1
    order_2_14  connected_order_arc_1236  1
    order_2_14  connected_order_arc_1257  1
    order_2_14  connected_order_arc_1278  1
    order_2_14  connected_order_arc_1299  1
    order_2_14  connected_order_arc_1320  1
    order_2_14  order_active_lb_1366  1
    order_2_14  order_active_ub_1367  1
    visit_2_15  out_degree_1370  -1
    visit_2_15  in_degree_1371  -1
    visit_2_15  order_active_lb_1372  -1
    visit_2_15  order_active_ub_1373  -11
    visit_2_15  service_visit_def_1374  -1
    order_2_15  connected_order_arc_1110  1
    order_2_15  connected_order_arc_1131  1
    order_2_15  connected_order_arc_1152  1
    order_2_15  connected_order_arc_1173  1
    order_2_15  connected_order_arc_1194  1
    order_2_15  connected_order_arc_1215  1
    order_2_15  connected_order_arc_1226  -1
    order_2_15  connected_order_arc_1228  -1
    order_2_15  connected_order_arc_1230  -1
    order_2_15  connected_order_arc_1232  -1
    order_2_15  connected_order_arc_1234  -1
    order_2_15  connected_order_arc_1236  -1
    order_2_15  connected_order_arc_1238  -1
    order_2_15  connected_order_arc_1240  -1
    order_2_15  connected_order_arc_1242  -1
    order_2_15  connected_order_arc_1244  -1
    order_2_15  connected_order_arc_1259  1
    order_2_15  connected_order_arc_1280  1
    order_2_15  connected_order_arc_1301  1
    order_2_15  connected_order_arc_1322  1
    order_2_15  order_active_lb_1372  1
    order_2_15  order_active_ub_1373  1
    visit_2_16  out_degree_1376  -1
    visit_2_16  in_degree_1377  -1
    visit_2_16  order_active_lb_1378  -1
    visit_2_16  order_active_ub_1379  -11
    visit_2_16  service_visit_def_1380  -1
    order_2_16  connected_order_arc_1112  1
    order_2_16  connected_order_arc_1133  1
    order_2_16  connected_order_arc_1154  1
    order_2_16  connected_order_arc_1175  1
    order_2_16  connected_order_arc_1196  1
    order_2_16  connected_order_arc_1217  1
    order_2_16  connected_order_arc_1238  1
    order_2_16  connected_order_arc_1247  -1
    order_2_16  connected_order_arc_1249  -1
    order_2_16  connected_order_arc_1251  -1
    order_2_16  connected_order_arc_1253  -1
    order_2_16  connected_order_arc_1255  -1
    order_2_16  connected_order_arc_1257  -1
    order_2_16  connected_order_arc_1259  -1
    order_2_16  connected_order_arc_1261  -1
    order_2_16  connected_order_arc_1263  -1
    order_2_16  connected_order_arc_1265  -1
    order_2_16  connected_order_arc_1282  1
    order_2_16  connected_order_arc_1303  1
    order_2_16  connected_order_arc_1324  1
    order_2_16  order_active_lb_1378  1
    order_2_16  order_active_ub_1379  1
    visit_2_17  out_degree_1382  -1
    visit_2_17  in_degree_1383  -1
    visit_2_17  order_active_lb_1384  -1
    visit_2_17  order_active_ub_1385  -11
    visit_2_17  service_visit_def_1386  -1
    order_2_17  connected_order_arc_1114  1
    order_2_17  connected_order_arc_1135  1
    order_2_17  connected_order_arc_1156  1
    order_2_17  connected_order_arc_1177  1
    order_2_17  connected_order_arc_1198  1
    order_2_17  connected_order_arc_1219  1
    order_2_17  connected_order_arc_1240  1
    order_2_17  connected_order_arc_1261  1
    order_2_17  connected_order_arc_1268  -1
    order_2_17  connected_order_arc_1270  -1
    order_2_17  connected_order_arc_1272  -1
    order_2_17  connected_order_arc_1274  -1
    order_2_17  connected_order_arc_1276  -1
    order_2_17  connected_order_arc_1278  -1
    order_2_17  connected_order_arc_1280  -1
    order_2_17  connected_order_arc_1282  -1
    order_2_17  connected_order_arc_1284  -1
    order_2_17  connected_order_arc_1286  -1
    order_2_17  connected_order_arc_1305  1
    order_2_17  connected_order_arc_1326  1
    order_2_17  order_active_lb_1384  1
    order_2_17  order_active_ub_1385  1
    visit_2_18  out_degree_1388  -1
    visit_2_18  in_degree_1389  -1
    visit_2_18  order_active_lb_1390  -1
    visit_2_18  order_active_ub_1391  -11
    visit_2_18  service_visit_def_1392  -1
    order_2_18  connected_order_arc_1116  1
    order_2_18  connected_order_arc_1137  1
    order_2_18  connected_order_arc_1158  1
    order_2_18  connected_order_arc_1179  1
    order_2_18  connected_order_arc_1200  1
    order_2_18  connected_order_arc_1221  1
    order_2_18  connected_order_arc_1242  1
    order_2_18  connected_order_arc_1263  1
    order_2_18  connected_order_arc_1284  1
    order_2_18  connected_order_arc_1289  -1
    order_2_18  connected_order_arc_1291  -1
    order_2_18  connected_order_arc_1293  -1
    order_2_18  connected_order_arc_1295  -1
    order_2_18  connected_order_arc_1297  -1
    order_2_18  connected_order_arc_1299  -1
    order_2_18  connected_order_arc_1301  -1
    order_2_18  connected_order_arc_1303  -1
    order_2_18  connected_order_arc_1305  -1
    order_2_18  connected_order_arc_1307  -1
    order_2_18  connected_order_arc_1328  1
    order_2_18  order_active_lb_1390  1
    order_2_18  order_active_ub_1391  1
    visit_2_19  out_degree_1394  -1
    visit_2_19  in_degree_1395  -1
    visit_2_19  order_active_lb_1396  -1
    visit_2_19  order_active_ub_1397  -11
    visit_2_19  service_visit_def_1398  -1
    order_2_19  connected_order_arc_1118  1
    order_2_19  connected_order_arc_1139  1
    order_2_19  connected_order_arc_1160  1
    order_2_19  connected_order_arc_1181  1
    order_2_19  connected_order_arc_1202  1
    order_2_19  connected_order_arc_1223  1
    order_2_19  connected_order_arc_1244  1
    order_2_19  connected_order_arc_1265  1
    order_2_19  connected_order_arc_1286  1
    order_2_19  connected_order_arc_1307  1
    order_2_19  connected_order_arc_1310  -1
    order_2_19  connected_order_arc_1312  -1
    order_2_19  connected_order_arc_1314  -1
    order_2_19  connected_order_arc_1316  -1
    order_2_19  connected_order_arc_1318  -1
    order_2_19  connected_order_arc_1320  -1
    order_2_19  connected_order_arc_1322  -1
    order_2_19  connected_order_arc_1324  -1
    order_2_19  connected_order_arc_1326  -1
    order_2_19  connected_order_arc_1328  -1
    order_2_19  order_active_lb_1396  1
    order_2_19  order_active_ub_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1086  -30
    arc_2_0_0  depot_departure_or_bypass_1329  1
    arc_2_0_0  depot_return_or_bypass_1330  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1086  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1087  -30
    arc_2_0_9  depot_departure_or_bypass_1329  1
    arc_2_0_9  in_degree_1332  1
    arc_2_0_9  original_T_including_depot_unload_1402  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1087  1
    load_2_0_9  segment_load_conservation_1335  -1
    load_2_0_9  segment_prefix_lb_1336  1
    load_2_0_9  segment_prefix_ub_1337  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1088  -30
    arc_2_0_10  depot_departure_or_bypass_1329  1
    arc_2_0_10  in_degree_1339  1
    arc_2_0_10  original_T_including_depot_unload_1402  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1088  1
    load_2_0_10  segment_load_conservation_1342  -1
    load_2_0_10  segment_prefix_lb_1343  1
    load_2_0_10  segment_prefix_ub_1344  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1089  -30
    arc_2_0_11  depot_departure_or_bypass_1329  1
    arc_2_0_11  in_degree_1346  1
    arc_2_0_11  original_T_including_depot_unload_1402  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1089  1
    load_2_0_11  segment_load_conservation_1349  -1
    load_2_0_11  segment_prefix_lb_1350  1
    load_2_0_11  segment_prefix_ub_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1090  -30
    arc_2_0_12  depot_departure_or_bypass_1329  1
    arc_2_0_12  in_degree_1353  1
    arc_2_0_12  original_T_including_depot_unload_1402  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1090  1
    load_2_0_12  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1091  -30
    arc_2_0_13  depot_departure_or_bypass_1329  1
    arc_2_0_13  in_degree_1359  1
    arc_2_0_13  original_T_including_depot_unload_1402  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1091  1
    load_2_0_13  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1092  -30
    arc_2_0_14  depot_departure_or_bypass_1329  1
    arc_2_0_14  in_degree_1365  1
    arc_2_0_14  original_T_including_depot_unload_1402  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1092  1
    load_2_0_14  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1093  -30
    arc_2_0_15  depot_departure_or_bypass_1329  1
    arc_2_0_15  in_degree_1371  1
    arc_2_0_15  original_T_including_depot_unload_1402  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1093  1
    load_2_0_15  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1094  -30
    arc_2_0_16  depot_departure_or_bypass_1329  1
    arc_2_0_16  in_degree_1377  1
    arc_2_0_16  original_T_including_depot_unload_1402  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1094  1
    load_2_0_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1095  -30
    arc_2_0_17  depot_departure_or_bypass_1329  1
    arc_2_0_17  in_degree_1383  1
    arc_2_0_17  original_T_including_depot_unload_1402  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1095  1
    load_2_0_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1096  -30
    arc_2_0_18  depot_departure_or_bypass_1329  1
    arc_2_0_18  in_degree_1389  1
    arc_2_0_18  original_T_including_depot_unload_1402  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1096  1
    load_2_0_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1097  -30
    arc_2_0_19  depot_departure_or_bypass_1329  1
    arc_2_0_19  in_degree_1395  1
    arc_2_0_19  original_T_including_depot_unload_1402  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1097  1
    load_2_0_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1098  -30
    arc_2_9_0  depot_return_or_bypass_1330  1
    arc_2_9_0  out_degree_1331  1
    arc_2_9_0  original_T_including_depot_unload_1402  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1098  1
    load_2_9_0  segment_load_conservation_1335  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1099  -30
    arc_2_9_10  connected_order_arc_1100  -12
    arc_2_9_10  out_degree_1331  1
    arc_2_9_10  in_degree_1339  1
    arc_2_9_10  original_T_including_depot_unload_1402  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1099  1
    load_2_9_10  segment_load_conservation_1335  1
    load_2_9_10  segment_load_conservation_1342  -1
    load_2_9_10  segment_prefix_lb_1343  1
    load_2_9_10  segment_prefix_ub_1344  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1101  -30
    arc_2_9_11  connected_order_arc_1102  -12
    arc_2_9_11  out_degree_1331  1
    arc_2_9_11  in_degree_1346  1
    arc_2_9_11  original_T_including_depot_unload_1402  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1101  1
    load_2_9_11  segment_load_conservation_1335  1
    load_2_9_11  segment_load_conservation_1349  -1
    load_2_9_11  segment_prefix_lb_1350  1
    load_2_9_11  segment_prefix_ub_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1103  -30
    arc_2_9_12  connected_order_arc_1104  -12
    arc_2_9_12  out_degree_1331  1
    arc_2_9_12  in_degree_1353  1
    arc_2_9_12  original_T_including_depot_unload_1402  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1103  1
    load_2_9_12  segment_load_conservation_1335  1
    load_2_9_12  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1105  -30
    arc_2_9_13  connected_order_arc_1106  -12
    arc_2_9_13  out_degree_1331  1
    arc_2_9_13  in_degree_1359  1
    arc_2_9_13  original_T_including_depot_unload_1402  1.7509294259345222e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1105  1
    load_2_9_13  segment_load_conservation_1335  1
    load_2_9_13  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1107  -30
    arc_2_9_14  connected_order_arc_1108  -12
    arc_2_9_14  out_degree_1331  1
    arc_2_9_14  in_degree_1365  1
    arc_2_9_14  original_T_including_depot_unload_1402  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1107  1
    load_2_9_14  segment_load_conservation_1335  1
    load_2_9_14  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1109  -30
    arc_2_9_15  connected_order_arc_1110  -12
    arc_2_9_15  out_degree_1331  1
    arc_2_9_15  in_degree_1371  1
    arc_2_9_15  original_T_including_depot_unload_1402  1.7513054753242350e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1109  1
    load_2_9_15  segment_load_conservation_1335  1
    load_2_9_15  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1111  -30
    arc_2_9_16  connected_order_arc_1112  -12
    arc_2_9_16  out_degree_1331  1
    arc_2_9_16  in_degree_1377  1
    arc_2_9_16  original_T_including_depot_unload_1402  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1111  1
    load_2_9_16  segment_load_conservation_1335  1
    load_2_9_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1113  -30
    arc_2_9_17  connected_order_arc_1114  -12
    arc_2_9_17  out_degree_1331  1
    arc_2_9_17  in_degree_1383  1
    arc_2_9_17  original_T_including_depot_unload_1402  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1113  1
    load_2_9_17  segment_load_conservation_1335  1
    load_2_9_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1115  -30
    arc_2_9_18  connected_order_arc_1116  -12
    arc_2_9_18  out_degree_1331  1
    arc_2_9_18  in_degree_1389  1
    arc_2_9_18  original_T_including_depot_unload_1402  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1115  1
    load_2_9_18  segment_load_conservation_1335  1
    load_2_9_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1117  -30
    arc_2_9_19  connected_order_arc_1118  -12
    arc_2_9_19  out_degree_1331  1
    arc_2_9_19  in_degree_1395  1
    arc_2_9_19  original_T_including_depot_unload_1402  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1117  1
    load_2_9_19  segment_load_conservation_1335  1
    load_2_9_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1119  -30
    arc_2_10_0  depot_return_or_bypass_1330  1
    arc_2_10_0  out_degree_1338  1
    arc_2_10_0  original_T_including_depot_unload_1402  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1119  1
    load_2_10_0  segment_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1120  -30
    arc_2_10_9  connected_order_arc_1121  -12
    arc_2_10_9  in_degree_1332  1
    arc_2_10_9  out_degree_1338  1
    arc_2_10_9  original_T_including_depot_unload_1402  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1120  1
    load_2_10_9  segment_load_conservation_1335  -1
    load_2_10_9  segment_prefix_lb_1336  1
    load_2_10_9  segment_prefix_ub_1337  1
    load_2_10_9  segment_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1122  -30
    arc_2_10_11  connected_order_arc_1123  -12
    arc_2_10_11  out_degree_1338  1
    arc_2_10_11  in_degree_1346  1
    arc_2_10_11  original_T_including_depot_unload_1402  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1122  1
    load_2_10_11  segment_load_conservation_1342  1
    load_2_10_11  segment_load_conservation_1349  -1
    load_2_10_11  segment_prefix_lb_1350  1
    load_2_10_11  segment_prefix_ub_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1124  -30
    arc_2_10_12  connected_order_arc_1125  -12
    arc_2_10_12  out_degree_1338  1
    arc_2_10_12  in_degree_1353  1
    arc_2_10_12  original_T_including_depot_unload_1402  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1124  1
    load_2_10_12  segment_load_conservation_1342  1
    load_2_10_12  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1126  -30
    arc_2_10_13  connected_order_arc_1127  -12
    arc_2_10_13  out_degree_1338  1
    arc_2_10_13  in_degree_1359  1
    arc_2_10_13  original_T_including_depot_unload_1402  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1126  1
    load_2_10_13  segment_load_conservation_1342  1
    load_2_10_13  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1128  -30
    arc_2_10_14  connected_order_arc_1129  -12
    arc_2_10_14  out_degree_1338  1
    arc_2_10_14  in_degree_1365  1
    arc_2_10_14  original_T_including_depot_unload_1402  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1128  1
    load_2_10_14  segment_load_conservation_1342  1
    load_2_10_14  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1130  -30
    arc_2_10_15  connected_order_arc_1131  -12
    arc_2_10_15  out_degree_1338  1
    arc_2_10_15  in_degree_1371  1
    arc_2_10_15  original_T_including_depot_unload_1402  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1130  1
    load_2_10_15  segment_load_conservation_1342  1
    load_2_10_15  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1132  -30
    arc_2_10_16  connected_order_arc_1133  -12
    arc_2_10_16  out_degree_1338  1
    arc_2_10_16  in_degree_1377  1
    arc_2_10_16  original_T_including_depot_unload_1402  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1132  1
    load_2_10_16  segment_load_conservation_1342  1
    load_2_10_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1134  -30
    arc_2_10_17  connected_order_arc_1135  -12
    arc_2_10_17  out_degree_1338  1
    arc_2_10_17  in_degree_1383  1
    arc_2_10_17  original_T_including_depot_unload_1402  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1134  1
    load_2_10_17  segment_load_conservation_1342  1
    load_2_10_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1136  -30
    arc_2_10_18  connected_order_arc_1137  -12
    arc_2_10_18  out_degree_1338  1
    arc_2_10_18  in_degree_1389  1
    arc_2_10_18  original_T_including_depot_unload_1402  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1136  1
    load_2_10_18  segment_load_conservation_1342  1
    load_2_10_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1138  -30
    arc_2_10_19  connected_order_arc_1139  -12
    arc_2_10_19  out_degree_1338  1
    arc_2_10_19  in_degree_1395  1
    arc_2_10_19  original_T_including_depot_unload_1402  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1138  1
    load_2_10_19  segment_load_conservation_1342  1
    load_2_10_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1140  -30
    arc_2_11_0  depot_return_or_bypass_1330  1
    arc_2_11_0  out_degree_1345  1
    arc_2_11_0  original_T_including_depot_unload_1402  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1140  1
    load_2_11_0  segment_load_conservation_1349  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1141  -30
    arc_2_11_9  connected_order_arc_1142  -12
    arc_2_11_9  in_degree_1332  1
    arc_2_11_9  out_degree_1345  1
    arc_2_11_9  original_T_including_depot_unload_1402  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1141  1
    load_2_11_9  segment_load_conservation_1335  -1
    load_2_11_9  segment_prefix_lb_1336  1
    load_2_11_9  segment_prefix_ub_1337  1
    load_2_11_9  segment_load_conservation_1349  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1143  -30
    arc_2_11_10  connected_order_arc_1144  -12
    arc_2_11_10  in_degree_1339  1
    arc_2_11_10  out_degree_1345  1
    arc_2_11_10  original_T_including_depot_unload_1402  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1143  1
    load_2_11_10  segment_load_conservation_1342  -1
    load_2_11_10  segment_prefix_lb_1343  1
    load_2_11_10  segment_prefix_ub_1344  1
    load_2_11_10  segment_load_conservation_1349  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1145  -30
    arc_2_11_12  connected_order_arc_1146  -12
    arc_2_11_12  out_degree_1345  1
    arc_2_11_12  in_degree_1353  1
    arc_2_11_12  original_T_including_depot_unload_1402  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1145  1
    load_2_11_12  segment_load_conservation_1349  1
    load_2_11_12  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1147  -30
    arc_2_11_13  connected_order_arc_1148  -12
    arc_2_11_13  out_degree_1345  1
    arc_2_11_13  in_degree_1359  1
    arc_2_11_13  original_T_including_depot_unload_1402  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1147  1
    load_2_11_13  segment_load_conservation_1349  1
    load_2_11_13  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1149  -30
    arc_2_11_14  connected_order_arc_1150  -12
    arc_2_11_14  out_degree_1345  1
    arc_2_11_14  in_degree_1365  1
    arc_2_11_14  original_T_including_depot_unload_1402  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1149  1
    load_2_11_14  segment_load_conservation_1349  1
    load_2_11_14  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1151  -30
    arc_2_11_15  connected_order_arc_1152  -12
    arc_2_11_15  out_degree_1345  1
    arc_2_11_15  in_degree_1371  1
    arc_2_11_15  original_T_including_depot_unload_1402  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1151  1
    load_2_11_15  segment_load_conservation_1349  1
    load_2_11_15  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1153  -30
    arc_2_11_16  connected_order_arc_1154  -12
    arc_2_11_16  out_degree_1345  1
    arc_2_11_16  in_degree_1377  1
    arc_2_11_16  original_T_including_depot_unload_1402  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1153  1
    load_2_11_16  segment_load_conservation_1349  1
    load_2_11_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1155  -30
    arc_2_11_17  connected_order_arc_1156  -12
    arc_2_11_17  out_degree_1345  1
    arc_2_11_17  in_degree_1383  1
    arc_2_11_17  original_T_including_depot_unload_1402  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1155  1
    load_2_11_17  segment_load_conservation_1349  1
    load_2_11_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1157  -30
    arc_2_11_18  connected_order_arc_1158  -12
    arc_2_11_18  out_degree_1345  1
    arc_2_11_18  in_degree_1389  1
    arc_2_11_18  original_T_including_depot_unload_1402  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1157  1
    load_2_11_18  segment_load_conservation_1349  1
    load_2_11_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1159  -30
    arc_2_11_19  connected_order_arc_1160  -12
    arc_2_11_19  out_degree_1345  1
    arc_2_11_19  in_degree_1395  1
    arc_2_11_19  original_T_including_depot_unload_1402  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1159  1
    load_2_11_19  segment_load_conservation_1349  1
    load_2_11_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1161  -30
    arc_2_12_0  depot_return_or_bypass_1330  1
    arc_2_12_0  out_degree_1352  1
    arc_2_12_0  original_T_including_depot_unload_1402  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1161  1
    load_2_12_0  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1162  -30
    arc_2_12_9  connected_order_arc_1163  -12
    arc_2_12_9  in_degree_1332  1
    arc_2_12_9  out_degree_1352  1
    arc_2_12_9  original_T_including_depot_unload_1402  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1162  1
    load_2_12_9  segment_load_conservation_1335  -1
    load_2_12_9  segment_prefix_lb_1336  1
    load_2_12_9  segment_prefix_ub_1337  1
    load_2_12_9  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1164  -30
    arc_2_12_10  connected_order_arc_1165  -12
    arc_2_12_10  in_degree_1339  1
    arc_2_12_10  out_degree_1352  1
    arc_2_12_10  original_T_including_depot_unload_1402  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1164  1
    load_2_12_10  segment_load_conservation_1342  -1
    load_2_12_10  segment_prefix_lb_1343  1
    load_2_12_10  segment_prefix_ub_1344  1
    load_2_12_10  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1166  -30
    arc_2_12_11  connected_order_arc_1167  -12
    arc_2_12_11  in_degree_1346  1
    arc_2_12_11  out_degree_1352  1
    arc_2_12_11  original_T_including_depot_unload_1402  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1166  1
    load_2_12_11  segment_load_conservation_1349  -1
    load_2_12_11  segment_prefix_lb_1350  1
    load_2_12_11  segment_prefix_ub_1351  1
    load_2_12_11  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1168  -30
    arc_2_12_13  connected_order_arc_1169  -12
    arc_2_12_13  out_degree_1352  1
    arc_2_12_13  in_degree_1359  1
    arc_2_12_13  original_T_including_depot_unload_1402  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1168  1
    load_2_12_13  free_load_conservation_1357  1
    load_2_12_13  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1170  -30
    arc_2_12_14  connected_order_arc_1171  -12
    arc_2_12_14  out_degree_1352  1
    arc_2_12_14  in_degree_1365  1
    arc_2_12_14  original_T_including_depot_unload_1402  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1170  1
    load_2_12_14  free_load_conservation_1357  1
    load_2_12_14  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1172  -30
    arc_2_12_15  connected_order_arc_1173  -12
    arc_2_12_15  out_degree_1352  1
    arc_2_12_15  in_degree_1371  1
    arc_2_12_15  original_T_including_depot_unload_1402  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1172  1
    load_2_12_15  free_load_conservation_1357  1
    load_2_12_15  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1174  -30
    arc_2_12_16  connected_order_arc_1175  -12
    arc_2_12_16  out_degree_1352  1
    arc_2_12_16  in_degree_1377  1
    arc_2_12_16  original_T_including_depot_unload_1402  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1174  1
    load_2_12_16  free_load_conservation_1357  1
    load_2_12_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1176  -30
    arc_2_12_17  connected_order_arc_1177  -12
    arc_2_12_17  out_degree_1352  1
    arc_2_12_17  in_degree_1383  1
    arc_2_12_17  original_T_including_depot_unload_1402  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1176  1
    load_2_12_17  free_load_conservation_1357  1
    load_2_12_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1178  -30
    arc_2_12_18  connected_order_arc_1179  -12
    arc_2_12_18  out_degree_1352  1
    arc_2_12_18  in_degree_1389  1
    arc_2_12_18  original_T_including_depot_unload_1402  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1178  1
    load_2_12_18  free_load_conservation_1357  1
    load_2_12_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1180  -30
    arc_2_12_19  connected_order_arc_1181  -12
    arc_2_12_19  out_degree_1352  1
    arc_2_12_19  in_degree_1395  1
    arc_2_12_19  original_T_including_depot_unload_1402  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1180  1
    load_2_12_19  free_load_conservation_1357  1
    load_2_12_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1182  -30
    arc_2_13_0  depot_return_or_bypass_1330  1
    arc_2_13_0  out_degree_1358  1
    arc_2_13_0  original_T_including_depot_unload_1402  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1182  1
    load_2_13_0  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1183  -30
    arc_2_13_9  connected_order_arc_1184  -12
    arc_2_13_9  in_degree_1332  1
    arc_2_13_9  out_degree_1358  1
    arc_2_13_9  original_T_including_depot_unload_1402  1.1473765463273915e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1183  1
    load_2_13_9  segment_load_conservation_1335  -1
    load_2_13_9  segment_prefix_lb_1336  1
    load_2_13_9  segment_prefix_ub_1337  1
    load_2_13_9  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1185  -30
    arc_2_13_10  connected_order_arc_1186  -12
    arc_2_13_10  in_degree_1339  1
    arc_2_13_10  out_degree_1358  1
    arc_2_13_10  original_T_including_depot_unload_1402  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1185  1
    load_2_13_10  segment_load_conservation_1342  -1
    load_2_13_10  segment_prefix_lb_1343  1
    load_2_13_10  segment_prefix_ub_1344  1
    load_2_13_10  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1187  -30
    arc_2_13_11  connected_order_arc_1188  -12
    arc_2_13_11  in_degree_1346  1
    arc_2_13_11  out_degree_1358  1
    arc_2_13_11  original_T_including_depot_unload_1402  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1187  1
    load_2_13_11  segment_load_conservation_1349  -1
    load_2_13_11  segment_prefix_lb_1350  1
    load_2_13_11  segment_prefix_ub_1351  1
    load_2_13_11  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1189  -30
    arc_2_13_12  connected_order_arc_1190  -12
    arc_2_13_12  in_degree_1353  1
    arc_2_13_12  out_degree_1358  1
    arc_2_13_12  original_T_including_depot_unload_1402  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1189  1
    load_2_13_12  free_load_conservation_1357  -1
    load_2_13_12  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1191  -30
    arc_2_13_14  connected_order_arc_1192  -12
    arc_2_13_14  out_degree_1358  1
    arc_2_13_14  in_degree_1365  1
    arc_2_13_14  original_T_including_depot_unload_1402  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1191  1
    load_2_13_14  free_load_conservation_1363  1
    load_2_13_14  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1193  -30
    arc_2_13_15  connected_order_arc_1194  -12
    arc_2_13_15  out_degree_1358  1
    arc_2_13_15  in_degree_1371  1
    arc_2_13_15  original_T_including_depot_unload_1402  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1193  1
    load_2_13_15  free_load_conservation_1363  1
    load_2_13_15  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1195  -30
    arc_2_13_16  connected_order_arc_1196  -12
    arc_2_13_16  out_degree_1358  1
    arc_2_13_16  in_degree_1377  1
    arc_2_13_16  original_T_including_depot_unload_1402  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1195  1
    load_2_13_16  free_load_conservation_1363  1
    load_2_13_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1197  -30
    arc_2_13_17  connected_order_arc_1198  -12
    arc_2_13_17  out_degree_1358  1
    arc_2_13_17  in_degree_1383  1
    arc_2_13_17  original_T_including_depot_unload_1402  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1197  1
    load_2_13_17  free_load_conservation_1363  1
    load_2_13_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1199  -30
    arc_2_13_18  connected_order_arc_1200  -12
    arc_2_13_18  out_degree_1358  1
    arc_2_13_18  in_degree_1389  1
    arc_2_13_18  original_T_including_depot_unload_1402  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1199  1
    load_2_13_18  free_load_conservation_1363  1
    load_2_13_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1201  -30
    arc_2_13_19  connected_order_arc_1202  -12
    arc_2_13_19  out_degree_1358  1
    arc_2_13_19  in_degree_1395  1
    arc_2_13_19  original_T_including_depot_unload_1402  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1201  1
    load_2_13_19  free_load_conservation_1363  1
    load_2_13_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1203  -30
    arc_2_14_0  depot_return_or_bypass_1330  1
    arc_2_14_0  out_degree_1364  1
    arc_2_14_0  original_T_including_depot_unload_1402  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1203  1
    load_2_14_0  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1204  -30
    arc_2_14_9  connected_order_arc_1205  -12
    arc_2_14_9  in_degree_1332  1
    arc_2_14_9  out_degree_1364  1
    arc_2_14_9  original_T_including_depot_unload_1402  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1204  1
    load_2_14_9  segment_load_conservation_1335  -1
    load_2_14_9  segment_prefix_lb_1336  1
    load_2_14_9  segment_prefix_ub_1337  1
    load_2_14_9  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1206  -30
    arc_2_14_10  connected_order_arc_1207  -12
    arc_2_14_10  in_degree_1339  1
    arc_2_14_10  out_degree_1364  1
    arc_2_14_10  original_T_including_depot_unload_1402  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1206  1
    load_2_14_10  segment_load_conservation_1342  -1
    load_2_14_10  segment_prefix_lb_1343  1
    load_2_14_10  segment_prefix_ub_1344  1
    load_2_14_10  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1208  -30
    arc_2_14_11  connected_order_arc_1209  -12
    arc_2_14_11  in_degree_1346  1
    arc_2_14_11  out_degree_1364  1
    arc_2_14_11  original_T_including_depot_unload_1402  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1208  1
    load_2_14_11  segment_load_conservation_1349  -1
    load_2_14_11  segment_prefix_lb_1350  1
    load_2_14_11  segment_prefix_ub_1351  1
    load_2_14_11  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1210  -30
    arc_2_14_12  connected_order_arc_1211  -12
    arc_2_14_12  in_degree_1353  1
    arc_2_14_12  out_degree_1364  1
    arc_2_14_12  original_T_including_depot_unload_1402  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1210  1
    load_2_14_12  free_load_conservation_1357  -1
    load_2_14_12  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1212  -30
    arc_2_14_13  connected_order_arc_1213  -12
    arc_2_14_13  in_degree_1359  1
    arc_2_14_13  out_degree_1364  1
    arc_2_14_13  original_T_including_depot_unload_1402  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1212  1
    load_2_14_13  free_load_conservation_1363  -1
    load_2_14_13  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1214  -30
    arc_2_14_15  connected_order_arc_1215  -12
    arc_2_14_15  out_degree_1364  1
    arc_2_14_15  in_degree_1371  1
    arc_2_14_15  original_T_including_depot_unload_1402  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1214  1
    load_2_14_15  free_load_conservation_1369  1
    load_2_14_15  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1216  -30
    arc_2_14_16  connected_order_arc_1217  -12
    arc_2_14_16  out_degree_1364  1
    arc_2_14_16  in_degree_1377  1
    arc_2_14_16  original_T_including_depot_unload_1402  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1216  1
    load_2_14_16  free_load_conservation_1369  1
    load_2_14_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1218  -30
    arc_2_14_17  connected_order_arc_1219  -12
    arc_2_14_17  out_degree_1364  1
    arc_2_14_17  in_degree_1383  1
    arc_2_14_17  original_T_including_depot_unload_1402  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1218  1
    load_2_14_17  free_load_conservation_1369  1
    load_2_14_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1220  -30
    arc_2_14_18  connected_order_arc_1221  -12
    arc_2_14_18  out_degree_1364  1
    arc_2_14_18  in_degree_1389  1
    arc_2_14_18  original_T_including_depot_unload_1402  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1220  1
    load_2_14_18  free_load_conservation_1369  1
    load_2_14_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1222  -30
    arc_2_14_19  connected_order_arc_1223  -12
    arc_2_14_19  out_degree_1364  1
    arc_2_14_19  in_degree_1395  1
    arc_2_14_19  original_T_including_depot_unload_1402  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1222  1
    load_2_14_19  free_load_conservation_1369  1
    load_2_14_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1224  -30
    arc_2_15_0  depot_return_or_bypass_1330  1
    arc_2_15_0  out_degree_1370  1
    arc_2_15_0  original_T_including_depot_unload_1402  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1224  1
    load_2_15_0  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1225  -30
    arc_2_15_9  connected_order_arc_1226  -12
    arc_2_15_9  in_degree_1332  1
    arc_2_15_9  out_degree_1370  1
    arc_2_15_9  original_T_including_depot_unload_1402  1.2438605922360068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1225  1
    load_2_15_9  segment_load_conservation_1335  -1
    load_2_15_9  segment_prefix_lb_1336  1
    load_2_15_9  segment_prefix_ub_1337  1
    load_2_15_9  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1227  -30
    arc_2_15_10  connected_order_arc_1228  -12
    arc_2_15_10  in_degree_1339  1
    arc_2_15_10  out_degree_1370  1
    arc_2_15_10  original_T_including_depot_unload_1402  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1227  1
    load_2_15_10  segment_load_conservation_1342  -1
    load_2_15_10  segment_prefix_lb_1343  1
    load_2_15_10  segment_prefix_ub_1344  1
    load_2_15_10  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1229  -30
    arc_2_15_11  connected_order_arc_1230  -12
    arc_2_15_11  in_degree_1346  1
    arc_2_15_11  out_degree_1370  1
    arc_2_15_11  original_T_including_depot_unload_1402  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1229  1
    load_2_15_11  segment_load_conservation_1349  -1
    load_2_15_11  segment_prefix_lb_1350  1
    load_2_15_11  segment_prefix_ub_1351  1
    load_2_15_11  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1231  -30
    arc_2_15_12  connected_order_arc_1232  -12
    arc_2_15_12  in_degree_1353  1
    arc_2_15_12  out_degree_1370  1
    arc_2_15_12  original_T_including_depot_unload_1402  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1231  1
    load_2_15_12  free_load_conservation_1357  -1
    load_2_15_12  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1233  -30
    arc_2_15_13  connected_order_arc_1234  -12
    arc_2_15_13  in_degree_1359  1
    arc_2_15_13  out_degree_1370  1
    arc_2_15_13  original_T_including_depot_unload_1402  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1233  1
    load_2_15_13  free_load_conservation_1363  -1
    load_2_15_13  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1235  -30
    arc_2_15_14  connected_order_arc_1236  -12
    arc_2_15_14  in_degree_1365  1
    arc_2_15_14  out_degree_1370  1
    arc_2_15_14  original_T_including_depot_unload_1402  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1235  1
    load_2_15_14  free_load_conservation_1369  -1
    load_2_15_14  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1237  -30
    arc_2_15_16  connected_order_arc_1238  -12
    arc_2_15_16  out_degree_1370  1
    arc_2_15_16  in_degree_1377  1
    arc_2_15_16  original_T_including_depot_unload_1402  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1237  1
    load_2_15_16  free_load_conservation_1375  1
    load_2_15_16  free_load_conservation_1381  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1239  -30
    arc_2_15_17  connected_order_arc_1240  -12
    arc_2_15_17  out_degree_1370  1
    arc_2_15_17  in_degree_1383  1
    arc_2_15_17  original_T_including_depot_unload_1402  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1239  1
    load_2_15_17  free_load_conservation_1375  1
    load_2_15_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1241  -30
    arc_2_15_18  connected_order_arc_1242  -12
    arc_2_15_18  out_degree_1370  1
    arc_2_15_18  in_degree_1389  1
    arc_2_15_18  original_T_including_depot_unload_1402  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1241  1
    load_2_15_18  free_load_conservation_1375  1
    load_2_15_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1243  -30
    arc_2_15_19  connected_order_arc_1244  -12
    arc_2_15_19  out_degree_1370  1
    arc_2_15_19  in_degree_1395  1
    arc_2_15_19  original_T_including_depot_unload_1402  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1243  1
    load_2_15_19  free_load_conservation_1375  1
    load_2_15_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1245  -30
    arc_2_16_0  depot_return_or_bypass_1330  1
    arc_2_16_0  out_degree_1376  1
    arc_2_16_0  original_T_including_depot_unload_1402  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1245  1
    load_2_16_0  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1246  -30
    arc_2_16_9  connected_order_arc_1247  -12
    arc_2_16_9  in_degree_1332  1
    arc_2_16_9  out_degree_1376  1
    arc_2_16_9  original_T_including_depot_unload_1402  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1246  1
    load_2_16_9  segment_load_conservation_1335  -1
    load_2_16_9  segment_prefix_lb_1336  1
    load_2_16_9  segment_prefix_ub_1337  1
    load_2_16_9  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1248  -30
    arc_2_16_10  connected_order_arc_1249  -12
    arc_2_16_10  in_degree_1339  1
    arc_2_16_10  out_degree_1376  1
    arc_2_16_10  original_T_including_depot_unload_1402  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1248  1
    load_2_16_10  segment_load_conservation_1342  -1
    load_2_16_10  segment_prefix_lb_1343  1
    load_2_16_10  segment_prefix_ub_1344  1
    load_2_16_10  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1250  -30
    arc_2_16_11  connected_order_arc_1251  -12
    arc_2_16_11  in_degree_1346  1
    arc_2_16_11  out_degree_1376  1
    arc_2_16_11  original_T_including_depot_unload_1402  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1250  1
    load_2_16_11  segment_load_conservation_1349  -1
    load_2_16_11  segment_prefix_lb_1350  1
    load_2_16_11  segment_prefix_ub_1351  1
    load_2_16_11  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1252  -30
    arc_2_16_12  connected_order_arc_1253  -12
    arc_2_16_12  in_degree_1353  1
    arc_2_16_12  out_degree_1376  1
    arc_2_16_12  original_T_including_depot_unload_1402  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1252  1
    load_2_16_12  free_load_conservation_1357  -1
    load_2_16_12  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1254  -30
    arc_2_16_13  connected_order_arc_1255  -12
    arc_2_16_13  in_degree_1359  1
    arc_2_16_13  out_degree_1376  1
    arc_2_16_13  original_T_including_depot_unload_1402  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1254  1
    load_2_16_13  free_load_conservation_1363  -1
    load_2_16_13  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1256  -30
    arc_2_16_14  connected_order_arc_1257  -12
    arc_2_16_14  in_degree_1365  1
    arc_2_16_14  out_degree_1376  1
    arc_2_16_14  original_T_including_depot_unload_1402  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1256  1
    load_2_16_14  free_load_conservation_1369  -1
    load_2_16_14  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1258  -30
    arc_2_16_15  connected_order_arc_1259  -12
    arc_2_16_15  in_degree_1371  1
    arc_2_16_15  out_degree_1376  1
    arc_2_16_15  original_T_including_depot_unload_1402  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1258  1
    load_2_16_15  free_load_conservation_1375  -1
    load_2_16_15  free_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1260  -30
    arc_2_16_17  connected_order_arc_1261  -12
    arc_2_16_17  out_degree_1376  1
    arc_2_16_17  in_degree_1383  1
    arc_2_16_17  original_T_including_depot_unload_1402  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1260  1
    load_2_16_17  free_load_conservation_1381  1
    load_2_16_17  free_load_conservation_1387  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1262  -30
    arc_2_16_18  connected_order_arc_1263  -12
    arc_2_16_18  out_degree_1376  1
    arc_2_16_18  in_degree_1389  1
    arc_2_16_18  original_T_including_depot_unload_1402  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1262  1
    load_2_16_18  free_load_conservation_1381  1
    load_2_16_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1264  -30
    arc_2_16_19  connected_order_arc_1265  -12
    arc_2_16_19  out_degree_1376  1
    arc_2_16_19  in_degree_1395  1
    arc_2_16_19  original_T_including_depot_unload_1402  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1264  1
    load_2_16_19  free_load_conservation_1381  1
    load_2_16_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1266  -30
    arc_2_17_0  depot_return_or_bypass_1330  1
    arc_2_17_0  out_degree_1382  1
    arc_2_17_0  original_T_including_depot_unload_1402  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1266  1
    load_2_17_0  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1267  -30
    arc_2_17_9  connected_order_arc_1268  -12
    arc_2_17_9  in_degree_1332  1
    arc_2_17_9  out_degree_1382  1
    arc_2_17_9  original_T_including_depot_unload_1402  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1267  1
    load_2_17_9  segment_load_conservation_1335  -1
    load_2_17_9  segment_prefix_lb_1336  1
    load_2_17_9  segment_prefix_ub_1337  1
    load_2_17_9  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1269  -30
    arc_2_17_10  connected_order_arc_1270  -12
    arc_2_17_10  in_degree_1339  1
    arc_2_17_10  out_degree_1382  1
    arc_2_17_10  original_T_including_depot_unload_1402  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1269  1
    load_2_17_10  segment_load_conservation_1342  -1
    load_2_17_10  segment_prefix_lb_1343  1
    load_2_17_10  segment_prefix_ub_1344  1
    load_2_17_10  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1271  -30
    arc_2_17_11  connected_order_arc_1272  -12
    arc_2_17_11  in_degree_1346  1
    arc_2_17_11  out_degree_1382  1
    arc_2_17_11  original_T_including_depot_unload_1402  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1271  1
    load_2_17_11  segment_load_conservation_1349  -1
    load_2_17_11  segment_prefix_lb_1350  1
    load_2_17_11  segment_prefix_ub_1351  1
    load_2_17_11  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1273  -30
    arc_2_17_12  connected_order_arc_1274  -12
    arc_2_17_12  in_degree_1353  1
    arc_2_17_12  out_degree_1382  1
    arc_2_17_12  original_T_including_depot_unload_1402  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1273  1
    load_2_17_12  free_load_conservation_1357  -1
    load_2_17_12  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1275  -30
    arc_2_17_13  connected_order_arc_1276  -12
    arc_2_17_13  in_degree_1359  1
    arc_2_17_13  out_degree_1382  1
    arc_2_17_13  original_T_including_depot_unload_1402  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1275  1
    load_2_17_13  free_load_conservation_1363  -1
    load_2_17_13  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1277  -30
    arc_2_17_14  connected_order_arc_1278  -12
    arc_2_17_14  in_degree_1365  1
    arc_2_17_14  out_degree_1382  1
    arc_2_17_14  original_T_including_depot_unload_1402  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1277  1
    load_2_17_14  free_load_conservation_1369  -1
    load_2_17_14  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1279  -30
    arc_2_17_15  connected_order_arc_1280  -12
    arc_2_17_15  in_degree_1371  1
    arc_2_17_15  out_degree_1382  1
    arc_2_17_15  original_T_including_depot_unload_1402  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1279  1
    load_2_17_15  free_load_conservation_1375  -1
    load_2_17_15  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1281  -30
    arc_2_17_16  connected_order_arc_1282  -12
    arc_2_17_16  in_degree_1377  1
    arc_2_17_16  out_degree_1382  1
    arc_2_17_16  original_T_including_depot_unload_1402  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1281  1
    load_2_17_16  free_load_conservation_1381  -1
    load_2_17_16  free_load_conservation_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1283  -30
    arc_2_17_18  connected_order_arc_1284  -12
    arc_2_17_18  out_degree_1382  1
    arc_2_17_18  in_degree_1389  1
    arc_2_17_18  original_T_including_depot_unload_1402  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1283  1
    load_2_17_18  free_load_conservation_1387  1
    load_2_17_18  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1285  -30
    arc_2_17_19  connected_order_arc_1286  -12
    arc_2_17_19  out_degree_1382  1
    arc_2_17_19  in_degree_1395  1
    arc_2_17_19  original_T_including_depot_unload_1402  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1285  1
    load_2_17_19  free_load_conservation_1387  1
    load_2_17_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1287  -30
    arc_2_18_0  depot_return_or_bypass_1330  1
    arc_2_18_0  out_degree_1388  1
    arc_2_18_0  original_T_including_depot_unload_1402  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1287  1
    load_2_18_0  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1288  -30
    arc_2_18_9  connected_order_arc_1289  -12
    arc_2_18_9  in_degree_1332  1
    arc_2_18_9  out_degree_1388  1
    arc_2_18_9  original_T_including_depot_unload_1402  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1288  1
    load_2_18_9  segment_load_conservation_1335  -1
    load_2_18_9  segment_prefix_lb_1336  1
    load_2_18_9  segment_prefix_ub_1337  1
    load_2_18_9  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1290  -30
    arc_2_18_10  connected_order_arc_1291  -12
    arc_2_18_10  in_degree_1339  1
    arc_2_18_10  out_degree_1388  1
    arc_2_18_10  original_T_including_depot_unload_1402  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1290  1
    load_2_18_10  segment_load_conservation_1342  -1
    load_2_18_10  segment_prefix_lb_1343  1
    load_2_18_10  segment_prefix_ub_1344  1
    load_2_18_10  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1292  -30
    arc_2_18_11  connected_order_arc_1293  -12
    arc_2_18_11  in_degree_1346  1
    arc_2_18_11  out_degree_1388  1
    arc_2_18_11  original_T_including_depot_unload_1402  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1292  1
    load_2_18_11  segment_load_conservation_1349  -1
    load_2_18_11  segment_prefix_lb_1350  1
    load_2_18_11  segment_prefix_ub_1351  1
    load_2_18_11  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1294  -30
    arc_2_18_12  connected_order_arc_1295  -12
    arc_2_18_12  in_degree_1353  1
    arc_2_18_12  out_degree_1388  1
    arc_2_18_12  original_T_including_depot_unload_1402  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1294  1
    load_2_18_12  free_load_conservation_1357  -1
    load_2_18_12  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1296  -30
    arc_2_18_13  connected_order_arc_1297  -12
    arc_2_18_13  in_degree_1359  1
    arc_2_18_13  out_degree_1388  1
    arc_2_18_13  original_T_including_depot_unload_1402  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1296  1
    load_2_18_13  free_load_conservation_1363  -1
    load_2_18_13  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1298  -30
    arc_2_18_14  connected_order_arc_1299  -12
    arc_2_18_14  in_degree_1365  1
    arc_2_18_14  out_degree_1388  1
    arc_2_18_14  original_T_including_depot_unload_1402  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1298  1
    load_2_18_14  free_load_conservation_1369  -1
    load_2_18_14  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1300  -30
    arc_2_18_15  connected_order_arc_1301  -12
    arc_2_18_15  in_degree_1371  1
    arc_2_18_15  out_degree_1388  1
    arc_2_18_15  original_T_including_depot_unload_1402  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1300  1
    load_2_18_15  free_load_conservation_1375  -1
    load_2_18_15  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1302  -30
    arc_2_18_16  connected_order_arc_1303  -12
    arc_2_18_16  in_degree_1377  1
    arc_2_18_16  out_degree_1388  1
    arc_2_18_16  original_T_including_depot_unload_1402  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1302  1
    load_2_18_16  free_load_conservation_1381  -1
    load_2_18_16  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1304  -30
    arc_2_18_17  connected_order_arc_1305  -12
    arc_2_18_17  in_degree_1383  1
    arc_2_18_17  out_degree_1388  1
    arc_2_18_17  original_T_including_depot_unload_1402  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1304  1
    load_2_18_17  free_load_conservation_1387  -1
    load_2_18_17  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1306  -30
    arc_2_18_19  connected_order_arc_1307  -12
    arc_2_18_19  out_degree_1388  1
    arc_2_18_19  in_degree_1395  1
    arc_2_18_19  original_T_including_depot_unload_1402  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1306  1
    load_2_18_19  free_load_conservation_1393  1
    load_2_18_19  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1308  -30
    arc_2_19_0  depot_return_or_bypass_1330  1
    arc_2_19_0  out_degree_1394  1
    arc_2_19_0  original_T_including_depot_unload_1402  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1308  1
    load_2_19_0  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1309  -30
    arc_2_19_9  connected_order_arc_1310  -12
    arc_2_19_9  in_degree_1332  1
    arc_2_19_9  out_degree_1394  1
    arc_2_19_9  original_T_including_depot_unload_1402  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1309  1
    load_2_19_9  segment_load_conservation_1335  -1
    load_2_19_9  segment_prefix_lb_1336  1
    load_2_19_9  segment_prefix_ub_1337  1
    load_2_19_9  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1311  -30
    arc_2_19_10  connected_order_arc_1312  -12
    arc_2_19_10  in_degree_1339  1
    arc_2_19_10  out_degree_1394  1
    arc_2_19_10  original_T_including_depot_unload_1402  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1311  1
    load_2_19_10  segment_load_conservation_1342  -1
    load_2_19_10  segment_prefix_lb_1343  1
    load_2_19_10  segment_prefix_ub_1344  1
    load_2_19_10  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1313  -30
    arc_2_19_11  connected_order_arc_1314  -12
    arc_2_19_11  in_degree_1346  1
    arc_2_19_11  out_degree_1394  1
    arc_2_19_11  original_T_including_depot_unload_1402  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1313  1
    load_2_19_11  segment_load_conservation_1349  -1
    load_2_19_11  segment_prefix_lb_1350  1
    load_2_19_11  segment_prefix_ub_1351  1
    load_2_19_11  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1315  -30
    arc_2_19_12  connected_order_arc_1316  -12
    arc_2_19_12  in_degree_1353  1
    arc_2_19_12  out_degree_1394  1
    arc_2_19_12  original_T_including_depot_unload_1402  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1315  1
    load_2_19_12  free_load_conservation_1357  -1
    load_2_19_12  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1317  -30
    arc_2_19_13  connected_order_arc_1318  -12
    arc_2_19_13  in_degree_1359  1
    arc_2_19_13  out_degree_1394  1
    arc_2_19_13  original_T_including_depot_unload_1402  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1317  1
    load_2_19_13  free_load_conservation_1363  -1
    load_2_19_13  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1319  -30
    arc_2_19_14  connected_order_arc_1320  -12
    arc_2_19_14  in_degree_1365  1
    arc_2_19_14  out_degree_1394  1
    arc_2_19_14  original_T_including_depot_unload_1402  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1319  1
    load_2_19_14  free_load_conservation_1369  -1
    load_2_19_14  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1321  -30
    arc_2_19_15  connected_order_arc_1322  -12
    arc_2_19_15  in_degree_1371  1
    arc_2_19_15  out_degree_1394  1
    arc_2_19_15  original_T_including_depot_unload_1402  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1321  1
    load_2_19_15  free_load_conservation_1375  -1
    load_2_19_15  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1323  -30
    arc_2_19_16  connected_order_arc_1324  -12
    arc_2_19_16  in_degree_1377  1
    arc_2_19_16  out_degree_1394  1
    arc_2_19_16  original_T_including_depot_unload_1402  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1323  1
    load_2_19_16  free_load_conservation_1381  -1
    load_2_19_16  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1325  -30
    arc_2_19_17  connected_order_arc_1326  -12
    arc_2_19_17  in_degree_1383  1
    arc_2_19_17  out_degree_1394  1
    arc_2_19_17  original_T_including_depot_unload_1402  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1325  1
    load_2_19_17  free_load_conservation_1387  -1
    load_2_19_17  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1327  -30
    arc_2_19_18  connected_order_arc_1328  -12
    arc_2_19_18  in_degree_1389  1
    arc_2_19_18  out_degree_1394  1
    arc_2_19_18  original_T_including_depot_unload_1402  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1327  1
    load_2_19_18  free_load_conservation_1393  -1
    load_2_19_18  free_load_conservation_1399  1
RHS
    RHS1      OBJ       -2.5288588598380557e-01
    RHS1      onehot_27_14  1
    RHS1      onehot_25_27  1
    RHS1      onehot_34_62  1
    RHS1      onehot_23_73  1
    RHS1      onehot_22_108  1
    RHS1      onehot_26_129  1
    RHS1      onehot_32_172  1
    RHS1      onehot_31_199  1
    RHS1      stock_ub_203  23
    RHS1      parent_nonstrict_scope_204  3.0850492019953130e-01
    RHS1      normalization_261  1
    RHS1      connected_order_arc_359  -12
    RHS1      connected_order_arc_361  -12
    RHS1      connected_order_arc_363  -12
    RHS1      connected_order_arc_365  -12
    RHS1      connected_order_arc_367  -12
    RHS1      connected_order_arc_369  -12
    RHS1      connected_order_arc_371  -12
    RHS1      connected_order_arc_373  -12
    RHS1      connected_order_arc_375  -12
    RHS1      connected_order_arc_377  -12
    RHS1      connected_order_arc_379  -12
    RHS1      connected_order_arc_382  -12
    RHS1      connected_order_arc_384  -12
    RHS1      connected_order_arc_386  -12
    RHS1      connected_order_arc_388  -12
    RHS1      connected_order_arc_390  -12
    RHS1      connected_order_arc_392  -12
    RHS1      connected_order_arc_394  -12
    RHS1      connected_order_arc_396  -12
    RHS1      connected_order_arc_398  -12
    RHS1      connected_order_arc_400  -12
    RHS1      connected_order_arc_402  -12
    RHS1      connected_order_arc_405  -12
    RHS1      connected_order_arc_407  -12
    RHS1      connected_order_arc_409  -12
    RHS1      connected_order_arc_411  -12
    RHS1      connected_order_arc_413  -12
    RHS1      connected_order_arc_415  -12
    RHS1      connected_order_arc_417  -12
    RHS1      connected_order_arc_419  -12
    RHS1      connected_order_arc_421  -12
    RHS1      connected_order_arc_423  -12
    RHS1      connected_order_arc_425  -12
    RHS1      connected_order_arc_428  -12
    RHS1      connected_order_arc_430  -12
    RHS1      connected_order_arc_432  -12
    RHS1      connected_order_arc_434  -12
    RHS1      connected_order_arc_436  -12
    RHS1      connected_order_arc_438  -12
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_442  -12
    RHS1      connected_order_arc_444  -12
    RHS1      connected_order_arc_446  -12
    RHS1      connected_order_arc_448  -12
    RHS1      connected_order_arc_451  -12
    RHS1      connected_order_arc_453  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_465  -12
    RHS1      connected_order_arc_467  -12
    RHS1      connected_order_arc_469  -12
    RHS1      connected_order_arc_471  -12
    RHS1      connected_order_arc_474  -12
    RHS1      connected_order_arc_476  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_488  -12
    RHS1      connected_order_arc_490  -12
    RHS1      connected_order_arc_492  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_497  -12
    RHS1      connected_order_arc_499  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_511  -12
    RHS1      connected_order_arc_513  -12
    RHS1      connected_order_arc_515  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_520  -12
    RHS1      connected_order_arc_522  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_534  -12
    RHS1      connected_order_arc_536  -12
    RHS1      connected_order_arc_538  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_543  -12
    RHS1      connected_order_arc_545  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_557  -12
    RHS1      connected_order_arc_559  -12
    RHS1      connected_order_arc_561  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_566  -12
    RHS1      connected_order_arc_568  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_580  -12
    RHS1      connected_order_arc_582  -12
    RHS1      connected_order_arc_584  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_589  -12
    RHS1      connected_order_arc_591  -12
    RHS1      connected_order_arc_593  -12
    RHS1      connected_order_arc_595  -12
    RHS1      connected_order_arc_597  -12
    RHS1      connected_order_arc_599  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_603  -12
    RHS1      connected_order_arc_605  -12
    RHS1      connected_order_arc_607  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_612  -12
    RHS1      connected_order_arc_614  -12
    RHS1      connected_order_arc_616  -12
    RHS1      connected_order_arc_618  -12
    RHS1      connected_order_arc_620  -12
    RHS1      connected_order_arc_622  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_626  -12
    RHS1      connected_order_arc_628  -12
    RHS1      connected_order_arc_630  -12
    RHS1      connected_order_arc_632  -12
    RHS1      depot_departure_or_bypass_633  1
    RHS1      depot_return_or_bypass_634  1
    RHS1      segment_load_conservation_639  2
    RHS1      segment_prefix_ub_641  9
    RHS1      segment_load_conservation_646  1
    RHS1      segment_prefix_ub_648  15
    RHS1      segment_load_conservation_653  2
    RHS1      segment_prefix_ub_655  18
    RHS1      segment_load_conservation_660  -3
    RHS1      segment_prefix_lb_661  3
    RHS1      segment_prefix_ub_662  20
    RHS1      fixed_segment_relative_order_711  1
    RHS1      fixed_segment_relative_order_712  1
    RHS1      fixed_segment_relative_order_713  1
    RHS1      original_T_including_depot_unload_714  1.6086462339106183e+03
    RHS1      connected_order_arc_730  -12
    RHS1      connected_order_arc_732  -12
    RHS1      connected_order_arc_734  -12
    RHS1      connected_order_arc_736  -12
    RHS1      connected_order_arc_738  -12
    RHS1      connected_order_arc_740  -12
    RHS1      connected_order_arc_742  -12
    RHS1      connected_order_arc_744  -12
    RHS1      connected_order_arc_746  -12
    RHS1      connected_order_arc_748  -12
    RHS1      connected_order_arc_750  -12
    RHS1      connected_order_arc_753  -12
    RHS1      connected_order_arc_755  -12
    RHS1      connected_order_arc_757  -12
    RHS1      connected_order_arc_759  -12
    RHS1      connected_order_arc_761  -12
    RHS1      connected_order_arc_763  -12
    RHS1      connected_order_arc_765  -12
    RHS1      connected_order_arc_767  -12
    RHS1      connected_order_arc_769  -12
    RHS1      connected_order_arc_771  -12
    RHS1      connected_order_arc_773  -12
    RHS1      connected_order_arc_776  -12
    RHS1      connected_order_arc_778  -12
    RHS1      connected_order_arc_780  -12
    RHS1      connected_order_arc_782  -12
    RHS1      connected_order_arc_784  -12
    RHS1      connected_order_arc_786  -12
    RHS1      connected_order_arc_788  -12
    RHS1      connected_order_arc_790  -12
    RHS1      connected_order_arc_792  -12
    RHS1      connected_order_arc_794  -12
    RHS1      connected_order_arc_796  -12
    RHS1      connected_order_arc_799  -12
    RHS1      connected_order_arc_801  -12
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_809  -12
    RHS1      connected_order_arc_811  -12
    RHS1      connected_order_arc_813  -12
    RHS1      connected_order_arc_815  -12
    RHS1      connected_order_arc_817  -12
    RHS1      connected_order_arc_819  -12
    RHS1      connected_order_arc_822  -12
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_836  -12
    RHS1      connected_order_arc_838  -12
    RHS1      connected_order_arc_840  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      depot_departure_or_bypass_1004  1
    RHS1      depot_return_or_bypass_1005  1
    RHS1      segment_load_conservation_1010  5
    RHS1      segment_prefix_ub_1012  20
    RHS1      segment_load_conservation_1017  5
    RHS1      segment_prefix_ub_1019  20
    RHS1      segment_load_conservation_1024  -4
    RHS1      segment_prefix_lb_1025  4
    RHS1      segment_prefix_ub_1026  25
    RHS1      segment_load_conservation_1031  -6
    RHS1      segment_prefix_lb_1032  6
    RHS1      segment_prefix_ub_1033  25
    RHS1      fixed_segment_relative_order_1082  1
    RHS1      fixed_segment_relative_order_1083  1
    RHS1      fixed_segment_relative_order_1084  1
    RHS1      original_T_including_depot_unload_1085  5100
    RHS1      connected_order_arc_1100  -11
    RHS1      connected_order_arc_1102  -11
    RHS1      connected_order_arc_1104  -11
    RHS1      connected_order_arc_1106  -11
    RHS1      connected_order_arc_1108  -11
    RHS1      connected_order_arc_1110  -11
    RHS1      connected_order_arc_1112  -11
    RHS1      connected_order_arc_1114  -11
    RHS1      connected_order_arc_1116  -11
    RHS1      connected_order_arc_1118  -11
    RHS1      connected_order_arc_1121  -11
    RHS1      connected_order_arc_1123  -11
    RHS1      connected_order_arc_1125  -11
    RHS1      connected_order_arc_1127  -11
    RHS1      connected_order_arc_1129  -11
    RHS1      connected_order_arc_1131  -11
    RHS1      connected_order_arc_1133  -11
    RHS1      connected_order_arc_1135  -11
    RHS1      connected_order_arc_1137  -11
    RHS1      connected_order_arc_1139  -11
    RHS1      connected_order_arc_1142  -11
    RHS1      connected_order_arc_1144  -11
    RHS1      connected_order_arc_1146  -11
    RHS1      connected_order_arc_1148  -11
    RHS1      connected_order_arc_1150  -11
    RHS1      connected_order_arc_1152  -11
    RHS1      connected_order_arc_1154  -11
    RHS1      connected_order_arc_1156  -11
    RHS1      connected_order_arc_1158  -11
    RHS1      connected_order_arc_1160  -11
    RHS1      connected_order_arc_1163  -11
    RHS1      connected_order_arc_1165  -11
    RHS1      connected_order_arc_1167  -11
    RHS1      connected_order_arc_1169  -11
    RHS1      connected_order_arc_1171  -11
    RHS1      connected_order_arc_1173  -11
    RHS1      connected_order_arc_1175  -11
    RHS1      connected_order_arc_1177  -11
    RHS1      connected_order_arc_1179  -11
    RHS1      connected_order_arc_1181  -11
    RHS1      connected_order_arc_1184  -11
    RHS1      connected_order_arc_1186  -11
    RHS1      connected_order_arc_1188  -11
    RHS1      connected_order_arc_1190  -11
    RHS1      connected_order_arc_1192  -11
    RHS1      connected_order_arc_1194  -11
    RHS1      connected_order_arc_1196  -11
    RHS1      connected_order_arc_1198  -11
    RHS1      connected_order_arc_1200  -11
    RHS1      connected_order_arc_1202  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1207  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1213  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1217  -11
    RHS1      connected_order_arc_1219  -11
    RHS1      connected_order_arc_1221  -11
    RHS1      connected_order_arc_1223  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1228  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1234  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1238  -11
    RHS1      connected_order_arc_1240  -11
    RHS1      connected_order_arc_1242  -11
    RHS1      connected_order_arc_1244  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1261  -11
    RHS1      connected_order_arc_1263  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1291  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      depot_departure_or_bypass_1329  1
    RHS1      depot_return_or_bypass_1330  1
    RHS1      segment_load_conservation_1335  3
    RHS1      segment_prefix_ub_1337  27
    RHS1      segment_load_conservation_1342  -1
    RHS1      segment_prefix_lb_1343  1
    RHS1      segment_prefix_ub_1344  30
    RHS1      segment_load_conservation_1349  -1
    RHS1      segment_prefix_lb_1350  1
    RHS1      segment_prefix_ub_1351  30
    RHS1      fixed_segment_relative_order_1400  1
    RHS1      fixed_segment_relative_order_1401  1
    RHS1      original_T_including_depot_unload_1402  4.7591520335762489e+03
BOUNDS
 LO BND1      t         2.4551831644558458e-02
 UP BND1      t         4.2073628850530440e-02
 UP BND1      q         4.2393967896198825e-01
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.2073628850530440e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.2073628850530440e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.2073628850530440e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.2073628850530440e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.2073628850530440e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.2073628850530440e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.2073628850530440e-02
 UP BND1      rho_27    1
 BV BND1      x_25_0  
 UP BND1      w_25_0    4.2073628850530440e-02
 BV BND1      x_25_1  
 UP BND1      w_25_1    4.2073628850530440e-02
 BV BND1      x_25_2  
 UP BND1      w_25_2    4.2073628850530440e-02
 BV BND1      x_25_3  
 UP BND1      w_25_3    4.2073628850530440e-02
 BV BND1      x_25_4  
 UP BND1      w_25_4    4.2073628850530440e-02
 UP BND1      rho_25    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.2073628850530440e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.2073628850530440e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.2073628850530440e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.2073628850530440e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.2073628850530440e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.2073628850530440e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.2073628850530440e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.2073628850530440e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.2073628850530440e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.2073628850530440e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.2073628850530440e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.2073628850530440e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.2073628850530440e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.2073628850530440e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.2073628850530440e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.2073628850530440e-02
 UP BND1      rho_34    1
 BV BND1      x_23_0  
 UP BND1      w_23_0    4.2073628850530440e-02
 BV BND1      x_23_1  
 UP BND1      w_23_1    4.2073628850530440e-02
 BV BND1      x_23_2  
 UP BND1      w_23_2    4.2073628850530440e-02
 BV BND1      x_23_3  
 UP BND1      w_23_3    4.2073628850530440e-02
 UP BND1      rho_23    1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.2073628850530440e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.2073628850530440e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.2073628850530440e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.2073628850530440e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.2073628850530440e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.2073628850530440e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.2073628850530440e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.2073628850530440e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.2073628850530440e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.2073628850530440e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.2073628850530440e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.2073628850530440e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.2073628850530440e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.2073628850530440e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.2073628850530440e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.2073628850530440e-02
 UP BND1      rho_22    1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.2073628850530440e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.2073628850530440e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.2073628850530440e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.2073628850530440e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.2073628850530440e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.2073628850530440e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.2073628850530440e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.2073628850530440e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.2073628850530440e-02
 UP BND1      rho_26    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.2073628850530440e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.2073628850530440e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.2073628850530440e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.2073628850530440e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.2073628850530440e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.2073628850530440e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.2073628850530440e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.2073628850530440e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.2073628850530440e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.2073628850530440e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.2073628850530440e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.2073628850530440e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.2073628850530440e-02
 BV BND1      x_32_13 
 UP BND1      w_32_13   4.2073628850530440e-02
 BV BND1      x_32_14 
 UP BND1      w_32_14   4.2073628850530440e-02
 BV BND1      x_32_15 
 UP BND1      w_32_15   4.2073628850530440e-02
 BV BND1      x_32_16 
 UP BND1      w_32_16   4.2073628850530440e-02
 BV BND1      x_32_17 
 UP BND1      w_32_17   4.2073628850530440e-02
 BV BND1      x_32_18 
 UP BND1      w_32_18   4.2073628850530440e-02
 BV BND1      x_32_19 
 UP BND1      w_32_19   4.2073628850530440e-02
 UP BND1      rho_32    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2073628850530440e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2073628850530440e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2073628850530440e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2073628850530440e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2073628850530440e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2073628850530440e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2073628850530440e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2073628850530440e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2073628850530440e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2073628850530440e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2073628850530440e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2073628850530440e-02
 UP BND1      rho_31    1
 UP BND1      a_27_25   1
 UP BND1      a_27_34   1
 UP BND1      a_27_23   1
 UP BND1      a_27_22   1
 UP BND1      a_27_26   1
 UP BND1      a_27_32   1
 UP BND1      a_27_31   1
 UP BND1      a_25_34   1
 UP BND1      a_25_23   1
 UP BND1      a_25_22   1
 UP BND1      a_25_26   1
 UP BND1      a_25_32   1
 UP BND1      a_25_31   1
 UP BND1      a_34_23   1
 UP BND1      a_34_22   1
 UP BND1      a_34_26   1
 UP BND1      a_34_32   1
 UP BND1      a_34_31   1
 UP BND1      a_23_22   1
 UP BND1      a_23_26   1
 UP BND1      a_23_32   1
 UP BND1      a_23_31   1
 UP BND1      a_22_26   1
 UP BND1      a_22_32   1
 UP BND1      a_22_31   1
 UP BND1      a_26_32   1
 UP BND1      a_26_31   1
 UP BND1      a_32_31   1
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_25_1
 BV BND1      service_0_25_2
 BV BND1      service_0_25_3
 BV BND1      service_0_25_4
 BV BND1      service_1_25_1
 BV BND1      service_1_25_2
 BV BND1      service_1_25_3
 BV BND1      service_1_25_4
 BV BND1      service_2_25_1
 BV BND1      service_2_25_2
 BV BND1      service_2_25_3
 BV BND1      service_2_25_4
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_23_0
 BV BND1      service_0_23_2
 BV BND1      service_0_23_3
 BV BND1      service_1_23_0
 BV BND1      service_1_23_2
 BV BND1      service_1_23_3
 BV BND1      service_2_23_0
 BV BND1      service_2_23_2
 BV BND1      service_2_23_3
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_26_0
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_0
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_0
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_32_0
 BV BND1      service_0_32_1
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_0_32_13
 BV BND1      service_0_32_14
 BV BND1      service_0_32_15
 BV BND1      service_0_32_16
 BV BND1      service_0_32_17
 BV BND1      service_0_32_18
 BV BND1      service_0_32_19
 BV BND1      service_1_32_0
 BV BND1      service_1_32_1
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_1_32_13
 BV BND1      service_1_32_14
 BV BND1      service_1_32_15
 BV BND1      service_1_32_16
 BV BND1      service_1_32_17
 BV BND1      service_1_32_18
 BV BND1      service_1_32_19
 BV BND1      service_2_32_0
 BV BND1      service_2_32_1
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_2_32_13
 BV BND1      service_2_32_14
 BV BND1      service_2_32_15
 BV BND1      service_2_32_16
 BV BND1      service_2_32_17
 BV BND1      service_2_32_18
 BV BND1      service_2_32_19
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_2
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_2
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_2
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
