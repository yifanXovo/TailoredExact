* Signature: 0xd1bafec535e1ff84
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_34_32
 E  normalized_mass_34_33
 E  normalized_ratio_34_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 E  onehot_31_59
 E  normalized_mass_31_60
 E  normalized_ratio_31_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 E  onehot_35_94
 E  normalized_mass_35_95
 E  normalized_ratio_35_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 E  onehot_32_137
 E  normalized_mass_32_138
 E  normalized_ratio_32_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 E  onehot_27_154
 E  normalized_mass_27_155
 E  normalized_ratio_27_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 E  onehot_25_167
 E  normalized_mass_25_168
 E  normalized_ratio_25_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 E  onehot_22_202
 E  normalized_mass_22_203
 E  normalized_ratio_22_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 E  onehot_26_223
 E  normalized_mass_26_224
 E  normalized_ratio_26_225
 G  stock_lb_226
 L  stock_ub_227
 L  parent_nonstrict_scope_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 E  normalization_285
 G  full_original_Gini_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 E  depot_departure_or_bypass_669
 E  depot_return_or_bypass_670
 E  out_degree_671
 E  in_degree_672
 G  order_active_lb_673
 L  order_active_ub_674
 E  segment_load_conservation_675
 G  segment_prefix_lb_676
 L  segment_prefix_ub_677
 E  out_degree_678
 E  in_degree_679
 G  order_active_lb_680
 L  order_active_ub_681
 E  segment_load_conservation_682
 G  segment_prefix_lb_683
 L  segment_prefix_ub_684
 E  out_degree_685
 E  in_degree_686
 G  order_active_lb_687
 L  order_active_ub_688
 E  segment_load_conservation_689
 G  segment_prefix_lb_690
 L  segment_prefix_ub_691
 E  out_degree_692
 E  in_degree_693
 G  order_active_lb_694
 L  order_active_ub_695
 E  segment_load_conservation_696
 G  segment_prefix_lb_697
 L  segment_prefix_ub_698
 E  out_degree_699
 E  in_degree_700
 G  order_active_lb_701
 L  order_active_ub_702
 E  service_visit_def_703
 E  free_load_conservation_704
 E  out_degree_705
 E  in_degree_706
 G  order_active_lb_707
 L  order_active_ub_708
 E  service_visit_def_709
 E  free_load_conservation_710
 E  out_degree_711
 E  in_degree_712
 G  order_active_lb_713
 L  order_active_ub_714
 E  service_visit_def_715
 E  free_load_conservation_716
 E  out_degree_717
 E  in_degree_718
 G  order_active_lb_719
 L  order_active_ub_720
 E  service_visit_def_721
 E  free_load_conservation_722
 E  out_degree_723
 E  in_degree_724
 G  order_active_lb_725
 L  order_active_ub_726
 E  service_visit_def_727
 E  free_load_conservation_728
 E  out_degree_729
 E  in_degree_730
 G  order_active_lb_731
 L  order_active_ub_732
 E  service_visit_def_733
 E  free_load_conservation_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  service_visit_def_739
 E  free_load_conservation_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  service_visit_def_745
 E  free_load_conservation_746
 G  fixed_segment_relative_order_747
 G  fixed_segment_relative_order_748
 G  fixed_segment_relative_order_749
 L  original_T_including_depot_unload_750
 L  arc_capacity_751
 L  arc_capacity_752
 L  arc_capacity_753
 L  arc_capacity_754
 L  arc_capacity_755
 L  arc_capacity_756
 L  arc_capacity_757
 L  arc_capacity_758
 L  arc_capacity_759
 L  arc_capacity_760
 L  arc_capacity_761
 L  arc_capacity_762
 L  arc_capacity_763
 L  arc_capacity_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 E  depot_departure_or_bypass_1040
 E  depot_return_or_bypass_1041
 E  out_degree_1042
 E  in_degree_1043
 G  order_active_lb_1044
 L  order_active_ub_1045
 E  segment_load_conservation_1046
 G  segment_prefix_lb_1047
 L  segment_prefix_ub_1048
 E  out_degree_1049
 E  in_degree_1050
 G  order_active_lb_1051
 L  order_active_ub_1052
 E  segment_load_conservation_1053
 G  segment_prefix_lb_1054
 L  segment_prefix_ub_1055
 E  out_degree_1056
 E  in_degree_1057
 G  order_active_lb_1058
 L  order_active_ub_1059
 E  segment_load_conservation_1060
 G  segment_prefix_lb_1061
 L  segment_prefix_ub_1062
 E  out_degree_1063
 E  in_degree_1064
 G  order_active_lb_1065
 L  order_active_ub_1066
 E  segment_load_conservation_1067
 G  segment_prefix_lb_1068
 L  segment_prefix_ub_1069
 E  out_degree_1070
 E  in_degree_1071
 G  order_active_lb_1072
 L  order_active_ub_1073
 E  service_visit_def_1074
 E  free_load_conservation_1075
 E  out_degree_1076
 E  in_degree_1077
 G  order_active_lb_1078
 L  order_active_ub_1079
 E  service_visit_def_1080
 E  free_load_conservation_1081
 E  out_degree_1082
 E  in_degree_1083
 G  order_active_lb_1084
 L  order_active_ub_1085
 E  service_visit_def_1086
 E  free_load_conservation_1087
 E  out_degree_1088
 E  in_degree_1089
 G  order_active_lb_1090
 L  order_active_ub_1091
 E  service_visit_def_1092
 E  free_load_conservation_1093
 E  out_degree_1094
 E  in_degree_1095
 G  order_active_lb_1096
 L  order_active_ub_1097
 E  service_visit_def_1098
 E  free_load_conservation_1099
 E  out_degree_1100
 E  in_degree_1101
 G  order_active_lb_1102
 L  order_active_ub_1103
 E  service_visit_def_1104
 E  free_load_conservation_1105
 E  out_degree_1106
 E  in_degree_1107
 G  order_active_lb_1108
 L  order_active_ub_1109
 E  service_visit_def_1110
 E  free_load_conservation_1111
 E  out_degree_1112
 E  in_degree_1113
 G  order_active_lb_1114
 L  order_active_ub_1115
 E  service_visit_def_1116
 E  free_load_conservation_1117
 G  fixed_segment_relative_order_1118
 G  fixed_segment_relative_order_1119
 G  fixed_segment_relative_order_1120
 L  original_T_including_depot_unload_1121
 L  arc_capacity_1122
 L  arc_capacity_1123
 L  arc_capacity_1124
 L  arc_capacity_1125
 L  arc_capacity_1126
 L  arc_capacity_1127
 L  arc_capacity_1128
 L  arc_capacity_1129
 L  arc_capacity_1130
 L  arc_capacity_1131
 L  arc_capacity_1132
 L  arc_capacity_1133
 L  arc_capacity_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 E  depot_departure_or_bypass_1365
 E  depot_return_or_bypass_1366
 E  out_degree_1367
 E  in_degree_1368
 G  order_active_lb_1369
 L  order_active_ub_1370
 E  segment_load_conservation_1371
 G  segment_prefix_lb_1372
 L  segment_prefix_ub_1373
 E  out_degree_1374
 E  in_degree_1375
 G  order_active_lb_1376
 L  order_active_ub_1377
 E  segment_load_conservation_1378
 G  segment_prefix_lb_1379
 L  segment_prefix_ub_1380
 E  out_degree_1381
 E  in_degree_1382
 G  order_active_lb_1383
 L  order_active_ub_1384
 E  segment_load_conservation_1385
 G  segment_prefix_lb_1386
 L  segment_prefix_ub_1387
 E  out_degree_1388
 E  in_degree_1389
 G  order_active_lb_1390
 L  order_active_ub_1391
 E  service_visit_def_1392
 E  free_load_conservation_1393
 E  out_degree_1394
 E  in_degree_1395
 G  order_active_lb_1396
 L  order_active_ub_1397
 E  service_visit_def_1398
 E  free_load_conservation_1399
 E  out_degree_1400
 E  in_degree_1401
 G  order_active_lb_1402
 L  order_active_ub_1403
 E  service_visit_def_1404
 E  free_load_conservation_1405
 E  out_degree_1406
 E  in_degree_1407
 G  order_active_lb_1408
 L  order_active_ub_1409
 E  service_visit_def_1410
 E  free_load_conservation_1411
 E  out_degree_1412
 E  in_degree_1413
 G  order_active_lb_1414
 L  order_active_ub_1415
 E  service_visit_def_1416
 E  free_load_conservation_1417
 E  out_degree_1418
 E  in_degree_1419
 G  order_active_lb_1420
 L  order_active_ub_1421
 E  service_visit_def_1422
 E  free_load_conservation_1423
 E  out_degree_1424
 E  in_degree_1425
 G  order_active_lb_1426
 L  order_active_ub_1427
 E  service_visit_def_1428
 E  free_load_conservation_1429
 E  out_degree_1430
 E  in_degree_1431
 G  order_active_lb_1432
 L  order_active_ub_1433
 E  service_visit_def_1434
 E  free_load_conservation_1435
 G  fixed_segment_relative_order_1436
 G  fixed_segment_relative_order_1437
 L  original_T_including_depot_unload_1438
COLUMNS
    t         normalized_mass_34_33  -1
    t         normalized_mass_31_60  -1
    t         normalized_mass_35_95  -1
    t         normalized_mass_32_138  -1
    t         normalized_mass_27_155  -1
    t         normalized_mass_25_168  -1
    t         normalized_mass_22_203  -1
    t         normalized_mass_26_224  -1
    t         normalization_285  2.4342857142857145e+01
    t         full_original_Gini_286  -6.8452380952380963e+01
    q         OBJ       1
    q         parent_nonstrict_scope_228  1
    q         full_original_Gini_286  35
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_0  -2.4887905662961264e-02
    x_34_0    product_ub_1  -4.1079812206613858e-02
    x_34_0    onehot_34_32  1
    x_34_0    parent_nonstrict_scope_228  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_0  1
    w_34_0    product_ub_1  1
    w_34_0    normalized_mass_34_33  1
    w_34_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_2  -2.4887905662961264e-02
    x_34_1    product_ub_3  -4.1079812206613858e-02
    x_34_1    onehot_34_32  1
    x_34_1    stock_lb_226  1
    x_34_1    stock_ub_227  1
    x_34_1    parent_nonstrict_scope_228  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_2  1
    w_34_1    product_ub_3  1
    w_34_1    normalized_mass_34_33  1
    w_34_1    normalized_ratio_34_34  -0.125
    w_34_1    full_original_Gini_286  -2.0967857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_4  -2.4887905662961264e-02
    x_34_2    product_ub_5  -4.1079812206613858e-02
    x_34_2    onehot_34_32  1
    x_34_2    stock_lb_226  2
    x_34_2    stock_ub_227  2
    x_34_2    parent_nonstrict_scope_228  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_4  1
    w_34_2    product_ub_5  1
    w_34_2    normalized_mass_34_33  1
    w_34_2    normalized_ratio_34_34  -0.25
    w_34_2    full_original_Gini_286  -1.7592857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_6  -2.4887905662961264e-02
    x_34_3    product_ub_7  -4.1079812206613858e-02
    x_34_3    onehot_34_32  1
    x_34_3    stock_lb_226  3
    x_34_3    stock_ub_227  3
    x_34_3    parent_nonstrict_scope_228  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_6  1
    w_34_3    product_ub_7  1
    w_34_3    normalized_mass_34_33  1
    w_34_3    normalized_ratio_34_34  -0.375
    w_34_3    full_original_Gini_286  -1.4217857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_8  -2.4887905662961264e-02
    x_34_4    product_ub_9  -4.1079812206613858e-02
    x_34_4    onehot_34_32  1
    x_34_4    stock_lb_226  4
    x_34_4    stock_ub_227  4
    x_34_4    parent_nonstrict_scope_228  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_8  1
    w_34_4    product_ub_9  1
    w_34_4    normalized_mass_34_33  1
    w_34_4    normalized_ratio_34_34  -0.5
    w_34_4    full_original_Gini_286  -1.0842857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_10  -2.4887905662961264e-02
    x_34_5    product_ub_11  -4.1079812206613858e-02
    x_34_5    onehot_34_32  1
    x_34_5    stock_lb_226  5
    x_34_5    stock_ub_227  5
    x_34_5    parent_nonstrict_scope_228  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_10  1
    w_34_5    product_ub_11  1
    w_34_5    normalized_mass_34_33  1
    w_34_5    normalized_ratio_34_34  -0.625
    w_34_5    full_original_Gini_286  -7.7678571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_12  -2.4887905662961264e-02
    x_34_6    product_ub_13  -4.1079812206613858e-02
    x_34_6    onehot_34_32  1
    x_34_6    stock_lb_226  6
    x_34_6    stock_ub_227  6
    x_34_6    parent_nonstrict_scope_228  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_12  1
    w_34_6    product_ub_13  1
    w_34_6    normalized_mass_34_33  1
    w_34_6    normalized_ratio_34_34  -0.75
    w_34_6    full_original_Gini_286  -5.2023809523809526e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_14  -2.4887905662961264e-02
    x_34_7    product_ub_15  -4.1079812206613858e-02
    x_34_7    onehot_34_32  1
    x_34_7    stock_lb_226  7
    x_34_7    stock_ub_227  7
    x_34_7    parent_nonstrict_scope_228  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_14  1
    w_34_7    product_ub_15  1
    w_34_7    normalized_mass_34_33  1
    w_34_7    normalized_ratio_34_34  -0.875
    w_34_7    full_original_Gini_286  -4.0321428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_16  -2.4887905662961264e-02
    x_34_8    product_ub_17  -4.1079812206613858e-02
    x_34_8    onehot_34_32  1
    x_34_8    stock_lb_226  8
    x_34_8    stock_ub_227  8
    x_34_8    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_16  1
    w_34_8    product_ub_17  1
    w_34_8    normalized_mass_34_33  1
    w_34_8    normalized_ratio_34_34  -1
    w_34_8    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_18  -2.4887905662961264e-02
    x_34_9    product_ub_19  -4.1079812206613858e-02
    x_34_9    onehot_34_32  1
    x_34_9    stock_lb_226  9
    x_34_9    stock_ub_227  9
    x_34_9    parent_nonstrict_scope_228  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_18  1
    w_34_9    product_ub_19  1
    w_34_9    normalized_mass_34_33  1
    w_34_9    normalized_ratio_34_34  -1.125
    w_34_9    full_original_Gini_286  -6.7821428571428584e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_20  -2.4887905662961264e-02
    x_34_10   product_ub_21  -4.1079812206613858e-02
    x_34_10   onehot_34_32  1
    x_34_10   stock_lb_226  10
    x_34_10   stock_ub_227  10
    x_34_10   parent_nonstrict_scope_228  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_20  1
    w_34_10   product_ub_21  1
    w_34_10   normalized_mass_34_33  1
    w_34_10   normalized_ratio_34_34  -1.25
    w_34_10   full_original_Gini_286  -9.9071428571428584e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_22  -2.4887905662961264e-02
    x_34_11   product_ub_23  -4.1079812206613858e-02
    x_34_11   onehot_34_32  1
    x_34_11   stock_lb_226  11
    x_34_11   stock_ub_227  11
    x_34_11   parent_nonstrict_scope_228  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_22  1
    w_34_11   product_ub_23  1
    w_34_11   normalized_mass_34_33  1
    w_34_11   normalized_ratio_34_34  -1.375
    w_34_11   full_original_Gini_286  -1.3032142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_24  -2.4887905662961264e-02
    x_34_12   product_ub_25  -4.1079812206613858e-02
    x_34_12   onehot_34_32  1
    x_34_12   stock_lb_226  12
    x_34_12   stock_ub_227  12
    x_34_12   parent_nonstrict_scope_228  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_24  1
    w_34_12   product_ub_25  1
    w_34_12   normalized_mass_34_33  1
    w_34_12   normalized_ratio_34_34  -1.5
    w_34_12   full_original_Gini_286  -1.6157142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_26  -2.4887905662961264e-02
    x_34_13   product_ub_27  -4.1079812206613858e-02
    x_34_13   onehot_34_32  1
    x_34_13   stock_lb_226  13
    x_34_13   stock_ub_227  13
    x_34_13   parent_nonstrict_scope_228  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_26  1
    w_34_13   product_ub_27  1
    w_34_13   normalized_mass_34_33  1
    w_34_13   normalized_ratio_34_34  -1.625
    w_34_13   full_original_Gini_286  -1.9532142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_28  -2.4887905662961264e-02
    x_34_14   product_ub_29  -4.1079812206613858e-02
    x_34_14   onehot_34_32  1
    x_34_14   stock_lb_226  14
    x_34_14   stock_ub_227  14
    x_34_14   parent_nonstrict_scope_228  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_28  1
    w_34_14   product_ub_29  1
    w_34_14   normalized_mass_34_33  1
    w_34_14   normalized_ratio_34_34  -1.75
    w_34_14   full_original_Gini_286  -2.2907142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_30  -2.4887905662961264e-02
    x_34_15   product_ub_31  -4.1079812206613858e-02
    x_34_15   onehot_34_32  1
    x_34_15   stock_lb_226  15
    x_34_15   stock_ub_227  15
    x_34_15   parent_nonstrict_scope_228  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_30  1
    w_34_15   product_ub_31  1
    w_34_15   normalized_mass_34_33  1
    w_34_15   normalized_ratio_34_34  -1.875
    w_34_15   full_original_Gini_286  -2.6282142857142855e+01
    rho_34    normalized_ratio_34_34  1
    rho_34    block_pair_pos_261  -1
    rho_34    block_pair_neg_262  1
    rho_34    block_pair_pos_263  -1
    rho_34    block_pair_neg_264  1
    rho_34    block_pair_pos_265  -1
    rho_34    block_pair_neg_266  1
    rho_34    block_pair_pos_267  -1
    rho_34    block_pair_neg_268  1
    rho_34    block_pair_pos_269  -1
    rho_34    block_pair_neg_270  1
    rho_34    block_pair_pos_271  -1
    rho_34    block_pair_neg_272  1
    rho_34    block_pair_pos_273  -1
    rho_34    block_pair_neg_274  1
    rho_34    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       1.6756644912833352e-02
    x_31_0    product_lb_35  -2.4887905662961264e-02
    x_31_0    product_ub_36  -4.1079812206613858e-02
    x_31_0    onehot_31_59  1
    x_31_0    parent_nonstrict_scope_228  0.0335132898256667
    x_31_0    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_35  1
    w_31_0    product_ub_36  1
    w_31_0    normalized_mass_31_60  1
    w_31_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       1.1171096608555569e-02
    x_31_1    product_lb_37  -2.4887905662961264e-02
    x_31_1    product_ub_38  -4.1079812206613858e-02
    x_31_1    onehot_31_59  1
    x_31_1    stock_lb_226  1
    x_31_1    stock_ub_227  1
    x_31_1    parent_nonstrict_scope_228  2.7927741521388921e-02
    x_31_1    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_37  1
    w_31_1    product_ub_38  1
    w_31_1    normalized_mass_31_60  1
    w_31_1    normalized_ratio_31_61  -1.6666666666666666e-01
    w_31_1    full_original_Gini_286  -1.9842857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       5.5855483042777862e-03
    x_31_2    product_lb_39  -2.4887905662961264e-02
    x_31_2    product_ub_40  -4.1079812206613858e-02
    x_31_2    onehot_31_59  1
    x_31_2    stock_lb_226  2
    x_31_2    stock_ub_227  2
    x_31_2    parent_nonstrict_scope_228  2.2342193217111138e-02
    x_31_2    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_39  1
    w_31_2    product_ub_40  1
    w_31_2    normalized_mass_31_60  1
    w_31_2    normalized_ratio_31_61  -3.3333333333333331e-01
    w_31_2    full_original_Gini_286  -1.5342857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    product_lb_41  -2.4887905662961264e-02
    x_31_3    product_ub_42  -4.1079812206613858e-02
    x_31_3    onehot_31_59  1
    x_31_3    stock_lb_226  3
    x_31_3    stock_ub_227  3
    x_31_3    parent_nonstrict_scope_228  1.6756644912833352e-02
    x_31_3    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_41  1
    w_31_3    product_ub_42  1
    w_31_3    normalized_mass_31_60  1
    w_31_3    normalized_ratio_31_61  -0.5
    w_31_3    full_original_Gini_286  -1.0842857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.5855483042777827e-03
    x_31_4    product_lb_43  -2.4887905662961264e-02
    x_31_4    product_ub_44  -4.1079812206613858e-02
    x_31_4    onehot_31_59  1
    x_31_4    stock_lb_226  4
    x_31_4    stock_ub_227  4
    x_31_4    parent_nonstrict_scope_228  1.1171096608555569e-02
    x_31_4    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_43  1
    w_31_4    product_ub_44  1
    w_31_4    normalized_mass_31_60  1
    w_31_4    normalized_ratio_31_61  -6.6666666666666663e-01
    w_31_4    full_original_Gini_286  -6.8095238095238066e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.1171096608555565e-02
    x_31_5    product_lb_45  -2.4887905662961264e-02
    x_31_5    product_ub_46  -4.1079812206613858e-02
    x_31_5    onehot_31_59  1
    x_31_5    stock_lb_226  5
    x_31_5    stock_ub_227  5
    x_31_5    parent_nonstrict_scope_228  5.5855483042777862e-03
    x_31_5    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_45  1
    w_31_5    product_ub_46  1
    w_31_5    normalized_mass_31_60  1
    w_31_5    normalized_ratio_31_61  -8.3333333333333326e-01
    w_31_5    full_original_Gini_286  -4.2523809523809541e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -1.6756644912833352e-02
    x_31_6    product_lb_47  -2.4887905662961264e-02
    x_31_6    product_ub_48  -4.1079812206613858e-02
    x_31_6    onehot_31_59  1
    x_31_6    stock_lb_226  6
    x_31_6    stock_ub_227  6
    x_31_6    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_47  1
    w_31_6    product_ub_48  1
    w_31_6    normalized_mass_31_60  1
    w_31_6    normalized_ratio_31_61  -1
    w_31_6    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -1.1171096608555572e-02
    x_31_7    product_lb_49  -2.4887905662961264e-02
    x_31_7    product_ub_50  -4.1079812206613858e-02
    x_31_7    onehot_31_59  1
    x_31_7    stock_lb_226  7
    x_31_7    stock_ub_227  7
    x_31_7    parent_nonstrict_scope_228  5.5855483042777793e-03
    x_31_7    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_49  1
    w_31_7    product_ub_50  1
    w_31_7    normalized_mass_31_60  1
    w_31_7    normalized_ratio_31_61  -1.1666666666666665e+00
    w_31_7    full_original_Gini_286  -7.8238095238095156e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -5.5855483042777862e-03
    x_31_8    product_lb_51  -2.4887905662961264e-02
    x_31_8    product_ub_52  -4.1079812206613858e-02
    x_31_8    onehot_31_59  1
    x_31_8    stock_lb_226  8
    x_31_8    stock_ub_227  8
    x_31_8    parent_nonstrict_scope_228  1.1171096608555565e-02
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_51  1
    w_31_8    product_ub_52  1
    w_31_8    normalized_mass_31_60  1
    w_31_8    normalized_ratio_31_61  -1.3333333333333333e+00
    w_31_8    full_original_Gini_286  -1.1990476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_9    product_lb_53  -2.4887905662961264e-02
    x_31_9    product_ub_54  -4.1079812206613858e-02
    x_31_9    onehot_31_59  1
    x_31_9    stock_lb_226  9
    x_31_9    stock_ub_227  9
    x_31_9    parent_nonstrict_scope_228  1.6756644912833352e-02
    x_31_9    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_53  1
    w_31_9    product_ub_54  1
    w_31_9    normalized_mass_31_60  1
    w_31_9    normalized_ratio_31_61  -1.5
    w_31_9    full_original_Gini_286  -1.6157142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       5.5855483042777793e-03
    x_31_10   product_lb_55  -2.4887905662961264e-02
    x_31_10   product_ub_56  -4.1079812206613858e-02
    x_31_10   onehot_31_59  1
    x_31_10   stock_lb_226  10
    x_31_10   stock_ub_227  10
    x_31_10   parent_nonstrict_scope_228  2.2342193217111131e-02
    x_31_10   unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_55  1
    w_31_10   product_ub_56  1
    w_31_10   normalized_mass_31_60  1
    w_31_10   normalized_ratio_31_61  -1.6666666666666665e+00
    w_31_10   full_original_Gini_286  -2.0657142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       1.1171096608555565e-02
    x_31_11   product_lb_57  -2.4887905662961264e-02
    x_31_11   product_ub_58  -4.1079812206613858e-02
    x_31_11   onehot_31_59  1
    x_31_11   stock_lb_226  11
    x_31_11   stock_ub_227  11
    x_31_11   parent_nonstrict_scope_228  2.7927741521388917e-02
    x_31_11   unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_57  1
    w_31_11   product_ub_58  1
    w_31_11   normalized_mass_31_60  1
    w_31_11   normalized_ratio_31_61  -1.8333333333333333e+00
    w_31_11   full_original_Gini_286  -2.5157142857142855e+01
    rho_31    normalized_ratio_31_61  1
    rho_31    block_pair_pos_241  -1
    rho_31    block_pair_neg_242  1
    rho_31    block_pair_pos_243  -1
    rho_31    block_pair_neg_244  1
    rho_31    block_pair_pos_245  -1
    rho_31    block_pair_neg_246  1
    rho_31    block_pair_pos_247  -1
    rho_31    block_pair_neg_248  1
    rho_31    block_pair_pos_249  -1
    rho_31    block_pair_neg_250  1
    rho_31    block_pair_pos_251  -1
    rho_31    block_pair_neg_252  1
    rho_31    block_pair_pos_269  1
    rho_31    block_pair_neg_270  -1
    rho_31    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       2.9789603523644435e-02
    x_35_0    product_lb_62  -2.4887905662961264e-02
    x_35_0    product_ub_63  -4.1079812206613858e-02
    x_35_0    onehot_35_94  1
    x_35_0    parent_nonstrict_scope_228  5.9579207047288869e-02
    x_35_0    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_62  1
    w_35_0    product_ub_63  1
    w_35_0    normalized_mass_35_95  1
    w_35_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       2.2342202642733327e-02
    x_35_1    product_lb_64  -2.4887905662961264e-02
    x_35_1    product_ub_65  -4.1079812206613858e-02
    x_35_1    onehot_35_94  1
    x_35_1    stock_lb_226  1
    x_35_1    stock_ub_227  1
    x_35_1    parent_nonstrict_scope_228  5.2131806166377762e-02
    x_35_1    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_64  1
    w_35_1    product_ub_65  1
    w_35_1    normalized_mass_35_95  1
    w_35_1    normalized_ratio_35_96  -0.125
    w_35_1    full_original_Gini_286  -2.0967857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       1.4894801761822219e-02
    x_35_2    product_lb_66  -2.4887905662961264e-02
    x_35_2    product_ub_67  -4.1079812206613858e-02
    x_35_2    onehot_35_94  1
    x_35_2    stock_lb_226  2
    x_35_2    stock_ub_227  2
    x_35_2    parent_nonstrict_scope_228  4.4684405285466654e-02
    x_35_2    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_66  1
    w_35_2    product_ub_67  1
    w_35_2    normalized_mass_35_95  1
    w_35_2    normalized_ratio_35_96  -0.25
    w_35_2    full_original_Gini_286  -1.7592857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       7.4474008809111113e-03
    x_35_3    product_lb_68  -2.4887905662961264e-02
    x_35_3    product_ub_69  -4.1079812206613858e-02
    x_35_3    onehot_35_94  1
    x_35_3    stock_lb_226  3
    x_35_3    stock_ub_227  3
    x_35_3    parent_nonstrict_scope_228  3.7237004404555546e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_68  1
    w_35_3    product_ub_69  1
    w_35_3    normalized_mass_35_95  1
    w_35_3    normalized_ratio_35_96  -0.375
    w_35_3    full_original_Gini_286  -1.4217857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_70  -2.4887905662961264e-02
    x_35_4    product_ub_71  -4.1079812206613858e-02
    x_35_4    onehot_35_94  1
    x_35_4    stock_lb_226  4
    x_35_4    stock_ub_227  4
    x_35_4    parent_nonstrict_scope_228  2.9789603523644435e-02
    x_35_4    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_70  1
    w_35_4    product_ub_71  1
    w_35_4    normalized_mass_35_95  1
    w_35_4    normalized_ratio_35_96  -0.5
    w_35_4    full_original_Gini_286  -1.0842857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -7.4474008809111078e-03
    x_35_5    product_lb_72  -2.4887905662961264e-02
    x_35_5    product_ub_73  -4.1079812206613858e-02
    x_35_5    onehot_35_94  1
    x_35_5    stock_lb_226  5
    x_35_5    stock_ub_227  5
    x_35_5    parent_nonstrict_scope_228  2.2342202642733327e-02
    x_35_5    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_72  1
    w_35_5    product_ub_73  1
    w_35_5    normalized_mass_35_95  1
    w_35_5    normalized_ratio_35_96  -0.625
    w_35_5    full_original_Gini_286  -7.7678571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -1.4894801761822217e-02
    x_35_6    product_lb_74  -2.4887905662961264e-02
    x_35_6    product_ub_75  -4.1079812206613858e-02
    x_35_6    onehot_35_94  1
    x_35_6    stock_lb_226  6
    x_35_6    stock_ub_227  6
    x_35_6    parent_nonstrict_scope_228  1.4894801761822217e-02
    x_35_6    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_74  1
    w_35_6    product_ub_75  1
    w_35_6    normalized_mass_35_95  1
    w_35_6    normalized_ratio_35_96  -0.75
    w_35_6    full_original_Gini_286  -5.2023809523809526e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -2.2342202642733327e-02
    x_35_7    product_lb_76  -2.4887905662961264e-02
    x_35_7    product_ub_77  -4.1079812206613858e-02
    x_35_7    onehot_35_94  1
    x_35_7    stock_lb_226  7
    x_35_7    stock_ub_227  7
    x_35_7    parent_nonstrict_scope_228  7.4474008809111087e-03
    x_35_7    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_76  1
    w_35_7    product_ub_77  1
    w_35_7    normalized_mass_35_95  1
    w_35_7    normalized_ratio_35_96  -0.875
    w_35_7    full_original_Gini_286  -4.0321428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -2.9789603523644435e-02
    x_35_8    product_lb_78  -2.4887905662961264e-02
    x_35_8    product_ub_79  -4.1079812206613858e-02
    x_35_8    onehot_35_94  1
    x_35_8    stock_lb_226  8
    x_35_8    stock_ub_227  8
    x_35_8    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_78  1
    w_35_8    product_ub_79  1
    w_35_8    normalized_mass_35_95  1
    w_35_8    normalized_ratio_35_96  -1
    w_35_8    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -2.2342202642733327e-02
    x_35_9    product_lb_80  -2.4887905662961264e-02
    x_35_9    product_ub_81  -4.1079812206613858e-02
    x_35_9    onehot_35_94  1
    x_35_9    stock_lb_226  9
    x_35_9    stock_ub_227  9
    x_35_9    parent_nonstrict_scope_228  7.4474008809111087e-03
    x_35_9    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_80  1
    w_35_9    product_ub_81  1
    w_35_9    normalized_mass_35_95  1
    w_35_9    normalized_ratio_35_96  -1.125
    w_35_9    full_original_Gini_286  -6.7821428571428584e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -1.4894801761822217e-02
    x_35_10   product_lb_82  -2.4887905662961264e-02
    x_35_10   product_ub_83  -4.1079812206613858e-02
    x_35_10   onehot_35_94  1
    x_35_10   stock_lb_226  10
    x_35_10   stock_ub_227  10
    x_35_10   parent_nonstrict_scope_228  1.4894801761822217e-02
    x_35_10   unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_82  1
    w_35_10   product_ub_83  1
    w_35_10   normalized_mass_35_95  1
    w_35_10   normalized_ratio_35_96  -1.25
    w_35_10   full_original_Gini_286  -9.9071428571428584e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -7.4474008809111078e-03
    x_35_11   product_lb_84  -2.4887905662961264e-02
    x_35_11   product_ub_85  -4.1079812206613858e-02
    x_35_11   onehot_35_94  1
    x_35_11   stock_lb_226  11
    x_35_11   stock_ub_227  11
    x_35_11   parent_nonstrict_scope_228  2.2342202642733327e-02
    x_35_11   unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_84  1
    w_35_11   product_ub_85  1
    w_35_11   normalized_mass_35_95  1
    w_35_11   normalized_ratio_35_96  -1.375
    w_35_11   full_original_Gini_286  -1.3032142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_86  -2.4887905662961264e-02
    x_35_12   product_ub_87  -4.1079812206613858e-02
    x_35_12   onehot_35_94  1
    x_35_12   stock_lb_226  12
    x_35_12   stock_ub_227  12
    x_35_12   parent_nonstrict_scope_228  2.9789603523644435e-02
    x_35_12   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_86  1
    w_35_12   product_ub_87  1
    w_35_12   normalized_mass_35_95  1
    w_35_12   normalized_ratio_35_96  -1.5
    w_35_12   full_original_Gini_286  -1.6157142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       7.4474008809111113e-03
    x_35_13   product_lb_88  -2.4887905662961264e-02
    x_35_13   product_ub_89  -4.1079812206613858e-02
    x_35_13   onehot_35_94  1
    x_35_13   stock_lb_226  13
    x_35_13   stock_ub_227  13
    x_35_13   parent_nonstrict_scope_228  3.7237004404555546e-02
    x_35_13   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_88  1
    w_35_13   product_ub_89  1
    w_35_13   normalized_mass_35_95  1
    w_35_13   normalized_ratio_35_96  -1.625
    w_35_13   full_original_Gini_286  -1.9532142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       1.4894801761822219e-02
    x_35_14   product_lb_90  -2.4887905662961264e-02
    x_35_14   product_ub_91  -4.1079812206613858e-02
    x_35_14   onehot_35_94  1
    x_35_14   stock_lb_226  14
    x_35_14   stock_ub_227  14
    x_35_14   parent_nonstrict_scope_228  4.4684405285466654e-02
    x_35_14   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_90  1
    w_35_14   product_ub_91  1
    w_35_14   normalized_mass_35_95  1
    w_35_14   normalized_ratio_35_96  -1.75
    w_35_14   full_original_Gini_286  -2.2907142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       2.2342202642733327e-02
    x_35_15   product_lb_92  -2.4887905662961264e-02
    x_35_15   product_ub_93  -4.1079812206613858e-02
    x_35_15   onehot_35_94  1
    x_35_15   stock_lb_226  15
    x_35_15   stock_ub_227  15
    x_35_15   parent_nonstrict_scope_228  5.2131806166377762e-02
    x_35_15   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_92  1
    w_35_15   product_ub_93  1
    w_35_15   normalized_mass_35_95  1
    w_35_15   normalized_ratio_35_96  -1.875
    w_35_15   full_original_Gini_286  -2.6282142857142855e+01
    rho_35    normalized_ratio_35_96  1
    rho_35    block_pair_pos_251  1
    rho_35    block_pair_neg_252  -1
    rho_35    block_pair_pos_273  1
    rho_35    block_pair_neg_274  -1
    rho_35    block_pair_pos_275  -1
    rho_35    block_pair_neg_276  1
    rho_35    block_pair_pos_277  -1
    rho_35    block_pair_neg_278  1
    rho_35    block_pair_pos_279  -1
    rho_35    block_pair_neg_280  1
    rho_35    block_pair_pos_281  -1
    rho_35    block_pair_neg_282  1
    rho_35    block_pair_pos_283  -1
    rho_35    block_pair_neg_284  1
    rho_35    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       3.3513323338990042e-02
    x_32_0    product_lb_97  -2.4887905662961264e-02
    x_32_0    product_ub_98  -4.1079812206613858e-02
    x_32_0    onehot_32_137  1
    x_32_0    parent_nonstrict_scope_228  0.0754049775127276
    x_32_0    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_97  1
    w_32_0    product_ub_98  1
    w_32_0    normalized_mass_32_138  1
    w_32_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       2.5134992504242532e-02
    x_32_1    product_lb_99  -2.4887905662961264e-02
    x_32_1    product_ub_100  -4.1079812206613858e-02
    x_32_1    onehot_32_137  1
    x_32_1    stock_lb_226  1
    x_32_1    stock_ub_227  1
    x_32_1    parent_nonstrict_scope_228  6.7026646677980084e-02
    x_32_1    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_99  1
    w_32_1    product_ub_100  1
    w_32_1    normalized_mass_32_138  1
    w_32_1    normalized_ratio_32_139  -1.1111111111111110e-01
    w_32_1    full_original_Gini_286  -2.1342857142857149e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       1.6756661669495021e-02
    x_32_2    product_lb_101  -2.4887905662961264e-02
    x_32_2    product_ub_102  -4.1079812206613858e-02
    x_32_2    onehot_32_137  1
    x_32_2    stock_lb_226  2
    x_32_2    stock_ub_227  2
    x_32_2    parent_nonstrict_scope_228  5.8648315843232574e-02
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_101  1
    w_32_2    product_ub_102  1
    w_32_2    normalized_mass_32_138  1
    w_32_2    normalized_ratio_32_139  -2.2222222222222221e-01
    w_32_2    full_original_Gini_286  -1.8342857142857149e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       8.3783308347475174e-03
    x_32_3    product_lb_103  -2.4887905662961264e-02
    x_32_3    product_ub_104  -4.1079812206613858e-02
    x_32_3    onehot_32_137  1
    x_32_3    stock_lb_226  3
    x_32_3    stock_ub_227  3
    x_32_3    parent_nonstrict_scope_228  5.0269985008485070e-02
    x_32_3    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_103  1
    w_32_3    product_ub_104  1
    w_32_3    normalized_mass_32_138  1
    w_32_3    normalized_ratio_32_139  -3.3333333333333331e-01
    w_32_3    full_original_Gini_286  -1.5342857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_4    product_lb_105  -2.4887905662961264e-02
    x_32_4    product_ub_106  -4.1079812206613858e-02
    x_32_4    onehot_32_137  1
    x_32_4    stock_lb_226  4
    x_32_4    stock_ub_227  4
    x_32_4    parent_nonstrict_scope_228  4.1891654173737553e-02
    x_32_4    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_105  1
    w_32_4    product_ub_106  1
    w_32_4    normalized_mass_32_138  1
    w_32_4    normalized_ratio_32_139  -4.4444444444444442e-01
    w_32_4    full_original_Gini_286  -1.2342857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -0.00837833083474751
    x_32_5    product_lb_107  -2.4887905662961264e-02
    x_32_5    product_ub_108  -4.1079812206613858e-02
    x_32_5    onehot_32_137  1
    x_32_5    stock_lb_226  5
    x_32_5    stock_ub_227  5
    x_32_5    parent_nonstrict_scope_228  3.3513323338990042e-02
    x_32_5    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_107  1
    w_32_5    product_ub_108  1
    w_32_5    normalized_mass_32_138  1
    w_32_5    normalized_ratio_32_139  -5.5555555555555558e-01
    w_32_5    full_original_Gini_286  -9.4539682539682541e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -1.6756661669495018e-02
    x_32_6    product_lb_109  -2.4887905662961264e-02
    x_32_6    product_ub_110  -4.1079812206613858e-02
    x_32_6    onehot_32_137  1
    x_32_6    stock_lb_226  6
    x_32_6    stock_ub_227  6
    x_32_6    parent_nonstrict_scope_228  2.5134992504242535e-02
    x_32_6    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_109  1
    w_32_6    product_ub_110  1
    w_32_6    normalized_mass_32_138  1
    w_32_6    normalized_ratio_32_139  -6.6666666666666663e-01
    w_32_6    full_original_Gini_286  -6.8095238095238066e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -2.5134992504242525e-02
    x_32_7    product_lb_111  -2.4887905662961264e-02
    x_32_7    product_ub_112  -4.1079812206613858e-02
    x_32_7    onehot_32_137  1
    x_32_7    stock_lb_226  7
    x_32_7    stock_ub_227  7
    x_32_7    parent_nonstrict_scope_228  1.6756661669495028e-02
    x_32_7    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_111  1
    w_32_7    product_ub_112  1
    w_32_7    normalized_mass_32_138  1
    w_32_7    normalized_ratio_32_139  -7.7777777777777768e-01
    w_32_7    full_original_Gini_286  -4.8412698412698418e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.3513323338990042e-02
    x_32_8    product_lb_113  -2.4887905662961264e-02
    x_32_8    product_ub_114  -4.1079812206613858e-02
    x_32_8    onehot_32_137  1
    x_32_8    stock_lb_226  8
    x_32_8    stock_ub_227  8
    x_32_8    parent_nonstrict_scope_228  8.3783308347475140e-03
    x_32_8    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_113  1
    w_32_8    product_ub_114  1
    w_32_8    normalized_mass_32_138  1
    w_32_8    normalized_ratio_32_139  -8.8888888888888884e-01
    w_32_8    full_original_Gini_286  -3.9904761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       -4.1891654173737553e-02
    x_32_9    product_lb_115  -2.4887905662961264e-02
    x_32_9    product_ub_116  -4.1079812206613858e-02
    x_32_9    onehot_32_137  1
    x_32_9    stock_lb_226  9
    x_32_9    stock_ub_227  9
    x_32_9    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_115  1
    w_32_9    product_ub_116  1
    w_32_9    normalized_mass_32_138  1
    w_32_9    normalized_ratio_32_139  -1
    w_32_9    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       -3.3513323338990042e-02
    x_32_10   product_lb_117  -2.4887905662961264e-02
    x_32_10   product_ub_118  -4.1079812206613858e-02
    x_32_10   onehot_32_137  1
    x_32_10   stock_lb_226  10
    x_32_10   stock_ub_227  10
    x_32_10   parent_nonstrict_scope_228  8.3783308347475140e-03
    x_32_10   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_117  1
    w_32_10   product_ub_118  1
    w_32_10   normalized_mass_32_138  1
    w_32_10   normalized_ratio_32_139  -1.1111111111111112e+00
    w_32_10   full_original_Gini_286  -6.4349206349206316e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       -2.5134992504242542e-02
    x_32_11   product_lb_119  -2.4887905662961264e-02
    x_32_11   product_ub_120  -4.1079812206613858e-02
    x_32_11   onehot_32_137  1
    x_32_11   stock_lb_226  11
    x_32_11   stock_ub_227  11
    x_32_11   parent_nonstrict_scope_228  1.6756661669495011e-02
    x_32_11   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_119  1
    w_32_11   product_ub_120  1
    w_32_11   normalized_mass_32_138  1
    w_32_11   normalized_ratio_32_139  -1.2222222222222221e+00
    w_32_11   full_original_Gini_286  -9.2126984126984119e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       -1.6756661669495028e-02
    x_32_12   product_lb_121  -2.4887905662961264e-02
    x_32_12   product_ub_122  -4.1079812206613858e-02
    x_32_12   onehot_32_137  1
    x_32_12   stock_lb_226  12
    x_32_12   stock_ub_227  12
    x_32_12   parent_nonstrict_scope_228  2.5134992504242525e-02
    x_32_12   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_121  1
    w_32_12   product_ub_122  1
    w_32_12   normalized_mass_32_138  1
    w_32_12   normalized_ratio_32_139  -1.3333333333333333e+00
    w_32_12   full_original_Gini_286  -1.1990476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_13   OBJ       -0.00837833083474751
    x_32_13   product_lb_123  -2.4887905662961264e-02
    x_32_13   product_ub_124  -4.1079812206613858e-02
    x_32_13   onehot_32_137  1
    x_32_13   stock_lb_226  13
    x_32_13   stock_ub_227  13
    x_32_13   parent_nonstrict_scope_228  3.3513323338990042e-02
    x_32_13   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_13   product_lb_123  1
    w_32_13   product_ub_124  1
    w_32_13   normalized_mass_32_138  1
    w_32_13   normalized_ratio_32_139  -1.4444444444444444e+00
    w_32_13   full_original_Gini_286  -1.4768253968253973e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_14   OBJ       -1.3877787807814457e-17
    x_32_14   product_lb_125  -2.4887905662961264e-02
    x_32_14   product_ub_126  -4.1079812206613858e-02
    x_32_14   onehot_32_137  1
    x_32_14   stock_lb_226  14
    x_32_14   stock_ub_227  14
    x_32_14   parent_nonstrict_scope_228  4.1891654173737539e-02
    x_32_14   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_14   product_lb_125  1
    w_32_14   product_ub_126  1
    w_32_14   normalized_mass_32_138  1
    w_32_14   normalized_ratio_32_139  -1.5555555555555554e+00
    w_32_14   full_original_Gini_286  -1.7657142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_15   OBJ       8.3783308347474966e-03
    x_32_15   product_lb_127  -2.4887905662961264e-02
    x_32_15   product_ub_128  -4.1079812206613858e-02
    x_32_15   onehot_32_137  1
    x_32_15   stock_lb_226  15
    x_32_15   stock_ub_227  15
    x_32_15   parent_nonstrict_scope_228  5.0269985008485049e-02
    x_32_15   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_15   product_lb_127  1
    w_32_15   product_ub_128  1
    w_32_15   normalized_mass_32_138  1
    w_32_15   normalized_ratio_32_139  -1.6666666666666665e+00
    w_32_15   full_original_Gini_286  -2.0657142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_16   OBJ       1.6756661669495014e-02
    x_32_16   product_lb_129  -2.4887905662961264e-02
    x_32_16   product_ub_130  -4.1079812206613858e-02
    x_32_16   onehot_32_137  1
    x_32_16   stock_lb_226  16
    x_32_16   stock_ub_227  16
    x_32_16   parent_nonstrict_scope_228  5.8648315843232567e-02
    x_32_16   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_16   product_lb_129  1
    w_32_16   product_ub_130  1
    w_32_16   normalized_mass_32_138  1
    w_32_16   normalized_ratio_32_139  -1.7777777777777777e+00
    w_32_16   full_original_Gini_286  -2.3657142857142865e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_17   OBJ       2.5134992504242532e-02
    x_32_17   product_lb_131  -2.4887905662961264e-02
    x_32_17   product_ub_132  -4.1079812206613858e-02
    x_32_17   onehot_32_137  1
    x_32_17   stock_lb_226  17
    x_32_17   stock_ub_227  17
    x_32_17   parent_nonstrict_scope_228  6.7026646677980084e-02
    x_32_17   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_17   product_lb_131  1
    w_32_17   product_ub_132  1
    w_32_17   normalized_mass_32_138  1
    w_32_17   normalized_ratio_32_139  -1.8888888888888888e+00
    w_32_17   full_original_Gini_286  -2.6657142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_18   OBJ       3.3513323338990042e-02
    x_32_18   product_lb_133  -2.4887905662961264e-02
    x_32_18   product_ub_134  -4.1079812206613858e-02
    x_32_18   onehot_32_137  1
    x_32_18   stock_lb_226  18
    x_32_18   stock_ub_227  18
    x_32_18   parent_nonstrict_scope_228  0.0754049775127276
    x_32_18   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_18   product_lb_133  1
    w_32_18   product_ub_134  1
    w_32_18   normalized_mass_32_138  1
    w_32_18   normalized_ratio_32_139  -2
    w_32_18   full_original_Gini_286  -2.9657142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_19   OBJ       4.1891654173737553e-02
    x_32_19   product_lb_135  -2.4887905662961264e-02
    x_32_19   product_ub_136  -4.1079812206613858e-02
    x_32_19   onehot_32_137  1
    x_32_19   stock_lb_226  19
    x_32_19   stock_ub_227  19
    x_32_19   parent_nonstrict_scope_228  0.0837833083474751
    x_32_19   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_19   product_lb_135  1
    w_32_19   product_ub_136  1
    w_32_19   normalized_mass_32_138  1
    w_32_19   normalized_ratio_32_139  -2.1111111111111112e+00
    w_32_19   full_original_Gini_286  -3.2657142857142858e+01
    rho_32    normalized_ratio_32_139  1
    rho_32    block_pair_pos_249  1
    rho_32    block_pair_neg_250  -1
    rho_32    block_pair_pos_253  -1
    rho_32    block_pair_neg_254  1
    rho_32    block_pair_pos_255  -1
    rho_32    block_pair_neg_256  1
    rho_32    block_pair_pos_257  -1
    rho_32    block_pair_neg_258  1
    rho_32    block_pair_pos_259  -1
    rho_32    block_pair_neg_260  1
    rho_32    block_pair_pos_271  1
    rho_32    block_pair_neg_272  -1
    rho_32    block_pair_pos_283  1
    rho_32    block_pair_neg_284  -1
    rho_32    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_140  -2.4887905662961264e-02
    x_27_0    product_ub_141  -4.1079812206613858e-02
    x_27_0    onehot_27_154  1
    x_27_0    parent_nonstrict_scope_228  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_140  1
    w_27_0    product_ub_141  1
    w_27_0    normalized_mass_27_155  1
    w_27_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_142  -2.4887905662961264e-02
    x_27_1    product_ub_143  -4.1079812206613858e-02
    x_27_1    onehot_27_154  1
    x_27_1    stock_lb_226  1
    x_27_1    stock_ub_227  1
    x_27_1    parent_nonstrict_scope_228  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_142  1
    w_27_1    product_ub_143  1
    w_27_1    normalized_mass_27_155  1
    w_27_1    normalized_ratio_27_156  -3.3333333333333331e-01
    w_27_1    full_original_Gini_286  -1.5342857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_144  -2.4887905662961264e-02
    x_27_2    product_ub_145  -4.1079812206613858e-02
    x_27_2    onehot_27_154  1
    x_27_2    stock_lb_226  2
    x_27_2    stock_ub_227  2
    x_27_2    parent_nonstrict_scope_228  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_144  1
    w_27_2    product_ub_145  1
    w_27_2    normalized_mass_27_155  1
    w_27_2    normalized_ratio_27_156  -6.6666666666666663e-01
    w_27_2    full_original_Gini_286  -6.8095238095238066e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_146  -2.4887905662961264e-02
    x_27_3    product_ub_147  -4.1079812206613858e-02
    x_27_3    onehot_27_154  1
    x_27_3    stock_lb_226  3
    x_27_3    stock_ub_227  3
    x_27_3    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_146  1
    w_27_3    product_ub_147  1
    w_27_3    normalized_mass_27_155  1
    w_27_3    normalized_ratio_27_156  -1
    w_27_3    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_148  -2.4887905662961264e-02
    x_27_4    product_ub_149  -4.1079812206613858e-02
    x_27_4    onehot_27_154  1
    x_27_4    stock_lb_226  4
    x_27_4    stock_ub_227  4
    x_27_4    parent_nonstrict_scope_228  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_148  1
    w_27_4    product_ub_149  1
    w_27_4    normalized_mass_27_155  1
    w_27_4    normalized_ratio_27_156  -1.3333333333333333e+00
    w_27_4    full_original_Gini_286  -1.1990476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_150  -2.4887905662961264e-02
    x_27_5    product_ub_151  -4.1079812206613858e-02
    x_27_5    onehot_27_154  1
    x_27_5    stock_lb_226  5
    x_27_5    stock_ub_227  5
    x_27_5    parent_nonstrict_scope_228  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_150  1
    w_27_5    product_ub_151  1
    w_27_5    normalized_mass_27_155  1
    w_27_5    normalized_ratio_27_156  -1.6666666666666665e+00
    w_27_5    full_original_Gini_286  -2.0657142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_152  -2.4887905662961264e-02
    x_27_6    product_ub_153  -4.1079812206613858e-02
    x_27_6    onehot_27_154  1
    x_27_6    stock_lb_226  6
    x_27_6    stock_ub_227  6
    x_27_6    parent_nonstrict_scope_228  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_152  1
    w_27_6    product_ub_153  1
    w_27_6    normalized_mass_27_155  1
    w_27_6    normalized_ratio_27_156  -2
    w_27_6    full_original_Gini_286  -2.9657142857142855e+01
    rho_27    normalized_ratio_27_156  1
    rho_27    block_pair_pos_235  -1
    rho_27    block_pair_neg_236  1
    rho_27    block_pair_pos_237  -1
    rho_27    block_pair_neg_238  1
    rho_27    block_pair_pos_239  -1
    rho_27    block_pair_neg_240  1
    rho_27    block_pair_pos_247  1
    rho_27    block_pair_neg_248  -1
    rho_27    block_pair_pos_259  1
    rho_27    block_pair_neg_260  -1
    rho_27    block_pair_pos_267  1
    rho_27    block_pair_neg_268  -1
    rho_27    block_pair_pos_281  1
    rho_27    block_pair_neg_282  -1
    rho_27    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_25_0    OBJ       3.7702488756363797e-03
    x_25_0    product_lb_157  -2.4887905662961264e-02
    x_25_0    product_ub_158  -4.1079812206613858e-02
    x_25_0    onehot_25_167  1
    x_25_0    parent_nonstrict_scope_228  7.5404977512727595e-03
    MARKER    'MARKER'                 'INTEND'
    w_25_0    product_lb_157  1
    w_25_0    product_ub_158  1
    w_25_0    normalized_mass_25_168  1
    w_25_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_1    product_lb_159  -2.4887905662961264e-02
    x_25_1    product_ub_160  -4.1079812206613858e-02
    x_25_1    onehot_25_167  1
    x_25_1    stock_lb_226  1
    x_25_1    stock_ub_227  1
    x_25_1    parent_nonstrict_scope_228  3.7702488756363797e-03
    x_25_1    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_1    product_lb_159  1
    w_25_1    product_ub_160  1
    w_25_1    normalized_mass_25_168  1
    w_25_1    normalized_ratio_25_169  -0.5
    w_25_1    full_original_Gini_286  -1.0842857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_2    OBJ       -3.7702488756363797e-03
    x_25_2    product_lb_161  -2.4887905662961264e-02
    x_25_2    product_ub_162  -4.1079812206613858e-02
    x_25_2    onehot_25_167  1
    x_25_2    stock_lb_226  2
    x_25_2    stock_ub_227  2
    x_25_2    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_2    product_lb_161  1
    w_25_2    product_ub_162  1
    w_25_2    normalized_mass_25_168  1
    w_25_2    normalized_ratio_25_169  -1
    w_25_2    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_3    product_lb_163  -2.4887905662961264e-02
    x_25_3    product_ub_164  -4.1079812206613858e-02
    x_25_3    onehot_25_167  1
    x_25_3    stock_lb_226  3
    x_25_3    stock_ub_227  3
    x_25_3    parent_nonstrict_scope_228  3.7702488756363797e-03
    x_25_3    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_3    product_lb_163  1
    w_25_3    product_ub_164  1
    w_25_3    normalized_mass_25_168  1
    w_25_3    normalized_ratio_25_169  -1.5
    w_25_3    full_original_Gini_286  -1.6157142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_4    OBJ       3.7702488756363797e-03
    x_25_4    product_lb_165  -2.4887905662961264e-02
    x_25_4    product_ub_166  -4.1079812206613858e-02
    x_25_4    onehot_25_167  1
    x_25_4    stock_lb_226  4
    x_25_4    stock_ub_227  4
    x_25_4    parent_nonstrict_scope_228  7.5404977512727595e-03
    x_25_4    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_4    product_lb_165  1
    w_25_4    product_ub_166  1
    w_25_4    normalized_mass_25_168  1
    w_25_4    normalized_ratio_25_169  -2
    w_25_4    full_original_Gini_286  -2.9657142857142855e+01
    rho_25    normalized_ratio_25_169  1
    rho_25    block_pair_pos_231  -1
    rho_25    block_pair_neg_232  1
    rho_25    block_pair_pos_233  -1
    rho_25    block_pair_neg_234  1
    rho_25    block_pair_pos_237  1
    rho_25    block_pair_neg_238  -1
    rho_25    block_pair_pos_243  1
    rho_25    block_pair_neg_244  -1
    rho_25    block_pair_pos_255  1
    rho_25    block_pair_neg_256  -1
    rho_25    block_pair_pos_263  1
    rho_25    block_pair_neg_264  -1
    rho_25    block_pair_pos_277  1
    rho_25    block_pair_neg_278  -1
    rho_25    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_170  -2.4887905662961264e-02
    x_22_0    product_ub_171  -4.1079812206613858e-02
    x_22_0    onehot_22_202  1
    x_22_0    parent_nonstrict_scope_228  0.0456153362865944
    x_22_0    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_170  1
    w_22_0    product_ub_171  1
    w_22_0    normalized_mass_22_203  1
    w_22_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_172  -2.4887905662961264e-02
    x_22_1    product_ub_173  -4.1079812206613858e-02
    x_22_1    onehot_22_202  1
    x_22_1    stock_lb_226  1
    x_22_1    stock_ub_227  1
    x_22_1    parent_nonstrict_scope_228  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_172  1
    w_22_1    product_ub_173  1
    w_22_1    normalized_mass_22_203  1
    w_22_1    normalized_ratio_22_204  -1.4285714285714285e-01
    w_22_1    full_original_Gini_286  -2.0485714285714288e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_174  -2.4887905662961264e-02
    x_22_2    product_ub_175  -4.1079812206613858e-02
    x_22_2    onehot_22_202  1
    x_22_2    stock_lb_226  2
    x_22_2    stock_ub_227  2
    x_22_2    parent_nonstrict_scope_228  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_174  1
    w_22_2    product_ub_175  1
    w_22_2    normalized_mass_22_203  1
    w_22_2    normalized_ratio_22_204  -2.8571428571428570e-01
    w_22_2    full_original_Gini_286  -1.6628571428571423e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_176  -2.4887905662961264e-02
    x_22_3    product_ub_177  -4.1079812206613858e-02
    x_22_3    onehot_22_202  1
    x_22_3    stock_lb_226  3
    x_22_3    stock_ub_227  3
    x_22_3    parent_nonstrict_scope_228  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_176  1
    w_22_3    product_ub_177  1
    w_22_3    normalized_mass_22_203  1
    w_22_3    normalized_ratio_22_204  -4.2857142857142855e-01
    w_22_3    full_original_Gini_286  -1.2771428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_178  -2.4887905662961264e-02
    x_22_4    product_ub_179  -4.1079812206613858e-02
    x_22_4    onehot_22_202  1
    x_22_4    stock_lb_226  4
    x_22_4    stock_ub_227  4
    x_22_4    parent_nonstrict_scope_228  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_178  1
    w_22_4    product_ub_179  1
    w_22_4    normalized_mass_22_203  1
    w_22_4    normalized_ratio_22_204  -5.7142857142857140e-01
    w_22_4    full_original_Gini_286  -9.0571428571428587e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_180  -2.4887905662961264e-02
    x_22_5    product_ub_181  -4.1079812206613858e-02
    x_22_5    onehot_22_202  1
    x_22_5    stock_lb_226  5
    x_22_5    stock_ub_227  5
    x_22_5    parent_nonstrict_scope_228  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_180  1
    w_22_5    product_ub_181  1
    w_22_5    normalized_mass_22_203  1
    w_22_5    normalized_ratio_22_204  -7.1428571428571419e-01
    w_22_5    full_original_Gini_286  -5.8095238095238084e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_182  -2.4887905662961264e-02
    x_22_6    product_ub_183  -4.1079812206613858e-02
    x_22_6    onehot_22_202  1
    x_22_6    stock_lb_226  6
    x_22_6    stock_ub_227  6
    x_22_6    parent_nonstrict_scope_228  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_182  1
    w_22_6    product_ub_183  1
    w_22_6    normalized_mass_22_203  1
    w_22_6    normalized_ratio_22_204  -8.5714285714285710e-01
    w_22_6    full_original_Gini_286  -4.0857142857142845e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_184  -2.4887905662961264e-02
    x_22_7    product_ub_185  -4.1079812206613858e-02
    x_22_7    onehot_22_202  1
    x_22_7    stock_lb_226  7
    x_22_7    stock_ub_227  7
    x_22_7    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_184  1
    w_22_7    product_ub_185  1
    w_22_7    normalized_mass_22_203  1
    w_22_7    normalized_ratio_22_204  -1
    w_22_7    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_186  -2.4887905662961264e-02
    x_22_8    product_ub_187  -4.1079812206613858e-02
    x_22_8    onehot_22_202  1
    x_22_8    stock_lb_226  8
    x_22_8    stock_ub_227  8
    x_22_8    parent_nonstrict_scope_228  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_186  1
    w_22_8    product_ub_187  1
    w_22_8    normalized_mass_22_203  1
    w_22_8    normalized_ratio_22_204  -1.1428571428571428e+00
    w_22_8    full_original_Gini_286  -7.2285714285714224e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_188  -2.4887905662961264e-02
    x_22_9    product_ub_189  -4.1079812206613858e-02
    x_22_9    onehot_22_202  1
    x_22_9    stock_lb_226  9
    x_22_9    stock_ub_227  9
    x_22_9    parent_nonstrict_scope_228  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_188  1
    w_22_9    product_ub_189  1
    w_22_9    normalized_mass_22_203  1
    w_22_9    normalized_ratio_22_204  -1.2857142857142856e+00
    w_22_9    full_original_Gini_286  -1.0799999999999994e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_190  -2.4887905662961264e-02
    x_22_10   product_ub_191  -4.1079812206613858e-02
    x_22_10   onehot_22_202  1
    x_22_10   stock_lb_226  10
    x_22_10   stock_ub_227  10
    x_22_10   parent_nonstrict_scope_228  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_190  1
    w_22_10   product_ub_191  1
    w_22_10   normalized_mass_22_203  1
    w_22_10   normalized_ratio_22_204  -1.4285714285714284e+00
    w_22_10   full_original_Gini_286  -1.4371428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_192  -2.4887905662961264e-02
    x_22_11   product_ub_193  -4.1079812206613858e-02
    x_22_11   onehot_22_202  1
    x_22_11   stock_lb_226  11
    x_22_11   stock_ub_227  11
    x_22_11   parent_nonstrict_scope_228  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_192  1
    w_22_11   product_ub_193  1
    w_22_11   normalized_mass_22_203  1
    w_22_11   normalized_ratio_22_204  -1.5714285714285714e+00
    w_22_11   full_original_Gini_286  -1.8085714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_194  -2.4887905662961264e-02
    x_22_12   product_ub_195  -4.1079812206613858e-02
    x_22_12   onehot_22_202  1
    x_22_12   stock_lb_226  12
    x_22_12   stock_ub_227  12
    x_22_12   parent_nonstrict_scope_228  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_194  1
    w_22_12   product_ub_195  1
    w_22_12   normalized_mass_22_203  1
    w_22_12   normalized_ratio_22_204  -1.7142857142857142e+00
    w_22_12   full_original_Gini_286  -2.1942857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_196  -2.4887905662961264e-02
    x_22_13   product_ub_197  -4.1079812206613858e-02
    x_22_13   onehot_22_202  1
    x_22_13   stock_lb_226  13
    x_22_13   stock_ub_227  13
    x_22_13   parent_nonstrict_scope_228  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_196  1
    w_22_13   product_ub_197  1
    w_22_13   normalized_mass_22_203  1
    w_22_13   normalized_ratio_22_204  -1.8571428571428570e+00
    w_22_13   full_original_Gini_286  -25.8
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_198  -2.4887905662961264e-02
    x_22_14   product_ub_199  -4.1079812206613858e-02
    x_22_14   onehot_22_202  1
    x_22_14   stock_lb_226  14
    x_22_14   stock_ub_227  14
    x_22_14   parent_nonstrict_scope_228  0.0456153362865944
    x_22_14   unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_198  1
    w_22_14   product_ub_199  1
    w_22_14   normalized_mass_22_203  1
    w_22_14   normalized_ratio_22_204  -2
    w_22_14   full_original_Gini_286  -2.9657142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_200  -2.4887905662961264e-02
    x_22_15   product_ub_201  -4.1079812206613858e-02
    x_22_15   onehot_22_202  1
    x_22_15   stock_lb_226  15
    x_22_15   stock_ub_227  15
    x_22_15   parent_nonstrict_scope_228  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_200  1
    w_22_15   product_ub_201  1
    w_22_15   normalized_mass_22_203  1
    w_22_15   normalized_ratio_22_204  -2.1428571428571428e+00
    w_22_15   full_original_Gini_286  -3.3514285714285720e+01
    rho_22    normalized_ratio_22_204  1
    rho_22    block_pair_pos_229  -1
    rho_22    block_pair_neg_230  1
    rho_22    block_pair_pos_231  1
    rho_22    block_pair_neg_232  -1
    rho_22    block_pair_pos_235  1
    rho_22    block_pair_neg_236  -1
    rho_22    block_pair_pos_241  1
    rho_22    block_pair_neg_242  -1
    rho_22    block_pair_pos_253  1
    rho_22    block_pair_neg_254  -1
    rho_22    block_pair_pos_261  1
    rho_22    block_pair_neg_262  -1
    rho_22    block_pair_pos_275  1
    rho_22    block_pair_neg_276  -1
    rho_22    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       7.4474103065332977e-03
    x_26_0    product_lb_205  -2.4887905662961264e-02
    x_26_0    product_ub_206  -4.1079812206613858e-02
    x_26_0    onehot_26_223  1
    x_26_0    parent_nonstrict_scope_228  1.4894820613066595e-02
    x_26_0    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_205  1
    w_26_0    product_ub_206  1
    w_26_0    normalized_mass_26_224  1
    w_26_0    full_original_Gini_286  -2.4342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       3.7237051532666493e-03
    x_26_1    product_lb_207  -2.4887905662961264e-02
    x_26_1    product_ub_208  -4.1079812206613858e-02
    x_26_1    onehot_26_223  1
    x_26_1    stock_lb_226  1
    x_26_1    stock_ub_227  1
    x_26_1    parent_nonstrict_scope_228  1.1171115459799947e-02
    x_26_1    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_207  1
    w_26_1    product_ub_208  1
    w_26_1    normalized_mass_26_224  1
    w_26_1    normalized_ratio_26_225  -0.25
    w_26_1    full_original_Gini_286  -1.7592857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_209  -2.4887905662961264e-02
    x_26_2    product_ub_210  -4.1079812206613858e-02
    x_26_2    onehot_26_223  1
    x_26_2    stock_lb_226  2
    x_26_2    stock_ub_227  2
    x_26_2    parent_nonstrict_scope_228  7.4474103065332977e-03
    x_26_2    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_209  1
    w_26_2    product_ub_210  1
    w_26_2    normalized_mass_26_224  1
    w_26_2    normalized_ratio_26_225  -0.5
    w_26_2    full_original_Gini_286  -1.0842857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -3.7237051532666488e-03
    x_26_3    product_lb_211  -2.4887905662961264e-02
    x_26_3    product_ub_212  -4.1079812206613858e-02
    x_26_3    onehot_26_223  1
    x_26_3    stock_lb_226  3
    x_26_3    stock_ub_227  3
    x_26_3    parent_nonstrict_scope_228  3.7237051532666488e-03
    x_26_3    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_211  1
    w_26_3    product_ub_212  1
    w_26_3    normalized_mass_26_224  1
    w_26_3    normalized_ratio_26_225  -0.75
    w_26_3    full_original_Gini_286  -5.2023809523809526e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -7.4474103065332977e-03
    x_26_4    product_lb_213  -2.4887905662961264e-02
    x_26_4    product_ub_214  -4.1079812206613858e-02
    x_26_4    onehot_26_223  1
    x_26_4    stock_lb_226  4
    x_26_4    stock_ub_227  4
    x_26_4    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_213  1
    w_26_4    product_ub_214  1
    w_26_4    normalized_mass_26_224  1
    w_26_4    normalized_ratio_26_225  -1
    w_26_4    full_original_Gini_286  -3.6571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -3.7237051532666488e-03
    x_26_5    product_lb_215  -2.4887905662961264e-02
    x_26_5    product_ub_216  -4.1079812206613858e-02
    x_26_5    onehot_26_223  1
    x_26_5    stock_lb_226  5
    x_26_5    stock_ub_227  5
    x_26_5    parent_nonstrict_scope_228  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_215  1
    w_26_5    product_ub_216  1
    w_26_5    normalized_mass_26_224  1
    w_26_5    normalized_ratio_26_225  -1.25
    w_26_5    full_original_Gini_286  -9.9071428571428584e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_217  -2.4887905662961264e-02
    x_26_6    product_ub_218  -4.1079812206613858e-02
    x_26_6    onehot_26_223  1
    x_26_6    stock_lb_226  6
    x_26_6    stock_ub_227  6
    x_26_6    parent_nonstrict_scope_228  7.4474103065332977e-03
    x_26_6    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_217  1
    w_26_6    product_ub_218  1
    w_26_6    normalized_mass_26_224  1
    w_26_6    normalized_ratio_26_225  -1.5
    w_26_6    full_original_Gini_286  -1.6157142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       3.7237051532666493e-03
    x_26_7    product_lb_219  -2.4887905662961264e-02
    x_26_7    product_ub_220  -4.1079812206613858e-02
    x_26_7    onehot_26_223  1
    x_26_7    stock_lb_226  7
    x_26_7    stock_ub_227  7
    x_26_7    parent_nonstrict_scope_228  1.1171115459799947e-02
    x_26_7    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_219  1
    w_26_7    product_ub_220  1
    w_26_7    normalized_mass_26_224  1
    w_26_7    normalized_ratio_26_225  -1.75
    w_26_7    full_original_Gini_286  -2.2907142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       7.4474103065332977e-03
    x_26_8    product_lb_221  -2.4887905662961264e-02
    x_26_8    product_ub_222  -4.1079812206613858e-02
    x_26_8    onehot_26_223  1
    x_26_8    stock_lb_226  8
    x_26_8    stock_ub_227  8
    x_26_8    parent_nonstrict_scope_228  1.4894820613066595e-02
    x_26_8    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_221  1
    w_26_8    product_ub_222  1
    w_26_8    normalized_mass_26_224  1
    w_26_8    normalized_ratio_26_225  -2
    w_26_8    full_original_Gini_286  -2.9657142857142855e+01
    rho_26    normalized_ratio_26_225  1
    rho_26    block_pair_pos_229  1
    rho_26    block_pair_neg_230  -1
    rho_26    block_pair_pos_233  1
    rho_26    block_pair_neg_234  -1
    rho_26    block_pair_pos_239  1
    rho_26    block_pair_neg_240  -1
    rho_26    block_pair_pos_245  1
    rho_26    block_pair_neg_246  -1
    rho_26    block_pair_pos_257  1
    rho_26    block_pair_neg_258  -1
    rho_26    block_pair_pos_265  1
    rho_26    block_pair_neg_266  -1
    rho_26    block_pair_pos_279  1
    rho_26    block_pair_neg_280  -1
    rho_26    normalization_285  1
    a_34_31   block_pair_pos_269  1
    a_34_31   block_pair_neg_270  1
    a_34_31   full_original_Gini_286  -1
    a_34_35   block_pair_pos_273  1
    a_34_35   block_pair_neg_274  1
    a_34_35   full_original_Gini_286  -1
    a_34_32   block_pair_pos_271  1
    a_34_32   block_pair_neg_272  1
    a_34_32   full_original_Gini_286  -1
    a_34_27   block_pair_pos_267  1
    a_34_27   block_pair_neg_268  1
    a_34_27   full_original_Gini_286  -1
    a_34_25   block_pair_pos_263  1
    a_34_25   block_pair_neg_264  1
    a_34_25   full_original_Gini_286  -1
    a_34_22   block_pair_pos_261  1
    a_34_22   block_pair_neg_262  1
    a_34_22   full_original_Gini_286  -1
    a_34_26   block_pair_pos_265  1
    a_34_26   block_pair_neg_266  1
    a_34_26   full_original_Gini_286  -1
    a_31_35   block_pair_pos_251  1
    a_31_35   block_pair_neg_252  1
    a_31_35   full_original_Gini_286  -1
    a_31_32   block_pair_pos_249  1
    a_31_32   block_pair_neg_250  1
    a_31_32   full_original_Gini_286  -1
    a_31_27   block_pair_pos_247  1
    a_31_27   block_pair_neg_248  1
    a_31_27   full_original_Gini_286  -1
    a_31_25   block_pair_pos_243  1
    a_31_25   block_pair_neg_244  1
    a_31_25   full_original_Gini_286  -1
    a_31_22   block_pair_pos_241  1
    a_31_22   block_pair_neg_242  1
    a_31_22   full_original_Gini_286  -1
    a_31_26   block_pair_pos_245  1
    a_31_26   block_pair_neg_246  1
    a_31_26   full_original_Gini_286  -1
    a_35_32   block_pair_pos_283  1
    a_35_32   block_pair_neg_284  1
    a_35_32   full_original_Gini_286  -1
    a_35_27   block_pair_pos_281  1
    a_35_27   block_pair_neg_282  1
    a_35_27   full_original_Gini_286  -1
    a_35_25   block_pair_pos_277  1
    a_35_25   block_pair_neg_278  1
    a_35_25   full_original_Gini_286  -1
    a_35_22   block_pair_pos_275  1
    a_35_22   block_pair_neg_276  1
    a_35_22   full_original_Gini_286  -1
    a_35_26   block_pair_pos_279  1
    a_35_26   block_pair_neg_280  1
    a_35_26   full_original_Gini_286  -1
    a_32_27   block_pair_pos_259  1
    a_32_27   block_pair_neg_260  1
    a_32_27   full_original_Gini_286  -1
    a_32_25   block_pair_pos_255  1
    a_32_25   block_pair_neg_256  1
    a_32_25   full_original_Gini_286  -1
    a_32_22   block_pair_pos_253  1
    a_32_22   block_pair_neg_254  1
    a_32_22   full_original_Gini_286  -1
    a_32_26   block_pair_pos_257  1
    a_32_26   block_pair_neg_258  1
    a_32_26   full_original_Gini_286  -1
    a_27_25   block_pair_pos_237  1
    a_27_25   block_pair_neg_238  1
    a_27_25   full_original_Gini_286  -1
    a_27_22   block_pair_pos_235  1
    a_27_22   block_pair_neg_236  1
    a_27_22   full_original_Gini_286  -1
    a_27_26   block_pair_pos_239  1
    a_27_26   block_pair_neg_240  1
    a_27_26   full_original_Gini_286  -1
    a_25_22   block_pair_pos_231  1
    a_25_22   block_pair_neg_232  1
    a_25_22   full_original_Gini_286  -1
    a_25_26   block_pair_pos_233  1
    a_25_26   block_pair_neg_234  1
    a_25_26   full_original_Gini_286  -1
    a_22_26   block_pair_pos_229  1
    a_22_26   block_pair_neg_230  1
    a_22_26   full_original_Gini_286  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_34_0  unique_nonzero_owner_287  1
    service_0_34_0  service_visit_def_703  1
    service_0_34_0  free_load_conservation_704  -2
    service_0_34_0  original_T_including_depot_unload_750  240
    service_0_34_1  unique_nonzero_owner_288  1
    service_0_34_1  service_visit_def_703  1
    service_0_34_1  free_load_conservation_704  -1
    service_0_34_1  original_T_including_depot_unload_750  120
    service_0_34_3  unique_nonzero_owner_289  1
    service_0_34_3  service_visit_def_703  1
    service_0_34_3  free_load_conservation_704  1
    service_0_34_4  unique_nonzero_owner_290  1
    service_0_34_4  service_visit_def_703  1
    service_0_34_4  free_load_conservation_704  2
    service_0_34_5  unique_nonzero_owner_291  1
    service_0_34_5  service_visit_def_703  1
    service_0_34_5  free_load_conservation_704  3
    service_0_34_6  unique_nonzero_owner_292  1
    service_0_34_6  service_visit_def_703  1
    service_0_34_6  free_load_conservation_704  4
    service_0_34_7  unique_nonzero_owner_293  1
    service_0_34_7  service_visit_def_703  1
    service_0_34_7  free_load_conservation_704  5
    service_0_34_8  unique_nonzero_owner_294  1
    service_0_34_8  service_visit_def_703  1
    service_0_34_8  free_load_conservation_704  6
    service_0_34_9  unique_nonzero_owner_295  1
    service_0_34_9  service_visit_def_703  1
    service_0_34_9  free_load_conservation_704  7
    service_0_34_10  unique_nonzero_owner_296  1
    service_0_34_10  service_visit_def_703  1
    service_0_34_10  free_load_conservation_704  8
    service_0_34_11  unique_nonzero_owner_297  1
    service_0_34_11  service_visit_def_703  1
    service_0_34_11  free_load_conservation_704  9
    service_0_34_12  unique_nonzero_owner_298  1
    service_0_34_12  service_visit_def_703  1
    service_0_34_12  free_load_conservation_704  10
    service_0_34_13  unique_nonzero_owner_299  1
    service_0_34_13  service_visit_def_703  1
    service_0_34_13  free_load_conservation_704  11
    service_0_34_14  unique_nonzero_owner_300  1
    service_0_34_14  service_visit_def_703  1
    service_0_34_14  free_load_conservation_704  12
    service_0_34_15  unique_nonzero_owner_301  1
    service_0_34_15  service_visit_def_703  1
    service_0_34_15  free_load_conservation_704  13
    service_1_34_0  unique_nonzero_owner_287  1
    service_1_34_0  service_visit_def_1074  1
    service_1_34_0  free_load_conservation_1075  -2
    service_1_34_0  original_T_including_depot_unload_1121  240
    service_1_34_1  unique_nonzero_owner_288  1
    service_1_34_1  service_visit_def_1074  1
    service_1_34_1  free_load_conservation_1075  -1
    service_1_34_1  original_T_including_depot_unload_1121  120
    service_1_34_3  unique_nonzero_owner_289  1
    service_1_34_3  service_visit_def_1074  1
    service_1_34_3  free_load_conservation_1075  1
    service_1_34_4  unique_nonzero_owner_290  1
    service_1_34_4  service_visit_def_1074  1
    service_1_34_4  free_load_conservation_1075  2
    service_1_34_5  unique_nonzero_owner_291  1
    service_1_34_5  service_visit_def_1074  1
    service_1_34_5  free_load_conservation_1075  3
    service_1_34_6  unique_nonzero_owner_292  1
    service_1_34_6  service_visit_def_1074  1
    service_1_34_6  free_load_conservation_1075  4
    service_1_34_7  unique_nonzero_owner_293  1
    service_1_34_7  service_visit_def_1074  1
    service_1_34_7  free_load_conservation_1075  5
    service_1_34_8  unique_nonzero_owner_294  1
    service_1_34_8  service_visit_def_1074  1
    service_1_34_8  free_load_conservation_1075  6
    service_1_34_9  unique_nonzero_owner_295  1
    service_1_34_9  service_visit_def_1074  1
    service_1_34_9  free_load_conservation_1075  7
    service_1_34_10  unique_nonzero_owner_296  1
    service_1_34_10  service_visit_def_1074  1
    service_1_34_10  free_load_conservation_1075  8
    service_1_34_11  unique_nonzero_owner_297  1
    service_1_34_11  service_visit_def_1074  1
    service_1_34_11  free_load_conservation_1075  9
    service_1_34_12  unique_nonzero_owner_298  1
    service_1_34_12  service_visit_def_1074  1
    service_1_34_12  free_load_conservation_1075  10
    service_1_34_13  unique_nonzero_owner_299  1
    service_1_34_13  service_visit_def_1074  1
    service_1_34_13  free_load_conservation_1075  11
    service_1_34_14  unique_nonzero_owner_300  1
    service_1_34_14  service_visit_def_1074  1
    service_1_34_14  free_load_conservation_1075  12
    service_1_34_15  unique_nonzero_owner_301  1
    service_1_34_15  service_visit_def_1074  1
    service_1_34_15  free_load_conservation_1075  13
    service_2_34_0  unique_nonzero_owner_287  1
    service_2_34_0  service_visit_def_1392  1
    service_2_34_0  free_load_conservation_1393  -2
    service_2_34_0  original_T_including_depot_unload_1438  240
    service_2_34_1  unique_nonzero_owner_288  1
    service_2_34_1  service_visit_def_1392  1
    service_2_34_1  free_load_conservation_1393  -1
    service_2_34_1  original_T_including_depot_unload_1438  120
    service_2_34_3  unique_nonzero_owner_289  1
    service_2_34_3  service_visit_def_1392  1
    service_2_34_3  free_load_conservation_1393  1
    service_2_34_4  unique_nonzero_owner_290  1
    service_2_34_4  service_visit_def_1392  1
    service_2_34_4  free_load_conservation_1393  2
    service_2_34_5  unique_nonzero_owner_291  1
    service_2_34_5  service_visit_def_1392  1
    service_2_34_5  free_load_conservation_1393  3
    service_2_34_6  unique_nonzero_owner_292  1
    service_2_34_6  service_visit_def_1392  1
    service_2_34_6  free_load_conservation_1393  4
    service_2_34_7  unique_nonzero_owner_293  1
    service_2_34_7  service_visit_def_1392  1
    service_2_34_7  free_load_conservation_1393  5
    service_2_34_8  unique_nonzero_owner_294  1
    service_2_34_8  service_visit_def_1392  1
    service_2_34_8  free_load_conservation_1393  6
    service_2_34_9  unique_nonzero_owner_295  1
    service_2_34_9  service_visit_def_1392  1
    service_2_34_9  free_load_conservation_1393  7
    service_2_34_10  unique_nonzero_owner_296  1
    service_2_34_10  service_visit_def_1392  1
    service_2_34_10  free_load_conservation_1393  8
    service_2_34_11  unique_nonzero_owner_297  1
    service_2_34_11  service_visit_def_1392  1
    service_2_34_11  free_load_conservation_1393  9
    service_2_34_12  unique_nonzero_owner_298  1
    service_2_34_12  service_visit_def_1392  1
    service_2_34_12  free_load_conservation_1393  10
    service_2_34_13  unique_nonzero_owner_299  1
    service_2_34_13  service_visit_def_1392  1
    service_2_34_13  free_load_conservation_1393  11
    service_2_34_14  unique_nonzero_owner_300  1
    service_2_34_14  service_visit_def_1392  1
    service_2_34_14  free_load_conservation_1393  12
    service_2_34_15  unique_nonzero_owner_301  1
    service_2_34_15  service_visit_def_1392  1
    service_2_34_15  free_load_conservation_1393  13
    service_0_31_0  unique_nonzero_owner_302  1
    service_0_31_0  service_visit_def_709  1
    service_0_31_0  free_load_conservation_710  -8
    service_0_31_0  original_T_including_depot_unload_750  960
    service_0_31_1  unique_nonzero_owner_303  1
    service_0_31_1  service_visit_def_709  1
    service_0_31_1  free_load_conservation_710  -7
    service_0_31_1  original_T_including_depot_unload_750  840
    service_0_31_2  unique_nonzero_owner_304  1
    service_0_31_2  service_visit_def_709  1
    service_0_31_2  free_load_conservation_710  -6
    service_0_31_2  original_T_including_depot_unload_750  720
    service_0_31_3  unique_nonzero_owner_305  1
    service_0_31_3  service_visit_def_709  1
    service_0_31_3  free_load_conservation_710  -5
    service_0_31_3  original_T_including_depot_unload_750  600
    service_0_31_4  unique_nonzero_owner_306  1
    service_0_31_4  service_visit_def_709  1
    service_0_31_4  free_load_conservation_710  -4
    service_0_31_4  original_T_including_depot_unload_750  480
    service_0_31_5  unique_nonzero_owner_307  1
    service_0_31_5  service_visit_def_709  1
    service_0_31_5  free_load_conservation_710  -3
    service_0_31_5  original_T_including_depot_unload_750  360
    service_0_31_6  unique_nonzero_owner_308  1
    service_0_31_6  service_visit_def_709  1
    service_0_31_6  free_load_conservation_710  -2
    service_0_31_6  original_T_including_depot_unload_750  240
    service_0_31_7  unique_nonzero_owner_309  1
    service_0_31_7  service_visit_def_709  1
    service_0_31_7  free_load_conservation_710  -1
    service_0_31_7  original_T_including_depot_unload_750  120
    service_0_31_9  unique_nonzero_owner_310  1
    service_0_31_9  service_visit_def_709  1
    service_0_31_9  free_load_conservation_710  1
    service_0_31_10  unique_nonzero_owner_311  1
    service_0_31_10  service_visit_def_709  1
    service_0_31_10  free_load_conservation_710  2
    service_0_31_11  unique_nonzero_owner_312  1
    service_0_31_11  service_visit_def_709  1
    service_0_31_11  free_load_conservation_710  3
    service_1_31_0  unique_nonzero_owner_302  1
    service_1_31_0  service_visit_def_1080  1
    service_1_31_0  free_load_conservation_1081  -8
    service_1_31_0  original_T_including_depot_unload_1121  960
    service_1_31_1  unique_nonzero_owner_303  1
    service_1_31_1  service_visit_def_1080  1
    service_1_31_1  free_load_conservation_1081  -7
    service_1_31_1  original_T_including_depot_unload_1121  840
    service_1_31_2  unique_nonzero_owner_304  1
    service_1_31_2  service_visit_def_1080  1
    service_1_31_2  free_load_conservation_1081  -6
    service_1_31_2  original_T_including_depot_unload_1121  720
    service_1_31_3  unique_nonzero_owner_305  1
    service_1_31_3  service_visit_def_1080  1
    service_1_31_3  free_load_conservation_1081  -5
    service_1_31_3  original_T_including_depot_unload_1121  600
    service_1_31_4  unique_nonzero_owner_306  1
    service_1_31_4  service_visit_def_1080  1
    service_1_31_4  free_load_conservation_1081  -4
    service_1_31_4  original_T_including_depot_unload_1121  480
    service_1_31_5  unique_nonzero_owner_307  1
    service_1_31_5  service_visit_def_1080  1
    service_1_31_5  free_load_conservation_1081  -3
    service_1_31_5  original_T_including_depot_unload_1121  360
    service_1_31_6  unique_nonzero_owner_308  1
    service_1_31_6  service_visit_def_1080  1
    service_1_31_6  free_load_conservation_1081  -2
    service_1_31_6  original_T_including_depot_unload_1121  240
    service_1_31_7  unique_nonzero_owner_309  1
    service_1_31_7  service_visit_def_1080  1
    service_1_31_7  free_load_conservation_1081  -1
    service_1_31_7  original_T_including_depot_unload_1121  120
    service_1_31_9  unique_nonzero_owner_310  1
    service_1_31_9  service_visit_def_1080  1
    service_1_31_9  free_load_conservation_1081  1
    service_1_31_10  unique_nonzero_owner_311  1
    service_1_31_10  service_visit_def_1080  1
    service_1_31_10  free_load_conservation_1081  2
    service_1_31_11  unique_nonzero_owner_312  1
    service_1_31_11  service_visit_def_1080  1
    service_1_31_11  free_load_conservation_1081  3
    service_2_31_0  unique_nonzero_owner_302  1
    service_2_31_0  service_visit_def_1398  1
    service_2_31_0  free_load_conservation_1399  -8
    service_2_31_0  original_T_including_depot_unload_1438  960
    service_2_31_1  unique_nonzero_owner_303  1
    service_2_31_1  service_visit_def_1398  1
    service_2_31_1  free_load_conservation_1399  -7
    service_2_31_1  original_T_including_depot_unload_1438  840
    service_2_31_2  unique_nonzero_owner_304  1
    service_2_31_2  service_visit_def_1398  1
    service_2_31_2  free_load_conservation_1399  -6
    service_2_31_2  original_T_including_depot_unload_1438  720
    service_2_31_3  unique_nonzero_owner_305  1
    service_2_31_3  service_visit_def_1398  1
    service_2_31_3  free_load_conservation_1399  -5
    service_2_31_3  original_T_including_depot_unload_1438  600
    service_2_31_4  unique_nonzero_owner_306  1
    service_2_31_4  service_visit_def_1398  1
    service_2_31_4  free_load_conservation_1399  -4
    service_2_31_4  original_T_including_depot_unload_1438  480
    service_2_31_5  unique_nonzero_owner_307  1
    service_2_31_5  service_visit_def_1398  1
    service_2_31_5  free_load_conservation_1399  -3
    service_2_31_5  original_T_including_depot_unload_1438  360
    service_2_31_6  unique_nonzero_owner_308  1
    service_2_31_6  service_visit_def_1398  1
    service_2_31_6  free_load_conservation_1399  -2
    service_2_31_6  original_T_including_depot_unload_1438  240
    service_2_31_7  unique_nonzero_owner_309  1
    service_2_31_7  service_visit_def_1398  1
    service_2_31_7  free_load_conservation_1399  -1
    service_2_31_7  original_T_including_depot_unload_1438  120
    service_2_31_9  unique_nonzero_owner_310  1
    service_2_31_9  service_visit_def_1398  1
    service_2_31_9  free_load_conservation_1399  1
    service_2_31_10  unique_nonzero_owner_311  1
    service_2_31_10  service_visit_def_1398  1
    service_2_31_10  free_load_conservation_1399  2
    service_2_31_11  unique_nonzero_owner_312  1
    service_2_31_11  service_visit_def_1398  1
    service_2_31_11  free_load_conservation_1399  3
    service_0_35_0  unique_nonzero_owner_313  1
    service_0_35_0  service_visit_def_715  1
    service_0_35_0  free_load_conservation_716  -3
    service_0_35_0  original_T_including_depot_unload_750  360
    service_0_35_1  unique_nonzero_owner_314  1
    service_0_35_1  service_visit_def_715  1
    service_0_35_1  free_load_conservation_716  -2
    service_0_35_1  original_T_including_depot_unload_750  240
    service_0_35_2  unique_nonzero_owner_315  1
    service_0_35_2  service_visit_def_715  1
    service_0_35_2  free_load_conservation_716  -1
    service_0_35_2  original_T_including_depot_unload_750  120
    service_0_35_4  unique_nonzero_owner_316  1
    service_0_35_4  service_visit_def_715  1
    service_0_35_4  free_load_conservation_716  1
    service_0_35_5  unique_nonzero_owner_317  1
    service_0_35_5  service_visit_def_715  1
    service_0_35_5  free_load_conservation_716  2
    service_0_35_6  unique_nonzero_owner_318  1
    service_0_35_6  service_visit_def_715  1
    service_0_35_6  free_load_conservation_716  3
    service_0_35_7  unique_nonzero_owner_319  1
    service_0_35_7  service_visit_def_715  1
    service_0_35_7  free_load_conservation_716  4
    service_0_35_8  unique_nonzero_owner_320  1
    service_0_35_8  service_visit_def_715  1
    service_0_35_8  free_load_conservation_716  5
    service_0_35_9  unique_nonzero_owner_321  1
    service_0_35_9  service_visit_def_715  1
    service_0_35_9  free_load_conservation_716  6
    service_0_35_10  unique_nonzero_owner_322  1
    service_0_35_10  service_visit_def_715  1
    service_0_35_10  free_load_conservation_716  7
    service_0_35_11  unique_nonzero_owner_323  1
    service_0_35_11  service_visit_def_715  1
    service_0_35_11  free_load_conservation_716  8
    service_0_35_12  unique_nonzero_owner_324  1
    service_0_35_12  service_visit_def_715  1
    service_0_35_12  free_load_conservation_716  9
    service_0_35_13  unique_nonzero_owner_325  1
    service_0_35_13  service_visit_def_715  1
    service_0_35_13  free_load_conservation_716  10
    service_0_35_14  unique_nonzero_owner_326  1
    service_0_35_14  service_visit_def_715  1
    service_0_35_14  free_load_conservation_716  11
    service_0_35_15  unique_nonzero_owner_327  1
    service_0_35_15  service_visit_def_715  1
    service_0_35_15  free_load_conservation_716  12
    service_1_35_0  unique_nonzero_owner_313  1
    service_1_35_0  service_visit_def_1086  1
    service_1_35_0  free_load_conservation_1087  -3
    service_1_35_0  original_T_including_depot_unload_1121  360
    service_1_35_1  unique_nonzero_owner_314  1
    service_1_35_1  service_visit_def_1086  1
    service_1_35_1  free_load_conservation_1087  -2
    service_1_35_1  original_T_including_depot_unload_1121  240
    service_1_35_2  unique_nonzero_owner_315  1
    service_1_35_2  service_visit_def_1086  1
    service_1_35_2  free_load_conservation_1087  -1
    service_1_35_2  original_T_including_depot_unload_1121  120
    service_1_35_4  unique_nonzero_owner_316  1
    service_1_35_4  service_visit_def_1086  1
    service_1_35_4  free_load_conservation_1087  1
    service_1_35_5  unique_nonzero_owner_317  1
    service_1_35_5  service_visit_def_1086  1
    service_1_35_5  free_load_conservation_1087  2
    service_1_35_6  unique_nonzero_owner_318  1
    service_1_35_6  service_visit_def_1086  1
    service_1_35_6  free_load_conservation_1087  3
    service_1_35_7  unique_nonzero_owner_319  1
    service_1_35_7  service_visit_def_1086  1
    service_1_35_7  free_load_conservation_1087  4
    service_1_35_8  unique_nonzero_owner_320  1
    service_1_35_8  service_visit_def_1086  1
    service_1_35_8  free_load_conservation_1087  5
    service_1_35_9  unique_nonzero_owner_321  1
    service_1_35_9  service_visit_def_1086  1
    service_1_35_9  free_load_conservation_1087  6
    service_1_35_10  unique_nonzero_owner_322  1
    service_1_35_10  service_visit_def_1086  1
    service_1_35_10  free_load_conservation_1087  7
    service_1_35_11  unique_nonzero_owner_323  1
    service_1_35_11  service_visit_def_1086  1
    service_1_35_11  free_load_conservation_1087  8
    service_1_35_12  unique_nonzero_owner_324  1
    service_1_35_12  service_visit_def_1086  1
    service_1_35_12  free_load_conservation_1087  9
    service_1_35_13  unique_nonzero_owner_325  1
    service_1_35_13  service_visit_def_1086  1
    service_1_35_13  free_load_conservation_1087  10
    service_1_35_14  unique_nonzero_owner_326  1
    service_1_35_14  service_visit_def_1086  1
    service_1_35_14  free_load_conservation_1087  11
    service_1_35_15  unique_nonzero_owner_327  1
    service_1_35_15  service_visit_def_1086  1
    service_1_35_15  free_load_conservation_1087  12
    service_2_35_0  unique_nonzero_owner_313  1
    service_2_35_0  service_visit_def_1404  1
    service_2_35_0  free_load_conservation_1405  -3
    service_2_35_0  original_T_including_depot_unload_1438  360
    service_2_35_1  unique_nonzero_owner_314  1
    service_2_35_1  service_visit_def_1404  1
    service_2_35_1  free_load_conservation_1405  -2
    service_2_35_1  original_T_including_depot_unload_1438  240
    service_2_35_2  unique_nonzero_owner_315  1
    service_2_35_2  service_visit_def_1404  1
    service_2_35_2  free_load_conservation_1405  -1
    service_2_35_2  original_T_including_depot_unload_1438  120
    service_2_35_4  unique_nonzero_owner_316  1
    service_2_35_4  service_visit_def_1404  1
    service_2_35_4  free_load_conservation_1405  1
    service_2_35_5  unique_nonzero_owner_317  1
    service_2_35_5  service_visit_def_1404  1
    service_2_35_5  free_load_conservation_1405  2
    service_2_35_6  unique_nonzero_owner_318  1
    service_2_35_6  service_visit_def_1404  1
    service_2_35_6  free_load_conservation_1405  3
    service_2_35_7  unique_nonzero_owner_319  1
    service_2_35_7  service_visit_def_1404  1
    service_2_35_7  free_load_conservation_1405  4
    service_2_35_8  unique_nonzero_owner_320  1
    service_2_35_8  service_visit_def_1404  1
    service_2_35_8  free_load_conservation_1405  5
    service_2_35_9  unique_nonzero_owner_321  1
    service_2_35_9  service_visit_def_1404  1
    service_2_35_9  free_load_conservation_1405  6
    service_2_35_10  unique_nonzero_owner_322  1
    service_2_35_10  service_visit_def_1404  1
    service_2_35_10  free_load_conservation_1405  7
    service_2_35_11  unique_nonzero_owner_323  1
    service_2_35_11  service_visit_def_1404  1
    service_2_35_11  free_load_conservation_1405  8
    service_2_35_12  unique_nonzero_owner_324  1
    service_2_35_12  service_visit_def_1404  1
    service_2_35_12  free_load_conservation_1405  9
    service_2_35_13  unique_nonzero_owner_325  1
    service_2_35_13  service_visit_def_1404  1
    service_2_35_13  free_load_conservation_1405  10
    service_2_35_14  unique_nonzero_owner_326  1
    service_2_35_14  service_visit_def_1404  1
    service_2_35_14  free_load_conservation_1405  11
    service_2_35_15  unique_nonzero_owner_327  1
    service_2_35_15  service_visit_def_1404  1
    service_2_35_15  free_load_conservation_1405  12
    service_0_32_0  unique_nonzero_owner_328  1
    service_0_32_0  service_visit_def_721  1
    service_0_32_0  free_load_conservation_722  -2
    service_0_32_0  original_T_including_depot_unload_750  240
    service_0_32_1  unique_nonzero_owner_329  1
    service_0_32_1  service_visit_def_721  1
    service_0_32_1  free_load_conservation_722  -1
    service_0_32_1  original_T_including_depot_unload_750  120
    service_0_32_3  unique_nonzero_owner_330  1
    service_0_32_3  service_visit_def_721  1
    service_0_32_3  free_load_conservation_722  1
    service_0_32_4  unique_nonzero_owner_331  1
    service_0_32_4  service_visit_def_721  1
    service_0_32_4  free_load_conservation_722  2
    service_0_32_5  unique_nonzero_owner_332  1
    service_0_32_5  service_visit_def_721  1
    service_0_32_5  free_load_conservation_722  3
    service_0_32_6  unique_nonzero_owner_333  1
    service_0_32_6  service_visit_def_721  1
    service_0_32_6  free_load_conservation_722  4
    service_0_32_7  unique_nonzero_owner_334  1
    service_0_32_7  service_visit_def_721  1
    service_0_32_7  free_load_conservation_722  5
    service_0_32_8  unique_nonzero_owner_335  1
    service_0_32_8  service_visit_def_721  1
    service_0_32_8  free_load_conservation_722  6
    service_0_32_9  unique_nonzero_owner_336  1
    service_0_32_9  service_visit_def_721  1
    service_0_32_9  free_load_conservation_722  7
    service_0_32_10  unique_nonzero_owner_337  1
    service_0_32_10  service_visit_def_721  1
    service_0_32_10  free_load_conservation_722  8
    service_0_32_11  unique_nonzero_owner_338  1
    service_0_32_11  service_visit_def_721  1
    service_0_32_11  free_load_conservation_722  9
    service_0_32_12  unique_nonzero_owner_339  1
    service_0_32_12  service_visit_def_721  1
    service_0_32_12  free_load_conservation_722  10
    service_0_32_13  unique_nonzero_owner_340  1
    service_0_32_13  service_visit_def_721  1
    service_0_32_13  free_load_conservation_722  11
    service_0_32_14  unique_nonzero_owner_341  1
    service_0_32_14  service_visit_def_721  1
    service_0_32_14  free_load_conservation_722  12
    service_0_32_15  unique_nonzero_owner_342  1
    service_0_32_15  service_visit_def_721  1
    service_0_32_15  free_load_conservation_722  13
    service_0_32_16  unique_nonzero_owner_343  1
    service_0_32_16  service_visit_def_721  1
    service_0_32_16  free_load_conservation_722  14
    service_0_32_17  unique_nonzero_owner_344  1
    service_0_32_17  service_visit_def_721  1
    service_0_32_17  free_load_conservation_722  15
    service_0_32_18  unique_nonzero_owner_345  1
    service_0_32_18  service_visit_def_721  1
    service_0_32_18  free_load_conservation_722  16
    service_0_32_19  unique_nonzero_owner_346  1
    service_0_32_19  service_visit_def_721  1
    service_0_32_19  free_load_conservation_722  17
    service_1_32_0  unique_nonzero_owner_328  1
    service_1_32_0  service_visit_def_1092  1
    service_1_32_0  free_load_conservation_1093  -2
    service_1_32_0  original_T_including_depot_unload_1121  240
    service_1_32_1  unique_nonzero_owner_329  1
    service_1_32_1  service_visit_def_1092  1
    service_1_32_1  free_load_conservation_1093  -1
    service_1_32_1  original_T_including_depot_unload_1121  120
    service_1_32_3  unique_nonzero_owner_330  1
    service_1_32_3  service_visit_def_1092  1
    service_1_32_3  free_load_conservation_1093  1
    service_1_32_4  unique_nonzero_owner_331  1
    service_1_32_4  service_visit_def_1092  1
    service_1_32_4  free_load_conservation_1093  2
    service_1_32_5  unique_nonzero_owner_332  1
    service_1_32_5  service_visit_def_1092  1
    service_1_32_5  free_load_conservation_1093  3
    service_1_32_6  unique_nonzero_owner_333  1
    service_1_32_6  service_visit_def_1092  1
    service_1_32_6  free_load_conservation_1093  4
    service_1_32_7  unique_nonzero_owner_334  1
    service_1_32_7  service_visit_def_1092  1
    service_1_32_7  free_load_conservation_1093  5
    service_1_32_8  unique_nonzero_owner_335  1
    service_1_32_8  service_visit_def_1092  1
    service_1_32_8  free_load_conservation_1093  6
    service_1_32_9  unique_nonzero_owner_336  1
    service_1_32_9  service_visit_def_1092  1
    service_1_32_9  free_load_conservation_1093  7
    service_1_32_10  unique_nonzero_owner_337  1
    service_1_32_10  service_visit_def_1092  1
    service_1_32_10  free_load_conservation_1093  8
    service_1_32_11  unique_nonzero_owner_338  1
    service_1_32_11  service_visit_def_1092  1
    service_1_32_11  free_load_conservation_1093  9
    service_1_32_12  unique_nonzero_owner_339  1
    service_1_32_12  service_visit_def_1092  1
    service_1_32_12  free_load_conservation_1093  10
    service_1_32_13  unique_nonzero_owner_340  1
    service_1_32_13  service_visit_def_1092  1
    service_1_32_13  free_load_conservation_1093  11
    service_1_32_14  unique_nonzero_owner_341  1
    service_1_32_14  service_visit_def_1092  1
    service_1_32_14  free_load_conservation_1093  12
    service_1_32_15  unique_nonzero_owner_342  1
    service_1_32_15  service_visit_def_1092  1
    service_1_32_15  free_load_conservation_1093  13
    service_1_32_16  unique_nonzero_owner_343  1
    service_1_32_16  service_visit_def_1092  1
    service_1_32_16  free_load_conservation_1093  14
    service_1_32_17  unique_nonzero_owner_344  1
    service_1_32_17  service_visit_def_1092  1
    service_1_32_17  free_load_conservation_1093  15
    service_1_32_18  unique_nonzero_owner_345  1
    service_1_32_18  service_visit_def_1092  1
    service_1_32_18  free_load_conservation_1093  16
    service_1_32_19  unique_nonzero_owner_346  1
    service_1_32_19  service_visit_def_1092  1
    service_1_32_19  free_load_conservation_1093  17
    service_2_32_0  unique_nonzero_owner_328  1
    service_2_32_0  service_visit_def_1410  1
    service_2_32_0  free_load_conservation_1411  -2
    service_2_32_0  original_T_including_depot_unload_1438  240
    service_2_32_1  unique_nonzero_owner_329  1
    service_2_32_1  service_visit_def_1410  1
    service_2_32_1  free_load_conservation_1411  -1
    service_2_32_1  original_T_including_depot_unload_1438  120
    service_2_32_3  unique_nonzero_owner_330  1
    service_2_32_3  service_visit_def_1410  1
    service_2_32_3  free_load_conservation_1411  1
    service_2_32_4  unique_nonzero_owner_331  1
    service_2_32_4  service_visit_def_1410  1
    service_2_32_4  free_load_conservation_1411  2
    service_2_32_5  unique_nonzero_owner_332  1
    service_2_32_5  service_visit_def_1410  1
    service_2_32_5  free_load_conservation_1411  3
    service_2_32_6  unique_nonzero_owner_333  1
    service_2_32_6  service_visit_def_1410  1
    service_2_32_6  free_load_conservation_1411  4
    service_2_32_7  unique_nonzero_owner_334  1
    service_2_32_7  service_visit_def_1410  1
    service_2_32_7  free_load_conservation_1411  5
    service_2_32_8  unique_nonzero_owner_335  1
    service_2_32_8  service_visit_def_1410  1
    service_2_32_8  free_load_conservation_1411  6
    service_2_32_9  unique_nonzero_owner_336  1
    service_2_32_9  service_visit_def_1410  1
    service_2_32_9  free_load_conservation_1411  7
    service_2_32_10  unique_nonzero_owner_337  1
    service_2_32_10  service_visit_def_1410  1
    service_2_32_10  free_load_conservation_1411  8
    service_2_32_11  unique_nonzero_owner_338  1
    service_2_32_11  service_visit_def_1410  1
    service_2_32_11  free_load_conservation_1411  9
    service_2_32_12  unique_nonzero_owner_339  1
    service_2_32_12  service_visit_def_1410  1
    service_2_32_12  free_load_conservation_1411  10
    service_2_32_13  unique_nonzero_owner_340  1
    service_2_32_13  service_visit_def_1410  1
    service_2_32_13  free_load_conservation_1411  11
    service_2_32_14  unique_nonzero_owner_341  1
    service_2_32_14  service_visit_def_1410  1
    service_2_32_14  free_load_conservation_1411  12
    service_2_32_15  unique_nonzero_owner_342  1
    service_2_32_15  service_visit_def_1410  1
    service_2_32_15  free_load_conservation_1411  13
    service_2_32_16  unique_nonzero_owner_343  1
    service_2_32_16  service_visit_def_1410  1
    service_2_32_16  free_load_conservation_1411  14
    service_2_32_17  unique_nonzero_owner_344  1
    service_2_32_17  service_visit_def_1410  1
    service_2_32_17  free_load_conservation_1411  15
    service_2_32_18  unique_nonzero_owner_345  1
    service_2_32_18  service_visit_def_1410  1
    service_2_32_18  free_load_conservation_1411  16
    service_2_32_19  unique_nonzero_owner_346  1
    service_2_32_19  service_visit_def_1410  1
    service_2_32_19  free_load_conservation_1411  17
    service_0_27_1  unique_nonzero_owner_347  1
    service_0_27_1  service_visit_def_727  1
    service_0_27_1  free_load_conservation_728  1
    service_0_27_2  unique_nonzero_owner_348  1
    service_0_27_2  service_visit_def_727  1
    service_0_27_2  free_load_conservation_728  2
    service_0_27_3  unique_nonzero_owner_349  1
    service_0_27_3  service_visit_def_727  1
    service_0_27_3  free_load_conservation_728  3
    service_0_27_4  unique_nonzero_owner_350  1
    service_0_27_4  service_visit_def_727  1
    service_0_27_4  free_load_conservation_728  4
    service_0_27_5  unique_nonzero_owner_351  1
    service_0_27_5  service_visit_def_727  1
    service_0_27_5  free_load_conservation_728  5
    service_0_27_6  unique_nonzero_owner_352  1
    service_0_27_6  service_visit_def_727  1
    service_0_27_6  free_load_conservation_728  6
    service_1_27_1  unique_nonzero_owner_347  1
    service_1_27_1  service_visit_def_1098  1
    service_1_27_1  free_load_conservation_1099  1
    service_1_27_2  unique_nonzero_owner_348  1
    service_1_27_2  service_visit_def_1098  1
    service_1_27_2  free_load_conservation_1099  2
    service_1_27_3  unique_nonzero_owner_349  1
    service_1_27_3  service_visit_def_1098  1
    service_1_27_3  free_load_conservation_1099  3
    service_1_27_4  unique_nonzero_owner_350  1
    service_1_27_4  service_visit_def_1098  1
    service_1_27_4  free_load_conservation_1099  4
    service_1_27_5  unique_nonzero_owner_351  1
    service_1_27_5  service_visit_def_1098  1
    service_1_27_5  free_load_conservation_1099  5
    service_1_27_6  unique_nonzero_owner_352  1
    service_1_27_6  service_visit_def_1098  1
    service_1_27_6  free_load_conservation_1099  6
    service_2_27_1  unique_nonzero_owner_347  1
    service_2_27_1  service_visit_def_1416  1
    service_2_27_1  free_load_conservation_1417  1
    service_2_27_2  unique_nonzero_owner_348  1
    service_2_27_2  service_visit_def_1416  1
    service_2_27_2  free_load_conservation_1417  2
    service_2_27_3  unique_nonzero_owner_349  1
    service_2_27_3  service_visit_def_1416  1
    service_2_27_3  free_load_conservation_1417  3
    service_2_27_4  unique_nonzero_owner_350  1
    service_2_27_4  service_visit_def_1416  1
    service_2_27_4  free_load_conservation_1417  4
    service_2_27_5  unique_nonzero_owner_351  1
    service_2_27_5  service_visit_def_1416  1
    service_2_27_5  free_load_conservation_1417  5
    service_2_27_6  unique_nonzero_owner_352  1
    service_2_27_6  service_visit_def_1416  1
    service_2_27_6  free_load_conservation_1417  6
    service_0_25_1  unique_nonzero_owner_353  1
    service_0_25_1  service_visit_def_733  1
    service_0_25_1  free_load_conservation_734  1
    service_0_25_2  unique_nonzero_owner_354  1
    service_0_25_2  service_visit_def_733  1
    service_0_25_2  free_load_conservation_734  2
    service_0_25_3  unique_nonzero_owner_355  1
    service_0_25_3  service_visit_def_733  1
    service_0_25_3  free_load_conservation_734  3
    service_0_25_4  unique_nonzero_owner_356  1
    service_0_25_4  service_visit_def_733  1
    service_0_25_4  free_load_conservation_734  4
    service_1_25_1  unique_nonzero_owner_353  1
    service_1_25_1  service_visit_def_1104  1
    service_1_25_1  free_load_conservation_1105  1
    service_1_25_2  unique_nonzero_owner_354  1
    service_1_25_2  service_visit_def_1104  1
    service_1_25_2  free_load_conservation_1105  2
    service_1_25_3  unique_nonzero_owner_355  1
    service_1_25_3  service_visit_def_1104  1
    service_1_25_3  free_load_conservation_1105  3
    service_1_25_4  unique_nonzero_owner_356  1
    service_1_25_4  service_visit_def_1104  1
    service_1_25_4  free_load_conservation_1105  4
    service_2_25_1  unique_nonzero_owner_353  1
    service_2_25_1  service_visit_def_1422  1
    service_2_25_1  free_load_conservation_1423  1
    service_2_25_2  unique_nonzero_owner_354  1
    service_2_25_2  service_visit_def_1422  1
    service_2_25_2  free_load_conservation_1423  2
    service_2_25_3  unique_nonzero_owner_355  1
    service_2_25_3  service_visit_def_1422  1
    service_2_25_3  free_load_conservation_1423  3
    service_2_25_4  unique_nonzero_owner_356  1
    service_2_25_4  service_visit_def_1422  1
    service_2_25_4  free_load_conservation_1423  4
    service_0_22_0  unique_nonzero_owner_357  1
    service_0_22_0  service_visit_def_739  1
    service_0_22_0  free_load_conservation_740  -2
    service_0_22_0  original_T_including_depot_unload_750  240
    service_0_22_1  unique_nonzero_owner_358  1
    service_0_22_1  service_visit_def_739  1
    service_0_22_1  free_load_conservation_740  -1
    service_0_22_1  original_T_including_depot_unload_750  120
    service_0_22_3  unique_nonzero_owner_359  1
    service_0_22_3  service_visit_def_739  1
    service_0_22_3  free_load_conservation_740  1
    service_0_22_4  unique_nonzero_owner_360  1
    service_0_22_4  service_visit_def_739  1
    service_0_22_4  free_load_conservation_740  2
    service_0_22_5  unique_nonzero_owner_361  1
    service_0_22_5  service_visit_def_739  1
    service_0_22_5  free_load_conservation_740  3
    service_0_22_6  unique_nonzero_owner_362  1
    service_0_22_6  service_visit_def_739  1
    service_0_22_6  free_load_conservation_740  4
    service_0_22_7  unique_nonzero_owner_363  1
    service_0_22_7  service_visit_def_739  1
    service_0_22_7  free_load_conservation_740  5
    service_0_22_8  unique_nonzero_owner_364  1
    service_0_22_8  service_visit_def_739  1
    service_0_22_8  free_load_conservation_740  6
    service_0_22_9  unique_nonzero_owner_365  1
    service_0_22_9  service_visit_def_739  1
    service_0_22_9  free_load_conservation_740  7
    service_0_22_10  unique_nonzero_owner_366  1
    service_0_22_10  service_visit_def_739  1
    service_0_22_10  free_load_conservation_740  8
    service_0_22_11  unique_nonzero_owner_367  1
    service_0_22_11  service_visit_def_739  1
    service_0_22_11  free_load_conservation_740  9
    service_0_22_12  unique_nonzero_owner_368  1
    service_0_22_12  service_visit_def_739  1
    service_0_22_12  free_load_conservation_740  10
    service_0_22_13  unique_nonzero_owner_369  1
    service_0_22_13  service_visit_def_739  1
    service_0_22_13  free_load_conservation_740  11
    service_0_22_14  unique_nonzero_owner_370  1
    service_0_22_14  service_visit_def_739  1
    service_0_22_14  free_load_conservation_740  12
    service_0_22_15  unique_nonzero_owner_371  1
    service_0_22_15  service_visit_def_739  1
    service_0_22_15  free_load_conservation_740  13
    service_1_22_0  unique_nonzero_owner_357  1
    service_1_22_0  service_visit_def_1110  1
    service_1_22_0  free_load_conservation_1111  -2
    service_1_22_0  original_T_including_depot_unload_1121  240
    service_1_22_1  unique_nonzero_owner_358  1
    service_1_22_1  service_visit_def_1110  1
    service_1_22_1  free_load_conservation_1111  -1
    service_1_22_1  original_T_including_depot_unload_1121  120
    service_1_22_3  unique_nonzero_owner_359  1
    service_1_22_3  service_visit_def_1110  1
    service_1_22_3  free_load_conservation_1111  1
    service_1_22_4  unique_nonzero_owner_360  1
    service_1_22_4  service_visit_def_1110  1
    service_1_22_4  free_load_conservation_1111  2
    service_1_22_5  unique_nonzero_owner_361  1
    service_1_22_5  service_visit_def_1110  1
    service_1_22_5  free_load_conservation_1111  3
    service_1_22_6  unique_nonzero_owner_362  1
    service_1_22_6  service_visit_def_1110  1
    service_1_22_6  free_load_conservation_1111  4
    service_1_22_7  unique_nonzero_owner_363  1
    service_1_22_7  service_visit_def_1110  1
    service_1_22_7  free_load_conservation_1111  5
    service_1_22_8  unique_nonzero_owner_364  1
    service_1_22_8  service_visit_def_1110  1
    service_1_22_8  free_load_conservation_1111  6
    service_1_22_9  unique_nonzero_owner_365  1
    service_1_22_9  service_visit_def_1110  1
    service_1_22_9  free_load_conservation_1111  7
    service_1_22_10  unique_nonzero_owner_366  1
    service_1_22_10  service_visit_def_1110  1
    service_1_22_10  free_load_conservation_1111  8
    service_1_22_11  unique_nonzero_owner_367  1
    service_1_22_11  service_visit_def_1110  1
    service_1_22_11  free_load_conservation_1111  9
    service_1_22_12  unique_nonzero_owner_368  1
    service_1_22_12  service_visit_def_1110  1
    service_1_22_12  free_load_conservation_1111  10
    service_1_22_13  unique_nonzero_owner_369  1
    service_1_22_13  service_visit_def_1110  1
    service_1_22_13  free_load_conservation_1111  11
    service_1_22_14  unique_nonzero_owner_370  1
    service_1_22_14  service_visit_def_1110  1
    service_1_22_14  free_load_conservation_1111  12
    service_1_22_15  unique_nonzero_owner_371  1
    service_1_22_15  service_visit_def_1110  1
    service_1_22_15  free_load_conservation_1111  13
    service_2_22_0  unique_nonzero_owner_357  1
    service_2_22_0  service_visit_def_1428  1
    service_2_22_0  free_load_conservation_1429  -2
    service_2_22_0  original_T_including_depot_unload_1438  240
    service_2_22_1  unique_nonzero_owner_358  1
    service_2_22_1  service_visit_def_1428  1
    service_2_22_1  free_load_conservation_1429  -1
    service_2_22_1  original_T_including_depot_unload_1438  120
    service_2_22_3  unique_nonzero_owner_359  1
    service_2_22_3  service_visit_def_1428  1
    service_2_22_3  free_load_conservation_1429  1
    service_2_22_4  unique_nonzero_owner_360  1
    service_2_22_4  service_visit_def_1428  1
    service_2_22_4  free_load_conservation_1429  2
    service_2_22_5  unique_nonzero_owner_361  1
    service_2_22_5  service_visit_def_1428  1
    service_2_22_5  free_load_conservation_1429  3
    service_2_22_6  unique_nonzero_owner_362  1
    service_2_22_6  service_visit_def_1428  1
    service_2_22_6  free_load_conservation_1429  4
    service_2_22_7  unique_nonzero_owner_363  1
    service_2_22_7  service_visit_def_1428  1
    service_2_22_7  free_load_conservation_1429  5
    service_2_22_8  unique_nonzero_owner_364  1
    service_2_22_8  service_visit_def_1428  1
    service_2_22_8  free_load_conservation_1429  6
    service_2_22_9  unique_nonzero_owner_365  1
    service_2_22_9  service_visit_def_1428  1
    service_2_22_9  free_load_conservation_1429  7
    service_2_22_10  unique_nonzero_owner_366  1
    service_2_22_10  service_visit_def_1428  1
    service_2_22_10  free_load_conservation_1429  8
    service_2_22_11  unique_nonzero_owner_367  1
    service_2_22_11  service_visit_def_1428  1
    service_2_22_11  free_load_conservation_1429  9
    service_2_22_12  unique_nonzero_owner_368  1
    service_2_22_12  service_visit_def_1428  1
    service_2_22_12  free_load_conservation_1429  10
    service_2_22_13  unique_nonzero_owner_369  1
    service_2_22_13  service_visit_def_1428  1
    service_2_22_13  free_load_conservation_1429  11
    service_2_22_14  unique_nonzero_owner_370  1
    service_2_22_14  service_visit_def_1428  1
    service_2_22_14  free_load_conservation_1429  12
    service_2_22_15  unique_nonzero_owner_371  1
    service_2_22_15  service_visit_def_1428  1
    service_2_22_15  free_load_conservation_1429  13
    service_0_26_0  unique_nonzero_owner_372  1
    service_0_26_0  service_visit_def_745  1
    service_0_26_0  free_load_conservation_746  -5
    service_0_26_0  original_T_including_depot_unload_750  600
    service_0_26_1  unique_nonzero_owner_373  1
    service_0_26_1  service_visit_def_745  1
    service_0_26_1  free_load_conservation_746  -4
    service_0_26_1  original_T_including_depot_unload_750  480
    service_0_26_2  unique_nonzero_owner_374  1
    service_0_26_2  service_visit_def_745  1
    service_0_26_2  free_load_conservation_746  -3
    service_0_26_2  original_T_including_depot_unload_750  360
    service_0_26_3  unique_nonzero_owner_375  1
    service_0_26_3  service_visit_def_745  1
    service_0_26_3  free_load_conservation_746  -2
    service_0_26_3  original_T_including_depot_unload_750  240
    service_0_26_4  unique_nonzero_owner_376  1
    service_0_26_4  service_visit_def_745  1
    service_0_26_4  free_load_conservation_746  -1
    service_0_26_4  original_T_including_depot_unload_750  120
    service_0_26_6  unique_nonzero_owner_377  1
    service_0_26_6  service_visit_def_745  1
    service_0_26_6  free_load_conservation_746  1
    service_0_26_7  unique_nonzero_owner_378  1
    service_0_26_7  service_visit_def_745  1
    service_0_26_7  free_load_conservation_746  2
    service_0_26_8  unique_nonzero_owner_379  1
    service_0_26_8  service_visit_def_745  1
    service_0_26_8  free_load_conservation_746  3
    service_1_26_0  unique_nonzero_owner_372  1
    service_1_26_0  service_visit_def_1116  1
    service_1_26_0  free_load_conservation_1117  -5
    service_1_26_0  original_T_including_depot_unload_1121  600
    service_1_26_1  unique_nonzero_owner_373  1
    service_1_26_1  service_visit_def_1116  1
    service_1_26_1  free_load_conservation_1117  -4
    service_1_26_1  original_T_including_depot_unload_1121  480
    service_1_26_2  unique_nonzero_owner_374  1
    service_1_26_2  service_visit_def_1116  1
    service_1_26_2  free_load_conservation_1117  -3
    service_1_26_2  original_T_including_depot_unload_1121  360
    service_1_26_3  unique_nonzero_owner_375  1
    service_1_26_3  service_visit_def_1116  1
    service_1_26_3  free_load_conservation_1117  -2
    service_1_26_3  original_T_including_depot_unload_1121  240
    service_1_26_4  unique_nonzero_owner_376  1
    service_1_26_4  service_visit_def_1116  1
    service_1_26_4  free_load_conservation_1117  -1
    service_1_26_4  original_T_including_depot_unload_1121  120
    service_1_26_6  unique_nonzero_owner_377  1
    service_1_26_6  service_visit_def_1116  1
    service_1_26_6  free_load_conservation_1117  1
    service_1_26_7  unique_nonzero_owner_378  1
    service_1_26_7  service_visit_def_1116  1
    service_1_26_7  free_load_conservation_1117  2
    service_1_26_8  unique_nonzero_owner_379  1
    service_1_26_8  service_visit_def_1116  1
    service_1_26_8  free_load_conservation_1117  3
    service_2_26_0  unique_nonzero_owner_372  1
    service_2_26_0  service_visit_def_1434  1
    service_2_26_0  free_load_conservation_1435  -5
    service_2_26_0  original_T_including_depot_unload_1438  600
    service_2_26_1  unique_nonzero_owner_373  1
    service_2_26_1  service_visit_def_1434  1
    service_2_26_1  free_load_conservation_1435  -4
    service_2_26_1  original_T_including_depot_unload_1438  480
    service_2_26_2  unique_nonzero_owner_374  1
    service_2_26_2  service_visit_def_1434  1
    service_2_26_2  free_load_conservation_1435  -3
    service_2_26_2  original_T_including_depot_unload_1438  360
    service_2_26_3  unique_nonzero_owner_375  1
    service_2_26_3  service_visit_def_1434  1
    service_2_26_3  free_load_conservation_1435  -2
    service_2_26_3  original_T_including_depot_unload_1438  240
    service_2_26_4  unique_nonzero_owner_376  1
    service_2_26_4  service_visit_def_1434  1
    service_2_26_4  free_load_conservation_1435  -1
    service_2_26_4  original_T_including_depot_unload_1438  120
    service_2_26_6  unique_nonzero_owner_377  1
    service_2_26_6  service_visit_def_1434  1
    service_2_26_6  free_load_conservation_1435  1
    service_2_26_7  unique_nonzero_owner_378  1
    service_2_26_7  service_visit_def_1434  1
    service_2_26_7  free_load_conservation_1435  2
    service_2_26_8  unique_nonzero_owner_379  1
    service_2_26_8  service_visit_def_1434  1
    service_2_26_8  free_load_conservation_1435  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_671  -1
    visit_0_1  in_degree_672  -1
    visit_0_1  order_active_lb_673  -1
    visit_0_1  order_active_ub_674  -12
    order_0_1  connected_order_arc_395  -1
    order_0_1  connected_order_arc_397  -1
    order_0_1  connected_order_arc_399  -1
    order_0_1  connected_order_arc_401  -1
    order_0_1  connected_order_arc_403  -1
    order_0_1  connected_order_arc_405  -1
    order_0_1  connected_order_arc_407  -1
    order_0_1  connected_order_arc_409  -1
    order_0_1  connected_order_arc_411  -1
    order_0_1  connected_order_arc_413  -1
    order_0_1  connected_order_arc_415  -1
    order_0_1  connected_order_arc_418  1
    order_0_1  connected_order_arc_441  1
    order_0_1  connected_order_arc_464  1
    order_0_1  connected_order_arc_487  1
    order_0_1  connected_order_arc_510  1
    order_0_1  connected_order_arc_533  1
    order_0_1  connected_order_arc_556  1
    order_0_1  connected_order_arc_579  1
    order_0_1  connected_order_arc_602  1
    order_0_1  connected_order_arc_625  1
    order_0_1  connected_order_arc_648  1
    order_0_1  order_active_lb_673  1
    order_0_1  order_active_ub_674  1
    order_0_1  fixed_segment_relative_order_747  -1
    visit_0_2  out_degree_678  -1
    visit_0_2  in_degree_679  -1
    visit_0_2  order_active_lb_680  -1
    visit_0_2  order_active_ub_681  -12
    order_0_2  connected_order_arc_395  1
    order_0_2  connected_order_arc_418  -1
    order_0_2  connected_order_arc_420  -1
    order_0_2  connected_order_arc_422  -1
    order_0_2  connected_order_arc_424  -1
    order_0_2  connected_order_arc_426  -1
    order_0_2  connected_order_arc_428  -1
    order_0_2  connected_order_arc_430  -1
    order_0_2  connected_order_arc_432  -1
    order_0_2  connected_order_arc_434  -1
    order_0_2  connected_order_arc_436  -1
    order_0_2  connected_order_arc_438  -1
    order_0_2  connected_order_arc_443  1
    order_0_2  connected_order_arc_466  1
    order_0_2  connected_order_arc_489  1
    order_0_2  connected_order_arc_512  1
    order_0_2  connected_order_arc_535  1
    order_0_2  connected_order_arc_558  1
    order_0_2  connected_order_arc_581  1
    order_0_2  connected_order_arc_604  1
    order_0_2  connected_order_arc_627  1
    order_0_2  connected_order_arc_650  1
    order_0_2  order_active_lb_680  1
    order_0_2  order_active_ub_681  1
    order_0_2  fixed_segment_relative_order_747  1
    order_0_2  fixed_segment_relative_order_748  -1
    visit_0_3  out_degree_685  -1
    visit_0_3  in_degree_686  -1
    visit_0_3  order_active_lb_687  -1
    visit_0_3  order_active_ub_688  -12
    order_0_3  connected_order_arc_397  1
    order_0_3  connected_order_arc_420  1
    order_0_3  connected_order_arc_441  -1
    order_0_3  connected_order_arc_443  -1
    order_0_3  connected_order_arc_445  -1
    order_0_3  connected_order_arc_447  -1
    order_0_3  connected_order_arc_449  -1
    order_0_3  connected_order_arc_451  -1
    order_0_3  connected_order_arc_453  -1
    order_0_3  connected_order_arc_455  -1
    order_0_3  connected_order_arc_457  -1
    order_0_3  connected_order_arc_459  -1
    order_0_3  connected_order_arc_461  -1
    order_0_3  connected_order_arc_468  1
    order_0_3  connected_order_arc_491  1
    order_0_3  connected_order_arc_514  1
    order_0_3  connected_order_arc_537  1
    order_0_3  connected_order_arc_560  1
    order_0_3  connected_order_arc_583  1
    order_0_3  connected_order_arc_606  1
    order_0_3  connected_order_arc_629  1
    order_0_3  connected_order_arc_652  1
    order_0_3  order_active_lb_687  1
    order_0_3  order_active_ub_688  1
    order_0_3  fixed_segment_relative_order_748  1
    order_0_3  fixed_segment_relative_order_749  -1
    visit_0_4  out_degree_692  -1
    visit_0_4  in_degree_693  -1
    visit_0_4  order_active_lb_694  -1
    visit_0_4  order_active_ub_695  -12
    order_0_4  connected_order_arc_399  1
    order_0_4  connected_order_arc_422  1
    order_0_4  connected_order_arc_445  1
    order_0_4  connected_order_arc_464  -1
    order_0_4  connected_order_arc_466  -1
    order_0_4  connected_order_arc_468  -1
    order_0_4  connected_order_arc_470  -1
    order_0_4  connected_order_arc_472  -1
    order_0_4  connected_order_arc_474  -1
    order_0_4  connected_order_arc_476  -1
    order_0_4  connected_order_arc_478  -1
    order_0_4  connected_order_arc_480  -1
    order_0_4  connected_order_arc_482  -1
    order_0_4  connected_order_arc_484  -1
    order_0_4  connected_order_arc_493  1
    order_0_4  connected_order_arc_516  1
    order_0_4  connected_order_arc_539  1
    order_0_4  connected_order_arc_562  1
    order_0_4  connected_order_arc_585  1
    order_0_4  connected_order_arc_608  1
    order_0_4  connected_order_arc_631  1
    order_0_4  connected_order_arc_654  1
    order_0_4  order_active_lb_694  1
    order_0_4  order_active_ub_695  1
    order_0_4  fixed_segment_relative_order_749  1
    visit_0_12  out_degree_699  -1
    visit_0_12  in_degree_700  -1
    visit_0_12  order_active_lb_701  -1
    visit_0_12  order_active_ub_702  -12
    visit_0_12  service_visit_def_703  -1
    order_0_12  connected_order_arc_401  1
    order_0_12  connected_order_arc_424  1
    order_0_12  connected_order_arc_447  1
    order_0_12  connected_order_arc_470  1
    order_0_12  connected_order_arc_487  -1
    order_0_12  connected_order_arc_489  -1
    order_0_12  connected_order_arc_491  -1
    order_0_12  connected_order_arc_493  -1
    order_0_12  connected_order_arc_495  -1
    order_0_12  connected_order_arc_497  -1
    order_0_12  connected_order_arc_499  -1
    order_0_12  connected_order_arc_501  -1
    order_0_12  connected_order_arc_503  -1
    order_0_12  connected_order_arc_505  -1
    order_0_12  connected_order_arc_507  -1
    order_0_12  connected_order_arc_518  1
    order_0_12  connected_order_arc_541  1
    order_0_12  connected_order_arc_564  1
    order_0_12  connected_order_arc_587  1
    order_0_12  connected_order_arc_610  1
    order_0_12  connected_order_arc_633  1
    order_0_12  connected_order_arc_656  1
    order_0_12  order_active_lb_701  1
    order_0_12  order_active_ub_702  1
    visit_0_13  out_degree_705  -1
    visit_0_13  in_degree_706  -1
    visit_0_13  order_active_lb_707  -1
    visit_0_13  order_active_ub_708  -12
    visit_0_13  service_visit_def_709  -1
    order_0_13  connected_order_arc_403  1
    order_0_13  connected_order_arc_426  1
    order_0_13  connected_order_arc_449  1
    order_0_13  connected_order_arc_472  1
    order_0_13  connected_order_arc_495  1
    order_0_13  connected_order_arc_510  -1
    order_0_13  connected_order_arc_512  -1
    order_0_13  connected_order_arc_514  -1
    order_0_13  connected_order_arc_516  -1
    order_0_13  connected_order_arc_518  -1
    order_0_13  connected_order_arc_520  -1
    order_0_13  connected_order_arc_522  -1
    order_0_13  connected_order_arc_524  -1
    order_0_13  connected_order_arc_526  -1
    order_0_13  connected_order_arc_528  -1
    order_0_13  connected_order_arc_530  -1
    order_0_13  connected_order_arc_543  1
    order_0_13  connected_order_arc_566  1
    order_0_13  connected_order_arc_589  1
    order_0_13  connected_order_arc_612  1
    order_0_13  connected_order_arc_635  1
    order_0_13  connected_order_arc_658  1
    order_0_13  order_active_lb_707  1
    order_0_13  order_active_ub_708  1
    visit_0_14  out_degree_711  -1
    visit_0_14  in_degree_712  -1
    visit_0_14  order_active_lb_713  -1
    visit_0_14  order_active_ub_714  -12
    visit_0_14  service_visit_def_715  -1
    order_0_14  connected_order_arc_405  1
    order_0_14  connected_order_arc_428  1
    order_0_14  connected_order_arc_451  1
    order_0_14  connected_order_arc_474  1
    order_0_14  connected_order_arc_497  1
    order_0_14  connected_order_arc_520  1
    order_0_14  connected_order_arc_533  -1
    order_0_14  connected_order_arc_535  -1
    order_0_14  connected_order_arc_537  -1
    order_0_14  connected_order_arc_539  -1
    order_0_14  connected_order_arc_541  -1
    order_0_14  connected_order_arc_543  -1
    order_0_14  connected_order_arc_545  -1
    order_0_14  connected_order_arc_547  -1
    order_0_14  connected_order_arc_549  -1
    order_0_14  connected_order_arc_551  -1
    order_0_14  connected_order_arc_553  -1
    order_0_14  connected_order_arc_568  1
    order_0_14  connected_order_arc_591  1
    order_0_14  connected_order_arc_614  1
    order_0_14  connected_order_arc_637  1
    order_0_14  connected_order_arc_660  1
    order_0_14  order_active_lb_713  1
    order_0_14  order_active_ub_714  1
    visit_0_15  out_degree_717  -1
    visit_0_15  in_degree_718  -1
    visit_0_15  order_active_lb_719  -1
    visit_0_15  order_active_ub_720  -12
    visit_0_15  service_visit_def_721  -1
    order_0_15  connected_order_arc_407  1
    order_0_15  connected_order_arc_430  1
    order_0_15  connected_order_arc_453  1
    order_0_15  connected_order_arc_476  1
    order_0_15  connected_order_arc_499  1
    order_0_15  connected_order_arc_522  1
    order_0_15  connected_order_arc_545  1
    order_0_15  connected_order_arc_556  -1
    order_0_15  connected_order_arc_558  -1
    order_0_15  connected_order_arc_560  -1
    order_0_15  connected_order_arc_562  -1
    order_0_15  connected_order_arc_564  -1
    order_0_15  connected_order_arc_566  -1
    order_0_15  connected_order_arc_568  -1
    order_0_15  connected_order_arc_570  -1
    order_0_15  connected_order_arc_572  -1
    order_0_15  connected_order_arc_574  -1
    order_0_15  connected_order_arc_576  -1
    order_0_15  connected_order_arc_593  1
    order_0_15  connected_order_arc_616  1
    order_0_15  connected_order_arc_639  1
    order_0_15  connected_order_arc_662  1
    order_0_15  order_active_lb_719  1
    order_0_15  order_active_ub_720  1
    visit_0_16  out_degree_723  -1
    visit_0_16  in_degree_724  -1
    visit_0_16  order_active_lb_725  -1
    visit_0_16  order_active_ub_726  -12
    visit_0_16  service_visit_def_727  -1
    order_0_16  connected_order_arc_409  1
    order_0_16  connected_order_arc_432  1
    order_0_16  connected_order_arc_455  1
    order_0_16  connected_order_arc_478  1
    order_0_16  connected_order_arc_501  1
    order_0_16  connected_order_arc_524  1
    order_0_16  connected_order_arc_547  1
    order_0_16  connected_order_arc_570  1
    order_0_16  connected_order_arc_579  -1
    order_0_16  connected_order_arc_581  -1
    order_0_16  connected_order_arc_583  -1
    order_0_16  connected_order_arc_585  -1
    order_0_16  connected_order_arc_587  -1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_591  -1
    order_0_16  connected_order_arc_593  -1
    order_0_16  connected_order_arc_595  -1
    order_0_16  connected_order_arc_597  -1
    order_0_16  connected_order_arc_599  -1
    order_0_16  connected_order_arc_618  1
    order_0_16  connected_order_arc_641  1
    order_0_16  connected_order_arc_664  1
    order_0_16  order_active_lb_725  1
    order_0_16  order_active_ub_726  1
    visit_0_17  out_degree_729  -1
    visit_0_17  in_degree_730  -1
    visit_0_17  order_active_lb_731  -1
    visit_0_17  order_active_ub_732  -12
    visit_0_17  service_visit_def_733  -1
    order_0_17  connected_order_arc_411  1
    order_0_17  connected_order_arc_434  1
    order_0_17  connected_order_arc_457  1
    order_0_17  connected_order_arc_480  1
    order_0_17  connected_order_arc_503  1
    order_0_17  connected_order_arc_526  1
    order_0_17  connected_order_arc_549  1
    order_0_17  connected_order_arc_572  1
    order_0_17  connected_order_arc_595  1
    order_0_17  connected_order_arc_602  -1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_606  -1
    order_0_17  connected_order_arc_608  -1
    order_0_17  connected_order_arc_610  -1
    order_0_17  connected_order_arc_612  -1
    order_0_17  connected_order_arc_614  -1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_618  -1
    order_0_17  connected_order_arc_620  -1
    order_0_17  connected_order_arc_622  -1
    order_0_17  connected_order_arc_643  1
    order_0_17  connected_order_arc_666  1
    order_0_17  order_active_lb_731  1
    order_0_17  order_active_ub_732  1
    visit_0_18  out_degree_735  -1
    visit_0_18  in_degree_736  -1
    visit_0_18  order_active_lb_737  -1
    visit_0_18  order_active_ub_738  -12
    visit_0_18  service_visit_def_739  -1
    order_0_18  connected_order_arc_413  1
    order_0_18  connected_order_arc_436  1
    order_0_18  connected_order_arc_459  1
    order_0_18  connected_order_arc_482  1
    order_0_18  connected_order_arc_505  1
    order_0_18  connected_order_arc_528  1
    order_0_18  connected_order_arc_551  1
    order_0_18  connected_order_arc_574  1
    order_0_18  connected_order_arc_597  1
    order_0_18  connected_order_arc_620  1
    order_0_18  connected_order_arc_625  -1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_633  -1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_637  -1
    order_0_18  connected_order_arc_639  -1
    order_0_18  connected_order_arc_641  -1
    order_0_18  connected_order_arc_643  -1
    order_0_18  connected_order_arc_645  -1
    order_0_18  connected_order_arc_668  1
    order_0_18  order_active_lb_737  1
    order_0_18  order_active_ub_738  1
    visit_0_19  out_degree_741  -1
    visit_0_19  in_degree_742  -1
    visit_0_19  order_active_lb_743  -1
    visit_0_19  order_active_ub_744  -12
    visit_0_19  service_visit_def_745  -1
    order_0_19  connected_order_arc_415  1
    order_0_19  connected_order_arc_438  1
    order_0_19  connected_order_arc_461  1
    order_0_19  connected_order_arc_484  1
    order_0_19  connected_order_arc_507  1
    order_0_19  connected_order_arc_530  1
    order_0_19  connected_order_arc_553  1
    order_0_19  connected_order_arc_576  1
    order_0_19  connected_order_arc_599  1
    order_0_19  connected_order_arc_622  1
    order_0_19  connected_order_arc_645  1
    order_0_19  connected_order_arc_648  -1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_662  -1
    order_0_19  connected_order_arc_664  -1
    order_0_19  connected_order_arc_666  -1
    order_0_19  connected_order_arc_668  -1
    order_0_19  order_active_lb_743  1
    order_0_19  order_active_ub_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_380  -20
    arc_0_0_0  depot_departure_or_bypass_669  1
    arc_0_0_0  depot_return_or_bypass_670  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_380  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_381  -20
    arc_0_0_1  depot_departure_or_bypass_669  1
    arc_0_0_1  in_degree_672  1
    arc_0_0_1  original_T_including_depot_unload_750  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_381  1
    load_0_0_1  segment_load_conservation_675  -1
    load_0_0_1  segment_prefix_lb_676  1
    load_0_0_1  segment_prefix_ub_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_382  -20
    arc_0_0_2  depot_departure_or_bypass_669  1
    arc_0_0_2  in_degree_679  1
    arc_0_0_2  original_T_including_depot_unload_750  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_382  1
    load_0_0_2  segment_load_conservation_682  -1
    load_0_0_2  segment_prefix_lb_683  1
    load_0_0_2  segment_prefix_ub_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_383  -20
    arc_0_0_3  depot_departure_or_bypass_669  1
    arc_0_0_3  in_degree_686  1
    arc_0_0_3  original_T_including_depot_unload_750  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_383  1
    load_0_0_3  segment_load_conservation_689  -1
    load_0_0_3  segment_prefix_lb_690  1
    load_0_0_3  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_384  -20
    arc_0_0_4  depot_departure_or_bypass_669  1
    arc_0_0_4  in_degree_693  1
    arc_0_0_4  original_T_including_depot_unload_750  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_384  1
    load_0_0_4  segment_load_conservation_696  -1
    load_0_0_4  segment_prefix_lb_697  1
    load_0_0_4  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_385  -20
    arc_0_0_12  depot_departure_or_bypass_669  1
    arc_0_0_12  in_degree_700  1
    arc_0_0_12  original_T_including_depot_unload_750  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_385  1
    load_0_0_12  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_386  -20
    arc_0_0_13  depot_departure_or_bypass_669  1
    arc_0_0_13  in_degree_706  1
    arc_0_0_13  original_T_including_depot_unload_750  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_386  1
    load_0_0_13  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_387  -20
    arc_0_0_14  depot_departure_or_bypass_669  1
    arc_0_0_14  in_degree_712  1
    arc_0_0_14  original_T_including_depot_unload_750  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_387  1
    load_0_0_14  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_388  -20
    arc_0_0_15  depot_departure_or_bypass_669  1
    arc_0_0_15  in_degree_718  1
    arc_0_0_15  original_T_including_depot_unload_750  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_388  1
    load_0_0_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_389  -20
    arc_0_0_16  depot_departure_or_bypass_669  1
    arc_0_0_16  in_degree_724  1
    arc_0_0_16  original_T_including_depot_unload_750  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_389  1
    load_0_0_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_390  -20
    arc_0_0_17  depot_departure_or_bypass_669  1
    arc_0_0_17  in_degree_730  1
    arc_0_0_17  original_T_including_depot_unload_750  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_390  1
    load_0_0_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_391  -20
    arc_0_0_18  depot_departure_or_bypass_669  1
    arc_0_0_18  in_degree_736  1
    arc_0_0_18  original_T_including_depot_unload_750  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_391  1
    load_0_0_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_392  -20
    arc_0_0_19  depot_departure_or_bypass_669  1
    arc_0_0_19  in_degree_742  1
    arc_0_0_19  original_T_including_depot_unload_750  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_392  1
    load_0_0_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_393  -20
    arc_0_1_0  depot_return_or_bypass_670  1
    arc_0_1_0  out_degree_671  1
    arc_0_1_0  original_T_including_depot_unload_750  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_393  1
    load_0_1_0  segment_load_conservation_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_394  -20
    arc_0_1_2  connected_order_arc_395  -13
    arc_0_1_2  out_degree_671  1
    arc_0_1_2  in_degree_679  1
    arc_0_1_2  original_T_including_depot_unload_750  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_394  1
    load_0_1_2  segment_load_conservation_675  1
    load_0_1_2  segment_load_conservation_682  -1
    load_0_1_2  segment_prefix_lb_683  1
    load_0_1_2  segment_prefix_ub_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_396  -20
    arc_0_1_3  connected_order_arc_397  -13
    arc_0_1_3  out_degree_671  1
    arc_0_1_3  in_degree_686  1
    arc_0_1_3  original_T_including_depot_unload_750  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_396  1
    load_0_1_3  segment_load_conservation_675  1
    load_0_1_3  segment_load_conservation_689  -1
    load_0_1_3  segment_prefix_lb_690  1
    load_0_1_3  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_398  -20
    arc_0_1_4  connected_order_arc_399  -13
    arc_0_1_4  out_degree_671  1
    arc_0_1_4  in_degree_693  1
    arc_0_1_4  original_T_including_depot_unload_750  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_398  1
    load_0_1_4  segment_load_conservation_675  1
    load_0_1_4  segment_load_conservation_696  -1
    load_0_1_4  segment_prefix_lb_697  1
    load_0_1_4  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_400  -20
    arc_0_1_12  connected_order_arc_401  -13
    arc_0_1_12  out_degree_671  1
    arc_0_1_12  in_degree_700  1
    arc_0_1_12  original_T_including_depot_unload_750  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_400  1
    load_0_1_12  segment_load_conservation_675  1
    load_0_1_12  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_402  -20
    arc_0_1_13  connected_order_arc_403  -13
    arc_0_1_13  out_degree_671  1
    arc_0_1_13  in_degree_706  1
    arc_0_1_13  original_T_including_depot_unload_750  1.7224091675467555e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_402  1
    load_0_1_13  segment_load_conservation_675  1
    load_0_1_13  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_404  -20
    arc_0_1_14  connected_order_arc_405  -13
    arc_0_1_14  out_degree_671  1
    arc_0_1_14  in_degree_712  1
    arc_0_1_14  original_T_including_depot_unload_750  2.0332430776353604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_404  1
    load_0_1_14  segment_load_conservation_675  1
    load_0_1_14  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_406  -20
    arc_0_1_15  connected_order_arc_407  -13
    arc_0_1_15  out_degree_671  1
    arc_0_1_15  in_degree_718  1
    arc_0_1_15  original_T_including_depot_unload_750  1.7489516402613351e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_406  1
    load_0_1_15  segment_load_conservation_675  1
    load_0_1_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_408  -20
    arc_0_1_16  connected_order_arc_409  -13
    arc_0_1_16  out_degree_671  1
    arc_0_1_16  in_degree_724  1
    arc_0_1_16  original_T_including_depot_unload_750  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_408  1
    load_0_1_16  segment_load_conservation_675  1
    load_0_1_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_410  -20
    arc_0_1_17  connected_order_arc_411  -13
    arc_0_1_17  out_degree_671  1
    arc_0_1_17  in_degree_730  1
    arc_0_1_17  original_T_including_depot_unload_750  9.9507040584540334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_410  1
    load_0_1_17  segment_load_conservation_675  1
    load_0_1_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_412  -20
    arc_0_1_18  connected_order_arc_413  -13
    arc_0_1_18  out_degree_671  1
    arc_0_1_18  in_degree_736  1
    arc_0_1_18  original_T_including_depot_unload_750  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_412  1
    load_0_1_18  segment_load_conservation_675  1
    load_0_1_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_414  -20
    arc_0_1_19  connected_order_arc_415  -13
    arc_0_1_19  out_degree_671  1
    arc_0_1_19  in_degree_742  1
    arc_0_1_19  original_T_including_depot_unload_750  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_414  1
    load_0_1_19  segment_load_conservation_675  1
    load_0_1_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_416  -20
    arc_0_2_0  depot_return_or_bypass_670  1
    arc_0_2_0  out_degree_678  1
    arc_0_2_0  original_T_including_depot_unload_750  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_416  1
    load_0_2_0  segment_load_conservation_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_417  -20
    arc_0_2_1  connected_order_arc_418  -13
    arc_0_2_1  in_degree_672  1
    arc_0_2_1  out_degree_678  1
    arc_0_2_1  original_T_including_depot_unload_750  4.9495118393852869e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_417  1
    load_0_2_1  segment_load_conservation_675  -1
    load_0_2_1  segment_prefix_lb_676  1
    load_0_2_1  segment_prefix_ub_677  1
    load_0_2_1  segment_load_conservation_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_419  -20
    arc_0_2_3  connected_order_arc_420  -13
    arc_0_2_3  out_degree_678  1
    arc_0_2_3  in_degree_686  1
    arc_0_2_3  original_T_including_depot_unload_750  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_419  1
    load_0_2_3  segment_load_conservation_682  1
    load_0_2_3  segment_load_conservation_689  -1
    load_0_2_3  segment_prefix_lb_690  1
    load_0_2_3  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_421  -20
    arc_0_2_4  connected_order_arc_422  -13
    arc_0_2_4  out_degree_678  1
    arc_0_2_4  in_degree_693  1
    arc_0_2_4  original_T_including_depot_unload_750  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_421  1
    load_0_2_4  segment_load_conservation_682  1
    load_0_2_4  segment_load_conservation_696  -1
    load_0_2_4  segment_prefix_lb_697  1
    load_0_2_4  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_423  -20
    arc_0_2_12  connected_order_arc_424  -13
    arc_0_2_12  out_degree_678  1
    arc_0_2_12  in_degree_700  1
    arc_0_2_12  original_T_including_depot_unload_750  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_423  1
    load_0_2_12  segment_load_conservation_682  1
    load_0_2_12  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_425  -20
    arc_0_2_13  connected_order_arc_426  -13
    arc_0_2_13  out_degree_678  1
    arc_0_2_13  in_degree_706  1
    arc_0_2_13  original_T_including_depot_unload_750  1.5387417148054021e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_425  1
    load_0_2_13  segment_load_conservation_682  1
    load_0_2_13  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_427  -20
    arc_0_2_14  connected_order_arc_428  -13
    arc_0_2_14  out_degree_678  1
    arc_0_2_14  in_degree_712  1
    arc_0_2_14  original_T_including_depot_unload_750  1.9263039852699487e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_427  1
    load_0_2_14  segment_load_conservation_682  1
    load_0_2_14  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_429  -20
    arc_0_2_15  connected_order_arc_430  -13
    arc_0_2_15  out_degree_678  1
    arc_0_2_15  in_degree_718  1
    arc_0_2_15  original_T_including_depot_unload_750  1.5771716839165504e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_429  1
    load_0_2_15  segment_load_conservation_682  1
    load_0_2_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_431  -20
    arc_0_2_16  connected_order_arc_432  -13
    arc_0_2_16  out_degree_678  1
    arc_0_2_16  in_degree_724  1
    arc_0_2_16  original_T_including_depot_unload_750  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_431  1
    load_0_2_16  segment_load_conservation_682  1
    load_0_2_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_433  -20
    arc_0_2_17  connected_order_arc_434  -13
    arc_0_2_17  out_degree_678  1
    arc_0_2_17  in_degree_730  1
    arc_0_2_17  original_T_including_depot_unload_750  8.0582548325956611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_433  1
    load_0_2_17  segment_load_conservation_682  1
    load_0_2_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_435  -20
    arc_0_2_18  connected_order_arc_436  -13
    arc_0_2_18  out_degree_678  1
    arc_0_2_18  in_degree_736  1
    arc_0_2_18  original_T_including_depot_unload_750  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_435  1
    load_0_2_18  segment_load_conservation_682  1
    load_0_2_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_437  -20
    arc_0_2_19  connected_order_arc_438  -13
    arc_0_2_19  out_degree_678  1
    arc_0_2_19  in_degree_742  1
    arc_0_2_19  original_T_including_depot_unload_750  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_437  1
    load_0_2_19  segment_load_conservation_682  1
    load_0_2_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_439  -20
    arc_0_3_0  depot_return_or_bypass_670  1
    arc_0_3_0  out_degree_685  1
    arc_0_3_0  original_T_including_depot_unload_750  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_439  1
    load_0_3_0  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_440  -20
    arc_0_3_1  connected_order_arc_441  -13
    arc_0_3_1  in_degree_672  1
    arc_0_3_1  out_degree_685  1
    arc_0_3_1  original_T_including_depot_unload_750  6.7806925965469873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_440  1
    load_0_3_1  segment_load_conservation_675  -1
    load_0_3_1  segment_prefix_lb_676  1
    load_0_3_1  segment_prefix_ub_677  1
    load_0_3_1  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_442  -20
    arc_0_3_2  connected_order_arc_443  -13
    arc_0_3_2  in_degree_679  1
    arc_0_3_2  out_degree_685  1
    arc_0_3_2  original_T_including_depot_unload_750  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_442  1
    load_0_3_2  segment_load_conservation_682  -1
    load_0_3_2  segment_prefix_lb_683  1
    load_0_3_2  segment_prefix_ub_684  1
    load_0_3_2  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_444  -20
    arc_0_3_4  connected_order_arc_445  -13
    arc_0_3_4  out_degree_685  1
    arc_0_3_4  in_degree_693  1
    arc_0_3_4  original_T_including_depot_unload_750  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_444  1
    load_0_3_4  segment_load_conservation_689  1
    load_0_3_4  segment_load_conservation_696  -1
    load_0_3_4  segment_prefix_lb_697  1
    load_0_3_4  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_446  -20
    arc_0_3_12  connected_order_arc_447  -13
    arc_0_3_12  out_degree_685  1
    arc_0_3_12  in_degree_700  1
    arc_0_3_12  original_T_including_depot_unload_750  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_446  1
    load_0_3_12  segment_load_conservation_689  1
    load_0_3_12  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_448  -20
    arc_0_3_13  connected_order_arc_449  -13
    arc_0_3_13  out_degree_685  1
    arc_0_3_13  in_degree_706  1
    arc_0_3_13  original_T_including_depot_unload_750  1.3451277357129768e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_448  1
    load_0_3_13  segment_load_conservation_689  1
    load_0_3_13  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_450  -20
    arc_0_3_14  connected_order_arc_451  -13
    arc_0_3_14  out_degree_685  1
    arc_0_3_14  in_degree_712  1
    arc_0_3_14  original_T_including_depot_unload_750  1.7740294865208371e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_450  1
    load_0_3_14  segment_load_conservation_689  1
    load_0_3_14  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_452  -20
    arc_0_3_15  connected_order_arc_453  -13
    arc_0_3_15  out_degree_685  1
    arc_0_3_15  in_degree_718  1
    arc_0_3_15  original_T_including_depot_unload_750  1.3859443171734331e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_452  1
    load_0_3_15  segment_load_conservation_689  1
    load_0_3_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_454  -20
    arc_0_3_16  connected_order_arc_455  -13
    arc_0_3_16  out_degree_685  1
    arc_0_3_16  in_degree_724  1
    arc_0_3_16  original_T_including_depot_unload_750  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_454  1
    load_0_3_16  segment_load_conservation_689  1
    load_0_3_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_456  -20
    arc_0_3_17  connected_order_arc_457  -13
    arc_0_3_17  out_degree_685  1
    arc_0_3_17  in_degree_730  1
    arc_0_3_17  original_T_including_depot_unload_750  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_456  1
    load_0_3_17  segment_load_conservation_689  1
    load_0_3_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_458  -20
    arc_0_3_18  connected_order_arc_459  -13
    arc_0_3_18  out_degree_685  1
    arc_0_3_18  in_degree_736  1
    arc_0_3_18  original_T_including_depot_unload_750  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_458  1
    load_0_3_18  segment_load_conservation_689  1
    load_0_3_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_460  -20
    arc_0_3_19  connected_order_arc_461  -13
    arc_0_3_19  out_degree_685  1
    arc_0_3_19  in_degree_742  1
    arc_0_3_19  original_T_including_depot_unload_750  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_460  1
    load_0_3_19  segment_load_conservation_689  1
    load_0_3_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_462  -20
    arc_0_4_0  depot_return_or_bypass_670  1
    arc_0_4_0  out_degree_692  1
    arc_0_4_0  original_T_including_depot_unload_750  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_462  1
    load_0_4_0  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_463  -20
    arc_0_4_1  connected_order_arc_464  -13
    arc_0_4_1  in_degree_672  1
    arc_0_4_1  out_degree_692  1
    arc_0_4_1  original_T_including_depot_unload_750  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_463  1
    load_0_4_1  segment_load_conservation_675  -1
    load_0_4_1  segment_prefix_lb_676  1
    load_0_4_1  segment_prefix_ub_677  1
    load_0_4_1  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_465  -20
    arc_0_4_2  connected_order_arc_466  -13
    arc_0_4_2  in_degree_679  1
    arc_0_4_2  out_degree_692  1
    arc_0_4_2  original_T_including_depot_unload_750  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_465  1
    load_0_4_2  segment_load_conservation_682  -1
    load_0_4_2  segment_prefix_lb_683  1
    load_0_4_2  segment_prefix_ub_684  1
    load_0_4_2  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_467  -20
    arc_0_4_3  connected_order_arc_468  -13
    arc_0_4_3  in_degree_686  1
    arc_0_4_3  out_degree_692  1
    arc_0_4_3  original_T_including_depot_unload_750  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_467  1
    load_0_4_3  segment_load_conservation_689  -1
    load_0_4_3  segment_prefix_lb_690  1
    load_0_4_3  segment_prefix_ub_691  1
    load_0_4_3  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_469  -20
    arc_0_4_12  connected_order_arc_470  -13
    arc_0_4_12  out_degree_692  1
    arc_0_4_12  in_degree_700  1
    arc_0_4_12  original_T_including_depot_unload_750  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_469  1
    load_0_4_12  segment_load_conservation_696  1
    load_0_4_12  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_471  -20
    arc_0_4_13  connected_order_arc_472  -13
    arc_0_4_13  out_degree_692  1
    arc_0_4_13  in_degree_706  1
    arc_0_4_13  original_T_including_depot_unload_750  1.2401143998876444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_471  1
    load_0_4_13  segment_load_conservation_696  1
    load_0_4_13  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_473  -20
    arc_0_4_14  connected_order_arc_474  -13
    arc_0_4_14  out_degree_692  1
    arc_0_4_14  in_degree_712  1
    arc_0_4_14  original_T_including_depot_unload_750  1.6849162169783858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_473  1
    load_0_4_14  segment_load_conservation_696  1
    load_0_4_14  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_475  -20
    arc_0_4_15  connected_order_arc_476  -13
    arc_0_4_15  out_degree_692  1
    arc_0_4_15  in_degree_718  1
    arc_0_4_15  original_T_including_depot_unload_750  1.2799228371310815e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_475  1
    load_0_4_15  segment_load_conservation_696  1
    load_0_4_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_477  -20
    arc_0_4_16  connected_order_arc_478  -13
    arc_0_4_16  out_degree_692  1
    arc_0_4_16  in_degree_724  1
    arc_0_4_16  original_T_including_depot_unload_750  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_477  1
    load_0_4_16  segment_load_conservation_696  1
    load_0_4_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_479  -20
    arc_0_4_17  connected_order_arc_480  -13
    arc_0_4_17  out_degree_692  1
    arc_0_4_17  in_degree_730  1
    arc_0_4_17  original_T_including_depot_unload_750  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_479  1
    load_0_4_17  segment_load_conservation_696  1
    load_0_4_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_481  -20
    arc_0_4_18  connected_order_arc_482  -13
    arc_0_4_18  out_degree_692  1
    arc_0_4_18  in_degree_736  1
    arc_0_4_18  original_T_including_depot_unload_750  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_481  1
    load_0_4_18  segment_load_conservation_696  1
    load_0_4_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_483  -20
    arc_0_4_19  connected_order_arc_484  -13
    arc_0_4_19  out_degree_692  1
    arc_0_4_19  in_degree_742  1
    arc_0_4_19  original_T_including_depot_unload_750  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_483  1
    load_0_4_19  segment_load_conservation_696  1
    load_0_4_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_485  -20
    arc_0_12_0  depot_return_or_bypass_670  1
    arc_0_12_0  out_degree_699  1
    arc_0_12_0  original_T_including_depot_unload_750  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_485  1
    load_0_12_0  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_486  -20
    arc_0_12_1  connected_order_arc_487  -13
    arc_0_12_1  in_degree_672  1
    arc_0_12_1  out_degree_699  1
    arc_0_12_1  original_T_including_depot_unload_750  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_486  1
    load_0_12_1  segment_load_conservation_675  -1
    load_0_12_1  segment_prefix_lb_676  1
    load_0_12_1  segment_prefix_ub_677  1
    load_0_12_1  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_488  -20
    arc_0_12_2  connected_order_arc_489  -13
    arc_0_12_2  in_degree_679  1
    arc_0_12_2  out_degree_699  1
    arc_0_12_2  original_T_including_depot_unload_750  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_488  1
    load_0_12_2  segment_load_conservation_682  -1
    load_0_12_2  segment_prefix_lb_683  1
    load_0_12_2  segment_prefix_ub_684  1
    load_0_12_2  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_490  -20
    arc_0_12_3  connected_order_arc_491  -13
    arc_0_12_3  in_degree_686  1
    arc_0_12_3  out_degree_699  1
    arc_0_12_3  original_T_including_depot_unload_750  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_490  1
    load_0_12_3  segment_load_conservation_689  -1
    load_0_12_3  segment_prefix_lb_690  1
    load_0_12_3  segment_prefix_ub_691  1
    load_0_12_3  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_492  -20
    arc_0_12_4  connected_order_arc_493  -13
    arc_0_12_4  in_degree_693  1
    arc_0_12_4  out_degree_699  1
    arc_0_12_4  original_T_including_depot_unload_750  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_492  1
    load_0_12_4  segment_load_conservation_696  -1
    load_0_12_4  segment_prefix_lb_697  1
    load_0_12_4  segment_prefix_ub_698  1
    load_0_12_4  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_494  -20
    arc_0_12_13  connected_order_arc_495  -13
    arc_0_12_13  out_degree_699  1
    arc_0_12_13  in_degree_706  1
    arc_0_12_13  original_T_including_depot_unload_750  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_494  1
    load_0_12_13  free_load_conservation_704  1
    load_0_12_13  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_496  -20
    arc_0_12_14  connected_order_arc_497  -13
    arc_0_12_14  out_degree_699  1
    arc_0_12_14  in_degree_712  1
    arc_0_12_14  original_T_including_depot_unload_750  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_496  1
    load_0_12_14  free_load_conservation_704  1
    load_0_12_14  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_498  -20
    arc_0_12_15  connected_order_arc_499  -13
    arc_0_12_15  out_degree_699  1
    arc_0_12_15  in_degree_718  1
    arc_0_12_15  original_T_including_depot_unload_750  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_498  1
    load_0_12_15  free_load_conservation_704  1
    load_0_12_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_500  -20
    arc_0_12_16  connected_order_arc_501  -13
    arc_0_12_16  out_degree_699  1
    arc_0_12_16  in_degree_724  1
    arc_0_12_16  original_T_including_depot_unload_750  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_500  1
    load_0_12_16  free_load_conservation_704  1
    load_0_12_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_502  -20
    arc_0_12_17  connected_order_arc_503  -13
    arc_0_12_17  out_degree_699  1
    arc_0_12_17  in_degree_730  1
    arc_0_12_17  original_T_including_depot_unload_750  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_502  1
    load_0_12_17  free_load_conservation_704  1
    load_0_12_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_504  -20
    arc_0_12_18  connected_order_arc_505  -13
    arc_0_12_18  out_degree_699  1
    arc_0_12_18  in_degree_736  1
    arc_0_12_18  original_T_including_depot_unload_750  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_504  1
    load_0_12_18  free_load_conservation_704  1
    load_0_12_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_506  -20
    arc_0_12_19  connected_order_arc_507  -13
    arc_0_12_19  out_degree_699  1
    arc_0_12_19  in_degree_742  1
    arc_0_12_19  original_T_including_depot_unload_750  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_506  1
    load_0_12_19  free_load_conservation_704  1
    load_0_12_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_508  -20
    arc_0_13_0  depot_return_or_bypass_670  1
    arc_0_13_0  out_degree_705  1
    arc_0_13_0  original_T_including_depot_unload_750  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_508  1
    load_0_13_0  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_509  -20
    arc_0_13_1  connected_order_arc_510  -13
    arc_0_13_1  in_degree_672  1
    arc_0_13_1  out_degree_705  1
    arc_0_13_1  original_T_including_depot_unload_750  2.0045579804597039e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_509  1
    load_0_13_1  segment_load_conservation_675  -1
    load_0_13_1  segment_prefix_lb_676  1
    load_0_13_1  segment_prefix_ub_677  1
    load_0_13_1  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_511  -20
    arc_0_13_2  connected_order_arc_512  -13
    arc_0_13_2  in_degree_679  1
    arc_0_13_2  out_degree_705  1
    arc_0_13_2  original_T_including_depot_unload_750  1.5412757472294663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_511  1
    load_0_13_2  segment_load_conservation_682  -1
    load_0_13_2  segment_prefix_lb_683  1
    load_0_13_2  segment_prefix_ub_684  1
    load_0_13_2  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_513  -20
    arc_0_13_3  connected_order_arc_514  -13
    arc_0_13_3  in_degree_686  1
    arc_0_13_3  out_degree_705  1
    arc_0_13_3  original_T_including_depot_unload_750  1.3451277357129768e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_513  1
    load_0_13_3  segment_load_conservation_689  -1
    load_0_13_3  segment_prefix_lb_690  1
    load_0_13_3  segment_prefix_ub_691  1
    load_0_13_3  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_515  -20
    arc_0_13_4  connected_order_arc_516  -13
    arc_0_13_4  in_degree_693  1
    arc_0_13_4  out_degree_705  1
    arc_0_13_4  original_T_including_depot_unload_750  1.2401143998876444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_515  1
    load_0_13_4  segment_load_conservation_696  -1
    load_0_13_4  segment_prefix_lb_697  1
    load_0_13_4  segment_prefix_ub_698  1
    load_0_13_4  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_517  -20
    arc_0_13_12  connected_order_arc_518  -13
    arc_0_13_12  in_degree_700  1
    arc_0_13_12  out_degree_705  1
    arc_0_13_12  original_T_including_depot_unload_750  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_517  1
    load_0_13_12  free_load_conservation_704  -1
    load_0_13_12  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_519  -20
    arc_0_13_14  connected_order_arc_520  -13
    arc_0_13_14  out_degree_705  1
    arc_0_13_14  in_degree_712  1
    arc_0_13_14  original_T_including_depot_unload_750  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_519  1
    load_0_13_14  free_load_conservation_710  1
    load_0_13_14  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_521  -20
    arc_0_13_15  connected_order_arc_522  -13
    arc_0_13_15  out_degree_705  1
    arc_0_13_15  in_degree_718  1
    arc_0_13_15  original_T_including_depot_unload_750  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_521  1
    load_0_13_15  free_load_conservation_710  1
    load_0_13_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_523  -20
    arc_0_13_16  connected_order_arc_524  -13
    arc_0_13_16  out_degree_705  1
    arc_0_13_16  in_degree_724  1
    arc_0_13_16  original_T_including_depot_unload_750  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_523  1
    load_0_13_16  free_load_conservation_710  1
    load_0_13_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_525  -20
    arc_0_13_17  connected_order_arc_526  -13
    arc_0_13_17  out_degree_705  1
    arc_0_13_17  in_degree_730  1
    arc_0_13_17  original_T_including_depot_unload_750  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_525  1
    load_0_13_17  free_load_conservation_710  1
    load_0_13_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_527  -20
    arc_0_13_18  connected_order_arc_528  -13
    arc_0_13_18  out_degree_705  1
    arc_0_13_18  in_degree_736  1
    arc_0_13_18  original_T_including_depot_unload_750  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_527  1
    load_0_13_18  free_load_conservation_710  1
    load_0_13_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_529  -20
    arc_0_13_19  connected_order_arc_530  -13
    arc_0_13_19  out_degree_705  1
    arc_0_13_19  in_degree_742  1
    arc_0_13_19  original_T_including_depot_unload_750  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_529  1
    load_0_13_19  free_load_conservation_710  1
    load_0_13_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_531  -20
    arc_0_14_0  depot_return_or_bypass_670  1
    arc_0_14_0  out_degree_711  1
    arc_0_14_0  original_T_including_depot_unload_750  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_531  1
    load_0_14_0  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_532  -20
    arc_0_14_1  connected_order_arc_533  -13
    arc_0_14_1  in_degree_672  1
    arc_0_14_1  out_degree_711  1
    arc_0_14_1  original_T_including_depot_unload_750  2.2244039731678959e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_532  1
    load_0_14_1  segment_load_conservation_675  -1
    load_0_14_1  segment_prefix_lb_676  1
    load_0_14_1  segment_prefix_ub_677  1
    load_0_14_1  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_534  -20
    arc_0_14_2  connected_order_arc_535  -13
    arc_0_14_2  in_degree_679  1
    arc_0_14_2  out_degree_711  1
    arc_0_14_2  original_T_including_depot_unload_750  1.9286914187809364e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_534  1
    load_0_14_2  segment_load_conservation_682  -1
    load_0_14_2  segment_prefix_lb_683  1
    load_0_14_2  segment_prefix_ub_684  1
    load_0_14_2  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_536  -20
    arc_0_14_3  connected_order_arc_537  -13
    arc_0_14_3  in_degree_686  1
    arc_0_14_3  out_degree_711  1
    arc_0_14_3  original_T_including_depot_unload_750  1.7740294865208371e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_536  1
    load_0_14_3  segment_load_conservation_689  -1
    load_0_14_3  segment_prefix_lb_690  1
    load_0_14_3  segment_prefix_ub_691  1
    load_0_14_3  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_538  -20
    arc_0_14_4  connected_order_arc_539  -13
    arc_0_14_4  in_degree_693  1
    arc_0_14_4  out_degree_711  1
    arc_0_14_4  original_T_including_depot_unload_750  1.6849162169783858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_538  1
    load_0_14_4  segment_load_conservation_696  -1
    load_0_14_4  segment_prefix_lb_697  1
    load_0_14_4  segment_prefix_ub_698  1
    load_0_14_4  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_540  -20
    arc_0_14_12  connected_order_arc_541  -13
    arc_0_14_12  in_degree_700  1
    arc_0_14_12  out_degree_711  1
    arc_0_14_12  original_T_including_depot_unload_750  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_540  1
    load_0_14_12  free_load_conservation_704  -1
    load_0_14_12  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_542  -20
    arc_0_14_13  connected_order_arc_543  -13
    arc_0_14_13  in_degree_706  1
    arc_0_14_13  out_degree_711  1
    arc_0_14_13  original_T_including_depot_unload_750  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_542  1
    load_0_14_13  free_load_conservation_710  -1
    load_0_14_13  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_544  -20
    arc_0_14_15  connected_order_arc_545  -13
    arc_0_14_15  out_degree_711  1
    arc_0_14_15  in_degree_718  1
    arc_0_14_15  original_T_including_depot_unload_750  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_544  1
    load_0_14_15  free_load_conservation_716  1
    load_0_14_15  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_546  -20
    arc_0_14_16  connected_order_arc_547  -13
    arc_0_14_16  out_degree_711  1
    arc_0_14_16  in_degree_724  1
    arc_0_14_16  original_T_including_depot_unload_750  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_546  1
    load_0_14_16  free_load_conservation_716  1
    load_0_14_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_548  -20
    arc_0_14_17  connected_order_arc_549  -13
    arc_0_14_17  out_degree_711  1
    arc_0_14_17  in_degree_730  1
    arc_0_14_17  original_T_including_depot_unload_750  1.4068884127351855e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_548  1
    load_0_14_17  free_load_conservation_716  1
    load_0_14_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_550  -20
    arc_0_14_18  connected_order_arc_551  -13
    arc_0_14_18  out_degree_711  1
    arc_0_14_18  in_degree_736  1
    arc_0_14_18  original_T_including_depot_unload_750  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_550  1
    load_0_14_18  free_load_conservation_716  1
    load_0_14_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_552  -20
    arc_0_14_19  connected_order_arc_553  -13
    arc_0_14_19  out_degree_711  1
    arc_0_14_19  in_degree_742  1
    arc_0_14_19  original_T_including_depot_unload_750  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_552  1
    load_0_14_19  free_load_conservation_716  1
    load_0_14_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_554  -20
    arc_0_15_0  depot_return_or_bypass_670  1
    arc_0_15_0  out_degree_717  1
    arc_0_15_0  original_T_including_depot_unload_750  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_554  1
    load_0_15_0  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_555  -20
    arc_0_15_1  connected_order_arc_556  -13
    arc_0_15_1  in_degree_672  1
    arc_0_15_1  out_degree_717  1
    arc_0_15_1  original_T_including_depot_unload_750  2.0184394615116689e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_555  1
    load_0_15_1  segment_load_conservation_675  -1
    load_0_15_1  segment_prefix_lb_676  1
    load_0_15_1  segment_prefix_ub_677  1
    load_0_15_1  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_557  -20
    arc_0_15_2  connected_order_arc_558  -13
    arc_0_15_2  in_degree_679  1
    arc_0_15_2  out_degree_717  1
    arc_0_15_2  original_T_including_depot_unload_750  1.5797610153191811e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_557  1
    load_0_15_2  segment_load_conservation_682  -1
    load_0_15_2  segment_prefix_lb_683  1
    load_0_15_2  segment_prefix_ub_684  1
    load_0_15_2  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_559  -20
    arc_0_15_3  connected_order_arc_560  -13
    arc_0_15_3  in_degree_686  1
    arc_0_15_3  out_degree_717  1
    arc_0_15_3  original_T_including_depot_unload_750  1.3859443171734331e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_559  1
    load_0_15_3  segment_load_conservation_689  -1
    load_0_15_3  segment_prefix_lb_690  1
    load_0_15_3  segment_prefix_ub_691  1
    load_0_15_3  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_561  -20
    arc_0_15_4  connected_order_arc_562  -13
    arc_0_15_4  in_degree_693  1
    arc_0_15_4  out_degree_717  1
    arc_0_15_4  original_T_including_depot_unload_750  1.2799228371310815e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_561  1
    load_0_15_4  segment_load_conservation_696  -1
    load_0_15_4  segment_prefix_lb_697  1
    load_0_15_4  segment_prefix_ub_698  1
    load_0_15_4  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_563  -20
    arc_0_15_12  connected_order_arc_564  -13
    arc_0_15_12  in_degree_700  1
    arc_0_15_12  out_degree_717  1
    arc_0_15_12  original_T_including_depot_unload_750  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_563  1
    load_0_15_12  free_load_conservation_704  -1
    load_0_15_12  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_565  -20
    arc_0_15_13  connected_order_arc_566  -13
    arc_0_15_13  in_degree_706  1
    arc_0_15_13  out_degree_717  1
    arc_0_15_13  original_T_including_depot_unload_750  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_565  1
    load_0_15_13  free_load_conservation_710  -1
    load_0_15_13  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_567  -20
    arc_0_15_14  connected_order_arc_568  -13
    arc_0_15_14  in_degree_712  1
    arc_0_15_14  out_degree_717  1
    arc_0_15_14  original_T_including_depot_unload_750  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_567  1
    load_0_15_14  free_load_conservation_716  -1
    load_0_15_14  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_569  -20
    arc_0_15_16  connected_order_arc_570  -13
    arc_0_15_16  out_degree_717  1
    arc_0_15_16  in_degree_724  1
    arc_0_15_16  original_T_including_depot_unload_750  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_569  1
    load_0_15_16  free_load_conservation_722  1
    load_0_15_16  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_571  -20
    arc_0_15_17  connected_order_arc_572  -13
    arc_0_15_17  out_degree_717  1
    arc_0_15_17  in_degree_730  1
    arc_0_15_17  original_T_including_depot_unload_750  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_571  1
    load_0_15_17  free_load_conservation_722  1
    load_0_15_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_573  -20
    arc_0_15_18  connected_order_arc_574  -13
    arc_0_15_18  out_degree_717  1
    arc_0_15_18  in_degree_736  1
    arc_0_15_18  original_T_including_depot_unload_750  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_573  1
    load_0_15_18  free_load_conservation_722  1
    load_0_15_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_575  -20
    arc_0_15_19  connected_order_arc_576  -13
    arc_0_15_19  out_degree_717  1
    arc_0_15_19  in_degree_742  1
    arc_0_15_19  original_T_including_depot_unload_750  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_575  1
    load_0_15_19  free_load_conservation_722  1
    load_0_15_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_577  -20
    arc_0_16_0  depot_return_or_bypass_670  1
    arc_0_16_0  out_degree_723  1
    arc_0_16_0  original_T_including_depot_unload_750  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_577  1
    load_0_16_0  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_578  -20
    arc_0_16_1  connected_order_arc_579  -13
    arc_0_16_1  in_degree_672  1
    arc_0_16_1  out_degree_723  1
    arc_0_16_1  original_T_including_depot_unload_750  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_578  1
    load_0_16_1  segment_load_conservation_675  -1
    load_0_16_1  segment_prefix_lb_676  1
    load_0_16_1  segment_prefix_ub_677  1
    load_0_16_1  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_580  -20
    arc_0_16_2  connected_order_arc_581  -13
    arc_0_16_2  in_degree_679  1
    arc_0_16_2  out_degree_723  1
    arc_0_16_2  original_T_including_depot_unload_750  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_580  1
    load_0_16_2  segment_load_conservation_682  -1
    load_0_16_2  segment_prefix_lb_683  1
    load_0_16_2  segment_prefix_ub_684  1
    load_0_16_2  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_582  -20
    arc_0_16_3  connected_order_arc_583  -13
    arc_0_16_3  in_degree_686  1
    arc_0_16_3  out_degree_723  1
    arc_0_16_3  original_T_including_depot_unload_750  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_582  1
    load_0_16_3  segment_load_conservation_689  -1
    load_0_16_3  segment_prefix_lb_690  1
    load_0_16_3  segment_prefix_ub_691  1
    load_0_16_3  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_584  -20
    arc_0_16_4  connected_order_arc_585  -13
    arc_0_16_4  in_degree_693  1
    arc_0_16_4  out_degree_723  1
    arc_0_16_4  original_T_including_depot_unload_750  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_584  1
    load_0_16_4  segment_load_conservation_696  -1
    load_0_16_4  segment_prefix_lb_697  1
    load_0_16_4  segment_prefix_ub_698  1
    load_0_16_4  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_586  -20
    arc_0_16_12  connected_order_arc_587  -13
    arc_0_16_12  in_degree_700  1
    arc_0_16_12  out_degree_723  1
    arc_0_16_12  original_T_including_depot_unload_750  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_586  1
    load_0_16_12  free_load_conservation_704  -1
    load_0_16_12  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_588  -20
    arc_0_16_13  connected_order_arc_589  -13
    arc_0_16_13  in_degree_706  1
    arc_0_16_13  out_degree_723  1
    arc_0_16_13  original_T_including_depot_unload_750  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_588  1
    load_0_16_13  free_load_conservation_710  -1
    load_0_16_13  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_590  -20
    arc_0_16_14  connected_order_arc_591  -13
    arc_0_16_14  in_degree_712  1
    arc_0_16_14  out_degree_723  1
    arc_0_16_14  original_T_including_depot_unload_750  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_590  1
    load_0_16_14  free_load_conservation_716  -1
    load_0_16_14  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_592  -20
    arc_0_16_15  connected_order_arc_593  -13
    arc_0_16_15  in_degree_718  1
    arc_0_16_15  out_degree_723  1
    arc_0_16_15  original_T_including_depot_unload_750  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_592  1
    load_0_16_15  free_load_conservation_722  -1
    load_0_16_15  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_594  -20
    arc_0_16_17  connected_order_arc_595  -13
    arc_0_16_17  out_degree_723  1
    arc_0_16_17  in_degree_730  1
    arc_0_16_17  original_T_including_depot_unload_750  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_594  1
    load_0_16_17  free_load_conservation_728  1
    load_0_16_17  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_596  -20
    arc_0_16_18  connected_order_arc_597  -13
    arc_0_16_18  out_degree_723  1
    arc_0_16_18  in_degree_736  1
    arc_0_16_18  original_T_including_depot_unload_750  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_596  1
    load_0_16_18  free_load_conservation_728  1
    load_0_16_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_598  -20
    arc_0_16_19  connected_order_arc_599  -13
    arc_0_16_19  out_degree_723  1
    arc_0_16_19  in_degree_742  1
    arc_0_16_19  original_T_including_depot_unload_750  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_598  1
    load_0_16_19  free_load_conservation_728  1
    load_0_16_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_600  -20
    arc_0_17_0  depot_return_or_bypass_670  1
    arc_0_17_0  out_degree_729  1
    arc_0_17_0  original_T_including_depot_unload_750  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_600  1
    load_0_17_0  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_601  -20
    arc_0_17_1  connected_order_arc_602  -13
    arc_0_17_1  in_degree_672  1
    arc_0_17_1  out_degree_729  1
    arc_0_17_1  original_T_including_depot_unload_750  1.2844696003118074e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_601  1
    load_0_17_1  segment_load_conservation_675  -1
    load_0_17_1  segment_prefix_lb_676  1
    load_0_17_1  segment_prefix_ub_677  1
    load_0_17_1  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_603  -20
    arc_0_17_2  connected_order_arc_604  -13
    arc_0_17_2  in_degree_679  1
    arc_0_17_2  out_degree_729  1
    arc_0_17_2  original_T_including_depot_unload_750  8.0831419223632781e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_603  1
    load_0_17_2  segment_load_conservation_682  -1
    load_0_17_2  segment_prefix_lb_683  1
    load_0_17_2  segment_prefix_ub_684  1
    load_0_17_2  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_605  -20
    arc_0_17_3  connected_order_arc_606  -13
    arc_0_17_3  in_degree_686  1
    arc_0_17_3  out_degree_729  1
    arc_0_17_3  original_T_including_depot_unload_750  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_605  1
    load_0_17_3  segment_load_conservation_689  -1
    load_0_17_3  segment_prefix_lb_690  1
    load_0_17_3  segment_prefix_ub_691  1
    load_0_17_3  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_607  -20
    arc_0_17_4  connected_order_arc_608  -13
    arc_0_17_4  in_degree_693  1
    arc_0_17_4  out_degree_729  1
    arc_0_17_4  original_T_including_depot_unload_750  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_607  1
    load_0_17_4  segment_load_conservation_696  -1
    load_0_17_4  segment_prefix_lb_697  1
    load_0_17_4  segment_prefix_ub_698  1
    load_0_17_4  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_609  -20
    arc_0_17_12  connected_order_arc_610  -13
    arc_0_17_12  in_degree_700  1
    arc_0_17_12  out_degree_729  1
    arc_0_17_12  original_T_including_depot_unload_750  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_609  1
    load_0_17_12  free_load_conservation_704  -1
    load_0_17_12  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_611  -20
    arc_0_17_13  connected_order_arc_612  -13
    arc_0_17_13  in_degree_706  1
    arc_0_17_13  out_degree_729  1
    arc_0_17_13  original_T_including_depot_unload_750  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_611  1
    load_0_17_13  free_load_conservation_710  -1
    load_0_17_13  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_613  -20
    arc_0_17_14  connected_order_arc_614  -13
    arc_0_17_14  in_degree_712  1
    arc_0_17_14  out_degree_729  1
    arc_0_17_14  original_T_including_depot_unload_750  1.4068884127351855e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_613  1
    load_0_17_14  free_load_conservation_716  -1
    load_0_17_14  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_615  -20
    arc_0_17_15  connected_order_arc_616  -13
    arc_0_17_15  in_degree_718  1
    arc_0_17_15  out_degree_729  1
    arc_0_17_15  original_T_including_depot_unload_750  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_615  1
    load_0_17_15  free_load_conservation_722  -1
    load_0_17_15  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_617  -20
    arc_0_17_16  connected_order_arc_618  -13
    arc_0_17_16  in_degree_724  1
    arc_0_17_16  out_degree_729  1
    arc_0_17_16  original_T_including_depot_unload_750  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_617  1
    load_0_17_16  free_load_conservation_728  -1
    load_0_17_16  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_619  -20
    arc_0_17_18  connected_order_arc_620  -13
    arc_0_17_18  out_degree_729  1
    arc_0_17_18  in_degree_736  1
    arc_0_17_18  original_T_including_depot_unload_750  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_619  1
    load_0_17_18  free_load_conservation_734  1
    load_0_17_18  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_621  -20
    arc_0_17_19  connected_order_arc_622  -13
    arc_0_17_19  out_degree_729  1
    arc_0_17_19  in_degree_742  1
    arc_0_17_19  original_T_including_depot_unload_750  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_621  1
    load_0_17_19  free_load_conservation_734  1
    load_0_17_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_623  -20
    arc_0_18_0  depot_return_or_bypass_670  1
    arc_0_18_0  out_degree_735  1
    arc_0_18_0  original_T_including_depot_unload_750  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_623  1
    load_0_18_0  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_624  -20
    arc_0_18_1  connected_order_arc_625  -13
    arc_0_18_1  in_degree_672  1
    arc_0_18_1  out_degree_735  1
    arc_0_18_1  original_T_including_depot_unload_750  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_624  1
    load_0_18_1  segment_load_conservation_675  -1
    load_0_18_1  segment_prefix_lb_676  1
    load_0_18_1  segment_prefix_ub_677  1
    load_0_18_1  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_626  -20
    arc_0_18_2  connected_order_arc_627  -13
    arc_0_18_2  in_degree_679  1
    arc_0_18_2  out_degree_735  1
    arc_0_18_2  original_T_including_depot_unload_750  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_626  1
    load_0_18_2  segment_load_conservation_682  -1
    load_0_18_2  segment_prefix_lb_683  1
    load_0_18_2  segment_prefix_ub_684  1
    load_0_18_2  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_628  -20
    arc_0_18_3  connected_order_arc_629  -13
    arc_0_18_3  in_degree_686  1
    arc_0_18_3  out_degree_735  1
    arc_0_18_3  original_T_including_depot_unload_750  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_628  1
    load_0_18_3  segment_load_conservation_689  -1
    load_0_18_3  segment_prefix_lb_690  1
    load_0_18_3  segment_prefix_ub_691  1
    load_0_18_3  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_630  -20
    arc_0_18_4  connected_order_arc_631  -13
    arc_0_18_4  in_degree_693  1
    arc_0_18_4  out_degree_735  1
    arc_0_18_4  original_T_including_depot_unload_750  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_630  1
    load_0_18_4  segment_load_conservation_696  -1
    load_0_18_4  segment_prefix_lb_697  1
    load_0_18_4  segment_prefix_ub_698  1
    load_0_18_4  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_632  -20
    arc_0_18_12  connected_order_arc_633  -13
    arc_0_18_12  in_degree_700  1
    arc_0_18_12  out_degree_735  1
    arc_0_18_12  original_T_including_depot_unload_750  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_632  1
    load_0_18_12  free_load_conservation_704  -1
    load_0_18_12  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_634  -20
    arc_0_18_13  connected_order_arc_635  -13
    arc_0_18_13  in_degree_706  1
    arc_0_18_13  out_degree_735  1
    arc_0_18_13  original_T_including_depot_unload_750  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_634  1
    load_0_18_13  free_load_conservation_710  -1
    load_0_18_13  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_636  -20
    arc_0_18_14  connected_order_arc_637  -13
    arc_0_18_14  in_degree_712  1
    arc_0_18_14  out_degree_735  1
    arc_0_18_14  original_T_including_depot_unload_750  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_636  1
    load_0_18_14  free_load_conservation_716  -1
    load_0_18_14  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_638  -20
    arc_0_18_15  connected_order_arc_639  -13
    arc_0_18_15  in_degree_718  1
    arc_0_18_15  out_degree_735  1
    arc_0_18_15  original_T_including_depot_unload_750  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_638  1
    load_0_18_15  free_load_conservation_722  -1
    load_0_18_15  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_640  -20
    arc_0_18_16  connected_order_arc_641  -13
    arc_0_18_16  in_degree_724  1
    arc_0_18_16  out_degree_735  1
    arc_0_18_16  original_T_including_depot_unload_750  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_640  1
    load_0_18_16  free_load_conservation_728  -1
    load_0_18_16  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_642  -20
    arc_0_18_17  connected_order_arc_643  -13
    arc_0_18_17  in_degree_730  1
    arc_0_18_17  out_degree_735  1
    arc_0_18_17  original_T_including_depot_unload_750  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_642  1
    load_0_18_17  free_load_conservation_734  -1
    load_0_18_17  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_644  -20
    arc_0_18_19  connected_order_arc_645  -13
    arc_0_18_19  out_degree_735  1
    arc_0_18_19  in_degree_742  1
    arc_0_18_19  original_T_including_depot_unload_750  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_644  1
    load_0_18_19  free_load_conservation_740  1
    load_0_18_19  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_646  -20
    arc_0_19_0  depot_return_or_bypass_670  1
    arc_0_19_0  out_degree_741  1
    arc_0_19_0  original_T_including_depot_unload_750  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_646  1
    load_0_19_0  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_647  -20
    arc_0_19_1  connected_order_arc_648  -13
    arc_0_19_1  in_degree_672  1
    arc_0_19_1  out_degree_741  1
    arc_0_19_1  original_T_including_depot_unload_750  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_647  1
    load_0_19_1  segment_load_conservation_675  -1
    load_0_19_1  segment_prefix_lb_676  1
    load_0_19_1  segment_prefix_ub_677  1
    load_0_19_1  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_649  -20
    arc_0_19_2  connected_order_arc_650  -13
    arc_0_19_2  in_degree_679  1
    arc_0_19_2  out_degree_741  1
    arc_0_19_2  original_T_including_depot_unload_750  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_649  1
    load_0_19_2  segment_load_conservation_682  -1
    load_0_19_2  segment_prefix_lb_683  1
    load_0_19_2  segment_prefix_ub_684  1
    load_0_19_2  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_651  -20
    arc_0_19_3  connected_order_arc_652  -13
    arc_0_19_3  in_degree_686  1
    arc_0_19_3  out_degree_741  1
    arc_0_19_3  original_T_including_depot_unload_750  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_651  1
    load_0_19_3  segment_load_conservation_689  -1
    load_0_19_3  segment_prefix_lb_690  1
    load_0_19_3  segment_prefix_ub_691  1
    load_0_19_3  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_653  -20
    arc_0_19_4  connected_order_arc_654  -13
    arc_0_19_4  in_degree_693  1
    arc_0_19_4  out_degree_741  1
    arc_0_19_4  original_T_including_depot_unload_750  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_653  1
    load_0_19_4  segment_load_conservation_696  -1
    load_0_19_4  segment_prefix_lb_697  1
    load_0_19_4  segment_prefix_ub_698  1
    load_0_19_4  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_655  -20
    arc_0_19_12  connected_order_arc_656  -13
    arc_0_19_12  in_degree_700  1
    arc_0_19_12  out_degree_741  1
    arc_0_19_12  original_T_including_depot_unload_750  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_655  1
    load_0_19_12  free_load_conservation_704  -1
    load_0_19_12  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_657  -20
    arc_0_19_13  connected_order_arc_658  -13
    arc_0_19_13  in_degree_706  1
    arc_0_19_13  out_degree_741  1
    arc_0_19_13  original_T_including_depot_unload_750  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_657  1
    load_0_19_13  free_load_conservation_710  -1
    load_0_19_13  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_659  -20
    arc_0_19_14  connected_order_arc_660  -13
    arc_0_19_14  in_degree_712  1
    arc_0_19_14  out_degree_741  1
    arc_0_19_14  original_T_including_depot_unload_750  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_659  1
    load_0_19_14  free_load_conservation_716  -1
    load_0_19_14  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_661  -20
    arc_0_19_15  connected_order_arc_662  -13
    arc_0_19_15  in_degree_718  1
    arc_0_19_15  out_degree_741  1
    arc_0_19_15  original_T_including_depot_unload_750  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_661  1
    load_0_19_15  free_load_conservation_722  -1
    load_0_19_15  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_663  -20
    arc_0_19_16  connected_order_arc_664  -13
    arc_0_19_16  in_degree_724  1
    arc_0_19_16  out_degree_741  1
    arc_0_19_16  original_T_including_depot_unload_750  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_663  1
    load_0_19_16  free_load_conservation_728  -1
    load_0_19_16  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_665  -20
    arc_0_19_17  connected_order_arc_666  -13
    arc_0_19_17  in_degree_730  1
    arc_0_19_17  out_degree_741  1
    arc_0_19_17  original_T_including_depot_unload_750  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_665  1
    load_0_19_17  free_load_conservation_734  -1
    load_0_19_17  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_667  -20
    arc_0_19_18  connected_order_arc_668  -13
    arc_0_19_18  in_degree_736  1
    arc_0_19_18  out_degree_741  1
    arc_0_19_18  original_T_including_depot_unload_750  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_667  1
    load_0_19_18  free_load_conservation_740  -1
    load_0_19_18  free_load_conservation_746  1
    visit_1_5  out_degree_1042  -1
    visit_1_5  in_degree_1043  -1
    visit_1_5  order_active_lb_1044  -1
    visit_1_5  order_active_ub_1045  -12
    order_1_5  connected_order_arc_766  -1
    order_1_5  connected_order_arc_768  -1
    order_1_5  connected_order_arc_770  -1
    order_1_5  connected_order_arc_772  -1
    order_1_5  connected_order_arc_774  -1
    order_1_5  connected_order_arc_776  -1
    order_1_5  connected_order_arc_778  -1
    order_1_5  connected_order_arc_780  -1
    order_1_5  connected_order_arc_782  -1
    order_1_5  connected_order_arc_784  -1
    order_1_5  connected_order_arc_786  -1
    order_1_5  connected_order_arc_789  1
    order_1_5  connected_order_arc_812  1
    order_1_5  connected_order_arc_835  1
    order_1_5  connected_order_arc_858  1
    order_1_5  connected_order_arc_881  1
    order_1_5  connected_order_arc_904  1
    order_1_5  connected_order_arc_927  1
    order_1_5  connected_order_arc_950  1
    order_1_5  connected_order_arc_973  1
    order_1_5  connected_order_arc_996  1
    order_1_5  connected_order_arc_1019  1
    order_1_5  order_active_lb_1044  1
    order_1_5  order_active_ub_1045  1
    order_1_5  fixed_segment_relative_order_1118  -1
    visit_1_6  out_degree_1049  -1
    visit_1_6  in_degree_1050  -1
    visit_1_6  order_active_lb_1051  -1
    visit_1_6  order_active_ub_1052  -12
    order_1_6  connected_order_arc_766  1
    order_1_6  connected_order_arc_789  -1
    order_1_6  connected_order_arc_791  -1
    order_1_6  connected_order_arc_793  -1
    order_1_6  connected_order_arc_795  -1
    order_1_6  connected_order_arc_797  -1
    order_1_6  connected_order_arc_799  -1
    order_1_6  connected_order_arc_801  -1
    order_1_6  connected_order_arc_803  -1
    order_1_6  connected_order_arc_805  -1
    order_1_6  connected_order_arc_807  -1
    order_1_6  connected_order_arc_809  -1
    order_1_6  connected_order_arc_814  1
    order_1_6  connected_order_arc_837  1
    order_1_6  connected_order_arc_860  1
    order_1_6  connected_order_arc_883  1
    order_1_6  connected_order_arc_906  1
    order_1_6  connected_order_arc_929  1
    order_1_6  connected_order_arc_952  1
    order_1_6  connected_order_arc_975  1
    order_1_6  connected_order_arc_998  1
    order_1_6  connected_order_arc_1021  1
    order_1_6  order_active_lb_1051  1
    order_1_6  order_active_ub_1052  1
    order_1_6  fixed_segment_relative_order_1118  1
    order_1_6  fixed_segment_relative_order_1119  -1
    visit_1_7  out_degree_1056  -1
    visit_1_7  in_degree_1057  -1
    visit_1_7  order_active_lb_1058  -1
    visit_1_7  order_active_ub_1059  -12
    order_1_7  connected_order_arc_768  1
    order_1_7  connected_order_arc_791  1
    order_1_7  connected_order_arc_812  -1
    order_1_7  connected_order_arc_814  -1
    order_1_7  connected_order_arc_816  -1
    order_1_7  connected_order_arc_818  -1
    order_1_7  connected_order_arc_820  -1
    order_1_7  connected_order_arc_822  -1
    order_1_7  connected_order_arc_824  -1
    order_1_7  connected_order_arc_826  -1
    order_1_7  connected_order_arc_828  -1
    order_1_7  connected_order_arc_830  -1
    order_1_7  connected_order_arc_832  -1
    order_1_7  connected_order_arc_839  1
    order_1_7  connected_order_arc_862  1
    order_1_7  connected_order_arc_885  1
    order_1_7  connected_order_arc_908  1
    order_1_7  connected_order_arc_931  1
    order_1_7  connected_order_arc_954  1
    order_1_7  connected_order_arc_977  1
    order_1_7  connected_order_arc_1000  1
    order_1_7  connected_order_arc_1023  1
    order_1_7  order_active_lb_1058  1
    order_1_7  order_active_ub_1059  1
    order_1_7  fixed_segment_relative_order_1119  1
    order_1_7  fixed_segment_relative_order_1120  -1
    visit_1_8  out_degree_1063  -1
    visit_1_8  in_degree_1064  -1
    visit_1_8  order_active_lb_1065  -1
    visit_1_8  order_active_ub_1066  -12
    order_1_8  connected_order_arc_770  1
    order_1_8  connected_order_arc_793  1
    order_1_8  connected_order_arc_816  1
    order_1_8  connected_order_arc_835  -1
    order_1_8  connected_order_arc_837  -1
    order_1_8  connected_order_arc_839  -1
    order_1_8  connected_order_arc_841  -1
    order_1_8  connected_order_arc_843  -1
    order_1_8  connected_order_arc_845  -1
    order_1_8  connected_order_arc_847  -1
    order_1_8  connected_order_arc_849  -1
    order_1_8  connected_order_arc_851  -1
    order_1_8  connected_order_arc_853  -1
    order_1_8  connected_order_arc_855  -1
    order_1_8  connected_order_arc_864  1
    order_1_8  connected_order_arc_887  1
    order_1_8  connected_order_arc_910  1
    order_1_8  connected_order_arc_933  1
    order_1_8  connected_order_arc_956  1
    order_1_8  connected_order_arc_979  1
    order_1_8  connected_order_arc_1002  1
    order_1_8  connected_order_arc_1025  1
    order_1_8  order_active_lb_1065  1
    order_1_8  order_active_ub_1066  1
    order_1_8  fixed_segment_relative_order_1120  1
    visit_1_12  out_degree_1070  -1
    visit_1_12  in_degree_1071  -1
    visit_1_12  order_active_lb_1072  -1
    visit_1_12  order_active_ub_1073  -12
    visit_1_12  service_visit_def_1074  -1
    order_1_12  connected_order_arc_772  1
    order_1_12  connected_order_arc_795  1
    order_1_12  connected_order_arc_818  1
    order_1_12  connected_order_arc_841  1
    order_1_12  connected_order_arc_858  -1
    order_1_12  connected_order_arc_860  -1
    order_1_12  connected_order_arc_862  -1
    order_1_12  connected_order_arc_864  -1
    order_1_12  connected_order_arc_866  -1
    order_1_12  connected_order_arc_868  -1
    order_1_12  connected_order_arc_870  -1
    order_1_12  connected_order_arc_872  -1
    order_1_12  connected_order_arc_874  -1
    order_1_12  connected_order_arc_876  -1
    order_1_12  connected_order_arc_878  -1
    order_1_12  connected_order_arc_889  1
    order_1_12  connected_order_arc_912  1
    order_1_12  connected_order_arc_935  1
    order_1_12  connected_order_arc_958  1
    order_1_12  connected_order_arc_981  1
    order_1_12  connected_order_arc_1004  1
    order_1_12  connected_order_arc_1027  1
    order_1_12  order_active_lb_1072  1
    order_1_12  order_active_ub_1073  1
    visit_1_13  out_degree_1076  -1
    visit_1_13  in_degree_1077  -1
    visit_1_13  order_active_lb_1078  -1
    visit_1_13  order_active_ub_1079  -12
    visit_1_13  service_visit_def_1080  -1
    order_1_13  connected_order_arc_774  1
    order_1_13  connected_order_arc_797  1
    order_1_13  connected_order_arc_820  1
    order_1_13  connected_order_arc_843  1
    order_1_13  connected_order_arc_866  1
    order_1_13  connected_order_arc_881  -1
    order_1_13  connected_order_arc_883  -1
    order_1_13  connected_order_arc_885  -1
    order_1_13  connected_order_arc_887  -1
    order_1_13  connected_order_arc_889  -1
    order_1_13  connected_order_arc_891  -1
    order_1_13  connected_order_arc_893  -1
    order_1_13  connected_order_arc_895  -1
    order_1_13  connected_order_arc_897  -1
    order_1_13  connected_order_arc_899  -1
    order_1_13  connected_order_arc_901  -1
    order_1_13  connected_order_arc_914  1
    order_1_13  connected_order_arc_937  1
    order_1_13  connected_order_arc_960  1
    order_1_13  connected_order_arc_983  1
    order_1_13  connected_order_arc_1006  1
    order_1_13  connected_order_arc_1029  1
    order_1_13  order_active_lb_1078  1
    order_1_13  order_active_ub_1079  1
    visit_1_14  out_degree_1082  -1
    visit_1_14  in_degree_1083  -1
    visit_1_14  order_active_lb_1084  -1
    visit_1_14  order_active_ub_1085  -12
    visit_1_14  service_visit_def_1086  -1
    order_1_14  connected_order_arc_776  1
    order_1_14  connected_order_arc_799  1
    order_1_14  connected_order_arc_822  1
    order_1_14  connected_order_arc_845  1
    order_1_14  connected_order_arc_868  1
    order_1_14  connected_order_arc_891  1
    order_1_14  connected_order_arc_904  -1
    order_1_14  connected_order_arc_906  -1
    order_1_14  connected_order_arc_908  -1
    order_1_14  connected_order_arc_910  -1
    order_1_14  connected_order_arc_912  -1
    order_1_14  connected_order_arc_914  -1
    order_1_14  connected_order_arc_916  -1
    order_1_14  connected_order_arc_918  -1
    order_1_14  connected_order_arc_920  -1
    order_1_14  connected_order_arc_922  -1
    order_1_14  connected_order_arc_924  -1
    order_1_14  connected_order_arc_939  1
    order_1_14  connected_order_arc_962  1
    order_1_14  connected_order_arc_985  1
    order_1_14  connected_order_arc_1008  1
    order_1_14  connected_order_arc_1031  1
    order_1_14  order_active_lb_1084  1
    order_1_14  order_active_ub_1085  1
    visit_1_15  out_degree_1088  -1
    visit_1_15  in_degree_1089  -1
    visit_1_15  order_active_lb_1090  -1
    visit_1_15  order_active_ub_1091  -12
    visit_1_15  service_visit_def_1092  -1
    order_1_15  connected_order_arc_778  1
    order_1_15  connected_order_arc_801  1
    order_1_15  connected_order_arc_824  1
    order_1_15  connected_order_arc_847  1
    order_1_15  connected_order_arc_870  1
    order_1_15  connected_order_arc_893  1
    order_1_15  connected_order_arc_916  1
    order_1_15  connected_order_arc_927  -1
    order_1_15  connected_order_arc_929  -1
    order_1_15  connected_order_arc_931  -1
    order_1_15  connected_order_arc_933  -1
    order_1_15  connected_order_arc_935  -1
    order_1_15  connected_order_arc_937  -1
    order_1_15  connected_order_arc_939  -1
    order_1_15  connected_order_arc_941  -1
    order_1_15  connected_order_arc_943  -1
    order_1_15  connected_order_arc_945  -1
    order_1_15  connected_order_arc_947  -1
    order_1_15  connected_order_arc_964  1
    order_1_15  connected_order_arc_987  1
    order_1_15  connected_order_arc_1010  1
    order_1_15  connected_order_arc_1033  1
    order_1_15  order_active_lb_1090  1
    order_1_15  order_active_ub_1091  1
    visit_1_16  out_degree_1094  -1
    visit_1_16  in_degree_1095  -1
    visit_1_16  order_active_lb_1096  -1
    visit_1_16  order_active_ub_1097  -12
    visit_1_16  service_visit_def_1098  -1
    order_1_16  connected_order_arc_780  1
    order_1_16  connected_order_arc_803  1
    order_1_16  connected_order_arc_826  1
    order_1_16  connected_order_arc_849  1
    order_1_16  connected_order_arc_872  1
    order_1_16  connected_order_arc_895  1
    order_1_16  connected_order_arc_918  1
    order_1_16  connected_order_arc_941  1
    order_1_16  connected_order_arc_950  -1
    order_1_16  connected_order_arc_952  -1
    order_1_16  connected_order_arc_954  -1
    order_1_16  connected_order_arc_956  -1
    order_1_16  connected_order_arc_958  -1
    order_1_16  connected_order_arc_960  -1
    order_1_16  connected_order_arc_962  -1
    order_1_16  connected_order_arc_964  -1
    order_1_16  connected_order_arc_966  -1
    order_1_16  connected_order_arc_968  -1
    order_1_16  connected_order_arc_970  -1
    order_1_16  connected_order_arc_989  1
    order_1_16  connected_order_arc_1012  1
    order_1_16  connected_order_arc_1035  1
    order_1_16  order_active_lb_1096  1
    order_1_16  order_active_ub_1097  1
    visit_1_17  out_degree_1100  -1
    visit_1_17  in_degree_1101  -1
    visit_1_17  order_active_lb_1102  -1
    visit_1_17  order_active_ub_1103  -12
    visit_1_17  service_visit_def_1104  -1
    order_1_17  connected_order_arc_782  1
    order_1_17  connected_order_arc_805  1
    order_1_17  connected_order_arc_828  1
    order_1_17  connected_order_arc_851  1
    order_1_17  connected_order_arc_874  1
    order_1_17  connected_order_arc_897  1
    order_1_17  connected_order_arc_920  1
    order_1_17  connected_order_arc_943  1
    order_1_17  connected_order_arc_966  1
    order_1_17  connected_order_arc_973  -1
    order_1_17  connected_order_arc_975  -1
    order_1_17  connected_order_arc_977  -1
    order_1_17  connected_order_arc_979  -1
    order_1_17  connected_order_arc_981  -1
    order_1_17  connected_order_arc_983  -1
    order_1_17  connected_order_arc_985  -1
    order_1_17  connected_order_arc_987  -1
    order_1_17  connected_order_arc_989  -1
    order_1_17  connected_order_arc_991  -1
    order_1_17  connected_order_arc_993  -1
    order_1_17  connected_order_arc_1014  1
    order_1_17  connected_order_arc_1037  1
    order_1_17  order_active_lb_1102  1
    order_1_17  order_active_ub_1103  1
    visit_1_18  out_degree_1106  -1
    visit_1_18  in_degree_1107  -1
    visit_1_18  order_active_lb_1108  -1
    visit_1_18  order_active_ub_1109  -12
    visit_1_18  service_visit_def_1110  -1
    order_1_18  connected_order_arc_784  1
    order_1_18  connected_order_arc_807  1
    order_1_18  connected_order_arc_830  1
    order_1_18  connected_order_arc_853  1
    order_1_18  connected_order_arc_876  1
    order_1_18  connected_order_arc_899  1
    order_1_18  connected_order_arc_922  1
    order_1_18  connected_order_arc_945  1
    order_1_18  connected_order_arc_968  1
    order_1_18  connected_order_arc_991  1
    order_1_18  connected_order_arc_996  -1
    order_1_18  connected_order_arc_998  -1
    order_1_18  connected_order_arc_1000  -1
    order_1_18  connected_order_arc_1002  -1
    order_1_18  connected_order_arc_1004  -1
    order_1_18  connected_order_arc_1006  -1
    order_1_18  connected_order_arc_1008  -1
    order_1_18  connected_order_arc_1010  -1
    order_1_18  connected_order_arc_1012  -1
    order_1_18  connected_order_arc_1014  -1
    order_1_18  connected_order_arc_1016  -1
    order_1_18  connected_order_arc_1039  1
    order_1_18  order_active_lb_1108  1
    order_1_18  order_active_ub_1109  1
    visit_1_19  out_degree_1112  -1
    visit_1_19  in_degree_1113  -1
    visit_1_19  order_active_lb_1114  -1
    visit_1_19  order_active_ub_1115  -12
    visit_1_19  service_visit_def_1116  -1
    order_1_19  connected_order_arc_786  1
    order_1_19  connected_order_arc_809  1
    order_1_19  connected_order_arc_832  1
    order_1_19  connected_order_arc_855  1
    order_1_19  connected_order_arc_878  1
    order_1_19  connected_order_arc_901  1
    order_1_19  connected_order_arc_924  1
    order_1_19  connected_order_arc_947  1
    order_1_19  connected_order_arc_970  1
    order_1_19  connected_order_arc_993  1
    order_1_19  connected_order_arc_1016  1
    order_1_19  connected_order_arc_1019  -1
    order_1_19  connected_order_arc_1021  -1
    order_1_19  connected_order_arc_1023  -1
    order_1_19  connected_order_arc_1025  -1
    order_1_19  connected_order_arc_1027  -1
    order_1_19  connected_order_arc_1029  -1
    order_1_19  connected_order_arc_1031  -1
    order_1_19  connected_order_arc_1033  -1
    order_1_19  connected_order_arc_1035  -1
    order_1_19  connected_order_arc_1037  -1
    order_1_19  connected_order_arc_1039  -1
    order_1_19  order_active_lb_1114  1
    order_1_19  order_active_ub_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_751  -25
    arc_1_0_0  depot_departure_or_bypass_1040  1
    arc_1_0_0  depot_return_or_bypass_1041  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_751  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_752  -25
    arc_1_0_5  depot_departure_or_bypass_1040  1
    arc_1_0_5  in_degree_1043  1
    arc_1_0_5  original_T_including_depot_unload_1121  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_752  1
    load_1_0_5  segment_load_conservation_1046  -1
    load_1_0_5  segment_prefix_lb_1047  1
    load_1_0_5  segment_prefix_ub_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_753  -25
    arc_1_0_6  depot_departure_or_bypass_1040  1
    arc_1_0_6  in_degree_1050  1
    arc_1_0_6  original_T_including_depot_unload_1121  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_753  1
    load_1_0_6  segment_load_conservation_1053  -1
    load_1_0_6  segment_prefix_lb_1054  1
    load_1_0_6  segment_prefix_ub_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_754  -25
    arc_1_0_7  depot_departure_or_bypass_1040  1
    arc_1_0_7  in_degree_1057  1
    arc_1_0_7  original_T_including_depot_unload_1121  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_754  1
    load_1_0_7  segment_load_conservation_1060  -1
    load_1_0_7  segment_prefix_lb_1061  1
    load_1_0_7  segment_prefix_ub_1062  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_755  -25
    arc_1_0_8  depot_departure_or_bypass_1040  1
    arc_1_0_8  in_degree_1064  1
    arc_1_0_8  original_T_including_depot_unload_1121  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_755  1
    load_1_0_8  segment_load_conservation_1067  -1
    load_1_0_8  segment_prefix_lb_1068  1
    load_1_0_8  segment_prefix_ub_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_756  -25
    arc_1_0_12  depot_departure_or_bypass_1040  1
    arc_1_0_12  in_degree_1071  1
    arc_1_0_12  original_T_including_depot_unload_1121  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_756  1
    load_1_0_12  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_757  -25
    arc_1_0_13  depot_departure_or_bypass_1040  1
    arc_1_0_13  in_degree_1077  1
    arc_1_0_13  original_T_including_depot_unload_1121  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_757  1
    load_1_0_13  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_758  -25
    arc_1_0_14  depot_departure_or_bypass_1040  1
    arc_1_0_14  in_degree_1083  1
    arc_1_0_14  original_T_including_depot_unload_1121  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_758  1
    load_1_0_14  free_load_conservation_1087  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_759  -25
    arc_1_0_15  depot_departure_or_bypass_1040  1
    arc_1_0_15  in_degree_1089  1
    arc_1_0_15  original_T_including_depot_unload_1121  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_759  1
    load_1_0_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_760  -25
    arc_1_0_16  depot_departure_or_bypass_1040  1
    arc_1_0_16  in_degree_1095  1
    arc_1_0_16  original_T_including_depot_unload_1121  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_760  1
    load_1_0_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_761  -25
    arc_1_0_17  depot_departure_or_bypass_1040  1
    arc_1_0_17  in_degree_1101  1
    arc_1_0_17  original_T_including_depot_unload_1121  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_761  1
    load_1_0_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_762  -25
    arc_1_0_18  depot_departure_or_bypass_1040  1
    arc_1_0_18  in_degree_1107  1
    arc_1_0_18  original_T_including_depot_unload_1121  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_762  1
    load_1_0_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_763  -25
    arc_1_0_19  depot_departure_or_bypass_1040  1
    arc_1_0_19  in_degree_1113  1
    arc_1_0_19  original_T_including_depot_unload_1121  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_763  1
    load_1_0_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_764  -25
    arc_1_5_0  depot_return_or_bypass_1041  1
    arc_1_5_0  out_degree_1042  1
    arc_1_5_0  original_T_including_depot_unload_1121  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_764  1
    load_1_5_0  segment_load_conservation_1046  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_765  -25
    arc_1_5_6  connected_order_arc_766  -13
    arc_1_5_6  out_degree_1042  1
    arc_1_5_6  in_degree_1050  1
    arc_1_5_6  original_T_including_depot_unload_1121  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_765  1
    load_1_5_6  segment_load_conservation_1046  1
    load_1_5_6  segment_load_conservation_1053  -1
    load_1_5_6  segment_prefix_lb_1054  1
    load_1_5_6  segment_prefix_ub_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_767  -25
    arc_1_5_7  connected_order_arc_768  -13
    arc_1_5_7  out_degree_1042  1
    arc_1_5_7  in_degree_1057  1
    arc_1_5_7  original_T_including_depot_unload_1121  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_767  1
    load_1_5_7  segment_load_conservation_1046  1
    load_1_5_7  segment_load_conservation_1060  -1
    load_1_5_7  segment_prefix_lb_1061  1
    load_1_5_7  segment_prefix_ub_1062  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_769  -25
    arc_1_5_8  connected_order_arc_770  -13
    arc_1_5_8  out_degree_1042  1
    arc_1_5_8  in_degree_1064  1
    arc_1_5_8  original_T_including_depot_unload_1121  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_769  1
    load_1_5_8  segment_load_conservation_1046  1
    load_1_5_8  segment_load_conservation_1067  -1
    load_1_5_8  segment_prefix_lb_1068  1
    load_1_5_8  segment_prefix_ub_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_771  -25
    arc_1_5_12  connected_order_arc_772  -13
    arc_1_5_12  out_degree_1042  1
    arc_1_5_12  in_degree_1071  1
    arc_1_5_12  original_T_including_depot_unload_1121  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_771  1
    load_1_5_12  segment_load_conservation_1046  1
    load_1_5_12  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_773  -25
    arc_1_5_13  connected_order_arc_774  -13
    arc_1_5_13  out_degree_1042  1
    arc_1_5_13  in_degree_1077  1
    arc_1_5_13  original_T_including_depot_unload_1121  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_773  1
    load_1_5_13  segment_load_conservation_1046  1
    load_1_5_13  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_775  -25
    arc_1_5_14  connected_order_arc_776  -13
    arc_1_5_14  out_degree_1042  1
    arc_1_5_14  in_degree_1083  1
    arc_1_5_14  original_T_including_depot_unload_1121  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_775  1
    load_1_5_14  segment_load_conservation_1046  1
    load_1_5_14  free_load_conservation_1087  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_777  -25
    arc_1_5_15  connected_order_arc_778  -13
    arc_1_5_15  out_degree_1042  1
    arc_1_5_15  in_degree_1089  1
    arc_1_5_15  original_T_including_depot_unload_1121  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_777  1
    load_1_5_15  segment_load_conservation_1046  1
    load_1_5_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_779  -25
    arc_1_5_16  connected_order_arc_780  -13
    arc_1_5_16  out_degree_1042  1
    arc_1_5_16  in_degree_1095  1
    arc_1_5_16  original_T_including_depot_unload_1121  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_779  1
    load_1_5_16  segment_load_conservation_1046  1
    load_1_5_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_781  -25
    arc_1_5_17  connected_order_arc_782  -13
    arc_1_5_17  out_degree_1042  1
    arc_1_5_17  in_degree_1101  1
    arc_1_5_17  original_T_including_depot_unload_1121  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_781  1
    load_1_5_17  segment_load_conservation_1046  1
    load_1_5_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_783  -25
    arc_1_5_18  connected_order_arc_784  -13
    arc_1_5_18  out_degree_1042  1
    arc_1_5_18  in_degree_1107  1
    arc_1_5_18  original_T_including_depot_unload_1121  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_783  1
    load_1_5_18  segment_load_conservation_1046  1
    load_1_5_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_785  -25
    arc_1_5_19  connected_order_arc_786  -13
    arc_1_5_19  out_degree_1042  1
    arc_1_5_19  in_degree_1113  1
    arc_1_5_19  original_T_including_depot_unload_1121  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_785  1
    load_1_5_19  segment_load_conservation_1046  1
    load_1_5_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_787  -25
    arc_1_6_0  depot_return_or_bypass_1041  1
    arc_1_6_0  out_degree_1049  1
    arc_1_6_0  original_T_including_depot_unload_1121  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_787  1
    load_1_6_0  segment_load_conservation_1053  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_788  -25
    arc_1_6_5  connected_order_arc_789  -13
    arc_1_6_5  in_degree_1043  1
    arc_1_6_5  out_degree_1049  1
    arc_1_6_5  original_T_including_depot_unload_1121  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_788  1
    load_1_6_5  segment_load_conservation_1046  -1
    load_1_6_5  segment_prefix_lb_1047  1
    load_1_6_5  segment_prefix_ub_1048  1
    load_1_6_5  segment_load_conservation_1053  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_790  -25
    arc_1_6_7  connected_order_arc_791  -13
    arc_1_6_7  out_degree_1049  1
    arc_1_6_7  in_degree_1057  1
    arc_1_6_7  original_T_including_depot_unload_1121  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_790  1
    load_1_6_7  segment_load_conservation_1053  1
    load_1_6_7  segment_load_conservation_1060  -1
    load_1_6_7  segment_prefix_lb_1061  1
    load_1_6_7  segment_prefix_ub_1062  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_792  -25
    arc_1_6_8  connected_order_arc_793  -13
    arc_1_6_8  out_degree_1049  1
    arc_1_6_8  in_degree_1064  1
    arc_1_6_8  original_T_including_depot_unload_1121  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_792  1
    load_1_6_8  segment_load_conservation_1053  1
    load_1_6_8  segment_load_conservation_1067  -1
    load_1_6_8  segment_prefix_lb_1068  1
    load_1_6_8  segment_prefix_ub_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_794  -25
    arc_1_6_12  connected_order_arc_795  -13
    arc_1_6_12  out_degree_1049  1
    arc_1_6_12  in_degree_1071  1
    arc_1_6_12  original_T_including_depot_unload_1121  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_794  1
    load_1_6_12  segment_load_conservation_1053  1
    load_1_6_12  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_796  -25
    arc_1_6_13  connected_order_arc_797  -13
    arc_1_6_13  out_degree_1049  1
    arc_1_6_13  in_degree_1077  1
    arc_1_6_13  original_T_including_depot_unload_1121  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_796  1
    load_1_6_13  segment_load_conservation_1053  1
    load_1_6_13  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_798  -25
    arc_1_6_14  connected_order_arc_799  -13
    arc_1_6_14  out_degree_1049  1
    arc_1_6_14  in_degree_1083  1
    arc_1_6_14  original_T_including_depot_unload_1121  2.9939628790517750e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_798  1
    load_1_6_14  segment_load_conservation_1053  1
    load_1_6_14  free_load_conservation_1087  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_800  -25
    arc_1_6_15  connected_order_arc_801  -13
    arc_1_6_15  out_degree_1049  1
    arc_1_6_15  in_degree_1089  1
    arc_1_6_15  original_T_including_depot_unload_1121  2.9006291140474787e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_800  1
    load_1_6_15  segment_load_conservation_1053  1
    load_1_6_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_802  -25
    arc_1_6_16  connected_order_arc_803  -13
    arc_1_6_16  out_degree_1049  1
    arc_1_6_16  in_degree_1095  1
    arc_1_6_16  original_T_including_depot_unload_1121  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_802  1
    load_1_6_16  segment_load_conservation_1053  1
    load_1_6_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_804  -25
    arc_1_6_17  connected_order_arc_805  -13
    arc_1_6_17  out_degree_1049  1
    arc_1_6_17  in_degree_1101  1
    arc_1_6_17  original_T_including_depot_unload_1121  2.1806564621513235e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_804  1
    load_1_6_17  segment_load_conservation_1053  1
    load_1_6_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_806  -25
    arc_1_6_18  connected_order_arc_807  -13
    arc_1_6_18  out_degree_1049  1
    arc_1_6_18  in_degree_1107  1
    arc_1_6_18  original_T_including_depot_unload_1121  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_806  1
    load_1_6_18  segment_load_conservation_1053  1
    load_1_6_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_808  -25
    arc_1_6_19  connected_order_arc_809  -13
    arc_1_6_19  out_degree_1049  1
    arc_1_6_19  in_degree_1113  1
    arc_1_6_19  original_T_including_depot_unload_1121  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_808  1
    load_1_6_19  segment_load_conservation_1053  1
    load_1_6_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_810  -25
    arc_1_7_0  depot_return_or_bypass_1041  1
    arc_1_7_0  out_degree_1056  1
    arc_1_7_0  original_T_including_depot_unload_1121  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_810  1
    load_1_7_0  segment_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_811  -25
    arc_1_7_5  connected_order_arc_812  -13
    arc_1_7_5  in_degree_1043  1
    arc_1_7_5  out_degree_1056  1
    arc_1_7_5  original_T_including_depot_unload_1121  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_811  1
    load_1_7_5  segment_load_conservation_1046  -1
    load_1_7_5  segment_prefix_lb_1047  1
    load_1_7_5  segment_prefix_ub_1048  1
    load_1_7_5  segment_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_813  -25
    arc_1_7_6  connected_order_arc_814  -13
    arc_1_7_6  in_degree_1050  1
    arc_1_7_6  out_degree_1056  1
    arc_1_7_6  original_T_including_depot_unload_1121  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_813  1
    load_1_7_6  segment_load_conservation_1053  -1
    load_1_7_6  segment_prefix_lb_1054  1
    load_1_7_6  segment_prefix_ub_1055  1
    load_1_7_6  segment_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_815  -25
    arc_1_7_8  connected_order_arc_816  -13
    arc_1_7_8  out_degree_1056  1
    arc_1_7_8  in_degree_1064  1
    arc_1_7_8  original_T_including_depot_unload_1121  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_815  1
    load_1_7_8  segment_load_conservation_1060  1
    load_1_7_8  segment_load_conservation_1067  -1
    load_1_7_8  segment_prefix_lb_1068  1
    load_1_7_8  segment_prefix_ub_1069  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_817  -25
    arc_1_7_12  connected_order_arc_818  -13
    arc_1_7_12  out_degree_1056  1
    arc_1_7_12  in_degree_1071  1
    arc_1_7_12  original_T_including_depot_unload_1121  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_817  1
    load_1_7_12  segment_load_conservation_1060  1
    load_1_7_12  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_819  -25
    arc_1_7_13  connected_order_arc_820  -13
    arc_1_7_13  out_degree_1056  1
    arc_1_7_13  in_degree_1077  1
    arc_1_7_13  original_T_including_depot_unload_1121  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_819  1
    load_1_7_13  segment_load_conservation_1060  1
    load_1_7_13  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_821  -25
    arc_1_7_14  connected_order_arc_822  -13
    arc_1_7_14  out_degree_1056  1
    arc_1_7_14  in_degree_1083  1
    arc_1_7_14  original_T_including_depot_unload_1121  2.0264134980919391e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_821  1
    load_1_7_14  segment_load_conservation_1060  1
    load_1_7_14  free_load_conservation_1087  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_823  -25
    arc_1_7_15  connected_order_arc_824  -13
    arc_1_7_15  out_degree_1056  1
    arc_1_7_15  in_degree_1089  1
    arc_1_7_15  original_T_including_depot_unload_1121  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_823  1
    load_1_7_15  segment_load_conservation_1060  1
    load_1_7_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_825  -25
    arc_1_7_16  connected_order_arc_826  -13
    arc_1_7_16  out_degree_1056  1
    arc_1_7_16  in_degree_1095  1
    arc_1_7_16  original_T_including_depot_unload_1121  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_825  1
    load_1_7_16  segment_load_conservation_1060  1
    load_1_7_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_827  -25
    arc_1_7_17  connected_order_arc_828  -13
    arc_1_7_17  out_degree_1056  1
    arc_1_7_17  in_degree_1101  1
    arc_1_7_17  original_T_including_depot_unload_1121  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_827  1
    load_1_7_17  segment_load_conservation_1060  1
    load_1_7_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_829  -25
    arc_1_7_18  connected_order_arc_830  -13
    arc_1_7_18  out_degree_1056  1
    arc_1_7_18  in_degree_1107  1
    arc_1_7_18  original_T_including_depot_unload_1121  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_829  1
    load_1_7_18  segment_load_conservation_1060  1
    load_1_7_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_831  -25
    arc_1_7_19  connected_order_arc_832  -13
    arc_1_7_19  out_degree_1056  1
    arc_1_7_19  in_degree_1113  1
    arc_1_7_19  original_T_including_depot_unload_1121  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_831  1
    load_1_7_19  segment_load_conservation_1060  1
    load_1_7_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_833  -25
    arc_1_8_0  depot_return_or_bypass_1041  1
    arc_1_8_0  out_degree_1063  1
    arc_1_8_0  original_T_including_depot_unload_1121  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_833  1
    load_1_8_0  segment_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_834  -25
    arc_1_8_5  connected_order_arc_835  -13
    arc_1_8_5  in_degree_1043  1
    arc_1_8_5  out_degree_1063  1
    arc_1_8_5  original_T_including_depot_unload_1121  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_834  1
    load_1_8_5  segment_load_conservation_1046  -1
    load_1_8_5  segment_prefix_lb_1047  1
    load_1_8_5  segment_prefix_ub_1048  1
    load_1_8_5  segment_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_836  -25
    arc_1_8_6  connected_order_arc_837  -13
    arc_1_8_6  in_degree_1050  1
    arc_1_8_6  out_degree_1063  1
    arc_1_8_6  original_T_including_depot_unload_1121  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_836  1
    load_1_8_6  segment_load_conservation_1053  -1
    load_1_8_6  segment_prefix_lb_1054  1
    load_1_8_6  segment_prefix_ub_1055  1
    load_1_8_6  segment_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_838  -25
    arc_1_8_7  connected_order_arc_839  -13
    arc_1_8_7  in_degree_1057  1
    arc_1_8_7  out_degree_1063  1
    arc_1_8_7  original_T_including_depot_unload_1121  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_838  1
    load_1_8_7  segment_load_conservation_1060  -1
    load_1_8_7  segment_prefix_lb_1061  1
    load_1_8_7  segment_prefix_ub_1062  1
    load_1_8_7  segment_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_840  -25
    arc_1_8_12  connected_order_arc_841  -13
    arc_1_8_12  out_degree_1063  1
    arc_1_8_12  in_degree_1071  1
    arc_1_8_12  original_T_including_depot_unload_1121  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_840  1
    load_1_8_12  segment_load_conservation_1067  1
    load_1_8_12  free_load_conservation_1075  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_842  -25
    arc_1_8_13  connected_order_arc_843  -13
    arc_1_8_13  out_degree_1063  1
    arc_1_8_13  in_degree_1077  1
    arc_1_8_13  original_T_including_depot_unload_1121  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_842  1
    load_1_8_13  segment_load_conservation_1067  1
    load_1_8_13  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_844  -25
    arc_1_8_14  connected_order_arc_845  -13
    arc_1_8_14  out_degree_1063  1
    arc_1_8_14  in_degree_1083  1
    arc_1_8_14  original_T_including_depot_unload_1121  1.7203273996041773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_844  1
    load_1_8_14  segment_load_conservation_1067  1
    load_1_8_14  free_load_conservation_1087  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_846  -25
    arc_1_8_15  connected_order_arc_847  -13
    arc_1_8_15  out_degree_1063  1
    arc_1_8_15  in_degree_1089  1
    arc_1_8_15  original_T_including_depot_unload_1121  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_846  1
    load_1_8_15  segment_load_conservation_1067  1
    load_1_8_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_848  -25
    arc_1_8_16  connected_order_arc_849  -13
    arc_1_8_16  out_degree_1063  1
    arc_1_8_16  in_degree_1095  1
    arc_1_8_16  original_T_including_depot_unload_1121  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_848  1
    load_1_8_16  segment_load_conservation_1067  1
    load_1_8_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_850  -25
    arc_1_8_17  connected_order_arc_851  -13
    arc_1_8_17  out_degree_1063  1
    arc_1_8_17  in_degree_1101  1
    arc_1_8_17  original_T_including_depot_unload_1121  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_850  1
    load_1_8_17  segment_load_conservation_1067  1
    load_1_8_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_852  -25
    arc_1_8_18  connected_order_arc_853  -13
    arc_1_8_18  out_degree_1063  1
    arc_1_8_18  in_degree_1107  1
    arc_1_8_18  original_T_including_depot_unload_1121  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_852  1
    load_1_8_18  segment_load_conservation_1067  1
    load_1_8_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_854  -25
    arc_1_8_19  connected_order_arc_855  -13
    arc_1_8_19  out_degree_1063  1
    arc_1_8_19  in_degree_1113  1
    arc_1_8_19  original_T_including_depot_unload_1121  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_854  1
    load_1_8_19  segment_load_conservation_1067  1
    load_1_8_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_856  -25
    arc_1_12_0  depot_return_or_bypass_1041  1
    arc_1_12_0  out_degree_1070  1
    arc_1_12_0  original_T_including_depot_unload_1121  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_856  1
    load_1_12_0  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_857  -25
    arc_1_12_5  connected_order_arc_858  -13
    arc_1_12_5  in_degree_1043  1
    arc_1_12_5  out_degree_1070  1
    arc_1_12_5  original_T_including_depot_unload_1121  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_857  1
    load_1_12_5  segment_load_conservation_1046  -1
    load_1_12_5  segment_prefix_lb_1047  1
    load_1_12_5  segment_prefix_ub_1048  1
    load_1_12_5  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_859  -25
    arc_1_12_6  connected_order_arc_860  -13
    arc_1_12_6  in_degree_1050  1
    arc_1_12_6  out_degree_1070  1
    arc_1_12_6  original_T_including_depot_unload_1121  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_859  1
    load_1_12_6  segment_load_conservation_1053  -1
    load_1_12_6  segment_prefix_lb_1054  1
    load_1_12_6  segment_prefix_ub_1055  1
    load_1_12_6  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_861  -25
    arc_1_12_7  connected_order_arc_862  -13
    arc_1_12_7  in_degree_1057  1
    arc_1_12_7  out_degree_1070  1
    arc_1_12_7  original_T_including_depot_unload_1121  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_861  1
    load_1_12_7  segment_load_conservation_1060  -1
    load_1_12_7  segment_prefix_lb_1061  1
    load_1_12_7  segment_prefix_ub_1062  1
    load_1_12_7  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_863  -25
    arc_1_12_8  connected_order_arc_864  -13
    arc_1_12_8  in_degree_1064  1
    arc_1_12_8  out_degree_1070  1
    arc_1_12_8  original_T_including_depot_unload_1121  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_863  1
    load_1_12_8  segment_load_conservation_1067  -1
    load_1_12_8  segment_prefix_lb_1068  1
    load_1_12_8  segment_prefix_ub_1069  1
    load_1_12_8  free_load_conservation_1075  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_865  -25
    arc_1_12_13  connected_order_arc_866  -13
    arc_1_12_13  out_degree_1070  1
    arc_1_12_13  in_degree_1077  1
    arc_1_12_13  original_T_including_depot_unload_1121  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_865  1
    load_1_12_13  free_load_conservation_1075  1
    load_1_12_13  free_load_conservation_1081  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_867  -25
    arc_1_12_14  connected_order_arc_868  -13
    arc_1_12_14  out_degree_1070  1
    arc_1_12_14  in_degree_1083  1
    arc_1_12_14  original_T_including_depot_unload_1121  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_867  1
    load_1_12_14  free_load_conservation_1075  1
    load_1_12_14  free_load_conservation_1087  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_869  -25
    arc_1_12_15  connected_order_arc_870  -13
    arc_1_12_15  out_degree_1070  1
    arc_1_12_15  in_degree_1089  1
    arc_1_12_15  original_T_including_depot_unload_1121  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_869  1
    load_1_12_15  free_load_conservation_1075  1
    load_1_12_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_871  -25
    arc_1_12_16  connected_order_arc_872  -13
    arc_1_12_16  out_degree_1070  1
    arc_1_12_16  in_degree_1095  1
    arc_1_12_16  original_T_including_depot_unload_1121  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_871  1
    load_1_12_16  free_load_conservation_1075  1
    load_1_12_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_873  -25
    arc_1_12_17  connected_order_arc_874  -13
    arc_1_12_17  out_degree_1070  1
    arc_1_12_17  in_degree_1101  1
    arc_1_12_17  original_T_including_depot_unload_1121  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_873  1
    load_1_12_17  free_load_conservation_1075  1
    load_1_12_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_875  -25
    arc_1_12_18  connected_order_arc_876  -13
    arc_1_12_18  out_degree_1070  1
    arc_1_12_18  in_degree_1107  1
    arc_1_12_18  original_T_including_depot_unload_1121  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_875  1
    load_1_12_18  free_load_conservation_1075  1
    load_1_12_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_877  -25
    arc_1_12_19  connected_order_arc_878  -13
    arc_1_12_19  out_degree_1070  1
    arc_1_12_19  in_degree_1113  1
    arc_1_12_19  original_T_including_depot_unload_1121  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_877  1
    load_1_12_19  free_load_conservation_1075  1
    load_1_12_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_879  -25
    arc_1_13_0  depot_return_or_bypass_1041  1
    arc_1_13_0  out_degree_1076  1
    arc_1_13_0  original_T_including_depot_unload_1121  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_879  1
    load_1_13_0  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_880  -25
    arc_1_13_5  connected_order_arc_881  -13
    arc_1_13_5  in_degree_1043  1
    arc_1_13_5  out_degree_1076  1
    arc_1_13_5  original_T_including_depot_unload_1121  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_880  1
    load_1_13_5  segment_load_conservation_1046  -1
    load_1_13_5  segment_prefix_lb_1047  1
    load_1_13_5  segment_prefix_ub_1048  1
    load_1_13_5  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_882  -25
    arc_1_13_6  connected_order_arc_883  -13
    arc_1_13_6  in_degree_1050  1
    arc_1_13_6  out_degree_1076  1
    arc_1_13_6  original_T_including_depot_unload_1121  2.8975409264294121e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_882  1
    load_1_13_6  segment_load_conservation_1053  -1
    load_1_13_6  segment_prefix_lb_1054  1
    load_1_13_6  segment_prefix_ub_1055  1
    load_1_13_6  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_884  -25
    arc_1_13_7  connected_order_arc_885  -13
    arc_1_13_7  in_degree_1057  1
    arc_1_13_7  out_degree_1076  1
    arc_1_13_7  original_T_including_depot_unload_1121  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_884  1
    load_1_13_7  segment_load_conservation_1060  -1
    load_1_13_7  segment_prefix_lb_1061  1
    load_1_13_7  segment_prefix_ub_1062  1
    load_1_13_7  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_886  -25
    arc_1_13_8  connected_order_arc_887  -13
    arc_1_13_8  in_degree_1064  1
    arc_1_13_8  out_degree_1076  1
    arc_1_13_8  original_T_including_depot_unload_1121  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_886  1
    load_1_13_8  segment_load_conservation_1067  -1
    load_1_13_8  segment_prefix_lb_1068  1
    load_1_13_8  segment_prefix_ub_1069  1
    load_1_13_8  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_888  -25
    arc_1_13_12  connected_order_arc_889  -13
    arc_1_13_12  in_degree_1071  1
    arc_1_13_12  out_degree_1076  1
    arc_1_13_12  original_T_including_depot_unload_1121  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_888  1
    load_1_13_12  free_load_conservation_1075  -1
    load_1_13_12  free_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_890  -25
    arc_1_13_14  connected_order_arc_891  -13
    arc_1_13_14  out_degree_1076  1
    arc_1_13_14  in_degree_1083  1
    arc_1_13_14  original_T_including_depot_unload_1121  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_890  1
    load_1_13_14  free_load_conservation_1081  1
    load_1_13_14  free_load_conservation_1087  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_892  -25
    arc_1_13_15  connected_order_arc_893  -13
    arc_1_13_15  out_degree_1076  1
    arc_1_13_15  in_degree_1089  1
    arc_1_13_15  original_T_including_depot_unload_1121  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_892  1
    load_1_13_15  free_load_conservation_1081  1
    load_1_13_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_894  -25
    arc_1_13_16  connected_order_arc_895  -13
    arc_1_13_16  out_degree_1076  1
    arc_1_13_16  in_degree_1095  1
    arc_1_13_16  original_T_including_depot_unload_1121  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_894  1
    load_1_13_16  free_load_conservation_1081  1
    load_1_13_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_896  -25
    arc_1_13_17  connected_order_arc_897  -13
    arc_1_13_17  out_degree_1076  1
    arc_1_13_17  in_degree_1101  1
    arc_1_13_17  original_T_including_depot_unload_1121  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_896  1
    load_1_13_17  free_load_conservation_1081  1
    load_1_13_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_898  -25
    arc_1_13_18  connected_order_arc_899  -13
    arc_1_13_18  out_degree_1076  1
    arc_1_13_18  in_degree_1107  1
    arc_1_13_18  original_T_including_depot_unload_1121  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_898  1
    load_1_13_18  free_load_conservation_1081  1
    load_1_13_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_900  -25
    arc_1_13_19  connected_order_arc_901  -13
    arc_1_13_19  out_degree_1076  1
    arc_1_13_19  in_degree_1113  1
    arc_1_13_19  original_T_including_depot_unload_1121  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_900  1
    load_1_13_19  free_load_conservation_1081  1
    load_1_13_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_902  -25
    arc_1_14_0  depot_return_or_bypass_1041  1
    arc_1_14_0  out_degree_1082  1
    arc_1_14_0  original_T_including_depot_unload_1121  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_902  1
    load_1_14_0  free_load_conservation_1087  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_903  -25
    arc_1_14_5  connected_order_arc_904  -13
    arc_1_14_5  in_degree_1043  1
    arc_1_14_5  out_degree_1082  1
    arc_1_14_5  original_T_including_depot_unload_1121  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_903  1
    load_1_14_5  segment_load_conservation_1046  -1
    load_1_14_5  segment_prefix_lb_1047  1
    load_1_14_5  segment_prefix_ub_1048  1
    load_1_14_5  free_load_conservation_1087  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_905  -25
    arc_1_14_6  connected_order_arc_906  -13
    arc_1_14_6  in_degree_1050  1
    arc_1_14_6  out_degree_1082  1
    arc_1_14_6  original_T_including_depot_unload_1121  2.9939628790517750e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_905  1
    load_1_14_6  segment_load_conservation_1053  -1
    load_1_14_6  segment_prefix_lb_1054  1
    load_1_14_6  segment_prefix_ub_1055  1
    load_1_14_6  free_load_conservation_1087  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_907  -25
    arc_1_14_7  connected_order_arc_908  -13
    arc_1_14_7  in_degree_1057  1
    arc_1_14_7  out_degree_1082  1
    arc_1_14_7  original_T_including_depot_unload_1121  2.0264134980919391e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_907  1
    load_1_14_7  segment_load_conservation_1060  -1
    load_1_14_7  segment_prefix_lb_1061  1
    load_1_14_7  segment_prefix_ub_1062  1
    load_1_14_7  free_load_conservation_1087  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_909  -25
    arc_1_14_8  connected_order_arc_910  -13
    arc_1_14_8  in_degree_1064  1
    arc_1_14_8  out_degree_1082  1
    arc_1_14_8  original_T_including_depot_unload_1121  1.7203273996041773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_909  1
    load_1_14_8  segment_load_conservation_1067  -1
    load_1_14_8  segment_prefix_lb_1068  1
    load_1_14_8  segment_prefix_ub_1069  1
    load_1_14_8  free_load_conservation_1087  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_911  -25
    arc_1_14_12  connected_order_arc_912  -13
    arc_1_14_12  in_degree_1071  1
    arc_1_14_12  out_degree_1082  1
    arc_1_14_12  original_T_including_depot_unload_1121  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_911  1
    load_1_14_12  free_load_conservation_1075  -1
    load_1_14_12  free_load_conservation_1087  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_913  -25
    arc_1_14_13  connected_order_arc_914  -13
    arc_1_14_13  in_degree_1077  1
    arc_1_14_13  out_degree_1082  1
    arc_1_14_13  original_T_including_depot_unload_1121  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_913  1
    load_1_14_13  free_load_conservation_1081  -1
    load_1_14_13  free_load_conservation_1087  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_915  -25
    arc_1_14_15  connected_order_arc_916  -13
    arc_1_14_15  out_degree_1082  1
    arc_1_14_15  in_degree_1089  1
    arc_1_14_15  original_T_including_depot_unload_1121  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_915  1
    load_1_14_15  free_load_conservation_1087  1
    load_1_14_15  free_load_conservation_1093  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_917  -25
    arc_1_14_16  connected_order_arc_918  -13
    arc_1_14_16  out_degree_1082  1
    arc_1_14_16  in_degree_1095  1
    arc_1_14_16  original_T_including_depot_unload_1121  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_917  1
    load_1_14_16  free_load_conservation_1087  1
    load_1_14_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_919  -25
    arc_1_14_17  connected_order_arc_920  -13
    arc_1_14_17  out_degree_1082  1
    arc_1_14_17  in_degree_1101  1
    arc_1_14_17  original_T_including_depot_unload_1121  1.4068884127351855e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_919  1
    load_1_14_17  free_load_conservation_1087  1
    load_1_14_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_921  -25
    arc_1_14_18  connected_order_arc_922  -13
    arc_1_14_18  out_degree_1082  1
    arc_1_14_18  in_degree_1107  1
    arc_1_14_18  original_T_including_depot_unload_1121  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_921  1
    load_1_14_18  free_load_conservation_1087  1
    load_1_14_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_923  -25
    arc_1_14_19  connected_order_arc_924  -13
    arc_1_14_19  out_degree_1082  1
    arc_1_14_19  in_degree_1113  1
    arc_1_14_19  original_T_including_depot_unload_1121  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_923  1
    load_1_14_19  free_load_conservation_1087  1
    load_1_14_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_925  -25
    arc_1_15_0  depot_return_or_bypass_1041  1
    arc_1_15_0  out_degree_1088  1
    arc_1_15_0  original_T_including_depot_unload_1121  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_925  1
    load_1_15_0  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_926  -25
    arc_1_15_5  connected_order_arc_927  -13
    arc_1_15_5  in_degree_1043  1
    arc_1_15_5  out_degree_1088  1
    arc_1_15_5  original_T_including_depot_unload_1121  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_926  1
    load_1_15_5  segment_load_conservation_1046  -1
    load_1_15_5  segment_prefix_lb_1047  1
    load_1_15_5  segment_prefix_ub_1048  1
    load_1_15_5  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_928  -25
    arc_1_15_6  connected_order_arc_929  -13
    arc_1_15_6  in_degree_1050  1
    arc_1_15_6  out_degree_1088  1
    arc_1_15_6  original_T_including_depot_unload_1121  2.9006291140474787e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_928  1
    load_1_15_6  segment_load_conservation_1053  -1
    load_1_15_6  segment_prefix_lb_1054  1
    load_1_15_6  segment_prefix_ub_1055  1
    load_1_15_6  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_930  -25
    arc_1_15_7  connected_order_arc_931  -13
    arc_1_15_7  in_degree_1057  1
    arc_1_15_7  out_degree_1088  1
    arc_1_15_7  original_T_including_depot_unload_1121  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_930  1
    load_1_15_7  segment_load_conservation_1060  -1
    load_1_15_7  segment_prefix_lb_1061  1
    load_1_15_7  segment_prefix_ub_1062  1
    load_1_15_7  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_932  -25
    arc_1_15_8  connected_order_arc_933  -13
    arc_1_15_8  in_degree_1064  1
    arc_1_15_8  out_degree_1088  1
    arc_1_15_8  original_T_including_depot_unload_1121  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_932  1
    load_1_15_8  segment_load_conservation_1067  -1
    load_1_15_8  segment_prefix_lb_1068  1
    load_1_15_8  segment_prefix_ub_1069  1
    load_1_15_8  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_934  -25
    arc_1_15_12  connected_order_arc_935  -13
    arc_1_15_12  in_degree_1071  1
    arc_1_15_12  out_degree_1088  1
    arc_1_15_12  original_T_including_depot_unload_1121  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_934  1
    load_1_15_12  free_load_conservation_1075  -1
    load_1_15_12  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_936  -25
    arc_1_15_13  connected_order_arc_937  -13
    arc_1_15_13  in_degree_1077  1
    arc_1_15_13  out_degree_1088  1
    arc_1_15_13  original_T_including_depot_unload_1121  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_936  1
    load_1_15_13  free_load_conservation_1081  -1
    load_1_15_13  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_938  -25
    arc_1_15_14  connected_order_arc_939  -13
    arc_1_15_14  in_degree_1083  1
    arc_1_15_14  out_degree_1088  1
    arc_1_15_14  original_T_including_depot_unload_1121  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_938  1
    load_1_15_14  free_load_conservation_1087  -1
    load_1_15_14  free_load_conservation_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_940  -25
    arc_1_15_16  connected_order_arc_941  -13
    arc_1_15_16  out_degree_1088  1
    arc_1_15_16  in_degree_1095  1
    arc_1_15_16  original_T_including_depot_unload_1121  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_940  1
    load_1_15_16  free_load_conservation_1093  1
    load_1_15_16  free_load_conservation_1099  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_942  -25
    arc_1_15_17  connected_order_arc_943  -13
    arc_1_15_17  out_degree_1088  1
    arc_1_15_17  in_degree_1101  1
    arc_1_15_17  original_T_including_depot_unload_1121  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_942  1
    load_1_15_17  free_load_conservation_1093  1
    load_1_15_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_944  -25
    arc_1_15_18  connected_order_arc_945  -13
    arc_1_15_18  out_degree_1088  1
    arc_1_15_18  in_degree_1107  1
    arc_1_15_18  original_T_including_depot_unload_1121  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_944  1
    load_1_15_18  free_load_conservation_1093  1
    load_1_15_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_946  -25
    arc_1_15_19  connected_order_arc_947  -13
    arc_1_15_19  out_degree_1088  1
    arc_1_15_19  in_degree_1113  1
    arc_1_15_19  original_T_including_depot_unload_1121  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_946  1
    load_1_15_19  free_load_conservation_1093  1
    load_1_15_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_948  -25
    arc_1_16_0  depot_return_or_bypass_1041  1
    arc_1_16_0  out_degree_1094  1
    arc_1_16_0  original_T_including_depot_unload_1121  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_948  1
    load_1_16_0  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_949  -25
    arc_1_16_5  connected_order_arc_950  -13
    arc_1_16_5  in_degree_1043  1
    arc_1_16_5  out_degree_1094  1
    arc_1_16_5  original_T_including_depot_unload_1121  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_949  1
    load_1_16_5  segment_load_conservation_1046  -1
    load_1_16_5  segment_prefix_lb_1047  1
    load_1_16_5  segment_prefix_ub_1048  1
    load_1_16_5  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_951  -25
    arc_1_16_6  connected_order_arc_952  -13
    arc_1_16_6  in_degree_1050  1
    arc_1_16_6  out_degree_1094  1
    arc_1_16_6  original_T_including_depot_unload_1121  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_951  1
    load_1_16_6  segment_load_conservation_1053  -1
    load_1_16_6  segment_prefix_lb_1054  1
    load_1_16_6  segment_prefix_ub_1055  1
    load_1_16_6  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_953  -25
    arc_1_16_7  connected_order_arc_954  -13
    arc_1_16_7  in_degree_1057  1
    arc_1_16_7  out_degree_1094  1
    arc_1_16_7  original_T_including_depot_unload_1121  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_953  1
    load_1_16_7  segment_load_conservation_1060  -1
    load_1_16_7  segment_prefix_lb_1061  1
    load_1_16_7  segment_prefix_ub_1062  1
    load_1_16_7  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_955  -25
    arc_1_16_8  connected_order_arc_956  -13
    arc_1_16_8  in_degree_1064  1
    arc_1_16_8  out_degree_1094  1
    arc_1_16_8  original_T_including_depot_unload_1121  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_955  1
    load_1_16_8  segment_load_conservation_1067  -1
    load_1_16_8  segment_prefix_lb_1068  1
    load_1_16_8  segment_prefix_ub_1069  1
    load_1_16_8  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_957  -25
    arc_1_16_12  connected_order_arc_958  -13
    arc_1_16_12  in_degree_1071  1
    arc_1_16_12  out_degree_1094  1
    arc_1_16_12  original_T_including_depot_unload_1121  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_957  1
    load_1_16_12  free_load_conservation_1075  -1
    load_1_16_12  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_959  -25
    arc_1_16_13  connected_order_arc_960  -13
    arc_1_16_13  in_degree_1077  1
    arc_1_16_13  out_degree_1094  1
    arc_1_16_13  original_T_including_depot_unload_1121  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_959  1
    load_1_16_13  free_load_conservation_1081  -1
    load_1_16_13  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_961  -25
    arc_1_16_14  connected_order_arc_962  -13
    arc_1_16_14  in_degree_1083  1
    arc_1_16_14  out_degree_1094  1
    arc_1_16_14  original_T_including_depot_unload_1121  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_961  1
    load_1_16_14  free_load_conservation_1087  -1
    load_1_16_14  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_963  -25
    arc_1_16_15  connected_order_arc_964  -13
    arc_1_16_15  in_degree_1089  1
    arc_1_16_15  out_degree_1094  1
    arc_1_16_15  original_T_including_depot_unload_1121  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_963  1
    load_1_16_15  free_load_conservation_1093  -1
    load_1_16_15  free_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_965  -25
    arc_1_16_17  connected_order_arc_966  -13
    arc_1_16_17  out_degree_1094  1
    arc_1_16_17  in_degree_1101  1
    arc_1_16_17  original_T_including_depot_unload_1121  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_965  1
    load_1_16_17  free_load_conservation_1099  1
    load_1_16_17  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_967  -25
    arc_1_16_18  connected_order_arc_968  -13
    arc_1_16_18  out_degree_1094  1
    arc_1_16_18  in_degree_1107  1
    arc_1_16_18  original_T_including_depot_unload_1121  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_967  1
    load_1_16_18  free_load_conservation_1099  1
    load_1_16_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_969  -25
    arc_1_16_19  connected_order_arc_970  -13
    arc_1_16_19  out_degree_1094  1
    arc_1_16_19  in_degree_1113  1
    arc_1_16_19  original_T_including_depot_unload_1121  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_969  1
    load_1_16_19  free_load_conservation_1099  1
    load_1_16_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_971  -25
    arc_1_17_0  depot_return_or_bypass_1041  1
    arc_1_17_0  out_degree_1100  1
    arc_1_17_0  original_T_including_depot_unload_1121  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_971  1
    load_1_17_0  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_972  -25
    arc_1_17_5  connected_order_arc_973  -13
    arc_1_17_5  in_degree_1043  1
    arc_1_17_5  out_degree_1100  1
    arc_1_17_5  original_T_including_depot_unload_1121  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_972  1
    load_1_17_5  segment_load_conservation_1046  -1
    load_1_17_5  segment_prefix_lb_1047  1
    load_1_17_5  segment_prefix_ub_1048  1
    load_1_17_5  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_974  -25
    arc_1_17_6  connected_order_arc_975  -13
    arc_1_17_6  in_degree_1050  1
    arc_1_17_6  out_degree_1100  1
    arc_1_17_6  original_T_including_depot_unload_1121  2.1806564621513235e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_974  1
    load_1_17_6  segment_load_conservation_1053  -1
    load_1_17_6  segment_prefix_lb_1054  1
    load_1_17_6  segment_prefix_ub_1055  1
    load_1_17_6  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_976  -25
    arc_1_17_7  connected_order_arc_977  -13
    arc_1_17_7  in_degree_1057  1
    arc_1_17_7  out_degree_1100  1
    arc_1_17_7  original_T_including_depot_unload_1121  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_976  1
    load_1_17_7  segment_load_conservation_1060  -1
    load_1_17_7  segment_prefix_lb_1061  1
    load_1_17_7  segment_prefix_ub_1062  1
    load_1_17_7  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_978  -25
    arc_1_17_8  connected_order_arc_979  -13
    arc_1_17_8  in_degree_1064  1
    arc_1_17_8  out_degree_1100  1
    arc_1_17_8  original_T_including_depot_unload_1121  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_978  1
    load_1_17_8  segment_load_conservation_1067  -1
    load_1_17_8  segment_prefix_lb_1068  1
    load_1_17_8  segment_prefix_ub_1069  1
    load_1_17_8  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_980  -25
    arc_1_17_12  connected_order_arc_981  -13
    arc_1_17_12  in_degree_1071  1
    arc_1_17_12  out_degree_1100  1
    arc_1_17_12  original_T_including_depot_unload_1121  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_980  1
    load_1_17_12  free_load_conservation_1075  -1
    load_1_17_12  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_982  -25
    arc_1_17_13  connected_order_arc_983  -13
    arc_1_17_13  in_degree_1077  1
    arc_1_17_13  out_degree_1100  1
    arc_1_17_13  original_T_including_depot_unload_1121  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_982  1
    load_1_17_13  free_load_conservation_1081  -1
    load_1_17_13  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_984  -25
    arc_1_17_14  connected_order_arc_985  -13
    arc_1_17_14  in_degree_1083  1
    arc_1_17_14  out_degree_1100  1
    arc_1_17_14  original_T_including_depot_unload_1121  1.4068884127351855e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_984  1
    load_1_17_14  free_load_conservation_1087  -1
    load_1_17_14  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_986  -25
    arc_1_17_15  connected_order_arc_987  -13
    arc_1_17_15  in_degree_1089  1
    arc_1_17_15  out_degree_1100  1
    arc_1_17_15  original_T_including_depot_unload_1121  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_986  1
    load_1_17_15  free_load_conservation_1093  -1
    load_1_17_15  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_988  -25
    arc_1_17_16  connected_order_arc_989  -13
    arc_1_17_16  in_degree_1095  1
    arc_1_17_16  out_degree_1100  1
    arc_1_17_16  original_T_including_depot_unload_1121  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_988  1
    load_1_17_16  free_load_conservation_1099  -1
    load_1_17_16  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_990  -25
    arc_1_17_18  connected_order_arc_991  -13
    arc_1_17_18  out_degree_1100  1
    arc_1_17_18  in_degree_1107  1
    arc_1_17_18  original_T_including_depot_unload_1121  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_990  1
    load_1_17_18  free_load_conservation_1105  1
    load_1_17_18  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_992  -25
    arc_1_17_19  connected_order_arc_993  -13
    arc_1_17_19  out_degree_1100  1
    arc_1_17_19  in_degree_1113  1
    arc_1_17_19  original_T_including_depot_unload_1121  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_992  1
    load_1_17_19  free_load_conservation_1105  1
    load_1_17_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_994  -25
    arc_1_18_0  depot_return_or_bypass_1041  1
    arc_1_18_0  out_degree_1106  1
    arc_1_18_0  original_T_including_depot_unload_1121  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_994  1
    load_1_18_0  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_995  -25
    arc_1_18_5  connected_order_arc_996  -13
    arc_1_18_5  in_degree_1043  1
    arc_1_18_5  out_degree_1106  1
    arc_1_18_5  original_T_including_depot_unload_1121  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_995  1
    load_1_18_5  segment_load_conservation_1046  -1
    load_1_18_5  segment_prefix_lb_1047  1
    load_1_18_5  segment_prefix_ub_1048  1
    load_1_18_5  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_997  -25
    arc_1_18_6  connected_order_arc_998  -13
    arc_1_18_6  in_degree_1050  1
    arc_1_18_6  out_degree_1106  1
    arc_1_18_6  original_T_including_depot_unload_1121  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_997  1
    load_1_18_6  segment_load_conservation_1053  -1
    load_1_18_6  segment_prefix_lb_1054  1
    load_1_18_6  segment_prefix_ub_1055  1
    load_1_18_6  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_999  -25
    arc_1_18_7  connected_order_arc_1000  -13
    arc_1_18_7  in_degree_1057  1
    arc_1_18_7  out_degree_1106  1
    arc_1_18_7  original_T_including_depot_unload_1121  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_999  1
    load_1_18_7  segment_load_conservation_1060  -1
    load_1_18_7  segment_prefix_lb_1061  1
    load_1_18_7  segment_prefix_ub_1062  1
    load_1_18_7  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1001  -25
    arc_1_18_8  connected_order_arc_1002  -13
    arc_1_18_8  in_degree_1064  1
    arc_1_18_8  out_degree_1106  1
    arc_1_18_8  original_T_including_depot_unload_1121  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1001  1
    load_1_18_8  segment_load_conservation_1067  -1
    load_1_18_8  segment_prefix_lb_1068  1
    load_1_18_8  segment_prefix_ub_1069  1
    load_1_18_8  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_1003  -25
    arc_1_18_12  connected_order_arc_1004  -13
    arc_1_18_12  in_degree_1071  1
    arc_1_18_12  out_degree_1106  1
    arc_1_18_12  original_T_including_depot_unload_1121  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_1003  1
    load_1_18_12  free_load_conservation_1075  -1
    load_1_18_12  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1005  -25
    arc_1_18_13  connected_order_arc_1006  -13
    arc_1_18_13  in_degree_1077  1
    arc_1_18_13  out_degree_1106  1
    arc_1_18_13  original_T_including_depot_unload_1121  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1005  1
    load_1_18_13  free_load_conservation_1081  -1
    load_1_18_13  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1007  -25
    arc_1_18_14  connected_order_arc_1008  -13
    arc_1_18_14  in_degree_1083  1
    arc_1_18_14  out_degree_1106  1
    arc_1_18_14  original_T_including_depot_unload_1121  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1007  1
    load_1_18_14  free_load_conservation_1087  -1
    load_1_18_14  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1009  -25
    arc_1_18_15  connected_order_arc_1010  -13
    arc_1_18_15  in_degree_1089  1
    arc_1_18_15  out_degree_1106  1
    arc_1_18_15  original_T_including_depot_unload_1121  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1009  1
    load_1_18_15  free_load_conservation_1093  -1
    load_1_18_15  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1011  -25
    arc_1_18_16  connected_order_arc_1012  -13
    arc_1_18_16  in_degree_1095  1
    arc_1_18_16  out_degree_1106  1
    arc_1_18_16  original_T_including_depot_unload_1121  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1011  1
    load_1_18_16  free_load_conservation_1099  -1
    load_1_18_16  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1013  -25
    arc_1_18_17  connected_order_arc_1014  -13
    arc_1_18_17  in_degree_1101  1
    arc_1_18_17  out_degree_1106  1
    arc_1_18_17  original_T_including_depot_unload_1121  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1013  1
    load_1_18_17  free_load_conservation_1105  -1
    load_1_18_17  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1015  -25
    arc_1_18_19  connected_order_arc_1016  -13
    arc_1_18_19  out_degree_1106  1
    arc_1_18_19  in_degree_1113  1
    arc_1_18_19  original_T_including_depot_unload_1121  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1015  1
    load_1_18_19  free_load_conservation_1111  1
    load_1_18_19  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1017  -25
    arc_1_19_0  depot_return_or_bypass_1041  1
    arc_1_19_0  out_degree_1112  1
    arc_1_19_0  original_T_including_depot_unload_1121  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1017  1
    load_1_19_0  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1018  -25
    arc_1_19_5  connected_order_arc_1019  -13
    arc_1_19_5  in_degree_1043  1
    arc_1_19_5  out_degree_1112  1
    arc_1_19_5  original_T_including_depot_unload_1121  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1018  1
    load_1_19_5  segment_load_conservation_1046  -1
    load_1_19_5  segment_prefix_lb_1047  1
    load_1_19_5  segment_prefix_ub_1048  1
    load_1_19_5  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1020  -25
    arc_1_19_6  connected_order_arc_1021  -13
    arc_1_19_6  in_degree_1050  1
    arc_1_19_6  out_degree_1112  1
    arc_1_19_6  original_T_including_depot_unload_1121  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1020  1
    load_1_19_6  segment_load_conservation_1053  -1
    load_1_19_6  segment_prefix_lb_1054  1
    load_1_19_6  segment_prefix_ub_1055  1
    load_1_19_6  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1022  -25
    arc_1_19_7  connected_order_arc_1023  -13
    arc_1_19_7  in_degree_1057  1
    arc_1_19_7  out_degree_1112  1
    arc_1_19_7  original_T_including_depot_unload_1121  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1022  1
    load_1_19_7  segment_load_conservation_1060  -1
    load_1_19_7  segment_prefix_lb_1061  1
    load_1_19_7  segment_prefix_ub_1062  1
    load_1_19_7  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1024  -25
    arc_1_19_8  connected_order_arc_1025  -13
    arc_1_19_8  in_degree_1064  1
    arc_1_19_8  out_degree_1112  1
    arc_1_19_8  original_T_including_depot_unload_1121  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1024  1
    load_1_19_8  segment_load_conservation_1067  -1
    load_1_19_8  segment_prefix_lb_1068  1
    load_1_19_8  segment_prefix_ub_1069  1
    load_1_19_8  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_1026  -25
    arc_1_19_12  connected_order_arc_1027  -13
    arc_1_19_12  in_degree_1071  1
    arc_1_19_12  out_degree_1112  1
    arc_1_19_12  original_T_including_depot_unload_1121  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_1026  1
    load_1_19_12  free_load_conservation_1075  -1
    load_1_19_12  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1028  -25
    arc_1_19_13  connected_order_arc_1029  -13
    arc_1_19_13  in_degree_1077  1
    arc_1_19_13  out_degree_1112  1
    arc_1_19_13  original_T_including_depot_unload_1121  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1028  1
    load_1_19_13  free_load_conservation_1081  -1
    load_1_19_13  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1030  -25
    arc_1_19_14  connected_order_arc_1031  -13
    arc_1_19_14  in_degree_1083  1
    arc_1_19_14  out_degree_1112  1
    arc_1_19_14  original_T_including_depot_unload_1121  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1030  1
    load_1_19_14  free_load_conservation_1087  -1
    load_1_19_14  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1032  -25
    arc_1_19_15  connected_order_arc_1033  -13
    arc_1_19_15  in_degree_1089  1
    arc_1_19_15  out_degree_1112  1
    arc_1_19_15  original_T_including_depot_unload_1121  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1032  1
    load_1_19_15  free_load_conservation_1093  -1
    load_1_19_15  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1034  -25
    arc_1_19_16  connected_order_arc_1035  -13
    arc_1_19_16  in_degree_1095  1
    arc_1_19_16  out_degree_1112  1
    arc_1_19_16  original_T_including_depot_unload_1121  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1034  1
    load_1_19_16  free_load_conservation_1099  -1
    load_1_19_16  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1036  -25
    arc_1_19_17  connected_order_arc_1037  -13
    arc_1_19_17  in_degree_1101  1
    arc_1_19_17  out_degree_1112  1
    arc_1_19_17  original_T_including_depot_unload_1121  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1036  1
    load_1_19_17  free_load_conservation_1105  -1
    load_1_19_17  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1038  -25
    arc_1_19_18  connected_order_arc_1039  -13
    arc_1_19_18  in_degree_1107  1
    arc_1_19_18  out_degree_1112  1
    arc_1_19_18  original_T_including_depot_unload_1121  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1038  1
    load_1_19_18  free_load_conservation_1111  -1
    load_1_19_18  free_load_conservation_1117  1
    visit_2_9  out_degree_1367  -1
    visit_2_9  in_degree_1368  -1
    visit_2_9  order_active_lb_1369  -1
    visit_2_9  order_active_ub_1370  -11
    order_2_9  connected_order_arc_1136  -1
    order_2_9  connected_order_arc_1138  -1
    order_2_9  connected_order_arc_1140  -1
    order_2_9  connected_order_arc_1142  -1
    order_2_9  connected_order_arc_1144  -1
    order_2_9  connected_order_arc_1146  -1
    order_2_9  connected_order_arc_1148  -1
    order_2_9  connected_order_arc_1150  -1
    order_2_9  connected_order_arc_1152  -1
    order_2_9  connected_order_arc_1154  -1
    order_2_9  connected_order_arc_1157  1
    order_2_9  connected_order_arc_1178  1
    order_2_9  connected_order_arc_1199  1
    order_2_9  connected_order_arc_1220  1
    order_2_9  connected_order_arc_1241  1
    order_2_9  connected_order_arc_1262  1
    order_2_9  connected_order_arc_1283  1
    order_2_9  connected_order_arc_1304  1
    order_2_9  connected_order_arc_1325  1
    order_2_9  connected_order_arc_1346  1
    order_2_9  order_active_lb_1369  1
    order_2_9  order_active_ub_1370  1
    order_2_9  fixed_segment_relative_order_1436  -1
    visit_2_10  out_degree_1374  -1
    visit_2_10  in_degree_1375  -1
    visit_2_10  order_active_lb_1376  -1
    visit_2_10  order_active_ub_1377  -11
    order_2_10  connected_order_arc_1136  1
    order_2_10  connected_order_arc_1157  -1
    order_2_10  connected_order_arc_1159  -1
    order_2_10  connected_order_arc_1161  -1
    order_2_10  connected_order_arc_1163  -1
    order_2_10  connected_order_arc_1165  -1
    order_2_10  connected_order_arc_1167  -1
    order_2_10  connected_order_arc_1169  -1
    order_2_10  connected_order_arc_1171  -1
    order_2_10  connected_order_arc_1173  -1
    order_2_10  connected_order_arc_1175  -1
    order_2_10  connected_order_arc_1180  1
    order_2_10  connected_order_arc_1201  1
    order_2_10  connected_order_arc_1222  1
    order_2_10  connected_order_arc_1243  1
    order_2_10  connected_order_arc_1264  1
    order_2_10  connected_order_arc_1285  1
    order_2_10  connected_order_arc_1306  1
    order_2_10  connected_order_arc_1327  1
    order_2_10  connected_order_arc_1348  1
    order_2_10  order_active_lb_1376  1
    order_2_10  order_active_ub_1377  1
    order_2_10  fixed_segment_relative_order_1436  1
    order_2_10  fixed_segment_relative_order_1437  -1
    visit_2_11  out_degree_1381  -1
    visit_2_11  in_degree_1382  -1
    visit_2_11  order_active_lb_1383  -1
    visit_2_11  order_active_ub_1384  -11
    order_2_11  connected_order_arc_1138  1
    order_2_11  connected_order_arc_1159  1
    order_2_11  connected_order_arc_1178  -1
    order_2_11  connected_order_arc_1180  -1
    order_2_11  connected_order_arc_1182  -1
    order_2_11  connected_order_arc_1184  -1
    order_2_11  connected_order_arc_1186  -1
    order_2_11  connected_order_arc_1188  -1
    order_2_11  connected_order_arc_1190  -1
    order_2_11  connected_order_arc_1192  -1
    order_2_11  connected_order_arc_1194  -1
    order_2_11  connected_order_arc_1196  -1
    order_2_11  connected_order_arc_1203  1
    order_2_11  connected_order_arc_1224  1
    order_2_11  connected_order_arc_1245  1
    order_2_11  connected_order_arc_1266  1
    order_2_11  connected_order_arc_1287  1
    order_2_11  connected_order_arc_1308  1
    order_2_11  connected_order_arc_1329  1
    order_2_11  connected_order_arc_1350  1
    order_2_11  order_active_lb_1383  1
    order_2_11  order_active_ub_1384  1
    order_2_11  fixed_segment_relative_order_1437  1
    visit_2_12  out_degree_1388  -1
    visit_2_12  in_degree_1389  -1
    visit_2_12  order_active_lb_1390  -1
    visit_2_12  order_active_ub_1391  -11
    visit_2_12  service_visit_def_1392  -1
    order_2_12  connected_order_arc_1140  1
    order_2_12  connected_order_arc_1161  1
    order_2_12  connected_order_arc_1182  1
    order_2_12  connected_order_arc_1199  -1
    order_2_12  connected_order_arc_1201  -1
    order_2_12  connected_order_arc_1203  -1
    order_2_12  connected_order_arc_1205  -1
    order_2_12  connected_order_arc_1207  -1
    order_2_12  connected_order_arc_1209  -1
    order_2_12  connected_order_arc_1211  -1
    order_2_12  connected_order_arc_1213  -1
    order_2_12  connected_order_arc_1215  -1
    order_2_12  connected_order_arc_1217  -1
    order_2_12  connected_order_arc_1226  1
    order_2_12  connected_order_arc_1247  1
    order_2_12  connected_order_arc_1268  1
    order_2_12  connected_order_arc_1289  1
    order_2_12  connected_order_arc_1310  1
    order_2_12  connected_order_arc_1331  1
    order_2_12  connected_order_arc_1352  1
    order_2_12  order_active_lb_1390  1
    order_2_12  order_active_ub_1391  1
    visit_2_13  out_degree_1394  -1
    visit_2_13  in_degree_1395  -1
    visit_2_13  order_active_lb_1396  -1
    visit_2_13  order_active_ub_1397  -11
    visit_2_13  service_visit_def_1398  -1
    order_2_13  connected_order_arc_1142  1
    order_2_13  connected_order_arc_1163  1
    order_2_13  connected_order_arc_1184  1
    order_2_13  connected_order_arc_1205  1
    order_2_13  connected_order_arc_1220  -1
    order_2_13  connected_order_arc_1222  -1
    order_2_13  connected_order_arc_1224  -1
    order_2_13  connected_order_arc_1226  -1
    order_2_13  connected_order_arc_1228  -1
    order_2_13  connected_order_arc_1230  -1
    order_2_13  connected_order_arc_1232  -1
    order_2_13  connected_order_arc_1234  -1
    order_2_13  connected_order_arc_1236  -1
    order_2_13  connected_order_arc_1238  -1
    order_2_13  connected_order_arc_1249  1
    order_2_13  connected_order_arc_1270  1
    order_2_13  connected_order_arc_1291  1
    order_2_13  connected_order_arc_1312  1
    order_2_13  connected_order_arc_1333  1
    order_2_13  connected_order_arc_1354  1
    order_2_13  order_active_lb_1396  1
    order_2_13  order_active_ub_1397  1
    visit_2_14  out_degree_1400  -1
    visit_2_14  in_degree_1401  -1
    visit_2_14  order_active_lb_1402  -1
    visit_2_14  order_active_ub_1403  -11
    visit_2_14  service_visit_def_1404  -1
    order_2_14  connected_order_arc_1144  1
    order_2_14  connected_order_arc_1165  1
    order_2_14  connected_order_arc_1186  1
    order_2_14  connected_order_arc_1207  1
    order_2_14  connected_order_arc_1228  1
    order_2_14  connected_order_arc_1241  -1
    order_2_14  connected_order_arc_1243  -1
    order_2_14  connected_order_arc_1245  -1
    order_2_14  connected_order_arc_1247  -1
    order_2_14  connected_order_arc_1249  -1
    order_2_14  connected_order_arc_1251  -1
    order_2_14  connected_order_arc_1253  -1
    order_2_14  connected_order_arc_1255  -1
    order_2_14  connected_order_arc_1257  -1
    order_2_14  connected_order_arc_1259  -1
    order_2_14  connected_order_arc_1272  1
    order_2_14  connected_order_arc_1293  1
    order_2_14  connected_order_arc_1314  1
    order_2_14  connected_order_arc_1335  1
    order_2_14  connected_order_arc_1356  1
    order_2_14  order_active_lb_1402  1
    order_2_14  order_active_ub_1403  1
    visit_2_15  out_degree_1406  -1
    visit_2_15  in_degree_1407  -1
    visit_2_15  order_active_lb_1408  -1
    visit_2_15  order_active_ub_1409  -11
    visit_2_15  service_visit_def_1410  -1
    order_2_15  connected_order_arc_1146  1
    order_2_15  connected_order_arc_1167  1
    order_2_15  connected_order_arc_1188  1
    order_2_15  connected_order_arc_1209  1
    order_2_15  connected_order_arc_1230  1
    order_2_15  connected_order_arc_1251  1
    order_2_15  connected_order_arc_1262  -1
    order_2_15  connected_order_arc_1264  -1
    order_2_15  connected_order_arc_1266  -1
    order_2_15  connected_order_arc_1268  -1
    order_2_15  connected_order_arc_1270  -1
    order_2_15  connected_order_arc_1272  -1
    order_2_15  connected_order_arc_1274  -1
    order_2_15  connected_order_arc_1276  -1
    order_2_15  connected_order_arc_1278  -1
    order_2_15  connected_order_arc_1280  -1
    order_2_15  connected_order_arc_1295  1
    order_2_15  connected_order_arc_1316  1
    order_2_15  connected_order_arc_1337  1
    order_2_15  connected_order_arc_1358  1
    order_2_15  order_active_lb_1408  1
    order_2_15  order_active_ub_1409  1
    visit_2_16  out_degree_1412  -1
    visit_2_16  in_degree_1413  -1
    visit_2_16  order_active_lb_1414  -1
    visit_2_16  order_active_ub_1415  -11
    visit_2_16  service_visit_def_1416  -1
    order_2_16  connected_order_arc_1148  1
    order_2_16  connected_order_arc_1169  1
    order_2_16  connected_order_arc_1190  1
    order_2_16  connected_order_arc_1211  1
    order_2_16  connected_order_arc_1232  1
    order_2_16  connected_order_arc_1253  1
    order_2_16  connected_order_arc_1274  1
    order_2_16  connected_order_arc_1283  -1
    order_2_16  connected_order_arc_1285  -1
    order_2_16  connected_order_arc_1287  -1
    order_2_16  connected_order_arc_1289  -1
    order_2_16  connected_order_arc_1291  -1
    order_2_16  connected_order_arc_1293  -1
    order_2_16  connected_order_arc_1295  -1
    order_2_16  connected_order_arc_1297  -1
    order_2_16  connected_order_arc_1299  -1
    order_2_16  connected_order_arc_1301  -1
    order_2_16  connected_order_arc_1318  1
    order_2_16  connected_order_arc_1339  1
    order_2_16  connected_order_arc_1360  1
    order_2_16  order_active_lb_1414  1
    order_2_16  order_active_ub_1415  1
    visit_2_17  out_degree_1418  -1
    visit_2_17  in_degree_1419  -1
    visit_2_17  order_active_lb_1420  -1
    visit_2_17  order_active_ub_1421  -11
    visit_2_17  service_visit_def_1422  -1
    order_2_17  connected_order_arc_1150  1
    order_2_17  connected_order_arc_1171  1
    order_2_17  connected_order_arc_1192  1
    order_2_17  connected_order_arc_1213  1
    order_2_17  connected_order_arc_1234  1
    order_2_17  connected_order_arc_1255  1
    order_2_17  connected_order_arc_1276  1
    order_2_17  connected_order_arc_1297  1
    order_2_17  connected_order_arc_1304  -1
    order_2_17  connected_order_arc_1306  -1
    order_2_17  connected_order_arc_1308  -1
    order_2_17  connected_order_arc_1310  -1
    order_2_17  connected_order_arc_1312  -1
    order_2_17  connected_order_arc_1314  -1
    order_2_17  connected_order_arc_1316  -1
    order_2_17  connected_order_arc_1318  -1
    order_2_17  connected_order_arc_1320  -1
    order_2_17  connected_order_arc_1322  -1
    order_2_17  connected_order_arc_1341  1
    order_2_17  connected_order_arc_1362  1
    order_2_17  order_active_lb_1420  1
    order_2_17  order_active_ub_1421  1
    visit_2_18  out_degree_1424  -1
    visit_2_18  in_degree_1425  -1
    visit_2_18  order_active_lb_1426  -1
    visit_2_18  order_active_ub_1427  -11
    visit_2_18  service_visit_def_1428  -1
    order_2_18  connected_order_arc_1152  1
    order_2_18  connected_order_arc_1173  1
    order_2_18  connected_order_arc_1194  1
    order_2_18  connected_order_arc_1215  1
    order_2_18  connected_order_arc_1236  1
    order_2_18  connected_order_arc_1257  1
    order_2_18  connected_order_arc_1278  1
    order_2_18  connected_order_arc_1299  1
    order_2_18  connected_order_arc_1320  1
    order_2_18  connected_order_arc_1325  -1
    order_2_18  connected_order_arc_1327  -1
    order_2_18  connected_order_arc_1329  -1
    order_2_18  connected_order_arc_1331  -1
    order_2_18  connected_order_arc_1333  -1
    order_2_18  connected_order_arc_1335  -1
    order_2_18  connected_order_arc_1337  -1
    order_2_18  connected_order_arc_1339  -1
    order_2_18  connected_order_arc_1341  -1
    order_2_18  connected_order_arc_1343  -1
    order_2_18  connected_order_arc_1364  1
    order_2_18  order_active_lb_1426  1
    order_2_18  order_active_ub_1427  1
    visit_2_19  out_degree_1430  -1
    visit_2_19  in_degree_1431  -1
    visit_2_19  order_active_lb_1432  -1
    visit_2_19  order_active_ub_1433  -11
    visit_2_19  service_visit_def_1434  -1
    order_2_19  connected_order_arc_1154  1
    order_2_19  connected_order_arc_1175  1
    order_2_19  connected_order_arc_1196  1
    order_2_19  connected_order_arc_1217  1
    order_2_19  connected_order_arc_1238  1
    order_2_19  connected_order_arc_1259  1
    order_2_19  connected_order_arc_1280  1
    order_2_19  connected_order_arc_1301  1
    order_2_19  connected_order_arc_1322  1
    order_2_19  connected_order_arc_1343  1
    order_2_19  connected_order_arc_1346  -1
    order_2_19  connected_order_arc_1348  -1
    order_2_19  connected_order_arc_1350  -1
    order_2_19  connected_order_arc_1352  -1
    order_2_19  connected_order_arc_1354  -1
    order_2_19  connected_order_arc_1356  -1
    order_2_19  connected_order_arc_1358  -1
    order_2_19  connected_order_arc_1360  -1
    order_2_19  connected_order_arc_1362  -1
    order_2_19  connected_order_arc_1364  -1
    order_2_19  order_active_lb_1432  1
    order_2_19  order_active_ub_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1122  -30
    arc_2_0_0  depot_departure_or_bypass_1365  1
    arc_2_0_0  depot_return_or_bypass_1366  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1122  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1123  -30
    arc_2_0_9  depot_departure_or_bypass_1365  1
    arc_2_0_9  in_degree_1368  1
    arc_2_0_9  original_T_including_depot_unload_1438  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1123  1
    load_2_0_9  segment_load_conservation_1371  -1
    load_2_0_9  segment_prefix_lb_1372  1
    load_2_0_9  segment_prefix_ub_1373  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1124  -30
    arc_2_0_10  depot_departure_or_bypass_1365  1
    arc_2_0_10  in_degree_1375  1
    arc_2_0_10  original_T_including_depot_unload_1438  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1124  1
    load_2_0_10  segment_load_conservation_1378  -1
    load_2_0_10  segment_prefix_lb_1379  1
    load_2_0_10  segment_prefix_ub_1380  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1125  -30
    arc_2_0_11  depot_departure_or_bypass_1365  1
    arc_2_0_11  in_degree_1382  1
    arc_2_0_11  original_T_including_depot_unload_1438  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1125  1
    load_2_0_11  segment_load_conservation_1385  -1
    load_2_0_11  segment_prefix_lb_1386  1
    load_2_0_11  segment_prefix_ub_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1126  -30
    arc_2_0_12  depot_departure_or_bypass_1365  1
    arc_2_0_12  in_degree_1389  1
    arc_2_0_12  original_T_including_depot_unload_1438  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1126  1
    load_2_0_12  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1127  -30
    arc_2_0_13  depot_departure_or_bypass_1365  1
    arc_2_0_13  in_degree_1395  1
    arc_2_0_13  original_T_including_depot_unload_1438  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1127  1
    load_2_0_13  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1128  -30
    arc_2_0_14  depot_departure_or_bypass_1365  1
    arc_2_0_14  in_degree_1401  1
    arc_2_0_14  original_T_including_depot_unload_1438  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1128  1
    load_2_0_14  free_load_conservation_1405  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1129  -30
    arc_2_0_15  depot_departure_or_bypass_1365  1
    arc_2_0_15  in_degree_1407  1
    arc_2_0_15  original_T_including_depot_unload_1438  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1129  1
    load_2_0_15  free_load_conservation_1411  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1130  -30
    arc_2_0_16  depot_departure_or_bypass_1365  1
    arc_2_0_16  in_degree_1413  1
    arc_2_0_16  original_T_including_depot_unload_1438  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1130  1
    load_2_0_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1131  -30
    arc_2_0_17  depot_departure_or_bypass_1365  1
    arc_2_0_17  in_degree_1419  1
    arc_2_0_17  original_T_including_depot_unload_1438  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1131  1
    load_2_0_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1132  -30
    arc_2_0_18  depot_departure_or_bypass_1365  1
    arc_2_0_18  in_degree_1425  1
    arc_2_0_18  original_T_including_depot_unload_1438  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1132  1
    load_2_0_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1133  -30
    arc_2_0_19  depot_departure_or_bypass_1365  1
    arc_2_0_19  in_degree_1431  1
    arc_2_0_19  original_T_including_depot_unload_1438  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1133  1
    load_2_0_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1134  -30
    arc_2_9_0  depot_return_or_bypass_1366  1
    arc_2_9_0  out_degree_1367  1
    arc_2_9_0  original_T_including_depot_unload_1438  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1134  1
    load_2_9_0  segment_load_conservation_1371  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1135  -30
    arc_2_9_10  connected_order_arc_1136  -12
    arc_2_9_10  out_degree_1367  1
    arc_2_9_10  in_degree_1375  1
    arc_2_9_10  original_T_including_depot_unload_1438  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1135  1
    load_2_9_10  segment_load_conservation_1371  1
    load_2_9_10  segment_load_conservation_1378  -1
    load_2_9_10  segment_prefix_lb_1379  1
    load_2_9_10  segment_prefix_ub_1380  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1137  -30
    arc_2_9_11  connected_order_arc_1138  -12
    arc_2_9_11  out_degree_1367  1
    arc_2_9_11  in_degree_1382  1
    arc_2_9_11  original_T_including_depot_unload_1438  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1137  1
    load_2_9_11  segment_load_conservation_1371  1
    load_2_9_11  segment_load_conservation_1385  -1
    load_2_9_11  segment_prefix_lb_1386  1
    load_2_9_11  segment_prefix_ub_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1139  -30
    arc_2_9_12  connected_order_arc_1140  -12
    arc_2_9_12  out_degree_1367  1
    arc_2_9_12  in_degree_1389  1
    arc_2_9_12  original_T_including_depot_unload_1438  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1139  1
    load_2_9_12  segment_load_conservation_1371  1
    load_2_9_12  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1141  -30
    arc_2_9_13  connected_order_arc_1142  -12
    arc_2_9_13  out_degree_1367  1
    arc_2_9_13  in_degree_1395  1
    arc_2_9_13  original_T_including_depot_unload_1438  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1141  1
    load_2_9_13  segment_load_conservation_1371  1
    load_2_9_13  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1143  -30
    arc_2_9_14  connected_order_arc_1144  -12
    arc_2_9_14  out_degree_1367  1
    arc_2_9_14  in_degree_1401  1
    arc_2_9_14  original_T_including_depot_unload_1438  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1143  1
    load_2_9_14  segment_load_conservation_1371  1
    load_2_9_14  free_load_conservation_1405  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1145  -30
    arc_2_9_15  connected_order_arc_1146  -12
    arc_2_9_15  out_degree_1367  1
    arc_2_9_15  in_degree_1407  1
    arc_2_9_15  original_T_including_depot_unload_1438  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1145  1
    load_2_9_15  segment_load_conservation_1371  1
    load_2_9_15  free_load_conservation_1411  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1147  -30
    arc_2_9_16  connected_order_arc_1148  -12
    arc_2_9_16  out_degree_1367  1
    arc_2_9_16  in_degree_1413  1
    arc_2_9_16  original_T_including_depot_unload_1438  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1147  1
    load_2_9_16  segment_load_conservation_1371  1
    load_2_9_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1149  -30
    arc_2_9_17  connected_order_arc_1150  -12
    arc_2_9_17  out_degree_1367  1
    arc_2_9_17  in_degree_1419  1
    arc_2_9_17  original_T_including_depot_unload_1438  1.1473765463273915e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1149  1
    load_2_9_17  segment_load_conservation_1371  1
    load_2_9_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1151  -30
    arc_2_9_18  connected_order_arc_1152  -12
    arc_2_9_18  out_degree_1367  1
    arc_2_9_18  in_degree_1425  1
    arc_2_9_18  original_T_including_depot_unload_1438  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1151  1
    load_2_9_18  segment_load_conservation_1371  1
    load_2_9_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1153  -30
    arc_2_9_19  connected_order_arc_1154  -12
    arc_2_9_19  out_degree_1367  1
    arc_2_9_19  in_degree_1431  1
    arc_2_9_19  original_T_including_depot_unload_1438  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1153  1
    load_2_9_19  segment_load_conservation_1371  1
    load_2_9_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1155  -30
    arc_2_10_0  depot_return_or_bypass_1366  1
    arc_2_10_0  out_degree_1374  1
    arc_2_10_0  original_T_including_depot_unload_1438  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1155  1
    load_2_10_0  segment_load_conservation_1378  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1156  -30
    arc_2_10_9  connected_order_arc_1157  -12
    arc_2_10_9  in_degree_1368  1
    arc_2_10_9  out_degree_1374  1
    arc_2_10_9  original_T_including_depot_unload_1438  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1156  1
    load_2_10_9  segment_load_conservation_1371  -1
    load_2_10_9  segment_prefix_lb_1372  1
    load_2_10_9  segment_prefix_ub_1373  1
    load_2_10_9  segment_load_conservation_1378  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1158  -30
    arc_2_10_11  connected_order_arc_1159  -12
    arc_2_10_11  out_degree_1374  1
    arc_2_10_11  in_degree_1382  1
    arc_2_10_11  original_T_including_depot_unload_1438  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1158  1
    load_2_10_11  segment_load_conservation_1378  1
    load_2_10_11  segment_load_conservation_1385  -1
    load_2_10_11  segment_prefix_lb_1386  1
    load_2_10_11  segment_prefix_ub_1387  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1160  -30
    arc_2_10_12  connected_order_arc_1161  -12
    arc_2_10_12  out_degree_1374  1
    arc_2_10_12  in_degree_1389  1
    arc_2_10_12  original_T_including_depot_unload_1438  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1160  1
    load_2_10_12  segment_load_conservation_1378  1
    load_2_10_12  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1162  -30
    arc_2_10_13  connected_order_arc_1163  -12
    arc_2_10_13  out_degree_1374  1
    arc_2_10_13  in_degree_1395  1
    arc_2_10_13  original_T_including_depot_unload_1438  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1162  1
    load_2_10_13  segment_load_conservation_1378  1
    load_2_10_13  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1164  -30
    arc_2_10_14  connected_order_arc_1165  -12
    arc_2_10_14  out_degree_1374  1
    arc_2_10_14  in_degree_1401  1
    arc_2_10_14  original_T_including_depot_unload_1438  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1164  1
    load_2_10_14  segment_load_conservation_1378  1
    load_2_10_14  free_load_conservation_1405  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1166  -30
    arc_2_10_15  connected_order_arc_1167  -12
    arc_2_10_15  out_degree_1374  1
    arc_2_10_15  in_degree_1407  1
    arc_2_10_15  original_T_including_depot_unload_1438  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1166  1
    load_2_10_15  segment_load_conservation_1378  1
    load_2_10_15  free_load_conservation_1411  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1168  -30
    arc_2_10_16  connected_order_arc_1169  -12
    arc_2_10_16  out_degree_1374  1
    arc_2_10_16  in_degree_1413  1
    arc_2_10_16  original_T_including_depot_unload_1438  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1168  1
    load_2_10_16  segment_load_conservation_1378  1
    load_2_10_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1170  -30
    arc_2_10_17  connected_order_arc_1171  -12
    arc_2_10_17  out_degree_1374  1
    arc_2_10_17  in_degree_1419  1
    arc_2_10_17  original_T_including_depot_unload_1438  1.7509294259345222e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1170  1
    load_2_10_17  segment_load_conservation_1378  1
    load_2_10_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1172  -30
    arc_2_10_18  connected_order_arc_1173  -12
    arc_2_10_18  out_degree_1374  1
    arc_2_10_18  in_degree_1425  1
    arc_2_10_18  original_T_including_depot_unload_1438  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1172  1
    load_2_10_18  segment_load_conservation_1378  1
    load_2_10_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1174  -30
    arc_2_10_19  connected_order_arc_1175  -12
    arc_2_10_19  out_degree_1374  1
    arc_2_10_19  in_degree_1431  1
    arc_2_10_19  original_T_including_depot_unload_1438  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1174  1
    load_2_10_19  segment_load_conservation_1378  1
    load_2_10_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1176  -30
    arc_2_11_0  depot_return_or_bypass_1366  1
    arc_2_11_0  out_degree_1381  1
    arc_2_11_0  original_T_including_depot_unload_1438  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1176  1
    load_2_11_0  segment_load_conservation_1385  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1177  -30
    arc_2_11_9  connected_order_arc_1178  -12
    arc_2_11_9  in_degree_1368  1
    arc_2_11_9  out_degree_1381  1
    arc_2_11_9  original_T_including_depot_unload_1438  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1177  1
    load_2_11_9  segment_load_conservation_1371  -1
    load_2_11_9  segment_prefix_lb_1372  1
    load_2_11_9  segment_prefix_ub_1373  1
    load_2_11_9  segment_load_conservation_1385  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1179  -30
    arc_2_11_10  connected_order_arc_1180  -12
    arc_2_11_10  in_degree_1375  1
    arc_2_11_10  out_degree_1381  1
    arc_2_11_10  original_T_including_depot_unload_1438  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1179  1
    load_2_11_10  segment_load_conservation_1378  -1
    load_2_11_10  segment_prefix_lb_1379  1
    load_2_11_10  segment_prefix_ub_1380  1
    load_2_11_10  segment_load_conservation_1385  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1181  -30
    arc_2_11_12  connected_order_arc_1182  -12
    arc_2_11_12  out_degree_1381  1
    arc_2_11_12  in_degree_1389  1
    arc_2_11_12  original_T_including_depot_unload_1438  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1181  1
    load_2_11_12  segment_load_conservation_1385  1
    load_2_11_12  free_load_conservation_1393  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1183  -30
    arc_2_11_13  connected_order_arc_1184  -12
    arc_2_11_13  out_degree_1381  1
    arc_2_11_13  in_degree_1395  1
    arc_2_11_13  original_T_including_depot_unload_1438  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1183  1
    load_2_11_13  segment_load_conservation_1385  1
    load_2_11_13  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1185  -30
    arc_2_11_14  connected_order_arc_1186  -12
    arc_2_11_14  out_degree_1381  1
    arc_2_11_14  in_degree_1401  1
    arc_2_11_14  original_T_including_depot_unload_1438  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1185  1
    load_2_11_14  segment_load_conservation_1385  1
    load_2_11_14  free_load_conservation_1405  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1187  -30
    arc_2_11_15  connected_order_arc_1188  -12
    arc_2_11_15  out_degree_1381  1
    arc_2_11_15  in_degree_1407  1
    arc_2_11_15  original_T_including_depot_unload_1438  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1187  1
    load_2_11_15  segment_load_conservation_1385  1
    load_2_11_15  free_load_conservation_1411  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1189  -30
    arc_2_11_16  connected_order_arc_1190  -12
    arc_2_11_16  out_degree_1381  1
    arc_2_11_16  in_degree_1413  1
    arc_2_11_16  original_T_including_depot_unload_1438  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1189  1
    load_2_11_16  segment_load_conservation_1385  1
    load_2_11_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1191  -30
    arc_2_11_17  connected_order_arc_1192  -12
    arc_2_11_17  out_degree_1381  1
    arc_2_11_17  in_degree_1419  1
    arc_2_11_17  original_T_including_depot_unload_1438  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1191  1
    load_2_11_17  segment_load_conservation_1385  1
    load_2_11_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1193  -30
    arc_2_11_18  connected_order_arc_1194  -12
    arc_2_11_18  out_degree_1381  1
    arc_2_11_18  in_degree_1425  1
    arc_2_11_18  original_T_including_depot_unload_1438  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1193  1
    load_2_11_18  segment_load_conservation_1385  1
    load_2_11_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1195  -30
    arc_2_11_19  connected_order_arc_1196  -12
    arc_2_11_19  out_degree_1381  1
    arc_2_11_19  in_degree_1431  1
    arc_2_11_19  original_T_including_depot_unload_1438  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1195  1
    load_2_11_19  segment_load_conservation_1385  1
    load_2_11_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1197  -30
    arc_2_12_0  depot_return_or_bypass_1366  1
    arc_2_12_0  out_degree_1388  1
    arc_2_12_0  original_T_including_depot_unload_1438  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1197  1
    load_2_12_0  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1198  -30
    arc_2_12_9  connected_order_arc_1199  -12
    arc_2_12_9  in_degree_1368  1
    arc_2_12_9  out_degree_1388  1
    arc_2_12_9  original_T_including_depot_unload_1438  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1198  1
    load_2_12_9  segment_load_conservation_1371  -1
    load_2_12_9  segment_prefix_lb_1372  1
    load_2_12_9  segment_prefix_ub_1373  1
    load_2_12_9  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1200  -30
    arc_2_12_10  connected_order_arc_1201  -12
    arc_2_12_10  in_degree_1375  1
    arc_2_12_10  out_degree_1388  1
    arc_2_12_10  original_T_including_depot_unload_1438  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1200  1
    load_2_12_10  segment_load_conservation_1378  -1
    load_2_12_10  segment_prefix_lb_1379  1
    load_2_12_10  segment_prefix_ub_1380  1
    load_2_12_10  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1202  -30
    arc_2_12_11  connected_order_arc_1203  -12
    arc_2_12_11  in_degree_1382  1
    arc_2_12_11  out_degree_1388  1
    arc_2_12_11  original_T_including_depot_unload_1438  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1202  1
    load_2_12_11  segment_load_conservation_1385  -1
    load_2_12_11  segment_prefix_lb_1386  1
    load_2_12_11  segment_prefix_ub_1387  1
    load_2_12_11  free_load_conservation_1393  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1204  -30
    arc_2_12_13  connected_order_arc_1205  -12
    arc_2_12_13  out_degree_1388  1
    arc_2_12_13  in_degree_1395  1
    arc_2_12_13  original_T_including_depot_unload_1438  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1204  1
    load_2_12_13  free_load_conservation_1393  1
    load_2_12_13  free_load_conservation_1399  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1206  -30
    arc_2_12_14  connected_order_arc_1207  -12
    arc_2_12_14  out_degree_1388  1
    arc_2_12_14  in_degree_1401  1
    arc_2_12_14  original_T_including_depot_unload_1438  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1206  1
    load_2_12_14  free_load_conservation_1393  1
    load_2_12_14  free_load_conservation_1405  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1208  -30
    arc_2_12_15  connected_order_arc_1209  -12
    arc_2_12_15  out_degree_1388  1
    arc_2_12_15  in_degree_1407  1
    arc_2_12_15  original_T_including_depot_unload_1438  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1208  1
    load_2_12_15  free_load_conservation_1393  1
    load_2_12_15  free_load_conservation_1411  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1210  -30
    arc_2_12_16  connected_order_arc_1211  -12
    arc_2_12_16  out_degree_1388  1
    arc_2_12_16  in_degree_1413  1
    arc_2_12_16  original_T_including_depot_unload_1438  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1210  1
    load_2_12_16  free_load_conservation_1393  1
    load_2_12_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1212  -30
    arc_2_12_17  connected_order_arc_1213  -12
    arc_2_12_17  out_degree_1388  1
    arc_2_12_17  in_degree_1419  1
    arc_2_12_17  original_T_including_depot_unload_1438  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1212  1
    load_2_12_17  free_load_conservation_1393  1
    load_2_12_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1214  -30
    arc_2_12_18  connected_order_arc_1215  -12
    arc_2_12_18  out_degree_1388  1
    arc_2_12_18  in_degree_1425  1
    arc_2_12_18  original_T_including_depot_unload_1438  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1214  1
    load_2_12_18  free_load_conservation_1393  1
    load_2_12_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1216  -30
    arc_2_12_19  connected_order_arc_1217  -12
    arc_2_12_19  out_degree_1388  1
    arc_2_12_19  in_degree_1431  1
    arc_2_12_19  original_T_including_depot_unload_1438  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1216  1
    load_2_12_19  free_load_conservation_1393  1
    load_2_12_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1218  -30
    arc_2_13_0  depot_return_or_bypass_1366  1
    arc_2_13_0  out_degree_1394  1
    arc_2_13_0  original_T_including_depot_unload_1438  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1218  1
    load_2_13_0  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1219  -30
    arc_2_13_9  connected_order_arc_1220  -12
    arc_2_13_9  in_degree_1368  1
    arc_2_13_9  out_degree_1394  1
    arc_2_13_9  original_T_including_depot_unload_1438  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1219  1
    load_2_13_9  segment_load_conservation_1371  -1
    load_2_13_9  segment_prefix_lb_1372  1
    load_2_13_9  segment_prefix_ub_1373  1
    load_2_13_9  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1221  -30
    arc_2_13_10  connected_order_arc_1222  -12
    arc_2_13_10  in_degree_1375  1
    arc_2_13_10  out_degree_1394  1
    arc_2_13_10  original_T_including_depot_unload_1438  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1221  1
    load_2_13_10  segment_load_conservation_1378  -1
    load_2_13_10  segment_prefix_lb_1379  1
    load_2_13_10  segment_prefix_ub_1380  1
    load_2_13_10  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1223  -30
    arc_2_13_11  connected_order_arc_1224  -12
    arc_2_13_11  in_degree_1382  1
    arc_2_13_11  out_degree_1394  1
    arc_2_13_11  original_T_including_depot_unload_1438  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1223  1
    load_2_13_11  segment_load_conservation_1385  -1
    load_2_13_11  segment_prefix_lb_1386  1
    load_2_13_11  segment_prefix_ub_1387  1
    load_2_13_11  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1225  -30
    arc_2_13_12  connected_order_arc_1226  -12
    arc_2_13_12  in_degree_1389  1
    arc_2_13_12  out_degree_1394  1
    arc_2_13_12  original_T_including_depot_unload_1438  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1225  1
    load_2_13_12  free_load_conservation_1393  -1
    load_2_13_12  free_load_conservation_1399  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1227  -30
    arc_2_13_14  connected_order_arc_1228  -12
    arc_2_13_14  out_degree_1394  1
    arc_2_13_14  in_degree_1401  1
    arc_2_13_14  original_T_including_depot_unload_1438  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1227  1
    load_2_13_14  free_load_conservation_1399  1
    load_2_13_14  free_load_conservation_1405  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1229  -30
    arc_2_13_15  connected_order_arc_1230  -12
    arc_2_13_15  out_degree_1394  1
    arc_2_13_15  in_degree_1407  1
    arc_2_13_15  original_T_including_depot_unload_1438  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1229  1
    load_2_13_15  free_load_conservation_1399  1
    load_2_13_15  free_load_conservation_1411  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1231  -30
    arc_2_13_16  connected_order_arc_1232  -12
    arc_2_13_16  out_degree_1394  1
    arc_2_13_16  in_degree_1413  1
    arc_2_13_16  original_T_including_depot_unload_1438  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1231  1
    load_2_13_16  free_load_conservation_1399  1
    load_2_13_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1233  -30
    arc_2_13_17  connected_order_arc_1234  -12
    arc_2_13_17  out_degree_1394  1
    arc_2_13_17  in_degree_1419  1
    arc_2_13_17  original_T_including_depot_unload_1438  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1233  1
    load_2_13_17  free_load_conservation_1399  1
    load_2_13_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1235  -30
    arc_2_13_18  connected_order_arc_1236  -12
    arc_2_13_18  out_degree_1394  1
    arc_2_13_18  in_degree_1425  1
    arc_2_13_18  original_T_including_depot_unload_1438  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1235  1
    load_2_13_18  free_load_conservation_1399  1
    load_2_13_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1237  -30
    arc_2_13_19  connected_order_arc_1238  -12
    arc_2_13_19  out_degree_1394  1
    arc_2_13_19  in_degree_1431  1
    arc_2_13_19  original_T_including_depot_unload_1438  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1237  1
    load_2_13_19  free_load_conservation_1399  1
    load_2_13_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1239  -30
    arc_2_14_0  depot_return_or_bypass_1366  1
    arc_2_14_0  out_degree_1400  1
    arc_2_14_0  original_T_including_depot_unload_1438  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1239  1
    load_2_14_0  free_load_conservation_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1240  -30
    arc_2_14_9  connected_order_arc_1241  -12
    arc_2_14_9  in_degree_1368  1
    arc_2_14_9  out_degree_1400  1
    arc_2_14_9  original_T_including_depot_unload_1438  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1240  1
    load_2_14_9  segment_load_conservation_1371  -1
    load_2_14_9  segment_prefix_lb_1372  1
    load_2_14_9  segment_prefix_ub_1373  1
    load_2_14_9  free_load_conservation_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1242  -30
    arc_2_14_10  connected_order_arc_1243  -12
    arc_2_14_10  in_degree_1375  1
    arc_2_14_10  out_degree_1400  1
    arc_2_14_10  original_T_including_depot_unload_1438  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1242  1
    load_2_14_10  segment_load_conservation_1378  -1
    load_2_14_10  segment_prefix_lb_1379  1
    load_2_14_10  segment_prefix_ub_1380  1
    load_2_14_10  free_load_conservation_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1244  -30
    arc_2_14_11  connected_order_arc_1245  -12
    arc_2_14_11  in_degree_1382  1
    arc_2_14_11  out_degree_1400  1
    arc_2_14_11  original_T_including_depot_unload_1438  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1244  1
    load_2_14_11  segment_load_conservation_1385  -1
    load_2_14_11  segment_prefix_lb_1386  1
    load_2_14_11  segment_prefix_ub_1387  1
    load_2_14_11  free_load_conservation_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1246  -30
    arc_2_14_12  connected_order_arc_1247  -12
    arc_2_14_12  in_degree_1389  1
    arc_2_14_12  out_degree_1400  1
    arc_2_14_12  original_T_including_depot_unload_1438  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1246  1
    load_2_14_12  free_load_conservation_1393  -1
    load_2_14_12  free_load_conservation_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1248  -30
    arc_2_14_13  connected_order_arc_1249  -12
    arc_2_14_13  in_degree_1395  1
    arc_2_14_13  out_degree_1400  1
    arc_2_14_13  original_T_including_depot_unload_1438  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1248  1
    load_2_14_13  free_load_conservation_1399  -1
    load_2_14_13  free_load_conservation_1405  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1250  -30
    arc_2_14_15  connected_order_arc_1251  -12
    arc_2_14_15  out_degree_1400  1
    arc_2_14_15  in_degree_1407  1
    arc_2_14_15  original_T_including_depot_unload_1438  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1250  1
    load_2_14_15  free_load_conservation_1405  1
    load_2_14_15  free_load_conservation_1411  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1252  -30
    arc_2_14_16  connected_order_arc_1253  -12
    arc_2_14_16  out_degree_1400  1
    arc_2_14_16  in_degree_1413  1
    arc_2_14_16  original_T_including_depot_unload_1438  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1252  1
    load_2_14_16  free_load_conservation_1405  1
    load_2_14_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1254  -30
    arc_2_14_17  connected_order_arc_1255  -12
    arc_2_14_17  out_degree_1400  1
    arc_2_14_17  in_degree_1419  1
    arc_2_14_17  original_T_including_depot_unload_1438  1.4068884127351855e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1254  1
    load_2_14_17  free_load_conservation_1405  1
    load_2_14_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1256  -30
    arc_2_14_18  connected_order_arc_1257  -12
    arc_2_14_18  out_degree_1400  1
    arc_2_14_18  in_degree_1425  1
    arc_2_14_18  original_T_including_depot_unload_1438  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1256  1
    load_2_14_18  free_load_conservation_1405  1
    load_2_14_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1258  -30
    arc_2_14_19  connected_order_arc_1259  -12
    arc_2_14_19  out_degree_1400  1
    arc_2_14_19  in_degree_1431  1
    arc_2_14_19  original_T_including_depot_unload_1438  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1258  1
    load_2_14_19  free_load_conservation_1405  1
    load_2_14_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1260  -30
    arc_2_15_0  depot_return_or_bypass_1366  1
    arc_2_15_0  out_degree_1406  1
    arc_2_15_0  original_T_including_depot_unload_1438  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1260  1
    load_2_15_0  free_load_conservation_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1261  -30
    arc_2_15_9  connected_order_arc_1262  -12
    arc_2_15_9  in_degree_1368  1
    arc_2_15_9  out_degree_1406  1
    arc_2_15_9  original_T_including_depot_unload_1438  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1261  1
    load_2_15_9  segment_load_conservation_1371  -1
    load_2_15_9  segment_prefix_lb_1372  1
    load_2_15_9  segment_prefix_ub_1373  1
    load_2_15_9  free_load_conservation_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1263  -30
    arc_2_15_10  connected_order_arc_1264  -12
    arc_2_15_10  in_degree_1375  1
    arc_2_15_10  out_degree_1406  1
    arc_2_15_10  original_T_including_depot_unload_1438  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1263  1
    load_2_15_10  segment_load_conservation_1378  -1
    load_2_15_10  segment_prefix_lb_1379  1
    load_2_15_10  segment_prefix_ub_1380  1
    load_2_15_10  free_load_conservation_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1265  -30
    arc_2_15_11  connected_order_arc_1266  -12
    arc_2_15_11  in_degree_1382  1
    arc_2_15_11  out_degree_1406  1
    arc_2_15_11  original_T_including_depot_unload_1438  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1265  1
    load_2_15_11  segment_load_conservation_1385  -1
    load_2_15_11  segment_prefix_lb_1386  1
    load_2_15_11  segment_prefix_ub_1387  1
    load_2_15_11  free_load_conservation_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1267  -30
    arc_2_15_12  connected_order_arc_1268  -12
    arc_2_15_12  in_degree_1389  1
    arc_2_15_12  out_degree_1406  1
    arc_2_15_12  original_T_including_depot_unload_1438  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1267  1
    load_2_15_12  free_load_conservation_1393  -1
    load_2_15_12  free_load_conservation_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1269  -30
    arc_2_15_13  connected_order_arc_1270  -12
    arc_2_15_13  in_degree_1395  1
    arc_2_15_13  out_degree_1406  1
    arc_2_15_13  original_T_including_depot_unload_1438  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1269  1
    load_2_15_13  free_load_conservation_1399  -1
    load_2_15_13  free_load_conservation_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1271  -30
    arc_2_15_14  connected_order_arc_1272  -12
    arc_2_15_14  in_degree_1401  1
    arc_2_15_14  out_degree_1406  1
    arc_2_15_14  original_T_including_depot_unload_1438  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1271  1
    load_2_15_14  free_load_conservation_1405  -1
    load_2_15_14  free_load_conservation_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1273  -30
    arc_2_15_16  connected_order_arc_1274  -12
    arc_2_15_16  out_degree_1406  1
    arc_2_15_16  in_degree_1413  1
    arc_2_15_16  original_T_including_depot_unload_1438  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1273  1
    load_2_15_16  free_load_conservation_1411  1
    load_2_15_16  free_load_conservation_1417  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1275  -30
    arc_2_15_17  connected_order_arc_1276  -12
    arc_2_15_17  out_degree_1406  1
    arc_2_15_17  in_degree_1419  1
    arc_2_15_17  original_T_including_depot_unload_1438  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1275  1
    load_2_15_17  free_load_conservation_1411  1
    load_2_15_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1277  -30
    arc_2_15_18  connected_order_arc_1278  -12
    arc_2_15_18  out_degree_1406  1
    arc_2_15_18  in_degree_1425  1
    arc_2_15_18  original_T_including_depot_unload_1438  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1277  1
    load_2_15_18  free_load_conservation_1411  1
    load_2_15_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1279  -30
    arc_2_15_19  connected_order_arc_1280  -12
    arc_2_15_19  out_degree_1406  1
    arc_2_15_19  in_degree_1431  1
    arc_2_15_19  original_T_including_depot_unload_1438  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1279  1
    load_2_15_19  free_load_conservation_1411  1
    load_2_15_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1281  -30
    arc_2_16_0  depot_return_or_bypass_1366  1
    arc_2_16_0  out_degree_1412  1
    arc_2_16_0  original_T_including_depot_unload_1438  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1281  1
    load_2_16_0  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1282  -30
    arc_2_16_9  connected_order_arc_1283  -12
    arc_2_16_9  in_degree_1368  1
    arc_2_16_9  out_degree_1412  1
    arc_2_16_9  original_T_including_depot_unload_1438  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1282  1
    load_2_16_9  segment_load_conservation_1371  -1
    load_2_16_9  segment_prefix_lb_1372  1
    load_2_16_9  segment_prefix_ub_1373  1
    load_2_16_9  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1284  -30
    arc_2_16_10  connected_order_arc_1285  -12
    arc_2_16_10  in_degree_1375  1
    arc_2_16_10  out_degree_1412  1
    arc_2_16_10  original_T_including_depot_unload_1438  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1284  1
    load_2_16_10  segment_load_conservation_1378  -1
    load_2_16_10  segment_prefix_lb_1379  1
    load_2_16_10  segment_prefix_ub_1380  1
    load_2_16_10  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1286  -30
    arc_2_16_11  connected_order_arc_1287  -12
    arc_2_16_11  in_degree_1382  1
    arc_2_16_11  out_degree_1412  1
    arc_2_16_11  original_T_including_depot_unload_1438  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1286  1
    load_2_16_11  segment_load_conservation_1385  -1
    load_2_16_11  segment_prefix_lb_1386  1
    load_2_16_11  segment_prefix_ub_1387  1
    load_2_16_11  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1288  -30
    arc_2_16_12  connected_order_arc_1289  -12
    arc_2_16_12  in_degree_1389  1
    arc_2_16_12  out_degree_1412  1
    arc_2_16_12  original_T_including_depot_unload_1438  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1288  1
    load_2_16_12  free_load_conservation_1393  -1
    load_2_16_12  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1290  -30
    arc_2_16_13  connected_order_arc_1291  -12
    arc_2_16_13  in_degree_1395  1
    arc_2_16_13  out_degree_1412  1
    arc_2_16_13  original_T_including_depot_unload_1438  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1290  1
    load_2_16_13  free_load_conservation_1399  -1
    load_2_16_13  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1292  -30
    arc_2_16_14  connected_order_arc_1293  -12
    arc_2_16_14  in_degree_1401  1
    arc_2_16_14  out_degree_1412  1
    arc_2_16_14  original_T_including_depot_unload_1438  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1292  1
    load_2_16_14  free_load_conservation_1405  -1
    load_2_16_14  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1294  -30
    arc_2_16_15  connected_order_arc_1295  -12
    arc_2_16_15  in_degree_1407  1
    arc_2_16_15  out_degree_1412  1
    arc_2_16_15  original_T_including_depot_unload_1438  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1294  1
    load_2_16_15  free_load_conservation_1411  -1
    load_2_16_15  free_load_conservation_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1296  -30
    arc_2_16_17  connected_order_arc_1297  -12
    arc_2_16_17  out_degree_1412  1
    arc_2_16_17  in_degree_1419  1
    arc_2_16_17  original_T_including_depot_unload_1438  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1296  1
    load_2_16_17  free_load_conservation_1417  1
    load_2_16_17  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1298  -30
    arc_2_16_18  connected_order_arc_1299  -12
    arc_2_16_18  out_degree_1412  1
    arc_2_16_18  in_degree_1425  1
    arc_2_16_18  original_T_including_depot_unload_1438  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1298  1
    load_2_16_18  free_load_conservation_1417  1
    load_2_16_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1300  -30
    arc_2_16_19  connected_order_arc_1301  -12
    arc_2_16_19  out_degree_1412  1
    arc_2_16_19  in_degree_1431  1
    arc_2_16_19  original_T_including_depot_unload_1438  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1300  1
    load_2_16_19  free_load_conservation_1417  1
    load_2_16_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1302  -30
    arc_2_17_0  depot_return_or_bypass_1366  1
    arc_2_17_0  out_degree_1418  1
    arc_2_17_0  original_T_including_depot_unload_1438  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1302  1
    load_2_17_0  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1303  -30
    arc_2_17_9  connected_order_arc_1304  -12
    arc_2_17_9  in_degree_1368  1
    arc_2_17_9  out_degree_1418  1
    arc_2_17_9  original_T_including_depot_unload_1438  1.1473765463273915e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1303  1
    load_2_17_9  segment_load_conservation_1371  -1
    load_2_17_9  segment_prefix_lb_1372  1
    load_2_17_9  segment_prefix_ub_1373  1
    load_2_17_9  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1305  -30
    arc_2_17_10  connected_order_arc_1306  -12
    arc_2_17_10  in_degree_1375  1
    arc_2_17_10  out_degree_1418  1
    arc_2_17_10  original_T_including_depot_unload_1438  1.7509294259345222e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1305  1
    load_2_17_10  segment_load_conservation_1378  -1
    load_2_17_10  segment_prefix_lb_1379  1
    load_2_17_10  segment_prefix_ub_1380  1
    load_2_17_10  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1307  -30
    arc_2_17_11  connected_order_arc_1308  -12
    arc_2_17_11  in_degree_1382  1
    arc_2_17_11  out_degree_1418  1
    arc_2_17_11  original_T_including_depot_unload_1438  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1307  1
    load_2_17_11  segment_load_conservation_1385  -1
    load_2_17_11  segment_prefix_lb_1386  1
    load_2_17_11  segment_prefix_ub_1387  1
    load_2_17_11  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1309  -30
    arc_2_17_12  connected_order_arc_1310  -12
    arc_2_17_12  in_degree_1389  1
    arc_2_17_12  out_degree_1418  1
    arc_2_17_12  original_T_including_depot_unload_1438  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1309  1
    load_2_17_12  free_load_conservation_1393  -1
    load_2_17_12  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1311  -30
    arc_2_17_13  connected_order_arc_1312  -12
    arc_2_17_13  in_degree_1395  1
    arc_2_17_13  out_degree_1418  1
    arc_2_17_13  original_T_including_depot_unload_1438  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1311  1
    load_2_17_13  free_load_conservation_1399  -1
    load_2_17_13  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1313  -30
    arc_2_17_14  connected_order_arc_1314  -12
    arc_2_17_14  in_degree_1401  1
    arc_2_17_14  out_degree_1418  1
    arc_2_17_14  original_T_including_depot_unload_1438  1.4068884127351855e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1313  1
    load_2_17_14  free_load_conservation_1405  -1
    load_2_17_14  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1315  -30
    arc_2_17_15  connected_order_arc_1316  -12
    arc_2_17_15  in_degree_1407  1
    arc_2_17_15  out_degree_1418  1
    arc_2_17_15  original_T_including_depot_unload_1438  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1315  1
    load_2_17_15  free_load_conservation_1411  -1
    load_2_17_15  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1317  -30
    arc_2_17_16  connected_order_arc_1318  -12
    arc_2_17_16  in_degree_1413  1
    arc_2_17_16  out_degree_1418  1
    arc_2_17_16  original_T_including_depot_unload_1438  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1317  1
    load_2_17_16  free_load_conservation_1417  -1
    load_2_17_16  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1319  -30
    arc_2_17_18  connected_order_arc_1320  -12
    arc_2_17_18  out_degree_1418  1
    arc_2_17_18  in_degree_1425  1
    arc_2_17_18  original_T_including_depot_unload_1438  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1319  1
    load_2_17_18  free_load_conservation_1423  1
    load_2_17_18  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1321  -30
    arc_2_17_19  connected_order_arc_1322  -12
    arc_2_17_19  out_degree_1418  1
    arc_2_17_19  in_degree_1431  1
    arc_2_17_19  original_T_including_depot_unload_1438  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1321  1
    load_2_17_19  free_load_conservation_1423  1
    load_2_17_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1323  -30
    arc_2_18_0  depot_return_or_bypass_1366  1
    arc_2_18_0  out_degree_1424  1
    arc_2_18_0  original_T_including_depot_unload_1438  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1323  1
    load_2_18_0  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1324  -30
    arc_2_18_9  connected_order_arc_1325  -12
    arc_2_18_9  in_degree_1368  1
    arc_2_18_9  out_degree_1424  1
    arc_2_18_9  original_T_including_depot_unload_1438  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1324  1
    load_2_18_9  segment_load_conservation_1371  -1
    load_2_18_9  segment_prefix_lb_1372  1
    load_2_18_9  segment_prefix_ub_1373  1
    load_2_18_9  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1326  -30
    arc_2_18_10  connected_order_arc_1327  -12
    arc_2_18_10  in_degree_1375  1
    arc_2_18_10  out_degree_1424  1
    arc_2_18_10  original_T_including_depot_unload_1438  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1326  1
    load_2_18_10  segment_load_conservation_1378  -1
    load_2_18_10  segment_prefix_lb_1379  1
    load_2_18_10  segment_prefix_ub_1380  1
    load_2_18_10  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1328  -30
    arc_2_18_11  connected_order_arc_1329  -12
    arc_2_18_11  in_degree_1382  1
    arc_2_18_11  out_degree_1424  1
    arc_2_18_11  original_T_including_depot_unload_1438  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1328  1
    load_2_18_11  segment_load_conservation_1385  -1
    load_2_18_11  segment_prefix_lb_1386  1
    load_2_18_11  segment_prefix_ub_1387  1
    load_2_18_11  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1330  -30
    arc_2_18_12  connected_order_arc_1331  -12
    arc_2_18_12  in_degree_1389  1
    arc_2_18_12  out_degree_1424  1
    arc_2_18_12  original_T_including_depot_unload_1438  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1330  1
    load_2_18_12  free_load_conservation_1393  -1
    load_2_18_12  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1332  -30
    arc_2_18_13  connected_order_arc_1333  -12
    arc_2_18_13  in_degree_1395  1
    arc_2_18_13  out_degree_1424  1
    arc_2_18_13  original_T_including_depot_unload_1438  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1332  1
    load_2_18_13  free_load_conservation_1399  -1
    load_2_18_13  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1334  -30
    arc_2_18_14  connected_order_arc_1335  -12
    arc_2_18_14  in_degree_1401  1
    arc_2_18_14  out_degree_1424  1
    arc_2_18_14  original_T_including_depot_unload_1438  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1334  1
    load_2_18_14  free_load_conservation_1405  -1
    load_2_18_14  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1336  -30
    arc_2_18_15  connected_order_arc_1337  -12
    arc_2_18_15  in_degree_1407  1
    arc_2_18_15  out_degree_1424  1
    arc_2_18_15  original_T_including_depot_unload_1438  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1336  1
    load_2_18_15  free_load_conservation_1411  -1
    load_2_18_15  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1338  -30
    arc_2_18_16  connected_order_arc_1339  -12
    arc_2_18_16  in_degree_1413  1
    arc_2_18_16  out_degree_1424  1
    arc_2_18_16  original_T_including_depot_unload_1438  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1338  1
    load_2_18_16  free_load_conservation_1417  -1
    load_2_18_16  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1340  -30
    arc_2_18_17  connected_order_arc_1341  -12
    arc_2_18_17  in_degree_1419  1
    arc_2_18_17  out_degree_1424  1
    arc_2_18_17  original_T_including_depot_unload_1438  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1340  1
    load_2_18_17  free_load_conservation_1423  -1
    load_2_18_17  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1342  -30
    arc_2_18_19  connected_order_arc_1343  -12
    arc_2_18_19  out_degree_1424  1
    arc_2_18_19  in_degree_1431  1
    arc_2_18_19  original_T_including_depot_unload_1438  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1342  1
    load_2_18_19  free_load_conservation_1429  1
    load_2_18_19  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1344  -30
    arc_2_19_0  depot_return_or_bypass_1366  1
    arc_2_19_0  out_degree_1430  1
    arc_2_19_0  original_T_including_depot_unload_1438  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1344  1
    load_2_19_0  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1345  -30
    arc_2_19_9  connected_order_arc_1346  -12
    arc_2_19_9  in_degree_1368  1
    arc_2_19_9  out_degree_1430  1
    arc_2_19_9  original_T_including_depot_unload_1438  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1345  1
    load_2_19_9  segment_load_conservation_1371  -1
    load_2_19_9  segment_prefix_lb_1372  1
    load_2_19_9  segment_prefix_ub_1373  1
    load_2_19_9  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1347  -30
    arc_2_19_10  connected_order_arc_1348  -12
    arc_2_19_10  in_degree_1375  1
    arc_2_19_10  out_degree_1430  1
    arc_2_19_10  original_T_including_depot_unload_1438  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1347  1
    load_2_19_10  segment_load_conservation_1378  -1
    load_2_19_10  segment_prefix_lb_1379  1
    load_2_19_10  segment_prefix_ub_1380  1
    load_2_19_10  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1349  -30
    arc_2_19_11  connected_order_arc_1350  -12
    arc_2_19_11  in_degree_1382  1
    arc_2_19_11  out_degree_1430  1
    arc_2_19_11  original_T_including_depot_unload_1438  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1349  1
    load_2_19_11  segment_load_conservation_1385  -1
    load_2_19_11  segment_prefix_lb_1386  1
    load_2_19_11  segment_prefix_ub_1387  1
    load_2_19_11  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1351  -30
    arc_2_19_12  connected_order_arc_1352  -12
    arc_2_19_12  in_degree_1389  1
    arc_2_19_12  out_degree_1430  1
    arc_2_19_12  original_T_including_depot_unload_1438  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1351  1
    load_2_19_12  free_load_conservation_1393  -1
    load_2_19_12  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1353  -30
    arc_2_19_13  connected_order_arc_1354  -12
    arc_2_19_13  in_degree_1395  1
    arc_2_19_13  out_degree_1430  1
    arc_2_19_13  original_T_including_depot_unload_1438  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1353  1
    load_2_19_13  free_load_conservation_1399  -1
    load_2_19_13  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1355  -30
    arc_2_19_14  connected_order_arc_1356  -12
    arc_2_19_14  in_degree_1401  1
    arc_2_19_14  out_degree_1430  1
    arc_2_19_14  original_T_including_depot_unload_1438  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1355  1
    load_2_19_14  free_load_conservation_1405  -1
    load_2_19_14  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1357  -30
    arc_2_19_15  connected_order_arc_1358  -12
    arc_2_19_15  in_degree_1407  1
    arc_2_19_15  out_degree_1430  1
    arc_2_19_15  original_T_including_depot_unload_1438  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1357  1
    load_2_19_15  free_load_conservation_1411  -1
    load_2_19_15  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1359  -30
    arc_2_19_16  connected_order_arc_1360  -12
    arc_2_19_16  in_degree_1413  1
    arc_2_19_16  out_degree_1430  1
    arc_2_19_16  original_T_including_depot_unload_1438  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1359  1
    load_2_19_16  free_load_conservation_1417  -1
    load_2_19_16  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1361  -30
    arc_2_19_17  connected_order_arc_1362  -12
    arc_2_19_17  in_degree_1419  1
    arc_2_19_17  out_degree_1430  1
    arc_2_19_17  original_T_including_depot_unload_1438  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1361  1
    load_2_19_17  free_load_conservation_1423  -1
    load_2_19_17  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1363  -30
    arc_2_19_18  connected_order_arc_1364  -12
    arc_2_19_18  in_degree_1425  1
    arc_2_19_18  out_degree_1430  1
    arc_2_19_18  original_T_including_depot_unload_1438  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1363  1
    load_2_19_18  free_load_conservation_1429  -1
    load_2_19_18  free_load_conservation_1435  1
RHS
    RHS1      OBJ       -2.4813816049954723e-01
    RHS1      onehot_34_32  1
    RHS1      onehot_31_59  1
    RHS1      onehot_35_94  1
    RHS1      onehot_32_137  1
    RHS1      onehot_27_154  1
    RHS1      onehot_25_167  1
    RHS1      onehot_22_202  1
    RHS1      onehot_26_223  1
    RHS1      stock_ub_227  26
    RHS1      parent_nonstrict_scope_228  3.3621192765781355e-01
    RHS1      normalization_285  1
    RHS1      connected_order_arc_395  -12
    RHS1      connected_order_arc_397  -12
    RHS1      connected_order_arc_399  -12
    RHS1      connected_order_arc_401  -12
    RHS1      connected_order_arc_403  -12
    RHS1      connected_order_arc_405  -12
    RHS1      connected_order_arc_407  -12
    RHS1      connected_order_arc_409  -12
    RHS1      connected_order_arc_411  -12
    RHS1      connected_order_arc_413  -12
    RHS1      connected_order_arc_415  -12
    RHS1      connected_order_arc_418  -12
    RHS1      connected_order_arc_420  -12
    RHS1      connected_order_arc_422  -12
    RHS1      connected_order_arc_424  -12
    RHS1      connected_order_arc_426  -12
    RHS1      connected_order_arc_428  -12
    RHS1      connected_order_arc_430  -12
    RHS1      connected_order_arc_432  -12
    RHS1      connected_order_arc_434  -12
    RHS1      connected_order_arc_436  -12
    RHS1      connected_order_arc_438  -12
    RHS1      connected_order_arc_441  -12
    RHS1      connected_order_arc_443  -12
    RHS1      connected_order_arc_445  -12
    RHS1      connected_order_arc_447  -12
    RHS1      connected_order_arc_449  -12
    RHS1      connected_order_arc_451  -12
    RHS1      connected_order_arc_453  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_464  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_470  -12
    RHS1      connected_order_arc_472  -12
    RHS1      connected_order_arc_474  -12
    RHS1      connected_order_arc_476  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_487  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_493  -12
    RHS1      connected_order_arc_495  -12
    RHS1      connected_order_arc_497  -12
    RHS1      connected_order_arc_499  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_510  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_516  -12
    RHS1      connected_order_arc_518  -12
    RHS1      connected_order_arc_520  -12
    RHS1      connected_order_arc_522  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_533  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_539  -12
    RHS1      connected_order_arc_541  -12
    RHS1      connected_order_arc_543  -12
    RHS1      connected_order_arc_545  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_556  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_562  -12
    RHS1      connected_order_arc_564  -12
    RHS1      connected_order_arc_566  -12
    RHS1      connected_order_arc_568  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_579  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_585  -12
    RHS1      connected_order_arc_587  -12
    RHS1      connected_order_arc_589  -12
    RHS1      connected_order_arc_591  -12
    RHS1      connected_order_arc_593  -12
    RHS1      connected_order_arc_595  -12
    RHS1      connected_order_arc_597  -12
    RHS1      connected_order_arc_599  -12
    RHS1      connected_order_arc_602  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_608  -12
    RHS1      connected_order_arc_610  -12
    RHS1      connected_order_arc_612  -12
    RHS1      connected_order_arc_614  -12
    RHS1      connected_order_arc_616  -12
    RHS1      connected_order_arc_618  -12
    RHS1      connected_order_arc_620  -12
    RHS1      connected_order_arc_622  -12
    RHS1      connected_order_arc_625  -12
    RHS1      connected_order_arc_627  -12
    RHS1      connected_order_arc_629  -12
    RHS1      connected_order_arc_631  -12
    RHS1      connected_order_arc_633  -12
    RHS1      connected_order_arc_635  -12
    RHS1      connected_order_arc_637  -12
    RHS1      connected_order_arc_639  -12
    RHS1      connected_order_arc_641  -12
    RHS1      connected_order_arc_643  -12
    RHS1      connected_order_arc_645  -12
    RHS1      connected_order_arc_648  -12
    RHS1      connected_order_arc_650  -12
    RHS1      connected_order_arc_652  -12
    RHS1      connected_order_arc_654  -12
    RHS1      connected_order_arc_656  -12
    RHS1      connected_order_arc_658  -12
    RHS1      connected_order_arc_660  -12
    RHS1      connected_order_arc_662  -12
    RHS1      connected_order_arc_664  -12
    RHS1      connected_order_arc_666  -12
    RHS1      connected_order_arc_668  -12
    RHS1      depot_departure_or_bypass_669  1
    RHS1      depot_return_or_bypass_670  1
    RHS1      segment_load_conservation_675  2
    RHS1      segment_prefix_ub_677  9
    RHS1      segment_load_conservation_682  1
    RHS1      segment_prefix_ub_684  15
    RHS1      segment_load_conservation_689  2
    RHS1      segment_prefix_ub_691  18
    RHS1      segment_load_conservation_696  -3
    RHS1      segment_prefix_lb_697  3
    RHS1      segment_prefix_ub_698  20
    RHS1      fixed_segment_relative_order_747  1
    RHS1      fixed_segment_relative_order_748  1
    RHS1      fixed_segment_relative_order_749  1
    RHS1      original_T_including_depot_unload_750  1.6086462339106183e+03
    RHS1      connected_order_arc_766  -12
    RHS1      connected_order_arc_768  -12
    RHS1      connected_order_arc_770  -12
    RHS1      connected_order_arc_772  -12
    RHS1      connected_order_arc_774  -12
    RHS1      connected_order_arc_776  -12
    RHS1      connected_order_arc_778  -12
    RHS1      connected_order_arc_780  -12
    RHS1      connected_order_arc_782  -12
    RHS1      connected_order_arc_784  -12
    RHS1      connected_order_arc_786  -12
    RHS1      connected_order_arc_789  -12
    RHS1      connected_order_arc_791  -12
    RHS1      connected_order_arc_793  -12
    RHS1      connected_order_arc_795  -12
    RHS1      connected_order_arc_797  -12
    RHS1      connected_order_arc_799  -12
    RHS1      connected_order_arc_801  -12
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_809  -12
    RHS1      connected_order_arc_812  -12
    RHS1      connected_order_arc_814  -12
    RHS1      connected_order_arc_816  -12
    RHS1      connected_order_arc_818  -12
    RHS1      connected_order_arc_820  -12
    RHS1      connected_order_arc_822  -12
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_835  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      depot_departure_or_bypass_1040  1
    RHS1      depot_return_or_bypass_1041  1
    RHS1      segment_load_conservation_1046  5
    RHS1      segment_prefix_ub_1048  20
    RHS1      segment_load_conservation_1053  5
    RHS1      segment_prefix_ub_1055  20
    RHS1      segment_load_conservation_1060  -4
    RHS1      segment_prefix_lb_1061  4
    RHS1      segment_prefix_ub_1062  25
    RHS1      segment_load_conservation_1067  -6
    RHS1      segment_prefix_lb_1068  6
    RHS1      segment_prefix_ub_1069  25
    RHS1      fixed_segment_relative_order_1118  1
    RHS1      fixed_segment_relative_order_1119  1
    RHS1      fixed_segment_relative_order_1120  1
    RHS1      original_T_including_depot_unload_1121  5100
    RHS1      connected_order_arc_1136  -11
    RHS1      connected_order_arc_1138  -11
    RHS1      connected_order_arc_1140  -11
    RHS1      connected_order_arc_1142  -11
    RHS1      connected_order_arc_1144  -11
    RHS1      connected_order_arc_1146  -11
    RHS1      connected_order_arc_1148  -11
    RHS1      connected_order_arc_1150  -11
    RHS1      connected_order_arc_1152  -11
    RHS1      connected_order_arc_1154  -11
    RHS1      connected_order_arc_1157  -11
    RHS1      connected_order_arc_1159  -11
    RHS1      connected_order_arc_1161  -11
    RHS1      connected_order_arc_1163  -11
    RHS1      connected_order_arc_1165  -11
    RHS1      connected_order_arc_1167  -11
    RHS1      connected_order_arc_1169  -11
    RHS1      connected_order_arc_1171  -11
    RHS1      connected_order_arc_1173  -11
    RHS1      connected_order_arc_1175  -11
    RHS1      connected_order_arc_1178  -11
    RHS1      connected_order_arc_1180  -11
    RHS1      connected_order_arc_1182  -11
    RHS1      connected_order_arc_1184  -11
    RHS1      connected_order_arc_1186  -11
    RHS1      connected_order_arc_1188  -11
    RHS1      connected_order_arc_1190  -11
    RHS1      connected_order_arc_1192  -11
    RHS1      connected_order_arc_1194  -11
    RHS1      connected_order_arc_1196  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1201  -11
    RHS1      connected_order_arc_1203  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1207  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1213  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1217  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1222  -11
    RHS1      connected_order_arc_1224  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1228  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1234  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1238  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1291  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      depot_departure_or_bypass_1365  1
    RHS1      depot_return_or_bypass_1366  1
    RHS1      segment_load_conservation_1371  3
    RHS1      segment_prefix_ub_1373  27
    RHS1      segment_load_conservation_1378  2
    RHS1      segment_prefix_ub_1380  28
    RHS1      segment_load_conservation_1385  -3
    RHS1      segment_prefix_lb_1386  3
    RHS1      segment_prefix_ub_1387  30
    RHS1      fixed_segment_relative_order_1436  1
    RHS1      fixed_segment_relative_order_1437  1
    RHS1      original_T_including_depot_unload_1438  5.6983679997279069e+03
BOUNDS
 LO BND1      t         2.4887905662961264e-02
 UP BND1      t         4.1079812206613858e-02
 UP BND1      q         4.2464985516364051e-01
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.1079812206613858e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.1079812206613858e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.1079812206613858e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.1079812206613858e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.1079812206613858e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.1079812206613858e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.1079812206613858e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.1079812206613858e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.1079812206613858e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.1079812206613858e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.1079812206613858e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.1079812206613858e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.1079812206613858e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.1079812206613858e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.1079812206613858e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.1079812206613858e-02
 UP BND1      rho_34    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1079812206613858e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1079812206613858e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1079812206613858e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1079812206613858e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1079812206613858e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1079812206613858e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1079812206613858e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1079812206613858e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1079812206613858e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1079812206613858e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1079812206613858e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1079812206613858e-02
 UP BND1      rho_31    1
 BV BND1      x_35_0  
 UP BND1      w_35_0    4.1079812206613858e-02
 BV BND1      x_35_1  
 UP BND1      w_35_1    4.1079812206613858e-02
 BV BND1      x_35_2  
 UP BND1      w_35_2    4.1079812206613858e-02
 BV BND1      x_35_3  
 UP BND1      w_35_3    4.1079812206613858e-02
 BV BND1      x_35_4  
 UP BND1      w_35_4    4.1079812206613858e-02
 BV BND1      x_35_5  
 UP BND1      w_35_5    4.1079812206613858e-02
 BV BND1      x_35_6  
 UP BND1      w_35_6    4.1079812206613858e-02
 BV BND1      x_35_7  
 UP BND1      w_35_7    4.1079812206613858e-02
 BV BND1      x_35_8  
 UP BND1      w_35_8    4.1079812206613858e-02
 BV BND1      x_35_9  
 UP BND1      w_35_9    4.1079812206613858e-02
 BV BND1      x_35_10 
 UP BND1      w_35_10   4.1079812206613858e-02
 BV BND1      x_35_11 
 UP BND1      w_35_11   4.1079812206613858e-02
 BV BND1      x_35_12 
 UP BND1      w_35_12   4.1079812206613858e-02
 BV BND1      x_35_13 
 UP BND1      w_35_13   4.1079812206613858e-02
 BV BND1      x_35_14 
 UP BND1      w_35_14   4.1079812206613858e-02
 BV BND1      x_35_15 
 UP BND1      w_35_15   4.1079812206613858e-02
 UP BND1      rho_35    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1079812206613858e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1079812206613858e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1079812206613858e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1079812206613858e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1079812206613858e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1079812206613858e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1079812206613858e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1079812206613858e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1079812206613858e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1079812206613858e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1079812206613858e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1079812206613858e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1079812206613858e-02
 BV BND1      x_32_13 
 UP BND1      w_32_13   4.1079812206613858e-02
 BV BND1      x_32_14 
 UP BND1      w_32_14   4.1079812206613858e-02
 BV BND1      x_32_15 
 UP BND1      w_32_15   4.1079812206613858e-02
 BV BND1      x_32_16 
 UP BND1      w_32_16   4.1079812206613858e-02
 BV BND1      x_32_17 
 UP BND1      w_32_17   4.1079812206613858e-02
 BV BND1      x_32_18 
 UP BND1      w_32_18   4.1079812206613858e-02
 BV BND1      x_32_19 
 UP BND1      w_32_19   4.1079812206613858e-02
 UP BND1      rho_32    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.1079812206613858e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.1079812206613858e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.1079812206613858e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.1079812206613858e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.1079812206613858e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.1079812206613858e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.1079812206613858e-02
 UP BND1      rho_27    1
 BV BND1      x_25_0  
 UP BND1      w_25_0    4.1079812206613858e-02
 BV BND1      x_25_1  
 UP BND1      w_25_1    4.1079812206613858e-02
 BV BND1      x_25_2  
 UP BND1      w_25_2    4.1079812206613858e-02
 BV BND1      x_25_3  
 UP BND1      w_25_3    4.1079812206613858e-02
 BV BND1      x_25_4  
 UP BND1      w_25_4    4.1079812206613858e-02
 UP BND1      rho_25    1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.1079812206613858e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.1079812206613858e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.1079812206613858e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.1079812206613858e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.1079812206613858e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.1079812206613858e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.1079812206613858e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.1079812206613858e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.1079812206613858e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.1079812206613858e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.1079812206613858e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.1079812206613858e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.1079812206613858e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.1079812206613858e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.1079812206613858e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.1079812206613858e-02
 UP BND1      rho_22    1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.1079812206613858e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.1079812206613858e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.1079812206613858e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.1079812206613858e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.1079812206613858e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.1079812206613858e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.1079812206613858e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.1079812206613858e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.1079812206613858e-02
 UP BND1      rho_26    1
 UP BND1      a_34_31   1
 UP BND1      a_34_35   1
 UP BND1      a_34_32   1
 UP BND1      a_34_27   1
 UP BND1      a_34_25   1
 UP BND1      a_34_22   1
 UP BND1      a_34_26   1
 UP BND1      a_31_35   1
 UP BND1      a_31_32   1
 UP BND1      a_31_27   1
 UP BND1      a_31_25   1
 UP BND1      a_31_22   1
 UP BND1      a_31_26   1
 UP BND1      a_35_32   1
 UP BND1      a_35_27   1
 UP BND1      a_35_25   1
 UP BND1      a_35_22   1
 UP BND1      a_35_26   1
 UP BND1      a_32_27   1
 UP BND1      a_32_25   1
 UP BND1      a_32_22   1
 UP BND1      a_32_26   1
 UP BND1      a_27_25   1
 UP BND1      a_27_22   1
 UP BND1      a_27_26   1
 UP BND1      a_25_22   1
 UP BND1      a_25_26   1
 UP BND1      a_22_26   1
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_2
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_2
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_2
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_11
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_11
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_11
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 BV BND1      service_0_32_0
 BV BND1      service_0_32_1
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_0_32_13
 BV BND1      service_0_32_14
 BV BND1      service_0_32_15
 BV BND1      service_0_32_16
 BV BND1      service_0_32_17
 BV BND1      service_0_32_18
 BV BND1      service_0_32_19
 BV BND1      service_1_32_0
 BV BND1      service_1_32_1
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_1_32_13
 BV BND1      service_1_32_14
 BV BND1      service_1_32_15
 BV BND1      service_1_32_16
 BV BND1      service_1_32_17
 BV BND1      service_1_32_18
 BV BND1      service_1_32_19
 BV BND1      service_2_32_0
 BV BND1      service_2_32_1
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_2_32_13
 BV BND1      service_2_32_14
 BV BND1      service_2_32_15
 BV BND1      service_2_32_16
 BV BND1      service_2_32_17
 BV BND1      service_2_32_18
 BV BND1      service_2_32_19
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_25_1
 BV BND1      service_0_25_2
 BV BND1      service_0_25_3
 BV BND1      service_0_25_4
 BV BND1      service_1_25_1
 BV BND1      service_1_25_2
 BV BND1      service_1_25_3
 BV BND1      service_1_25_4
 BV BND1      service_2_25_1
 BV BND1      service_2_25_2
 BV BND1      service_2_25_3
 BV BND1      service_2_25_4
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_26_0
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_0
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_0
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
