* Signature: 0xe80b56c83b3f462e
NAME obj
ROWS
 N  OBJ
 L  c4      
 L  c5      
 L  c6      
 L  c7      
 L  c8      
 G  c10     
 L  c11     
 L  c12     
 E  c18     
 L  c19     
 E  c20     
 E  c21     
 E  c22     
 E  c23     
 L  c24     
 L  c25     
 L  c26     
 L  c27     
 L  c28     
 L  c29     
 E  c30     
 E  c31     
 E  c32     
 L  c33     
 L  c34     
 L  c35     
 G  c36     
 L  c37     
 L  c38     
 G  c39     
 L  c40     
 G  c41     
 L  c42     
 L  c43     
 L  c44     
 L  c45     
 L  c46     
 L  c47     
 L  c48     
 L  c49     
 G  c50     
 L  c51     
 L  c52     
 L  c53     
 L  c54     
 L  c55     
 L  c56     
 G  c57     
 L  c58     
 L  c59     
 G  c60     
 L  c61     
 G  c62     
 L  c63     
 G  c64     
 L  c65     
 G  c66     
 G  c67     
 L  c68     
 L  c69     
 E  c70     
 E  c71     
 G  c72     
 G  c73     
 E  c74     
 E  c75     
 G  c76     
 G  c77     
 L  c78     
 L  c79     
 L  c80     
 L  c81     
 L  c82     
 E  c91     
 E  c92     
 E  c93     
 E  c94     
 E  c103    
 E  c104    
 E  c105    
 E  c106    
 E  rn_zero_only_g
COLUMNS
    G         OBJ       1
    G         c8        1
    G         rn_zero_only_g  1
    e_1       OBJ       0.1
    e_1       c8        0.1
    e_1       c10       1
    e_1       c11       1
    e_1       c72       1
    e_1       c73       1
    e_2       OBJ       0.1
    e_2       c8        0.1
    e_2       c10       1
    e_2       c12       1
    e_2       c76       1
    e_2       c77       1
    r_1       c4        1
    r_1       c5        -1
    r_1       c6        5.9999999999999987e-01
    r_1       c7        -1.4000000000000001e+00
    r_1       c71       1
    r_1       c72       -1
    r_1       c73       1
    r_2       c4        -1
    r_2       c5        1
    r_2       c6        -1.4000000000000001e+00
    r_2       c7        5.9999999999999987e-01
    r_2       c75       1
    r_2       c76       -1
    r_2       c77       1
    MARKER    'MARKER'                 'INTORG'
    x_0_0_1   c18       1
    x_0_0_1   c19       1
    x_0_0_1   c20       1
    x_0_0_1   c24       -2
    x_0_0_1   c59       2
    x_0_0_1   c60       -2
    x_0_0_2   c18       1
    x_0_0_2   c19       1
    x_0_0_2   c22       1
    x_0_0_2   c25       -2
    x_0_0_2   c61       2
    x_0_0_2   c62       -2
    x_0_1_0   c18       -1
    x_0_1_0   c21       1
    x_0_1_0   c26       -2
    x_0_2_0   c18       -1
    x_0_2_0   c23       1
    x_0_2_0   c28       -2
    x_0_2_1   c20       1
    x_0_2_1   c23       1
    x_0_2_1   c29       -2
    x_0_2_1   c44       2
    x_0_2_1   c65       2
    x_0_2_1   c66       -2
    z_0_1     c20       -1
    z_0_1     c21       -1
    z_0_1     c30       -1
    z_0_1     c32       -1
    z_0_1     c33       1
    z_0_1     c39       -1
    z_0_1     c40       -2
    z_0_1     c46       -2
    z_0_1     c47       -1
    z_0_1     c49       -2
    z_0_1     c50       -1
    z_0_1     c51       -2
    z_0_1     c69       105
    z_0_1     c78       -2
    z_0_1     c92       1
    x_0_1_2   c21       1
    x_0_1_2   c22       1
    x_0_1_2   c27       -2
    x_0_1_2   c43       2
    x_0_1_2   c63       2
    x_0_1_2   c64       -2
    z_0_2     c22       -1
    z_0_2     c23       -1
    z_0_2     c31       -1
    z_0_2     c32       -1
    z_0_2     c34       1
    z_0_2     c41       -1
    z_0_2     c42       -2
    z_0_2     c53       -2
    z_0_2     c54       -1
    z_0_2     c56       -2
    z_0_2     c57       -1
    z_0_2     c58       -2
    z_0_2     c69       105
    z_0_2     c80       -2
    z_0_2     c104      1
    MARKER    'MARKER'                 'INTEND'
    conn_0_0_1  c24       1
    conn_0_0_1  c30       1
    conn_0_0_1  c32       1
    conn_0_0_2  c25       1
    conn_0_0_2  c31       1
    conn_0_0_2  c32       1
    conn_0_1_0  c26       1
    conn_0_1_0  c30       -1
    conn_0_1_0  c32       -1
    conn_0_1_2  c27       1
    conn_0_1_2  c30       -1
    conn_0_1_2  c31       1
    conn_0_2_0  c28       1
    conn_0_2_0  c31       -1
    conn_0_2_0  c32       -1
    conn_0_2_1  c29       1
    conn_0_2_1  c30       1
    conn_0_2_1  c31       -1
    MARKER    'MARKER'                 'INTORG'
    Y_1       c35       1
    Y_1       c36       1
    Y_1       c70       1
    Y_1       c71       -1
    Y_1       c78       1
    Y_1       c79       -1
    Y_1       c94       1
    Y_2       c35       1
    Y_2       c36       1
    Y_2       c74       1
    Y_2       c75       -0.5
    Y_2       c80       1
    Y_2       c81       -1
    Y_2       c106      1
    MARKER    'MARKER'                 'INTEND'
    d_0_1     c37       1
    d_0_1     c46       1
    d_0_1     c49       1
    d_0_1     c50       1
    d_0_1     c59       1
    d_0_1     c60       1
    d_0_1     c65       1
    d_0_1     c66       1
    d_0_1     c67       -1
    d_0_1     c70       -1
    d_0_1     c91       1
    p_0_2     c37       -1
    p_0_2     c52       1
    p_0_2     c55       1
    p_0_2     c57       1
    p_0_2     c61       -1
    p_0_2     c62       -1
    p_0_2     c63       -1
    p_0_2     c64       -1
    p_0_2     c67       1
    p_0_2     c68       5
    p_0_2     c69       5
    p_0_2     c74       1
    p_0_2     c82       5
    p_0_2     c103      1
    d_0_2     c38       1
    d_0_2     c53       1
    d_0_2     c56       1
    d_0_2     c57       1
    d_0_2     c61       1
    d_0_2     c62       1
    d_0_2     c63       1
    d_0_2     c64       1
    d_0_2     c67       -1
    d_0_2     c74       -1
    d_0_2     c103      1
    p_0_1     c38       -1
    p_0_1     c45       1
    p_0_1     c48       1
    p_0_1     c50       1
    p_0_1     c59       -1
    p_0_1     c60       -1
    p_0_1     c65       -1
    p_0_1     c66       -1
    p_0_1     c67       1
    p_0_1     c68       5
    p_0_1     c69       5
    p_0_1     c70       1
    p_0_1     c82       5
    p_0_1     c91       1
    ord_0_1   c39       1
    ord_0_1   c40       1
    ord_0_1   c43       1
    ord_0_1   c44       -1
    ord_0_2   c41       1
    ord_0_2   c42       1
    ord_0_2   c43       -1
    ord_0_2   c44       1
    MARKER    'MARKER'                 'INTORG'
    mode_0_1  c47       1
    mode_0_1  c49       2
    load_0_1  c51       1
    load_0_1  c59       1
    load_0_1  c60       1
    load_0_1  c63       -1
    load_0_1  c64       -1
    load_0_1  c65       1
    load_0_1  c66       1
    mode_0_2  c54       1
    mode_0_2  c56       2
    load_0_2  c58       1
    load_0_2  c61       1
    load_0_2  c62       1
    load_0_2  c63       1
    load_0_2  c64       1
    load_0_2  c65       -1
    load_0_2  c66       -1
    state_1_0  c92       1
    state_1_0  c93       1
    state_1_1  c91       -1
    state_1_1  c93       1
    state_1_1  c94       -1
    state_1_2  c91       -2
    state_1_2  c93       1
    state_1_2  c94       -2
    state_2_0  c104      1
    state_2_0  c105      1
    state_2_1  c103      -1
    state_2_1  c105      1
    state_2_1  c106      -1
    state_2_2  c103      -2
    state_2_2  c105      1
    state_2_2  c106      -2
    MARKER    'MARKER'                 'INTEND'
    r_max     OBJ       0
    r_min     OBJ       0
RHS
    RHS1      c4        1.2000000000000002e+00
    RHS1      c5        1.2000000000000002e+00
    RHS1      c8        2.0000000000000004e-01
    RHS1      c11       2.0000000000000004e+00
    RHS1      c12       2.0000000000000004e+00
    RHS1      c19       1
    RHS1      c33       1
    RHS1      c34       1
    RHS1      c36       -2
    RHS1      c43       1
    RHS1      c44       1
    RHS1      c59       2
    RHS1      c60       -2
    RHS1      c61       2
    RHS1      c62       -2
    RHS1      c63       2
    RHS1      c64       -2
    RHS1      c65       2
    RHS1      c66       -2
    RHS1      c68       100
    RHS1      c69       310
    RHS1      c72       -1
    RHS1      c73       1
    RHS1      c76       -1
    RHS1      c77       1
    RHS1      c82       100
    RHS1      c92       1
    RHS1      c93       1
    RHS1      c104      1
    RHS1      c105      1
BOUNDS
 UP BND1      G         2.0000000000000004e-01
 UP BND1      e_1       1
 UP BND1      e_2       1
 UP BND1      r_1       2
 UP BND1      r_2       1
 BV BND1      x_0_0_1 
 BV BND1      x_0_0_2 
 BV BND1      x_0_1_0 
 BV BND1      x_0_2_0 
 BV BND1      x_0_2_1 
 BV BND1      z_0_1   
 BV BND1      x_0_1_2 
 BV BND1      z_0_2   
 UP BND1      conn_0_0_1  2
 UP BND1      conn_0_0_2  2
 UP BND1      conn_0_1_0  2
 UP BND1      conn_0_1_2  2
 UP BND1      conn_0_2_0  2
 UP BND1      conn_0_2_1  2
 UP BND1      Y_1       2
 UP BND1      Y_2       2
 UP BND1      d_0_1     2
 FX BND1      p_0_2     0
 UP BND1      d_0_2     2
 FX BND1      p_0_1     0
 UP BND1      ord_0_1   2
 UP BND1      ord_0_2   2
 BV BND1      mode_0_1
 UP BND1      load_0_1  2
 BV BND1      mode_0_2
 UP BND1      load_0_2  2
 BV BND1      state_1_0
 BV BND1      state_1_1
 BV BND1      state_1_2
 BV BND1      state_2_0
 BV BND1      state_2_1
 BV BND1      state_2_2
 UP BND1      r_max     2
 UP BND1      r_min     2
ENDATA
