* Signature: 0x38a0207a4dffbbb5
NAME R157_mandatory_metric_tour
ROWS
 N  OBJ
 E  degree_0
 E  degree_1
 E  degree_2
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    edge[0,1]  OBJ       1
    edge[0,1]  degree_0  1
    edge[0,1]  degree_1  1
    edge[0,2]  OBJ       4
    edge[0,2]  degree_0  1
    edge[0,2]  degree_2  1
    edge[1,2]  OBJ       3
    edge[1,2]  degree_1  1
    edge[1,2]  degree_2  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      degree_0  2
    RHS1      degree_1  2
    RHS1      degree_2  2
BOUNDS
 BV BND1      edge[0,1]
 BV BND1      edge[0,2]
 BV BND1      edge[1,2]
ENDATA
