* Signature: 0x952dfcf5f092e13f
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 E  onehot_1_0
 E  onehot_2_1
 E  onehot_3_2
 E  onehot_4_3
 G  stock_lb_4
 L  stock_ub_5
 L  parent_nonstrict_scope_6
 E  unique_nonzero_owner_7
 E  unique_nonzero_owner_8
 E  unique_nonzero_owner_9
 E  unique_nonzero_owner_10
 E  unique_nonzero_owner_11
 E  unique_nonzero_owner_12
 E  unique_nonzero_owner_13
 E  unique_nonzero_owner_14
 E  unique_nonzero_owner_15
 E  unique_nonzero_owner_16
 L  arc_capacity_17
 L  arc_capacity_18
 L  arc_capacity_19
 L  arc_capacity_20
 L  arc_capacity_21
 L  arc_capacity_22
 L  arc_capacity_23
 G  connected_order_arc_24
 L  arc_capacity_25
 G  connected_order_arc_26
 L  arc_capacity_27
 G  connected_order_arc_28
 L  arc_capacity_29
 L  arc_capacity_30
 G  connected_order_arc_31
 L  arc_capacity_32
 G  connected_order_arc_33
 L  arc_capacity_34
 G  connected_order_arc_35
 L  arc_capacity_36
 L  arc_capacity_37
 G  connected_order_arc_38
 L  arc_capacity_39
 G  connected_order_arc_40
 L  arc_capacity_41
 G  connected_order_arc_42
 L  arc_capacity_43
 L  arc_capacity_44
 G  connected_order_arc_45
 L  arc_capacity_46
 G  connected_order_arc_47
 L  arc_capacity_48
 G  connected_order_arc_49
 E  depot_departure_or_bypass_50
 E  depot_return_or_bypass_51
 E  out_degree_52
 E  in_degree_53
 G  order_active_lb_54
 L  order_active_ub_55
 E  service_visit_def_56
 E  free_load_conservation_57
 E  out_degree_58
 E  in_degree_59
 G  order_active_lb_60
 L  order_active_ub_61
 E  service_visit_def_62
 E  free_load_conservation_63
 E  out_degree_64
 E  in_degree_65
 G  order_active_lb_66
 L  order_active_ub_67
 E  service_visit_def_68
 E  free_load_conservation_69
 E  out_degree_70
 E  in_degree_71
 G  order_active_lb_72
 L  order_active_ub_73
 E  service_visit_def_74
 E  free_load_conservation_75
 L  original_T_including_depot_unload_76
 L  arc_capacity_77
 L  arc_capacity_78
 L  arc_capacity_79
 L  arc_capacity_80
 L  arc_capacity_81
 L  arc_capacity_82
 L  arc_capacity_83
 G  connected_order_arc_84
 L  arc_capacity_85
 G  connected_order_arc_86
 L  arc_capacity_87
 G  connected_order_arc_88
 L  arc_capacity_89
 L  arc_capacity_90
 G  connected_order_arc_91
 L  arc_capacity_92
 G  connected_order_arc_93
 L  arc_capacity_94
 G  connected_order_arc_95
 L  arc_capacity_96
 L  arc_capacity_97
 G  connected_order_arc_98
 L  arc_capacity_99
 G  connected_order_arc_100
 L  arc_capacity_101
 G  connected_order_arc_102
 L  arc_capacity_103
 L  arc_capacity_104
 G  connected_order_arc_105
 L  arc_capacity_106
 G  connected_order_arc_107
 L  arc_capacity_108
 G  connected_order_arc_109
 E  depot_departure_or_bypass_110
 E  depot_return_or_bypass_111
 E  out_degree_112
 E  in_degree_113
 G  order_active_lb_114
 L  order_active_ub_115
 E  service_visit_def_116
 E  free_load_conservation_117
 E  out_degree_118
 E  in_degree_119
 G  order_active_lb_120
 L  order_active_ub_121
 E  service_visit_def_122
 E  free_load_conservation_123
 E  out_degree_124
 E  in_degree_125
 G  order_active_lb_126
 L  order_active_ub_127
 E  service_visit_def_128
 E  free_load_conservation_129
 E  out_degree_130
 E  in_degree_131
 G  order_active_lb_132
 L  order_active_ub_133
 E  service_visit_def_134
 E  free_load_conservation_135
 L  original_T_including_depot_unload_136
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     onehot_1_0  1
    x_1_0     parent_nonstrict_scope_6  0.15
    x_1_0     unique_nonzero_owner_7  -1
    x_1_1     OBJ       -0.075
    x_1_1     onehot_1_0  1
    x_1_1     stock_lb_4  1
    x_1_1     stock_ub_5  1
    x_1_1     unique_nonzero_owner_8  -1
    x_1_2     OBJ       0.075
    x_1_2     onehot_1_0  1
    x_1_2     stock_lb_4  2
    x_1_2     stock_ub_5  2
    x_1_2     parent_nonstrict_scope_6  0.15
    x_2_0     OBJ       0.075
    x_2_0     onehot_2_1  1
    x_2_0     parent_nonstrict_scope_6  0.15
    x_2_0     unique_nonzero_owner_9  -1
    x_2_1     OBJ       -0.075
    x_2_1     onehot_2_1  1
    x_2_1     stock_lb_4  1
    x_2_1     stock_ub_5  1
    x_2_1     unique_nonzero_owner_10  -1
    x_2_2     OBJ       0.075
    x_2_2     onehot_2_1  1
    x_2_2     stock_lb_4  2
    x_2_2     stock_ub_5  2
    x_2_2     parent_nonstrict_scope_6  0.15
    x_3_0     onehot_3_2  1
    x_3_0     parent_nonstrict_scope_6  0.15
    x_3_1     OBJ       -0.15
    x_3_1     onehot_3_2  1
    x_3_1     stock_lb_4  1
    x_3_1     stock_ub_5  1
    x_3_1     unique_nonzero_owner_11  -1
    x_3_2     onehot_3_2  1
    x_3_2     stock_lb_4  2
    x_3_2     stock_ub_5  2
    x_3_2     parent_nonstrict_scope_6  0.15
    x_3_2     unique_nonzero_owner_12  -1
    x_3_3     OBJ       0.15
    x_3_3     onehot_3_2  1
    x_3_3     stock_lb_4  3
    x_3_3     stock_ub_5  3
    x_3_3     parent_nonstrict_scope_6  0.3
    x_3_3     unique_nonzero_owner_13  -1
    x_4_0     onehot_4_3  1
    x_4_0     parent_nonstrict_scope_6  0.15
    x_4_1     OBJ       -0.15
    x_4_1     onehot_4_3  1
    x_4_1     stock_lb_4  1
    x_4_1     stock_ub_5  1
    x_4_1     unique_nonzero_owner_14  -1
    x_4_2     onehot_4_3  1
    x_4_2     stock_lb_4  2
    x_4_2     stock_ub_5  2
    x_4_2     parent_nonstrict_scope_6  0.15
    x_4_2     unique_nonzero_owner_15  -1
    x_4_3     OBJ       0.15
    x_4_3     onehot_4_3  1
    x_4_3     stock_lb_4  3
    x_4_3     stock_ub_5  3
    x_4_3     parent_nonstrict_scope_6  0.3
    x_4_3     unique_nonzero_owner_16  -1
    service_0_1_0  unique_nonzero_owner_7  1
    service_0_1_0  service_visit_def_56  1
    service_0_1_0  free_load_conservation_57  -2
    service_0_1_0  original_T_including_depot_unload_76  14
    service_0_1_1  unique_nonzero_owner_8  1
    service_0_1_1  service_visit_def_56  1
    service_0_1_1  free_load_conservation_57  -1
    service_0_1_1  original_T_including_depot_unload_76  7
    service_1_1_0  unique_nonzero_owner_7  1
    service_1_1_0  service_visit_def_116  1
    service_1_1_0  free_load_conservation_117  -2
    service_1_1_0  original_T_including_depot_unload_136  14
    service_1_1_1  unique_nonzero_owner_8  1
    service_1_1_1  service_visit_def_116  1
    service_1_1_1  free_load_conservation_117  -1
    service_1_1_1  original_T_including_depot_unload_136  7
    service_0_2_0  unique_nonzero_owner_9  1
    service_0_2_0  service_visit_def_62  1
    service_0_2_0  free_load_conservation_63  -2
    service_0_2_0  original_T_including_depot_unload_76  14
    service_0_2_1  unique_nonzero_owner_10  1
    service_0_2_1  service_visit_def_62  1
    service_0_2_1  free_load_conservation_63  -1
    service_0_2_1  original_T_including_depot_unload_76  7
    service_1_2_0  unique_nonzero_owner_9  1
    service_1_2_0  service_visit_def_122  1
    service_1_2_0  free_load_conservation_123  -2
    service_1_2_0  original_T_including_depot_unload_136  14
    service_1_2_1  unique_nonzero_owner_10  1
    service_1_2_1  service_visit_def_122  1
    service_1_2_1  free_load_conservation_123  -1
    service_1_2_1  original_T_including_depot_unload_136  7
    service_0_3_1  unique_nonzero_owner_11  1
    service_0_3_1  service_visit_def_68  1
    service_0_3_1  free_load_conservation_69  1
    service_0_3_2  unique_nonzero_owner_12  1
    service_0_3_2  service_visit_def_68  1
    service_0_3_2  free_load_conservation_69  2
    service_0_3_3  unique_nonzero_owner_13  1
    service_0_3_3  service_visit_def_68  1
    service_0_3_3  free_load_conservation_69  3
    service_1_3_1  unique_nonzero_owner_11  1
    service_1_3_1  service_visit_def_128  1
    service_1_3_1  free_load_conservation_129  1
    service_1_3_2  unique_nonzero_owner_12  1
    service_1_3_2  service_visit_def_128  1
    service_1_3_2  free_load_conservation_129  2
    service_1_3_3  unique_nonzero_owner_13  1
    service_1_3_3  service_visit_def_128  1
    service_1_3_3  free_load_conservation_129  3
    service_0_4_1  unique_nonzero_owner_14  1
    service_0_4_1  service_visit_def_74  1
    service_0_4_1  free_load_conservation_75  1
    service_0_4_2  unique_nonzero_owner_15  1
    service_0_4_2  service_visit_def_74  1
    service_0_4_2  free_load_conservation_75  2
    service_0_4_3  unique_nonzero_owner_16  1
    service_0_4_3  service_visit_def_74  1
    service_0_4_3  free_load_conservation_75  3
    service_1_4_1  unique_nonzero_owner_14  1
    service_1_4_1  service_visit_def_134  1
    service_1_4_1  free_load_conservation_135  1
    service_1_4_2  unique_nonzero_owner_15  1
    service_1_4_2  service_visit_def_134  1
    service_1_4_2  free_load_conservation_135  2
    service_1_4_3  unique_nonzero_owner_16  1
    service_1_4_3  service_visit_def_134  1
    service_1_4_3  free_load_conservation_135  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_52  -1
    visit_0_1  in_degree_53  -1
    visit_0_1  order_active_lb_54  -1
    visit_0_1  order_active_ub_55  -4
    visit_0_1  service_visit_def_56  -1
    order_0_1  connected_order_arc_24  -1
    order_0_1  connected_order_arc_26  -1
    order_0_1  connected_order_arc_28  -1
    order_0_1  connected_order_arc_31  1
    order_0_1  connected_order_arc_38  1
    order_0_1  connected_order_arc_45  1
    order_0_1  order_active_lb_54  1
    order_0_1  order_active_ub_55  1
    visit_0_2  out_degree_58  -1
    visit_0_2  in_degree_59  -1
    visit_0_2  order_active_lb_60  -1
    visit_0_2  order_active_ub_61  -4
    visit_0_2  service_visit_def_62  -1
    order_0_2  connected_order_arc_24  1
    order_0_2  connected_order_arc_31  -1
    order_0_2  connected_order_arc_33  -1
    order_0_2  connected_order_arc_35  -1
    order_0_2  connected_order_arc_40  1
    order_0_2  connected_order_arc_47  1
    order_0_2  order_active_lb_60  1
    order_0_2  order_active_ub_61  1
    visit_0_3  out_degree_64  -1
    visit_0_3  in_degree_65  -1
    visit_0_3  order_active_lb_66  -1
    visit_0_3  order_active_ub_67  -4
    visit_0_3  service_visit_def_68  -1
    order_0_3  connected_order_arc_26  1
    order_0_3  connected_order_arc_33  1
    order_0_3  connected_order_arc_38  -1
    order_0_3  connected_order_arc_40  -1
    order_0_3  connected_order_arc_42  -1
    order_0_3  connected_order_arc_49  1
    order_0_3  order_active_lb_66  1
    order_0_3  order_active_ub_67  1
    visit_0_4  out_degree_70  -1
    visit_0_4  in_degree_71  -1
    visit_0_4  order_active_lb_72  -1
    visit_0_4  order_active_ub_73  -4
    visit_0_4  service_visit_def_74  -1
    order_0_4  connected_order_arc_28  1
    order_0_4  connected_order_arc_35  1
    order_0_4  connected_order_arc_42  1
    order_0_4  connected_order_arc_45  -1
    order_0_4  connected_order_arc_47  -1
    order_0_4  connected_order_arc_49  -1
    order_0_4  order_active_lb_72  1
    order_0_4  order_active_ub_73  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_17  -3
    arc_0_0_0  depot_departure_or_bypass_50  1
    arc_0_0_0  depot_return_or_bypass_51  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_17  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_18  -3
    arc_0_0_1  depot_departure_or_bypass_50  1
    arc_0_0_1  in_degree_53  1
    arc_0_0_1  original_T_including_depot_unload_76  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_18  1
    load_0_0_1  free_load_conservation_57  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_19  -3
    arc_0_0_2  depot_departure_or_bypass_50  1
    arc_0_0_2  in_degree_59  1
    arc_0_0_2  original_T_including_depot_unload_76  2
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_19  1
    load_0_0_2  free_load_conservation_63  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_20  -3
    arc_0_0_3  depot_departure_or_bypass_50  1
    arc_0_0_3  in_degree_65  1
    arc_0_0_3  original_T_including_depot_unload_76  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_20  1
    load_0_0_3  free_load_conservation_69  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_21  -3
    arc_0_0_4  depot_departure_or_bypass_50  1
    arc_0_0_4  in_degree_71  1
    arc_0_0_4  original_T_including_depot_unload_76  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_21  1
    load_0_0_4  free_load_conservation_75  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_22  -3
    arc_0_1_0  depot_return_or_bypass_51  1
    arc_0_1_0  out_degree_52  1
    arc_0_1_0  original_T_including_depot_unload_76  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_22  1
    load_0_1_0  free_load_conservation_57  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_23  -3
    arc_0_1_2  connected_order_arc_24  -5
    arc_0_1_2  out_degree_52  1
    arc_0_1_2  in_degree_59  1
    arc_0_1_2  original_T_including_depot_unload_76  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_23  1
    load_0_1_2  free_load_conservation_57  1
    load_0_1_2  free_load_conservation_63  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_25  -3
    arc_0_1_3  connected_order_arc_26  -5
    arc_0_1_3  out_degree_52  1
    arc_0_1_3  in_degree_65  1
    arc_0_1_3  original_T_including_depot_unload_76  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_25  1
    load_0_1_3  free_load_conservation_57  1
    load_0_1_3  free_load_conservation_69  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_27  -3
    arc_0_1_4  connected_order_arc_28  -5
    arc_0_1_4  out_degree_52  1
    arc_0_1_4  in_degree_71  1
    arc_0_1_4  original_T_including_depot_unload_76  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_27  1
    load_0_1_4  free_load_conservation_57  1
    load_0_1_4  free_load_conservation_75  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_29  -3
    arc_0_2_0  depot_return_or_bypass_51  1
    arc_0_2_0  out_degree_58  1
    arc_0_2_0  original_T_including_depot_unload_76  2
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_29  1
    load_0_2_0  free_load_conservation_63  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_30  -3
    arc_0_2_1  connected_order_arc_31  -5
    arc_0_2_1  in_degree_53  1
    arc_0_2_1  out_degree_58  1
    arc_0_2_1  original_T_including_depot_unload_76  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_30  1
    load_0_2_1  free_load_conservation_57  -1
    load_0_2_1  free_load_conservation_63  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_32  -3
    arc_0_2_3  connected_order_arc_33  -5
    arc_0_2_3  out_degree_58  1
    arc_0_2_3  in_degree_65  1
    arc_0_2_3  original_T_including_depot_unload_76  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_32  1
    load_0_2_3  free_load_conservation_63  1
    load_0_2_3  free_load_conservation_69  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_34  -3
    arc_0_2_4  connected_order_arc_35  -5
    arc_0_2_4  out_degree_58  1
    arc_0_2_4  in_degree_71  1
    arc_0_2_4  original_T_including_depot_unload_76  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_34  1
    load_0_2_4  free_load_conservation_63  1
    load_0_2_4  free_load_conservation_75  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_36  -3
    arc_0_3_0  depot_return_or_bypass_51  1
    arc_0_3_0  out_degree_64  1
    arc_0_3_0  original_T_including_depot_unload_76  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_36  1
    load_0_3_0  free_load_conservation_69  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_37  -3
    arc_0_3_1  connected_order_arc_38  -5
    arc_0_3_1  in_degree_53  1
    arc_0_3_1  out_degree_64  1
    arc_0_3_1  original_T_including_depot_unload_76  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_37  1
    load_0_3_1  free_load_conservation_57  -1
    load_0_3_1  free_load_conservation_69  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_39  -3
    arc_0_3_2  connected_order_arc_40  -5
    arc_0_3_2  in_degree_59  1
    arc_0_3_2  out_degree_64  1
    arc_0_3_2  original_T_including_depot_unload_76  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_39  1
    load_0_3_2  free_load_conservation_63  -1
    load_0_3_2  free_load_conservation_69  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_41  -3
    arc_0_3_4  connected_order_arc_42  -5
    arc_0_3_4  out_degree_64  1
    arc_0_3_4  in_degree_71  1
    arc_0_3_4  original_T_including_depot_unload_76  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_41  1
    load_0_3_4  free_load_conservation_69  1
    load_0_3_4  free_load_conservation_75  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_43  -3
    arc_0_4_0  depot_return_or_bypass_51  1
    arc_0_4_0  out_degree_70  1
    arc_0_4_0  original_T_including_depot_unload_76  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_43  1
    load_0_4_0  free_load_conservation_75  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_44  -3
    arc_0_4_1  connected_order_arc_45  -5
    arc_0_4_1  in_degree_53  1
    arc_0_4_1  out_degree_70  1
    arc_0_4_1  original_T_including_depot_unload_76  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_44  1
    load_0_4_1  free_load_conservation_57  -1
    load_0_4_1  free_load_conservation_75  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_46  -3
    arc_0_4_2  connected_order_arc_47  -5
    arc_0_4_2  in_degree_59  1
    arc_0_4_2  out_degree_70  1
    arc_0_4_2  original_T_including_depot_unload_76  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_46  1
    load_0_4_2  free_load_conservation_63  -1
    load_0_4_2  free_load_conservation_75  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_48  -3
    arc_0_4_3  connected_order_arc_49  -5
    arc_0_4_3  in_degree_65  1
    arc_0_4_3  out_degree_70  1
    arc_0_4_3  original_T_including_depot_unload_76  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_48  1
    load_0_4_3  free_load_conservation_69  -1
    load_0_4_3  free_load_conservation_75  1
    visit_1_1  out_degree_112  -1
    visit_1_1  in_degree_113  -1
    visit_1_1  order_active_lb_114  -1
    visit_1_1  order_active_ub_115  -4
    visit_1_1  service_visit_def_116  -1
    order_1_1  connected_order_arc_84  -1
    order_1_1  connected_order_arc_86  -1
    order_1_1  connected_order_arc_88  -1
    order_1_1  connected_order_arc_91  1
    order_1_1  connected_order_arc_98  1
    order_1_1  connected_order_arc_105  1
    order_1_1  order_active_lb_114  1
    order_1_1  order_active_ub_115  1
    visit_1_2  out_degree_118  -1
    visit_1_2  in_degree_119  -1
    visit_1_2  order_active_lb_120  -1
    visit_1_2  order_active_ub_121  -4
    visit_1_2  service_visit_def_122  -1
    order_1_2  connected_order_arc_84  1
    order_1_2  connected_order_arc_91  -1
    order_1_2  connected_order_arc_93  -1
    order_1_2  connected_order_arc_95  -1
    order_1_2  connected_order_arc_100  1
    order_1_2  connected_order_arc_107  1
    order_1_2  order_active_lb_120  1
    order_1_2  order_active_ub_121  1
    visit_1_3  out_degree_124  -1
    visit_1_3  in_degree_125  -1
    visit_1_3  order_active_lb_126  -1
    visit_1_3  order_active_ub_127  -4
    visit_1_3  service_visit_def_128  -1
    order_1_3  connected_order_arc_86  1
    order_1_3  connected_order_arc_93  1
    order_1_3  connected_order_arc_98  -1
    order_1_3  connected_order_arc_100  -1
    order_1_3  connected_order_arc_102  -1
    order_1_3  connected_order_arc_109  1
    order_1_3  order_active_lb_126  1
    order_1_3  order_active_ub_127  1
    visit_1_4  out_degree_130  -1
    visit_1_4  in_degree_131  -1
    visit_1_4  order_active_lb_132  -1
    visit_1_4  order_active_ub_133  -4
    visit_1_4  service_visit_def_134  -1
    order_1_4  connected_order_arc_88  1
    order_1_4  connected_order_arc_95  1
    order_1_4  connected_order_arc_102  1
    order_1_4  connected_order_arc_105  -1
    order_1_4  connected_order_arc_107  -1
    order_1_4  connected_order_arc_109  -1
    order_1_4  order_active_lb_132  1
    order_1_4  order_active_ub_133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_77  -3
    arc_1_0_0  depot_departure_or_bypass_110  1
    arc_1_0_0  depot_return_or_bypass_111  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_77  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_1  arc_capacity_78  -3
    arc_1_0_1  depot_departure_or_bypass_110  1
    arc_1_0_1  in_degree_113  1
    arc_1_0_1  original_T_including_depot_unload_136  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_0_1  arc_capacity_78  1
    load_1_0_1  free_load_conservation_117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_2  arc_capacity_79  -3
    arc_1_0_2  depot_departure_or_bypass_110  1
    arc_1_0_2  in_degree_119  1
    arc_1_0_2  original_T_including_depot_unload_136  2
    MARKER    'MARKER'                 'INTEND'
    load_1_0_2  arc_capacity_79  1
    load_1_0_2  free_load_conservation_123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_3  arc_capacity_80  -3
    arc_1_0_3  depot_departure_or_bypass_110  1
    arc_1_0_3  in_degree_125  1
    arc_1_0_3  original_T_including_depot_unload_136  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_0_3  arc_capacity_80  1
    load_1_0_3  free_load_conservation_129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_4  arc_capacity_81  -3
    arc_1_0_4  depot_departure_or_bypass_110  1
    arc_1_0_4  in_degree_131  1
    arc_1_0_4  original_T_including_depot_unload_136  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_0_4  arc_capacity_81  1
    load_1_0_4  free_load_conservation_135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_0  arc_capacity_82  -3
    arc_1_1_0  depot_return_or_bypass_111  1
    arc_1_1_0  out_degree_112  1
    arc_1_1_0  original_T_including_depot_unload_136  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_1_0  arc_capacity_82  1
    load_1_1_0  free_load_conservation_117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_2  arc_capacity_83  -3
    arc_1_1_2  connected_order_arc_84  -5
    arc_1_1_2  out_degree_112  1
    arc_1_1_2  in_degree_119  1
    arc_1_1_2  original_T_including_depot_unload_136  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_1_2  arc_capacity_83  1
    load_1_1_2  free_load_conservation_117  1
    load_1_1_2  free_load_conservation_123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_3  arc_capacity_85  -3
    arc_1_1_3  connected_order_arc_86  -5
    arc_1_1_3  out_degree_112  1
    arc_1_1_3  in_degree_125  1
    arc_1_1_3  original_T_including_depot_unload_136  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_1_3  arc_capacity_85  1
    load_1_1_3  free_load_conservation_117  1
    load_1_1_3  free_load_conservation_129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_4  arc_capacity_87  -3
    arc_1_1_4  connected_order_arc_88  -5
    arc_1_1_4  out_degree_112  1
    arc_1_1_4  in_degree_131  1
    arc_1_1_4  original_T_including_depot_unload_136  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_1_4  arc_capacity_87  1
    load_1_1_4  free_load_conservation_117  1
    load_1_1_4  free_load_conservation_135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_0  arc_capacity_89  -3
    arc_1_2_0  depot_return_or_bypass_111  1
    arc_1_2_0  out_degree_118  1
    arc_1_2_0  original_T_including_depot_unload_136  2
    MARKER    'MARKER'                 'INTEND'
    load_1_2_0  arc_capacity_89  1
    load_1_2_0  free_load_conservation_123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_1  arc_capacity_90  -3
    arc_1_2_1  connected_order_arc_91  -5
    arc_1_2_1  in_degree_113  1
    arc_1_2_1  out_degree_118  1
    arc_1_2_1  original_T_including_depot_unload_136  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_2_1  arc_capacity_90  1
    load_1_2_1  free_load_conservation_117  -1
    load_1_2_1  free_load_conservation_123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_3  arc_capacity_92  -3
    arc_1_2_3  connected_order_arc_93  -5
    arc_1_2_3  out_degree_118  1
    arc_1_2_3  in_degree_125  1
    arc_1_2_3  original_T_including_depot_unload_136  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_2_3  arc_capacity_92  1
    load_1_2_3  free_load_conservation_123  1
    load_1_2_3  free_load_conservation_129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_4  arc_capacity_94  -3
    arc_1_2_4  connected_order_arc_95  -5
    arc_1_2_4  out_degree_118  1
    arc_1_2_4  in_degree_131  1
    arc_1_2_4  original_T_including_depot_unload_136  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_2_4  arc_capacity_94  1
    load_1_2_4  free_load_conservation_123  1
    load_1_2_4  free_load_conservation_135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_0  arc_capacity_96  -3
    arc_1_3_0  depot_return_or_bypass_111  1
    arc_1_3_0  out_degree_124  1
    arc_1_3_0  original_T_including_depot_unload_136  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_3_0  arc_capacity_96  1
    load_1_3_0  free_load_conservation_129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_1  arc_capacity_97  -3
    arc_1_3_1  connected_order_arc_98  -5
    arc_1_3_1  in_degree_113  1
    arc_1_3_1  out_degree_124  1
    arc_1_3_1  original_T_including_depot_unload_136  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_3_1  arc_capacity_97  1
    load_1_3_1  free_load_conservation_117  -1
    load_1_3_1  free_load_conservation_129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_2  arc_capacity_99  -3
    arc_1_3_2  connected_order_arc_100  -5
    arc_1_3_2  in_degree_119  1
    arc_1_3_2  out_degree_124  1
    arc_1_3_2  original_T_including_depot_unload_136  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_3_2  arc_capacity_99  1
    load_1_3_2  free_load_conservation_123  -1
    load_1_3_2  free_load_conservation_129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_4  arc_capacity_101  -3
    arc_1_3_4  connected_order_arc_102  -5
    arc_1_3_4  out_degree_124  1
    arc_1_3_4  in_degree_131  1
    arc_1_3_4  original_T_including_depot_unload_136  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_3_4  arc_capacity_101  1
    load_1_3_4  free_load_conservation_129  1
    load_1_3_4  free_load_conservation_135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_0  arc_capacity_103  -3
    arc_1_4_0  depot_return_or_bypass_111  1
    arc_1_4_0  out_degree_130  1
    arc_1_4_0  original_T_including_depot_unload_136  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_4_0  arc_capacity_103  1
    load_1_4_0  free_load_conservation_135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_1  arc_capacity_104  -3
    arc_1_4_1  connected_order_arc_105  -5
    arc_1_4_1  in_degree_113  1
    arc_1_4_1  out_degree_130  1
    arc_1_4_1  original_T_including_depot_unload_136  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_4_1  arc_capacity_104  1
    load_1_4_1  free_load_conservation_117  -1
    load_1_4_1  free_load_conservation_135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_2  arc_capacity_106  -3
    arc_1_4_2  connected_order_arc_107  -5
    arc_1_4_2  in_degree_119  1
    arc_1_4_2  out_degree_130  1
    arc_1_4_2  original_T_including_depot_unload_136  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_4_2  arc_capacity_106  1
    load_1_4_2  free_load_conservation_123  -1
    load_1_4_2  free_load_conservation_135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_3  arc_capacity_108  -3
    arc_1_4_3  connected_order_arc_109  -5
    arc_1_4_3  in_degree_125  1
    arc_1_4_3  out_degree_130  1
    arc_1_4_3  original_T_including_depot_unload_136  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_4_3  arc_capacity_108  1
    load_1_4_3  free_load_conservation_129  -1
    load_1_4_3  free_load_conservation_135  1
RHS
    RHS1      OBJ       -4.4999999999999996e-01
    RHS1      onehot_1_0  1
    RHS1      onehot_2_1  1
    RHS1      onehot_3_2  1
    RHS1      onehot_4_3  1
    RHS1      stock_ub_5  4
    RHS1      parent_nonstrict_scope_6  1.22500001
    RHS1      connected_order_arc_24  -4
    RHS1      connected_order_arc_26  -4
    RHS1      connected_order_arc_28  -4
    RHS1      connected_order_arc_31  -4
    RHS1      connected_order_arc_33  -4
    RHS1      connected_order_arc_35  -4
    RHS1      connected_order_arc_38  -4
    RHS1      connected_order_arc_40  -4
    RHS1      connected_order_arc_42  -4
    RHS1      connected_order_arc_45  -4
    RHS1      connected_order_arc_47  -4
    RHS1      connected_order_arc_49  -4
    RHS1      depot_departure_or_bypass_50  1
    RHS1      depot_return_or_bypass_51  1
    RHS1      original_T_including_depot_unload_76  100
    RHS1      connected_order_arc_84  -4
    RHS1      connected_order_arc_86  -4
    RHS1      connected_order_arc_88  -4
    RHS1      connected_order_arc_91  -4
    RHS1      connected_order_arc_93  -4
    RHS1      connected_order_arc_95  -4
    RHS1      connected_order_arc_98  -4
    RHS1      connected_order_arc_100  -4
    RHS1      connected_order_arc_102  -4
    RHS1      connected_order_arc_105  -4
    RHS1      connected_order_arc_107  -4
    RHS1      connected_order_arc_109  -4
    RHS1      depot_departure_or_bypass_110  1
    RHS1      depot_return_or_bypass_111  1
    RHS1      original_T_including_depot_unload_136  100
BOUNDS
 FX BND1      x_1_0     1
 BV BND1      x_1_0   
 FX BND1      x_1_1     0
 BV BND1      x_1_1   
 FX BND1      x_1_2     0
 BV BND1      x_1_2   
 FX BND1      x_2_0     1
 BV BND1      x_2_0   
 FX BND1      x_2_1     0
 BV BND1      x_2_1   
 FX BND1      x_2_2     0
 BV BND1      x_2_2   
 FX BND1      x_3_0     1
 BV BND1      x_3_0   
 FX BND1      x_3_1     0
 BV BND1      x_3_1   
 FX BND1      x_3_2     0
 BV BND1      x_3_2   
 FX BND1      x_3_3     0
 BV BND1      x_3_3   
 FX BND1      x_4_0     1
 BV BND1      x_4_0   
 FX BND1      x_4_1     0
 BV BND1      x_4_1   
 FX BND1      x_4_2     0
 BV BND1      x_4_2   
 FX BND1      x_4_3     0
 BV BND1      x_4_3   
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_0_2_0
 BV BND1      service_0_2_1
 BV BND1      service_1_2_0
 BV BND1      service_1_2_1
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 UP BND1      visit_0_1  1
 UP BND1      order_0_1  4
 UP BND1      visit_0_2  1
 UP BND1      order_0_2  4
 UP BND1      visit_0_3  1
 UP BND1      order_0_3  4
 UP BND1      visit_0_4  1
 UP BND1      order_0_4  4
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  3
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  3
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  3
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  3
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  3
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  3
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  3
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  3
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  3
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  3
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  3
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  3
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  3
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  3
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  3
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  3
 UP BND1      visit_1_1  1
 UP BND1      order_1_1  4
 UP BND1      visit_1_2  1
 UP BND1      order_1_2  4
 UP BND1      visit_1_3  1
 UP BND1      order_1_3  4
 UP BND1      visit_1_4  1
 UP BND1      order_1_4  4
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_1
 FX BND1      load_1_0_1  0
 BV BND1      arc_1_0_2
 FX BND1      load_1_0_2  0
 BV BND1      arc_1_0_3
 FX BND1      load_1_0_3  0
 BV BND1      arc_1_0_4
 FX BND1      load_1_0_4  0
 BV BND1      arc_1_1_0
 UP BND1      load_1_1_0  3
 BV BND1      arc_1_1_2
 UP BND1      load_1_1_2  3
 BV BND1      arc_1_1_3
 UP BND1      load_1_1_3  3
 BV BND1      arc_1_1_4
 UP BND1      load_1_1_4  3
 BV BND1      arc_1_2_0
 UP BND1      load_1_2_0  3
 BV BND1      arc_1_2_1
 UP BND1      load_1_2_1  3
 BV BND1      arc_1_2_3
 UP BND1      load_1_2_3  3
 BV BND1      arc_1_2_4
 UP BND1      load_1_2_4  3
 BV BND1      arc_1_3_0
 UP BND1      load_1_3_0  3
 BV BND1      arc_1_3_1
 UP BND1      load_1_3_1  3
 BV BND1      arc_1_3_2
 UP BND1      load_1_3_2  3
 BV BND1      arc_1_3_4
 UP BND1      load_1_3_4  3
 BV BND1      arc_1_4_0
 UP BND1      load_1_4_0  3
 BV BND1      arc_1_4_1
 UP BND1      load_1_4_1  3
 BV BND1      arc_1_4_2
 UP BND1      load_1_4_2  3
 BV BND1      arc_1_4_3
 UP BND1      load_1_4_3  3
ENDATA
