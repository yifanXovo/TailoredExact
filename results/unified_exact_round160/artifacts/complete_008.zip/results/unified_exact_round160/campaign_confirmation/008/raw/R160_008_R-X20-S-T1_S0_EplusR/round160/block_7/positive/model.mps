* Signature: 0x5e3c5798ad4a8f44
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 E  onehot_19_12
 E  normalized_mass_19_13
 E  normalized_ratio_19_14
 G  product_lb_15
 L  product_ub_16
 G  product_lb_17
 L  product_ub_18
 E  onehot_15_19
 E  normalized_mass_15_20
 E  normalized_ratio_15_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 G  product_lb_40
 L  product_ub_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 E  onehot_18_54
 E  normalized_mass_18_55
 E  normalized_ratio_18_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 E  onehot_16_63
 E  normalized_mass_16_64
 E  normalized_ratio_16_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 E  onehot_17_100
 E  normalized_mass_17_101
 E  normalized_ratio_17_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 E  onehot_12_135
 E  normalized_mass_12_136
 E  normalized_ratio_12_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 E  onehot_11_170
 E  normalized_mass_11_171
 E  normalized_ratio_11_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 E  onehot_9_177
 E  normalized_mass_9_178
 E  normalized_ratio_9_179
 G  stock_lb_180
 L  stock_ub_181
 L  parent_nonstrict_scope_182
 G  block_pair_pos_183
 G  block_pair_neg_184
 G  block_pair_pos_185
 G  block_pair_neg_186
 G  block_pair_pos_187
 G  block_pair_neg_188
 G  block_pair_pos_189
 G  block_pair_neg_190
 G  block_pair_pos_191
 G  block_pair_neg_192
 G  block_pair_pos_193
 G  block_pair_neg_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 E  normalization_239
 G  full_original_Gini_240
 E  unique_nonzero_owner_241
 E  unique_nonzero_owner_242
 E  unique_nonzero_owner_243
 E  unique_nonzero_owner_244
 E  unique_nonzero_owner_245
 E  unique_nonzero_owner_246
 E  unique_nonzero_owner_247
 E  unique_nonzero_owner_248
 E  unique_nonzero_owner_249
 E  unique_nonzero_owner_250
 E  unique_nonzero_owner_251
 E  unique_nonzero_owner_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 L  arc_capacity_311
 L  arc_capacity_312
 L  arc_capacity_313
 L  arc_capacity_314
 L  arc_capacity_315
 L  arc_capacity_316
 L  arc_capacity_317
 L  arc_capacity_318
 L  arc_capacity_319
 L  arc_capacity_320
 L  arc_capacity_321
 L  arc_capacity_322
 L  arc_capacity_323
 L  arc_capacity_324
 L  arc_capacity_325
 L  arc_capacity_326
 L  arc_capacity_327
 L  arc_capacity_328
 L  arc_capacity_329
 G  connected_order_arc_330
 L  arc_capacity_331
 G  connected_order_arc_332
 L  arc_capacity_333
 G  connected_order_arc_334
 L  arc_capacity_335
 G  connected_order_arc_336
 L  arc_capacity_337
 G  connected_order_arc_338
 L  arc_capacity_339
 G  connected_order_arc_340
 L  arc_capacity_341
 G  connected_order_arc_342
 L  arc_capacity_343
 G  connected_order_arc_344
 L  arc_capacity_345
 G  connected_order_arc_346
 L  arc_capacity_347
 G  connected_order_arc_348
 L  arc_capacity_349
 G  connected_order_arc_350
 L  arc_capacity_351
 G  connected_order_arc_352
 L  arc_capacity_353
 G  connected_order_arc_354
 L  arc_capacity_355
 G  connected_order_arc_356
 L  arc_capacity_357
 G  connected_order_arc_358
 L  arc_capacity_359
 L  arc_capacity_360
 G  connected_order_arc_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 G  connected_order_arc_385
 L  arc_capacity_386
 G  connected_order_arc_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 E  depot_departure_or_bypass_824
 E  depot_return_or_bypass_825
 E  out_degree_826
 E  in_degree_827
 G  order_active_lb_828
 L  order_active_ub_829
 E  segment_load_conservation_830
 G  segment_prefix_lb_831
 L  segment_prefix_ub_832
 E  out_degree_833
 E  in_degree_834
 G  order_active_lb_835
 L  order_active_ub_836
 E  segment_load_conservation_837
 G  segment_prefix_lb_838
 L  segment_prefix_ub_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  segment_load_conservation_844
 G  segment_prefix_lb_845
 L  segment_prefix_ub_846
 E  out_degree_847
 E  in_degree_848
 G  order_active_lb_849
 L  order_active_ub_850
 E  segment_load_conservation_851
 G  segment_prefix_lb_852
 L  segment_prefix_ub_853
 E  out_degree_854
 E  in_degree_855
 G  order_active_lb_856
 L  order_active_ub_857
 E  segment_load_conservation_858
 G  segment_prefix_lb_859
 L  segment_prefix_ub_860
 E  out_degree_861
 E  in_degree_862
 G  order_active_lb_863
 L  order_active_ub_864
 E  segment_load_conservation_865
 G  segment_prefix_lb_866
 L  segment_prefix_ub_867
 E  out_degree_868
 E  in_degree_869
 G  order_active_lb_870
 L  order_active_ub_871
 E  segment_load_conservation_872
 G  segment_prefix_lb_873
 L  segment_prefix_ub_874
 E  out_degree_875
 E  in_degree_876
 G  order_active_lb_877
 L  order_active_ub_878
 E  segment_load_conservation_879
 G  segment_prefix_lb_880
 L  segment_prefix_ub_881
 E  out_degree_882
 E  in_degree_883
 G  order_active_lb_884
 L  order_active_ub_885
 E  service_visit_def_886
 E  free_load_conservation_887
 E  out_degree_888
 E  in_degree_889
 G  order_active_lb_890
 L  order_active_ub_891
 E  service_visit_def_892
 E  free_load_conservation_893
 E  out_degree_894
 E  in_degree_895
 G  order_active_lb_896
 L  order_active_ub_897
 E  service_visit_def_898
 E  free_load_conservation_899
 E  out_degree_900
 E  in_degree_901
 G  order_active_lb_902
 L  order_active_ub_903
 E  service_visit_def_904
 E  free_load_conservation_905
 E  out_degree_906
 E  in_degree_907
 G  order_active_lb_908
 L  order_active_ub_909
 E  service_visit_def_910
 E  free_load_conservation_911
 E  out_degree_912
 E  in_degree_913
 G  order_active_lb_914
 L  order_active_ub_915
 E  service_visit_def_916
 E  free_load_conservation_917
 E  out_degree_918
 E  in_degree_919
 G  order_active_lb_920
 L  order_active_ub_921
 E  service_visit_def_922
 E  free_load_conservation_923
 E  out_degree_924
 E  in_degree_925
 G  order_active_lb_926
 L  order_active_ub_927
 E  service_visit_def_928
 E  free_load_conservation_929
 G  fixed_segment_relative_order_930
 G  fixed_segment_relative_order_931
 G  fixed_segment_relative_order_932
 G  fixed_segment_relative_order_933
 G  fixed_segment_relative_order_934
 G  fixed_segment_relative_order_935
 G  fixed_segment_relative_order_936
 L  original_T_including_depot_unload_937
 L  arc_capacity_938
 L  arc_capacity_939
 L  arc_capacity_940
 L  arc_capacity_941
 L  arc_capacity_942
 L  arc_capacity_943
 L  arc_capacity_944
 L  arc_capacity_945
 L  arc_capacity_946
 L  arc_capacity_947
 L  arc_capacity_948
 L  arc_capacity_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 E  depot_departure_or_bypass_1139
 E  depot_return_or_bypass_1140
 E  out_degree_1141
 E  in_degree_1142
 G  order_active_lb_1143
 L  order_active_ub_1144
 E  segment_load_conservation_1145
 G  segment_prefix_lb_1146
 L  segment_prefix_ub_1147
 E  out_degree_1148
 E  in_degree_1149
 G  order_active_lb_1150
 L  order_active_ub_1151
 E  segment_load_conservation_1152
 G  segment_prefix_lb_1153
 L  segment_prefix_ub_1154
 E  out_degree_1155
 E  in_degree_1156
 G  order_active_lb_1157
 L  order_active_ub_1158
 E  service_visit_def_1159
 E  free_load_conservation_1160
 E  out_degree_1161
 E  in_degree_1162
 G  order_active_lb_1163
 L  order_active_ub_1164
 E  service_visit_def_1165
 E  free_load_conservation_1166
 E  out_degree_1167
 E  in_degree_1168
 G  order_active_lb_1169
 L  order_active_ub_1170
 E  service_visit_def_1171
 E  free_load_conservation_1172
 E  out_degree_1173
 E  in_degree_1174
 G  order_active_lb_1175
 L  order_active_ub_1176
 E  service_visit_def_1177
 E  free_load_conservation_1178
 E  out_degree_1179
 E  in_degree_1180
 G  order_active_lb_1181
 L  order_active_ub_1182
 E  service_visit_def_1183
 E  free_load_conservation_1184
 E  out_degree_1185
 E  in_degree_1186
 G  order_active_lb_1187
 L  order_active_ub_1188
 E  service_visit_def_1189
 E  free_load_conservation_1190
 E  out_degree_1191
 E  in_degree_1192
 G  order_active_lb_1193
 L  order_active_ub_1194
 E  service_visit_def_1195
 E  free_load_conservation_1196
 E  out_degree_1197
 E  in_degree_1198
 G  order_active_lb_1199
 L  order_active_ub_1200
 E  service_visit_def_1201
 E  free_load_conservation_1202
 G  fixed_segment_relative_order_1203
 L  original_T_including_depot_unload_1204
COLUMNS
    t         normalized_mass_19_13  -1
    t         normalized_mass_15_20  -1
    t         normalized_mass_18_55  -1
    t         normalized_mass_16_64  -1
    t         normalized_mass_17_101  -1
    t         normalized_mass_12_136  -1
    t         normalized_mass_11_171  -1
    t         normalized_mass_9_178  -1
    t         normalization_239  1.0853571428571428e+01
    t         full_original_Gini_240  -2.4167857142857137e+01
    q         OBJ       1
    q         parent_nonstrict_scope_182  1
    q         full_original_Gini_240  20
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       3.1690152449914983e-03
    x_19_0    product_lb_0  -3.9538094640352073e-02
    x_19_0    product_ub_1  -0.0921355709115762
    x_19_0    onehot_19_12  1
    x_19_0    parent_nonstrict_scope_182  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_0  1
    w_19_0    product_ub_1  1
    w_19_0    normalized_mass_19_13  1
    w_19_0    full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       -3.1690152449914983e-03
    x_19_1    product_lb_2  -3.9538094640352073e-02
    x_19_1    product_ub_3  -0.0921355709115762
    x_19_1    onehot_19_12  1
    x_19_1    stock_lb_180  1
    x_19_1    stock_ub_181  1
    x_19_1    parent_nonstrict_scope_182  6.3380304899829966e-03
    x_19_1    unique_nonzero_owner_241  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_2  1
    w_19_1    product_ub_3  1
    w_19_1    normalized_mass_19_13  1
    w_19_1    normalized_ratio_19_14  -0.5
    w_19_1    full_original_Gini_240  -5.9964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_2    OBJ       -9.5070457349744949e-03
    x_19_2    product_lb_4  -3.9538094640352073e-02
    x_19_2    product_ub_5  -0.0921355709115762
    x_19_2    onehot_19_12  1
    x_19_2    stock_lb_180  2
    x_19_2    stock_ub_181  2
    x_19_2    unique_nonzero_owner_242  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_4  1
    w_19_2    product_ub_5  1
    w_19_2    normalized_mass_19_13  1
    w_19_2    normalized_ratio_19_14  -1
    w_19_2    full_original_Gini_240  -2.3964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -3.1690152449914983e-03
    x_19_3    product_lb_6  -3.9538094640352073e-02
    x_19_3    product_ub_7  -0.0921355709115762
    x_19_3    onehot_19_12  1
    x_19_3    stock_lb_180  3
    x_19_3    stock_ub_181  3
    x_19_3    parent_nonstrict_scope_182  6.3380304899829966e-03
    x_19_3    unique_nonzero_owner_243  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_6  1
    w_19_3    product_ub_7  1
    w_19_3    normalized_mass_19_13  1
    w_19_3    normalized_ratio_19_14  -1.5
    w_19_3    full_original_Gini_240  -7.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       3.1690152449914983e-03
    x_19_4    product_lb_8  -3.9538094640352073e-02
    x_19_4    product_ub_9  -0.0921355709115762
    x_19_4    onehot_19_12  1
    x_19_4    stock_lb_180  4
    x_19_4    stock_ub_181  4
    x_19_4    parent_nonstrict_scope_182  1.2676060979965993e-02
    x_19_4    unique_nonzero_owner_244  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_8  1
    w_19_4    product_ub_9  1
    w_19_4    normalized_mass_19_13  1
    w_19_4    normalized_ratio_19_14  -2
    w_19_4    full_original_Gini_240  -1.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       9.5070457349744949e-03
    x_19_5    product_lb_10  -3.9538094640352073e-02
    x_19_5    product_ub_11  -0.0921355709115762
    x_19_5    onehot_19_12  1
    x_19_5    stock_lb_180  5
    x_19_5    stock_ub_181  5
    x_19_5    parent_nonstrict_scope_182  1.9014091469948990e-02
    x_19_5    unique_nonzero_owner_245  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_10  1
    w_19_5    product_ub_11  1
    w_19_5    normalized_mass_19_13  1
    w_19_5    normalized_ratio_19_14  -2.5
    w_19_5    full_original_Gini_240  -1.9146428571428572e+01
    rho_19    normalized_ratio_19_14  1
    rho_19    block_pair_pos_225  -1
    rho_19    block_pair_neg_226  1
    rho_19    block_pair_pos_227  -1
    rho_19    block_pair_neg_228  1
    rho_19    block_pair_pos_229  -1
    rho_19    block_pair_neg_230  1
    rho_19    block_pair_pos_231  -1
    rho_19    block_pair_neg_232  1
    rho_19    block_pair_pos_233  -1
    rho_19    block_pair_neg_234  1
    rho_19    block_pair_pos_235  -1
    rho_19    block_pair_neg_236  1
    rho_19    block_pair_pos_237  -1
    rho_19    block_pair_neg_238  1
    rho_19    normalization_239  1
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       6.3380304899829966e-03
    x_15_0    product_lb_15  -3.9538094640352073e-02
    x_15_0    product_ub_16  -0.0921355709115762
    x_15_0    onehot_15_19  1
    x_15_0    parent_nonstrict_scope_182  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_15  1
    w_15_0    product_ub_16  1
    w_15_0    normalized_mass_15_20  1
    w_15_0    full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       -6.3380304899829966e-03
    x_15_1    product_lb_17  -3.9538094640352073e-02
    x_15_1    product_ub_18  -0.0921355709115762
    x_15_1    onehot_15_19  1
    x_15_1    stock_lb_180  1
    x_15_1    stock_ub_181  1
    x_15_1    unique_nonzero_owner_246  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_17  1
    w_15_1    product_ub_18  1
    w_15_1    normalized_mass_15_20  1
    w_15_1    normalized_ratio_15_21  -1
    w_15_1    full_original_Gini_240  -2.3964285714285714e+00
    rho_15    normalized_ratio_15_21  1
    rho_15    block_pair_pos_189  -1
    rho_15    block_pair_neg_190  1
    rho_15    block_pair_pos_191  -1
    rho_15    block_pair_neg_192  1
    rho_15    block_pair_pos_193  -1
    rho_15    block_pair_neg_194  1
    rho_15    block_pair_pos_195  -1
    rho_15    block_pair_neg_196  1
    rho_15    block_pair_pos_197  -1
    rho_15    block_pair_neg_198  1
    rho_15    block_pair_pos_199  -1
    rho_15    block_pair_neg_200  1
    rho_15    block_pair_pos_231  1
    rho_15    block_pair_neg_232  -1
    rho_15    normalization_239  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_22  -3.9538094640352073e-02
    x_18_0    product_ub_23  -0.0921355709115762
    x_18_0    onehot_18_54  1
    x_18_0    parent_nonstrict_scope_182  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_22  1
    w_18_0    product_ub_23  1
    w_18_0    normalized_mass_18_55  1
    w_18_0    full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_24  -3.9538094640352073e-02
    x_18_1    product_ub_25  -0.0921355709115762
    x_18_1    onehot_18_54  1
    x_18_1    stock_lb_180  1
    x_18_1    stock_ub_181  1
    x_18_1    parent_nonstrict_scope_182  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_247  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_24  1
    w_18_1    product_ub_25  1
    w_18_1    normalized_mass_18_55  1
    w_18_1    normalized_ratio_18_56  -1.4285714285714285e-01
    w_18_1    full_original_Gini_240  -9.4250000000000025e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_26  -3.9538094640352073e-02
    x_18_2    product_ub_27  -0.0921355709115762
    x_18_2    onehot_18_54  1
    x_18_2    stock_lb_180  2
    x_18_2    stock_ub_181  2
    x_18_2    parent_nonstrict_scope_182  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_248  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_26  1
    w_18_2    product_ub_27  1
    w_18_2    normalized_mass_18_55  1
    w_18_2    normalized_ratio_18_56  -2.8571428571428570e-01
    w_18_2    full_original_Gini_240  -7.9964285714285728e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_28  -3.9538094640352073e-02
    x_18_3    product_ub_29  -0.0921355709115762
    x_18_3    onehot_18_54  1
    x_18_3    stock_lb_180  3
    x_18_3    stock_ub_181  3
    x_18_3    parent_nonstrict_scope_182  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_249  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_28  1
    w_18_3    product_ub_29  1
    w_18_3    normalized_mass_18_55  1
    w_18_3    normalized_ratio_18_56  -4.2857142857142855e-01
    w_18_3    full_original_Gini_240  -6.5678571428571413e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_30  -3.9538094640352073e-02
    x_18_4    product_ub_31  -0.0921355709115762
    x_18_4    onehot_18_54  1
    x_18_4    stock_lb_180  4
    x_18_4    stock_ub_181  4
    x_18_4    parent_nonstrict_scope_182  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_250  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_30  1
    w_18_4    product_ub_31  1
    w_18_4    normalized_mass_18_55  1
    w_18_4    normalized_ratio_18_56  -5.7142857142857140e-01
    w_18_4    full_original_Gini_240  -5.4250000000000007e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_32  -3.9538094640352073e-02
    x_18_5    product_ub_33  -0.0921355709115762
    x_18_5    onehot_18_54  1
    x_18_5    stock_lb_180  5
    x_18_5    stock_ub_181  5
    x_18_5    parent_nonstrict_scope_182  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_251  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_32  1
    w_18_5    product_ub_33  1
    w_18_5    normalized_mass_18_55  1
    w_18_5    normalized_ratio_18_56  -7.1428571428571419e-01
    w_18_5    full_original_Gini_240  -4.2821428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_34  -3.9538094640352073e-02
    x_18_6    product_ub_35  -0.0921355709115762
    x_18_6    onehot_18_54  1
    x_18_6    stock_lb_180  6
    x_18_6    stock_ub_181  6
    x_18_6    parent_nonstrict_scope_182  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_252  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_34  1
    w_18_6    product_ub_35  1
    w_18_6    normalized_mass_18_55  1
    w_18_6    normalized_ratio_18_56  -8.5714285714285710e-01
    w_18_6    full_original_Gini_240  -3.2535714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_36  -3.9538094640352073e-02
    x_18_7    product_ub_37  -0.0921355709115762
    x_18_7    onehot_18_54  1
    x_18_7    stock_lb_180  7
    x_18_7    stock_ub_181  7
    x_18_7    unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_36  1
    w_18_7    product_ub_37  1
    w_18_7    normalized_mass_18_55  1
    w_18_7    normalized_ratio_18_56  -1
    w_18_7    full_original_Gini_240  -2.3964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_38  -3.9538094640352073e-02
    x_18_8    product_ub_39  -0.0921355709115762
    x_18_8    onehot_18_54  1
    x_18_8    stock_lb_180  8
    x_18_8    stock_ub_181  8
    x_18_8    parent_nonstrict_scope_182  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_38  1
    w_18_8    product_ub_39  1
    w_18_8    normalized_mass_18_55  1
    w_18_8    normalized_ratio_18_56  -1.1428571428571428e+00
    w_18_8    full_original_Gini_240  -3.5749999999999993e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_40  -3.9538094640352073e-02
    x_18_9    product_ub_41  -0.0921355709115762
    x_18_9    onehot_18_54  1
    x_18_9    stock_lb_180  9
    x_18_9    stock_ub_181  9
    x_18_9    parent_nonstrict_scope_182  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_40  1
    w_18_9    product_ub_41  1
    w_18_9    normalized_mass_18_55  1
    w_18_9    normalized_ratio_18_56  -1.2857142857142856e+00
    w_18_9    full_original_Gini_240  -5.0035714285714272e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_42  -3.9538094640352073e-02
    x_18_10   product_ub_43  -0.0921355709115762
    x_18_10   onehot_18_54  1
    x_18_10   stock_lb_180  10
    x_18_10   stock_ub_181  10
    x_18_10   parent_nonstrict_scope_182  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_42  1
    w_18_10   product_ub_43  1
    w_18_10   normalized_mass_18_55  1
    w_18_10   normalized_ratio_18_56  -1.4285714285714284e+00
    w_18_10   full_original_Gini_240  -6.4321428571428552e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_44  -3.9538094640352073e-02
    x_18_11   product_ub_45  -0.0921355709115762
    x_18_11   onehot_18_54  1
    x_18_11   stock_lb_180  11
    x_18_11   stock_ub_181  11
    x_18_11   parent_nonstrict_scope_182  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_44  1
    w_18_11   product_ub_45  1
    w_18_11   normalized_mass_18_55  1
    w_18_11   normalized_ratio_18_56  -1.5714285714285714e+00
    w_18_11   full_original_Gini_240  -8.0035714285714263e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_46  -3.9538094640352073e-02
    x_18_12   product_ub_47  -0.0921355709115762
    x_18_12   onehot_18_54  1
    x_18_12   stock_lb_180  12
    x_18_12   stock_ub_181  12
    x_18_12   parent_nonstrict_scope_182  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_46  1
    w_18_12   product_ub_47  1
    w_18_12   normalized_mass_18_55  1
    w_18_12   normalized_ratio_18_56  -1.7142857142857142e+00
    w_18_12   full_original_Gini_240  -9.71785714285714
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_48  -3.9538094640352073e-02
    x_18_13   product_ub_49  -0.0921355709115762
    x_18_13   onehot_18_54  1
    x_18_13   stock_lb_180  13
    x_18_13   stock_ub_181  13
    x_18_13   parent_nonstrict_scope_182  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_48  1
    w_18_13   product_ub_49  1
    w_18_13   normalized_mass_18_55  1
    w_18_13   normalized_ratio_18_56  -1.8571428571428570e+00
    w_18_13   full_original_Gini_240  -1.1432142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_50  -3.9538094640352073e-02
    x_18_14   product_ub_51  -0.0921355709115762
    x_18_14   onehot_18_54  1
    x_18_14   stock_lb_180  14
    x_18_14   stock_ub_181  14
    x_18_14   parent_nonstrict_scope_182  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_50  1
    w_18_14   product_ub_51  1
    w_18_14   normalized_mass_18_55  1
    w_18_14   normalized_ratio_18_56  -2
    w_18_14   full_original_Gini_240  -1.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_52  -3.9538094640352073e-02
    x_18_15   product_ub_53  -0.0921355709115762
    x_18_15   onehot_18_54  1
    x_18_15   stock_lb_180  15
    x_18_15   stock_ub_181  15
    x_18_15   parent_nonstrict_scope_182  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_52  1
    w_18_15   product_ub_53  1
    w_18_15   normalized_mass_18_55  1
    w_18_15   normalized_ratio_18_56  -2.1428571428571428e+00
    w_18_15   full_original_Gini_240  -1.4860714285714282e+01
    rho_18    normalized_ratio_18_56  1
    rho_18    block_pair_pos_199  1
    rho_18    block_pair_neg_200  -1
    rho_18    block_pair_pos_215  -1
    rho_18    block_pair_neg_216  1
    rho_18    block_pair_pos_217  -1
    rho_18    block_pair_neg_218  1
    rho_18    block_pair_pos_219  -1
    rho_18    block_pair_neg_220  1
    rho_18    block_pair_pos_221  -1
    rho_18    block_pair_neg_222  1
    rho_18    block_pair_pos_223  -1
    rho_18    block_pair_neg_224  1
    rho_18    block_pair_pos_237  1
    rho_18    block_pair_neg_238  -1
    rho_18    normalization_239  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       6.3380304899829966e-03
    x_16_0    product_lb_57  -3.9538094640352073e-02
    x_16_0    product_ub_58  -0.0921355709115762
    x_16_0    onehot_16_63  1
    x_16_0    parent_nonstrict_scope_182  1.2676060979965993e-02
    x_16_0    unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_57  1
    w_16_0    product_ub_58  1
    w_16_0    normalized_mass_16_64  1
    w_16_0    full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       -6.3380304899829966e-03
    x_16_1    product_lb_59  -3.9538094640352073e-02
    x_16_1    product_ub_60  -0.0921355709115762
    x_16_1    onehot_16_63  1
    x_16_1    stock_lb_180  1
    x_16_1    stock_ub_181  1
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_59  1
    w_16_1    product_ub_60  1
    w_16_1    normalized_mass_16_64  1
    w_16_1    normalized_ratio_16_65  -1
    w_16_1    full_original_Gini_240  -2.3964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       6.3380304899829966e-03
    x_16_2    product_lb_61  -3.9538094640352073e-02
    x_16_2    product_ub_62  -0.0921355709115762
    x_16_2    onehot_16_63  1
    x_16_2    stock_lb_180  2
    x_16_2    stock_ub_181  2
    x_16_2    parent_nonstrict_scope_182  1.2676060979965993e-02
    x_16_2    unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_61  1
    w_16_2    product_ub_62  1
    w_16_2    normalized_mass_16_64  1
    w_16_2    normalized_ratio_16_65  -2
    w_16_2    full_original_Gini_240  -1.3146428571428572e+01
    rho_16    normalized_ratio_16_65  1
    rho_16    block_pair_pos_195  1
    rho_16    block_pair_neg_196  -1
    rho_16    block_pair_pos_201  -1
    rho_16    block_pair_neg_202  1
    rho_16    block_pair_pos_203  -1
    rho_16    block_pair_neg_204  1
    rho_16    block_pair_pos_205  -1
    rho_16    block_pair_neg_206  1
    rho_16    block_pair_pos_207  -1
    rho_16    block_pair_neg_208  1
    rho_16    block_pair_pos_221  1
    rho_16    block_pair_neg_222  -1
    rho_16    block_pair_pos_233  1
    rho_16    block_pair_neg_234  -1
    rho_16    normalization_239  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_66  -3.9538094640352073e-02
    x_17_0    product_ub_67  -0.0921355709115762
    x_17_0    onehot_17_100  1
    x_17_0    parent_nonstrict_scope_182  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_66  1
    w_17_0    product_ub_67  1
    w_17_0    normalized_mass_17_101  1
    w_17_0    full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_68  -3.9538094640352073e-02
    x_17_1    product_ub_69  -0.0921355709115762
    x_17_1    onehot_17_100  1
    x_17_1    stock_lb_180  1
    x_17_1    stock_ub_181  1
    x_17_1    parent_nonstrict_scope_182  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_68  1
    w_17_1    product_ub_69  1
    w_17_1    normalized_mass_17_101  1
    w_17_1    normalized_ratio_17_102  -1.1111111111111110e-01
    w_17_1    full_original_Gini_240  -9.7424603174603170e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_70  -3.9538094640352073e-02
    x_17_2    product_ub_71  -0.0921355709115762
    x_17_2    onehot_17_100  1
    x_17_2    stock_lb_180  2
    x_17_2    stock_ub_181  2
    x_17_2    parent_nonstrict_scope_182  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_70  1
    w_17_2    product_ub_71  1
    w_17_2    normalized_mass_17_101  1
    w_17_2    normalized_ratio_17_102  -2.2222222222222221e-01
    w_17_2    full_original_Gini_240  -8.6313492063492063e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_72  -3.9538094640352073e-02
    x_17_3    product_ub_73  -0.0921355709115762
    x_17_3    onehot_17_100  1
    x_17_3    stock_lb_180  3
    x_17_3    stock_ub_181  3
    x_17_3    parent_nonstrict_scope_182  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_72  1
    w_17_3    product_ub_73  1
    w_17_3    normalized_mass_17_101  1
    w_17_3    normalized_ratio_17_102  -3.3333333333333331e-01
    w_17_3    full_original_Gini_240  -7.5202380952380974e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_74  -3.9538094640352073e-02
    x_17_4    product_ub_75  -0.0921355709115762
    x_17_4    onehot_17_100  1
    x_17_4    stock_lb_180  4
    x_17_4    stock_ub_181  4
    x_17_4    parent_nonstrict_scope_182  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_74  1
    w_17_4    product_ub_75  1
    w_17_4    normalized_mass_17_101  1
    w_17_4    normalized_ratio_17_102  -4.4444444444444442e-01
    w_17_4    full_original_Gini_240  -6.4408730158730148e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_76  -3.9538094640352073e-02
    x_17_5    product_ub_77  -0.0921355709115762
    x_17_5    onehot_17_100  1
    x_17_5    stock_lb_180  5
    x_17_5    stock_ub_181  5
    x_17_5    parent_nonstrict_scope_182  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_76  1
    w_17_5    product_ub_77  1
    w_17_5    normalized_mass_17_101  1
    w_17_5    normalized_ratio_17_102  -5.5555555555555558e-01
    w_17_5    full_original_Gini_240  -5.5519841269841272e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_78  -3.9538094640352073e-02
    x_17_6    product_ub_79  -0.0921355709115762
    x_17_6    onehot_17_100  1
    x_17_6    stock_lb_180  6
    x_17_6    stock_ub_181  6
    x_17_6    parent_nonstrict_scope_182  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_78  1
    w_17_6    product_ub_79  1
    w_17_6    normalized_mass_17_101  1
    w_17_6    normalized_ratio_17_102  -6.6666666666666663e-01
    w_17_6    full_original_Gini_240  -4.6630952380952388e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_80  -3.9538094640352073e-02
    x_17_7    product_ub_81  -0.0921355709115762
    x_17_7    onehot_17_100  1
    x_17_7    stock_lb_180  7
    x_17_7    stock_ub_181  7
    x_17_7    parent_nonstrict_scope_182  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_80  1
    w_17_7    product_ub_81  1
    w_17_7    normalized_mass_17_101  1
    w_17_7    normalized_ratio_17_102  -7.7777777777777768e-01
    w_17_7    full_original_Gini_240  -3.77420634920635
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_82  -3.9538094640352073e-02
    x_17_8    product_ub_83  -0.0921355709115762
    x_17_8    onehot_17_100  1
    x_17_8    stock_lb_180  8
    x_17_8    stock_ub_181  8
    x_17_8    parent_nonstrict_scope_182  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_82  1
    w_17_8    product_ub_83  1
    w_17_8    normalized_mass_17_101  1
    w_17_8    normalized_ratio_17_102  -8.8888888888888884e-01
    w_17_8    full_original_Gini_240  -3.0630952380952383e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_84  -3.9538094640352073e-02
    x_17_9    product_ub_85  -0.0921355709115762
    x_17_9    onehot_17_100  1
    x_17_9    stock_lb_180  9
    x_17_9    stock_ub_181  9
    x_17_9    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_84  1
    w_17_9    product_ub_85  1
    w_17_9    normalized_mass_17_101  1
    w_17_9    normalized_ratio_17_102  -1
    w_17_9    full_original_Gini_240  -2.3964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_86  -3.9538094640352073e-02
    x_17_10   product_ub_87  -0.0921355709115762
    x_17_10   onehot_17_100  1
    x_17_10   stock_lb_180  10
    x_17_10   stock_ub_181  10
    x_17_10   parent_nonstrict_scope_182  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_86  1
    w_17_10   product_ub_87  1
    w_17_10   normalized_mass_17_101  1
    w_17_10   normalized_ratio_17_102  -1.1111111111111112e+00
    w_17_10   full_original_Gini_240  -3.2853174603174606e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_88  -3.9538094640352073e-02
    x_17_11   product_ub_89  -0.0921355709115762
    x_17_11   onehot_17_100  1
    x_17_11   stock_lb_180  11
    x_17_11   stock_ub_181  11
    x_17_11   parent_nonstrict_scope_182  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_88  1
    w_17_11   product_ub_89  1
    w_17_11   normalized_mass_17_101  1
    w_17_11   normalized_ratio_17_102  -1.2222222222222221e+00
    w_17_11   full_original_Gini_240  -4.3686507936507928e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_90  -3.9538094640352073e-02
    x_17_12   product_ub_91  -0.0921355709115762
    x_17_12   onehot_17_100  1
    x_17_12   stock_lb_180  12
    x_17_12   stock_ub_181  12
    x_17_12   parent_nonstrict_scope_182  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_90  1
    w_17_12   product_ub_91  1
    w_17_12   normalized_mass_17_101  1
    w_17_12   normalized_ratio_17_102  -1.3333333333333333e+00
    w_17_12   full_original_Gini_240  -5.4797619047619035e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_92  -3.9538094640352073e-02
    x_17_13   product_ub_93  -0.0921355709115762
    x_17_13   onehot_17_100  1
    x_17_13   stock_lb_180  13
    x_17_13   stock_ub_181  13
    x_17_13   parent_nonstrict_scope_182  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_92  1
    w_17_13   product_ub_93  1
    w_17_13   normalized_mass_17_101  1
    w_17_13   normalized_ratio_17_102  -1.4444444444444444e+00
    w_17_13   full_original_Gini_240  -6.5908730158730160e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_94  -3.9538094640352073e-02
    x_17_14   product_ub_95  -0.0921355709115762
    x_17_14   onehot_17_100  1
    x_17_14   stock_lb_180  14
    x_17_14   stock_ub_181  14
    x_17_14   parent_nonstrict_scope_182  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_94  1
    w_17_14   product_ub_95  1
    w_17_14   normalized_mass_17_101  1
    w_17_14   normalized_ratio_17_102  -1.5555555555555554e+00
    w_17_14   full_original_Gini_240  -7.8130952380952357e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_96  -3.9538094640352073e-02
    x_17_15   product_ub_97  -0.0921355709115762
    x_17_15   onehot_17_100  1
    x_17_15   stock_lb_180  15
    x_17_15   stock_ub_181  15
    x_17_15   parent_nonstrict_scope_182  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_96  1
    w_17_15   product_ub_97  1
    w_17_15   normalized_mass_17_101  1
    w_17_15   normalized_ratio_17_102  -1.6666666666666665e+00
    w_17_15   full_original_Gini_240  -9.1464285714285687e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_98  -3.9538094640352073e-02
    x_17_16   product_ub_99  -0.0921355709115762
    x_17_16   onehot_17_100  1
    x_17_16   stock_lb_180  16
    x_17_16   stock_ub_181  16
    x_17_16   parent_nonstrict_scope_182  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_98  1
    w_17_16   product_ub_99  1
    w_17_16   normalized_mass_17_101  1
    w_17_16   normalized_ratio_17_102  -1.7777777777777777e+00
    w_17_16   full_original_Gini_240  -1.0479761904761904e+01
    rho_17    normalized_ratio_17_102  1
    rho_17    block_pair_pos_197  1
    rho_17    block_pair_neg_198  -1
    rho_17    block_pair_pos_207  1
    rho_17    block_pair_neg_208  -1
    rho_17    block_pair_pos_209  -1
    rho_17    block_pair_neg_210  1
    rho_17    block_pair_pos_211  -1
    rho_17    block_pair_neg_212  1
    rho_17    block_pair_pos_213  -1
    rho_17    block_pair_neg_214  1
    rho_17    block_pair_pos_223  1
    rho_17    block_pair_neg_224  -1
    rho_17    block_pair_pos_235  1
    rho_17    block_pair_neg_236  -1
    rho_17    normalization_239  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_103  -3.9538094640352073e-02
    x_12_0    product_ub_104  -0.0921355709115762
    x_12_0    onehot_12_135  1
    x_12_0    parent_nonstrict_scope_182  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_103  1
    w_12_0    product_ub_104  1
    w_12_0    normalized_mass_12_136  1
    w_12_0    full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_105  -3.9538094640352073e-02
    x_12_1    product_ub_106  -0.0921355709115762
    x_12_1    onehot_12_135  1
    x_12_1    stock_lb_180  1
    x_12_1    stock_ub_181  1
    x_12_1    parent_nonstrict_scope_182  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_105  1
    w_12_1    product_ub_106  1
    w_12_1    normalized_mass_12_136  1
    w_12_1    normalized_ratio_12_137  -1.4285714285714285e-01
    w_12_1    full_original_Gini_240  -9.4250000000000025e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_107  -3.9538094640352073e-02
    x_12_2    product_ub_108  -0.0921355709115762
    x_12_2    onehot_12_135  1
    x_12_2    stock_lb_180  2
    x_12_2    stock_ub_181  2
    x_12_2    parent_nonstrict_scope_182  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_107  1
    w_12_2    product_ub_108  1
    w_12_2    normalized_mass_12_136  1
    w_12_2    normalized_ratio_12_137  -2.8571428571428570e-01
    w_12_2    full_original_Gini_240  -7.9964285714285728e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_109  -3.9538094640352073e-02
    x_12_3    product_ub_110  -0.0921355709115762
    x_12_3    onehot_12_135  1
    x_12_3    stock_lb_180  3
    x_12_3    stock_ub_181  3
    x_12_3    parent_nonstrict_scope_182  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_109  1
    w_12_3    product_ub_110  1
    w_12_3    normalized_mass_12_136  1
    w_12_3    normalized_ratio_12_137  -4.2857142857142855e-01
    w_12_3    full_original_Gini_240  -6.5678571428571413e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_111  -3.9538094640352073e-02
    x_12_4    product_ub_112  -0.0921355709115762
    x_12_4    onehot_12_135  1
    x_12_4    stock_lb_180  4
    x_12_4    stock_ub_181  4
    x_12_4    parent_nonstrict_scope_182  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_111  1
    w_12_4    product_ub_112  1
    w_12_4    normalized_mass_12_136  1
    w_12_4    normalized_ratio_12_137  -5.7142857142857140e-01
    w_12_4    full_original_Gini_240  -5.4250000000000007e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_113  -3.9538094640352073e-02
    x_12_5    product_ub_114  -0.0921355709115762
    x_12_5    onehot_12_135  1
    x_12_5    stock_lb_180  5
    x_12_5    stock_ub_181  5
    x_12_5    parent_nonstrict_scope_182  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_113  1
    w_12_5    product_ub_114  1
    w_12_5    normalized_mass_12_136  1
    w_12_5    normalized_ratio_12_137  -7.1428571428571419e-01
    w_12_5    full_original_Gini_240  -4.2821428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_115  -3.9538094640352073e-02
    x_12_6    product_ub_116  -0.0921355709115762
    x_12_6    onehot_12_135  1
    x_12_6    stock_lb_180  6
    x_12_6    stock_ub_181  6
    x_12_6    parent_nonstrict_scope_182  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_115  1
    w_12_6    product_ub_116  1
    w_12_6    normalized_mass_12_136  1
    w_12_6    normalized_ratio_12_137  -8.5714285714285710e-01
    w_12_6    full_original_Gini_240  -3.2535714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_117  -3.9538094640352073e-02
    x_12_7    product_ub_118  -0.0921355709115762
    x_12_7    onehot_12_135  1
    x_12_7    stock_lb_180  7
    x_12_7    stock_ub_181  7
    x_12_7    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_117  1
    w_12_7    product_ub_118  1
    w_12_7    normalized_mass_12_136  1
    w_12_7    normalized_ratio_12_137  -1
    w_12_7    full_original_Gini_240  -2.3964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_119  -3.9538094640352073e-02
    x_12_8    product_ub_120  -0.0921355709115762
    x_12_8    onehot_12_135  1
    x_12_8    stock_lb_180  8
    x_12_8    stock_ub_181  8
    x_12_8    parent_nonstrict_scope_182  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_119  1
    w_12_8    product_ub_120  1
    w_12_8    normalized_mass_12_136  1
    w_12_8    normalized_ratio_12_137  -1.1428571428571428e+00
    w_12_8    full_original_Gini_240  -3.5749999999999993e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_121  -3.9538094640352073e-02
    x_12_9    product_ub_122  -0.0921355709115762
    x_12_9    onehot_12_135  1
    x_12_9    stock_lb_180  9
    x_12_9    stock_ub_181  9
    x_12_9    parent_nonstrict_scope_182  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_121  1
    w_12_9    product_ub_122  1
    w_12_9    normalized_mass_12_136  1
    w_12_9    normalized_ratio_12_137  -1.2857142857142856e+00
    w_12_9    full_original_Gini_240  -5.0035714285714272e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_123  -3.9538094640352073e-02
    x_12_10   product_ub_124  -0.0921355709115762
    x_12_10   onehot_12_135  1
    x_12_10   stock_lb_180  10
    x_12_10   stock_ub_181  10
    x_12_10   parent_nonstrict_scope_182  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_123  1
    w_12_10   product_ub_124  1
    w_12_10   normalized_mass_12_136  1
    w_12_10   normalized_ratio_12_137  -1.4285714285714284e+00
    w_12_10   full_original_Gini_240  -6.4321428571428552e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_125  -3.9538094640352073e-02
    x_12_11   product_ub_126  -0.0921355709115762
    x_12_11   onehot_12_135  1
    x_12_11   stock_lb_180  11
    x_12_11   stock_ub_181  11
    x_12_11   parent_nonstrict_scope_182  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_125  1
    w_12_11   product_ub_126  1
    w_12_11   normalized_mass_12_136  1
    w_12_11   normalized_ratio_12_137  -1.5714285714285714e+00
    w_12_11   full_original_Gini_240  -8.0035714285714263e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_127  -3.9538094640352073e-02
    x_12_12   product_ub_128  -0.0921355709115762
    x_12_12   onehot_12_135  1
    x_12_12   stock_lb_180  12
    x_12_12   stock_ub_181  12
    x_12_12   parent_nonstrict_scope_182  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_127  1
    w_12_12   product_ub_128  1
    w_12_12   normalized_mass_12_136  1
    w_12_12   normalized_ratio_12_137  -1.7142857142857142e+00
    w_12_12   full_original_Gini_240  -9.71785714285714
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_129  -3.9538094640352073e-02
    x_12_13   product_ub_130  -0.0921355709115762
    x_12_13   onehot_12_135  1
    x_12_13   stock_lb_180  13
    x_12_13   stock_ub_181  13
    x_12_13   parent_nonstrict_scope_182  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_129  1
    w_12_13   product_ub_130  1
    w_12_13   normalized_mass_12_136  1
    w_12_13   normalized_ratio_12_137  -1.8571428571428570e+00
    w_12_13   full_original_Gini_240  -1.1432142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_131  -3.9538094640352073e-02
    x_12_14   product_ub_132  -0.0921355709115762
    x_12_14   onehot_12_135  1
    x_12_14   stock_lb_180  14
    x_12_14   stock_ub_181  14
    x_12_14   parent_nonstrict_scope_182  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_131  1
    w_12_14   product_ub_132  1
    w_12_14   normalized_mass_12_136  1
    w_12_14   normalized_ratio_12_137  -2
    w_12_14   full_original_Gini_240  -1.3146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_133  -3.9538094640352073e-02
    x_12_15   product_ub_134  -0.0921355709115762
    x_12_15   onehot_12_135  1
    x_12_15   stock_lb_180  15
    x_12_15   stock_ub_181  15
    x_12_15   parent_nonstrict_scope_182  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_133  1
    w_12_15   product_ub_134  1
    w_12_15   normalized_mass_12_136  1
    w_12_15   normalized_ratio_12_137  -2.1428571428571428e+00
    w_12_15   full_original_Gini_240  -1.4860714285714282e+01
    rho_12    normalized_ratio_12_137  1
    rho_12    block_pair_pos_185  -1
    rho_12    block_pair_neg_186  1
    rho_12    block_pair_pos_187  -1
    rho_12    block_pair_neg_188  1
    rho_12    block_pair_pos_193  1
    rho_12    block_pair_neg_194  -1
    rho_12    block_pair_pos_205  1
    rho_12    block_pair_neg_206  -1
    rho_12    block_pair_pos_213  1
    rho_12    block_pair_neg_214  -1
    rho_12    block_pair_pos_219  1
    rho_12    block_pair_neg_220  -1
    rho_12    block_pair_pos_229  1
    rho_12    block_pair_neg_230  -1
    rho_12    normalization_239  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_138  -3.9538094640352073e-02
    x_11_0    product_ub_139  -0.0921355709115762
    x_11_0    onehot_11_170  1
    x_11_0    parent_nonstrict_scope_182  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_138  1
    w_11_0    product_ub_139  1
    w_11_0    normalized_mass_11_171  1
    w_11_0    full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_140  -3.9538094640352073e-02
    x_11_1    product_ub_141  -0.0921355709115762
    x_11_1    onehot_11_170  1
    x_11_1    stock_lb_180  1
    x_11_1    stock_ub_181  1
    x_11_1    parent_nonstrict_scope_182  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_140  1
    w_11_1    product_ub_141  1
    w_11_1    normalized_mass_11_171  1
    w_11_1    normalized_ratio_11_172  -0.125
    w_11_1    full_original_Gini_240  -9.6035714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_142  -3.9538094640352073e-02
    x_11_2    product_ub_143  -0.0921355709115762
    x_11_2    onehot_11_170  1
    x_11_2    stock_lb_180  2
    x_11_2    stock_ub_181  2
    x_11_2    parent_nonstrict_scope_182  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_142  1
    w_11_2    product_ub_143  1
    w_11_2    normalized_mass_11_171  1
    w_11_2    normalized_ratio_11_172  -0.25
    w_11_2    full_original_Gini_240  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_144  -3.9538094640352073e-02
    x_11_3    product_ub_145  -0.0921355709115762
    x_11_3    onehot_11_170  1
    x_11_3    stock_lb_180  3
    x_11_3    stock_ub_181  3
    x_11_3    parent_nonstrict_scope_182  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_144  1
    w_11_3    product_ub_145  1
    w_11_3    normalized_mass_11_171  1
    w_11_3    normalized_ratio_11_172  -0.375
    w_11_3    full_original_Gini_240  -7.1035714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_146  -3.9538094640352073e-02
    x_11_4    product_ub_147  -0.0921355709115762
    x_11_4    onehot_11_170  1
    x_11_4    stock_lb_180  4
    x_11_4    stock_ub_181  4
    x_11_4    parent_nonstrict_scope_182  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_146  1
    w_11_4    product_ub_147  1
    w_11_4    normalized_mass_11_171  1
    w_11_4    normalized_ratio_11_172  -0.5
    w_11_4    full_original_Gini_240  -5.9964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_148  -3.9538094640352073e-02
    x_11_5    product_ub_149  -0.0921355709115762
    x_11_5    onehot_11_170  1
    x_11_5    stock_lb_180  5
    x_11_5    stock_ub_181  5
    x_11_5    parent_nonstrict_scope_182  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_148  1
    w_11_5    product_ub_149  1
    w_11_5    normalized_mass_11_171  1
    w_11_5    normalized_ratio_11_172  -0.625
    w_11_5    full_original_Gini_240  -4.9964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_150  -3.9538094640352073e-02
    x_11_6    product_ub_151  -0.0921355709115762
    x_11_6    onehot_11_170  1
    x_11_6    stock_lb_180  6
    x_11_6    stock_ub_181  6
    x_11_6    parent_nonstrict_scope_182  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_150  1
    w_11_6    product_ub_151  1
    w_11_6    normalized_mass_11_171  1
    w_11_6    normalized_ratio_11_172  -0.75
    w_11_6    full_original_Gini_240  -3.9964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_152  -3.9538094640352073e-02
    x_11_7    product_ub_153  -0.0921355709115762
    x_11_7    onehot_11_170  1
    x_11_7    stock_lb_180  7
    x_11_7    stock_ub_181  7
    x_11_7    parent_nonstrict_scope_182  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_152  1
    w_11_7    product_ub_153  1
    w_11_7    normalized_mass_11_171  1
    w_11_7    normalized_ratio_11_172  -0.875
    w_11_7    full_original_Gini_240  -3.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_154  -3.9538094640352073e-02
    x_11_8    product_ub_155  -0.0921355709115762
    x_11_8    onehot_11_170  1
    x_11_8    stock_lb_180  8
    x_11_8    stock_ub_181  8
    x_11_8    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_154  1
    w_11_8    product_ub_155  1
    w_11_8    normalized_mass_11_171  1
    w_11_8    normalized_ratio_11_172  -1
    w_11_8    full_original_Gini_240  -2.3964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_156  -3.9538094640352073e-02
    x_11_9    product_ub_157  -0.0921355709115762
    x_11_9    onehot_11_170  1
    x_11_9    stock_lb_180  9
    x_11_9    stock_ub_181  9
    x_11_9    parent_nonstrict_scope_182  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_156  1
    w_11_9    product_ub_157  1
    w_11_9    normalized_mass_11_171  1
    w_11_9    normalized_ratio_11_172  -1.125
    w_11_9    full_original_Gini_240  -3.3964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_158  -3.9538094640352073e-02
    x_11_10   product_ub_159  -0.0921355709115762
    x_11_10   onehot_11_170  1
    x_11_10   stock_lb_180  10
    x_11_10   stock_ub_181  10
    x_11_10   parent_nonstrict_scope_182  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_158  1
    w_11_10   product_ub_159  1
    w_11_10   normalized_mass_11_171  1
    w_11_10   normalized_ratio_11_172  -1.25
    w_11_10   full_original_Gini_240  -4.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_160  -3.9538094640352073e-02
    x_11_11   product_ub_161  -0.0921355709115762
    x_11_11   onehot_11_170  1
    x_11_11   stock_lb_180  11
    x_11_11   stock_ub_181  11
    x_11_11   parent_nonstrict_scope_182  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_160  1
    w_11_11   product_ub_161  1
    w_11_11   normalized_mass_11_171  1
    w_11_11   normalized_ratio_11_172  -1.375
    w_11_11   full_original_Gini_240  -5.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_162  -3.9538094640352073e-02
    x_11_12   product_ub_163  -0.0921355709115762
    x_11_12   onehot_11_170  1
    x_11_12   stock_lb_180  12
    x_11_12   stock_ub_181  12
    x_11_12   parent_nonstrict_scope_182  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_162  1
    w_11_12   product_ub_163  1
    w_11_12   normalized_mass_11_171  1
    w_11_12   normalized_ratio_11_172  -1.5
    w_11_12   full_original_Gini_240  -7.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_164  -3.9538094640352073e-02
    x_11_13   product_ub_165  -0.0921355709115762
    x_11_13   onehot_11_170  1
    x_11_13   stock_lb_180  13
    x_11_13   stock_ub_181  13
    x_11_13   parent_nonstrict_scope_182  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_164  1
    w_11_13   product_ub_165  1
    w_11_13   normalized_mass_11_171  1
    w_11_13   normalized_ratio_11_172  -1.625
    w_11_13   full_original_Gini_240  -8.6464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_166  -3.9538094640352073e-02
    x_11_14   product_ub_167  -0.0921355709115762
    x_11_14   onehot_11_170  1
    x_11_14   stock_lb_180  14
    x_11_14   stock_ub_181  14
    x_11_14   parent_nonstrict_scope_182  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_166  1
    w_11_14   product_ub_167  1
    w_11_14   normalized_mass_11_171  1
    w_11_14   normalized_ratio_11_172  -1.75
    w_11_14   full_original_Gini_240  -1.0146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_168  -3.9538094640352073e-02
    x_11_15   product_ub_169  -0.0921355709115762
    x_11_15   onehot_11_170  1
    x_11_15   stock_lb_180  15
    x_11_15   stock_ub_181  15
    x_11_15   parent_nonstrict_scope_182  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_168  1
    w_11_15   product_ub_169  1
    w_11_15   normalized_mass_11_171  1
    w_11_15   normalized_ratio_11_172  -1.875
    w_11_15   full_original_Gini_240  -1.1646428571428572e+01
    rho_11    normalized_ratio_11_172  1
    rho_11    block_pair_pos_183  -1
    rho_11    block_pair_neg_184  1
    rho_11    block_pair_pos_187  1
    rho_11    block_pair_neg_188  -1
    rho_11    block_pair_pos_191  1
    rho_11    block_pair_neg_192  -1
    rho_11    block_pair_pos_203  1
    rho_11    block_pair_neg_204  -1
    rho_11    block_pair_pos_211  1
    rho_11    block_pair_neg_212  -1
    rho_11    block_pair_pos_217  1
    rho_11    block_pair_neg_218  -1
    rho_11    block_pair_pos_227  1
    rho_11    block_pair_neg_228  -1
    rho_11    normalization_239  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       6.3380304899829966e-03
    x_9_0     product_lb_173  -3.9538094640352073e-02
    x_9_0     product_ub_174  -0.0921355709115762
    x_9_0     onehot_9_177  1
    x_9_0     parent_nonstrict_scope_182  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_173  1
    w_9_0     product_ub_174  1
    w_9_0     normalized_mass_9_178  1
    w_9_0     full_original_Gini_240  -1.0853571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       -6.3380304899829966e-03
    x_9_1     product_lb_175  -3.9538094640352073e-02
    x_9_1     product_ub_176  -0.0921355709115762
    x_9_1     onehot_9_177  1
    x_9_1     stock_lb_180  1
    x_9_1     stock_ub_181  1
    x_9_1     unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_175  1
    w_9_1     product_ub_176  1
    w_9_1     normalized_mass_9_178  1
    w_9_1     normalized_ratio_9_179  -1
    w_9_1     full_original_Gini_240  -2.3964285714285714e+00
    rho_9     normalized_ratio_9_179  1
    rho_9     block_pair_pos_183  1
    rho_9     block_pair_neg_184  -1
    rho_9     block_pair_pos_185  1
    rho_9     block_pair_neg_186  -1
    rho_9     block_pair_pos_189  1
    rho_9     block_pair_neg_190  -1
    rho_9     block_pair_pos_201  1
    rho_9     block_pair_neg_202  -1
    rho_9     block_pair_pos_209  1
    rho_9     block_pair_neg_210  -1
    rho_9     block_pair_pos_215  1
    rho_9     block_pair_neg_216  -1
    rho_9     block_pair_pos_225  1
    rho_9     block_pair_neg_226  -1
    rho_9     normalization_239  1
    a_19_15   block_pair_pos_231  1
    a_19_15   block_pair_neg_232  1
    a_19_15   full_original_Gini_240  -1
    a_19_18   block_pair_pos_237  1
    a_19_18   block_pair_neg_238  1
    a_19_18   full_original_Gini_240  -1
    a_19_16   block_pair_pos_233  1
    a_19_16   block_pair_neg_234  1
    a_19_16   full_original_Gini_240  -1
    a_19_17   block_pair_pos_235  1
    a_19_17   block_pair_neg_236  1
    a_19_17   full_original_Gini_240  -1
    a_19_12   block_pair_pos_229  1
    a_19_12   block_pair_neg_230  1
    a_19_12   full_original_Gini_240  -1
    a_19_11   block_pair_pos_227  1
    a_19_11   block_pair_neg_228  1
    a_19_11   full_original_Gini_240  -1
    a_19_9    block_pair_pos_225  1
    a_19_9    block_pair_neg_226  1
    a_19_9    full_original_Gini_240  -1
    a_15_18   block_pair_pos_199  1
    a_15_18   block_pair_neg_200  1
    a_15_18   full_original_Gini_240  -1
    a_15_16   block_pair_pos_195  1
    a_15_16   block_pair_neg_196  1
    a_15_16   full_original_Gini_240  -1
    a_15_17   block_pair_pos_197  1
    a_15_17   block_pair_neg_198  1
    a_15_17   full_original_Gini_240  -1
    a_15_12   block_pair_pos_193  1
    a_15_12   block_pair_neg_194  1
    a_15_12   full_original_Gini_240  -1
    a_15_11   block_pair_pos_191  1
    a_15_11   block_pair_neg_192  1
    a_15_11   full_original_Gini_240  -1
    a_15_9    block_pair_pos_189  1
    a_15_9    block_pair_neg_190  1
    a_15_9    full_original_Gini_240  -1
    a_18_16   block_pair_pos_221  1
    a_18_16   block_pair_neg_222  1
    a_18_16   full_original_Gini_240  -1
    a_18_17   block_pair_pos_223  1
    a_18_17   block_pair_neg_224  1
    a_18_17   full_original_Gini_240  -1
    a_18_12   block_pair_pos_219  1
    a_18_12   block_pair_neg_220  1
    a_18_12   full_original_Gini_240  -1
    a_18_11   block_pair_pos_217  1
    a_18_11   block_pair_neg_218  1
    a_18_11   full_original_Gini_240  -1
    a_18_9    block_pair_pos_215  1
    a_18_9    block_pair_neg_216  1
    a_18_9    full_original_Gini_240  -1
    a_16_17   block_pair_pos_207  1
    a_16_17   block_pair_neg_208  1
    a_16_17   full_original_Gini_240  -1
    a_16_12   block_pair_pos_205  1
    a_16_12   block_pair_neg_206  1
    a_16_12   full_original_Gini_240  -1
    a_16_11   block_pair_pos_203  1
    a_16_11   block_pair_neg_204  1
    a_16_11   full_original_Gini_240  -1
    a_16_9    block_pair_pos_201  1
    a_16_9    block_pair_neg_202  1
    a_16_9    full_original_Gini_240  -1
    a_17_12   block_pair_pos_213  1
    a_17_12   block_pair_neg_214  1
    a_17_12   full_original_Gini_240  -1
    a_17_11   block_pair_pos_211  1
    a_17_11   block_pair_neg_212  1
    a_17_11   full_original_Gini_240  -1
    a_17_9    block_pair_pos_209  1
    a_17_9    block_pair_neg_210  1
    a_17_9    full_original_Gini_240  -1
    a_12_11   block_pair_pos_187  1
    a_12_11   block_pair_neg_188  1
    a_12_11   full_original_Gini_240  -1
    a_12_9    block_pair_pos_185  1
    a_12_9    block_pair_neg_186  1
    a_12_9    full_original_Gini_240  -1
    a_11_9    block_pair_pos_183  1
    a_11_9    block_pair_neg_184  1
    a_11_9    full_original_Gini_240  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_19_1  unique_nonzero_owner_241  1
    service_0_19_1  service_visit_def_886  1
    service_0_19_1  free_load_conservation_887  1
    service_0_19_2  unique_nonzero_owner_242  1
    service_0_19_2  service_visit_def_886  1
    service_0_19_2  free_load_conservation_887  2
    service_0_19_3  unique_nonzero_owner_243  1
    service_0_19_3  service_visit_def_886  1
    service_0_19_3  free_load_conservation_887  3
    service_0_19_4  unique_nonzero_owner_244  1
    service_0_19_4  service_visit_def_886  1
    service_0_19_4  free_load_conservation_887  4
    service_0_19_5  unique_nonzero_owner_245  1
    service_0_19_5  service_visit_def_886  1
    service_0_19_5  free_load_conservation_887  5
    service_1_19_1  unique_nonzero_owner_241  1
    service_1_19_1  service_visit_def_1159  1
    service_1_19_1  free_load_conservation_1160  1
    service_1_19_2  unique_nonzero_owner_242  1
    service_1_19_2  service_visit_def_1159  1
    service_1_19_2  free_load_conservation_1160  2
    service_1_19_3  unique_nonzero_owner_243  1
    service_1_19_3  service_visit_def_1159  1
    service_1_19_3  free_load_conservation_1160  3
    service_1_19_4  unique_nonzero_owner_244  1
    service_1_19_4  service_visit_def_1159  1
    service_1_19_4  free_load_conservation_1160  4
    service_1_19_5  unique_nonzero_owner_245  1
    service_1_19_5  service_visit_def_1159  1
    service_1_19_5  free_load_conservation_1160  5
    service_0_15_1  unique_nonzero_owner_246  1
    service_0_15_1  service_visit_def_892  1
    service_0_15_1  free_load_conservation_893  1
    service_1_15_1  unique_nonzero_owner_246  1
    service_1_15_1  service_visit_def_1165  1
    service_1_15_1  free_load_conservation_1166  1
    service_0_18_1  unique_nonzero_owner_247  1
    service_0_18_1  service_visit_def_898  1
    service_0_18_1  free_load_conservation_899  1
    service_0_18_2  unique_nonzero_owner_248  1
    service_0_18_2  service_visit_def_898  1
    service_0_18_2  free_load_conservation_899  2
    service_0_18_3  unique_nonzero_owner_249  1
    service_0_18_3  service_visit_def_898  1
    service_0_18_3  free_load_conservation_899  3
    service_0_18_4  unique_nonzero_owner_250  1
    service_0_18_4  service_visit_def_898  1
    service_0_18_4  free_load_conservation_899  4
    service_0_18_5  unique_nonzero_owner_251  1
    service_0_18_5  service_visit_def_898  1
    service_0_18_5  free_load_conservation_899  5
    service_0_18_6  unique_nonzero_owner_252  1
    service_0_18_6  service_visit_def_898  1
    service_0_18_6  free_load_conservation_899  6
    service_0_18_7  unique_nonzero_owner_253  1
    service_0_18_7  service_visit_def_898  1
    service_0_18_7  free_load_conservation_899  7
    service_0_18_8  unique_nonzero_owner_254  1
    service_0_18_8  service_visit_def_898  1
    service_0_18_8  free_load_conservation_899  8
    service_0_18_9  unique_nonzero_owner_255  1
    service_0_18_9  service_visit_def_898  1
    service_0_18_9  free_load_conservation_899  9
    service_0_18_10  unique_nonzero_owner_256  1
    service_0_18_10  service_visit_def_898  1
    service_0_18_10  free_load_conservation_899  10
    service_0_18_11  unique_nonzero_owner_257  1
    service_0_18_11  service_visit_def_898  1
    service_0_18_11  free_load_conservation_899  11
    service_0_18_12  unique_nonzero_owner_258  1
    service_0_18_12  service_visit_def_898  1
    service_0_18_12  free_load_conservation_899  12
    service_0_18_13  unique_nonzero_owner_259  1
    service_0_18_13  service_visit_def_898  1
    service_0_18_13  free_load_conservation_899  13
    service_0_18_14  unique_nonzero_owner_260  1
    service_0_18_14  service_visit_def_898  1
    service_0_18_14  free_load_conservation_899  14
    service_0_18_15  unique_nonzero_owner_261  1
    service_0_18_15  service_visit_def_898  1
    service_0_18_15  free_load_conservation_899  15
    service_1_18_1  unique_nonzero_owner_247  1
    service_1_18_1  service_visit_def_1171  1
    service_1_18_1  free_load_conservation_1172  1
    service_1_18_2  unique_nonzero_owner_248  1
    service_1_18_2  service_visit_def_1171  1
    service_1_18_2  free_load_conservation_1172  2
    service_1_18_3  unique_nonzero_owner_249  1
    service_1_18_3  service_visit_def_1171  1
    service_1_18_3  free_load_conservation_1172  3
    service_1_18_4  unique_nonzero_owner_250  1
    service_1_18_4  service_visit_def_1171  1
    service_1_18_4  free_load_conservation_1172  4
    service_1_18_5  unique_nonzero_owner_251  1
    service_1_18_5  service_visit_def_1171  1
    service_1_18_5  free_load_conservation_1172  5
    service_1_18_6  unique_nonzero_owner_252  1
    service_1_18_6  service_visit_def_1171  1
    service_1_18_6  free_load_conservation_1172  6
    service_1_18_7  unique_nonzero_owner_253  1
    service_1_18_7  service_visit_def_1171  1
    service_1_18_7  free_load_conservation_1172  7
    service_1_18_8  unique_nonzero_owner_254  1
    service_1_18_8  service_visit_def_1171  1
    service_1_18_8  free_load_conservation_1172  8
    service_1_18_9  unique_nonzero_owner_255  1
    service_1_18_9  service_visit_def_1171  1
    service_1_18_9  free_load_conservation_1172  9
    service_1_18_10  unique_nonzero_owner_256  1
    service_1_18_10  service_visit_def_1171  1
    service_1_18_10  free_load_conservation_1172  10
    service_1_18_11  unique_nonzero_owner_257  1
    service_1_18_11  service_visit_def_1171  1
    service_1_18_11  free_load_conservation_1172  11
    service_1_18_12  unique_nonzero_owner_258  1
    service_1_18_12  service_visit_def_1171  1
    service_1_18_12  free_load_conservation_1172  12
    service_1_18_13  unique_nonzero_owner_259  1
    service_1_18_13  service_visit_def_1171  1
    service_1_18_13  free_load_conservation_1172  13
    service_1_18_14  unique_nonzero_owner_260  1
    service_1_18_14  service_visit_def_1171  1
    service_1_18_14  free_load_conservation_1172  14
    service_1_18_15  unique_nonzero_owner_261  1
    service_1_18_15  service_visit_def_1171  1
    service_1_18_15  free_load_conservation_1172  15
    service_0_16_0  unique_nonzero_owner_262  1
    service_0_16_0  service_visit_def_904  1
    service_0_16_0  free_load_conservation_905  -1
    service_0_16_0  original_T_including_depot_unload_937  120
    service_0_16_2  unique_nonzero_owner_263  1
    service_0_16_2  service_visit_def_904  1
    service_0_16_2  free_load_conservation_905  1
    service_1_16_0  unique_nonzero_owner_262  1
    service_1_16_0  service_visit_def_1177  1
    service_1_16_0  free_load_conservation_1178  -1
    service_1_16_0  original_T_including_depot_unload_1204  120
    service_1_16_2  unique_nonzero_owner_263  1
    service_1_16_2  service_visit_def_1177  1
    service_1_16_2  free_load_conservation_1178  1
    service_0_17_0  unique_nonzero_owner_264  1
    service_0_17_0  service_visit_def_910  1
    service_0_17_0  free_load_conservation_911  -3
    service_0_17_0  original_T_including_depot_unload_937  360
    service_0_17_1  unique_nonzero_owner_265  1
    service_0_17_1  service_visit_def_910  1
    service_0_17_1  free_load_conservation_911  -2
    service_0_17_1  original_T_including_depot_unload_937  240
    service_0_17_2  unique_nonzero_owner_266  1
    service_0_17_2  service_visit_def_910  1
    service_0_17_2  free_load_conservation_911  -1
    service_0_17_2  original_T_including_depot_unload_937  120
    service_0_17_4  unique_nonzero_owner_267  1
    service_0_17_4  service_visit_def_910  1
    service_0_17_4  free_load_conservation_911  1
    service_0_17_5  unique_nonzero_owner_268  1
    service_0_17_5  service_visit_def_910  1
    service_0_17_5  free_load_conservation_911  2
    service_0_17_6  unique_nonzero_owner_269  1
    service_0_17_6  service_visit_def_910  1
    service_0_17_6  free_load_conservation_911  3
    service_0_17_7  unique_nonzero_owner_270  1
    service_0_17_7  service_visit_def_910  1
    service_0_17_7  free_load_conservation_911  4
    service_0_17_8  unique_nonzero_owner_271  1
    service_0_17_8  service_visit_def_910  1
    service_0_17_8  free_load_conservation_911  5
    service_0_17_9  unique_nonzero_owner_272  1
    service_0_17_9  service_visit_def_910  1
    service_0_17_9  free_load_conservation_911  6
    service_0_17_10  unique_nonzero_owner_273  1
    service_0_17_10  service_visit_def_910  1
    service_0_17_10  free_load_conservation_911  7
    service_0_17_11  unique_nonzero_owner_274  1
    service_0_17_11  service_visit_def_910  1
    service_0_17_11  free_load_conservation_911  8
    service_0_17_12  unique_nonzero_owner_275  1
    service_0_17_12  service_visit_def_910  1
    service_0_17_12  free_load_conservation_911  9
    service_0_17_13  unique_nonzero_owner_276  1
    service_0_17_13  service_visit_def_910  1
    service_0_17_13  free_load_conservation_911  10
    service_0_17_14  unique_nonzero_owner_277  1
    service_0_17_14  service_visit_def_910  1
    service_0_17_14  free_load_conservation_911  11
    service_0_17_15  unique_nonzero_owner_278  1
    service_0_17_15  service_visit_def_910  1
    service_0_17_15  free_load_conservation_911  12
    service_0_17_16  unique_nonzero_owner_279  1
    service_0_17_16  service_visit_def_910  1
    service_0_17_16  free_load_conservation_911  13
    service_1_17_0  unique_nonzero_owner_264  1
    service_1_17_0  service_visit_def_1183  1
    service_1_17_0  free_load_conservation_1184  -3
    service_1_17_0  original_T_including_depot_unload_1204  360
    service_1_17_1  unique_nonzero_owner_265  1
    service_1_17_1  service_visit_def_1183  1
    service_1_17_1  free_load_conservation_1184  -2
    service_1_17_1  original_T_including_depot_unload_1204  240
    service_1_17_2  unique_nonzero_owner_266  1
    service_1_17_2  service_visit_def_1183  1
    service_1_17_2  free_load_conservation_1184  -1
    service_1_17_2  original_T_including_depot_unload_1204  120
    service_1_17_4  unique_nonzero_owner_267  1
    service_1_17_4  service_visit_def_1183  1
    service_1_17_4  free_load_conservation_1184  1
    service_1_17_5  unique_nonzero_owner_268  1
    service_1_17_5  service_visit_def_1183  1
    service_1_17_5  free_load_conservation_1184  2
    service_1_17_6  unique_nonzero_owner_269  1
    service_1_17_6  service_visit_def_1183  1
    service_1_17_6  free_load_conservation_1184  3
    service_1_17_7  unique_nonzero_owner_270  1
    service_1_17_7  service_visit_def_1183  1
    service_1_17_7  free_load_conservation_1184  4
    service_1_17_8  unique_nonzero_owner_271  1
    service_1_17_8  service_visit_def_1183  1
    service_1_17_8  free_load_conservation_1184  5
    service_1_17_9  unique_nonzero_owner_272  1
    service_1_17_9  service_visit_def_1183  1
    service_1_17_9  free_load_conservation_1184  6
    service_1_17_10  unique_nonzero_owner_273  1
    service_1_17_10  service_visit_def_1183  1
    service_1_17_10  free_load_conservation_1184  7
    service_1_17_11  unique_nonzero_owner_274  1
    service_1_17_11  service_visit_def_1183  1
    service_1_17_11  free_load_conservation_1184  8
    service_1_17_12  unique_nonzero_owner_275  1
    service_1_17_12  service_visit_def_1183  1
    service_1_17_12  free_load_conservation_1184  9
    service_1_17_13  unique_nonzero_owner_276  1
    service_1_17_13  service_visit_def_1183  1
    service_1_17_13  free_load_conservation_1184  10
    service_1_17_14  unique_nonzero_owner_277  1
    service_1_17_14  service_visit_def_1183  1
    service_1_17_14  free_load_conservation_1184  11
    service_1_17_15  unique_nonzero_owner_278  1
    service_1_17_15  service_visit_def_1183  1
    service_1_17_15  free_load_conservation_1184  12
    service_1_17_16  unique_nonzero_owner_279  1
    service_1_17_16  service_visit_def_1183  1
    service_1_17_16  free_load_conservation_1184  13
    service_0_12_0  unique_nonzero_owner_280  1
    service_0_12_0  service_visit_def_916  1
    service_0_12_0  free_load_conservation_917  -11
    service_0_12_0  original_T_including_depot_unload_937  1320
    service_0_12_1  unique_nonzero_owner_281  1
    service_0_12_1  service_visit_def_916  1
    service_0_12_1  free_load_conservation_917  -10
    service_0_12_1  original_T_including_depot_unload_937  1200
    service_0_12_2  unique_nonzero_owner_282  1
    service_0_12_2  service_visit_def_916  1
    service_0_12_2  free_load_conservation_917  -9
    service_0_12_2  original_T_including_depot_unload_937  1080
    service_0_12_3  unique_nonzero_owner_283  1
    service_0_12_3  service_visit_def_916  1
    service_0_12_3  free_load_conservation_917  -8
    service_0_12_3  original_T_including_depot_unload_937  960
    service_0_12_4  unique_nonzero_owner_284  1
    service_0_12_4  service_visit_def_916  1
    service_0_12_4  free_load_conservation_917  -7
    service_0_12_4  original_T_including_depot_unload_937  840
    service_0_12_5  unique_nonzero_owner_285  1
    service_0_12_5  service_visit_def_916  1
    service_0_12_5  free_load_conservation_917  -6
    service_0_12_5  original_T_including_depot_unload_937  720
    service_0_12_6  unique_nonzero_owner_286  1
    service_0_12_6  service_visit_def_916  1
    service_0_12_6  free_load_conservation_917  -5
    service_0_12_6  original_T_including_depot_unload_937  600
    service_0_12_7  unique_nonzero_owner_287  1
    service_0_12_7  service_visit_def_916  1
    service_0_12_7  free_load_conservation_917  -4
    service_0_12_7  original_T_including_depot_unload_937  480
    service_0_12_8  unique_nonzero_owner_288  1
    service_0_12_8  service_visit_def_916  1
    service_0_12_8  free_load_conservation_917  -3
    service_0_12_8  original_T_including_depot_unload_937  360
    service_0_12_9  unique_nonzero_owner_289  1
    service_0_12_9  service_visit_def_916  1
    service_0_12_9  free_load_conservation_917  -2
    service_0_12_9  original_T_including_depot_unload_937  240
    service_0_12_10  unique_nonzero_owner_290  1
    service_0_12_10  service_visit_def_916  1
    service_0_12_10  free_load_conservation_917  -1
    service_0_12_10  original_T_including_depot_unload_937  120
    service_0_12_12  unique_nonzero_owner_291  1
    service_0_12_12  service_visit_def_916  1
    service_0_12_12  free_load_conservation_917  1
    service_0_12_13  unique_nonzero_owner_292  1
    service_0_12_13  service_visit_def_916  1
    service_0_12_13  free_load_conservation_917  2
    service_0_12_14  unique_nonzero_owner_293  1
    service_0_12_14  service_visit_def_916  1
    service_0_12_14  free_load_conservation_917  3
    service_0_12_15  unique_nonzero_owner_294  1
    service_0_12_15  service_visit_def_916  1
    service_0_12_15  free_load_conservation_917  4
    service_1_12_0  unique_nonzero_owner_280  1
    service_1_12_0  service_visit_def_1189  1
    service_1_12_0  free_load_conservation_1190  -11
    service_1_12_0  original_T_including_depot_unload_1204  1320
    service_1_12_1  unique_nonzero_owner_281  1
    service_1_12_1  service_visit_def_1189  1
    service_1_12_1  free_load_conservation_1190  -10
    service_1_12_1  original_T_including_depot_unload_1204  1200
    service_1_12_2  unique_nonzero_owner_282  1
    service_1_12_2  service_visit_def_1189  1
    service_1_12_2  free_load_conservation_1190  -9
    service_1_12_2  original_T_including_depot_unload_1204  1080
    service_1_12_3  unique_nonzero_owner_283  1
    service_1_12_3  service_visit_def_1189  1
    service_1_12_3  free_load_conservation_1190  -8
    service_1_12_3  original_T_including_depot_unload_1204  960
    service_1_12_4  unique_nonzero_owner_284  1
    service_1_12_4  service_visit_def_1189  1
    service_1_12_4  free_load_conservation_1190  -7
    service_1_12_4  original_T_including_depot_unload_1204  840
    service_1_12_5  unique_nonzero_owner_285  1
    service_1_12_5  service_visit_def_1189  1
    service_1_12_5  free_load_conservation_1190  -6
    service_1_12_5  original_T_including_depot_unload_1204  720
    service_1_12_6  unique_nonzero_owner_286  1
    service_1_12_6  service_visit_def_1189  1
    service_1_12_6  free_load_conservation_1190  -5
    service_1_12_6  original_T_including_depot_unload_1204  600
    service_1_12_7  unique_nonzero_owner_287  1
    service_1_12_7  service_visit_def_1189  1
    service_1_12_7  free_load_conservation_1190  -4
    service_1_12_7  original_T_including_depot_unload_1204  480
    service_1_12_8  unique_nonzero_owner_288  1
    service_1_12_8  service_visit_def_1189  1
    service_1_12_8  free_load_conservation_1190  -3
    service_1_12_8  original_T_including_depot_unload_1204  360
    service_1_12_9  unique_nonzero_owner_289  1
    service_1_12_9  service_visit_def_1189  1
    service_1_12_9  free_load_conservation_1190  -2
    service_1_12_9  original_T_including_depot_unload_1204  240
    service_1_12_10  unique_nonzero_owner_290  1
    service_1_12_10  service_visit_def_1189  1
    service_1_12_10  free_load_conservation_1190  -1
    service_1_12_10  original_T_including_depot_unload_1204  120
    service_1_12_12  unique_nonzero_owner_291  1
    service_1_12_12  service_visit_def_1189  1
    service_1_12_12  free_load_conservation_1190  1
    service_1_12_13  unique_nonzero_owner_292  1
    service_1_12_13  service_visit_def_1189  1
    service_1_12_13  free_load_conservation_1190  2
    service_1_12_14  unique_nonzero_owner_293  1
    service_1_12_14  service_visit_def_1189  1
    service_1_12_14  free_load_conservation_1190  3
    service_1_12_15  unique_nonzero_owner_294  1
    service_1_12_15  service_visit_def_1189  1
    service_1_12_15  free_load_conservation_1190  4
    service_0_11_0  unique_nonzero_owner_295  1
    service_0_11_0  service_visit_def_922  1
    service_0_11_0  free_load_conservation_923  -1
    service_0_11_0  original_T_including_depot_unload_937  120
    service_0_11_2  unique_nonzero_owner_296  1
    service_0_11_2  service_visit_def_922  1
    service_0_11_2  free_load_conservation_923  1
    service_0_11_3  unique_nonzero_owner_297  1
    service_0_11_3  service_visit_def_922  1
    service_0_11_3  free_load_conservation_923  2
    service_0_11_4  unique_nonzero_owner_298  1
    service_0_11_4  service_visit_def_922  1
    service_0_11_4  free_load_conservation_923  3
    service_0_11_5  unique_nonzero_owner_299  1
    service_0_11_5  service_visit_def_922  1
    service_0_11_5  free_load_conservation_923  4
    service_0_11_6  unique_nonzero_owner_300  1
    service_0_11_6  service_visit_def_922  1
    service_0_11_6  free_load_conservation_923  5
    service_0_11_7  unique_nonzero_owner_301  1
    service_0_11_7  service_visit_def_922  1
    service_0_11_7  free_load_conservation_923  6
    service_0_11_8  unique_nonzero_owner_302  1
    service_0_11_8  service_visit_def_922  1
    service_0_11_8  free_load_conservation_923  7
    service_0_11_9  unique_nonzero_owner_303  1
    service_0_11_9  service_visit_def_922  1
    service_0_11_9  free_load_conservation_923  8
    service_0_11_10  unique_nonzero_owner_304  1
    service_0_11_10  service_visit_def_922  1
    service_0_11_10  free_load_conservation_923  9
    service_0_11_11  unique_nonzero_owner_305  1
    service_0_11_11  service_visit_def_922  1
    service_0_11_11  free_load_conservation_923  10
    service_0_11_12  unique_nonzero_owner_306  1
    service_0_11_12  service_visit_def_922  1
    service_0_11_12  free_load_conservation_923  11
    service_0_11_13  unique_nonzero_owner_307  1
    service_0_11_13  service_visit_def_922  1
    service_0_11_13  free_load_conservation_923  12
    service_0_11_14  unique_nonzero_owner_308  1
    service_0_11_14  service_visit_def_922  1
    service_0_11_14  free_load_conservation_923  13
    service_0_11_15  unique_nonzero_owner_309  1
    service_0_11_15  service_visit_def_922  1
    service_0_11_15  free_load_conservation_923  14
    service_1_11_0  unique_nonzero_owner_295  1
    service_1_11_0  service_visit_def_1195  1
    service_1_11_0  free_load_conservation_1196  -1
    service_1_11_0  original_T_including_depot_unload_1204  120
    service_1_11_2  unique_nonzero_owner_296  1
    service_1_11_2  service_visit_def_1195  1
    service_1_11_2  free_load_conservation_1196  1
    service_1_11_3  unique_nonzero_owner_297  1
    service_1_11_3  service_visit_def_1195  1
    service_1_11_3  free_load_conservation_1196  2
    service_1_11_4  unique_nonzero_owner_298  1
    service_1_11_4  service_visit_def_1195  1
    service_1_11_4  free_load_conservation_1196  3
    service_1_11_5  unique_nonzero_owner_299  1
    service_1_11_5  service_visit_def_1195  1
    service_1_11_5  free_load_conservation_1196  4
    service_1_11_6  unique_nonzero_owner_300  1
    service_1_11_6  service_visit_def_1195  1
    service_1_11_6  free_load_conservation_1196  5
    service_1_11_7  unique_nonzero_owner_301  1
    service_1_11_7  service_visit_def_1195  1
    service_1_11_7  free_load_conservation_1196  6
    service_1_11_8  unique_nonzero_owner_302  1
    service_1_11_8  service_visit_def_1195  1
    service_1_11_8  free_load_conservation_1196  7
    service_1_11_9  unique_nonzero_owner_303  1
    service_1_11_9  service_visit_def_1195  1
    service_1_11_9  free_load_conservation_1196  8
    service_1_11_10  unique_nonzero_owner_304  1
    service_1_11_10  service_visit_def_1195  1
    service_1_11_10  free_load_conservation_1196  9
    service_1_11_11  unique_nonzero_owner_305  1
    service_1_11_11  service_visit_def_1195  1
    service_1_11_11  free_load_conservation_1196  10
    service_1_11_12  unique_nonzero_owner_306  1
    service_1_11_12  service_visit_def_1195  1
    service_1_11_12  free_load_conservation_1196  11
    service_1_11_13  unique_nonzero_owner_307  1
    service_1_11_13  service_visit_def_1195  1
    service_1_11_13  free_load_conservation_1196  12
    service_1_11_14  unique_nonzero_owner_308  1
    service_1_11_14  service_visit_def_1195  1
    service_1_11_14  free_load_conservation_1196  13
    service_1_11_15  unique_nonzero_owner_309  1
    service_1_11_15  service_visit_def_1195  1
    service_1_11_15  free_load_conservation_1196  14
    service_0_9_1  unique_nonzero_owner_310  1
    service_0_9_1  service_visit_def_928  1
    service_0_9_1  free_load_conservation_929  1
    service_1_9_1  unique_nonzero_owner_310  1
    service_1_9_1  service_visit_def_1201  1
    service_1_9_1  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_826  -1
    visit_0_1  in_degree_827  -1
    visit_0_1  order_active_lb_828  -1
    visit_0_1  order_active_ub_829  -16
    order_0_1  connected_order_arc_330  -1
    order_0_1  connected_order_arc_332  -1
    order_0_1  connected_order_arc_334  -1
    order_0_1  connected_order_arc_336  -1
    order_0_1  connected_order_arc_338  -1
    order_0_1  connected_order_arc_340  -1
    order_0_1  connected_order_arc_342  -1
    order_0_1  connected_order_arc_344  -1
    order_0_1  connected_order_arc_346  -1
    order_0_1  connected_order_arc_348  -1
    order_0_1  connected_order_arc_350  -1
    order_0_1  connected_order_arc_352  -1
    order_0_1  connected_order_arc_354  -1
    order_0_1  connected_order_arc_356  -1
    order_0_1  connected_order_arc_358  -1
    order_0_1  connected_order_arc_361  1
    order_0_1  connected_order_arc_392  1
    order_0_1  connected_order_arc_423  1
    order_0_1  connected_order_arc_454  1
    order_0_1  connected_order_arc_485  1
    order_0_1  connected_order_arc_516  1
    order_0_1  connected_order_arc_547  1
    order_0_1  connected_order_arc_578  1
    order_0_1  connected_order_arc_609  1
    order_0_1  connected_order_arc_640  1
    order_0_1  connected_order_arc_671  1
    order_0_1  connected_order_arc_702  1
    order_0_1  connected_order_arc_733  1
    order_0_1  connected_order_arc_764  1
    order_0_1  connected_order_arc_795  1
    order_0_1  order_active_lb_828  1
    order_0_1  order_active_ub_829  1
    order_0_1  fixed_segment_relative_order_930  -1
    visit_0_2  out_degree_833  -1
    visit_0_2  in_degree_834  -1
    visit_0_2  order_active_lb_835  -1
    visit_0_2  order_active_ub_836  -16
    order_0_2  connected_order_arc_330  1
    order_0_2  connected_order_arc_361  -1
    order_0_2  connected_order_arc_363  -1
    order_0_2  connected_order_arc_365  -1
    order_0_2  connected_order_arc_367  -1
    order_0_2  connected_order_arc_369  -1
    order_0_2  connected_order_arc_371  -1
    order_0_2  connected_order_arc_373  -1
    order_0_2  connected_order_arc_375  -1
    order_0_2  connected_order_arc_377  -1
    order_0_2  connected_order_arc_379  -1
    order_0_2  connected_order_arc_381  -1
    order_0_2  connected_order_arc_383  -1
    order_0_2  connected_order_arc_385  -1
    order_0_2  connected_order_arc_387  -1
    order_0_2  connected_order_arc_389  -1
    order_0_2  connected_order_arc_394  1
    order_0_2  connected_order_arc_425  1
    order_0_2  connected_order_arc_456  1
    order_0_2  connected_order_arc_487  1
    order_0_2  connected_order_arc_518  1
    order_0_2  connected_order_arc_549  1
    order_0_2  connected_order_arc_580  1
    order_0_2  connected_order_arc_611  1
    order_0_2  connected_order_arc_642  1
    order_0_2  connected_order_arc_673  1
    order_0_2  connected_order_arc_704  1
    order_0_2  connected_order_arc_735  1
    order_0_2  connected_order_arc_766  1
    order_0_2  connected_order_arc_797  1
    order_0_2  order_active_lb_835  1
    order_0_2  order_active_ub_836  1
    order_0_2  fixed_segment_relative_order_930  1
    order_0_2  fixed_segment_relative_order_931  -1
    visit_0_3  out_degree_840  -1
    visit_0_3  in_degree_841  -1
    visit_0_3  order_active_lb_842  -1
    visit_0_3  order_active_ub_843  -16
    order_0_3  connected_order_arc_332  1
    order_0_3  connected_order_arc_363  1
    order_0_3  connected_order_arc_392  -1
    order_0_3  connected_order_arc_394  -1
    order_0_3  connected_order_arc_396  -1
    order_0_3  connected_order_arc_398  -1
    order_0_3  connected_order_arc_400  -1
    order_0_3  connected_order_arc_402  -1
    order_0_3  connected_order_arc_404  -1
    order_0_3  connected_order_arc_406  -1
    order_0_3  connected_order_arc_408  -1
    order_0_3  connected_order_arc_410  -1
    order_0_3  connected_order_arc_412  -1
    order_0_3  connected_order_arc_414  -1
    order_0_3  connected_order_arc_416  -1
    order_0_3  connected_order_arc_418  -1
    order_0_3  connected_order_arc_420  -1
    order_0_3  connected_order_arc_427  1
    order_0_3  connected_order_arc_458  1
    order_0_3  connected_order_arc_489  1
    order_0_3  connected_order_arc_520  1
    order_0_3  connected_order_arc_551  1
    order_0_3  connected_order_arc_582  1
    order_0_3  connected_order_arc_613  1
    order_0_3  connected_order_arc_644  1
    order_0_3  connected_order_arc_675  1
    order_0_3  connected_order_arc_706  1
    order_0_3  connected_order_arc_737  1
    order_0_3  connected_order_arc_768  1
    order_0_3  connected_order_arc_799  1
    order_0_3  order_active_lb_842  1
    order_0_3  order_active_ub_843  1
    order_0_3  fixed_segment_relative_order_931  1
    order_0_3  fixed_segment_relative_order_932  -1
    visit_0_4  out_degree_847  -1
    visit_0_4  in_degree_848  -1
    visit_0_4  order_active_lb_849  -1
    visit_0_4  order_active_ub_850  -16
    order_0_4  connected_order_arc_334  1
    order_0_4  connected_order_arc_365  1
    order_0_4  connected_order_arc_396  1
    order_0_4  connected_order_arc_423  -1
    order_0_4  connected_order_arc_425  -1
    order_0_4  connected_order_arc_427  -1
    order_0_4  connected_order_arc_429  -1
    order_0_4  connected_order_arc_431  -1
    order_0_4  connected_order_arc_433  -1
    order_0_4  connected_order_arc_435  -1
    order_0_4  connected_order_arc_437  -1
    order_0_4  connected_order_arc_439  -1
    order_0_4  connected_order_arc_441  -1
    order_0_4  connected_order_arc_443  -1
    order_0_4  connected_order_arc_445  -1
    order_0_4  connected_order_arc_447  -1
    order_0_4  connected_order_arc_449  -1
    order_0_4  connected_order_arc_451  -1
    order_0_4  connected_order_arc_460  1
    order_0_4  connected_order_arc_491  1
    order_0_4  connected_order_arc_522  1
    order_0_4  connected_order_arc_553  1
    order_0_4  connected_order_arc_584  1
    order_0_4  connected_order_arc_615  1
    order_0_4  connected_order_arc_646  1
    order_0_4  connected_order_arc_677  1
    order_0_4  connected_order_arc_708  1
    order_0_4  connected_order_arc_739  1
    order_0_4  connected_order_arc_770  1
    order_0_4  connected_order_arc_801  1
    order_0_4  order_active_lb_849  1
    order_0_4  order_active_ub_850  1
    order_0_4  fixed_segment_relative_order_932  1
    order_0_4  fixed_segment_relative_order_933  -1
    visit_0_5  out_degree_854  -1
    visit_0_5  in_degree_855  -1
    visit_0_5  order_active_lb_856  -1
    visit_0_5  order_active_ub_857  -16
    order_0_5  connected_order_arc_336  1
    order_0_5  connected_order_arc_367  1
    order_0_5  connected_order_arc_398  1
    order_0_5  connected_order_arc_429  1
    order_0_5  connected_order_arc_454  -1
    order_0_5  connected_order_arc_456  -1
    order_0_5  connected_order_arc_458  -1
    order_0_5  connected_order_arc_460  -1
    order_0_5  connected_order_arc_462  -1
    order_0_5  connected_order_arc_464  -1
    order_0_5  connected_order_arc_466  -1
    order_0_5  connected_order_arc_468  -1
    order_0_5  connected_order_arc_470  -1
    order_0_5  connected_order_arc_472  -1
    order_0_5  connected_order_arc_474  -1
    order_0_5  connected_order_arc_476  -1
    order_0_5  connected_order_arc_478  -1
    order_0_5  connected_order_arc_480  -1
    order_0_5  connected_order_arc_482  -1
    order_0_5  connected_order_arc_493  1
    order_0_5  connected_order_arc_524  1
    order_0_5  connected_order_arc_555  1
    order_0_5  connected_order_arc_586  1
    order_0_5  connected_order_arc_617  1
    order_0_5  connected_order_arc_648  1
    order_0_5  connected_order_arc_679  1
    order_0_5  connected_order_arc_710  1
    order_0_5  connected_order_arc_741  1
    order_0_5  connected_order_arc_772  1
    order_0_5  connected_order_arc_803  1
    order_0_5  order_active_lb_856  1
    order_0_5  order_active_ub_857  1
    order_0_5  fixed_segment_relative_order_933  1
    order_0_5  fixed_segment_relative_order_934  -1
    visit_0_6  out_degree_861  -1
    visit_0_6  in_degree_862  -1
    visit_0_6  order_active_lb_863  -1
    visit_0_6  order_active_ub_864  -16
    order_0_6  connected_order_arc_338  1
    order_0_6  connected_order_arc_369  1
    order_0_6  connected_order_arc_400  1
    order_0_6  connected_order_arc_431  1
    order_0_6  connected_order_arc_462  1
    order_0_6  connected_order_arc_485  -1
    order_0_6  connected_order_arc_487  -1
    order_0_6  connected_order_arc_489  -1
    order_0_6  connected_order_arc_491  -1
    order_0_6  connected_order_arc_493  -1
    order_0_6  connected_order_arc_495  -1
    order_0_6  connected_order_arc_497  -1
    order_0_6  connected_order_arc_499  -1
    order_0_6  connected_order_arc_501  -1
    order_0_6  connected_order_arc_503  -1
    order_0_6  connected_order_arc_505  -1
    order_0_6  connected_order_arc_507  -1
    order_0_6  connected_order_arc_509  -1
    order_0_6  connected_order_arc_511  -1
    order_0_6  connected_order_arc_513  -1
    order_0_6  connected_order_arc_526  1
    order_0_6  connected_order_arc_557  1
    order_0_6  connected_order_arc_588  1
    order_0_6  connected_order_arc_619  1
    order_0_6  connected_order_arc_650  1
    order_0_6  connected_order_arc_681  1
    order_0_6  connected_order_arc_712  1
    order_0_6  connected_order_arc_743  1
    order_0_6  connected_order_arc_774  1
    order_0_6  connected_order_arc_805  1
    order_0_6  order_active_lb_863  1
    order_0_6  order_active_ub_864  1
    order_0_6  fixed_segment_relative_order_934  1
    order_0_6  fixed_segment_relative_order_935  -1
    visit_0_7  out_degree_868  -1
    visit_0_7  in_degree_869  -1
    visit_0_7  order_active_lb_870  -1
    visit_0_7  order_active_ub_871  -16
    order_0_7  connected_order_arc_340  1
    order_0_7  connected_order_arc_371  1
    order_0_7  connected_order_arc_402  1
    order_0_7  connected_order_arc_433  1
    order_0_7  connected_order_arc_464  1
    order_0_7  connected_order_arc_495  1
    order_0_7  connected_order_arc_516  -1
    order_0_7  connected_order_arc_518  -1
    order_0_7  connected_order_arc_520  -1
    order_0_7  connected_order_arc_522  -1
    order_0_7  connected_order_arc_524  -1
    order_0_7  connected_order_arc_526  -1
    order_0_7  connected_order_arc_528  -1
    order_0_7  connected_order_arc_530  -1
    order_0_7  connected_order_arc_532  -1
    order_0_7  connected_order_arc_534  -1
    order_0_7  connected_order_arc_536  -1
    order_0_7  connected_order_arc_538  -1
    order_0_7  connected_order_arc_540  -1
    order_0_7  connected_order_arc_542  -1
    order_0_7  connected_order_arc_544  -1
    order_0_7  connected_order_arc_559  1
    order_0_7  connected_order_arc_590  1
    order_0_7  connected_order_arc_621  1
    order_0_7  connected_order_arc_652  1
    order_0_7  connected_order_arc_683  1
    order_0_7  connected_order_arc_714  1
    order_0_7  connected_order_arc_745  1
    order_0_7  connected_order_arc_776  1
    order_0_7  connected_order_arc_807  1
    order_0_7  order_active_lb_870  1
    order_0_7  order_active_ub_871  1
    order_0_7  fixed_segment_relative_order_935  1
    order_0_7  fixed_segment_relative_order_936  -1
    visit_0_8  out_degree_875  -1
    visit_0_8  in_degree_876  -1
    visit_0_8  order_active_lb_877  -1
    visit_0_8  order_active_ub_878  -16
    order_0_8  connected_order_arc_342  1
    order_0_8  connected_order_arc_373  1
    order_0_8  connected_order_arc_404  1
    order_0_8  connected_order_arc_435  1
    order_0_8  connected_order_arc_466  1
    order_0_8  connected_order_arc_497  1
    order_0_8  connected_order_arc_528  1
    order_0_8  connected_order_arc_547  -1
    order_0_8  connected_order_arc_549  -1
    order_0_8  connected_order_arc_551  -1
    order_0_8  connected_order_arc_553  -1
    order_0_8  connected_order_arc_555  -1
    order_0_8  connected_order_arc_557  -1
    order_0_8  connected_order_arc_559  -1
    order_0_8  connected_order_arc_561  -1
    order_0_8  connected_order_arc_563  -1
    order_0_8  connected_order_arc_565  -1
    order_0_8  connected_order_arc_567  -1
    order_0_8  connected_order_arc_569  -1
    order_0_8  connected_order_arc_571  -1
    order_0_8  connected_order_arc_573  -1
    order_0_8  connected_order_arc_575  -1
    order_0_8  connected_order_arc_592  1
    order_0_8  connected_order_arc_623  1
    order_0_8  connected_order_arc_654  1
    order_0_8  connected_order_arc_685  1
    order_0_8  connected_order_arc_716  1
    order_0_8  connected_order_arc_747  1
    order_0_8  connected_order_arc_778  1
    order_0_8  connected_order_arc_809  1
    order_0_8  order_active_lb_877  1
    order_0_8  order_active_ub_878  1
    order_0_8  fixed_segment_relative_order_936  1
    visit_0_11  out_degree_882  -1
    visit_0_11  in_degree_883  -1
    visit_0_11  order_active_lb_884  -1
    visit_0_11  order_active_ub_885  -16
    visit_0_11  service_visit_def_886  -1
    order_0_11  connected_order_arc_344  1
    order_0_11  connected_order_arc_375  1
    order_0_11  connected_order_arc_406  1
    order_0_11  connected_order_arc_437  1
    order_0_11  connected_order_arc_468  1
    order_0_11  connected_order_arc_499  1
    order_0_11  connected_order_arc_530  1
    order_0_11  connected_order_arc_561  1
    order_0_11  connected_order_arc_578  -1
    order_0_11  connected_order_arc_580  -1
    order_0_11  connected_order_arc_582  -1
    order_0_11  connected_order_arc_584  -1
    order_0_11  connected_order_arc_586  -1
    order_0_11  connected_order_arc_588  -1
    order_0_11  connected_order_arc_590  -1
    order_0_11  connected_order_arc_592  -1
    order_0_11  connected_order_arc_594  -1
    order_0_11  connected_order_arc_596  -1
    order_0_11  connected_order_arc_598  -1
    order_0_11  connected_order_arc_600  -1
    order_0_11  connected_order_arc_602  -1
    order_0_11  connected_order_arc_604  -1
    order_0_11  connected_order_arc_606  -1
    order_0_11  connected_order_arc_625  1
    order_0_11  connected_order_arc_656  1
    order_0_11  connected_order_arc_687  1
    order_0_11  connected_order_arc_718  1
    order_0_11  connected_order_arc_749  1
    order_0_11  connected_order_arc_780  1
    order_0_11  connected_order_arc_811  1
    order_0_11  order_active_lb_884  1
    order_0_11  order_active_ub_885  1
    visit_0_12  out_degree_888  -1
    visit_0_12  in_degree_889  -1
    visit_0_12  order_active_lb_890  -1
    visit_0_12  order_active_ub_891  -16
    visit_0_12  service_visit_def_892  -1
    order_0_12  connected_order_arc_346  1
    order_0_12  connected_order_arc_377  1
    order_0_12  connected_order_arc_408  1
    order_0_12  connected_order_arc_439  1
    order_0_12  connected_order_arc_470  1
    order_0_12  connected_order_arc_501  1
    order_0_12  connected_order_arc_532  1
    order_0_12  connected_order_arc_563  1
    order_0_12  connected_order_arc_594  1
    order_0_12  connected_order_arc_609  -1
    order_0_12  connected_order_arc_611  -1
    order_0_12  connected_order_arc_613  -1
    order_0_12  connected_order_arc_615  -1
    order_0_12  connected_order_arc_617  -1
    order_0_12  connected_order_arc_619  -1
    order_0_12  connected_order_arc_621  -1
    order_0_12  connected_order_arc_623  -1
    order_0_12  connected_order_arc_625  -1
    order_0_12  connected_order_arc_627  -1
    order_0_12  connected_order_arc_629  -1
    order_0_12  connected_order_arc_631  -1
    order_0_12  connected_order_arc_633  -1
    order_0_12  connected_order_arc_635  -1
    order_0_12  connected_order_arc_637  -1
    order_0_12  connected_order_arc_658  1
    order_0_12  connected_order_arc_689  1
    order_0_12  connected_order_arc_720  1
    order_0_12  connected_order_arc_751  1
    order_0_12  connected_order_arc_782  1
    order_0_12  connected_order_arc_813  1
    order_0_12  order_active_lb_890  1
    order_0_12  order_active_ub_891  1
    visit_0_13  out_degree_894  -1
    visit_0_13  in_degree_895  -1
    visit_0_13  order_active_lb_896  -1
    visit_0_13  order_active_ub_897  -16
    visit_0_13  service_visit_def_898  -1
    order_0_13  connected_order_arc_348  1
    order_0_13  connected_order_arc_379  1
    order_0_13  connected_order_arc_410  1
    order_0_13  connected_order_arc_441  1
    order_0_13  connected_order_arc_472  1
    order_0_13  connected_order_arc_503  1
    order_0_13  connected_order_arc_534  1
    order_0_13  connected_order_arc_565  1
    order_0_13  connected_order_arc_596  1
    order_0_13  connected_order_arc_627  1
    order_0_13  connected_order_arc_640  -1
    order_0_13  connected_order_arc_642  -1
    order_0_13  connected_order_arc_644  -1
    order_0_13  connected_order_arc_646  -1
    order_0_13  connected_order_arc_648  -1
    order_0_13  connected_order_arc_650  -1
    order_0_13  connected_order_arc_652  -1
    order_0_13  connected_order_arc_654  -1
    order_0_13  connected_order_arc_656  -1
    order_0_13  connected_order_arc_658  -1
    order_0_13  connected_order_arc_660  -1
    order_0_13  connected_order_arc_662  -1
    order_0_13  connected_order_arc_664  -1
    order_0_13  connected_order_arc_666  -1
    order_0_13  connected_order_arc_668  -1
    order_0_13  connected_order_arc_691  1
    order_0_13  connected_order_arc_722  1
    order_0_13  connected_order_arc_753  1
    order_0_13  connected_order_arc_784  1
    order_0_13  connected_order_arc_815  1
    order_0_13  order_active_lb_896  1
    order_0_13  order_active_ub_897  1
    visit_0_14  out_degree_900  -1
    visit_0_14  in_degree_901  -1
    visit_0_14  order_active_lb_902  -1
    visit_0_14  order_active_ub_903  -16
    visit_0_14  service_visit_def_904  -1
    order_0_14  connected_order_arc_350  1
    order_0_14  connected_order_arc_381  1
    order_0_14  connected_order_arc_412  1
    order_0_14  connected_order_arc_443  1
    order_0_14  connected_order_arc_474  1
    order_0_14  connected_order_arc_505  1
    order_0_14  connected_order_arc_536  1
    order_0_14  connected_order_arc_567  1
    order_0_14  connected_order_arc_598  1
    order_0_14  connected_order_arc_629  1
    order_0_14  connected_order_arc_660  1
    order_0_14  connected_order_arc_671  -1
    order_0_14  connected_order_arc_673  -1
    order_0_14  connected_order_arc_675  -1
    order_0_14  connected_order_arc_677  -1
    order_0_14  connected_order_arc_679  -1
    order_0_14  connected_order_arc_681  -1
    order_0_14  connected_order_arc_683  -1
    order_0_14  connected_order_arc_685  -1
    order_0_14  connected_order_arc_687  -1
    order_0_14  connected_order_arc_689  -1
    order_0_14  connected_order_arc_691  -1
    order_0_14  connected_order_arc_693  -1
    order_0_14  connected_order_arc_695  -1
    order_0_14  connected_order_arc_697  -1
    order_0_14  connected_order_arc_699  -1
    order_0_14  connected_order_arc_724  1
    order_0_14  connected_order_arc_755  1
    order_0_14  connected_order_arc_786  1
    order_0_14  connected_order_arc_817  1
    order_0_14  order_active_lb_902  1
    order_0_14  order_active_ub_903  1
    visit_0_15  out_degree_906  -1
    visit_0_15  in_degree_907  -1
    visit_0_15  order_active_lb_908  -1
    visit_0_15  order_active_ub_909  -16
    visit_0_15  service_visit_def_910  -1
    order_0_15  connected_order_arc_352  1
    order_0_15  connected_order_arc_383  1
    order_0_15  connected_order_arc_414  1
    order_0_15  connected_order_arc_445  1
    order_0_15  connected_order_arc_476  1
    order_0_15  connected_order_arc_507  1
    order_0_15  connected_order_arc_538  1
    order_0_15  connected_order_arc_569  1
    order_0_15  connected_order_arc_600  1
    order_0_15  connected_order_arc_631  1
    order_0_15  connected_order_arc_662  1
    order_0_15  connected_order_arc_693  1
    order_0_15  connected_order_arc_702  -1
    order_0_15  connected_order_arc_704  -1
    order_0_15  connected_order_arc_706  -1
    order_0_15  connected_order_arc_708  -1
    order_0_15  connected_order_arc_710  -1
    order_0_15  connected_order_arc_712  -1
    order_0_15  connected_order_arc_714  -1
    order_0_15  connected_order_arc_716  -1
    order_0_15  connected_order_arc_718  -1
    order_0_15  connected_order_arc_720  -1
    order_0_15  connected_order_arc_722  -1
    order_0_15  connected_order_arc_724  -1
    order_0_15  connected_order_arc_726  -1
    order_0_15  connected_order_arc_728  -1
    order_0_15  connected_order_arc_730  -1
    order_0_15  connected_order_arc_757  1
    order_0_15  connected_order_arc_788  1
    order_0_15  connected_order_arc_819  1
    order_0_15  order_active_lb_908  1
    order_0_15  order_active_ub_909  1
    visit_0_16  out_degree_912  -1
    visit_0_16  in_degree_913  -1
    visit_0_16  order_active_lb_914  -1
    visit_0_16  order_active_ub_915  -16
    visit_0_16  service_visit_def_916  -1
    order_0_16  connected_order_arc_354  1
    order_0_16  connected_order_arc_385  1
    order_0_16  connected_order_arc_416  1
    order_0_16  connected_order_arc_447  1
    order_0_16  connected_order_arc_478  1
    order_0_16  connected_order_arc_509  1
    order_0_16  connected_order_arc_540  1
    order_0_16  connected_order_arc_571  1
    order_0_16  connected_order_arc_602  1
    order_0_16  connected_order_arc_633  1
    order_0_16  connected_order_arc_664  1
    order_0_16  connected_order_arc_695  1
    order_0_16  connected_order_arc_726  1
    order_0_16  connected_order_arc_733  -1
    order_0_16  connected_order_arc_735  -1
    order_0_16  connected_order_arc_737  -1
    order_0_16  connected_order_arc_739  -1
    order_0_16  connected_order_arc_741  -1
    order_0_16  connected_order_arc_743  -1
    order_0_16  connected_order_arc_745  -1
    order_0_16  connected_order_arc_747  -1
    order_0_16  connected_order_arc_749  -1
    order_0_16  connected_order_arc_751  -1
    order_0_16  connected_order_arc_753  -1
    order_0_16  connected_order_arc_755  -1
    order_0_16  connected_order_arc_757  -1
    order_0_16  connected_order_arc_759  -1
    order_0_16  connected_order_arc_761  -1
    order_0_16  connected_order_arc_790  1
    order_0_16  connected_order_arc_821  1
    order_0_16  order_active_lb_914  1
    order_0_16  order_active_ub_915  1
    visit_0_17  out_degree_918  -1
    visit_0_17  in_degree_919  -1
    visit_0_17  order_active_lb_920  -1
    visit_0_17  order_active_ub_921  -16
    visit_0_17  service_visit_def_922  -1
    order_0_17  connected_order_arc_356  1
    order_0_17  connected_order_arc_387  1
    order_0_17  connected_order_arc_418  1
    order_0_17  connected_order_arc_449  1
    order_0_17  connected_order_arc_480  1
    order_0_17  connected_order_arc_511  1
    order_0_17  connected_order_arc_542  1
    order_0_17  connected_order_arc_573  1
    order_0_17  connected_order_arc_604  1
    order_0_17  connected_order_arc_635  1
    order_0_17  connected_order_arc_666  1
    order_0_17  connected_order_arc_697  1
    order_0_17  connected_order_arc_728  1
    order_0_17  connected_order_arc_759  1
    order_0_17  connected_order_arc_764  -1
    order_0_17  connected_order_arc_766  -1
    order_0_17  connected_order_arc_768  -1
    order_0_17  connected_order_arc_770  -1
    order_0_17  connected_order_arc_772  -1
    order_0_17  connected_order_arc_774  -1
    order_0_17  connected_order_arc_776  -1
    order_0_17  connected_order_arc_778  -1
    order_0_17  connected_order_arc_780  -1
    order_0_17  connected_order_arc_782  -1
    order_0_17  connected_order_arc_784  -1
    order_0_17  connected_order_arc_786  -1
    order_0_17  connected_order_arc_788  -1
    order_0_17  connected_order_arc_790  -1
    order_0_17  connected_order_arc_792  -1
    order_0_17  connected_order_arc_823  1
    order_0_17  order_active_lb_920  1
    order_0_17  order_active_ub_921  1
    visit_0_18  out_degree_924  -1
    visit_0_18  in_degree_925  -1
    visit_0_18  order_active_lb_926  -1
    visit_0_18  order_active_ub_927  -16
    visit_0_18  service_visit_def_928  -1
    order_0_18  connected_order_arc_358  1
    order_0_18  connected_order_arc_389  1
    order_0_18  connected_order_arc_420  1
    order_0_18  connected_order_arc_451  1
    order_0_18  connected_order_arc_482  1
    order_0_18  connected_order_arc_513  1
    order_0_18  connected_order_arc_544  1
    order_0_18  connected_order_arc_575  1
    order_0_18  connected_order_arc_606  1
    order_0_18  connected_order_arc_637  1
    order_0_18  connected_order_arc_668  1
    order_0_18  connected_order_arc_699  1
    order_0_18  connected_order_arc_730  1
    order_0_18  connected_order_arc_761  1
    order_0_18  connected_order_arc_792  1
    order_0_18  connected_order_arc_795  -1
    order_0_18  connected_order_arc_797  -1
    order_0_18  connected_order_arc_799  -1
    order_0_18  connected_order_arc_801  -1
    order_0_18  connected_order_arc_803  -1
    order_0_18  connected_order_arc_805  -1
    order_0_18  connected_order_arc_807  -1
    order_0_18  connected_order_arc_809  -1
    order_0_18  connected_order_arc_811  -1
    order_0_18  connected_order_arc_813  -1
    order_0_18  connected_order_arc_815  -1
    order_0_18  connected_order_arc_817  -1
    order_0_18  connected_order_arc_819  -1
    order_0_18  connected_order_arc_821  -1
    order_0_18  connected_order_arc_823  -1
    order_0_18  order_active_lb_926  1
    order_0_18  order_active_ub_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_311  -30
    arc_0_0_0  depot_departure_or_bypass_824  1
    arc_0_0_0  depot_return_or_bypass_825  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_311  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_312  -30
    arc_0_0_1  depot_departure_or_bypass_824  1
    arc_0_0_1  in_degree_827  1
    arc_0_0_1  original_T_including_depot_unload_937  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_312  1
    load_0_0_1  segment_load_conservation_830  -1
    load_0_0_1  segment_prefix_lb_831  1
    load_0_0_1  segment_prefix_ub_832  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_313  -30
    arc_0_0_2  depot_departure_or_bypass_824  1
    arc_0_0_2  in_degree_834  1
    arc_0_0_2  original_T_including_depot_unload_937  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_313  1
    load_0_0_2  segment_load_conservation_837  -1
    load_0_0_2  segment_prefix_lb_838  1
    load_0_0_2  segment_prefix_ub_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_314  -30
    arc_0_0_3  depot_departure_or_bypass_824  1
    arc_0_0_3  in_degree_841  1
    arc_0_0_3  original_T_including_depot_unload_937  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_314  1
    load_0_0_3  segment_load_conservation_844  -1
    load_0_0_3  segment_prefix_lb_845  1
    load_0_0_3  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_315  -30
    arc_0_0_4  depot_departure_or_bypass_824  1
    arc_0_0_4  in_degree_848  1
    arc_0_0_4  original_T_including_depot_unload_937  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_315  1
    load_0_0_4  segment_load_conservation_851  -1
    load_0_0_4  segment_prefix_lb_852  1
    load_0_0_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_316  -30
    arc_0_0_5  depot_departure_or_bypass_824  1
    arc_0_0_5  in_degree_855  1
    arc_0_0_5  original_T_including_depot_unload_937  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_316  1
    load_0_0_5  segment_load_conservation_858  -1
    load_0_0_5  segment_prefix_lb_859  1
    load_0_0_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_317  -30
    arc_0_0_6  depot_departure_or_bypass_824  1
    arc_0_0_6  in_degree_862  1
    arc_0_0_6  original_T_including_depot_unload_937  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_317  1
    load_0_0_6  segment_load_conservation_865  -1
    load_0_0_6  segment_prefix_lb_866  1
    load_0_0_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_7  arc_capacity_318  -30
    arc_0_0_7  depot_departure_or_bypass_824  1
    arc_0_0_7  in_degree_869  1
    arc_0_0_7  original_T_including_depot_unload_937  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_7  arc_capacity_318  1
    load_0_0_7  segment_load_conservation_872  -1
    load_0_0_7  segment_prefix_lb_873  1
    load_0_0_7  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_319  -30
    arc_0_0_8  depot_departure_or_bypass_824  1
    arc_0_0_8  in_degree_876  1
    arc_0_0_8  original_T_including_depot_unload_937  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_319  1
    load_0_0_8  segment_load_conservation_879  -1
    load_0_0_8  segment_prefix_lb_880  1
    load_0_0_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_320  -30
    arc_0_0_11  depot_departure_or_bypass_824  1
    arc_0_0_11  in_degree_883  1
    arc_0_0_11  original_T_including_depot_unload_937  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_320  1
    load_0_0_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_321  -30
    arc_0_0_12  depot_departure_or_bypass_824  1
    arc_0_0_12  in_degree_889  1
    arc_0_0_12  original_T_including_depot_unload_937  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_321  1
    load_0_0_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_322  -30
    arc_0_0_13  depot_departure_or_bypass_824  1
    arc_0_0_13  in_degree_895  1
    arc_0_0_13  original_T_including_depot_unload_937  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_322  1
    load_0_0_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_323  -30
    arc_0_0_14  depot_departure_or_bypass_824  1
    arc_0_0_14  in_degree_901  1
    arc_0_0_14  original_T_including_depot_unload_937  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_323  1
    load_0_0_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_324  -30
    arc_0_0_15  depot_departure_or_bypass_824  1
    arc_0_0_15  in_degree_907  1
    arc_0_0_15  original_T_including_depot_unload_937  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_324  1
    load_0_0_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_325  -30
    arc_0_0_16  depot_departure_or_bypass_824  1
    arc_0_0_16  in_degree_913  1
    arc_0_0_16  original_T_including_depot_unload_937  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_325  1
    load_0_0_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_326  -30
    arc_0_0_17  depot_departure_or_bypass_824  1
    arc_0_0_17  in_degree_919  1
    arc_0_0_17  original_T_including_depot_unload_937  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_326  1
    load_0_0_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_327  -30
    arc_0_0_18  depot_departure_or_bypass_824  1
    arc_0_0_18  in_degree_925  1
    arc_0_0_18  original_T_including_depot_unload_937  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_327  1
    load_0_0_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_328  -30
    arc_0_1_0  depot_return_or_bypass_825  1
    arc_0_1_0  out_degree_826  1
    arc_0_1_0  original_T_including_depot_unload_937  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_328  1
    load_0_1_0  segment_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_329  -30
    arc_0_1_2  connected_order_arc_330  -17
    arc_0_1_2  out_degree_826  1
    arc_0_1_2  in_degree_834  1
    arc_0_1_2  original_T_including_depot_unload_937  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_329  1
    load_0_1_2  segment_load_conservation_830  1
    load_0_1_2  segment_load_conservation_837  -1
    load_0_1_2  segment_prefix_lb_838  1
    load_0_1_2  segment_prefix_ub_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_331  -30
    arc_0_1_3  connected_order_arc_332  -17
    arc_0_1_3  out_degree_826  1
    arc_0_1_3  in_degree_841  1
    arc_0_1_3  original_T_including_depot_unload_937  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_331  1
    load_0_1_3  segment_load_conservation_830  1
    load_0_1_3  segment_load_conservation_844  -1
    load_0_1_3  segment_prefix_lb_845  1
    load_0_1_3  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_333  -30
    arc_0_1_4  connected_order_arc_334  -17
    arc_0_1_4  out_degree_826  1
    arc_0_1_4  in_degree_848  1
    arc_0_1_4  original_T_including_depot_unload_937  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_333  1
    load_0_1_4  segment_load_conservation_830  1
    load_0_1_4  segment_load_conservation_851  -1
    load_0_1_4  segment_prefix_lb_852  1
    load_0_1_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_335  -30
    arc_0_1_5  connected_order_arc_336  -17
    arc_0_1_5  out_degree_826  1
    arc_0_1_5  in_degree_855  1
    arc_0_1_5  original_T_including_depot_unload_937  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_335  1
    load_0_1_5  segment_load_conservation_830  1
    load_0_1_5  segment_load_conservation_858  -1
    load_0_1_5  segment_prefix_lb_859  1
    load_0_1_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_337  -30
    arc_0_1_6  connected_order_arc_338  -17
    arc_0_1_6  out_degree_826  1
    arc_0_1_6  in_degree_862  1
    arc_0_1_6  original_T_including_depot_unload_937  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_337  1
    load_0_1_6  segment_load_conservation_830  1
    load_0_1_6  segment_load_conservation_865  -1
    load_0_1_6  segment_prefix_lb_866  1
    load_0_1_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_7  arc_capacity_339  -30
    arc_0_1_7  connected_order_arc_340  -17
    arc_0_1_7  out_degree_826  1
    arc_0_1_7  in_degree_869  1
    arc_0_1_7  original_T_including_depot_unload_937  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_1_7  arc_capacity_339  1
    load_0_1_7  segment_load_conservation_830  1
    load_0_1_7  segment_load_conservation_872  -1
    load_0_1_7  segment_prefix_lb_873  1
    load_0_1_7  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_341  -30
    arc_0_1_8  connected_order_arc_342  -17
    arc_0_1_8  out_degree_826  1
    arc_0_1_8  in_degree_876  1
    arc_0_1_8  original_T_including_depot_unload_937  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_341  1
    load_0_1_8  segment_load_conservation_830  1
    load_0_1_8  segment_load_conservation_879  -1
    load_0_1_8  segment_prefix_lb_880  1
    load_0_1_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_343  -30
    arc_0_1_11  connected_order_arc_344  -17
    arc_0_1_11  out_degree_826  1
    arc_0_1_11  in_degree_883  1
    arc_0_1_11  original_T_including_depot_unload_937  2.9475580354409412e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_343  1
    load_0_1_11  segment_load_conservation_830  1
    load_0_1_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_345  -30
    arc_0_1_12  connected_order_arc_346  -17
    arc_0_1_12  out_degree_826  1
    arc_0_1_12  in_degree_889  1
    arc_0_1_12  original_T_including_depot_unload_937  2.7384186870432241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_345  1
    load_0_1_12  segment_load_conservation_830  1
    load_0_1_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_347  -30
    arc_0_1_13  connected_order_arc_348  -17
    arc_0_1_13  out_degree_826  1
    arc_0_1_13  in_degree_895  1
    arc_0_1_13  original_T_including_depot_unload_937  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_347  1
    load_0_1_13  segment_load_conservation_830  1
    load_0_1_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_349  -30
    arc_0_1_14  connected_order_arc_350  -17
    arc_0_1_14  out_degree_826  1
    arc_0_1_14  in_degree_901  1
    arc_0_1_14  original_T_including_depot_unload_937  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_349  1
    load_0_1_14  segment_load_conservation_830  1
    load_0_1_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_351  -30
    arc_0_1_15  connected_order_arc_352  -17
    arc_0_1_15  out_degree_826  1
    arc_0_1_15  in_degree_907  1
    arc_0_1_15  original_T_including_depot_unload_937  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_351  1
    load_0_1_15  segment_load_conservation_830  1
    load_0_1_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_353  -30
    arc_0_1_16  connected_order_arc_354  -17
    arc_0_1_16  out_degree_826  1
    arc_0_1_16  in_degree_913  1
    arc_0_1_16  original_T_including_depot_unload_937  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_353  1
    load_0_1_16  segment_load_conservation_830  1
    load_0_1_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_355  -30
    arc_0_1_17  connected_order_arc_356  -17
    arc_0_1_17  out_degree_826  1
    arc_0_1_17  in_degree_919  1
    arc_0_1_17  original_T_including_depot_unload_937  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_355  1
    load_0_1_17  segment_load_conservation_830  1
    load_0_1_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_357  -30
    arc_0_1_18  connected_order_arc_358  -17
    arc_0_1_18  out_degree_826  1
    arc_0_1_18  in_degree_925  1
    arc_0_1_18  original_T_including_depot_unload_937  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_357  1
    load_0_1_18  segment_load_conservation_830  1
    load_0_1_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_359  -30
    arc_0_2_0  depot_return_or_bypass_825  1
    arc_0_2_0  out_degree_833  1
    arc_0_2_0  original_T_including_depot_unload_937  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_359  1
    load_0_2_0  segment_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_360  -30
    arc_0_2_1  connected_order_arc_361  -17
    arc_0_2_1  in_degree_827  1
    arc_0_2_1  out_degree_833  1
    arc_0_2_1  original_T_including_depot_unload_937  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_360  1
    load_0_2_1  segment_load_conservation_830  -1
    load_0_2_1  segment_prefix_lb_831  1
    load_0_2_1  segment_prefix_ub_832  1
    load_0_2_1  segment_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_362  -30
    arc_0_2_3  connected_order_arc_363  -17
    arc_0_2_3  out_degree_833  1
    arc_0_2_3  in_degree_841  1
    arc_0_2_3  original_T_including_depot_unload_937  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_362  1
    load_0_2_3  segment_load_conservation_837  1
    load_0_2_3  segment_load_conservation_844  -1
    load_0_2_3  segment_prefix_lb_845  1
    load_0_2_3  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_364  -30
    arc_0_2_4  connected_order_arc_365  -17
    arc_0_2_4  out_degree_833  1
    arc_0_2_4  in_degree_848  1
    arc_0_2_4  original_T_including_depot_unload_937  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_364  1
    load_0_2_4  segment_load_conservation_837  1
    load_0_2_4  segment_load_conservation_851  -1
    load_0_2_4  segment_prefix_lb_852  1
    load_0_2_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_366  -30
    arc_0_2_5  connected_order_arc_367  -17
    arc_0_2_5  out_degree_833  1
    arc_0_2_5  in_degree_855  1
    arc_0_2_5  original_T_including_depot_unload_937  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_366  1
    load_0_2_5  segment_load_conservation_837  1
    load_0_2_5  segment_load_conservation_858  -1
    load_0_2_5  segment_prefix_lb_859  1
    load_0_2_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_368  -30
    arc_0_2_6  connected_order_arc_369  -17
    arc_0_2_6  out_degree_833  1
    arc_0_2_6  in_degree_862  1
    arc_0_2_6  original_T_including_depot_unload_937  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_368  1
    load_0_2_6  segment_load_conservation_837  1
    load_0_2_6  segment_load_conservation_865  -1
    load_0_2_6  segment_prefix_lb_866  1
    load_0_2_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_7  arc_capacity_370  -30
    arc_0_2_7  connected_order_arc_371  -17
    arc_0_2_7  out_degree_833  1
    arc_0_2_7  in_degree_869  1
    arc_0_2_7  original_T_including_depot_unload_937  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_7  arc_capacity_370  1
    load_0_2_7  segment_load_conservation_837  1
    load_0_2_7  segment_load_conservation_872  -1
    load_0_2_7  segment_prefix_lb_873  1
    load_0_2_7  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_372  -30
    arc_0_2_8  connected_order_arc_373  -17
    arc_0_2_8  out_degree_833  1
    arc_0_2_8  in_degree_876  1
    arc_0_2_8  original_T_including_depot_unload_937  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_372  1
    load_0_2_8  segment_load_conservation_837  1
    load_0_2_8  segment_load_conservation_879  -1
    load_0_2_8  segment_prefix_lb_880  1
    load_0_2_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_374  -30
    arc_0_2_11  connected_order_arc_375  -17
    arc_0_2_11  out_degree_833  1
    arc_0_2_11  in_degree_883  1
    arc_0_2_11  original_T_including_depot_unload_937  3.1940365421146048e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_374  1
    load_0_2_11  segment_load_conservation_837  1
    load_0_2_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_376  -30
    arc_0_2_12  connected_order_arc_377  -17
    arc_0_2_12  out_degree_833  1
    arc_0_2_12  in_degree_889  1
    arc_0_2_12  original_T_including_depot_unload_937  3.0014740451067628e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_376  1
    load_0_2_12  segment_load_conservation_837  1
    load_0_2_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_378  -30
    arc_0_2_13  connected_order_arc_379  -17
    arc_0_2_13  out_degree_833  1
    arc_0_2_13  in_degree_895  1
    arc_0_2_13  original_T_including_depot_unload_937  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_378  1
    load_0_2_13  segment_load_conservation_837  1
    load_0_2_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_380  -30
    arc_0_2_14  connected_order_arc_381  -17
    arc_0_2_14  out_degree_833  1
    arc_0_2_14  in_degree_901  1
    arc_0_2_14  original_T_including_depot_unload_937  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_380  1
    load_0_2_14  segment_load_conservation_837  1
    load_0_2_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_382  -30
    arc_0_2_15  connected_order_arc_383  -17
    arc_0_2_15  out_degree_833  1
    arc_0_2_15  in_degree_907  1
    arc_0_2_15  original_T_including_depot_unload_937  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_382  1
    load_0_2_15  segment_load_conservation_837  1
    load_0_2_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_384  -30
    arc_0_2_16  connected_order_arc_385  -17
    arc_0_2_16  out_degree_833  1
    arc_0_2_16  in_degree_913  1
    arc_0_2_16  original_T_including_depot_unload_937  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_384  1
    load_0_2_16  segment_load_conservation_837  1
    load_0_2_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_386  -30
    arc_0_2_17  connected_order_arc_387  -17
    arc_0_2_17  out_degree_833  1
    arc_0_2_17  in_degree_919  1
    arc_0_2_17  original_T_including_depot_unload_937  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_386  1
    load_0_2_17  segment_load_conservation_837  1
    load_0_2_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_388  -30
    arc_0_2_18  connected_order_arc_389  -17
    arc_0_2_18  out_degree_833  1
    arc_0_2_18  in_degree_925  1
    arc_0_2_18  original_T_including_depot_unload_937  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_388  1
    load_0_2_18  segment_load_conservation_837  1
    load_0_2_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_390  -30
    arc_0_3_0  depot_return_or_bypass_825  1
    arc_0_3_0  out_degree_840  1
    arc_0_3_0  original_T_including_depot_unload_937  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_390  1
    load_0_3_0  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_391  -30
    arc_0_3_1  connected_order_arc_392  -17
    arc_0_3_1  in_degree_827  1
    arc_0_3_1  out_degree_840  1
    arc_0_3_1  original_T_including_depot_unload_937  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_391  1
    load_0_3_1  segment_load_conservation_830  -1
    load_0_3_1  segment_prefix_lb_831  1
    load_0_3_1  segment_prefix_ub_832  1
    load_0_3_1  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_393  -30
    arc_0_3_2  connected_order_arc_394  -17
    arc_0_3_2  in_degree_834  1
    arc_0_3_2  out_degree_840  1
    arc_0_3_2  original_T_including_depot_unload_937  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_393  1
    load_0_3_2  segment_load_conservation_837  -1
    load_0_3_2  segment_prefix_lb_838  1
    load_0_3_2  segment_prefix_ub_839  1
    load_0_3_2  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_395  -30
    arc_0_3_4  connected_order_arc_396  -17
    arc_0_3_4  out_degree_840  1
    arc_0_3_4  in_degree_848  1
    arc_0_3_4  original_T_including_depot_unload_937  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_395  1
    load_0_3_4  segment_load_conservation_844  1
    load_0_3_4  segment_load_conservation_851  -1
    load_0_3_4  segment_prefix_lb_852  1
    load_0_3_4  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_397  -30
    arc_0_3_5  connected_order_arc_398  -17
    arc_0_3_5  out_degree_840  1
    arc_0_3_5  in_degree_855  1
    arc_0_3_5  original_T_including_depot_unload_937  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_397  1
    load_0_3_5  segment_load_conservation_844  1
    load_0_3_5  segment_load_conservation_858  -1
    load_0_3_5  segment_prefix_lb_859  1
    load_0_3_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_399  -30
    arc_0_3_6  connected_order_arc_400  -17
    arc_0_3_6  out_degree_840  1
    arc_0_3_6  in_degree_862  1
    arc_0_3_6  original_T_including_depot_unload_937  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_399  1
    load_0_3_6  segment_load_conservation_844  1
    load_0_3_6  segment_load_conservation_865  -1
    load_0_3_6  segment_prefix_lb_866  1
    load_0_3_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_7  arc_capacity_401  -30
    arc_0_3_7  connected_order_arc_402  -17
    arc_0_3_7  out_degree_840  1
    arc_0_3_7  in_degree_869  1
    arc_0_3_7  original_T_including_depot_unload_937  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_7  arc_capacity_401  1
    load_0_3_7  segment_load_conservation_844  1
    load_0_3_7  segment_load_conservation_872  -1
    load_0_3_7  segment_prefix_lb_873  1
    load_0_3_7  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_403  -30
    arc_0_3_8  connected_order_arc_404  -17
    arc_0_3_8  out_degree_840  1
    arc_0_3_8  in_degree_876  1
    arc_0_3_8  original_T_including_depot_unload_937  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_403  1
    load_0_3_8  segment_load_conservation_844  1
    load_0_3_8  segment_load_conservation_879  -1
    load_0_3_8  segment_prefix_lb_880  1
    load_0_3_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_405  -30
    arc_0_3_11  connected_order_arc_406  -17
    arc_0_3_11  out_degree_840  1
    arc_0_3_11  in_degree_883  1
    arc_0_3_11  original_T_including_depot_unload_937  3.4153410343469327e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_405  1
    load_0_3_11  segment_load_conservation_844  1
    load_0_3_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_407  -30
    arc_0_3_12  connected_order_arc_408  -17
    arc_0_3_12  out_degree_840  1
    arc_0_3_12  in_degree_889  1
    arc_0_3_12  original_T_including_depot_unload_937  3.2308847977395667e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_407  1
    load_0_3_12  segment_load_conservation_844  1
    load_0_3_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_409  -30
    arc_0_3_13  connected_order_arc_410  -17
    arc_0_3_13  out_degree_840  1
    arc_0_3_13  in_degree_895  1
    arc_0_3_13  original_T_including_depot_unload_937  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_409  1
    load_0_3_13  segment_load_conservation_844  1
    load_0_3_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_411  -30
    arc_0_3_14  connected_order_arc_412  -17
    arc_0_3_14  out_degree_840  1
    arc_0_3_14  in_degree_901  1
    arc_0_3_14  original_T_including_depot_unload_937  3.2360258354135326e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_411  1
    load_0_3_14  segment_load_conservation_844  1
    load_0_3_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_413  -30
    arc_0_3_15  connected_order_arc_414  -17
    arc_0_3_15  out_degree_840  1
    arc_0_3_15  in_degree_907  1
    arc_0_3_15  original_T_including_depot_unload_937  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_413  1
    load_0_3_15  segment_load_conservation_844  1
    load_0_3_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_415  -30
    arc_0_3_16  connected_order_arc_416  -17
    arc_0_3_16  out_degree_840  1
    arc_0_3_16  in_degree_913  1
    arc_0_3_16  original_T_including_depot_unload_937  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_415  1
    load_0_3_16  segment_load_conservation_844  1
    load_0_3_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_417  -30
    arc_0_3_17  connected_order_arc_418  -17
    arc_0_3_17  out_degree_840  1
    arc_0_3_17  in_degree_919  1
    arc_0_3_17  original_T_including_depot_unload_937  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_417  1
    load_0_3_17  segment_load_conservation_844  1
    load_0_3_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_419  -30
    arc_0_3_18  connected_order_arc_420  -17
    arc_0_3_18  out_degree_840  1
    arc_0_3_18  in_degree_925  1
    arc_0_3_18  original_T_including_depot_unload_937  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_419  1
    load_0_3_18  segment_load_conservation_844  1
    load_0_3_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_421  -30
    arc_0_4_0  depot_return_or_bypass_825  1
    arc_0_4_0  out_degree_847  1
    arc_0_4_0  original_T_including_depot_unload_937  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_421  1
    load_0_4_0  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_422  -30
    arc_0_4_1  connected_order_arc_423  -17
    arc_0_4_1  in_degree_827  1
    arc_0_4_1  out_degree_847  1
    arc_0_4_1  original_T_including_depot_unload_937  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_422  1
    load_0_4_1  segment_load_conservation_830  -1
    load_0_4_1  segment_prefix_lb_831  1
    load_0_4_1  segment_prefix_ub_832  1
    load_0_4_1  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_424  -30
    arc_0_4_2  connected_order_arc_425  -17
    arc_0_4_2  in_degree_834  1
    arc_0_4_2  out_degree_847  1
    arc_0_4_2  original_T_including_depot_unload_937  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_424  1
    load_0_4_2  segment_load_conservation_837  -1
    load_0_4_2  segment_prefix_lb_838  1
    load_0_4_2  segment_prefix_ub_839  1
    load_0_4_2  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_426  -30
    arc_0_4_3  connected_order_arc_427  -17
    arc_0_4_3  in_degree_841  1
    arc_0_4_3  out_degree_847  1
    arc_0_4_3  original_T_including_depot_unload_937  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_426  1
    load_0_4_3  segment_load_conservation_844  -1
    load_0_4_3  segment_prefix_lb_845  1
    load_0_4_3  segment_prefix_ub_846  1
    load_0_4_3  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_428  -30
    arc_0_4_5  connected_order_arc_429  -17
    arc_0_4_5  out_degree_847  1
    arc_0_4_5  in_degree_855  1
    arc_0_4_5  original_T_including_depot_unload_937  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_428  1
    load_0_4_5  segment_load_conservation_851  1
    load_0_4_5  segment_load_conservation_858  -1
    load_0_4_5  segment_prefix_lb_859  1
    load_0_4_5  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_430  -30
    arc_0_4_6  connected_order_arc_431  -17
    arc_0_4_6  out_degree_847  1
    arc_0_4_6  in_degree_862  1
    arc_0_4_6  original_T_including_depot_unload_937  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_430  1
    load_0_4_6  segment_load_conservation_851  1
    load_0_4_6  segment_load_conservation_865  -1
    load_0_4_6  segment_prefix_lb_866  1
    load_0_4_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_7  arc_capacity_432  -30
    arc_0_4_7  connected_order_arc_433  -17
    arc_0_4_7  out_degree_847  1
    arc_0_4_7  in_degree_869  1
    arc_0_4_7  original_T_including_depot_unload_937  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_7  arc_capacity_432  1
    load_0_4_7  segment_load_conservation_851  1
    load_0_4_7  segment_load_conservation_872  -1
    load_0_4_7  segment_prefix_lb_873  1
    load_0_4_7  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_434  -30
    arc_0_4_8  connected_order_arc_435  -17
    arc_0_4_8  out_degree_847  1
    arc_0_4_8  in_degree_876  1
    arc_0_4_8  original_T_including_depot_unload_937  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_434  1
    load_0_4_8  segment_load_conservation_851  1
    load_0_4_8  segment_load_conservation_879  -1
    load_0_4_8  segment_prefix_lb_880  1
    load_0_4_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_436  -30
    arc_0_4_11  connected_order_arc_437  -17
    arc_0_4_11  out_degree_847  1
    arc_0_4_11  in_degree_883  1
    arc_0_4_11  original_T_including_depot_unload_937  3.0706942101225172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_436  1
    load_0_4_11  segment_load_conservation_851  1
    load_0_4_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_438  -30
    arc_0_4_12  connected_order_arc_439  -17
    arc_0_4_12  out_degree_847  1
    arc_0_4_12  in_degree_889  1
    arc_0_4_12  original_T_including_depot_unload_937  2.9012357973868689e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_438  1
    load_0_4_12  segment_load_conservation_851  1
    load_0_4_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_440  -30
    arc_0_4_13  connected_order_arc_441  -17
    arc_0_4_13  out_degree_847  1
    arc_0_4_13  in_degree_895  1
    arc_0_4_13  original_T_including_depot_unload_937  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_440  1
    load_0_4_13  segment_load_conservation_851  1
    load_0_4_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_442  -30
    arc_0_4_14  connected_order_arc_443  -17
    arc_0_4_14  out_degree_847  1
    arc_0_4_14  in_degree_901  1
    arc_0_4_14  original_T_including_depot_unload_937  2.9361273497784791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_442  1
    load_0_4_14  segment_load_conservation_851  1
    load_0_4_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_444  -30
    arc_0_4_15  connected_order_arc_445  -17
    arc_0_4_15  out_degree_847  1
    arc_0_4_15  in_degree_907  1
    arc_0_4_15  original_T_including_depot_unload_937  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_444  1
    load_0_4_15  segment_load_conservation_851  1
    load_0_4_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_446  -30
    arc_0_4_16  connected_order_arc_447  -17
    arc_0_4_16  out_degree_847  1
    arc_0_4_16  in_degree_913  1
    arc_0_4_16  original_T_including_depot_unload_937  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_446  1
    load_0_4_16  segment_load_conservation_851  1
    load_0_4_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_448  -30
    arc_0_4_17  connected_order_arc_449  -17
    arc_0_4_17  out_degree_847  1
    arc_0_4_17  in_degree_919  1
    arc_0_4_17  original_T_including_depot_unload_937  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_448  1
    load_0_4_17  segment_load_conservation_851  1
    load_0_4_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_450  -30
    arc_0_4_18  connected_order_arc_451  -17
    arc_0_4_18  out_degree_847  1
    arc_0_4_18  in_degree_925  1
    arc_0_4_18  original_T_including_depot_unload_937  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_450  1
    load_0_4_18  segment_load_conservation_851  1
    load_0_4_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_452  -30
    arc_0_5_0  depot_return_or_bypass_825  1
    arc_0_5_0  out_degree_854  1
    arc_0_5_0  original_T_including_depot_unload_937  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_452  1
    load_0_5_0  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_453  -30
    arc_0_5_1  connected_order_arc_454  -17
    arc_0_5_1  in_degree_827  1
    arc_0_5_1  out_degree_854  1
    arc_0_5_1  original_T_including_depot_unload_937  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_453  1
    load_0_5_1  segment_load_conservation_830  -1
    load_0_5_1  segment_prefix_lb_831  1
    load_0_5_1  segment_prefix_ub_832  1
    load_0_5_1  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_455  -30
    arc_0_5_2  connected_order_arc_456  -17
    arc_0_5_2  in_degree_834  1
    arc_0_5_2  out_degree_854  1
    arc_0_5_2  original_T_including_depot_unload_937  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_455  1
    load_0_5_2  segment_load_conservation_837  -1
    load_0_5_2  segment_prefix_lb_838  1
    load_0_5_2  segment_prefix_ub_839  1
    load_0_5_2  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_457  -30
    arc_0_5_3  connected_order_arc_458  -17
    arc_0_5_3  in_degree_841  1
    arc_0_5_3  out_degree_854  1
    arc_0_5_3  original_T_including_depot_unload_937  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_457  1
    load_0_5_3  segment_load_conservation_844  -1
    load_0_5_3  segment_prefix_lb_845  1
    load_0_5_3  segment_prefix_ub_846  1
    load_0_5_3  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_459  -30
    arc_0_5_4  connected_order_arc_460  -17
    arc_0_5_4  in_degree_848  1
    arc_0_5_4  out_degree_854  1
    arc_0_5_4  original_T_including_depot_unload_937  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_459  1
    load_0_5_4  segment_load_conservation_851  -1
    load_0_5_4  segment_prefix_lb_852  1
    load_0_5_4  segment_prefix_ub_853  1
    load_0_5_4  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_461  -30
    arc_0_5_6  connected_order_arc_462  -17
    arc_0_5_6  out_degree_854  1
    arc_0_5_6  in_degree_862  1
    arc_0_5_6  original_T_including_depot_unload_937  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_461  1
    load_0_5_6  segment_load_conservation_858  1
    load_0_5_6  segment_load_conservation_865  -1
    load_0_5_6  segment_prefix_lb_866  1
    load_0_5_6  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_7  arc_capacity_463  -30
    arc_0_5_7  connected_order_arc_464  -17
    arc_0_5_7  out_degree_854  1
    arc_0_5_7  in_degree_869  1
    arc_0_5_7  original_T_including_depot_unload_937  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_7  arc_capacity_463  1
    load_0_5_7  segment_load_conservation_858  1
    load_0_5_7  segment_load_conservation_872  -1
    load_0_5_7  segment_prefix_lb_873  1
    load_0_5_7  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_465  -30
    arc_0_5_8  connected_order_arc_466  -17
    arc_0_5_8  out_degree_854  1
    arc_0_5_8  in_degree_876  1
    arc_0_5_8  original_T_including_depot_unload_937  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_465  1
    load_0_5_8  segment_load_conservation_858  1
    load_0_5_8  segment_load_conservation_879  -1
    load_0_5_8  segment_prefix_lb_880  1
    load_0_5_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_467  -30
    arc_0_5_11  connected_order_arc_468  -17
    arc_0_5_11  out_degree_854  1
    arc_0_5_11  in_degree_883  1
    arc_0_5_11  original_T_including_depot_unload_937  2.9857518131746506e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_467  1
    load_0_5_11  segment_load_conservation_858  1
    load_0_5_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_469  -30
    arc_0_5_12  connected_order_arc_470  -17
    arc_0_5_12  out_degree_854  1
    arc_0_5_12  in_degree_889  1
    arc_0_5_12  original_T_including_depot_unload_937  2.8044705317383118e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_469  1
    load_0_5_12  segment_load_conservation_858  1
    load_0_5_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_471  -30
    arc_0_5_13  connected_order_arc_472  -17
    arc_0_5_13  out_degree_854  1
    arc_0_5_13  in_degree_895  1
    arc_0_5_13  original_T_including_depot_unload_937  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_471  1
    load_0_5_13  segment_load_conservation_858  1
    load_0_5_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_473  -30
    arc_0_5_14  connected_order_arc_474  -17
    arc_0_5_14  out_degree_854  1
    arc_0_5_14  in_degree_901  1
    arc_0_5_14  original_T_including_depot_unload_937  2.8188003047777693e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_473  1
    load_0_5_14  segment_load_conservation_858  1
    load_0_5_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_475  -30
    arc_0_5_15  connected_order_arc_476  -17
    arc_0_5_15  out_degree_854  1
    arc_0_5_15  in_degree_907  1
    arc_0_5_15  original_T_including_depot_unload_937  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_475  1
    load_0_5_15  segment_load_conservation_858  1
    load_0_5_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_477  -30
    arc_0_5_16  connected_order_arc_478  -17
    arc_0_5_16  out_degree_854  1
    arc_0_5_16  in_degree_913  1
    arc_0_5_16  original_T_including_depot_unload_937  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_477  1
    load_0_5_16  segment_load_conservation_858  1
    load_0_5_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_479  -30
    arc_0_5_17  connected_order_arc_480  -17
    arc_0_5_17  out_degree_854  1
    arc_0_5_17  in_degree_919  1
    arc_0_5_17  original_T_including_depot_unload_937  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_479  1
    load_0_5_17  segment_load_conservation_858  1
    load_0_5_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_481  -30
    arc_0_5_18  connected_order_arc_482  -17
    arc_0_5_18  out_degree_854  1
    arc_0_5_18  in_degree_925  1
    arc_0_5_18  original_T_including_depot_unload_937  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_481  1
    load_0_5_18  segment_load_conservation_858  1
    load_0_5_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_483  -30
    arc_0_6_0  depot_return_or_bypass_825  1
    arc_0_6_0  out_degree_861  1
    arc_0_6_0  original_T_including_depot_unload_937  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_483  1
    load_0_6_0  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_484  -30
    arc_0_6_1  connected_order_arc_485  -17
    arc_0_6_1  in_degree_827  1
    arc_0_6_1  out_degree_861  1
    arc_0_6_1  original_T_including_depot_unload_937  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_484  1
    load_0_6_1  segment_load_conservation_830  -1
    load_0_6_1  segment_prefix_lb_831  1
    load_0_6_1  segment_prefix_ub_832  1
    load_0_6_1  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_486  -30
    arc_0_6_2  connected_order_arc_487  -17
    arc_0_6_2  in_degree_834  1
    arc_0_6_2  out_degree_861  1
    arc_0_6_2  original_T_including_depot_unload_937  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_486  1
    load_0_6_2  segment_load_conservation_837  -1
    load_0_6_2  segment_prefix_lb_838  1
    load_0_6_2  segment_prefix_ub_839  1
    load_0_6_2  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_488  -30
    arc_0_6_3  connected_order_arc_489  -17
    arc_0_6_3  in_degree_841  1
    arc_0_6_3  out_degree_861  1
    arc_0_6_3  original_T_including_depot_unload_937  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_488  1
    load_0_6_3  segment_load_conservation_844  -1
    load_0_6_3  segment_prefix_lb_845  1
    load_0_6_3  segment_prefix_ub_846  1
    load_0_6_3  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_490  -30
    arc_0_6_4  connected_order_arc_491  -17
    arc_0_6_4  in_degree_848  1
    arc_0_6_4  out_degree_861  1
    arc_0_6_4  original_T_including_depot_unload_937  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_490  1
    load_0_6_4  segment_load_conservation_851  -1
    load_0_6_4  segment_prefix_lb_852  1
    load_0_6_4  segment_prefix_ub_853  1
    load_0_6_4  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_492  -30
    arc_0_6_5  connected_order_arc_493  -17
    arc_0_6_5  in_degree_855  1
    arc_0_6_5  out_degree_861  1
    arc_0_6_5  original_T_including_depot_unload_937  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_492  1
    load_0_6_5  segment_load_conservation_858  -1
    load_0_6_5  segment_prefix_lb_859  1
    load_0_6_5  segment_prefix_ub_860  1
    load_0_6_5  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_7  arc_capacity_494  -30
    arc_0_6_7  connected_order_arc_495  -17
    arc_0_6_7  out_degree_861  1
    arc_0_6_7  in_degree_869  1
    arc_0_6_7  original_T_including_depot_unload_937  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_7  arc_capacity_494  1
    load_0_6_7  segment_load_conservation_865  1
    load_0_6_7  segment_load_conservation_872  -1
    load_0_6_7  segment_prefix_lb_873  1
    load_0_6_7  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_8  arc_capacity_496  -30
    arc_0_6_8  connected_order_arc_497  -17
    arc_0_6_8  out_degree_861  1
    arc_0_6_8  in_degree_876  1
    arc_0_6_8  original_T_including_depot_unload_937  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_8  arc_capacity_496  1
    load_0_6_8  segment_load_conservation_865  1
    load_0_6_8  segment_load_conservation_879  -1
    load_0_6_8  segment_prefix_lb_880  1
    load_0_6_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_498  -30
    arc_0_6_11  connected_order_arc_499  -17
    arc_0_6_11  out_degree_861  1
    arc_0_6_11  in_degree_883  1
    arc_0_6_11  original_T_including_depot_unload_937  2.9992588346691123e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_498  1
    load_0_6_11  segment_load_conservation_865  1
    load_0_6_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_500  -30
    arc_0_6_12  connected_order_arc_501  -17
    arc_0_6_12  out_degree_861  1
    arc_0_6_12  in_degree_889  1
    arc_0_6_12  original_T_including_depot_unload_937  2.8096824480964965e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_500  1
    load_0_6_12  segment_load_conservation_865  1
    load_0_6_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_502  -30
    arc_0_6_13  connected_order_arc_503  -17
    arc_0_6_13  out_degree_861  1
    arc_0_6_13  in_degree_895  1
    arc_0_6_13  original_T_including_depot_unload_937  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_502  1
    load_0_6_13  segment_load_conservation_865  1
    load_0_6_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_504  -30
    arc_0_6_14  connected_order_arc_505  -17
    arc_0_6_14  out_degree_861  1
    arc_0_6_14  in_degree_901  1
    arc_0_6_14  original_T_including_depot_unload_937  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_504  1
    load_0_6_14  segment_load_conservation_865  1
    load_0_6_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_506  -30
    arc_0_6_15  connected_order_arc_507  -17
    arc_0_6_15  out_degree_861  1
    arc_0_6_15  in_degree_907  1
    arc_0_6_15  original_T_including_depot_unload_937  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_506  1
    load_0_6_15  segment_load_conservation_865  1
    load_0_6_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_508  -30
    arc_0_6_16  connected_order_arc_509  -17
    arc_0_6_16  out_degree_861  1
    arc_0_6_16  in_degree_913  1
    arc_0_6_16  original_T_including_depot_unload_937  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_508  1
    load_0_6_16  segment_load_conservation_865  1
    load_0_6_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_510  -30
    arc_0_6_17  connected_order_arc_511  -17
    arc_0_6_17  out_degree_861  1
    arc_0_6_17  in_degree_919  1
    arc_0_6_17  original_T_including_depot_unload_937  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_510  1
    load_0_6_17  segment_load_conservation_865  1
    load_0_6_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_512  -30
    arc_0_6_18  connected_order_arc_513  -17
    arc_0_6_18  out_degree_861  1
    arc_0_6_18  in_degree_925  1
    arc_0_6_18  original_T_including_depot_unload_937  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_512  1
    load_0_6_18  segment_load_conservation_865  1
    load_0_6_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_0  arc_capacity_514  -30
    arc_0_7_0  depot_return_or_bypass_825  1
    arc_0_7_0  out_degree_868  1
    arc_0_7_0  original_T_including_depot_unload_937  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_0  arc_capacity_514  1
    load_0_7_0  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_1  arc_capacity_515  -30
    arc_0_7_1  connected_order_arc_516  -17
    arc_0_7_1  in_degree_827  1
    arc_0_7_1  out_degree_868  1
    arc_0_7_1  original_T_including_depot_unload_937  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_7_1  arc_capacity_515  1
    load_0_7_1  segment_load_conservation_830  -1
    load_0_7_1  segment_prefix_lb_831  1
    load_0_7_1  segment_prefix_ub_832  1
    load_0_7_1  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_2  arc_capacity_517  -30
    arc_0_7_2  connected_order_arc_518  -17
    arc_0_7_2  in_degree_834  1
    arc_0_7_2  out_degree_868  1
    arc_0_7_2  original_T_including_depot_unload_937  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_2  arc_capacity_517  1
    load_0_7_2  segment_load_conservation_837  -1
    load_0_7_2  segment_prefix_lb_838  1
    load_0_7_2  segment_prefix_ub_839  1
    load_0_7_2  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_3  arc_capacity_519  -30
    arc_0_7_3  connected_order_arc_520  -17
    arc_0_7_3  in_degree_841  1
    arc_0_7_3  out_degree_868  1
    arc_0_7_3  original_T_including_depot_unload_937  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_3  arc_capacity_519  1
    load_0_7_3  segment_load_conservation_844  -1
    load_0_7_3  segment_prefix_lb_845  1
    load_0_7_3  segment_prefix_ub_846  1
    load_0_7_3  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_4  arc_capacity_521  -30
    arc_0_7_4  connected_order_arc_522  -17
    arc_0_7_4  in_degree_848  1
    arc_0_7_4  out_degree_868  1
    arc_0_7_4  original_T_including_depot_unload_937  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_4  arc_capacity_521  1
    load_0_7_4  segment_load_conservation_851  -1
    load_0_7_4  segment_prefix_lb_852  1
    load_0_7_4  segment_prefix_ub_853  1
    load_0_7_4  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_5  arc_capacity_523  -30
    arc_0_7_5  connected_order_arc_524  -17
    arc_0_7_5  in_degree_855  1
    arc_0_7_5  out_degree_868  1
    arc_0_7_5  original_T_including_depot_unload_937  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_5  arc_capacity_523  1
    load_0_7_5  segment_load_conservation_858  -1
    load_0_7_5  segment_prefix_lb_859  1
    load_0_7_5  segment_prefix_ub_860  1
    load_0_7_5  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_6  arc_capacity_525  -30
    arc_0_7_6  connected_order_arc_526  -17
    arc_0_7_6  in_degree_862  1
    arc_0_7_6  out_degree_868  1
    arc_0_7_6  original_T_including_depot_unload_937  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_6  arc_capacity_525  1
    load_0_7_6  segment_load_conservation_865  -1
    load_0_7_6  segment_prefix_lb_866  1
    load_0_7_6  segment_prefix_ub_867  1
    load_0_7_6  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_8  arc_capacity_527  -30
    arc_0_7_8  connected_order_arc_528  -17
    arc_0_7_8  out_degree_868  1
    arc_0_7_8  in_degree_876  1
    arc_0_7_8  original_T_including_depot_unload_937  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_8  arc_capacity_527  1
    load_0_7_8  segment_load_conservation_872  1
    load_0_7_8  segment_load_conservation_879  -1
    load_0_7_8  segment_prefix_lb_880  1
    load_0_7_8  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_11  arc_capacity_529  -30
    arc_0_7_11  connected_order_arc_530  -17
    arc_0_7_11  out_degree_868  1
    arc_0_7_11  in_degree_883  1
    arc_0_7_11  original_T_including_depot_unload_937  3.0078695794061259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_11  arc_capacity_529  1
    load_0_7_11  segment_load_conservation_872  1
    load_0_7_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_12  arc_capacity_531  -30
    arc_0_7_12  connected_order_arc_532  -17
    arc_0_7_12  out_degree_868  1
    arc_0_7_12  in_degree_889  1
    arc_0_7_12  original_T_including_depot_unload_937  2.8118819084250831e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_12  arc_capacity_531  1
    load_0_7_12  segment_load_conservation_872  1
    load_0_7_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_13  arc_capacity_533  -30
    arc_0_7_13  connected_order_arc_534  -17
    arc_0_7_13  out_degree_868  1
    arc_0_7_13  in_degree_895  1
    arc_0_7_13  original_T_including_depot_unload_937  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_13  arc_capacity_533  1
    load_0_7_13  segment_load_conservation_872  1
    load_0_7_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_14  arc_capacity_535  -30
    arc_0_7_14  connected_order_arc_536  -17
    arc_0_7_14  out_degree_868  1
    arc_0_7_14  in_degree_901  1
    arc_0_7_14  original_T_including_depot_unload_937  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_14  arc_capacity_535  1
    load_0_7_14  segment_load_conservation_872  1
    load_0_7_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_15  arc_capacity_537  -30
    arc_0_7_15  connected_order_arc_538  -17
    arc_0_7_15  out_degree_868  1
    arc_0_7_15  in_degree_907  1
    arc_0_7_15  original_T_including_depot_unload_937  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_15  arc_capacity_537  1
    load_0_7_15  segment_load_conservation_872  1
    load_0_7_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_16  arc_capacity_539  -30
    arc_0_7_16  connected_order_arc_540  -17
    arc_0_7_16  out_degree_868  1
    arc_0_7_16  in_degree_913  1
    arc_0_7_16  original_T_including_depot_unload_937  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_16  arc_capacity_539  1
    load_0_7_16  segment_load_conservation_872  1
    load_0_7_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_17  arc_capacity_541  -30
    arc_0_7_17  connected_order_arc_542  -17
    arc_0_7_17  out_degree_868  1
    arc_0_7_17  in_degree_919  1
    arc_0_7_17  original_T_including_depot_unload_937  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_17  arc_capacity_541  1
    load_0_7_17  segment_load_conservation_872  1
    load_0_7_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_18  arc_capacity_543  -30
    arc_0_7_18  connected_order_arc_544  -17
    arc_0_7_18  out_degree_868  1
    arc_0_7_18  in_degree_925  1
    arc_0_7_18  original_T_including_depot_unload_937  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_18  arc_capacity_543  1
    load_0_7_18  segment_load_conservation_872  1
    load_0_7_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_545  -30
    arc_0_8_0  depot_return_or_bypass_825  1
    arc_0_8_0  out_degree_875  1
    arc_0_8_0  original_T_including_depot_unload_937  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_545  1
    load_0_8_0  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_546  -30
    arc_0_8_1  connected_order_arc_547  -17
    arc_0_8_1  in_degree_827  1
    arc_0_8_1  out_degree_875  1
    arc_0_8_1  original_T_including_depot_unload_937  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_546  1
    load_0_8_1  segment_load_conservation_830  -1
    load_0_8_1  segment_prefix_lb_831  1
    load_0_8_1  segment_prefix_ub_832  1
    load_0_8_1  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_548  -30
    arc_0_8_2  connected_order_arc_549  -17
    arc_0_8_2  in_degree_834  1
    arc_0_8_2  out_degree_875  1
    arc_0_8_2  original_T_including_depot_unload_937  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_548  1
    load_0_8_2  segment_load_conservation_837  -1
    load_0_8_2  segment_prefix_lb_838  1
    load_0_8_2  segment_prefix_ub_839  1
    load_0_8_2  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_550  -30
    arc_0_8_3  connected_order_arc_551  -17
    arc_0_8_3  in_degree_841  1
    arc_0_8_3  out_degree_875  1
    arc_0_8_3  original_T_including_depot_unload_937  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_550  1
    load_0_8_3  segment_load_conservation_844  -1
    load_0_8_3  segment_prefix_lb_845  1
    load_0_8_3  segment_prefix_ub_846  1
    load_0_8_3  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_552  -30
    arc_0_8_4  connected_order_arc_553  -17
    arc_0_8_4  in_degree_848  1
    arc_0_8_4  out_degree_875  1
    arc_0_8_4  original_T_including_depot_unload_937  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_552  1
    load_0_8_4  segment_load_conservation_851  -1
    load_0_8_4  segment_prefix_lb_852  1
    load_0_8_4  segment_prefix_ub_853  1
    load_0_8_4  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_554  -30
    arc_0_8_5  connected_order_arc_555  -17
    arc_0_8_5  in_degree_855  1
    arc_0_8_5  out_degree_875  1
    arc_0_8_5  original_T_including_depot_unload_937  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_554  1
    load_0_8_5  segment_load_conservation_858  -1
    load_0_8_5  segment_prefix_lb_859  1
    load_0_8_5  segment_prefix_ub_860  1
    load_0_8_5  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_6  arc_capacity_556  -30
    arc_0_8_6  connected_order_arc_557  -17
    arc_0_8_6  in_degree_862  1
    arc_0_8_6  out_degree_875  1
    arc_0_8_6  original_T_including_depot_unload_937  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_6  arc_capacity_556  1
    load_0_8_6  segment_load_conservation_865  -1
    load_0_8_6  segment_prefix_lb_866  1
    load_0_8_6  segment_prefix_ub_867  1
    load_0_8_6  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_7  arc_capacity_558  -30
    arc_0_8_7  connected_order_arc_559  -17
    arc_0_8_7  in_degree_869  1
    arc_0_8_7  out_degree_875  1
    arc_0_8_7  original_T_including_depot_unload_937  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_7  arc_capacity_558  1
    load_0_8_7  segment_load_conservation_872  -1
    load_0_8_7  segment_prefix_lb_873  1
    load_0_8_7  segment_prefix_ub_874  1
    load_0_8_7  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_560  -30
    arc_0_8_11  connected_order_arc_561  -17
    arc_0_8_11  out_degree_875  1
    arc_0_8_11  in_degree_883  1
    arc_0_8_11  original_T_including_depot_unload_937  2.9299952981117208e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_560  1
    load_0_8_11  segment_load_conservation_879  1
    load_0_8_11  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_562  -30
    arc_0_8_12  connected_order_arc_563  -17
    arc_0_8_12  out_degree_875  1
    arc_0_8_12  in_degree_889  1
    arc_0_8_12  original_T_including_depot_unload_937  2.7275263449800736e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_562  1
    load_0_8_12  segment_load_conservation_879  1
    load_0_8_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_564  -30
    arc_0_8_13  connected_order_arc_565  -17
    arc_0_8_13  out_degree_875  1
    arc_0_8_13  in_degree_895  1
    arc_0_8_13  original_T_including_depot_unload_937  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_564  1
    load_0_8_13  segment_load_conservation_879  1
    load_0_8_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_566  -30
    arc_0_8_14  connected_order_arc_567  -17
    arc_0_8_14  out_degree_875  1
    arc_0_8_14  in_degree_901  1
    arc_0_8_14  original_T_including_depot_unload_937  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_566  1
    load_0_8_14  segment_load_conservation_879  1
    load_0_8_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_568  -30
    arc_0_8_15  connected_order_arc_569  -17
    arc_0_8_15  out_degree_875  1
    arc_0_8_15  in_degree_907  1
    arc_0_8_15  original_T_including_depot_unload_937  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_568  1
    load_0_8_15  segment_load_conservation_879  1
    load_0_8_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_16  arc_capacity_570  -30
    arc_0_8_16  connected_order_arc_571  -17
    arc_0_8_16  out_degree_875  1
    arc_0_8_16  in_degree_913  1
    arc_0_8_16  original_T_including_depot_unload_937  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_16  arc_capacity_570  1
    load_0_8_16  segment_load_conservation_879  1
    load_0_8_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_17  arc_capacity_572  -30
    arc_0_8_17  connected_order_arc_573  -17
    arc_0_8_17  out_degree_875  1
    arc_0_8_17  in_degree_919  1
    arc_0_8_17  original_T_including_depot_unload_937  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_17  arc_capacity_572  1
    load_0_8_17  segment_load_conservation_879  1
    load_0_8_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_18  arc_capacity_574  -30
    arc_0_8_18  connected_order_arc_575  -17
    arc_0_8_18  out_degree_875  1
    arc_0_8_18  in_degree_925  1
    arc_0_8_18  original_T_including_depot_unload_937  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_18  arc_capacity_574  1
    load_0_8_18  segment_load_conservation_879  1
    load_0_8_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_576  -30
    arc_0_11_0  depot_return_or_bypass_825  1
    arc_0_11_0  out_degree_882  1
    arc_0_11_0  original_T_including_depot_unload_937  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_576  1
    load_0_11_0  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_577  -30
    arc_0_11_1  connected_order_arc_578  -17
    arc_0_11_1  in_degree_827  1
    arc_0_11_1  out_degree_882  1
    arc_0_11_1  original_T_including_depot_unload_937  2.9475580354409412e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_577  1
    load_0_11_1  segment_load_conservation_830  -1
    load_0_11_1  segment_prefix_lb_831  1
    load_0_11_1  segment_prefix_ub_832  1
    load_0_11_1  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_579  -30
    arc_0_11_2  connected_order_arc_580  -17
    arc_0_11_2  in_degree_834  1
    arc_0_11_2  out_degree_882  1
    arc_0_11_2  original_T_including_depot_unload_937  3.1940365421146048e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_579  1
    load_0_11_2  segment_load_conservation_837  -1
    load_0_11_2  segment_prefix_lb_838  1
    load_0_11_2  segment_prefix_ub_839  1
    load_0_11_2  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_581  -30
    arc_0_11_3  connected_order_arc_582  -17
    arc_0_11_3  in_degree_841  1
    arc_0_11_3  out_degree_882  1
    arc_0_11_3  original_T_including_depot_unload_937  3.4153410343469327e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_581  1
    load_0_11_3  segment_load_conservation_844  -1
    load_0_11_3  segment_prefix_lb_845  1
    load_0_11_3  segment_prefix_ub_846  1
    load_0_11_3  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_583  -30
    arc_0_11_4  connected_order_arc_584  -17
    arc_0_11_4  in_degree_848  1
    arc_0_11_4  out_degree_882  1
    arc_0_11_4  original_T_including_depot_unload_937  3.0706942101225172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_583  1
    load_0_11_4  segment_load_conservation_851  -1
    load_0_11_4  segment_prefix_lb_852  1
    load_0_11_4  segment_prefix_ub_853  1
    load_0_11_4  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_585  -30
    arc_0_11_5  connected_order_arc_586  -17
    arc_0_11_5  in_degree_855  1
    arc_0_11_5  out_degree_882  1
    arc_0_11_5  original_T_including_depot_unload_937  2.9857518131746506e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_585  1
    load_0_11_5  segment_load_conservation_858  -1
    load_0_11_5  segment_prefix_lb_859  1
    load_0_11_5  segment_prefix_ub_860  1
    load_0_11_5  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_587  -30
    arc_0_11_6  connected_order_arc_588  -17
    arc_0_11_6  in_degree_862  1
    arc_0_11_6  out_degree_882  1
    arc_0_11_6  original_T_including_depot_unload_937  2.9992588346691123e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_587  1
    load_0_11_6  segment_load_conservation_865  -1
    load_0_11_6  segment_prefix_lb_866  1
    load_0_11_6  segment_prefix_ub_867  1
    load_0_11_6  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_7  arc_capacity_589  -30
    arc_0_11_7  connected_order_arc_590  -17
    arc_0_11_7  in_degree_869  1
    arc_0_11_7  out_degree_882  1
    arc_0_11_7  original_T_including_depot_unload_937  3.0078695794061259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_7  arc_capacity_589  1
    load_0_11_7  segment_load_conservation_872  -1
    load_0_11_7  segment_prefix_lb_873  1
    load_0_11_7  segment_prefix_ub_874  1
    load_0_11_7  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_591  -30
    arc_0_11_8  connected_order_arc_592  -17
    arc_0_11_8  in_degree_876  1
    arc_0_11_8  out_degree_882  1
    arc_0_11_8  original_T_including_depot_unload_937  2.9299952981117208e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_591  1
    load_0_11_8  segment_load_conservation_879  -1
    load_0_11_8  segment_prefix_lb_880  1
    load_0_11_8  segment_prefix_ub_881  1
    load_0_11_8  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_593  -30
    arc_0_11_12  connected_order_arc_594  -17
    arc_0_11_12  out_degree_882  1
    arc_0_11_12  in_degree_889  1
    arc_0_11_12  original_T_including_depot_unload_937  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_593  1
    load_0_11_12  free_load_conservation_887  1
    load_0_11_12  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_595  -30
    arc_0_11_13  connected_order_arc_596  -17
    arc_0_11_13  out_degree_882  1
    arc_0_11_13  in_degree_895  1
    arc_0_11_13  original_T_including_depot_unload_937  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_595  1
    load_0_11_13  free_load_conservation_887  1
    load_0_11_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_597  -30
    arc_0_11_14  connected_order_arc_598  -17
    arc_0_11_14  out_degree_882  1
    arc_0_11_14  in_degree_901  1
    arc_0_11_14  original_T_including_depot_unload_937  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_597  1
    load_0_11_14  free_load_conservation_887  1
    load_0_11_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_599  -30
    arc_0_11_15  connected_order_arc_600  -17
    arc_0_11_15  out_degree_882  1
    arc_0_11_15  in_degree_907  1
    arc_0_11_15  original_T_including_depot_unload_937  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_599  1
    load_0_11_15  free_load_conservation_887  1
    load_0_11_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_601  -30
    arc_0_11_16  connected_order_arc_602  -17
    arc_0_11_16  out_degree_882  1
    arc_0_11_16  in_degree_913  1
    arc_0_11_16  original_T_including_depot_unload_937  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_601  1
    load_0_11_16  free_load_conservation_887  1
    load_0_11_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_17  arc_capacity_603  -30
    arc_0_11_17  connected_order_arc_604  -17
    arc_0_11_17  out_degree_882  1
    arc_0_11_17  in_degree_919  1
    arc_0_11_17  original_T_including_depot_unload_937  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_17  arc_capacity_603  1
    load_0_11_17  free_load_conservation_887  1
    load_0_11_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_18  arc_capacity_605  -30
    arc_0_11_18  connected_order_arc_606  -17
    arc_0_11_18  out_degree_882  1
    arc_0_11_18  in_degree_925  1
    arc_0_11_18  original_T_including_depot_unload_937  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_18  arc_capacity_605  1
    load_0_11_18  free_load_conservation_887  1
    load_0_11_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_607  -30
    arc_0_12_0  depot_return_or_bypass_825  1
    arc_0_12_0  out_degree_888  1
    arc_0_12_0  original_T_including_depot_unload_937  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_607  1
    load_0_12_0  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_608  -30
    arc_0_12_1  connected_order_arc_609  -17
    arc_0_12_1  in_degree_827  1
    arc_0_12_1  out_degree_888  1
    arc_0_12_1  original_T_including_depot_unload_937  2.7384186870432241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_608  1
    load_0_12_1  segment_load_conservation_830  -1
    load_0_12_1  segment_prefix_lb_831  1
    load_0_12_1  segment_prefix_ub_832  1
    load_0_12_1  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_610  -30
    arc_0_12_2  connected_order_arc_611  -17
    arc_0_12_2  in_degree_834  1
    arc_0_12_2  out_degree_888  1
    arc_0_12_2  original_T_including_depot_unload_937  3.0014740451067628e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_610  1
    load_0_12_2  segment_load_conservation_837  -1
    load_0_12_2  segment_prefix_lb_838  1
    load_0_12_2  segment_prefix_ub_839  1
    load_0_12_2  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_612  -30
    arc_0_12_3  connected_order_arc_613  -17
    arc_0_12_3  in_degree_841  1
    arc_0_12_3  out_degree_888  1
    arc_0_12_3  original_T_including_depot_unload_937  3.2308847977395667e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_612  1
    load_0_12_3  segment_load_conservation_844  -1
    load_0_12_3  segment_prefix_lb_845  1
    load_0_12_3  segment_prefix_ub_846  1
    load_0_12_3  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_614  -30
    arc_0_12_4  connected_order_arc_615  -17
    arc_0_12_4  in_degree_848  1
    arc_0_12_4  out_degree_888  1
    arc_0_12_4  original_T_including_depot_unload_937  2.9012357973868689e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_614  1
    load_0_12_4  segment_load_conservation_851  -1
    load_0_12_4  segment_prefix_lb_852  1
    load_0_12_4  segment_prefix_ub_853  1
    load_0_12_4  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_616  -30
    arc_0_12_5  connected_order_arc_617  -17
    arc_0_12_5  in_degree_855  1
    arc_0_12_5  out_degree_888  1
    arc_0_12_5  original_T_including_depot_unload_937  2.8044705317383118e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_616  1
    load_0_12_5  segment_load_conservation_858  -1
    load_0_12_5  segment_prefix_lb_859  1
    load_0_12_5  segment_prefix_ub_860  1
    load_0_12_5  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_618  -30
    arc_0_12_6  connected_order_arc_619  -17
    arc_0_12_6  in_degree_862  1
    arc_0_12_6  out_degree_888  1
    arc_0_12_6  original_T_including_depot_unload_937  2.8096824480964965e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_618  1
    load_0_12_6  segment_load_conservation_865  -1
    load_0_12_6  segment_prefix_lb_866  1
    load_0_12_6  segment_prefix_ub_867  1
    load_0_12_6  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_7  arc_capacity_620  -30
    arc_0_12_7  connected_order_arc_621  -17
    arc_0_12_7  in_degree_869  1
    arc_0_12_7  out_degree_888  1
    arc_0_12_7  original_T_including_depot_unload_937  2.8118819084250831e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_7  arc_capacity_620  1
    load_0_12_7  segment_load_conservation_872  -1
    load_0_12_7  segment_prefix_lb_873  1
    load_0_12_7  segment_prefix_ub_874  1
    load_0_12_7  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_622  -30
    arc_0_12_8  connected_order_arc_623  -17
    arc_0_12_8  in_degree_876  1
    arc_0_12_8  out_degree_888  1
    arc_0_12_8  original_T_including_depot_unload_937  2.7275263449800736e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_622  1
    load_0_12_8  segment_load_conservation_879  -1
    load_0_12_8  segment_prefix_lb_880  1
    load_0_12_8  segment_prefix_ub_881  1
    load_0_12_8  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_624  -30
    arc_0_12_11  connected_order_arc_625  -17
    arc_0_12_11  in_degree_883  1
    arc_0_12_11  out_degree_888  1
    arc_0_12_11  original_T_including_depot_unload_937  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_624  1
    load_0_12_11  free_load_conservation_887  -1
    load_0_12_11  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_626  -30
    arc_0_12_13  connected_order_arc_627  -17
    arc_0_12_13  out_degree_888  1
    arc_0_12_13  in_degree_895  1
    arc_0_12_13  original_T_including_depot_unload_937  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_626  1
    load_0_12_13  free_load_conservation_893  1
    load_0_12_13  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_628  -30
    arc_0_12_14  connected_order_arc_629  -17
    arc_0_12_14  out_degree_888  1
    arc_0_12_14  in_degree_901  1
    arc_0_12_14  original_T_including_depot_unload_937  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_628  1
    load_0_12_14  free_load_conservation_893  1
    load_0_12_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_630  -30
    arc_0_12_15  connected_order_arc_631  -17
    arc_0_12_15  out_degree_888  1
    arc_0_12_15  in_degree_907  1
    arc_0_12_15  original_T_including_depot_unload_937  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_630  1
    load_0_12_15  free_load_conservation_893  1
    load_0_12_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_632  -30
    arc_0_12_16  connected_order_arc_633  -17
    arc_0_12_16  out_degree_888  1
    arc_0_12_16  in_degree_913  1
    arc_0_12_16  original_T_including_depot_unload_937  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_632  1
    load_0_12_16  free_load_conservation_893  1
    load_0_12_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_634  -30
    arc_0_12_17  connected_order_arc_635  -17
    arc_0_12_17  out_degree_888  1
    arc_0_12_17  in_degree_919  1
    arc_0_12_17  original_T_including_depot_unload_937  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_634  1
    load_0_12_17  free_load_conservation_893  1
    load_0_12_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_636  -30
    arc_0_12_18  connected_order_arc_637  -17
    arc_0_12_18  out_degree_888  1
    arc_0_12_18  in_degree_925  1
    arc_0_12_18  original_T_including_depot_unload_937  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_636  1
    load_0_12_18  free_load_conservation_893  1
    load_0_12_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_638  -30
    arc_0_13_0  depot_return_or_bypass_825  1
    arc_0_13_0  out_degree_894  1
    arc_0_13_0  original_T_including_depot_unload_937  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_638  1
    load_0_13_0  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_639  -30
    arc_0_13_1  connected_order_arc_640  -17
    arc_0_13_1  in_degree_827  1
    arc_0_13_1  out_degree_894  1
    arc_0_13_1  original_T_including_depot_unload_937  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_639  1
    load_0_13_1  segment_load_conservation_830  -1
    load_0_13_1  segment_prefix_lb_831  1
    load_0_13_1  segment_prefix_ub_832  1
    load_0_13_1  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_641  -30
    arc_0_13_2  connected_order_arc_642  -17
    arc_0_13_2  in_degree_834  1
    arc_0_13_2  out_degree_894  1
    arc_0_13_2  original_T_including_depot_unload_937  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_641  1
    load_0_13_2  segment_load_conservation_837  -1
    load_0_13_2  segment_prefix_lb_838  1
    load_0_13_2  segment_prefix_ub_839  1
    load_0_13_2  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_643  -30
    arc_0_13_3  connected_order_arc_644  -17
    arc_0_13_3  in_degree_841  1
    arc_0_13_3  out_degree_894  1
    arc_0_13_3  original_T_including_depot_unload_937  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_643  1
    load_0_13_3  segment_load_conservation_844  -1
    load_0_13_3  segment_prefix_lb_845  1
    load_0_13_3  segment_prefix_ub_846  1
    load_0_13_3  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_645  -30
    arc_0_13_4  connected_order_arc_646  -17
    arc_0_13_4  in_degree_848  1
    arc_0_13_4  out_degree_894  1
    arc_0_13_4  original_T_including_depot_unload_937  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_645  1
    load_0_13_4  segment_load_conservation_851  -1
    load_0_13_4  segment_prefix_lb_852  1
    load_0_13_4  segment_prefix_ub_853  1
    load_0_13_4  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_647  -30
    arc_0_13_5  connected_order_arc_648  -17
    arc_0_13_5  in_degree_855  1
    arc_0_13_5  out_degree_894  1
    arc_0_13_5  original_T_including_depot_unload_937  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_647  1
    load_0_13_5  segment_load_conservation_858  -1
    load_0_13_5  segment_prefix_lb_859  1
    load_0_13_5  segment_prefix_ub_860  1
    load_0_13_5  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_649  -30
    arc_0_13_6  connected_order_arc_650  -17
    arc_0_13_6  in_degree_862  1
    arc_0_13_6  out_degree_894  1
    arc_0_13_6  original_T_including_depot_unload_937  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_649  1
    load_0_13_6  segment_load_conservation_865  -1
    load_0_13_6  segment_prefix_lb_866  1
    load_0_13_6  segment_prefix_ub_867  1
    load_0_13_6  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_7  arc_capacity_651  -30
    arc_0_13_7  connected_order_arc_652  -17
    arc_0_13_7  in_degree_869  1
    arc_0_13_7  out_degree_894  1
    arc_0_13_7  original_T_including_depot_unload_937  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_7  arc_capacity_651  1
    load_0_13_7  segment_load_conservation_872  -1
    load_0_13_7  segment_prefix_lb_873  1
    load_0_13_7  segment_prefix_ub_874  1
    load_0_13_7  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_653  -30
    arc_0_13_8  connected_order_arc_654  -17
    arc_0_13_8  in_degree_876  1
    arc_0_13_8  out_degree_894  1
    arc_0_13_8  original_T_including_depot_unload_937  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_653  1
    load_0_13_8  segment_load_conservation_879  -1
    load_0_13_8  segment_prefix_lb_880  1
    load_0_13_8  segment_prefix_ub_881  1
    load_0_13_8  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_655  -30
    arc_0_13_11  connected_order_arc_656  -17
    arc_0_13_11  in_degree_883  1
    arc_0_13_11  out_degree_894  1
    arc_0_13_11  original_T_including_depot_unload_937  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_655  1
    load_0_13_11  free_load_conservation_887  -1
    load_0_13_11  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_657  -30
    arc_0_13_12  connected_order_arc_658  -17
    arc_0_13_12  in_degree_889  1
    arc_0_13_12  out_degree_894  1
    arc_0_13_12  original_T_including_depot_unload_937  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_657  1
    load_0_13_12  free_load_conservation_893  -1
    load_0_13_12  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_659  -30
    arc_0_13_14  connected_order_arc_660  -17
    arc_0_13_14  out_degree_894  1
    arc_0_13_14  in_degree_901  1
    arc_0_13_14  original_T_including_depot_unload_937  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_659  1
    load_0_13_14  free_load_conservation_899  1
    load_0_13_14  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_661  -30
    arc_0_13_15  connected_order_arc_662  -17
    arc_0_13_15  out_degree_894  1
    arc_0_13_15  in_degree_907  1
    arc_0_13_15  original_T_including_depot_unload_937  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_661  1
    load_0_13_15  free_load_conservation_899  1
    load_0_13_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_663  -30
    arc_0_13_16  connected_order_arc_664  -17
    arc_0_13_16  out_degree_894  1
    arc_0_13_16  in_degree_913  1
    arc_0_13_16  original_T_including_depot_unload_937  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_663  1
    load_0_13_16  free_load_conservation_899  1
    load_0_13_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_665  -30
    arc_0_13_17  connected_order_arc_666  -17
    arc_0_13_17  out_degree_894  1
    arc_0_13_17  in_degree_919  1
    arc_0_13_17  original_T_including_depot_unload_937  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_665  1
    load_0_13_17  free_load_conservation_899  1
    load_0_13_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_667  -30
    arc_0_13_18  connected_order_arc_668  -17
    arc_0_13_18  out_degree_894  1
    arc_0_13_18  in_degree_925  1
    arc_0_13_18  original_T_including_depot_unload_937  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_667  1
    load_0_13_18  free_load_conservation_899  1
    load_0_13_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_669  -30
    arc_0_14_0  depot_return_or_bypass_825  1
    arc_0_14_0  out_degree_900  1
    arc_0_14_0  original_T_including_depot_unload_937  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_669  1
    load_0_14_0  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_670  -30
    arc_0_14_1  connected_order_arc_671  -17
    arc_0_14_1  in_degree_827  1
    arc_0_14_1  out_degree_900  1
    arc_0_14_1  original_T_including_depot_unload_937  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_670  1
    load_0_14_1  segment_load_conservation_830  -1
    load_0_14_1  segment_prefix_lb_831  1
    load_0_14_1  segment_prefix_ub_832  1
    load_0_14_1  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_672  -30
    arc_0_14_2  connected_order_arc_673  -17
    arc_0_14_2  in_degree_834  1
    arc_0_14_2  out_degree_900  1
    arc_0_14_2  original_T_including_depot_unload_937  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_672  1
    load_0_14_2  segment_load_conservation_837  -1
    load_0_14_2  segment_prefix_lb_838  1
    load_0_14_2  segment_prefix_ub_839  1
    load_0_14_2  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_674  -30
    arc_0_14_3  connected_order_arc_675  -17
    arc_0_14_3  in_degree_841  1
    arc_0_14_3  out_degree_900  1
    arc_0_14_3  original_T_including_depot_unload_937  3.2360258354135326e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_674  1
    load_0_14_3  segment_load_conservation_844  -1
    load_0_14_3  segment_prefix_lb_845  1
    load_0_14_3  segment_prefix_ub_846  1
    load_0_14_3  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_676  -30
    arc_0_14_4  connected_order_arc_677  -17
    arc_0_14_4  in_degree_848  1
    arc_0_14_4  out_degree_900  1
    arc_0_14_4  original_T_including_depot_unload_937  2.9361273497784791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_676  1
    load_0_14_4  segment_load_conservation_851  -1
    load_0_14_4  segment_prefix_lb_852  1
    load_0_14_4  segment_prefix_ub_853  1
    load_0_14_4  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_678  -30
    arc_0_14_5  connected_order_arc_679  -17
    arc_0_14_5  in_degree_855  1
    arc_0_14_5  out_degree_900  1
    arc_0_14_5  original_T_including_depot_unload_937  2.8188003047777693e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_678  1
    load_0_14_5  segment_load_conservation_858  -1
    load_0_14_5  segment_prefix_lb_859  1
    load_0_14_5  segment_prefix_ub_860  1
    load_0_14_5  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_680  -30
    arc_0_14_6  connected_order_arc_681  -17
    arc_0_14_6  in_degree_862  1
    arc_0_14_6  out_degree_900  1
    arc_0_14_6  original_T_including_depot_unload_937  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_680  1
    load_0_14_6  segment_load_conservation_865  -1
    load_0_14_6  segment_prefix_lb_866  1
    load_0_14_6  segment_prefix_ub_867  1
    load_0_14_6  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_7  arc_capacity_682  -30
    arc_0_14_7  connected_order_arc_683  -17
    arc_0_14_7  in_degree_869  1
    arc_0_14_7  out_degree_900  1
    arc_0_14_7  original_T_including_depot_unload_937  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_7  arc_capacity_682  1
    load_0_14_7  segment_load_conservation_872  -1
    load_0_14_7  segment_prefix_lb_873  1
    load_0_14_7  segment_prefix_ub_874  1
    load_0_14_7  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_684  -30
    arc_0_14_8  connected_order_arc_685  -17
    arc_0_14_8  in_degree_876  1
    arc_0_14_8  out_degree_900  1
    arc_0_14_8  original_T_including_depot_unload_937  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_684  1
    load_0_14_8  segment_load_conservation_879  -1
    load_0_14_8  segment_prefix_lb_880  1
    load_0_14_8  segment_prefix_ub_881  1
    load_0_14_8  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_686  -30
    arc_0_14_11  connected_order_arc_687  -17
    arc_0_14_11  in_degree_883  1
    arc_0_14_11  out_degree_900  1
    arc_0_14_11  original_T_including_depot_unload_937  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_686  1
    load_0_14_11  free_load_conservation_887  -1
    load_0_14_11  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_688  -30
    arc_0_14_12  connected_order_arc_689  -17
    arc_0_14_12  in_degree_889  1
    arc_0_14_12  out_degree_900  1
    arc_0_14_12  original_T_including_depot_unload_937  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_688  1
    load_0_14_12  free_load_conservation_893  -1
    load_0_14_12  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_690  -30
    arc_0_14_13  connected_order_arc_691  -17
    arc_0_14_13  in_degree_895  1
    arc_0_14_13  out_degree_900  1
    arc_0_14_13  original_T_including_depot_unload_937  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_690  1
    load_0_14_13  free_load_conservation_899  -1
    load_0_14_13  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_692  -30
    arc_0_14_15  connected_order_arc_693  -17
    arc_0_14_15  out_degree_900  1
    arc_0_14_15  in_degree_907  1
    arc_0_14_15  original_T_including_depot_unload_937  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_692  1
    load_0_14_15  free_load_conservation_905  1
    load_0_14_15  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_694  -30
    arc_0_14_16  connected_order_arc_695  -17
    arc_0_14_16  out_degree_900  1
    arc_0_14_16  in_degree_913  1
    arc_0_14_16  original_T_including_depot_unload_937  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_694  1
    load_0_14_16  free_load_conservation_905  1
    load_0_14_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_696  -30
    arc_0_14_17  connected_order_arc_697  -17
    arc_0_14_17  out_degree_900  1
    arc_0_14_17  in_degree_919  1
    arc_0_14_17  original_T_including_depot_unload_937  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_696  1
    load_0_14_17  free_load_conservation_905  1
    load_0_14_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_698  -30
    arc_0_14_18  connected_order_arc_699  -17
    arc_0_14_18  out_degree_900  1
    arc_0_14_18  in_degree_925  1
    arc_0_14_18  original_T_including_depot_unload_937  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_698  1
    load_0_14_18  free_load_conservation_905  1
    load_0_14_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_700  -30
    arc_0_15_0  depot_return_or_bypass_825  1
    arc_0_15_0  out_degree_906  1
    arc_0_15_0  original_T_including_depot_unload_937  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_700  1
    load_0_15_0  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_701  -30
    arc_0_15_1  connected_order_arc_702  -17
    arc_0_15_1  in_degree_827  1
    arc_0_15_1  out_degree_906  1
    arc_0_15_1  original_T_including_depot_unload_937  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_701  1
    load_0_15_1  segment_load_conservation_830  -1
    load_0_15_1  segment_prefix_lb_831  1
    load_0_15_1  segment_prefix_ub_832  1
    load_0_15_1  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_703  -30
    arc_0_15_2  connected_order_arc_704  -17
    arc_0_15_2  in_degree_834  1
    arc_0_15_2  out_degree_906  1
    arc_0_15_2  original_T_including_depot_unload_937  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_703  1
    load_0_15_2  segment_load_conservation_837  -1
    load_0_15_2  segment_prefix_lb_838  1
    load_0_15_2  segment_prefix_ub_839  1
    load_0_15_2  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_705  -30
    arc_0_15_3  connected_order_arc_706  -17
    arc_0_15_3  in_degree_841  1
    arc_0_15_3  out_degree_906  1
    arc_0_15_3  original_T_including_depot_unload_937  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_705  1
    load_0_15_3  segment_load_conservation_844  -1
    load_0_15_3  segment_prefix_lb_845  1
    load_0_15_3  segment_prefix_ub_846  1
    load_0_15_3  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_707  -30
    arc_0_15_4  connected_order_arc_708  -17
    arc_0_15_4  in_degree_848  1
    arc_0_15_4  out_degree_906  1
    arc_0_15_4  original_T_including_depot_unload_937  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_707  1
    load_0_15_4  segment_load_conservation_851  -1
    load_0_15_4  segment_prefix_lb_852  1
    load_0_15_4  segment_prefix_ub_853  1
    load_0_15_4  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_709  -30
    arc_0_15_5  connected_order_arc_710  -17
    arc_0_15_5  in_degree_855  1
    arc_0_15_5  out_degree_906  1
    arc_0_15_5  original_T_including_depot_unload_937  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_709  1
    load_0_15_5  segment_load_conservation_858  -1
    load_0_15_5  segment_prefix_lb_859  1
    load_0_15_5  segment_prefix_ub_860  1
    load_0_15_5  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_711  -30
    arc_0_15_6  connected_order_arc_712  -17
    arc_0_15_6  in_degree_862  1
    arc_0_15_6  out_degree_906  1
    arc_0_15_6  original_T_including_depot_unload_937  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_711  1
    load_0_15_6  segment_load_conservation_865  -1
    load_0_15_6  segment_prefix_lb_866  1
    load_0_15_6  segment_prefix_ub_867  1
    load_0_15_6  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_7  arc_capacity_713  -30
    arc_0_15_7  connected_order_arc_714  -17
    arc_0_15_7  in_degree_869  1
    arc_0_15_7  out_degree_906  1
    arc_0_15_7  original_T_including_depot_unload_937  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_7  arc_capacity_713  1
    load_0_15_7  segment_load_conservation_872  -1
    load_0_15_7  segment_prefix_lb_873  1
    load_0_15_7  segment_prefix_ub_874  1
    load_0_15_7  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_715  -30
    arc_0_15_8  connected_order_arc_716  -17
    arc_0_15_8  in_degree_876  1
    arc_0_15_8  out_degree_906  1
    arc_0_15_8  original_T_including_depot_unload_937  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_715  1
    load_0_15_8  segment_load_conservation_879  -1
    load_0_15_8  segment_prefix_lb_880  1
    load_0_15_8  segment_prefix_ub_881  1
    load_0_15_8  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_717  -30
    arc_0_15_11  connected_order_arc_718  -17
    arc_0_15_11  in_degree_883  1
    arc_0_15_11  out_degree_906  1
    arc_0_15_11  original_T_including_depot_unload_937  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_717  1
    load_0_15_11  free_load_conservation_887  -1
    load_0_15_11  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_719  -30
    arc_0_15_12  connected_order_arc_720  -17
    arc_0_15_12  in_degree_889  1
    arc_0_15_12  out_degree_906  1
    arc_0_15_12  original_T_including_depot_unload_937  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_719  1
    load_0_15_12  free_load_conservation_893  -1
    load_0_15_12  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_721  -30
    arc_0_15_13  connected_order_arc_722  -17
    arc_0_15_13  in_degree_895  1
    arc_0_15_13  out_degree_906  1
    arc_0_15_13  original_T_including_depot_unload_937  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_721  1
    load_0_15_13  free_load_conservation_899  -1
    load_0_15_13  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_723  -30
    arc_0_15_14  connected_order_arc_724  -17
    arc_0_15_14  in_degree_901  1
    arc_0_15_14  out_degree_906  1
    arc_0_15_14  original_T_including_depot_unload_937  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_723  1
    load_0_15_14  free_load_conservation_905  -1
    load_0_15_14  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_725  -30
    arc_0_15_16  connected_order_arc_726  -17
    arc_0_15_16  out_degree_906  1
    arc_0_15_16  in_degree_913  1
    arc_0_15_16  original_T_including_depot_unload_937  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_725  1
    load_0_15_16  free_load_conservation_911  1
    load_0_15_16  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_727  -30
    arc_0_15_17  connected_order_arc_728  -17
    arc_0_15_17  out_degree_906  1
    arc_0_15_17  in_degree_919  1
    arc_0_15_17  original_T_including_depot_unload_937  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_727  1
    load_0_15_17  free_load_conservation_911  1
    load_0_15_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_729  -30
    arc_0_15_18  connected_order_arc_730  -17
    arc_0_15_18  out_degree_906  1
    arc_0_15_18  in_degree_925  1
    arc_0_15_18  original_T_including_depot_unload_937  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_729  1
    load_0_15_18  free_load_conservation_911  1
    load_0_15_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_731  -30
    arc_0_16_0  depot_return_or_bypass_825  1
    arc_0_16_0  out_degree_912  1
    arc_0_16_0  original_T_including_depot_unload_937  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_731  1
    load_0_16_0  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_732  -30
    arc_0_16_1  connected_order_arc_733  -17
    arc_0_16_1  in_degree_827  1
    arc_0_16_1  out_degree_912  1
    arc_0_16_1  original_T_including_depot_unload_937  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_732  1
    load_0_16_1  segment_load_conservation_830  -1
    load_0_16_1  segment_prefix_lb_831  1
    load_0_16_1  segment_prefix_ub_832  1
    load_0_16_1  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_734  -30
    arc_0_16_2  connected_order_arc_735  -17
    arc_0_16_2  in_degree_834  1
    arc_0_16_2  out_degree_912  1
    arc_0_16_2  original_T_including_depot_unload_937  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_734  1
    load_0_16_2  segment_load_conservation_837  -1
    load_0_16_2  segment_prefix_lb_838  1
    load_0_16_2  segment_prefix_ub_839  1
    load_0_16_2  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_736  -30
    arc_0_16_3  connected_order_arc_737  -17
    arc_0_16_3  in_degree_841  1
    arc_0_16_3  out_degree_912  1
    arc_0_16_3  original_T_including_depot_unload_937  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_736  1
    load_0_16_3  segment_load_conservation_844  -1
    load_0_16_3  segment_prefix_lb_845  1
    load_0_16_3  segment_prefix_ub_846  1
    load_0_16_3  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_738  -30
    arc_0_16_4  connected_order_arc_739  -17
    arc_0_16_4  in_degree_848  1
    arc_0_16_4  out_degree_912  1
    arc_0_16_4  original_T_including_depot_unload_937  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_738  1
    load_0_16_4  segment_load_conservation_851  -1
    load_0_16_4  segment_prefix_lb_852  1
    load_0_16_4  segment_prefix_ub_853  1
    load_0_16_4  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_740  -30
    arc_0_16_5  connected_order_arc_741  -17
    arc_0_16_5  in_degree_855  1
    arc_0_16_5  out_degree_912  1
    arc_0_16_5  original_T_including_depot_unload_937  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_740  1
    load_0_16_5  segment_load_conservation_858  -1
    load_0_16_5  segment_prefix_lb_859  1
    load_0_16_5  segment_prefix_ub_860  1
    load_0_16_5  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_742  -30
    arc_0_16_6  connected_order_arc_743  -17
    arc_0_16_6  in_degree_862  1
    arc_0_16_6  out_degree_912  1
    arc_0_16_6  original_T_including_depot_unload_937  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_742  1
    load_0_16_6  segment_load_conservation_865  -1
    load_0_16_6  segment_prefix_lb_866  1
    load_0_16_6  segment_prefix_ub_867  1
    load_0_16_6  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_7  arc_capacity_744  -30
    arc_0_16_7  connected_order_arc_745  -17
    arc_0_16_7  in_degree_869  1
    arc_0_16_7  out_degree_912  1
    arc_0_16_7  original_T_including_depot_unload_937  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_7  arc_capacity_744  1
    load_0_16_7  segment_load_conservation_872  -1
    load_0_16_7  segment_prefix_lb_873  1
    load_0_16_7  segment_prefix_ub_874  1
    load_0_16_7  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_8  arc_capacity_746  -30
    arc_0_16_8  connected_order_arc_747  -17
    arc_0_16_8  in_degree_876  1
    arc_0_16_8  out_degree_912  1
    arc_0_16_8  original_T_including_depot_unload_937  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_8  arc_capacity_746  1
    load_0_16_8  segment_load_conservation_879  -1
    load_0_16_8  segment_prefix_lb_880  1
    load_0_16_8  segment_prefix_ub_881  1
    load_0_16_8  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_748  -30
    arc_0_16_11  connected_order_arc_749  -17
    arc_0_16_11  in_degree_883  1
    arc_0_16_11  out_degree_912  1
    arc_0_16_11  original_T_including_depot_unload_937  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_748  1
    load_0_16_11  free_load_conservation_887  -1
    load_0_16_11  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_750  -30
    arc_0_16_12  connected_order_arc_751  -17
    arc_0_16_12  in_degree_889  1
    arc_0_16_12  out_degree_912  1
    arc_0_16_12  original_T_including_depot_unload_937  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_750  1
    load_0_16_12  free_load_conservation_893  -1
    load_0_16_12  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_752  -30
    arc_0_16_13  connected_order_arc_753  -17
    arc_0_16_13  in_degree_895  1
    arc_0_16_13  out_degree_912  1
    arc_0_16_13  original_T_including_depot_unload_937  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_752  1
    load_0_16_13  free_load_conservation_899  -1
    load_0_16_13  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_754  -30
    arc_0_16_14  connected_order_arc_755  -17
    arc_0_16_14  in_degree_901  1
    arc_0_16_14  out_degree_912  1
    arc_0_16_14  original_T_including_depot_unload_937  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_754  1
    load_0_16_14  free_load_conservation_905  -1
    load_0_16_14  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_756  -30
    arc_0_16_15  connected_order_arc_757  -17
    arc_0_16_15  in_degree_907  1
    arc_0_16_15  out_degree_912  1
    arc_0_16_15  original_T_including_depot_unload_937  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_756  1
    load_0_16_15  free_load_conservation_911  -1
    load_0_16_15  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_758  -30
    arc_0_16_17  connected_order_arc_759  -17
    arc_0_16_17  out_degree_912  1
    arc_0_16_17  in_degree_919  1
    arc_0_16_17  original_T_including_depot_unload_937  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_758  1
    load_0_16_17  free_load_conservation_917  1
    load_0_16_17  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_760  -30
    arc_0_16_18  connected_order_arc_761  -17
    arc_0_16_18  out_degree_912  1
    arc_0_16_18  in_degree_925  1
    arc_0_16_18  original_T_including_depot_unload_937  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_760  1
    load_0_16_18  free_load_conservation_917  1
    load_0_16_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_762  -30
    arc_0_17_0  depot_return_or_bypass_825  1
    arc_0_17_0  out_degree_918  1
    arc_0_17_0  original_T_including_depot_unload_937  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_762  1
    load_0_17_0  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_763  -30
    arc_0_17_1  connected_order_arc_764  -17
    arc_0_17_1  in_degree_827  1
    arc_0_17_1  out_degree_918  1
    arc_0_17_1  original_T_including_depot_unload_937  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_763  1
    load_0_17_1  segment_load_conservation_830  -1
    load_0_17_1  segment_prefix_lb_831  1
    load_0_17_1  segment_prefix_ub_832  1
    load_0_17_1  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_765  -30
    arc_0_17_2  connected_order_arc_766  -17
    arc_0_17_2  in_degree_834  1
    arc_0_17_2  out_degree_918  1
    arc_0_17_2  original_T_including_depot_unload_937  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_765  1
    load_0_17_2  segment_load_conservation_837  -1
    load_0_17_2  segment_prefix_lb_838  1
    load_0_17_2  segment_prefix_ub_839  1
    load_0_17_2  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_767  -30
    arc_0_17_3  connected_order_arc_768  -17
    arc_0_17_3  in_degree_841  1
    arc_0_17_3  out_degree_918  1
    arc_0_17_3  original_T_including_depot_unload_937  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_767  1
    load_0_17_3  segment_load_conservation_844  -1
    load_0_17_3  segment_prefix_lb_845  1
    load_0_17_3  segment_prefix_ub_846  1
    load_0_17_3  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_769  -30
    arc_0_17_4  connected_order_arc_770  -17
    arc_0_17_4  in_degree_848  1
    arc_0_17_4  out_degree_918  1
    arc_0_17_4  original_T_including_depot_unload_937  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_769  1
    load_0_17_4  segment_load_conservation_851  -1
    load_0_17_4  segment_prefix_lb_852  1
    load_0_17_4  segment_prefix_ub_853  1
    load_0_17_4  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_771  -30
    arc_0_17_5  connected_order_arc_772  -17
    arc_0_17_5  in_degree_855  1
    arc_0_17_5  out_degree_918  1
    arc_0_17_5  original_T_including_depot_unload_937  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_771  1
    load_0_17_5  segment_load_conservation_858  -1
    load_0_17_5  segment_prefix_lb_859  1
    load_0_17_5  segment_prefix_ub_860  1
    load_0_17_5  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_773  -30
    arc_0_17_6  connected_order_arc_774  -17
    arc_0_17_6  in_degree_862  1
    arc_0_17_6  out_degree_918  1
    arc_0_17_6  original_T_including_depot_unload_937  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_773  1
    load_0_17_6  segment_load_conservation_865  -1
    load_0_17_6  segment_prefix_lb_866  1
    load_0_17_6  segment_prefix_ub_867  1
    load_0_17_6  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_7  arc_capacity_775  -30
    arc_0_17_7  connected_order_arc_776  -17
    arc_0_17_7  in_degree_869  1
    arc_0_17_7  out_degree_918  1
    arc_0_17_7  original_T_including_depot_unload_937  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_7  arc_capacity_775  1
    load_0_17_7  segment_load_conservation_872  -1
    load_0_17_7  segment_prefix_lb_873  1
    load_0_17_7  segment_prefix_ub_874  1
    load_0_17_7  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_8  arc_capacity_777  -30
    arc_0_17_8  connected_order_arc_778  -17
    arc_0_17_8  in_degree_876  1
    arc_0_17_8  out_degree_918  1
    arc_0_17_8  original_T_including_depot_unload_937  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_8  arc_capacity_777  1
    load_0_17_8  segment_load_conservation_879  -1
    load_0_17_8  segment_prefix_lb_880  1
    load_0_17_8  segment_prefix_ub_881  1
    load_0_17_8  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_11  arc_capacity_779  -30
    arc_0_17_11  connected_order_arc_780  -17
    arc_0_17_11  in_degree_883  1
    arc_0_17_11  out_degree_918  1
    arc_0_17_11  original_T_including_depot_unload_937  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_11  arc_capacity_779  1
    load_0_17_11  free_load_conservation_887  -1
    load_0_17_11  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_781  -30
    arc_0_17_12  connected_order_arc_782  -17
    arc_0_17_12  in_degree_889  1
    arc_0_17_12  out_degree_918  1
    arc_0_17_12  original_T_including_depot_unload_937  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_781  1
    load_0_17_12  free_load_conservation_893  -1
    load_0_17_12  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_783  -30
    arc_0_17_13  connected_order_arc_784  -17
    arc_0_17_13  in_degree_895  1
    arc_0_17_13  out_degree_918  1
    arc_0_17_13  original_T_including_depot_unload_937  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_783  1
    load_0_17_13  free_load_conservation_899  -1
    load_0_17_13  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_785  -30
    arc_0_17_14  connected_order_arc_786  -17
    arc_0_17_14  in_degree_901  1
    arc_0_17_14  out_degree_918  1
    arc_0_17_14  original_T_including_depot_unload_937  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_785  1
    load_0_17_14  free_load_conservation_905  -1
    load_0_17_14  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_787  -30
    arc_0_17_15  connected_order_arc_788  -17
    arc_0_17_15  in_degree_907  1
    arc_0_17_15  out_degree_918  1
    arc_0_17_15  original_T_including_depot_unload_937  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_787  1
    load_0_17_15  free_load_conservation_911  -1
    load_0_17_15  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_789  -30
    arc_0_17_16  connected_order_arc_790  -17
    arc_0_17_16  in_degree_913  1
    arc_0_17_16  out_degree_918  1
    arc_0_17_16  original_T_including_depot_unload_937  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_789  1
    load_0_17_16  free_load_conservation_917  -1
    load_0_17_16  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_791  -30
    arc_0_17_18  connected_order_arc_792  -17
    arc_0_17_18  out_degree_918  1
    arc_0_17_18  in_degree_925  1
    arc_0_17_18  original_T_including_depot_unload_937  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_791  1
    load_0_17_18  free_load_conservation_923  1
    load_0_17_18  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_793  -30
    arc_0_18_0  depot_return_or_bypass_825  1
    arc_0_18_0  out_degree_924  1
    arc_0_18_0  original_T_including_depot_unload_937  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_793  1
    load_0_18_0  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_794  -30
    arc_0_18_1  connected_order_arc_795  -17
    arc_0_18_1  in_degree_827  1
    arc_0_18_1  out_degree_924  1
    arc_0_18_1  original_T_including_depot_unload_937  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_794  1
    load_0_18_1  segment_load_conservation_830  -1
    load_0_18_1  segment_prefix_lb_831  1
    load_0_18_1  segment_prefix_ub_832  1
    load_0_18_1  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_796  -30
    arc_0_18_2  connected_order_arc_797  -17
    arc_0_18_2  in_degree_834  1
    arc_0_18_2  out_degree_924  1
    arc_0_18_2  original_T_including_depot_unload_937  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_796  1
    load_0_18_2  segment_load_conservation_837  -1
    load_0_18_2  segment_prefix_lb_838  1
    load_0_18_2  segment_prefix_ub_839  1
    load_0_18_2  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_798  -30
    arc_0_18_3  connected_order_arc_799  -17
    arc_0_18_3  in_degree_841  1
    arc_0_18_3  out_degree_924  1
    arc_0_18_3  original_T_including_depot_unload_937  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_798  1
    load_0_18_3  segment_load_conservation_844  -1
    load_0_18_3  segment_prefix_lb_845  1
    load_0_18_3  segment_prefix_ub_846  1
    load_0_18_3  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_800  -30
    arc_0_18_4  connected_order_arc_801  -17
    arc_0_18_4  in_degree_848  1
    arc_0_18_4  out_degree_924  1
    arc_0_18_4  original_T_including_depot_unload_937  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_800  1
    load_0_18_4  segment_load_conservation_851  -1
    load_0_18_4  segment_prefix_lb_852  1
    load_0_18_4  segment_prefix_ub_853  1
    load_0_18_4  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_802  -30
    arc_0_18_5  connected_order_arc_803  -17
    arc_0_18_5  in_degree_855  1
    arc_0_18_5  out_degree_924  1
    arc_0_18_5  original_T_including_depot_unload_937  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_802  1
    load_0_18_5  segment_load_conservation_858  -1
    load_0_18_5  segment_prefix_lb_859  1
    load_0_18_5  segment_prefix_ub_860  1
    load_0_18_5  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_804  -30
    arc_0_18_6  connected_order_arc_805  -17
    arc_0_18_6  in_degree_862  1
    arc_0_18_6  out_degree_924  1
    arc_0_18_6  original_T_including_depot_unload_937  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_804  1
    load_0_18_6  segment_load_conservation_865  -1
    load_0_18_6  segment_prefix_lb_866  1
    load_0_18_6  segment_prefix_ub_867  1
    load_0_18_6  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_7  arc_capacity_806  -30
    arc_0_18_7  connected_order_arc_807  -17
    arc_0_18_7  in_degree_869  1
    arc_0_18_7  out_degree_924  1
    arc_0_18_7  original_T_including_depot_unload_937  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_7  arc_capacity_806  1
    load_0_18_7  segment_load_conservation_872  -1
    load_0_18_7  segment_prefix_lb_873  1
    load_0_18_7  segment_prefix_ub_874  1
    load_0_18_7  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_8  arc_capacity_808  -30
    arc_0_18_8  connected_order_arc_809  -17
    arc_0_18_8  in_degree_876  1
    arc_0_18_8  out_degree_924  1
    arc_0_18_8  original_T_including_depot_unload_937  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_8  arc_capacity_808  1
    load_0_18_8  segment_load_conservation_879  -1
    load_0_18_8  segment_prefix_lb_880  1
    load_0_18_8  segment_prefix_ub_881  1
    load_0_18_8  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_11  arc_capacity_810  -30
    arc_0_18_11  connected_order_arc_811  -17
    arc_0_18_11  in_degree_883  1
    arc_0_18_11  out_degree_924  1
    arc_0_18_11  original_T_including_depot_unload_937  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_11  arc_capacity_810  1
    load_0_18_11  free_load_conservation_887  -1
    load_0_18_11  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_812  -30
    arc_0_18_12  connected_order_arc_813  -17
    arc_0_18_12  in_degree_889  1
    arc_0_18_12  out_degree_924  1
    arc_0_18_12  original_T_including_depot_unload_937  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_812  1
    load_0_18_12  free_load_conservation_893  -1
    load_0_18_12  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_814  -30
    arc_0_18_13  connected_order_arc_815  -17
    arc_0_18_13  in_degree_895  1
    arc_0_18_13  out_degree_924  1
    arc_0_18_13  original_T_including_depot_unload_937  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_814  1
    load_0_18_13  free_load_conservation_899  -1
    load_0_18_13  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_816  -30
    arc_0_18_14  connected_order_arc_817  -17
    arc_0_18_14  in_degree_901  1
    arc_0_18_14  out_degree_924  1
    arc_0_18_14  original_T_including_depot_unload_937  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_816  1
    load_0_18_14  free_load_conservation_905  -1
    load_0_18_14  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_818  -30
    arc_0_18_15  connected_order_arc_819  -17
    arc_0_18_15  in_degree_907  1
    arc_0_18_15  out_degree_924  1
    arc_0_18_15  original_T_including_depot_unload_937  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_818  1
    load_0_18_15  free_load_conservation_911  -1
    load_0_18_15  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_820  -30
    arc_0_18_16  connected_order_arc_821  -17
    arc_0_18_16  in_degree_913  1
    arc_0_18_16  out_degree_924  1
    arc_0_18_16  original_T_including_depot_unload_937  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_820  1
    load_0_18_16  free_load_conservation_917  -1
    load_0_18_16  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_822  -30
    arc_0_18_17  connected_order_arc_823  -17
    arc_0_18_17  in_degree_919  1
    arc_0_18_17  out_degree_924  1
    arc_0_18_17  original_T_including_depot_unload_937  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_822  1
    load_0_18_17  free_load_conservation_923  -1
    load_0_18_17  free_load_conservation_929  1
    visit_1_9  out_degree_1141  -1
    visit_1_9  in_degree_1142  -1
    visit_1_9  order_active_lb_1143  -1
    visit_1_9  order_active_ub_1144  -10
    order_1_9  connected_order_arc_951  -1
    order_1_9  connected_order_arc_953  -1
    order_1_9  connected_order_arc_955  -1
    order_1_9  connected_order_arc_957  -1
    order_1_9  connected_order_arc_959  -1
    order_1_9  connected_order_arc_961  -1
    order_1_9  connected_order_arc_963  -1
    order_1_9  connected_order_arc_965  -1
    order_1_9  connected_order_arc_967  -1
    order_1_9  connected_order_arc_970  1
    order_1_9  connected_order_arc_989  1
    order_1_9  connected_order_arc_1008  1
    order_1_9  connected_order_arc_1027  1
    order_1_9  connected_order_arc_1046  1
    order_1_9  connected_order_arc_1065  1
    order_1_9  connected_order_arc_1084  1
    order_1_9  connected_order_arc_1103  1
    order_1_9  connected_order_arc_1122  1
    order_1_9  order_active_lb_1143  1
    order_1_9  order_active_ub_1144  1
    order_1_9  fixed_segment_relative_order_1203  -1
    visit_1_10  out_degree_1148  -1
    visit_1_10  in_degree_1149  -1
    visit_1_10  order_active_lb_1150  -1
    visit_1_10  order_active_ub_1151  -10
    order_1_10  connected_order_arc_951  1
    order_1_10  connected_order_arc_970  -1
    order_1_10  connected_order_arc_972  -1
    order_1_10  connected_order_arc_974  -1
    order_1_10  connected_order_arc_976  -1
    order_1_10  connected_order_arc_978  -1
    order_1_10  connected_order_arc_980  -1
    order_1_10  connected_order_arc_982  -1
    order_1_10  connected_order_arc_984  -1
    order_1_10  connected_order_arc_986  -1
    order_1_10  connected_order_arc_991  1
    order_1_10  connected_order_arc_1010  1
    order_1_10  connected_order_arc_1029  1
    order_1_10  connected_order_arc_1048  1
    order_1_10  connected_order_arc_1067  1
    order_1_10  connected_order_arc_1086  1
    order_1_10  connected_order_arc_1105  1
    order_1_10  connected_order_arc_1124  1
    order_1_10  order_active_lb_1150  1
    order_1_10  order_active_ub_1151  1
    order_1_10  fixed_segment_relative_order_1203  1
    visit_1_11  out_degree_1155  -1
    visit_1_11  in_degree_1156  -1
    visit_1_11  order_active_lb_1157  -1
    visit_1_11  order_active_ub_1158  -10
    visit_1_11  service_visit_def_1159  -1
    order_1_11  connected_order_arc_953  1
    order_1_11  connected_order_arc_972  1
    order_1_11  connected_order_arc_989  -1
    order_1_11  connected_order_arc_991  -1
    order_1_11  connected_order_arc_993  -1
    order_1_11  connected_order_arc_995  -1
    order_1_11  connected_order_arc_997  -1
    order_1_11  connected_order_arc_999  -1
    order_1_11  connected_order_arc_1001  -1
    order_1_11  connected_order_arc_1003  -1
    order_1_11  connected_order_arc_1005  -1
    order_1_11  connected_order_arc_1012  1
    order_1_11  connected_order_arc_1031  1
    order_1_11  connected_order_arc_1050  1
    order_1_11  connected_order_arc_1069  1
    order_1_11  connected_order_arc_1088  1
    order_1_11  connected_order_arc_1107  1
    order_1_11  connected_order_arc_1126  1
    order_1_11  order_active_lb_1157  1
    order_1_11  order_active_ub_1158  1
    visit_1_12  out_degree_1161  -1
    visit_1_12  in_degree_1162  -1
    visit_1_12  order_active_lb_1163  -1
    visit_1_12  order_active_ub_1164  -10
    visit_1_12  service_visit_def_1165  -1
    order_1_12  connected_order_arc_955  1
    order_1_12  connected_order_arc_974  1
    order_1_12  connected_order_arc_993  1
    order_1_12  connected_order_arc_1008  -1
    order_1_12  connected_order_arc_1010  -1
    order_1_12  connected_order_arc_1012  -1
    order_1_12  connected_order_arc_1014  -1
    order_1_12  connected_order_arc_1016  -1
    order_1_12  connected_order_arc_1018  -1
    order_1_12  connected_order_arc_1020  -1
    order_1_12  connected_order_arc_1022  -1
    order_1_12  connected_order_arc_1024  -1
    order_1_12  connected_order_arc_1033  1
    order_1_12  connected_order_arc_1052  1
    order_1_12  connected_order_arc_1071  1
    order_1_12  connected_order_arc_1090  1
    order_1_12  connected_order_arc_1109  1
    order_1_12  connected_order_arc_1128  1
    order_1_12  order_active_lb_1163  1
    order_1_12  order_active_ub_1164  1
    visit_1_13  out_degree_1167  -1
    visit_1_13  in_degree_1168  -1
    visit_1_13  order_active_lb_1169  -1
    visit_1_13  order_active_ub_1170  -10
    visit_1_13  service_visit_def_1171  -1
    order_1_13  connected_order_arc_957  1
    order_1_13  connected_order_arc_976  1
    order_1_13  connected_order_arc_995  1
    order_1_13  connected_order_arc_1014  1
    order_1_13  connected_order_arc_1027  -1
    order_1_13  connected_order_arc_1029  -1
    order_1_13  connected_order_arc_1031  -1
    order_1_13  connected_order_arc_1033  -1
    order_1_13  connected_order_arc_1035  -1
    order_1_13  connected_order_arc_1037  -1
    order_1_13  connected_order_arc_1039  -1
    order_1_13  connected_order_arc_1041  -1
    order_1_13  connected_order_arc_1043  -1
    order_1_13  connected_order_arc_1054  1
    order_1_13  connected_order_arc_1073  1
    order_1_13  connected_order_arc_1092  1
    order_1_13  connected_order_arc_1111  1
    order_1_13  connected_order_arc_1130  1
    order_1_13  order_active_lb_1169  1
    order_1_13  order_active_ub_1170  1
    visit_1_14  out_degree_1173  -1
    visit_1_14  in_degree_1174  -1
    visit_1_14  order_active_lb_1175  -1
    visit_1_14  order_active_ub_1176  -10
    visit_1_14  service_visit_def_1177  -1
    order_1_14  connected_order_arc_959  1
    order_1_14  connected_order_arc_978  1
    order_1_14  connected_order_arc_997  1
    order_1_14  connected_order_arc_1016  1
    order_1_14  connected_order_arc_1035  1
    order_1_14  connected_order_arc_1046  -1
    order_1_14  connected_order_arc_1048  -1
    order_1_14  connected_order_arc_1050  -1
    order_1_14  connected_order_arc_1052  -1
    order_1_14  connected_order_arc_1054  -1
    order_1_14  connected_order_arc_1056  -1
    order_1_14  connected_order_arc_1058  -1
    order_1_14  connected_order_arc_1060  -1
    order_1_14  connected_order_arc_1062  -1
    order_1_14  connected_order_arc_1075  1
    order_1_14  connected_order_arc_1094  1
    order_1_14  connected_order_arc_1113  1
    order_1_14  connected_order_arc_1132  1
    order_1_14  order_active_lb_1175  1
    order_1_14  order_active_ub_1176  1
    visit_1_15  out_degree_1179  -1
    visit_1_15  in_degree_1180  -1
    visit_1_15  order_active_lb_1181  -1
    visit_1_15  order_active_ub_1182  -10
    visit_1_15  service_visit_def_1183  -1
    order_1_15  connected_order_arc_961  1
    order_1_15  connected_order_arc_980  1
    order_1_15  connected_order_arc_999  1
    order_1_15  connected_order_arc_1018  1
    order_1_15  connected_order_arc_1037  1
    order_1_15  connected_order_arc_1056  1
    order_1_15  connected_order_arc_1065  -1
    order_1_15  connected_order_arc_1067  -1
    order_1_15  connected_order_arc_1069  -1
    order_1_15  connected_order_arc_1071  -1
    order_1_15  connected_order_arc_1073  -1
    order_1_15  connected_order_arc_1075  -1
    order_1_15  connected_order_arc_1077  -1
    order_1_15  connected_order_arc_1079  -1
    order_1_15  connected_order_arc_1081  -1
    order_1_15  connected_order_arc_1096  1
    order_1_15  connected_order_arc_1115  1
    order_1_15  connected_order_arc_1134  1
    order_1_15  order_active_lb_1181  1
    order_1_15  order_active_ub_1182  1
    visit_1_16  out_degree_1185  -1
    visit_1_16  in_degree_1186  -1
    visit_1_16  order_active_lb_1187  -1
    visit_1_16  order_active_ub_1188  -10
    visit_1_16  service_visit_def_1189  -1
    order_1_16  connected_order_arc_963  1
    order_1_16  connected_order_arc_982  1
    order_1_16  connected_order_arc_1001  1
    order_1_16  connected_order_arc_1020  1
    order_1_16  connected_order_arc_1039  1
    order_1_16  connected_order_arc_1058  1
    order_1_16  connected_order_arc_1077  1
    order_1_16  connected_order_arc_1084  -1
    order_1_16  connected_order_arc_1086  -1
    order_1_16  connected_order_arc_1088  -1
    order_1_16  connected_order_arc_1090  -1
    order_1_16  connected_order_arc_1092  -1
    order_1_16  connected_order_arc_1094  -1
    order_1_16  connected_order_arc_1096  -1
    order_1_16  connected_order_arc_1098  -1
    order_1_16  connected_order_arc_1100  -1
    order_1_16  connected_order_arc_1117  1
    order_1_16  connected_order_arc_1136  1
    order_1_16  order_active_lb_1187  1
    order_1_16  order_active_ub_1188  1
    visit_1_17  out_degree_1191  -1
    visit_1_17  in_degree_1192  -1
    visit_1_17  order_active_lb_1193  -1
    visit_1_17  order_active_ub_1194  -10
    visit_1_17  service_visit_def_1195  -1
    order_1_17  connected_order_arc_965  1
    order_1_17  connected_order_arc_984  1
    order_1_17  connected_order_arc_1003  1
    order_1_17  connected_order_arc_1022  1
    order_1_17  connected_order_arc_1041  1
    order_1_17  connected_order_arc_1060  1
    order_1_17  connected_order_arc_1079  1
    order_1_17  connected_order_arc_1098  1
    order_1_17  connected_order_arc_1103  -1
    order_1_17  connected_order_arc_1105  -1
    order_1_17  connected_order_arc_1107  -1
    order_1_17  connected_order_arc_1109  -1
    order_1_17  connected_order_arc_1111  -1
    order_1_17  connected_order_arc_1113  -1
    order_1_17  connected_order_arc_1115  -1
    order_1_17  connected_order_arc_1117  -1
    order_1_17  connected_order_arc_1119  -1
    order_1_17  connected_order_arc_1138  1
    order_1_17  order_active_lb_1193  1
    order_1_17  order_active_ub_1194  1
    visit_1_18  out_degree_1197  -1
    visit_1_18  in_degree_1198  -1
    visit_1_18  order_active_lb_1199  -1
    visit_1_18  order_active_ub_1200  -10
    visit_1_18  service_visit_def_1201  -1
    order_1_18  connected_order_arc_967  1
    order_1_18  connected_order_arc_986  1
    order_1_18  connected_order_arc_1005  1
    order_1_18  connected_order_arc_1024  1
    order_1_18  connected_order_arc_1043  1
    order_1_18  connected_order_arc_1062  1
    order_1_18  connected_order_arc_1081  1
    order_1_18  connected_order_arc_1100  1
    order_1_18  connected_order_arc_1119  1
    order_1_18  connected_order_arc_1122  -1
    order_1_18  connected_order_arc_1124  -1
    order_1_18  connected_order_arc_1126  -1
    order_1_18  connected_order_arc_1128  -1
    order_1_18  connected_order_arc_1130  -1
    order_1_18  connected_order_arc_1132  -1
    order_1_18  connected_order_arc_1134  -1
    order_1_18  connected_order_arc_1136  -1
    order_1_18  connected_order_arc_1138  -1
    order_1_18  order_active_lb_1199  1
    order_1_18  order_active_ub_1200  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_938  -30
    arc_1_0_0  depot_departure_or_bypass_1139  1
    arc_1_0_0  depot_return_or_bypass_1140  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_938  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_939  -30
    arc_1_0_9  depot_departure_or_bypass_1139  1
    arc_1_0_9  in_degree_1142  1
    arc_1_0_9  original_T_including_depot_unload_1204  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_939  1
    load_1_0_9  segment_load_conservation_1145  -1
    load_1_0_9  segment_prefix_lb_1146  1
    load_1_0_9  segment_prefix_ub_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_940  -30
    arc_1_0_10  depot_departure_or_bypass_1139  1
    arc_1_0_10  in_degree_1149  1
    arc_1_0_10  original_T_including_depot_unload_1204  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_940  1
    load_1_0_10  segment_load_conservation_1152  -1
    load_1_0_10  segment_prefix_lb_1153  1
    load_1_0_10  segment_prefix_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_941  -30
    arc_1_0_11  depot_departure_or_bypass_1139  1
    arc_1_0_11  in_degree_1156  1
    arc_1_0_11  original_T_including_depot_unload_1204  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_941  1
    load_1_0_11  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_942  -30
    arc_1_0_12  depot_departure_or_bypass_1139  1
    arc_1_0_12  in_degree_1162  1
    arc_1_0_12  original_T_including_depot_unload_1204  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_942  1
    load_1_0_12  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_943  -30
    arc_1_0_13  depot_departure_or_bypass_1139  1
    arc_1_0_13  in_degree_1168  1
    arc_1_0_13  original_T_including_depot_unload_1204  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_943  1
    load_1_0_13  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_944  -30
    arc_1_0_14  depot_departure_or_bypass_1139  1
    arc_1_0_14  in_degree_1174  1
    arc_1_0_14  original_T_including_depot_unload_1204  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_944  1
    load_1_0_14  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_945  -30
    arc_1_0_15  depot_departure_or_bypass_1139  1
    arc_1_0_15  in_degree_1180  1
    arc_1_0_15  original_T_including_depot_unload_1204  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_945  1
    load_1_0_15  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_946  -30
    arc_1_0_16  depot_departure_or_bypass_1139  1
    arc_1_0_16  in_degree_1186  1
    arc_1_0_16  original_T_including_depot_unload_1204  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_946  1
    load_1_0_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_947  -30
    arc_1_0_17  depot_departure_or_bypass_1139  1
    arc_1_0_17  in_degree_1192  1
    arc_1_0_17  original_T_including_depot_unload_1204  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_947  1
    load_1_0_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_948  -30
    arc_1_0_18  depot_departure_or_bypass_1139  1
    arc_1_0_18  in_degree_1198  1
    arc_1_0_18  original_T_including_depot_unload_1204  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_948  1
    load_1_0_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_949  -30
    arc_1_9_0  depot_return_or_bypass_1140  1
    arc_1_9_0  out_degree_1141  1
    arc_1_9_0  original_T_including_depot_unload_1204  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_949  1
    load_1_9_0  segment_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_950  -30
    arc_1_9_10  connected_order_arc_951  -11
    arc_1_9_10  out_degree_1141  1
    arc_1_9_10  in_degree_1149  1
    arc_1_9_10  original_T_including_depot_unload_1204  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_950  1
    load_1_9_10  segment_load_conservation_1145  1
    load_1_9_10  segment_load_conservation_1152  -1
    load_1_9_10  segment_prefix_lb_1153  1
    load_1_9_10  segment_prefix_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_952  -30
    arc_1_9_11  connected_order_arc_953  -11
    arc_1_9_11  out_degree_1141  1
    arc_1_9_11  in_degree_1156  1
    arc_1_9_11  original_T_including_depot_unload_1204  4.0654406432457854e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_952  1
    load_1_9_11  segment_load_conservation_1145  1
    load_1_9_11  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_954  -30
    arc_1_9_12  connected_order_arc_955  -11
    arc_1_9_12  out_degree_1141  1
    arc_1_9_12  in_degree_1162  1
    arc_1_9_12  original_T_including_depot_unload_1204  3.8248940301741582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_954  1
    load_1_9_12  segment_load_conservation_1145  1
    load_1_9_12  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_956  -30
    arc_1_9_13  connected_order_arc_957  -11
    arc_1_9_13  out_degree_1141  1
    arc_1_9_13  in_degree_1168  1
    arc_1_9_13  original_T_including_depot_unload_1204  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_956  1
    load_1_9_13  segment_load_conservation_1145  1
    load_1_9_13  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_958  -30
    arc_1_9_14  connected_order_arc_959  -11
    arc_1_9_14  out_degree_1141  1
    arc_1_9_14  in_degree_1174  1
    arc_1_9_14  original_T_including_depot_unload_1204  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_958  1
    load_1_9_14  segment_load_conservation_1145  1
    load_1_9_14  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_960  -30
    arc_1_9_15  connected_order_arc_961  -11
    arc_1_9_15  out_degree_1141  1
    arc_1_9_15  in_degree_1180  1
    arc_1_9_15  original_T_including_depot_unload_1204  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_960  1
    load_1_9_15  segment_load_conservation_1145  1
    load_1_9_15  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_962  -30
    arc_1_9_16  connected_order_arc_963  -11
    arc_1_9_16  out_degree_1141  1
    arc_1_9_16  in_degree_1186  1
    arc_1_9_16  original_T_including_depot_unload_1204  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_962  1
    load_1_9_16  segment_load_conservation_1145  1
    load_1_9_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_964  -30
    arc_1_9_17  connected_order_arc_965  -11
    arc_1_9_17  out_degree_1141  1
    arc_1_9_17  in_degree_1192  1
    arc_1_9_17  original_T_including_depot_unload_1204  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_964  1
    load_1_9_17  segment_load_conservation_1145  1
    load_1_9_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_966  -30
    arc_1_9_18  connected_order_arc_967  -11
    arc_1_9_18  out_degree_1141  1
    arc_1_9_18  in_degree_1198  1
    arc_1_9_18  original_T_including_depot_unload_1204  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_966  1
    load_1_9_18  segment_load_conservation_1145  1
    load_1_9_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_968  -30
    arc_1_10_0  depot_return_or_bypass_1140  1
    arc_1_10_0  out_degree_1148  1
    arc_1_10_0  original_T_including_depot_unload_1204  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_968  1
    load_1_10_0  segment_load_conservation_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_969  -30
    arc_1_10_9  connected_order_arc_970  -11
    arc_1_10_9  in_degree_1142  1
    arc_1_10_9  out_degree_1148  1
    arc_1_10_9  original_T_including_depot_unload_1204  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_969  1
    load_1_10_9  segment_load_conservation_1145  -1
    load_1_10_9  segment_prefix_lb_1146  1
    load_1_10_9  segment_prefix_ub_1147  1
    load_1_10_9  segment_load_conservation_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_971  -30
    arc_1_10_11  connected_order_arc_972  -11
    arc_1_10_11  out_degree_1148  1
    arc_1_10_11  in_degree_1156  1
    arc_1_10_11  original_T_including_depot_unload_1204  3.9583831508648805e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_971  1
    load_1_10_11  segment_load_conservation_1152  1
    load_1_10_11  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_973  -30
    arc_1_10_12  connected_order_arc_974  -11
    arc_1_10_12  out_degree_1148  1
    arc_1_10_12  in_degree_1162  1
    arc_1_10_12  original_T_including_depot_unload_1204  3.7172787566213742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_973  1
    load_1_10_12  segment_load_conservation_1152  1
    load_1_10_12  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_975  -30
    arc_1_10_13  connected_order_arc_976  -11
    arc_1_10_13  out_degree_1148  1
    arc_1_10_13  in_degree_1168  1
    arc_1_10_13  original_T_including_depot_unload_1204  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_975  1
    load_1_10_13  segment_load_conservation_1152  1
    load_1_10_13  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_977  -30
    arc_1_10_14  connected_order_arc_978  -11
    arc_1_10_14  out_degree_1148  1
    arc_1_10_14  in_degree_1174  1
    arc_1_10_14  original_T_including_depot_unload_1204  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_977  1
    load_1_10_14  segment_load_conservation_1152  1
    load_1_10_14  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_979  -30
    arc_1_10_15  connected_order_arc_980  -11
    arc_1_10_15  out_degree_1148  1
    arc_1_10_15  in_degree_1180  1
    arc_1_10_15  original_T_including_depot_unload_1204  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_979  1
    load_1_10_15  segment_load_conservation_1152  1
    load_1_10_15  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_981  -30
    arc_1_10_16  connected_order_arc_982  -11
    arc_1_10_16  out_degree_1148  1
    arc_1_10_16  in_degree_1186  1
    arc_1_10_16  original_T_including_depot_unload_1204  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_981  1
    load_1_10_16  segment_load_conservation_1152  1
    load_1_10_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_983  -30
    arc_1_10_17  connected_order_arc_984  -11
    arc_1_10_17  out_degree_1148  1
    arc_1_10_17  in_degree_1192  1
    arc_1_10_17  original_T_including_depot_unload_1204  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_983  1
    load_1_10_17  segment_load_conservation_1152  1
    load_1_10_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_985  -30
    arc_1_10_18  connected_order_arc_986  -11
    arc_1_10_18  out_degree_1148  1
    arc_1_10_18  in_degree_1198  1
    arc_1_10_18  original_T_including_depot_unload_1204  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_985  1
    load_1_10_18  segment_load_conservation_1152  1
    load_1_10_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_987  -30
    arc_1_11_0  depot_return_or_bypass_1140  1
    arc_1_11_0  out_degree_1155  1
    arc_1_11_0  original_T_including_depot_unload_1204  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_987  1
    load_1_11_0  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_988  -30
    arc_1_11_9  connected_order_arc_989  -11
    arc_1_11_9  in_degree_1142  1
    arc_1_11_9  out_degree_1155  1
    arc_1_11_9  original_T_including_depot_unload_1204  4.0654406432457854e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_988  1
    load_1_11_9  segment_load_conservation_1145  -1
    load_1_11_9  segment_prefix_lb_1146  1
    load_1_11_9  segment_prefix_ub_1147  1
    load_1_11_9  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_990  -30
    arc_1_11_10  connected_order_arc_991  -11
    arc_1_11_10  in_degree_1149  1
    arc_1_11_10  out_degree_1155  1
    arc_1_11_10  original_T_including_depot_unload_1204  3.9583831508648805e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_990  1
    load_1_11_10  segment_load_conservation_1152  -1
    load_1_11_10  segment_prefix_lb_1153  1
    load_1_11_10  segment_prefix_ub_1154  1
    load_1_11_10  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_992  -30
    arc_1_11_12  connected_order_arc_993  -11
    arc_1_11_12  out_degree_1155  1
    arc_1_11_12  in_degree_1162  1
    arc_1_11_12  original_T_including_depot_unload_1204  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_992  1
    load_1_11_12  free_load_conservation_1160  1
    load_1_11_12  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_994  -30
    arc_1_11_13  connected_order_arc_995  -11
    arc_1_11_13  out_degree_1155  1
    arc_1_11_13  in_degree_1168  1
    arc_1_11_13  original_T_including_depot_unload_1204  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_994  1
    load_1_11_13  free_load_conservation_1160  1
    load_1_11_13  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_996  -30
    arc_1_11_14  connected_order_arc_997  -11
    arc_1_11_14  out_degree_1155  1
    arc_1_11_14  in_degree_1174  1
    arc_1_11_14  original_T_including_depot_unload_1204  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_996  1
    load_1_11_14  free_load_conservation_1160  1
    load_1_11_14  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_998  -30
    arc_1_11_15  connected_order_arc_999  -11
    arc_1_11_15  out_degree_1155  1
    arc_1_11_15  in_degree_1180  1
    arc_1_11_15  original_T_including_depot_unload_1204  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_998  1
    load_1_11_15  free_load_conservation_1160  1
    load_1_11_15  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_1000  -30
    arc_1_11_16  connected_order_arc_1001  -11
    arc_1_11_16  out_degree_1155  1
    arc_1_11_16  in_degree_1186  1
    arc_1_11_16  original_T_including_depot_unload_1204  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_1000  1
    load_1_11_16  free_load_conservation_1160  1
    load_1_11_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_17  arc_capacity_1002  -30
    arc_1_11_17  connected_order_arc_1003  -11
    arc_1_11_17  out_degree_1155  1
    arc_1_11_17  in_degree_1192  1
    arc_1_11_17  original_T_including_depot_unload_1204  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_17  arc_capacity_1002  1
    load_1_11_17  free_load_conservation_1160  1
    load_1_11_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_18  arc_capacity_1004  -30
    arc_1_11_18  connected_order_arc_1005  -11
    arc_1_11_18  out_degree_1155  1
    arc_1_11_18  in_degree_1198  1
    arc_1_11_18  original_T_including_depot_unload_1204  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_18  arc_capacity_1004  1
    load_1_11_18  free_load_conservation_1160  1
    load_1_11_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_1006  -30
    arc_1_12_0  depot_return_or_bypass_1140  1
    arc_1_12_0  out_degree_1161  1
    arc_1_12_0  original_T_including_depot_unload_1204  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_1006  1
    load_1_12_0  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_1007  -30
    arc_1_12_9  connected_order_arc_1008  -11
    arc_1_12_9  in_degree_1142  1
    arc_1_12_9  out_degree_1161  1
    arc_1_12_9  original_T_including_depot_unload_1204  3.8248940301741582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_1007  1
    load_1_12_9  segment_load_conservation_1145  -1
    load_1_12_9  segment_prefix_lb_1146  1
    load_1_12_9  segment_prefix_ub_1147  1
    load_1_12_9  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_1009  -30
    arc_1_12_10  connected_order_arc_1010  -11
    arc_1_12_10  in_degree_1149  1
    arc_1_12_10  out_degree_1161  1
    arc_1_12_10  original_T_including_depot_unload_1204  3.7172787566213742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_1009  1
    load_1_12_10  segment_load_conservation_1152  -1
    load_1_12_10  segment_prefix_lb_1153  1
    load_1_12_10  segment_prefix_ub_1154  1
    load_1_12_10  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_1011  -30
    arc_1_12_11  connected_order_arc_1012  -11
    arc_1_12_11  in_degree_1156  1
    arc_1_12_11  out_degree_1161  1
    arc_1_12_11  original_T_including_depot_unload_1204  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_1011  1
    load_1_12_11  free_load_conservation_1160  -1
    load_1_12_11  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_1013  -30
    arc_1_12_13  connected_order_arc_1014  -11
    arc_1_12_13  out_degree_1161  1
    arc_1_12_13  in_degree_1168  1
    arc_1_12_13  original_T_including_depot_unload_1204  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_1013  1
    load_1_12_13  free_load_conservation_1166  1
    load_1_12_13  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_1015  -30
    arc_1_12_14  connected_order_arc_1016  -11
    arc_1_12_14  out_degree_1161  1
    arc_1_12_14  in_degree_1174  1
    arc_1_12_14  original_T_including_depot_unload_1204  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_1015  1
    load_1_12_14  free_load_conservation_1166  1
    load_1_12_14  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_1017  -30
    arc_1_12_15  connected_order_arc_1018  -11
    arc_1_12_15  out_degree_1161  1
    arc_1_12_15  in_degree_1180  1
    arc_1_12_15  original_T_including_depot_unload_1204  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_1017  1
    load_1_12_15  free_load_conservation_1166  1
    load_1_12_15  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_1019  -30
    arc_1_12_16  connected_order_arc_1020  -11
    arc_1_12_16  out_degree_1161  1
    arc_1_12_16  in_degree_1186  1
    arc_1_12_16  original_T_including_depot_unload_1204  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_1019  1
    load_1_12_16  free_load_conservation_1166  1
    load_1_12_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_1021  -30
    arc_1_12_17  connected_order_arc_1022  -11
    arc_1_12_17  out_degree_1161  1
    arc_1_12_17  in_degree_1192  1
    arc_1_12_17  original_T_including_depot_unload_1204  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_1021  1
    load_1_12_17  free_load_conservation_1166  1
    load_1_12_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_1023  -30
    arc_1_12_18  connected_order_arc_1024  -11
    arc_1_12_18  out_degree_1161  1
    arc_1_12_18  in_degree_1198  1
    arc_1_12_18  original_T_including_depot_unload_1204  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_1023  1
    load_1_12_18  free_load_conservation_1166  1
    load_1_12_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_1025  -30
    arc_1_13_0  depot_return_or_bypass_1140  1
    arc_1_13_0  out_degree_1167  1
    arc_1_13_0  original_T_including_depot_unload_1204  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_1025  1
    load_1_13_0  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_1026  -30
    arc_1_13_9  connected_order_arc_1027  -11
    arc_1_13_9  in_degree_1142  1
    arc_1_13_9  out_degree_1167  1
    arc_1_13_9  original_T_including_depot_unload_1204  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_1026  1
    load_1_13_9  segment_load_conservation_1145  -1
    load_1_13_9  segment_prefix_lb_1146  1
    load_1_13_9  segment_prefix_ub_1147  1
    load_1_13_9  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_1028  -30
    arc_1_13_10  connected_order_arc_1029  -11
    arc_1_13_10  in_degree_1149  1
    arc_1_13_10  out_degree_1167  1
    arc_1_13_10  original_T_including_depot_unload_1204  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_1028  1
    load_1_13_10  segment_load_conservation_1152  -1
    load_1_13_10  segment_prefix_lb_1153  1
    load_1_13_10  segment_prefix_ub_1154  1
    load_1_13_10  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_1030  -30
    arc_1_13_11  connected_order_arc_1031  -11
    arc_1_13_11  in_degree_1156  1
    arc_1_13_11  out_degree_1167  1
    arc_1_13_11  original_T_including_depot_unload_1204  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_1030  1
    load_1_13_11  free_load_conservation_1160  -1
    load_1_13_11  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_1032  -30
    arc_1_13_12  connected_order_arc_1033  -11
    arc_1_13_12  in_degree_1162  1
    arc_1_13_12  out_degree_1167  1
    arc_1_13_12  original_T_including_depot_unload_1204  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_1032  1
    load_1_13_12  free_load_conservation_1166  -1
    load_1_13_12  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1034  -30
    arc_1_13_14  connected_order_arc_1035  -11
    arc_1_13_14  out_degree_1167  1
    arc_1_13_14  in_degree_1174  1
    arc_1_13_14  original_T_including_depot_unload_1204  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1034  1
    load_1_13_14  free_load_conservation_1172  1
    load_1_13_14  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1036  -30
    arc_1_13_15  connected_order_arc_1037  -11
    arc_1_13_15  out_degree_1167  1
    arc_1_13_15  in_degree_1180  1
    arc_1_13_15  original_T_including_depot_unload_1204  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1036  1
    load_1_13_15  free_load_conservation_1172  1
    load_1_13_15  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1038  -30
    arc_1_13_16  connected_order_arc_1039  -11
    arc_1_13_16  out_degree_1167  1
    arc_1_13_16  in_degree_1186  1
    arc_1_13_16  original_T_including_depot_unload_1204  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1038  1
    load_1_13_16  free_load_conservation_1172  1
    load_1_13_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_1040  -30
    arc_1_13_17  connected_order_arc_1041  -11
    arc_1_13_17  out_degree_1167  1
    arc_1_13_17  in_degree_1192  1
    arc_1_13_17  original_T_including_depot_unload_1204  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_1040  1
    load_1_13_17  free_load_conservation_1172  1
    load_1_13_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_1042  -30
    arc_1_13_18  connected_order_arc_1043  -11
    arc_1_13_18  out_degree_1167  1
    arc_1_13_18  in_degree_1198  1
    arc_1_13_18  original_T_including_depot_unload_1204  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_1042  1
    load_1_13_18  free_load_conservation_1172  1
    load_1_13_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1044  -30
    arc_1_14_0  depot_return_or_bypass_1140  1
    arc_1_14_0  out_degree_1173  1
    arc_1_14_0  original_T_including_depot_unload_1204  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1044  1
    load_1_14_0  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1045  -30
    arc_1_14_9  connected_order_arc_1046  -11
    arc_1_14_9  in_degree_1142  1
    arc_1_14_9  out_degree_1173  1
    arc_1_14_9  original_T_including_depot_unload_1204  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1045  1
    load_1_14_9  segment_load_conservation_1145  -1
    load_1_14_9  segment_prefix_lb_1146  1
    load_1_14_9  segment_prefix_ub_1147  1
    load_1_14_9  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1047  -30
    arc_1_14_10  connected_order_arc_1048  -11
    arc_1_14_10  in_degree_1149  1
    arc_1_14_10  out_degree_1173  1
    arc_1_14_10  original_T_including_depot_unload_1204  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1047  1
    load_1_14_10  segment_load_conservation_1152  -1
    load_1_14_10  segment_prefix_lb_1153  1
    load_1_14_10  segment_prefix_ub_1154  1
    load_1_14_10  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1049  -30
    arc_1_14_11  connected_order_arc_1050  -11
    arc_1_14_11  in_degree_1156  1
    arc_1_14_11  out_degree_1173  1
    arc_1_14_11  original_T_including_depot_unload_1204  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1049  1
    load_1_14_11  free_load_conservation_1160  -1
    load_1_14_11  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1051  -30
    arc_1_14_12  connected_order_arc_1052  -11
    arc_1_14_12  in_degree_1162  1
    arc_1_14_12  out_degree_1173  1
    arc_1_14_12  original_T_including_depot_unload_1204  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1051  1
    load_1_14_12  free_load_conservation_1166  -1
    load_1_14_12  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1053  -30
    arc_1_14_13  connected_order_arc_1054  -11
    arc_1_14_13  in_degree_1168  1
    arc_1_14_13  out_degree_1173  1
    arc_1_14_13  original_T_including_depot_unload_1204  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1053  1
    load_1_14_13  free_load_conservation_1172  -1
    load_1_14_13  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1055  -30
    arc_1_14_15  connected_order_arc_1056  -11
    arc_1_14_15  out_degree_1173  1
    arc_1_14_15  in_degree_1180  1
    arc_1_14_15  original_T_including_depot_unload_1204  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1055  1
    load_1_14_15  free_load_conservation_1178  1
    load_1_14_15  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1057  -30
    arc_1_14_16  connected_order_arc_1058  -11
    arc_1_14_16  out_degree_1173  1
    arc_1_14_16  in_degree_1186  1
    arc_1_14_16  original_T_including_depot_unload_1204  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1057  1
    load_1_14_16  free_load_conservation_1178  1
    load_1_14_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1059  -30
    arc_1_14_17  connected_order_arc_1060  -11
    arc_1_14_17  out_degree_1173  1
    arc_1_14_17  in_degree_1192  1
    arc_1_14_17  original_T_including_depot_unload_1204  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1059  1
    load_1_14_17  free_load_conservation_1178  1
    load_1_14_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1061  -30
    arc_1_14_18  connected_order_arc_1062  -11
    arc_1_14_18  out_degree_1173  1
    arc_1_14_18  in_degree_1198  1
    arc_1_14_18  original_T_including_depot_unload_1204  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1061  1
    load_1_14_18  free_load_conservation_1178  1
    load_1_14_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1063  -30
    arc_1_15_0  depot_return_or_bypass_1140  1
    arc_1_15_0  out_degree_1179  1
    arc_1_15_0  original_T_including_depot_unload_1204  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1063  1
    load_1_15_0  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1064  -30
    arc_1_15_9  connected_order_arc_1065  -11
    arc_1_15_9  in_degree_1142  1
    arc_1_15_9  out_degree_1179  1
    arc_1_15_9  original_T_including_depot_unload_1204  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1064  1
    load_1_15_9  segment_load_conservation_1145  -1
    load_1_15_9  segment_prefix_lb_1146  1
    load_1_15_9  segment_prefix_ub_1147  1
    load_1_15_9  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1066  -30
    arc_1_15_10  connected_order_arc_1067  -11
    arc_1_15_10  in_degree_1149  1
    arc_1_15_10  out_degree_1179  1
    arc_1_15_10  original_T_including_depot_unload_1204  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1066  1
    load_1_15_10  segment_load_conservation_1152  -1
    load_1_15_10  segment_prefix_lb_1153  1
    load_1_15_10  segment_prefix_ub_1154  1
    load_1_15_10  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1068  -30
    arc_1_15_11  connected_order_arc_1069  -11
    arc_1_15_11  in_degree_1156  1
    arc_1_15_11  out_degree_1179  1
    arc_1_15_11  original_T_including_depot_unload_1204  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1068  1
    load_1_15_11  free_load_conservation_1160  -1
    load_1_15_11  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1070  -30
    arc_1_15_12  connected_order_arc_1071  -11
    arc_1_15_12  in_degree_1162  1
    arc_1_15_12  out_degree_1179  1
    arc_1_15_12  original_T_including_depot_unload_1204  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1070  1
    load_1_15_12  free_load_conservation_1166  -1
    load_1_15_12  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1072  -30
    arc_1_15_13  connected_order_arc_1073  -11
    arc_1_15_13  in_degree_1168  1
    arc_1_15_13  out_degree_1179  1
    arc_1_15_13  original_T_including_depot_unload_1204  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1072  1
    load_1_15_13  free_load_conservation_1172  -1
    load_1_15_13  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1074  -30
    arc_1_15_14  connected_order_arc_1075  -11
    arc_1_15_14  in_degree_1174  1
    arc_1_15_14  out_degree_1179  1
    arc_1_15_14  original_T_including_depot_unload_1204  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1074  1
    load_1_15_14  free_load_conservation_1178  -1
    load_1_15_14  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1076  -30
    arc_1_15_16  connected_order_arc_1077  -11
    arc_1_15_16  out_degree_1179  1
    arc_1_15_16  in_degree_1186  1
    arc_1_15_16  original_T_including_depot_unload_1204  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1076  1
    load_1_15_16  free_load_conservation_1184  1
    load_1_15_16  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1078  -30
    arc_1_15_17  connected_order_arc_1079  -11
    arc_1_15_17  out_degree_1179  1
    arc_1_15_17  in_degree_1192  1
    arc_1_15_17  original_T_including_depot_unload_1204  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1078  1
    load_1_15_17  free_load_conservation_1184  1
    load_1_15_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1080  -30
    arc_1_15_18  connected_order_arc_1081  -11
    arc_1_15_18  out_degree_1179  1
    arc_1_15_18  in_degree_1198  1
    arc_1_15_18  original_T_including_depot_unload_1204  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1080  1
    load_1_15_18  free_load_conservation_1184  1
    load_1_15_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1082  -30
    arc_1_16_0  depot_return_or_bypass_1140  1
    arc_1_16_0  out_degree_1185  1
    arc_1_16_0  original_T_including_depot_unload_1204  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1082  1
    load_1_16_0  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1083  -30
    arc_1_16_9  connected_order_arc_1084  -11
    arc_1_16_9  in_degree_1142  1
    arc_1_16_9  out_degree_1185  1
    arc_1_16_9  original_T_including_depot_unload_1204  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1083  1
    load_1_16_9  segment_load_conservation_1145  -1
    load_1_16_9  segment_prefix_lb_1146  1
    load_1_16_9  segment_prefix_ub_1147  1
    load_1_16_9  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1085  -30
    arc_1_16_10  connected_order_arc_1086  -11
    arc_1_16_10  in_degree_1149  1
    arc_1_16_10  out_degree_1185  1
    arc_1_16_10  original_T_including_depot_unload_1204  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1085  1
    load_1_16_10  segment_load_conservation_1152  -1
    load_1_16_10  segment_prefix_lb_1153  1
    load_1_16_10  segment_prefix_ub_1154  1
    load_1_16_10  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1087  -30
    arc_1_16_11  connected_order_arc_1088  -11
    arc_1_16_11  in_degree_1156  1
    arc_1_16_11  out_degree_1185  1
    arc_1_16_11  original_T_including_depot_unload_1204  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1087  1
    load_1_16_11  free_load_conservation_1160  -1
    load_1_16_11  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1089  -30
    arc_1_16_12  connected_order_arc_1090  -11
    arc_1_16_12  in_degree_1162  1
    arc_1_16_12  out_degree_1185  1
    arc_1_16_12  original_T_including_depot_unload_1204  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1089  1
    load_1_16_12  free_load_conservation_1166  -1
    load_1_16_12  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1091  -30
    arc_1_16_13  connected_order_arc_1092  -11
    arc_1_16_13  in_degree_1168  1
    arc_1_16_13  out_degree_1185  1
    arc_1_16_13  original_T_including_depot_unload_1204  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1091  1
    load_1_16_13  free_load_conservation_1172  -1
    load_1_16_13  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1093  -30
    arc_1_16_14  connected_order_arc_1094  -11
    arc_1_16_14  in_degree_1174  1
    arc_1_16_14  out_degree_1185  1
    arc_1_16_14  original_T_including_depot_unload_1204  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1093  1
    load_1_16_14  free_load_conservation_1178  -1
    load_1_16_14  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1095  -30
    arc_1_16_15  connected_order_arc_1096  -11
    arc_1_16_15  in_degree_1180  1
    arc_1_16_15  out_degree_1185  1
    arc_1_16_15  original_T_including_depot_unload_1204  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1095  1
    load_1_16_15  free_load_conservation_1184  -1
    load_1_16_15  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1097  -30
    arc_1_16_17  connected_order_arc_1098  -11
    arc_1_16_17  out_degree_1185  1
    arc_1_16_17  in_degree_1192  1
    arc_1_16_17  original_T_including_depot_unload_1204  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1097  1
    load_1_16_17  free_load_conservation_1190  1
    load_1_16_17  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1099  -30
    arc_1_16_18  connected_order_arc_1100  -11
    arc_1_16_18  out_degree_1185  1
    arc_1_16_18  in_degree_1198  1
    arc_1_16_18  original_T_including_depot_unload_1204  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1099  1
    load_1_16_18  free_load_conservation_1190  1
    load_1_16_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1101  -30
    arc_1_17_0  depot_return_or_bypass_1140  1
    arc_1_17_0  out_degree_1191  1
    arc_1_17_0  original_T_including_depot_unload_1204  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1101  1
    load_1_17_0  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1102  -30
    arc_1_17_9  connected_order_arc_1103  -11
    arc_1_17_9  in_degree_1142  1
    arc_1_17_9  out_degree_1191  1
    arc_1_17_9  original_T_including_depot_unload_1204  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1102  1
    load_1_17_9  segment_load_conservation_1145  -1
    load_1_17_9  segment_prefix_lb_1146  1
    load_1_17_9  segment_prefix_ub_1147  1
    load_1_17_9  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1104  -30
    arc_1_17_10  connected_order_arc_1105  -11
    arc_1_17_10  in_degree_1149  1
    arc_1_17_10  out_degree_1191  1
    arc_1_17_10  original_T_including_depot_unload_1204  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1104  1
    load_1_17_10  segment_load_conservation_1152  -1
    load_1_17_10  segment_prefix_lb_1153  1
    load_1_17_10  segment_prefix_ub_1154  1
    load_1_17_10  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_11  arc_capacity_1106  -30
    arc_1_17_11  connected_order_arc_1107  -11
    arc_1_17_11  in_degree_1156  1
    arc_1_17_11  out_degree_1191  1
    arc_1_17_11  original_T_including_depot_unload_1204  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_11  arc_capacity_1106  1
    load_1_17_11  free_load_conservation_1160  -1
    load_1_17_11  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_1108  -30
    arc_1_17_12  connected_order_arc_1109  -11
    arc_1_17_12  in_degree_1162  1
    arc_1_17_12  out_degree_1191  1
    arc_1_17_12  original_T_including_depot_unload_1204  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_1108  1
    load_1_17_12  free_load_conservation_1166  -1
    load_1_17_12  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1110  -30
    arc_1_17_13  connected_order_arc_1111  -11
    arc_1_17_13  in_degree_1168  1
    arc_1_17_13  out_degree_1191  1
    arc_1_17_13  original_T_including_depot_unload_1204  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1110  1
    load_1_17_13  free_load_conservation_1172  -1
    load_1_17_13  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1112  -30
    arc_1_17_14  connected_order_arc_1113  -11
    arc_1_17_14  in_degree_1174  1
    arc_1_17_14  out_degree_1191  1
    arc_1_17_14  original_T_including_depot_unload_1204  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1112  1
    load_1_17_14  free_load_conservation_1178  -1
    load_1_17_14  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1114  -30
    arc_1_17_15  connected_order_arc_1115  -11
    arc_1_17_15  in_degree_1180  1
    arc_1_17_15  out_degree_1191  1
    arc_1_17_15  original_T_including_depot_unload_1204  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1114  1
    load_1_17_15  free_load_conservation_1184  -1
    load_1_17_15  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1116  -30
    arc_1_17_16  connected_order_arc_1117  -11
    arc_1_17_16  in_degree_1186  1
    arc_1_17_16  out_degree_1191  1
    arc_1_17_16  original_T_including_depot_unload_1204  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1116  1
    load_1_17_16  free_load_conservation_1190  -1
    load_1_17_16  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1118  -30
    arc_1_17_18  connected_order_arc_1119  -11
    arc_1_17_18  out_degree_1191  1
    arc_1_17_18  in_degree_1198  1
    arc_1_17_18  original_T_including_depot_unload_1204  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1118  1
    load_1_17_18  free_load_conservation_1196  1
    load_1_17_18  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1120  -30
    arc_1_18_0  depot_return_or_bypass_1140  1
    arc_1_18_0  out_degree_1197  1
    arc_1_18_0  original_T_including_depot_unload_1204  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1120  1
    load_1_18_0  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1121  -30
    arc_1_18_9  connected_order_arc_1122  -11
    arc_1_18_9  in_degree_1142  1
    arc_1_18_9  out_degree_1197  1
    arc_1_18_9  original_T_including_depot_unload_1204  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1121  1
    load_1_18_9  segment_load_conservation_1145  -1
    load_1_18_9  segment_prefix_lb_1146  1
    load_1_18_9  segment_prefix_ub_1147  1
    load_1_18_9  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1123  -30
    arc_1_18_10  connected_order_arc_1124  -11
    arc_1_18_10  in_degree_1149  1
    arc_1_18_10  out_degree_1197  1
    arc_1_18_10  original_T_including_depot_unload_1204  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1123  1
    load_1_18_10  segment_load_conservation_1152  -1
    load_1_18_10  segment_prefix_lb_1153  1
    load_1_18_10  segment_prefix_ub_1154  1
    load_1_18_10  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_11  arc_capacity_1125  -30
    arc_1_18_11  connected_order_arc_1126  -11
    arc_1_18_11  in_degree_1156  1
    arc_1_18_11  out_degree_1197  1
    arc_1_18_11  original_T_including_depot_unload_1204  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_11  arc_capacity_1125  1
    load_1_18_11  free_load_conservation_1160  -1
    load_1_18_11  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_1127  -30
    arc_1_18_12  connected_order_arc_1128  -11
    arc_1_18_12  in_degree_1162  1
    arc_1_18_12  out_degree_1197  1
    arc_1_18_12  original_T_including_depot_unload_1204  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_1127  1
    load_1_18_12  free_load_conservation_1166  -1
    load_1_18_12  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1129  -30
    arc_1_18_13  connected_order_arc_1130  -11
    arc_1_18_13  in_degree_1168  1
    arc_1_18_13  out_degree_1197  1
    arc_1_18_13  original_T_including_depot_unload_1204  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1129  1
    load_1_18_13  free_load_conservation_1172  -1
    load_1_18_13  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1131  -30
    arc_1_18_14  connected_order_arc_1132  -11
    arc_1_18_14  in_degree_1174  1
    arc_1_18_14  out_degree_1197  1
    arc_1_18_14  original_T_including_depot_unload_1204  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1131  1
    load_1_18_14  free_load_conservation_1178  -1
    load_1_18_14  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1133  -30
    arc_1_18_15  connected_order_arc_1134  -11
    arc_1_18_15  in_degree_1180  1
    arc_1_18_15  out_degree_1197  1
    arc_1_18_15  original_T_including_depot_unload_1204  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1133  1
    load_1_18_15  free_load_conservation_1184  -1
    load_1_18_15  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1135  -30
    arc_1_18_16  connected_order_arc_1136  -11
    arc_1_18_16  in_degree_1186  1
    arc_1_18_16  out_degree_1197  1
    arc_1_18_16  original_T_including_depot_unload_1204  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1135  1
    load_1_18_16  free_load_conservation_1190  -1
    load_1_18_16  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1137  -30
    arc_1_18_17  connected_order_arc_1138  -11
    arc_1_18_17  in_degree_1192  1
    arc_1_18_17  out_degree_1197  1
    arc_1_18_17  original_T_including_depot_unload_1204  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1137  1
    load_1_18_17  free_load_conservation_1196  -1
    load_1_18_17  free_load_conservation_1202  1
RHS
    RHS1      OBJ       -3.5653365334833986e-01
    RHS1      onehot_19_12  1
    RHS1      onehot_15_19  1
    RHS1      onehot_18_54  1
    RHS1      onehot_16_63  1
    RHS1      onehot_17_100  1
    RHS1      onehot_12_135  1
    RHS1      onehot_11_170  1
    RHS1      onehot_9_177  1
    RHS1      stock_ub_181  17
    RHS1      parent_nonstrict_scope_182  5.6713365119737225e-01
    RHS1      normalization_239  1
    RHS1      connected_order_arc_330  -16
    RHS1      connected_order_arc_332  -16
    RHS1      connected_order_arc_334  -16
    RHS1      connected_order_arc_336  -16
    RHS1      connected_order_arc_338  -16
    RHS1      connected_order_arc_340  -16
    RHS1      connected_order_arc_342  -16
    RHS1      connected_order_arc_344  -16
    RHS1      connected_order_arc_346  -16
    RHS1      connected_order_arc_348  -16
    RHS1      connected_order_arc_350  -16
    RHS1      connected_order_arc_352  -16
    RHS1      connected_order_arc_354  -16
    RHS1      connected_order_arc_356  -16
    RHS1      connected_order_arc_358  -16
    RHS1      connected_order_arc_361  -16
    RHS1      connected_order_arc_363  -16
    RHS1      connected_order_arc_365  -16
    RHS1      connected_order_arc_367  -16
    RHS1      connected_order_arc_369  -16
    RHS1      connected_order_arc_371  -16
    RHS1      connected_order_arc_373  -16
    RHS1      connected_order_arc_375  -16
    RHS1      connected_order_arc_377  -16
    RHS1      connected_order_arc_379  -16
    RHS1      connected_order_arc_381  -16
    RHS1      connected_order_arc_383  -16
    RHS1      connected_order_arc_385  -16
    RHS1      connected_order_arc_387  -16
    RHS1      connected_order_arc_389  -16
    RHS1      connected_order_arc_392  -16
    RHS1      connected_order_arc_394  -16
    RHS1      connected_order_arc_396  -16
    RHS1      connected_order_arc_398  -16
    RHS1      connected_order_arc_400  -16
    RHS1      connected_order_arc_402  -16
    RHS1      connected_order_arc_404  -16
    RHS1      connected_order_arc_406  -16
    RHS1      connected_order_arc_408  -16
    RHS1      connected_order_arc_410  -16
    RHS1      connected_order_arc_412  -16
    RHS1      connected_order_arc_414  -16
    RHS1      connected_order_arc_416  -16
    RHS1      connected_order_arc_418  -16
    RHS1      connected_order_arc_420  -16
    RHS1      connected_order_arc_423  -16
    RHS1      connected_order_arc_425  -16
    RHS1      connected_order_arc_427  -16
    RHS1      connected_order_arc_429  -16
    RHS1      connected_order_arc_431  -16
    RHS1      connected_order_arc_433  -16
    RHS1      connected_order_arc_435  -16
    RHS1      connected_order_arc_437  -16
    RHS1      connected_order_arc_439  -16
    RHS1      connected_order_arc_441  -16
    RHS1      connected_order_arc_443  -16
    RHS1      connected_order_arc_445  -16
    RHS1      connected_order_arc_447  -16
    RHS1      connected_order_arc_449  -16
    RHS1      connected_order_arc_451  -16
    RHS1      connected_order_arc_454  -16
    RHS1      connected_order_arc_456  -16
    RHS1      connected_order_arc_458  -16
    RHS1      connected_order_arc_460  -16
    RHS1      connected_order_arc_462  -16
    RHS1      connected_order_arc_464  -16
    RHS1      connected_order_arc_466  -16
    RHS1      connected_order_arc_468  -16
    RHS1      connected_order_arc_470  -16
    RHS1      connected_order_arc_472  -16
    RHS1      connected_order_arc_474  -16
    RHS1      connected_order_arc_476  -16
    RHS1      connected_order_arc_478  -16
    RHS1      connected_order_arc_480  -16
    RHS1      connected_order_arc_482  -16
    RHS1      connected_order_arc_485  -16
    RHS1      connected_order_arc_487  -16
    RHS1      connected_order_arc_489  -16
    RHS1      connected_order_arc_491  -16
    RHS1      connected_order_arc_493  -16
    RHS1      connected_order_arc_495  -16
    RHS1      connected_order_arc_497  -16
    RHS1      connected_order_arc_499  -16
    RHS1      connected_order_arc_501  -16
    RHS1      connected_order_arc_503  -16
    RHS1      connected_order_arc_505  -16
    RHS1      connected_order_arc_507  -16
    RHS1      connected_order_arc_509  -16
    RHS1      connected_order_arc_511  -16
    RHS1      connected_order_arc_513  -16
    RHS1      connected_order_arc_516  -16
    RHS1      connected_order_arc_518  -16
    RHS1      connected_order_arc_520  -16
    RHS1      connected_order_arc_522  -16
    RHS1      connected_order_arc_524  -16
    RHS1      connected_order_arc_526  -16
    RHS1      connected_order_arc_528  -16
    RHS1      connected_order_arc_530  -16
    RHS1      connected_order_arc_532  -16
    RHS1      connected_order_arc_534  -16
    RHS1      connected_order_arc_536  -16
    RHS1      connected_order_arc_538  -16
    RHS1      connected_order_arc_540  -16
    RHS1      connected_order_arc_542  -16
    RHS1      connected_order_arc_544  -16
    RHS1      connected_order_arc_547  -16
    RHS1      connected_order_arc_549  -16
    RHS1      connected_order_arc_551  -16
    RHS1      connected_order_arc_553  -16
    RHS1      connected_order_arc_555  -16
    RHS1      connected_order_arc_557  -16
    RHS1      connected_order_arc_559  -16
    RHS1      connected_order_arc_561  -16
    RHS1      connected_order_arc_563  -16
    RHS1      connected_order_arc_565  -16
    RHS1      connected_order_arc_567  -16
    RHS1      connected_order_arc_569  -16
    RHS1      connected_order_arc_571  -16
    RHS1      connected_order_arc_573  -16
    RHS1      connected_order_arc_575  -16
    RHS1      connected_order_arc_578  -16
    RHS1      connected_order_arc_580  -16
    RHS1      connected_order_arc_582  -16
    RHS1      connected_order_arc_584  -16
    RHS1      connected_order_arc_586  -16
    RHS1      connected_order_arc_588  -16
    RHS1      connected_order_arc_590  -16
    RHS1      connected_order_arc_592  -16
    RHS1      connected_order_arc_594  -16
    RHS1      connected_order_arc_596  -16
    RHS1      connected_order_arc_598  -16
    RHS1      connected_order_arc_600  -16
    RHS1      connected_order_arc_602  -16
    RHS1      connected_order_arc_604  -16
    RHS1      connected_order_arc_606  -16
    RHS1      connected_order_arc_609  -16
    RHS1      connected_order_arc_611  -16
    RHS1      connected_order_arc_613  -16
    RHS1      connected_order_arc_615  -16
    RHS1      connected_order_arc_617  -16
    RHS1      connected_order_arc_619  -16
    RHS1      connected_order_arc_621  -16
    RHS1      connected_order_arc_623  -16
    RHS1      connected_order_arc_625  -16
    RHS1      connected_order_arc_627  -16
    RHS1      connected_order_arc_629  -16
    RHS1      connected_order_arc_631  -16
    RHS1      connected_order_arc_633  -16
    RHS1      connected_order_arc_635  -16
    RHS1      connected_order_arc_637  -16
    RHS1      connected_order_arc_640  -16
    RHS1      connected_order_arc_642  -16
    RHS1      connected_order_arc_644  -16
    RHS1      connected_order_arc_646  -16
    RHS1      connected_order_arc_648  -16
    RHS1      connected_order_arc_650  -16
    RHS1      connected_order_arc_652  -16
    RHS1      connected_order_arc_654  -16
    RHS1      connected_order_arc_656  -16
    RHS1      connected_order_arc_658  -16
    RHS1      connected_order_arc_660  -16
    RHS1      connected_order_arc_662  -16
    RHS1      connected_order_arc_664  -16
    RHS1      connected_order_arc_666  -16
    RHS1      connected_order_arc_668  -16
    RHS1      connected_order_arc_671  -16
    RHS1      connected_order_arc_673  -16
    RHS1      connected_order_arc_675  -16
    RHS1      connected_order_arc_677  -16
    RHS1      connected_order_arc_679  -16
    RHS1      connected_order_arc_681  -16
    RHS1      connected_order_arc_683  -16
    RHS1      connected_order_arc_685  -16
    RHS1      connected_order_arc_687  -16
    RHS1      connected_order_arc_689  -16
    RHS1      connected_order_arc_691  -16
    RHS1      connected_order_arc_693  -16
    RHS1      connected_order_arc_695  -16
    RHS1      connected_order_arc_697  -16
    RHS1      connected_order_arc_699  -16
    RHS1      connected_order_arc_702  -16
    RHS1      connected_order_arc_704  -16
    RHS1      connected_order_arc_706  -16
    RHS1      connected_order_arc_708  -16
    RHS1      connected_order_arc_710  -16
    RHS1      connected_order_arc_712  -16
    RHS1      connected_order_arc_714  -16
    RHS1      connected_order_arc_716  -16
    RHS1      connected_order_arc_718  -16
    RHS1      connected_order_arc_720  -16
    RHS1      connected_order_arc_722  -16
    RHS1      connected_order_arc_724  -16
    RHS1      connected_order_arc_726  -16
    RHS1      connected_order_arc_728  -16
    RHS1      connected_order_arc_730  -16
    RHS1      connected_order_arc_733  -16
    RHS1      connected_order_arc_735  -16
    RHS1      connected_order_arc_737  -16
    RHS1      connected_order_arc_739  -16
    RHS1      connected_order_arc_741  -16
    RHS1      connected_order_arc_743  -16
    RHS1      connected_order_arc_745  -16
    RHS1      connected_order_arc_747  -16
    RHS1      connected_order_arc_749  -16
    RHS1      connected_order_arc_751  -16
    RHS1      connected_order_arc_753  -16
    RHS1      connected_order_arc_755  -16
    RHS1      connected_order_arc_757  -16
    RHS1      connected_order_arc_759  -16
    RHS1      connected_order_arc_761  -16
    RHS1      connected_order_arc_764  -16
    RHS1      connected_order_arc_766  -16
    RHS1      connected_order_arc_768  -16
    RHS1      connected_order_arc_770  -16
    RHS1      connected_order_arc_772  -16
    RHS1      connected_order_arc_774  -16
    RHS1      connected_order_arc_776  -16
    RHS1      connected_order_arc_778  -16
    RHS1      connected_order_arc_780  -16
    RHS1      connected_order_arc_782  -16
    RHS1      connected_order_arc_784  -16
    RHS1      connected_order_arc_786  -16
    RHS1      connected_order_arc_788  -16
    RHS1      connected_order_arc_790  -16
    RHS1      connected_order_arc_792  -16
    RHS1      connected_order_arc_795  -16
    RHS1      connected_order_arc_797  -16
    RHS1      connected_order_arc_799  -16
    RHS1      connected_order_arc_801  -16
    RHS1      connected_order_arc_803  -16
    RHS1      connected_order_arc_805  -16
    RHS1      connected_order_arc_807  -16
    RHS1      connected_order_arc_809  -16
    RHS1      connected_order_arc_811  -16
    RHS1      connected_order_arc_813  -16
    RHS1      connected_order_arc_815  -16
    RHS1      connected_order_arc_817  -16
    RHS1      connected_order_arc_819  -16
    RHS1      connected_order_arc_821  -16
    RHS1      connected_order_arc_823  -16
    RHS1      depot_departure_or_bypass_824  1
    RHS1      depot_return_or_bypass_825  1
    RHS1      segment_load_conservation_830  -1
    RHS1      segment_prefix_lb_831  1
    RHS1      segment_prefix_ub_832  30
    RHS1      segment_load_conservation_837  -1
    RHS1      segment_prefix_lb_838  1
    RHS1      segment_prefix_ub_839  30
    RHS1      segment_load_conservation_844  4
    RHS1      segment_prefix_ub_846  26
    RHS1      segment_load_conservation_851  -2
    RHS1      segment_prefix_lb_852  2
    RHS1      segment_prefix_ub_853  30
    RHS1      segment_load_conservation_858  -1
    RHS1      segment_prefix_lb_859  1
    RHS1      segment_prefix_ub_860  30
    RHS1      segment_load_conservation_865  3
    RHS1      segment_prefix_ub_867  27
    RHS1      segment_load_conservation_872  -1
    RHS1      segment_prefix_lb_873  1
    RHS1      segment_prefix_ub_874  30
    RHS1      segment_load_conservation_879  -3
    RHS1      segment_prefix_lb_880  3
    RHS1      segment_prefix_ub_881  30
    RHS1      fixed_segment_relative_order_930  1
    RHS1      fixed_segment_relative_order_931  1
    RHS1      fixed_segment_relative_order_932  1
    RHS1      fixed_segment_relative_order_933  1
    RHS1      fixed_segment_relative_order_934  1
    RHS1      fixed_segment_relative_order_935  1
    RHS1      fixed_segment_relative_order_936  1
    RHS1      original_T_including_depot_unload_937  3960
    RHS1      connected_order_arc_951  -10
    RHS1      connected_order_arc_953  -10
    RHS1      connected_order_arc_955  -10
    RHS1      connected_order_arc_957  -10
    RHS1      connected_order_arc_959  -10
    RHS1      connected_order_arc_961  -10
    RHS1      connected_order_arc_963  -10
    RHS1      connected_order_arc_965  -10
    RHS1      connected_order_arc_967  -10
    RHS1      connected_order_arc_970  -10
    RHS1      connected_order_arc_972  -10
    RHS1      connected_order_arc_974  -10
    RHS1      connected_order_arc_976  -10
    RHS1      connected_order_arc_978  -10
    RHS1      connected_order_arc_980  -10
    RHS1      connected_order_arc_982  -10
    RHS1      connected_order_arc_984  -10
    RHS1      connected_order_arc_986  -10
    RHS1      connected_order_arc_989  -10
    RHS1      connected_order_arc_991  -10
    RHS1      connected_order_arc_993  -10
    RHS1      connected_order_arc_995  -10
    RHS1      connected_order_arc_997  -10
    RHS1      connected_order_arc_999  -10
    RHS1      connected_order_arc_1001  -10
    RHS1      connected_order_arc_1003  -10
    RHS1      connected_order_arc_1005  -10
    RHS1      connected_order_arc_1008  -10
    RHS1      connected_order_arc_1010  -10
    RHS1      connected_order_arc_1012  -10
    RHS1      connected_order_arc_1014  -10
    RHS1      connected_order_arc_1016  -10
    RHS1      connected_order_arc_1018  -10
    RHS1      connected_order_arc_1020  -10
    RHS1      connected_order_arc_1022  -10
    RHS1      connected_order_arc_1024  -10
    RHS1      connected_order_arc_1027  -10
    RHS1      connected_order_arc_1029  -10
    RHS1      connected_order_arc_1031  -10
    RHS1      connected_order_arc_1033  -10
    RHS1      connected_order_arc_1035  -10
    RHS1      connected_order_arc_1037  -10
    RHS1      connected_order_arc_1039  -10
    RHS1      connected_order_arc_1041  -10
    RHS1      connected_order_arc_1043  -10
    RHS1      connected_order_arc_1046  -10
    RHS1      connected_order_arc_1048  -10
    RHS1      connected_order_arc_1050  -10
    RHS1      connected_order_arc_1052  -10
    RHS1      connected_order_arc_1054  -10
    RHS1      connected_order_arc_1056  -10
    RHS1      connected_order_arc_1058  -10
    RHS1      connected_order_arc_1060  -10
    RHS1      connected_order_arc_1062  -10
    RHS1      connected_order_arc_1065  -10
    RHS1      connected_order_arc_1067  -10
    RHS1      connected_order_arc_1069  -10
    RHS1      connected_order_arc_1071  -10
    RHS1      connected_order_arc_1073  -10
    RHS1      connected_order_arc_1075  -10
    RHS1      connected_order_arc_1077  -10
    RHS1      connected_order_arc_1079  -10
    RHS1      connected_order_arc_1081  -10
    RHS1      connected_order_arc_1084  -10
    RHS1      connected_order_arc_1086  -10
    RHS1      connected_order_arc_1088  -10
    RHS1      connected_order_arc_1090  -10
    RHS1      connected_order_arc_1092  -10
    RHS1      connected_order_arc_1094  -10
    RHS1      connected_order_arc_1096  -10
    RHS1      connected_order_arc_1098  -10
    RHS1      connected_order_arc_1100  -10
    RHS1      connected_order_arc_1103  -10
    RHS1      connected_order_arc_1105  -10
    RHS1      connected_order_arc_1107  -10
    RHS1      connected_order_arc_1109  -10
    RHS1      connected_order_arc_1111  -10
    RHS1      connected_order_arc_1113  -10
    RHS1      connected_order_arc_1115  -10
    RHS1      connected_order_arc_1117  -10
    RHS1      connected_order_arc_1119  -10
    RHS1      connected_order_arc_1122  -10
    RHS1      connected_order_arc_1124  -10
    RHS1      connected_order_arc_1126  -10
    RHS1      connected_order_arc_1128  -10
    RHS1      connected_order_arc_1130  -10
    RHS1      connected_order_arc_1132  -10
    RHS1      connected_order_arc_1134  -10
    RHS1      connected_order_arc_1136  -10
    RHS1      connected_order_arc_1138  -10
    RHS1      depot_departure_or_bypass_1139  1
    RHS1      depot_return_or_bypass_1140  1
    RHS1      segment_load_conservation_1145  4
    RHS1      segment_prefix_ub_1147  26
    RHS1      segment_load_conservation_1152  -1
    RHS1      segment_prefix_lb_1153  1
    RHS1      segment_prefix_ub_1154  30
    RHS1      fixed_segment_relative_order_1203  1
    RHS1      original_T_including_depot_unload_1204  4320
BOUNDS
 LO BND1      t         3.9538094640352073e-02
 UP BND1      t         0.0921355709115762
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_19_0  
 UP BND1      w_19_0    0.0921355709115762
 BV BND1      x_19_1  
 UP BND1      w_19_1    0.0921355709115762
 BV BND1      x_19_2  
 UP BND1      w_19_2    0.0921355709115762
 BV BND1      x_19_3  
 UP BND1      w_19_3    0.0921355709115762
 BV BND1      x_19_4  
 UP BND1      w_19_4    0.0921355709115762
 BV BND1      x_19_5  
 UP BND1      w_19_5    0.0921355709115762
 UP BND1      rho_19    1
 BV BND1      x_15_0  
 UP BND1      w_15_0    0.0921355709115762
 BV BND1      x_15_1  
 UP BND1      w_15_1    0.0921355709115762
 UP BND1      rho_15    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    0.0921355709115762
 BV BND1      x_18_1  
 UP BND1      w_18_1    0.0921355709115762
 BV BND1      x_18_2  
 UP BND1      w_18_2    0.0921355709115762
 BV BND1      x_18_3  
 UP BND1      w_18_3    0.0921355709115762
 BV BND1      x_18_4  
 UP BND1      w_18_4    0.0921355709115762
 BV BND1      x_18_5  
 UP BND1      w_18_5    0.0921355709115762
 BV BND1      x_18_6  
 UP BND1      w_18_6    0.0921355709115762
 BV BND1      x_18_7  
 UP BND1      w_18_7    0.0921355709115762
 BV BND1      x_18_8  
 UP BND1      w_18_8    0.0921355709115762
 BV BND1      x_18_9  
 UP BND1      w_18_9    0.0921355709115762
 BV BND1      x_18_10 
 UP BND1      w_18_10   0.0921355709115762
 BV BND1      x_18_11 
 UP BND1      w_18_11   0.0921355709115762
 BV BND1      x_18_12 
 UP BND1      w_18_12   0.0921355709115762
 BV BND1      x_18_13 
 UP BND1      w_18_13   0.0921355709115762
 BV BND1      x_18_14 
 UP BND1      w_18_14   0.0921355709115762
 BV BND1      x_18_15 
 UP BND1      w_18_15   0.0921355709115762
 UP BND1      rho_18    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    0.0921355709115762
 BV BND1      x_16_1  
 UP BND1      w_16_1    0.0921355709115762
 BV BND1      x_16_2  
 UP BND1      w_16_2    0.0921355709115762
 UP BND1      rho_16    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    0.0921355709115762
 BV BND1      x_17_1  
 UP BND1      w_17_1    0.0921355709115762
 BV BND1      x_17_2  
 UP BND1      w_17_2    0.0921355709115762
 BV BND1      x_17_3  
 UP BND1      w_17_3    0.0921355709115762
 BV BND1      x_17_4  
 UP BND1      w_17_4    0.0921355709115762
 BV BND1      x_17_5  
 UP BND1      w_17_5    0.0921355709115762
 BV BND1      x_17_6  
 UP BND1      w_17_6    0.0921355709115762
 BV BND1      x_17_7  
 UP BND1      w_17_7    0.0921355709115762
 BV BND1      x_17_8  
 UP BND1      w_17_8    0.0921355709115762
 BV BND1      x_17_9  
 UP BND1      w_17_9    0.0921355709115762
 BV BND1      x_17_10 
 UP BND1      w_17_10   0.0921355709115762
 BV BND1      x_17_11 
 UP BND1      w_17_11   0.0921355709115762
 BV BND1      x_17_12 
 UP BND1      w_17_12   0.0921355709115762
 BV BND1      x_17_13 
 UP BND1      w_17_13   0.0921355709115762
 BV BND1      x_17_14 
 UP BND1      w_17_14   0.0921355709115762
 BV BND1      x_17_15 
 UP BND1      w_17_15   0.0921355709115762
 BV BND1      x_17_16 
 UP BND1      w_17_16   0.0921355709115762
 UP BND1      rho_17    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    0.0921355709115762
 BV BND1      x_12_1  
 UP BND1      w_12_1    0.0921355709115762
 BV BND1      x_12_2  
 UP BND1      w_12_2    0.0921355709115762
 BV BND1      x_12_3  
 UP BND1      w_12_3    0.0921355709115762
 BV BND1      x_12_4  
 UP BND1      w_12_4    0.0921355709115762
 BV BND1      x_12_5  
 UP BND1      w_12_5    0.0921355709115762
 BV BND1      x_12_6  
 UP BND1      w_12_6    0.0921355709115762
 BV BND1      x_12_7  
 UP BND1      w_12_7    0.0921355709115762
 BV BND1      x_12_8  
 UP BND1      w_12_8    0.0921355709115762
 BV BND1      x_12_9  
 UP BND1      w_12_9    0.0921355709115762
 BV BND1      x_12_10 
 UP BND1      w_12_10   0.0921355709115762
 BV BND1      x_12_11 
 UP BND1      w_12_11   0.0921355709115762
 BV BND1      x_12_12 
 UP BND1      w_12_12   0.0921355709115762
 BV BND1      x_12_13 
 UP BND1      w_12_13   0.0921355709115762
 BV BND1      x_12_14 
 UP BND1      w_12_14   0.0921355709115762
 BV BND1      x_12_15 
 UP BND1      w_12_15   0.0921355709115762
 UP BND1      rho_12    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    0.0921355709115762
 BV BND1      x_11_1  
 UP BND1      w_11_1    0.0921355709115762
 BV BND1      x_11_2  
 UP BND1      w_11_2    0.0921355709115762
 BV BND1      x_11_3  
 UP BND1      w_11_3    0.0921355709115762
 BV BND1      x_11_4  
 UP BND1      w_11_4    0.0921355709115762
 BV BND1      x_11_5  
 UP BND1      w_11_5    0.0921355709115762
 BV BND1      x_11_6  
 UP BND1      w_11_6    0.0921355709115762
 BV BND1      x_11_7  
 UP BND1      w_11_7    0.0921355709115762
 BV BND1      x_11_8  
 UP BND1      w_11_8    0.0921355709115762
 BV BND1      x_11_9  
 UP BND1      w_11_9    0.0921355709115762
 BV BND1      x_11_10 
 UP BND1      w_11_10   0.0921355709115762
 BV BND1      x_11_11 
 UP BND1      w_11_11   0.0921355709115762
 BV BND1      x_11_12 
 UP BND1      w_11_12   0.0921355709115762
 BV BND1      x_11_13 
 UP BND1      w_11_13   0.0921355709115762
 BV BND1      x_11_14 
 UP BND1      w_11_14   0.0921355709115762
 BV BND1      x_11_15 
 UP BND1      w_11_15   0.0921355709115762
 UP BND1      rho_11    1
 BV BND1      x_9_0   
 UP BND1      w_9_0     0.0921355709115762
 BV BND1      x_9_1   
 UP BND1      w_9_1     0.0921355709115762
 UP BND1      rho_9     1
 UP BND1      a_19_15   1
 UP BND1      a_19_18   1
 UP BND1      a_19_16   1
 UP BND1      a_19_17   1
 UP BND1      a_19_12   1
 UP BND1      a_19_11   1
 UP BND1      a_19_9    1
 UP BND1      a_15_18   1
 UP BND1      a_15_16   1
 UP BND1      a_15_17   1
 UP BND1      a_15_12   1
 UP BND1      a_15_11   1
 UP BND1      a_15_9    1
 UP BND1      a_18_16   1
 UP BND1      a_18_17   1
 UP BND1      a_18_12   1
 UP BND1      a_18_11   1
 UP BND1      a_18_9    1
 UP BND1      a_16_17   1
 UP BND1      a_16_12   1
 UP BND1      a_16_11   1
 UP BND1      a_16_9    1
 UP BND1      a_17_12   1
 UP BND1      a_17_11   1
 UP BND1      a_17_9    1
 UP BND1      a_12_11   1
 UP BND1      a_12_9    1
 UP BND1      a_11_9    1
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_0_15_1
 BV BND1      service_1_15_1
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_9_1
 BV BND1      service_1_9_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  16
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  16
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  16
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  16
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  16
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  16
 FX BND1      visit_0_7  1
 UP BND1      order_0_7  16
 FX BND1      visit_0_8  1
 UP BND1      order_0_8  16
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  16
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  16
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  16
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  16
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  16
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  16
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  16
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  16
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_7
 FX BND1      load_0_0_7  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_7
 UP BND1      load_0_1_7  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  30
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_7
 UP BND1      load_0_2_7  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  30
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_7
 UP BND1      load_0_3_7  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  30
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_7
 UP BND1      load_0_4_7  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  30
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_7
 UP BND1      load_0_5_7  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  30
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_7
 UP BND1      load_0_6_7  30
 BV BND1      arc_0_6_8
 UP BND1      load_0_6_8  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  30
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  30
 BV BND1      arc_0_7_0
 UP BND1      load_0_7_0  30
 BV BND1      arc_0_7_1
 UP BND1      load_0_7_1  30
 BV BND1      arc_0_7_2
 UP BND1      load_0_7_2  30
 BV BND1      arc_0_7_3
 UP BND1      load_0_7_3  30
 BV BND1      arc_0_7_4
 UP BND1      load_0_7_4  30
 BV BND1      arc_0_7_5
 UP BND1      load_0_7_5  30
 BV BND1      arc_0_7_6
 UP BND1      load_0_7_6  30
 BV BND1      arc_0_7_8
 UP BND1      load_0_7_8  30
 BV BND1      arc_0_7_11
 UP BND1      load_0_7_11  30
 BV BND1      arc_0_7_12
 UP BND1      load_0_7_12  30
 BV BND1      arc_0_7_13
 UP BND1      load_0_7_13  30
 BV BND1      arc_0_7_14
 UP BND1      load_0_7_14  30
 BV BND1      arc_0_7_15
 UP BND1      load_0_7_15  30
 BV BND1      arc_0_7_16
 UP BND1      load_0_7_16  30
 BV BND1      arc_0_7_17
 UP BND1      load_0_7_17  30
 BV BND1      arc_0_7_18
 UP BND1      load_0_7_18  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_6
 UP BND1      load_0_8_6  30
 BV BND1      arc_0_8_7
 UP BND1      load_0_8_7  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_8_16
 UP BND1      load_0_8_16  30
 BV BND1      arc_0_8_17
 UP BND1      load_0_8_17  30
 BV BND1      arc_0_8_18
 UP BND1      load_0_8_18  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_7
 UP BND1      load_0_11_7  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_11_17
 UP BND1      load_0_11_17  30
 BV BND1      arc_0_11_18
 UP BND1      load_0_11_18  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_7
 UP BND1      load_0_12_7  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  30
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_7
 UP BND1      load_0_13_7  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  30
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_7
 UP BND1      load_0_14_7  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  30
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_7
 UP BND1      load_0_15_7  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  30
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_7
 UP BND1      load_0_16_7  30
 BV BND1      arc_0_16_8
 UP BND1      load_0_16_8  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  30
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  30
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  30
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  30
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  30
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  30
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  30
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  30
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  30
 BV BND1      arc_0_17_7
 UP BND1      load_0_17_7  30
 BV BND1      arc_0_17_8
 UP BND1      load_0_17_8  30
 BV BND1      arc_0_17_11
 UP BND1      load_0_17_11  30
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  30
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  30
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  30
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  30
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  30
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  30
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  30
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  30
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  30
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  30
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  30
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  30
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  30
 BV BND1      arc_0_18_7
 UP BND1      load_0_18_7  30
 BV BND1      arc_0_18_8
 UP BND1      load_0_18_8  30
 BV BND1      arc_0_18_11
 UP BND1      load_0_18_11  30
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  30
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  30
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  30
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  30
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  30
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  30
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  10
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  10
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  30
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  30
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_11_17
 UP BND1      load_1_11_17  30
 BV BND1      arc_1_11_18
 UP BND1      load_1_11_18  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  30
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  30
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  30
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  30
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  30
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  30
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  30
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  30
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  30
 BV BND1      arc_1_17_11
 UP BND1      load_1_17_11  30
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  30
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  30
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  30
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  30
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  30
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  30
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  30
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  30
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  30
 BV BND1      arc_1_18_11
 UP BND1      load_1_18_11  30
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  30
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  30
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  30
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  30
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  30
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  30
ENDATA
