* Signature: 0x3372dcdf53347065
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
 L  column_13
 L  column_14
 L  column_15
 L  column_16
 L  column_17
 L  column_18
 L  column_19
 L  column_20
 L  column_21
 L  column_22
 L  column_23
 L  column_24
 L  column_25
 L  column_26
 L  column_27
 L  column_28
 L  column_29
 L  column_30
 L  column_31
 L  column_32
 L  column_33
 L  column_34
 L  column_35
 L  column_36
 L  column_37
 L  column_38
 L  column_39
 L  column_40
 L  column_41
 L  column_42
 L  column_43
 L  column_44
 L  column_45
 L  column_46
COLUMNS
    psi[1,4]  OBJ       1
    psi[1,4]  column_0  1
    psi[1,4]  column_1  1
    psi[1,4]  column_2  1
    psi[1,4]  column_3  1
    psi[1,4]  column_4  1
    psi[1,4]  column_5  1
    psi[1,4]  column_6  1
    psi[1,4]  column_7  1
    psi[1,4]  column_8  1
    psi[1,4]  column_9  1
    psi[1,4]  column_10  1
    psi[1,4]  column_11  1
    psi[1,4]  column_12  1
    psi[1,4]  column_13  1
    psi[1,4]  column_14  1
    psi[1,4]  column_15  1
    psi[1,4]  column_16  1
    psi[1,4]  column_17  1
    psi[1,4]  column_18  1
    psi[1,4]  column_19  1
    psi[1,4]  column_20  1
    psi[1,4]  column_21  1
    psi[1,4]  column_22  1
    psi[1,4]  column_23  1
    psi[1,4]  column_24  1
    psi[1,4]  column_25  1
    psi[1,4]  column_26  1
    psi[1,4]  column_27  1
    psi[1,4]  column_28  1
    psi[1,4]  column_29  1
    psi[1,4]  column_30  1
    psi[1,4]  column_31  1
    psi[1,4]  column_32  1
    psi[1,4]  column_33  1
    psi[1,4]  column_34  1
    psi[1,4]  column_35  1
    psi[1,4]  column_36  1
    psi[1,4]  column_37  1
    psi[1,4]  column_38  1
    psi[1,4]  column_39  1
    psi[1,4]  column_40  1
    psi[1,4]  column_41  1
    psi[1,4]  column_42  1
    psi[1,4]  column_43  1
    psi[1,4]  column_44  1
    psi[1,4]  column_45  1
    psi[1,4]  column_46  1
    psi[2,0]  OBJ       0
    psi[2,1]  OBJ       0
    psi[2,2]  OBJ       0
    psi[2,3]  OBJ       0
    psi[2,4]  OBJ       0
    psi[2,5]  OBJ       0
    psi[2,6]  OBJ       0
    psi[2,7]  OBJ       0
    psi[2,8]  OBJ       0
    psi[2,9]  OBJ       0
    psi[2,10]  OBJ       0
    psi[2,11]  OBJ       0
    psi[2,12]  OBJ       1
    psi[2,12]  column_0  1
    psi[2,12]  column_1  1
    psi[2,12]  column_2  1
    psi[2,12]  column_3  1
    psi[2,12]  column_4  1
    psi[2,12]  column_5  1
    psi[2,12]  column_6  1
    psi[2,12]  column_7  1
    psi[2,12]  column_8  1
    psi[2,12]  column_9  1
    psi[2,12]  column_10  1
    psi[2,12]  column_11  1
    psi[2,12]  column_12  1
    psi[2,12]  column_13  1
    psi[2,12]  column_14  1
    psi[2,12]  column_15  1
    psi[2,12]  column_16  1
    psi[2,12]  column_17  1
    psi[2,12]  column_18  1
    psi[2,12]  column_19  1
    psi[2,12]  column_20  1
    psi[2,12]  column_21  1
    psi[2,12]  column_22  1
    psi[2,12]  column_23  1
    psi[2,12]  column_24  1
    psi[2,12]  column_25  1
    psi[2,12]  column_26  1
    psi[2,12]  column_27  1
    psi[2,12]  column_28  1
    psi[2,12]  column_29  1
    psi[2,12]  column_30  1
    psi[2,12]  column_31  1
    psi[2,12]  column_32  1
    psi[2,12]  column_33  1
    psi[2,12]  column_34  1
    psi[2,12]  column_35  1
    psi[2,12]  column_36  1
    psi[2,12]  column_37  1
    psi[2,12]  column_38  1
    psi[2,12]  column_39  1
    psi[2,12]  column_40  1
    psi[2,12]  column_41  1
    psi[2,12]  column_42  1
    psi[2,12]  column_43  1
    psi[2,12]  column_44  1
    psi[2,12]  column_45  1
    psi[2,12]  column_46  1
    psi[2,13]  OBJ       0
    psi[2,14]  OBJ       0
    psi[2,15]  OBJ       0
    psi[2,16]  OBJ       0
    psi[2,17]  OBJ       0
    psi[2,18]  OBJ       0
    psi[2,19]  OBJ       0
    psi[2,20]  OBJ       0
    psi[2,21]  OBJ       0
    psi[2,22]  OBJ       0
    psi[2,23]  OBJ       0
    psi[3,13]  OBJ       1
    psi[3,13]  column_0  1
    psi[3,13]  column_1  1
    psi[3,13]  column_2  1
    psi[3,13]  column_3  1
    psi[3,13]  column_4  1
    psi[3,13]  column_5  1
    psi[3,13]  column_6  1
    psi[3,13]  column_7  1
    psi[3,13]  column_8  1
    psi[3,13]  column_9  1
    psi[3,13]  column_10  1
    psi[3,13]  column_11  1
    psi[3,13]  column_12  1
    psi[3,13]  column_13  1
    psi[3,13]  column_14  1
    psi[3,13]  column_15  1
    psi[3,13]  column_16  1
    psi[3,13]  column_17  1
    psi[3,13]  column_18  1
    psi[3,13]  column_19  1
    psi[3,13]  column_20  1
    psi[3,13]  column_21  1
    psi[3,13]  column_22  1
    psi[3,13]  column_23  1
    psi[3,13]  column_24  1
    psi[3,13]  column_25  1
    psi[3,13]  column_26  1
    psi[3,13]  column_27  1
    psi[3,13]  column_28  1
    psi[3,13]  column_29  1
    psi[3,13]  column_30  1
    psi[3,13]  column_31  1
    psi[3,13]  column_32  1
    psi[3,13]  column_33  1
    psi[3,13]  column_34  1
    psi[3,13]  column_35  1
    psi[3,13]  column_36  1
    psi[3,13]  column_37  1
    psi[3,13]  column_38  1
    psi[3,13]  column_39  1
    psi[3,13]  column_40  1
    psi[3,13]  column_41  1
    psi[3,13]  column_42  1
    psi[3,13]  column_43  1
    psi[3,13]  column_44  1
    psi[3,13]  column_45  1
    psi[3,13]  column_46  1
    psi[4,0]  OBJ       0
    psi[4,1]  OBJ       0
    psi[4,2]  OBJ       0
    psi[4,3]  OBJ       0
    psi[4,4]  OBJ       0
    psi[4,5]  OBJ       0
    psi[4,6]  OBJ       0
    psi[4,7]  OBJ       9.5949074074074070e-01
    psi[4,7]  column_0  1
    psi[4,7]  column_1  1
    psi[4,7]  column_2  1
    psi[4,7]  column_3  1
    psi[4,7]  column_4  1
    psi[4,7]  column_5  1
    psi[4,7]  column_6  1
    psi[4,7]  column_7  1
    psi[4,7]  column_8  1
    psi[4,7]  column_9  1
    psi[4,7]  column_10  1
    psi[4,7]  column_11  1
    psi[4,7]  column_12  1
    psi[4,7]  column_13  1
    psi[4,7]  column_14  1
    psi[4,7]  column_15  1
    psi[4,7]  column_16  1
    psi[4,7]  column_17  1
    psi[4,7]  column_18  1
    psi[4,7]  column_19  1
    psi[4,7]  column_20  1
    psi[4,7]  column_21  1
    psi[4,7]  column_22  1
    psi[4,7]  column_23  1
    psi[4,8]  OBJ       0
    psi[4,9]  OBJ       0
    psi[4,10]  OBJ       0
    psi[4,11]  OBJ       0
    psi[4,12]  OBJ       0
    psi[4,13]  OBJ       4.0509259259259328e-02
    psi[4,13]  column_24  1
    psi[4,13]  column_25  1
    psi[4,13]  column_26  1
    psi[4,13]  column_27  1
    psi[4,13]  column_28  1
    psi[4,13]  column_29  1
    psi[4,13]  column_30  1
    psi[4,13]  column_31  1
    psi[4,13]  column_32  1
    psi[4,13]  column_33  1
    psi[4,13]  column_34  1
    psi[4,13]  column_35  1
    psi[4,13]  column_36  1
    psi[4,13]  column_37  1
    psi[4,13]  column_38  1
    psi[4,13]  column_39  1
    psi[4,13]  column_40  1
    psi[4,13]  column_41  1
    psi[4,13]  column_42  1
    psi[4,13]  column_43  1
    psi[4,13]  column_44  1
    psi[4,13]  column_45  1
    psi[4,13]  column_46  1
    psi[4,14]  OBJ       0
    psi[4,15]  OBJ       0
    psi[5,0]  OBJ       0
    psi[5,1]  OBJ       0
    psi[5,2]  OBJ       0
    psi[5,3]  OBJ       0
    psi[5,4]  OBJ       0
    psi[5,5]  OBJ       0
    psi[5,6]  OBJ       0
    psi[5,7]  OBJ       0
    psi[5,8]  OBJ       1
    psi[5,8]  column_0  1
    psi[5,8]  column_1  1
    psi[5,8]  column_2  1
    psi[5,8]  column_3  1
    psi[5,8]  column_4  1
    psi[5,8]  column_5  1
    psi[5,8]  column_6  1
    psi[5,8]  column_7  1
    psi[5,8]  column_8  1
    psi[5,8]  column_9  1
    psi[5,8]  column_10  1
    psi[5,8]  column_11  1
    psi[5,8]  column_12  1
    psi[5,8]  column_13  1
    psi[5,8]  column_14  1
    psi[5,8]  column_15  1
    psi[5,8]  column_16  1
    psi[5,8]  column_17  1
    psi[5,8]  column_18  1
    psi[5,8]  column_19  1
    psi[5,8]  column_20  1
    psi[5,8]  column_21  1
    psi[5,8]  column_22  1
    psi[5,8]  column_23  1
    psi[5,8]  column_24  1
    psi[5,8]  column_25  1
    psi[5,8]  column_26  1
    psi[5,8]  column_27  1
    psi[5,8]  column_28  1
    psi[5,8]  column_29  1
    psi[5,8]  column_30  1
    psi[5,8]  column_31  1
    psi[5,8]  column_32  1
    psi[5,8]  column_33  1
    psi[5,8]  column_34  1
    psi[5,8]  column_35  1
    psi[5,8]  column_36  1
    psi[5,8]  column_37  1
    psi[5,8]  column_38  1
    psi[5,8]  column_39  1
    psi[5,8]  column_40  1
    psi[5,8]  column_41  1
    psi[5,8]  column_42  1
    psi[5,8]  column_43  1
    psi[5,8]  column_44  1
    psi[5,8]  column_45  1
    psi[5,8]  column_46  1
    psi[5,9]  OBJ       0
    psi[5,10]  OBJ       0
    psi[5,11]  OBJ       0
    psi[5,12]  OBJ       0
    psi[5,13]  OBJ       0
    psi[5,14]  OBJ       0
    psi[5,15]  OBJ       0
    psi[6,4]  OBJ       1
    psi[6,4]  column_0  1
    psi[6,4]  column_1  1
    psi[6,4]  column_2  1
    psi[6,4]  column_3  1
    psi[6,4]  column_4  1
    psi[6,4]  column_5  1
    psi[6,4]  column_6  1
    psi[6,4]  column_7  1
    psi[6,4]  column_8  1
    psi[6,4]  column_9  1
    psi[6,4]  column_10  1
    psi[6,4]  column_11  1
    psi[6,4]  column_12  1
    psi[6,4]  column_13  1
    psi[6,4]  column_14  1
    psi[6,4]  column_15  1
    psi[6,4]  column_16  1
    psi[6,4]  column_17  1
    psi[6,4]  column_18  1
    psi[6,4]  column_19  1
    psi[6,4]  column_20  1
    psi[6,4]  column_21  1
    psi[6,4]  column_22  1
    psi[6,4]  column_23  1
    psi[6,4]  column_24  1
    psi[6,4]  column_25  1
    psi[6,4]  column_26  1
    psi[6,4]  column_27  1
    psi[6,4]  column_28  1
    psi[6,4]  column_29  1
    psi[6,4]  column_30  1
    psi[6,4]  column_31  1
    psi[6,4]  column_32  1
    psi[6,4]  column_33  1
    psi[6,4]  column_34  1
    psi[6,4]  column_35  1
    psi[6,4]  column_36  1
    psi[6,4]  column_37  1
    psi[6,4]  column_38  1
    psi[6,4]  column_39  1
    psi[6,4]  column_40  1
    psi[6,4]  column_41  1
    psi[6,4]  column_42  1
    psi[6,4]  column_43  1
    psi[6,4]  column_44  1
    psi[6,4]  column_45  1
    psi[6,4]  column_46  1
    psi[7,0]  OBJ       0
    psi[7,1]  OBJ       0
    psi[7,2]  OBJ       0
    psi[7,3]  OBJ       0
    psi[7,4]  OBJ       0
    psi[7,5]  OBJ       0
    psi[7,6]  OBJ       0
    psi[7,7]  OBJ       0
    psi[7,8]  OBJ       0
    psi[7,9]  OBJ       0
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[7,10]  column_12  1
    psi[7,10]  column_13  1
    psi[7,10]  column_14  1
    psi[7,10]  column_15  1
    psi[7,10]  column_16  1
    psi[7,10]  column_17  1
    psi[7,10]  column_18  1
    psi[7,10]  column_19  1
    psi[7,10]  column_20  1
    psi[7,10]  column_21  1
    psi[7,10]  column_22  1
    psi[7,10]  column_23  1
    psi[7,10]  column_24  1
    psi[7,10]  column_25  1
    psi[7,10]  column_26  1
    psi[7,10]  column_27  1
    psi[7,10]  column_28  1
    psi[7,10]  column_29  1
    psi[7,10]  column_30  1
    psi[7,10]  column_31  1
    psi[7,10]  column_32  1
    psi[7,10]  column_33  1
    psi[7,10]  column_34  1
    psi[7,10]  column_35  1
    psi[7,10]  column_36  1
    psi[7,10]  column_37  1
    psi[7,10]  column_38  1
    psi[7,10]  column_39  1
    psi[7,10]  column_40  1
    psi[7,10]  column_41  1
    psi[7,10]  column_42  1
    psi[7,10]  column_43  1
    psi[7,10]  column_44  1
    psi[7,10]  column_45  1
    psi[7,10]  column_46  1
    psi[7,11]  OBJ       0
    psi[7,12]  OBJ       0
    psi[7,13]  OBJ       0
    psi[7,14]  OBJ       0
    psi[7,15]  OBJ       0
    psi[7,16]  OBJ       0
    psi[7,17]  OBJ       0
    psi[7,18]  OBJ       0
    psi[7,19]  OBJ       0
    psi[8,0]  OBJ       0
    psi[8,1]  OBJ       0
    psi[8,2]  OBJ       0
    psi[8,3]  OBJ       0
    psi[8,4]  OBJ       0
    psi[8,5]  OBJ       0
    psi[8,6]  OBJ       0
    psi[8,7]  OBJ       1
    psi[8,7]  column_0  1
    psi[8,7]  column_1  1
    psi[8,7]  column_2  1
    psi[8,7]  column_3  1
    psi[8,7]  column_4  1
    psi[8,7]  column_5  1
    psi[8,7]  column_6  1
    psi[8,7]  column_7  1
    psi[8,7]  column_8  1
    psi[8,7]  column_9  1
    psi[8,7]  column_10  1
    psi[8,7]  column_11  1
    psi[8,7]  column_12  1
    psi[8,7]  column_13  1
    psi[8,7]  column_14  1
    psi[8,7]  column_15  1
    psi[8,7]  column_16  1
    psi[8,7]  column_17  1
    psi[8,7]  column_18  1
    psi[8,7]  column_24  1
    psi[8,7]  column_25  1
    psi[8,7]  column_26  1
    psi[8,7]  column_27  1
    psi[8,7]  column_28  1
    psi[8,7]  column_29  1
    psi[8,8]  OBJ       0
    psi[8,9]  OBJ       0
    psi[8,10]  OBJ       0
    psi[8,11]  OBJ       0
    psi[8,12]  OBJ       0
    psi[8,13]  column_19  1
    psi[8,13]  column_20  1
    psi[8,13]  column_21  1
    psi[8,13]  column_22  1
    psi[8,13]  column_23  1
    psi[8,13]  column_30  1
    psi[8,13]  column_31  1
    psi[8,13]  column_32  1
    psi[8,13]  column_33  1
    psi[8,13]  column_34  1
    psi[8,13]  column_35  1
    psi[8,13]  column_36  1
    psi[8,13]  column_37  1
    psi[8,13]  column_38  1
    psi[8,13]  column_39  1
    psi[8,13]  column_40  1
    psi[8,13]  column_41  1
    psi[8,13]  column_42  1
    psi[8,13]  column_43  1
    psi[8,13]  column_44  1
    psi[8,13]  column_45  1
    psi[8,13]  column_46  1
    psi[8,14]  OBJ       0
    psi[8,15]  OBJ       0
    psi[9,0]  OBJ       0
    psi[9,1]  OBJ       0
    psi[9,2]  OBJ       0
    psi[9,3]  OBJ       0
    psi[9,4]  OBJ       0
    psi[9,5]  OBJ       1.1111111111111116e-01
    psi[9,5]  column_0  1
    psi[9,5]  column_1  1
    psi[9,5]  column_2  1
    psi[9,5]  column_3  1
    psi[9,5]  column_4  1
    psi[9,5]  column_5  1
    psi[9,5]  column_6  1
    psi[9,5]  column_7  1
    psi[9,5]  column_8  1
    psi[9,5]  column_19  1
    psi[9,5]  column_20  1
    psi[9,5]  column_21  1
    psi[9,5]  column_22  1
    psi[9,5]  column_23  1
    psi[9,5]  column_24  1
    psi[9,5]  column_25  1
    psi[9,5]  column_26  1
    psi[9,5]  column_27  1
    psi[9,5]  column_30  1
    psi[9,5]  column_31  1
    psi[9,5]  column_32  1
    psi[9,5]  column_33  1
    psi[9,5]  column_34  1
    psi[9,5]  column_35  1
    psi[9,5]  column_36  1
    psi[9,5]  column_37  1
    psi[9,5]  column_38  1
    psi[9,5]  column_39  1
    psi[9,5]  column_40  1
    psi[9,5]  column_41  1
    psi[9,5]  column_42  1
    psi[9,5]  column_43  1
    psi[9,5]  column_44  1
    psi[9,5]  column_45  1
    psi[9,5]  column_46  1
    psi[9,6]  OBJ       0
    psi[9,7]  OBJ       0
    psi[9,8]  OBJ       0
    psi[9,9]  OBJ       0
    psi[9,10]  OBJ       8.8888888888888884e-01
    psi[9,10]  column_9  1
    psi[9,10]  column_10  1
    psi[9,10]  column_11  1
    psi[9,10]  column_12  1
    psi[9,10]  column_13  1
    psi[9,10]  column_14  1
    psi[9,10]  column_15  1
    psi[9,10]  column_16  1
    psi[9,10]  column_17  1
    psi[9,10]  column_18  1
    psi[9,10]  column_28  1
    psi[9,10]  column_29  1
    psi[9,11]  OBJ       0
    psi[9,12]  OBJ       0
    psi[9,13]  OBJ       0
    psi[9,14]  OBJ       0
    psi[10,0]  OBJ       0
    psi[10,1]  OBJ       0
    psi[10,2]  OBJ       0
    psi[10,3]  OBJ       0
    psi[10,4]  OBJ       1.8312452937755153e-01
    psi[10,4]  column_0  1
    psi[10,4]  column_9  1
    psi[10,4]  column_10  1
    psi[10,4]  column_11  1
    psi[10,4]  column_19  1
    psi[10,4]  column_20  1
    psi[10,4]  column_21  1
    psi[10,4]  column_28  1
    psi[10,4]  column_30  1
    psi[10,4]  column_31  1
    psi[10,4]  column_32  1
    psi[10,4]  column_33  1
    psi[10,4]  column_34  1
    psi[10,4]  column_35  1
    psi[10,4]  column_36  1
    psi[10,4]  column_37  1
    psi[10,4]  column_38  1
    psi[10,5]  OBJ       0
    psi[10,6]  OBJ       6.1067516760046892e-01
    psi[10,6]  column_1  1
    psi[10,6]  column_2  1
    psi[10,6]  column_3  1
    psi[10,6]  column_12  1
    psi[10,6]  column_13  1
    psi[10,6]  column_14  1
    psi[10,6]  column_15  1
    psi[10,6]  column_16  1
    psi[10,6]  column_24  1
    psi[10,6]  column_25  1
    psi[10,6]  column_26  1
    psi[10,6]  column_29  1
    psi[10,6]  column_39  1
    psi[10,6]  column_40  1
    psi[10,7]  OBJ       2.0620030302197953e-01
    psi[10,7]  column_4  1
    psi[10,7]  column_5  1
    psi[10,7]  column_6  1
    psi[10,7]  column_7  1
    psi[10,7]  column_8  1
    psi[10,7]  column_17  1
    psi[10,7]  column_18  1
    psi[10,7]  column_22  1
    psi[10,7]  column_23  1
    psi[10,7]  column_27  1
    psi[10,7]  column_41  1
    psi[10,7]  column_42  1
    psi[10,7]  column_43  1
    psi[10,7]  column_44  1
    psi[10,7]  column_45  1
    psi[10,7]  column_46  1
    psi[10,8]  OBJ       0
    psi[10,9]  OBJ       0
    psi[10,10]  OBJ       0
    psi[10,11]  OBJ       0
    psi[11,0]  OBJ       0
    psi[11,1]  OBJ       0
    psi[11,2]  OBJ       0
    psi[11,3]  OBJ       0
    psi[11,4]  OBJ       0
    psi[11,5]  OBJ       0
    psi[11,6]  OBJ       0
    psi[11,7]  OBJ       1
    psi[11,7]  column_0  1
    psi[11,7]  column_1  1
    psi[11,7]  column_2  1
    psi[11,7]  column_3  1
    psi[11,7]  column_4  1
    psi[11,7]  column_5  1
    psi[11,7]  column_6  1
    psi[11,7]  column_7  1
    psi[11,7]  column_8  1
    psi[11,7]  column_9  1
    psi[11,7]  column_10  1
    psi[11,7]  column_11  1
    psi[11,7]  column_12  1
    psi[11,7]  column_13  1
    psi[11,7]  column_14  1
    psi[11,7]  column_15  1
    psi[11,7]  column_16  1
    psi[11,7]  column_17  1
    psi[11,7]  column_18  1
    psi[11,7]  column_19  1
    psi[11,7]  column_20  1
    psi[11,7]  column_21  1
    psi[11,7]  column_22  1
    psi[11,7]  column_23  1
    psi[11,7]  column_24  1
    psi[11,7]  column_25  1
    psi[11,7]  column_26  1
    psi[11,7]  column_27  1
    psi[11,7]  column_28  1
    psi[11,7]  column_29  1
    psi[11,7]  column_30  1
    psi[11,7]  column_31  1
    psi[11,7]  column_32  1
    psi[11,7]  column_33  1
    psi[11,7]  column_34  1
    psi[11,7]  column_35  1
    psi[11,7]  column_36  1
    psi[11,7]  column_37  1
    psi[11,7]  column_38  1
    psi[11,7]  column_39  1
    psi[11,7]  column_40  1
    psi[11,7]  column_41  1
    psi[11,7]  column_42  1
    psi[11,7]  column_43  1
    psi[11,7]  column_44  1
    psi[11,7]  column_45  1
    psi[11,7]  column_46  1
    psi[11,8]  OBJ       0
    psi[11,9]  OBJ       0
    psi[11,10]  OBJ       0
    psi[11,11]  OBJ       0
    psi[11,12]  OBJ       0
    psi[11,13]  OBJ       0
    psi[11,14]  OBJ       0
    psi[11,15]  OBJ       0
    psi[12,0]  OBJ       0
    psi[12,1]  OBJ       0
    psi[12,2]  OBJ       0
    psi[12,3]  OBJ       0
    psi[12,4]  OBJ       0
    psi[12,5]  OBJ       0
    psi[12,6]  OBJ       0
    psi[12,7]  OBJ       0
    psi[12,8]  OBJ       8.8743914074529773e-01
    psi[12,8]  column_0  1
    psi[12,8]  column_1  1
    psi[12,8]  column_2  1
    psi[12,8]  column_4  1
    psi[12,8]  column_5  1
    psi[12,8]  column_6  1
    psi[12,8]  column_7  1
    psi[12,8]  column_9  1
    psi[12,8]  column_10  1
    psi[12,8]  column_11  1
    psi[12,8]  column_12  1
    psi[12,8]  column_13  1
    psi[12,8]  column_14  1
    psi[12,8]  column_17  1
    psi[12,8]  column_24  1
    psi[12,8]  column_29  1
    psi[12,8]  column_30  1
    psi[12,8]  column_31  1
    psi[12,8]  column_39  1
    psi[12,8]  column_41  1
    psi[12,8]  column_42  1
    psi[12,8]  column_43  1
    psi[12,9]  OBJ       0
    psi[12,10]  OBJ       0
    psi[12,11]  OBJ       0
    psi[12,12]  OBJ       0
    psi[12,13]  OBJ       0
    psi[12,14]  OBJ       1.1256085925470233e-01
    psi[12,14]  column_3  1
    psi[12,14]  column_8  1
    psi[12,14]  column_15  1
    psi[12,14]  column_16  1
    psi[12,14]  column_18  1
    psi[12,14]  column_19  1
    psi[12,14]  column_20  1
    psi[12,14]  column_21  1
    psi[12,14]  column_22  1
    psi[12,14]  column_23  1
    psi[12,14]  column_25  1
    psi[12,14]  column_26  1
    psi[12,14]  column_27  1
    psi[12,14]  column_28  1
    psi[12,14]  column_32  1
    psi[12,14]  column_33  1
    psi[12,14]  column_34  1
    psi[12,14]  column_35  1
    psi[12,14]  column_36  1
    psi[12,14]  column_37  1
    psi[12,14]  column_38  1
    psi[12,14]  column_40  1
    psi[12,14]  column_44  1
    psi[12,14]  column_45  1
    psi[12,14]  column_46  1
    psi[12,15]  OBJ       0
    psi[13,0]  OBJ       0
    psi[13,1]  OBJ       0
    psi[13,2]  OBJ       0
    psi[13,3]  OBJ       0
    psi[13,4]  OBJ       0
    psi[13,5]  OBJ       0
    psi[13,6]  OBJ       0
    psi[13,7]  OBJ       0
    psi[13,8]  OBJ       0
    psi[13,9]  OBJ       0
    psi[13,10]  OBJ       1
    psi[13,10]  column_0  1
    psi[13,10]  column_1  1
    psi[13,10]  column_2  1
    psi[13,10]  column_3  1
    psi[13,10]  column_4  1
    psi[13,10]  column_5  1
    psi[13,10]  column_6  1
    psi[13,10]  column_7  1
    psi[13,10]  column_8  1
    psi[13,10]  column_9  1
    psi[13,10]  column_10  1
    psi[13,10]  column_11  1
    psi[13,10]  column_12  1
    psi[13,10]  column_13  1
    psi[13,10]  column_14  1
    psi[13,10]  column_15  1
    psi[13,10]  column_16  1
    psi[13,10]  column_17  1
    psi[13,10]  column_18  1
    psi[13,10]  column_19  1
    psi[13,10]  column_20  1
    psi[13,10]  column_21  1
    psi[13,10]  column_22  1
    psi[13,10]  column_23  1
    psi[13,10]  column_24  1
    psi[13,10]  column_25  1
    psi[13,10]  column_26  1
    psi[13,10]  column_27  1
    psi[13,10]  column_28  1
    psi[13,10]  column_29  1
    psi[13,10]  column_30  1
    psi[13,10]  column_31  1
    psi[13,10]  column_32  1
    psi[13,10]  column_33  1
    psi[13,10]  column_34  1
    psi[13,10]  column_35  1
    psi[13,10]  column_36  1
    psi[13,10]  column_37  1
    psi[13,10]  column_38  1
    psi[13,10]  column_39  1
    psi[13,10]  column_40  1
    psi[13,10]  column_41  1
    psi[13,10]  column_42  1
    psi[13,10]  column_43  1
    psi[13,10]  column_44  1
    psi[13,10]  column_45  1
    psi[13,10]  column_46  1
    psi[13,11]  OBJ       0
    psi[13,12]  OBJ       0
    psi[13,13]  OBJ       0
    psi[13,14]  OBJ       0
    psi[13,15]  OBJ       0
    psi[13,16]  OBJ       0
    psi[13,17]  OBJ       0
    psi[13,18]  OBJ       0
    psi[13,19]  OBJ       0
    psi[14,0]  OBJ       0
    psi[14,1]  OBJ       0
    psi[14,2]  OBJ       0
    psi[14,3]  OBJ       0
    psi[14,4]  OBJ       0
    psi[14,5]  OBJ       0
    psi[14,6]  OBJ       0
    psi[14,7]  OBJ       0
    psi[14,8]  OBJ       0
    psi[14,9]  OBJ       0
    psi[14,10]  OBJ       1
    psi[14,10]  column_0  1
    psi[14,10]  column_1  1
    psi[14,10]  column_2  1
    psi[14,10]  column_3  1
    psi[14,10]  column_4  1
    psi[14,10]  column_5  1
    psi[14,10]  column_6  1
    psi[14,10]  column_7  1
    psi[14,10]  column_8  1
    psi[14,10]  column_9  1
    psi[14,10]  column_10  1
    psi[14,10]  column_11  1
    psi[14,10]  column_12  1
    psi[14,10]  column_13  1
    psi[14,10]  column_14  1
    psi[14,10]  column_15  1
    psi[14,10]  column_16  1
    psi[14,10]  column_17  1
    psi[14,10]  column_18  1
    psi[14,10]  column_19  1
    psi[14,10]  column_20  1
    psi[14,10]  column_21  1
    psi[14,10]  column_22  1
    psi[14,10]  column_23  1
    psi[14,10]  column_24  1
    psi[14,10]  column_25  1
    psi[14,10]  column_26  1
    psi[14,10]  column_27  1
    psi[14,10]  column_28  1
    psi[14,10]  column_29  1
    psi[14,10]  column_30  1
    psi[14,10]  column_31  1
    psi[14,10]  column_32  1
    psi[14,10]  column_33  1
    psi[14,10]  column_34  1
    psi[14,10]  column_35  1
    psi[14,10]  column_36  1
    psi[14,10]  column_37  1
    psi[14,10]  column_38  1
    psi[14,10]  column_39  1
    psi[14,10]  column_40  1
    psi[14,10]  column_41  1
    psi[14,10]  column_42  1
    psi[14,10]  column_43  1
    psi[14,10]  column_44  1
    psi[14,10]  column_45  1
    psi[14,10]  column_46  1
    psi[14,11]  OBJ       0
    psi[14,12]  OBJ       0
    psi[14,13]  OBJ       0
    psi[14,14]  OBJ       0
    psi[14,15]  OBJ       0
    psi[14,16]  OBJ       0
    psi[14,17]  OBJ       0
    psi[14,18]  OBJ       0
    psi[15,0]  OBJ       0
    psi[15,1]  OBJ       0
    psi[15,2]  OBJ       0
    psi[15,3]  OBJ       0
    psi[15,4]  OBJ       0
    psi[15,5]  OBJ       0
    psi[15,6]  OBJ       0
    psi[15,7]  OBJ       0
    psi[15,8]  OBJ       0
    psi[15,9]  OBJ       0
    psi[15,10]  OBJ       1
    psi[15,10]  column_0  1
    psi[15,10]  column_1  1
    psi[15,10]  column_2  1
    psi[15,10]  column_3  1
    psi[15,10]  column_4  1
    psi[15,10]  column_5  1
    psi[15,10]  column_6  1
    psi[15,10]  column_7  1
    psi[15,10]  column_8  1
    psi[15,10]  column_9  1
    psi[15,10]  column_10  1
    psi[15,10]  column_11  1
    psi[15,10]  column_12  1
    psi[15,10]  column_13  1
    psi[15,10]  column_14  1
    psi[15,10]  column_15  1
    psi[15,10]  column_16  1
    psi[15,10]  column_17  1
    psi[15,10]  column_18  1
    psi[15,10]  column_19  1
    psi[15,10]  column_20  1
    psi[15,10]  column_21  1
    psi[15,10]  column_22  1
    psi[15,10]  column_23  1
    psi[15,10]  column_24  1
    psi[15,10]  column_25  1
    psi[15,10]  column_26  1
    psi[15,10]  column_27  1
    psi[15,10]  column_28  1
    psi[15,10]  column_29  1
    psi[15,10]  column_30  1
    psi[15,10]  column_31  1
    psi[15,10]  column_32  1
    psi[15,10]  column_33  1
    psi[15,10]  column_34  1
    psi[15,10]  column_35  1
    psi[15,10]  column_36  1
    psi[15,10]  column_37  1
    psi[15,10]  column_38  1
    psi[15,10]  column_39  1
    psi[15,10]  column_40  1
    psi[15,10]  column_41  1
    psi[15,10]  column_42  1
    psi[15,10]  column_43  1
    psi[15,10]  column_44  1
    psi[15,10]  column_45  1
    psi[15,10]  column_46  1
    psi[15,11]  OBJ       0
    psi[15,12]  OBJ       0
    psi[15,13]  OBJ       0
    psi[15,14]  OBJ       0
    psi[15,15]  OBJ       0
    psi[15,16]  OBJ       0
    psi[15,17]  OBJ       0
    psi[15,18]  OBJ       0
    psi[15,19]  OBJ       0
    psi[16,0]  OBJ       0
    psi[16,1]  OBJ       0
    psi[16,2]  OBJ       0
    psi[16,3]  OBJ       8.2299555825268977e-01
    psi[16,3]  column_0  1
    psi[16,3]  column_1  1
    psi[16,3]  column_2  1
    psi[16,3]  column_4  1
    psi[16,3]  column_5  1
    psi[16,3]  column_6  1
    psi[16,3]  column_9  1
    psi[16,3]  column_10  1
    psi[16,3]  column_11  1
    psi[16,3]  column_12  1
    psi[16,3]  column_15  1
    psi[16,3]  column_16  1
    psi[16,3]  column_17  1
    psi[16,3]  column_18  1
    psi[16,3]  column_19  1
    psi[16,3]  column_20  1
    psi[16,3]  column_22  1
    psi[16,3]  column_24  1
    psi[16,3]  column_25  1
    psi[16,3]  column_28  1
    psi[16,3]  column_29  1
    psi[16,3]  column_32  1
    psi[16,3]  column_33  1
    psi[16,3]  column_34  1
    psi[16,3]  column_41  1
    psi[16,3]  column_42  1
    psi[16,3]  column_44  1
    psi[16,3]  column_45  1
    psi[16,3]  column_46  1
    psi[16,4]  OBJ       0
    psi[16,5]  OBJ       0
    psi[16,6]  OBJ       0
    psi[16,7]  OBJ       0
    psi[16,8]  OBJ       0
    psi[16,9]  OBJ       0
    psi[16,10]  OBJ       0
    psi[16,11]  OBJ       1.7700444174731023e-01
    psi[16,11]  column_3  1
    psi[16,11]  column_7  1
    psi[16,11]  column_8  1
    psi[16,11]  column_13  1
    psi[16,11]  column_14  1
    psi[16,11]  column_21  1
    psi[16,11]  column_23  1
    psi[16,11]  column_26  1
    psi[16,11]  column_27  1
    psi[16,11]  column_30  1
    psi[16,11]  column_31  1
    psi[16,11]  column_35  1
    psi[16,11]  column_36  1
    psi[16,11]  column_37  1
    psi[16,11]  column_38  1
    psi[16,11]  column_39  1
    psi[16,11]  column_40  1
    psi[16,11]  column_43  1
    psi[17,16]  OBJ       1
    psi[17,16]  column_0  1
    psi[17,16]  column_1  1
    psi[17,16]  column_2  1
    psi[17,16]  column_3  1
    psi[17,16]  column_4  1
    psi[17,16]  column_5  1
    psi[17,16]  column_6  1
    psi[17,16]  column_7  1
    psi[17,16]  column_8  1
    psi[17,16]  column_9  1
    psi[17,16]  column_10  1
    psi[17,16]  column_11  1
    psi[17,16]  column_12  1
    psi[17,16]  column_13  1
    psi[17,16]  column_14  1
    psi[17,16]  column_15  1
    psi[17,16]  column_16  1
    psi[17,16]  column_17  1
    psi[17,16]  column_18  1
    psi[17,16]  column_19  1
    psi[17,16]  column_20  1
    psi[17,16]  column_21  1
    psi[17,16]  column_22  1
    psi[17,16]  column_23  1
    psi[17,16]  column_24  1
    psi[17,16]  column_25  1
    psi[17,16]  column_26  1
    psi[17,16]  column_27  1
    psi[17,16]  column_28  1
    psi[17,16]  column_29  1
    psi[17,16]  column_30  1
    psi[17,16]  column_31  1
    psi[17,16]  column_32  1
    psi[17,16]  column_33  1
    psi[17,16]  column_34  1
    psi[17,16]  column_35  1
    psi[17,16]  column_36  1
    psi[17,16]  column_37  1
    psi[17,16]  column_38  1
    psi[17,16]  column_39  1
    psi[17,16]  column_40  1
    psi[17,16]  column_41  1
    psi[17,16]  column_42  1
    psi[17,16]  column_43  1
    psi[17,16]  column_44  1
    psi[17,16]  column_45  1
    psi[17,16]  column_46  1
    psi[18,0]  OBJ       0
    psi[18,1]  OBJ       0
    psi[18,2]  OBJ       0
    psi[18,3]  OBJ       0
    psi[18,4]  OBJ       0
    psi[18,5]  OBJ       0
    psi[18,6]  OBJ       0
    psi[18,7]  OBJ       1
    psi[18,7]  column_0  1
    psi[18,7]  column_1  1
    psi[18,7]  column_2  1
    psi[18,7]  column_3  1
    psi[18,7]  column_4  1
    psi[18,7]  column_5  1
    psi[18,7]  column_6  1
    psi[18,7]  column_7  1
    psi[18,7]  column_8  1
    psi[18,7]  column_9  1
    psi[18,7]  column_10  1
    psi[18,7]  column_11  1
    psi[18,7]  column_12  1
    psi[18,7]  column_13  1
    psi[18,7]  column_14  1
    psi[18,7]  column_15  1
    psi[18,7]  column_16  1
    psi[18,7]  column_17  1
    psi[18,7]  column_18  1
    psi[18,7]  column_19  1
    psi[18,7]  column_20  1
    psi[18,7]  column_21  1
    psi[18,7]  column_22  1
    psi[18,7]  column_23  1
    psi[18,7]  column_24  1
    psi[18,7]  column_25  1
    psi[18,7]  column_26  1
    psi[18,7]  column_27  1
    psi[18,7]  column_28  1
    psi[18,7]  column_29  1
    psi[18,7]  column_30  1
    psi[18,7]  column_31  1
    psi[18,7]  column_32  1
    psi[18,7]  column_33  1
    psi[18,7]  column_34  1
    psi[18,7]  column_35  1
    psi[18,7]  column_36  1
    psi[18,7]  column_37  1
    psi[18,7]  column_38  1
    psi[18,7]  column_39  1
    psi[18,7]  column_40  1
    psi[18,7]  column_41  1
    psi[18,7]  column_42  1
    psi[18,7]  column_43  1
    psi[18,7]  column_44  1
    psi[18,7]  column_45  1
    psi[18,7]  column_46  1
    psi[18,8]  OBJ       0
    psi[18,9]  OBJ       0
    psi[18,10]  OBJ       0
    psi[18,11]  OBJ       0
    psi[18,12]  OBJ       0
    psi[18,13]  OBJ       0
    psi[18,14]  OBJ       0
    psi[18,15]  OBJ       0
    psi[19,0]  OBJ       0
    psi[19,1]  OBJ       0
    psi[19,2]  OBJ       0
    psi[19,3]  OBJ       0
    psi[19,4]  OBJ       0
    psi[19,5]  OBJ       0
    psi[19,6]  OBJ       0
    psi[19,7]  OBJ       0
    psi[19,8]  OBJ       0
    psi[19,9]  OBJ       1
    psi[19,9]  column_0  1
    psi[19,9]  column_1  1
    psi[19,9]  column_2  1
    psi[19,9]  column_3  1
    psi[19,9]  column_4  1
    psi[19,9]  column_5  1
    psi[19,9]  column_6  1
    psi[19,9]  column_7  1
    psi[19,9]  column_8  1
    psi[19,9]  column_9  1
    psi[19,9]  column_10  1
    psi[19,9]  column_11  1
    psi[19,9]  column_12  1
    psi[19,9]  column_13  1
    psi[19,9]  column_14  1
    psi[19,9]  column_15  1
    psi[19,9]  column_16  1
    psi[19,9]  column_17  1
    psi[19,9]  column_18  1
    psi[19,9]  column_19  1
    psi[19,9]  column_20  1
    psi[19,9]  column_21  1
    psi[19,9]  column_22  1
    psi[19,9]  column_23  1
    psi[19,9]  column_24  1
    psi[19,9]  column_25  1
    psi[19,9]  column_26  1
    psi[19,9]  column_27  1
    psi[19,9]  column_28  1
    psi[19,9]  column_29  1
    psi[19,9]  column_30  1
    psi[19,9]  column_31  1
    psi[19,9]  column_32  1
    psi[19,9]  column_33  1
    psi[19,9]  column_34  1
    psi[19,9]  column_35  1
    psi[19,9]  column_36  1
    psi[19,9]  column_37  1
    psi[19,9]  column_38  1
    psi[19,9]  column_39  1
    psi[19,9]  column_40  1
    psi[19,9]  column_41  1
    psi[19,9]  column_42  1
    psi[19,9]  column_43  1
    psi[19,9]  column_44  1
    psi[19,9]  column_45  1
    psi[19,9]  column_46  1
    psi[19,10]  OBJ       0
    psi[19,11]  OBJ       0
    psi[19,12]  OBJ       0
    psi[19,13]  OBJ       0
    psi[19,14]  OBJ       0
    psi[19,15]  OBJ       0
    psi[19,16]  OBJ       0
    psi[19,17]  OBJ       0
    psi[19,18]  OBJ       0
    psi[19,19]  OBJ       0
    psi[20,0]  OBJ       0
    psi[20,1]  OBJ       0
    psi[20,2]  OBJ       0
    psi[20,3]  OBJ       0
    psi[20,4]  OBJ       0
    psi[20,5]  OBJ       0
    psi[20,6]  OBJ       0
    psi[20,7]  OBJ       1
    psi[20,7]  column_0  1
    psi[20,7]  column_1  1
    psi[20,7]  column_2  1
    psi[20,7]  column_3  1
    psi[20,7]  column_4  1
    psi[20,7]  column_5  1
    psi[20,7]  column_6  1
    psi[20,7]  column_7  1
    psi[20,7]  column_8  1
    psi[20,7]  column_9  1
    psi[20,7]  column_10  1
    psi[20,7]  column_11  1
    psi[20,7]  column_12  1
    psi[20,7]  column_13  1
    psi[20,7]  column_14  1
    psi[20,7]  column_15  1
    psi[20,7]  column_16  1
    psi[20,7]  column_17  1
    psi[20,7]  column_18  1
    psi[20,7]  column_19  1
    psi[20,7]  column_20  1
    psi[20,7]  column_21  1
    psi[20,7]  column_22  1
    psi[20,7]  column_23  1
    psi[20,7]  column_24  1
    psi[20,7]  column_25  1
    psi[20,7]  column_26  1
    psi[20,7]  column_27  1
    psi[20,7]  column_28  1
    psi[20,7]  column_29  1
    psi[20,7]  column_32  1
    psi[20,7]  column_33  1
    psi[20,7]  column_35  1
    psi[20,7]  column_36  1
    psi[20,7]  column_37  1
    psi[20,7]  column_39  1
    psi[20,7]  column_40  1
    psi[20,7]  column_43  1
    psi[20,7]  column_44  1
    psi[20,8]  OBJ       0
    psi[20,9]  OBJ       0
    psi[20,10]  OBJ       0
    psi[20,11]  OBJ       0
    psi[20,12]  OBJ       0
    psi[20,13]  column_30  1
    psi[20,13]  column_31  1
    psi[20,13]  column_34  1
    psi[20,13]  column_38  1
    psi[20,13]  column_41  1
    psi[20,13]  column_42  1
    psi[20,13]  column_45  1
    psi[20,13]  column_46  1
    psi[20,14]  OBJ       0
    psi[20,15]  OBJ       0
    psi[21,0]  OBJ       0
    psi[21,1]  OBJ       0
    psi[21,2]  OBJ       0
    psi[21,3]  OBJ       0
    psi[21,4]  OBJ       0
    psi[21,5]  OBJ       0
    psi[21,6]  OBJ       0
    psi[21,7]  OBJ       0
    psi[21,8]  OBJ       0
    psi[21,9]  OBJ       1
    psi[21,9]  column_0  1
    psi[21,9]  column_1  1
    psi[21,9]  column_2  1
    psi[21,9]  column_3  1
    psi[21,9]  column_4  1
    psi[21,9]  column_5  1
    psi[21,9]  column_6  1
    psi[21,9]  column_7  1
    psi[21,9]  column_8  1
    psi[21,9]  column_9  1
    psi[21,9]  column_10  1
    psi[21,9]  column_11  1
    psi[21,9]  column_12  1
    psi[21,9]  column_13  1
    psi[21,9]  column_14  1
    psi[21,9]  column_15  1
    psi[21,9]  column_16  1
    psi[21,9]  column_17  1
    psi[21,9]  column_18  1
    psi[21,9]  column_19  1
    psi[21,9]  column_20  1
    psi[21,9]  column_21  1
    psi[21,9]  column_22  1
    psi[21,9]  column_23  1
    psi[21,9]  column_24  1
    psi[21,9]  column_25  1
    psi[21,9]  column_26  1
    psi[21,9]  column_27  1
    psi[21,9]  column_28  1
    psi[21,9]  column_29  1
    psi[21,9]  column_30  1
    psi[21,9]  column_31  1
    psi[21,9]  column_32  1
    psi[21,9]  column_33  1
    psi[21,9]  column_34  1
    psi[21,9]  column_35  1
    psi[21,9]  column_36  1
    psi[21,9]  column_37  1
    psi[21,9]  column_38  1
    psi[21,9]  column_39  1
    psi[21,9]  column_40  1
    psi[21,9]  column_41  1
    psi[21,9]  column_42  1
    psi[21,9]  column_43  1
    psi[21,9]  column_44  1
    psi[21,9]  column_45  1
    psi[21,9]  column_46  1
    psi[21,10]  OBJ       0
    psi[21,11]  OBJ       0
    psi[21,12]  OBJ       0
    psi[21,13]  OBJ       0
    psi[21,14]  OBJ       0
    psi[21,15]  OBJ       0
    psi[21,16]  OBJ       0
    psi[21,17]  OBJ       0
    psi[21,18]  OBJ       0
    psi[21,19]  OBJ       0
    psi[22,0]  OBJ       0
    psi[22,1]  OBJ       0
    psi[22,2]  OBJ       0
    psi[22,3]  OBJ       0
    psi[22,4]  OBJ       0
    psi[22,5]  OBJ       0
    psi[22,6]  OBJ       0
    psi[22,7]  OBJ       0
    psi[22,8]  OBJ       0
    psi[22,9]  OBJ       0
    psi[22,10]  OBJ       1
    psi[22,10]  column_0  1
    psi[22,10]  column_1  1
    psi[22,10]  column_2  1
    psi[22,10]  column_3  1
    psi[22,10]  column_4  1
    psi[22,10]  column_5  1
    psi[22,10]  column_6  1
    psi[22,10]  column_7  1
    psi[22,10]  column_8  1
    psi[22,10]  column_9  1
    psi[22,10]  column_10  1
    psi[22,10]  column_11  1
    psi[22,10]  column_12  1
    psi[22,10]  column_13  1
    psi[22,10]  column_14  1
    psi[22,10]  column_15  1
    psi[22,10]  column_16  1
    psi[22,10]  column_17  1
    psi[22,10]  column_18  1
    psi[22,10]  column_19  1
    psi[22,10]  column_20  1
    psi[22,10]  column_21  1
    psi[22,10]  column_22  1
    psi[22,10]  column_23  1
    psi[22,10]  column_24  1
    psi[22,10]  column_25  1
    psi[22,10]  column_26  1
    psi[22,10]  column_27  1
    psi[22,10]  column_28  1
    psi[22,10]  column_29  1
    psi[22,10]  column_30  1
    psi[22,10]  column_31  1
    psi[22,10]  column_32  1
    psi[22,10]  column_33  1
    psi[22,10]  column_34  1
    psi[22,10]  column_35  1
    psi[22,10]  column_36  1
    psi[22,10]  column_37  1
    psi[22,10]  column_38  1
    psi[22,10]  column_39  1
    psi[22,10]  column_40  1
    psi[22,10]  column_41  1
    psi[22,10]  column_42  1
    psi[22,10]  column_43  1
    psi[22,10]  column_44  1
    psi[22,10]  column_45  1
    psi[22,10]  column_46  1
    psi[22,11]  OBJ       0
    psi[22,12]  OBJ       0
    psi[22,13]  OBJ       0
    psi[22,14]  OBJ       0
    psi[22,15]  OBJ       0
    psi[22,16]  OBJ       0
    psi[22,17]  OBJ       0
    psi[22,18]  OBJ       0
    psi[22,19]  OBJ       0
    psi[23,0]  OBJ       0
    psi[23,1]  OBJ       0
    psi[23,2]  OBJ       0
    psi[23,3]  OBJ       0
    psi[23,4]  OBJ       0
    psi[23,5]  OBJ       0
    psi[23,6]  OBJ       0
    psi[23,7]  OBJ       0
    psi[23,8]  OBJ       9.4444444444444431e-01
    psi[23,8]  column_0  1
    psi[23,8]  column_1  1
    psi[23,8]  column_2  1
    psi[23,8]  column_3  1
    psi[23,8]  column_4  1
    psi[23,8]  column_5  1
    psi[23,8]  column_7  1
    psi[23,8]  column_9  1
    psi[23,8]  column_10  1
    psi[23,8]  column_11  1
    psi[23,8]  column_12  1
    psi[23,8]  column_13  1
    psi[23,8]  column_14  1
    psi[23,8]  column_15  1
    psi[23,8]  column_17  1
    psi[23,8]  column_18  1
    psi[23,8]  column_24  1
    psi[23,8]  column_26  1
    psi[23,8]  column_30  1
    psi[23,8]  column_31  1
    psi[23,8]  column_38  1
    psi[23,8]  column_40  1
    psi[23,8]  column_45  1
    psi[23,9]  OBJ       0
    psi[23,10]  OBJ       0
    psi[23,11]  OBJ       0
    psi[23,12]  OBJ       0
    psi[23,13]  OBJ       5.5555555555555650e-02
    psi[23,13]  column_6  1
    psi[23,13]  column_8  1
    psi[23,13]  column_16  1
    psi[23,13]  column_19  1
    psi[23,13]  column_20  1
    psi[23,13]  column_21  1
    psi[23,13]  column_22  1
    psi[23,13]  column_23  1
    psi[23,13]  column_25  1
    psi[23,13]  column_27  1
    psi[23,13]  column_28  1
    psi[23,13]  column_29  1
    psi[23,13]  column_32  1
    psi[23,13]  column_33  1
    psi[23,13]  column_34  1
    psi[23,13]  column_35  1
    psi[23,13]  column_36  1
    psi[23,13]  column_37  1
    psi[23,13]  column_39  1
    psi[23,13]  column_41  1
    psi[23,13]  column_42  1
    psi[23,13]  column_43  1
    psi[23,13]  column_44  1
    psi[23,13]  column_46  1
    psi[23,14]  OBJ       0
    psi[23,15]  OBJ       0
    psi[24,0]  OBJ       0
    psi[24,1]  OBJ       0
    psi[24,2]  OBJ       6.6816025856343442e-01
    psi[24,2]  column_0  1
    psi[24,2]  column_1  1
    psi[24,2]  column_4  1
    psi[24,2]  column_9  1
    psi[24,2]  column_10  1
    psi[24,2]  column_12  1
    psi[24,2]  column_13  1
    psi[24,2]  column_15  1
    psi[24,2]  column_16  1
    psi[24,2]  column_18  1
    psi[24,2]  column_19  1
    psi[24,2]  column_20  1
    psi[24,2]  column_29  1
    psi[24,2]  column_34  1
    psi[24,2]  column_38  1
    psi[24,2]  column_46  1
    psi[24,3]  OBJ       0
    psi[24,4]  OBJ       1.4375072866018429e-01
    psi[24,4]  column_14  1
    psi[24,4]  column_24  1
    psi[24,5]  column_11  1
    psi[24,5]  column_28  1
    psi[24,6]  column_32  1
    psi[24,6]  column_35  1
    psi[24,7]  column_2  1
    psi[24,7]  column_3  1
    psi[24,7]  column_22  1
    psi[24,7]  column_26  1
    psi[24,7]  column_30  1
    psi[24,7]  column_36  1
    psi[24,7]  column_40  1
    psi[24,7]  column_41  1
    psi[24,7]  column_45  1
    psi[24,8]  OBJ       1.8808901277635676e-01
    psi[24,8]  column_5  1
    psi[24,8]  column_6  1
    psi[24,8]  column_7  1
    psi[24,8]  column_8  1
    psi[24,8]  column_17  1
    psi[24,8]  column_21  1
    psi[24,8]  column_23  1
    psi[24,8]  column_25  1
    psi[24,8]  column_27  1
    psi[24,8]  column_31  1
    psi[24,8]  column_33  1
    psi[24,8]  column_37  1
    psi[24,8]  column_39  1
    psi[24,8]  column_42  1
    psi[24,8]  column_43  1
    psi[24,8]  column_44  1
    psi[25,0]  OBJ       0
    psi[25,1]  OBJ       0
    psi[25,2]  OBJ       0
    psi[25,3]  OBJ       0
    psi[25,4]  OBJ       0
    psi[25,5]  OBJ       0
    psi[25,6]  OBJ       0
    psi[25,7]  OBJ       1
    psi[25,7]  column_0  1
    psi[25,7]  column_1  1
    psi[25,7]  column_2  1
    psi[25,7]  column_3  1
    psi[25,7]  column_4  1
    psi[25,7]  column_5  1
    psi[25,7]  column_6  1
    psi[25,7]  column_7  1
    psi[25,7]  column_8  1
    psi[25,7]  column_9  1
    psi[25,7]  column_10  1
    psi[25,7]  column_11  1
    psi[25,7]  column_12  1
    psi[25,7]  column_13  1
    psi[25,7]  column_14  1
    psi[25,7]  column_15  1
    psi[25,7]  column_16  1
    psi[25,7]  column_17  1
    psi[25,7]  column_18  1
    psi[25,7]  column_19  1
    psi[25,7]  column_20  1
    psi[25,7]  column_21  1
    psi[25,7]  column_22  1
    psi[25,7]  column_23  1
    psi[25,7]  column_24  1
    psi[25,7]  column_25  1
    psi[25,7]  column_26  1
    psi[25,7]  column_27  1
    psi[25,7]  column_28  1
    psi[25,7]  column_29  1
    psi[25,7]  column_30  1
    psi[25,7]  column_31  1
    psi[25,7]  column_32  1
    psi[25,7]  column_33  1
    psi[25,7]  column_34  1
    psi[25,7]  column_35  1
    psi[25,7]  column_36  1
    psi[25,7]  column_37  1
    psi[25,7]  column_38  1
    psi[25,7]  column_39  1
    psi[25,7]  column_40  1
    psi[25,7]  column_41  1
    psi[25,7]  column_42  1
    psi[25,7]  column_43  1
    psi[25,7]  column_44  1
    psi[25,7]  column_45  1
    psi[25,7]  column_46  1
    psi[25,8]  OBJ       0
    psi[25,9]  OBJ       0
    psi[25,10]  OBJ       0
    psi[25,11]  OBJ       0
    psi[25,12]  OBJ       0
    psi[25,13]  OBJ       0
    psi[25,14]  OBJ       0
    psi[25,15]  OBJ       0
    psi[26,0]  OBJ       0
    psi[26,1]  OBJ       0
    psi[26,2]  OBJ       0
    psi[26,3]  OBJ       0
    psi[26,4]  OBJ       0
    psi[26,5]  OBJ       0
    psi[26,6]  OBJ       0
    psi[26,7]  OBJ       0
    psi[26,8]  OBJ       8.6492696889435716e-01
    psi[26,8]  column_0  1
    psi[26,8]  column_4  1
    psi[26,8]  column_5  1
    psi[26,8]  column_9  1
    psi[26,8]  column_11  1
    psi[26,8]  column_12  1
    psi[26,8]  column_13  1
    psi[26,8]  column_14  1
    psi[26,8]  column_15  1
    psi[26,8]  column_16  1
    psi[26,8]  column_17  1
    psi[26,8]  column_18  1
    psi[26,8]  column_19  1
    psi[26,8]  column_24  1
    psi[26,8]  column_25  1
    psi[26,8]  column_29  1
    psi[26,9]  OBJ       0
    psi[26,10]  OBJ       0
    psi[26,11]  OBJ       0
    psi[26,12]  OBJ       0
    psi[26,13]  OBJ       1.3507303110564281e-01
    psi[26,13]  column_1  1
    psi[26,13]  column_2  1
    psi[26,13]  column_3  1
    psi[26,13]  column_6  1
    psi[26,13]  column_7  1
    psi[26,13]  column_8  1
    psi[26,13]  column_10  1
    psi[26,13]  column_20  1
    psi[26,13]  column_21  1
    psi[26,13]  column_22  1
    psi[26,13]  column_23  1
    psi[26,13]  column_26  1
    psi[26,13]  column_27  1
    psi[26,13]  column_28  1
    psi[26,13]  column_30  1
    psi[26,13]  column_31  1
    psi[26,13]  column_32  1
    psi[26,13]  column_33  1
    psi[26,13]  column_34  1
    psi[26,13]  column_35  1
    psi[26,13]  column_36  1
    psi[26,13]  column_37  1
    psi[26,13]  column_38  1
    psi[26,13]  column_39  1
    psi[26,13]  column_40  1
    psi[26,13]  column_41  1
    psi[26,13]  column_42  1
    psi[26,13]  column_43  1
    psi[26,13]  column_44  1
    psi[26,13]  column_45  1
    psi[26,13]  column_46  1
    psi[26,14]  OBJ       0
    psi[26,15]  OBJ       0
    psi[27,0]  OBJ       0
    psi[27,1]  OBJ       0
    psi[27,2]  OBJ       0
    psi[27,3]  OBJ       0
    psi[27,4]  OBJ       0
    psi[27,5]  OBJ       0
    psi[27,6]  OBJ       0
    psi[27,7]  OBJ       0
    psi[27,8]  OBJ       0
    psi[27,9]  OBJ       1
    psi[27,9]  column_0  1
    psi[27,9]  column_1  1
    psi[27,9]  column_2  1
    psi[27,9]  column_3  1
    psi[27,9]  column_4  1
    psi[27,9]  column_5  1
    psi[27,9]  column_6  1
    psi[27,9]  column_7  1
    psi[27,9]  column_8  1
    psi[27,9]  column_9  1
    psi[27,9]  column_10  1
    psi[27,9]  column_11  1
    psi[27,9]  column_12  1
    psi[27,9]  column_13  1
    psi[27,9]  column_14  1
    psi[27,9]  column_15  1
    psi[27,9]  column_16  1
    psi[27,9]  column_17  1
    psi[27,9]  column_18  1
    psi[27,9]  column_19  1
    psi[27,9]  column_20  1
    psi[27,9]  column_21  1
    psi[27,9]  column_22  1
    psi[27,9]  column_23  1
    psi[27,9]  column_24  1
    psi[27,9]  column_25  1
    psi[27,9]  column_26  1
    psi[27,9]  column_27  1
    psi[27,9]  column_28  1
    psi[27,9]  column_29  1
    psi[27,9]  column_30  1
    psi[27,9]  column_31  1
    psi[27,9]  column_32  1
    psi[27,9]  column_33  1
    psi[27,9]  column_34  1
    psi[27,9]  column_35  1
    psi[27,9]  column_36  1
    psi[27,9]  column_37  1
    psi[27,9]  column_38  1
    psi[27,9]  column_39  1
    psi[27,9]  column_40  1
    psi[27,9]  column_41  1
    psi[27,9]  column_42  1
    psi[27,9]  column_43  1
    psi[27,9]  column_44  1
    psi[27,9]  column_45  1
    psi[27,9]  column_46  1
    psi[27,10]  OBJ       0
    psi[27,11]  OBJ       0
    psi[27,12]  OBJ       0
    psi[27,13]  OBJ       0
    psi[27,14]  OBJ       0
    psi[27,15]  OBJ       0
    psi[27,16]  OBJ       0
    psi[27,17]  OBJ       0
    psi[27,18]  OBJ       0
    psi[27,19]  OBJ       0
    psi[28,0]  OBJ       0
    psi[28,1]  OBJ       0
    psi[28,2]  OBJ       0
    psi[28,3]  OBJ       0
    psi[28,4]  OBJ       0
    psi[28,5]  OBJ       0
    psi[28,6]  OBJ       0
    psi[28,7]  OBJ       1
    psi[28,7]  column_0  1
    psi[28,7]  column_1  1
    psi[28,7]  column_2  1
    psi[28,7]  column_3  1
    psi[28,7]  column_4  1
    psi[28,7]  column_5  1
    psi[28,7]  column_6  1
    psi[28,7]  column_7  1
    psi[28,7]  column_8  1
    psi[28,7]  column_9  1
    psi[28,7]  column_10  1
    psi[28,7]  column_11  1
    psi[28,7]  column_12  1
    psi[28,7]  column_13  1
    psi[28,7]  column_14  1
    psi[28,7]  column_15  1
    psi[28,7]  column_16  1
    psi[28,7]  column_17  1
    psi[28,7]  column_18  1
    psi[28,7]  column_19  1
    psi[28,7]  column_20  1
    psi[28,7]  column_21  1
    psi[28,7]  column_22  1
    psi[28,7]  column_23  1
    psi[28,7]  column_24  1
    psi[28,7]  column_25  1
    psi[28,7]  column_26  1
    psi[28,7]  column_27  1
    psi[28,7]  column_28  1
    psi[28,7]  column_29  1
    psi[28,7]  column_30  1
    psi[28,7]  column_31  1
    psi[28,7]  column_32  1
    psi[28,7]  column_33  1
    psi[28,7]  column_34  1
    psi[28,7]  column_35  1
    psi[28,7]  column_36  1
    psi[28,7]  column_37  1
    psi[28,7]  column_38  1
    psi[28,7]  column_39  1
    psi[28,7]  column_40  1
    psi[28,7]  column_41  1
    psi[28,7]  column_42  1
    psi[28,7]  column_43  1
    psi[28,7]  column_44  1
    psi[28,7]  column_45  1
    psi[28,7]  column_46  1
    psi[28,8]  OBJ       0
    psi[28,9]  OBJ       0
    psi[28,10]  OBJ       0
    psi[28,11]  OBJ       0
    psi[28,12]  OBJ       0
    psi[28,13]  OBJ       0
    psi[28,14]  OBJ       0
    psi[28,15]  OBJ       0
    psi[29,0]  OBJ       0
    psi[29,1]  OBJ       0
    psi[29,2]  OBJ       0
    psi[29,3]  OBJ       0
    psi[29,4]  OBJ       0
    psi[29,5]  OBJ       0
    psi[29,6]  OBJ       0
    psi[29,7]  OBJ       1
    psi[29,7]  column_0  1
    psi[29,7]  column_1  1
    psi[29,7]  column_2  1
    psi[29,7]  column_3  1
    psi[29,7]  column_4  1
    psi[29,7]  column_5  1
    psi[29,7]  column_6  1
    psi[29,7]  column_7  1
    psi[29,7]  column_8  1
    psi[29,7]  column_9  1
    psi[29,7]  column_10  1
    psi[29,7]  column_11  1
    psi[29,7]  column_12  1
    psi[29,7]  column_13  1
    psi[29,7]  column_14  1
    psi[29,7]  column_15  1
    psi[29,7]  column_16  1
    psi[29,7]  column_17  1
    psi[29,7]  column_18  1
    psi[29,7]  column_19  1
    psi[29,7]  column_20  1
    psi[29,7]  column_21  1
    psi[29,7]  column_22  1
    psi[29,7]  column_23  1
    psi[29,7]  column_24  1
    psi[29,7]  column_25  1
    psi[29,7]  column_26  1
    psi[29,7]  column_27  1
    psi[29,7]  column_28  1
    psi[29,7]  column_29  1
    psi[29,7]  column_32  1
    psi[29,7]  column_33  1
    psi[29,7]  column_35  1
    psi[29,7]  column_36  1
    psi[29,7]  column_37  1
    psi[29,7]  column_39  1
    psi[29,7]  column_40  1
    psi[29,7]  column_43  1
    psi[29,8]  OBJ       0
    psi[29,9]  OBJ       0
    psi[29,10]  OBJ       0
    psi[29,11]  OBJ       0
    psi[29,12]  column_30  1
    psi[29,12]  column_31  1
    psi[29,12]  column_34  1
    psi[29,12]  column_38  1
    psi[29,12]  column_41  1
    psi[29,12]  column_42  1
    psi[29,12]  column_44  1
    psi[29,12]  column_45  1
    psi[29,12]  column_46  1
    psi[29,13]  OBJ       0
    psi[29,14]  OBJ       0
    psi[29,15]  OBJ       0
    psi[30,0]  OBJ       0
    psi[30,1]  OBJ       0
    psi[30,2]  OBJ       0
    psi[30,3]  OBJ       0
    psi[30,4]  OBJ       0
    psi[30,5]  OBJ       0
    psi[30,6]  OBJ       0
    psi[30,7]  OBJ       0
    psi[30,8]  OBJ       0
    psi[30,9]  OBJ       0
    psi[30,10]  OBJ       0
    psi[30,11]  OBJ       1
    psi[30,11]  column_0  1
    psi[30,11]  column_1  1
    psi[30,11]  column_2  1
    psi[30,11]  column_3  1
    psi[30,11]  column_4  1
    psi[30,11]  column_5  1
    psi[30,11]  column_6  1
    psi[30,11]  column_7  1
    psi[30,11]  column_8  1
    psi[30,11]  column_9  1
    psi[30,11]  column_10  1
    psi[30,11]  column_11  1
    psi[30,11]  column_12  1
    psi[30,11]  column_13  1
    psi[30,11]  column_14  1
    psi[30,11]  column_15  1
    psi[30,11]  column_16  1
    psi[30,11]  column_17  1
    psi[30,11]  column_18  1
    psi[30,11]  column_19  1
    psi[30,11]  column_20  1
    psi[30,11]  column_21  1
    psi[30,11]  column_22  1
    psi[30,11]  column_23  1
    psi[30,11]  column_24  1
    psi[30,11]  column_25  1
    psi[30,11]  column_26  1
    psi[30,11]  column_27  1
    psi[30,11]  column_28  1
    psi[30,11]  column_29  1
    psi[30,11]  column_30  1
    psi[30,11]  column_31  1
    psi[30,11]  column_32  1
    psi[30,11]  column_33  1
    psi[30,11]  column_34  1
    psi[30,11]  column_35  1
    psi[30,11]  column_36  1
    psi[30,11]  column_37  1
    psi[30,11]  column_38  1
    psi[30,11]  column_39  1
    psi[30,11]  column_40  1
    psi[30,11]  column_41  1
    psi[30,11]  column_42  1
    psi[30,11]  column_43  1
    psi[30,11]  column_44  1
    psi[30,11]  column_45  1
    psi[30,11]  column_46  1
    psi[30,12]  OBJ       0
    psi[30,13]  OBJ       0
    psi[30,14]  OBJ       0
    psi[30,15]  OBJ       0
    psi[30,16]  OBJ       0
    psi[30,17]  OBJ       0
    psi[30,18]  OBJ       0
    psi[30,19]  OBJ       0
    psi[30,20]  OBJ       0
    psi[31,0]  OBJ       0
    psi[31,1]  OBJ       0
    psi[31,2]  OBJ       0
    psi[31,3]  OBJ       0
    psi[31,4]  OBJ       0
    psi[31,5]  OBJ       0
    psi[31,6]  OBJ       0
    psi[31,7]  OBJ       1
    psi[31,7]  column_0  1
    psi[31,7]  column_1  1
    psi[31,7]  column_2  1
    psi[31,7]  column_3  1
    psi[31,7]  column_4  1
    psi[31,7]  column_5  1
    psi[31,7]  column_6  1
    psi[31,7]  column_7  1
    psi[31,7]  column_8  1
    psi[31,7]  column_9  1
    psi[31,7]  column_10  1
    psi[31,7]  column_11  1
    psi[31,7]  column_12  1
    psi[31,7]  column_13  1
    psi[31,7]  column_14  1
    psi[31,7]  column_15  1
    psi[31,7]  column_16  1
    psi[31,7]  column_17  1
    psi[31,7]  column_18  1
    psi[31,7]  column_19  1
    psi[31,7]  column_20  1
    psi[31,7]  column_21  1
    psi[31,7]  column_22  1
    psi[31,7]  column_23  1
    psi[31,7]  column_24  1
    psi[31,7]  column_25  1
    psi[31,7]  column_26  1
    psi[31,7]  column_27  1
    psi[31,7]  column_28  1
    psi[31,7]  column_29  1
    psi[31,7]  column_30  1
    psi[31,7]  column_31  1
    psi[31,7]  column_32  1
    psi[31,7]  column_33  1
    psi[31,7]  column_34  1
    psi[31,7]  column_35  1
    psi[31,7]  column_36  1
    psi[31,7]  column_37  1
    psi[31,7]  column_38  1
    psi[31,7]  column_39  1
    psi[31,7]  column_40  1
    psi[31,7]  column_41  1
    psi[31,7]  column_42  1
    psi[31,7]  column_43  1
    psi[31,7]  column_44  1
    psi[31,7]  column_45  1
    psi[31,7]  column_46  1
    psi[31,8]  OBJ       0
    psi[31,9]  OBJ       0
    psi[31,10]  OBJ       0
    psi[31,11]  OBJ       0
    psi[31,12]  OBJ       0
    psi[31,13]  OBJ       0
    psi[31,14]  OBJ       0
    psi[31,15]  OBJ       0
    psi[32,0]  OBJ       0
    psi[32,1]  OBJ       0
    psi[32,2]  OBJ       0
    psi[32,3]  OBJ       0
    psi[32,4]  OBJ       0
    psi[32,5]  OBJ       0
    psi[32,6]  OBJ       0
    psi[32,7]  OBJ       0
    psi[32,8]  OBJ       1
    psi[32,8]  column_0  1
    psi[32,8]  column_1  1
    psi[32,8]  column_2  1
    psi[32,8]  column_3  1
    psi[32,8]  column_4  1
    psi[32,8]  column_5  1
    psi[32,8]  column_6  1
    psi[32,8]  column_7  1
    psi[32,8]  column_8  1
    psi[32,8]  column_9  1
    psi[32,8]  column_10  1
    psi[32,8]  column_11  1
    psi[32,8]  column_12  1
    psi[32,8]  column_13  1
    psi[32,8]  column_14  1
    psi[32,8]  column_15  1
    psi[32,8]  column_16  1
    psi[32,8]  column_17  1
    psi[32,8]  column_18  1
    psi[32,8]  column_19  1
    psi[32,8]  column_20  1
    psi[32,8]  column_21  1
    psi[32,8]  column_22  1
    psi[32,8]  column_23  1
    psi[32,8]  column_24  1
    psi[32,8]  column_25  1
    psi[32,8]  column_26  1
    psi[32,8]  column_27  1
    psi[32,8]  column_28  1
    psi[32,8]  column_29  1
    psi[32,8]  column_30  1
    psi[32,8]  column_31  1
    psi[32,8]  column_32  1
    psi[32,8]  column_33  1
    psi[32,8]  column_34  1
    psi[32,8]  column_35  1
    psi[32,8]  column_36  1
    psi[32,8]  column_37  1
    psi[32,8]  column_38  1
    psi[32,8]  column_39  1
    psi[32,8]  column_40  1
    psi[32,8]  column_41  1
    psi[32,8]  column_42  1
    psi[32,8]  column_43  1
    psi[32,8]  column_44  1
    psi[32,8]  column_45  1
    psi[32,8]  column_46  1
    psi[32,9]  OBJ       0
    psi[32,10]  OBJ       0
    psi[32,11]  OBJ       0
    psi[32,12]  OBJ       0
    psi[32,13]  OBJ       0
    psi[32,14]  OBJ       0
    psi[32,15]  OBJ       0
    psi[33,0]  OBJ       0
    psi[33,1]  OBJ       0
    psi[33,2]  OBJ       0
    psi[33,3]  OBJ       0
    psi[33,4]  OBJ       0
    psi[33,5]  OBJ       0
    psi[33,6]  OBJ       0
    psi[33,7]  OBJ       0
    psi[33,8]  OBJ       0
    psi[33,9]  OBJ       0
    psi[33,10]  OBJ       0
    psi[33,11]  OBJ       0
    psi[33,12]  OBJ       0
    psi[33,13]  OBJ       1
    psi[33,13]  column_0  1
    psi[33,13]  column_1  1
    psi[33,13]  column_2  1
    psi[33,13]  column_3  1
    psi[33,13]  column_4  1
    psi[33,13]  column_5  1
    psi[33,13]  column_6  1
    psi[33,13]  column_7  1
    psi[33,13]  column_8  1
    psi[33,13]  column_9  1
    psi[33,13]  column_10  1
    psi[33,13]  column_11  1
    psi[33,13]  column_12  1
    psi[33,13]  column_13  1
    psi[33,13]  column_14  1
    psi[33,13]  column_15  1
    psi[33,13]  column_16  1
    psi[33,13]  column_17  1
    psi[33,13]  column_18  1
    psi[33,13]  column_19  1
    psi[33,13]  column_20  1
    psi[33,13]  column_21  1
    psi[33,13]  column_22  1
    psi[33,13]  column_23  1
    psi[33,13]  column_24  1
    psi[33,13]  column_25  1
    psi[33,13]  column_26  1
    psi[33,13]  column_27  1
    psi[33,13]  column_28  1
    psi[33,13]  column_29  1
    psi[33,13]  column_30  1
    psi[33,13]  column_31  1
    psi[33,13]  column_32  1
    psi[33,13]  column_33  1
    psi[33,13]  column_34  1
    psi[33,13]  column_35  1
    psi[33,13]  column_36  1
    psi[33,13]  column_37  1
    psi[33,13]  column_38  1
    psi[33,13]  column_39  1
    psi[33,13]  column_40  1
    psi[33,13]  column_41  1
    psi[33,13]  column_42  1
    psi[33,13]  column_43  1
    psi[33,13]  column_44  1
    psi[33,13]  column_45  1
    psi[33,13]  column_46  1
    psi[33,14]  OBJ       0
    psi[33,15]  OBJ       0
    psi[33,16]  OBJ       0
    psi[33,17]  OBJ       0
    psi[33,18]  OBJ       0
    psi[33,19]  OBJ       0
    psi[33,20]  OBJ       0
    psi[33,21]  OBJ       0
    psi[33,22]  OBJ       0
    psi[33,23]  OBJ       0
    psi[33,24]  OBJ       0
    psi[34,0]  OBJ       0
    psi[34,1]  OBJ       0
    psi[34,2]  OBJ       0
    psi[34,3]  OBJ       0
    psi[34,4]  OBJ       0
    psi[34,5]  OBJ       0
    psi[34,6]  OBJ       0
    psi[34,7]  OBJ       0
    psi[34,8]  OBJ       1
    psi[34,8]  column_0  1
    psi[34,8]  column_1  1
    psi[34,8]  column_2  1
    psi[34,8]  column_3  1
    psi[34,8]  column_4  1
    psi[34,8]  column_5  1
    psi[34,8]  column_6  1
    psi[34,8]  column_7  1
    psi[34,8]  column_8  1
    psi[34,8]  column_9  1
    psi[34,8]  column_10  1
    psi[34,8]  column_11  1
    psi[34,8]  column_12  1
    psi[34,8]  column_13  1
    psi[34,8]  column_14  1
    psi[34,8]  column_15  1
    psi[34,8]  column_16  1
    psi[34,8]  column_17  1
    psi[34,8]  column_18  1
    psi[34,8]  column_19  1
    psi[34,8]  column_20  1
    psi[34,8]  column_21  1
    psi[34,8]  column_22  1
    psi[34,8]  column_23  1
    psi[34,8]  column_24  1
    psi[34,8]  column_25  1
    psi[34,8]  column_26  1
    psi[34,8]  column_27  1
    psi[34,8]  column_28  1
    psi[34,8]  column_29  1
    psi[34,8]  column_30  1
    psi[34,8]  column_31  1
    psi[34,8]  column_32  1
    psi[34,8]  column_33  1
    psi[34,8]  column_34  1
    psi[34,8]  column_35  1
    psi[34,8]  column_36  1
    psi[34,8]  column_37  1
    psi[34,8]  column_38  1
    psi[34,8]  column_39  1
    psi[34,8]  column_40  1
    psi[34,8]  column_41  1
    psi[34,8]  column_42  1
    psi[34,8]  column_43  1
    psi[34,8]  column_44  1
    psi[34,8]  column_45  1
    psi[34,8]  column_46  1
    psi[34,9]  OBJ       0
    psi[34,10]  OBJ       0
    psi[34,11]  OBJ       0
    psi[34,12]  OBJ       0
    psi[34,13]  OBJ       0
    psi[34,14]  OBJ       0
    psi[34,15]  OBJ       0
    psi[35,0]  OBJ       0
    psi[35,1]  OBJ       0
    psi[35,2]  OBJ       0
    psi[35,3]  OBJ       0
    psi[35,4]  OBJ       0
    psi[35,5]  OBJ       0
    psi[35,6]  OBJ       0
    psi[35,7]  OBJ       0
    psi[35,8]  OBJ       0
    psi[35,9]  OBJ       1
    psi[35,9]  column_0  1
    psi[35,9]  column_1  1
    psi[35,9]  column_2  1
    psi[35,9]  column_3  1
    psi[35,9]  column_4  1
    psi[35,9]  column_5  1
    psi[35,9]  column_6  1
    psi[35,9]  column_7  1
    psi[35,9]  column_8  1
    psi[35,9]  column_9  1
    psi[35,9]  column_10  1
    psi[35,9]  column_11  1
    psi[35,9]  column_12  1
    psi[35,9]  column_13  1
    psi[35,9]  column_14  1
    psi[35,9]  column_15  1
    psi[35,9]  column_16  1
    psi[35,9]  column_17  1
    psi[35,9]  column_18  1
    psi[35,9]  column_19  1
    psi[35,9]  column_20  1
    psi[35,9]  column_21  1
    psi[35,9]  column_22  1
    psi[35,9]  column_23  1
    psi[35,9]  column_24  1
    psi[35,9]  column_25  1
    psi[35,9]  column_26  1
    psi[35,9]  column_27  1
    psi[35,9]  column_28  1
    psi[35,9]  column_29  1
    psi[35,9]  column_30  1
    psi[35,9]  column_31  1
    psi[35,9]  column_32  1
    psi[35,9]  column_33  1
    psi[35,9]  column_34  1
    psi[35,9]  column_35  1
    psi[35,9]  column_36  1
    psi[35,9]  column_37  1
    psi[35,9]  column_38  1
    psi[35,9]  column_39  1
    psi[35,9]  column_40  1
    psi[35,9]  column_41  1
    psi[35,9]  column_42  1
    psi[35,9]  column_43  1
    psi[35,9]  column_44  1
    psi[35,9]  column_45  1
    psi[35,9]  column_46  1
    psi[35,10]  OBJ       0
    psi[35,11]  OBJ       0
    psi[35,12]  OBJ       0
    psi[35,13]  OBJ       0
    psi[35,14]  OBJ       0
    psi[35,15]  OBJ       0
    psi[35,16]  OBJ       0
    psi[35,17]  OBJ       0
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
    a         column_13  1
    a         column_14  1
    a         column_15  1
    a         column_16  1
    a         column_17  1
    a         column_18  1
    a         column_19  1
    a         column_20  1
    a         column_21  1
    a         column_22  1
    a         column_23  1
    a         column_24  1
    a         column_25  1
    a         column_26  1
    a         column_27  1
    a         column_28  1
    a         column_29  1
    a         column_30  1
    a         column_31  1
    a         column_32  1
    a         column_33  1
    a         column_34  1
    a         column_35  1
    a         column_36  1
    a         column_37  1
    a         column_38  1
    a         column_39  1
    a         column_40  1
    a         column_41  1
    a         column_42  1
    a         column_43  1
    a         column_44  1
    a         column_45  1
    a         column_46  1
RHS
    RHS1      column_0  1.1507627578536928e-01
    RHS1      column_1  1.2073250383989552e-01
    RHS1      column_2  1.2292597944336392e-01
    RHS1      column_3  1.4652411311190594e-01
    RHS1      column_4  1.1090541771750757e-01
    RHS1      column_5  1.1997140706346748e-01
    RHS1      column_6  1.4140965258399632e-01
    RHS1      column_7  1.4291402423861593e-01
    RHS1      column_8  1.6062762636743566e-01
    RHS1      column_9  1.0297492506569134e-01
    RHS1      column_10  1.1645336519211724e-01
    RHS1      column_11  9.5862663828110123e-02
    RHS1      column_12  9.4844902442851931e-02
    RHS1      column_13  1.1139806990349520e-01
    RHS1      column_14  9.8231163338409491e-02
    RHS1      column_15  1.1098189684690885e-01
    RHS1      column_16  1.2292597944336392e-01
    RHS1      column_17  1.0715845426300490e-01
    RHS1      column_18  1.1420799663648208e-01
    RHS1      column_19  1.5794563015874763e-01
    RHS1      column_20  1.6693273858434091e-01
    RHS1      column_21  1.7673301734156738e-01
    RHS1      column_22  1.5869169735550204e-01
    RHS1      column_23  1.7005069287767885e-01
    RHS1      column_24  1.1335919752928866e-01
    RHS1      column_25  1.5412547718983971e-01
    RHS1      column_26  1.5781325578675465e-01
    RHS1      column_27  1.7005069287767885e-01
    RHS1      column_28  1.4595201749380879e-01
    RHS1      column_29  1.2522680278230228e-01
    RHS1      column_30  1.8304711832841691e-01
    RHS1      column_31  1.8688326698699761e-01
    RHS1      column_32  1.7195253188749260e-01
    RHS1      column_33  1.7948112112205092e-01
    RHS1      column_34  1.9440636028069608e-01
    RHS1      column_35  1.7831198089290656e-01
    RHS1      column_36  1.8074401196344753e-01
    RHS1      column_37  1.8476342910680826e-01
    RHS1      column_38  1.9482757889588867e-01
    RHS1      column_39  1.7011063561244011e-01
    RHS1      column_40  1.6739914058779728e-01
    RHS1      column_41  1.7636751967725350e-01
    RHS1      column_42  1.8064391142357378e-01
    RHS1      column_43  1.7153013728224367e-01
    RHS1      column_44  1.7918766292628274e-01
    RHS1      column_45  1.7764490677046002e-01
    RHS1      column_46  1.8810877923742392e-01
BOUNDS
 FX BND1      psi[1,4]  0
 LO BND1      psi[2,0]  -0.05
 UP BND1      psi[2,0]  0.05
 LO BND1      psi[2,1]  -0.05
 UP BND1      psi[2,1]  0.05
 LO BND1      psi[2,2]  -0.05
 UP BND1      psi[2,2]  0.05
 LO BND1      psi[2,3]  -0.05
 UP BND1      psi[2,3]  0.05
 LO BND1      psi[2,4]  -0.05
 UP BND1      psi[2,4]  0.05
 LO BND1      psi[2,5]  -0.05
 UP BND1      psi[2,5]  0.05
 LO BND1      psi[2,6]  -0.05
 UP BND1      psi[2,6]  0.05
 LO BND1      psi[2,7]  -0.05
 UP BND1      psi[2,7]  0.05
 LO BND1      psi[2,8]  -0.05
 UP BND1      psi[2,8]  0.05
 LO BND1      psi[2,9]  -0.05
 UP BND1      psi[2,9]  0.05
 LO BND1      psi[2,10]  -0.05
 UP BND1      psi[2,10]  0.05
 LO BND1      psi[2,11]  -0.05
 UP BND1      psi[2,11]  0.05
 FX BND1      psi[2,12]  0
 LO BND1      psi[2,13]  -0.05
 UP BND1      psi[2,13]  0.05
 LO BND1      psi[2,14]  -0.05
 UP BND1      psi[2,14]  0.05
 LO BND1      psi[2,15]  -0.05
 UP BND1      psi[2,15]  0.05
 LO BND1      psi[2,16]  -0.05
 UP BND1      psi[2,16]  0.05
 LO BND1      psi[2,17]  -0.05
 UP BND1      psi[2,17]  0.05
 LO BND1      psi[2,18]  -0.05
 UP BND1      psi[2,18]  0.05
 LO BND1      psi[2,19]  -0.05
 UP BND1      psi[2,19]  0.05
 LO BND1      psi[2,20]  -0.05
 UP BND1      psi[2,20]  0.05
 LO BND1      psi[2,21]  -0.05
 UP BND1      psi[2,21]  0.05
 LO BND1      psi[2,22]  -0.05
 UP BND1      psi[2,22]  0.05
 LO BND1      psi[2,23]  -0.05
 UP BND1      psi[2,23]  0.05
 FX BND1      psi[3,13]  0
 LO BND1      psi[4,0]  -0.05
 UP BND1      psi[4,0]  0.05
 LO BND1      psi[4,1]  -0.05
 UP BND1      psi[4,1]  0.05
 LO BND1      psi[4,2]  -0.05
 UP BND1      psi[4,2]  0.05
 LO BND1      psi[4,3]  -0.05
 UP BND1      psi[4,3]  0.05
 LO BND1      psi[4,4]  -0.05
 UP BND1      psi[4,4]  0.05
 LO BND1      psi[4,5]  -0.05
 UP BND1      psi[4,5]  0.05
 LO BND1      psi[4,6]  -0.05
 UP BND1      psi[4,6]  0.05
 FX BND1      psi[4,7]  0
 LO BND1      psi[4,8]  -0.05
 UP BND1      psi[4,8]  0.05
 LO BND1      psi[4,9]  -0.05
 UP BND1      psi[4,9]  0.05
 LO BND1      psi[4,10]  -0.05
 UP BND1      psi[4,10]  0.05
 LO BND1      psi[4,11]  -0.05
 UP BND1      psi[4,11]  0.05
 LO BND1      psi[4,12]  -0.05
 UP BND1      psi[4,12]  0.05
 LO BND1      psi[4,13]  -0.05
 UP BND1      psi[4,13]  0.05
 LO BND1      psi[4,14]  -0.05
 UP BND1      psi[4,14]  0.05
 LO BND1      psi[4,15]  -0.05
 UP BND1      psi[4,15]  0.05
 LO BND1      psi[5,0]  -0.05
 UP BND1      psi[5,0]  0.05
 LO BND1      psi[5,1]  -0.05
 UP BND1      psi[5,1]  0.05
 LO BND1      psi[5,2]  -0.05
 UP BND1      psi[5,2]  0.05
 LO BND1      psi[5,3]  -0.05
 UP BND1      psi[5,3]  0.05
 LO BND1      psi[5,4]  -0.05
 UP BND1      psi[5,4]  0.05
 LO BND1      psi[5,5]  -0.05
 UP BND1      psi[5,5]  0.05
 LO BND1      psi[5,6]  -0.05
 UP BND1      psi[5,6]  0.05
 LO BND1      psi[5,7]  -0.05
 UP BND1      psi[5,7]  0.05
 FX BND1      psi[5,8]  0
 LO BND1      psi[5,9]  -0.05
 UP BND1      psi[5,9]  0.05
 LO BND1      psi[5,10]  -0.05
 UP BND1      psi[5,10]  0.05
 LO BND1      psi[5,11]  -0.05
 UP BND1      psi[5,11]  0.05
 LO BND1      psi[5,12]  -0.05
 UP BND1      psi[5,12]  0.05
 LO BND1      psi[5,13]  -0.05
 UP BND1      psi[5,13]  0.05
 LO BND1      psi[5,14]  -0.05
 UP BND1      psi[5,14]  0.05
 LO BND1      psi[5,15]  -0.05
 UP BND1      psi[5,15]  0.05
 FX BND1      psi[6,4]  0
 LO BND1      psi[7,0]  -0.05
 UP BND1      psi[7,0]  0.05
 LO BND1      psi[7,1]  -0.05
 UP BND1      psi[7,1]  0.05
 LO BND1      psi[7,2]  -0.05
 UP BND1      psi[7,2]  0.05
 LO BND1      psi[7,3]  -0.05
 UP BND1      psi[7,3]  0.05
 LO BND1      psi[7,4]  -0.05
 UP BND1      psi[7,4]  0.05
 LO BND1      psi[7,5]  -0.05
 UP BND1      psi[7,5]  0.05
 LO BND1      psi[7,6]  -0.05
 UP BND1      psi[7,6]  0.05
 LO BND1      psi[7,7]  -0.05
 UP BND1      psi[7,7]  0.05
 LO BND1      psi[7,8]  -0.05
 UP BND1      psi[7,8]  0.05
 LO BND1      psi[7,9]  -0.05
 UP BND1      psi[7,9]  0.05
 FX BND1      psi[7,10]  0
 LO BND1      psi[7,11]  -0.05
 UP BND1      psi[7,11]  0.05
 LO BND1      psi[7,12]  -0.05
 UP BND1      psi[7,12]  0.05
 LO BND1      psi[7,13]  -0.05
 UP BND1      psi[7,13]  0.05
 LO BND1      psi[7,14]  -0.05
 UP BND1      psi[7,14]  0.05
 LO BND1      psi[7,15]  -0.05
 UP BND1      psi[7,15]  0.05
 LO BND1      psi[7,16]  -0.05
 UP BND1      psi[7,16]  0.05
 LO BND1      psi[7,17]  -0.05
 UP BND1      psi[7,17]  0.05
 LO BND1      psi[7,18]  -0.05
 UP BND1      psi[7,18]  0.05
 LO BND1      psi[7,19]  -0.05
 UP BND1      psi[7,19]  0.05
 LO BND1      psi[8,0]  -0.05
 UP BND1      psi[8,0]  0.05
 LO BND1      psi[8,1]  -0.05
 UP BND1      psi[8,1]  0.05
 LO BND1      psi[8,2]  -0.05
 UP BND1      psi[8,2]  0.05
 LO BND1      psi[8,3]  -0.05
 UP BND1      psi[8,3]  0.05
 LO BND1      psi[8,4]  -0.05
 UP BND1      psi[8,4]  0.05
 LO BND1      psi[8,5]  -0.05
 UP BND1      psi[8,5]  0.05
 LO BND1      psi[8,6]  -0.05
 UP BND1      psi[8,6]  0.05
 FX BND1      psi[8,7]  0
 LO BND1      psi[8,8]  -0.05
 UP BND1      psi[8,8]  0.05
 LO BND1      psi[8,9]  -0.05
 UP BND1      psi[8,9]  0.05
 LO BND1      psi[8,10]  -0.05
 UP BND1      psi[8,10]  0.05
 LO BND1      psi[8,11]  -0.05
 UP BND1      psi[8,11]  0.05
 LO BND1      psi[8,12]  -0.05
 UP BND1      psi[8,12]  0.05
 LO BND1      psi[8,13]  -0.05
 UP BND1      psi[8,13]  0.05
 LO BND1      psi[8,14]  -0.05
 UP BND1      psi[8,14]  0.05
 LO BND1      psi[8,15]  -0.05
 UP BND1      psi[8,15]  0.05
 LO BND1      psi[9,0]  -0.05
 UP BND1      psi[9,0]  0.05
 LO BND1      psi[9,1]  -0.05
 UP BND1      psi[9,1]  0.05
 LO BND1      psi[9,2]  -0.05
 UP BND1      psi[9,2]  0.05
 LO BND1      psi[9,3]  -0.05
 UP BND1      psi[9,3]  0.05
 LO BND1      psi[9,4]  -0.05
 UP BND1      psi[9,4]  0.05
 LO BND1      psi[9,5]  -0.05
 UP BND1      psi[9,5]  0.05
 LO BND1      psi[9,6]  -0.05
 UP BND1      psi[9,6]  0.05
 LO BND1      psi[9,7]  -0.05
 UP BND1      psi[9,7]  0.05
 LO BND1      psi[9,8]  -0.05
 UP BND1      psi[9,8]  0.05
 LO BND1      psi[9,9]  -0.05
 UP BND1      psi[9,9]  0.05
 FX BND1      psi[9,10]  0
 LO BND1      psi[9,11]  -0.05
 UP BND1      psi[9,11]  0.05
 LO BND1      psi[9,12]  -0.05
 UP BND1      psi[9,12]  0.05
 LO BND1      psi[9,13]  -0.05
 UP BND1      psi[9,13]  0.05
 LO BND1      psi[9,14]  -0.05
 UP BND1      psi[9,14]  0.05
 LO BND1      psi[10,0]  -0.05
 UP BND1      psi[10,0]  0.05
 LO BND1      psi[10,1]  -0.05
 UP BND1      psi[10,1]  0.05
 LO BND1      psi[10,2]  -0.05
 UP BND1      psi[10,2]  0.05
 LO BND1      psi[10,3]  -0.05
 UP BND1      psi[10,3]  0.05
 LO BND1      psi[10,4]  -0.05
 UP BND1      psi[10,4]  0.05
 LO BND1      psi[10,5]  -0.05
 UP BND1      psi[10,5]  0.05
 FX BND1      psi[10,6]  0
 LO BND1      psi[10,7]  -0.05
 UP BND1      psi[10,7]  0.05
 LO BND1      psi[10,8]  -0.05
 UP BND1      psi[10,8]  0.05
 LO BND1      psi[10,9]  -0.05
 UP BND1      psi[10,9]  0.05
 LO BND1      psi[10,10]  -0.05
 UP BND1      psi[10,10]  0.05
 LO BND1      psi[10,11]  -0.05
 UP BND1      psi[10,11]  0.05
 LO BND1      psi[11,0]  -0.05
 UP BND1      psi[11,0]  0.05
 LO BND1      psi[11,1]  -0.05
 UP BND1      psi[11,1]  0.05
 LO BND1      psi[11,2]  -0.05
 UP BND1      psi[11,2]  0.05
 LO BND1      psi[11,3]  -0.05
 UP BND1      psi[11,3]  0.05
 LO BND1      psi[11,4]  -0.05
 UP BND1      psi[11,4]  0.05
 LO BND1      psi[11,5]  -0.05
 UP BND1      psi[11,5]  0.05
 LO BND1      psi[11,6]  -0.05
 UP BND1      psi[11,6]  0.05
 FX BND1      psi[11,7]  0
 LO BND1      psi[11,8]  -0.05
 UP BND1      psi[11,8]  0.05
 LO BND1      psi[11,9]  -0.05
 UP BND1      psi[11,9]  0.05
 LO BND1      psi[11,10]  -0.05
 UP BND1      psi[11,10]  0.05
 LO BND1      psi[11,11]  -0.05
 UP BND1      psi[11,11]  0.05
 LO BND1      psi[11,12]  -0.05
 UP BND1      psi[11,12]  0.05
 LO BND1      psi[11,13]  -0.05
 UP BND1      psi[11,13]  0.05
 LO BND1      psi[11,14]  -0.05
 UP BND1      psi[11,14]  0.05
 LO BND1      psi[11,15]  -0.05
 UP BND1      psi[11,15]  0.05
 LO BND1      psi[12,0]  -0.05
 UP BND1      psi[12,0]  0.05
 LO BND1      psi[12,1]  -0.05
 UP BND1      psi[12,1]  0.05
 LO BND1      psi[12,2]  -0.05
 UP BND1      psi[12,2]  0.05
 LO BND1      psi[12,3]  -0.05
 UP BND1      psi[12,3]  0.05
 LO BND1      psi[12,4]  -0.05
 UP BND1      psi[12,4]  0.05
 LO BND1      psi[12,5]  -0.05
 UP BND1      psi[12,5]  0.05
 LO BND1      psi[12,6]  -0.05
 UP BND1      psi[12,6]  0.05
 LO BND1      psi[12,7]  -0.05
 UP BND1      psi[12,7]  0.05
 FX BND1      psi[12,8]  0
 LO BND1      psi[12,9]  -0.05
 UP BND1      psi[12,9]  0.05
 LO BND1      psi[12,10]  -0.05
 UP BND1      psi[12,10]  0.05
 LO BND1      psi[12,11]  -0.05
 UP BND1      psi[12,11]  0.05
 LO BND1      psi[12,12]  -0.05
 UP BND1      psi[12,12]  0.05
 LO BND1      psi[12,13]  -0.05
 UP BND1      psi[12,13]  0.05
 LO BND1      psi[12,14]  -0.05
 UP BND1      psi[12,14]  0.05
 LO BND1      psi[12,15]  -0.05
 UP BND1      psi[12,15]  0.05
 LO BND1      psi[13,0]  -0.05
 UP BND1      psi[13,0]  0.05
 LO BND1      psi[13,1]  -0.05
 UP BND1      psi[13,1]  0.05
 LO BND1      psi[13,2]  -0.05
 UP BND1      psi[13,2]  0.05
 LO BND1      psi[13,3]  -0.05
 UP BND1      psi[13,3]  0.05
 LO BND1      psi[13,4]  -0.05
 UP BND1      psi[13,4]  0.05
 LO BND1      psi[13,5]  -0.05
 UP BND1      psi[13,5]  0.05
 LO BND1      psi[13,6]  -0.05
 UP BND1      psi[13,6]  0.05
 LO BND1      psi[13,7]  -0.05
 UP BND1      psi[13,7]  0.05
 LO BND1      psi[13,8]  -0.05
 UP BND1      psi[13,8]  0.05
 LO BND1      psi[13,9]  -0.05
 UP BND1      psi[13,9]  0.05
 FX BND1      psi[13,10]  0
 LO BND1      psi[13,11]  -0.05
 UP BND1      psi[13,11]  0.05
 LO BND1      psi[13,12]  -0.05
 UP BND1      psi[13,12]  0.05
 LO BND1      psi[13,13]  -0.05
 UP BND1      psi[13,13]  0.05
 LO BND1      psi[13,14]  -0.05
 UP BND1      psi[13,14]  0.05
 LO BND1      psi[13,15]  -0.05
 UP BND1      psi[13,15]  0.05
 LO BND1      psi[13,16]  -0.05
 UP BND1      psi[13,16]  0.05
 LO BND1      psi[13,17]  -0.05
 UP BND1      psi[13,17]  0.05
 LO BND1      psi[13,18]  -0.05
 UP BND1      psi[13,18]  0.05
 LO BND1      psi[13,19]  -0.05
 UP BND1      psi[13,19]  0.05
 LO BND1      psi[14,0]  -0.05
 UP BND1      psi[14,0]  0.05
 LO BND1      psi[14,1]  -0.05
 UP BND1      psi[14,1]  0.05
 LO BND1      psi[14,2]  -0.05
 UP BND1      psi[14,2]  0.05
 LO BND1      psi[14,3]  -0.05
 UP BND1      psi[14,3]  0.05
 LO BND1      psi[14,4]  -0.05
 UP BND1      psi[14,4]  0.05
 LO BND1      psi[14,5]  -0.05
 UP BND1      psi[14,5]  0.05
 LO BND1      psi[14,6]  -0.05
 UP BND1      psi[14,6]  0.05
 LO BND1      psi[14,7]  -0.05
 UP BND1      psi[14,7]  0.05
 LO BND1      psi[14,8]  -0.05
 UP BND1      psi[14,8]  0.05
 LO BND1      psi[14,9]  -0.05
 UP BND1      psi[14,9]  0.05
 FX BND1      psi[14,10]  0
 LO BND1      psi[14,11]  -0.05
 UP BND1      psi[14,11]  0.05
 LO BND1      psi[14,12]  -0.05
 UP BND1      psi[14,12]  0.05
 LO BND1      psi[14,13]  -0.05
 UP BND1      psi[14,13]  0.05
 LO BND1      psi[14,14]  -0.05
 UP BND1      psi[14,14]  0.05
 LO BND1      psi[14,15]  -0.05
 UP BND1      psi[14,15]  0.05
 LO BND1      psi[14,16]  -0.05
 UP BND1      psi[14,16]  0.05
 LO BND1      psi[14,17]  -0.05
 UP BND1      psi[14,17]  0.05
 LO BND1      psi[14,18]  -0.05
 UP BND1      psi[14,18]  0.05
 LO BND1      psi[15,0]  -0.05
 UP BND1      psi[15,0]  0.05
 LO BND1      psi[15,1]  -0.05
 UP BND1      psi[15,1]  0.05
 LO BND1      psi[15,2]  -0.05
 UP BND1      psi[15,2]  0.05
 LO BND1      psi[15,3]  -0.05
 UP BND1      psi[15,3]  0.05
 LO BND1      psi[15,4]  -0.05
 UP BND1      psi[15,4]  0.05
 LO BND1      psi[15,5]  -0.05
 UP BND1      psi[15,5]  0.05
 LO BND1      psi[15,6]  -0.05
 UP BND1      psi[15,6]  0.05
 LO BND1      psi[15,7]  -0.05
 UP BND1      psi[15,7]  0.05
 LO BND1      psi[15,8]  -0.05
 UP BND1      psi[15,8]  0.05
 LO BND1      psi[15,9]  -0.05
 UP BND1      psi[15,9]  0.05
 FX BND1      psi[15,10]  0
 LO BND1      psi[15,11]  -0.05
 UP BND1      psi[15,11]  0.05
 LO BND1      psi[15,12]  -0.05
 UP BND1      psi[15,12]  0.05
 LO BND1      psi[15,13]  -0.05
 UP BND1      psi[15,13]  0.05
 LO BND1      psi[15,14]  -0.05
 UP BND1      psi[15,14]  0.05
 LO BND1      psi[15,15]  -0.05
 UP BND1      psi[15,15]  0.05
 LO BND1      psi[15,16]  -0.05
 UP BND1      psi[15,16]  0.05
 LO BND1      psi[15,17]  -0.05
 UP BND1      psi[15,17]  0.05
 LO BND1      psi[15,18]  -0.05
 UP BND1      psi[15,18]  0.05
 LO BND1      psi[15,19]  -0.05
 UP BND1      psi[15,19]  0.05
 LO BND1      psi[16,0]  -0.05
 UP BND1      psi[16,0]  0.05
 LO BND1      psi[16,1]  -0.05
 UP BND1      psi[16,1]  0.05
 LO BND1      psi[16,2]  -0.05
 UP BND1      psi[16,2]  0.05
 FX BND1      psi[16,3]  0
 LO BND1      psi[16,4]  -0.05
 UP BND1      psi[16,4]  0.05
 LO BND1      psi[16,5]  -0.05
 UP BND1      psi[16,5]  0.05
 LO BND1      psi[16,6]  -0.05
 UP BND1      psi[16,6]  0.05
 LO BND1      psi[16,7]  -0.05
 UP BND1      psi[16,7]  0.05
 LO BND1      psi[16,8]  -0.05
 UP BND1      psi[16,8]  0.05
 LO BND1      psi[16,9]  -0.05
 UP BND1      psi[16,9]  0.05
 LO BND1      psi[16,10]  -0.05
 UP BND1      psi[16,10]  0.05
 LO BND1      psi[16,11]  -0.05
 UP BND1      psi[16,11]  0.05
 FX BND1      psi[17,16]  0
 LO BND1      psi[18,0]  -0.05
 UP BND1      psi[18,0]  0.05
 LO BND1      psi[18,1]  -0.05
 UP BND1      psi[18,1]  0.05
 LO BND1      psi[18,2]  -0.05
 UP BND1      psi[18,2]  0.05
 LO BND1      psi[18,3]  -0.05
 UP BND1      psi[18,3]  0.05
 LO BND1      psi[18,4]  -0.05
 UP BND1      psi[18,4]  0.05
 LO BND1      psi[18,5]  -0.05
 UP BND1      psi[18,5]  0.05
 LO BND1      psi[18,6]  -0.05
 UP BND1      psi[18,6]  0.05
 FX BND1      psi[18,7]  0
 LO BND1      psi[18,8]  -0.05
 UP BND1      psi[18,8]  0.05
 LO BND1      psi[18,9]  -0.05
 UP BND1      psi[18,9]  0.05
 LO BND1      psi[18,10]  -0.05
 UP BND1      psi[18,10]  0.05
 LO BND1      psi[18,11]  -0.05
 UP BND1      psi[18,11]  0.05
 LO BND1      psi[18,12]  -0.05
 UP BND1      psi[18,12]  0.05
 LO BND1      psi[18,13]  -0.05
 UP BND1      psi[18,13]  0.05
 LO BND1      psi[18,14]  -0.05
 UP BND1      psi[18,14]  0.05
 LO BND1      psi[18,15]  -0.05
 UP BND1      psi[18,15]  0.05
 LO BND1      psi[19,0]  -0.05
 UP BND1      psi[19,0]  0.05
 LO BND1      psi[19,1]  -0.05
 UP BND1      psi[19,1]  0.05
 LO BND1      psi[19,2]  -0.05
 UP BND1      psi[19,2]  0.05
 LO BND1      psi[19,3]  -0.05
 UP BND1      psi[19,3]  0.05
 LO BND1      psi[19,4]  -0.05
 UP BND1      psi[19,4]  0.05
 LO BND1      psi[19,5]  -0.05
 UP BND1      psi[19,5]  0.05
 LO BND1      psi[19,6]  -0.05
 UP BND1      psi[19,6]  0.05
 LO BND1      psi[19,7]  -0.05
 UP BND1      psi[19,7]  0.05
 LO BND1      psi[19,8]  -0.05
 UP BND1      psi[19,8]  0.05
 FX BND1      psi[19,9]  0
 LO BND1      psi[19,10]  -0.05
 UP BND1      psi[19,10]  0.05
 LO BND1      psi[19,11]  -0.05
 UP BND1      psi[19,11]  0.05
 LO BND1      psi[19,12]  -0.05
 UP BND1      psi[19,12]  0.05
 LO BND1      psi[19,13]  -0.05
 UP BND1      psi[19,13]  0.05
 LO BND1      psi[19,14]  -0.05
 UP BND1      psi[19,14]  0.05
 LO BND1      psi[19,15]  -0.05
 UP BND1      psi[19,15]  0.05
 LO BND1      psi[19,16]  -0.05
 UP BND1      psi[19,16]  0.05
 LO BND1      psi[19,17]  -0.05
 UP BND1      psi[19,17]  0.05
 LO BND1      psi[19,18]  -0.05
 UP BND1      psi[19,18]  0.05
 LO BND1      psi[19,19]  -0.05
 UP BND1      psi[19,19]  0.05
 LO BND1      psi[20,0]  -0.05
 UP BND1      psi[20,0]  0.05
 LO BND1      psi[20,1]  -0.05
 UP BND1      psi[20,1]  0.05
 LO BND1      psi[20,2]  -0.05
 UP BND1      psi[20,2]  0.05
 LO BND1      psi[20,3]  -0.05
 UP BND1      psi[20,3]  0.05
 LO BND1      psi[20,4]  -0.05
 UP BND1      psi[20,4]  0.05
 LO BND1      psi[20,5]  -0.05
 UP BND1      psi[20,5]  0.05
 LO BND1      psi[20,6]  -0.05
 UP BND1      psi[20,6]  0.05
 FX BND1      psi[20,7]  0
 LO BND1      psi[20,8]  -0.05
 UP BND1      psi[20,8]  0.05
 LO BND1      psi[20,9]  -0.05
 UP BND1      psi[20,9]  0.05
 LO BND1      psi[20,10]  -0.05
 UP BND1      psi[20,10]  0.05
 LO BND1      psi[20,11]  -0.05
 UP BND1      psi[20,11]  0.05
 LO BND1      psi[20,12]  -0.05
 UP BND1      psi[20,12]  0.05
 LO BND1      psi[20,13]  -0.05
 UP BND1      psi[20,13]  0.05
 LO BND1      psi[20,14]  -0.05
 UP BND1      psi[20,14]  0.05
 LO BND1      psi[20,15]  -0.05
 UP BND1      psi[20,15]  0.05
 LO BND1      psi[21,0]  -0.05
 UP BND1      psi[21,0]  0.05
 LO BND1      psi[21,1]  -0.05
 UP BND1      psi[21,1]  0.05
 LO BND1      psi[21,2]  -0.05
 UP BND1      psi[21,2]  0.05
 LO BND1      psi[21,3]  -0.05
 UP BND1      psi[21,3]  0.05
 LO BND1      psi[21,4]  -0.05
 UP BND1      psi[21,4]  0.05
 LO BND1      psi[21,5]  -0.05
 UP BND1      psi[21,5]  0.05
 LO BND1      psi[21,6]  -0.05
 UP BND1      psi[21,6]  0.05
 LO BND1      psi[21,7]  -0.05
 UP BND1      psi[21,7]  0.05
 LO BND1      psi[21,8]  -0.05
 UP BND1      psi[21,8]  0.05
 FX BND1      psi[21,9]  0
 LO BND1      psi[21,10]  -0.05
 UP BND1      psi[21,10]  0.05
 LO BND1      psi[21,11]  -0.05
 UP BND1      psi[21,11]  0.05
 LO BND1      psi[21,12]  -0.05
 UP BND1      psi[21,12]  0.05
 LO BND1      psi[21,13]  -0.05
 UP BND1      psi[21,13]  0.05
 LO BND1      psi[21,14]  -0.05
 UP BND1      psi[21,14]  0.05
 LO BND1      psi[21,15]  -0.05
 UP BND1      psi[21,15]  0.05
 LO BND1      psi[21,16]  -0.05
 UP BND1      psi[21,16]  0.05
 LO BND1      psi[21,17]  -0.05
 UP BND1      psi[21,17]  0.05
 LO BND1      psi[21,18]  -0.05
 UP BND1      psi[21,18]  0.05
 LO BND1      psi[21,19]  -0.05
 UP BND1      psi[21,19]  0.05
 LO BND1      psi[22,0]  -0.05
 UP BND1      psi[22,0]  0.05
 LO BND1      psi[22,1]  -0.05
 UP BND1      psi[22,1]  0.05
 LO BND1      psi[22,2]  -0.05
 UP BND1      psi[22,2]  0.05
 LO BND1      psi[22,3]  -0.05
 UP BND1      psi[22,3]  0.05
 LO BND1      psi[22,4]  -0.05
 UP BND1      psi[22,4]  0.05
 LO BND1      psi[22,5]  -0.05
 UP BND1      psi[22,5]  0.05
 LO BND1      psi[22,6]  -0.05
 UP BND1      psi[22,6]  0.05
 LO BND1      psi[22,7]  -0.05
 UP BND1      psi[22,7]  0.05
 LO BND1      psi[22,8]  -0.05
 UP BND1      psi[22,8]  0.05
 LO BND1      psi[22,9]  -0.05
 UP BND1      psi[22,9]  0.05
 FX BND1      psi[22,10]  0
 LO BND1      psi[22,11]  -0.05
 UP BND1      psi[22,11]  0.05
 LO BND1      psi[22,12]  -0.05
 UP BND1      psi[22,12]  0.05
 LO BND1      psi[22,13]  -0.05
 UP BND1      psi[22,13]  0.05
 LO BND1      psi[22,14]  -0.05
 UP BND1      psi[22,14]  0.05
 LO BND1      psi[22,15]  -0.05
 UP BND1      psi[22,15]  0.05
 LO BND1      psi[22,16]  -0.05
 UP BND1      psi[22,16]  0.05
 LO BND1      psi[22,17]  -0.05
 UP BND1      psi[22,17]  0.05
 LO BND1      psi[22,18]  -0.05
 UP BND1      psi[22,18]  0.05
 LO BND1      psi[22,19]  -0.05
 UP BND1      psi[22,19]  0.05
 LO BND1      psi[23,0]  -0.05
 UP BND1      psi[23,0]  0.05
 LO BND1      psi[23,1]  -0.05
 UP BND1      psi[23,1]  0.05
 LO BND1      psi[23,2]  -0.05
 UP BND1      psi[23,2]  0.05
 LO BND1      psi[23,3]  -0.05
 UP BND1      psi[23,3]  0.05
 LO BND1      psi[23,4]  -0.05
 UP BND1      psi[23,4]  0.05
 LO BND1      psi[23,5]  -0.05
 UP BND1      psi[23,5]  0.05
 LO BND1      psi[23,6]  -0.05
 UP BND1      psi[23,6]  0.05
 LO BND1      psi[23,7]  -0.05
 UP BND1      psi[23,7]  0.05
 FX BND1      psi[23,8]  0
 LO BND1      psi[23,9]  -0.05
 UP BND1      psi[23,9]  0.05
 LO BND1      psi[23,10]  -0.05
 UP BND1      psi[23,10]  0.05
 LO BND1      psi[23,11]  -0.05
 UP BND1      psi[23,11]  0.05
 LO BND1      psi[23,12]  -0.05
 UP BND1      psi[23,12]  0.05
 LO BND1      psi[23,13]  -0.05
 UP BND1      psi[23,13]  0.05
 LO BND1      psi[23,14]  -0.05
 UP BND1      psi[23,14]  0.05
 LO BND1      psi[23,15]  -0.05
 UP BND1      psi[23,15]  0.05
 LO BND1      psi[24,0]  -0.05
 UP BND1      psi[24,0]  0.05
 LO BND1      psi[24,1]  -0.05
 UP BND1      psi[24,1]  0.05
 FX BND1      psi[24,2]  0
 LO BND1      psi[24,3]  -0.05
 UP BND1      psi[24,3]  0.05
 LO BND1      psi[24,4]  -0.05
 UP BND1      psi[24,4]  0.05
 LO BND1      psi[24,5]  -0.05
 UP BND1      psi[24,5]  0.05
 LO BND1      psi[24,6]  -0.05
 UP BND1      psi[24,6]  0.05
 LO BND1      psi[24,7]  -0.05
 UP BND1      psi[24,7]  0.05
 LO BND1      psi[24,8]  -0.05
 UP BND1      psi[24,8]  0.05
 LO BND1      psi[25,0]  -0.05
 UP BND1      psi[25,0]  0.05
 LO BND1      psi[25,1]  -0.05
 UP BND1      psi[25,1]  0.05
 LO BND1      psi[25,2]  -0.05
 UP BND1      psi[25,2]  0.05
 LO BND1      psi[25,3]  -0.05
 UP BND1      psi[25,3]  0.05
 LO BND1      psi[25,4]  -0.05
 UP BND1      psi[25,4]  0.05
 LO BND1      psi[25,5]  -0.05
 UP BND1      psi[25,5]  0.05
 LO BND1      psi[25,6]  -0.05
 UP BND1      psi[25,6]  0.05
 FX BND1      psi[25,7]  0
 LO BND1      psi[25,8]  -0.05
 UP BND1      psi[25,8]  0.05
 LO BND1      psi[25,9]  -0.05
 UP BND1      psi[25,9]  0.05
 LO BND1      psi[25,10]  -0.05
 UP BND1      psi[25,10]  0.05
 LO BND1      psi[25,11]  -0.05
 UP BND1      psi[25,11]  0.05
 LO BND1      psi[25,12]  -0.05
 UP BND1      psi[25,12]  0.05
 LO BND1      psi[25,13]  -0.05
 UP BND1      psi[25,13]  0.05
 LO BND1      psi[25,14]  -0.05
 UP BND1      psi[25,14]  0.05
 LO BND1      psi[25,15]  -0.05
 UP BND1      psi[25,15]  0.05
 LO BND1      psi[26,0]  -0.05
 UP BND1      psi[26,0]  0.05
 LO BND1      psi[26,1]  -0.05
 UP BND1      psi[26,1]  0.05
 LO BND1      psi[26,2]  -0.05
 UP BND1      psi[26,2]  0.05
 LO BND1      psi[26,3]  -0.05
 UP BND1      psi[26,3]  0.05
 LO BND1      psi[26,4]  -0.05
 UP BND1      psi[26,4]  0.05
 LO BND1      psi[26,5]  -0.05
 UP BND1      psi[26,5]  0.05
 LO BND1      psi[26,6]  -0.05
 UP BND1      psi[26,6]  0.05
 LO BND1      psi[26,7]  -0.05
 UP BND1      psi[26,7]  0.05
 FX BND1      psi[26,8]  0
 LO BND1      psi[26,9]  -0.05
 UP BND1      psi[26,9]  0.05
 LO BND1      psi[26,10]  -0.05
 UP BND1      psi[26,10]  0.05
 LO BND1      psi[26,11]  -0.05
 UP BND1      psi[26,11]  0.05
 LO BND1      psi[26,12]  -0.05
 UP BND1      psi[26,12]  0.05
 LO BND1      psi[26,13]  -0.05
 UP BND1      psi[26,13]  0.05
 LO BND1      psi[26,14]  -0.05
 UP BND1      psi[26,14]  0.05
 LO BND1      psi[26,15]  -0.05
 UP BND1      psi[26,15]  0.05
 LO BND1      psi[27,0]  -0.05
 UP BND1      psi[27,0]  0.05
 LO BND1      psi[27,1]  -0.05
 UP BND1      psi[27,1]  0.05
 LO BND1      psi[27,2]  -0.05
 UP BND1      psi[27,2]  0.05
 LO BND1      psi[27,3]  -0.05
 UP BND1      psi[27,3]  0.05
 LO BND1      psi[27,4]  -0.05
 UP BND1      psi[27,4]  0.05
 LO BND1      psi[27,5]  -0.05
 UP BND1      psi[27,5]  0.05
 LO BND1      psi[27,6]  -0.05
 UP BND1      psi[27,6]  0.05
 LO BND1      psi[27,7]  -0.05
 UP BND1      psi[27,7]  0.05
 LO BND1      psi[27,8]  -0.05
 UP BND1      psi[27,8]  0.05
 FX BND1      psi[27,9]  0
 LO BND1      psi[27,10]  -0.05
 UP BND1      psi[27,10]  0.05
 LO BND1      psi[27,11]  -0.05
 UP BND1      psi[27,11]  0.05
 LO BND1      psi[27,12]  -0.05
 UP BND1      psi[27,12]  0.05
 LO BND1      psi[27,13]  -0.05
 UP BND1      psi[27,13]  0.05
 LO BND1      psi[27,14]  -0.05
 UP BND1      psi[27,14]  0.05
 LO BND1      psi[27,15]  -0.05
 UP BND1      psi[27,15]  0.05
 LO BND1      psi[27,16]  -0.05
 UP BND1      psi[27,16]  0.05
 LO BND1      psi[27,17]  -0.05
 UP BND1      psi[27,17]  0.05
 LO BND1      psi[27,18]  -0.05
 UP BND1      psi[27,18]  0.05
 LO BND1      psi[27,19]  -0.05
 UP BND1      psi[27,19]  0.05
 LO BND1      psi[28,0]  -0.05
 UP BND1      psi[28,0]  0.05
 LO BND1      psi[28,1]  -0.05
 UP BND1      psi[28,1]  0.05
 LO BND1      psi[28,2]  -0.05
 UP BND1      psi[28,2]  0.05
 LO BND1      psi[28,3]  -0.05
 UP BND1      psi[28,3]  0.05
 LO BND1      psi[28,4]  -0.05
 UP BND1      psi[28,4]  0.05
 LO BND1      psi[28,5]  -0.05
 UP BND1      psi[28,5]  0.05
 LO BND1      psi[28,6]  -0.05
 UP BND1      psi[28,6]  0.05
 FX BND1      psi[28,7]  0
 LO BND1      psi[28,8]  -0.05
 UP BND1      psi[28,8]  0.05
 LO BND1      psi[28,9]  -0.05
 UP BND1      psi[28,9]  0.05
 LO BND1      psi[28,10]  -0.05
 UP BND1      psi[28,10]  0.05
 LO BND1      psi[28,11]  -0.05
 UP BND1      psi[28,11]  0.05
 LO BND1      psi[28,12]  -0.05
 UP BND1      psi[28,12]  0.05
 LO BND1      psi[28,13]  -0.05
 UP BND1      psi[28,13]  0.05
 LO BND1      psi[28,14]  -0.05
 UP BND1      psi[28,14]  0.05
 LO BND1      psi[28,15]  -0.05
 UP BND1      psi[28,15]  0.05
 LO BND1      psi[29,0]  -0.05
 UP BND1      psi[29,0]  0.05
 LO BND1      psi[29,1]  -0.05
 UP BND1      psi[29,1]  0.05
 LO BND1      psi[29,2]  -0.05
 UP BND1      psi[29,2]  0.05
 LO BND1      psi[29,3]  -0.05
 UP BND1      psi[29,3]  0.05
 LO BND1      psi[29,4]  -0.05
 UP BND1      psi[29,4]  0.05
 LO BND1      psi[29,5]  -0.05
 UP BND1      psi[29,5]  0.05
 LO BND1      psi[29,6]  -0.05
 UP BND1      psi[29,6]  0.05
 FX BND1      psi[29,7]  0
 LO BND1      psi[29,8]  -0.05
 UP BND1      psi[29,8]  0.05
 LO BND1      psi[29,9]  -0.05
 UP BND1      psi[29,9]  0.05
 LO BND1      psi[29,10]  -0.05
 UP BND1      psi[29,10]  0.05
 LO BND1      psi[29,11]  -0.05
 UP BND1      psi[29,11]  0.05
 LO BND1      psi[29,12]  -0.05
 UP BND1      psi[29,12]  0.05
 LO BND1      psi[29,13]  -0.05
 UP BND1      psi[29,13]  0.05
 LO BND1      psi[29,14]  -0.05
 UP BND1      psi[29,14]  0.05
 LO BND1      psi[29,15]  -0.05
 UP BND1      psi[29,15]  0.05
 LO BND1      psi[30,0]  -0.05
 UP BND1      psi[30,0]  0.05
 LO BND1      psi[30,1]  -0.05
 UP BND1      psi[30,1]  0.05
 LO BND1      psi[30,2]  -0.05
 UP BND1      psi[30,2]  0.05
 LO BND1      psi[30,3]  -0.05
 UP BND1      psi[30,3]  0.05
 LO BND1      psi[30,4]  -0.05
 UP BND1      psi[30,4]  0.05
 LO BND1      psi[30,5]  -0.05
 UP BND1      psi[30,5]  0.05
 LO BND1      psi[30,6]  -0.05
 UP BND1      psi[30,6]  0.05
 LO BND1      psi[30,7]  -0.05
 UP BND1      psi[30,7]  0.05
 LO BND1      psi[30,8]  -0.05
 UP BND1      psi[30,8]  0.05
 LO BND1      psi[30,9]  -0.05
 UP BND1      psi[30,9]  0.05
 LO BND1      psi[30,10]  -0.05
 UP BND1      psi[30,10]  0.05
 FX BND1      psi[30,11]  0
 LO BND1      psi[30,12]  -0.05
 UP BND1      psi[30,12]  0.05
 LO BND1      psi[30,13]  -0.05
 UP BND1      psi[30,13]  0.05
 LO BND1      psi[30,14]  -0.05
 UP BND1      psi[30,14]  0.05
 LO BND1      psi[30,15]  -0.05
 UP BND1      psi[30,15]  0.05
 LO BND1      psi[30,16]  -0.05
 UP BND1      psi[30,16]  0.05
 LO BND1      psi[30,17]  -0.05
 UP BND1      psi[30,17]  0.05
 LO BND1      psi[30,18]  -0.05
 UP BND1      psi[30,18]  0.05
 LO BND1      psi[30,19]  -0.05
 UP BND1      psi[30,19]  0.05
 LO BND1      psi[30,20]  -0.05
 UP BND1      psi[30,20]  0.05
 LO BND1      psi[31,0]  -0.05
 UP BND1      psi[31,0]  0.05
 LO BND1      psi[31,1]  -0.05
 UP BND1      psi[31,1]  0.05
 LO BND1      psi[31,2]  -0.05
 UP BND1      psi[31,2]  0.05
 LO BND1      psi[31,3]  -0.05
 UP BND1      psi[31,3]  0.05
 LO BND1      psi[31,4]  -0.05
 UP BND1      psi[31,4]  0.05
 LO BND1      psi[31,5]  -0.05
 UP BND1      psi[31,5]  0.05
 LO BND1      psi[31,6]  -0.05
 UP BND1      psi[31,6]  0.05
 FX BND1      psi[31,7]  0
 LO BND1      psi[31,8]  -0.05
 UP BND1      psi[31,8]  0.05
 LO BND1      psi[31,9]  -0.05
 UP BND1      psi[31,9]  0.05
 LO BND1      psi[31,10]  -0.05
 UP BND1      psi[31,10]  0.05
 LO BND1      psi[31,11]  -0.05
 UP BND1      psi[31,11]  0.05
 LO BND1      psi[31,12]  -0.05
 UP BND1      psi[31,12]  0.05
 LO BND1      psi[31,13]  -0.05
 UP BND1      psi[31,13]  0.05
 LO BND1      psi[31,14]  -0.05
 UP BND1      psi[31,14]  0.05
 LO BND1      psi[31,15]  -0.05
 UP BND1      psi[31,15]  0.05
 LO BND1      psi[32,0]  -0.05
 UP BND1      psi[32,0]  0.05
 LO BND1      psi[32,1]  -0.05
 UP BND1      psi[32,1]  0.05
 LO BND1      psi[32,2]  -0.05
 UP BND1      psi[32,2]  0.05
 LO BND1      psi[32,3]  -0.05
 UP BND1      psi[32,3]  0.05
 LO BND1      psi[32,4]  -0.05
 UP BND1      psi[32,4]  0.05
 LO BND1      psi[32,5]  -0.05
 UP BND1      psi[32,5]  0.05
 LO BND1      psi[32,6]  -0.05
 UP BND1      psi[32,6]  0.05
 LO BND1      psi[32,7]  -0.05
 UP BND1      psi[32,7]  0.05
 FX BND1      psi[32,8]  0
 LO BND1      psi[32,9]  -0.05
 UP BND1      psi[32,9]  0.05
 LO BND1      psi[32,10]  -0.05
 UP BND1      psi[32,10]  0.05
 LO BND1      psi[32,11]  -0.05
 UP BND1      psi[32,11]  0.05
 LO BND1      psi[32,12]  -0.05
 UP BND1      psi[32,12]  0.05
 LO BND1      psi[32,13]  -0.05
 UP BND1      psi[32,13]  0.05
 LO BND1      psi[32,14]  -0.05
 UP BND1      psi[32,14]  0.05
 LO BND1      psi[32,15]  -0.05
 UP BND1      psi[32,15]  0.05
 LO BND1      psi[33,0]  -0.05
 UP BND1      psi[33,0]  0.05
 LO BND1      psi[33,1]  -0.05
 UP BND1      psi[33,1]  0.05
 LO BND1      psi[33,2]  -0.05
 UP BND1      psi[33,2]  0.05
 LO BND1      psi[33,3]  -0.05
 UP BND1      psi[33,3]  0.05
 LO BND1      psi[33,4]  -0.05
 UP BND1      psi[33,4]  0.05
 LO BND1      psi[33,5]  -0.05
 UP BND1      psi[33,5]  0.05
 LO BND1      psi[33,6]  -0.05
 UP BND1      psi[33,6]  0.05
 LO BND1      psi[33,7]  -0.05
 UP BND1      psi[33,7]  0.05
 LO BND1      psi[33,8]  -0.05
 UP BND1      psi[33,8]  0.05
 LO BND1      psi[33,9]  -0.05
 UP BND1      psi[33,9]  0.05
 LO BND1      psi[33,10]  -0.05
 UP BND1      psi[33,10]  0.05
 LO BND1      psi[33,11]  -0.05
 UP BND1      psi[33,11]  0.05
 LO BND1      psi[33,12]  -0.05
 UP BND1      psi[33,12]  0.05
 FX BND1      psi[33,13]  0
 LO BND1      psi[33,14]  -0.05
 UP BND1      psi[33,14]  0.05
 LO BND1      psi[33,15]  -0.05
 UP BND1      psi[33,15]  0.05
 LO BND1      psi[33,16]  -0.05
 UP BND1      psi[33,16]  0.05
 LO BND1      psi[33,17]  -0.05
 UP BND1      psi[33,17]  0.05
 LO BND1      psi[33,18]  -0.05
 UP BND1      psi[33,18]  0.05
 LO BND1      psi[33,19]  -0.05
 UP BND1      psi[33,19]  0.05
 LO BND1      psi[33,20]  -0.05
 UP BND1      psi[33,20]  0.05
 LO BND1      psi[33,21]  -0.05
 UP BND1      psi[33,21]  0.05
 LO BND1      psi[33,22]  -0.05
 UP BND1      psi[33,22]  0.05
 LO BND1      psi[33,23]  -0.05
 UP BND1      psi[33,23]  0.05
 LO BND1      psi[33,24]  -0.05
 UP BND1      psi[33,24]  0.05
 LO BND1      psi[34,0]  -0.05
 UP BND1      psi[34,0]  0.05
 LO BND1      psi[34,1]  -0.05
 UP BND1      psi[34,1]  0.05
 LO BND1      psi[34,2]  -0.05
 UP BND1      psi[34,2]  0.05
 LO BND1      psi[34,3]  -0.05
 UP BND1      psi[34,3]  0.05
 LO BND1      psi[34,4]  -0.05
 UP BND1      psi[34,4]  0.05
 LO BND1      psi[34,5]  -0.05
 UP BND1      psi[34,5]  0.05
 LO BND1      psi[34,6]  -0.05
 UP BND1      psi[34,6]  0.05
 LO BND1      psi[34,7]  -0.05
 UP BND1      psi[34,7]  0.05
 FX BND1      psi[34,8]  0
 LO BND1      psi[34,9]  -0.05
 UP BND1      psi[34,9]  0.05
 LO BND1      psi[34,10]  -0.05
 UP BND1      psi[34,10]  0.05
 LO BND1      psi[34,11]  -0.05
 UP BND1      psi[34,11]  0.05
 LO BND1      psi[34,12]  -0.05
 UP BND1      psi[34,12]  0.05
 LO BND1      psi[34,13]  -0.05
 UP BND1      psi[34,13]  0.05
 LO BND1      psi[34,14]  -0.05
 UP BND1      psi[34,14]  0.05
 LO BND1      psi[34,15]  -0.05
 UP BND1      psi[34,15]  0.05
 LO BND1      psi[35,0]  -0.05
 UP BND1      psi[35,0]  0.05
 LO BND1      psi[35,1]  -0.05
 UP BND1      psi[35,1]  0.05
 LO BND1      psi[35,2]  -0.05
 UP BND1      psi[35,2]  0.05
 LO BND1      psi[35,3]  -0.05
 UP BND1      psi[35,3]  0.05
 LO BND1      psi[35,4]  -0.05
 UP BND1      psi[35,4]  0.05
 LO BND1      psi[35,5]  -0.05
 UP BND1      psi[35,5]  0.05
 LO BND1      psi[35,6]  -0.05
 UP BND1      psi[35,6]  0.05
 LO BND1      psi[35,7]  -0.05
 UP BND1      psi[35,7]  0.05
 LO BND1      psi[35,8]  -0.05
 UP BND1      psi[35,8]  0.05
 FX BND1      psi[35,9]  0
 LO BND1      psi[35,10]  -0.05
 UP BND1      psi[35,10]  0.05
 LO BND1      psi[35,11]  -0.05
 UP BND1      psi[35,11]  0.05
 LO BND1      psi[35,12]  -0.05
 UP BND1      psi[35,12]  0.05
 LO BND1      psi[35,13]  -0.05
 UP BND1      psi[35,13]  0.05
 LO BND1      psi[35,14]  -0.05
 UP BND1      psi[35,14]  0.05
 LO BND1      psi[35,15]  -0.05
 UP BND1      psi[35,15]  0.05
 LO BND1      psi[35,16]  -0.05
 UP BND1      psi[35,16]  0.05
 LO BND1      psi[35,17]  -0.05
 UP BND1      psi[35,17]  0.05
 FR BND1      a       
ENDATA
