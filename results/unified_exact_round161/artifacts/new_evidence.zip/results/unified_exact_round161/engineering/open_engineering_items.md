# Delivery hardening pending after the finite timed panel

Do not edit/rebuild measured C++ while the serial panel is active. Its four
LPs/four MIPs all use v3 PE SHA
567e8c34d578843adf19e5958c36b63dcf92bd60d75b889db1d5fd2334a34598.

1. Bind/preserve actual source bytes first with `round161_identity.py`.
   v2 matches C++ commit 696a446fb; v3 matches 1fafb6e2a. v1 predates the
   B=0 guard; identity.py reconstructs only that exact earlier source and
   must verify every byte against build_v1.json before retaining it.
2. General zero-branch scaling hardening: R143's block may scale a row by a
   positive power of two. When adding z0 to rn_lb rows, use the negative of
   their actual stored selector coefficient; when adding z0 to normalization,
   use its actual stored RHS, not a literal one. Apply the same finite
   power-of-two coefficient preservation policy to new zero-disjunction rows.
   Actual two-source domains are structurally positive; the measured ordinary
   zero tiny has no row scaling. Thus this is a general numerical-interface
   correction, not a changed real-source formulation/recipe. Add an exported
   zero-stock Start with tiny normalization coefficients to exercise it.
3. Harden the semantic replacement registry: generate state_g names from
   every actual registered selector, including fixed-zero selectors; reject
   unexpected products rather than deleting an unknown prefix. Reject any
   old-objective consumer that also contains a physical/unknown column.
   The separate matrix checker now explicitly tests that removed rows contain
   no route/p/d/load/connection/order variables. Preserve all old failures.
4. Compute actual LP/MPS, named-row and named-column/domain SHA fingerprints
   from each saved replacement, not the original matrix identity.
5. Clean CMake build only after timed science ends. Use the existing Visual
   Studio bundled CMake/Ninja and inherited GNU flags, one build job; see
   round160_buildcheck.py for exact installed paths. Keep delivery PE distinct
   from measured v3. Do not repeat scientific MIPs for metadata-only fixes.

After the first bridge finishes, run saved-evidence analysis and the optional
zero-Optimize envelope diagnostic under the R161 meter. The diagnostic only
tests an existing original-e penalty/cutoff box bound against the saved LP
point; it neither automatically revises nor proves a reoptimized benefit.
Choose any single major expression revision only from the actual results.
No complete candidate/panel has yet been frozen or entered.

## Final resolution

All numbered items are resolved by measured_manifest*, qualification/revision.json, reports/model_identities.json and engineering/cmake_delivery.json. Scaled rows are tested in an explicitly algebraic kernel; the existing reader has integer targets and was unchanged. Both rejected noninteger-demand probe inputs/logs remain, with the corrected diagnosis. The sole RN-P revision completed both affected LP/MIP pairs and did not earn the conditional complete panel. See decision.json.
