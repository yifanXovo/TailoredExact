* Signature: 0xa697dab066634ae7
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 E  onehot_28_14
 E  normalized_mass_28_15
 E  normalized_ratio_28_16
 G  product_lb_17
 L  product_ub_18
 G  product_lb_19
 L  product_ub_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_29_39
 E  normalized_mass_29_40
 E  normalized_ratio_29_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_34_74
 E  normalized_mass_34_75
 E  normalized_ratio_34_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 E  onehot_26_95
 E  normalized_mass_26_96
 E  normalized_ratio_26_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 E  onehot_22_130
 E  normalized_mass_22_131
 E  normalized_ratio_22_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 E  onehot_33_157
 E  normalized_mass_33_158
 E  normalized_ratio_33_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 E  onehot_27_174
 E  normalized_mass_27_175
 E  normalized_ratio_27_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 E  onehot_35_209
 E  normalized_mass_35_210
 E  normalized_ratio_35_211
 G  stock_lb_212
 L  stock_ub_213
 L  parent_nonstrict_scope_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 E  normalization_271
 G  full_original_Gini_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 L  arc_capacity_359
 L  arc_capacity_360
 L  arc_capacity_361
 L  arc_capacity_362
 L  arc_capacity_363
 L  arc_capacity_364
 L  arc_capacity_365
 L  arc_capacity_366
 L  arc_capacity_367
 L  arc_capacity_368
 L  arc_capacity_369
 L  arc_capacity_370
 L  arc_capacity_371
 L  arc_capacity_372
 L  arc_capacity_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 G  connected_order_arc_385
 L  arc_capacity_386
 G  connected_order_arc_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 E  depot_departure_or_bypass_698
 E  depot_return_or_bypass_699
 E  out_degree_700
 E  in_degree_701
 G  order_active_lb_702
 L  order_active_ub_703
 E  segment_load_conservation_704
 G  segment_prefix_lb_705
 L  segment_prefix_ub_706
 E  out_degree_707
 E  in_degree_708
 G  order_active_lb_709
 L  order_active_ub_710
 E  segment_load_conservation_711
 G  segment_prefix_lb_712
 L  segment_prefix_ub_713
 E  out_degree_714
 E  in_degree_715
 G  order_active_lb_716
 L  order_active_ub_717
 E  segment_load_conservation_718
 G  segment_prefix_lb_719
 L  segment_prefix_ub_720
 E  out_degree_721
 E  in_degree_722
 G  order_active_lb_723
 L  order_active_ub_724
 E  segment_load_conservation_725
 G  segment_prefix_lb_726
 L  segment_prefix_ub_727
 E  out_degree_728
 E  in_degree_729
 G  order_active_lb_730
 L  order_active_ub_731
 E  segment_load_conservation_732
 G  segment_prefix_lb_733
 L  segment_prefix_ub_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  service_visit_def_739
 E  free_load_conservation_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  service_visit_def_745
 E  free_load_conservation_746
 E  out_degree_747
 E  in_degree_748
 G  order_active_lb_749
 L  order_active_ub_750
 E  service_visit_def_751
 E  free_load_conservation_752
 E  out_degree_753
 E  in_degree_754
 G  order_active_lb_755
 L  order_active_ub_756
 E  service_visit_def_757
 E  free_load_conservation_758
 E  out_degree_759
 E  in_degree_760
 G  order_active_lb_761
 L  order_active_ub_762
 E  service_visit_def_763
 E  free_load_conservation_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  service_visit_def_769
 E  free_load_conservation_770
 E  out_degree_771
 E  in_degree_772
 G  order_active_lb_773
 L  order_active_ub_774
 E  service_visit_def_775
 E  free_load_conservation_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  service_visit_def_781
 E  free_load_conservation_782
 G  fixed_segment_relative_order_783
 G  fixed_segment_relative_order_784
 G  fixed_segment_relative_order_785
 G  fixed_segment_relative_order_786
 L  original_T_including_depot_unload_787
 L  arc_capacity_788
 L  arc_capacity_789
 L  arc_capacity_790
 L  arc_capacity_791
 L  arc_capacity_792
 L  arc_capacity_793
 L  arc_capacity_794
 L  arc_capacity_795
 L  arc_capacity_796
 L  arc_capacity_797
 L  arc_capacity_798
 L  arc_capacity_799
 L  arc_capacity_800
 L  arc_capacity_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 E  depot_departure_or_bypass_1077
 E  depot_return_or_bypass_1078
 E  out_degree_1079
 E  in_degree_1080
 G  order_active_lb_1081
 L  order_active_ub_1082
 E  segment_load_conservation_1083
 G  segment_prefix_lb_1084
 L  segment_prefix_ub_1085
 E  out_degree_1086
 E  in_degree_1087
 G  order_active_lb_1088
 L  order_active_ub_1089
 E  segment_load_conservation_1090
 G  segment_prefix_lb_1091
 L  segment_prefix_ub_1092
 E  out_degree_1093
 E  in_degree_1094
 G  order_active_lb_1095
 L  order_active_ub_1096
 E  segment_load_conservation_1097
 G  segment_prefix_lb_1098
 L  segment_prefix_ub_1099
 E  out_degree_1100
 E  in_degree_1101
 G  order_active_lb_1102
 L  order_active_ub_1103
 E  segment_load_conservation_1104
 G  segment_prefix_lb_1105
 L  segment_prefix_ub_1106
 E  out_degree_1107
 E  in_degree_1108
 G  order_active_lb_1109
 L  order_active_ub_1110
 E  service_visit_def_1111
 E  free_load_conservation_1112
 E  out_degree_1113
 E  in_degree_1114
 G  order_active_lb_1115
 L  order_active_ub_1116
 E  service_visit_def_1117
 E  free_load_conservation_1118
 E  out_degree_1119
 E  in_degree_1120
 G  order_active_lb_1121
 L  order_active_ub_1122
 E  service_visit_def_1123
 E  free_load_conservation_1124
 E  out_degree_1125
 E  in_degree_1126
 G  order_active_lb_1127
 L  order_active_ub_1128
 E  service_visit_def_1129
 E  free_load_conservation_1130
 E  out_degree_1131
 E  in_degree_1132
 G  order_active_lb_1133
 L  order_active_ub_1134
 E  service_visit_def_1135
 E  free_load_conservation_1136
 E  out_degree_1137
 E  in_degree_1138
 G  order_active_lb_1139
 L  order_active_ub_1140
 E  service_visit_def_1141
 E  free_load_conservation_1142
 E  out_degree_1143
 E  in_degree_1144
 G  order_active_lb_1145
 L  order_active_ub_1146
 E  service_visit_def_1147
 E  free_load_conservation_1148
 E  out_degree_1149
 E  in_degree_1150
 G  order_active_lb_1151
 L  order_active_ub_1152
 E  service_visit_def_1153
 E  free_load_conservation_1154
 G  fixed_segment_relative_order_1155
 G  fixed_segment_relative_order_1156
 G  fixed_segment_relative_order_1157
 L  original_T_including_depot_unload_1158
 L  arc_capacity_1159
 L  arc_capacity_1160
 L  arc_capacity_1161
 L  arc_capacity_1162
 L  arc_capacity_1163
 L  arc_capacity_1164
 L  arc_capacity_1165
 L  arc_capacity_1166
 L  arc_capacity_1167
 L  arc_capacity_1168
 L  arc_capacity_1169
 L  arc_capacity_1170
 L  arc_capacity_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 E  depot_departure_or_bypass_1402
 E  depot_return_or_bypass_1403
 E  out_degree_1404
 E  in_degree_1405
 G  order_active_lb_1406
 L  order_active_ub_1407
 E  segment_load_conservation_1408
 G  segment_prefix_lb_1409
 L  segment_prefix_ub_1410
 E  out_degree_1411
 E  in_degree_1412
 G  order_active_lb_1413
 L  order_active_ub_1414
 E  segment_load_conservation_1415
 G  segment_prefix_lb_1416
 L  segment_prefix_ub_1417
 E  out_degree_1418
 E  in_degree_1419
 G  order_active_lb_1420
 L  order_active_ub_1421
 E  segment_load_conservation_1422
 G  segment_prefix_lb_1423
 L  segment_prefix_ub_1424
 E  out_degree_1425
 E  in_degree_1426
 G  order_active_lb_1427
 L  order_active_ub_1428
 E  service_visit_def_1429
 E  free_load_conservation_1430
 E  out_degree_1431
 E  in_degree_1432
 G  order_active_lb_1433
 L  order_active_ub_1434
 E  service_visit_def_1435
 E  free_load_conservation_1436
 E  out_degree_1437
 E  in_degree_1438
 G  order_active_lb_1439
 L  order_active_ub_1440
 E  service_visit_def_1441
 E  free_load_conservation_1442
 E  out_degree_1443
 E  in_degree_1444
 G  order_active_lb_1445
 L  order_active_ub_1446
 E  service_visit_def_1447
 E  free_load_conservation_1448
 E  out_degree_1449
 E  in_degree_1450
 G  order_active_lb_1451
 L  order_active_ub_1452
 E  service_visit_def_1453
 E  free_load_conservation_1454
 E  out_degree_1455
 E  in_degree_1456
 G  order_active_lb_1457
 L  order_active_ub_1458
 E  service_visit_def_1459
 E  free_load_conservation_1460
 E  out_degree_1461
 E  in_degree_1462
 G  order_active_lb_1463
 L  order_active_ub_1464
 E  service_visit_def_1465
 E  free_load_conservation_1466
 E  out_degree_1467
 E  in_degree_1468
 G  order_active_lb_1469
 L  order_active_ub_1470
 E  service_visit_def_1471
 E  free_load_conservation_1472
 G  fixed_segment_relative_order_1473
 G  fixed_segment_relative_order_1474
 L  original_T_including_depot_unload_1475
COLUMNS
    t         normalized_mass_28_15  -1
    t         normalized_mass_29_40  -1
    t         normalized_mass_34_75  -1
    t         normalized_mass_26_96  -1
    t         normalized_mass_22_131  -1
    t         normalized_mass_33_158  -1
    t         normalized_mass_27_175  -1
    t         normalized_mass_35_210  -1
    t         normalization_271  2.3844047619047622e+01
    t         full_original_Gini_272  -7.6700000000000031e+01
    q         OBJ       1
    q         parent_nonstrict_scope_214  1
    q         full_original_Gini_272  35
    MARKER    'MARKER'                 'INTORG'
    x_28_0    OBJ       4.1891612282083379e-03
    x_28_0    product_lb_0  -2.5039496825324466e-02
    x_28_0    product_ub_1  -4.1939188177185088e-02
    x_28_0    onehot_28_14  1
    x_28_0    parent_nonstrict_scope_214  8.3783224564166758e-03
    x_28_0    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_0    product_lb_0  1
    w_28_0    product_ub_1  1
    w_28_0    normalized_mass_28_15  1
    w_28_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_1    OBJ       1.3963870760694466e-03
    x_28_1    product_lb_2  -2.5039496825324466e-02
    x_28_1    product_ub_3  -4.1939188177185088e-02
    x_28_1    onehot_28_14  1
    x_28_1    stock_lb_212  1
    x_28_1    stock_ub_213  1
    x_28_1    parent_nonstrict_scope_214  5.5855483042777845e-03
    MARKER    'MARKER'                 'INTEND'
    w_28_1    product_lb_2  1
    w_28_1    product_ub_3  1
    w_28_1    normalized_mass_28_15  1
    w_28_1    normalized_ratio_28_16  -3.3333333333333331e-01
    w_28_1    full_original_Gini_272  -1.5510714285714281e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_2    OBJ       -1.3963870760694457e-03
    x_28_2    product_lb_4  -2.5039496825324466e-02
    x_28_2    product_ub_5  -4.1939188177185088e-02
    x_28_2    onehot_28_14  1
    x_28_2    stock_lb_212  2
    x_28_2    stock_ub_213  2
    x_28_2    parent_nonstrict_scope_214  2.7927741521388922e-03
    x_28_2    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_2    product_lb_4  1
    w_28_2    product_ub_5  1
    w_28_2    normalized_mass_28_15  1
    w_28_2    normalized_ratio_28_16  -6.6666666666666663e-01
    w_28_2    full_original_Gini_272  -7.17738095238095
    MARKER    'MARKER'                 'INTORG'
    x_28_3    OBJ       -4.1891612282083379e-03
    x_28_3    product_lb_6  -2.5039496825324466e-02
    x_28_3    product_ub_7  -4.1939188177185088e-02
    x_28_3    onehot_28_14  1
    x_28_3    stock_lb_212  3
    x_28_3    stock_ub_213  3
    x_28_3    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_3    product_lb_6  1
    w_28_3    product_ub_7  1
    w_28_3    normalized_mass_28_15  1
    w_28_3    normalized_ratio_28_16  -1
    w_28_3    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_4    OBJ       -1.3963870760694466e-03
    x_28_4    product_lb_8  -2.5039496825324466e-02
    x_28_4    product_ub_9  -4.1939188177185088e-02
    x_28_4    onehot_28_14  1
    x_28_4    stock_lb_212  4
    x_28_4    stock_ub_213  4
    x_28_4    parent_nonstrict_scope_214  2.7927741521388914e-03
    x_28_4    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_4    product_lb_8  1
    w_28_4    product_ub_9  1
    w_28_4    normalized_mass_28_15  1
    w_28_4    normalized_ratio_28_16  -1.3333333333333333e+00
    w_28_4    full_original_Gini_272  -1.2489285714285716e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_5    OBJ       1.3963870760694448e-03
    x_28_5    product_lb_10  -2.5039496825324466e-02
    x_28_5    product_ub_11  -4.1939188177185088e-02
    x_28_5    onehot_28_14  1
    x_28_5    stock_lb_212  5
    x_28_5    stock_ub_213  5
    x_28_5    parent_nonstrict_scope_214  5.5855483042777827e-03
    x_28_5    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_5    product_lb_10  1
    w_28_5    product_ub_11  1
    w_28_5    normalized_mass_28_15  1
    w_28_5    normalized_ratio_28_16  -1.6666666666666665e+00
    w_28_5    full_original_Gini_272  -2.1155952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_6    OBJ       4.1891612282083379e-03
    x_28_6    product_lb_12  -2.5039496825324466e-02
    x_28_6    product_ub_13  -4.1939188177185088e-02
    x_28_6    onehot_28_14  1
    x_28_6    stock_lb_212  6
    x_28_6    stock_ub_213  6
    x_28_6    parent_nonstrict_scope_214  8.3783224564166758e-03
    x_28_6    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_6    product_lb_12  1
    w_28_6    product_ub_13  1
    w_28_6    normalized_mass_28_15  1
    w_28_6    normalized_ratio_28_16  -2
    w_28_6    full_original_Gini_272  -3.0155952380952378e+01
    rho_28    normalized_ratio_28_16  1
    rho_28    block_pair_pos_231  -1
    rho_28    block_pair_neg_232  1
    rho_28    block_pair_pos_233  -1
    rho_28    block_pair_neg_234  1
    rho_28    block_pair_pos_235  -1
    rho_28    block_pair_neg_236  1
    rho_28    block_pair_pos_237  -1
    rho_28    block_pair_neg_238  1
    rho_28    block_pair_pos_239  -1
    rho_28    block_pair_neg_240  1
    rho_28    block_pair_pos_241  -1
    rho_28    block_pair_neg_242  1
    rho_28    block_pair_pos_243  -1
    rho_28    block_pair_neg_244  1
    rho_28    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_17  -2.5039496825324466e-02
    x_29_0    product_ub_18  -4.1939188177185088e-02
    x_29_0    onehot_29_39  1
    x_29_0    parent_nonstrict_scope_214  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_17  1
    w_29_0    product_ub_18  1
    w_29_0    normalized_mass_29_40  1
    w_29_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_19  -2.5039496825324466e-02
    x_29_1    product_ub_20  -4.1939188177185088e-02
    x_29_1    onehot_29_39  1
    x_29_1    stock_lb_212  1
    x_29_1    stock_ub_213  1
    x_29_1    parent_nonstrict_scope_214  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_19  1
    w_29_1    product_ub_20  1
    w_29_1    normalized_mass_29_40  1
    w_29_1    normalized_ratio_29_41  -0.2
    w_29_1    full_original_Gini_272  -1.8844047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_21  -2.5039496825324466e-02
    x_29_2    product_ub_22  -4.1939188177185088e-02
    x_29_2    onehot_29_39  1
    x_29_2    stock_lb_212  2
    x_29_2    stock_ub_213  2
    x_29_2    parent_nonstrict_scope_214  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_21  1
    w_29_2    product_ub_22  1
    w_29_2    normalized_mass_29_40  1
    w_29_2    normalized_ratio_29_41  -0.4
    w_29_2    full_original_Gini_272  -1.3844047619047615e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_23  -2.5039496825324466e-02
    x_29_3    product_ub_24  -4.1939188177185088e-02
    x_29_3    onehot_29_39  1
    x_29_3    stock_lb_212  3
    x_29_3    stock_ub_213  3
    x_29_3    parent_nonstrict_scope_214  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_23  1
    w_29_3    product_ub_24  1
    w_29_3    normalized_mass_29_40  1
    w_29_3    normalized_ratio_29_41  -6.0000000000000009e-01
    w_29_3    full_original_Gini_272  -8.8440476190476218e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_25  -2.5039496825324466e-02
    x_29_4    product_ub_26  -4.1939188177185088e-02
    x_29_4    onehot_29_39  1
    x_29_4    stock_lb_212  4
    x_29_4    stock_ub_213  4
    x_29_4    parent_nonstrict_scope_214  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_25  1
    w_29_4    product_ub_26  1
    w_29_4    normalized_mass_29_40  1
    w_29_4    normalized_ratio_29_41  -0.8
    w_29_4    full_original_Gini_272  -4.5821428571428582e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_27  -2.5039496825324466e-02
    x_29_5    product_ub_28  -4.1939188177185088e-02
    x_29_5    onehot_29_39  1
    x_29_5    stock_lb_212  5
    x_29_5    stock_ub_213  5
    x_29_5    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_27  1
    w_29_5    product_ub_28  1
    w_29_5    normalized_mass_29_40  1
    w_29_5    normalized_ratio_29_41  -1
    w_29_5    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_29  -2.5039496825324466e-02
    x_29_6    product_ub_30  -4.1939188177185088e-02
    x_29_6    onehot_29_39  1
    x_29_6    stock_lb_212  6
    x_29_6    stock_ub_213  6
    x_29_6    parent_nonstrict_scope_214  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_29  1
    w_29_6    product_ub_30  1
    w_29_6    normalized_mass_29_40  1
    w_29_6    normalized_ratio_29_41  -1.2000000000000002e+00
    w_29_6    full_original_Gini_272  -9.1559523809523835e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_31  -2.5039496825324466e-02
    x_29_7    product_ub_32  -4.1939188177185088e-02
    x_29_7    onehot_29_39  1
    x_29_7    stock_lb_212  7
    x_29_7    stock_ub_213  7
    x_29_7    parent_nonstrict_scope_214  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_31  1
    w_29_7    product_ub_32  1
    w_29_7    normalized_mass_29_40  1
    w_29_7    normalized_ratio_29_41  -1.4000000000000001e+00
    w_29_7    full_original_Gini_272  -1.4155952380952387e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_33  -2.5039496825324466e-02
    x_29_8    product_ub_34  -4.1939188177185088e-02
    x_29_8    onehot_29_39  1
    x_29_8    stock_lb_212  8
    x_29_8    stock_ub_213  8
    x_29_8    parent_nonstrict_scope_214  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_33  1
    w_29_8    product_ub_34  1
    w_29_8    normalized_mass_29_40  1
    w_29_8    normalized_ratio_29_41  -1.6
    w_29_8    full_original_Gini_272  -1.9355952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_35  -2.5039496825324466e-02
    x_29_9    product_ub_36  -4.1939188177185088e-02
    x_29_9    onehot_29_39  1
    x_29_9    stock_lb_212  9
    x_29_9    stock_ub_213  9
    x_29_9    parent_nonstrict_scope_214  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_35  1
    w_29_9    product_ub_36  1
    w_29_9    normalized_mass_29_40  1
    w_29_9    normalized_ratio_29_41  -1.8
    w_29_9    full_original_Gini_272  -2.4755952380952390e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_37  -2.5039496825324466e-02
    x_29_10   product_ub_38  -4.1939188177185088e-02
    x_29_10   onehot_29_39  1
    x_29_10   stock_lb_212  10
    x_29_10   stock_ub_213  10
    x_29_10   parent_nonstrict_scope_214  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_37  1
    w_29_10   product_ub_38  1
    w_29_10   normalized_mass_29_40  1
    w_29_10   normalized_ratio_29_41  -2
    w_29_10   full_original_Gini_272  -3.0155952380952378e+01
    rho_29    normalized_ratio_29_41  1
    rho_29    block_pair_pos_237  1
    rho_29    block_pair_neg_238  -1
    rho_29    block_pair_pos_245  -1
    rho_29    block_pair_neg_246  1
    rho_29    block_pair_pos_247  -1
    rho_29    block_pair_neg_248  1
    rho_29    block_pair_pos_249  -1
    rho_29    block_pair_neg_250  1
    rho_29    block_pair_pos_251  -1
    rho_29    block_pair_neg_252  1
    rho_29    block_pair_pos_253  -1
    rho_29    block_pair_neg_254  1
    rho_29    block_pair_pos_255  -1
    rho_29    block_pair_neg_256  1
    rho_29    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_42  -2.5039496825324466e-02
    x_34_0    product_ub_43  -4.1939188177185088e-02
    x_34_0    onehot_34_74  1
    x_34_0    parent_nonstrict_scope_214  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_42  1
    w_34_0    product_ub_43  1
    w_34_0    normalized_mass_34_75  1
    w_34_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_44  -2.5039496825324466e-02
    x_34_1    product_ub_45  -4.1939188177185088e-02
    x_34_1    onehot_34_74  1
    x_34_1    stock_lb_212  1
    x_34_1    stock_ub_213  1
    x_34_1    parent_nonstrict_scope_214  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_44  1
    w_34_1    product_ub_45  1
    w_34_1    normalized_mass_34_75  1
    w_34_1    normalized_ratio_34_76  -0.125
    w_34_1    full_original_Gini_272  -2.0719047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_46  -2.5039496825324466e-02
    x_34_2    product_ub_47  -4.1939188177185088e-02
    x_34_2    onehot_34_74  1
    x_34_2    stock_lb_212  2
    x_34_2    stock_ub_213  2
    x_34_2    parent_nonstrict_scope_214  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_46  1
    w_34_2    product_ub_47  1
    w_34_2    normalized_mass_34_75  1
    w_34_2    normalized_ratio_34_76  -0.25
    w_34_2    full_original_Gini_272  -1.7594047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_48  -2.5039496825324466e-02
    x_34_3    product_ub_49  -4.1939188177185088e-02
    x_34_3    onehot_34_74  1
    x_34_3    stock_lb_212  3
    x_34_3    stock_ub_213  3
    x_34_3    parent_nonstrict_scope_214  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_48  1
    w_34_3    product_ub_49  1
    w_34_3    normalized_mass_34_75  1
    w_34_3    normalized_ratio_34_76  -0.375
    w_34_3    full_original_Gini_272  -1.4469047619047616e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_50  -2.5039496825324466e-02
    x_34_4    product_ub_51  -4.1939188177185088e-02
    x_34_4    onehot_34_74  1
    x_34_4    stock_lb_212  4
    x_34_4    stock_ub_213  4
    x_34_4    parent_nonstrict_scope_214  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_50  1
    w_34_4    product_ub_51  1
    w_34_4    normalized_mass_34_75  1
    w_34_4    normalized_ratio_34_76  -0.5
    w_34_4    full_original_Gini_272  -1.1344047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_52  -2.5039496825324466e-02
    x_34_5    product_ub_53  -4.1939188177185088e-02
    x_34_5    onehot_34_74  1
    x_34_5    stock_lb_212  5
    x_34_5    stock_ub_213  5
    x_34_5    parent_nonstrict_scope_214  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_52  1
    w_34_5    product_ub_53  1
    w_34_5    normalized_mass_34_75  1
    w_34_5    normalized_ratio_34_76  -0.625
    w_34_5    full_original_Gini_272  -8.2190476190476165e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_54  -2.5039496825324466e-02
    x_34_6    product_ub_55  -4.1939188177185088e-02
    x_34_6    onehot_34_74  1
    x_34_6    stock_lb_212  6
    x_34_6    stock_ub_213  6
    x_34_6    parent_nonstrict_scope_214  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_54  1
    w_34_6    product_ub_55  1
    w_34_6    normalized_mass_34_75  1
    w_34_6    normalized_ratio_34_76  -0.75
    w_34_6    full_original_Gini_272  -5.3321428571428564e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_56  -2.5039496825324466e-02
    x_34_7    product_ub_57  -4.1939188177185088e-02
    x_34_7    onehot_34_74  1
    x_34_7    stock_lb_212  7
    x_34_7    stock_ub_213  7
    x_34_7    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_56  1
    w_34_7    product_ub_57  1
    w_34_7    normalized_mass_34_75  1
    w_34_7    normalized_ratio_34_76  -0.875
    w_34_7    full_original_Gini_272  -4.0309523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_58  -2.5039496825324466e-02
    x_34_8    product_ub_59  -4.1939188177185088e-02
    x_34_8    onehot_34_74  1
    x_34_8    stock_lb_212  8
    x_34_8    stock_ub_213  8
    x_34_8    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_58  1
    w_34_8    product_ub_59  1
    w_34_8    normalized_mass_34_75  1
    w_34_8    normalized_ratio_34_76  -1
    w_34_8    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_60  -2.5039496825324466e-02
    x_34_9    product_ub_61  -4.1939188177185088e-02
    x_34_9    onehot_34_74  1
    x_34_9    stock_lb_212  9
    x_34_9    stock_ub_213  9
    x_34_9    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_60  1
    w_34_9    product_ub_61  1
    w_34_9    normalized_mass_34_75  1
    w_34_9    normalized_ratio_34_76  -1.125
    w_34_9    full_original_Gini_272  -7.2809523809523817e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_62  -2.5039496825324466e-02
    x_34_10   product_ub_63  -4.1939188177185088e-02
    x_34_10   onehot_34_74  1
    x_34_10   stock_lb_212  10
    x_34_10   stock_ub_213  10
    x_34_10   parent_nonstrict_scope_214  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_62  1
    w_34_10   product_ub_63  1
    w_34_10   normalized_mass_34_75  1
    w_34_10   normalized_ratio_34_76  -1.25
    w_34_10   full_original_Gini_272  -1.0405952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_64  -2.5039496825324466e-02
    x_34_11   product_ub_65  -4.1939188177185088e-02
    x_34_11   onehot_34_74  1
    x_34_11   stock_lb_212  11
    x_34_11   stock_ub_213  11
    x_34_11   parent_nonstrict_scope_214  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_64  1
    w_34_11   product_ub_65  1
    w_34_11   normalized_mass_34_75  1
    w_34_11   normalized_ratio_34_76  -1.375
    w_34_11   full_original_Gini_272  -1.3530952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_66  -2.5039496825324466e-02
    x_34_12   product_ub_67  -4.1939188177185088e-02
    x_34_12   onehot_34_74  1
    x_34_12   stock_lb_212  12
    x_34_12   stock_ub_213  12
    x_34_12   parent_nonstrict_scope_214  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_66  1
    w_34_12   product_ub_67  1
    w_34_12   normalized_mass_34_75  1
    w_34_12   normalized_ratio_34_76  -1.5
    w_34_12   full_original_Gini_272  -1.6655952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_68  -2.5039496825324466e-02
    x_34_13   product_ub_69  -4.1939188177185088e-02
    x_34_13   onehot_34_74  1
    x_34_13   stock_lb_212  13
    x_34_13   stock_ub_213  13
    x_34_13   parent_nonstrict_scope_214  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_68  1
    w_34_13   product_ub_69  1
    w_34_13   normalized_mass_34_75  1
    w_34_13   normalized_ratio_34_76  -1.625
    w_34_13   full_original_Gini_272  -2.0030952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_70  -2.5039496825324466e-02
    x_34_14   product_ub_71  -4.1939188177185088e-02
    x_34_14   onehot_34_74  1
    x_34_14   stock_lb_212  14
    x_34_14   stock_ub_213  14
    x_34_14   parent_nonstrict_scope_214  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_70  1
    w_34_14   product_ub_71  1
    w_34_14   normalized_mass_34_75  1
    w_34_14   normalized_ratio_34_76  -1.75
    w_34_14   full_original_Gini_272  -2.3405952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_72  -2.5039496825324466e-02
    x_34_15   product_ub_73  -4.1939188177185088e-02
    x_34_15   onehot_34_74  1
    x_34_15   stock_lb_212  15
    x_34_15   stock_ub_213  15
    x_34_15   parent_nonstrict_scope_214  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_72  1
    w_34_15   product_ub_73  1
    w_34_15   normalized_mass_34_75  1
    w_34_15   normalized_ratio_34_76  -1.875
    w_34_15   full_original_Gini_272  -2.6780952380952378e+01
    rho_34    normalized_ratio_34_76  1
    rho_34    block_pair_pos_241  1
    rho_34    block_pair_neg_242  -1
    rho_34    block_pair_pos_253  1
    rho_34    block_pair_neg_254  -1
    rho_34    block_pair_pos_261  -1
    rho_34    block_pair_neg_262  1
    rho_34    block_pair_pos_263  -1
    rho_34    block_pair_neg_264  1
    rho_34    block_pair_pos_265  -1
    rho_34    block_pair_neg_266  1
    rho_34    block_pair_pos_267  -1
    rho_34    block_pair_neg_268  1
    rho_34    block_pair_pos_269  -1
    rho_34    block_pair_neg_270  1
    rho_34    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       7.4474103065332977e-03
    x_26_0    product_lb_77  -2.5039496825324466e-02
    x_26_0    product_ub_78  -4.1939188177185088e-02
    x_26_0    onehot_26_95  1
    x_26_0    parent_nonstrict_scope_214  1.4894820613066595e-02
    x_26_0    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_77  1
    w_26_0    product_ub_78  1
    w_26_0    normalized_mass_26_96  1
    w_26_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       3.7237051532666493e-03
    x_26_1    product_lb_79  -2.5039496825324466e-02
    x_26_1    product_ub_80  -4.1939188177185088e-02
    x_26_1    onehot_26_95  1
    x_26_1    stock_lb_212  1
    x_26_1    stock_ub_213  1
    x_26_1    parent_nonstrict_scope_214  1.1171115459799947e-02
    x_26_1    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_79  1
    w_26_1    product_ub_80  1
    w_26_1    normalized_mass_26_96  1
    w_26_1    normalized_ratio_26_97  -0.25
    w_26_1    full_original_Gini_272  -1.7594047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_81  -2.5039496825324466e-02
    x_26_2    product_ub_82  -4.1939188177185088e-02
    x_26_2    onehot_26_95  1
    x_26_2    stock_lb_212  2
    x_26_2    stock_ub_213  2
    x_26_2    parent_nonstrict_scope_214  7.4474103065332977e-03
    x_26_2    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_81  1
    w_26_2    product_ub_82  1
    w_26_2    normalized_mass_26_96  1
    w_26_2    normalized_ratio_26_97  -0.5
    w_26_2    full_original_Gini_272  -1.1344047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -3.7237051532666488e-03
    x_26_3    product_lb_83  -2.5039496825324466e-02
    x_26_3    product_ub_84  -4.1939188177185088e-02
    x_26_3    onehot_26_95  1
    x_26_3    stock_lb_212  3
    x_26_3    stock_ub_213  3
    x_26_3    parent_nonstrict_scope_214  3.7237051532666488e-03
    x_26_3    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_83  1
    w_26_3    product_ub_84  1
    w_26_3    normalized_mass_26_96  1
    w_26_3    normalized_ratio_26_97  -0.75
    w_26_3    full_original_Gini_272  -5.3321428571428564e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -7.4474103065332977e-03
    x_26_4    product_lb_85  -2.5039496825324466e-02
    x_26_4    product_ub_86  -4.1939188177185088e-02
    x_26_4    onehot_26_95  1
    x_26_4    stock_lb_212  4
    x_26_4    stock_ub_213  4
    x_26_4    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_85  1
    w_26_4    product_ub_86  1
    w_26_4    normalized_mass_26_96  1
    w_26_4    normalized_ratio_26_97  -1
    w_26_4    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -3.7237051532666488e-03
    x_26_5    product_lb_87  -2.5039496825324466e-02
    x_26_5    product_ub_88  -4.1939188177185088e-02
    x_26_5    onehot_26_95  1
    x_26_5    stock_lb_212  5
    x_26_5    stock_ub_213  5
    x_26_5    parent_nonstrict_scope_214  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_87  1
    w_26_5    product_ub_88  1
    w_26_5    normalized_mass_26_96  1
    w_26_5    normalized_ratio_26_97  -1.25
    w_26_5    full_original_Gini_272  -1.0405952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_89  -2.5039496825324466e-02
    x_26_6    product_ub_90  -4.1939188177185088e-02
    x_26_6    onehot_26_95  1
    x_26_6    stock_lb_212  6
    x_26_6    stock_ub_213  6
    x_26_6    parent_nonstrict_scope_214  7.4474103065332977e-03
    x_26_6    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_89  1
    w_26_6    product_ub_90  1
    w_26_6    normalized_mass_26_96  1
    w_26_6    normalized_ratio_26_97  -1.5
    w_26_6    full_original_Gini_272  -1.6655952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       3.7237051532666493e-03
    x_26_7    product_lb_91  -2.5039496825324466e-02
    x_26_7    product_ub_92  -4.1939188177185088e-02
    x_26_7    onehot_26_95  1
    x_26_7    stock_lb_212  7
    x_26_7    stock_ub_213  7
    x_26_7    parent_nonstrict_scope_214  1.1171115459799947e-02
    x_26_7    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_91  1
    w_26_7    product_ub_92  1
    w_26_7    normalized_mass_26_96  1
    w_26_7    normalized_ratio_26_97  -1.75
    w_26_7    full_original_Gini_272  -2.3405952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       7.4474103065332977e-03
    x_26_8    product_lb_93  -2.5039496825324466e-02
    x_26_8    product_ub_94  -4.1939188177185088e-02
    x_26_8    onehot_26_95  1
    x_26_8    stock_lb_212  8
    x_26_8    stock_ub_213  8
    x_26_8    parent_nonstrict_scope_214  1.4894820613066595e-02
    x_26_8    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_93  1
    w_26_8    product_ub_94  1
    w_26_8    normalized_mass_26_96  1
    w_26_8    normalized_ratio_26_97  -2
    w_26_8    full_original_Gini_272  -3.0155952380952378e+01
    rho_26    normalized_ratio_26_97  1
    rho_26    block_pair_pos_221  -1
    rho_26    block_pair_neg_222  1
    rho_26    block_pair_pos_223  -1
    rho_26    block_pair_neg_224  1
    rho_26    block_pair_pos_225  -1
    rho_26    block_pair_neg_226  1
    rho_26    block_pair_pos_227  -1
    rho_26    block_pair_neg_228  1
    rho_26    block_pair_pos_233  1
    rho_26    block_pair_neg_234  -1
    rho_26    block_pair_pos_247  1
    rho_26    block_pair_neg_248  -1
    rho_26    block_pair_pos_263  1
    rho_26    block_pair_neg_264  -1
    rho_26    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_98  -2.5039496825324466e-02
    x_22_0    product_ub_99  -4.1939188177185088e-02
    x_22_0    onehot_22_130  1
    x_22_0    parent_nonstrict_scope_214  0.0456153362865944
    x_22_0    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_98  1
    w_22_0    product_ub_99  1
    w_22_0    normalized_mass_22_131  1
    w_22_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_100  -2.5039496825324466e-02
    x_22_1    product_ub_101  -4.1939188177185088e-02
    x_22_1    onehot_22_130  1
    x_22_1    stock_lb_212  1
    x_22_1    stock_ub_213  1
    x_22_1    parent_nonstrict_scope_214  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_100  1
    w_22_1    product_ub_101  1
    w_22_1    normalized_mass_22_131  1
    w_22_1    normalized_ratio_22_132  -1.4285714285714285e-01
    w_22_1    full_original_Gini_272  -2.0272619047619052e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_102  -2.5039496825324466e-02
    x_22_2    product_ub_103  -4.1939188177185088e-02
    x_22_2    onehot_22_130  1
    x_22_2    stock_lb_212  2
    x_22_2    stock_ub_213  2
    x_22_2    parent_nonstrict_scope_214  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_102  1
    w_22_2    product_ub_103  1
    w_22_2    normalized_mass_22_131  1
    w_22_2    normalized_ratio_22_132  -2.8571428571428570e-01
    w_22_2    full_original_Gini_272  -1.6701190476190469e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_104  -2.5039496825324466e-02
    x_22_3    product_ub_105  -4.1939188177185088e-02
    x_22_3    onehot_22_130  1
    x_22_3    stock_lb_212  3
    x_22_3    stock_ub_213  3
    x_22_3    parent_nonstrict_scope_214  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_104  1
    w_22_3    product_ub_105  1
    w_22_3    normalized_mass_22_131  1
    w_22_3    normalized_ratio_22_132  -4.2857142857142855e-01
    w_22_3    full_original_Gini_272  -1.3129761904761901e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_106  -2.5039496825324466e-02
    x_22_4    product_ub_107  -4.1939188177185088e-02
    x_22_4    onehot_22_130  1
    x_22_4    stock_lb_212  4
    x_22_4    stock_ub_213  4
    x_22_4    parent_nonstrict_scope_214  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_106  1
    w_22_4    product_ub_107  1
    w_22_4    normalized_mass_22_131  1
    w_22_4    normalized_ratio_22_132  -5.7142857142857140e-01
    w_22_4    full_original_Gini_272  -9.5583333333333353e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_108  -2.5039496825324466e-02
    x_22_5    product_ub_109  -4.1939188177185088e-02
    x_22_5    onehot_22_130  1
    x_22_5    stock_lb_212  5
    x_22_5    stock_ub_213  5
    x_22_5    parent_nonstrict_scope_214  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_108  1
    w_22_5    product_ub_109  1
    w_22_5    normalized_mass_22_131  1
    w_22_5    normalized_ratio_22_132  -7.1428571428571419e-01
    w_22_5    full_original_Gini_272  -6.0821428571428564e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_110  -2.5039496825324466e-02
    x_22_6    product_ub_111  -4.1939188177185088e-02
    x_22_6    onehot_22_130  1
    x_22_6    stock_lb_212  6
    x_22_6    stock_ub_213  6
    x_22_6    parent_nonstrict_scope_214  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_110  1
    w_22_6    product_ub_111  1
    w_22_6    normalized_mass_22_131  1
    w_22_6    normalized_ratio_22_132  -8.5714285714285710e-01
    w_22_6    full_original_Gini_272  -4.0488095238095232e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_112  -2.5039496825324466e-02
    x_22_7    product_ub_113  -4.1939188177185088e-02
    x_22_7    onehot_22_130  1
    x_22_7    stock_lb_212  7
    x_22_7    stock_ub_213  7
    x_22_7    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_112  1
    w_22_7    product_ub_113  1
    w_22_7    normalized_mass_22_131  1
    w_22_7    normalized_ratio_22_132  -1
    w_22_7    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_114  -2.5039496825324466e-02
    x_22_8    product_ub_115  -4.1939188177185088e-02
    x_22_8    onehot_22_130  1
    x_22_8    stock_lb_212  8
    x_22_8    stock_ub_213  8
    x_22_8    parent_nonstrict_scope_214  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_114  1
    w_22_8    product_ub_115  1
    w_22_8    normalized_mass_22_131  1
    w_22_8    normalized_ratio_22_132  -1.1428571428571428e+00
    w_22_8    full_original_Gini_272  -7.7273809523809458e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_116  -2.5039496825324466e-02
    x_22_9    product_ub_117  -4.1939188177185088e-02
    x_22_9    onehot_22_130  1
    x_22_9    stock_lb_212  9
    x_22_9    stock_ub_213  9
    x_22_9    parent_nonstrict_scope_214  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_116  1
    w_22_9    product_ub_117  1
    w_22_9    normalized_mass_22_131  1
    w_22_9    normalized_ratio_22_132  -1.2857142857142856e+00
    w_22_9    full_original_Gini_272  -1.1298809523809515e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_118  -2.5039496825324466e-02
    x_22_10   product_ub_119  -4.1939188177185088e-02
    x_22_10   onehot_22_130  1
    x_22_10   stock_lb_212  10
    x_22_10   stock_ub_213  10
    x_22_10   parent_nonstrict_scope_214  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_118  1
    w_22_10   product_ub_119  1
    w_22_10   normalized_mass_22_131  1
    w_22_10   normalized_ratio_22_132  -1.4285714285714284e+00
    w_22_10   full_original_Gini_272  -1.4870238095238095e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_120  -2.5039496825324466e-02
    x_22_11   product_ub_121  -4.1939188177185088e-02
    x_22_11   onehot_22_130  1
    x_22_11   stock_lb_212  11
    x_22_11   stock_ub_213  11
    x_22_11   parent_nonstrict_scope_214  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_120  1
    w_22_11   product_ub_121  1
    w_22_11   normalized_mass_22_131  1
    w_22_11   normalized_ratio_22_132  -1.5714285714285714e+00
    w_22_11   full_original_Gini_272  -1.8584523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_122  -2.5039496825324466e-02
    x_22_12   product_ub_123  -4.1939188177185088e-02
    x_22_12   onehot_22_130  1
    x_22_12   stock_lb_212  12
    x_22_12   stock_ub_213  12
    x_22_12   parent_nonstrict_scope_214  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_122  1
    w_22_12   product_ub_123  1
    w_22_12   normalized_mass_22_131  1
    w_22_12   normalized_ratio_22_132  -1.7142857142857142e+00
    w_22_12   full_original_Gini_272  -2.2441666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_124  -2.5039496825324466e-02
    x_22_13   product_ub_125  -4.1939188177185088e-02
    x_22_13   onehot_22_130  1
    x_22_13   stock_lb_212  13
    x_22_13   stock_ub_213  13
    x_22_13   parent_nonstrict_scope_214  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_124  1
    w_22_13   product_ub_125  1
    w_22_13   normalized_mass_22_131  1
    w_22_13   normalized_ratio_22_132  -1.8571428571428570e+00
    w_22_13   full_original_Gini_272  -2.6298809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_126  -2.5039496825324466e-02
    x_22_14   product_ub_127  -4.1939188177185088e-02
    x_22_14   onehot_22_130  1
    x_22_14   stock_lb_212  14
    x_22_14   stock_ub_213  14
    x_22_14   parent_nonstrict_scope_214  0.0456153362865944
    x_22_14   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_126  1
    w_22_14   product_ub_127  1
    w_22_14   normalized_mass_22_131  1
    w_22_14   normalized_ratio_22_132  -2
    w_22_14   full_original_Gini_272  -3.0155952380952378e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_128  -2.5039496825324466e-02
    x_22_15   product_ub_129  -4.1939188177185088e-02
    x_22_15   onehot_22_130  1
    x_22_15   stock_lb_212  15
    x_22_15   stock_ub_213  15
    x_22_15   parent_nonstrict_scope_214  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_128  1
    w_22_15   product_ub_129  1
    w_22_15   normalized_mass_22_131  1
    w_22_15   normalized_ratio_22_132  -2.1428571428571428e+00
    w_22_15   full_original_Gini_272  -3.4013095238095232e+01
    rho_22    normalized_ratio_22_132  1
    rho_22    block_pair_pos_215  -1
    rho_22    block_pair_neg_216  1
    rho_22    block_pair_pos_217  -1
    rho_22    block_pair_neg_218  1
    rho_22    block_pair_pos_219  -1
    rho_22    block_pair_neg_220  1
    rho_22    block_pair_pos_221  1
    rho_22    block_pair_neg_222  -1
    rho_22    block_pair_pos_231  1
    rho_22    block_pair_neg_232  -1
    rho_22    block_pair_pos_245  1
    rho_22    block_pair_neg_246  -1
    rho_22    block_pair_pos_261  1
    rho_22    block_pair_neg_262  -1
    rho_22    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_33_0    OBJ       9.3092572277933064e-03
    x_33_0    product_lb_133  -2.5039496825324466e-02
    x_33_0    product_ub_134  -4.1939188177185088e-02
    x_33_0    onehot_33_157  1
    x_33_0    parent_nonstrict_scope_214  2.3273143069483273e-02
    x_33_0    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_0    product_lb_133  1
    w_33_0    product_ub_134  1
    w_33_0    normalized_mass_33_158  1
    w_33_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_1    OBJ       4.6546286138966532e-03
    x_33_1    product_lb_135  -2.5039496825324466e-02
    x_33_1    product_ub_136  -4.1939188177185088e-02
    x_33_1    onehot_33_157  1
    x_33_1    stock_lb_212  1
    x_33_1    stock_ub_213  1
    x_33_1    parent_nonstrict_scope_214  1.8618514455586620e-02
    x_33_1    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_1    product_lb_135  1
    w_33_1    product_ub_136  1
    w_33_1    normalized_mass_33_158  1
    w_33_1    normalized_ratio_33_159  -0.2
    w_33_1    full_original_Gini_272  -1.8844047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_2    OBJ       -3.4694469519536142e-18
    x_33_2    product_lb_137  -2.5039496825324466e-02
    x_33_2    product_ub_138  -4.1939188177185088e-02
    x_33_2    onehot_33_157  1
    x_33_2    stock_lb_212  2
    x_33_2    stock_ub_213  2
    x_33_2    parent_nonstrict_scope_214  1.3963885841689963e-02
    x_33_2    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_2    product_lb_137  1
    w_33_2    product_ub_138  1
    w_33_2    normalized_mass_33_158  1
    w_33_2    normalized_ratio_33_159  -0.4
    w_33_2    full_original_Gini_272  -1.3844047619047615e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_3    OBJ       -0.00465462861389666
    x_33_3    product_lb_139  -2.5039496825324466e-02
    x_33_3    product_ub_140  -4.1939188177185088e-02
    x_33_3    onehot_33_157  1
    x_33_3    stock_lb_212  3
    x_33_3    stock_ub_213  3
    x_33_3    parent_nonstrict_scope_214  9.3092572277933064e-03
    x_33_3    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_3    product_lb_139  1
    w_33_3    product_ub_140  1
    w_33_3    normalized_mass_33_158  1
    w_33_3    normalized_ratio_33_159  -6.0000000000000009e-01
    w_33_3    full_original_Gini_272  -8.8440476190476218e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_4    OBJ       -9.3092572277933133e-03
    x_33_4    product_lb_141  -2.5039496825324466e-02
    x_33_4    product_ub_142  -4.1939188177185088e-02
    x_33_4    onehot_33_157  1
    x_33_4    stock_lb_212  4
    x_33_4    stock_ub_213  4
    x_33_4    parent_nonstrict_scope_214  4.6546286138966532e-03
    x_33_4    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_4    product_lb_141  1
    w_33_4    product_ub_142  1
    w_33_4    normalized_mass_33_158  1
    w_33_4    normalized_ratio_33_159  -0.8
    w_33_4    full_original_Gini_272  -4.5821428571428582e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_5    OBJ       -1.3963885841689967e-02
    x_33_5    product_lb_143  -2.5039496825324466e-02
    x_33_5    product_ub_144  -4.1939188177185088e-02
    x_33_5    onehot_33_157  1
    x_33_5    stock_lb_212  5
    x_33_5    stock_ub_213  5
    x_33_5    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_5    product_lb_143  1
    w_33_5    product_ub_144  1
    w_33_5    normalized_mass_33_158  1
    w_33_5    normalized_ratio_33_159  -1
    w_33_5    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_6    OBJ       -9.3092572277933081e-03
    x_33_6    product_lb_145  -2.5039496825324466e-02
    x_33_6    product_ub_146  -4.1939188177185088e-02
    x_33_6    onehot_33_157  1
    x_33_6    stock_lb_212  6
    x_33_6    stock_ub_213  6
    x_33_6    parent_nonstrict_scope_214  4.6546286138966584e-03
    x_33_6    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_6    product_lb_145  1
    w_33_6    product_ub_146  1
    w_33_6    normalized_mass_33_158  1
    w_33_6    normalized_ratio_33_159  -1.2000000000000002e+00
    w_33_6    full_original_Gini_272  -9.1559523809523835e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_7    OBJ       -4.6546286138966549e-03
    x_33_7    product_lb_147  -2.5039496825324466e-02
    x_33_7    product_ub_148  -4.1939188177185088e-02
    x_33_7    onehot_33_157  1
    x_33_7    stock_lb_212  7
    x_33_7    stock_ub_213  7
    x_33_7    parent_nonstrict_scope_214  9.3092572277933116e-03
    x_33_7    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_7    product_lb_147  1
    w_33_7    product_ub_148  1
    w_33_7    normalized_mass_33_158  1
    w_33_7    normalized_ratio_33_159  -1.4000000000000001e+00
    w_33_7    full_original_Gini_272  -1.4155952380952387e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_8    product_lb_149  -2.5039496825324466e-02
    x_33_8    product_ub_150  -4.1939188177185088e-02
    x_33_8    onehot_33_157  1
    x_33_8    stock_lb_212  8
    x_33_8    stock_ub_213  8
    x_33_8    parent_nonstrict_scope_214  1.3963885841689967e-02
    MARKER    'MARKER'                 'INTEND'
    w_33_8    product_lb_149  1
    w_33_8    product_ub_150  1
    w_33_8    normalized_mass_33_158  1
    w_33_8    normalized_ratio_33_159  -1.6
    w_33_8    full_original_Gini_272  -1.9355952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_9    OBJ       4.6546286138966532e-03
    x_33_9    product_lb_151  -2.5039496825324466e-02
    x_33_9    product_ub_152  -4.1939188177185088e-02
    x_33_9    onehot_33_157  1
    x_33_9    stock_lb_212  9
    x_33_9    stock_ub_213  9
    x_33_9    parent_nonstrict_scope_214  1.8618514455586620e-02
    x_33_9    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_9    product_lb_151  1
    w_33_9    product_ub_152  1
    w_33_9    normalized_mass_33_158  1
    w_33_9    normalized_ratio_33_159  -1.8
    w_33_9    full_original_Gini_272  -2.4755952380952390e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_10   OBJ       9.3092572277933064e-03
    x_33_10   product_lb_153  -2.5039496825324466e-02
    x_33_10   product_ub_154  -4.1939188177185088e-02
    x_33_10   onehot_33_157  1
    x_33_10   stock_lb_212  10
    x_33_10   stock_ub_213  10
    x_33_10   parent_nonstrict_scope_214  2.3273143069483273e-02
    x_33_10   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_10   product_lb_153  1
    w_33_10   product_ub_154  1
    w_33_10   normalized_mass_33_158  1
    w_33_10   normalized_ratio_33_159  -2
    w_33_10   full_original_Gini_272  -3.0155952380952378e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_11   OBJ       1.3963885841689967e-02
    x_33_11   product_lb_155  -2.5039496825324466e-02
    x_33_11   product_ub_156  -4.1939188177185088e-02
    x_33_11   onehot_33_157  1
    x_33_11   stock_lb_212  11
    x_33_11   stock_ub_213  11
    x_33_11   parent_nonstrict_scope_214  2.7927771683379933e-02
    x_33_11   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_11   product_lb_155  1
    w_33_11   product_ub_156  1
    w_33_11   normalized_mass_33_158  1
    w_33_11   normalized_ratio_33_159  -2.2
    w_33_11   full_original_Gini_272  -3.5555952380952377e+01
    rho_33    normalized_ratio_33_159  1
    rho_33    block_pair_pos_217  1
    rho_33    block_pair_neg_218  -1
    rho_33    block_pair_pos_225  1
    rho_33    block_pair_neg_226  -1
    rho_33    block_pair_pos_239  1
    rho_33    block_pair_neg_240  -1
    rho_33    block_pair_pos_251  1
    rho_33    block_pair_neg_252  -1
    rho_33    block_pair_pos_257  -1
    rho_33    block_pair_neg_258  1
    rho_33    block_pair_pos_259  -1
    rho_33    block_pair_neg_260  1
    rho_33    block_pair_pos_267  1
    rho_33    block_pair_neg_268  -1
    rho_33    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_160  -2.5039496825324466e-02
    x_27_0    product_ub_161  -4.1939188177185088e-02
    x_27_0    onehot_27_174  1
    x_27_0    parent_nonstrict_scope_214  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_160  1
    w_27_0    product_ub_161  1
    w_27_0    normalized_mass_27_175  1
    w_27_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_162  -2.5039496825324466e-02
    x_27_1    product_ub_163  -4.1939188177185088e-02
    x_27_1    onehot_27_174  1
    x_27_1    stock_lb_212  1
    x_27_1    stock_ub_213  1
    x_27_1    parent_nonstrict_scope_214  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_162  1
    w_27_1    product_ub_163  1
    w_27_1    normalized_mass_27_175  1
    w_27_1    normalized_ratio_27_176  -3.3333333333333331e-01
    w_27_1    full_original_Gini_272  -1.5510714285714281e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_164  -2.5039496825324466e-02
    x_27_2    product_ub_165  -4.1939188177185088e-02
    x_27_2    onehot_27_174  1
    x_27_2    stock_lb_212  2
    x_27_2    stock_ub_213  2
    x_27_2    parent_nonstrict_scope_214  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_164  1
    w_27_2    product_ub_165  1
    w_27_2    normalized_mass_27_175  1
    w_27_2    normalized_ratio_27_176  -6.6666666666666663e-01
    w_27_2    full_original_Gini_272  -7.17738095238095
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_166  -2.5039496825324466e-02
    x_27_3    product_ub_167  -4.1939188177185088e-02
    x_27_3    onehot_27_174  1
    x_27_3    stock_lb_212  3
    x_27_3    stock_ub_213  3
    x_27_3    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_166  1
    w_27_3    product_ub_167  1
    w_27_3    normalized_mass_27_175  1
    w_27_3    normalized_ratio_27_176  -1
    w_27_3    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_168  -2.5039496825324466e-02
    x_27_4    product_ub_169  -4.1939188177185088e-02
    x_27_4    onehot_27_174  1
    x_27_4    stock_lb_212  4
    x_27_4    stock_ub_213  4
    x_27_4    parent_nonstrict_scope_214  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_168  1
    w_27_4    product_ub_169  1
    w_27_4    normalized_mass_27_175  1
    w_27_4    normalized_ratio_27_176  -1.3333333333333333e+00
    w_27_4    full_original_Gini_272  -1.2489285714285716e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_170  -2.5039496825324466e-02
    x_27_5    product_ub_171  -4.1939188177185088e-02
    x_27_5    onehot_27_174  1
    x_27_5    stock_lb_212  5
    x_27_5    stock_ub_213  5
    x_27_5    parent_nonstrict_scope_214  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_170  1
    w_27_5    product_ub_171  1
    w_27_5    normalized_mass_27_175  1
    w_27_5    normalized_ratio_27_176  -1.6666666666666665e+00
    w_27_5    full_original_Gini_272  -2.1155952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_172  -2.5039496825324466e-02
    x_27_6    product_ub_173  -4.1939188177185088e-02
    x_27_6    onehot_27_174  1
    x_27_6    stock_lb_212  6
    x_27_6    stock_ub_213  6
    x_27_6    parent_nonstrict_scope_214  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_172  1
    w_27_6    product_ub_173  1
    w_27_6    normalized_mass_27_175  1
    w_27_6    normalized_ratio_27_176  -2
    w_27_6    full_original_Gini_272  -3.0155952380952378e+01
    rho_27    normalized_ratio_27_176  1
    rho_27    block_pair_pos_215  1
    rho_27    block_pair_neg_216  -1
    rho_27    block_pair_pos_223  1
    rho_27    block_pair_neg_224  -1
    rho_27    block_pair_pos_229  -1
    rho_27    block_pair_neg_230  1
    rho_27    block_pair_pos_235  1
    rho_27    block_pair_neg_236  -1
    rho_27    block_pair_pos_249  1
    rho_27    block_pair_neg_250  -1
    rho_27    block_pair_pos_257  1
    rho_27    block_pair_neg_258  -1
    rho_27    block_pair_pos_265  1
    rho_27    block_pair_neg_266  -1
    rho_27    normalization_271  1
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       2.9789603523644435e-02
    x_35_0    product_lb_177  -2.5039496825324466e-02
    x_35_0    product_ub_178  -4.1939188177185088e-02
    x_35_0    onehot_35_209  1
    x_35_0    parent_nonstrict_scope_214  5.9579207047288869e-02
    x_35_0    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_177  1
    w_35_0    product_ub_178  1
    w_35_0    normalized_mass_35_210  1
    w_35_0    full_original_Gini_272  -2.3844047619047622e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       2.2342202642733327e-02
    x_35_1    product_lb_179  -2.5039496825324466e-02
    x_35_1    product_ub_180  -4.1939188177185088e-02
    x_35_1    onehot_35_209  1
    x_35_1    stock_lb_212  1
    x_35_1    stock_ub_213  1
    x_35_1    parent_nonstrict_scope_214  5.2131806166377762e-02
    x_35_1    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_179  1
    w_35_1    product_ub_180  1
    w_35_1    normalized_mass_35_210  1
    w_35_1    normalized_ratio_35_211  -0.125
    w_35_1    full_original_Gini_272  -2.0719047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       1.4894801761822219e-02
    x_35_2    product_lb_181  -2.5039496825324466e-02
    x_35_2    product_ub_182  -4.1939188177185088e-02
    x_35_2    onehot_35_209  1
    x_35_2    stock_lb_212  2
    x_35_2    stock_ub_213  2
    x_35_2    parent_nonstrict_scope_214  4.4684405285466654e-02
    x_35_2    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_181  1
    w_35_2    product_ub_182  1
    w_35_2    normalized_mass_35_210  1
    w_35_2    normalized_ratio_35_211  -0.25
    w_35_2    full_original_Gini_272  -1.7594047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       7.4474008809111113e-03
    x_35_3    product_lb_183  -2.5039496825324466e-02
    x_35_3    product_ub_184  -4.1939188177185088e-02
    x_35_3    onehot_35_209  1
    x_35_3    stock_lb_212  3
    x_35_3    stock_ub_213  3
    x_35_3    parent_nonstrict_scope_214  3.7237004404555546e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_183  1
    w_35_3    product_ub_184  1
    w_35_3    normalized_mass_35_210  1
    w_35_3    normalized_ratio_35_211  -0.375
    w_35_3    full_original_Gini_272  -1.4469047619047616e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_185  -2.5039496825324466e-02
    x_35_4    product_ub_186  -4.1939188177185088e-02
    x_35_4    onehot_35_209  1
    x_35_4    stock_lb_212  4
    x_35_4    stock_ub_213  4
    x_35_4    parent_nonstrict_scope_214  2.9789603523644435e-02
    x_35_4    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_185  1
    w_35_4    product_ub_186  1
    w_35_4    normalized_mass_35_210  1
    w_35_4    normalized_ratio_35_211  -0.5
    w_35_4    full_original_Gini_272  -1.1344047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -7.4474008809111078e-03
    x_35_5    product_lb_187  -2.5039496825324466e-02
    x_35_5    product_ub_188  -4.1939188177185088e-02
    x_35_5    onehot_35_209  1
    x_35_5    stock_lb_212  5
    x_35_5    stock_ub_213  5
    x_35_5    parent_nonstrict_scope_214  2.2342202642733327e-02
    x_35_5    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_187  1
    w_35_5    product_ub_188  1
    w_35_5    normalized_mass_35_210  1
    w_35_5    normalized_ratio_35_211  -0.625
    w_35_5    full_original_Gini_272  -8.2190476190476165e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -1.4894801761822217e-02
    x_35_6    product_lb_189  -2.5039496825324466e-02
    x_35_6    product_ub_190  -4.1939188177185088e-02
    x_35_6    onehot_35_209  1
    x_35_6    stock_lb_212  6
    x_35_6    stock_ub_213  6
    x_35_6    parent_nonstrict_scope_214  1.4894801761822217e-02
    x_35_6    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_189  1
    w_35_6    product_ub_190  1
    w_35_6    normalized_mass_35_210  1
    w_35_6    normalized_ratio_35_211  -0.75
    w_35_6    full_original_Gini_272  -5.3321428571428564e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -2.2342202642733327e-02
    x_35_7    product_lb_191  -2.5039496825324466e-02
    x_35_7    product_ub_192  -4.1939188177185088e-02
    x_35_7    onehot_35_209  1
    x_35_7    stock_lb_212  7
    x_35_7    stock_ub_213  7
    x_35_7    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_35_7    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_191  1
    w_35_7    product_ub_192  1
    w_35_7    normalized_mass_35_210  1
    w_35_7    normalized_ratio_35_211  -0.875
    w_35_7    full_original_Gini_272  -4.0309523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -2.9789603523644435e-02
    x_35_8    product_lb_193  -2.5039496825324466e-02
    x_35_8    product_ub_194  -4.1939188177185088e-02
    x_35_8    onehot_35_209  1
    x_35_8    stock_lb_212  8
    x_35_8    stock_ub_213  8
    x_35_8    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_193  1
    w_35_8    product_ub_194  1
    w_35_8    normalized_mass_35_210  1
    w_35_8    normalized_ratio_35_211  -1
    w_35_8    full_original_Gini_272  -4.1559523809523808e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -2.2342202642733327e-02
    x_35_9    product_lb_195  -2.5039496825324466e-02
    x_35_9    product_ub_196  -4.1939188177185088e-02
    x_35_9    onehot_35_209  1
    x_35_9    stock_lb_212  9
    x_35_9    stock_ub_213  9
    x_35_9    parent_nonstrict_scope_214  7.4474008809111087e-03
    x_35_9    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_195  1
    w_35_9    product_ub_196  1
    w_35_9    normalized_mass_35_210  1
    w_35_9    normalized_ratio_35_211  -1.125
    w_35_9    full_original_Gini_272  -7.2809523809523817e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -1.4894801761822217e-02
    x_35_10   product_lb_197  -2.5039496825324466e-02
    x_35_10   product_ub_198  -4.1939188177185088e-02
    x_35_10   onehot_35_209  1
    x_35_10   stock_lb_212  10
    x_35_10   stock_ub_213  10
    x_35_10   parent_nonstrict_scope_214  1.4894801761822217e-02
    x_35_10   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_197  1
    w_35_10   product_ub_198  1
    w_35_10   normalized_mass_35_210  1
    w_35_10   normalized_ratio_35_211  -1.25
    w_35_10   full_original_Gini_272  -1.0405952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -7.4474008809111078e-03
    x_35_11   product_lb_199  -2.5039496825324466e-02
    x_35_11   product_ub_200  -4.1939188177185088e-02
    x_35_11   onehot_35_209  1
    x_35_11   stock_lb_212  11
    x_35_11   stock_ub_213  11
    x_35_11   parent_nonstrict_scope_214  2.2342202642733327e-02
    x_35_11   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_199  1
    w_35_11   product_ub_200  1
    w_35_11   normalized_mass_35_210  1
    w_35_11   normalized_ratio_35_211  -1.375
    w_35_11   full_original_Gini_272  -1.3530952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_201  -2.5039496825324466e-02
    x_35_12   product_ub_202  -4.1939188177185088e-02
    x_35_12   onehot_35_209  1
    x_35_12   stock_lb_212  12
    x_35_12   stock_ub_213  12
    x_35_12   parent_nonstrict_scope_214  2.9789603523644435e-02
    x_35_12   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_201  1
    w_35_12   product_ub_202  1
    w_35_12   normalized_mass_35_210  1
    w_35_12   normalized_ratio_35_211  -1.5
    w_35_12   full_original_Gini_272  -1.6655952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       7.4474008809111113e-03
    x_35_13   product_lb_203  -2.5039496825324466e-02
    x_35_13   product_ub_204  -4.1939188177185088e-02
    x_35_13   onehot_35_209  1
    x_35_13   stock_lb_212  13
    x_35_13   stock_ub_213  13
    x_35_13   parent_nonstrict_scope_214  3.7237004404555546e-02
    x_35_13   unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_203  1
    w_35_13   product_ub_204  1
    w_35_13   normalized_mass_35_210  1
    w_35_13   normalized_ratio_35_211  -1.625
    w_35_13   full_original_Gini_272  -2.0030952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       1.4894801761822219e-02
    x_35_14   product_lb_205  -2.5039496825324466e-02
    x_35_14   product_ub_206  -4.1939188177185088e-02
    x_35_14   onehot_35_209  1
    x_35_14   stock_lb_212  14
    x_35_14   stock_ub_213  14
    x_35_14   parent_nonstrict_scope_214  4.4684405285466654e-02
    x_35_14   unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_205  1
    w_35_14   product_ub_206  1
    w_35_14   normalized_mass_35_210  1
    w_35_14   normalized_ratio_35_211  -1.75
    w_35_14   full_original_Gini_272  -2.3405952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       2.2342202642733327e-02
    x_35_15   product_lb_207  -2.5039496825324466e-02
    x_35_15   product_ub_208  -4.1939188177185088e-02
    x_35_15   onehot_35_209  1
    x_35_15   stock_lb_212  15
    x_35_15   stock_ub_213  15
    x_35_15   parent_nonstrict_scope_214  5.2131806166377762e-02
    x_35_15   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_207  1
    w_35_15   product_ub_208  1
    w_35_15   normalized_mass_35_210  1
    w_35_15   normalized_ratio_35_211  -1.875
    w_35_15   full_original_Gini_272  -2.6780952380952378e+01
    rho_35    normalized_ratio_35_211  1
    rho_35    block_pair_pos_219  1
    rho_35    block_pair_neg_220  -1
    rho_35    block_pair_pos_227  1
    rho_35    block_pair_neg_228  -1
    rho_35    block_pair_pos_229  1
    rho_35    block_pair_neg_230  -1
    rho_35    block_pair_pos_243  1
    rho_35    block_pair_neg_244  -1
    rho_35    block_pair_pos_255  1
    rho_35    block_pair_neg_256  -1
    rho_35    block_pair_pos_259  1
    rho_35    block_pair_neg_260  -1
    rho_35    block_pair_pos_269  1
    rho_35    block_pair_neg_270  -1
    rho_35    normalization_271  1
    a_28_29   block_pair_pos_237  1
    a_28_29   block_pair_neg_238  1
    a_28_29   full_original_Gini_272  -1
    a_28_34   block_pair_pos_241  1
    a_28_34   block_pair_neg_242  1
    a_28_34   full_original_Gini_272  -1
    a_28_26   block_pair_pos_233  1
    a_28_26   block_pair_neg_234  1
    a_28_26   full_original_Gini_272  -1
    a_28_22   block_pair_pos_231  1
    a_28_22   block_pair_neg_232  1
    a_28_22   full_original_Gini_272  -1
    a_28_33   block_pair_pos_239  1
    a_28_33   block_pair_neg_240  1
    a_28_33   full_original_Gini_272  -1
    a_28_27   block_pair_pos_235  1
    a_28_27   block_pair_neg_236  1
    a_28_27   full_original_Gini_272  -1
    a_28_35   block_pair_pos_243  1
    a_28_35   block_pair_neg_244  1
    a_28_35   full_original_Gini_272  -1
    a_29_34   block_pair_pos_253  1
    a_29_34   block_pair_neg_254  1
    a_29_34   full_original_Gini_272  -1
    a_29_26   block_pair_pos_247  1
    a_29_26   block_pair_neg_248  1
    a_29_26   full_original_Gini_272  -1
    a_29_22   block_pair_pos_245  1
    a_29_22   block_pair_neg_246  1
    a_29_22   full_original_Gini_272  -1
    a_29_33   block_pair_pos_251  1
    a_29_33   block_pair_neg_252  1
    a_29_33   full_original_Gini_272  -1
    a_29_27   block_pair_pos_249  1
    a_29_27   block_pair_neg_250  1
    a_29_27   full_original_Gini_272  -1
    a_29_35   block_pair_pos_255  1
    a_29_35   block_pair_neg_256  1
    a_29_35   full_original_Gini_272  -1
    a_34_26   block_pair_pos_263  1
    a_34_26   block_pair_neg_264  1
    a_34_26   full_original_Gini_272  -1
    a_34_22   block_pair_pos_261  1
    a_34_22   block_pair_neg_262  1
    a_34_22   full_original_Gini_272  -1
    a_34_33   block_pair_pos_267  1
    a_34_33   block_pair_neg_268  1
    a_34_33   full_original_Gini_272  -1
    a_34_27   block_pair_pos_265  1
    a_34_27   block_pair_neg_266  1
    a_34_27   full_original_Gini_272  -1
    a_34_35   block_pair_pos_269  1
    a_34_35   block_pair_neg_270  1
    a_34_35   full_original_Gini_272  -1
    a_26_22   block_pair_pos_221  1
    a_26_22   block_pair_neg_222  1
    a_26_22   full_original_Gini_272  -1
    a_26_33   block_pair_pos_225  1
    a_26_33   block_pair_neg_226  1
    a_26_33   full_original_Gini_272  -1
    a_26_27   block_pair_pos_223  1
    a_26_27   block_pair_neg_224  1
    a_26_27   full_original_Gini_272  -1
    a_26_35   block_pair_pos_227  1
    a_26_35   block_pair_neg_228  1
    a_26_35   full_original_Gini_272  -1
    a_22_33   block_pair_pos_217  1
    a_22_33   block_pair_neg_218  1
    a_22_33   full_original_Gini_272  -1
    a_22_27   block_pair_pos_215  1
    a_22_27   block_pair_neg_216  1
    a_22_27   full_original_Gini_272  -1
    a_22_35   block_pair_pos_219  1
    a_22_35   block_pair_neg_220  1
    a_22_35   full_original_Gini_272  -1
    a_33_27   block_pair_pos_257  1
    a_33_27   block_pair_neg_258  1
    a_33_27   full_original_Gini_272  -1
    a_33_35   block_pair_pos_259  1
    a_33_35   block_pair_neg_260  1
    a_33_35   full_original_Gini_272  -1
    a_27_35   block_pair_pos_229  1
    a_27_35   block_pair_neg_230  1
    a_27_35   full_original_Gini_272  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_28_0  unique_nonzero_owner_273  1
    service_0_28_0  service_visit_def_739  1
    service_0_28_0  free_load_conservation_740  -1
    service_0_28_0  original_T_including_depot_unload_787  120
    service_0_28_2  unique_nonzero_owner_274  1
    service_0_28_2  service_visit_def_739  1
    service_0_28_2  free_load_conservation_740  1
    service_0_28_3  unique_nonzero_owner_275  1
    service_0_28_3  service_visit_def_739  1
    service_0_28_3  free_load_conservation_740  2
    service_0_28_4  unique_nonzero_owner_276  1
    service_0_28_4  service_visit_def_739  1
    service_0_28_4  free_load_conservation_740  3
    service_0_28_5  unique_nonzero_owner_277  1
    service_0_28_5  service_visit_def_739  1
    service_0_28_5  free_load_conservation_740  4
    service_0_28_6  unique_nonzero_owner_278  1
    service_0_28_6  service_visit_def_739  1
    service_0_28_6  free_load_conservation_740  5
    service_1_28_0  unique_nonzero_owner_273  1
    service_1_28_0  service_visit_def_1111  1
    service_1_28_0  free_load_conservation_1112  -1
    service_1_28_0  original_T_including_depot_unload_1158  120
    service_1_28_2  unique_nonzero_owner_274  1
    service_1_28_2  service_visit_def_1111  1
    service_1_28_2  free_load_conservation_1112  1
    service_1_28_3  unique_nonzero_owner_275  1
    service_1_28_3  service_visit_def_1111  1
    service_1_28_3  free_load_conservation_1112  2
    service_1_28_4  unique_nonzero_owner_276  1
    service_1_28_4  service_visit_def_1111  1
    service_1_28_4  free_load_conservation_1112  3
    service_1_28_5  unique_nonzero_owner_277  1
    service_1_28_5  service_visit_def_1111  1
    service_1_28_5  free_load_conservation_1112  4
    service_1_28_6  unique_nonzero_owner_278  1
    service_1_28_6  service_visit_def_1111  1
    service_1_28_6  free_load_conservation_1112  5
    service_2_28_0  unique_nonzero_owner_273  1
    service_2_28_0  service_visit_def_1429  1
    service_2_28_0  free_load_conservation_1430  -1
    service_2_28_0  original_T_including_depot_unload_1475  120
    service_2_28_2  unique_nonzero_owner_274  1
    service_2_28_2  service_visit_def_1429  1
    service_2_28_2  free_load_conservation_1430  1
    service_2_28_3  unique_nonzero_owner_275  1
    service_2_28_3  service_visit_def_1429  1
    service_2_28_3  free_load_conservation_1430  2
    service_2_28_4  unique_nonzero_owner_276  1
    service_2_28_4  service_visit_def_1429  1
    service_2_28_4  free_load_conservation_1430  3
    service_2_28_5  unique_nonzero_owner_277  1
    service_2_28_5  service_visit_def_1429  1
    service_2_28_5  free_load_conservation_1430  4
    service_2_28_6  unique_nonzero_owner_278  1
    service_2_28_6  service_visit_def_1429  1
    service_2_28_6  free_load_conservation_1430  5
    service_0_29_0  unique_nonzero_owner_279  1
    service_0_29_0  service_visit_def_745  1
    service_0_29_0  free_load_conservation_746  -1
    service_0_29_0  original_T_including_depot_unload_787  120
    service_0_29_2  unique_nonzero_owner_280  1
    service_0_29_2  service_visit_def_745  1
    service_0_29_2  free_load_conservation_746  1
    service_0_29_3  unique_nonzero_owner_281  1
    service_0_29_3  service_visit_def_745  1
    service_0_29_3  free_load_conservation_746  2
    service_0_29_4  unique_nonzero_owner_282  1
    service_0_29_4  service_visit_def_745  1
    service_0_29_4  free_load_conservation_746  3
    service_0_29_5  unique_nonzero_owner_283  1
    service_0_29_5  service_visit_def_745  1
    service_0_29_5  free_load_conservation_746  4
    service_0_29_6  unique_nonzero_owner_284  1
    service_0_29_6  service_visit_def_745  1
    service_0_29_6  free_load_conservation_746  5
    service_0_29_7  unique_nonzero_owner_285  1
    service_0_29_7  service_visit_def_745  1
    service_0_29_7  free_load_conservation_746  6
    service_0_29_8  unique_nonzero_owner_286  1
    service_0_29_8  service_visit_def_745  1
    service_0_29_8  free_load_conservation_746  7
    service_0_29_9  unique_nonzero_owner_287  1
    service_0_29_9  service_visit_def_745  1
    service_0_29_9  free_load_conservation_746  8
    service_0_29_10  unique_nonzero_owner_288  1
    service_0_29_10  service_visit_def_745  1
    service_0_29_10  free_load_conservation_746  9
    service_1_29_0  unique_nonzero_owner_279  1
    service_1_29_0  service_visit_def_1117  1
    service_1_29_0  free_load_conservation_1118  -1
    service_1_29_0  original_T_including_depot_unload_1158  120
    service_1_29_2  unique_nonzero_owner_280  1
    service_1_29_2  service_visit_def_1117  1
    service_1_29_2  free_load_conservation_1118  1
    service_1_29_3  unique_nonzero_owner_281  1
    service_1_29_3  service_visit_def_1117  1
    service_1_29_3  free_load_conservation_1118  2
    service_1_29_4  unique_nonzero_owner_282  1
    service_1_29_4  service_visit_def_1117  1
    service_1_29_4  free_load_conservation_1118  3
    service_1_29_5  unique_nonzero_owner_283  1
    service_1_29_5  service_visit_def_1117  1
    service_1_29_5  free_load_conservation_1118  4
    service_1_29_6  unique_nonzero_owner_284  1
    service_1_29_6  service_visit_def_1117  1
    service_1_29_6  free_load_conservation_1118  5
    service_1_29_7  unique_nonzero_owner_285  1
    service_1_29_7  service_visit_def_1117  1
    service_1_29_7  free_load_conservation_1118  6
    service_1_29_8  unique_nonzero_owner_286  1
    service_1_29_8  service_visit_def_1117  1
    service_1_29_8  free_load_conservation_1118  7
    service_1_29_9  unique_nonzero_owner_287  1
    service_1_29_9  service_visit_def_1117  1
    service_1_29_9  free_load_conservation_1118  8
    service_1_29_10  unique_nonzero_owner_288  1
    service_1_29_10  service_visit_def_1117  1
    service_1_29_10  free_load_conservation_1118  9
    service_2_29_0  unique_nonzero_owner_279  1
    service_2_29_0  service_visit_def_1435  1
    service_2_29_0  free_load_conservation_1436  -1
    service_2_29_0  original_T_including_depot_unload_1475  120
    service_2_29_2  unique_nonzero_owner_280  1
    service_2_29_2  service_visit_def_1435  1
    service_2_29_2  free_load_conservation_1436  1
    service_2_29_3  unique_nonzero_owner_281  1
    service_2_29_3  service_visit_def_1435  1
    service_2_29_3  free_load_conservation_1436  2
    service_2_29_4  unique_nonzero_owner_282  1
    service_2_29_4  service_visit_def_1435  1
    service_2_29_4  free_load_conservation_1436  3
    service_2_29_5  unique_nonzero_owner_283  1
    service_2_29_5  service_visit_def_1435  1
    service_2_29_5  free_load_conservation_1436  4
    service_2_29_6  unique_nonzero_owner_284  1
    service_2_29_6  service_visit_def_1435  1
    service_2_29_6  free_load_conservation_1436  5
    service_2_29_7  unique_nonzero_owner_285  1
    service_2_29_7  service_visit_def_1435  1
    service_2_29_7  free_load_conservation_1436  6
    service_2_29_8  unique_nonzero_owner_286  1
    service_2_29_8  service_visit_def_1435  1
    service_2_29_8  free_load_conservation_1436  7
    service_2_29_9  unique_nonzero_owner_287  1
    service_2_29_9  service_visit_def_1435  1
    service_2_29_9  free_load_conservation_1436  8
    service_2_29_10  unique_nonzero_owner_288  1
    service_2_29_10  service_visit_def_1435  1
    service_2_29_10  free_load_conservation_1436  9
    service_0_34_0  unique_nonzero_owner_289  1
    service_0_34_0  service_visit_def_751  1
    service_0_34_0  free_load_conservation_752  -2
    service_0_34_0  original_T_including_depot_unload_787  240
    service_0_34_1  unique_nonzero_owner_290  1
    service_0_34_1  service_visit_def_751  1
    service_0_34_1  free_load_conservation_752  -1
    service_0_34_1  original_T_including_depot_unload_787  120
    service_0_34_3  unique_nonzero_owner_291  1
    service_0_34_3  service_visit_def_751  1
    service_0_34_3  free_load_conservation_752  1
    service_0_34_4  unique_nonzero_owner_292  1
    service_0_34_4  service_visit_def_751  1
    service_0_34_4  free_load_conservation_752  2
    service_0_34_5  unique_nonzero_owner_293  1
    service_0_34_5  service_visit_def_751  1
    service_0_34_5  free_load_conservation_752  3
    service_0_34_6  unique_nonzero_owner_294  1
    service_0_34_6  service_visit_def_751  1
    service_0_34_6  free_load_conservation_752  4
    service_0_34_7  unique_nonzero_owner_295  1
    service_0_34_7  service_visit_def_751  1
    service_0_34_7  free_load_conservation_752  5
    service_0_34_8  unique_nonzero_owner_296  1
    service_0_34_8  service_visit_def_751  1
    service_0_34_8  free_load_conservation_752  6
    service_0_34_9  unique_nonzero_owner_297  1
    service_0_34_9  service_visit_def_751  1
    service_0_34_9  free_load_conservation_752  7
    service_0_34_10  unique_nonzero_owner_298  1
    service_0_34_10  service_visit_def_751  1
    service_0_34_10  free_load_conservation_752  8
    service_0_34_11  unique_nonzero_owner_299  1
    service_0_34_11  service_visit_def_751  1
    service_0_34_11  free_load_conservation_752  9
    service_0_34_12  unique_nonzero_owner_300  1
    service_0_34_12  service_visit_def_751  1
    service_0_34_12  free_load_conservation_752  10
    service_0_34_13  unique_nonzero_owner_301  1
    service_0_34_13  service_visit_def_751  1
    service_0_34_13  free_load_conservation_752  11
    service_0_34_14  unique_nonzero_owner_302  1
    service_0_34_14  service_visit_def_751  1
    service_0_34_14  free_load_conservation_752  12
    service_0_34_15  unique_nonzero_owner_303  1
    service_0_34_15  service_visit_def_751  1
    service_0_34_15  free_load_conservation_752  13
    service_1_34_0  unique_nonzero_owner_289  1
    service_1_34_0  service_visit_def_1123  1
    service_1_34_0  free_load_conservation_1124  -2
    service_1_34_0  original_T_including_depot_unload_1158  240
    service_1_34_1  unique_nonzero_owner_290  1
    service_1_34_1  service_visit_def_1123  1
    service_1_34_1  free_load_conservation_1124  -1
    service_1_34_1  original_T_including_depot_unload_1158  120
    service_1_34_3  unique_nonzero_owner_291  1
    service_1_34_3  service_visit_def_1123  1
    service_1_34_3  free_load_conservation_1124  1
    service_1_34_4  unique_nonzero_owner_292  1
    service_1_34_4  service_visit_def_1123  1
    service_1_34_4  free_load_conservation_1124  2
    service_1_34_5  unique_nonzero_owner_293  1
    service_1_34_5  service_visit_def_1123  1
    service_1_34_5  free_load_conservation_1124  3
    service_1_34_6  unique_nonzero_owner_294  1
    service_1_34_6  service_visit_def_1123  1
    service_1_34_6  free_load_conservation_1124  4
    service_1_34_7  unique_nonzero_owner_295  1
    service_1_34_7  service_visit_def_1123  1
    service_1_34_7  free_load_conservation_1124  5
    service_1_34_8  unique_nonzero_owner_296  1
    service_1_34_8  service_visit_def_1123  1
    service_1_34_8  free_load_conservation_1124  6
    service_1_34_9  unique_nonzero_owner_297  1
    service_1_34_9  service_visit_def_1123  1
    service_1_34_9  free_load_conservation_1124  7
    service_1_34_10  unique_nonzero_owner_298  1
    service_1_34_10  service_visit_def_1123  1
    service_1_34_10  free_load_conservation_1124  8
    service_1_34_11  unique_nonzero_owner_299  1
    service_1_34_11  service_visit_def_1123  1
    service_1_34_11  free_load_conservation_1124  9
    service_1_34_12  unique_nonzero_owner_300  1
    service_1_34_12  service_visit_def_1123  1
    service_1_34_12  free_load_conservation_1124  10
    service_1_34_13  unique_nonzero_owner_301  1
    service_1_34_13  service_visit_def_1123  1
    service_1_34_13  free_load_conservation_1124  11
    service_1_34_14  unique_nonzero_owner_302  1
    service_1_34_14  service_visit_def_1123  1
    service_1_34_14  free_load_conservation_1124  12
    service_1_34_15  unique_nonzero_owner_303  1
    service_1_34_15  service_visit_def_1123  1
    service_1_34_15  free_load_conservation_1124  13
    service_2_34_0  unique_nonzero_owner_289  1
    service_2_34_0  service_visit_def_1441  1
    service_2_34_0  free_load_conservation_1442  -2
    service_2_34_0  original_T_including_depot_unload_1475  240
    service_2_34_1  unique_nonzero_owner_290  1
    service_2_34_1  service_visit_def_1441  1
    service_2_34_1  free_load_conservation_1442  -1
    service_2_34_1  original_T_including_depot_unload_1475  120
    service_2_34_3  unique_nonzero_owner_291  1
    service_2_34_3  service_visit_def_1441  1
    service_2_34_3  free_load_conservation_1442  1
    service_2_34_4  unique_nonzero_owner_292  1
    service_2_34_4  service_visit_def_1441  1
    service_2_34_4  free_load_conservation_1442  2
    service_2_34_5  unique_nonzero_owner_293  1
    service_2_34_5  service_visit_def_1441  1
    service_2_34_5  free_load_conservation_1442  3
    service_2_34_6  unique_nonzero_owner_294  1
    service_2_34_6  service_visit_def_1441  1
    service_2_34_6  free_load_conservation_1442  4
    service_2_34_7  unique_nonzero_owner_295  1
    service_2_34_7  service_visit_def_1441  1
    service_2_34_7  free_load_conservation_1442  5
    service_2_34_8  unique_nonzero_owner_296  1
    service_2_34_8  service_visit_def_1441  1
    service_2_34_8  free_load_conservation_1442  6
    service_2_34_9  unique_nonzero_owner_297  1
    service_2_34_9  service_visit_def_1441  1
    service_2_34_9  free_load_conservation_1442  7
    service_2_34_10  unique_nonzero_owner_298  1
    service_2_34_10  service_visit_def_1441  1
    service_2_34_10  free_load_conservation_1442  8
    service_2_34_11  unique_nonzero_owner_299  1
    service_2_34_11  service_visit_def_1441  1
    service_2_34_11  free_load_conservation_1442  9
    service_2_34_12  unique_nonzero_owner_300  1
    service_2_34_12  service_visit_def_1441  1
    service_2_34_12  free_load_conservation_1442  10
    service_2_34_13  unique_nonzero_owner_301  1
    service_2_34_13  service_visit_def_1441  1
    service_2_34_13  free_load_conservation_1442  11
    service_2_34_14  unique_nonzero_owner_302  1
    service_2_34_14  service_visit_def_1441  1
    service_2_34_14  free_load_conservation_1442  12
    service_2_34_15  unique_nonzero_owner_303  1
    service_2_34_15  service_visit_def_1441  1
    service_2_34_15  free_load_conservation_1442  13
    service_0_26_0  unique_nonzero_owner_304  1
    service_0_26_0  service_visit_def_757  1
    service_0_26_0  free_load_conservation_758  -5
    service_0_26_0  original_T_including_depot_unload_787  600
    service_0_26_1  unique_nonzero_owner_305  1
    service_0_26_1  service_visit_def_757  1
    service_0_26_1  free_load_conservation_758  -4
    service_0_26_1  original_T_including_depot_unload_787  480
    service_0_26_2  unique_nonzero_owner_306  1
    service_0_26_2  service_visit_def_757  1
    service_0_26_2  free_load_conservation_758  -3
    service_0_26_2  original_T_including_depot_unload_787  360
    service_0_26_3  unique_nonzero_owner_307  1
    service_0_26_3  service_visit_def_757  1
    service_0_26_3  free_load_conservation_758  -2
    service_0_26_3  original_T_including_depot_unload_787  240
    service_0_26_4  unique_nonzero_owner_308  1
    service_0_26_4  service_visit_def_757  1
    service_0_26_4  free_load_conservation_758  -1
    service_0_26_4  original_T_including_depot_unload_787  120
    service_0_26_6  unique_nonzero_owner_309  1
    service_0_26_6  service_visit_def_757  1
    service_0_26_6  free_load_conservation_758  1
    service_0_26_7  unique_nonzero_owner_310  1
    service_0_26_7  service_visit_def_757  1
    service_0_26_7  free_load_conservation_758  2
    service_0_26_8  unique_nonzero_owner_311  1
    service_0_26_8  service_visit_def_757  1
    service_0_26_8  free_load_conservation_758  3
    service_1_26_0  unique_nonzero_owner_304  1
    service_1_26_0  service_visit_def_1129  1
    service_1_26_0  free_load_conservation_1130  -5
    service_1_26_0  original_T_including_depot_unload_1158  600
    service_1_26_1  unique_nonzero_owner_305  1
    service_1_26_1  service_visit_def_1129  1
    service_1_26_1  free_load_conservation_1130  -4
    service_1_26_1  original_T_including_depot_unload_1158  480
    service_1_26_2  unique_nonzero_owner_306  1
    service_1_26_2  service_visit_def_1129  1
    service_1_26_2  free_load_conservation_1130  -3
    service_1_26_2  original_T_including_depot_unload_1158  360
    service_1_26_3  unique_nonzero_owner_307  1
    service_1_26_3  service_visit_def_1129  1
    service_1_26_3  free_load_conservation_1130  -2
    service_1_26_3  original_T_including_depot_unload_1158  240
    service_1_26_4  unique_nonzero_owner_308  1
    service_1_26_4  service_visit_def_1129  1
    service_1_26_4  free_load_conservation_1130  -1
    service_1_26_4  original_T_including_depot_unload_1158  120
    service_1_26_6  unique_nonzero_owner_309  1
    service_1_26_6  service_visit_def_1129  1
    service_1_26_6  free_load_conservation_1130  1
    service_1_26_7  unique_nonzero_owner_310  1
    service_1_26_7  service_visit_def_1129  1
    service_1_26_7  free_load_conservation_1130  2
    service_1_26_8  unique_nonzero_owner_311  1
    service_1_26_8  service_visit_def_1129  1
    service_1_26_8  free_load_conservation_1130  3
    service_2_26_0  unique_nonzero_owner_304  1
    service_2_26_0  service_visit_def_1447  1
    service_2_26_0  free_load_conservation_1448  -5
    service_2_26_0  original_T_including_depot_unload_1475  600
    service_2_26_1  unique_nonzero_owner_305  1
    service_2_26_1  service_visit_def_1447  1
    service_2_26_1  free_load_conservation_1448  -4
    service_2_26_1  original_T_including_depot_unload_1475  480
    service_2_26_2  unique_nonzero_owner_306  1
    service_2_26_2  service_visit_def_1447  1
    service_2_26_2  free_load_conservation_1448  -3
    service_2_26_2  original_T_including_depot_unload_1475  360
    service_2_26_3  unique_nonzero_owner_307  1
    service_2_26_3  service_visit_def_1447  1
    service_2_26_3  free_load_conservation_1448  -2
    service_2_26_3  original_T_including_depot_unload_1475  240
    service_2_26_4  unique_nonzero_owner_308  1
    service_2_26_4  service_visit_def_1447  1
    service_2_26_4  free_load_conservation_1448  -1
    service_2_26_4  original_T_including_depot_unload_1475  120
    service_2_26_6  unique_nonzero_owner_309  1
    service_2_26_6  service_visit_def_1447  1
    service_2_26_6  free_load_conservation_1448  1
    service_2_26_7  unique_nonzero_owner_310  1
    service_2_26_7  service_visit_def_1447  1
    service_2_26_7  free_load_conservation_1448  2
    service_2_26_8  unique_nonzero_owner_311  1
    service_2_26_8  service_visit_def_1447  1
    service_2_26_8  free_load_conservation_1448  3
    service_0_22_0  unique_nonzero_owner_312  1
    service_0_22_0  service_visit_def_763  1
    service_0_22_0  free_load_conservation_764  -2
    service_0_22_0  original_T_including_depot_unload_787  240
    service_0_22_1  unique_nonzero_owner_313  1
    service_0_22_1  service_visit_def_763  1
    service_0_22_1  free_load_conservation_764  -1
    service_0_22_1  original_T_including_depot_unload_787  120
    service_0_22_3  unique_nonzero_owner_314  1
    service_0_22_3  service_visit_def_763  1
    service_0_22_3  free_load_conservation_764  1
    service_0_22_4  unique_nonzero_owner_315  1
    service_0_22_4  service_visit_def_763  1
    service_0_22_4  free_load_conservation_764  2
    service_0_22_5  unique_nonzero_owner_316  1
    service_0_22_5  service_visit_def_763  1
    service_0_22_5  free_load_conservation_764  3
    service_0_22_6  unique_nonzero_owner_317  1
    service_0_22_6  service_visit_def_763  1
    service_0_22_6  free_load_conservation_764  4
    service_0_22_7  unique_nonzero_owner_318  1
    service_0_22_7  service_visit_def_763  1
    service_0_22_7  free_load_conservation_764  5
    service_0_22_8  unique_nonzero_owner_319  1
    service_0_22_8  service_visit_def_763  1
    service_0_22_8  free_load_conservation_764  6
    service_0_22_9  unique_nonzero_owner_320  1
    service_0_22_9  service_visit_def_763  1
    service_0_22_9  free_load_conservation_764  7
    service_0_22_10  unique_nonzero_owner_321  1
    service_0_22_10  service_visit_def_763  1
    service_0_22_10  free_load_conservation_764  8
    service_0_22_11  unique_nonzero_owner_322  1
    service_0_22_11  service_visit_def_763  1
    service_0_22_11  free_load_conservation_764  9
    service_0_22_12  unique_nonzero_owner_323  1
    service_0_22_12  service_visit_def_763  1
    service_0_22_12  free_load_conservation_764  10
    service_0_22_13  unique_nonzero_owner_324  1
    service_0_22_13  service_visit_def_763  1
    service_0_22_13  free_load_conservation_764  11
    service_0_22_14  unique_nonzero_owner_325  1
    service_0_22_14  service_visit_def_763  1
    service_0_22_14  free_load_conservation_764  12
    service_0_22_15  unique_nonzero_owner_326  1
    service_0_22_15  service_visit_def_763  1
    service_0_22_15  free_load_conservation_764  13
    service_1_22_0  unique_nonzero_owner_312  1
    service_1_22_0  service_visit_def_1135  1
    service_1_22_0  free_load_conservation_1136  -2
    service_1_22_0  original_T_including_depot_unload_1158  240
    service_1_22_1  unique_nonzero_owner_313  1
    service_1_22_1  service_visit_def_1135  1
    service_1_22_1  free_load_conservation_1136  -1
    service_1_22_1  original_T_including_depot_unload_1158  120
    service_1_22_3  unique_nonzero_owner_314  1
    service_1_22_3  service_visit_def_1135  1
    service_1_22_3  free_load_conservation_1136  1
    service_1_22_4  unique_nonzero_owner_315  1
    service_1_22_4  service_visit_def_1135  1
    service_1_22_4  free_load_conservation_1136  2
    service_1_22_5  unique_nonzero_owner_316  1
    service_1_22_5  service_visit_def_1135  1
    service_1_22_5  free_load_conservation_1136  3
    service_1_22_6  unique_nonzero_owner_317  1
    service_1_22_6  service_visit_def_1135  1
    service_1_22_6  free_load_conservation_1136  4
    service_1_22_7  unique_nonzero_owner_318  1
    service_1_22_7  service_visit_def_1135  1
    service_1_22_7  free_load_conservation_1136  5
    service_1_22_8  unique_nonzero_owner_319  1
    service_1_22_8  service_visit_def_1135  1
    service_1_22_8  free_load_conservation_1136  6
    service_1_22_9  unique_nonzero_owner_320  1
    service_1_22_9  service_visit_def_1135  1
    service_1_22_9  free_load_conservation_1136  7
    service_1_22_10  unique_nonzero_owner_321  1
    service_1_22_10  service_visit_def_1135  1
    service_1_22_10  free_load_conservation_1136  8
    service_1_22_11  unique_nonzero_owner_322  1
    service_1_22_11  service_visit_def_1135  1
    service_1_22_11  free_load_conservation_1136  9
    service_1_22_12  unique_nonzero_owner_323  1
    service_1_22_12  service_visit_def_1135  1
    service_1_22_12  free_load_conservation_1136  10
    service_1_22_13  unique_nonzero_owner_324  1
    service_1_22_13  service_visit_def_1135  1
    service_1_22_13  free_load_conservation_1136  11
    service_1_22_14  unique_nonzero_owner_325  1
    service_1_22_14  service_visit_def_1135  1
    service_1_22_14  free_load_conservation_1136  12
    service_1_22_15  unique_nonzero_owner_326  1
    service_1_22_15  service_visit_def_1135  1
    service_1_22_15  free_load_conservation_1136  13
    service_2_22_0  unique_nonzero_owner_312  1
    service_2_22_0  service_visit_def_1453  1
    service_2_22_0  free_load_conservation_1454  -2
    service_2_22_0  original_T_including_depot_unload_1475  240
    service_2_22_1  unique_nonzero_owner_313  1
    service_2_22_1  service_visit_def_1453  1
    service_2_22_1  free_load_conservation_1454  -1
    service_2_22_1  original_T_including_depot_unload_1475  120
    service_2_22_3  unique_nonzero_owner_314  1
    service_2_22_3  service_visit_def_1453  1
    service_2_22_3  free_load_conservation_1454  1
    service_2_22_4  unique_nonzero_owner_315  1
    service_2_22_4  service_visit_def_1453  1
    service_2_22_4  free_load_conservation_1454  2
    service_2_22_5  unique_nonzero_owner_316  1
    service_2_22_5  service_visit_def_1453  1
    service_2_22_5  free_load_conservation_1454  3
    service_2_22_6  unique_nonzero_owner_317  1
    service_2_22_6  service_visit_def_1453  1
    service_2_22_6  free_load_conservation_1454  4
    service_2_22_7  unique_nonzero_owner_318  1
    service_2_22_7  service_visit_def_1453  1
    service_2_22_7  free_load_conservation_1454  5
    service_2_22_8  unique_nonzero_owner_319  1
    service_2_22_8  service_visit_def_1453  1
    service_2_22_8  free_load_conservation_1454  6
    service_2_22_9  unique_nonzero_owner_320  1
    service_2_22_9  service_visit_def_1453  1
    service_2_22_9  free_load_conservation_1454  7
    service_2_22_10  unique_nonzero_owner_321  1
    service_2_22_10  service_visit_def_1453  1
    service_2_22_10  free_load_conservation_1454  8
    service_2_22_11  unique_nonzero_owner_322  1
    service_2_22_11  service_visit_def_1453  1
    service_2_22_11  free_load_conservation_1454  9
    service_2_22_12  unique_nonzero_owner_323  1
    service_2_22_12  service_visit_def_1453  1
    service_2_22_12  free_load_conservation_1454  10
    service_2_22_13  unique_nonzero_owner_324  1
    service_2_22_13  service_visit_def_1453  1
    service_2_22_13  free_load_conservation_1454  11
    service_2_22_14  unique_nonzero_owner_325  1
    service_2_22_14  service_visit_def_1453  1
    service_2_22_14  free_load_conservation_1454  12
    service_2_22_15  unique_nonzero_owner_326  1
    service_2_22_15  service_visit_def_1453  1
    service_2_22_15  free_load_conservation_1454  13
    service_0_33_0  unique_nonzero_owner_327  1
    service_0_33_0  service_visit_def_769  1
    service_0_33_0  free_load_conservation_770  -8
    service_0_33_0  original_T_including_depot_unload_787  960
    service_0_33_1  unique_nonzero_owner_328  1
    service_0_33_1  service_visit_def_769  1
    service_0_33_1  free_load_conservation_770  -7
    service_0_33_1  original_T_including_depot_unload_787  840
    service_0_33_2  unique_nonzero_owner_329  1
    service_0_33_2  service_visit_def_769  1
    service_0_33_2  free_load_conservation_770  -6
    service_0_33_2  original_T_including_depot_unload_787  720
    service_0_33_3  unique_nonzero_owner_330  1
    service_0_33_3  service_visit_def_769  1
    service_0_33_3  free_load_conservation_770  -5
    service_0_33_3  original_T_including_depot_unload_787  600
    service_0_33_4  unique_nonzero_owner_331  1
    service_0_33_4  service_visit_def_769  1
    service_0_33_4  free_load_conservation_770  -4
    service_0_33_4  original_T_including_depot_unload_787  480
    service_0_33_5  unique_nonzero_owner_332  1
    service_0_33_5  service_visit_def_769  1
    service_0_33_5  free_load_conservation_770  -3
    service_0_33_5  original_T_including_depot_unload_787  360
    service_0_33_6  unique_nonzero_owner_333  1
    service_0_33_6  service_visit_def_769  1
    service_0_33_6  free_load_conservation_770  -2
    service_0_33_6  original_T_including_depot_unload_787  240
    service_0_33_7  unique_nonzero_owner_334  1
    service_0_33_7  service_visit_def_769  1
    service_0_33_7  free_load_conservation_770  -1
    service_0_33_7  original_T_including_depot_unload_787  120
    service_0_33_9  unique_nonzero_owner_335  1
    service_0_33_9  service_visit_def_769  1
    service_0_33_9  free_load_conservation_770  1
    service_0_33_10  unique_nonzero_owner_336  1
    service_0_33_10  service_visit_def_769  1
    service_0_33_10  free_load_conservation_770  2
    service_0_33_11  unique_nonzero_owner_337  1
    service_0_33_11  service_visit_def_769  1
    service_0_33_11  free_load_conservation_770  3
    service_1_33_0  unique_nonzero_owner_327  1
    service_1_33_0  service_visit_def_1141  1
    service_1_33_0  free_load_conservation_1142  -8
    service_1_33_0  original_T_including_depot_unload_1158  960
    service_1_33_1  unique_nonzero_owner_328  1
    service_1_33_1  service_visit_def_1141  1
    service_1_33_1  free_load_conservation_1142  -7
    service_1_33_1  original_T_including_depot_unload_1158  840
    service_1_33_2  unique_nonzero_owner_329  1
    service_1_33_2  service_visit_def_1141  1
    service_1_33_2  free_load_conservation_1142  -6
    service_1_33_2  original_T_including_depot_unload_1158  720
    service_1_33_3  unique_nonzero_owner_330  1
    service_1_33_3  service_visit_def_1141  1
    service_1_33_3  free_load_conservation_1142  -5
    service_1_33_3  original_T_including_depot_unload_1158  600
    service_1_33_4  unique_nonzero_owner_331  1
    service_1_33_4  service_visit_def_1141  1
    service_1_33_4  free_load_conservation_1142  -4
    service_1_33_4  original_T_including_depot_unload_1158  480
    service_1_33_5  unique_nonzero_owner_332  1
    service_1_33_5  service_visit_def_1141  1
    service_1_33_5  free_load_conservation_1142  -3
    service_1_33_5  original_T_including_depot_unload_1158  360
    service_1_33_6  unique_nonzero_owner_333  1
    service_1_33_6  service_visit_def_1141  1
    service_1_33_6  free_load_conservation_1142  -2
    service_1_33_6  original_T_including_depot_unload_1158  240
    service_1_33_7  unique_nonzero_owner_334  1
    service_1_33_7  service_visit_def_1141  1
    service_1_33_7  free_load_conservation_1142  -1
    service_1_33_7  original_T_including_depot_unload_1158  120
    service_1_33_9  unique_nonzero_owner_335  1
    service_1_33_9  service_visit_def_1141  1
    service_1_33_9  free_load_conservation_1142  1
    service_1_33_10  unique_nonzero_owner_336  1
    service_1_33_10  service_visit_def_1141  1
    service_1_33_10  free_load_conservation_1142  2
    service_1_33_11  unique_nonzero_owner_337  1
    service_1_33_11  service_visit_def_1141  1
    service_1_33_11  free_load_conservation_1142  3
    service_2_33_0  unique_nonzero_owner_327  1
    service_2_33_0  service_visit_def_1459  1
    service_2_33_0  free_load_conservation_1460  -8
    service_2_33_0  original_T_including_depot_unload_1475  960
    service_2_33_1  unique_nonzero_owner_328  1
    service_2_33_1  service_visit_def_1459  1
    service_2_33_1  free_load_conservation_1460  -7
    service_2_33_1  original_T_including_depot_unload_1475  840
    service_2_33_2  unique_nonzero_owner_329  1
    service_2_33_2  service_visit_def_1459  1
    service_2_33_2  free_load_conservation_1460  -6
    service_2_33_2  original_T_including_depot_unload_1475  720
    service_2_33_3  unique_nonzero_owner_330  1
    service_2_33_3  service_visit_def_1459  1
    service_2_33_3  free_load_conservation_1460  -5
    service_2_33_3  original_T_including_depot_unload_1475  600
    service_2_33_4  unique_nonzero_owner_331  1
    service_2_33_4  service_visit_def_1459  1
    service_2_33_4  free_load_conservation_1460  -4
    service_2_33_4  original_T_including_depot_unload_1475  480
    service_2_33_5  unique_nonzero_owner_332  1
    service_2_33_5  service_visit_def_1459  1
    service_2_33_5  free_load_conservation_1460  -3
    service_2_33_5  original_T_including_depot_unload_1475  360
    service_2_33_6  unique_nonzero_owner_333  1
    service_2_33_6  service_visit_def_1459  1
    service_2_33_6  free_load_conservation_1460  -2
    service_2_33_6  original_T_including_depot_unload_1475  240
    service_2_33_7  unique_nonzero_owner_334  1
    service_2_33_7  service_visit_def_1459  1
    service_2_33_7  free_load_conservation_1460  -1
    service_2_33_7  original_T_including_depot_unload_1475  120
    service_2_33_9  unique_nonzero_owner_335  1
    service_2_33_9  service_visit_def_1459  1
    service_2_33_9  free_load_conservation_1460  1
    service_2_33_10  unique_nonzero_owner_336  1
    service_2_33_10  service_visit_def_1459  1
    service_2_33_10  free_load_conservation_1460  2
    service_2_33_11  unique_nonzero_owner_337  1
    service_2_33_11  service_visit_def_1459  1
    service_2_33_11  free_load_conservation_1460  3
    service_0_27_1  unique_nonzero_owner_338  1
    service_0_27_1  service_visit_def_775  1
    service_0_27_1  free_load_conservation_776  1
    service_0_27_2  unique_nonzero_owner_339  1
    service_0_27_2  service_visit_def_775  1
    service_0_27_2  free_load_conservation_776  2
    service_0_27_3  unique_nonzero_owner_340  1
    service_0_27_3  service_visit_def_775  1
    service_0_27_3  free_load_conservation_776  3
    service_0_27_4  unique_nonzero_owner_341  1
    service_0_27_4  service_visit_def_775  1
    service_0_27_4  free_load_conservation_776  4
    service_0_27_5  unique_nonzero_owner_342  1
    service_0_27_5  service_visit_def_775  1
    service_0_27_5  free_load_conservation_776  5
    service_0_27_6  unique_nonzero_owner_343  1
    service_0_27_6  service_visit_def_775  1
    service_0_27_6  free_load_conservation_776  6
    service_1_27_1  unique_nonzero_owner_338  1
    service_1_27_1  service_visit_def_1147  1
    service_1_27_1  free_load_conservation_1148  1
    service_1_27_2  unique_nonzero_owner_339  1
    service_1_27_2  service_visit_def_1147  1
    service_1_27_2  free_load_conservation_1148  2
    service_1_27_3  unique_nonzero_owner_340  1
    service_1_27_3  service_visit_def_1147  1
    service_1_27_3  free_load_conservation_1148  3
    service_1_27_4  unique_nonzero_owner_341  1
    service_1_27_4  service_visit_def_1147  1
    service_1_27_4  free_load_conservation_1148  4
    service_1_27_5  unique_nonzero_owner_342  1
    service_1_27_5  service_visit_def_1147  1
    service_1_27_5  free_load_conservation_1148  5
    service_1_27_6  unique_nonzero_owner_343  1
    service_1_27_6  service_visit_def_1147  1
    service_1_27_6  free_load_conservation_1148  6
    service_2_27_1  unique_nonzero_owner_338  1
    service_2_27_1  service_visit_def_1465  1
    service_2_27_1  free_load_conservation_1466  1
    service_2_27_2  unique_nonzero_owner_339  1
    service_2_27_2  service_visit_def_1465  1
    service_2_27_2  free_load_conservation_1466  2
    service_2_27_3  unique_nonzero_owner_340  1
    service_2_27_3  service_visit_def_1465  1
    service_2_27_3  free_load_conservation_1466  3
    service_2_27_4  unique_nonzero_owner_341  1
    service_2_27_4  service_visit_def_1465  1
    service_2_27_4  free_load_conservation_1466  4
    service_2_27_5  unique_nonzero_owner_342  1
    service_2_27_5  service_visit_def_1465  1
    service_2_27_5  free_load_conservation_1466  5
    service_2_27_6  unique_nonzero_owner_343  1
    service_2_27_6  service_visit_def_1465  1
    service_2_27_6  free_load_conservation_1466  6
    service_0_35_0  unique_nonzero_owner_344  1
    service_0_35_0  service_visit_def_781  1
    service_0_35_0  free_load_conservation_782  -3
    service_0_35_0  original_T_including_depot_unload_787  360
    service_0_35_1  unique_nonzero_owner_345  1
    service_0_35_1  service_visit_def_781  1
    service_0_35_1  free_load_conservation_782  -2
    service_0_35_1  original_T_including_depot_unload_787  240
    service_0_35_2  unique_nonzero_owner_346  1
    service_0_35_2  service_visit_def_781  1
    service_0_35_2  free_load_conservation_782  -1
    service_0_35_2  original_T_including_depot_unload_787  120
    service_0_35_4  unique_nonzero_owner_347  1
    service_0_35_4  service_visit_def_781  1
    service_0_35_4  free_load_conservation_782  1
    service_0_35_5  unique_nonzero_owner_348  1
    service_0_35_5  service_visit_def_781  1
    service_0_35_5  free_load_conservation_782  2
    service_0_35_6  unique_nonzero_owner_349  1
    service_0_35_6  service_visit_def_781  1
    service_0_35_6  free_load_conservation_782  3
    service_0_35_7  unique_nonzero_owner_350  1
    service_0_35_7  service_visit_def_781  1
    service_0_35_7  free_load_conservation_782  4
    service_0_35_8  unique_nonzero_owner_351  1
    service_0_35_8  service_visit_def_781  1
    service_0_35_8  free_load_conservation_782  5
    service_0_35_9  unique_nonzero_owner_352  1
    service_0_35_9  service_visit_def_781  1
    service_0_35_9  free_load_conservation_782  6
    service_0_35_10  unique_nonzero_owner_353  1
    service_0_35_10  service_visit_def_781  1
    service_0_35_10  free_load_conservation_782  7
    service_0_35_11  unique_nonzero_owner_354  1
    service_0_35_11  service_visit_def_781  1
    service_0_35_11  free_load_conservation_782  8
    service_0_35_12  unique_nonzero_owner_355  1
    service_0_35_12  service_visit_def_781  1
    service_0_35_12  free_load_conservation_782  9
    service_0_35_13  unique_nonzero_owner_356  1
    service_0_35_13  service_visit_def_781  1
    service_0_35_13  free_load_conservation_782  10
    service_0_35_14  unique_nonzero_owner_357  1
    service_0_35_14  service_visit_def_781  1
    service_0_35_14  free_load_conservation_782  11
    service_0_35_15  unique_nonzero_owner_358  1
    service_0_35_15  service_visit_def_781  1
    service_0_35_15  free_load_conservation_782  12
    service_1_35_0  unique_nonzero_owner_344  1
    service_1_35_0  service_visit_def_1153  1
    service_1_35_0  free_load_conservation_1154  -3
    service_1_35_0  original_T_including_depot_unload_1158  360
    service_1_35_1  unique_nonzero_owner_345  1
    service_1_35_1  service_visit_def_1153  1
    service_1_35_1  free_load_conservation_1154  -2
    service_1_35_1  original_T_including_depot_unload_1158  240
    service_1_35_2  unique_nonzero_owner_346  1
    service_1_35_2  service_visit_def_1153  1
    service_1_35_2  free_load_conservation_1154  -1
    service_1_35_2  original_T_including_depot_unload_1158  120
    service_1_35_4  unique_nonzero_owner_347  1
    service_1_35_4  service_visit_def_1153  1
    service_1_35_4  free_load_conservation_1154  1
    service_1_35_5  unique_nonzero_owner_348  1
    service_1_35_5  service_visit_def_1153  1
    service_1_35_5  free_load_conservation_1154  2
    service_1_35_6  unique_nonzero_owner_349  1
    service_1_35_6  service_visit_def_1153  1
    service_1_35_6  free_load_conservation_1154  3
    service_1_35_7  unique_nonzero_owner_350  1
    service_1_35_7  service_visit_def_1153  1
    service_1_35_7  free_load_conservation_1154  4
    service_1_35_8  unique_nonzero_owner_351  1
    service_1_35_8  service_visit_def_1153  1
    service_1_35_8  free_load_conservation_1154  5
    service_1_35_9  unique_nonzero_owner_352  1
    service_1_35_9  service_visit_def_1153  1
    service_1_35_9  free_load_conservation_1154  6
    service_1_35_10  unique_nonzero_owner_353  1
    service_1_35_10  service_visit_def_1153  1
    service_1_35_10  free_load_conservation_1154  7
    service_1_35_11  unique_nonzero_owner_354  1
    service_1_35_11  service_visit_def_1153  1
    service_1_35_11  free_load_conservation_1154  8
    service_1_35_12  unique_nonzero_owner_355  1
    service_1_35_12  service_visit_def_1153  1
    service_1_35_12  free_load_conservation_1154  9
    service_1_35_13  unique_nonzero_owner_356  1
    service_1_35_13  service_visit_def_1153  1
    service_1_35_13  free_load_conservation_1154  10
    service_1_35_14  unique_nonzero_owner_357  1
    service_1_35_14  service_visit_def_1153  1
    service_1_35_14  free_load_conservation_1154  11
    service_1_35_15  unique_nonzero_owner_358  1
    service_1_35_15  service_visit_def_1153  1
    service_1_35_15  free_load_conservation_1154  12
    service_2_35_0  unique_nonzero_owner_344  1
    service_2_35_0  service_visit_def_1471  1
    service_2_35_0  free_load_conservation_1472  -3
    service_2_35_0  original_T_including_depot_unload_1475  360
    service_2_35_1  unique_nonzero_owner_345  1
    service_2_35_1  service_visit_def_1471  1
    service_2_35_1  free_load_conservation_1472  -2
    service_2_35_1  original_T_including_depot_unload_1475  240
    service_2_35_2  unique_nonzero_owner_346  1
    service_2_35_2  service_visit_def_1471  1
    service_2_35_2  free_load_conservation_1472  -1
    service_2_35_2  original_T_including_depot_unload_1475  120
    service_2_35_4  unique_nonzero_owner_347  1
    service_2_35_4  service_visit_def_1471  1
    service_2_35_4  free_load_conservation_1472  1
    service_2_35_5  unique_nonzero_owner_348  1
    service_2_35_5  service_visit_def_1471  1
    service_2_35_5  free_load_conservation_1472  2
    service_2_35_6  unique_nonzero_owner_349  1
    service_2_35_6  service_visit_def_1471  1
    service_2_35_6  free_load_conservation_1472  3
    service_2_35_7  unique_nonzero_owner_350  1
    service_2_35_7  service_visit_def_1471  1
    service_2_35_7  free_load_conservation_1472  4
    service_2_35_8  unique_nonzero_owner_351  1
    service_2_35_8  service_visit_def_1471  1
    service_2_35_8  free_load_conservation_1472  5
    service_2_35_9  unique_nonzero_owner_352  1
    service_2_35_9  service_visit_def_1471  1
    service_2_35_9  free_load_conservation_1472  6
    service_2_35_10  unique_nonzero_owner_353  1
    service_2_35_10  service_visit_def_1471  1
    service_2_35_10  free_load_conservation_1472  7
    service_2_35_11  unique_nonzero_owner_354  1
    service_2_35_11  service_visit_def_1471  1
    service_2_35_11  free_load_conservation_1472  8
    service_2_35_12  unique_nonzero_owner_355  1
    service_2_35_12  service_visit_def_1471  1
    service_2_35_12  free_load_conservation_1472  9
    service_2_35_13  unique_nonzero_owner_356  1
    service_2_35_13  service_visit_def_1471  1
    service_2_35_13  free_load_conservation_1472  10
    service_2_35_14  unique_nonzero_owner_357  1
    service_2_35_14  service_visit_def_1471  1
    service_2_35_14  free_load_conservation_1472  11
    service_2_35_15  unique_nonzero_owner_358  1
    service_2_35_15  service_visit_def_1471  1
    service_2_35_15  free_load_conservation_1472  12
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_700  -1
    visit_0_1  in_degree_701  -1
    visit_0_1  order_active_lb_702  -1
    visit_0_1  order_active_ub_703  -13
    order_0_1  connected_order_arc_375  -1
    order_0_1  connected_order_arc_377  -1
    order_0_1  connected_order_arc_379  -1
    order_0_1  connected_order_arc_381  -1
    order_0_1  connected_order_arc_383  -1
    order_0_1  connected_order_arc_385  -1
    order_0_1  connected_order_arc_387  -1
    order_0_1  connected_order_arc_389  -1
    order_0_1  connected_order_arc_391  -1
    order_0_1  connected_order_arc_393  -1
    order_0_1  connected_order_arc_395  -1
    order_0_1  connected_order_arc_397  -1
    order_0_1  connected_order_arc_400  1
    order_0_1  connected_order_arc_425  1
    order_0_1  connected_order_arc_450  1
    order_0_1  connected_order_arc_475  1
    order_0_1  connected_order_arc_500  1
    order_0_1  connected_order_arc_525  1
    order_0_1  connected_order_arc_550  1
    order_0_1  connected_order_arc_575  1
    order_0_1  connected_order_arc_600  1
    order_0_1  connected_order_arc_625  1
    order_0_1  connected_order_arc_650  1
    order_0_1  connected_order_arc_675  1
    order_0_1  order_active_lb_702  1
    order_0_1  order_active_ub_703  1
    order_0_1  fixed_segment_relative_order_783  -1
    visit_0_2  out_degree_707  -1
    visit_0_2  in_degree_708  -1
    visit_0_2  order_active_lb_709  -1
    visit_0_2  order_active_ub_710  -13
    order_0_2  connected_order_arc_375  1
    order_0_2  connected_order_arc_400  -1
    order_0_2  connected_order_arc_402  -1
    order_0_2  connected_order_arc_404  -1
    order_0_2  connected_order_arc_406  -1
    order_0_2  connected_order_arc_408  -1
    order_0_2  connected_order_arc_410  -1
    order_0_2  connected_order_arc_412  -1
    order_0_2  connected_order_arc_414  -1
    order_0_2  connected_order_arc_416  -1
    order_0_2  connected_order_arc_418  -1
    order_0_2  connected_order_arc_420  -1
    order_0_2  connected_order_arc_422  -1
    order_0_2  connected_order_arc_427  1
    order_0_2  connected_order_arc_452  1
    order_0_2  connected_order_arc_477  1
    order_0_2  connected_order_arc_502  1
    order_0_2  connected_order_arc_527  1
    order_0_2  connected_order_arc_552  1
    order_0_2  connected_order_arc_577  1
    order_0_2  connected_order_arc_602  1
    order_0_2  connected_order_arc_627  1
    order_0_2  connected_order_arc_652  1
    order_0_2  connected_order_arc_677  1
    order_0_2  order_active_lb_709  1
    order_0_2  order_active_ub_710  1
    order_0_2  fixed_segment_relative_order_783  1
    order_0_2  fixed_segment_relative_order_784  -1
    visit_0_3  out_degree_714  -1
    visit_0_3  in_degree_715  -1
    visit_0_3  order_active_lb_716  -1
    visit_0_3  order_active_ub_717  -13
    order_0_3  connected_order_arc_377  1
    order_0_3  connected_order_arc_402  1
    order_0_3  connected_order_arc_425  -1
    order_0_3  connected_order_arc_427  -1
    order_0_3  connected_order_arc_429  -1
    order_0_3  connected_order_arc_431  -1
    order_0_3  connected_order_arc_433  -1
    order_0_3  connected_order_arc_435  -1
    order_0_3  connected_order_arc_437  -1
    order_0_3  connected_order_arc_439  -1
    order_0_3  connected_order_arc_441  -1
    order_0_3  connected_order_arc_443  -1
    order_0_3  connected_order_arc_445  -1
    order_0_3  connected_order_arc_447  -1
    order_0_3  connected_order_arc_454  1
    order_0_3  connected_order_arc_479  1
    order_0_3  connected_order_arc_504  1
    order_0_3  connected_order_arc_529  1
    order_0_3  connected_order_arc_554  1
    order_0_3  connected_order_arc_579  1
    order_0_3  connected_order_arc_604  1
    order_0_3  connected_order_arc_629  1
    order_0_3  connected_order_arc_654  1
    order_0_3  connected_order_arc_679  1
    order_0_3  order_active_lb_716  1
    order_0_3  order_active_ub_717  1
    order_0_3  fixed_segment_relative_order_784  1
    order_0_3  fixed_segment_relative_order_785  -1
    visit_0_4  out_degree_721  -1
    visit_0_4  in_degree_722  -1
    visit_0_4  order_active_lb_723  -1
    visit_0_4  order_active_ub_724  -13
    order_0_4  connected_order_arc_379  1
    order_0_4  connected_order_arc_404  1
    order_0_4  connected_order_arc_429  1
    order_0_4  connected_order_arc_450  -1
    order_0_4  connected_order_arc_452  -1
    order_0_4  connected_order_arc_454  -1
    order_0_4  connected_order_arc_456  -1
    order_0_4  connected_order_arc_458  -1
    order_0_4  connected_order_arc_460  -1
    order_0_4  connected_order_arc_462  -1
    order_0_4  connected_order_arc_464  -1
    order_0_4  connected_order_arc_466  -1
    order_0_4  connected_order_arc_468  -1
    order_0_4  connected_order_arc_470  -1
    order_0_4  connected_order_arc_472  -1
    order_0_4  connected_order_arc_481  1
    order_0_4  connected_order_arc_506  1
    order_0_4  connected_order_arc_531  1
    order_0_4  connected_order_arc_556  1
    order_0_4  connected_order_arc_581  1
    order_0_4  connected_order_arc_606  1
    order_0_4  connected_order_arc_631  1
    order_0_4  connected_order_arc_656  1
    order_0_4  connected_order_arc_681  1
    order_0_4  order_active_lb_723  1
    order_0_4  order_active_ub_724  1
    order_0_4  fixed_segment_relative_order_785  1
    order_0_4  fixed_segment_relative_order_786  -1
    visit_0_5  out_degree_728  -1
    visit_0_5  in_degree_729  -1
    visit_0_5  order_active_lb_730  -1
    visit_0_5  order_active_ub_731  -13
    order_0_5  connected_order_arc_381  1
    order_0_5  connected_order_arc_406  1
    order_0_5  connected_order_arc_431  1
    order_0_5  connected_order_arc_456  1
    order_0_5  connected_order_arc_475  -1
    order_0_5  connected_order_arc_477  -1
    order_0_5  connected_order_arc_479  -1
    order_0_5  connected_order_arc_481  -1
    order_0_5  connected_order_arc_483  -1
    order_0_5  connected_order_arc_485  -1
    order_0_5  connected_order_arc_487  -1
    order_0_5  connected_order_arc_489  -1
    order_0_5  connected_order_arc_491  -1
    order_0_5  connected_order_arc_493  -1
    order_0_5  connected_order_arc_495  -1
    order_0_5  connected_order_arc_497  -1
    order_0_5  connected_order_arc_508  1
    order_0_5  connected_order_arc_533  1
    order_0_5  connected_order_arc_558  1
    order_0_5  connected_order_arc_583  1
    order_0_5  connected_order_arc_608  1
    order_0_5  connected_order_arc_633  1
    order_0_5  connected_order_arc_658  1
    order_0_5  connected_order_arc_683  1
    order_0_5  order_active_lb_730  1
    order_0_5  order_active_ub_731  1
    order_0_5  fixed_segment_relative_order_786  1
    visit_0_13  out_degree_735  -1
    visit_0_13  in_degree_736  -1
    visit_0_13  order_active_lb_737  -1
    visit_0_13  order_active_ub_738  -13
    visit_0_13  service_visit_def_739  -1
    order_0_13  connected_order_arc_383  1
    order_0_13  connected_order_arc_408  1
    order_0_13  connected_order_arc_433  1
    order_0_13  connected_order_arc_458  1
    order_0_13  connected_order_arc_483  1
    order_0_13  connected_order_arc_500  -1
    order_0_13  connected_order_arc_502  -1
    order_0_13  connected_order_arc_504  -1
    order_0_13  connected_order_arc_506  -1
    order_0_13  connected_order_arc_508  -1
    order_0_13  connected_order_arc_510  -1
    order_0_13  connected_order_arc_512  -1
    order_0_13  connected_order_arc_514  -1
    order_0_13  connected_order_arc_516  -1
    order_0_13  connected_order_arc_518  -1
    order_0_13  connected_order_arc_520  -1
    order_0_13  connected_order_arc_522  -1
    order_0_13  connected_order_arc_535  1
    order_0_13  connected_order_arc_560  1
    order_0_13  connected_order_arc_585  1
    order_0_13  connected_order_arc_610  1
    order_0_13  connected_order_arc_635  1
    order_0_13  connected_order_arc_660  1
    order_0_13  connected_order_arc_685  1
    order_0_13  order_active_lb_737  1
    order_0_13  order_active_ub_738  1
    visit_0_14  out_degree_741  -1
    visit_0_14  in_degree_742  -1
    visit_0_14  order_active_lb_743  -1
    visit_0_14  order_active_ub_744  -13
    visit_0_14  service_visit_def_745  -1
    order_0_14  connected_order_arc_385  1
    order_0_14  connected_order_arc_410  1
    order_0_14  connected_order_arc_435  1
    order_0_14  connected_order_arc_460  1
    order_0_14  connected_order_arc_485  1
    order_0_14  connected_order_arc_510  1
    order_0_14  connected_order_arc_525  -1
    order_0_14  connected_order_arc_527  -1
    order_0_14  connected_order_arc_529  -1
    order_0_14  connected_order_arc_531  -1
    order_0_14  connected_order_arc_533  -1
    order_0_14  connected_order_arc_535  -1
    order_0_14  connected_order_arc_537  -1
    order_0_14  connected_order_arc_539  -1
    order_0_14  connected_order_arc_541  -1
    order_0_14  connected_order_arc_543  -1
    order_0_14  connected_order_arc_545  -1
    order_0_14  connected_order_arc_547  -1
    order_0_14  connected_order_arc_562  1
    order_0_14  connected_order_arc_587  1
    order_0_14  connected_order_arc_612  1
    order_0_14  connected_order_arc_637  1
    order_0_14  connected_order_arc_662  1
    order_0_14  connected_order_arc_687  1
    order_0_14  order_active_lb_743  1
    order_0_14  order_active_ub_744  1
    visit_0_15  out_degree_747  -1
    visit_0_15  in_degree_748  -1
    visit_0_15  order_active_lb_749  -1
    visit_0_15  order_active_ub_750  -13
    visit_0_15  service_visit_def_751  -1
    order_0_15  connected_order_arc_387  1
    order_0_15  connected_order_arc_412  1
    order_0_15  connected_order_arc_437  1
    order_0_15  connected_order_arc_462  1
    order_0_15  connected_order_arc_487  1
    order_0_15  connected_order_arc_512  1
    order_0_15  connected_order_arc_537  1
    order_0_15  connected_order_arc_550  -1
    order_0_15  connected_order_arc_552  -1
    order_0_15  connected_order_arc_554  -1
    order_0_15  connected_order_arc_556  -1
    order_0_15  connected_order_arc_558  -1
    order_0_15  connected_order_arc_560  -1
    order_0_15  connected_order_arc_562  -1
    order_0_15  connected_order_arc_564  -1
    order_0_15  connected_order_arc_566  -1
    order_0_15  connected_order_arc_568  -1
    order_0_15  connected_order_arc_570  -1
    order_0_15  connected_order_arc_572  -1
    order_0_15  connected_order_arc_589  1
    order_0_15  connected_order_arc_614  1
    order_0_15  connected_order_arc_639  1
    order_0_15  connected_order_arc_664  1
    order_0_15  connected_order_arc_689  1
    order_0_15  order_active_lb_749  1
    order_0_15  order_active_ub_750  1
    visit_0_16  out_degree_753  -1
    visit_0_16  in_degree_754  -1
    visit_0_16  order_active_lb_755  -1
    visit_0_16  order_active_ub_756  -13
    visit_0_16  service_visit_def_757  -1
    order_0_16  connected_order_arc_389  1
    order_0_16  connected_order_arc_414  1
    order_0_16  connected_order_arc_439  1
    order_0_16  connected_order_arc_464  1
    order_0_16  connected_order_arc_489  1
    order_0_16  connected_order_arc_514  1
    order_0_16  connected_order_arc_539  1
    order_0_16  connected_order_arc_564  1
    order_0_16  connected_order_arc_575  -1
    order_0_16  connected_order_arc_577  -1
    order_0_16  connected_order_arc_579  -1
    order_0_16  connected_order_arc_581  -1
    order_0_16  connected_order_arc_583  -1
    order_0_16  connected_order_arc_585  -1
    order_0_16  connected_order_arc_587  -1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_591  -1
    order_0_16  connected_order_arc_593  -1
    order_0_16  connected_order_arc_595  -1
    order_0_16  connected_order_arc_597  -1
    order_0_16  connected_order_arc_616  1
    order_0_16  connected_order_arc_641  1
    order_0_16  connected_order_arc_666  1
    order_0_16  connected_order_arc_691  1
    order_0_16  order_active_lb_755  1
    order_0_16  order_active_ub_756  1
    visit_0_17  out_degree_759  -1
    visit_0_17  in_degree_760  -1
    visit_0_17  order_active_lb_761  -1
    visit_0_17  order_active_ub_762  -13
    visit_0_17  service_visit_def_763  -1
    order_0_17  connected_order_arc_391  1
    order_0_17  connected_order_arc_416  1
    order_0_17  connected_order_arc_441  1
    order_0_17  connected_order_arc_466  1
    order_0_17  connected_order_arc_491  1
    order_0_17  connected_order_arc_516  1
    order_0_17  connected_order_arc_541  1
    order_0_17  connected_order_arc_566  1
    order_0_17  connected_order_arc_591  1
    order_0_17  connected_order_arc_600  -1
    order_0_17  connected_order_arc_602  -1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_606  -1
    order_0_17  connected_order_arc_608  -1
    order_0_17  connected_order_arc_610  -1
    order_0_17  connected_order_arc_612  -1
    order_0_17  connected_order_arc_614  -1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_618  -1
    order_0_17  connected_order_arc_620  -1
    order_0_17  connected_order_arc_622  -1
    order_0_17  connected_order_arc_643  1
    order_0_17  connected_order_arc_668  1
    order_0_17  connected_order_arc_693  1
    order_0_17  order_active_lb_761  1
    order_0_17  order_active_ub_762  1
    visit_0_18  out_degree_765  -1
    visit_0_18  in_degree_766  -1
    visit_0_18  order_active_lb_767  -1
    visit_0_18  order_active_ub_768  -13
    visit_0_18  service_visit_def_769  -1
    order_0_18  connected_order_arc_393  1
    order_0_18  connected_order_arc_418  1
    order_0_18  connected_order_arc_443  1
    order_0_18  connected_order_arc_468  1
    order_0_18  connected_order_arc_493  1
    order_0_18  connected_order_arc_518  1
    order_0_18  connected_order_arc_543  1
    order_0_18  connected_order_arc_568  1
    order_0_18  connected_order_arc_593  1
    order_0_18  connected_order_arc_618  1
    order_0_18  connected_order_arc_625  -1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_633  -1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_637  -1
    order_0_18  connected_order_arc_639  -1
    order_0_18  connected_order_arc_641  -1
    order_0_18  connected_order_arc_643  -1
    order_0_18  connected_order_arc_645  -1
    order_0_18  connected_order_arc_647  -1
    order_0_18  connected_order_arc_670  1
    order_0_18  connected_order_arc_695  1
    order_0_18  order_active_lb_767  1
    order_0_18  order_active_ub_768  1
    visit_0_19  out_degree_771  -1
    visit_0_19  in_degree_772  -1
    visit_0_19  order_active_lb_773  -1
    visit_0_19  order_active_ub_774  -13
    visit_0_19  service_visit_def_775  -1
    order_0_19  connected_order_arc_395  1
    order_0_19  connected_order_arc_420  1
    order_0_19  connected_order_arc_445  1
    order_0_19  connected_order_arc_470  1
    order_0_19  connected_order_arc_495  1
    order_0_19  connected_order_arc_520  1
    order_0_19  connected_order_arc_545  1
    order_0_19  connected_order_arc_570  1
    order_0_19  connected_order_arc_595  1
    order_0_19  connected_order_arc_620  1
    order_0_19  connected_order_arc_645  1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_662  -1
    order_0_19  connected_order_arc_664  -1
    order_0_19  connected_order_arc_666  -1
    order_0_19  connected_order_arc_668  -1
    order_0_19  connected_order_arc_670  -1
    order_0_19  connected_order_arc_672  -1
    order_0_19  connected_order_arc_697  1
    order_0_19  order_active_lb_773  1
    order_0_19  order_active_ub_774  1
    visit_0_20  out_degree_777  -1
    visit_0_20  in_degree_778  -1
    visit_0_20  order_active_lb_779  -1
    visit_0_20  order_active_ub_780  -13
    visit_0_20  service_visit_def_781  -1
    order_0_20  connected_order_arc_397  1
    order_0_20  connected_order_arc_422  1
    order_0_20  connected_order_arc_447  1
    order_0_20  connected_order_arc_472  1
    order_0_20  connected_order_arc_497  1
    order_0_20  connected_order_arc_522  1
    order_0_20  connected_order_arc_547  1
    order_0_20  connected_order_arc_572  1
    order_0_20  connected_order_arc_597  1
    order_0_20  connected_order_arc_622  1
    order_0_20  connected_order_arc_647  1
    order_0_20  connected_order_arc_672  1
    order_0_20  connected_order_arc_675  -1
    order_0_20  connected_order_arc_677  -1
    order_0_20  connected_order_arc_679  -1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  connected_order_arc_687  -1
    order_0_20  connected_order_arc_689  -1
    order_0_20  connected_order_arc_691  -1
    order_0_20  connected_order_arc_693  -1
    order_0_20  connected_order_arc_695  -1
    order_0_20  connected_order_arc_697  -1
    order_0_20  order_active_lb_779  1
    order_0_20  order_active_ub_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_359  -20
    arc_0_0_0  depot_departure_or_bypass_698  1
    arc_0_0_0  depot_return_or_bypass_699  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_359  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_360  -20
    arc_0_0_1  depot_departure_or_bypass_698  1
    arc_0_0_1  in_degree_701  1
    arc_0_0_1  original_T_including_depot_unload_787  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_360  1
    load_0_0_1  segment_load_conservation_704  -1
    load_0_0_1  segment_prefix_lb_705  1
    load_0_0_1  segment_prefix_ub_706  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_361  -20
    arc_0_0_2  depot_departure_or_bypass_698  1
    arc_0_0_2  in_degree_708  1
    arc_0_0_2  original_T_including_depot_unload_787  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_361  1
    load_0_0_2  segment_load_conservation_711  -1
    load_0_0_2  segment_prefix_lb_712  1
    load_0_0_2  segment_prefix_ub_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_362  -20
    arc_0_0_3  depot_departure_or_bypass_698  1
    arc_0_0_3  in_degree_715  1
    arc_0_0_3  original_T_including_depot_unload_787  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_362  1
    load_0_0_3  segment_load_conservation_718  -1
    load_0_0_3  segment_prefix_lb_719  1
    load_0_0_3  segment_prefix_ub_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_363  -20
    arc_0_0_4  depot_departure_or_bypass_698  1
    arc_0_0_4  in_degree_722  1
    arc_0_0_4  original_T_including_depot_unload_787  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_363  1
    load_0_0_4  segment_load_conservation_725  -1
    load_0_0_4  segment_prefix_lb_726  1
    load_0_0_4  segment_prefix_ub_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_364  -20
    arc_0_0_5  depot_departure_or_bypass_698  1
    arc_0_0_5  in_degree_729  1
    arc_0_0_5  original_T_including_depot_unload_787  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_364  1
    load_0_0_5  segment_load_conservation_732  -1
    load_0_0_5  segment_prefix_lb_733  1
    load_0_0_5  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_365  -20
    arc_0_0_13  depot_departure_or_bypass_698  1
    arc_0_0_13  in_degree_736  1
    arc_0_0_13  original_T_including_depot_unload_787  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_365  1
    load_0_0_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_366  -20
    arc_0_0_14  depot_departure_or_bypass_698  1
    arc_0_0_14  in_degree_742  1
    arc_0_0_14  original_T_including_depot_unload_787  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_366  1
    load_0_0_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_367  -20
    arc_0_0_15  depot_departure_or_bypass_698  1
    arc_0_0_15  in_degree_748  1
    arc_0_0_15  original_T_including_depot_unload_787  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_367  1
    load_0_0_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_368  -20
    arc_0_0_16  depot_departure_or_bypass_698  1
    arc_0_0_16  in_degree_754  1
    arc_0_0_16  original_T_including_depot_unload_787  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_368  1
    load_0_0_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_369  -20
    arc_0_0_17  depot_departure_or_bypass_698  1
    arc_0_0_17  in_degree_760  1
    arc_0_0_17  original_T_including_depot_unload_787  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_369  1
    load_0_0_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_370  -20
    arc_0_0_18  depot_departure_or_bypass_698  1
    arc_0_0_18  in_degree_766  1
    arc_0_0_18  original_T_including_depot_unload_787  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_370  1
    load_0_0_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_371  -20
    arc_0_0_19  depot_departure_or_bypass_698  1
    arc_0_0_19  in_degree_772  1
    arc_0_0_19  original_T_including_depot_unload_787  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_371  1
    load_0_0_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_372  -20
    arc_0_0_20  depot_departure_or_bypass_698  1
    arc_0_0_20  in_degree_778  1
    arc_0_0_20  original_T_including_depot_unload_787  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_372  1
    load_0_0_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_373  -20
    arc_0_1_0  depot_return_or_bypass_699  1
    arc_0_1_0  out_degree_700  1
    arc_0_1_0  original_T_including_depot_unload_787  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_373  1
    load_0_1_0  segment_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_374  -20
    arc_0_1_2  connected_order_arc_375  -14
    arc_0_1_2  out_degree_700  1
    arc_0_1_2  in_degree_708  1
    arc_0_1_2  original_T_including_depot_unload_787  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_374  1
    load_0_1_2  segment_load_conservation_704  1
    load_0_1_2  segment_load_conservation_711  -1
    load_0_1_2  segment_prefix_lb_712  1
    load_0_1_2  segment_prefix_ub_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_376  -20
    arc_0_1_3  connected_order_arc_377  -14
    arc_0_1_3  out_degree_700  1
    arc_0_1_3  in_degree_715  1
    arc_0_1_3  original_T_including_depot_unload_787  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_376  1
    load_0_1_3  segment_load_conservation_704  1
    load_0_1_3  segment_load_conservation_718  -1
    load_0_1_3  segment_prefix_lb_719  1
    load_0_1_3  segment_prefix_ub_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_378  -20
    arc_0_1_4  connected_order_arc_379  -14
    arc_0_1_4  out_degree_700  1
    arc_0_1_4  in_degree_722  1
    arc_0_1_4  original_T_including_depot_unload_787  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_378  1
    load_0_1_4  segment_load_conservation_704  1
    load_0_1_4  segment_load_conservation_725  -1
    load_0_1_4  segment_prefix_lb_726  1
    load_0_1_4  segment_prefix_ub_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_380  -20
    arc_0_1_5  connected_order_arc_381  -14
    arc_0_1_5  out_degree_700  1
    arc_0_1_5  in_degree_729  1
    arc_0_1_5  original_T_including_depot_unload_787  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_380  1
    load_0_1_5  segment_load_conservation_704  1
    load_0_1_5  segment_load_conservation_732  -1
    load_0_1_5  segment_prefix_lb_733  1
    load_0_1_5  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_382  -20
    arc_0_1_13  connected_order_arc_383  -14
    arc_0_1_13  out_degree_700  1
    arc_0_1_13  in_degree_736  1
    arc_0_1_13  original_T_including_depot_unload_787  1.4285403548915413e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_382  1
    load_0_1_13  segment_load_conservation_704  1
    load_0_1_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_384  -20
    arc_0_1_14  connected_order_arc_385  -14
    arc_0_1_14  out_degree_700  1
    arc_0_1_14  in_degree_742  1
    arc_0_1_14  original_T_including_depot_unload_787  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_384  1
    load_0_1_14  segment_load_conservation_704  1
    load_0_1_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_386  -20
    arc_0_1_15  connected_order_arc_387  -14
    arc_0_1_15  out_degree_700  1
    arc_0_1_15  in_degree_748  1
    arc_0_1_15  original_T_including_depot_unload_787  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_386  1
    load_0_1_15  segment_load_conservation_704  1
    load_0_1_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_388  -20
    arc_0_1_16  connected_order_arc_389  -14
    arc_0_1_16  out_degree_700  1
    arc_0_1_16  in_degree_754  1
    arc_0_1_16  original_T_including_depot_unload_787  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_388  1
    load_0_1_16  segment_load_conservation_704  1
    load_0_1_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_390  -20
    arc_0_1_17  connected_order_arc_391  -14
    arc_0_1_17  out_degree_700  1
    arc_0_1_17  in_degree_760  1
    arc_0_1_17  original_T_including_depot_unload_787  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_390  1
    load_0_1_17  segment_load_conservation_704  1
    load_0_1_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_392  -20
    arc_0_1_18  connected_order_arc_393  -14
    arc_0_1_18  out_degree_700  1
    arc_0_1_18  in_degree_766  1
    arc_0_1_18  original_T_including_depot_unload_787  1.8746346603188274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_392  1
    load_0_1_18  segment_load_conservation_704  1
    load_0_1_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_394  -20
    arc_0_1_19  connected_order_arc_395  -14
    arc_0_1_19  out_degree_700  1
    arc_0_1_19  in_degree_772  1
    arc_0_1_19  original_T_including_depot_unload_787  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_394  1
    load_0_1_19  segment_load_conservation_704  1
    load_0_1_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_396  -20
    arc_0_1_20  connected_order_arc_397  -14
    arc_0_1_20  out_degree_700  1
    arc_0_1_20  in_degree_778  1
    arc_0_1_20  original_T_including_depot_unload_787  2.0332430776353604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_396  1
    load_0_1_20  segment_load_conservation_704  1
    load_0_1_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_398  -20
    arc_0_2_0  depot_return_or_bypass_699  1
    arc_0_2_0  out_degree_707  1
    arc_0_2_0  original_T_including_depot_unload_787  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_398  1
    load_0_2_0  segment_load_conservation_711  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_399  -20
    arc_0_2_1  connected_order_arc_400  -14
    arc_0_2_1  in_degree_701  1
    arc_0_2_1  out_degree_707  1
    arc_0_2_1  original_T_including_depot_unload_787  4.9445985110995662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_399  1
    load_0_2_1  segment_load_conservation_704  -1
    load_0_2_1  segment_prefix_lb_705  1
    load_0_2_1  segment_prefix_ub_706  1
    load_0_2_1  segment_load_conservation_711  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_401  -20
    arc_0_2_3  connected_order_arc_402  -14
    arc_0_2_3  out_degree_707  1
    arc_0_2_3  in_degree_715  1
    arc_0_2_3  original_T_including_depot_unload_787  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_401  1
    load_0_2_3  segment_load_conservation_711  1
    load_0_2_3  segment_load_conservation_718  -1
    load_0_2_3  segment_prefix_lb_719  1
    load_0_2_3  segment_prefix_ub_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_403  -20
    arc_0_2_4  connected_order_arc_404  -14
    arc_0_2_4  out_degree_707  1
    arc_0_2_4  in_degree_722  1
    arc_0_2_4  original_T_including_depot_unload_787  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_403  1
    load_0_2_4  segment_load_conservation_711  1
    load_0_2_4  segment_load_conservation_725  -1
    load_0_2_4  segment_prefix_lb_726  1
    load_0_2_4  segment_prefix_ub_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_405  -20
    arc_0_2_5  connected_order_arc_406  -14
    arc_0_2_5  out_degree_707  1
    arc_0_2_5  in_degree_729  1
    arc_0_2_5  original_T_including_depot_unload_787  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_405  1
    load_0_2_5  segment_load_conservation_711  1
    load_0_2_5  segment_load_conservation_732  -1
    load_0_2_5  segment_prefix_lb_733  1
    load_0_2_5  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_407  -20
    arc_0_2_13  connected_order_arc_408  -14
    arc_0_2_13  out_degree_707  1
    arc_0_2_13  in_degree_736  1
    arc_0_2_13  original_T_including_depot_unload_787  1.3220876423614575e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_407  1
    load_0_2_13  segment_load_conservation_711  1
    load_0_2_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_409  -20
    arc_0_2_14  connected_order_arc_410  -14
    arc_0_2_14  out_degree_707  1
    arc_0_2_14  in_degree_742  1
    arc_0_2_14  original_T_including_depot_unload_787  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_409  1
    load_0_2_14  segment_load_conservation_711  1
    load_0_2_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_411  -20
    arc_0_2_15  connected_order_arc_412  -14
    arc_0_2_15  out_degree_707  1
    arc_0_2_15  in_degree_748  1
    arc_0_2_15  original_T_including_depot_unload_787  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_411  1
    load_0_2_15  segment_load_conservation_711  1
    load_0_2_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_413  -20
    arc_0_2_16  connected_order_arc_414  -14
    arc_0_2_16  out_degree_707  1
    arc_0_2_16  in_degree_754  1
    arc_0_2_16  original_T_including_depot_unload_787  1.0464557570570403e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_413  1
    load_0_2_16  segment_load_conservation_711  1
    load_0_2_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_415  -20
    arc_0_2_17  connected_order_arc_416  -14
    arc_0_2_17  out_degree_707  1
    arc_0_2_17  in_degree_760  1
    arc_0_2_17  original_T_including_depot_unload_787  756.038676628532
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_415  1
    load_0_2_17  segment_load_conservation_711  1
    load_0_2_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_417  -20
    arc_0_2_18  connected_order_arc_418  -14
    arc_0_2_18  out_degree_707  1
    arc_0_2_18  in_degree_766  1
    arc_0_2_18  original_T_including_depot_unload_787  1.7472867782185979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_417  1
    load_0_2_18  segment_load_conservation_711  1
    load_0_2_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_419  -20
    arc_0_2_19  connected_order_arc_420  -14
    arc_0_2_19  out_degree_707  1
    arc_0_2_19  in_degree_772  1
    arc_0_2_19  original_T_including_depot_unload_787  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_419  1
    load_0_2_19  segment_load_conservation_711  1
    load_0_2_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_421  -20
    arc_0_2_20  connected_order_arc_422  -14
    arc_0_2_20  out_degree_707  1
    arc_0_2_20  in_degree_778  1
    arc_0_2_20  original_T_including_depot_unload_787  1.9275265073261364e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_421  1
    load_0_2_20  segment_load_conservation_711  1
    load_0_2_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_423  -20
    arc_0_3_0  depot_return_or_bypass_699  1
    arc_0_3_0  out_degree_714  1
    arc_0_3_0  original_T_including_depot_unload_787  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_423  1
    load_0_3_0  segment_load_conservation_718  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_424  -20
    arc_0_3_1  connected_order_arc_425  -14
    arc_0_3_1  in_degree_701  1
    arc_0_3_1  out_degree_714  1
    arc_0_3_1  original_T_including_depot_unload_787  4.9495118393852869e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_424  1
    load_0_3_1  segment_load_conservation_704  -1
    load_0_3_1  segment_prefix_lb_705  1
    load_0_3_1  segment_prefix_ub_706  1
    load_0_3_1  segment_load_conservation_718  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_426  -20
    arc_0_3_2  connected_order_arc_427  -14
    arc_0_3_2  in_degree_708  1
    arc_0_3_2  out_degree_714  1
    arc_0_3_2  original_T_including_depot_unload_787  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_426  1
    load_0_3_2  segment_load_conservation_711  -1
    load_0_3_2  segment_prefix_lb_712  1
    load_0_3_2  segment_prefix_ub_713  1
    load_0_3_2  segment_load_conservation_718  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_428  -20
    arc_0_3_4  connected_order_arc_429  -14
    arc_0_3_4  out_degree_714  1
    arc_0_3_4  in_degree_722  1
    arc_0_3_4  original_T_including_depot_unload_787  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_428  1
    load_0_3_4  segment_load_conservation_718  1
    load_0_3_4  segment_load_conservation_725  -1
    load_0_3_4  segment_prefix_lb_726  1
    load_0_3_4  segment_prefix_ub_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_430  -20
    arc_0_3_5  connected_order_arc_431  -14
    arc_0_3_5  out_degree_714  1
    arc_0_3_5  in_degree_729  1
    arc_0_3_5  original_T_including_depot_unload_787  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_430  1
    load_0_3_5  segment_load_conservation_718  1
    load_0_3_5  segment_load_conservation_732  -1
    load_0_3_5  segment_prefix_lb_733  1
    load_0_3_5  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_432  -20
    arc_0_3_13  connected_order_arc_433  -14
    arc_0_3_13  out_degree_714  1
    arc_0_3_13  in_degree_736  1
    arc_0_3_13  original_T_including_depot_unload_787  1.3208627731923268e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_432  1
    load_0_3_13  segment_load_conservation_718  1
    load_0_3_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_434  -20
    arc_0_3_14  connected_order_arc_435  -14
    arc_0_3_14  out_degree_714  1
    arc_0_3_14  in_degree_742  1
    arc_0_3_14  original_T_including_depot_unload_787  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_434  1
    load_0_3_14  segment_load_conservation_718  1
    load_0_3_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_436  -20
    arc_0_3_15  connected_order_arc_437  -14
    arc_0_3_15  out_degree_714  1
    arc_0_3_15  in_degree_748  1
    arc_0_3_15  original_T_including_depot_unload_787  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_436  1
    load_0_3_15  segment_load_conservation_718  1
    load_0_3_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_438  -20
    arc_0_3_16  connected_order_arc_439  -14
    arc_0_3_16  out_degree_714  1
    arc_0_3_16  in_degree_754  1
    arc_0_3_16  original_T_including_depot_unload_787  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_438  1
    load_0_3_16  segment_load_conservation_718  1
    load_0_3_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_440  -20
    arc_0_3_17  connected_order_arc_441  -14
    arc_0_3_17  out_degree_714  1
    arc_0_3_17  in_degree_760  1
    arc_0_3_17  original_T_including_depot_unload_787  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_440  1
    load_0_3_17  segment_load_conservation_718  1
    load_0_3_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_442  -20
    arc_0_3_18  connected_order_arc_443  -14
    arc_0_3_18  out_degree_714  1
    arc_0_3_18  in_degree_766  1
    arc_0_3_18  original_T_including_depot_unload_787  1.7460980574235175e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_442  1
    load_0_3_18  segment_load_conservation_718  1
    load_0_3_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_444  -20
    arc_0_3_19  connected_order_arc_445  -14
    arc_0_3_19  out_degree_714  1
    arc_0_3_19  in_degree_772  1
    arc_0_3_19  original_T_including_depot_unload_787  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_444  1
    load_0_3_19  segment_load_conservation_718  1
    load_0_3_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_446  -20
    arc_0_3_20  connected_order_arc_447  -14
    arc_0_3_20  out_degree_714  1
    arc_0_3_20  in_degree_778  1
    arc_0_3_20  original_T_including_depot_unload_787  1.9263039852699487e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_446  1
    load_0_3_20  segment_load_conservation_718  1
    load_0_3_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_448  -20
    arc_0_4_0  depot_return_or_bypass_699  1
    arc_0_4_0  out_degree_721  1
    arc_0_4_0  original_T_including_depot_unload_787  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_448  1
    load_0_4_0  segment_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_449  -20
    arc_0_4_1  connected_order_arc_450  -14
    arc_0_4_1  in_degree_701  1
    arc_0_4_1  out_degree_721  1
    arc_0_4_1  original_T_including_depot_unload_787  6.7806925965469873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_449  1
    load_0_4_1  segment_load_conservation_704  -1
    load_0_4_1  segment_prefix_lb_705  1
    load_0_4_1  segment_prefix_ub_706  1
    load_0_4_1  segment_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_451  -20
    arc_0_4_2  connected_order_arc_452  -14
    arc_0_4_2  in_degree_708  1
    arc_0_4_2  out_degree_721  1
    arc_0_4_2  original_T_including_depot_unload_787  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_451  1
    load_0_4_2  segment_load_conservation_711  -1
    load_0_4_2  segment_prefix_lb_712  1
    load_0_4_2  segment_prefix_ub_713  1
    load_0_4_2  segment_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_453  -20
    arc_0_4_3  connected_order_arc_454  -14
    arc_0_4_3  in_degree_715  1
    arc_0_4_3  out_degree_721  1
    arc_0_4_3  original_T_including_depot_unload_787  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_453  1
    load_0_4_3  segment_load_conservation_718  -1
    load_0_4_3  segment_prefix_lb_719  1
    load_0_4_3  segment_prefix_ub_720  1
    load_0_4_3  segment_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_455  -20
    arc_0_4_5  connected_order_arc_456  -14
    arc_0_4_5  out_degree_721  1
    arc_0_4_5  in_degree_729  1
    arc_0_4_5  original_T_including_depot_unload_787  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_455  1
    load_0_4_5  segment_load_conservation_725  1
    load_0_4_5  segment_load_conservation_732  -1
    load_0_4_5  segment_prefix_lb_733  1
    load_0_4_5  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_457  -20
    arc_0_4_13  connected_order_arc_458  -14
    arc_0_4_13  out_degree_721  1
    arc_0_4_13  in_degree_736  1
    arc_0_4_13  original_T_including_depot_unload_787  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_457  1
    load_0_4_13  segment_load_conservation_725  1
    load_0_4_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_459  -20
    arc_0_4_14  connected_order_arc_460  -14
    arc_0_4_14  out_degree_721  1
    arc_0_4_14  in_degree_742  1
    arc_0_4_14  original_T_including_depot_unload_787  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_459  1
    load_0_4_14  segment_load_conservation_725  1
    load_0_4_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_461  -20
    arc_0_4_15  connected_order_arc_462  -14
    arc_0_4_15  out_degree_721  1
    arc_0_4_15  in_degree_748  1
    arc_0_4_15  original_T_including_depot_unload_787  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_461  1
    load_0_4_15  segment_load_conservation_725  1
    load_0_4_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_463  -20
    arc_0_4_16  connected_order_arc_464  -14
    arc_0_4_16  out_degree_721  1
    arc_0_4_16  in_degree_754  1
    arc_0_4_16  original_T_including_depot_unload_787  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_463  1
    load_0_4_16  segment_load_conservation_725  1
    load_0_4_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_465  -20
    arc_0_4_17  connected_order_arc_466  -14
    arc_0_4_17  out_degree_721  1
    arc_0_4_17  in_degree_760  1
    arc_0_4_17  original_T_including_depot_unload_787  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_465  1
    load_0_4_17  segment_load_conservation_725  1
    load_0_4_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_467  -20
    arc_0_4_18  connected_order_arc_468  -14
    arc_0_4_18  out_degree_721  1
    arc_0_4_18  in_degree_766  1
    arc_0_4_18  original_T_including_depot_unload_787  1.5787929582117179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_467  1
    load_0_4_18  segment_load_conservation_725  1
    load_0_4_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_469  -20
    arc_0_4_19  connected_order_arc_470  -14
    arc_0_4_19  out_degree_721  1
    arc_0_4_19  in_degree_772  1
    arc_0_4_19  original_T_including_depot_unload_787  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_469  1
    load_0_4_19  segment_load_conservation_725  1
    load_0_4_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_471  -20
    arc_0_4_20  connected_order_arc_472  -14
    arc_0_4_20  out_degree_721  1
    arc_0_4_20  in_degree_778  1
    arc_0_4_20  original_T_including_depot_unload_787  1.7740294865208371e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_471  1
    load_0_4_20  segment_load_conservation_725  1
    load_0_4_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_473  -20
    arc_0_5_0  depot_return_or_bypass_699  1
    arc_0_5_0  out_degree_728  1
    arc_0_5_0  original_T_including_depot_unload_787  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_473  1
    load_0_5_0  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_474  -20
    arc_0_5_1  connected_order_arc_475  -14
    arc_0_5_1  in_degree_701  1
    arc_0_5_1  out_degree_728  1
    arc_0_5_1  original_T_including_depot_unload_787  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_474  1
    load_0_5_1  segment_load_conservation_704  -1
    load_0_5_1  segment_prefix_lb_705  1
    load_0_5_1  segment_prefix_ub_706  1
    load_0_5_1  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_476  -20
    arc_0_5_2  connected_order_arc_477  -14
    arc_0_5_2  in_degree_708  1
    arc_0_5_2  out_degree_728  1
    arc_0_5_2  original_T_including_depot_unload_787  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_476  1
    load_0_5_2  segment_load_conservation_711  -1
    load_0_5_2  segment_prefix_lb_712  1
    load_0_5_2  segment_prefix_ub_713  1
    load_0_5_2  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_478  -20
    arc_0_5_3  connected_order_arc_479  -14
    arc_0_5_3  in_degree_715  1
    arc_0_5_3  out_degree_728  1
    arc_0_5_3  original_T_including_depot_unload_787  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_478  1
    load_0_5_3  segment_load_conservation_718  -1
    load_0_5_3  segment_prefix_lb_719  1
    load_0_5_3  segment_prefix_ub_720  1
    load_0_5_3  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_480  -20
    arc_0_5_4  connected_order_arc_481  -14
    arc_0_5_4  in_degree_722  1
    arc_0_5_4  out_degree_728  1
    arc_0_5_4  original_T_including_depot_unload_787  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_480  1
    load_0_5_4  segment_load_conservation_725  -1
    load_0_5_4  segment_prefix_lb_726  1
    load_0_5_4  segment_prefix_ub_727  1
    load_0_5_4  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_482  -20
    arc_0_5_13  connected_order_arc_483  -14
    arc_0_5_13  out_degree_728  1
    arc_0_5_13  in_degree_736  1
    arc_0_5_13  original_T_including_depot_unload_787  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_482  1
    load_0_5_13  segment_load_conservation_732  1
    load_0_5_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_484  -20
    arc_0_5_14  connected_order_arc_485  -14
    arc_0_5_14  out_degree_728  1
    arc_0_5_14  in_degree_742  1
    arc_0_5_14  original_T_including_depot_unload_787  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_484  1
    load_0_5_14  segment_load_conservation_732  1
    load_0_5_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_486  -20
    arc_0_5_15  connected_order_arc_487  -14
    arc_0_5_15  out_degree_728  1
    arc_0_5_15  in_degree_748  1
    arc_0_5_15  original_T_including_depot_unload_787  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_486  1
    load_0_5_15  segment_load_conservation_732  1
    load_0_5_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_488  -20
    arc_0_5_16  connected_order_arc_489  -14
    arc_0_5_16  out_degree_728  1
    arc_0_5_16  in_degree_754  1
    arc_0_5_16  original_T_including_depot_unload_787  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_488  1
    load_0_5_16  segment_load_conservation_732  1
    load_0_5_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_490  -20
    arc_0_5_17  connected_order_arc_491  -14
    arc_0_5_17  out_degree_728  1
    arc_0_5_17  in_degree_760  1
    arc_0_5_17  original_T_including_depot_unload_787  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_490  1
    load_0_5_17  segment_load_conservation_732  1
    load_0_5_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_492  -20
    arc_0_5_18  connected_order_arc_493  -14
    arc_0_5_18  out_degree_728  1
    arc_0_5_18  in_degree_766  1
    arc_0_5_18  original_T_including_depot_unload_787  1.4823747651994408e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_492  1
    load_0_5_18  segment_load_conservation_732  1
    load_0_5_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_494  -20
    arc_0_5_19  connected_order_arc_495  -14
    arc_0_5_19  out_degree_728  1
    arc_0_5_19  in_degree_772  1
    arc_0_5_19  original_T_including_depot_unload_787  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_494  1
    load_0_5_19  segment_load_conservation_732  1
    load_0_5_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_496  -20
    arc_0_5_20  connected_order_arc_497  -14
    arc_0_5_20  out_degree_728  1
    arc_0_5_20  in_degree_778  1
    arc_0_5_20  original_T_including_depot_unload_787  1.6849162169783858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_496  1
    load_0_5_20  segment_load_conservation_732  1
    load_0_5_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_498  -20
    arc_0_13_0  depot_return_or_bypass_699  1
    arc_0_13_0  out_degree_735  1
    arc_0_13_0  original_T_including_depot_unload_787  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_498  1
    load_0_13_0  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_499  -20
    arc_0_13_1  connected_order_arc_500  -14
    arc_0_13_1  in_degree_701  1
    arc_0_13_1  out_degree_735  1
    arc_0_13_1  original_T_including_depot_unload_787  1.6289794123513827e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_499  1
    load_0_13_1  segment_load_conservation_704  -1
    load_0_13_1  segment_prefix_lb_705  1
    load_0_13_1  segment_prefix_ub_706  1
    load_0_13_1  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_501  -20
    arc_0_13_2  connected_order_arc_502  -14
    arc_0_13_2  in_degree_708  1
    arc_0_13_2  out_degree_735  1
    arc_0_13_2  original_T_including_depot_unload_787  1.3232349913962587e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_501  1
    load_0_13_2  segment_load_conservation_711  -1
    load_0_13_2  segment_prefix_lb_712  1
    load_0_13_2  segment_prefix_ub_713  1
    load_0_13_2  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_503  -20
    arc_0_13_3  connected_order_arc_504  -14
    arc_0_13_3  in_degree_715  1
    arc_0_13_3  out_degree_735  1
    arc_0_13_3  original_T_including_depot_unload_787  1.3208627731923268e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_503  1
    load_0_13_3  segment_load_conservation_718  -1
    load_0_13_3  segment_prefix_lb_719  1
    load_0_13_3  segment_prefix_ub_720  1
    load_0_13_3  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_505  -20
    arc_0_13_4  connected_order_arc_506  -14
    arc_0_13_4  in_degree_722  1
    arc_0_13_4  out_degree_735  1
    arc_0_13_4  original_T_including_depot_unload_787  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_505  1
    load_0_13_4  segment_load_conservation_725  -1
    load_0_13_4  segment_prefix_lb_726  1
    load_0_13_4  segment_prefix_ub_727  1
    load_0_13_4  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_507  -20
    arc_0_13_5  connected_order_arc_508  -14
    arc_0_13_5  in_degree_729  1
    arc_0_13_5  out_degree_735  1
    arc_0_13_5  original_T_including_depot_unload_787  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_507  1
    load_0_13_5  segment_load_conservation_732  -1
    load_0_13_5  segment_prefix_lb_733  1
    load_0_13_5  segment_prefix_ub_734  1
    load_0_13_5  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_509  -20
    arc_0_13_14  connected_order_arc_510  -14
    arc_0_13_14  out_degree_735  1
    arc_0_13_14  in_degree_742  1
    arc_0_13_14  original_T_including_depot_unload_787  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_509  1
    load_0_13_14  free_load_conservation_740  1
    load_0_13_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_511  -20
    arc_0_13_15  connected_order_arc_512  -14
    arc_0_13_15  out_degree_735  1
    arc_0_13_15  in_degree_748  1
    arc_0_13_15  original_T_including_depot_unload_787  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_511  1
    load_0_13_15  free_load_conservation_740  1
    load_0_13_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_513  -20
    arc_0_13_16  connected_order_arc_514  -14
    arc_0_13_16  out_degree_735  1
    arc_0_13_16  in_degree_754  1
    arc_0_13_16  original_T_including_depot_unload_787  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_513  1
    load_0_13_16  free_load_conservation_740  1
    load_0_13_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_515  -20
    arc_0_13_17  connected_order_arc_516  -14
    arc_0_13_17  out_degree_735  1
    arc_0_13_17  in_degree_760  1
    arc_0_13_17  original_T_including_depot_unload_787  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_515  1
    load_0_13_17  free_load_conservation_740  1
    load_0_13_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_517  -20
    arc_0_13_18  connected_order_arc_518  -14
    arc_0_13_18  out_degree_735  1
    arc_0_13_18  in_degree_766  1
    arc_0_13_18  original_T_including_depot_unload_787  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_517  1
    load_0_13_18  free_load_conservation_740  1
    load_0_13_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_519  -20
    arc_0_13_19  connected_order_arc_520  -14
    arc_0_13_19  out_degree_735  1
    arc_0_13_19  in_degree_772  1
    arc_0_13_19  original_T_including_depot_unload_787  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_519  1
    load_0_13_19  free_load_conservation_740  1
    load_0_13_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_521  -20
    arc_0_13_20  connected_order_arc_522  -14
    arc_0_13_20  out_degree_735  1
    arc_0_13_20  in_degree_778  1
    arc_0_13_20  original_T_including_depot_unload_787  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_521  1
    load_0_13_20  free_load_conservation_740  1
    load_0_13_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_523  -20
    arc_0_14_0  depot_return_or_bypass_699  1
    arc_0_14_0  out_degree_741  1
    arc_0_14_0  original_T_including_depot_unload_787  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_523  1
    load_0_14_0  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_524  -20
    arc_0_14_1  connected_order_arc_525  -14
    arc_0_14_1  in_degree_701  1
    arc_0_14_1  out_degree_741  1
    arc_0_14_1  original_T_including_depot_unload_787  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_524  1
    load_0_14_1  segment_load_conservation_704  -1
    load_0_14_1  segment_prefix_lb_705  1
    load_0_14_1  segment_prefix_ub_706  1
    load_0_14_1  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_526  -20
    arc_0_14_2  connected_order_arc_527  -14
    arc_0_14_2  in_degree_708  1
    arc_0_14_2  out_degree_741  1
    arc_0_14_2  original_T_including_depot_unload_787  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_526  1
    load_0_14_2  segment_load_conservation_711  -1
    load_0_14_2  segment_prefix_lb_712  1
    load_0_14_2  segment_prefix_ub_713  1
    load_0_14_2  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_528  -20
    arc_0_14_3  connected_order_arc_529  -14
    arc_0_14_3  in_degree_715  1
    arc_0_14_3  out_degree_741  1
    arc_0_14_3  original_T_including_depot_unload_787  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_528  1
    load_0_14_3  segment_load_conservation_718  -1
    load_0_14_3  segment_prefix_lb_719  1
    load_0_14_3  segment_prefix_ub_720  1
    load_0_14_3  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_530  -20
    arc_0_14_4  connected_order_arc_531  -14
    arc_0_14_4  in_degree_722  1
    arc_0_14_4  out_degree_741  1
    arc_0_14_4  original_T_including_depot_unload_787  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_530  1
    load_0_14_4  segment_load_conservation_725  -1
    load_0_14_4  segment_prefix_lb_726  1
    load_0_14_4  segment_prefix_ub_727  1
    load_0_14_4  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_532  -20
    arc_0_14_5  connected_order_arc_533  -14
    arc_0_14_5  in_degree_729  1
    arc_0_14_5  out_degree_741  1
    arc_0_14_5  original_T_including_depot_unload_787  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_532  1
    load_0_14_5  segment_load_conservation_732  -1
    load_0_14_5  segment_prefix_lb_733  1
    load_0_14_5  segment_prefix_ub_734  1
    load_0_14_5  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_534  -20
    arc_0_14_13  connected_order_arc_535  -14
    arc_0_14_13  in_degree_736  1
    arc_0_14_13  out_degree_741  1
    arc_0_14_13  original_T_including_depot_unload_787  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_534  1
    load_0_14_13  free_load_conservation_740  -1
    load_0_14_13  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_536  -20
    arc_0_14_15  connected_order_arc_537  -14
    arc_0_14_15  out_degree_741  1
    arc_0_14_15  in_degree_748  1
    arc_0_14_15  original_T_including_depot_unload_787  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_536  1
    load_0_14_15  free_load_conservation_746  1
    load_0_14_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_538  -20
    arc_0_14_16  connected_order_arc_539  -14
    arc_0_14_16  out_degree_741  1
    arc_0_14_16  in_degree_754  1
    arc_0_14_16  original_T_including_depot_unload_787  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_538  1
    load_0_14_16  free_load_conservation_746  1
    load_0_14_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_540  -20
    arc_0_14_17  connected_order_arc_541  -14
    arc_0_14_17  out_degree_741  1
    arc_0_14_17  in_degree_760  1
    arc_0_14_17  original_T_including_depot_unload_787  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_540  1
    load_0_14_17  free_load_conservation_746  1
    load_0_14_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_542  -20
    arc_0_14_18  connected_order_arc_543  -14
    arc_0_14_18  out_degree_741  1
    arc_0_14_18  in_degree_766  1
    arc_0_14_18  original_T_including_depot_unload_787  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_542  1
    load_0_14_18  free_load_conservation_746  1
    load_0_14_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_544  -20
    arc_0_14_19  connected_order_arc_545  -14
    arc_0_14_19  out_degree_741  1
    arc_0_14_19  in_degree_772  1
    arc_0_14_19  original_T_including_depot_unload_787  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_544  1
    load_0_14_19  free_load_conservation_746  1
    load_0_14_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_546  -20
    arc_0_14_20  connected_order_arc_547  -14
    arc_0_14_20  out_degree_741  1
    arc_0_14_20  in_degree_778  1
    arc_0_14_20  original_T_including_depot_unload_787  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_546  1
    load_0_14_20  free_load_conservation_746  1
    load_0_14_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_548  -20
    arc_0_15_0  depot_return_or_bypass_699  1
    arc_0_15_0  out_degree_747  1
    arc_0_15_0  original_T_including_depot_unload_787  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_548  1
    load_0_15_0  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_549  -20
    arc_0_15_1  connected_order_arc_550  -14
    arc_0_15_1  in_degree_701  1
    arc_0_15_1  out_degree_747  1
    arc_0_15_1  original_T_including_depot_unload_787  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_549  1
    load_0_15_1  segment_load_conservation_704  -1
    load_0_15_1  segment_prefix_lb_705  1
    load_0_15_1  segment_prefix_ub_706  1
    load_0_15_1  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_551  -20
    arc_0_15_2  connected_order_arc_552  -14
    arc_0_15_2  in_degree_708  1
    arc_0_15_2  out_degree_747  1
    arc_0_15_2  original_T_including_depot_unload_787  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_551  1
    load_0_15_2  segment_load_conservation_711  -1
    load_0_15_2  segment_prefix_lb_712  1
    load_0_15_2  segment_prefix_ub_713  1
    load_0_15_2  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_553  -20
    arc_0_15_3  connected_order_arc_554  -14
    arc_0_15_3  in_degree_715  1
    arc_0_15_3  out_degree_747  1
    arc_0_15_3  original_T_including_depot_unload_787  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_553  1
    load_0_15_3  segment_load_conservation_718  -1
    load_0_15_3  segment_prefix_lb_719  1
    load_0_15_3  segment_prefix_ub_720  1
    load_0_15_3  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_555  -20
    arc_0_15_4  connected_order_arc_556  -14
    arc_0_15_4  in_degree_722  1
    arc_0_15_4  out_degree_747  1
    arc_0_15_4  original_T_including_depot_unload_787  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_555  1
    load_0_15_4  segment_load_conservation_725  -1
    load_0_15_4  segment_prefix_lb_726  1
    load_0_15_4  segment_prefix_ub_727  1
    load_0_15_4  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_557  -20
    arc_0_15_5  connected_order_arc_558  -14
    arc_0_15_5  in_degree_729  1
    arc_0_15_5  out_degree_747  1
    arc_0_15_5  original_T_including_depot_unload_787  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_557  1
    load_0_15_5  segment_load_conservation_732  -1
    load_0_15_5  segment_prefix_lb_733  1
    load_0_15_5  segment_prefix_ub_734  1
    load_0_15_5  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_559  -20
    arc_0_15_13  connected_order_arc_560  -14
    arc_0_15_13  in_degree_736  1
    arc_0_15_13  out_degree_747  1
    arc_0_15_13  original_T_including_depot_unload_787  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_559  1
    load_0_15_13  free_load_conservation_740  -1
    load_0_15_13  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_561  -20
    arc_0_15_14  connected_order_arc_562  -14
    arc_0_15_14  in_degree_742  1
    arc_0_15_14  out_degree_747  1
    arc_0_15_14  original_T_including_depot_unload_787  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_561  1
    load_0_15_14  free_load_conservation_746  -1
    load_0_15_14  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_563  -20
    arc_0_15_16  connected_order_arc_564  -14
    arc_0_15_16  out_degree_747  1
    arc_0_15_16  in_degree_754  1
    arc_0_15_16  original_T_including_depot_unload_787  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_563  1
    load_0_15_16  free_load_conservation_752  1
    load_0_15_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_565  -20
    arc_0_15_17  connected_order_arc_566  -14
    arc_0_15_17  out_degree_747  1
    arc_0_15_17  in_degree_760  1
    arc_0_15_17  original_T_including_depot_unload_787  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_565  1
    load_0_15_17  free_load_conservation_752  1
    load_0_15_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_567  -20
    arc_0_15_18  connected_order_arc_568  -14
    arc_0_15_18  out_degree_747  1
    arc_0_15_18  in_degree_766  1
    arc_0_15_18  original_T_including_depot_unload_787  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_567  1
    load_0_15_18  free_load_conservation_752  1
    load_0_15_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_569  -20
    arc_0_15_19  connected_order_arc_570  -14
    arc_0_15_19  out_degree_747  1
    arc_0_15_19  in_degree_772  1
    arc_0_15_19  original_T_including_depot_unload_787  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_569  1
    load_0_15_19  free_load_conservation_752  1
    load_0_15_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_571  -20
    arc_0_15_20  connected_order_arc_572  -14
    arc_0_15_20  out_degree_747  1
    arc_0_15_20  in_degree_778  1
    arc_0_15_20  original_T_including_depot_unload_787  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_571  1
    load_0_15_20  free_load_conservation_752  1
    load_0_15_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_573  -20
    arc_0_16_0  depot_return_or_bypass_699  1
    arc_0_16_0  out_degree_753  1
    arc_0_16_0  original_T_including_depot_unload_787  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_573  1
    load_0_16_0  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_574  -20
    arc_0_16_1  connected_order_arc_575  -14
    arc_0_16_1  in_degree_701  1
    arc_0_16_1  out_degree_753  1
    arc_0_16_1  original_T_including_depot_unload_787  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_574  1
    load_0_16_1  segment_load_conservation_704  -1
    load_0_16_1  segment_prefix_lb_705  1
    load_0_16_1  segment_prefix_ub_706  1
    load_0_16_1  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_576  -20
    arc_0_16_2  connected_order_arc_577  -14
    arc_0_16_2  in_degree_708  1
    arc_0_16_2  out_degree_753  1
    arc_0_16_2  original_T_including_depot_unload_787  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_576  1
    load_0_16_2  segment_load_conservation_711  -1
    load_0_16_2  segment_prefix_lb_712  1
    load_0_16_2  segment_prefix_ub_713  1
    load_0_16_2  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_578  -20
    arc_0_16_3  connected_order_arc_579  -14
    arc_0_16_3  in_degree_715  1
    arc_0_16_3  out_degree_753  1
    arc_0_16_3  original_T_including_depot_unload_787  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_578  1
    load_0_16_3  segment_load_conservation_718  -1
    load_0_16_3  segment_prefix_lb_719  1
    load_0_16_3  segment_prefix_ub_720  1
    load_0_16_3  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_580  -20
    arc_0_16_4  connected_order_arc_581  -14
    arc_0_16_4  in_degree_722  1
    arc_0_16_4  out_degree_753  1
    arc_0_16_4  original_T_including_depot_unload_787  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_580  1
    load_0_16_4  segment_load_conservation_725  -1
    load_0_16_4  segment_prefix_lb_726  1
    load_0_16_4  segment_prefix_ub_727  1
    load_0_16_4  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_582  -20
    arc_0_16_5  connected_order_arc_583  -14
    arc_0_16_5  in_degree_729  1
    arc_0_16_5  out_degree_753  1
    arc_0_16_5  original_T_including_depot_unload_787  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_582  1
    load_0_16_5  segment_load_conservation_732  -1
    load_0_16_5  segment_prefix_lb_733  1
    load_0_16_5  segment_prefix_ub_734  1
    load_0_16_5  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_584  -20
    arc_0_16_13  connected_order_arc_585  -14
    arc_0_16_13  in_degree_736  1
    arc_0_16_13  out_degree_753  1
    arc_0_16_13  original_T_including_depot_unload_787  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_584  1
    load_0_16_13  free_load_conservation_740  -1
    load_0_16_13  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_586  -20
    arc_0_16_14  connected_order_arc_587  -14
    arc_0_16_14  in_degree_742  1
    arc_0_16_14  out_degree_753  1
    arc_0_16_14  original_T_including_depot_unload_787  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_586  1
    load_0_16_14  free_load_conservation_746  -1
    load_0_16_14  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_588  -20
    arc_0_16_15  connected_order_arc_589  -14
    arc_0_16_15  in_degree_748  1
    arc_0_16_15  out_degree_753  1
    arc_0_16_15  original_T_including_depot_unload_787  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_588  1
    load_0_16_15  free_load_conservation_752  -1
    load_0_16_15  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_590  -20
    arc_0_16_17  connected_order_arc_591  -14
    arc_0_16_17  out_degree_753  1
    arc_0_16_17  in_degree_760  1
    arc_0_16_17  original_T_including_depot_unload_787  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_590  1
    load_0_16_17  free_load_conservation_758  1
    load_0_16_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_592  -20
    arc_0_16_18  connected_order_arc_593  -14
    arc_0_16_18  out_degree_753  1
    arc_0_16_18  in_degree_766  1
    arc_0_16_18  original_T_including_depot_unload_787  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_592  1
    load_0_16_18  free_load_conservation_758  1
    load_0_16_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_594  -20
    arc_0_16_19  connected_order_arc_595  -14
    arc_0_16_19  out_degree_753  1
    arc_0_16_19  in_degree_772  1
    arc_0_16_19  original_T_including_depot_unload_787  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_594  1
    load_0_16_19  free_load_conservation_758  1
    load_0_16_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_596  -20
    arc_0_16_20  connected_order_arc_597  -14
    arc_0_16_20  out_degree_753  1
    arc_0_16_20  in_degree_778  1
    arc_0_16_20  original_T_including_depot_unload_787  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_596  1
    load_0_16_20  free_load_conservation_758  1
    load_0_16_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_598  -20
    arc_0_17_0  depot_return_or_bypass_699  1
    arc_0_17_0  out_degree_759  1
    arc_0_17_0  original_T_including_depot_unload_787  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_598  1
    load_0_17_0  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_599  -20
    arc_0_17_1  connected_order_arc_600  -14
    arc_0_17_1  in_degree_701  1
    arc_0_17_1  out_degree_759  1
    arc_0_17_1  original_T_including_depot_unload_787  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_599  1
    load_0_17_1  segment_load_conservation_704  -1
    load_0_17_1  segment_prefix_lb_705  1
    load_0_17_1  segment_prefix_ub_706  1
    load_0_17_1  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_601  -20
    arc_0_17_2  connected_order_arc_602  -14
    arc_0_17_2  in_degree_708  1
    arc_0_17_2  out_degree_759  1
    arc_0_17_2  original_T_including_depot_unload_787  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_601  1
    load_0_17_2  segment_load_conservation_711  -1
    load_0_17_2  segment_prefix_lb_712  1
    load_0_17_2  segment_prefix_ub_713  1
    load_0_17_2  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_603  -20
    arc_0_17_3  connected_order_arc_604  -14
    arc_0_17_3  in_degree_715  1
    arc_0_17_3  out_degree_759  1
    arc_0_17_3  original_T_including_depot_unload_787  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_603  1
    load_0_17_3  segment_load_conservation_718  -1
    load_0_17_3  segment_prefix_lb_719  1
    load_0_17_3  segment_prefix_ub_720  1
    load_0_17_3  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_605  -20
    arc_0_17_4  connected_order_arc_606  -14
    arc_0_17_4  in_degree_722  1
    arc_0_17_4  out_degree_759  1
    arc_0_17_4  original_T_including_depot_unload_787  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_605  1
    load_0_17_4  segment_load_conservation_725  -1
    load_0_17_4  segment_prefix_lb_726  1
    load_0_17_4  segment_prefix_ub_727  1
    load_0_17_4  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_607  -20
    arc_0_17_5  connected_order_arc_608  -14
    arc_0_17_5  in_degree_729  1
    arc_0_17_5  out_degree_759  1
    arc_0_17_5  original_T_including_depot_unload_787  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_607  1
    load_0_17_5  segment_load_conservation_732  -1
    load_0_17_5  segment_prefix_lb_733  1
    load_0_17_5  segment_prefix_ub_734  1
    load_0_17_5  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_609  -20
    arc_0_17_13  connected_order_arc_610  -14
    arc_0_17_13  in_degree_736  1
    arc_0_17_13  out_degree_759  1
    arc_0_17_13  original_T_including_depot_unload_787  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_609  1
    load_0_17_13  free_load_conservation_740  -1
    load_0_17_13  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_611  -20
    arc_0_17_14  connected_order_arc_612  -14
    arc_0_17_14  in_degree_742  1
    arc_0_17_14  out_degree_759  1
    arc_0_17_14  original_T_including_depot_unload_787  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_611  1
    load_0_17_14  free_load_conservation_746  -1
    load_0_17_14  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_613  -20
    arc_0_17_15  connected_order_arc_614  -14
    arc_0_17_15  in_degree_748  1
    arc_0_17_15  out_degree_759  1
    arc_0_17_15  original_T_including_depot_unload_787  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_613  1
    load_0_17_15  free_load_conservation_752  -1
    load_0_17_15  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_615  -20
    arc_0_17_16  connected_order_arc_616  -14
    arc_0_17_16  in_degree_754  1
    arc_0_17_16  out_degree_759  1
    arc_0_17_16  original_T_including_depot_unload_787  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_615  1
    load_0_17_16  free_load_conservation_758  -1
    load_0_17_16  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_617  -20
    arc_0_17_18  connected_order_arc_618  -14
    arc_0_17_18  out_degree_759  1
    arc_0_17_18  in_degree_766  1
    arc_0_17_18  original_T_including_depot_unload_787  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_617  1
    load_0_17_18  free_load_conservation_764  1
    load_0_17_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_619  -20
    arc_0_17_19  connected_order_arc_620  -14
    arc_0_17_19  out_degree_759  1
    arc_0_17_19  in_degree_772  1
    arc_0_17_19  original_T_including_depot_unload_787  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_619  1
    load_0_17_19  free_load_conservation_764  1
    load_0_17_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_621  -20
    arc_0_17_20  connected_order_arc_622  -14
    arc_0_17_20  out_degree_759  1
    arc_0_17_20  in_degree_778  1
    arc_0_17_20  original_T_including_depot_unload_787  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_621  1
    load_0_17_20  free_load_conservation_764  1
    load_0_17_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_623  -20
    arc_0_18_0  depot_return_or_bypass_699  1
    arc_0_18_0  out_degree_765  1
    arc_0_18_0  original_T_including_depot_unload_787  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_623  1
    load_0_18_0  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_624  -20
    arc_0_18_1  connected_order_arc_625  -14
    arc_0_18_1  in_degree_701  1
    arc_0_18_1  out_degree_765  1
    arc_0_18_1  original_T_including_depot_unload_787  2093.82511369171
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_624  1
    load_0_18_1  segment_load_conservation_704  -1
    load_0_18_1  segment_prefix_lb_705  1
    load_0_18_1  segment_prefix_ub_706  1
    load_0_18_1  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_626  -20
    arc_0_18_2  connected_order_arc_627  -14
    arc_0_18_2  in_degree_708  1
    arc_0_18_2  out_degree_765  1
    arc_0_18_2  original_T_including_depot_unload_787  1.7486017219434013e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_626  1
    load_0_18_2  segment_load_conservation_711  -1
    load_0_18_2  segment_prefix_lb_712  1
    load_0_18_2  segment_prefix_ub_713  1
    load_0_18_2  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_628  -20
    arc_0_18_3  connected_order_arc_629  -14
    arc_0_18_3  in_degree_715  1
    arc_0_18_3  out_degree_765  1
    arc_0_18_3  original_T_including_depot_unload_787  1.7460980574235175e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_628  1
    load_0_18_3  segment_load_conservation_718  -1
    load_0_18_3  segment_prefix_lb_719  1
    load_0_18_3  segment_prefix_ub_720  1
    load_0_18_3  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_630  -20
    arc_0_18_4  connected_order_arc_631  -14
    arc_0_18_4  in_degree_722  1
    arc_0_18_4  out_degree_765  1
    arc_0_18_4  original_T_including_depot_unload_787  1.5787929582117179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_630  1
    load_0_18_4  segment_load_conservation_725  -1
    load_0_18_4  segment_prefix_lb_726  1
    load_0_18_4  segment_prefix_ub_727  1
    load_0_18_4  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_632  -20
    arc_0_18_5  connected_order_arc_633  -14
    arc_0_18_5  in_degree_729  1
    arc_0_18_5  out_degree_765  1
    arc_0_18_5  original_T_including_depot_unload_787  1.4823747651994408e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_632  1
    load_0_18_5  segment_load_conservation_732  -1
    load_0_18_5  segment_prefix_lb_733  1
    load_0_18_5  segment_prefix_ub_734  1
    load_0_18_5  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_634  -20
    arc_0_18_13  connected_order_arc_635  -14
    arc_0_18_13  in_degree_736  1
    arc_0_18_13  out_degree_765  1
    arc_0_18_13  original_T_including_depot_unload_787  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_634  1
    load_0_18_13  free_load_conservation_740  -1
    load_0_18_13  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_636  -20
    arc_0_18_14  connected_order_arc_637  -14
    arc_0_18_14  in_degree_742  1
    arc_0_18_14  out_degree_765  1
    arc_0_18_14  original_T_including_depot_unload_787  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_636  1
    load_0_18_14  free_load_conservation_746  -1
    load_0_18_14  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_638  -20
    arc_0_18_15  connected_order_arc_639  -14
    arc_0_18_15  in_degree_748  1
    arc_0_18_15  out_degree_765  1
    arc_0_18_15  original_T_including_depot_unload_787  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_638  1
    load_0_18_15  free_load_conservation_752  -1
    load_0_18_15  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_640  -20
    arc_0_18_16  connected_order_arc_641  -14
    arc_0_18_16  in_degree_754  1
    arc_0_18_16  out_degree_765  1
    arc_0_18_16  original_T_including_depot_unload_787  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_640  1
    load_0_18_16  free_load_conservation_758  -1
    load_0_18_16  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_642  -20
    arc_0_18_17  connected_order_arc_643  -14
    arc_0_18_17  in_degree_760  1
    arc_0_18_17  out_degree_765  1
    arc_0_18_17  original_T_including_depot_unload_787  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_642  1
    load_0_18_17  free_load_conservation_764  -1
    load_0_18_17  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_644  -20
    arc_0_18_19  connected_order_arc_645  -14
    arc_0_18_19  out_degree_765  1
    arc_0_18_19  in_degree_772  1
    arc_0_18_19  original_T_including_depot_unload_787  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_644  1
    load_0_18_19  free_load_conservation_770  1
    load_0_18_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_646  -20
    arc_0_18_20  connected_order_arc_647  -14
    arc_0_18_20  out_degree_765  1
    arc_0_18_20  in_degree_778  1
    arc_0_18_20  original_T_including_depot_unload_787  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_646  1
    load_0_18_20  free_load_conservation_770  1
    load_0_18_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_648  -20
    arc_0_19_0  depot_return_or_bypass_699  1
    arc_0_19_0  out_degree_771  1
    arc_0_19_0  original_T_including_depot_unload_787  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_648  1
    load_0_19_0  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_649  -20
    arc_0_19_1  connected_order_arc_650  -14
    arc_0_19_1  in_degree_701  1
    arc_0_19_1  out_degree_771  1
    arc_0_19_1  original_T_including_depot_unload_787  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_649  1
    load_0_19_1  segment_load_conservation_704  -1
    load_0_19_1  segment_prefix_lb_705  1
    load_0_19_1  segment_prefix_ub_706  1
    load_0_19_1  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_651  -20
    arc_0_19_2  connected_order_arc_652  -14
    arc_0_19_2  in_degree_708  1
    arc_0_19_2  out_degree_771  1
    arc_0_19_2  original_T_including_depot_unload_787  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_651  1
    load_0_19_2  segment_load_conservation_711  -1
    load_0_19_2  segment_prefix_lb_712  1
    load_0_19_2  segment_prefix_ub_713  1
    load_0_19_2  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_653  -20
    arc_0_19_3  connected_order_arc_654  -14
    arc_0_19_3  in_degree_715  1
    arc_0_19_3  out_degree_771  1
    arc_0_19_3  original_T_including_depot_unload_787  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_653  1
    load_0_19_3  segment_load_conservation_718  -1
    load_0_19_3  segment_prefix_lb_719  1
    load_0_19_3  segment_prefix_ub_720  1
    load_0_19_3  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_655  -20
    arc_0_19_4  connected_order_arc_656  -14
    arc_0_19_4  in_degree_722  1
    arc_0_19_4  out_degree_771  1
    arc_0_19_4  original_T_including_depot_unload_787  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_655  1
    load_0_19_4  segment_load_conservation_725  -1
    load_0_19_4  segment_prefix_lb_726  1
    load_0_19_4  segment_prefix_ub_727  1
    load_0_19_4  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_657  -20
    arc_0_19_5  connected_order_arc_658  -14
    arc_0_19_5  in_degree_729  1
    arc_0_19_5  out_degree_771  1
    arc_0_19_5  original_T_including_depot_unload_787  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_657  1
    load_0_19_5  segment_load_conservation_732  -1
    load_0_19_5  segment_prefix_lb_733  1
    load_0_19_5  segment_prefix_ub_734  1
    load_0_19_5  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_659  -20
    arc_0_19_13  connected_order_arc_660  -14
    arc_0_19_13  in_degree_736  1
    arc_0_19_13  out_degree_771  1
    arc_0_19_13  original_T_including_depot_unload_787  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_659  1
    load_0_19_13  free_load_conservation_740  -1
    load_0_19_13  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_661  -20
    arc_0_19_14  connected_order_arc_662  -14
    arc_0_19_14  in_degree_742  1
    arc_0_19_14  out_degree_771  1
    arc_0_19_14  original_T_including_depot_unload_787  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_661  1
    load_0_19_14  free_load_conservation_746  -1
    load_0_19_14  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_663  -20
    arc_0_19_15  connected_order_arc_664  -14
    arc_0_19_15  in_degree_748  1
    arc_0_19_15  out_degree_771  1
    arc_0_19_15  original_T_including_depot_unload_787  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_663  1
    load_0_19_15  free_load_conservation_752  -1
    load_0_19_15  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_665  -20
    arc_0_19_16  connected_order_arc_666  -14
    arc_0_19_16  in_degree_754  1
    arc_0_19_16  out_degree_771  1
    arc_0_19_16  original_T_including_depot_unload_787  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_665  1
    load_0_19_16  free_load_conservation_758  -1
    load_0_19_16  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_667  -20
    arc_0_19_17  connected_order_arc_668  -14
    arc_0_19_17  in_degree_760  1
    arc_0_19_17  out_degree_771  1
    arc_0_19_17  original_T_including_depot_unload_787  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_667  1
    load_0_19_17  free_load_conservation_764  -1
    load_0_19_17  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_669  -20
    arc_0_19_18  connected_order_arc_670  -14
    arc_0_19_18  in_degree_766  1
    arc_0_19_18  out_degree_771  1
    arc_0_19_18  original_T_including_depot_unload_787  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_669  1
    load_0_19_18  free_load_conservation_770  -1
    load_0_19_18  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_671  -20
    arc_0_19_20  connected_order_arc_672  -14
    arc_0_19_20  out_degree_771  1
    arc_0_19_20  in_degree_778  1
    arc_0_19_20  original_T_including_depot_unload_787  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_671  1
    load_0_19_20  free_load_conservation_776  1
    load_0_19_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_673  -20
    arc_0_20_0  depot_return_or_bypass_699  1
    arc_0_20_0  out_degree_777  1
    arc_0_20_0  original_T_including_depot_unload_787  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_673  1
    load_0_20_0  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_674  -20
    arc_0_20_1  connected_order_arc_675  -14
    arc_0_20_1  in_degree_701  1
    arc_0_20_1  out_degree_777  1
    arc_0_20_1  original_T_including_depot_unload_787  2.2244039731678959e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_674  1
    load_0_20_1  segment_load_conservation_704  -1
    load_0_20_1  segment_prefix_lb_705  1
    load_0_20_1  segment_prefix_ub_706  1
    load_0_20_1  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_676  -20
    arc_0_20_2  connected_order_arc_677  -14
    arc_0_20_2  in_degree_708  1
    arc_0_20_2  out_degree_777  1
    arc_0_20_2  original_T_including_depot_unload_787  1.9286914187809364e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_676  1
    load_0_20_2  segment_load_conservation_711  -1
    load_0_20_2  segment_prefix_lb_712  1
    load_0_20_2  segment_prefix_ub_713  1
    load_0_20_2  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_678  -20
    arc_0_20_3  connected_order_arc_679  -14
    arc_0_20_3  in_degree_715  1
    arc_0_20_3  out_degree_777  1
    arc_0_20_3  original_T_including_depot_unload_787  1.9263039852699487e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_678  1
    load_0_20_3  segment_load_conservation_718  -1
    load_0_20_3  segment_prefix_lb_719  1
    load_0_20_3  segment_prefix_ub_720  1
    load_0_20_3  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_680  -20
    arc_0_20_4  connected_order_arc_681  -14
    arc_0_20_4  in_degree_722  1
    arc_0_20_4  out_degree_777  1
    arc_0_20_4  original_T_including_depot_unload_787  1.7740294865208371e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_680  1
    load_0_20_4  segment_load_conservation_725  -1
    load_0_20_4  segment_prefix_lb_726  1
    load_0_20_4  segment_prefix_ub_727  1
    load_0_20_4  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_682  -20
    arc_0_20_5  connected_order_arc_683  -14
    arc_0_20_5  in_degree_729  1
    arc_0_20_5  out_degree_777  1
    arc_0_20_5  original_T_including_depot_unload_787  1.6849162169783858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_682  1
    load_0_20_5  segment_load_conservation_732  -1
    load_0_20_5  segment_prefix_lb_733  1
    load_0_20_5  segment_prefix_ub_734  1
    load_0_20_5  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_684  -20
    arc_0_20_13  connected_order_arc_685  -14
    arc_0_20_13  in_degree_736  1
    arc_0_20_13  out_degree_777  1
    arc_0_20_13  original_T_including_depot_unload_787  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_684  1
    load_0_20_13  free_load_conservation_740  -1
    load_0_20_13  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_686  -20
    arc_0_20_14  connected_order_arc_687  -14
    arc_0_20_14  in_degree_742  1
    arc_0_20_14  out_degree_777  1
    arc_0_20_14  original_T_including_depot_unload_787  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_686  1
    load_0_20_14  free_load_conservation_746  -1
    load_0_20_14  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_688  -20
    arc_0_20_15  connected_order_arc_689  -14
    arc_0_20_15  in_degree_748  1
    arc_0_20_15  out_degree_777  1
    arc_0_20_15  original_T_including_depot_unload_787  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_688  1
    load_0_20_15  free_load_conservation_752  -1
    load_0_20_15  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_690  -20
    arc_0_20_16  connected_order_arc_691  -14
    arc_0_20_16  in_degree_754  1
    arc_0_20_16  out_degree_777  1
    arc_0_20_16  original_T_including_depot_unload_787  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_690  1
    load_0_20_16  free_load_conservation_758  -1
    load_0_20_16  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_692  -20
    arc_0_20_17  connected_order_arc_693  -14
    arc_0_20_17  in_degree_760  1
    arc_0_20_17  out_degree_777  1
    arc_0_20_17  original_T_including_depot_unload_787  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_692  1
    load_0_20_17  free_load_conservation_764  -1
    load_0_20_17  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_694  -20
    arc_0_20_18  connected_order_arc_695  -14
    arc_0_20_18  in_degree_766  1
    arc_0_20_18  out_degree_777  1
    arc_0_20_18  original_T_including_depot_unload_787  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_694  1
    load_0_20_18  free_load_conservation_770  -1
    load_0_20_18  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_696  -20
    arc_0_20_19  connected_order_arc_697  -14
    arc_0_20_19  in_degree_772  1
    arc_0_20_19  out_degree_777  1
    arc_0_20_19  original_T_including_depot_unload_787  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_696  1
    load_0_20_19  free_load_conservation_776  -1
    load_0_20_19  free_load_conservation_782  1
    visit_1_6  out_degree_1079  -1
    visit_1_6  in_degree_1080  -1
    visit_1_6  order_active_lb_1081  -1
    visit_1_6  order_active_ub_1082  -12
    order_1_6  connected_order_arc_803  -1
    order_1_6  connected_order_arc_805  -1
    order_1_6  connected_order_arc_807  -1
    order_1_6  connected_order_arc_809  -1
    order_1_6  connected_order_arc_811  -1
    order_1_6  connected_order_arc_813  -1
    order_1_6  connected_order_arc_815  -1
    order_1_6  connected_order_arc_817  -1
    order_1_6  connected_order_arc_819  -1
    order_1_6  connected_order_arc_821  -1
    order_1_6  connected_order_arc_823  -1
    order_1_6  connected_order_arc_826  1
    order_1_6  connected_order_arc_849  1
    order_1_6  connected_order_arc_872  1
    order_1_6  connected_order_arc_895  1
    order_1_6  connected_order_arc_918  1
    order_1_6  connected_order_arc_941  1
    order_1_6  connected_order_arc_964  1
    order_1_6  connected_order_arc_987  1
    order_1_6  connected_order_arc_1010  1
    order_1_6  connected_order_arc_1033  1
    order_1_6  connected_order_arc_1056  1
    order_1_6  order_active_lb_1081  1
    order_1_6  order_active_ub_1082  1
    order_1_6  fixed_segment_relative_order_1155  -1
    visit_1_7  out_degree_1086  -1
    visit_1_7  in_degree_1087  -1
    visit_1_7  order_active_lb_1088  -1
    visit_1_7  order_active_ub_1089  -12
    order_1_7  connected_order_arc_803  1
    order_1_7  connected_order_arc_826  -1
    order_1_7  connected_order_arc_828  -1
    order_1_7  connected_order_arc_830  -1
    order_1_7  connected_order_arc_832  -1
    order_1_7  connected_order_arc_834  -1
    order_1_7  connected_order_arc_836  -1
    order_1_7  connected_order_arc_838  -1
    order_1_7  connected_order_arc_840  -1
    order_1_7  connected_order_arc_842  -1
    order_1_7  connected_order_arc_844  -1
    order_1_7  connected_order_arc_846  -1
    order_1_7  connected_order_arc_851  1
    order_1_7  connected_order_arc_874  1
    order_1_7  connected_order_arc_897  1
    order_1_7  connected_order_arc_920  1
    order_1_7  connected_order_arc_943  1
    order_1_7  connected_order_arc_966  1
    order_1_7  connected_order_arc_989  1
    order_1_7  connected_order_arc_1012  1
    order_1_7  connected_order_arc_1035  1
    order_1_7  connected_order_arc_1058  1
    order_1_7  order_active_lb_1088  1
    order_1_7  order_active_ub_1089  1
    order_1_7  fixed_segment_relative_order_1155  1
    order_1_7  fixed_segment_relative_order_1156  -1
    visit_1_8  out_degree_1093  -1
    visit_1_8  in_degree_1094  -1
    visit_1_8  order_active_lb_1095  -1
    visit_1_8  order_active_ub_1096  -12
    order_1_8  connected_order_arc_805  1
    order_1_8  connected_order_arc_828  1
    order_1_8  connected_order_arc_849  -1
    order_1_8  connected_order_arc_851  -1
    order_1_8  connected_order_arc_853  -1
    order_1_8  connected_order_arc_855  -1
    order_1_8  connected_order_arc_857  -1
    order_1_8  connected_order_arc_859  -1
    order_1_8  connected_order_arc_861  -1
    order_1_8  connected_order_arc_863  -1
    order_1_8  connected_order_arc_865  -1
    order_1_8  connected_order_arc_867  -1
    order_1_8  connected_order_arc_869  -1
    order_1_8  connected_order_arc_876  1
    order_1_8  connected_order_arc_899  1
    order_1_8  connected_order_arc_922  1
    order_1_8  connected_order_arc_945  1
    order_1_8  connected_order_arc_968  1
    order_1_8  connected_order_arc_991  1
    order_1_8  connected_order_arc_1014  1
    order_1_8  connected_order_arc_1037  1
    order_1_8  connected_order_arc_1060  1
    order_1_8  order_active_lb_1095  1
    order_1_8  order_active_ub_1096  1
    order_1_8  fixed_segment_relative_order_1156  1
    order_1_8  fixed_segment_relative_order_1157  -1
    visit_1_9  out_degree_1100  -1
    visit_1_9  in_degree_1101  -1
    visit_1_9  order_active_lb_1102  -1
    visit_1_9  order_active_ub_1103  -12
    order_1_9  connected_order_arc_807  1
    order_1_9  connected_order_arc_830  1
    order_1_9  connected_order_arc_853  1
    order_1_9  connected_order_arc_872  -1
    order_1_9  connected_order_arc_874  -1
    order_1_9  connected_order_arc_876  -1
    order_1_9  connected_order_arc_878  -1
    order_1_9  connected_order_arc_880  -1
    order_1_9  connected_order_arc_882  -1
    order_1_9  connected_order_arc_884  -1
    order_1_9  connected_order_arc_886  -1
    order_1_9  connected_order_arc_888  -1
    order_1_9  connected_order_arc_890  -1
    order_1_9  connected_order_arc_892  -1
    order_1_9  connected_order_arc_901  1
    order_1_9  connected_order_arc_924  1
    order_1_9  connected_order_arc_947  1
    order_1_9  connected_order_arc_970  1
    order_1_9  connected_order_arc_993  1
    order_1_9  connected_order_arc_1016  1
    order_1_9  connected_order_arc_1039  1
    order_1_9  connected_order_arc_1062  1
    order_1_9  order_active_lb_1102  1
    order_1_9  order_active_ub_1103  1
    order_1_9  fixed_segment_relative_order_1157  1
    visit_1_13  out_degree_1107  -1
    visit_1_13  in_degree_1108  -1
    visit_1_13  order_active_lb_1109  -1
    visit_1_13  order_active_ub_1110  -12
    visit_1_13  service_visit_def_1111  -1
    order_1_13  connected_order_arc_809  1
    order_1_13  connected_order_arc_832  1
    order_1_13  connected_order_arc_855  1
    order_1_13  connected_order_arc_878  1
    order_1_13  connected_order_arc_895  -1
    order_1_13  connected_order_arc_897  -1
    order_1_13  connected_order_arc_899  -1
    order_1_13  connected_order_arc_901  -1
    order_1_13  connected_order_arc_903  -1
    order_1_13  connected_order_arc_905  -1
    order_1_13  connected_order_arc_907  -1
    order_1_13  connected_order_arc_909  -1
    order_1_13  connected_order_arc_911  -1
    order_1_13  connected_order_arc_913  -1
    order_1_13  connected_order_arc_915  -1
    order_1_13  connected_order_arc_926  1
    order_1_13  connected_order_arc_949  1
    order_1_13  connected_order_arc_972  1
    order_1_13  connected_order_arc_995  1
    order_1_13  connected_order_arc_1018  1
    order_1_13  connected_order_arc_1041  1
    order_1_13  connected_order_arc_1064  1
    order_1_13  order_active_lb_1109  1
    order_1_13  order_active_ub_1110  1
    visit_1_14  out_degree_1113  -1
    visit_1_14  in_degree_1114  -1
    visit_1_14  order_active_lb_1115  -1
    visit_1_14  order_active_ub_1116  -12
    visit_1_14  service_visit_def_1117  -1
    order_1_14  connected_order_arc_811  1
    order_1_14  connected_order_arc_834  1
    order_1_14  connected_order_arc_857  1
    order_1_14  connected_order_arc_880  1
    order_1_14  connected_order_arc_903  1
    order_1_14  connected_order_arc_918  -1
    order_1_14  connected_order_arc_920  -1
    order_1_14  connected_order_arc_922  -1
    order_1_14  connected_order_arc_924  -1
    order_1_14  connected_order_arc_926  -1
    order_1_14  connected_order_arc_928  -1
    order_1_14  connected_order_arc_930  -1
    order_1_14  connected_order_arc_932  -1
    order_1_14  connected_order_arc_934  -1
    order_1_14  connected_order_arc_936  -1
    order_1_14  connected_order_arc_938  -1
    order_1_14  connected_order_arc_951  1
    order_1_14  connected_order_arc_974  1
    order_1_14  connected_order_arc_997  1
    order_1_14  connected_order_arc_1020  1
    order_1_14  connected_order_arc_1043  1
    order_1_14  connected_order_arc_1066  1
    order_1_14  order_active_lb_1115  1
    order_1_14  order_active_ub_1116  1
    visit_1_15  out_degree_1119  -1
    visit_1_15  in_degree_1120  -1
    visit_1_15  order_active_lb_1121  -1
    visit_1_15  order_active_ub_1122  -12
    visit_1_15  service_visit_def_1123  -1
    order_1_15  connected_order_arc_813  1
    order_1_15  connected_order_arc_836  1
    order_1_15  connected_order_arc_859  1
    order_1_15  connected_order_arc_882  1
    order_1_15  connected_order_arc_905  1
    order_1_15  connected_order_arc_928  1
    order_1_15  connected_order_arc_941  -1
    order_1_15  connected_order_arc_943  -1
    order_1_15  connected_order_arc_945  -1
    order_1_15  connected_order_arc_947  -1
    order_1_15  connected_order_arc_949  -1
    order_1_15  connected_order_arc_951  -1
    order_1_15  connected_order_arc_953  -1
    order_1_15  connected_order_arc_955  -1
    order_1_15  connected_order_arc_957  -1
    order_1_15  connected_order_arc_959  -1
    order_1_15  connected_order_arc_961  -1
    order_1_15  connected_order_arc_976  1
    order_1_15  connected_order_arc_999  1
    order_1_15  connected_order_arc_1022  1
    order_1_15  connected_order_arc_1045  1
    order_1_15  connected_order_arc_1068  1
    order_1_15  order_active_lb_1121  1
    order_1_15  order_active_ub_1122  1
    visit_1_16  out_degree_1125  -1
    visit_1_16  in_degree_1126  -1
    visit_1_16  order_active_lb_1127  -1
    visit_1_16  order_active_ub_1128  -12
    visit_1_16  service_visit_def_1129  -1
    order_1_16  connected_order_arc_815  1
    order_1_16  connected_order_arc_838  1
    order_1_16  connected_order_arc_861  1
    order_1_16  connected_order_arc_884  1
    order_1_16  connected_order_arc_907  1
    order_1_16  connected_order_arc_930  1
    order_1_16  connected_order_arc_953  1
    order_1_16  connected_order_arc_964  -1
    order_1_16  connected_order_arc_966  -1
    order_1_16  connected_order_arc_968  -1
    order_1_16  connected_order_arc_970  -1
    order_1_16  connected_order_arc_972  -1
    order_1_16  connected_order_arc_974  -1
    order_1_16  connected_order_arc_976  -1
    order_1_16  connected_order_arc_978  -1
    order_1_16  connected_order_arc_980  -1
    order_1_16  connected_order_arc_982  -1
    order_1_16  connected_order_arc_984  -1
    order_1_16  connected_order_arc_1001  1
    order_1_16  connected_order_arc_1024  1
    order_1_16  connected_order_arc_1047  1
    order_1_16  connected_order_arc_1070  1
    order_1_16  order_active_lb_1127  1
    order_1_16  order_active_ub_1128  1
    visit_1_17  out_degree_1131  -1
    visit_1_17  in_degree_1132  -1
    visit_1_17  order_active_lb_1133  -1
    visit_1_17  order_active_ub_1134  -12
    visit_1_17  service_visit_def_1135  -1
    order_1_17  connected_order_arc_817  1
    order_1_17  connected_order_arc_840  1
    order_1_17  connected_order_arc_863  1
    order_1_17  connected_order_arc_886  1
    order_1_17  connected_order_arc_909  1
    order_1_17  connected_order_arc_932  1
    order_1_17  connected_order_arc_955  1
    order_1_17  connected_order_arc_978  1
    order_1_17  connected_order_arc_987  -1
    order_1_17  connected_order_arc_989  -1
    order_1_17  connected_order_arc_991  -1
    order_1_17  connected_order_arc_993  -1
    order_1_17  connected_order_arc_995  -1
    order_1_17  connected_order_arc_997  -1
    order_1_17  connected_order_arc_999  -1
    order_1_17  connected_order_arc_1001  -1
    order_1_17  connected_order_arc_1003  -1
    order_1_17  connected_order_arc_1005  -1
    order_1_17  connected_order_arc_1007  -1
    order_1_17  connected_order_arc_1026  1
    order_1_17  connected_order_arc_1049  1
    order_1_17  connected_order_arc_1072  1
    order_1_17  order_active_lb_1133  1
    order_1_17  order_active_ub_1134  1
    visit_1_18  out_degree_1137  -1
    visit_1_18  in_degree_1138  -1
    visit_1_18  order_active_lb_1139  -1
    visit_1_18  order_active_ub_1140  -12
    visit_1_18  service_visit_def_1141  -1
    order_1_18  connected_order_arc_819  1
    order_1_18  connected_order_arc_842  1
    order_1_18  connected_order_arc_865  1
    order_1_18  connected_order_arc_888  1
    order_1_18  connected_order_arc_911  1
    order_1_18  connected_order_arc_934  1
    order_1_18  connected_order_arc_957  1
    order_1_18  connected_order_arc_980  1
    order_1_18  connected_order_arc_1003  1
    order_1_18  connected_order_arc_1010  -1
    order_1_18  connected_order_arc_1012  -1
    order_1_18  connected_order_arc_1014  -1
    order_1_18  connected_order_arc_1016  -1
    order_1_18  connected_order_arc_1018  -1
    order_1_18  connected_order_arc_1020  -1
    order_1_18  connected_order_arc_1022  -1
    order_1_18  connected_order_arc_1024  -1
    order_1_18  connected_order_arc_1026  -1
    order_1_18  connected_order_arc_1028  -1
    order_1_18  connected_order_arc_1030  -1
    order_1_18  connected_order_arc_1051  1
    order_1_18  connected_order_arc_1074  1
    order_1_18  order_active_lb_1139  1
    order_1_18  order_active_ub_1140  1
    visit_1_19  out_degree_1143  -1
    visit_1_19  in_degree_1144  -1
    visit_1_19  order_active_lb_1145  -1
    visit_1_19  order_active_ub_1146  -12
    visit_1_19  service_visit_def_1147  -1
    order_1_19  connected_order_arc_821  1
    order_1_19  connected_order_arc_844  1
    order_1_19  connected_order_arc_867  1
    order_1_19  connected_order_arc_890  1
    order_1_19  connected_order_arc_913  1
    order_1_19  connected_order_arc_936  1
    order_1_19  connected_order_arc_959  1
    order_1_19  connected_order_arc_982  1
    order_1_19  connected_order_arc_1005  1
    order_1_19  connected_order_arc_1028  1
    order_1_19  connected_order_arc_1033  -1
    order_1_19  connected_order_arc_1035  -1
    order_1_19  connected_order_arc_1037  -1
    order_1_19  connected_order_arc_1039  -1
    order_1_19  connected_order_arc_1041  -1
    order_1_19  connected_order_arc_1043  -1
    order_1_19  connected_order_arc_1045  -1
    order_1_19  connected_order_arc_1047  -1
    order_1_19  connected_order_arc_1049  -1
    order_1_19  connected_order_arc_1051  -1
    order_1_19  connected_order_arc_1053  -1
    order_1_19  connected_order_arc_1076  1
    order_1_19  order_active_lb_1145  1
    order_1_19  order_active_ub_1146  1
    visit_1_20  out_degree_1149  -1
    visit_1_20  in_degree_1150  -1
    visit_1_20  order_active_lb_1151  -1
    visit_1_20  order_active_ub_1152  -12
    visit_1_20  service_visit_def_1153  -1
    order_1_20  connected_order_arc_823  1
    order_1_20  connected_order_arc_846  1
    order_1_20  connected_order_arc_869  1
    order_1_20  connected_order_arc_892  1
    order_1_20  connected_order_arc_915  1
    order_1_20  connected_order_arc_938  1
    order_1_20  connected_order_arc_961  1
    order_1_20  connected_order_arc_984  1
    order_1_20  connected_order_arc_1007  1
    order_1_20  connected_order_arc_1030  1
    order_1_20  connected_order_arc_1053  1
    order_1_20  connected_order_arc_1056  -1
    order_1_20  connected_order_arc_1058  -1
    order_1_20  connected_order_arc_1060  -1
    order_1_20  connected_order_arc_1062  -1
    order_1_20  connected_order_arc_1064  -1
    order_1_20  connected_order_arc_1066  -1
    order_1_20  connected_order_arc_1068  -1
    order_1_20  connected_order_arc_1070  -1
    order_1_20  connected_order_arc_1072  -1
    order_1_20  connected_order_arc_1074  -1
    order_1_20  connected_order_arc_1076  -1
    order_1_20  order_active_lb_1151  1
    order_1_20  order_active_ub_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_788  -25
    arc_1_0_0  depot_departure_or_bypass_1077  1
    arc_1_0_0  depot_return_or_bypass_1078  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_789  -25
    arc_1_0_6  depot_departure_or_bypass_1077  1
    arc_1_0_6  in_degree_1080  1
    arc_1_0_6  original_T_including_depot_unload_1158  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_789  1
    load_1_0_6  segment_load_conservation_1083  -1
    load_1_0_6  segment_prefix_lb_1084  1
    load_1_0_6  segment_prefix_ub_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_790  -25
    arc_1_0_7  depot_departure_or_bypass_1077  1
    arc_1_0_7  in_degree_1087  1
    arc_1_0_7  original_T_including_depot_unload_1158  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_790  1
    load_1_0_7  segment_load_conservation_1090  -1
    load_1_0_7  segment_prefix_lb_1091  1
    load_1_0_7  segment_prefix_ub_1092  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_791  -25
    arc_1_0_8  depot_departure_or_bypass_1077  1
    arc_1_0_8  in_degree_1094  1
    arc_1_0_8  original_T_including_depot_unload_1158  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_791  1
    load_1_0_8  segment_load_conservation_1097  -1
    load_1_0_8  segment_prefix_lb_1098  1
    load_1_0_8  segment_prefix_ub_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_792  -25
    arc_1_0_9  depot_departure_or_bypass_1077  1
    arc_1_0_9  in_degree_1101  1
    arc_1_0_9  original_T_including_depot_unload_1158  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_792  1
    load_1_0_9  segment_load_conservation_1104  -1
    load_1_0_9  segment_prefix_lb_1105  1
    load_1_0_9  segment_prefix_ub_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_793  -25
    arc_1_0_13  depot_departure_or_bypass_1077  1
    arc_1_0_13  in_degree_1108  1
    arc_1_0_13  original_T_including_depot_unload_1158  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_793  1
    load_1_0_13  free_load_conservation_1112  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_794  -25
    arc_1_0_14  depot_departure_or_bypass_1077  1
    arc_1_0_14  in_degree_1114  1
    arc_1_0_14  original_T_including_depot_unload_1158  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_794  1
    load_1_0_14  free_load_conservation_1118  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_795  -25
    arc_1_0_15  depot_departure_or_bypass_1077  1
    arc_1_0_15  in_degree_1120  1
    arc_1_0_15  original_T_including_depot_unload_1158  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_795  1
    load_1_0_15  free_load_conservation_1124  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_796  -25
    arc_1_0_16  depot_departure_or_bypass_1077  1
    arc_1_0_16  in_degree_1126  1
    arc_1_0_16  original_T_including_depot_unload_1158  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_796  1
    load_1_0_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_797  -25
    arc_1_0_17  depot_departure_or_bypass_1077  1
    arc_1_0_17  in_degree_1132  1
    arc_1_0_17  original_T_including_depot_unload_1158  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_797  1
    load_1_0_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_798  -25
    arc_1_0_18  depot_departure_or_bypass_1077  1
    arc_1_0_18  in_degree_1138  1
    arc_1_0_18  original_T_including_depot_unload_1158  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_798  1
    load_1_0_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_799  -25
    arc_1_0_19  depot_departure_or_bypass_1077  1
    arc_1_0_19  in_degree_1144  1
    arc_1_0_19  original_T_including_depot_unload_1158  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_799  1
    load_1_0_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_800  -25
    arc_1_0_20  depot_departure_or_bypass_1077  1
    arc_1_0_20  in_degree_1150  1
    arc_1_0_20  original_T_including_depot_unload_1158  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_800  1
    load_1_0_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_801  -25
    arc_1_6_0  depot_return_or_bypass_1078  1
    arc_1_6_0  out_degree_1079  1
    arc_1_6_0  original_T_including_depot_unload_1158  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_801  1
    load_1_6_0  segment_load_conservation_1083  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_802  -25
    arc_1_6_7  connected_order_arc_803  -13
    arc_1_6_7  out_degree_1079  1
    arc_1_6_7  in_degree_1087  1
    arc_1_6_7  original_T_including_depot_unload_1158  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_802  1
    load_1_6_7  segment_load_conservation_1083  1
    load_1_6_7  segment_load_conservation_1090  -1
    load_1_6_7  segment_prefix_lb_1091  1
    load_1_6_7  segment_prefix_ub_1092  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_804  -25
    arc_1_6_8  connected_order_arc_805  -13
    arc_1_6_8  out_degree_1079  1
    arc_1_6_8  in_degree_1094  1
    arc_1_6_8  original_T_including_depot_unload_1158  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_804  1
    load_1_6_8  segment_load_conservation_1083  1
    load_1_6_8  segment_load_conservation_1097  -1
    load_1_6_8  segment_prefix_lb_1098  1
    load_1_6_8  segment_prefix_ub_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_806  -25
    arc_1_6_9  connected_order_arc_807  -13
    arc_1_6_9  out_degree_1079  1
    arc_1_6_9  in_degree_1101  1
    arc_1_6_9  original_T_including_depot_unload_1158  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_806  1
    load_1_6_9  segment_load_conservation_1083  1
    load_1_6_9  segment_load_conservation_1104  -1
    load_1_6_9  segment_prefix_lb_1105  1
    load_1_6_9  segment_prefix_ub_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_808  -25
    arc_1_6_13  connected_order_arc_809  -13
    arc_1_6_13  out_degree_1079  1
    arc_1_6_13  in_degree_1108  1
    arc_1_6_13  original_T_including_depot_unload_1158  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_808  1
    load_1_6_13  segment_load_conservation_1083  1
    load_1_6_13  free_load_conservation_1112  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_810  -25
    arc_1_6_14  connected_order_arc_811  -13
    arc_1_6_14  out_degree_1079  1
    arc_1_6_14  in_degree_1114  1
    arc_1_6_14  original_T_including_depot_unload_1158  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_810  1
    load_1_6_14  segment_load_conservation_1083  1
    load_1_6_14  free_load_conservation_1118  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_812  -25
    arc_1_6_15  connected_order_arc_813  -13
    arc_1_6_15  out_degree_1079  1
    arc_1_6_15  in_degree_1120  1
    arc_1_6_15  original_T_including_depot_unload_1158  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_812  1
    load_1_6_15  segment_load_conservation_1083  1
    load_1_6_15  free_load_conservation_1124  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_814  -25
    arc_1_6_16  connected_order_arc_815  -13
    arc_1_6_16  out_degree_1079  1
    arc_1_6_16  in_degree_1126  1
    arc_1_6_16  original_T_including_depot_unload_1158  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_814  1
    load_1_6_16  segment_load_conservation_1083  1
    load_1_6_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_816  -25
    arc_1_6_17  connected_order_arc_817  -13
    arc_1_6_17  out_degree_1079  1
    arc_1_6_17  in_degree_1132  1
    arc_1_6_17  original_T_including_depot_unload_1158  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_816  1
    load_1_6_17  segment_load_conservation_1083  1
    load_1_6_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_818  -25
    arc_1_6_18  connected_order_arc_819  -13
    arc_1_6_18  out_degree_1079  1
    arc_1_6_18  in_degree_1138  1
    arc_1_6_18  original_T_including_depot_unload_1158  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_818  1
    load_1_6_18  segment_load_conservation_1083  1
    load_1_6_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_820  -25
    arc_1_6_19  connected_order_arc_821  -13
    arc_1_6_19  out_degree_1079  1
    arc_1_6_19  in_degree_1144  1
    arc_1_6_19  original_T_including_depot_unload_1158  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_820  1
    load_1_6_19  segment_load_conservation_1083  1
    load_1_6_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_822  -25
    arc_1_6_20  connected_order_arc_823  -13
    arc_1_6_20  out_degree_1079  1
    arc_1_6_20  in_degree_1150  1
    arc_1_6_20  original_T_including_depot_unload_1158  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_822  1
    load_1_6_20  segment_load_conservation_1083  1
    load_1_6_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_824  -25
    arc_1_7_0  depot_return_or_bypass_1078  1
    arc_1_7_0  out_degree_1086  1
    arc_1_7_0  original_T_including_depot_unload_1158  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_824  1
    load_1_7_0  segment_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_825  -25
    arc_1_7_6  connected_order_arc_826  -13
    arc_1_7_6  in_degree_1080  1
    arc_1_7_6  out_degree_1086  1
    arc_1_7_6  original_T_including_depot_unload_1158  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_825  1
    load_1_7_6  segment_load_conservation_1083  -1
    load_1_7_6  segment_prefix_lb_1084  1
    load_1_7_6  segment_prefix_ub_1085  1
    load_1_7_6  segment_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_827  -25
    arc_1_7_8  connected_order_arc_828  -13
    arc_1_7_8  out_degree_1086  1
    arc_1_7_8  in_degree_1094  1
    arc_1_7_8  original_T_including_depot_unload_1158  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_827  1
    load_1_7_8  segment_load_conservation_1090  1
    load_1_7_8  segment_load_conservation_1097  -1
    load_1_7_8  segment_prefix_lb_1098  1
    load_1_7_8  segment_prefix_ub_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_829  -25
    arc_1_7_9  connected_order_arc_830  -13
    arc_1_7_9  out_degree_1086  1
    arc_1_7_9  in_degree_1101  1
    arc_1_7_9  original_T_including_depot_unload_1158  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_829  1
    load_1_7_9  segment_load_conservation_1090  1
    load_1_7_9  segment_load_conservation_1104  -1
    load_1_7_9  segment_prefix_lb_1105  1
    load_1_7_9  segment_prefix_ub_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_831  -25
    arc_1_7_13  connected_order_arc_832  -13
    arc_1_7_13  out_degree_1086  1
    arc_1_7_13  in_degree_1108  1
    arc_1_7_13  original_T_including_depot_unload_1158  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_831  1
    load_1_7_13  segment_load_conservation_1090  1
    load_1_7_13  free_load_conservation_1112  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_833  -25
    arc_1_7_14  connected_order_arc_834  -13
    arc_1_7_14  out_degree_1086  1
    arc_1_7_14  in_degree_1114  1
    arc_1_7_14  original_T_including_depot_unload_1158  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_833  1
    load_1_7_14  segment_load_conservation_1090  1
    load_1_7_14  free_load_conservation_1118  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_835  -25
    arc_1_7_15  connected_order_arc_836  -13
    arc_1_7_15  out_degree_1086  1
    arc_1_7_15  in_degree_1120  1
    arc_1_7_15  original_T_including_depot_unload_1158  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_835  1
    load_1_7_15  segment_load_conservation_1090  1
    load_1_7_15  free_load_conservation_1124  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_837  -25
    arc_1_7_16  connected_order_arc_838  -13
    arc_1_7_16  out_degree_1086  1
    arc_1_7_16  in_degree_1126  1
    arc_1_7_16  original_T_including_depot_unload_1158  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_837  1
    load_1_7_16  segment_load_conservation_1090  1
    load_1_7_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_839  -25
    arc_1_7_17  connected_order_arc_840  -13
    arc_1_7_17  out_degree_1086  1
    arc_1_7_17  in_degree_1132  1
    arc_1_7_17  original_T_including_depot_unload_1158  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_839  1
    load_1_7_17  segment_load_conservation_1090  1
    load_1_7_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_841  -25
    arc_1_7_18  connected_order_arc_842  -13
    arc_1_7_18  out_degree_1086  1
    arc_1_7_18  in_degree_1138  1
    arc_1_7_18  original_T_including_depot_unload_1158  2.9105426006346024e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_841  1
    load_1_7_18  segment_load_conservation_1090  1
    load_1_7_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_843  -25
    arc_1_7_19  connected_order_arc_844  -13
    arc_1_7_19  out_degree_1086  1
    arc_1_7_19  in_degree_1144  1
    arc_1_7_19  original_T_including_depot_unload_1158  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_843  1
    load_1_7_19  segment_load_conservation_1090  1
    load_1_7_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_845  -25
    arc_1_7_20  connected_order_arc_846  -13
    arc_1_7_20  out_degree_1086  1
    arc_1_7_20  in_degree_1150  1
    arc_1_7_20  original_T_including_depot_unload_1158  2.9939628790517750e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_845  1
    load_1_7_20  segment_load_conservation_1090  1
    load_1_7_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_847  -25
    arc_1_8_0  depot_return_or_bypass_1078  1
    arc_1_8_0  out_degree_1093  1
    arc_1_8_0  original_T_including_depot_unload_1158  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_847  1
    load_1_8_0  segment_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_848  -25
    arc_1_8_6  connected_order_arc_849  -13
    arc_1_8_6  in_degree_1080  1
    arc_1_8_6  out_degree_1093  1
    arc_1_8_6  original_T_including_depot_unload_1158  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_848  1
    load_1_8_6  segment_load_conservation_1083  -1
    load_1_8_6  segment_prefix_lb_1084  1
    load_1_8_6  segment_prefix_ub_1085  1
    load_1_8_6  segment_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_850  -25
    arc_1_8_7  connected_order_arc_851  -13
    arc_1_8_7  in_degree_1087  1
    arc_1_8_7  out_degree_1093  1
    arc_1_8_7  original_T_including_depot_unload_1158  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_850  1
    load_1_8_7  segment_load_conservation_1090  -1
    load_1_8_7  segment_prefix_lb_1091  1
    load_1_8_7  segment_prefix_ub_1092  1
    load_1_8_7  segment_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_852  -25
    arc_1_8_9  connected_order_arc_853  -13
    arc_1_8_9  out_degree_1093  1
    arc_1_8_9  in_degree_1101  1
    arc_1_8_9  original_T_including_depot_unload_1158  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_852  1
    load_1_8_9  segment_load_conservation_1097  1
    load_1_8_9  segment_load_conservation_1104  -1
    load_1_8_9  segment_prefix_lb_1105  1
    load_1_8_9  segment_prefix_ub_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_854  -25
    arc_1_8_13  connected_order_arc_855  -13
    arc_1_8_13  out_degree_1093  1
    arc_1_8_13  in_degree_1108  1
    arc_1_8_13  original_T_including_depot_unload_1158  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_854  1
    load_1_8_13  segment_load_conservation_1097  1
    load_1_8_13  free_load_conservation_1112  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_856  -25
    arc_1_8_14  connected_order_arc_857  -13
    arc_1_8_14  out_degree_1093  1
    arc_1_8_14  in_degree_1114  1
    arc_1_8_14  original_T_including_depot_unload_1158  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_856  1
    load_1_8_14  segment_load_conservation_1097  1
    load_1_8_14  free_load_conservation_1118  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_858  -25
    arc_1_8_15  connected_order_arc_859  -13
    arc_1_8_15  out_degree_1093  1
    arc_1_8_15  in_degree_1120  1
    arc_1_8_15  original_T_including_depot_unload_1158  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_858  1
    load_1_8_15  segment_load_conservation_1097  1
    load_1_8_15  free_load_conservation_1124  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_860  -25
    arc_1_8_16  connected_order_arc_861  -13
    arc_1_8_16  out_degree_1093  1
    arc_1_8_16  in_degree_1126  1
    arc_1_8_16  original_T_including_depot_unload_1158  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_860  1
    load_1_8_16  segment_load_conservation_1097  1
    load_1_8_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_862  -25
    arc_1_8_17  connected_order_arc_863  -13
    arc_1_8_17  out_degree_1093  1
    arc_1_8_17  in_degree_1132  1
    arc_1_8_17  original_T_including_depot_unload_1158  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_862  1
    load_1_8_17  segment_load_conservation_1097  1
    load_1_8_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_864  -25
    arc_1_8_18  connected_order_arc_865  -13
    arc_1_8_18  out_degree_1093  1
    arc_1_8_18  in_degree_1138  1
    arc_1_8_18  original_T_including_depot_unload_1158  1.9370748198308336e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_864  1
    load_1_8_18  segment_load_conservation_1097  1
    load_1_8_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_866  -25
    arc_1_8_19  connected_order_arc_867  -13
    arc_1_8_19  out_degree_1093  1
    arc_1_8_19  in_degree_1144  1
    arc_1_8_19  original_T_including_depot_unload_1158  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_866  1
    load_1_8_19  segment_load_conservation_1097  1
    load_1_8_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_868  -25
    arc_1_8_20  connected_order_arc_869  -13
    arc_1_8_20  out_degree_1093  1
    arc_1_8_20  in_degree_1150  1
    arc_1_8_20  original_T_including_depot_unload_1158  2.0264134980919391e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_868  1
    load_1_8_20  segment_load_conservation_1097  1
    load_1_8_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_870  -25
    arc_1_9_0  depot_return_or_bypass_1078  1
    arc_1_9_0  out_degree_1100  1
    arc_1_9_0  original_T_including_depot_unload_1158  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_870  1
    load_1_9_0  segment_load_conservation_1104  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_871  -25
    arc_1_9_6  connected_order_arc_872  -13
    arc_1_9_6  in_degree_1080  1
    arc_1_9_6  out_degree_1100  1
    arc_1_9_6  original_T_including_depot_unload_1158  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_871  1
    load_1_9_6  segment_load_conservation_1083  -1
    load_1_9_6  segment_prefix_lb_1084  1
    load_1_9_6  segment_prefix_ub_1085  1
    load_1_9_6  segment_load_conservation_1104  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_873  -25
    arc_1_9_7  connected_order_arc_874  -13
    arc_1_9_7  in_degree_1087  1
    arc_1_9_7  out_degree_1100  1
    arc_1_9_7  original_T_including_depot_unload_1158  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_873  1
    load_1_9_7  segment_load_conservation_1090  -1
    load_1_9_7  segment_prefix_lb_1091  1
    load_1_9_7  segment_prefix_ub_1092  1
    load_1_9_7  segment_load_conservation_1104  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_875  -25
    arc_1_9_8  connected_order_arc_876  -13
    arc_1_9_8  in_degree_1094  1
    arc_1_9_8  out_degree_1100  1
    arc_1_9_8  original_T_including_depot_unload_1158  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_875  1
    load_1_9_8  segment_load_conservation_1097  -1
    load_1_9_8  segment_prefix_lb_1098  1
    load_1_9_8  segment_prefix_ub_1099  1
    load_1_9_8  segment_load_conservation_1104  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_877  -25
    arc_1_9_13  connected_order_arc_878  -13
    arc_1_9_13  out_degree_1100  1
    arc_1_9_13  in_degree_1108  1
    arc_1_9_13  original_T_including_depot_unload_1158  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_877  1
    load_1_9_13  segment_load_conservation_1104  1
    load_1_9_13  free_load_conservation_1112  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_879  -25
    arc_1_9_14  connected_order_arc_880  -13
    arc_1_9_14  out_degree_1100  1
    arc_1_9_14  in_degree_1114  1
    arc_1_9_14  original_T_including_depot_unload_1158  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_879  1
    load_1_9_14  segment_load_conservation_1104  1
    load_1_9_14  free_load_conservation_1118  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_881  -25
    arc_1_9_15  connected_order_arc_882  -13
    arc_1_9_15  out_degree_1100  1
    arc_1_9_15  in_degree_1120  1
    arc_1_9_15  original_T_including_depot_unload_1158  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_881  1
    load_1_9_15  segment_load_conservation_1104  1
    load_1_9_15  free_load_conservation_1124  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_883  -25
    arc_1_9_16  connected_order_arc_884  -13
    arc_1_9_16  out_degree_1100  1
    arc_1_9_16  in_degree_1126  1
    arc_1_9_16  original_T_including_depot_unload_1158  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_883  1
    load_1_9_16  segment_load_conservation_1104  1
    load_1_9_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_885  -25
    arc_1_9_17  connected_order_arc_886  -13
    arc_1_9_17  out_degree_1100  1
    arc_1_9_17  in_degree_1132  1
    arc_1_9_17  original_T_including_depot_unload_1158  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_885  1
    load_1_9_17  segment_load_conservation_1104  1
    load_1_9_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_887  -25
    arc_1_9_18  connected_order_arc_888  -13
    arc_1_9_18  out_degree_1100  1
    arc_1_9_18  in_degree_1138  1
    arc_1_9_18  original_T_including_depot_unload_1158  1.6359122202972637e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_887  1
    load_1_9_18  segment_load_conservation_1104  1
    load_1_9_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_889  -25
    arc_1_9_19  connected_order_arc_890  -13
    arc_1_9_19  out_degree_1100  1
    arc_1_9_19  in_degree_1144  1
    arc_1_9_19  original_T_including_depot_unload_1158  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_889  1
    load_1_9_19  segment_load_conservation_1104  1
    load_1_9_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_891  -25
    arc_1_9_20  connected_order_arc_892  -13
    arc_1_9_20  out_degree_1100  1
    arc_1_9_20  in_degree_1150  1
    arc_1_9_20  original_T_including_depot_unload_1158  1.7203273996041773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_891  1
    load_1_9_20  segment_load_conservation_1104  1
    load_1_9_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_893  -25
    arc_1_13_0  depot_return_or_bypass_1078  1
    arc_1_13_0  out_degree_1107  1
    arc_1_13_0  original_T_including_depot_unload_1158  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_893  1
    load_1_13_0  free_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_894  -25
    arc_1_13_6  connected_order_arc_895  -13
    arc_1_13_6  in_degree_1080  1
    arc_1_13_6  out_degree_1107  1
    arc_1_13_6  original_T_including_depot_unload_1158  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_894  1
    load_1_13_6  segment_load_conservation_1083  -1
    load_1_13_6  segment_prefix_lb_1084  1
    load_1_13_6  segment_prefix_ub_1085  1
    load_1_13_6  free_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_896  -25
    arc_1_13_7  connected_order_arc_897  -13
    arc_1_13_7  in_degree_1087  1
    arc_1_13_7  out_degree_1107  1
    arc_1_13_7  original_T_including_depot_unload_1158  1.4636929855741182e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_896  1
    load_1_13_7  segment_load_conservation_1090  -1
    load_1_13_7  segment_prefix_lb_1091  1
    load_1_13_7  segment_prefix_ub_1092  1
    load_1_13_7  free_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_898  -25
    arc_1_13_8  connected_order_arc_899  -13
    arc_1_13_8  in_degree_1094  1
    arc_1_13_8  out_degree_1107  1
    arc_1_13_8  original_T_including_depot_unload_1158  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_898  1
    load_1_13_8  segment_load_conservation_1097  -1
    load_1_13_8  segment_prefix_lb_1098  1
    load_1_13_8  segment_prefix_ub_1099  1
    load_1_13_8  free_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_900  -25
    arc_1_13_9  connected_order_arc_901  -13
    arc_1_13_9  in_degree_1101  1
    arc_1_13_9  out_degree_1107  1
    arc_1_13_9  original_T_including_depot_unload_1158  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_900  1
    load_1_13_9  segment_load_conservation_1104  -1
    load_1_13_9  segment_prefix_lb_1105  1
    load_1_13_9  segment_prefix_ub_1106  1
    load_1_13_9  free_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_902  -25
    arc_1_13_14  connected_order_arc_903  -13
    arc_1_13_14  out_degree_1107  1
    arc_1_13_14  in_degree_1114  1
    arc_1_13_14  original_T_including_depot_unload_1158  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_902  1
    load_1_13_14  free_load_conservation_1112  1
    load_1_13_14  free_load_conservation_1118  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_904  -25
    arc_1_13_15  connected_order_arc_905  -13
    arc_1_13_15  out_degree_1107  1
    arc_1_13_15  in_degree_1120  1
    arc_1_13_15  original_T_including_depot_unload_1158  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_904  1
    load_1_13_15  free_load_conservation_1112  1
    load_1_13_15  free_load_conservation_1124  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_906  -25
    arc_1_13_16  connected_order_arc_907  -13
    arc_1_13_16  out_degree_1107  1
    arc_1_13_16  in_degree_1126  1
    arc_1_13_16  original_T_including_depot_unload_1158  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_906  1
    load_1_13_16  free_load_conservation_1112  1
    load_1_13_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_908  -25
    arc_1_13_17  connected_order_arc_909  -13
    arc_1_13_17  out_degree_1107  1
    arc_1_13_17  in_degree_1132  1
    arc_1_13_17  original_T_including_depot_unload_1158  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_908  1
    load_1_13_17  free_load_conservation_1112  1
    load_1_13_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_910  -25
    arc_1_13_18  connected_order_arc_911  -13
    arc_1_13_18  out_degree_1107  1
    arc_1_13_18  in_degree_1138  1
    arc_1_13_18  original_T_including_depot_unload_1158  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_910  1
    load_1_13_18  free_load_conservation_1112  1
    load_1_13_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_912  -25
    arc_1_13_19  connected_order_arc_913  -13
    arc_1_13_19  out_degree_1107  1
    arc_1_13_19  in_degree_1144  1
    arc_1_13_19  original_T_including_depot_unload_1158  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_912  1
    load_1_13_19  free_load_conservation_1112  1
    load_1_13_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_914  -25
    arc_1_13_20  connected_order_arc_915  -13
    arc_1_13_20  out_degree_1107  1
    arc_1_13_20  in_degree_1150  1
    arc_1_13_20  original_T_including_depot_unload_1158  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_914  1
    load_1_13_20  free_load_conservation_1112  1
    load_1_13_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_916  -25
    arc_1_14_0  depot_return_or_bypass_1078  1
    arc_1_14_0  out_degree_1113  1
    arc_1_14_0  original_T_including_depot_unload_1158  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_916  1
    load_1_14_0  free_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_917  -25
    arc_1_14_6  connected_order_arc_918  -13
    arc_1_14_6  in_degree_1080  1
    arc_1_14_6  out_degree_1113  1
    arc_1_14_6  original_T_including_depot_unload_1158  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_917  1
    load_1_14_6  segment_load_conservation_1083  -1
    load_1_14_6  segment_prefix_lb_1084  1
    load_1_14_6  segment_prefix_ub_1085  1
    load_1_14_6  free_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_919  -25
    arc_1_14_7  connected_order_arc_920  -13
    arc_1_14_7  in_degree_1087  1
    arc_1_14_7  out_degree_1113  1
    arc_1_14_7  original_T_including_depot_unload_1158  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_919  1
    load_1_14_7  segment_load_conservation_1090  -1
    load_1_14_7  segment_prefix_lb_1091  1
    load_1_14_7  segment_prefix_ub_1092  1
    load_1_14_7  free_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_921  -25
    arc_1_14_8  connected_order_arc_922  -13
    arc_1_14_8  in_degree_1094  1
    arc_1_14_8  out_degree_1113  1
    arc_1_14_8  original_T_including_depot_unload_1158  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_921  1
    load_1_14_8  segment_load_conservation_1097  -1
    load_1_14_8  segment_prefix_lb_1098  1
    load_1_14_8  segment_prefix_ub_1099  1
    load_1_14_8  free_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_923  -25
    arc_1_14_9  connected_order_arc_924  -13
    arc_1_14_9  in_degree_1101  1
    arc_1_14_9  out_degree_1113  1
    arc_1_14_9  original_T_including_depot_unload_1158  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_923  1
    load_1_14_9  segment_load_conservation_1104  -1
    load_1_14_9  segment_prefix_lb_1105  1
    load_1_14_9  segment_prefix_ub_1106  1
    load_1_14_9  free_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_925  -25
    arc_1_14_13  connected_order_arc_926  -13
    arc_1_14_13  in_degree_1108  1
    arc_1_14_13  out_degree_1113  1
    arc_1_14_13  original_T_including_depot_unload_1158  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_925  1
    load_1_14_13  free_load_conservation_1112  -1
    load_1_14_13  free_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_927  -25
    arc_1_14_15  connected_order_arc_928  -13
    arc_1_14_15  out_degree_1113  1
    arc_1_14_15  in_degree_1120  1
    arc_1_14_15  original_T_including_depot_unload_1158  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_927  1
    load_1_14_15  free_load_conservation_1118  1
    load_1_14_15  free_load_conservation_1124  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_929  -25
    arc_1_14_16  connected_order_arc_930  -13
    arc_1_14_16  out_degree_1113  1
    arc_1_14_16  in_degree_1126  1
    arc_1_14_16  original_T_including_depot_unload_1158  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_929  1
    load_1_14_16  free_load_conservation_1118  1
    load_1_14_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_931  -25
    arc_1_14_17  connected_order_arc_932  -13
    arc_1_14_17  out_degree_1113  1
    arc_1_14_17  in_degree_1132  1
    arc_1_14_17  original_T_including_depot_unload_1158  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_931  1
    load_1_14_17  free_load_conservation_1118  1
    load_1_14_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_933  -25
    arc_1_14_18  connected_order_arc_934  -13
    arc_1_14_18  out_degree_1113  1
    arc_1_14_18  in_degree_1138  1
    arc_1_14_18  original_T_including_depot_unload_1158  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_933  1
    load_1_14_18  free_load_conservation_1118  1
    load_1_14_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_935  -25
    arc_1_14_19  connected_order_arc_936  -13
    arc_1_14_19  out_degree_1113  1
    arc_1_14_19  in_degree_1144  1
    arc_1_14_19  original_T_including_depot_unload_1158  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_935  1
    load_1_14_19  free_load_conservation_1118  1
    load_1_14_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_937  -25
    arc_1_14_20  connected_order_arc_938  -13
    arc_1_14_20  out_degree_1113  1
    arc_1_14_20  in_degree_1150  1
    arc_1_14_20  original_T_including_depot_unload_1158  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_937  1
    load_1_14_20  free_load_conservation_1118  1
    load_1_14_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_939  -25
    arc_1_15_0  depot_return_or_bypass_1078  1
    arc_1_15_0  out_degree_1119  1
    arc_1_15_0  original_T_including_depot_unload_1158  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_939  1
    load_1_15_0  free_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_940  -25
    arc_1_15_6  connected_order_arc_941  -13
    arc_1_15_6  in_degree_1080  1
    arc_1_15_6  out_degree_1119  1
    arc_1_15_6  original_T_including_depot_unload_1158  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_940  1
    load_1_15_6  segment_load_conservation_1083  -1
    load_1_15_6  segment_prefix_lb_1084  1
    load_1_15_6  segment_prefix_ub_1085  1
    load_1_15_6  free_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_942  -25
    arc_1_15_7  connected_order_arc_943  -13
    arc_1_15_7  in_degree_1087  1
    arc_1_15_7  out_degree_1119  1
    arc_1_15_7  original_T_including_depot_unload_1158  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_942  1
    load_1_15_7  segment_load_conservation_1090  -1
    load_1_15_7  segment_prefix_lb_1091  1
    load_1_15_7  segment_prefix_ub_1092  1
    load_1_15_7  free_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_944  -25
    arc_1_15_8  connected_order_arc_945  -13
    arc_1_15_8  in_degree_1094  1
    arc_1_15_8  out_degree_1119  1
    arc_1_15_8  original_T_including_depot_unload_1158  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_944  1
    load_1_15_8  segment_load_conservation_1097  -1
    load_1_15_8  segment_prefix_lb_1098  1
    load_1_15_8  segment_prefix_ub_1099  1
    load_1_15_8  free_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_946  -25
    arc_1_15_9  connected_order_arc_947  -13
    arc_1_15_9  in_degree_1101  1
    arc_1_15_9  out_degree_1119  1
    arc_1_15_9  original_T_including_depot_unload_1158  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_946  1
    load_1_15_9  segment_load_conservation_1104  -1
    load_1_15_9  segment_prefix_lb_1105  1
    load_1_15_9  segment_prefix_ub_1106  1
    load_1_15_9  free_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_948  -25
    arc_1_15_13  connected_order_arc_949  -13
    arc_1_15_13  in_degree_1108  1
    arc_1_15_13  out_degree_1119  1
    arc_1_15_13  original_T_including_depot_unload_1158  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_948  1
    load_1_15_13  free_load_conservation_1112  -1
    load_1_15_13  free_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_950  -25
    arc_1_15_14  connected_order_arc_951  -13
    arc_1_15_14  in_degree_1114  1
    arc_1_15_14  out_degree_1119  1
    arc_1_15_14  original_T_including_depot_unload_1158  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_950  1
    load_1_15_14  free_load_conservation_1118  -1
    load_1_15_14  free_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_952  -25
    arc_1_15_16  connected_order_arc_953  -13
    arc_1_15_16  out_degree_1119  1
    arc_1_15_16  in_degree_1126  1
    arc_1_15_16  original_T_including_depot_unload_1158  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_952  1
    load_1_15_16  free_load_conservation_1124  1
    load_1_15_16  free_load_conservation_1130  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_954  -25
    arc_1_15_17  connected_order_arc_955  -13
    arc_1_15_17  out_degree_1119  1
    arc_1_15_17  in_degree_1132  1
    arc_1_15_17  original_T_including_depot_unload_1158  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_954  1
    load_1_15_17  free_load_conservation_1124  1
    load_1_15_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_956  -25
    arc_1_15_18  connected_order_arc_957  -13
    arc_1_15_18  out_degree_1119  1
    arc_1_15_18  in_degree_1138  1
    arc_1_15_18  original_T_including_depot_unload_1158  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_956  1
    load_1_15_18  free_load_conservation_1124  1
    load_1_15_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_958  -25
    arc_1_15_19  connected_order_arc_959  -13
    arc_1_15_19  out_degree_1119  1
    arc_1_15_19  in_degree_1144  1
    arc_1_15_19  original_T_including_depot_unload_1158  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_958  1
    load_1_15_19  free_load_conservation_1124  1
    load_1_15_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_960  -25
    arc_1_15_20  connected_order_arc_961  -13
    arc_1_15_20  out_degree_1119  1
    arc_1_15_20  in_degree_1150  1
    arc_1_15_20  original_T_including_depot_unload_1158  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_960  1
    load_1_15_20  free_load_conservation_1124  1
    load_1_15_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_962  -25
    arc_1_16_0  depot_return_or_bypass_1078  1
    arc_1_16_0  out_degree_1125  1
    arc_1_16_0  original_T_including_depot_unload_1158  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_962  1
    load_1_16_0  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_963  -25
    arc_1_16_6  connected_order_arc_964  -13
    arc_1_16_6  in_degree_1080  1
    arc_1_16_6  out_degree_1125  1
    arc_1_16_6  original_T_including_depot_unload_1158  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_963  1
    load_1_16_6  segment_load_conservation_1083  -1
    load_1_16_6  segment_prefix_lb_1084  1
    load_1_16_6  segment_prefix_ub_1085  1
    load_1_16_6  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_965  -25
    arc_1_16_7  connected_order_arc_966  -13
    arc_1_16_7  in_degree_1087  1
    arc_1_16_7  out_degree_1125  1
    arc_1_16_7  original_T_including_depot_unload_1158  1.3923205390152336e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_965  1
    load_1_16_7  segment_load_conservation_1090  -1
    load_1_16_7  segment_prefix_lb_1091  1
    load_1_16_7  segment_prefix_ub_1092  1
    load_1_16_7  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_967  -25
    arc_1_16_8  connected_order_arc_968  -13
    arc_1_16_8  in_degree_1094  1
    arc_1_16_8  out_degree_1125  1
    arc_1_16_8  original_T_including_depot_unload_1158  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_967  1
    load_1_16_8  segment_load_conservation_1097  -1
    load_1_16_8  segment_prefix_lb_1098  1
    load_1_16_8  segment_prefix_ub_1099  1
    load_1_16_8  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_969  -25
    arc_1_16_9  connected_order_arc_970  -13
    arc_1_16_9  in_degree_1101  1
    arc_1_16_9  out_degree_1125  1
    arc_1_16_9  original_T_including_depot_unload_1158  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_969  1
    load_1_16_9  segment_load_conservation_1104  -1
    load_1_16_9  segment_prefix_lb_1105  1
    load_1_16_9  segment_prefix_ub_1106  1
    load_1_16_9  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_971  -25
    arc_1_16_13  connected_order_arc_972  -13
    arc_1_16_13  in_degree_1108  1
    arc_1_16_13  out_degree_1125  1
    arc_1_16_13  original_T_including_depot_unload_1158  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_971  1
    load_1_16_13  free_load_conservation_1112  -1
    load_1_16_13  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_973  -25
    arc_1_16_14  connected_order_arc_974  -13
    arc_1_16_14  in_degree_1114  1
    arc_1_16_14  out_degree_1125  1
    arc_1_16_14  original_T_including_depot_unload_1158  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_973  1
    load_1_16_14  free_load_conservation_1118  -1
    load_1_16_14  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_975  -25
    arc_1_16_15  connected_order_arc_976  -13
    arc_1_16_15  in_degree_1120  1
    arc_1_16_15  out_degree_1125  1
    arc_1_16_15  original_T_including_depot_unload_1158  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_975  1
    load_1_16_15  free_load_conservation_1124  -1
    load_1_16_15  free_load_conservation_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_977  -25
    arc_1_16_17  connected_order_arc_978  -13
    arc_1_16_17  out_degree_1125  1
    arc_1_16_17  in_degree_1132  1
    arc_1_16_17  original_T_including_depot_unload_1158  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_977  1
    load_1_16_17  free_load_conservation_1130  1
    load_1_16_17  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_979  -25
    arc_1_16_18  connected_order_arc_980  -13
    arc_1_16_18  out_degree_1125  1
    arc_1_16_18  in_degree_1138  1
    arc_1_16_18  original_T_including_depot_unload_1158  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_979  1
    load_1_16_18  free_load_conservation_1130  1
    load_1_16_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_981  -25
    arc_1_16_19  connected_order_arc_982  -13
    arc_1_16_19  out_degree_1125  1
    arc_1_16_19  in_degree_1144  1
    arc_1_16_19  original_T_including_depot_unload_1158  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_981  1
    load_1_16_19  free_load_conservation_1130  1
    load_1_16_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_983  -25
    arc_1_16_20  connected_order_arc_984  -13
    arc_1_16_20  out_degree_1125  1
    arc_1_16_20  in_degree_1150  1
    arc_1_16_20  original_T_including_depot_unload_1158  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_983  1
    load_1_16_20  free_load_conservation_1130  1
    load_1_16_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_985  -25
    arc_1_17_0  depot_return_or_bypass_1078  1
    arc_1_17_0  out_degree_1131  1
    arc_1_17_0  original_T_including_depot_unload_1158  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_985  1
    load_1_17_0  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_986  -25
    arc_1_17_6  connected_order_arc_987  -13
    arc_1_17_6  in_degree_1080  1
    arc_1_17_6  out_degree_1131  1
    arc_1_17_6  original_T_including_depot_unload_1158  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_986  1
    load_1_17_6  segment_load_conservation_1083  -1
    load_1_17_6  segment_prefix_lb_1084  1
    load_1_17_6  segment_prefix_ub_1085  1
    load_1_17_6  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_988  -25
    arc_1_17_7  connected_order_arc_989  -13
    arc_1_17_7  in_degree_1087  1
    arc_1_17_7  out_degree_1131  1
    arc_1_17_7  original_T_including_depot_unload_1158  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_988  1
    load_1_17_7  segment_load_conservation_1090  -1
    load_1_17_7  segment_prefix_lb_1091  1
    load_1_17_7  segment_prefix_ub_1092  1
    load_1_17_7  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_990  -25
    arc_1_17_8  connected_order_arc_991  -13
    arc_1_17_8  in_degree_1094  1
    arc_1_17_8  out_degree_1131  1
    arc_1_17_8  original_T_including_depot_unload_1158  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_990  1
    load_1_17_8  segment_load_conservation_1097  -1
    load_1_17_8  segment_prefix_lb_1098  1
    load_1_17_8  segment_prefix_ub_1099  1
    load_1_17_8  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_992  -25
    arc_1_17_9  connected_order_arc_993  -13
    arc_1_17_9  in_degree_1101  1
    arc_1_17_9  out_degree_1131  1
    arc_1_17_9  original_T_including_depot_unload_1158  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_992  1
    load_1_17_9  segment_load_conservation_1104  -1
    load_1_17_9  segment_prefix_lb_1105  1
    load_1_17_9  segment_prefix_ub_1106  1
    load_1_17_9  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_994  -25
    arc_1_17_13  connected_order_arc_995  -13
    arc_1_17_13  in_degree_1108  1
    arc_1_17_13  out_degree_1131  1
    arc_1_17_13  original_T_including_depot_unload_1158  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_994  1
    load_1_17_13  free_load_conservation_1112  -1
    load_1_17_13  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_996  -25
    arc_1_17_14  connected_order_arc_997  -13
    arc_1_17_14  in_degree_1114  1
    arc_1_17_14  out_degree_1131  1
    arc_1_17_14  original_T_including_depot_unload_1158  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_996  1
    load_1_17_14  free_load_conservation_1118  -1
    load_1_17_14  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_998  -25
    arc_1_17_15  connected_order_arc_999  -13
    arc_1_17_15  in_degree_1120  1
    arc_1_17_15  out_degree_1131  1
    arc_1_17_15  original_T_including_depot_unload_1158  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_998  1
    load_1_17_15  free_load_conservation_1124  -1
    load_1_17_15  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1000  -25
    arc_1_17_16  connected_order_arc_1001  -13
    arc_1_17_16  in_degree_1126  1
    arc_1_17_16  out_degree_1131  1
    arc_1_17_16  original_T_including_depot_unload_1158  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1000  1
    load_1_17_16  free_load_conservation_1130  -1
    load_1_17_16  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1002  -25
    arc_1_17_18  connected_order_arc_1003  -13
    arc_1_17_18  out_degree_1131  1
    arc_1_17_18  in_degree_1138  1
    arc_1_17_18  original_T_including_depot_unload_1158  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1002  1
    load_1_17_18  free_load_conservation_1136  1
    load_1_17_18  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1004  -25
    arc_1_17_19  connected_order_arc_1005  -13
    arc_1_17_19  out_degree_1131  1
    arc_1_17_19  in_degree_1144  1
    arc_1_17_19  original_T_including_depot_unload_1158  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1004  1
    load_1_17_19  free_load_conservation_1136  1
    load_1_17_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1006  -25
    arc_1_17_20  connected_order_arc_1007  -13
    arc_1_17_20  out_degree_1131  1
    arc_1_17_20  in_degree_1150  1
    arc_1_17_20  original_T_including_depot_unload_1158  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1006  1
    load_1_17_20  free_load_conservation_1136  1
    load_1_17_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1008  -25
    arc_1_18_0  depot_return_or_bypass_1078  1
    arc_1_18_0  out_degree_1137  1
    arc_1_18_0  original_T_including_depot_unload_1158  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1008  1
    load_1_18_0  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1009  -25
    arc_1_18_6  connected_order_arc_1010  -13
    arc_1_18_6  in_degree_1080  1
    arc_1_18_6  out_degree_1137  1
    arc_1_18_6  original_T_including_depot_unload_1158  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1009  1
    load_1_18_6  segment_load_conservation_1083  -1
    load_1_18_6  segment_prefix_lb_1084  1
    load_1_18_6  segment_prefix_ub_1085  1
    load_1_18_6  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1011  -25
    arc_1_18_7  connected_order_arc_1012  -13
    arc_1_18_7  in_degree_1087  1
    arc_1_18_7  out_degree_1137  1
    arc_1_18_7  original_T_including_depot_unload_1158  1.9444044143793826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1011  1
    load_1_18_7  segment_load_conservation_1090  -1
    load_1_18_7  segment_prefix_lb_1091  1
    load_1_18_7  segment_prefix_ub_1092  1
    load_1_18_7  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1013  -25
    arc_1_18_8  connected_order_arc_1014  -13
    arc_1_18_8  in_degree_1094  1
    arc_1_18_8  out_degree_1137  1
    arc_1_18_8  original_T_including_depot_unload_1158  1.9370748198308336e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1013  1
    load_1_18_8  segment_load_conservation_1097  -1
    load_1_18_8  segment_prefix_lb_1098  1
    load_1_18_8  segment_prefix_ub_1099  1
    load_1_18_8  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1015  -25
    arc_1_18_9  connected_order_arc_1016  -13
    arc_1_18_9  in_degree_1101  1
    arc_1_18_9  out_degree_1137  1
    arc_1_18_9  original_T_including_depot_unload_1158  1.6359122202972637e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1015  1
    load_1_18_9  segment_load_conservation_1104  -1
    load_1_18_9  segment_prefix_lb_1105  1
    load_1_18_9  segment_prefix_ub_1106  1
    load_1_18_9  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1017  -25
    arc_1_18_13  connected_order_arc_1018  -13
    arc_1_18_13  in_degree_1108  1
    arc_1_18_13  out_degree_1137  1
    arc_1_18_13  original_T_including_depot_unload_1158  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1017  1
    load_1_18_13  free_load_conservation_1112  -1
    load_1_18_13  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1019  -25
    arc_1_18_14  connected_order_arc_1020  -13
    arc_1_18_14  in_degree_1114  1
    arc_1_18_14  out_degree_1137  1
    arc_1_18_14  original_T_including_depot_unload_1158  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1019  1
    load_1_18_14  free_load_conservation_1118  -1
    load_1_18_14  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1021  -25
    arc_1_18_15  connected_order_arc_1022  -13
    arc_1_18_15  in_degree_1120  1
    arc_1_18_15  out_degree_1137  1
    arc_1_18_15  original_T_including_depot_unload_1158  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1021  1
    load_1_18_15  free_load_conservation_1124  -1
    load_1_18_15  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1023  -25
    arc_1_18_16  connected_order_arc_1024  -13
    arc_1_18_16  in_degree_1126  1
    arc_1_18_16  out_degree_1137  1
    arc_1_18_16  original_T_including_depot_unload_1158  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1023  1
    load_1_18_16  free_load_conservation_1130  -1
    load_1_18_16  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1025  -25
    arc_1_18_17  connected_order_arc_1026  -13
    arc_1_18_17  in_degree_1132  1
    arc_1_18_17  out_degree_1137  1
    arc_1_18_17  original_T_including_depot_unload_1158  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1025  1
    load_1_18_17  free_load_conservation_1136  -1
    load_1_18_17  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1027  -25
    arc_1_18_19  connected_order_arc_1028  -13
    arc_1_18_19  out_degree_1137  1
    arc_1_18_19  in_degree_1144  1
    arc_1_18_19  original_T_including_depot_unload_1158  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1027  1
    load_1_18_19  free_load_conservation_1142  1
    load_1_18_19  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1029  -25
    arc_1_18_20  connected_order_arc_1030  -13
    arc_1_18_20  out_degree_1137  1
    arc_1_18_20  in_degree_1150  1
    arc_1_18_20  original_T_including_depot_unload_1158  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1029  1
    load_1_18_20  free_load_conservation_1142  1
    load_1_18_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1031  -25
    arc_1_19_0  depot_return_or_bypass_1078  1
    arc_1_19_0  out_degree_1143  1
    arc_1_19_0  original_T_including_depot_unload_1158  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1031  1
    load_1_19_0  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1032  -25
    arc_1_19_6  connected_order_arc_1033  -13
    arc_1_19_6  in_degree_1080  1
    arc_1_19_6  out_degree_1143  1
    arc_1_19_6  original_T_including_depot_unload_1158  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1032  1
    load_1_19_6  segment_load_conservation_1083  -1
    load_1_19_6  segment_prefix_lb_1084  1
    load_1_19_6  segment_prefix_ub_1085  1
    load_1_19_6  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1034  -25
    arc_1_19_7  connected_order_arc_1035  -13
    arc_1_19_7  in_degree_1087  1
    arc_1_19_7  out_degree_1143  1
    arc_1_19_7  original_T_including_depot_unload_1158  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1034  1
    load_1_19_7  segment_load_conservation_1090  -1
    load_1_19_7  segment_prefix_lb_1091  1
    load_1_19_7  segment_prefix_ub_1092  1
    load_1_19_7  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1036  -25
    arc_1_19_8  connected_order_arc_1037  -13
    arc_1_19_8  in_degree_1094  1
    arc_1_19_8  out_degree_1143  1
    arc_1_19_8  original_T_including_depot_unload_1158  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1036  1
    load_1_19_8  segment_load_conservation_1097  -1
    load_1_19_8  segment_prefix_lb_1098  1
    load_1_19_8  segment_prefix_ub_1099  1
    load_1_19_8  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1038  -25
    arc_1_19_9  connected_order_arc_1039  -13
    arc_1_19_9  in_degree_1101  1
    arc_1_19_9  out_degree_1143  1
    arc_1_19_9  original_T_including_depot_unload_1158  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1038  1
    load_1_19_9  segment_load_conservation_1104  -1
    load_1_19_9  segment_prefix_lb_1105  1
    load_1_19_9  segment_prefix_ub_1106  1
    load_1_19_9  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1040  -25
    arc_1_19_13  connected_order_arc_1041  -13
    arc_1_19_13  in_degree_1108  1
    arc_1_19_13  out_degree_1143  1
    arc_1_19_13  original_T_including_depot_unload_1158  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1040  1
    load_1_19_13  free_load_conservation_1112  -1
    load_1_19_13  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1042  -25
    arc_1_19_14  connected_order_arc_1043  -13
    arc_1_19_14  in_degree_1114  1
    arc_1_19_14  out_degree_1143  1
    arc_1_19_14  original_T_including_depot_unload_1158  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1042  1
    load_1_19_14  free_load_conservation_1118  -1
    load_1_19_14  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1044  -25
    arc_1_19_15  connected_order_arc_1045  -13
    arc_1_19_15  in_degree_1120  1
    arc_1_19_15  out_degree_1143  1
    arc_1_19_15  original_T_including_depot_unload_1158  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1044  1
    load_1_19_15  free_load_conservation_1124  -1
    load_1_19_15  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1046  -25
    arc_1_19_16  connected_order_arc_1047  -13
    arc_1_19_16  in_degree_1126  1
    arc_1_19_16  out_degree_1143  1
    arc_1_19_16  original_T_including_depot_unload_1158  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1046  1
    load_1_19_16  free_load_conservation_1130  -1
    load_1_19_16  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1048  -25
    arc_1_19_17  connected_order_arc_1049  -13
    arc_1_19_17  in_degree_1132  1
    arc_1_19_17  out_degree_1143  1
    arc_1_19_17  original_T_including_depot_unload_1158  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1048  1
    load_1_19_17  free_load_conservation_1136  -1
    load_1_19_17  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1050  -25
    arc_1_19_18  connected_order_arc_1051  -13
    arc_1_19_18  in_degree_1138  1
    arc_1_19_18  out_degree_1143  1
    arc_1_19_18  original_T_including_depot_unload_1158  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1050  1
    load_1_19_18  free_load_conservation_1142  -1
    load_1_19_18  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1052  -25
    arc_1_19_20  connected_order_arc_1053  -13
    arc_1_19_20  out_degree_1143  1
    arc_1_19_20  in_degree_1150  1
    arc_1_19_20  original_T_including_depot_unload_1158  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1052  1
    load_1_19_20  free_load_conservation_1148  1
    load_1_19_20  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1054  -25
    arc_1_20_0  depot_return_or_bypass_1078  1
    arc_1_20_0  out_degree_1149  1
    arc_1_20_0  original_T_including_depot_unload_1158  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1054  1
    load_1_20_0  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1055  -25
    arc_1_20_6  connected_order_arc_1056  -13
    arc_1_20_6  in_degree_1080  1
    arc_1_20_6  out_degree_1149  1
    arc_1_20_6  original_T_including_depot_unload_1158  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1055  1
    load_1_20_6  segment_load_conservation_1083  -1
    load_1_20_6  segment_prefix_lb_1084  1
    load_1_20_6  segment_prefix_ub_1085  1
    load_1_20_6  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1057  -25
    arc_1_20_7  connected_order_arc_1058  -13
    arc_1_20_7  in_degree_1087  1
    arc_1_20_7  out_degree_1149  1
    arc_1_20_7  original_T_including_depot_unload_1158  1.9888769270297350e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1057  1
    load_1_20_7  segment_load_conservation_1090  -1
    load_1_20_7  segment_prefix_lb_1091  1
    load_1_20_7  segment_prefix_ub_1092  1
    load_1_20_7  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1059  -25
    arc_1_20_8  connected_order_arc_1060  -13
    arc_1_20_8  in_degree_1094  1
    arc_1_20_8  out_degree_1149  1
    arc_1_20_8  original_T_including_depot_unload_1158  2.0264134980919391e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1059  1
    load_1_20_8  segment_load_conservation_1097  -1
    load_1_20_8  segment_prefix_lb_1098  1
    load_1_20_8  segment_prefix_ub_1099  1
    load_1_20_8  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1061  -25
    arc_1_20_9  connected_order_arc_1062  -13
    arc_1_20_9  in_degree_1101  1
    arc_1_20_9  out_degree_1149  1
    arc_1_20_9  original_T_including_depot_unload_1158  1.7203273996041773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1061  1
    load_1_20_9  segment_load_conservation_1104  -1
    load_1_20_9  segment_prefix_lb_1105  1
    load_1_20_9  segment_prefix_ub_1106  1
    load_1_20_9  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1063  -25
    arc_1_20_13  connected_order_arc_1064  -13
    arc_1_20_13  in_degree_1108  1
    arc_1_20_13  out_degree_1149  1
    arc_1_20_13  original_T_including_depot_unload_1158  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1063  1
    load_1_20_13  free_load_conservation_1112  -1
    load_1_20_13  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1065  -25
    arc_1_20_14  connected_order_arc_1066  -13
    arc_1_20_14  in_degree_1114  1
    arc_1_20_14  out_degree_1149  1
    arc_1_20_14  original_T_including_depot_unload_1158  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1065  1
    load_1_20_14  free_load_conservation_1118  -1
    load_1_20_14  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1067  -25
    arc_1_20_15  connected_order_arc_1068  -13
    arc_1_20_15  in_degree_1120  1
    arc_1_20_15  out_degree_1149  1
    arc_1_20_15  original_T_including_depot_unload_1158  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1067  1
    load_1_20_15  free_load_conservation_1124  -1
    load_1_20_15  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1069  -25
    arc_1_20_16  connected_order_arc_1070  -13
    arc_1_20_16  in_degree_1126  1
    arc_1_20_16  out_degree_1149  1
    arc_1_20_16  original_T_including_depot_unload_1158  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1069  1
    load_1_20_16  free_load_conservation_1130  -1
    load_1_20_16  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1071  -25
    arc_1_20_17  connected_order_arc_1072  -13
    arc_1_20_17  in_degree_1132  1
    arc_1_20_17  out_degree_1149  1
    arc_1_20_17  original_T_including_depot_unload_1158  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1071  1
    load_1_20_17  free_load_conservation_1136  -1
    load_1_20_17  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1073  -25
    arc_1_20_18  connected_order_arc_1074  -13
    arc_1_20_18  in_degree_1138  1
    arc_1_20_18  out_degree_1149  1
    arc_1_20_18  original_T_including_depot_unload_1158  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1073  1
    load_1_20_18  free_load_conservation_1142  -1
    load_1_20_18  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1075  -25
    arc_1_20_19  connected_order_arc_1076  -13
    arc_1_20_19  in_degree_1144  1
    arc_1_20_19  out_degree_1149  1
    arc_1_20_19  original_T_including_depot_unload_1158  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1075  1
    load_1_20_19  free_load_conservation_1148  -1
    load_1_20_19  free_load_conservation_1154  1
    visit_2_10  out_degree_1404  -1
    visit_2_10  in_degree_1405  -1
    visit_2_10  order_active_lb_1406  -1
    visit_2_10  order_active_ub_1407  -11
    order_2_10  connected_order_arc_1173  -1
    order_2_10  connected_order_arc_1175  -1
    order_2_10  connected_order_arc_1177  -1
    order_2_10  connected_order_arc_1179  -1
    order_2_10  connected_order_arc_1181  -1
    order_2_10  connected_order_arc_1183  -1
    order_2_10  connected_order_arc_1185  -1
    order_2_10  connected_order_arc_1187  -1
    order_2_10  connected_order_arc_1189  -1
    order_2_10  connected_order_arc_1191  -1
    order_2_10  connected_order_arc_1194  1
    order_2_10  connected_order_arc_1215  1
    order_2_10  connected_order_arc_1236  1
    order_2_10  connected_order_arc_1257  1
    order_2_10  connected_order_arc_1278  1
    order_2_10  connected_order_arc_1299  1
    order_2_10  connected_order_arc_1320  1
    order_2_10  connected_order_arc_1341  1
    order_2_10  connected_order_arc_1362  1
    order_2_10  connected_order_arc_1383  1
    order_2_10  order_active_lb_1406  1
    order_2_10  order_active_ub_1407  1
    order_2_10  fixed_segment_relative_order_1473  -1
    visit_2_11  out_degree_1411  -1
    visit_2_11  in_degree_1412  -1
    visit_2_11  order_active_lb_1413  -1
    visit_2_11  order_active_ub_1414  -11
    order_2_11  connected_order_arc_1173  1
    order_2_11  connected_order_arc_1194  -1
    order_2_11  connected_order_arc_1196  -1
    order_2_11  connected_order_arc_1198  -1
    order_2_11  connected_order_arc_1200  -1
    order_2_11  connected_order_arc_1202  -1
    order_2_11  connected_order_arc_1204  -1
    order_2_11  connected_order_arc_1206  -1
    order_2_11  connected_order_arc_1208  -1
    order_2_11  connected_order_arc_1210  -1
    order_2_11  connected_order_arc_1212  -1
    order_2_11  connected_order_arc_1217  1
    order_2_11  connected_order_arc_1238  1
    order_2_11  connected_order_arc_1259  1
    order_2_11  connected_order_arc_1280  1
    order_2_11  connected_order_arc_1301  1
    order_2_11  connected_order_arc_1322  1
    order_2_11  connected_order_arc_1343  1
    order_2_11  connected_order_arc_1364  1
    order_2_11  connected_order_arc_1385  1
    order_2_11  order_active_lb_1413  1
    order_2_11  order_active_ub_1414  1
    order_2_11  fixed_segment_relative_order_1473  1
    order_2_11  fixed_segment_relative_order_1474  -1
    visit_2_12  out_degree_1418  -1
    visit_2_12  in_degree_1419  -1
    visit_2_12  order_active_lb_1420  -1
    visit_2_12  order_active_ub_1421  -11
    order_2_12  connected_order_arc_1175  1
    order_2_12  connected_order_arc_1196  1
    order_2_12  connected_order_arc_1215  -1
    order_2_12  connected_order_arc_1217  -1
    order_2_12  connected_order_arc_1219  -1
    order_2_12  connected_order_arc_1221  -1
    order_2_12  connected_order_arc_1223  -1
    order_2_12  connected_order_arc_1225  -1
    order_2_12  connected_order_arc_1227  -1
    order_2_12  connected_order_arc_1229  -1
    order_2_12  connected_order_arc_1231  -1
    order_2_12  connected_order_arc_1233  -1
    order_2_12  connected_order_arc_1240  1
    order_2_12  connected_order_arc_1261  1
    order_2_12  connected_order_arc_1282  1
    order_2_12  connected_order_arc_1303  1
    order_2_12  connected_order_arc_1324  1
    order_2_12  connected_order_arc_1345  1
    order_2_12  connected_order_arc_1366  1
    order_2_12  connected_order_arc_1387  1
    order_2_12  order_active_lb_1420  1
    order_2_12  order_active_ub_1421  1
    order_2_12  fixed_segment_relative_order_1474  1
    visit_2_13  out_degree_1425  -1
    visit_2_13  in_degree_1426  -1
    visit_2_13  order_active_lb_1427  -1
    visit_2_13  order_active_ub_1428  -11
    visit_2_13  service_visit_def_1429  -1
    order_2_13  connected_order_arc_1177  1
    order_2_13  connected_order_arc_1198  1
    order_2_13  connected_order_arc_1219  1
    order_2_13  connected_order_arc_1236  -1
    order_2_13  connected_order_arc_1238  -1
    order_2_13  connected_order_arc_1240  -1
    order_2_13  connected_order_arc_1242  -1
    order_2_13  connected_order_arc_1244  -1
    order_2_13  connected_order_arc_1246  -1
    order_2_13  connected_order_arc_1248  -1
    order_2_13  connected_order_arc_1250  -1
    order_2_13  connected_order_arc_1252  -1
    order_2_13  connected_order_arc_1254  -1
    order_2_13  connected_order_arc_1263  1
    order_2_13  connected_order_arc_1284  1
    order_2_13  connected_order_arc_1305  1
    order_2_13  connected_order_arc_1326  1
    order_2_13  connected_order_arc_1347  1
    order_2_13  connected_order_arc_1368  1
    order_2_13  connected_order_arc_1389  1
    order_2_13  order_active_lb_1427  1
    order_2_13  order_active_ub_1428  1
    visit_2_14  out_degree_1431  -1
    visit_2_14  in_degree_1432  -1
    visit_2_14  order_active_lb_1433  -1
    visit_2_14  order_active_ub_1434  -11
    visit_2_14  service_visit_def_1435  -1
    order_2_14  connected_order_arc_1179  1
    order_2_14  connected_order_arc_1200  1
    order_2_14  connected_order_arc_1221  1
    order_2_14  connected_order_arc_1242  1
    order_2_14  connected_order_arc_1257  -1
    order_2_14  connected_order_arc_1259  -1
    order_2_14  connected_order_arc_1261  -1
    order_2_14  connected_order_arc_1263  -1
    order_2_14  connected_order_arc_1265  -1
    order_2_14  connected_order_arc_1267  -1
    order_2_14  connected_order_arc_1269  -1
    order_2_14  connected_order_arc_1271  -1
    order_2_14  connected_order_arc_1273  -1
    order_2_14  connected_order_arc_1275  -1
    order_2_14  connected_order_arc_1286  1
    order_2_14  connected_order_arc_1307  1
    order_2_14  connected_order_arc_1328  1
    order_2_14  connected_order_arc_1349  1
    order_2_14  connected_order_arc_1370  1
    order_2_14  connected_order_arc_1391  1
    order_2_14  order_active_lb_1433  1
    order_2_14  order_active_ub_1434  1
    visit_2_15  out_degree_1437  -1
    visit_2_15  in_degree_1438  -1
    visit_2_15  order_active_lb_1439  -1
    visit_2_15  order_active_ub_1440  -11
    visit_2_15  service_visit_def_1441  -1
    order_2_15  connected_order_arc_1181  1
    order_2_15  connected_order_arc_1202  1
    order_2_15  connected_order_arc_1223  1
    order_2_15  connected_order_arc_1244  1
    order_2_15  connected_order_arc_1265  1
    order_2_15  connected_order_arc_1278  -1
    order_2_15  connected_order_arc_1280  -1
    order_2_15  connected_order_arc_1282  -1
    order_2_15  connected_order_arc_1284  -1
    order_2_15  connected_order_arc_1286  -1
    order_2_15  connected_order_arc_1288  -1
    order_2_15  connected_order_arc_1290  -1
    order_2_15  connected_order_arc_1292  -1
    order_2_15  connected_order_arc_1294  -1
    order_2_15  connected_order_arc_1296  -1
    order_2_15  connected_order_arc_1309  1
    order_2_15  connected_order_arc_1330  1
    order_2_15  connected_order_arc_1351  1
    order_2_15  connected_order_arc_1372  1
    order_2_15  connected_order_arc_1393  1
    order_2_15  order_active_lb_1439  1
    order_2_15  order_active_ub_1440  1
    visit_2_16  out_degree_1443  -1
    visit_2_16  in_degree_1444  -1
    visit_2_16  order_active_lb_1445  -1
    visit_2_16  order_active_ub_1446  -11
    visit_2_16  service_visit_def_1447  -1
    order_2_16  connected_order_arc_1183  1
    order_2_16  connected_order_arc_1204  1
    order_2_16  connected_order_arc_1225  1
    order_2_16  connected_order_arc_1246  1
    order_2_16  connected_order_arc_1267  1
    order_2_16  connected_order_arc_1288  1
    order_2_16  connected_order_arc_1299  -1
    order_2_16  connected_order_arc_1301  -1
    order_2_16  connected_order_arc_1303  -1
    order_2_16  connected_order_arc_1305  -1
    order_2_16  connected_order_arc_1307  -1
    order_2_16  connected_order_arc_1309  -1
    order_2_16  connected_order_arc_1311  -1
    order_2_16  connected_order_arc_1313  -1
    order_2_16  connected_order_arc_1315  -1
    order_2_16  connected_order_arc_1317  -1
    order_2_16  connected_order_arc_1332  1
    order_2_16  connected_order_arc_1353  1
    order_2_16  connected_order_arc_1374  1
    order_2_16  connected_order_arc_1395  1
    order_2_16  order_active_lb_1445  1
    order_2_16  order_active_ub_1446  1
    visit_2_17  out_degree_1449  -1
    visit_2_17  in_degree_1450  -1
    visit_2_17  order_active_lb_1451  -1
    visit_2_17  order_active_ub_1452  -11
    visit_2_17  service_visit_def_1453  -1
    order_2_17  connected_order_arc_1185  1
    order_2_17  connected_order_arc_1206  1
    order_2_17  connected_order_arc_1227  1
    order_2_17  connected_order_arc_1248  1
    order_2_17  connected_order_arc_1269  1
    order_2_17  connected_order_arc_1290  1
    order_2_17  connected_order_arc_1311  1
    order_2_17  connected_order_arc_1320  -1
    order_2_17  connected_order_arc_1322  -1
    order_2_17  connected_order_arc_1324  -1
    order_2_17  connected_order_arc_1326  -1
    order_2_17  connected_order_arc_1328  -1
    order_2_17  connected_order_arc_1330  -1
    order_2_17  connected_order_arc_1332  -1
    order_2_17  connected_order_arc_1334  -1
    order_2_17  connected_order_arc_1336  -1
    order_2_17  connected_order_arc_1338  -1
    order_2_17  connected_order_arc_1355  1
    order_2_17  connected_order_arc_1376  1
    order_2_17  connected_order_arc_1397  1
    order_2_17  order_active_lb_1451  1
    order_2_17  order_active_ub_1452  1
    visit_2_18  out_degree_1455  -1
    visit_2_18  in_degree_1456  -1
    visit_2_18  order_active_lb_1457  -1
    visit_2_18  order_active_ub_1458  -11
    visit_2_18  service_visit_def_1459  -1
    order_2_18  connected_order_arc_1187  1
    order_2_18  connected_order_arc_1208  1
    order_2_18  connected_order_arc_1229  1
    order_2_18  connected_order_arc_1250  1
    order_2_18  connected_order_arc_1271  1
    order_2_18  connected_order_arc_1292  1
    order_2_18  connected_order_arc_1313  1
    order_2_18  connected_order_arc_1334  1
    order_2_18  connected_order_arc_1341  -1
    order_2_18  connected_order_arc_1343  -1
    order_2_18  connected_order_arc_1345  -1
    order_2_18  connected_order_arc_1347  -1
    order_2_18  connected_order_arc_1349  -1
    order_2_18  connected_order_arc_1351  -1
    order_2_18  connected_order_arc_1353  -1
    order_2_18  connected_order_arc_1355  -1
    order_2_18  connected_order_arc_1357  -1
    order_2_18  connected_order_arc_1359  -1
    order_2_18  connected_order_arc_1378  1
    order_2_18  connected_order_arc_1399  1
    order_2_18  order_active_lb_1457  1
    order_2_18  order_active_ub_1458  1
    visit_2_19  out_degree_1461  -1
    visit_2_19  in_degree_1462  -1
    visit_2_19  order_active_lb_1463  -1
    visit_2_19  order_active_ub_1464  -11
    visit_2_19  service_visit_def_1465  -1
    order_2_19  connected_order_arc_1189  1
    order_2_19  connected_order_arc_1210  1
    order_2_19  connected_order_arc_1231  1
    order_2_19  connected_order_arc_1252  1
    order_2_19  connected_order_arc_1273  1
    order_2_19  connected_order_arc_1294  1
    order_2_19  connected_order_arc_1315  1
    order_2_19  connected_order_arc_1336  1
    order_2_19  connected_order_arc_1357  1
    order_2_19  connected_order_arc_1362  -1
    order_2_19  connected_order_arc_1364  -1
    order_2_19  connected_order_arc_1366  -1
    order_2_19  connected_order_arc_1368  -1
    order_2_19  connected_order_arc_1370  -1
    order_2_19  connected_order_arc_1372  -1
    order_2_19  connected_order_arc_1374  -1
    order_2_19  connected_order_arc_1376  -1
    order_2_19  connected_order_arc_1378  -1
    order_2_19  connected_order_arc_1380  -1
    order_2_19  connected_order_arc_1401  1
    order_2_19  order_active_lb_1463  1
    order_2_19  order_active_ub_1464  1
    visit_2_20  out_degree_1467  -1
    visit_2_20  in_degree_1468  -1
    visit_2_20  order_active_lb_1469  -1
    visit_2_20  order_active_ub_1470  -11
    visit_2_20  service_visit_def_1471  -1
    order_2_20  connected_order_arc_1191  1
    order_2_20  connected_order_arc_1212  1
    order_2_20  connected_order_arc_1233  1
    order_2_20  connected_order_arc_1254  1
    order_2_20  connected_order_arc_1275  1
    order_2_20  connected_order_arc_1296  1
    order_2_20  connected_order_arc_1317  1
    order_2_20  connected_order_arc_1338  1
    order_2_20  connected_order_arc_1359  1
    order_2_20  connected_order_arc_1380  1
    order_2_20  connected_order_arc_1383  -1
    order_2_20  connected_order_arc_1385  -1
    order_2_20  connected_order_arc_1387  -1
    order_2_20  connected_order_arc_1389  -1
    order_2_20  connected_order_arc_1391  -1
    order_2_20  connected_order_arc_1393  -1
    order_2_20  connected_order_arc_1395  -1
    order_2_20  connected_order_arc_1397  -1
    order_2_20  connected_order_arc_1399  -1
    order_2_20  connected_order_arc_1401  -1
    order_2_20  order_active_lb_1469  1
    order_2_20  order_active_ub_1470  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1159  -30
    arc_2_0_0  depot_departure_or_bypass_1402  1
    arc_2_0_0  depot_return_or_bypass_1403  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1160  -30
    arc_2_0_10  depot_departure_or_bypass_1402  1
    arc_2_0_10  in_degree_1405  1
    arc_2_0_10  original_T_including_depot_unload_1475  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1160  1
    load_2_0_10  segment_load_conservation_1408  -1
    load_2_0_10  segment_prefix_lb_1409  1
    load_2_0_10  segment_prefix_ub_1410  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1161  -30
    arc_2_0_11  depot_departure_or_bypass_1402  1
    arc_2_0_11  in_degree_1412  1
    arc_2_0_11  original_T_including_depot_unload_1475  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1161  1
    load_2_0_11  segment_load_conservation_1415  -1
    load_2_0_11  segment_prefix_lb_1416  1
    load_2_0_11  segment_prefix_ub_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1162  -30
    arc_2_0_12  depot_departure_or_bypass_1402  1
    arc_2_0_12  in_degree_1419  1
    arc_2_0_12  original_T_including_depot_unload_1475  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1162  1
    load_2_0_12  segment_load_conservation_1422  -1
    load_2_0_12  segment_prefix_lb_1423  1
    load_2_0_12  segment_prefix_ub_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1163  -30
    arc_2_0_13  depot_departure_or_bypass_1402  1
    arc_2_0_13  in_degree_1426  1
    arc_2_0_13  original_T_including_depot_unload_1475  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1163  1
    load_2_0_13  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1164  -30
    arc_2_0_14  depot_departure_or_bypass_1402  1
    arc_2_0_14  in_degree_1432  1
    arc_2_0_14  original_T_including_depot_unload_1475  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1164  1
    load_2_0_14  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1165  -30
    arc_2_0_15  depot_departure_or_bypass_1402  1
    arc_2_0_15  in_degree_1438  1
    arc_2_0_15  original_T_including_depot_unload_1475  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1165  1
    load_2_0_15  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1166  -30
    arc_2_0_16  depot_departure_or_bypass_1402  1
    arc_2_0_16  in_degree_1444  1
    arc_2_0_16  original_T_including_depot_unload_1475  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1166  1
    load_2_0_16  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1167  -30
    arc_2_0_17  depot_departure_or_bypass_1402  1
    arc_2_0_17  in_degree_1450  1
    arc_2_0_17  original_T_including_depot_unload_1475  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1167  1
    load_2_0_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1168  -30
    arc_2_0_18  depot_departure_or_bypass_1402  1
    arc_2_0_18  in_degree_1456  1
    arc_2_0_18  original_T_including_depot_unload_1475  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1168  1
    load_2_0_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1169  -30
    arc_2_0_19  depot_departure_or_bypass_1402  1
    arc_2_0_19  in_degree_1462  1
    arc_2_0_19  original_T_including_depot_unload_1475  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1169  1
    load_2_0_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1170  -30
    arc_2_0_20  depot_departure_or_bypass_1402  1
    arc_2_0_20  in_degree_1468  1
    arc_2_0_20  original_T_including_depot_unload_1475  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1170  1
    load_2_0_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1171  -30
    arc_2_10_0  depot_return_or_bypass_1403  1
    arc_2_10_0  out_degree_1404  1
    arc_2_10_0  original_T_including_depot_unload_1475  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1171  1
    load_2_10_0  segment_load_conservation_1408  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1172  -30
    arc_2_10_11  connected_order_arc_1173  -12
    arc_2_10_11  out_degree_1404  1
    arc_2_10_11  in_degree_1412  1
    arc_2_10_11  original_T_including_depot_unload_1475  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1172  1
    load_2_10_11  segment_load_conservation_1408  1
    load_2_10_11  segment_load_conservation_1415  -1
    load_2_10_11  segment_prefix_lb_1416  1
    load_2_10_11  segment_prefix_ub_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1174  -30
    arc_2_10_12  connected_order_arc_1175  -12
    arc_2_10_12  out_degree_1404  1
    arc_2_10_12  in_degree_1419  1
    arc_2_10_12  original_T_including_depot_unload_1475  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1174  1
    load_2_10_12  segment_load_conservation_1408  1
    load_2_10_12  segment_load_conservation_1422  -1
    load_2_10_12  segment_prefix_lb_1423  1
    load_2_10_12  segment_prefix_ub_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1176  -30
    arc_2_10_13  connected_order_arc_1177  -12
    arc_2_10_13  out_degree_1404  1
    arc_2_10_13  in_degree_1426  1
    arc_2_10_13  original_T_including_depot_unload_1475  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1176  1
    load_2_10_13  segment_load_conservation_1408  1
    load_2_10_13  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1178  -30
    arc_2_10_14  connected_order_arc_1179  -12
    arc_2_10_14  out_degree_1404  1
    arc_2_10_14  in_degree_1432  1
    arc_2_10_14  original_T_including_depot_unload_1475  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1178  1
    load_2_10_14  segment_load_conservation_1408  1
    load_2_10_14  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1180  -30
    arc_2_10_15  connected_order_arc_1181  -12
    arc_2_10_15  out_degree_1404  1
    arc_2_10_15  in_degree_1438  1
    arc_2_10_15  original_T_including_depot_unload_1475  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1180  1
    load_2_10_15  segment_load_conservation_1408  1
    load_2_10_15  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1182  -30
    arc_2_10_16  connected_order_arc_1183  -12
    arc_2_10_16  out_degree_1404  1
    arc_2_10_16  in_degree_1444  1
    arc_2_10_16  original_T_including_depot_unload_1475  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1182  1
    load_2_10_16  segment_load_conservation_1408  1
    load_2_10_16  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1184  -30
    arc_2_10_17  connected_order_arc_1185  -12
    arc_2_10_17  out_degree_1404  1
    arc_2_10_17  in_degree_1450  1
    arc_2_10_17  original_T_including_depot_unload_1475  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1184  1
    load_2_10_17  segment_load_conservation_1408  1
    load_2_10_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1186  -30
    arc_2_10_18  connected_order_arc_1187  -12
    arc_2_10_18  out_degree_1404  1
    arc_2_10_18  in_degree_1456  1
    arc_2_10_18  original_T_including_depot_unload_1475  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1186  1
    load_2_10_18  segment_load_conservation_1408  1
    load_2_10_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1188  -30
    arc_2_10_19  connected_order_arc_1189  -12
    arc_2_10_19  out_degree_1404  1
    arc_2_10_19  in_degree_1462  1
    arc_2_10_19  original_T_including_depot_unload_1475  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1188  1
    load_2_10_19  segment_load_conservation_1408  1
    load_2_10_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1190  -30
    arc_2_10_20  connected_order_arc_1191  -12
    arc_2_10_20  out_degree_1404  1
    arc_2_10_20  in_degree_1468  1
    arc_2_10_20  original_T_including_depot_unload_1475  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1190  1
    load_2_10_20  segment_load_conservation_1408  1
    load_2_10_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1192  -30
    arc_2_11_0  depot_return_or_bypass_1403  1
    arc_2_11_0  out_degree_1411  1
    arc_2_11_0  original_T_including_depot_unload_1475  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1192  1
    load_2_11_0  segment_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1193  -30
    arc_2_11_10  connected_order_arc_1194  -12
    arc_2_11_10  in_degree_1405  1
    arc_2_11_10  out_degree_1411  1
    arc_2_11_10  original_T_including_depot_unload_1475  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1193  1
    load_2_11_10  segment_load_conservation_1408  -1
    load_2_11_10  segment_prefix_lb_1409  1
    load_2_11_10  segment_prefix_ub_1410  1
    load_2_11_10  segment_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1195  -30
    arc_2_11_12  connected_order_arc_1196  -12
    arc_2_11_12  out_degree_1411  1
    arc_2_11_12  in_degree_1419  1
    arc_2_11_12  original_T_including_depot_unload_1475  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1195  1
    load_2_11_12  segment_load_conservation_1415  1
    load_2_11_12  segment_load_conservation_1422  -1
    load_2_11_12  segment_prefix_lb_1423  1
    load_2_11_12  segment_prefix_ub_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1197  -30
    arc_2_11_13  connected_order_arc_1198  -12
    arc_2_11_13  out_degree_1411  1
    arc_2_11_13  in_degree_1426  1
    arc_2_11_13  original_T_including_depot_unload_1475  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1197  1
    load_2_11_13  segment_load_conservation_1415  1
    load_2_11_13  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1199  -30
    arc_2_11_14  connected_order_arc_1200  -12
    arc_2_11_14  out_degree_1411  1
    arc_2_11_14  in_degree_1432  1
    arc_2_11_14  original_T_including_depot_unload_1475  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1199  1
    load_2_11_14  segment_load_conservation_1415  1
    load_2_11_14  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1201  -30
    arc_2_11_15  connected_order_arc_1202  -12
    arc_2_11_15  out_degree_1411  1
    arc_2_11_15  in_degree_1438  1
    arc_2_11_15  original_T_including_depot_unload_1475  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1201  1
    load_2_11_15  segment_load_conservation_1415  1
    load_2_11_15  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1203  -30
    arc_2_11_16  connected_order_arc_1204  -12
    arc_2_11_16  out_degree_1411  1
    arc_2_11_16  in_degree_1444  1
    arc_2_11_16  original_T_including_depot_unload_1475  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1203  1
    load_2_11_16  segment_load_conservation_1415  1
    load_2_11_16  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1205  -30
    arc_2_11_17  connected_order_arc_1206  -12
    arc_2_11_17  out_degree_1411  1
    arc_2_11_17  in_degree_1450  1
    arc_2_11_17  original_T_including_depot_unload_1475  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1205  1
    load_2_11_17  segment_load_conservation_1415  1
    load_2_11_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1207  -30
    arc_2_11_18  connected_order_arc_1208  -12
    arc_2_11_18  out_degree_1411  1
    arc_2_11_18  in_degree_1456  1
    arc_2_11_18  original_T_including_depot_unload_1475  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1207  1
    load_2_11_18  segment_load_conservation_1415  1
    load_2_11_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1209  -30
    arc_2_11_19  connected_order_arc_1210  -12
    arc_2_11_19  out_degree_1411  1
    arc_2_11_19  in_degree_1462  1
    arc_2_11_19  original_T_including_depot_unload_1475  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1209  1
    load_2_11_19  segment_load_conservation_1415  1
    load_2_11_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1211  -30
    arc_2_11_20  connected_order_arc_1212  -12
    arc_2_11_20  out_degree_1411  1
    arc_2_11_20  in_degree_1468  1
    arc_2_11_20  original_T_including_depot_unload_1475  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1211  1
    load_2_11_20  segment_load_conservation_1415  1
    load_2_11_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1213  -30
    arc_2_12_0  depot_return_or_bypass_1403  1
    arc_2_12_0  out_degree_1418  1
    arc_2_12_0  original_T_including_depot_unload_1475  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1213  1
    load_2_12_0  segment_load_conservation_1422  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1214  -30
    arc_2_12_10  connected_order_arc_1215  -12
    arc_2_12_10  in_degree_1405  1
    arc_2_12_10  out_degree_1418  1
    arc_2_12_10  original_T_including_depot_unload_1475  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1214  1
    load_2_12_10  segment_load_conservation_1408  -1
    load_2_12_10  segment_prefix_lb_1409  1
    load_2_12_10  segment_prefix_ub_1410  1
    load_2_12_10  segment_load_conservation_1422  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1216  -30
    arc_2_12_11  connected_order_arc_1217  -12
    arc_2_12_11  in_degree_1412  1
    arc_2_12_11  out_degree_1418  1
    arc_2_12_11  original_T_including_depot_unload_1475  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1216  1
    load_2_12_11  segment_load_conservation_1415  -1
    load_2_12_11  segment_prefix_lb_1416  1
    load_2_12_11  segment_prefix_ub_1417  1
    load_2_12_11  segment_load_conservation_1422  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1218  -30
    arc_2_12_13  connected_order_arc_1219  -12
    arc_2_12_13  out_degree_1418  1
    arc_2_12_13  in_degree_1426  1
    arc_2_12_13  original_T_including_depot_unload_1475  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1218  1
    load_2_12_13  segment_load_conservation_1422  1
    load_2_12_13  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1220  -30
    arc_2_12_14  connected_order_arc_1221  -12
    arc_2_12_14  out_degree_1418  1
    arc_2_12_14  in_degree_1432  1
    arc_2_12_14  original_T_including_depot_unload_1475  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1220  1
    load_2_12_14  segment_load_conservation_1422  1
    load_2_12_14  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1222  -30
    arc_2_12_15  connected_order_arc_1223  -12
    arc_2_12_15  out_degree_1418  1
    arc_2_12_15  in_degree_1438  1
    arc_2_12_15  original_T_including_depot_unload_1475  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1222  1
    load_2_12_15  segment_load_conservation_1422  1
    load_2_12_15  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1224  -30
    arc_2_12_16  connected_order_arc_1225  -12
    arc_2_12_16  out_degree_1418  1
    arc_2_12_16  in_degree_1444  1
    arc_2_12_16  original_T_including_depot_unload_1475  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1224  1
    load_2_12_16  segment_load_conservation_1422  1
    load_2_12_16  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1226  -30
    arc_2_12_17  connected_order_arc_1227  -12
    arc_2_12_17  out_degree_1418  1
    arc_2_12_17  in_degree_1450  1
    arc_2_12_17  original_T_including_depot_unload_1475  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1226  1
    load_2_12_17  segment_load_conservation_1422  1
    load_2_12_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1228  -30
    arc_2_12_18  connected_order_arc_1229  -12
    arc_2_12_18  out_degree_1418  1
    arc_2_12_18  in_degree_1456  1
    arc_2_12_18  original_T_including_depot_unload_1475  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1228  1
    load_2_12_18  segment_load_conservation_1422  1
    load_2_12_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1230  -30
    arc_2_12_19  connected_order_arc_1231  -12
    arc_2_12_19  out_degree_1418  1
    arc_2_12_19  in_degree_1462  1
    arc_2_12_19  original_T_including_depot_unload_1475  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1230  1
    load_2_12_19  segment_load_conservation_1422  1
    load_2_12_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1232  -30
    arc_2_12_20  connected_order_arc_1233  -12
    arc_2_12_20  out_degree_1418  1
    arc_2_12_20  in_degree_1468  1
    arc_2_12_20  original_T_including_depot_unload_1475  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1232  1
    load_2_12_20  segment_load_conservation_1422  1
    load_2_12_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1234  -30
    arc_2_13_0  depot_return_or_bypass_1403  1
    arc_2_13_0  out_degree_1425  1
    arc_2_13_0  original_T_including_depot_unload_1475  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1234  1
    load_2_13_0  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1235  -30
    arc_2_13_10  connected_order_arc_1236  -12
    arc_2_13_10  in_degree_1405  1
    arc_2_13_10  out_degree_1425  1
    arc_2_13_10  original_T_including_depot_unload_1475  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1235  1
    load_2_13_10  segment_load_conservation_1408  -1
    load_2_13_10  segment_prefix_lb_1409  1
    load_2_13_10  segment_prefix_ub_1410  1
    load_2_13_10  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1237  -30
    arc_2_13_11  connected_order_arc_1238  -12
    arc_2_13_11  in_degree_1412  1
    arc_2_13_11  out_degree_1425  1
    arc_2_13_11  original_T_including_depot_unload_1475  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1237  1
    load_2_13_11  segment_load_conservation_1415  -1
    load_2_13_11  segment_prefix_lb_1416  1
    load_2_13_11  segment_prefix_ub_1417  1
    load_2_13_11  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1239  -30
    arc_2_13_12  connected_order_arc_1240  -12
    arc_2_13_12  in_degree_1419  1
    arc_2_13_12  out_degree_1425  1
    arc_2_13_12  original_T_including_depot_unload_1475  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1239  1
    load_2_13_12  segment_load_conservation_1422  -1
    load_2_13_12  segment_prefix_lb_1423  1
    load_2_13_12  segment_prefix_ub_1424  1
    load_2_13_12  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1241  -30
    arc_2_13_14  connected_order_arc_1242  -12
    arc_2_13_14  out_degree_1425  1
    arc_2_13_14  in_degree_1432  1
    arc_2_13_14  original_T_including_depot_unload_1475  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1241  1
    load_2_13_14  free_load_conservation_1430  1
    load_2_13_14  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1243  -30
    arc_2_13_15  connected_order_arc_1244  -12
    arc_2_13_15  out_degree_1425  1
    arc_2_13_15  in_degree_1438  1
    arc_2_13_15  original_T_including_depot_unload_1475  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1243  1
    load_2_13_15  free_load_conservation_1430  1
    load_2_13_15  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1245  -30
    arc_2_13_16  connected_order_arc_1246  -12
    arc_2_13_16  out_degree_1425  1
    arc_2_13_16  in_degree_1444  1
    arc_2_13_16  original_T_including_depot_unload_1475  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1245  1
    load_2_13_16  free_load_conservation_1430  1
    load_2_13_16  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1247  -30
    arc_2_13_17  connected_order_arc_1248  -12
    arc_2_13_17  out_degree_1425  1
    arc_2_13_17  in_degree_1450  1
    arc_2_13_17  original_T_including_depot_unload_1475  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1247  1
    load_2_13_17  free_load_conservation_1430  1
    load_2_13_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1249  -30
    arc_2_13_18  connected_order_arc_1250  -12
    arc_2_13_18  out_degree_1425  1
    arc_2_13_18  in_degree_1456  1
    arc_2_13_18  original_T_including_depot_unload_1475  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1249  1
    load_2_13_18  free_load_conservation_1430  1
    load_2_13_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1251  -30
    arc_2_13_19  connected_order_arc_1252  -12
    arc_2_13_19  out_degree_1425  1
    arc_2_13_19  in_degree_1462  1
    arc_2_13_19  original_T_including_depot_unload_1475  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1251  1
    load_2_13_19  free_load_conservation_1430  1
    load_2_13_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1253  -30
    arc_2_13_20  connected_order_arc_1254  -12
    arc_2_13_20  out_degree_1425  1
    arc_2_13_20  in_degree_1468  1
    arc_2_13_20  original_T_including_depot_unload_1475  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1253  1
    load_2_13_20  free_load_conservation_1430  1
    load_2_13_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1255  -30
    arc_2_14_0  depot_return_or_bypass_1403  1
    arc_2_14_0  out_degree_1431  1
    arc_2_14_0  original_T_including_depot_unload_1475  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1255  1
    load_2_14_0  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1256  -30
    arc_2_14_10  connected_order_arc_1257  -12
    arc_2_14_10  in_degree_1405  1
    arc_2_14_10  out_degree_1431  1
    arc_2_14_10  original_T_including_depot_unload_1475  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1256  1
    load_2_14_10  segment_load_conservation_1408  -1
    load_2_14_10  segment_prefix_lb_1409  1
    load_2_14_10  segment_prefix_ub_1410  1
    load_2_14_10  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1258  -30
    arc_2_14_11  connected_order_arc_1259  -12
    arc_2_14_11  in_degree_1412  1
    arc_2_14_11  out_degree_1431  1
    arc_2_14_11  original_T_including_depot_unload_1475  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1258  1
    load_2_14_11  segment_load_conservation_1415  -1
    load_2_14_11  segment_prefix_lb_1416  1
    load_2_14_11  segment_prefix_ub_1417  1
    load_2_14_11  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1260  -30
    arc_2_14_12  connected_order_arc_1261  -12
    arc_2_14_12  in_degree_1419  1
    arc_2_14_12  out_degree_1431  1
    arc_2_14_12  original_T_including_depot_unload_1475  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1260  1
    load_2_14_12  segment_load_conservation_1422  -1
    load_2_14_12  segment_prefix_lb_1423  1
    load_2_14_12  segment_prefix_ub_1424  1
    load_2_14_12  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1262  -30
    arc_2_14_13  connected_order_arc_1263  -12
    arc_2_14_13  in_degree_1426  1
    arc_2_14_13  out_degree_1431  1
    arc_2_14_13  original_T_including_depot_unload_1475  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1262  1
    load_2_14_13  free_load_conservation_1430  -1
    load_2_14_13  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1264  -30
    arc_2_14_15  connected_order_arc_1265  -12
    arc_2_14_15  out_degree_1431  1
    arc_2_14_15  in_degree_1438  1
    arc_2_14_15  original_T_including_depot_unload_1475  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1264  1
    load_2_14_15  free_load_conservation_1436  1
    load_2_14_15  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1266  -30
    arc_2_14_16  connected_order_arc_1267  -12
    arc_2_14_16  out_degree_1431  1
    arc_2_14_16  in_degree_1444  1
    arc_2_14_16  original_T_including_depot_unload_1475  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1266  1
    load_2_14_16  free_load_conservation_1436  1
    load_2_14_16  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1268  -30
    arc_2_14_17  connected_order_arc_1269  -12
    arc_2_14_17  out_degree_1431  1
    arc_2_14_17  in_degree_1450  1
    arc_2_14_17  original_T_including_depot_unload_1475  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1268  1
    load_2_14_17  free_load_conservation_1436  1
    load_2_14_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1270  -30
    arc_2_14_18  connected_order_arc_1271  -12
    arc_2_14_18  out_degree_1431  1
    arc_2_14_18  in_degree_1456  1
    arc_2_14_18  original_T_including_depot_unload_1475  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1270  1
    load_2_14_18  free_load_conservation_1436  1
    load_2_14_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1272  -30
    arc_2_14_19  connected_order_arc_1273  -12
    arc_2_14_19  out_degree_1431  1
    arc_2_14_19  in_degree_1462  1
    arc_2_14_19  original_T_including_depot_unload_1475  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1272  1
    load_2_14_19  free_load_conservation_1436  1
    load_2_14_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1274  -30
    arc_2_14_20  connected_order_arc_1275  -12
    arc_2_14_20  out_degree_1431  1
    arc_2_14_20  in_degree_1468  1
    arc_2_14_20  original_T_including_depot_unload_1475  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1274  1
    load_2_14_20  free_load_conservation_1436  1
    load_2_14_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1276  -30
    arc_2_15_0  depot_return_or_bypass_1403  1
    arc_2_15_0  out_degree_1437  1
    arc_2_15_0  original_T_including_depot_unload_1475  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1276  1
    load_2_15_0  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1277  -30
    arc_2_15_10  connected_order_arc_1278  -12
    arc_2_15_10  in_degree_1405  1
    arc_2_15_10  out_degree_1437  1
    arc_2_15_10  original_T_including_depot_unload_1475  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1277  1
    load_2_15_10  segment_load_conservation_1408  -1
    load_2_15_10  segment_prefix_lb_1409  1
    load_2_15_10  segment_prefix_ub_1410  1
    load_2_15_10  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1279  -30
    arc_2_15_11  connected_order_arc_1280  -12
    arc_2_15_11  in_degree_1412  1
    arc_2_15_11  out_degree_1437  1
    arc_2_15_11  original_T_including_depot_unload_1475  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1279  1
    load_2_15_11  segment_load_conservation_1415  -1
    load_2_15_11  segment_prefix_lb_1416  1
    load_2_15_11  segment_prefix_ub_1417  1
    load_2_15_11  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1281  -30
    arc_2_15_12  connected_order_arc_1282  -12
    arc_2_15_12  in_degree_1419  1
    arc_2_15_12  out_degree_1437  1
    arc_2_15_12  original_T_including_depot_unload_1475  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1281  1
    load_2_15_12  segment_load_conservation_1422  -1
    load_2_15_12  segment_prefix_lb_1423  1
    load_2_15_12  segment_prefix_ub_1424  1
    load_2_15_12  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1283  -30
    arc_2_15_13  connected_order_arc_1284  -12
    arc_2_15_13  in_degree_1426  1
    arc_2_15_13  out_degree_1437  1
    arc_2_15_13  original_T_including_depot_unload_1475  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1283  1
    load_2_15_13  free_load_conservation_1430  -1
    load_2_15_13  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1285  -30
    arc_2_15_14  connected_order_arc_1286  -12
    arc_2_15_14  in_degree_1432  1
    arc_2_15_14  out_degree_1437  1
    arc_2_15_14  original_T_including_depot_unload_1475  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1285  1
    load_2_15_14  free_load_conservation_1436  -1
    load_2_15_14  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1287  -30
    arc_2_15_16  connected_order_arc_1288  -12
    arc_2_15_16  out_degree_1437  1
    arc_2_15_16  in_degree_1444  1
    arc_2_15_16  original_T_including_depot_unload_1475  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1287  1
    load_2_15_16  free_load_conservation_1442  1
    load_2_15_16  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1289  -30
    arc_2_15_17  connected_order_arc_1290  -12
    arc_2_15_17  out_degree_1437  1
    arc_2_15_17  in_degree_1450  1
    arc_2_15_17  original_T_including_depot_unload_1475  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1289  1
    load_2_15_17  free_load_conservation_1442  1
    load_2_15_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1291  -30
    arc_2_15_18  connected_order_arc_1292  -12
    arc_2_15_18  out_degree_1437  1
    arc_2_15_18  in_degree_1456  1
    arc_2_15_18  original_T_including_depot_unload_1475  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1291  1
    load_2_15_18  free_load_conservation_1442  1
    load_2_15_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1293  -30
    arc_2_15_19  connected_order_arc_1294  -12
    arc_2_15_19  out_degree_1437  1
    arc_2_15_19  in_degree_1462  1
    arc_2_15_19  original_T_including_depot_unload_1475  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1293  1
    load_2_15_19  free_load_conservation_1442  1
    load_2_15_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1295  -30
    arc_2_15_20  connected_order_arc_1296  -12
    arc_2_15_20  out_degree_1437  1
    arc_2_15_20  in_degree_1468  1
    arc_2_15_20  original_T_including_depot_unload_1475  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1295  1
    load_2_15_20  free_load_conservation_1442  1
    load_2_15_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1297  -30
    arc_2_16_0  depot_return_or_bypass_1403  1
    arc_2_16_0  out_degree_1443  1
    arc_2_16_0  original_T_including_depot_unload_1475  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1297  1
    load_2_16_0  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1298  -30
    arc_2_16_10  connected_order_arc_1299  -12
    arc_2_16_10  in_degree_1405  1
    arc_2_16_10  out_degree_1443  1
    arc_2_16_10  original_T_including_depot_unload_1475  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1298  1
    load_2_16_10  segment_load_conservation_1408  -1
    load_2_16_10  segment_prefix_lb_1409  1
    load_2_16_10  segment_prefix_ub_1410  1
    load_2_16_10  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1300  -30
    arc_2_16_11  connected_order_arc_1301  -12
    arc_2_16_11  in_degree_1412  1
    arc_2_16_11  out_degree_1443  1
    arc_2_16_11  original_T_including_depot_unload_1475  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1300  1
    load_2_16_11  segment_load_conservation_1415  -1
    load_2_16_11  segment_prefix_lb_1416  1
    load_2_16_11  segment_prefix_ub_1417  1
    load_2_16_11  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1302  -30
    arc_2_16_12  connected_order_arc_1303  -12
    arc_2_16_12  in_degree_1419  1
    arc_2_16_12  out_degree_1443  1
    arc_2_16_12  original_T_including_depot_unload_1475  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1302  1
    load_2_16_12  segment_load_conservation_1422  -1
    load_2_16_12  segment_prefix_lb_1423  1
    load_2_16_12  segment_prefix_ub_1424  1
    load_2_16_12  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1304  -30
    arc_2_16_13  connected_order_arc_1305  -12
    arc_2_16_13  in_degree_1426  1
    arc_2_16_13  out_degree_1443  1
    arc_2_16_13  original_T_including_depot_unload_1475  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1304  1
    load_2_16_13  free_load_conservation_1430  -1
    load_2_16_13  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1306  -30
    arc_2_16_14  connected_order_arc_1307  -12
    arc_2_16_14  in_degree_1432  1
    arc_2_16_14  out_degree_1443  1
    arc_2_16_14  original_T_including_depot_unload_1475  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1306  1
    load_2_16_14  free_load_conservation_1436  -1
    load_2_16_14  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1308  -30
    arc_2_16_15  connected_order_arc_1309  -12
    arc_2_16_15  in_degree_1438  1
    arc_2_16_15  out_degree_1443  1
    arc_2_16_15  original_T_including_depot_unload_1475  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1308  1
    load_2_16_15  free_load_conservation_1442  -1
    load_2_16_15  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1310  -30
    arc_2_16_17  connected_order_arc_1311  -12
    arc_2_16_17  out_degree_1443  1
    arc_2_16_17  in_degree_1450  1
    arc_2_16_17  original_T_including_depot_unload_1475  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1310  1
    load_2_16_17  free_load_conservation_1448  1
    load_2_16_17  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1312  -30
    arc_2_16_18  connected_order_arc_1313  -12
    arc_2_16_18  out_degree_1443  1
    arc_2_16_18  in_degree_1456  1
    arc_2_16_18  original_T_including_depot_unload_1475  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1312  1
    load_2_16_18  free_load_conservation_1448  1
    load_2_16_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1314  -30
    arc_2_16_19  connected_order_arc_1315  -12
    arc_2_16_19  out_degree_1443  1
    arc_2_16_19  in_degree_1462  1
    arc_2_16_19  original_T_including_depot_unload_1475  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1314  1
    load_2_16_19  free_load_conservation_1448  1
    load_2_16_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1316  -30
    arc_2_16_20  connected_order_arc_1317  -12
    arc_2_16_20  out_degree_1443  1
    arc_2_16_20  in_degree_1468  1
    arc_2_16_20  original_T_including_depot_unload_1475  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1316  1
    load_2_16_20  free_load_conservation_1448  1
    load_2_16_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1318  -30
    arc_2_17_0  depot_return_or_bypass_1403  1
    arc_2_17_0  out_degree_1449  1
    arc_2_17_0  original_T_including_depot_unload_1475  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1318  1
    load_2_17_0  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1319  -30
    arc_2_17_10  connected_order_arc_1320  -12
    arc_2_17_10  in_degree_1405  1
    arc_2_17_10  out_degree_1449  1
    arc_2_17_10  original_T_including_depot_unload_1475  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1319  1
    load_2_17_10  segment_load_conservation_1408  -1
    load_2_17_10  segment_prefix_lb_1409  1
    load_2_17_10  segment_prefix_ub_1410  1
    load_2_17_10  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1321  -30
    arc_2_17_11  connected_order_arc_1322  -12
    arc_2_17_11  in_degree_1412  1
    arc_2_17_11  out_degree_1449  1
    arc_2_17_11  original_T_including_depot_unload_1475  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1321  1
    load_2_17_11  segment_load_conservation_1415  -1
    load_2_17_11  segment_prefix_lb_1416  1
    load_2_17_11  segment_prefix_ub_1417  1
    load_2_17_11  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1323  -30
    arc_2_17_12  connected_order_arc_1324  -12
    arc_2_17_12  in_degree_1419  1
    arc_2_17_12  out_degree_1449  1
    arc_2_17_12  original_T_including_depot_unload_1475  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1323  1
    load_2_17_12  segment_load_conservation_1422  -1
    load_2_17_12  segment_prefix_lb_1423  1
    load_2_17_12  segment_prefix_ub_1424  1
    load_2_17_12  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1325  -30
    arc_2_17_13  connected_order_arc_1326  -12
    arc_2_17_13  in_degree_1426  1
    arc_2_17_13  out_degree_1449  1
    arc_2_17_13  original_T_including_depot_unload_1475  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1325  1
    load_2_17_13  free_load_conservation_1430  -1
    load_2_17_13  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1327  -30
    arc_2_17_14  connected_order_arc_1328  -12
    arc_2_17_14  in_degree_1432  1
    arc_2_17_14  out_degree_1449  1
    arc_2_17_14  original_T_including_depot_unload_1475  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1327  1
    load_2_17_14  free_load_conservation_1436  -1
    load_2_17_14  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1329  -30
    arc_2_17_15  connected_order_arc_1330  -12
    arc_2_17_15  in_degree_1438  1
    arc_2_17_15  out_degree_1449  1
    arc_2_17_15  original_T_including_depot_unload_1475  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1329  1
    load_2_17_15  free_load_conservation_1442  -1
    load_2_17_15  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1331  -30
    arc_2_17_16  connected_order_arc_1332  -12
    arc_2_17_16  in_degree_1444  1
    arc_2_17_16  out_degree_1449  1
    arc_2_17_16  original_T_including_depot_unload_1475  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1331  1
    load_2_17_16  free_load_conservation_1448  -1
    load_2_17_16  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1333  -30
    arc_2_17_18  connected_order_arc_1334  -12
    arc_2_17_18  out_degree_1449  1
    arc_2_17_18  in_degree_1456  1
    arc_2_17_18  original_T_including_depot_unload_1475  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1333  1
    load_2_17_18  free_load_conservation_1454  1
    load_2_17_18  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1335  -30
    arc_2_17_19  connected_order_arc_1336  -12
    arc_2_17_19  out_degree_1449  1
    arc_2_17_19  in_degree_1462  1
    arc_2_17_19  original_T_including_depot_unload_1475  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1335  1
    load_2_17_19  free_load_conservation_1454  1
    load_2_17_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1337  -30
    arc_2_17_20  connected_order_arc_1338  -12
    arc_2_17_20  out_degree_1449  1
    arc_2_17_20  in_degree_1468  1
    arc_2_17_20  original_T_including_depot_unload_1475  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1337  1
    load_2_17_20  free_load_conservation_1454  1
    load_2_17_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1339  -30
    arc_2_18_0  depot_return_or_bypass_1403  1
    arc_2_18_0  out_degree_1455  1
    arc_2_18_0  original_T_including_depot_unload_1475  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1339  1
    load_2_18_0  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1340  -30
    arc_2_18_10  connected_order_arc_1341  -12
    arc_2_18_10  in_degree_1405  1
    arc_2_18_10  out_degree_1455  1
    arc_2_18_10  original_T_including_depot_unload_1475  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1340  1
    load_2_18_10  segment_load_conservation_1408  -1
    load_2_18_10  segment_prefix_lb_1409  1
    load_2_18_10  segment_prefix_ub_1410  1
    load_2_18_10  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1342  -30
    arc_2_18_11  connected_order_arc_1343  -12
    arc_2_18_11  in_degree_1412  1
    arc_2_18_11  out_degree_1455  1
    arc_2_18_11  original_T_including_depot_unload_1475  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1342  1
    load_2_18_11  segment_load_conservation_1415  -1
    load_2_18_11  segment_prefix_lb_1416  1
    load_2_18_11  segment_prefix_ub_1417  1
    load_2_18_11  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1344  -30
    arc_2_18_12  connected_order_arc_1345  -12
    arc_2_18_12  in_degree_1419  1
    arc_2_18_12  out_degree_1455  1
    arc_2_18_12  original_T_including_depot_unload_1475  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1344  1
    load_2_18_12  segment_load_conservation_1422  -1
    load_2_18_12  segment_prefix_lb_1423  1
    load_2_18_12  segment_prefix_ub_1424  1
    load_2_18_12  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1346  -30
    arc_2_18_13  connected_order_arc_1347  -12
    arc_2_18_13  in_degree_1426  1
    arc_2_18_13  out_degree_1455  1
    arc_2_18_13  original_T_including_depot_unload_1475  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1346  1
    load_2_18_13  free_load_conservation_1430  -1
    load_2_18_13  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1348  -30
    arc_2_18_14  connected_order_arc_1349  -12
    arc_2_18_14  in_degree_1432  1
    arc_2_18_14  out_degree_1455  1
    arc_2_18_14  original_T_including_depot_unload_1475  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1348  1
    load_2_18_14  free_load_conservation_1436  -1
    load_2_18_14  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1350  -30
    arc_2_18_15  connected_order_arc_1351  -12
    arc_2_18_15  in_degree_1438  1
    arc_2_18_15  out_degree_1455  1
    arc_2_18_15  original_T_including_depot_unload_1475  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1350  1
    load_2_18_15  free_load_conservation_1442  -1
    load_2_18_15  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1352  -30
    arc_2_18_16  connected_order_arc_1353  -12
    arc_2_18_16  in_degree_1444  1
    arc_2_18_16  out_degree_1455  1
    arc_2_18_16  original_T_including_depot_unload_1475  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1352  1
    load_2_18_16  free_load_conservation_1448  -1
    load_2_18_16  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1354  -30
    arc_2_18_17  connected_order_arc_1355  -12
    arc_2_18_17  in_degree_1450  1
    arc_2_18_17  out_degree_1455  1
    arc_2_18_17  original_T_including_depot_unload_1475  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1354  1
    load_2_18_17  free_load_conservation_1454  -1
    load_2_18_17  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1356  -30
    arc_2_18_19  connected_order_arc_1357  -12
    arc_2_18_19  out_degree_1455  1
    arc_2_18_19  in_degree_1462  1
    arc_2_18_19  original_T_including_depot_unload_1475  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1356  1
    load_2_18_19  free_load_conservation_1460  1
    load_2_18_19  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1358  -30
    arc_2_18_20  connected_order_arc_1359  -12
    arc_2_18_20  out_degree_1455  1
    arc_2_18_20  in_degree_1468  1
    arc_2_18_20  original_T_including_depot_unload_1475  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1358  1
    load_2_18_20  free_load_conservation_1460  1
    load_2_18_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1360  -30
    arc_2_19_0  depot_return_or_bypass_1403  1
    arc_2_19_0  out_degree_1461  1
    arc_2_19_0  original_T_including_depot_unload_1475  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1360  1
    load_2_19_0  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1361  -30
    arc_2_19_10  connected_order_arc_1362  -12
    arc_2_19_10  in_degree_1405  1
    arc_2_19_10  out_degree_1461  1
    arc_2_19_10  original_T_including_depot_unload_1475  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1361  1
    load_2_19_10  segment_load_conservation_1408  -1
    load_2_19_10  segment_prefix_lb_1409  1
    load_2_19_10  segment_prefix_ub_1410  1
    load_2_19_10  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1363  -30
    arc_2_19_11  connected_order_arc_1364  -12
    arc_2_19_11  in_degree_1412  1
    arc_2_19_11  out_degree_1461  1
    arc_2_19_11  original_T_including_depot_unload_1475  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1363  1
    load_2_19_11  segment_load_conservation_1415  -1
    load_2_19_11  segment_prefix_lb_1416  1
    load_2_19_11  segment_prefix_ub_1417  1
    load_2_19_11  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1365  -30
    arc_2_19_12  connected_order_arc_1366  -12
    arc_2_19_12  in_degree_1419  1
    arc_2_19_12  out_degree_1461  1
    arc_2_19_12  original_T_including_depot_unload_1475  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1365  1
    load_2_19_12  segment_load_conservation_1422  -1
    load_2_19_12  segment_prefix_lb_1423  1
    load_2_19_12  segment_prefix_ub_1424  1
    load_2_19_12  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1367  -30
    arc_2_19_13  connected_order_arc_1368  -12
    arc_2_19_13  in_degree_1426  1
    arc_2_19_13  out_degree_1461  1
    arc_2_19_13  original_T_including_depot_unload_1475  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1367  1
    load_2_19_13  free_load_conservation_1430  -1
    load_2_19_13  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1369  -30
    arc_2_19_14  connected_order_arc_1370  -12
    arc_2_19_14  in_degree_1432  1
    arc_2_19_14  out_degree_1461  1
    arc_2_19_14  original_T_including_depot_unload_1475  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1369  1
    load_2_19_14  free_load_conservation_1436  -1
    load_2_19_14  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1371  -30
    arc_2_19_15  connected_order_arc_1372  -12
    arc_2_19_15  in_degree_1438  1
    arc_2_19_15  out_degree_1461  1
    arc_2_19_15  original_T_including_depot_unload_1475  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1371  1
    load_2_19_15  free_load_conservation_1442  -1
    load_2_19_15  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1373  -30
    arc_2_19_16  connected_order_arc_1374  -12
    arc_2_19_16  in_degree_1444  1
    arc_2_19_16  out_degree_1461  1
    arc_2_19_16  original_T_including_depot_unload_1475  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1373  1
    load_2_19_16  free_load_conservation_1448  -1
    load_2_19_16  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1375  -30
    arc_2_19_17  connected_order_arc_1376  -12
    arc_2_19_17  in_degree_1450  1
    arc_2_19_17  out_degree_1461  1
    arc_2_19_17  original_T_including_depot_unload_1475  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1375  1
    load_2_19_17  free_load_conservation_1454  -1
    load_2_19_17  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1377  -30
    arc_2_19_18  connected_order_arc_1378  -12
    arc_2_19_18  in_degree_1456  1
    arc_2_19_18  out_degree_1461  1
    arc_2_19_18  original_T_including_depot_unload_1475  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1377  1
    load_2_19_18  free_load_conservation_1460  -1
    load_2_19_18  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1379  -30
    arc_2_19_20  connected_order_arc_1380  -12
    arc_2_19_20  out_degree_1461  1
    arc_2_19_20  in_degree_1468  1
    arc_2_19_20  original_T_including_depot_unload_1475  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1379  1
    load_2_19_20  free_load_conservation_1466  1
    load_2_19_20  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1381  -30
    arc_2_20_0  depot_return_or_bypass_1403  1
    arc_2_20_0  out_degree_1467  1
    arc_2_20_0  original_T_including_depot_unload_1475  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1381  1
    load_2_20_0  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1382  -30
    arc_2_20_10  connected_order_arc_1383  -12
    arc_2_20_10  in_degree_1405  1
    arc_2_20_10  out_degree_1467  1
    arc_2_20_10  original_T_including_depot_unload_1475  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1382  1
    load_2_20_10  segment_load_conservation_1408  -1
    load_2_20_10  segment_prefix_lb_1409  1
    load_2_20_10  segment_prefix_ub_1410  1
    load_2_20_10  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1384  -30
    arc_2_20_11  connected_order_arc_1385  -12
    arc_2_20_11  in_degree_1412  1
    arc_2_20_11  out_degree_1467  1
    arc_2_20_11  original_T_including_depot_unload_1475  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1384  1
    load_2_20_11  segment_load_conservation_1415  -1
    load_2_20_11  segment_prefix_lb_1416  1
    load_2_20_11  segment_prefix_ub_1417  1
    load_2_20_11  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1386  -30
    arc_2_20_12  connected_order_arc_1387  -12
    arc_2_20_12  in_degree_1419  1
    arc_2_20_12  out_degree_1467  1
    arc_2_20_12  original_T_including_depot_unload_1475  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1386  1
    load_2_20_12  segment_load_conservation_1422  -1
    load_2_20_12  segment_prefix_lb_1423  1
    load_2_20_12  segment_prefix_ub_1424  1
    load_2_20_12  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1388  -30
    arc_2_20_13  connected_order_arc_1389  -12
    arc_2_20_13  in_degree_1426  1
    arc_2_20_13  out_degree_1467  1
    arc_2_20_13  original_T_including_depot_unload_1475  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1388  1
    load_2_20_13  free_load_conservation_1430  -1
    load_2_20_13  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1390  -30
    arc_2_20_14  connected_order_arc_1391  -12
    arc_2_20_14  in_degree_1432  1
    arc_2_20_14  out_degree_1467  1
    arc_2_20_14  original_T_including_depot_unload_1475  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1390  1
    load_2_20_14  free_load_conservation_1436  -1
    load_2_20_14  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1392  -30
    arc_2_20_15  connected_order_arc_1393  -12
    arc_2_20_15  in_degree_1438  1
    arc_2_20_15  out_degree_1467  1
    arc_2_20_15  original_T_including_depot_unload_1475  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1392  1
    load_2_20_15  free_load_conservation_1442  -1
    load_2_20_15  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1394  -30
    arc_2_20_16  connected_order_arc_1395  -12
    arc_2_20_16  in_degree_1444  1
    arc_2_20_16  out_degree_1467  1
    arc_2_20_16  original_T_including_depot_unload_1475  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1394  1
    load_2_20_16  free_load_conservation_1448  -1
    load_2_20_16  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1396  -30
    arc_2_20_17  connected_order_arc_1397  -12
    arc_2_20_17  in_degree_1450  1
    arc_2_20_17  out_degree_1467  1
    arc_2_20_17  original_T_including_depot_unload_1475  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1396  1
    load_2_20_17  free_load_conservation_1454  -1
    load_2_20_17  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1398  -30
    arc_2_20_18  connected_order_arc_1399  -12
    arc_2_20_18  in_degree_1456  1
    arc_2_20_18  out_degree_1467  1
    arc_2_20_18  original_T_including_depot_unload_1475  3.0639095850963037e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1398  1
    load_2_20_18  free_load_conservation_1460  -1
    load_2_20_18  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1400  -30
    arc_2_20_19  connected_order_arc_1401  -12
    arc_2_20_19  in_degree_1462  1
    arc_2_20_19  out_degree_1467  1
    arc_2_20_19  original_T_including_depot_unload_1475  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1400  1
    load_2_20_19  free_load_conservation_1466  -1
    load_2_20_19  free_load_conservation_1472  1
RHS
    RHS1      OBJ       -2.3887545743711461e-01
    RHS1      onehot_28_14  1
    RHS1      onehot_29_39  1
    RHS1      onehot_34_74  1
    RHS1      onehot_26_95  1
    RHS1      onehot_22_130  1
    RHS1      onehot_33_157  1
    RHS1      onehot_27_174  1
    RHS1      onehot_35_209  1
    RHS1      stock_ub_213  24
    RHS1      parent_nonstrict_scope_214  3.0636281570314328e-01
    RHS1      normalization_271  1
    RHS1      connected_order_arc_375  -13
    RHS1      connected_order_arc_377  -13
    RHS1      connected_order_arc_379  -13
    RHS1      connected_order_arc_381  -13
    RHS1      connected_order_arc_383  -13
    RHS1      connected_order_arc_385  -13
    RHS1      connected_order_arc_387  -13
    RHS1      connected_order_arc_389  -13
    RHS1      connected_order_arc_391  -13
    RHS1      connected_order_arc_393  -13
    RHS1      connected_order_arc_395  -13
    RHS1      connected_order_arc_397  -13
    RHS1      connected_order_arc_400  -13
    RHS1      connected_order_arc_402  -13
    RHS1      connected_order_arc_404  -13
    RHS1      connected_order_arc_406  -13
    RHS1      connected_order_arc_408  -13
    RHS1      connected_order_arc_410  -13
    RHS1      connected_order_arc_412  -13
    RHS1      connected_order_arc_414  -13
    RHS1      connected_order_arc_416  -13
    RHS1      connected_order_arc_418  -13
    RHS1      connected_order_arc_420  -13
    RHS1      connected_order_arc_422  -13
    RHS1      connected_order_arc_425  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_435  -13
    RHS1      connected_order_arc_437  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_693  -13
    RHS1      connected_order_arc_695  -13
    RHS1      connected_order_arc_697  -13
    RHS1      depot_departure_or_bypass_698  1
    RHS1      depot_return_or_bypass_699  1
    RHS1      segment_load_conservation_704  2
    RHS1      segment_prefix_ub_706  9
    RHS1      segment_load_conservation_711  5
    RHS1      segment_prefix_ub_713  15
    RHS1      segment_load_conservation_718  -4
    RHS1      segment_prefix_lb_719  4
    RHS1      segment_prefix_ub_720  20
    RHS1      segment_load_conservation_725  2
    RHS1      segment_prefix_ub_727  18
    RHS1      segment_load_conservation_732  -3
    RHS1      segment_prefix_lb_733  3
    RHS1      segment_prefix_ub_734  20
    RHS1      fixed_segment_relative_order_783  1
    RHS1      fixed_segment_relative_order_784  1
    RHS1      fixed_segment_relative_order_785  1
    RHS1      fixed_segment_relative_order_786  1
    RHS1      original_T_including_depot_unload_787  1.5605895099879472e+03
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_809  -12
    RHS1      connected_order_arc_811  -12
    RHS1      connected_order_arc_813  -12
    RHS1      connected_order_arc_815  -12
    RHS1      connected_order_arc_817  -12
    RHS1      connected_order_arc_819  -12
    RHS1      connected_order_arc_821  -12
    RHS1      connected_order_arc_823  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_836  -12
    RHS1      connected_order_arc_838  -12
    RHS1      connected_order_arc_840  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_844  -12
    RHS1      connected_order_arc_846  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      depot_departure_or_bypass_1077  1
    RHS1      depot_return_or_bypass_1078  1
    RHS1      segment_load_conservation_1083  5
    RHS1      segment_prefix_ub_1085  20
    RHS1      segment_load_conservation_1090  4
    RHS1      segment_prefix_lb_1091  1
    RHS1      segment_prefix_ub_1092  21
    RHS1      segment_load_conservation_1097  -4
    RHS1      segment_prefix_lb_1098  4
    RHS1      segment_prefix_ub_1099  25
    RHS1      segment_load_conservation_1104  -5
    RHS1      segment_prefix_lb_1105  5
    RHS1      segment_prefix_ub_1106  25
    RHS1      fixed_segment_relative_order_1155  1
    RHS1      fixed_segment_relative_order_1156  1
    RHS1      fixed_segment_relative_order_1157  1
    RHS1      original_T_including_depot_unload_1158  4.0640082462635783e+03
    RHS1      connected_order_arc_1173  -11
    RHS1      connected_order_arc_1175  -11
    RHS1      connected_order_arc_1177  -11
    RHS1      connected_order_arc_1179  -11
    RHS1      connected_order_arc_1181  -11
    RHS1      connected_order_arc_1183  -11
    RHS1      connected_order_arc_1185  -11
    RHS1      connected_order_arc_1187  -11
    RHS1      connected_order_arc_1189  -11
    RHS1      connected_order_arc_1191  -11
    RHS1      connected_order_arc_1194  -11
    RHS1      connected_order_arc_1196  -11
    RHS1      connected_order_arc_1198  -11
    RHS1      connected_order_arc_1200  -11
    RHS1      connected_order_arc_1202  -11
    RHS1      connected_order_arc_1204  -11
    RHS1      connected_order_arc_1206  -11
    RHS1      connected_order_arc_1208  -11
    RHS1      connected_order_arc_1210  -11
    RHS1      connected_order_arc_1212  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1217  -11
    RHS1      connected_order_arc_1219  -11
    RHS1      connected_order_arc_1221  -11
    RHS1      connected_order_arc_1223  -11
    RHS1      connected_order_arc_1225  -11
    RHS1      connected_order_arc_1227  -11
    RHS1      connected_order_arc_1229  -11
    RHS1      connected_order_arc_1231  -11
    RHS1      connected_order_arc_1233  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1238  -11
    RHS1      connected_order_arc_1240  -11
    RHS1      connected_order_arc_1242  -11
    RHS1      connected_order_arc_1244  -11
    RHS1      connected_order_arc_1246  -11
    RHS1      connected_order_arc_1248  -11
    RHS1      connected_order_arc_1250  -11
    RHS1      connected_order_arc_1252  -11
    RHS1      connected_order_arc_1254  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1261  -11
    RHS1      connected_order_arc_1263  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1267  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1288  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      depot_departure_or_bypass_1402  1
    RHS1      depot_return_or_bypass_1403  1
    RHS1      segment_load_conservation_1408  2
    RHS1      segment_prefix_ub_1410  28
    RHS1      segment_load_conservation_1415  -4
    RHS1      segment_prefix_lb_1416  4
    RHS1      segment_prefix_ub_1417  30
    RHS1      segment_load_conservation_1422  2
    RHS1      segment_prefix_ub_1424  28
    RHS1      fixed_segment_relative_order_1473  1
    RHS1      fixed_segment_relative_order_1474  1
    RHS1      original_T_including_depot_unload_1475  5820
BOUNDS
 LO BND1      t         2.5039496825324466e-02
 UP BND1      t         4.1939188177185088e-02
 UP BND1      q         4.1816696950410492e-01
 BV BND1      x_28_0  
 UP BND1      w_28_0    4.1939188177185088e-02
 BV BND1      x_28_1  
 UP BND1      w_28_1    4.1939188177185088e-02
 BV BND1      x_28_2  
 UP BND1      w_28_2    4.1939188177185088e-02
 BV BND1      x_28_3  
 UP BND1      w_28_3    4.1939188177185088e-02
 BV BND1      x_28_4  
 UP BND1      w_28_4    4.1939188177185088e-02
 BV BND1      x_28_5  
 UP BND1      w_28_5    4.1939188177185088e-02
 BV BND1      x_28_6  
 UP BND1      w_28_6    4.1939188177185088e-02
 UP BND1      rho_28    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.1939188177185088e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.1939188177185088e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.1939188177185088e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.1939188177185088e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.1939188177185088e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.1939188177185088e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.1939188177185088e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.1939188177185088e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.1939188177185088e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.1939188177185088e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.1939188177185088e-02
 UP BND1      rho_29    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.1939188177185088e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.1939188177185088e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.1939188177185088e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.1939188177185088e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.1939188177185088e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.1939188177185088e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.1939188177185088e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.1939188177185088e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.1939188177185088e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.1939188177185088e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.1939188177185088e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.1939188177185088e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.1939188177185088e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.1939188177185088e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.1939188177185088e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.1939188177185088e-02
 UP BND1      rho_34    1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.1939188177185088e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.1939188177185088e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.1939188177185088e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.1939188177185088e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.1939188177185088e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.1939188177185088e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.1939188177185088e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.1939188177185088e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.1939188177185088e-02
 UP BND1      rho_26    1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.1939188177185088e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.1939188177185088e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.1939188177185088e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.1939188177185088e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.1939188177185088e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.1939188177185088e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.1939188177185088e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.1939188177185088e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.1939188177185088e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.1939188177185088e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.1939188177185088e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.1939188177185088e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.1939188177185088e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.1939188177185088e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.1939188177185088e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.1939188177185088e-02
 UP BND1      rho_22    1
 BV BND1      x_33_0  
 UP BND1      w_33_0    4.1939188177185088e-02
 BV BND1      x_33_1  
 UP BND1      w_33_1    4.1939188177185088e-02
 BV BND1      x_33_2  
 UP BND1      w_33_2    4.1939188177185088e-02
 BV BND1      x_33_3  
 UP BND1      w_33_3    4.1939188177185088e-02
 BV BND1      x_33_4  
 UP BND1      w_33_4    4.1939188177185088e-02
 BV BND1      x_33_5  
 UP BND1      w_33_5    4.1939188177185088e-02
 BV BND1      x_33_6  
 UP BND1      w_33_6    4.1939188177185088e-02
 BV BND1      x_33_7  
 UP BND1      w_33_7    4.1939188177185088e-02
 BV BND1      x_33_8  
 UP BND1      w_33_8    4.1939188177185088e-02
 BV BND1      x_33_9  
 UP BND1      w_33_9    4.1939188177185088e-02
 BV BND1      x_33_10 
 UP BND1      w_33_10   4.1939188177185088e-02
 BV BND1      x_33_11 
 UP BND1      w_33_11   4.1939188177185088e-02
 UP BND1      rho_33    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.1939188177185088e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.1939188177185088e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.1939188177185088e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.1939188177185088e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.1939188177185088e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.1939188177185088e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.1939188177185088e-02
 UP BND1      rho_27    1
 BV BND1      x_35_0  
 UP BND1      w_35_0    4.1939188177185088e-02
 BV BND1      x_35_1  
 UP BND1      w_35_1    4.1939188177185088e-02
 BV BND1      x_35_2  
 UP BND1      w_35_2    4.1939188177185088e-02
 BV BND1      x_35_3  
 UP BND1      w_35_3    4.1939188177185088e-02
 BV BND1      x_35_4  
 UP BND1      w_35_4    4.1939188177185088e-02
 BV BND1      x_35_5  
 UP BND1      w_35_5    4.1939188177185088e-02
 BV BND1      x_35_6  
 UP BND1      w_35_6    4.1939188177185088e-02
 BV BND1      x_35_7  
 UP BND1      w_35_7    4.1939188177185088e-02
 BV BND1      x_35_8  
 UP BND1      w_35_8    4.1939188177185088e-02
 BV BND1      x_35_9  
 UP BND1      w_35_9    4.1939188177185088e-02
 BV BND1      x_35_10 
 UP BND1      w_35_10   4.1939188177185088e-02
 BV BND1      x_35_11 
 UP BND1      w_35_11   4.1939188177185088e-02
 BV BND1      x_35_12 
 UP BND1      w_35_12   4.1939188177185088e-02
 BV BND1      x_35_13 
 UP BND1      w_35_13   4.1939188177185088e-02
 BV BND1      x_35_14 
 UP BND1      w_35_14   4.1939188177185088e-02
 BV BND1      x_35_15 
 UP BND1      w_35_15   4.1939188177185088e-02
 UP BND1      rho_35    1
 UP BND1      a_28_29   1
 UP BND1      a_28_34   1
 UP BND1      a_28_26   1
 UP BND1      a_28_22   1
 UP BND1      a_28_33   1
 UP BND1      a_28_27   1
 UP BND1      a_28_35   1
 UP BND1      a_29_34   1
 UP BND1      a_29_26   1
 UP BND1      a_29_22   1
 UP BND1      a_29_33   1
 UP BND1      a_29_27   1
 UP BND1      a_29_35   1
 UP BND1      a_34_26   1
 UP BND1      a_34_22   1
 UP BND1      a_34_33   1
 UP BND1      a_34_27   1
 UP BND1      a_34_35   1
 UP BND1      a_26_22   1
 UP BND1      a_26_33   1
 UP BND1      a_26_27   1
 UP BND1      a_26_35   1
 UP BND1      a_22_33   1
 UP BND1      a_22_27   1
 UP BND1      a_22_35   1
 UP BND1      a_33_27   1
 UP BND1      a_33_35   1
 UP BND1      a_27_35   1
 BV BND1      service_0_28_0
 BV BND1      service_0_28_2
 BV BND1      service_0_28_3
 BV BND1      service_0_28_4
 BV BND1      service_0_28_5
 BV BND1      service_0_28_6
 BV BND1      service_1_28_0
 BV BND1      service_1_28_2
 BV BND1      service_1_28_3
 BV BND1      service_1_28_4
 BV BND1      service_1_28_5
 BV BND1      service_1_28_6
 BV BND1      service_2_28_0
 BV BND1      service_2_28_2
 BV BND1      service_2_28_3
 BV BND1      service_2_28_4
 BV BND1      service_2_28_5
 BV BND1      service_2_28_6
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_26_0
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_0
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_0
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_33_0
 BV BND1      service_0_33_1
 BV BND1      service_0_33_2
 BV BND1      service_0_33_3
 BV BND1      service_0_33_4
 BV BND1      service_0_33_5
 BV BND1      service_0_33_6
 BV BND1      service_0_33_7
 BV BND1      service_0_33_9
 BV BND1      service_0_33_10
 BV BND1      service_0_33_11
 BV BND1      service_1_33_0
 BV BND1      service_1_33_1
 BV BND1      service_1_33_2
 BV BND1      service_1_33_3
 BV BND1      service_1_33_4
 BV BND1      service_1_33_5
 BV BND1      service_1_33_6
 BV BND1      service_1_33_7
 BV BND1      service_1_33_9
 BV BND1      service_1_33_10
 BV BND1      service_1_33_11
 BV BND1      service_2_33_0
 BV BND1      service_2_33_1
 BV BND1      service_2_33_2
 BV BND1      service_2_33_3
 BV BND1      service_2_33_4
 BV BND1      service_2_33_5
 BV BND1      service_2_33_6
 BV BND1      service_2_33_7
 BV BND1      service_2_33_9
 BV BND1      service_2_33_10
 BV BND1      service_2_33_11
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_11
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_11
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_11
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
