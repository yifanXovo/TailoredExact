* Signature: 0x90df0f63399e561f
NAME R157_mandatory_metric_tour
ROWS
 N  OBJ
 E  degree_0
 E  degree_1
 E  degree_2
 E  degree_3
 E  degree_4
 E  degree_5
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    edge[0,1]  OBJ       1
    edge[0,1]  degree_0  1
    edge[0,1]  degree_1  1
    edge[0,2]  OBJ       2
    edge[0,2]  degree_0  1
    edge[0,2]  degree_2  1
    edge[0,3]  OBJ       100
    edge[0,3]  degree_0  1
    edge[0,3]  degree_3  1
    edge[0,4]  OBJ       101
    edge[0,4]  degree_0  1
    edge[0,4]  degree_4  1
    edge[0,5]  OBJ       102
    edge[0,5]  degree_0  1
    edge[0,5]  degree_5  1
    edge[1,2]  OBJ       1
    edge[1,2]  degree_1  1
    edge[1,2]  degree_2  1
    edge[1,3]  OBJ       99
    edge[1,3]  degree_1  1
    edge[1,3]  degree_3  1
    edge[1,4]  OBJ       100
    edge[1,4]  degree_1  1
    edge[1,4]  degree_4  1
    edge[1,5]  OBJ       101
    edge[1,5]  degree_1  1
    edge[1,5]  degree_5  1
    edge[2,3]  OBJ       98
    edge[2,3]  degree_2  1
    edge[2,3]  degree_3  1
    edge[2,4]  OBJ       99
    edge[2,4]  degree_2  1
    edge[2,4]  degree_4  1
    edge[2,5]  OBJ       100
    edge[2,5]  degree_2  1
    edge[2,5]  degree_5  1
    edge[3,4]  OBJ       1
    edge[3,4]  degree_3  1
    edge[3,4]  degree_4  1
    edge[3,5]  OBJ       2
    edge[3,5]  degree_3  1
    edge[3,5]  degree_5  1
    edge[4,5]  OBJ       1
    edge[4,5]  degree_4  1
    edge[4,5]  degree_5  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      degree_0  2
    RHS1      degree_1  2
    RHS1      degree_2  2
    RHS1      degree_3  2
    RHS1      degree_4  2
    RHS1      degree_5  2
BOUNDS
 BV BND1      edge[0,1]
 BV BND1      edge[0,2]
 BV BND1      edge[0,3]
 BV BND1      edge[0,4]
 BV BND1      edge[0,5]
 BV BND1      edge[1,2]
 BV BND1      edge[1,3]
 BV BND1      edge[1,4]
 BV BND1      edge[1,5]
 BV BND1      edge[2,3]
 BV BND1      edge[2,4]
 BV BND1      edge[2,5]
 BV BND1      edge[3,4]
 BV BND1      edge[3,5]
 BV BND1      edge[4,5]
ENDATA
