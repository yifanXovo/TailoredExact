* Signature: 0xf5307223ecd02f9a
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  R2      
 L  R3      
 G  R4      
 L  R5      
 G  R6      
 L  R7      
 G  R8      
 L  R9      
 G  R10     
 L  R11     
 G  R12     
 L  R13     
 G  R14     
 L  R15     
 G  R16     
 L  R17     
 G  R18     
 L  R19     
 G  R20     
 L  R21     
 G  R22     
 L  R23     
 G  R24     
 L  R25     
 G  R26     
 L  R27     
 G  R28     
 L  R29     
 G  R30     
 L  R31     
 G  R32     
 L  R33     
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 G  R38     
 L  R39     
 G  R40     
 L  R41     
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  R46     
 L  R47     
 G  R48     
 L  R49     
 G  R50     
 L  R51     
 G  R52     
 L  R53     
 G  R54     
 L  R55     
 G  R56     
 L  R57     
 G  R58     
 L  R59     
 G  R60     
 L  R61     
 G  R62     
 L  R63     
 G  R64     
 L  R65     
 G  R66     
 L  R67     
 G  R68     
 L  R69     
 G  R70     
 L  R71     
 G  R72     
 L  R73     
 G  R74     
 L  R75     
 G  R76     
 L  R77     
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  R82     
 L  R83     
 G  R84     
 L  R85     
 G  R86     
 L  R87     
 G  R88     
 L  R89     
 G  R90     
 L  R91     
 G  R92     
 L  R93     
 G  R94     
 L  R95     
 G  R96     
 L  R97     
 G  R98     
 L  R99     
 G  R100    
 L  R101    
 G  R102    
 L  R103    
 G  R104    
 L  R105    
 G  R106    
 L  R107    
 G  R108    
 L  R109    
 G  R110    
 L  R111    
 G  R112    
 L  R113    
 G  R114    
 L  R115    
 G  R116    
 L  R117    
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  R122    
 L  R123    
 G  R124    
 L  R125    
 G  R126    
 L  R127    
 G  R128    
 L  R129    
 G  R130    
 L  R131    
 G  R132    
 L  R133    
 G  R134    
 L  R135    
 G  R136    
 L  R137    
 G  R138    
 L  R139    
 G  R140    
 L  R141    
 G  R142    
 L  R143    
 G  R144    
 L  R145    
 G  R146    
 L  R147    
 G  R148    
 L  R149    
 G  R150    
 L  R151    
 G  R152    
 L  R153    
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  R158    
 L  R159    
 G  R160    
 L  R161    
 G  R162    
 L  R163    
 G  R164    
 L  R165    
 G  R166    
 L  R167    
 G  R168    
 L  R169    
 G  R170    
 L  R171    
 G  R172    
 L  R173    
 G  R174    
 L  R175    
 G  R176    
 L  R177    
 G  R178    
 L  R179    
 G  R180    
 L  R181    
 G  R182    
 L  R183    
 G  R184    
 L  R185    
 G  R186    
 L  R187    
 G  R188    
 L  R189    
 G  R190    
 L  R191    
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  R196    
 L  R197    
 G  R198    
 L  R199    
 G  R200    
 L  R201    
 G  R202    
 L  R203    
 G  R204    
 L  R205    
 G  R206    
 L  R207    
 G  R208    
 L  R209    
 G  R210    
 L  R211    
 G  R212    
 L  R213    
 G  R214    
 L  R215    
 G  R216    
 L  R217    
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  R222    
 L  R223    
 G  R224    
 L  R225    
 G  R226    
 L  R227    
 G  R228    
 L  R229    
 G  R230    
 L  R231    
 G  R232    
 L  R233    
 G  R234    
 L  R235    
 G  R236    
 L  R237    
 G  R238    
 L  R239    
 G  R240    
 L  R241    
 G  R242    
 L  R243    
 G  R244    
 L  R245    
 G  R246    
 L  R247    
 G  R248    
 L  R249    
 G  R250    
 L  R251    
 G  R252    
 L  R253    
 G  R254    
 L  R255    
 G  R256    
 L  R257    
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  R262    
 L  R263    
 G  R264    
 L  R265    
 G  R266    
 L  R267    
 G  R268    
 L  R269    
 G  R270    
 L  R271    
 G  R272    
 L  R273    
 G  R274    
 L  R275    
 G  R276    
 L  R277    
 G  R278    
 L  R279    
 G  R280    
 L  R281    
 G  R282    
 L  R283    
 G  R284    
 L  R285    
 G  R286    
 L  R287    
 G  R288    
 L  R289    
 G  R290    
 L  R291    
 G  R292    
 L  R293    
 G  R294    
 L  R295    
 G  R296    
 L  R297    
 G  R298    
 L  R299    
 G  R300    
 L  R301    
 G  R302    
 L  R303    
 G  R304    
 L  R305    
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  R310    
 L  R311    
 G  R312    
 L  R313    
 G  R314    
 L  R315    
 G  R316    
 L  R317    
 G  R318    
 L  R319    
 G  R320    
 L  R321    
 G  R322    
 L  R323    
 G  R324    
 L  R325    
 G  R326    
 L  R327    
 G  R328    
 L  R329    
 G  R330    
 L  R331    
 G  R332    
 L  R333    
 G  R334    
 L  R335    
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  R340    
 L  R341    
 G  R342    
 L  R343    
 G  R344    
 L  R345    
 G  R346    
 L  R347    
 G  R348    
 L  R349    
 G  R350    
 L  R351    
 G  R352    
 L  R353    
 G  R354    
 L  R355    
 G  R356    
 L  R357    
 G  R358    
 L  R359    
 G  R360    
 L  R361    
 G  R362    
 L  R363    
 G  R364    
 L  R365    
 G  R366    
 L  R367    
 G  R368    
 L  R369    
 G  R370    
 L  R371    
 G  R372    
 L  R373    
 G  R374    
 L  R375    
 G  R376    
 L  R377    
 G  R378    
 L  R379    
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  R384    
 L  R385    
 G  R386    
 L  R387    
 G  R388    
 L  R389    
 G  R390    
 L  R391    
 G  R392    
 L  R393    
 G  R394    
 L  R395    
 G  R396    
 L  R397    
 G  R398    
 L  R399    
 G  R400    
 L  R401    
 G  R402    
 L  R403    
 G  R404    
 L  R405    
 G  R406    
 L  R407    
 G  R408    
 L  R409    
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  R414    
 L  R415    
 G  R416    
 L  R417    
 G  R418    
 L  R419    
 G  R420    
 L  R421    
 G  R422    
 L  R423    
 G  R424    
 L  R425    
 G  R426    
 L  R427    
 G  R428    
 L  R429    
 G  R430    
 L  R431    
 G  R432    
 L  R433    
 G  R434    
 L  R435    
 G  R436    
 L  R437    
 G  R438    
 L  R439    
 G  R440    
 L  R441    
 G  R442    
 L  R443    
 G  R444    
 L  R445    
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  R450    
 L  R451    
 G  R452    
 L  R453    
 G  R454    
 L  R455    
 G  R456    
 L  R457    
 G  R458    
 L  R459    
 G  R460    
 L  R461    
 G  R462    
 L  R463    
 G  R464    
 L  R465    
 G  R466    
 L  R467    
 G  R468    
 L  R469    
 G  R470    
 L  R471    
 G  R472    
 L  R473    
 G  R474    
 L  R475    
 G  R476    
 L  R477    
 G  R478    
 L  R479    
 G  R480    
 L  R481    
 G  R482    
 L  R483    
 G  R484    
 L  R485    
 G  R486    
 L  R487    
 G  R488    
 L  R489    
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  R494    
 L  R495    
 G  R496    
 L  R497    
 G  R498    
 L  R499    
 G  R500    
 L  R501    
 G  R502    
 L  R503    
 G  R504    
 L  R505    
 G  R506    
 L  R507    
 G  R508    
 L  R509    
 G  R510    
 L  R511    
 G  R512    
 L  R513    
 G  R514    
 L  R515    
 G  R516    
 L  R517    
 G  R518    
 L  R519    
 G  R520    
 L  R521    
 G  R522    
 L  R523    
 G  R524    
 L  R525    
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  R530    
 L  R531    
 G  R532    
 L  R533    
 G  R534    
 L  R535    
 G  R536    
 L  R537    
 G  R538    
 L  R539    
 G  R540    
 L  R541    
 G  R542    
 L  R543    
 G  R544    
 L  R545    
 G  R546    
 L  R547    
 G  R548    
 L  R549    
 G  R550    
 L  R551    
 G  R552    
 L  R553    
 G  R554    
 L  R555    
 G  R556    
 L  R557    
 G  R558    
 L  R559    
 G  R560    
 L  R561    
 G  R562    
 L  R563    
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  R568    
 L  R569    
 G  R570    
 L  R571    
 G  R572    
 L  R573    
 G  R574    
 L  R575    
 G  R576    
 L  R577    
 G  R578    
 L  R579    
 G  R580    
 L  R581    
 G  R582    
 L  R583    
 G  R584    
 L  R585    
 G  R586    
 L  R587    
 G  R588    
 L  R589    
 G  R590    
 L  R591    
 G  R592    
 L  R593    
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  R598    
 L  R599    
 G  R600    
 L  R601    
 G  R602    
 L  R603    
 G  R604    
 L  R605    
 G  R606    
 L  R607    
 G  R608    
 L  R609    
 G  R610    
 L  R611    
 G  R612    
 L  R613    
 G  R614    
 L  R615    
 G  R616    
 L  R617    
 G  R618    
 L  R619    
 G  R620    
 L  R621    
 G  R622    
 L  R623    
 G  R624    
 L  R625    
 G  R626    
 L  R627    
 G  R628    
 L  R629    
 G  R630    
 L  R631    
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  R636    
 L  R637    
 G  R638    
 L  R639    
 G  R640    
 L  R641    
 G  R642    
 L  R643    
 G  R644    
 L  R645    
 G  R646    
 L  R647    
 G  R648    
 L  R649    
 G  R650    
 L  R651    
 G  R652    
 L  R653    
 G  R654    
 L  R655    
 G  R656    
 L  R657    
 G  R658    
 L  R659    
 G  R660    
 L  R661    
 G  R662    
 L  R663    
 G  R664    
 L  R665    
 G  R666    
 L  R667    
 G  R668    
 L  R669    
 G  R670    
 L  R671    
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  R676    
 L  R677    
 G  R678    
 L  R679    
 G  R680    
 L  R681    
 G  R682    
 L  R683    
 G  R684    
 L  R685    
 G  R686    
 L  R687    
 G  R688    
 L  R689    
 G  R690    
 L  R691    
 G  R692    
 L  R693    
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  R698    
 L  R699    
 G  R700    
 L  R701    
 G  R702    
 L  R703    
 G  R704    
 L  R705    
 G  R706    
 L  R707    
 G  R708    
 L  R709    
 G  R710    
 L  R711    
 G  R712    
 L  R713    
 G  R714    
 L  R715    
 G  R716    
 L  R717    
 G  R718    
 L  R719    
 G  R720    
 L  R721    
 G  R722    
 L  R723    
 E  normalized_inventory_20
 E  normalized_ratio_20
 E  onehot_21
 E  mass_21 
 G  R728    
 L  R729    
 G  R730    
 L  R731    
 G  R732    
 L  R733    
 G  R734    
 L  R735    
 G  R736    
 L  R737    
 G  R738    
 L  R739    
 G  R740    
 L  R741    
 G  R742    
 L  R743    
 G  R744    
 L  R745    
 G  R746    
 L  R747    
 G  R748    
 L  R749    
 G  R750    
 L  R751    
 G  R752    
 L  R753    
 G  R754    
 L  R755    
 G  R756    
 L  R757    
 G  R758    
 L  R759    
 E  normalized_inventory_21
 E  normalized_ratio_21
 E  onehot_22
 E  mass_22 
 G  R764    
 L  R765    
 G  R766    
 L  R767    
 G  R768    
 L  R769    
 G  R770    
 L  R771    
 G  R772    
 L  R773    
 G  R774    
 L  R775    
 G  R776    
 L  R777    
 G  R778    
 L  R779    
 G  R780    
 L  R781    
 G  R782    
 L  R783    
 G  R784    
 L  R785    
 G  R786    
 L  R787    
 G  R788    
 L  R789    
 E  normalized_inventory_22
 E  normalized_ratio_22
 E  onehot_23
 E  mass_23 
 G  R794    
 L  R795    
 G  R796    
 L  R797    
 G  R798    
 L  R799    
 G  R800    
 L  R801    
 G  R802    
 L  R803    
 G  R804    
 L  R805    
 G  R806    
 L  R807    
 G  R808    
 L  R809    
 G  R810    
 L  R811    
 G  R812    
 L  R813    
 G  R814    
 L  R815    
 G  R816    
 L  R817    
 E  normalized_inventory_23
 E  normalized_ratio_23
 E  onehot_24
 E  mass_24 
 G  R822    
 L  R823    
 G  R824    
 L  R825    
 G  R826    
 L  R827    
 G  R828    
 L  R829    
 G  R830    
 L  R831    
 G  R832    
 L  R833    
 G  R834    
 L  R835    
 G  R836    
 L  R837    
 G  R838    
 L  R839    
 G  R840    
 L  R841    
 G  R842    
 L  R843    
 G  R844    
 L  R845    
 G  R846    
 L  R847    
 G  R848    
 L  R849    
 G  R850    
 L  R851    
 G  R852    
 L  R853    
 E  normalized_inventory_24
 E  normalized_ratio_24
 E  onehot_25
 E  mass_25 
 G  R858    
 L  R859    
 G  R860    
 L  R861    
 G  R862    
 L  R863    
 G  R864    
 L  R865    
 G  R866    
 L  R867    
 G  R868    
 L  R869    
 G  R870    
 L  R871    
 G  R872    
 L  R873    
 G  R874    
 L  R875    
 G  R876    
 L  R877    
 G  R878    
 L  R879    
 G  R880    
 L  R881    
 G  R882    
 L  R883    
 G  R884    
 L  R885    
 G  R886    
 L  R887    
 G  R888    
 L  R889    
 E  normalized_inventory_25
 E  normalized_ratio_25
 E  onehot_26
 E  mass_26 
 G  R894    
 L  R895    
 G  R896    
 L  R897    
 G  R898    
 L  R899    
 G  R900    
 L  R901    
 G  R902    
 L  R903    
 G  R904    
 L  R905    
 G  R906    
 L  R907    
 G  R908    
 L  R909    
 G  R910    
 L  R911    
 E  normalized_inventory_26
 E  normalized_ratio_26
 E  onehot_27
 E  mass_27 
 G  R916    
 L  R917    
 G  R918    
 L  R919    
 G  R920    
 L  R921    
 G  R922    
 L  R923    
 G  R924    
 L  R925    
 G  R926    
 L  R927    
 G  R928    
 L  R929    
 G  R930    
 L  R931    
 G  R932    
 L  R933    
 G  R934    
 L  R935    
 G  R936    
 L  R937    
 G  R938    
 L  R939    
 G  R940    
 L  R941    
 G  R942    
 L  R943    
 G  R944    
 L  R945    
 G  R946    
 L  R947    
 E  normalized_inventory_27
 E  normalized_ratio_27
 E  onehot_28
 E  mass_28 
 G  R952    
 L  R953    
 G  R954    
 L  R955    
 G  R956    
 L  R957    
 G  R958    
 L  R959    
 G  R960    
 L  R961    
 G  R962    
 L  R963    
 G  R964    
 L  R965    
 G  R966    
 L  R967    
 G  R968    
 L  R969    
 G  R970    
 L  R971    
 G  R972    
 L  R973    
 G  R974    
 L  R975    
 G  R976    
 L  R977    
 G  R978    
 L  R979    
 G  R980    
 L  R981    
 G  R982    
 L  R983    
 G  R984    
 L  R985    
 G  R986    
 L  R987    
 G  R988    
 L  R989    
 G  R990    
 L  R991    
 E  normalized_inventory_28
 E  normalized_ratio_28
 E  onehot_29
 E  mass_29 
 G  R996    
 L  R997    
 G  R998    
 L  R999    
 G  R1000   
 L  R1001   
 G  R1002   
 L  R1003   
 G  R1004   
 L  R1005   
 G  R1006   
 L  R1007   
 G  R1008   
 L  R1009   
 G  R1010   
 L  R1011   
 G  R1012   
 L  R1013   
 G  R1014   
 L  R1015   
 G  R1016   
 L  R1017   
 G  R1018   
 L  R1019   
 G  R1020   
 L  R1021   
 G  R1022   
 L  R1023   
 G  R1024   
 L  R1025   
 G  R1026   
 L  R1027   
 E  normalized_inventory_29
 E  normalized_ratio_29
 E  onehot_30
 E  mass_30 
 G  R1032   
 L  R1033   
 G  R1034   
 L  R1035   
 G  R1036   
 L  R1037   
 G  R1038   
 L  R1039   
 G  R1040   
 L  R1041   
 G  R1042   
 L  R1043   
 G  R1044   
 L  R1045   
 G  R1046   
 L  R1047   
 G  R1048   
 L  R1049   
 E  normalized_inventory_30
 E  normalized_ratio_30
 E  onehot_31
 E  mass_31 
 G  R1054   
 L  R1055   
 G  R1056   
 L  R1057   
 G  R1058   
 L  R1059   
 G  R1060   
 L  R1061   
 G  R1062   
 L  R1063   
 G  R1064   
 L  R1065   
 G  R1066   
 L  R1067   
 G  R1068   
 L  R1069   
 G  R1070   
 L  R1071   
 G  R1072   
 L  R1073   
 G  R1074   
 L  R1075   
 G  R1076   
 L  R1077   
 G  R1078   
 L  R1079   
 E  normalized_inventory_31
 E  normalized_ratio_31
 E  onehot_32
 E  mass_32 
 G  R1084   
 L  R1085   
 G  R1086   
 L  R1087   
 G  R1088   
 L  R1089   
 G  R1090   
 L  R1091   
 G  R1092   
 L  R1093   
 G  R1094   
 L  R1095   
 G  R1096   
 L  R1097   
 G  R1098   
 L  R1099   
 G  R1100   
 L  R1101   
 G  R1102   
 L  R1103   
 G  R1104   
 L  R1105   
 G  R1106   
 L  R1107   
 G  R1108   
 L  R1109   
 E  normalized_inventory_32
 E  normalized_ratio_32
 E  onehot_33
 E  mass_33 
 G  R1114   
 L  R1115   
 G  R1116   
 L  R1117   
 G  R1118   
 L  R1119   
 G  R1120   
 L  R1121   
 G  R1122   
 L  R1123   
 G  R1124   
 L  R1125   
 G  R1126   
 L  R1127   
 G  R1128   
 L  R1129   
 G  R1130   
 L  R1131   
 G  R1132   
 L  R1133   
 G  R1134   
 L  R1135   
 G  R1136   
 L  R1137   
 G  R1138   
 L  R1139   
 G  R1140   
 L  R1141   
 G  R1142   
 L  R1143   
 G  R1144   
 L  R1145   
 G  R1146   
 L  R1147   
 E  normalized_inventory_33
 E  normalized_ratio_33
 E  onehot_34
 E  mass_34 
 G  R1152   
 L  R1153   
 G  R1154   
 L  R1155   
 G  R1156   
 L  R1157   
 G  R1158   
 L  R1159   
 G  R1160   
 L  R1161   
 G  R1162   
 L  R1163   
 G  R1164   
 L  R1165   
 G  R1166   
 L  R1167   
 G  R1168   
 L  R1169   
 G  R1170   
 L  R1171   
 G  R1172   
 L  R1173   
 G  R1174   
 L  R1175   
 E  normalized_inventory_34
 E  normalized_ratio_34
 E  onehot_35
 E  mass_35 
 G  R1180   
 L  R1181   
 G  R1182   
 L  R1183   
 G  R1184   
 L  R1185   
 G  R1186   
 L  R1187   
 G  R1188   
 L  R1189   
 G  R1190   
 L  R1191   
 G  R1192   
 L  R1193   
 G  R1194   
 L  R1195   
 G  R1196   
 L  R1197   
 G  R1198   
 L  R1199   
 G  R1200   
 L  R1201   
 G  R1202   
 L  R1203   
 G  R1204   
 L  R1205   
 G  R1206   
 L  R1207   
 G  R1208   
 L  R1209   
 G  R1210   
 L  R1211   
 E  normalized_inventory_35
 E  normalized_ratio_35
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  R1219   
 G  R1220   
 G  R1221   
 G  R1222   
 G  R1223   
 G  R1224   
 G  R1225   
 G  R1226   
 G  R1227   
 G  R1228   
 G  R1229   
 G  R1230   
 G  R1231   
 G  R1232   
 G  R1233   
 G  R1234   
 G  R1235   
 G  R1236   
 G  R1237   
 G  R1238   
 G  R1239   
 G  R1240   
 G  R1241   
 G  R1242   
 G  R1243   
 G  R1244   
 G  R1245   
 G  R1246   
 G  R1247   
 G  R1248   
 G  R1249   
 G  R1250   
 G  R1251   
 G  R1252   
 G  R1253   
 G  R1254   
 G  R1255   
 G  R1256   
 G  R1257   
 G  R1258   
 G  R1259   
 G  R1260   
 G  R1261   
 G  R1262   
 G  R1263   
 G  R1264   
 G  R1265   
 G  R1266   
 G  R1267   
 G  R1268   
 G  R1269   
 G  R1270   
 G  R1271   
 G  R1272   
 G  R1273   
 G  R1274   
 G  R1275   
 G  R1276   
 G  R1277   
 G  R1278   
 G  R1279   
 G  R1280   
 G  R1281   
 G  R1282   
 G  R1283   
 G  R1284   
 G  R1285   
 G  R1286   
 G  R1287   
 G  R1288   
 G  R1289   
 G  R1290   
 G  R1291   
 G  R1292   
 G  R1293   
 G  R1294   
 G  R1295   
 G  R1296   
 G  R1297   
 G  R1298   
 G  R1299   
 G  R1300   
 G  R1301   
 G  R1302   
 G  R1303   
 G  R1304   
 G  R1305   
 G  R1306   
 G  R1307   
 G  R1308   
 G  R1309   
 G  R1310   
 G  R1311   
 G  R1312   
 G  R1313   
 G  R1314   
 G  R1315   
 G  R1316   
 G  R1317   
 G  R1318   
 G  R1319   
 G  R1320   
 G  R1321   
 G  R1322   
 G  R1323   
 G  R1324   
 G  R1325   
 G  R1326   
 G  R1327   
 G  R1328   
 G  R1329   
 G  R1330   
 G  R1331   
 G  R1332   
 G  R1333   
 G  R1334   
 G  R1335   
 G  R1336   
 G  R1337   
 G  R1338   
 G  R1339   
 G  R1340   
 G  R1341   
 G  R1342   
 G  R1343   
 G  R1344   
 G  R1345   
 G  R1346   
 G  R1347   
 G  R1348   
 G  R1349   
 G  R1350   
 G  R1351   
 G  R1352   
 G  R1353   
 G  R1354   
 G  R1355   
 G  R1356   
 G  R1357   
 G  R1358   
 G  R1359   
 G  R1360   
 G  R1361   
 G  R1362   
 G  R1363   
 G  R1364   
 G  R1365   
 G  R1366   
 G  R1367   
 G  R1368   
 G  R1369   
 G  R1370   
 G  R1371   
 G  R1372   
 G  R1373   
 G  R1374   
 G  R1375   
 G  R1376   
 G  R1377   
 G  R1378   
 G  R1379   
 G  R1380   
 G  R1381   
 G  R1382   
 G  R1383   
 G  R1384   
 G  R1385   
 G  R1386   
 G  R1387   
 G  R1388   
 G  R1389   
 G  R1390   
 G  R1391   
 G  R1392   
 G  R1393   
 G  R1394   
 G  R1395   
 G  R1396   
 G  R1397   
 G  R1398   
 G  R1399   
 G  R1400   
 G  R1401   
 G  R1402   
 G  R1403   
 G  R1404   
 G  R1405   
 G  R1406   
 G  R1407   
 G  R1408   
 G  R1409   
 G  R1410   
 G  R1411   
 G  R1412   
 G  R1413   
 G  R1414   
 G  R1415   
 G  R1416   
 G  R1417   
 G  R1418   
 G  R1419   
 G  R1420   
 G  R1421   
 G  R1422   
 G  R1423   
 G  R1424   
 G  R1425   
 G  R1426   
 G  R1427   
 G  R1428   
 G  R1429   
 G  R1430   
 G  R1431   
 G  R1432   
 G  R1433   
 G  R1434   
 G  R1435   
 G  R1436   
 G  R1437   
 G  R1438   
 G  R1439   
 G  R1440   
 G  R1441   
 G  R1442   
 G  R1443   
 G  R1444   
 G  R1445   
 G  R1446   
 G  R1447   
 G  R1448   
 G  R1449   
 G  R1450   
 G  R1451   
 G  R1452   
 G  R1453   
 G  R1454   
 G  R1455   
 G  R1456   
 G  R1457   
 G  R1458   
 G  R1459   
 G  R1460   
 G  R1461   
 G  R1462   
 G  R1463   
 G  R1464   
 G  R1465   
 G  R1466   
 G  R1467   
 G  R1468   
 G  R1469   
 G  R1470   
 G  R1471   
 G  R1472   
 G  R1473   
 G  R1474   
 G  R1475   
 G  R1476   
 G  R1477   
 G  R1478   
 G  R1479   
 G  R1480   
 G  R1481   
 G  R1482   
 G  R1483   
 G  R1484   
 G  R1485   
 G  R1486   
 G  R1487   
 G  R1488   
 G  R1489   
 G  R1490   
 G  R1491   
 G  R1492   
 G  R1493   
 G  R1494   
 G  R1495   
 G  R1496   
 G  R1497   
 G  R1498   
 G  R1499   
 G  R1500   
 G  R1501   
 G  R1502   
 G  R1503   
 G  R1504   
 G  R1505   
 G  R1506   
 G  R1507   
 G  R1508   
 G  R1509   
 G  R1510   
 G  R1511   
 G  R1512   
 G  R1513   
 G  R1514   
 G  R1515   
 G  R1516   
 G  R1517   
 G  R1518   
 G  R1519   
 G  R1520   
 G  R1521   
 G  R1522   
 G  R1523   
 G  R1524   
 G  R1525   
 G  R1526   
 G  R1527   
 G  R1528   
 G  R1529   
 G  R1530   
 G  R1531   
 G  R1532   
 G  R1533   
 G  R1534   
 G  R1535   
 G  R1536   
 G  R1537   
 G  R1538   
 G  R1539   
 G  R1540   
 G  R1541   
 G  R1542   
 G  R1543   
 G  R1544   
 G  R1545   
 G  R1546   
 G  R1547   
 G  R1548   
 G  R1549   
 G  R1550   
 G  R1551   
 G  R1552   
 G  R1553   
 G  R1554   
 G  R1555   
 G  R1556   
 G  R1557   
 G  R1558   
 G  R1559   
 G  R1560   
 G  R1561   
 G  R1562   
 G  R1563   
 G  R1564   
 G  R1565   
 G  R1566   
 G  R1567   
 G  R1568   
 G  R1569   
 G  R1570   
 G  R1571   
 G  R1572   
 G  R1573   
 G  R1574   
 G  R1575   
 G  R1576   
 G  R1577   
 G  R1578   
 G  R1579   
 G  R1580   
 G  R1581   
 G  R1582   
 G  R1583   
 G  R1584   
 G  R1585   
 G  R1586   
 G  R1587   
 G  R1588   
 G  R1589   
 G  R1590   
 G  R1591   
 G  R1592   
 G  R1593   
 G  R1594   
 G  R1595   
 G  R1596   
 G  R1597   
 G  R1598   
 G  R1599   
 G  R1600   
 G  R1601   
 G  R1602   
 G  R1603   
 G  R1604   
 G  R1605   
 G  R1606   
 G  R1607   
 G  R1608   
 G  R1609   
 G  R1610   
 G  R1611   
 G  R1612   
 G  R1613   
 G  R1614   
 G  R1615   
 G  R1616   
 G  R1617   
 G  R1618   
 G  R1619   
 G  R1620   
 G  R1621   
 G  R1622   
 G  R1623   
 G  R1624   
 G  R1625   
 G  R1626   
 G  R1627   
 G  R1628   
 G  R1629   
 G  R1630   
 G  R1631   
 G  R1632   
 G  R1633   
 G  R1634   
 G  R1635   
 G  R1636   
 G  R1637   
 G  R1638   
 G  R1639   
 G  R1640   
 G  R1641   
 G  R1642   
 G  R1643   
 G  R1644   
 G  R1645   
 G  R1646   
 G  R1647   
 G  R1648   
 G  R1649   
 G  R1650   
 G  R1651   
 G  R1652   
 G  R1653   
 G  R1654   
 G  R1655   
 G  R1656   
 G  R1657   
 G  R1658   
 G  R1659   
 G  R1660   
 G  R1661   
 G  R1662   
 G  R1663   
 G  R1664   
 G  R1665   
 G  R1666   
 G  R1667   
 G  R1668   
 G  R1669   
 G  R1670   
 G  R1671   
 G  R1672   
 G  R1673   
 G  R1674   
 G  R1675   
 G  R1676   
 G  R1677   
 G  R1678   
 G  R1679   
 G  R1680   
 G  R1681   
 G  R1682   
 G  R1683   
 G  R1684   
 G  R1685   
 G  R1686   
 G  R1687   
 G  R1688   
 G  R1689   
 G  R1690   
 G  R1691   
 G  R1692   
 G  R1693   
 G  R1694   
 G  R1695   
 G  R1696   
 G  R1697   
 G  R1698   
 G  R1699   
 G  R1700   
 G  R1701   
 G  R1702   
 G  R1703   
 G  R1704   
 G  R1705   
 G  R1706   
 G  R1707   
 G  R1708   
 G  R1709   
 G  R1710   
 G  R1711   
 G  R1712   
 G  R1713   
 G  R1714   
 G  R1715   
 G  R1716   
 G  R1717   
 G  R1718   
 G  R1719   
 G  R1720   
 G  R1721   
 G  R1722   
 G  R1723   
 G  R1724   
 G  R1725   
 G  R1726   
 G  R1727   
 G  R1728   
 G  R1729   
 G  R1730   
 G  R1731   
 G  R1732   
 G  R1733   
 G  R1734   
 G  R1735   
 G  R1736   
 G  R1737   
 G  R1738   
 G  R1739   
 G  R1740   
 G  R1741   
 G  R1742   
 G  R1743   
 G  R1744   
 G  R1745   
 G  R1746   
 G  R1747   
 G  R1748   
 G  R1749   
 G  R1750   
 G  R1751   
 G  R1752   
 G  R1753   
 G  R1754   
 G  R1755   
 G  R1756   
 G  R1757   
 G  R1758   
 G  R1759   
 G  R1760   
 G  R1761   
 G  R1762   
 G  R1763   
 G  R1764   
 G  R1765   
 G  R1766   
 G  R1767   
 G  R1768   
 G  R1769   
 G  R1770   
 G  R1771   
 G  R1772   
 G  R1773   
 G  R1774   
 G  R1775   
 G  R1776   
 G  R1777   
 G  R1778   
 G  R1779   
 G  R1780   
 G  R1781   
 G  R1782   
 G  R1783   
 G  R1784   
 G  R1785   
 G  R1786   
 G  R1787   
 G  R1788   
 G  R1789   
 G  R1790   
 G  R1791   
 G  R1792   
 G  R1793   
 G  R1794   
 G  R1795   
 G  R1796   
 G  R1797   
 G  R1798   
 G  R1799   
 G  R1800   
 G  R1801   
 G  R1802   
 G  R1803   
 G  R1804   
 G  R1805   
 G  R1806   
 G  R1807   
 G  R1808   
 G  R1809   
 G  R1810   
 G  R1811   
 G  R1812   
 G  R1813   
 G  R1814   
 G  R1815   
 G  R1816   
 G  R1817   
 G  R1818   
 G  R1819   
 G  R1820   
 G  R1821   
 G  R1822   
 G  R1823   
 G  R1824   
 G  R1825   
 G  R1826   
 G  R1827   
 G  R1828   
 G  R1829   
 G  R1830   
 G  R1831   
 G  R1832   
 G  R1833   
 G  R1834   
 G  R1835   
 G  R1836   
 G  R1837   
 G  R1838   
 G  R1839   
 G  R1840   
 G  R1841   
 G  R1842   
 G  R1843   
 G  R1844   
 G  R1845   
 G  R1846   
 G  R1847   
 G  R1848   
 G  R1849   
 G  R1850   
 G  R1851   
 G  R1852   
 G  R1853   
 G  R1854   
 G  R1855   
 G  R1856   
 G  R1857   
 G  R1858   
 G  R1859   
 G  R1860   
 G  R1861   
 G  R1862   
 G  R1863   
 G  R1864   
 G  R1865   
 G  R1866   
 G  R1867   
 G  R1868   
 G  R1869   
 G  R1870   
 G  R1871   
 G  R1872   
 G  R1873   
 G  R1874   
 G  R1875   
 G  R1876   
 G  R1877   
 G  R1878   
 G  R1879   
 G  R1880   
 G  R1881   
 G  R1882   
 G  R1883   
 G  R1884   
 G  R1885   
 G  R1886   
 G  R1887   
 G  R1888   
 G  R1889   
 G  R1890   
 G  R1891   
 G  R1892   
 G  R1893   
 G  R1894   
 G  R1895   
 G  R1896   
 G  R1897   
 G  R1898   
 G  R1899   
 G  R1900   
 G  R1901   
 G  R1902   
 G  R1903   
 G  R1904   
 G  R1905   
 G  R1906   
 G  R1907   
 G  R1908   
 G  R1909   
 G  R1910   
 G  R1911   
 G  R1912   
 G  R1913   
 G  R1914   
 G  R1915   
 G  R1916   
 G  R1917   
 G  R1918   
 G  R1919   
 G  R1920   
 G  R1921   
 G  R1922   
 G  R1923   
 G  R1924   
 G  R1925   
 G  R1926   
 G  R1927   
 G  R1928   
 G  R1929   
 G  R1930   
 G  R1931   
 G  R1932   
 G  R1933   
 G  R1934   
 G  R1935   
 G  R1936   
 G  R1937   
 G  R1938   
 G  R1939   
 G  R1940   
 G  R1941   
 G  R1942   
 G  R1943   
 G  R1944   
 G  R1945   
 G  R1946   
 G  R1947   
 G  R1948   
 G  R1949   
 G  R1950   
 G  R1951   
 G  R1952   
 G  R1953   
 G  R1954   
 G  R1955   
 G  R1956   
 G  R1957   
 G  R1958   
 G  R1959   
 G  R1960   
 G  R1961   
 G  R1962   
 G  R1963   
 G  R1964   
 G  R1965   
 G  R1966   
 G  R1967   
 G  R1968   
 G  R1969   
 G  R1970   
 G  R1971   
 G  R1972   
 G  R1973   
 G  R1974   
 G  R1975   
 G  R1976   
 G  R1977   
 G  R1978   
 G  R1979   
 G  R1980   
 G  R1981   
 G  R1982   
 G  R1983   
 G  R1984   
 G  R1985   
 G  R1986   
 G  R1987   
 G  R1988   
 G  R1989   
 G  R1990   
 G  R1991   
 G  R1992   
 G  R1993   
 G  R1994   
 G  R1995   
 G  R1996   
 G  R1997   
 G  R1998   
 G  R1999   
 G  R2000   
 G  R2001   
 G  R2002   
 G  R2003   
 G  R2004   
 G  R2005   
 G  R2006   
 G  R2007   
 G  R2008   
 G  R2009   
 G  R2010   
 G  R2011   
 G  R2012   
 G  R2013   
 G  R2014   
 G  R2015   
 G  R2016   
 G  R2017   
 G  R2018   
 G  R2019   
 G  R2020   
 G  R2021   
 G  R2022   
 G  R2023   
 G  R2024   
 G  R2025   
 G  R2026   
 G  R2027   
 G  R2028   
 G  R2029   
 G  R2030   
 G  R2031   
 G  R2032   
 G  R2033   
 G  R2034   
 G  R2035   
 G  R2036   
 G  R2037   
 G  R2038   
 G  R2039   
 G  R2040   
 G  R2041   
 G  R2042   
 G  R2043   
 G  R2044   
 G  R2045   
 G  R2046   
 G  R2047   
 G  R2048   
 G  R2049   
 G  R2050   
 G  R2051   
 G  R2052   
 G  R2053   
 G  R2054   
 G  R2055   
 G  R2056   
 G  R2057   
 G  R2058   
 G  R2059   
 G  R2060   
 G  R2061   
 G  R2062   
 G  R2063   
 G  R2064   
 G  R2065   
 G  R2066   
 G  R2067   
 G  R2068   
 G  R2069   
 G  R2070   
 G  R2071   
 G  R2072   
 G  R2073   
 G  R2074   
 G  R2075   
 G  R2076   
 G  R2077   
 G  R2078   
 G  R2079   
 G  R2080   
 G  R2081   
 G  R2082   
 G  R2083   
 G  R2084   
 G  R2085   
 G  R2086   
 G  R2087   
 G  R2088   
 G  R2089   
 G  R2090   
 G  R2091   
 G  R2092   
 G  R2093   
 G  R2094   
 G  R2095   
 G  R2096   
 G  R2097   
 G  R2098   
 G  R2099   
 G  R2100   
 G  R2101   
 G  R2102   
 G  R2103   
 G  R2104   
 G  R2105   
 G  R2106   
 G  R2107   
 G  R2108   
 G  R2109   
 G  R2110   
 G  R2111   
 G  R2112   
 G  R2113   
 G  R2114   
 G  R2115   
 G  R2116   
 G  R2117   
 G  R2118   
 G  R2119   
 G  R2120   
 G  R2121   
 G  R2122   
 G  R2123   
 G  R2124   
 G  R2125   
 G  R2126   
 G  R2127   
 G  R2128   
 G  R2129   
 G  R2130   
 G  R2131   
 G  R2132   
 G  R2133   
 G  R2134   
 G  R2135   
 G  R2136   
 G  R2137   
 G  R2138   
 G  R2139   
 G  R2140   
 G  R2141   
 G  R2142   
 G  R2143   
 G  R2144   
 G  R2145   
 G  R2146   
 G  R2147   
 G  R2148   
 G  R2149   
 G  R2150   
 G  R2151   
 G  R2152   
 G  R2153   
 G  R2154   
 G  R2155   
 G  R2156   
 G  R2157   
 G  R2158   
 G  R2159   
 G  R2160   
 G  R2161   
 G  R2162   
 G  R2163   
 G  R2164   
 G  R2165   
 G  R2166   
 G  R2167   
 G  R2168   
 G  R2169   
 G  R2170   
 G  R2171   
 G  R2172   
 G  R2173   
 G  R2174   
 G  R2175   
 G  R2176   
 G  R2177   
 G  R2178   
 G  R2179   
 G  R2180   
 G  R2181   
 G  R2182   
 G  R2183   
 G  R2184   
 G  R2185   
 G  R2186   
 G  R2187   
 G  R2188   
 G  R2189   
 G  R2190   
 G  R2191   
 G  R2192   
 G  R2193   
 G  R2194   
 G  R2195   
 G  R2196   
 G  R2197   
 G  R2198   
 G  R2199   
 G  R2200   
 G  R2201   
 G  R2202   
 G  R2203   
 G  R2204   
 G  R2205   
 G  R2206   
 G  R2207   
 G  R2208   
 G  R2209   
 G  R2210   
 G  R2211   
 G  R2212   
 G  R2213   
 G  R2214   
 G  R2215   
 G  R2216   
 G  R2217   
 G  R2218   
 G  R2219   
 G  R2220   
 G  R2221   
 G  R2222   
 G  R2223   
 G  R2224   
 G  R2225   
 G  R2226   
 G  R2227   
 G  R2228   
 G  R2229   
 G  R2230   
 G  R2231   
 G  R2232   
 G  R2233   
 G  R2234   
 G  R2235   
 G  R2236   
 G  R2237   
 G  R2238   
 G  R2239   
 G  R2240   
 G  R2241   
 G  R2242   
 G  R2243   
 G  R2244   
 G  R2245   
 G  R2246   
 G  R2247   
 G  R2248   
 G  R2249   
 G  R2250   
 G  R2251   
 G  R2252   
 G  R2253   
 G  R2254   
 G  R2255   
 G  R2256   
 G  R2257   
 G  R2258   
 G  R2259   
 G  R2260   
 G  R2261   
 G  R2262   
 G  R2263   
 G  R2264   
 G  R2265   
 G  R2266   
 G  R2267   
 G  R2268   
 G  R2269   
 G  R2270   
 G  R2271   
 G  R2272   
 G  R2273   
 G  R2274   
 G  R2275   
 G  R2276   
 G  R2277   
 G  R2278   
 G  R2279   
 G  R2280   
 G  R2281   
 G  R2282   
 G  R2283   
 G  R2284   
 G  R2285   
 G  R2286   
 G  R2287   
 G  R2288   
 G  R2289   
 G  R2290   
 G  R2291   
 G  R2292   
 G  R2293   
 G  R2294   
 G  R2295   
 G  R2296   
 G  R2297   
 G  R2298   
 G  R2299   
 G  R2300   
 G  R2301   
 G  R2302   
 G  R2303   
 G  R2304   
 G  R2305   
 G  R2306   
 G  R2307   
 G  R2308   
 G  R2309   
 G  R2310   
 G  R2311   
 G  R2312   
 G  R2313   
 G  R2314   
 G  R2315   
 G  R2316   
 G  R2317   
 G  R2318   
 G  R2319   
 G  R2320   
 G  R2321   
 G  R2322   
 G  R2323   
 G  R2324   
 G  R2325   
 G  R2326   
 G  R2327   
 G  R2328   
 G  R2329   
 G  R2330   
 G  R2331   
 G  R2332   
 G  R2333   
 G  R2334   
 G  R2335   
 G  R2336   
 G  R2337   
 G  R2338   
 G  R2339   
 G  R2340   
 G  R2341   
 G  R2342   
 G  R2343   
 G  R2344   
 G  R2345   
 G  R2346   
 G  R2347   
 G  R2348   
 G  R2349   
 G  R2350   
 G  R2351   
 G  R2352   
 G  R2353   
 G  R2354   
 G  R2355   
 G  R2356   
 G  R2357   
 G  R2358   
 G  R2359   
 G  R2360   
 G  R2361   
 G  R2362   
 G  R2363   
 G  R2364   
 G  R2365   
 G  R2366   
 G  R2367   
 G  R2368   
 G  R2369   
 G  R2370   
 G  R2371   
 G  R2372   
 G  R2373   
 G  R2374   
 G  R2375   
 G  R2376   
 G  R2377   
 G  R2378   
 G  R2379   
 G  R2380   
 G  R2381   
 G  R2382   
 G  R2383   
 G  R2384   
 G  R2385   
 G  R2386   
 G  R2387   
 G  R2388   
 G  R2389   
 G  R2390   
 G  R2391   
 G  R2392   
 G  R2393   
 G  R2394   
 G  R2395   
 G  R2396   
 G  R2397   
 G  R2398   
 G  R2399   
 G  R2400   
 G  R2401   
 G  R2402   
 G  R2403   
 G  R2404   
 G  R2405   
 G  R2406   
 G  R2407   
 G  R2408   
 L  true_G_epigraph
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       7.9999999999999988e-02
    x[1,0]    onehot_1  1
    x[1,0]    R2        -2.6697177726926005e-02
    x[1,0]    R3        -6.7365269461077862e-02
    x[1,1]    OBJ       0.08
    x[1,1]    onehot_1  1
    x[1,1]    R4        -2.6697177726926005e-02
    x[1,1]    R5        -6.7365269461077862e-02
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,2]    OBJ       5.6196993131943561e-02
    x[1,2]    onehot_1  1
    x[1,2]    R6        -2.6697177726926005e-02
    x[1,2]    R7        -6.7365269461077862e-02
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,3]    OBJ       7.9999999999999988e-02
    x[1,3]    onehot_1  1
    x[1,3]    R8        -2.6697177726926005e-02
    x[1,3]    R9        -6.7365269461077862e-02
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[1,4]    OBJ       7.9999999999999988e-02
    x[1,4]    onehot_1  1
    x[1,4]    R10       -2.6697177726926005e-02
    x[1,4]    R11       -6.7365269461077862e-02
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[1,5]    OBJ       7.9999999999999988e-02
    x[1,5]    onehot_1  1
    x[1,5]    R12       -2.6697177726926005e-02
    x[1,5]    R13       -6.7365269461077862e-02
    x[1,5]    hard_lower  5
    x[1,5]    hard_upper  5
    x[1,6]    OBJ       7.9999999999999988e-02
    x[1,6]    onehot_1  1
    x[1,6]    R14       -2.6697177726926005e-02
    x[1,6]    R15       -6.7365269461077862e-02
    x[1,6]    hard_lower  6
    x[1,6]    hard_upper  6
    x[1,7]    OBJ       7.9999999999999988e-02
    x[1,7]    onehot_1  1
    x[1,7]    R16       -2.6697177726926005e-02
    x[1,7]    R17       -6.7365269461077862e-02
    x[1,7]    hard_lower  7
    x[1,7]    hard_upper  7
    x[1,8]    OBJ       2.9999999999999992e-02
    x[1,8]    onehot_1  1
    x[1,8]    R18       -2.6697177726926005e-02
    x[1,8]    R19       -6.7365269461077862e-02
    x[1,8]    hard_lower  8
    x[1,8]    hard_upper  8
    x[1,9]    OBJ       7.9999999999999988e-02
    x[1,9]    onehot_1  1
    x[1,9]    R20       -2.6697177726926005e-02
    x[1,9]    R21       -6.7365269461077862e-02
    x[1,9]    hard_lower  9
    x[1,9]    hard_upper  9
    x[1,10]   OBJ       1.6630198803622369e-02
    x[1,10]   onehot_1  1
    x[1,10]   R22       -2.6697177726926005e-02
    x[1,10]   R23       -6.7365269461077862e-02
    x[1,10]   hard_lower  10
    x[1,10]   hard_upper  10
    x[1,11]   OBJ       7.9999999999999988e-02
    x[1,11]   onehot_1  1
    x[1,11]   R24       -2.6697177726926005e-02
    x[1,11]   R25       -6.7365269461077862e-02
    x[1,11]   hard_lower  11
    x[1,11]   hard_upper  11
    x[1,12]   OBJ       7.9999999999999988e-02
    x[1,12]   onehot_1  1
    x[1,12]   R26       -2.6697177726926005e-02
    x[1,12]   R27       -6.7365269461077862e-02
    x[1,12]   hard_lower  12
    x[1,12]   hard_upper  12
    x[1,13]   OBJ       7.9999999999999988e-02
    x[1,13]   onehot_1  1
    x[1,13]   R28       -2.6697177726926005e-02
    x[1,13]   R29       -6.7365269461077862e-02
    x[1,13]   hard_lower  13
    x[1,13]   hard_upper  13
    x[1,14]   OBJ       7.9999999999999988e-02
    x[1,14]   onehot_1  1
    x[1,14]   R30       -2.6697177726926005e-02
    x[1,14]   R31       -6.7365269461077862e-02
    x[1,14]   hard_lower  14
    x[1,14]   hard_upper  14
    x[1,15]   OBJ       7.9999999999999988e-02
    x[1,15]   onehot_1  1
    x[1,15]   R32       -2.6697177726926005e-02
    x[1,15]   R33       -6.7365269461077862e-02
    x[1,15]   hard_lower  15
    x[1,15]   hard_upper  15
    x[1,16]   OBJ       7.9999999999999988e-02
    x[1,16]   onehot_1  1
    x[1,16]   R34       -2.6697177726926005e-02
    x[1,16]   R35       -6.7365269461077862e-02
    x[1,16]   hard_lower  16
    x[1,16]   hard_upper  16
    x[1,17]   OBJ       7.9999999999999988e-02
    x[1,17]   onehot_1  1
    x[1,17]   R36       -2.6697177726926005e-02
    x[1,17]   R37       -6.7365269461077862e-02
    x[1,17]   hard_lower  17
    x[1,17]   hard_upper  17
    x[1,18]   OBJ       7.9999999999999988e-02
    x[1,18]   onehot_1  1
    x[1,18]   R38       -2.6697177726926005e-02
    x[1,18]   R39       -6.7365269461077862e-02
    x[1,18]   hard_lower  18
    x[1,18]   hard_upper  18
    x[1,19]   OBJ       7.9999999999999988e-02
    x[1,19]   onehot_1  1
    x[1,19]   R40       -2.6697177726926005e-02
    x[1,19]   R41       -6.7365269461077862e-02
    x[1,19]   hard_lower  19
    x[1,19]   hard_upper  19
    x[2,0]    OBJ       6.0500000000000005e-02
    x[2,0]    onehot_2  1
    x[2,0]    R46       -2.6697177726926005e-02
    x[2,0]    R47       -6.7365269461077862e-02
    x[2,1]    OBJ       0.0605
    x[2,1]    onehot_2  1
    x[2,1]    R48       -2.6697177726926005e-02
    x[2,1]    R49       -6.7365269461077862e-02
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,2]    OBJ       6.0500000000000005e-02
    x[2,2]    onehot_2  1
    x[2,2]    R50       -2.6697177726926005e-02
    x[2,2]    R51       -6.7365269461077862e-02
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,3]    OBJ       0.0605
    x[2,3]    onehot_2  1
    x[2,3]    R52       -2.6697177726926005e-02
    x[2,3]    R53       -6.7365269461077862e-02
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,4]    OBJ       6.0500000000000005e-02
    x[2,4]    onehot_2  1
    x[2,4]    R54       -2.6697177726926005e-02
    x[2,4]    R55       -6.7365269461077862e-02
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[2,5]    OBJ       6.0500000000000005e-02
    x[2,5]    onehot_2  1
    x[2,5]    R56       -2.6697177726926005e-02
    x[2,5]    R57       -6.7365269461077862e-02
    x[2,5]    hard_lower  5
    x[2,5]    hard_upper  5
    x[2,6]    OBJ       1.0500000000000002e-02
    x[2,6]    onehot_2  1
    x[2,6]    R58       -2.6697177726926005e-02
    x[2,6]    R59       -6.7365269461077862e-02
    x[2,6]    hard_lower  6
    x[2,6]    hard_upper  6
    x[2,7]    OBJ       4.7194425664095407e-03
    x[2,7]    onehot_2  1
    x[2,7]    R60       -2.6697177726926005e-02
    x[2,7]    R61       -6.7365269461077862e-02
    x[2,7]    hard_lower  7
    x[2,7]    hard_upper  7
    x[2,8]    OBJ       0.0605
    x[2,8]    onehot_2  1
    x[2,8]    R62       -2.6697177726926005e-02
    x[2,8]    R63       -6.7365269461077862e-02
    x[2,8]    hard_lower  8
    x[2,8]    hard_upper  8
    x[2,9]    OBJ       0.0605
    x[2,9]    onehot_2  1
    x[2,9]    R64       -2.6697177726926005e-02
    x[2,9]    R65       -6.7365269461077862e-02
    x[2,9]    hard_lower  9
    x[2,9]    hard_upper  9
    x[2,10]   OBJ       0.0605
    x[2,10]   onehot_2  1
    x[2,10]   R66       -2.6697177726926005e-02
    x[2,10]   R67       -6.7365269461077862e-02
    x[2,10]   hard_lower  10
    x[2,10]   hard_upper  10
    x[2,11]   OBJ       6.0500000000000005e-02
    x[2,11]   onehot_2  1
    x[2,11]   R68       -2.6697177726926005e-02
    x[2,11]   R69       -6.7365269461077862e-02
    x[2,11]   hard_lower  11
    x[2,11]   hard_upper  11
    x[2,12]   OBJ       0.0605
    x[2,12]   onehot_2  1
    x[2,12]   R70       -2.6697177726926005e-02
    x[2,12]   R71       -6.7365269461077862e-02
    x[2,12]   hard_lower  12
    x[2,12]   hard_upper  12
    x[2,13]   OBJ       6.0500000000000005e-02
    x[2,13]   onehot_2  1
    x[2,13]   R72       -2.6697177726926005e-02
    x[2,13]   R73       -6.7365269461077862e-02
    x[2,13]   hard_lower  13
    x[2,13]   hard_upper  13
    x[2,14]   OBJ       6.0500000000000005e-02
    x[2,14]   onehot_2  1
    x[2,14]   R74       -2.6697177726926005e-02
    x[2,14]   R75       -6.7365269461077862e-02
    x[2,14]   hard_lower  14
    x[2,14]   hard_upper  14
    x[2,15]   OBJ       0.0605
    x[2,15]   onehot_2  1
    x[2,15]   R76       -2.6697177726926005e-02
    x[2,15]   R77       -6.7365269461077862e-02
    x[2,15]   hard_lower  15
    x[2,15]   hard_upper  15
    x[3,0]    OBJ       0.062
    x[3,0]    onehot_3  1
    x[3,0]    R82       -2.6697177726926005e-02
    x[3,0]    R83       -6.7365269461077862e-02
    x[3,1]    OBJ       0.062
    x[3,1]    onehot_3  1
    x[3,1]    R84       -2.6697177726926005e-02
    x[3,1]    R85       -6.7365269461077862e-02
    x[3,1]    hard_lower  1
    x[3,1]    hard_upper  1
    x[3,2]    OBJ       6.1999999999999993e-02
    x[3,2]    onehot_3  1
    x[3,2]    R86       -2.6697177726926005e-02
    x[3,2]    R87       -6.7365269461077862e-02
    x[3,2]    hard_lower  2
    x[3,2]    hard_upper  2
    x[3,3]    OBJ       6.2000000000000006e-02
    x[3,3]    onehot_3  1
    x[3,3]    R88       -2.6697177726926005e-02
    x[3,3]    R89       -6.7365269461077862e-02
    x[3,3]    hard_lower  3
    x[3,3]    hard_upper  3
    x[3,4]    OBJ       0.062
    x[3,4]    onehot_3  1
    x[3,4]    R90       -2.6697177726926005e-02
    x[3,4]    R91       -6.7365269461077862e-02
    x[3,4]    hard_lower  4
    x[3,4]    hard_upper  4
    x[3,5]    OBJ       0.062
    x[3,5]    onehot_3  1
    x[3,5]    R92       -2.6697177726926005e-02
    x[3,5]    R93       -6.7365269461077862e-02
    x[3,5]    hard_lower  5
    x[3,5]    hard_upper  5
    x[3,6]    OBJ       1.7350982670038189e-02
    x[3,6]    onehot_3  1
    x[3,6]    R94       -2.6697177726926005e-02
    x[3,6]    R95       -6.7365269461077862e-02
    x[3,6]    hard_lower  6
    x[3,6]    hard_upper  6
    x[3,7]    OBJ       0.012
    x[3,7]    onehot_3  1
    x[3,7]    R96       -2.6697177726926005e-02
    x[3,7]    R97       -6.7365269461077862e-02
    x[3,7]    hard_lower  7
    x[3,7]    hard_upper  7
    x[3,8]    OBJ       0.062
    x[3,8]    onehot_3  1
    x[3,8]    R98       -2.6697177726926005e-02
    x[3,8]    R99       -6.7365269461077862e-02
    x[3,8]    hard_lower  8
    x[3,8]    hard_upper  8
    x[3,9]    OBJ       0.062
    x[3,9]    onehot_3  1
    x[3,9]    R100      -2.6697177726926005e-02
    x[3,9]    R101      -6.7365269461077862e-02
    x[3,9]    hard_lower  9
    x[3,9]    hard_upper  9
    x[3,10]   OBJ       6.2000000000000006e-02
    x[3,10]   onehot_3  1
    x[3,10]   R102      -2.6697177726926005e-02
    x[3,10]   R103      -6.7365269461077862e-02
    x[3,10]   hard_lower  10
    x[3,10]   hard_upper  10
    x[3,11]   OBJ       0.062
    x[3,11]   onehot_3  1
    x[3,11]   R104      -2.6697177726926005e-02
    x[3,11]   R105      -6.7365269461077862e-02
    x[3,11]   hard_lower  11
    x[3,11]   hard_upper  11
    x[3,12]   OBJ       0.062
    x[3,12]   onehot_3  1
    x[3,12]   R106      -2.6697177726926005e-02
    x[3,12]   R107      -6.7365269461077862e-02
    x[3,12]   hard_lower  12
    x[3,12]   hard_upper  12
    x[3,13]   OBJ       6.2000000000000006e-02
    x[3,13]   onehot_3  1
    x[3,13]   R108      -2.6697177726926005e-02
    x[3,13]   R109      -6.7365269461077862e-02
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[3,14]   OBJ       6.1999999999999993e-02
    x[3,14]   onehot_3  1
    x[3,14]   R110      -2.6697177726926005e-02
    x[3,14]   R111      -6.7365269461077862e-02
    x[3,14]   hard_lower  14
    x[3,14]   hard_upper  14
    x[3,15]   OBJ       0.062
    x[3,15]   onehot_3  1
    x[3,15]   R112      -2.6697177726926005e-02
    x[3,15]   R113      -6.7365269461077862e-02
    x[3,15]   hard_lower  15
    x[3,15]   hard_upper  15
    x[3,16]   OBJ       0.062
    x[3,16]   onehot_3  1
    x[3,16]   R114      -2.6697177726926005e-02
    x[3,16]   R115      -6.7365269461077862e-02
    x[3,16]   hard_lower  16
    x[3,16]   hard_upper  16
    x[3,17]   OBJ       0.062
    x[3,17]   onehot_3  1
    x[3,17]   R116      -2.6697177726926005e-02
    x[3,17]   R117      -6.7365269461077862e-02
    x[3,17]   hard_lower  17
    x[3,17]   hard_upper  17
    x[4,0]    OBJ       6.0500000000000005e-02
    x[4,0]    onehot_4  1
    x[4,0]    R122      -2.6697177726926005e-02
    x[4,0]    R123      -6.7365269461077862e-02
    x[4,1]    OBJ       0.0605
    x[4,1]    onehot_4  1
    x[4,1]    R124      -2.6697177726926005e-02
    x[4,1]    R125      -6.7365269461077862e-02
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,2]    OBJ       6.0500000000000005e-02
    x[4,2]    onehot_4  1
    x[4,2]    R126      -2.6697177726926005e-02
    x[4,2]    R127      -6.7365269461077862e-02
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,3]    OBJ       0.0605
    x[4,3]    onehot_4  1
    x[4,3]    R128      -2.6697177726926005e-02
    x[4,3]    R129      -6.7365269461077862e-02
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,4]    OBJ       6.0500000000000005e-02
    x[4,4]    onehot_4  1
    x[4,4]    R130      -2.6697177726926005e-02
    x[4,4]    R131      -6.7365269461077862e-02
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,5]    OBJ       6.0500000000000005e-02
    x[4,5]    onehot_4  1
    x[4,5]    R132      -2.6697177726926005e-02
    x[4,5]    R133      -6.7365269461077862e-02
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,6]    OBJ       1.0500000000000002e-02
    x[4,6]    onehot_4  1
    x[4,6]    R134      -2.6697177726926005e-02
    x[4,6]    R135      -6.7365269461077862e-02
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,7]    OBJ       4.3157787419935830e-03
    x[4,7]    onehot_4  1
    x[4,7]    R136      -2.6697177726926005e-02
    x[4,7]    R137      -6.7365269461077862e-02
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,8]    OBJ       0.0605
    x[4,8]    onehot_4  1
    x[4,8]    R138      -2.6697177726926005e-02
    x[4,8]    R139      -6.7365269461077862e-02
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,9]    OBJ       0.0605
    x[4,9]    onehot_4  1
    x[4,9]    R140      -2.6697177726926005e-02
    x[4,9]    R141      -6.7365269461077862e-02
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,10]   OBJ       0.0605
    x[4,10]   onehot_4  1
    x[4,10]   R142      -2.6697177726926005e-02
    x[4,10]   R143      -6.7365269461077862e-02
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,11]   OBJ       6.0500000000000005e-02
    x[4,11]   onehot_4  1
    x[4,11]   R144      -2.6697177726926005e-02
    x[4,11]   R145      -6.7365269461077862e-02
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,12]   OBJ       0.0605
    x[4,12]   onehot_4  1
    x[4,12]   R146      -2.6697177726926005e-02
    x[4,12]   R147      -6.7365269461077862e-02
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,13]   OBJ       6.0500000000000005e-02
    x[4,13]   onehot_4  1
    x[4,13]   R148      -2.6697177726926005e-02
    x[4,13]   R149      -6.7365269461077862e-02
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,14]   OBJ       6.0500000000000005e-02
    x[4,14]   onehot_4  1
    x[4,14]   R150      -2.6697177726926005e-02
    x[4,14]   R151      -6.7365269461077862e-02
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,15]   OBJ       0.0605
    x[4,15]   onehot_4  1
    x[4,15]   R152      -2.6697177726926005e-02
    x[4,15]   R153      -6.7365269461077862e-02
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[5,0]    OBJ       0.05
    x[5,0]    onehot_5  1
    x[5,0]    R158      -2.6697177726926005e-02
    x[5,0]    R159      -6.7365269461077862e-02
    x[5,1]    OBJ       4.9999999999999996e-02
    x[5,1]    onehot_5  1
    x[5,1]    R160      -2.6697177726926005e-02
    x[5,1]    R161      -6.7365269461077862e-02
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,2]    OBJ       2.6715626170837746e-02
    x[5,2]    onehot_5  1
    x[5,2]    R162      -2.6697177726926005e-02
    x[5,2]    R163      -6.7365269461077862e-02
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,3]    OBJ       0.05
    x[5,3]    onehot_5  1
    x[5,3]    R164      -2.6697177726926005e-02
    x[5,3]    R165      -6.7365269461077862e-02
    x[5,3]    hard_lower  3
    x[5,3]    hard_upper  3
    x[5,4]    OBJ       1.9968988869152479e-02
    x[5,4]    onehot_5  1
    x[5,4]    R166      -2.6697177726926005e-02
    x[5,4]    R167      -6.7365269461077862e-02
    x[5,4]    hard_lower  4
    x[5,4]    hard_upper  4
    x[5,5]    OBJ       4.9999999999999996e-02
    x[5,5]    onehot_5  1
    x[5,5]    R168      -2.6697177726926005e-02
    x[5,5]    R169      -6.7365269461077862e-02
    x[5,5]    hard_lower  5
    x[5,5]    hard_upper  5
    x[5,6]    OBJ       0.05
    x[5,6]    onehot_5  1
    x[5,6]    R170      -2.6697177726926005e-02
    x[5,6]    R171      -6.7365269461077862e-02
    x[5,6]    hard_lower  6
    x[5,6]    hard_upper  6
    x[5,7]    OBJ       0.05
    x[5,7]    onehot_5  1
    x[5,7]    R172      -2.6697177726926005e-02
    x[5,7]    R173      -6.7365269461077862e-02
    x[5,7]    hard_lower  7
    x[5,7]    hard_upper  7
    x[5,8]    onehot_5  1
    x[5,8]    R174      -2.6697177726926005e-02
    x[5,8]    R175      -6.7365269461077862e-02
    x[5,8]    hard_lower  8
    x[5,8]    hard_upper  8
    x[5,9]    OBJ       0.05
    x[5,9]    onehot_5  1
    x[5,9]    R176      -2.6697177726926005e-02
    x[5,9]    R177      -6.7365269461077862e-02
    x[5,9]    hard_lower  9
    x[5,9]    hard_upper  9
    x[5,10]   OBJ       0.05
    x[5,10]   onehot_5  1
    x[5,10]   R178      -2.6697177726926005e-02
    x[5,10]   R179      -6.7365269461077862e-02
    x[5,10]   hard_lower  10
    x[5,10]   hard_upper  10
    x[5,11]   OBJ       4.9999999999999996e-02
    x[5,11]   onehot_5  1
    x[5,11]   R180      -2.6697177726926005e-02
    x[5,11]   R181      -6.7365269461077862e-02
    x[5,11]   hard_lower  11
    x[5,11]   hard_upper  11
    x[5,12]   OBJ       0.05
    x[5,12]   onehot_5  1
    x[5,12]   R182      -2.6697177726926005e-02
    x[5,12]   R183      -6.7365269461077862e-02
    x[5,12]   hard_lower  12
    x[5,12]   hard_upper  12
    x[5,13]   OBJ       0.05
    x[5,13]   onehot_5  1
    x[5,13]   R184      -2.6697177726926005e-02
    x[5,13]   R185      -6.7365269461077862e-02
    x[5,13]   hard_lower  13
    x[5,13]   hard_upper  13
    x[5,14]   OBJ       4.9999999999999996e-02
    x[5,14]   onehot_5  1
    x[5,14]   R186      -2.6697177726926005e-02
    x[5,14]   R187      -6.7365269461077862e-02
    x[5,14]   hard_lower  14
    x[5,14]   hard_upper  14
    x[5,15]   OBJ       4.9999999999999996e-02
    x[5,15]   onehot_5  1
    x[5,15]   R188      -2.6697177726926005e-02
    x[5,15]   R189      -6.7365269461077862e-02
    x[5,15]   hard_lower  15
    x[5,15]   hard_upper  15
    x[5,16]   OBJ       0.05
    x[5,16]   onehot_5  1
    x[5,16]   R190      -2.6697177726926005e-02
    x[5,16]   R191      -6.7365269461077862e-02
    x[5,16]   hard_lower  16
    x[5,16]   hard_upper  16
    x[6,0]    OBJ       0.05
    x[6,0]    onehot_6  1
    x[6,0]    R196      -2.6697177726926005e-02
    x[6,0]    R197      -6.7365269461077862e-02
    x[6,1]    OBJ       8.7119088927757413e-03
    x[6,1]    onehot_6  1
    x[6,1]    R198      -2.6697177726926005e-02
    x[6,1]    R199      -6.7365269461077862e-02
    x[6,1]    hard_lower  1
    x[6,1]    hard_upper  1
    x[6,2]    OBJ       0.05
    x[6,2]    onehot_6  1
    x[6,2]    R200      -2.6697177726926005e-02
    x[6,2]    R201      -6.7365269461077862e-02
    x[6,2]    hard_lower  2
    x[6,2]    hard_upper  2
    x[6,3]    OBJ       4.9999999999999996e-02
    x[6,3]    onehot_6  1
    x[6,3]    R202      -2.6697177726926005e-02
    x[6,3]    R203      -6.7365269461077862e-02
    x[6,3]    hard_lower  3
    x[6,3]    hard_upper  3
    x[6,4]    OBJ       4.9999999999999996e-02
    x[6,4]    onehot_6  1
    x[6,4]    R204      -2.6697177726926005e-02
    x[6,4]    R205      -6.7365269461077862e-02
    x[6,4]    hard_lower  4
    x[6,4]    hard_upper  4
    x[6,5]    OBJ       2.0816681711721684e-18
    x[6,5]    onehot_6  1
    x[6,5]    R206      -2.6697177726926005e-02
    x[6,5]    R207      -6.7365269461077862e-02
    x[6,5]    hard_lower  5
    x[6,5]    hard_upper  5
    x[6,6]    OBJ       0.05
    x[6,6]    onehot_6  1
    x[6,6]    R208      -2.6697177726926005e-02
    x[6,6]    R209      -6.7365269461077862e-02
    x[6,6]    hard_lower  6
    x[6,6]    hard_upper  6
    x[6,7]    OBJ       0.05
    x[6,7]    onehot_6  1
    x[6,7]    R210      -2.6697177726926005e-02
    x[6,7]    R211      -6.7365269461077862e-02
    x[6,7]    hard_lower  7
    x[6,7]    hard_upper  7
    x[6,8]    OBJ       0.05
    x[6,8]    onehot_6  1
    x[6,8]    R212      -2.6697177726926005e-02
    x[6,8]    R213      -6.7365269461077862e-02
    x[6,8]    hard_lower  8
    x[6,8]    hard_upper  8
    x[6,9]    OBJ       0.05
    x[6,9]    onehot_6  1
    x[6,9]    R214      -2.6697177726926005e-02
    x[6,9]    R215      -6.7365269461077862e-02
    x[6,9]    hard_lower  9
    x[6,9]    hard_upper  9
    x[6,10]   OBJ       4.9999999999999996e-02
    x[6,10]   onehot_6  1
    x[6,10]   R216      -2.6697177726926005e-02
    x[6,10]   R217      -6.7365269461077862e-02
    x[6,10]   hard_lower  10
    x[6,10]   hard_upper  10
    x[7,0]    OBJ       0.05
    x[7,0]    onehot_7  1
    x[7,0]    R222      -2.6697177726926005e-02
    x[7,0]    R223      -6.7365269461077862e-02
    x[7,1]    OBJ       4.9999999999999996e-02
    x[7,1]    onehot_7  1
    x[7,1]    R224      -2.6697177726926005e-02
    x[7,1]    R225      -6.7365269461077862e-02
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,2]    OBJ       4.9999999999999996e-02
    x[7,2]    onehot_7  1
    x[7,2]    R226      -2.6697177726926005e-02
    x[7,2]    R227      -6.7365269461077862e-02
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,3]    OBJ       0.05
    x[7,3]    onehot_7  1
    x[7,3]    R228      -2.6697177726926005e-02
    x[7,3]    R229      -6.7365269461077862e-02
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,4]    OBJ       0.05
    x[7,4]    onehot_7  1
    x[7,4]    R230      -2.6697177726926005e-02
    x[7,4]    R231      -6.7365269461077862e-02
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,5]    OBJ       1.6656098386173320e-02
    x[7,5]    onehot_7  1
    x[7,5]    R232      -2.6697177726926005e-02
    x[7,5]    R233      -6.7365269461077862e-02
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,6]    OBJ       0.05
    x[7,6]    onehot_7  1
    x[7,6]    R234      -2.6697177726926005e-02
    x[7,6]    R235      -6.7365269461077862e-02
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,7]    OBJ       0.05
    x[7,7]    onehot_7  1
    x[7,7]    R236      -2.6697177726926005e-02
    x[7,7]    R237      -6.7365269461077862e-02
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,8]    onehot_7  1
    x[7,8]    R238      -2.6697177726926005e-02
    x[7,8]    R239      -6.7365269461077862e-02
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,9]    OBJ       0.05
    x[7,9]    onehot_7  1
    x[7,9]    R240      -2.6697177726926005e-02
    x[7,9]    R241      -6.7365269461077862e-02
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,10]   OBJ       0.05
    x[7,10]   onehot_7  1
    x[7,10]   R242      -2.6697177726926005e-02
    x[7,10]   R243      -6.7365269461077862e-02
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,11]   OBJ       4.9999999999999996e-02
    x[7,11]   onehot_7  1
    x[7,11]   R244      -2.6697177726926005e-02
    x[7,11]   R245      -6.7365269461077862e-02
    x[7,11]   hard_lower  11
    x[7,11]   hard_upper  11
    x[7,12]   OBJ       0.05
    x[7,12]   onehot_7  1
    x[7,12]   R246      -2.6697177726926005e-02
    x[7,12]   R247      -6.7365269461077862e-02
    x[7,12]   hard_lower  12
    x[7,12]   hard_upper  12
    x[7,13]   OBJ       0.05
    x[7,13]   onehot_7  1
    x[7,13]   R248      -2.6697177726926005e-02
    x[7,13]   R249      -6.7365269461077862e-02
    x[7,13]   hard_lower  13
    x[7,13]   hard_upper  13
    x[7,14]   OBJ       4.9999999999999996e-02
    x[7,14]   onehot_7  1
    x[7,14]   R250      -2.6697177726926005e-02
    x[7,14]   R251      -6.7365269461077862e-02
    x[7,14]   hard_lower  14
    x[7,14]   hard_upper  14
    x[7,15]   OBJ       4.9999999999999996e-02
    x[7,15]   onehot_7  1
    x[7,15]   R252      -2.6697177726926005e-02
    x[7,15]   R253      -6.7365269461077862e-02
    x[7,15]   hard_lower  15
    x[7,15]   hard_upper  15
    x[7,16]   OBJ       0.05
    x[7,16]   onehot_7  1
    x[7,16]   R254      -2.6697177726926005e-02
    x[7,16]   R255      -6.7365269461077862e-02
    x[7,16]   hard_lower  16
    x[7,16]   hard_upper  16
    x[7,17]   OBJ       0.05
    x[7,17]   onehot_7  1
    x[7,17]   R256      -2.6697177726926005e-02
    x[7,17]   R257      -6.7365269461077862e-02
    x[7,17]   hard_lower  17
    x[7,17]   hard_upper  17
    x[8,0]    OBJ       5.0000000000000017e-02
    x[8,0]    onehot_8  1
    x[8,0]    R262      -2.6697177726926005e-02
    x[8,0]    R263      -6.7365269461077862e-02
    x[8,1]    OBJ       5.0000000000000024e-02
    x[8,1]    onehot_8  1
    x[8,1]    R264      -2.6697177726926005e-02
    x[8,1]    R265      -6.7365269461077862e-02
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,2]    OBJ       5.0000000000000010e-02
    x[8,2]    onehot_8  1
    x[8,2]    R266      -2.6697177726926005e-02
    x[8,2]    R267      -6.7365269461077862e-02
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,3]    OBJ       0.05
    x[8,3]    onehot_8  1
    x[8,3]    R268      -2.6697177726926005e-02
    x[8,3]    R269      -6.7365269461077862e-02
    x[8,3]    hard_lower  3
    x[8,3]    hard_upper  3
    x[8,4]    OBJ       0.05
    x[8,4]    onehot_8  1
    x[8,4]    R270      -2.6697177726926005e-02
    x[8,4]    R271      -6.7365269461077862e-02
    x[8,4]    hard_lower  4
    x[8,4]    hard_upper  4
    x[8,5]    OBJ       0.0274816446121552
    x[8,5]    onehot_8  1
    x[8,5]    R272      -2.6697177726926005e-02
    x[8,5]    R273      -6.7365269461077862e-02
    x[8,5]    hard_lower  5
    x[8,5]    hard_upper  5
    x[8,6]    OBJ       5.0000000000000010e-02
    x[8,6]    onehot_8  1
    x[8,6]    R274      -2.6697177726926005e-02
    x[8,6]    R275      -6.7365269461077862e-02
    x[8,6]    hard_lower  6
    x[8,6]    hard_upper  6
    x[8,7]    OBJ       1.8589542517627136e-02
    x[8,7]    onehot_8  1
    x[8,7]    R276      -2.6697177726926005e-02
    x[8,7]    R277      -6.7365269461077862e-02
    x[8,7]    hard_lower  7
    x[8,7]    hard_upper  7
    x[8,8]    OBJ       5.0000000000000010e-02
    x[8,8]    onehot_8  1
    x[8,8]    R278      -2.6697177726926005e-02
    x[8,8]    R279      -6.7365269461077862e-02
    x[8,8]    hard_lower  8
    x[8,8]    hard_upper  8
    x[8,9]    OBJ       0.05
    x[8,9]    onehot_8  1
    x[8,9]    R280      -2.6697177726926005e-02
    x[8,9]    R281      -6.7365269461077862e-02
    x[8,9]    hard_lower  9
    x[8,9]    hard_upper  9
    x[8,10]   OBJ       8.3266726846886737e-18
    x[8,10]   onehot_8  1
    x[8,10]   R282      -2.6697177726926005e-02
    x[8,10]   R283      -6.7365269461077862e-02
    x[8,10]   hard_lower  10
    x[8,10]   hard_upper  10
    x[8,11]   OBJ       5.0000000000000010e-02
    x[8,11]   onehot_8  1
    x[8,11]   R284      -2.6697177726926005e-02
    x[8,11]   R285      -6.7365269461077862e-02
    x[8,11]   hard_lower  11
    x[8,11]   hard_upper  11
    x[8,12]   OBJ       0.05
    x[8,12]   onehot_8  1
    x[8,12]   R286      -2.6697177726926005e-02
    x[8,12]   R287      -6.7365269461077862e-02
    x[8,12]   hard_lower  12
    x[8,12]   hard_upper  12
    x[8,13]   OBJ       0.05
    x[8,13]   onehot_8  1
    x[8,13]   R288      -2.6697177726926005e-02
    x[8,13]   R289      -6.7365269461077862e-02
    x[8,13]   hard_lower  13
    x[8,13]   hard_upper  13
    x[8,14]   OBJ       0.05
    x[8,14]   onehot_8  1
    x[8,14]   R290      -2.6697177726926005e-02
    x[8,14]   R291      -6.7365269461077862e-02
    x[8,14]   hard_lower  14
    x[8,14]   hard_upper  14
    x[8,15]   OBJ       0.05
    x[8,15]   onehot_8  1
    x[8,15]   R292      -2.6697177726926005e-02
    x[8,15]   R293      -6.7365269461077862e-02
    x[8,15]   hard_lower  15
    x[8,15]   hard_upper  15
    x[8,16]   OBJ       0.05
    x[8,16]   onehot_8  1
    x[8,16]   R294      -2.6697177726926005e-02
    x[8,16]   R295      -6.7365269461077862e-02
    x[8,16]   hard_lower  16
    x[8,16]   hard_upper  16
    x[8,17]   OBJ       5.0000000000000010e-02
    x[8,17]   onehot_8  1
    x[8,17]   R296      -2.6697177726926005e-02
    x[8,17]   R297      -6.7365269461077862e-02
    x[8,17]   hard_lower  17
    x[8,17]   hard_upper  17
    x[8,18]   OBJ       5.0000000000000017e-02
    x[8,18]   onehot_8  1
    x[8,18]   R298      -2.6697177726926005e-02
    x[8,18]   R299      -6.7365269461077862e-02
    x[8,18]   hard_lower  18
    x[8,18]   hard_upper  18
    x[8,19]   OBJ       5.0000000000000017e-02
    x[8,19]   onehot_8  1
    x[8,19]   R300      -2.6697177726926005e-02
    x[8,19]   R301      -6.7365269461077862e-02
    x[8,19]   hard_lower  19
    x[8,19]   hard_upper  19
    x[8,20]   OBJ       0.05
    x[8,20]   onehot_8  1
    x[8,20]   R302      -2.6697177726926005e-02
    x[8,20]   R303      -6.7365269461077862e-02
    x[8,20]   hard_lower  20
    x[8,20]   hard_upper  20
    x[8,21]   OBJ       5.0000000000000017e-02
    x[8,21]   onehot_8  1
    x[8,21]   R304      -2.6697177726926005e-02
    x[8,21]   R305      -6.7365269461077862e-02
    x[8,21]   hard_lower  21
    x[8,21]   hard_upper  21
    x[9,0]    OBJ       0.05
    x[9,0]    onehot_9  1
    x[9,0]    R310      -2.6697177726926005e-02
    x[9,0]    R311      -6.7365269461077862e-02
    x[9,1]    OBJ       0.05
    x[9,1]    onehot_9  1
    x[9,1]    R312      -2.6697177726926005e-02
    x[9,1]    R313      -6.7365269461077862e-02
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,2]    OBJ       0.05
    x[9,2]    onehot_9  1
    x[9,2]    R314      -2.6697177726926005e-02
    x[9,2]    R315      -6.7365269461077862e-02
    x[9,2]    hard_lower  2
    x[9,2]    hard_upper  2
    x[9,3]    OBJ       7.7975587136262809e-03
    x[9,3]    onehot_9  1
    x[9,3]    R316      -2.6697177726926005e-02
    x[9,3]    R317      -6.7365269461077862e-02
    x[9,3]    hard_lower  3
    x[9,3]    hard_upper  3
    x[9,4]    OBJ       4.9999999999999996e-02
    x[9,4]    onehot_9  1
    x[9,4]    R318      -2.6697177726926005e-02
    x[9,4]    R319      -6.7365269461077862e-02
    x[9,4]    hard_lower  4
    x[9,4]    hard_upper  4
    x[9,5]    OBJ       2.0816681711721684e-18
    x[9,5]    onehot_9  1
    x[9,5]    R320      -2.6697177726926005e-02
    x[9,5]    R321      -6.7365269461077862e-02
    x[9,5]    hard_lower  5
    x[9,5]    hard_upper  5
    x[9,6]    OBJ       0.05
    x[9,6]    onehot_9  1
    x[9,6]    R322      -2.6697177726926005e-02
    x[9,6]    R323      -6.7365269461077862e-02
    x[9,6]    hard_lower  6
    x[9,6]    hard_upper  6
    x[9,7]    OBJ       0.05
    x[9,7]    onehot_9  1
    x[9,7]    R324      -2.6697177726926005e-02
    x[9,7]    R325      -6.7365269461077862e-02
    x[9,7]    hard_lower  7
    x[9,7]    hard_upper  7
    x[9,8]    OBJ       0.05
    x[9,8]    onehot_9  1
    x[9,8]    R326      -2.6697177726926005e-02
    x[9,8]    R327      -6.7365269461077862e-02
    x[9,8]    hard_lower  8
    x[9,8]    hard_upper  8
    x[9,9]    OBJ       0.05
    x[9,9]    onehot_9  1
    x[9,9]    R328      -2.6697177726926005e-02
    x[9,9]    R329      -6.7365269461077862e-02
    x[9,9]    hard_lower  9
    x[9,9]    hard_upper  9
    x[9,10]   OBJ       4.9999999999999996e-02
    x[9,10]   onehot_9  1
    x[9,10]   R330      -2.6697177726926005e-02
    x[9,10]   R331      -6.7365269461077862e-02
    x[9,10]   hard_lower  10
    x[9,10]   hard_upper  10
    x[9,11]   OBJ       4.9999999999999996e-02
    x[9,11]   onehot_9  1
    x[9,11]   R332      -2.6697177726926005e-02
    x[9,11]   R333      -6.7365269461077862e-02
    x[9,11]   hard_lower  11
    x[9,11]   hard_upper  11
    x[9,12]   OBJ       0.05
    x[9,12]   onehot_9  1
    x[9,12]   R334      -2.6697177726926005e-02
    x[9,12]   R335      -6.7365269461077862e-02
    x[9,12]   hard_lower  12
    x[9,12]   hard_upper  12
    x[10,0]   OBJ       5.0000000000000017e-02
    x[10,0]   onehot_10  1
    x[10,0]   R340      -2.6697177726926005e-02
    x[10,0]   R341      -6.7365269461077862e-02
    x[10,1]   OBJ       5.0000000000000024e-02
    x[10,1]   onehot_10  1
    x[10,1]   R342      -2.6697177726926005e-02
    x[10,1]   R343      -6.7365269461077862e-02
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,2]   OBJ       5.0000000000000010e-02
    x[10,2]   onehot_10  1
    x[10,2]   R344      -2.6697177726926005e-02
    x[10,2]   R345      -6.7365269461077862e-02
    x[10,2]   hard_lower  2
    x[10,2]   hard_upper  2
    x[10,3]   OBJ       0.05
    x[10,3]   onehot_10  1
    x[10,3]   R346      -2.6697177726926005e-02
    x[10,3]   R347      -6.7365269461077862e-02
    x[10,3]   hard_lower  3
    x[10,3]   hard_upper  3
    x[10,4]   OBJ       0.05
    x[10,4]   onehot_10  1
    x[10,4]   R348      -2.6697177726926005e-02
    x[10,4]   R349      -6.7365269461077862e-02
    x[10,4]   hard_lower  4
    x[10,4]   hard_upper  4
    x[10,5]   OBJ       2.8603280959924468e-02
    x[10,5]   onehot_10  1
    x[10,5]   R350      -2.6697177726926005e-02
    x[10,5]   R351      -6.7365269461077862e-02
    x[10,5]   hard_lower  5
    x[10,5]   hard_upper  5
    x[10,6]   OBJ       2.3871312224863758e-02
    x[10,6]   onehot_10  1
    x[10,6]   R352      -2.6697177726926005e-02
    x[10,6]   R353      -6.7365269461077862e-02
    x[10,6]   hard_lower  6
    x[10,6]   hard_upper  6
    x[10,7]   OBJ       5.0000000000000010e-02
    x[10,7]   onehot_10  1
    x[10,7]   R354      -2.6697177726926005e-02
    x[10,7]   R355      -6.7365269461077862e-02
    x[10,7]   hard_lower  7
    x[10,7]   hard_upper  7
    x[10,8]   OBJ       5.0000000000000010e-02
    x[10,8]   onehot_10  1
    x[10,8]   R356      -2.6697177726926005e-02
    x[10,8]   R357      -6.7365269461077862e-02
    x[10,8]   hard_lower  8
    x[10,8]   hard_upper  8
    x[10,9]   OBJ       0.05
    x[10,9]   onehot_10  1
    x[10,9]   R358      -2.6697177726926005e-02
    x[10,9]   R359      -6.7365269461077862e-02
    x[10,9]   hard_lower  9
    x[10,9]   hard_upper  9
    x[10,10]  OBJ       8.3266726846886737e-18
    x[10,10]  onehot_10  1
    x[10,10]  R360      -2.6697177726926005e-02
    x[10,10]  R361      -6.7365269461077862e-02
    x[10,10]  hard_lower  10
    x[10,10]  hard_upper  10
    x[10,11]  OBJ       5.0000000000000010e-02
    x[10,11]  onehot_10  1
    x[10,11]  R362      -2.6697177726926005e-02
    x[10,11]  R363      -6.7365269461077862e-02
    x[10,11]  hard_lower  11
    x[10,11]  hard_upper  11
    x[10,12]  OBJ       0.05
    x[10,12]  onehot_10  1
    x[10,12]  R364      -2.6697177726926005e-02
    x[10,12]  R365      -6.7365269461077862e-02
    x[10,12]  hard_lower  12
    x[10,12]  hard_upper  12
    x[10,13]  OBJ       0.05
    x[10,13]  onehot_10  1
    x[10,13]  R366      -2.6697177726926005e-02
    x[10,13]  R367      -6.7365269461077862e-02
    x[10,13]  hard_lower  13
    x[10,13]  hard_upper  13
    x[10,14]  OBJ       0.05
    x[10,14]  onehot_10  1
    x[10,14]  R368      -2.6697177726926005e-02
    x[10,14]  R369      -6.7365269461077862e-02
    x[10,14]  hard_lower  14
    x[10,14]  hard_upper  14
    x[10,15]  OBJ       0.05
    x[10,15]  onehot_10  1
    x[10,15]  R370      -2.6697177726926005e-02
    x[10,15]  R371      -6.7365269461077862e-02
    x[10,15]  hard_lower  15
    x[10,15]  hard_upper  15
    x[10,16]  OBJ       0.05
    x[10,16]  onehot_10  1
    x[10,16]  R372      -2.6697177726926005e-02
    x[10,16]  R373      -6.7365269461077862e-02
    x[10,16]  hard_lower  16
    x[10,16]  hard_upper  16
    x[10,17]  OBJ       5.0000000000000010e-02
    x[10,17]  onehot_10  1
    x[10,17]  R374      -2.6697177726926005e-02
    x[10,17]  R375      -6.7365269461077862e-02
    x[10,17]  hard_lower  17
    x[10,17]  hard_upper  17
    x[10,18]  OBJ       5.0000000000000017e-02
    x[10,18]  onehot_10  1
    x[10,18]  R376      -2.6697177726926005e-02
    x[10,18]  R377      -6.7365269461077862e-02
    x[10,18]  hard_lower  18
    x[10,18]  hard_upper  18
    x[10,19]  OBJ       5.0000000000000017e-02
    x[10,19]  onehot_10  1
    x[10,19]  R378      -2.6697177726926005e-02
    x[10,19]  R379      -6.7365269461077862e-02
    x[10,19]  hard_lower  19
    x[10,19]  hard_upper  19
    x[11,0]   OBJ       0.05
    x[11,0]   onehot_11  1
    x[11,0]   R384      -2.6697177726926005e-02
    x[11,0]   R385      -6.7365269461077862e-02
    x[11,1]   OBJ       0.05
    x[11,1]   onehot_11  1
    x[11,1]   R386      -2.6697177726926005e-02
    x[11,1]   R387      -6.7365269461077862e-02
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,2]   OBJ       9.2998111037938744e-03
    x[11,2]   onehot_11  1
    x[11,2]   R388      -2.6697177726926005e-02
    x[11,2]   R389      -6.7365269461077862e-02
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,3]   OBJ       4.9999999999999996e-02
    x[11,3]   onehot_11  1
    x[11,3]   R390      -2.6697177726926005e-02
    x[11,3]   R391      -6.7365269461077862e-02
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,4]   OBJ       4.9999999999999996e-02
    x[11,4]   onehot_11  1
    x[11,4]   R392      -2.6697177726926005e-02
    x[11,4]   R393      -6.7365269461077862e-02
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,5]   OBJ       2.0816681711721684e-18
    x[11,5]   onehot_11  1
    x[11,5]   R394      -2.6697177726926005e-02
    x[11,5]   R395      -6.7365269461077862e-02
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,6]   OBJ       0.05
    x[11,6]   onehot_11  1
    x[11,6]   R396      -2.6697177726926005e-02
    x[11,6]   R397      -6.7365269461077862e-02
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,7]   OBJ       0.05
    x[11,7]   onehot_11  1
    x[11,7]   R398      -2.6697177726926005e-02
    x[11,7]   R399      -6.7365269461077862e-02
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,8]   OBJ       0.05
    x[11,8]   onehot_11  1
    x[11,8]   R400      -2.6697177726926005e-02
    x[11,8]   R401      -6.7365269461077862e-02
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,9]   OBJ       0.05
    x[11,9]   onehot_11  1
    x[11,9]   R402      -2.6697177726926005e-02
    x[11,9]   R403      -6.7365269461077862e-02
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,10]  OBJ       4.9999999999999996e-02
    x[11,10]  onehot_11  1
    x[11,10]  R404      -2.6697177726926005e-02
    x[11,10]  R405      -6.7365269461077862e-02
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,11]  OBJ       4.9999999999999996e-02
    x[11,11]  onehot_11  1
    x[11,11]  R406      -2.6697177726926005e-02
    x[11,11]  R407      -6.7365269461077862e-02
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,12]  OBJ       0.05
    x[11,12]  onehot_11  1
    x[11,12]  R408      -2.6697177726926005e-02
    x[11,12]  R409      -6.7365269461077862e-02
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[12,0]   OBJ       0.05
    x[12,0]   onehot_12  1
    x[12,0]   R414      -2.6697177726926005e-02
    x[12,0]   R415      -6.7365269461077862e-02
    x[12,1]   OBJ       0.05
    x[12,1]   onehot_12  1
    x[12,1]   R416      -2.6697177726926005e-02
    x[12,1]   R417      -6.7365269461077862e-02
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,2]   OBJ       0.05
    x[12,2]   onehot_12  1
    x[12,2]   R418      -2.6697177726926005e-02
    x[12,2]   R419      -6.7365269461077862e-02
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,3]   OBJ       0.05
    x[12,3]   onehot_12  1
    x[12,3]   R420      -2.6697177726926005e-02
    x[12,3]   R421      -6.7365269461077862e-02
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,4]   OBJ       1.4894579800273058e-02
    x[12,4]   onehot_12  1
    x[12,4]   R422      -2.6697177726926005e-02
    x[12,4]   R423      -6.7365269461077862e-02
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,5]   OBJ       0.05
    x[12,5]   onehot_12  1
    x[12,5]   R424      -2.6697177726926005e-02
    x[12,5]   R425      -6.7365269461077862e-02
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,6]   OBJ       5.0000000000000010e-02
    x[12,6]   onehot_12  1
    x[12,6]   R426      -2.6697177726926005e-02
    x[12,6]   R427      -6.7365269461077862e-02
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,7]   OBJ       4.08006961549745e-18
    x[12,7]   onehot_12  1
    x[12,7]   R428      -2.6697177726926005e-02
    x[12,7]   R429      -6.7365269461077862e-02
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,8]   OBJ       0.05
    x[12,8]   onehot_12  1
    x[12,8]   R430      -2.6697177726926005e-02
    x[12,8]   R431      -6.7365269461077862e-02
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,9]   OBJ       0.05
    x[12,9]   onehot_12  1
    x[12,9]   R432      -2.6697177726926005e-02
    x[12,9]   R433      -6.7365269461077862e-02
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,10]  OBJ       0.05
    x[12,10]  onehot_12  1
    x[12,10]  R434      -2.6697177726926005e-02
    x[12,10]  R435      -6.7365269461077862e-02
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,11]  OBJ       0.05
    x[12,11]  onehot_12  1
    x[12,11]  R436      -2.6697177726926005e-02
    x[12,11]  R437      -6.7365269461077862e-02
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,12]  OBJ       0.05
    x[12,12]  onehot_12  1
    x[12,12]  R438      -2.6697177726926005e-02
    x[12,12]  R439      -6.7365269461077862e-02
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,13]  OBJ       0.05
    x[12,13]  onehot_12  1
    x[12,13]  R440      -2.6697177726926005e-02
    x[12,13]  R441      -6.7365269461077862e-02
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,14]  OBJ       5.0000000000000010e-02
    x[12,14]  onehot_12  1
    x[12,14]  R442      -2.6697177726926005e-02
    x[12,14]  R443      -6.7365269461077862e-02
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,15]  OBJ       0.05
    x[12,15]  onehot_12  1
    x[12,15]  R444      -2.6697177726926005e-02
    x[12,15]  R445      -6.7365269461077862e-02
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[13,0]   OBJ       0.062
    x[13,0]   onehot_13  1
    x[13,0]   R450      -2.6697177726926005e-02
    x[13,0]   R451      -6.7365269461077862e-02
    x[13,1]   OBJ       0.062
    x[13,1]   onehot_13  1
    x[13,1]   R452      -2.6697177726926005e-02
    x[13,1]   R453      -6.7365269461077862e-02
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,2]   OBJ       6.1999999999999993e-02
    x[13,2]   onehot_13  1
    x[13,2]   R454      -2.6697177726926005e-02
    x[13,2]   R455      -6.7365269461077862e-02
    x[13,2]   hard_lower  2
    x[13,2]   hard_upper  2
    x[13,3]   OBJ       6.2000000000000006e-02
    x[13,3]   onehot_13  1
    x[13,3]   R456      -2.6697177726926005e-02
    x[13,3]   R457      -6.7365269461077862e-02
    x[13,3]   hard_lower  3
    x[13,3]   hard_upper  3
    x[13,4]   OBJ       2.4651177512259214e-02
    x[13,4]   onehot_13  1
    x[13,4]   R458      -2.6697177726926005e-02
    x[13,4]   R459      -6.7365269461077862e-02
    x[13,4]   hard_lower  4
    x[13,4]   hard_upper  4
    x[13,5]   OBJ       0.062
    x[13,5]   onehot_13  1
    x[13,5]   R460      -2.6697177726926005e-02
    x[13,5]   R461      -6.7365269461077862e-02
    x[13,5]   hard_lower  5
    x[13,5]   hard_upper  5
    x[13,6]   OBJ       6.2000000000000006e-02
    x[13,6]   onehot_13  1
    x[13,6]   R462      -2.6697177726926005e-02
    x[13,6]   R463      -6.7365269461077862e-02
    x[13,6]   hard_lower  6
    x[13,6]   hard_upper  6
    x[13,7]   OBJ       0.012
    x[13,7]   onehot_13  1
    x[13,7]   R464      -2.6697177726926005e-02
    x[13,7]   R465      -6.7365269461077862e-02
    x[13,7]   hard_lower  7
    x[13,7]   hard_upper  7
    x[13,8]   OBJ       4.6647251587706821e-03
    x[13,8]   onehot_13  1
    x[13,8]   R466      -2.6697177726926005e-02
    x[13,8]   R467      -6.7365269461077862e-02
    x[13,8]   hard_lower  8
    x[13,8]   hard_upper  8
    x[13,9]   OBJ       0.062
    x[13,9]   onehot_13  1
    x[13,9]   R468      -2.6697177726926005e-02
    x[13,9]   R469      -6.7365269461077862e-02
    x[13,9]   hard_lower  9
    x[13,9]   hard_upper  9
    x[13,10]  OBJ       6.2000000000000006e-02
    x[13,10]  onehot_13  1
    x[13,10]  R470      -2.6697177726926005e-02
    x[13,10]  R471      -6.7365269461077862e-02
    x[13,10]  hard_lower  10
    x[13,10]  hard_upper  10
    x[13,11]  OBJ       0.062
    x[13,11]  onehot_13  1
    x[13,11]  R472      -2.6697177726926005e-02
    x[13,11]  R473      -6.7365269461077862e-02
    x[13,11]  hard_lower  11
    x[13,11]  hard_upper  11
    x[13,12]  OBJ       0.062
    x[13,12]  onehot_13  1
    x[13,12]  R474      -2.6697177726926005e-02
    x[13,12]  R475      -6.7365269461077862e-02
    x[13,12]  hard_lower  12
    x[13,12]  hard_upper  12
    x[13,13]  OBJ       6.2000000000000006e-02
    x[13,13]  onehot_13  1
    x[13,13]  R476      -2.6697177726926005e-02
    x[13,13]  R477      -6.7365269461077862e-02
    x[13,13]  hard_lower  13
    x[13,13]  hard_upper  13
    x[13,14]  OBJ       6.1999999999999993e-02
    x[13,14]  onehot_13  1
    x[13,14]  R478      -2.6697177726926005e-02
    x[13,14]  R479      -6.7365269461077862e-02
    x[13,14]  hard_lower  14
    x[13,14]  hard_upper  14
    x[13,15]  OBJ       0.062
    x[13,15]  onehot_13  1
    x[13,15]  R480      -2.6697177726926005e-02
    x[13,15]  R481      -6.7365269461077862e-02
    x[13,15]  hard_lower  15
    x[13,15]  hard_upper  15
    x[13,16]  OBJ       0.062
    x[13,16]  onehot_13  1
    x[13,16]  R482      -2.6697177726926005e-02
    x[13,16]  R483      -6.7365269461077862e-02
    x[13,16]  hard_lower  16
    x[13,16]  hard_upper  16
    x[13,17]  OBJ       0.062
    x[13,17]  onehot_13  1
    x[13,17]  R484      -2.6697177726926005e-02
    x[13,17]  R485      -6.7365269461077862e-02
    x[13,17]  hard_lower  17
    x[13,17]  hard_upper  17
    x[13,18]  OBJ       6.2000000000000006e-02
    x[13,18]  onehot_13  1
    x[13,18]  R486      -2.6697177726926005e-02
    x[13,18]  R487      -6.7365269461077862e-02
    x[13,18]  hard_lower  18
    x[13,18]  hard_upper  18
    x[13,19]  OBJ       6.1999999999999993e-02
    x[13,19]  onehot_13  1
    x[13,19]  R488      -2.6697177726926005e-02
    x[13,19]  R489      -6.7365269461077862e-02
    x[13,19]  hard_lower  19
    x[13,19]  hard_upper  19
    x[14,0]   OBJ       0.05
    x[14,0]   onehot_14  1
    x[14,0]   R494      -2.6697177726926005e-02
    x[14,0]   R495      -6.7365269461077862e-02
    x[14,1]   OBJ       4.9999999999999996e-02
    x[14,1]   onehot_14  1
    x[14,1]   R496      -2.6697177726926005e-02
    x[14,1]   R497      -6.7365269461077862e-02
    x[14,1]   hard_lower  1
    x[14,1]   hard_upper  1
    x[14,2]   OBJ       2.5518445364192427e-02
    x[14,2]   onehot_14  1
    x[14,2]   R498      -2.6697177726926005e-02
    x[14,2]   R499      -6.7365269461077862e-02
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,3]   OBJ       0.05
    x[14,3]   onehot_14  1
    x[14,3]   R500      -2.6697177726926005e-02
    x[14,3]   R501      -6.7365269461077862e-02
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,4]   OBJ       0.05
    x[14,4]   onehot_14  1
    x[14,4]   R502      -2.6697177726926005e-02
    x[14,4]   R503      -6.7365269461077862e-02
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,5]   OBJ       4.9999999999999996e-02
    x[14,5]   onehot_14  1
    x[14,5]   R504      -2.6697177726926005e-02
    x[14,5]   R505      -6.7365269461077862e-02
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,6]   OBJ       0.05
    x[14,6]   onehot_14  1
    x[14,6]   R506      -2.6697177726926005e-02
    x[14,6]   R507      -6.7365269461077862e-02
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,7]   OBJ       0.05
    x[14,7]   onehot_14  1
    x[14,7]   R508      -2.6697177726926005e-02
    x[14,7]   R509      -6.7365269461077862e-02
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,8]   onehot_14  1
    x[14,8]   R510      -2.6697177726926005e-02
    x[14,8]   R511      -6.7365269461077862e-02
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,9]   OBJ       0.05
    x[14,9]   onehot_14  1
    x[14,9]   R512      -2.6697177726926005e-02
    x[14,9]   R513      -6.7365269461077862e-02
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,10]  OBJ       0.05
    x[14,10]  onehot_14  1
    x[14,10]  R514      -2.6697177726926005e-02
    x[14,10]  R515      -6.7365269461077862e-02
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,11]  OBJ       4.9999999999999996e-02
    x[14,11]  onehot_14  1
    x[14,11]  R516      -2.6697177726926005e-02
    x[14,11]  R517      -6.7365269461077862e-02
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,12]  OBJ       0.05
    x[14,12]  onehot_14  1
    x[14,12]  R518      -2.6697177726926005e-02
    x[14,12]  R519      -6.7365269461077862e-02
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,13]  OBJ       0.05
    x[14,13]  onehot_14  1
    x[14,13]  R520      -2.6697177726926005e-02
    x[14,13]  R521      -6.7365269461077862e-02
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,14]  OBJ       4.9999999999999996e-02
    x[14,14]  onehot_14  1
    x[14,14]  R522      -2.6697177726926005e-02
    x[14,14]  R523      -6.7365269461077862e-02
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,15]  OBJ       4.9999999999999996e-02
    x[14,15]  onehot_14  1
    x[14,15]  R524      -2.6697177726926005e-02
    x[14,15]  R525      -6.7365269461077862e-02
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[15,0]   OBJ       0.0635
    x[15,0]   onehot_15  1
    x[15,0]   R530      -2.6697177726926005e-02
    x[15,0]   R531      -6.7365269461077862e-02
    x[15,1]   OBJ       0.0635
    x[15,1]   onehot_15  1
    x[15,1]   R532      -2.6697177726926005e-02
    x[15,1]   R533      -6.7365269461077862e-02
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,2]   OBJ       0.0635
    x[15,2]   onehot_15  1
    x[15,2]   R534      -2.6697177726926005e-02
    x[15,2]   R535      -6.7365269461077862e-02
    x[15,2]   hard_lower  2
    x[15,2]   hard_upper  2
    x[15,3]   OBJ       3.2974963399818653e-02
    x[15,3]   onehot_15  1
    x[15,3]   R536      -2.6697177726926005e-02
    x[15,3]   R537      -6.7365269461077862e-02
    x[15,3]   hard_lower  3
    x[15,3]   hard_upper  3
    x[15,4]   OBJ       0.0635
    x[15,4]   onehot_15  1
    x[15,4]   R538      -2.6697177726926005e-02
    x[15,4]   R539      -6.7365269461077862e-02
    x[15,4]   hard_lower  4
    x[15,4]   hard_upper  4
    x[15,5]   OBJ       0.0635
    x[15,5]   onehot_15  1
    x[15,5]   R540      -2.6697177726926005e-02
    x[15,5]   R541      -6.7365269461077862e-02
    x[15,5]   hard_lower  5
    x[15,5]   hard_upper  5
    x[15,6]   OBJ       0.0635
    x[15,6]   onehot_15  1
    x[15,6]   R542      -2.6697177726926005e-02
    x[15,6]   R543      -6.7365269461077862e-02
    x[15,6]   hard_lower  6
    x[15,6]   hard_upper  6
    x[15,7]   OBJ       0.0635
    x[15,7]   onehot_15  1
    x[15,7]   R544      -2.6697177726926005e-02
    x[15,7]   R545      -6.7365269461077862e-02
    x[15,7]   hard_lower  7
    x[15,7]   hard_upper  7
    x[15,8]   OBJ       1.3500000000000005e-02
    x[15,8]   onehot_15  1
    x[15,8]   R546      -2.6697177726926005e-02
    x[15,8]   R547      -6.7365269461077862e-02
    x[15,8]   hard_lower  8
    x[15,8]   hard_upper  8
    x[15,9]   OBJ       0.0635
    x[15,9]   onehot_15  1
    x[15,9]   R548      -2.6697177726926005e-02
    x[15,9]   R549      -6.7365269461077862e-02
    x[15,9]   hard_lower  9
    x[15,9]   hard_upper  9
    x[15,10]  OBJ       0.0635
    x[15,10]  onehot_15  1
    x[15,10]  R550      -2.6697177726926005e-02
    x[15,10]  R551      -6.7365269461077862e-02
    x[15,10]  hard_lower  10
    x[15,10]  hard_upper  10
    x[15,11]  OBJ       0.0635
    x[15,11]  onehot_15  1
    x[15,11]  R552      -2.6697177726926005e-02
    x[15,11]  R553      -6.7365269461077862e-02
    x[15,11]  hard_lower  11
    x[15,11]  hard_upper  11
    x[15,12]  OBJ       0.0635
    x[15,12]  onehot_15  1
    x[15,12]  R554      -2.6697177726926005e-02
    x[15,12]  R555      -6.7365269461077862e-02
    x[15,12]  hard_lower  12
    x[15,12]  hard_upper  12
    x[15,13]  OBJ       0.0635
    x[15,13]  onehot_15  1
    x[15,13]  R556      -2.6697177726926005e-02
    x[15,13]  R557      -6.7365269461077862e-02
    x[15,13]  hard_lower  13
    x[15,13]  hard_upper  13
    x[15,14]  OBJ       0.0635
    x[15,14]  onehot_15  1
    x[15,14]  R558      -2.6697177726926005e-02
    x[15,14]  R559      -6.7365269461077862e-02
    x[15,14]  hard_lower  14
    x[15,14]  hard_upper  14
    x[15,15]  OBJ       0.0635
    x[15,15]  onehot_15  1
    x[15,15]  R560      -2.6697177726926005e-02
    x[15,15]  R561      -6.7365269461077862e-02
    x[15,15]  hard_lower  15
    x[15,15]  hard_upper  15
    x[15,16]  OBJ       0.0635
    x[15,16]  onehot_15  1
    x[15,16]  R562      -2.6697177726926005e-02
    x[15,16]  R563      -6.7365269461077862e-02
    x[15,16]  hard_lower  16
    x[15,16]  hard_upper  16
    x[16,0]   OBJ       0.05
    x[16,0]   onehot_16  1
    x[16,0]   R568      -2.6697177726926005e-02
    x[16,0]   R569      -6.7365269461077862e-02
    x[16,1]   OBJ       0.05
    x[16,1]   onehot_16  1
    x[16,1]   R570      -2.6697177726926005e-02
    x[16,1]   R571      -6.7365269461077862e-02
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,2]   OBJ       0.05
    x[16,2]   onehot_16  1
    x[16,2]   R572      -2.6697177726926005e-02
    x[16,2]   R573      -6.7365269461077862e-02
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,3]   OBJ       1.2461542726707613e-02
    x[16,3]   onehot_16  1
    x[16,3]   R574      -2.6697177726926005e-02
    x[16,3]   R575      -6.7365269461077862e-02
    x[16,3]   hard_lower  3
    x[16,3]   hard_upper  3
    x[16,4]   OBJ       4.9999999999999996e-02
    x[16,4]   onehot_16  1
    x[16,4]   R576      -2.6697177726926005e-02
    x[16,4]   R577      -6.7365269461077862e-02
    x[16,4]   hard_lower  4
    x[16,4]   hard_upper  4
    x[16,5]   OBJ       0.05
    x[16,5]   onehot_16  1
    x[16,5]   R578      -2.6697177726926005e-02
    x[16,5]   R579      -6.7365269461077862e-02
    x[16,5]   hard_lower  5
    x[16,5]   hard_upper  5
    x[16,6]   OBJ       2.9976021664879226e-18
    x[16,6]   onehot_16  1
    x[16,6]   R580      -2.6697177726926005e-02
    x[16,6]   R581      -6.7365269461077862e-02
    x[16,6]   hard_lower  6
    x[16,6]   hard_upper  6
    x[16,7]   OBJ       0.05
    x[16,7]   onehot_16  1
    x[16,7]   R582      -2.6697177726926005e-02
    x[16,7]   R583      -6.7365269461077862e-02
    x[16,7]   hard_lower  7
    x[16,7]   hard_upper  7
    x[16,8]   OBJ       0.05
    x[16,8]   onehot_16  1
    x[16,8]   R584      -2.6697177726926005e-02
    x[16,8]   R585      -6.7365269461077862e-02
    x[16,8]   hard_lower  8
    x[16,8]   hard_upper  8
    x[16,9]   OBJ       0.05
    x[16,9]   onehot_16  1
    x[16,9]   R586      -2.6697177726926005e-02
    x[16,9]   R587      -6.7365269461077862e-02
    x[16,9]   hard_lower  9
    x[16,9]   hard_upper  9
    x[16,10]  OBJ       0.05
    x[16,10]  onehot_16  1
    x[16,10]  R588      -2.6697177726926005e-02
    x[16,10]  R589      -6.7365269461077862e-02
    x[16,10]  hard_lower  10
    x[16,10]  hard_upper  10
    x[16,11]  OBJ       0.05
    x[16,11]  onehot_16  1
    x[16,11]  R590      -2.6697177726926005e-02
    x[16,11]  R591      -6.7365269461077862e-02
    x[16,11]  hard_lower  11
    x[16,11]  hard_upper  11
    x[16,12]  OBJ       0.05
    x[16,12]  onehot_16  1
    x[16,12]  R592      -2.6697177726926005e-02
    x[16,12]  R593      -6.7365269461077862e-02
    x[16,12]  hard_lower  12
    x[16,12]  hard_upper  12
    x[17,0]   OBJ       0.077
    x[17,0]   onehot_17  1
    x[17,0]   R598      -2.6697177726926005e-02
    x[17,0]   R599      -6.7365269461077862e-02
    x[17,1]   OBJ       0.077
    x[17,1]   onehot_17  1
    x[17,1]   R600      -2.6697177726926005e-02
    x[17,1]   R601      -6.7365269461077862e-02
    x[17,1]   hard_lower  1
    x[17,1]   hard_upper  1
    x[17,2]   OBJ       0.077
    x[17,2]   onehot_17  1
    x[17,2]   R602      -2.6697177726926005e-02
    x[17,2]   R603      -6.7365269461077862e-02
    x[17,2]   hard_lower  2
    x[17,2]   hard_upper  2
    x[17,3]   OBJ       0.077
    x[17,3]   onehot_17  1
    x[17,3]   R604      -2.6697177726926005e-02
    x[17,3]   R605      -6.7365269461077862e-02
    x[17,3]   hard_lower  3
    x[17,3]   hard_upper  3
    x[17,4]   OBJ       0.077
    x[17,4]   onehot_17  1
    x[17,4]   R606      -2.6697177726926005e-02
    x[17,4]   R607      -6.7365269461077862e-02
    x[17,4]   hard_lower  4
    x[17,4]   hard_upper  4
    x[17,5]   OBJ       0.077
    x[17,5]   onehot_17  1
    x[17,5]   R608      -2.6697177726926005e-02
    x[17,5]   R609      -6.7365269461077862e-02
    x[17,5]   hard_lower  5
    x[17,5]   hard_upper  5
    x[17,6]   OBJ       0.077
    x[17,6]   onehot_17  1
    x[17,6]   R610      -2.6697177726926005e-02
    x[17,6]   R611      -6.7365269461077862e-02
    x[17,6]   hard_lower  6
    x[17,6]   hard_upper  6
    x[17,7]   OBJ       2.7000000000000003e-02
    x[17,7]   onehot_17  1
    x[17,7]   R612      -2.6697177726926005e-02
    x[17,7]   R613      -6.7365269461077862e-02
    x[17,7]   hard_lower  7
    x[17,7]   hard_upper  7
    x[17,8]   OBJ       0.077
    x[17,8]   onehot_17  1
    x[17,8]   R614      -2.6697177726926005e-02
    x[17,8]   R615      -6.7365269461077862e-02
    x[17,8]   hard_lower  8
    x[17,8]   hard_upper  8
    x[17,9]   OBJ       1.5173089055534042e-02
    x[17,9]   onehot_17  1
    x[17,9]   R616      -2.6697177726926005e-02
    x[17,9]   R617      -6.7365269461077862e-02
    x[17,9]   hard_lower  9
    x[17,9]   hard_upper  9
    x[17,10]  OBJ       0.077
    x[17,10]  onehot_17  1
    x[17,10]  R618      -2.6697177726926005e-02
    x[17,10]  R619      -6.7365269461077862e-02
    x[17,10]  hard_lower  10
    x[17,10]  hard_upper  10
    x[17,11]  OBJ       0.077
    x[17,11]  onehot_17  1
    x[17,11]  R620      -2.6697177726926005e-02
    x[17,11]  R621      -6.7365269461077862e-02
    x[17,11]  hard_lower  11
    x[17,11]  hard_upper  11
    x[17,12]  OBJ       0.077
    x[17,12]  onehot_17  1
    x[17,12]  R622      -2.6697177726926005e-02
    x[17,12]  R623      -6.7365269461077862e-02
    x[17,12]  hard_lower  12
    x[17,12]  hard_upper  12
    x[17,13]  OBJ       0.077
    x[17,13]  onehot_17  1
    x[17,13]  R624      -2.6697177726926005e-02
    x[17,13]  R625      -6.7365269461077862e-02
    x[17,13]  hard_lower  13
    x[17,13]  hard_upper  13
    x[17,14]  OBJ       0.077
    x[17,14]  onehot_17  1
    x[17,14]  R626      -2.6697177726926005e-02
    x[17,14]  R627      -6.7365269461077862e-02
    x[17,14]  hard_lower  14
    x[17,14]  hard_upper  14
    x[17,15]  OBJ       0.077
    x[17,15]  onehot_17  1
    x[17,15]  R628      -2.6697177726926005e-02
    x[17,15]  R629      -6.7365269461077862e-02
    x[17,15]  hard_lower  15
    x[17,15]  hard_upper  15
    x[17,16]  OBJ       0.077
    x[17,16]  onehot_17  1
    x[17,16]  R630      -2.6697177726926005e-02
    x[17,16]  R631      -6.7365269461077862e-02
    x[17,16]  hard_lower  16
    x[17,16]  hard_upper  16
    x[18,0]   OBJ       0.05
    x[18,0]   onehot_18  1
    x[18,0]   R636      -2.6697177726926005e-02
    x[18,0]   R637      -6.7365269461077862e-02
    x[18,1]   OBJ       0.05
    x[18,1]   onehot_18  1
    x[18,1]   R638      -2.6697177726926005e-02
    x[18,1]   R639      -6.7365269461077862e-02
    x[18,1]   hard_lower  1
    x[18,1]   hard_upper  1
    x[18,2]   OBJ       0.05
    x[18,2]   onehot_18  1
    x[18,2]   R640      -2.6697177726926005e-02
    x[18,2]   R641      -6.7365269461077862e-02
    x[18,2]   hard_lower  2
    x[18,2]   hard_upper  2
    x[18,3]   OBJ       0.05
    x[18,3]   onehot_18  1
    x[18,3]   R642      -2.6697177726926005e-02
    x[18,3]   R643      -6.7365269461077862e-02
    x[18,3]   hard_lower  3
    x[18,3]   hard_upper  3
    x[18,4]   OBJ       0.05
    x[18,4]   onehot_18  1
    x[18,4]   R644      -2.6697177726926005e-02
    x[18,4]   R645      -6.7365269461077862e-02
    x[18,4]   hard_lower  4
    x[18,4]   hard_upper  4
    x[18,5]   OBJ       2.6896194018026474e-02
    x[18,5]   onehot_18  1
    x[18,5]   R646      -2.6697177726926005e-02
    x[18,5]   R647      -6.7365269461077862e-02
    x[18,5]   hard_lower  5
    x[18,5]   hard_upper  5
    x[18,6]   OBJ       1.7388475474385212e-02
    x[18,6]   onehot_18  1
    x[18,6]   R648      -2.6697177726926005e-02
    x[18,6]   R649      -6.7365269461077862e-02
    x[18,6]   hard_lower  6
    x[18,6]   hard_upper  6
    x[18,7]   OBJ       5.0000000000000010e-02
    x[18,7]   onehot_18  1
    x[18,7]   R650      -2.6697177726926005e-02
    x[18,7]   R651      -6.7365269461077862e-02
    x[18,7]   hard_lower  7
    x[18,7]   hard_upper  7
    x[18,8]   OBJ       5.0000000000000010e-02
    x[18,8]   onehot_18  1
    x[18,8]   R652      -2.6697177726926005e-02
    x[18,8]   R653      -6.7365269461077862e-02
    x[18,8]   hard_lower  8
    x[18,8]   hard_upper  8
    x[18,9]   OBJ       6.7446048745978258e-18
    x[18,9]   onehot_18  1
    x[18,9]   R654      -2.6697177726926005e-02
    x[18,9]   R655      -6.7365269461077862e-02
    x[18,9]   hard_lower  9
    x[18,9]   hard_upper  9
    x[18,10]  OBJ       5.0000000000000010e-02
    x[18,10]  onehot_18  1
    x[18,10]  R656      -2.6697177726926005e-02
    x[18,10]  R657      -6.7365269461077862e-02
    x[18,10]  hard_lower  10
    x[18,10]  hard_upper  10
    x[18,11]  OBJ       0.05
    x[18,11]  onehot_18  1
    x[18,11]  R658      -2.6697177726926005e-02
    x[18,11]  R659      -6.7365269461077862e-02
    x[18,11]  hard_lower  11
    x[18,11]  hard_upper  11
    x[18,12]  OBJ       5.0000000000000010e-02
    x[18,12]  onehot_18  1
    x[18,12]  R660      -2.6697177726926005e-02
    x[18,12]  R661      -6.7365269461077862e-02
    x[18,12]  hard_lower  12
    x[18,12]  hard_upper  12
    x[18,13]  OBJ       5.0000000000000010e-02
    x[18,13]  onehot_18  1
    x[18,13]  R662      -2.6697177726926005e-02
    x[18,13]  R663      -6.7365269461077862e-02
    x[18,13]  hard_lower  13
    x[18,13]  hard_upper  13
    x[18,14]  OBJ       0.05
    x[18,14]  onehot_18  1
    x[18,14]  R664      -2.6697177726926005e-02
    x[18,14]  R665      -6.7365269461077862e-02
    x[18,14]  hard_lower  14
    x[18,14]  hard_upper  14
    x[18,15]  OBJ       0.05
    x[18,15]  onehot_18  1
    x[18,15]  R666      -2.6697177726926005e-02
    x[18,15]  R667      -6.7365269461077862e-02
    x[18,15]  hard_lower  15
    x[18,15]  hard_upper  15
    x[18,16]  OBJ       0.05
    x[18,16]  onehot_18  1
    x[18,16]  R668      -2.6697177726926005e-02
    x[18,16]  R669      -6.7365269461077862e-02
    x[18,16]  hard_lower  16
    x[18,16]  hard_upper  16
    x[18,17]  OBJ       0.05
    x[18,17]  onehot_18  1
    x[18,17]  R670      -2.6697177726926005e-02
    x[18,17]  R671      -6.7365269461077862e-02
    x[18,17]  hard_lower  17
    x[18,17]  hard_upper  17
    x[19,0]   OBJ       0.05
    x[19,0]   onehot_19  1
    x[19,0]   R676      -2.6697177726926005e-02
    x[19,0]   R677      -6.7365269461077862e-02
    x[19,1]   OBJ       4.9999999999999996e-02
    x[19,1]   onehot_19  1
    x[19,1]   R678      -2.6697177726926005e-02
    x[19,1]   R679      -6.7365269461077862e-02
    x[19,1]   hard_lower  1
    x[19,1]   hard_upper  1
    x[19,2]   OBJ       4.2367046898115213e-03
    x[19,2]   onehot_19  1
    x[19,2]   R680      -2.6697177726926005e-02
    x[19,2]   R681      -6.7365269461077862e-02
    x[19,2]   hard_lower  2
    x[19,2]   hard_upper  2
    x[19,3]   OBJ       0.05
    x[19,3]   onehot_19  1
    x[19,3]   R682      -2.6697177726926005e-02
    x[19,3]   R683      -6.7365269461077862e-02
    x[19,3]   hard_lower  3
    x[19,3]   hard_upper  3
    x[19,4]   onehot_19  1
    x[19,4]   R684      -2.6697177726926005e-02
    x[19,4]   R685      -6.7365269461077862e-02
    x[19,4]   hard_lower  4
    x[19,4]   hard_upper  4
    x[19,5]   OBJ       0.05
    x[19,5]   onehot_19  1
    x[19,5]   R686      -2.6697177726926005e-02
    x[19,5]   R687      -6.7365269461077862e-02
    x[19,5]   hard_lower  5
    x[19,5]   hard_upper  5
    x[19,6]   OBJ       0.05
    x[19,6]   onehot_19  1
    x[19,6]   R688      -2.6697177726926005e-02
    x[19,6]   R689      -6.7365269461077862e-02
    x[19,6]   hard_lower  6
    x[19,6]   hard_upper  6
    x[19,7]   OBJ       4.9999999999999996e-02
    x[19,7]   onehot_19  1
    x[19,7]   R690      -2.6697177726926005e-02
    x[19,7]   R691      -6.7365269461077862e-02
    x[19,7]   hard_lower  7
    x[19,7]   hard_upper  7
    x[19,8]   OBJ       0.05
    x[19,8]   onehot_19  1
    x[19,8]   R692      -2.6697177726926005e-02
    x[19,8]   R693      -6.7365269461077862e-02
    x[19,8]   hard_lower  8
    x[19,8]   hard_upper  8
    x[20,0]   OBJ       0.05
    x[20,0]   onehot_20  1
    x[20,0]   R698      -2.6697177726926005e-02
    x[20,0]   R699      -6.7365269461077862e-02
    x[20,1]   OBJ       0.05
    x[20,1]   onehot_20  1
    x[20,1]   R700      -2.6697177726926005e-02
    x[20,1]   R701      -6.7365269461077862e-02
    x[20,1]   hard_lower  1
    x[20,1]   hard_upper  1
    x[20,2]   OBJ       0.05
    x[20,2]   onehot_20  1
    x[20,2]   R702      -2.6697177726926005e-02
    x[20,2]   R703      -6.7365269461077862e-02
    x[20,2]   hard_lower  2
    x[20,2]   hard_upper  2
    x[20,3]   OBJ       1.2997814612897899e-02
    x[20,3]   onehot_20  1
    x[20,3]   R704      -2.6697177726926005e-02
    x[20,3]   R705      -6.7365269461077862e-02
    x[20,3]   hard_lower  3
    x[20,3]   hard_upper  3
    x[20,4]   OBJ       4.9999999999999996e-02
    x[20,4]   onehot_20  1
    x[20,4]   R706      -2.6697177726926005e-02
    x[20,4]   R707      -6.7365269461077862e-02
    x[20,4]   hard_lower  4
    x[20,4]   hard_upper  4
    x[20,5]   OBJ       0.05
    x[20,5]   onehot_20  1
    x[20,5]   R708      -2.6697177726926005e-02
    x[20,5]   R709      -6.7365269461077862e-02
    x[20,5]   hard_lower  5
    x[20,5]   hard_upper  5
    x[20,6]   OBJ       2.9976021664879226e-18
    x[20,6]   onehot_20  1
    x[20,6]   R710      -2.6697177726926005e-02
    x[20,6]   R711      -6.7365269461077862e-02
    x[20,6]   hard_lower  6
    x[20,6]   hard_upper  6
    x[20,7]   OBJ       0.05
    x[20,7]   onehot_20  1
    x[20,7]   R712      -2.6697177726926005e-02
    x[20,7]   R713      -6.7365269461077862e-02
    x[20,7]   hard_lower  7
    x[20,7]   hard_upper  7
    x[20,8]   OBJ       0.05
    x[20,8]   onehot_20  1
    x[20,8]   R714      -2.6697177726926005e-02
    x[20,8]   R715      -6.7365269461077862e-02
    x[20,8]   hard_lower  8
    x[20,8]   hard_upper  8
    x[20,9]   OBJ       0.05
    x[20,9]   onehot_20  1
    x[20,9]   R716      -2.6697177726926005e-02
    x[20,9]   R717      -6.7365269461077862e-02
    x[20,9]   hard_lower  9
    x[20,9]   hard_upper  9
    x[20,10]  OBJ       0.05
    x[20,10]  onehot_20  1
    x[20,10]  R718      -2.6697177726926005e-02
    x[20,10]  R719      -6.7365269461077862e-02
    x[20,10]  hard_lower  10
    x[20,10]  hard_upper  10
    x[20,11]  OBJ       0.05
    x[20,11]  onehot_20  1
    x[20,11]  R720      -2.6697177726926005e-02
    x[20,11]  R721      -6.7365269461077862e-02
    x[20,11]  hard_lower  11
    x[20,11]  hard_upper  11
    x[20,12]  OBJ       0.05
    x[20,12]  onehot_20  1
    x[20,12]  R722      -2.6697177726926005e-02
    x[20,12]  R723      -6.7365269461077862e-02
    x[20,12]  hard_lower  12
    x[20,12]  hard_upper  12
    x[21,0]   OBJ       0.062
    x[21,0]   onehot_21  1
    x[21,0]   R728      -2.6697177726926005e-02
    x[21,0]   R729      -6.7365269461077862e-02
    x[21,1]   OBJ       3.2997879955372587e-02
    x[21,1]   onehot_21  1
    x[21,1]   R730      -2.6697177726926005e-02
    x[21,1]   R731      -6.7365269461077862e-02
    x[21,1]   hard_lower  1
    x[21,1]   hard_upper  1
    x[21,2]   OBJ       6.1999999999999993e-02
    x[21,2]   onehot_21  1
    x[21,2]   R732      -2.6697177726926005e-02
    x[21,2]   R733      -6.7365269461077862e-02
    x[21,2]   hard_lower  2
    x[21,2]   hard_upper  2
    x[21,3]   OBJ       6.2000000000000006e-02
    x[21,3]   onehot_21  1
    x[21,3]   R734      -2.6697177726926005e-02
    x[21,3]   R735      -6.7365269461077862e-02
    x[21,3]   hard_lower  3
    x[21,3]   hard_upper  3
    x[21,4]   OBJ       2.6194327355613656e-02
    x[21,4]   onehot_21  1
    x[21,4]   R736      -2.6697177726926005e-02
    x[21,4]   R737      -6.7365269461077862e-02
    x[21,4]   hard_lower  4
    x[21,4]   hard_upper  4
    x[21,5]   OBJ       0.062
    x[21,5]   onehot_21  1
    x[21,5]   R738      -2.6697177726926005e-02
    x[21,5]   R739      -6.7365269461077862e-02
    x[21,5]   hard_lower  5
    x[21,5]   hard_upper  5
    x[21,6]   OBJ       6.2000000000000006e-02
    x[21,6]   onehot_21  1
    x[21,6]   R740      -2.6697177726926005e-02
    x[21,6]   R741      -6.7365269461077862e-02
    x[21,6]   hard_lower  6
    x[21,6]   hard_upper  6
    x[21,7]   OBJ       0.012
    x[21,7]   onehot_21  1
    x[21,7]   R742      -2.6697177726926005e-02
    x[21,7]   R743      -6.7365269461077862e-02
    x[21,7]   hard_lower  7
    x[21,7]   hard_upper  7
    x[21,8]   OBJ       0.062
    x[21,8]   onehot_21  1
    x[21,8]   R744      -2.6697177726926005e-02
    x[21,8]   R745      -6.7365269461077862e-02
    x[21,8]   hard_lower  8
    x[21,8]   hard_upper  8
    x[21,9]   OBJ       0.062
    x[21,9]   onehot_21  1
    x[21,9]   R746      -2.6697177726926005e-02
    x[21,9]   R747      -6.7365269461077862e-02
    x[21,9]   hard_lower  9
    x[21,9]   hard_upper  9
    x[21,10]  OBJ       6.2000000000000006e-02
    x[21,10]  onehot_21  1
    x[21,10]  R748      -2.6697177726926005e-02
    x[21,10]  R749      -6.7365269461077862e-02
    x[21,10]  hard_lower  10
    x[21,10]  hard_upper  10
    x[21,11]  OBJ       0.062
    x[21,11]  onehot_21  1
    x[21,11]  R750      -2.6697177726926005e-02
    x[21,11]  R751      -6.7365269461077862e-02
    x[21,11]  hard_lower  11
    x[21,11]  hard_upper  11
    x[21,12]  OBJ       0.062
    x[21,12]  onehot_21  1
    x[21,12]  R752      -2.6697177726926005e-02
    x[21,12]  R753      -6.7365269461077862e-02
    x[21,12]  hard_lower  12
    x[21,12]  hard_upper  12
    x[21,13]  OBJ       6.2000000000000006e-02
    x[21,13]  onehot_21  1
    x[21,13]  R754      -2.6697177726926005e-02
    x[21,13]  R755      -6.7365269461077862e-02
    x[21,13]  hard_lower  13
    x[21,13]  hard_upper  13
    x[21,14]  OBJ       6.1999999999999993e-02
    x[21,14]  onehot_21  1
    x[21,14]  R756      -2.6697177726926005e-02
    x[21,14]  R757      -6.7365269461077862e-02
    x[21,14]  hard_lower  14
    x[21,14]  hard_upper  14
    x[21,15]  OBJ       0.062
    x[21,15]  onehot_21  1
    x[21,15]  R758      -2.6697177726926005e-02
    x[21,15]  R759      -6.7365269461077862e-02
    x[21,15]  hard_lower  15
    x[21,15]  hard_upper  15
    x[22,0]   OBJ       5.9000000000000004e-02
    x[22,0]   onehot_22  1
    x[22,0]   R764      -2.6697177726926005e-02
    x[22,0]   R765      -6.7365269461077862e-02
    x[22,1]   OBJ       5.9000000000000004e-02
    x[22,1]   onehot_22  1
    x[22,1]   R766      -2.6697177726926005e-02
    x[22,1]   R767      -6.7365269461077862e-02
    x[22,1]   hard_lower  1
    x[22,1]   hard_upper  1
    x[22,2]   OBJ       5.9000000000000004e-02
    x[22,2]   onehot_22  1
    x[22,2]   R768      -2.6697177726926005e-02
    x[22,2]   R769      -6.7365269461077862e-02
    x[22,2]   hard_lower  2
    x[22,2]   hard_upper  2
    x[22,3]   OBJ       5.9000000000000004e-02
    x[22,3]   onehot_22  1
    x[22,3]   R770      -2.6697177726926005e-02
    x[22,3]   R771      -6.7365269461077862e-02
    x[22,3]   hard_lower  3
    x[22,3]   hard_upper  3
    x[22,4]   OBJ       0.059
    x[22,4]   onehot_22  1
    x[22,4]   R772      -2.6697177726926005e-02
    x[22,4]   R773      -6.7365269461077862e-02
    x[22,4]   hard_lower  4
    x[22,4]   hard_upper  4
    x[22,5]   OBJ       9.0000000000000011e-03
    x[22,5]   onehot_22  1
    x[22,5]   R774      -2.6697177726926005e-02
    x[22,5]   R775      -6.7365269461077862e-02
    x[22,5]   hard_lower  5
    x[22,5]   hard_upper  5
    x[22,6]   OBJ       0.002276701973114
    x[22,6]   onehot_22  1
    x[22,6]   R776      -2.6697177726926005e-02
    x[22,6]   R777      -6.7365269461077862e-02
    x[22,6]   hard_lower  6
    x[22,6]   hard_upper  6
    x[22,7]   OBJ       5.9000000000000004e-02
    x[22,7]   onehot_22  1
    x[22,7]   R778      -2.6697177726926005e-02
    x[22,7]   R779      -6.7365269461077862e-02
    x[22,7]   hard_lower  7
    x[22,7]   hard_upper  7
    x[22,8]   OBJ       5.9000000000000004e-02
    x[22,8]   onehot_22  1
    x[22,8]   R780      -2.6697177726926005e-02
    x[22,8]   R781      -6.7365269461077862e-02
    x[22,8]   hard_lower  8
    x[22,8]   hard_upper  8
    x[22,9]   OBJ       0.059
    x[22,9]   onehot_22  1
    x[22,9]   R782      -2.6697177726926005e-02
    x[22,9]   R783      -6.7365269461077862e-02
    x[22,9]   hard_lower  9
    x[22,9]   hard_upper  9
    x[22,10]  OBJ       0.059
    x[22,10]  onehot_22  1
    x[22,10]  R784      -2.6697177726926005e-02
    x[22,10]  R785      -6.7365269461077862e-02
    x[22,10]  hard_lower  10
    x[22,10]  hard_upper  10
    x[22,11]  OBJ       5.9000000000000004e-02
    x[22,11]  onehot_22  1
    x[22,11]  R786      -2.6697177726926005e-02
    x[22,11]  R787      -6.7365269461077862e-02
    x[22,11]  hard_lower  11
    x[22,11]  hard_upper  11
    x[22,12]  OBJ       5.9000000000000004e-02
    x[22,12]  onehot_22  1
    x[22,12]  R788      -2.6697177726926005e-02
    x[22,12]  R789      -6.7365269461077862e-02
    x[22,12]  hard_lower  12
    x[22,12]  hard_upper  12
    x[23,0]   OBJ       0.0575
    x[23,0]   onehot_23  1
    x[23,0]   R794      -2.6697177726926005e-02
    x[23,0]   R795      -6.7365269461077862e-02
    x[23,1]   OBJ       5.7499999999999996e-02
    x[23,1]   onehot_23  1
    x[23,1]   R796      -2.6697177726926005e-02
    x[23,1]   R797      -6.7365269461077862e-02
    x[23,1]   hard_lower  1
    x[23,1]   hard_upper  1
    x[23,2]   OBJ       5.7499999999999996e-02
    x[23,2]   onehot_23  1
    x[23,2]   R798      -2.6697177726926005e-02
    x[23,2]   R799      -6.7365269461077862e-02
    x[23,2]   hard_lower  2
    x[23,2]   hard_upper  2
    x[23,3]   OBJ       0.0117754510636947
    x[23,3]   onehot_23  1
    x[23,3]   R800      -2.6697177726926005e-02
    x[23,3]   R801      -6.7365269461077862e-02
    x[23,3]   hard_lower  3
    x[23,3]   hard_upper  3
    x[23,4]   OBJ       7.4999999999999980e-03
    x[23,4]   onehot_23  1
    x[23,4]   R802      -2.6697177726926005e-02
    x[23,4]   R803      -6.7365269461077862e-02
    x[23,4]   hard_lower  4
    x[23,4]   hard_upper  4
    x[23,5]   OBJ       2.4115137059096039e-03
    x[23,5]   onehot_23  1
    x[23,5]   R804      -2.6697177726926005e-02
    x[23,5]   R805      -6.7365269461077862e-02
    x[23,5]   hard_lower  5
    x[23,5]   hard_upper  5
    x[23,6]   OBJ       0.0575
    x[23,6]   onehot_23  1
    x[23,6]   R806      -2.6697177726926005e-02
    x[23,6]   R807      -6.7365269461077862e-02
    x[23,6]   hard_lower  6
    x[23,6]   hard_upper  6
    x[23,7]   OBJ       0.0575
    x[23,7]   onehot_23  1
    x[23,7]   R808      -2.6697177726926005e-02
    x[23,7]   R809      -6.7365269461077862e-02
    x[23,7]   hard_lower  7
    x[23,7]   hard_upper  7
    x[23,8]   OBJ       5.7499999999999996e-02
    x[23,8]   onehot_23  1
    x[23,8]   R810      -2.6697177726926005e-02
    x[23,8]   R811      -6.7365269461077862e-02
    x[23,8]   hard_lower  8
    x[23,8]   hard_upper  8
    x[23,9]   OBJ       5.7499999999999996e-02
    x[23,9]   onehot_23  1
    x[23,9]   R812      -2.6697177726926005e-02
    x[23,9]   R813      -6.7365269461077862e-02
    x[23,9]   hard_lower  9
    x[23,9]   hard_upper  9
    x[23,10]  OBJ       5.7499999999999996e-02
    x[23,10]  onehot_23  1
    x[23,10]  R814      -2.6697177726926005e-02
    x[23,10]  R815      -6.7365269461077862e-02
    x[23,10]  hard_lower  10
    x[23,10]  hard_upper  10
    x[23,11]  OBJ       5.7499999999999996e-02
    x[23,11]  onehot_23  1
    x[23,11]  R816      -2.6697177726926005e-02
    x[23,11]  R817      -6.7365269461077862e-02
    x[23,11]  hard_lower  11
    x[23,11]  hard_upper  11
    x[24,0]   OBJ       0.062
    x[24,0]   onehot_24  1
    x[24,0]   R822      -2.6697177726926005e-02
    x[24,0]   R823      -6.7365269461077862e-02
    x[24,1]   OBJ       0.062
    x[24,1]   onehot_24  1
    x[24,1]   R824      -2.6697177726926005e-02
    x[24,1]   R825      -6.7365269461077862e-02
    x[24,1]   hard_lower  1
    x[24,1]   hard_upper  1
    x[24,2]   OBJ       6.1999999999999993e-02
    x[24,2]   onehot_24  1
    x[24,2]   R826      -2.6697177726926005e-02
    x[24,2]   R827      -6.7365269461077862e-02
    x[24,2]   hard_lower  2
    x[24,2]   hard_upper  2
    x[24,3]   OBJ       6.2000000000000006e-02
    x[24,3]   onehot_24  1
    x[24,3]   R828      -2.6697177726926005e-02
    x[24,3]   R829      -6.7365269461077862e-02
    x[24,3]   hard_lower  3
    x[24,3]   hard_upper  3
    x[24,4]   OBJ       2.5575207984339283e-02
    x[24,4]   onehot_24  1
    x[24,4]   R830      -2.6697177726926005e-02
    x[24,4]   R831      -6.7365269461077862e-02
    x[24,4]   hard_lower  4
    x[24,4]   hard_upper  4
    x[24,5]   OBJ       0.062
    x[24,5]   onehot_24  1
    x[24,5]   R832      -2.6697177726926005e-02
    x[24,5]   R833      -6.7365269461077862e-02
    x[24,5]   hard_lower  5
    x[24,5]   hard_upper  5
    x[24,6]   OBJ       6.2000000000000006e-02
    x[24,6]   onehot_24  1
    x[24,6]   R834      -2.6697177726926005e-02
    x[24,6]   R835      -6.7365269461077862e-02
    x[24,6]   hard_lower  6
    x[24,6]   hard_upper  6
    x[24,7]   OBJ       0.012
    x[24,7]   onehot_24  1
    x[24,7]   R836      -2.6697177726926005e-02
    x[24,7]   R837      -6.7365269461077862e-02
    x[24,7]   hard_lower  7
    x[24,7]   hard_upper  7
    x[24,8]   OBJ       4.0450574030544660e-03
    x[24,8]   onehot_24  1
    x[24,8]   R838      -2.6697177726926005e-02
    x[24,8]   R839      -6.7365269461077862e-02
    x[24,8]   hard_lower  8
    x[24,8]   hard_upper  8
    x[24,9]   OBJ       0.062
    x[24,9]   onehot_24  1
    x[24,9]   R840      -2.6697177726926005e-02
    x[24,9]   R841      -6.7365269461077862e-02
    x[24,9]   hard_lower  9
    x[24,9]   hard_upper  9
    x[24,10]  OBJ       6.2000000000000006e-02
    x[24,10]  onehot_24  1
    x[24,10]  R842      -2.6697177726926005e-02
    x[24,10]  R843      -6.7365269461077862e-02
    x[24,10]  hard_lower  10
    x[24,10]  hard_upper  10
    x[24,11]  OBJ       0.062
    x[24,11]  onehot_24  1
    x[24,11]  R844      -2.6697177726926005e-02
    x[24,11]  R845      -6.7365269461077862e-02
    x[24,11]  hard_lower  11
    x[24,11]  hard_upper  11
    x[24,12]  OBJ       0.062
    x[24,12]  onehot_24  1
    x[24,12]  R846      -2.6697177726926005e-02
    x[24,12]  R847      -6.7365269461077862e-02
    x[24,12]  hard_lower  12
    x[24,12]  hard_upper  12
    x[24,13]  OBJ       6.2000000000000006e-02
    x[24,13]  onehot_24  1
    x[24,13]  R848      -2.6697177726926005e-02
    x[24,13]  R849      -6.7365269461077862e-02
    x[24,13]  hard_lower  13
    x[24,13]  hard_upper  13
    x[24,14]  OBJ       6.1999999999999993e-02
    x[24,14]  onehot_24  1
    x[24,14]  R850      -2.6697177726926005e-02
    x[24,14]  R851      -6.7365269461077862e-02
    x[24,14]  hard_lower  14
    x[24,14]  hard_upper  14
    x[24,15]  OBJ       0.062
    x[24,15]  onehot_24  1
    x[24,15]  R852      -2.6697177726926005e-02
    x[24,15]  R853      -6.7365269461077862e-02
    x[24,15]  hard_lower  15
    x[24,15]  hard_upper  15
    x[25,0]   OBJ       6.0500000000000005e-02
    x[25,0]   onehot_25  1
    x[25,0]   R858      -2.6697177726926005e-02
    x[25,0]   R859      -6.7365269461077862e-02
    x[25,1]   OBJ       0.0605
    x[25,1]   onehot_25  1
    x[25,1]   R860      -2.6697177726926005e-02
    x[25,1]   R861      -6.7365269461077862e-02
    x[25,1]   hard_lower  1
    x[25,1]   hard_upper  1
    x[25,2]   OBJ       6.0500000000000005e-02
    x[25,2]   onehot_25  1
    x[25,2]   R862      -2.6697177726926005e-02
    x[25,2]   R863      -6.7365269461077862e-02
    x[25,2]   hard_lower  2
    x[25,2]   hard_upper  2
    x[25,3]   OBJ       0.0605
    x[25,3]   onehot_25  1
    x[25,3]   R864      -2.6697177726926005e-02
    x[25,3]   R865      -6.7365269461077862e-02
    x[25,3]   hard_lower  3
    x[25,3]   hard_upper  3
    x[25,4]   OBJ       6.0500000000000005e-02
    x[25,4]   onehot_25  1
    x[25,4]   R866      -2.6697177726926005e-02
    x[25,4]   R867      -6.7365269461077862e-02
    x[25,4]   hard_lower  4
    x[25,4]   hard_upper  4
    x[25,5]   OBJ       6.0500000000000005e-02
    x[25,5]   onehot_25  1
    x[25,5]   R868      -2.6697177726926005e-02
    x[25,5]   R869      -6.7365269461077862e-02
    x[25,5]   hard_lower  5
    x[25,5]   hard_upper  5
    x[25,6]   OBJ       1.0500000000000002e-02
    x[25,6]   onehot_25  1
    x[25,6]   R870      -2.6697177726926005e-02
    x[25,6]   R871      -6.7365269461077862e-02
    x[25,6]   hard_lower  6
    x[25,6]   hard_upper  6
    x[25,7]   OBJ       4.4605046334358555e-03
    x[25,7]   onehot_25  1
    x[25,7]   R872      -2.6697177726926005e-02
    x[25,7]   R873      -6.7365269461077862e-02
    x[25,7]   hard_lower  7
    x[25,7]   hard_upper  7
    x[25,8]   OBJ       0.0605
    x[25,8]   onehot_25  1
    x[25,8]   R874      -2.6697177726926005e-02
    x[25,8]   R875      -6.7365269461077862e-02
    x[25,8]   hard_lower  8
    x[25,8]   hard_upper  8
    x[25,9]   OBJ       0.0605
    x[25,9]   onehot_25  1
    x[25,9]   R876      -2.6697177726926005e-02
    x[25,9]   R877      -6.7365269461077862e-02
    x[25,9]   hard_lower  9
    x[25,9]   hard_upper  9
    x[25,10]  OBJ       0.0605
    x[25,10]  onehot_25  1
    x[25,10]  R878      -2.6697177726926005e-02
    x[25,10]  R879      -6.7365269461077862e-02
    x[25,10]  hard_lower  10
    x[25,10]  hard_upper  10
    x[25,11]  OBJ       6.0500000000000005e-02
    x[25,11]  onehot_25  1
    x[25,11]  R880      -2.6697177726926005e-02
    x[25,11]  R881      -6.7365269461077862e-02
    x[25,11]  hard_lower  11
    x[25,11]  hard_upper  11
    x[25,12]  OBJ       0.0605
    x[25,12]  onehot_25  1
    x[25,12]  R882      -2.6697177726926005e-02
    x[25,12]  R883      -6.7365269461077862e-02
    x[25,12]  hard_lower  12
    x[25,12]  hard_upper  12
    x[25,13]  OBJ       6.0500000000000005e-02
    x[25,13]  onehot_25  1
    x[25,13]  R884      -2.6697177726926005e-02
    x[25,13]  R885      -6.7365269461077862e-02
    x[25,13]  hard_lower  13
    x[25,13]  hard_upper  13
    x[25,14]  OBJ       6.0500000000000005e-02
    x[25,14]  onehot_25  1
    x[25,14]  R886      -2.6697177726926005e-02
    x[25,14]  R887      -6.7365269461077862e-02
    x[25,14]  hard_lower  14
    x[25,14]  hard_upper  14
    x[25,15]  OBJ       0.0605
    x[25,15]  onehot_25  1
    x[25,15]  R888      -2.6697177726926005e-02
    x[25,15]  R889      -6.7365269461077862e-02
    x[25,15]  hard_lower  15
    x[25,15]  hard_upper  15
    x[26,0]   OBJ       0.056
    x[26,0]   onehot_26  1
    x[26,0]   R894      -2.6697177726926005e-02
    x[26,0]   R895      -6.7365269461077862e-02
    x[26,1]   OBJ       5.5999999999999994e-02
    x[26,1]   onehot_26  1
    x[26,1]   R896      -2.6697177726926005e-02
    x[26,1]   R897      -6.7365269461077862e-02
    x[26,1]   hard_lower  1
    x[26,1]   hard_upper  1
    x[26,2]   OBJ       0.056
    x[26,2]   onehot_26  1
    x[26,2]   R898      -2.6697177726926005e-02
    x[26,2]   R899      -6.7365269461077862e-02
    x[26,2]   hard_lower  2
    x[26,2]   hard_upper  2
    x[26,3]   OBJ       0.006
    x[26,3]   onehot_26  1
    x[26,3]   R900      -2.6697177726926005e-02
    x[26,3]   R901      -6.7365269461077862e-02
    x[26,3]   hard_lower  3
    x[26,3]   hard_upper  3
    x[26,4]   OBJ       2.0498062845515173e-03
    x[26,4]   onehot_26  1
    x[26,4]   R902      -2.6697177726926005e-02
    x[26,4]   R903      -6.7365269461077862e-02
    x[26,4]   hard_lower  4
    x[26,4]   hard_upper  4
    x[26,5]   OBJ       0.056
    x[26,5]   onehot_26  1
    x[26,5]   R904      -2.6697177726926005e-02
    x[26,5]   R905      -6.7365269461077862e-02
    x[26,5]   hard_lower  5
    x[26,5]   hard_upper  5
    x[26,6]   OBJ       0.056
    x[26,6]   onehot_26  1
    x[26,6]   R906      -2.6697177726926005e-02
    x[26,6]   R907      -6.7365269461077862e-02
    x[26,6]   hard_lower  6
    x[26,6]   hard_upper  6
    x[26,7]   OBJ       5.5999999999999994e-02
    x[26,7]   onehot_26  1
    x[26,7]   R908      -2.6697177726926005e-02
    x[26,7]   R909      -6.7365269461077862e-02
    x[26,7]   hard_lower  7
    x[26,7]   hard_upper  7
    x[26,8]   OBJ       0.056
    x[26,8]   onehot_26  1
    x[26,8]   R910      -2.6697177726926005e-02
    x[26,8]   R911      -6.7365269461077862e-02
    x[26,8]   hard_lower  8
    x[26,8]   hard_upper  8
    x[27,0]   OBJ       6.0500000000000005e-02
    x[27,0]   onehot_27  1
    x[27,0]   R916      -2.6697177726926005e-02
    x[27,0]   R917      -6.7365269461077862e-02
    x[27,1]   OBJ       0.0605
    x[27,1]   onehot_27  1
    x[27,1]   R918      -2.6697177726926005e-02
    x[27,1]   R919      -6.7365269461077862e-02
    x[27,1]   hard_lower  1
    x[27,1]   hard_upper  1
    x[27,2]   OBJ       6.0500000000000005e-02
    x[27,2]   onehot_27  1
    x[27,2]   R920      -2.6697177726926005e-02
    x[27,2]   R921      -6.7365269461077862e-02
    x[27,2]   hard_lower  2
    x[27,2]   hard_upper  2
    x[27,3]   OBJ       0.0605
    x[27,3]   onehot_27  1
    x[27,3]   R922      -2.6697177726926005e-02
    x[27,3]   R923      -6.7365269461077862e-02
    x[27,3]   hard_lower  3
    x[27,3]   hard_upper  3
    x[27,4]   OBJ       6.0500000000000005e-02
    x[27,4]   onehot_27  1
    x[27,4]   R924      -2.6697177726926005e-02
    x[27,4]   R925      -6.7365269461077862e-02
    x[27,4]   hard_lower  4
    x[27,4]   hard_upper  4
    x[27,5]   OBJ       6.0500000000000005e-02
    x[27,5]   onehot_27  1
    x[27,5]   R926      -2.6697177726926005e-02
    x[27,5]   R927      -6.7365269461077862e-02
    x[27,5]   hard_lower  5
    x[27,5]   hard_upper  5
    x[27,6]   OBJ       1.0500000000000002e-02
    x[27,6]   onehot_27  1
    x[27,6]   R928      -2.6697177726926005e-02
    x[27,6]   R929      -6.7365269461077862e-02
    x[27,6]   hard_lower  6
    x[27,6]   hard_upper  6
    x[27,7]   OBJ       4.4605046334358208e-03
    x[27,7]   onehot_27  1
    x[27,7]   R930      -2.6697177726926005e-02
    x[27,7]   R931      -6.7365269461077862e-02
    x[27,7]   hard_lower  7
    x[27,7]   hard_upper  7
    x[27,8]   OBJ       0.0605
    x[27,8]   onehot_27  1
    x[27,8]   R932      -2.6697177726926005e-02
    x[27,8]   R933      -6.7365269461077862e-02
    x[27,8]   hard_lower  8
    x[27,8]   hard_upper  8
    x[27,9]   OBJ       0.0605
    x[27,9]   onehot_27  1
    x[27,9]   R934      -2.6697177726926005e-02
    x[27,9]   R935      -6.7365269461077862e-02
    x[27,9]   hard_lower  9
    x[27,9]   hard_upper  9
    x[27,10]  OBJ       0.0605
    x[27,10]  onehot_27  1
    x[27,10]  R936      -2.6697177726926005e-02
    x[27,10]  R937      -6.7365269461077862e-02
    x[27,10]  hard_lower  10
    x[27,10]  hard_upper  10
    x[27,11]  OBJ       6.0500000000000005e-02
    x[27,11]  onehot_27  1
    x[27,11]  R938      -2.6697177726926005e-02
    x[27,11]  R939      -6.7365269461077862e-02
    x[27,11]  hard_lower  11
    x[27,11]  hard_upper  11
    x[27,12]  OBJ       0.0605
    x[27,12]  onehot_27  1
    x[27,12]  R940      -2.6697177726926005e-02
    x[27,12]  R941      -6.7365269461077862e-02
    x[27,12]  hard_lower  12
    x[27,12]  hard_upper  12
    x[27,13]  OBJ       6.0500000000000005e-02
    x[27,13]  onehot_27  1
    x[27,13]  R942      -2.6697177726926005e-02
    x[27,13]  R943      -6.7365269461077862e-02
    x[27,13]  hard_lower  13
    x[27,13]  hard_upper  13
    x[27,14]  OBJ       6.0500000000000005e-02
    x[27,14]  onehot_27  1
    x[27,14]  R944      -2.6697177726926005e-02
    x[27,14]  R945      -6.7365269461077862e-02
    x[27,14]  hard_lower  14
    x[27,14]  hard_upper  14
    x[27,15]  OBJ       0.0605
    x[27,15]  onehot_27  1
    x[27,15]  R946      -2.6697177726926005e-02
    x[27,15]  R947      -6.7365269461077862e-02
    x[27,15]  hard_lower  15
    x[27,15]  hard_upper  15
    x[28,0]   OBJ       0.074
    x[28,0]   onehot_28  1
    x[28,0]   R952      -2.6697177726926005e-02
    x[28,0]   R953      -6.7365269461077862e-02
    x[28,1]   OBJ       0.074
    x[28,1]   onehot_28  1
    x[28,1]   R954      -2.6697177726926005e-02
    x[28,1]   R955      -6.7365269461077862e-02
    x[28,1]   hard_lower  1
    x[28,1]   hard_upper  1
    x[28,2]   OBJ       0.074
    x[28,2]   onehot_28  1
    x[28,2]   R956      -2.6697177726926005e-02
    x[28,2]   R957      -6.7365269461077862e-02
    x[28,2]   hard_lower  2
    x[28,2]   hard_upper  2
    x[28,3]   OBJ       0.074
    x[28,3]   onehot_28  1
    x[28,3]   R958      -2.6697177726926005e-02
    x[28,3]   R959      -6.7365269461077862e-02
    x[28,3]   hard_lower  3
    x[28,3]   hard_upper  3
    x[28,4]   OBJ       0.074
    x[28,4]   onehot_28  1
    x[28,4]   R960      -2.6697177726926005e-02
    x[28,4]   R961      -6.7365269461077862e-02
    x[28,4]   hard_lower  4
    x[28,4]   hard_upper  4
    x[28,5]   OBJ       0.074
    x[28,5]   onehot_28  1
    x[28,5]   R962      -2.6697177726926005e-02
    x[28,5]   R963      -6.7365269461077862e-02
    x[28,5]   hard_lower  5
    x[28,5]   hard_upper  5
    x[28,6]   OBJ       0.024
    x[28,6]   onehot_28  1
    x[28,6]   R964      -2.6697177726926005e-02
    x[28,6]   R965      -6.7365269461077862e-02
    x[28,6]   hard_lower  6
    x[28,6]   hard_upper  6
    x[28,7]   OBJ       0.074
    x[28,7]   onehot_28  1
    x[28,7]   R966      -2.6697177726926005e-02
    x[28,7]   R967      -6.7365269461077862e-02
    x[28,7]   hard_lower  7
    x[28,7]   hard_upper  7
    x[28,8]   OBJ       1.0173776360153507e-02
    x[28,8]   onehot_28  1
    x[28,8]   R968      -2.6697177726926005e-02
    x[28,8]   R969      -6.7365269461077862e-02
    x[28,8]   hard_lower  8
    x[28,8]   hard_upper  8
    x[28,9]   OBJ       0.074
    x[28,9]   onehot_28  1
    x[28,9]   R970      -2.6697177726926005e-02
    x[28,9]   R971      -6.7365269461077862e-02
    x[28,9]   hard_lower  9
    x[28,9]   hard_upper  9
    x[28,10]  OBJ       0.074
    x[28,10]  onehot_28  1
    x[28,10]  R972      -2.6697177726926005e-02
    x[28,10]  R973      -6.7365269461077862e-02
    x[28,10]  hard_lower  10
    x[28,10]  hard_upper  10
    x[28,11]  OBJ       0.074
    x[28,11]  onehot_28  1
    x[28,11]  R974      -2.6697177726926005e-02
    x[28,11]  R975      -6.7365269461077862e-02
    x[28,11]  hard_lower  11
    x[28,11]  hard_upper  11
    x[28,12]  OBJ       0.074
    x[28,12]  onehot_28  1
    x[28,12]  R976      -2.6697177726926005e-02
    x[28,12]  R977      -6.7365269461077862e-02
    x[28,12]  hard_lower  12
    x[28,12]  hard_upper  12
    x[28,13]  OBJ       0.074
    x[28,13]  onehot_28  1
    x[28,13]  R978      -2.6697177726926005e-02
    x[28,13]  R979      -6.7365269461077862e-02
    x[28,13]  hard_lower  13
    x[28,13]  hard_upper  13
    x[28,14]  OBJ       0.074
    x[28,14]  onehot_28  1
    x[28,14]  R980      -2.6697177726926005e-02
    x[28,14]  R981      -6.7365269461077862e-02
    x[28,14]  hard_lower  14
    x[28,14]  hard_upper  14
    x[28,15]  OBJ       0.074
    x[28,15]  onehot_28  1
    x[28,15]  R982      -2.6697177726926005e-02
    x[28,15]  R983      -6.7365269461077862e-02
    x[28,15]  hard_lower  15
    x[28,15]  hard_upper  15
    x[28,16]  OBJ       0.074
    x[28,16]  onehot_28  1
    x[28,16]  R984      -2.6697177726926005e-02
    x[28,16]  R985      -6.7365269461077862e-02
    x[28,16]  hard_lower  16
    x[28,16]  hard_upper  16
    x[28,17]  OBJ       0.074
    x[28,17]  onehot_28  1
    x[28,17]  R986      -2.6697177726926005e-02
    x[28,17]  R987      -6.7365269461077862e-02
    x[28,17]  hard_lower  17
    x[28,17]  hard_upper  17
    x[28,18]  OBJ       7.4000000000000010e-02
    x[28,18]  onehot_28  1
    x[28,18]  R988      -2.6697177726926005e-02
    x[28,18]  R989      -6.7365269461077862e-02
    x[28,18]  hard_lower  18
    x[28,18]  hard_upper  18
    x[28,19]  OBJ       0.074
    x[28,19]  onehot_28  1
    x[28,19]  R990      -2.6697177726926005e-02
    x[28,19]  R991      -6.7365269461077862e-02
    x[28,19]  hard_lower  19
    x[28,19]  hard_upper  19
    x[29,0]   OBJ       0.074
    x[29,0]   onehot_29  1
    x[29,0]   R996      -2.6697177726926005e-02
    x[29,0]   R997      -6.7365269461077862e-02
    x[29,1]   OBJ       0.074
    x[29,1]   onehot_29  1
    x[29,1]   R998      -2.6697177726926005e-02
    x[29,1]   R999      -6.7365269461077862e-02
    x[29,1]   hard_lower  1
    x[29,1]   hard_upper  1
    x[29,2]   OBJ       0.074
    x[29,2]   onehot_29  1
    x[29,2]   R1000     -2.6697177726926005e-02
    x[29,2]   R1001     -6.7365269461077862e-02
    x[29,2]   hard_lower  2
    x[29,2]   hard_upper  2
    x[29,3]   OBJ       0.074
    x[29,3]   onehot_29  1
    x[29,3]   R1002     -2.6697177726926005e-02
    x[29,3]   R1003     -6.7365269461077862e-02
    x[29,3]   hard_lower  3
    x[29,3]   hard_upper  3
    x[29,4]   OBJ       0.074
    x[29,4]   onehot_29  1
    x[29,4]   R1004     -2.6697177726926005e-02
    x[29,4]   R1005     -6.7365269461077862e-02
    x[29,4]   hard_lower  4
    x[29,4]   hard_upper  4
    x[29,5]   OBJ       0.074
    x[29,5]   onehot_29  1
    x[29,5]   R1006     -2.6697177726926005e-02
    x[29,5]   R1007     -6.7365269461077862e-02
    x[29,5]   hard_lower  5
    x[29,5]   hard_upper  5
    x[29,6]   OBJ       0.024
    x[29,6]   onehot_29  1
    x[29,6]   R1008     -2.6697177726926005e-02
    x[29,6]   R1009     -6.7365269461077862e-02
    x[29,6]   hard_lower  6
    x[29,6]   hard_upper  6
    x[29,7]   OBJ       0.074
    x[29,7]   onehot_29  1
    x[29,7]   R1010     -2.6697177726926005e-02
    x[29,7]   R1011     -6.7365269461077862e-02
    x[29,7]   hard_lower  7
    x[29,7]   hard_upper  7
    x[29,8]   OBJ       1.0383673536886052e-02
    x[29,8]   onehot_29  1
    x[29,8]   R1012     -2.6697177726926005e-02
    x[29,8]   R1013     -6.7365269461077862e-02
    x[29,8]   hard_lower  8
    x[29,8]   hard_upper  8
    x[29,9]   OBJ       0.074
    x[29,9]   onehot_29  1
    x[29,9]   R1014     -2.6697177726926005e-02
    x[29,9]   R1015     -6.7365269461077862e-02
    x[29,9]   hard_lower  9
    x[29,9]   hard_upper  9
    x[29,10]  OBJ       0.074
    x[29,10]  onehot_29  1
    x[29,10]  R1016     -2.6697177726926005e-02
    x[29,10]  R1017     -6.7365269461077862e-02
    x[29,10]  hard_lower  10
    x[29,10]  hard_upper  10
    x[29,11]  OBJ       0.074
    x[29,11]  onehot_29  1
    x[29,11]  R1018     -2.6697177726926005e-02
    x[29,11]  R1019     -6.7365269461077862e-02
    x[29,11]  hard_lower  11
    x[29,11]  hard_upper  11
    x[29,12]  OBJ       0.074
    x[29,12]  onehot_29  1
    x[29,12]  R1020     -2.6697177726926005e-02
    x[29,12]  R1021     -6.7365269461077862e-02
    x[29,12]  hard_lower  12
    x[29,12]  hard_upper  12
    x[29,13]  OBJ       0.074
    x[29,13]  onehot_29  1
    x[29,13]  R1022     -2.6697177726926005e-02
    x[29,13]  R1023     -6.7365269461077862e-02
    x[29,13]  hard_lower  13
    x[29,13]  hard_upper  13
    x[29,14]  OBJ       0.074
    x[29,14]  onehot_29  1
    x[29,14]  R1024     -2.6697177726926005e-02
    x[29,14]  R1025     -6.7365269461077862e-02
    x[29,14]  hard_lower  14
    x[29,14]  hard_upper  14
    x[29,15]  OBJ       0.074
    x[29,15]  onehot_29  1
    x[29,15]  R1026     -2.6697177726926005e-02
    x[29,15]  R1027     -6.7365269461077862e-02
    x[29,15]  hard_lower  15
    x[29,15]  hard_upper  15
    x[30,0]   OBJ       0.056
    x[30,0]   onehot_30  1
    x[30,0]   R1032     -2.6697177726926005e-02
    x[30,0]   R1033     -6.7365269461077862e-02
    x[30,1]   OBJ       5.5999999999999994e-02
    x[30,1]   onehot_30  1
    x[30,1]   R1034     -2.6697177726926005e-02
    x[30,1]   R1035     -6.7365269461077862e-02
    x[30,1]   hard_lower  1
    x[30,1]   hard_upper  1
    x[30,2]   OBJ       0.056
    x[30,2]   onehot_30  1
    x[30,2]   R1036     -2.6697177726926005e-02
    x[30,2]   R1037     -6.7365269461077862e-02
    x[30,2]   hard_lower  2
    x[30,2]   hard_upper  2
    x[30,3]   OBJ       0.006
    x[30,3]   onehot_30  1
    x[30,3]   R1038     -2.6697177726926005e-02
    x[30,3]   R1039     -6.7365269461077862e-02
    x[30,3]   hard_lower  3
    x[30,3]   hard_upper  3
    x[30,4]   OBJ       9.3470106927215531e-04
    x[30,4]   onehot_30  1
    x[30,4]   R1040     -2.6697177726926005e-02
    x[30,4]   R1041     -6.7365269461077862e-02
    x[30,4]   hard_lower  4
    x[30,4]   hard_upper  4
    x[30,5]   OBJ       0.056
    x[30,5]   onehot_30  1
    x[30,5]   R1042     -2.6697177726926005e-02
    x[30,5]   R1043     -6.7365269461077862e-02
    x[30,5]   hard_lower  5
    x[30,5]   hard_upper  5
    x[30,6]   OBJ       0.056
    x[30,6]   onehot_30  1
    x[30,6]   R1044     -2.6697177726926005e-02
    x[30,6]   R1045     -6.7365269461077862e-02
    x[30,6]   hard_lower  6
    x[30,6]   hard_upper  6
    x[30,7]   OBJ       5.5999999999999994e-02
    x[30,7]   onehot_30  1
    x[30,7]   R1046     -2.6697177726926005e-02
    x[30,7]   R1047     -6.7365269461077862e-02
    x[30,7]   hard_lower  7
    x[30,7]   hard_upper  7
    x[30,8]   OBJ       0.056
    x[30,8]   onehot_30  1
    x[30,8]   R1048     -2.6697177726926005e-02
    x[30,8]   R1049     -6.7365269461077862e-02
    x[30,8]   hard_lower  8
    x[30,8]   hard_upper  8
    x[31,0]   OBJ       0.05
    x[31,0]   onehot_31  1
    x[31,0]   R1054     -2.6697177726926005e-02
    x[31,0]   R1055     -6.7365269461077862e-02
    x[31,1]   OBJ       0.05
    x[31,1]   onehot_31  1
    x[31,1]   R1056     -2.6697177726926005e-02
    x[31,1]   R1057     -6.7365269461077862e-02
    x[31,1]   hard_lower  1
    x[31,1]   hard_upper  1
    x[31,2]   OBJ       2.0128002426731732e-02
    x[31,2]   onehot_31  1
    x[31,2]   R1058     -2.6697177726926005e-02
    x[31,2]   R1059     -6.7365269461077862e-02
    x[31,2]   hard_lower  2
    x[31,2]   hard_upper  2
    x[31,3]   OBJ       0.05
    x[31,3]   onehot_31  1
    x[31,3]   R1060     -2.6697177726926005e-02
    x[31,3]   R1061     -6.7365269461077862e-02
    x[31,3]   hard_lower  3
    x[31,3]   hard_upper  3
    x[31,4]   OBJ       0.05
    x[31,4]   onehot_31  1
    x[31,4]   R1062     -2.6697177726926005e-02
    x[31,4]   R1063     -6.7365269461077862e-02
    x[31,4]   hard_lower  4
    x[31,4]   hard_upper  4
    x[31,5]   OBJ       0.05
    x[31,5]   onehot_31  1
    x[31,5]   R1064     -2.6697177726926005e-02
    x[31,5]   R1065     -6.7365269461077862e-02
    x[31,5]   hard_lower  5
    x[31,5]   hard_upper  5
    x[31,6]   OBJ       5.0000000000000010e-02
    x[31,6]   onehot_31  1
    x[31,6]   R1066     -2.6697177726926005e-02
    x[31,6]   R1067     -6.7365269461077862e-02
    x[31,6]   hard_lower  6
    x[31,6]   hard_upper  6
    x[31,7]   OBJ       4.08006961549745e-18
    x[31,7]   onehot_31  1
    x[31,7]   R1068     -2.6697177726926005e-02
    x[31,7]   R1069     -6.7365269461077862e-02
    x[31,7]   hard_lower  7
    x[31,7]   hard_upper  7
    x[31,8]   OBJ       0.05
    x[31,8]   onehot_31  1
    x[31,8]   R1070     -2.6697177726926005e-02
    x[31,8]   R1071     -6.7365269461077862e-02
    x[31,8]   hard_lower  8
    x[31,8]   hard_upper  8
    x[31,9]   OBJ       0.05
    x[31,9]   onehot_31  1
    x[31,9]   R1072     -2.6697177726926005e-02
    x[31,9]   R1073     -6.7365269461077862e-02
    x[31,9]   hard_lower  9
    x[31,9]   hard_upper  9
    x[31,10]  OBJ       0.05
    x[31,10]  onehot_31  1
    x[31,10]  R1074     -2.6697177726926005e-02
    x[31,10]  R1075     -6.7365269461077862e-02
    x[31,10]  hard_lower  10
    x[31,10]  hard_upper  10
    x[31,11]  OBJ       0.05
    x[31,11]  onehot_31  1
    x[31,11]  R1076     -2.6697177726926005e-02
    x[31,11]  R1077     -6.7365269461077862e-02
    x[31,11]  hard_lower  11
    x[31,11]  hard_upper  11
    x[31,12]  OBJ       0.05
    x[31,12]  onehot_31  1
    x[31,12]  R1078     -2.6697177726926005e-02
    x[31,12]  R1079     -6.7365269461077862e-02
    x[31,12]  hard_lower  12
    x[31,12]  hard_upper  12
    x[32,0]   OBJ       0.05
    x[32,0]   onehot_32  1
    x[32,0]   R1084     -2.6697177726926005e-02
    x[32,0]   R1085     -6.7365269461077862e-02
    x[32,1]   OBJ       0.05
    x[32,1]   onehot_32  1
    x[32,1]   R1086     -2.6697177726926005e-02
    x[32,1]   R1087     -6.7365269461077862e-02
    x[32,1]   hard_lower  1
    x[32,1]   hard_upper  1
    x[32,2]   OBJ       0.05
    x[32,2]   onehot_32  1
    x[32,2]   R1088     -2.6697177726926005e-02
    x[32,2]   R1089     -6.7365269461077862e-02
    x[32,2]   hard_lower  2
    x[32,2]   hard_upper  2
    x[32,3]   OBJ       9.2539341295527575e-03
    x[32,3]   onehot_32  1
    x[32,3]   R1090     -2.6697177726926005e-02
    x[32,3]   R1091     -6.7365269461077862e-02
    x[32,3]   hard_lower  3
    x[32,3]   hard_upper  3
    x[32,4]   OBJ       4.9999999999999996e-02
    x[32,4]   onehot_32  1
    x[32,4]   R1092     -2.6697177726926005e-02
    x[32,4]   R1093     -6.7365269461077862e-02
    x[32,4]   hard_lower  4
    x[32,4]   hard_upper  4
    x[32,5]   OBJ       2.0816681711721684e-18
    x[32,5]   onehot_32  1
    x[32,5]   R1094     -2.6697177726926005e-02
    x[32,5]   R1095     -6.7365269461077862e-02
    x[32,5]   hard_lower  5
    x[32,5]   hard_upper  5
    x[32,6]   OBJ       0.05
    x[32,6]   onehot_32  1
    x[32,6]   R1096     -2.6697177726926005e-02
    x[32,6]   R1097     -6.7365269461077862e-02
    x[32,6]   hard_lower  6
    x[32,6]   hard_upper  6
    x[32,7]   OBJ       0.05
    x[32,7]   onehot_32  1
    x[32,7]   R1098     -2.6697177726926005e-02
    x[32,7]   R1099     -6.7365269461077862e-02
    x[32,7]   hard_lower  7
    x[32,7]   hard_upper  7
    x[32,8]   OBJ       0.05
    x[32,8]   onehot_32  1
    x[32,8]   R1100     -2.6697177726926005e-02
    x[32,8]   R1101     -6.7365269461077862e-02
    x[32,8]   hard_lower  8
    x[32,8]   hard_upper  8
    x[32,9]   OBJ       0.05
    x[32,9]   onehot_32  1
    x[32,9]   R1102     -2.6697177726926005e-02
    x[32,9]   R1103     -6.7365269461077862e-02
    x[32,9]   hard_lower  9
    x[32,9]   hard_upper  9
    x[32,10]  OBJ       4.9999999999999996e-02
    x[32,10]  onehot_32  1
    x[32,10]  R1104     -2.6697177726926005e-02
    x[32,10]  R1105     -6.7365269461077862e-02
    x[32,10]  hard_lower  10
    x[32,10]  hard_upper  10
    x[32,11]  OBJ       4.9999999999999996e-02
    x[32,11]  onehot_32  1
    x[32,11]  R1106     -2.6697177726926005e-02
    x[32,11]  R1107     -6.7365269461077862e-02
    x[32,11]  hard_lower  11
    x[32,11]  hard_upper  11
    x[32,12]  OBJ       0.05
    x[32,12]  onehot_32  1
    x[32,12]  R1108     -2.6697177726926005e-02
    x[32,12]  R1109     -6.7365269461077862e-02
    x[32,12]  hard_lower  12
    x[32,12]  hard_upper  12
    x[33,0]   OBJ       6.0500000000000005e-02
    x[33,0]   onehot_33  1
    x[33,0]   R1114     -2.6697177726926005e-02
    x[33,0]   R1115     -6.7365269461077862e-02
    x[33,1]   OBJ       0.0605
    x[33,1]   onehot_33  1
    x[33,1]   R1116     -2.6697177726926005e-02
    x[33,1]   R1117     -6.7365269461077862e-02
    x[33,1]   hard_lower  1
    x[33,1]   hard_upper  1
    x[33,2]   OBJ       6.0500000000000005e-02
    x[33,2]   onehot_33  1
    x[33,2]   R1118     -2.6697177726926005e-02
    x[33,2]   R1119     -6.7365269461077862e-02
    x[33,2]   hard_lower  2
    x[33,2]   hard_upper  2
    x[33,3]   OBJ       0.0605
    x[33,3]   onehot_33  1
    x[33,3]   R1120     -2.6697177726926005e-02
    x[33,3]   R1121     -6.7365269461077862e-02
    x[33,3]   hard_lower  3
    x[33,3]   hard_upper  3
    x[33,4]   OBJ       6.0500000000000005e-02
    x[33,4]   onehot_33  1
    x[33,4]   R1122     -2.6697177726926005e-02
    x[33,4]   R1123     -6.7365269461077862e-02
    x[33,4]   hard_lower  4
    x[33,4]   hard_upper  4
    x[33,5]   OBJ       6.0500000000000005e-02
    x[33,5]   onehot_33  1
    x[33,5]   R1124     -2.6697177726926005e-02
    x[33,5]   R1125     -6.7365269461077862e-02
    x[33,5]   hard_lower  5
    x[33,5]   hard_upper  5
    x[33,6]   OBJ       1.0500000000000002e-02
    x[33,6]   onehot_33  1
    x[33,6]   R1126     -2.6697177726926005e-02
    x[33,6]   R1127     -6.7365269461077862e-02
    x[33,6]   hard_lower  6
    x[33,6]   hard_upper  6
    x[33,7]   OBJ       2.6776488921749016e-03
    x[33,7]   onehot_33  1
    x[33,7]   R1128     -2.6697177726926005e-02
    x[33,7]   R1129     -6.7365269461077862e-02
    x[33,7]   hard_lower  7
    x[33,7]   hard_upper  7
    x[33,8]   OBJ       0.0605
    x[33,8]   onehot_33  1
    x[33,8]   R1130     -2.6697177726926005e-02
    x[33,8]   R1131     -6.7365269461077862e-02
    x[33,8]   hard_lower  8
    x[33,8]   hard_upper  8
    x[33,9]   OBJ       0.0605
    x[33,9]   onehot_33  1
    x[33,9]   R1132     -2.6697177726926005e-02
    x[33,9]   R1133     -6.7365269461077862e-02
    x[33,9]   hard_lower  9
    x[33,9]   hard_upper  9
    x[33,10]  OBJ       0.0605
    x[33,10]  onehot_33  1
    x[33,10]  R1134     -2.6697177726926005e-02
    x[33,10]  R1135     -6.7365269461077862e-02
    x[33,10]  hard_lower  10
    x[33,10]  hard_upper  10
    x[33,11]  OBJ       6.0500000000000005e-02
    x[33,11]  onehot_33  1
    x[33,11]  R1136     -2.6697177726926005e-02
    x[33,11]  R1137     -6.7365269461077862e-02
    x[33,11]  hard_lower  11
    x[33,11]  hard_upper  11
    x[33,12]  OBJ       0.0605
    x[33,12]  onehot_33  1
    x[33,12]  R1138     -2.6697177726926005e-02
    x[33,12]  R1139     -6.7365269461077862e-02
    x[33,12]  hard_lower  12
    x[33,12]  hard_upper  12
    x[33,13]  OBJ       6.0500000000000005e-02
    x[33,13]  onehot_33  1
    x[33,13]  R1140     -2.6697177726926005e-02
    x[33,13]  R1141     -6.7365269461077862e-02
    x[33,13]  hard_lower  13
    x[33,13]  hard_upper  13
    x[33,14]  OBJ       6.0500000000000005e-02
    x[33,14]  onehot_33  1
    x[33,14]  R1142     -2.6697177726926005e-02
    x[33,14]  R1143     -6.7365269461077862e-02
    x[33,14]  hard_lower  14
    x[33,14]  hard_upper  14
    x[33,15]  OBJ       0.0605
    x[33,15]  onehot_33  1
    x[33,15]  R1144     -2.6697177726926005e-02
    x[33,15]  R1145     -6.7365269461077862e-02
    x[33,15]  hard_lower  15
    x[33,15]  hard_upper  15
    x[33,16]  OBJ       0.0605
    x[33,16]  onehot_33  1
    x[33,16]  R1146     -2.6697177726926005e-02
    x[33,16]  R1147     -6.7365269461077862e-02
    x[33,16]  hard_lower  16
    x[33,16]  hard_upper  16
    x[34,0]   OBJ       0.05
    x[34,0]   onehot_34  1
    x[34,0]   R1152     -2.6697177726926005e-02
    x[34,0]   R1153     -6.7365269461077862e-02
    x[34,1]   OBJ       8.0880415960927227e-03
    x[34,1]   onehot_34  1
    x[34,1]   R1154     -2.6697177726926005e-02
    x[34,1]   R1155     -6.7365269461077862e-02
    x[34,1]   hard_lower  1
    x[34,1]   hard_upper  1
    x[34,2]   OBJ       0.05
    x[34,2]   onehot_34  1
    x[34,2]   R1156     -2.6697177726926005e-02
    x[34,2]   R1157     -6.7365269461077862e-02
    x[34,2]   hard_lower  2
    x[34,2]   hard_upper  2
    x[34,3]   OBJ       4.9999999999999996e-02
    x[34,3]   onehot_34  1
    x[34,3]   R1158     -2.6697177726926005e-02
    x[34,3]   R1159     -6.7365269461077862e-02
    x[34,3]   hard_lower  3
    x[34,3]   hard_upper  3
    x[34,4]   OBJ       4.9999999999999996e-02
    x[34,4]   onehot_34  1
    x[34,4]   R1160     -2.6697177726926005e-02
    x[34,4]   R1161     -6.7365269461077862e-02
    x[34,4]   hard_lower  4
    x[34,4]   hard_upper  4
    x[34,5]   OBJ       2.0816681711721684e-18
    x[34,5]   onehot_34  1
    x[34,5]   R1162     -2.6697177726926005e-02
    x[34,5]   R1163     -6.7365269461077862e-02
    x[34,5]   hard_lower  5
    x[34,5]   hard_upper  5
    x[34,6]   OBJ       0.05
    x[34,6]   onehot_34  1
    x[34,6]   R1164     -2.6697177726926005e-02
    x[34,6]   R1165     -6.7365269461077862e-02
    x[34,6]   hard_lower  6
    x[34,6]   hard_upper  6
    x[34,7]   OBJ       0.05
    x[34,7]   onehot_34  1
    x[34,7]   R1166     -2.6697177726926005e-02
    x[34,7]   R1167     -6.7365269461077862e-02
    x[34,7]   hard_lower  7
    x[34,7]   hard_upper  7
    x[34,8]   OBJ       0.05
    x[34,8]   onehot_34  1
    x[34,8]   R1168     -2.6697177726926005e-02
    x[34,8]   R1169     -6.7365269461077862e-02
    x[34,8]   hard_lower  8
    x[34,8]   hard_upper  8
    x[34,9]   OBJ       0.05
    x[34,9]   onehot_34  1
    x[34,9]   R1170     -2.6697177726926005e-02
    x[34,9]   R1171     -6.7365269461077862e-02
    x[34,9]   hard_lower  9
    x[34,9]   hard_upper  9
    x[34,10]  OBJ       4.9999999999999996e-02
    x[34,10]  onehot_34  1
    x[34,10]  R1172     -2.6697177726926005e-02
    x[34,10]  R1173     -6.7365269461077862e-02
    x[34,10]  hard_lower  10
    x[34,10]  hard_upper  10
    x[34,11]  OBJ       4.9999999999999996e-02
    x[34,11]  onehot_34  1
    x[34,11]  R1174     -2.6697177726926005e-02
    x[34,11]  R1175     -6.7365269461077862e-02
    x[34,11]  hard_lower  11
    x[34,11]  hard_upper  11
    x[35,0]   OBJ       0.05
    x[35,0]   onehot_35  1
    x[35,0]   R1180     -2.6697177726926005e-02
    x[35,0]   R1181     -6.7365269461077862e-02
    x[35,1]   OBJ       4.9999999999999996e-02
    x[35,1]   onehot_35  1
    x[35,1]   R1182     -2.6697177726926005e-02
    x[35,1]   R1183     -6.7365269461077862e-02
    x[35,1]   hard_lower  1
    x[35,1]   hard_upper  1
    x[35,2]   OBJ       4.9999999999999996e-02
    x[35,2]   onehot_35  1
    x[35,2]   R1184     -2.6697177726926005e-02
    x[35,2]   R1185     -6.7365269461077862e-02
    x[35,2]   hard_lower  2
    x[35,2]   hard_upper  2
    x[35,3]   OBJ       0.05
    x[35,3]   onehot_35  1
    x[35,3]   R1186     -2.6697177726926005e-02
    x[35,3]   R1187     -6.7365269461077862e-02
    x[35,3]   hard_lower  3
    x[35,3]   hard_upper  3
    x[35,4]   OBJ       1.9021348693940496e-02
    x[35,4]   onehot_35  1
    x[35,4]   R1188     -2.6697177726926005e-02
    x[35,4]   R1189     -6.7365269461077862e-02
    x[35,4]   hard_lower  4
    x[35,4]   hard_upper  4
    x[35,5]   OBJ       4.9999999999999996e-02
    x[35,5]   onehot_35  1
    x[35,5]   R1190     -2.6697177726926005e-02
    x[35,5]   R1191     -6.7365269461077862e-02
    x[35,5]   hard_lower  5
    x[35,5]   hard_upper  5
    x[35,6]   OBJ       0.05
    x[35,6]   onehot_35  1
    x[35,6]   R1192     -2.6697177726926005e-02
    x[35,6]   R1193     -6.7365269461077862e-02
    x[35,6]   hard_lower  6
    x[35,6]   hard_upper  6
    x[35,7]   OBJ       0.05
    x[35,7]   onehot_35  1
    x[35,7]   R1194     -2.6697177726926005e-02
    x[35,7]   R1195     -6.7365269461077862e-02
    x[35,7]   hard_lower  7
    x[35,7]   hard_upper  7
    x[35,8]   onehot_35  1
    x[35,8]   R1196     -2.6697177726926005e-02
    x[35,8]   R1197     -6.7365269461077862e-02
    x[35,8]   hard_lower  8
    x[35,8]   hard_upper  8
    x[35,9]   OBJ       0.05
    x[35,9]   onehot_35  1
    x[35,9]   R1198     -2.6697177726926005e-02
    x[35,9]   R1199     -6.7365269461077862e-02
    x[35,9]   hard_lower  9
    x[35,9]   hard_upper  9
    x[35,10]  OBJ       0.05
    x[35,10]  onehot_35  1
    x[35,10]  R1200     -2.6697177726926005e-02
    x[35,10]  R1201     -6.7365269461077862e-02
    x[35,10]  hard_lower  10
    x[35,10]  hard_upper  10
    x[35,11]  OBJ       4.9999999999999996e-02
    x[35,11]  onehot_35  1
    x[35,11]  R1202     -2.6697177726926005e-02
    x[35,11]  R1203     -6.7365269461077862e-02
    x[35,11]  hard_lower  11
    x[35,11]  hard_upper  11
    x[35,12]  OBJ       0.05
    x[35,12]  onehot_35  1
    x[35,12]  R1204     -2.6697177726926005e-02
    x[35,12]  R1205     -6.7365269461077862e-02
    x[35,12]  hard_lower  12
    x[35,12]  hard_upper  12
    x[35,13]  OBJ       0.05
    x[35,13]  onehot_35  1
    x[35,13]  R1206     -2.6697177726926005e-02
    x[35,13]  R1207     -6.7365269461077862e-02
    x[35,13]  hard_lower  13
    x[35,13]  hard_upper  13
    x[35,14]  OBJ       4.9999999999999996e-02
    x[35,14]  onehot_35  1
    x[35,14]  R1208     -2.6697177726926005e-02
    x[35,14]  R1209     -6.7365269461077862e-02
    x[35,14]  hard_lower  14
    x[35,14]  hard_upper  14
    x[35,15]  OBJ       4.9999999999999996e-02
    x[35,15]  onehot_35  1
    x[35,15]  R1210     -2.6697177726926005e-02
    x[35,15]  R1211     -6.7365269461077862e-02
    x[35,15]  hard_lower  15
    x[35,15]  hard_upper  15
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    R2        1
    w[1,0]    R3        1
    w[1,1]    mass_1    1
    w[1,1]    R4        1
    w[1,1]    R5        1
    w[1,1]    normalized_inventory_1  -1
    w[1,2]    mass_1    1
    w[1,2]    R6        1
    w[1,2]    R7        1
    w[1,2]    normalized_inventory_1  -2
    w[1,3]    mass_1    1
    w[1,3]    R8        1
    w[1,3]    R9        1
    w[1,3]    normalized_inventory_1  -3
    w[1,4]    mass_1    1
    w[1,4]    R10       1
    w[1,4]    R11       1
    w[1,4]    normalized_inventory_1  -4
    w[1,5]    mass_1    1
    w[1,5]    R12       1
    w[1,5]    R13       1
    w[1,5]    normalized_inventory_1  -5
    w[1,6]    mass_1    1
    w[1,6]    R14       1
    w[1,6]    R15       1
    w[1,6]    normalized_inventory_1  -6
    w[1,7]    mass_1    1
    w[1,7]    R16       1
    w[1,7]    R17       1
    w[1,7]    normalized_inventory_1  -7
    w[1,8]    mass_1    1
    w[1,8]    R18       1
    w[1,8]    R19       1
    w[1,8]    normalized_inventory_1  -8
    w[1,9]    mass_1    1
    w[1,9]    R20       1
    w[1,9]    R21       1
    w[1,9]    normalized_inventory_1  -9
    w[1,10]   mass_1    1
    w[1,10]   R22       1
    w[1,10]   R23       1
    w[1,10]   normalized_inventory_1  -10
    w[1,11]   mass_1    1
    w[1,11]   R24       1
    w[1,11]   R25       1
    w[1,11]   normalized_inventory_1  -11
    w[1,12]   mass_1    1
    w[1,12]   R26       1
    w[1,12]   R27       1
    w[1,12]   normalized_inventory_1  -12
    w[1,13]   mass_1    1
    w[1,13]   R28       1
    w[1,13]   R29       1
    w[1,13]   normalized_inventory_1  -13
    w[1,14]   mass_1    1
    w[1,14]   R30       1
    w[1,14]   R31       1
    w[1,14]   normalized_inventory_1  -14
    w[1,15]   mass_1    1
    w[1,15]   R32       1
    w[1,15]   R33       1
    w[1,15]   normalized_inventory_1  -15
    w[1,16]   mass_1    1
    w[1,16]   R34       1
    w[1,16]   R35       1
    w[1,16]   normalized_inventory_1  -16
    w[1,17]   mass_1    1
    w[1,17]   R36       1
    w[1,17]   R37       1
    w[1,17]   normalized_inventory_1  -17
    w[1,18]   mass_1    1
    w[1,18]   R38       1
    w[1,18]   R39       1
    w[1,18]   normalized_inventory_1  -18
    w[1,19]   mass_1    1
    w[1,19]   R40       1
    w[1,19]   R41       1
    w[1,19]   normalized_inventory_1  -19
    w[2,0]    mass_2    1
    w[2,0]    R46       1
    w[2,0]    R47       1
    w[2,1]    mass_2    1
    w[2,1]    R48       1
    w[2,1]    R49       1
    w[2,1]    normalized_inventory_2  -1
    w[2,2]    mass_2    1
    w[2,2]    R50       1
    w[2,2]    R51       1
    w[2,2]    normalized_inventory_2  -2
    w[2,3]    mass_2    1
    w[2,3]    R52       1
    w[2,3]    R53       1
    w[2,3]    normalized_inventory_2  -3
    w[2,4]    mass_2    1
    w[2,4]    R54       1
    w[2,4]    R55       1
    w[2,4]    normalized_inventory_2  -4
    w[2,5]    mass_2    1
    w[2,5]    R56       1
    w[2,5]    R57       1
    w[2,5]    normalized_inventory_2  -5
    w[2,6]    mass_2    1
    w[2,6]    R58       1
    w[2,6]    R59       1
    w[2,6]    normalized_inventory_2  -6
    w[2,7]    mass_2    1
    w[2,7]    R60       1
    w[2,7]    R61       1
    w[2,7]    normalized_inventory_2  -7
    w[2,8]    mass_2    1
    w[2,8]    R62       1
    w[2,8]    R63       1
    w[2,8]    normalized_inventory_2  -8
    w[2,9]    mass_2    1
    w[2,9]    R64       1
    w[2,9]    R65       1
    w[2,9]    normalized_inventory_2  -9
    w[2,10]   mass_2    1
    w[2,10]   R66       1
    w[2,10]   R67       1
    w[2,10]   normalized_inventory_2  -10
    w[2,11]   mass_2    1
    w[2,11]   R68       1
    w[2,11]   R69       1
    w[2,11]   normalized_inventory_2  -11
    w[2,12]   mass_2    1
    w[2,12]   R70       1
    w[2,12]   R71       1
    w[2,12]   normalized_inventory_2  -12
    w[2,13]   mass_2    1
    w[2,13]   R72       1
    w[2,13]   R73       1
    w[2,13]   normalized_inventory_2  -13
    w[2,14]   mass_2    1
    w[2,14]   R74       1
    w[2,14]   R75       1
    w[2,14]   normalized_inventory_2  -14
    w[2,15]   mass_2    1
    w[2,15]   R76       1
    w[2,15]   R77       1
    w[2,15]   normalized_inventory_2  -15
    w[3,0]    mass_3    1
    w[3,0]    R82       1
    w[3,0]    R83       1
    w[3,1]    mass_3    1
    w[3,1]    R84       1
    w[3,1]    R85       1
    w[3,1]    normalized_inventory_3  -1
    w[3,2]    mass_3    1
    w[3,2]    R86       1
    w[3,2]    R87       1
    w[3,2]    normalized_inventory_3  -2
    w[3,3]    mass_3    1
    w[3,3]    R88       1
    w[3,3]    R89       1
    w[3,3]    normalized_inventory_3  -3
    w[3,4]    mass_3    1
    w[3,4]    R90       1
    w[3,4]    R91       1
    w[3,4]    normalized_inventory_3  -4
    w[3,5]    mass_3    1
    w[3,5]    R92       1
    w[3,5]    R93       1
    w[3,5]    normalized_inventory_3  -5
    w[3,6]    mass_3    1
    w[3,6]    R94       1
    w[3,6]    R95       1
    w[3,6]    normalized_inventory_3  -6
    w[3,7]    mass_3    1
    w[3,7]    R96       1
    w[3,7]    R97       1
    w[3,7]    normalized_inventory_3  -7
    w[3,8]    mass_3    1
    w[3,8]    R98       1
    w[3,8]    R99       1
    w[3,8]    normalized_inventory_3  -8
    w[3,9]    mass_3    1
    w[3,9]    R100      1
    w[3,9]    R101      1
    w[3,9]    normalized_inventory_3  -9
    w[3,10]   mass_3    1
    w[3,10]   R102      1
    w[3,10]   R103      1
    w[3,10]   normalized_inventory_3  -10
    w[3,11]   mass_3    1
    w[3,11]   R104      1
    w[3,11]   R105      1
    w[3,11]   normalized_inventory_3  -11
    w[3,12]   mass_3    1
    w[3,12]   R106      1
    w[3,12]   R107      1
    w[3,12]   normalized_inventory_3  -12
    w[3,13]   mass_3    1
    w[3,13]   R108      1
    w[3,13]   R109      1
    w[3,13]   normalized_inventory_3  -13
    w[3,14]   mass_3    1
    w[3,14]   R110      1
    w[3,14]   R111      1
    w[3,14]   normalized_inventory_3  -14
    w[3,15]   mass_3    1
    w[3,15]   R112      1
    w[3,15]   R113      1
    w[3,15]   normalized_inventory_3  -15
    w[3,16]   mass_3    1
    w[3,16]   R114      1
    w[3,16]   R115      1
    w[3,16]   normalized_inventory_3  -16
    w[3,17]   mass_3    1
    w[3,17]   R116      1
    w[3,17]   R117      1
    w[3,17]   normalized_inventory_3  -17
    w[4,0]    mass_4    1
    w[4,0]    R122      1
    w[4,0]    R123      1
    w[4,1]    mass_4    1
    w[4,1]    R124      1
    w[4,1]    R125      1
    w[4,1]    normalized_inventory_4  -1
    w[4,2]    mass_4    1
    w[4,2]    R126      1
    w[4,2]    R127      1
    w[4,2]    normalized_inventory_4  -2
    w[4,3]    mass_4    1
    w[4,3]    R128      1
    w[4,3]    R129      1
    w[4,3]    normalized_inventory_4  -3
    w[4,4]    mass_4    1
    w[4,4]    R130      1
    w[4,4]    R131      1
    w[4,4]    normalized_inventory_4  -4
    w[4,5]    mass_4    1
    w[4,5]    R132      1
    w[4,5]    R133      1
    w[4,5]    normalized_inventory_4  -5
    w[4,6]    mass_4    1
    w[4,6]    R134      1
    w[4,6]    R135      1
    w[4,6]    normalized_inventory_4  -6
    w[4,7]    mass_4    1
    w[4,7]    R136      1
    w[4,7]    R137      1
    w[4,7]    normalized_inventory_4  -7
    w[4,8]    mass_4    1
    w[4,8]    R138      1
    w[4,8]    R139      1
    w[4,8]    normalized_inventory_4  -8
    w[4,9]    mass_4    1
    w[4,9]    R140      1
    w[4,9]    R141      1
    w[4,9]    normalized_inventory_4  -9
    w[4,10]   mass_4    1
    w[4,10]   R142      1
    w[4,10]   R143      1
    w[4,10]   normalized_inventory_4  -10
    w[4,11]   mass_4    1
    w[4,11]   R144      1
    w[4,11]   R145      1
    w[4,11]   normalized_inventory_4  -11
    w[4,12]   mass_4    1
    w[4,12]   R146      1
    w[4,12]   R147      1
    w[4,12]   normalized_inventory_4  -12
    w[4,13]   mass_4    1
    w[4,13]   R148      1
    w[4,13]   R149      1
    w[4,13]   normalized_inventory_4  -13
    w[4,14]   mass_4    1
    w[4,14]   R150      1
    w[4,14]   R151      1
    w[4,14]   normalized_inventory_4  -14
    w[4,15]   mass_4    1
    w[4,15]   R152      1
    w[4,15]   R153      1
    w[4,15]   normalized_inventory_4  -15
    w[5,0]    mass_5    1
    w[5,0]    R158      1
    w[5,0]    R159      1
    w[5,1]    mass_5    1
    w[5,1]    R160      1
    w[5,1]    R161      1
    w[5,1]    normalized_inventory_5  -1
    w[5,2]    mass_5    1
    w[5,2]    R162      1
    w[5,2]    R163      1
    w[5,2]    normalized_inventory_5  -2
    w[5,3]    mass_5    1
    w[5,3]    R164      1
    w[5,3]    R165      1
    w[5,3]    normalized_inventory_5  -3
    w[5,4]    mass_5    1
    w[5,4]    R166      1
    w[5,4]    R167      1
    w[5,4]    normalized_inventory_5  -4
    w[5,5]    mass_5    1
    w[5,5]    R168      1
    w[5,5]    R169      1
    w[5,5]    normalized_inventory_5  -5
    w[5,6]    mass_5    1
    w[5,6]    R170      1
    w[5,6]    R171      1
    w[5,6]    normalized_inventory_5  -6
    w[5,7]    mass_5    1
    w[5,7]    R172      1
    w[5,7]    R173      1
    w[5,7]    normalized_inventory_5  -7
    w[5,8]    mass_5    1
    w[5,8]    R174      1
    w[5,8]    R175      1
    w[5,8]    normalized_inventory_5  -8
    w[5,9]    mass_5    1
    w[5,9]    R176      1
    w[5,9]    R177      1
    w[5,9]    normalized_inventory_5  -9
    w[5,10]   mass_5    1
    w[5,10]   R178      1
    w[5,10]   R179      1
    w[5,10]   normalized_inventory_5  -10
    w[5,11]   mass_5    1
    w[5,11]   R180      1
    w[5,11]   R181      1
    w[5,11]   normalized_inventory_5  -11
    w[5,12]   mass_5    1
    w[5,12]   R182      1
    w[5,12]   R183      1
    w[5,12]   normalized_inventory_5  -12
    w[5,13]   mass_5    1
    w[5,13]   R184      1
    w[5,13]   R185      1
    w[5,13]   normalized_inventory_5  -13
    w[5,14]   mass_5    1
    w[5,14]   R186      1
    w[5,14]   R187      1
    w[5,14]   normalized_inventory_5  -14
    w[5,15]   mass_5    1
    w[5,15]   R188      1
    w[5,15]   R189      1
    w[5,15]   normalized_inventory_5  -15
    w[5,16]   mass_5    1
    w[5,16]   R190      1
    w[5,16]   R191      1
    w[5,16]   normalized_inventory_5  -16
    w[6,0]    mass_6    1
    w[6,0]    R196      1
    w[6,0]    R197      1
    w[6,1]    mass_6    1
    w[6,1]    R198      1
    w[6,1]    R199      1
    w[6,1]    normalized_inventory_6  -1
    w[6,2]    mass_6    1
    w[6,2]    R200      1
    w[6,2]    R201      1
    w[6,2]    normalized_inventory_6  -2
    w[6,3]    mass_6    1
    w[6,3]    R202      1
    w[6,3]    R203      1
    w[6,3]    normalized_inventory_6  -3
    w[6,4]    mass_6    1
    w[6,4]    R204      1
    w[6,4]    R205      1
    w[6,4]    normalized_inventory_6  -4
    w[6,5]    mass_6    1
    w[6,5]    R206      1
    w[6,5]    R207      1
    w[6,5]    normalized_inventory_6  -5
    w[6,6]    mass_6    1
    w[6,6]    R208      1
    w[6,6]    R209      1
    w[6,6]    normalized_inventory_6  -6
    w[6,7]    mass_6    1
    w[6,7]    R210      1
    w[6,7]    R211      1
    w[6,7]    normalized_inventory_6  -7
    w[6,8]    mass_6    1
    w[6,8]    R212      1
    w[6,8]    R213      1
    w[6,8]    normalized_inventory_6  -8
    w[6,9]    mass_6    1
    w[6,9]    R214      1
    w[6,9]    R215      1
    w[6,9]    normalized_inventory_6  -9
    w[6,10]   mass_6    1
    w[6,10]   R216      1
    w[6,10]   R217      1
    w[6,10]   normalized_inventory_6  -10
    w[7,0]    mass_7    1
    w[7,0]    R222      1
    w[7,0]    R223      1
    w[7,1]    mass_7    1
    w[7,1]    R224      1
    w[7,1]    R225      1
    w[7,1]    normalized_inventory_7  -1
    w[7,2]    mass_7    1
    w[7,2]    R226      1
    w[7,2]    R227      1
    w[7,2]    normalized_inventory_7  -2
    w[7,3]    mass_7    1
    w[7,3]    R228      1
    w[7,3]    R229      1
    w[7,3]    normalized_inventory_7  -3
    w[7,4]    mass_7    1
    w[7,4]    R230      1
    w[7,4]    R231      1
    w[7,4]    normalized_inventory_7  -4
    w[7,5]    mass_7    1
    w[7,5]    R232      1
    w[7,5]    R233      1
    w[7,5]    normalized_inventory_7  -5
    w[7,6]    mass_7    1
    w[7,6]    R234      1
    w[7,6]    R235      1
    w[7,6]    normalized_inventory_7  -6
    w[7,7]    mass_7    1
    w[7,7]    R236      1
    w[7,7]    R237      1
    w[7,7]    normalized_inventory_7  -7
    w[7,8]    mass_7    1
    w[7,8]    R238      1
    w[7,8]    R239      1
    w[7,8]    normalized_inventory_7  -8
    w[7,9]    mass_7    1
    w[7,9]    R240      1
    w[7,9]    R241      1
    w[7,9]    normalized_inventory_7  -9
    w[7,10]   mass_7    1
    w[7,10]   R242      1
    w[7,10]   R243      1
    w[7,10]   normalized_inventory_7  -10
    w[7,11]   mass_7    1
    w[7,11]   R244      1
    w[7,11]   R245      1
    w[7,11]   normalized_inventory_7  -11
    w[7,12]   mass_7    1
    w[7,12]   R246      1
    w[7,12]   R247      1
    w[7,12]   normalized_inventory_7  -12
    w[7,13]   mass_7    1
    w[7,13]   R248      1
    w[7,13]   R249      1
    w[7,13]   normalized_inventory_7  -13
    w[7,14]   mass_7    1
    w[7,14]   R250      1
    w[7,14]   R251      1
    w[7,14]   normalized_inventory_7  -14
    w[7,15]   mass_7    1
    w[7,15]   R252      1
    w[7,15]   R253      1
    w[7,15]   normalized_inventory_7  -15
    w[7,16]   mass_7    1
    w[7,16]   R254      1
    w[7,16]   R255      1
    w[7,16]   normalized_inventory_7  -16
    w[7,17]   mass_7    1
    w[7,17]   R256      1
    w[7,17]   R257      1
    w[7,17]   normalized_inventory_7  -17
    w[8,0]    mass_8    1
    w[8,0]    R262      1
    w[8,0]    R263      1
    w[8,1]    mass_8    1
    w[8,1]    R264      1
    w[8,1]    R265      1
    w[8,1]    normalized_inventory_8  -1
    w[8,2]    mass_8    1
    w[8,2]    R266      1
    w[8,2]    R267      1
    w[8,2]    normalized_inventory_8  -2
    w[8,3]    mass_8    1
    w[8,3]    R268      1
    w[8,3]    R269      1
    w[8,3]    normalized_inventory_8  -3
    w[8,4]    mass_8    1
    w[8,4]    R270      1
    w[8,4]    R271      1
    w[8,4]    normalized_inventory_8  -4
    w[8,5]    mass_8    1
    w[8,5]    R272      1
    w[8,5]    R273      1
    w[8,5]    normalized_inventory_8  -5
    w[8,6]    mass_8    1
    w[8,6]    R274      1
    w[8,6]    R275      1
    w[8,6]    normalized_inventory_8  -6
    w[8,7]    mass_8    1
    w[8,7]    R276      1
    w[8,7]    R277      1
    w[8,7]    normalized_inventory_8  -7
    w[8,8]    mass_8    1
    w[8,8]    R278      1
    w[8,8]    R279      1
    w[8,8]    normalized_inventory_8  -8
    w[8,9]    mass_8    1
    w[8,9]    R280      1
    w[8,9]    R281      1
    w[8,9]    normalized_inventory_8  -9
    w[8,10]   mass_8    1
    w[8,10]   R282      1
    w[8,10]   R283      1
    w[8,10]   normalized_inventory_8  -10
    w[8,11]   mass_8    1
    w[8,11]   R284      1
    w[8,11]   R285      1
    w[8,11]   normalized_inventory_8  -11
    w[8,12]   mass_8    1
    w[8,12]   R286      1
    w[8,12]   R287      1
    w[8,12]   normalized_inventory_8  -12
    w[8,13]   mass_8    1
    w[8,13]   R288      1
    w[8,13]   R289      1
    w[8,13]   normalized_inventory_8  -13
    w[8,14]   mass_8    1
    w[8,14]   R290      1
    w[8,14]   R291      1
    w[8,14]   normalized_inventory_8  -14
    w[8,15]   mass_8    1
    w[8,15]   R292      1
    w[8,15]   R293      1
    w[8,15]   normalized_inventory_8  -15
    w[8,16]   mass_8    1
    w[8,16]   R294      1
    w[8,16]   R295      1
    w[8,16]   normalized_inventory_8  -16
    w[8,17]   mass_8    1
    w[8,17]   R296      1
    w[8,17]   R297      1
    w[8,17]   normalized_inventory_8  -17
    w[8,18]   mass_8    1
    w[8,18]   R298      1
    w[8,18]   R299      1
    w[8,18]   normalized_inventory_8  -18
    w[8,19]   mass_8    1
    w[8,19]   R300      1
    w[8,19]   R301      1
    w[8,19]   normalized_inventory_8  -19
    w[8,20]   mass_8    1
    w[8,20]   R302      1
    w[8,20]   R303      1
    w[8,20]   normalized_inventory_8  -20
    w[8,21]   mass_8    1
    w[8,21]   R304      1
    w[8,21]   R305      1
    w[8,21]   normalized_inventory_8  -21
    w[9,0]    mass_9    1
    w[9,0]    R310      1
    w[9,0]    R311      1
    w[9,1]    mass_9    1
    w[9,1]    R312      1
    w[9,1]    R313      1
    w[9,1]    normalized_inventory_9  -1
    w[9,2]    mass_9    1
    w[9,2]    R314      1
    w[9,2]    R315      1
    w[9,2]    normalized_inventory_9  -2
    w[9,3]    mass_9    1
    w[9,3]    R316      1
    w[9,3]    R317      1
    w[9,3]    normalized_inventory_9  -3
    w[9,4]    mass_9    1
    w[9,4]    R318      1
    w[9,4]    R319      1
    w[9,4]    normalized_inventory_9  -4
    w[9,5]    mass_9    1
    w[9,5]    R320      1
    w[9,5]    R321      1
    w[9,5]    normalized_inventory_9  -5
    w[9,6]    mass_9    1
    w[9,6]    R322      1
    w[9,6]    R323      1
    w[9,6]    normalized_inventory_9  -6
    w[9,7]    mass_9    1
    w[9,7]    R324      1
    w[9,7]    R325      1
    w[9,7]    normalized_inventory_9  -7
    w[9,8]    mass_9    1
    w[9,8]    R326      1
    w[9,8]    R327      1
    w[9,8]    normalized_inventory_9  -8
    w[9,9]    mass_9    1
    w[9,9]    R328      1
    w[9,9]    R329      1
    w[9,9]    normalized_inventory_9  -9
    w[9,10]   mass_9    1
    w[9,10]   R330      1
    w[9,10]   R331      1
    w[9,10]   normalized_inventory_9  -10
    w[9,11]   mass_9    1
    w[9,11]   R332      1
    w[9,11]   R333      1
    w[9,11]   normalized_inventory_9  -11
    w[9,12]   mass_9    1
    w[9,12]   R334      1
    w[9,12]   R335      1
    w[9,12]   normalized_inventory_9  -12
    w[10,0]   mass_10   1
    w[10,0]   R340      1
    w[10,0]   R341      1
    w[10,1]   mass_10   1
    w[10,1]   R342      1
    w[10,1]   R343      1
    w[10,1]   normalized_inventory_10  -1
    w[10,2]   mass_10   1
    w[10,2]   R344      1
    w[10,2]   R345      1
    w[10,2]   normalized_inventory_10  -2
    w[10,3]   mass_10   1
    w[10,3]   R346      1
    w[10,3]   R347      1
    w[10,3]   normalized_inventory_10  -3
    w[10,4]   mass_10   1
    w[10,4]   R348      1
    w[10,4]   R349      1
    w[10,4]   normalized_inventory_10  -4
    w[10,5]   mass_10   1
    w[10,5]   R350      1
    w[10,5]   R351      1
    w[10,5]   normalized_inventory_10  -5
    w[10,6]   mass_10   1
    w[10,6]   R352      1
    w[10,6]   R353      1
    w[10,6]   normalized_inventory_10  -6
    w[10,7]   mass_10   1
    w[10,7]   R354      1
    w[10,7]   R355      1
    w[10,7]   normalized_inventory_10  -7
    w[10,8]   mass_10   1
    w[10,8]   R356      1
    w[10,8]   R357      1
    w[10,8]   normalized_inventory_10  -8
    w[10,9]   mass_10   1
    w[10,9]   R358      1
    w[10,9]   R359      1
    w[10,9]   normalized_inventory_10  -9
    w[10,10]  mass_10   1
    w[10,10]  R360      1
    w[10,10]  R361      1
    w[10,10]  normalized_inventory_10  -10
    w[10,11]  mass_10   1
    w[10,11]  R362      1
    w[10,11]  R363      1
    w[10,11]  normalized_inventory_10  -11
    w[10,12]  mass_10   1
    w[10,12]  R364      1
    w[10,12]  R365      1
    w[10,12]  normalized_inventory_10  -12
    w[10,13]  mass_10   1
    w[10,13]  R366      1
    w[10,13]  R367      1
    w[10,13]  normalized_inventory_10  -13
    w[10,14]  mass_10   1
    w[10,14]  R368      1
    w[10,14]  R369      1
    w[10,14]  normalized_inventory_10  -14
    w[10,15]  mass_10   1
    w[10,15]  R370      1
    w[10,15]  R371      1
    w[10,15]  normalized_inventory_10  -15
    w[10,16]  mass_10   1
    w[10,16]  R372      1
    w[10,16]  R373      1
    w[10,16]  normalized_inventory_10  -16
    w[10,17]  mass_10   1
    w[10,17]  R374      1
    w[10,17]  R375      1
    w[10,17]  normalized_inventory_10  -17
    w[10,18]  mass_10   1
    w[10,18]  R376      1
    w[10,18]  R377      1
    w[10,18]  normalized_inventory_10  -18
    w[10,19]  mass_10   1
    w[10,19]  R378      1
    w[10,19]  R379      1
    w[10,19]  normalized_inventory_10  -19
    w[11,0]   mass_11   1
    w[11,0]   R384      1
    w[11,0]   R385      1
    w[11,1]   mass_11   1
    w[11,1]   R386      1
    w[11,1]   R387      1
    w[11,1]   normalized_inventory_11  -1
    w[11,2]   mass_11   1
    w[11,2]   R388      1
    w[11,2]   R389      1
    w[11,2]   normalized_inventory_11  -2
    w[11,3]   mass_11   1
    w[11,3]   R390      1
    w[11,3]   R391      1
    w[11,3]   normalized_inventory_11  -3
    w[11,4]   mass_11   1
    w[11,4]   R392      1
    w[11,4]   R393      1
    w[11,4]   normalized_inventory_11  -4
    w[11,5]   mass_11   1
    w[11,5]   R394      1
    w[11,5]   R395      1
    w[11,5]   normalized_inventory_11  -5
    w[11,6]   mass_11   1
    w[11,6]   R396      1
    w[11,6]   R397      1
    w[11,6]   normalized_inventory_11  -6
    w[11,7]   mass_11   1
    w[11,7]   R398      1
    w[11,7]   R399      1
    w[11,7]   normalized_inventory_11  -7
    w[11,8]   mass_11   1
    w[11,8]   R400      1
    w[11,8]   R401      1
    w[11,8]   normalized_inventory_11  -8
    w[11,9]   mass_11   1
    w[11,9]   R402      1
    w[11,9]   R403      1
    w[11,9]   normalized_inventory_11  -9
    w[11,10]  mass_11   1
    w[11,10]  R404      1
    w[11,10]  R405      1
    w[11,10]  normalized_inventory_11  -10
    w[11,11]  mass_11   1
    w[11,11]  R406      1
    w[11,11]  R407      1
    w[11,11]  normalized_inventory_11  -11
    w[11,12]  mass_11   1
    w[11,12]  R408      1
    w[11,12]  R409      1
    w[11,12]  normalized_inventory_11  -12
    w[12,0]   mass_12   1
    w[12,0]   R414      1
    w[12,0]   R415      1
    w[12,1]   mass_12   1
    w[12,1]   R416      1
    w[12,1]   R417      1
    w[12,1]   normalized_inventory_12  -1
    w[12,2]   mass_12   1
    w[12,2]   R418      1
    w[12,2]   R419      1
    w[12,2]   normalized_inventory_12  -2
    w[12,3]   mass_12   1
    w[12,3]   R420      1
    w[12,3]   R421      1
    w[12,3]   normalized_inventory_12  -3
    w[12,4]   mass_12   1
    w[12,4]   R422      1
    w[12,4]   R423      1
    w[12,4]   normalized_inventory_12  -4
    w[12,5]   mass_12   1
    w[12,5]   R424      1
    w[12,5]   R425      1
    w[12,5]   normalized_inventory_12  -5
    w[12,6]   mass_12   1
    w[12,6]   R426      1
    w[12,6]   R427      1
    w[12,6]   normalized_inventory_12  -6
    w[12,7]   mass_12   1
    w[12,7]   R428      1
    w[12,7]   R429      1
    w[12,7]   normalized_inventory_12  -7
    w[12,8]   mass_12   1
    w[12,8]   R430      1
    w[12,8]   R431      1
    w[12,8]   normalized_inventory_12  -8
    w[12,9]   mass_12   1
    w[12,9]   R432      1
    w[12,9]   R433      1
    w[12,9]   normalized_inventory_12  -9
    w[12,10]  mass_12   1
    w[12,10]  R434      1
    w[12,10]  R435      1
    w[12,10]  normalized_inventory_12  -10
    w[12,11]  mass_12   1
    w[12,11]  R436      1
    w[12,11]  R437      1
    w[12,11]  normalized_inventory_12  -11
    w[12,12]  mass_12   1
    w[12,12]  R438      1
    w[12,12]  R439      1
    w[12,12]  normalized_inventory_12  -12
    w[12,13]  mass_12   1
    w[12,13]  R440      1
    w[12,13]  R441      1
    w[12,13]  normalized_inventory_12  -13
    w[12,14]  mass_12   1
    w[12,14]  R442      1
    w[12,14]  R443      1
    w[12,14]  normalized_inventory_12  -14
    w[12,15]  mass_12   1
    w[12,15]  R444      1
    w[12,15]  R445      1
    w[12,15]  normalized_inventory_12  -15
    w[13,0]   mass_13   1
    w[13,0]   R450      1
    w[13,0]   R451      1
    w[13,1]   mass_13   1
    w[13,1]   R452      1
    w[13,1]   R453      1
    w[13,1]   normalized_inventory_13  -1
    w[13,2]   mass_13   1
    w[13,2]   R454      1
    w[13,2]   R455      1
    w[13,2]   normalized_inventory_13  -2
    w[13,3]   mass_13   1
    w[13,3]   R456      1
    w[13,3]   R457      1
    w[13,3]   normalized_inventory_13  -3
    w[13,4]   mass_13   1
    w[13,4]   R458      1
    w[13,4]   R459      1
    w[13,4]   normalized_inventory_13  -4
    w[13,5]   mass_13   1
    w[13,5]   R460      1
    w[13,5]   R461      1
    w[13,5]   normalized_inventory_13  -5
    w[13,6]   mass_13   1
    w[13,6]   R462      1
    w[13,6]   R463      1
    w[13,6]   normalized_inventory_13  -6
    w[13,7]   mass_13   1
    w[13,7]   R464      1
    w[13,7]   R465      1
    w[13,7]   normalized_inventory_13  -7
    w[13,8]   mass_13   1
    w[13,8]   R466      1
    w[13,8]   R467      1
    w[13,8]   normalized_inventory_13  -8
    w[13,9]   mass_13   1
    w[13,9]   R468      1
    w[13,9]   R469      1
    w[13,9]   normalized_inventory_13  -9
    w[13,10]  mass_13   1
    w[13,10]  R470      1
    w[13,10]  R471      1
    w[13,10]  normalized_inventory_13  -10
    w[13,11]  mass_13   1
    w[13,11]  R472      1
    w[13,11]  R473      1
    w[13,11]  normalized_inventory_13  -11
    w[13,12]  mass_13   1
    w[13,12]  R474      1
    w[13,12]  R475      1
    w[13,12]  normalized_inventory_13  -12
    w[13,13]  mass_13   1
    w[13,13]  R476      1
    w[13,13]  R477      1
    w[13,13]  normalized_inventory_13  -13
    w[13,14]  mass_13   1
    w[13,14]  R478      1
    w[13,14]  R479      1
    w[13,14]  normalized_inventory_13  -14
    w[13,15]  mass_13   1
    w[13,15]  R480      1
    w[13,15]  R481      1
    w[13,15]  normalized_inventory_13  -15
    w[13,16]  mass_13   1
    w[13,16]  R482      1
    w[13,16]  R483      1
    w[13,16]  normalized_inventory_13  -16
    w[13,17]  mass_13   1
    w[13,17]  R484      1
    w[13,17]  R485      1
    w[13,17]  normalized_inventory_13  -17
    w[13,18]  mass_13   1
    w[13,18]  R486      1
    w[13,18]  R487      1
    w[13,18]  normalized_inventory_13  -18
    w[13,19]  mass_13   1
    w[13,19]  R488      1
    w[13,19]  R489      1
    w[13,19]  normalized_inventory_13  -19
    w[14,0]   mass_14   1
    w[14,0]   R494      1
    w[14,0]   R495      1
    w[14,1]   mass_14   1
    w[14,1]   R496      1
    w[14,1]   R497      1
    w[14,1]   normalized_inventory_14  -1
    w[14,2]   mass_14   1
    w[14,2]   R498      1
    w[14,2]   R499      1
    w[14,2]   normalized_inventory_14  -2
    w[14,3]   mass_14   1
    w[14,3]   R500      1
    w[14,3]   R501      1
    w[14,3]   normalized_inventory_14  -3
    w[14,4]   mass_14   1
    w[14,4]   R502      1
    w[14,4]   R503      1
    w[14,4]   normalized_inventory_14  -4
    w[14,5]   mass_14   1
    w[14,5]   R504      1
    w[14,5]   R505      1
    w[14,5]   normalized_inventory_14  -5
    w[14,6]   mass_14   1
    w[14,6]   R506      1
    w[14,6]   R507      1
    w[14,6]   normalized_inventory_14  -6
    w[14,7]   mass_14   1
    w[14,7]   R508      1
    w[14,7]   R509      1
    w[14,7]   normalized_inventory_14  -7
    w[14,8]   mass_14   1
    w[14,8]   R510      1
    w[14,8]   R511      1
    w[14,8]   normalized_inventory_14  -8
    w[14,9]   mass_14   1
    w[14,9]   R512      1
    w[14,9]   R513      1
    w[14,9]   normalized_inventory_14  -9
    w[14,10]  mass_14   1
    w[14,10]  R514      1
    w[14,10]  R515      1
    w[14,10]  normalized_inventory_14  -10
    w[14,11]  mass_14   1
    w[14,11]  R516      1
    w[14,11]  R517      1
    w[14,11]  normalized_inventory_14  -11
    w[14,12]  mass_14   1
    w[14,12]  R518      1
    w[14,12]  R519      1
    w[14,12]  normalized_inventory_14  -12
    w[14,13]  mass_14   1
    w[14,13]  R520      1
    w[14,13]  R521      1
    w[14,13]  normalized_inventory_14  -13
    w[14,14]  mass_14   1
    w[14,14]  R522      1
    w[14,14]  R523      1
    w[14,14]  normalized_inventory_14  -14
    w[14,15]  mass_14   1
    w[14,15]  R524      1
    w[14,15]  R525      1
    w[14,15]  normalized_inventory_14  -15
    w[15,0]   mass_15   1
    w[15,0]   R530      1
    w[15,0]   R531      1
    w[15,1]   mass_15   1
    w[15,1]   R532      1
    w[15,1]   R533      1
    w[15,1]   normalized_inventory_15  -1
    w[15,2]   mass_15   1
    w[15,2]   R534      1
    w[15,2]   R535      1
    w[15,2]   normalized_inventory_15  -2
    w[15,3]   mass_15   1
    w[15,3]   R536      1
    w[15,3]   R537      1
    w[15,3]   normalized_inventory_15  -3
    w[15,4]   mass_15   1
    w[15,4]   R538      1
    w[15,4]   R539      1
    w[15,4]   normalized_inventory_15  -4
    w[15,5]   mass_15   1
    w[15,5]   R540      1
    w[15,5]   R541      1
    w[15,5]   normalized_inventory_15  -5
    w[15,6]   mass_15   1
    w[15,6]   R542      1
    w[15,6]   R543      1
    w[15,6]   normalized_inventory_15  -6
    w[15,7]   mass_15   1
    w[15,7]   R544      1
    w[15,7]   R545      1
    w[15,7]   normalized_inventory_15  -7
    w[15,8]   mass_15   1
    w[15,8]   R546      1
    w[15,8]   R547      1
    w[15,8]   normalized_inventory_15  -8
    w[15,9]   mass_15   1
    w[15,9]   R548      1
    w[15,9]   R549      1
    w[15,9]   normalized_inventory_15  -9
    w[15,10]  mass_15   1
    w[15,10]  R550      1
    w[15,10]  R551      1
    w[15,10]  normalized_inventory_15  -10
    w[15,11]  mass_15   1
    w[15,11]  R552      1
    w[15,11]  R553      1
    w[15,11]  normalized_inventory_15  -11
    w[15,12]  mass_15   1
    w[15,12]  R554      1
    w[15,12]  R555      1
    w[15,12]  normalized_inventory_15  -12
    w[15,13]  mass_15   1
    w[15,13]  R556      1
    w[15,13]  R557      1
    w[15,13]  normalized_inventory_15  -13
    w[15,14]  mass_15   1
    w[15,14]  R558      1
    w[15,14]  R559      1
    w[15,14]  normalized_inventory_15  -14
    w[15,15]  mass_15   1
    w[15,15]  R560      1
    w[15,15]  R561      1
    w[15,15]  normalized_inventory_15  -15
    w[15,16]  mass_15   1
    w[15,16]  R562      1
    w[15,16]  R563      1
    w[15,16]  normalized_inventory_15  -16
    w[16,0]   mass_16   1
    w[16,0]   R568      1
    w[16,0]   R569      1
    w[16,1]   mass_16   1
    w[16,1]   R570      1
    w[16,1]   R571      1
    w[16,1]   normalized_inventory_16  -1
    w[16,2]   mass_16   1
    w[16,2]   R572      1
    w[16,2]   R573      1
    w[16,2]   normalized_inventory_16  -2
    w[16,3]   mass_16   1
    w[16,3]   R574      1
    w[16,3]   R575      1
    w[16,3]   normalized_inventory_16  -3
    w[16,4]   mass_16   1
    w[16,4]   R576      1
    w[16,4]   R577      1
    w[16,4]   normalized_inventory_16  -4
    w[16,5]   mass_16   1
    w[16,5]   R578      1
    w[16,5]   R579      1
    w[16,5]   normalized_inventory_16  -5
    w[16,6]   mass_16   1
    w[16,6]   R580      1
    w[16,6]   R581      1
    w[16,6]   normalized_inventory_16  -6
    w[16,7]   mass_16   1
    w[16,7]   R582      1
    w[16,7]   R583      1
    w[16,7]   normalized_inventory_16  -7
    w[16,8]   mass_16   1
    w[16,8]   R584      1
    w[16,8]   R585      1
    w[16,8]   normalized_inventory_16  -8
    w[16,9]   mass_16   1
    w[16,9]   R586      1
    w[16,9]   R587      1
    w[16,9]   normalized_inventory_16  -9
    w[16,10]  mass_16   1
    w[16,10]  R588      1
    w[16,10]  R589      1
    w[16,10]  normalized_inventory_16  -10
    w[16,11]  mass_16   1
    w[16,11]  R590      1
    w[16,11]  R591      1
    w[16,11]  normalized_inventory_16  -11
    w[16,12]  mass_16   1
    w[16,12]  R592      1
    w[16,12]  R593      1
    w[16,12]  normalized_inventory_16  -12
    w[17,0]   mass_17   1
    w[17,0]   R598      1
    w[17,0]   R599      1
    w[17,1]   mass_17   1
    w[17,1]   R600      1
    w[17,1]   R601      1
    w[17,1]   normalized_inventory_17  -1
    w[17,2]   mass_17   1
    w[17,2]   R602      1
    w[17,2]   R603      1
    w[17,2]   normalized_inventory_17  -2
    w[17,3]   mass_17   1
    w[17,3]   R604      1
    w[17,3]   R605      1
    w[17,3]   normalized_inventory_17  -3
    w[17,4]   mass_17   1
    w[17,4]   R606      1
    w[17,4]   R607      1
    w[17,4]   normalized_inventory_17  -4
    w[17,5]   mass_17   1
    w[17,5]   R608      1
    w[17,5]   R609      1
    w[17,5]   normalized_inventory_17  -5
    w[17,6]   mass_17   1
    w[17,6]   R610      1
    w[17,6]   R611      1
    w[17,6]   normalized_inventory_17  -6
    w[17,7]   mass_17   1
    w[17,7]   R612      1
    w[17,7]   R613      1
    w[17,7]   normalized_inventory_17  -7
    w[17,8]   mass_17   1
    w[17,8]   R614      1
    w[17,8]   R615      1
    w[17,8]   normalized_inventory_17  -8
    w[17,9]   mass_17   1
    w[17,9]   R616      1
    w[17,9]   R617      1
    w[17,9]   normalized_inventory_17  -9
    w[17,10]  mass_17   1
    w[17,10]  R618      1
    w[17,10]  R619      1
    w[17,10]  normalized_inventory_17  -10
    w[17,11]  mass_17   1
    w[17,11]  R620      1
    w[17,11]  R621      1
    w[17,11]  normalized_inventory_17  -11
    w[17,12]  mass_17   1
    w[17,12]  R622      1
    w[17,12]  R623      1
    w[17,12]  normalized_inventory_17  -12
    w[17,13]  mass_17   1
    w[17,13]  R624      1
    w[17,13]  R625      1
    w[17,13]  normalized_inventory_17  -13
    w[17,14]  mass_17   1
    w[17,14]  R626      1
    w[17,14]  R627      1
    w[17,14]  normalized_inventory_17  -14
    w[17,15]  mass_17   1
    w[17,15]  R628      1
    w[17,15]  R629      1
    w[17,15]  normalized_inventory_17  -15
    w[17,16]  mass_17   1
    w[17,16]  R630      1
    w[17,16]  R631      1
    w[17,16]  normalized_inventory_17  -16
    w[18,0]   mass_18   1
    w[18,0]   R636      1
    w[18,0]   R637      1
    w[18,1]   mass_18   1
    w[18,1]   R638      1
    w[18,1]   R639      1
    w[18,1]   normalized_inventory_18  -1
    w[18,2]   mass_18   1
    w[18,2]   R640      1
    w[18,2]   R641      1
    w[18,2]   normalized_inventory_18  -2
    w[18,3]   mass_18   1
    w[18,3]   R642      1
    w[18,3]   R643      1
    w[18,3]   normalized_inventory_18  -3
    w[18,4]   mass_18   1
    w[18,4]   R644      1
    w[18,4]   R645      1
    w[18,4]   normalized_inventory_18  -4
    w[18,5]   mass_18   1
    w[18,5]   R646      1
    w[18,5]   R647      1
    w[18,5]   normalized_inventory_18  -5
    w[18,6]   mass_18   1
    w[18,6]   R648      1
    w[18,6]   R649      1
    w[18,6]   normalized_inventory_18  -6
    w[18,7]   mass_18   1
    w[18,7]   R650      1
    w[18,7]   R651      1
    w[18,7]   normalized_inventory_18  -7
    w[18,8]   mass_18   1
    w[18,8]   R652      1
    w[18,8]   R653      1
    w[18,8]   normalized_inventory_18  -8
    w[18,9]   mass_18   1
    w[18,9]   R654      1
    w[18,9]   R655      1
    w[18,9]   normalized_inventory_18  -9
    w[18,10]  mass_18   1
    w[18,10]  R656      1
    w[18,10]  R657      1
    w[18,10]  normalized_inventory_18  -10
    w[18,11]  mass_18   1
    w[18,11]  R658      1
    w[18,11]  R659      1
    w[18,11]  normalized_inventory_18  -11
    w[18,12]  mass_18   1
    w[18,12]  R660      1
    w[18,12]  R661      1
    w[18,12]  normalized_inventory_18  -12
    w[18,13]  mass_18   1
    w[18,13]  R662      1
    w[18,13]  R663      1
    w[18,13]  normalized_inventory_18  -13
    w[18,14]  mass_18   1
    w[18,14]  R664      1
    w[18,14]  R665      1
    w[18,14]  normalized_inventory_18  -14
    w[18,15]  mass_18   1
    w[18,15]  R666      1
    w[18,15]  R667      1
    w[18,15]  normalized_inventory_18  -15
    w[18,16]  mass_18   1
    w[18,16]  R668      1
    w[18,16]  R669      1
    w[18,16]  normalized_inventory_18  -16
    w[18,17]  mass_18   1
    w[18,17]  R670      1
    w[18,17]  R671      1
    w[18,17]  normalized_inventory_18  -17
    w[19,0]   mass_19   1
    w[19,0]   R676      1
    w[19,0]   R677      1
    w[19,1]   mass_19   1
    w[19,1]   R678      1
    w[19,1]   R679      1
    w[19,1]   normalized_inventory_19  -1
    w[19,2]   mass_19   1
    w[19,2]   R680      1
    w[19,2]   R681      1
    w[19,2]   normalized_inventory_19  -2
    w[19,3]   mass_19   1
    w[19,3]   R682      1
    w[19,3]   R683      1
    w[19,3]   normalized_inventory_19  -3
    w[19,4]   mass_19   1
    w[19,4]   R684      1
    w[19,4]   R685      1
    w[19,4]   normalized_inventory_19  -4
    w[19,5]   mass_19   1
    w[19,5]   R686      1
    w[19,5]   R687      1
    w[19,5]   normalized_inventory_19  -5
    w[19,6]   mass_19   1
    w[19,6]   R688      1
    w[19,6]   R689      1
    w[19,6]   normalized_inventory_19  -6
    w[19,7]   mass_19   1
    w[19,7]   R690      1
    w[19,7]   R691      1
    w[19,7]   normalized_inventory_19  -7
    w[19,8]   mass_19   1
    w[19,8]   R692      1
    w[19,8]   R693      1
    w[19,8]   normalized_inventory_19  -8
    w[20,0]   mass_20   1
    w[20,0]   R698      1
    w[20,0]   R699      1
    w[20,1]   mass_20   1
    w[20,1]   R700      1
    w[20,1]   R701      1
    w[20,1]   normalized_inventory_20  -1
    w[20,2]   mass_20   1
    w[20,2]   R702      1
    w[20,2]   R703      1
    w[20,2]   normalized_inventory_20  -2
    w[20,3]   mass_20   1
    w[20,3]   R704      1
    w[20,3]   R705      1
    w[20,3]   normalized_inventory_20  -3
    w[20,4]   mass_20   1
    w[20,4]   R706      1
    w[20,4]   R707      1
    w[20,4]   normalized_inventory_20  -4
    w[20,5]   mass_20   1
    w[20,5]   R708      1
    w[20,5]   R709      1
    w[20,5]   normalized_inventory_20  -5
    w[20,6]   mass_20   1
    w[20,6]   R710      1
    w[20,6]   R711      1
    w[20,6]   normalized_inventory_20  -6
    w[20,7]   mass_20   1
    w[20,7]   R712      1
    w[20,7]   R713      1
    w[20,7]   normalized_inventory_20  -7
    w[20,8]   mass_20   1
    w[20,8]   R714      1
    w[20,8]   R715      1
    w[20,8]   normalized_inventory_20  -8
    w[20,9]   mass_20   1
    w[20,9]   R716      1
    w[20,9]   R717      1
    w[20,9]   normalized_inventory_20  -9
    w[20,10]  mass_20   1
    w[20,10]  R718      1
    w[20,10]  R719      1
    w[20,10]  normalized_inventory_20  -10
    w[20,11]  mass_20   1
    w[20,11]  R720      1
    w[20,11]  R721      1
    w[20,11]  normalized_inventory_20  -11
    w[20,12]  mass_20   1
    w[20,12]  R722      1
    w[20,12]  R723      1
    w[20,12]  normalized_inventory_20  -12
    w[21,0]   mass_21   1
    w[21,0]   R728      1
    w[21,0]   R729      1
    w[21,1]   mass_21   1
    w[21,1]   R730      1
    w[21,1]   R731      1
    w[21,1]   normalized_inventory_21  -1
    w[21,2]   mass_21   1
    w[21,2]   R732      1
    w[21,2]   R733      1
    w[21,2]   normalized_inventory_21  -2
    w[21,3]   mass_21   1
    w[21,3]   R734      1
    w[21,3]   R735      1
    w[21,3]   normalized_inventory_21  -3
    w[21,4]   mass_21   1
    w[21,4]   R736      1
    w[21,4]   R737      1
    w[21,4]   normalized_inventory_21  -4
    w[21,5]   mass_21   1
    w[21,5]   R738      1
    w[21,5]   R739      1
    w[21,5]   normalized_inventory_21  -5
    w[21,6]   mass_21   1
    w[21,6]   R740      1
    w[21,6]   R741      1
    w[21,6]   normalized_inventory_21  -6
    w[21,7]   mass_21   1
    w[21,7]   R742      1
    w[21,7]   R743      1
    w[21,7]   normalized_inventory_21  -7
    w[21,8]   mass_21   1
    w[21,8]   R744      1
    w[21,8]   R745      1
    w[21,8]   normalized_inventory_21  -8
    w[21,9]   mass_21   1
    w[21,9]   R746      1
    w[21,9]   R747      1
    w[21,9]   normalized_inventory_21  -9
    w[21,10]  mass_21   1
    w[21,10]  R748      1
    w[21,10]  R749      1
    w[21,10]  normalized_inventory_21  -10
    w[21,11]  mass_21   1
    w[21,11]  R750      1
    w[21,11]  R751      1
    w[21,11]  normalized_inventory_21  -11
    w[21,12]  mass_21   1
    w[21,12]  R752      1
    w[21,12]  R753      1
    w[21,12]  normalized_inventory_21  -12
    w[21,13]  mass_21   1
    w[21,13]  R754      1
    w[21,13]  R755      1
    w[21,13]  normalized_inventory_21  -13
    w[21,14]  mass_21   1
    w[21,14]  R756      1
    w[21,14]  R757      1
    w[21,14]  normalized_inventory_21  -14
    w[21,15]  mass_21   1
    w[21,15]  R758      1
    w[21,15]  R759      1
    w[21,15]  normalized_inventory_21  -15
    w[22,0]   mass_22   1
    w[22,0]   R764      1
    w[22,0]   R765      1
    w[22,1]   mass_22   1
    w[22,1]   R766      1
    w[22,1]   R767      1
    w[22,1]   normalized_inventory_22  -1
    w[22,2]   mass_22   1
    w[22,2]   R768      1
    w[22,2]   R769      1
    w[22,2]   normalized_inventory_22  -2
    w[22,3]   mass_22   1
    w[22,3]   R770      1
    w[22,3]   R771      1
    w[22,3]   normalized_inventory_22  -3
    w[22,4]   mass_22   1
    w[22,4]   R772      1
    w[22,4]   R773      1
    w[22,4]   normalized_inventory_22  -4
    w[22,5]   mass_22   1
    w[22,5]   R774      1
    w[22,5]   R775      1
    w[22,5]   normalized_inventory_22  -5
    w[22,6]   mass_22   1
    w[22,6]   R776      1
    w[22,6]   R777      1
    w[22,6]   normalized_inventory_22  -6
    w[22,7]   mass_22   1
    w[22,7]   R778      1
    w[22,7]   R779      1
    w[22,7]   normalized_inventory_22  -7
    w[22,8]   mass_22   1
    w[22,8]   R780      1
    w[22,8]   R781      1
    w[22,8]   normalized_inventory_22  -8
    w[22,9]   mass_22   1
    w[22,9]   R782      1
    w[22,9]   R783      1
    w[22,9]   normalized_inventory_22  -9
    w[22,10]  mass_22   1
    w[22,10]  R784      1
    w[22,10]  R785      1
    w[22,10]  normalized_inventory_22  -10
    w[22,11]  mass_22   1
    w[22,11]  R786      1
    w[22,11]  R787      1
    w[22,11]  normalized_inventory_22  -11
    w[22,12]  mass_22   1
    w[22,12]  R788      1
    w[22,12]  R789      1
    w[22,12]  normalized_inventory_22  -12
    w[23,0]   mass_23   1
    w[23,0]   R794      1
    w[23,0]   R795      1
    w[23,1]   mass_23   1
    w[23,1]   R796      1
    w[23,1]   R797      1
    w[23,1]   normalized_inventory_23  -1
    w[23,2]   mass_23   1
    w[23,2]   R798      1
    w[23,2]   R799      1
    w[23,2]   normalized_inventory_23  -2
    w[23,3]   mass_23   1
    w[23,3]   R800      1
    w[23,3]   R801      1
    w[23,3]   normalized_inventory_23  -3
    w[23,4]   mass_23   1
    w[23,4]   R802      1
    w[23,4]   R803      1
    w[23,4]   normalized_inventory_23  -4
    w[23,5]   mass_23   1
    w[23,5]   R804      1
    w[23,5]   R805      1
    w[23,5]   normalized_inventory_23  -5
    w[23,6]   mass_23   1
    w[23,6]   R806      1
    w[23,6]   R807      1
    w[23,6]   normalized_inventory_23  -6
    w[23,7]   mass_23   1
    w[23,7]   R808      1
    w[23,7]   R809      1
    w[23,7]   normalized_inventory_23  -7
    w[23,8]   mass_23   1
    w[23,8]   R810      1
    w[23,8]   R811      1
    w[23,8]   normalized_inventory_23  -8
    w[23,9]   mass_23   1
    w[23,9]   R812      1
    w[23,9]   R813      1
    w[23,9]   normalized_inventory_23  -9
    w[23,10]  mass_23   1
    w[23,10]  R814      1
    w[23,10]  R815      1
    w[23,10]  normalized_inventory_23  -10
    w[23,11]  mass_23   1
    w[23,11]  R816      1
    w[23,11]  R817      1
    w[23,11]  normalized_inventory_23  -11
    w[24,0]   mass_24   1
    w[24,0]   R822      1
    w[24,0]   R823      1
    w[24,1]   mass_24   1
    w[24,1]   R824      1
    w[24,1]   R825      1
    w[24,1]   normalized_inventory_24  -1
    w[24,2]   mass_24   1
    w[24,2]   R826      1
    w[24,2]   R827      1
    w[24,2]   normalized_inventory_24  -2
    w[24,3]   mass_24   1
    w[24,3]   R828      1
    w[24,3]   R829      1
    w[24,3]   normalized_inventory_24  -3
    w[24,4]   mass_24   1
    w[24,4]   R830      1
    w[24,4]   R831      1
    w[24,4]   normalized_inventory_24  -4
    w[24,5]   mass_24   1
    w[24,5]   R832      1
    w[24,5]   R833      1
    w[24,5]   normalized_inventory_24  -5
    w[24,6]   mass_24   1
    w[24,6]   R834      1
    w[24,6]   R835      1
    w[24,6]   normalized_inventory_24  -6
    w[24,7]   mass_24   1
    w[24,7]   R836      1
    w[24,7]   R837      1
    w[24,7]   normalized_inventory_24  -7
    w[24,8]   mass_24   1
    w[24,8]   R838      1
    w[24,8]   R839      1
    w[24,8]   normalized_inventory_24  -8
    w[24,9]   mass_24   1
    w[24,9]   R840      1
    w[24,9]   R841      1
    w[24,9]   normalized_inventory_24  -9
    w[24,10]  mass_24   1
    w[24,10]  R842      1
    w[24,10]  R843      1
    w[24,10]  normalized_inventory_24  -10
    w[24,11]  mass_24   1
    w[24,11]  R844      1
    w[24,11]  R845      1
    w[24,11]  normalized_inventory_24  -11
    w[24,12]  mass_24   1
    w[24,12]  R846      1
    w[24,12]  R847      1
    w[24,12]  normalized_inventory_24  -12
    w[24,13]  mass_24   1
    w[24,13]  R848      1
    w[24,13]  R849      1
    w[24,13]  normalized_inventory_24  -13
    w[24,14]  mass_24   1
    w[24,14]  R850      1
    w[24,14]  R851      1
    w[24,14]  normalized_inventory_24  -14
    w[24,15]  mass_24   1
    w[24,15]  R852      1
    w[24,15]  R853      1
    w[24,15]  normalized_inventory_24  -15
    w[25,0]   mass_25   1
    w[25,0]   R858      1
    w[25,0]   R859      1
    w[25,1]   mass_25   1
    w[25,1]   R860      1
    w[25,1]   R861      1
    w[25,1]   normalized_inventory_25  -1
    w[25,2]   mass_25   1
    w[25,2]   R862      1
    w[25,2]   R863      1
    w[25,2]   normalized_inventory_25  -2
    w[25,3]   mass_25   1
    w[25,3]   R864      1
    w[25,3]   R865      1
    w[25,3]   normalized_inventory_25  -3
    w[25,4]   mass_25   1
    w[25,4]   R866      1
    w[25,4]   R867      1
    w[25,4]   normalized_inventory_25  -4
    w[25,5]   mass_25   1
    w[25,5]   R868      1
    w[25,5]   R869      1
    w[25,5]   normalized_inventory_25  -5
    w[25,6]   mass_25   1
    w[25,6]   R870      1
    w[25,6]   R871      1
    w[25,6]   normalized_inventory_25  -6
    w[25,7]   mass_25   1
    w[25,7]   R872      1
    w[25,7]   R873      1
    w[25,7]   normalized_inventory_25  -7
    w[25,8]   mass_25   1
    w[25,8]   R874      1
    w[25,8]   R875      1
    w[25,8]   normalized_inventory_25  -8
    w[25,9]   mass_25   1
    w[25,9]   R876      1
    w[25,9]   R877      1
    w[25,9]   normalized_inventory_25  -9
    w[25,10]  mass_25   1
    w[25,10]  R878      1
    w[25,10]  R879      1
    w[25,10]  normalized_inventory_25  -10
    w[25,11]  mass_25   1
    w[25,11]  R880      1
    w[25,11]  R881      1
    w[25,11]  normalized_inventory_25  -11
    w[25,12]  mass_25   1
    w[25,12]  R882      1
    w[25,12]  R883      1
    w[25,12]  normalized_inventory_25  -12
    w[25,13]  mass_25   1
    w[25,13]  R884      1
    w[25,13]  R885      1
    w[25,13]  normalized_inventory_25  -13
    w[25,14]  mass_25   1
    w[25,14]  R886      1
    w[25,14]  R887      1
    w[25,14]  normalized_inventory_25  -14
    w[25,15]  mass_25   1
    w[25,15]  R888      1
    w[25,15]  R889      1
    w[25,15]  normalized_inventory_25  -15
    w[26,0]   mass_26   1
    w[26,0]   R894      1
    w[26,0]   R895      1
    w[26,1]   mass_26   1
    w[26,1]   R896      1
    w[26,1]   R897      1
    w[26,1]   normalized_inventory_26  -1
    w[26,2]   mass_26   1
    w[26,2]   R898      1
    w[26,2]   R899      1
    w[26,2]   normalized_inventory_26  -2
    w[26,3]   mass_26   1
    w[26,3]   R900      1
    w[26,3]   R901      1
    w[26,3]   normalized_inventory_26  -3
    w[26,4]   mass_26   1
    w[26,4]   R902      1
    w[26,4]   R903      1
    w[26,4]   normalized_inventory_26  -4
    w[26,5]   mass_26   1
    w[26,5]   R904      1
    w[26,5]   R905      1
    w[26,5]   normalized_inventory_26  -5
    w[26,6]   mass_26   1
    w[26,6]   R906      1
    w[26,6]   R907      1
    w[26,6]   normalized_inventory_26  -6
    w[26,7]   mass_26   1
    w[26,7]   R908      1
    w[26,7]   R909      1
    w[26,7]   normalized_inventory_26  -7
    w[26,8]   mass_26   1
    w[26,8]   R910      1
    w[26,8]   R911      1
    w[26,8]   normalized_inventory_26  -8
    w[27,0]   mass_27   1
    w[27,0]   R916      1
    w[27,0]   R917      1
    w[27,1]   mass_27   1
    w[27,1]   R918      1
    w[27,1]   R919      1
    w[27,1]   normalized_inventory_27  -1
    w[27,2]   mass_27   1
    w[27,2]   R920      1
    w[27,2]   R921      1
    w[27,2]   normalized_inventory_27  -2
    w[27,3]   mass_27   1
    w[27,3]   R922      1
    w[27,3]   R923      1
    w[27,3]   normalized_inventory_27  -3
    w[27,4]   mass_27   1
    w[27,4]   R924      1
    w[27,4]   R925      1
    w[27,4]   normalized_inventory_27  -4
    w[27,5]   mass_27   1
    w[27,5]   R926      1
    w[27,5]   R927      1
    w[27,5]   normalized_inventory_27  -5
    w[27,6]   mass_27   1
    w[27,6]   R928      1
    w[27,6]   R929      1
    w[27,6]   normalized_inventory_27  -6
    w[27,7]   mass_27   1
    w[27,7]   R930      1
    w[27,7]   R931      1
    w[27,7]   normalized_inventory_27  -7
    w[27,8]   mass_27   1
    w[27,8]   R932      1
    w[27,8]   R933      1
    w[27,8]   normalized_inventory_27  -8
    w[27,9]   mass_27   1
    w[27,9]   R934      1
    w[27,9]   R935      1
    w[27,9]   normalized_inventory_27  -9
    w[27,10]  mass_27   1
    w[27,10]  R936      1
    w[27,10]  R937      1
    w[27,10]  normalized_inventory_27  -10
    w[27,11]  mass_27   1
    w[27,11]  R938      1
    w[27,11]  R939      1
    w[27,11]  normalized_inventory_27  -11
    w[27,12]  mass_27   1
    w[27,12]  R940      1
    w[27,12]  R941      1
    w[27,12]  normalized_inventory_27  -12
    w[27,13]  mass_27   1
    w[27,13]  R942      1
    w[27,13]  R943      1
    w[27,13]  normalized_inventory_27  -13
    w[27,14]  mass_27   1
    w[27,14]  R944      1
    w[27,14]  R945      1
    w[27,14]  normalized_inventory_27  -14
    w[27,15]  mass_27   1
    w[27,15]  R946      1
    w[27,15]  R947      1
    w[27,15]  normalized_inventory_27  -15
    w[28,0]   mass_28   1
    w[28,0]   R952      1
    w[28,0]   R953      1
    w[28,1]   mass_28   1
    w[28,1]   R954      1
    w[28,1]   R955      1
    w[28,1]   normalized_inventory_28  -1
    w[28,2]   mass_28   1
    w[28,2]   R956      1
    w[28,2]   R957      1
    w[28,2]   normalized_inventory_28  -2
    w[28,3]   mass_28   1
    w[28,3]   R958      1
    w[28,3]   R959      1
    w[28,3]   normalized_inventory_28  -3
    w[28,4]   mass_28   1
    w[28,4]   R960      1
    w[28,4]   R961      1
    w[28,4]   normalized_inventory_28  -4
    w[28,5]   mass_28   1
    w[28,5]   R962      1
    w[28,5]   R963      1
    w[28,5]   normalized_inventory_28  -5
    w[28,6]   mass_28   1
    w[28,6]   R964      1
    w[28,6]   R965      1
    w[28,6]   normalized_inventory_28  -6
    w[28,7]   mass_28   1
    w[28,7]   R966      1
    w[28,7]   R967      1
    w[28,7]   normalized_inventory_28  -7
    w[28,8]   mass_28   1
    w[28,8]   R968      1
    w[28,8]   R969      1
    w[28,8]   normalized_inventory_28  -8
    w[28,9]   mass_28   1
    w[28,9]   R970      1
    w[28,9]   R971      1
    w[28,9]   normalized_inventory_28  -9
    w[28,10]  mass_28   1
    w[28,10]  R972      1
    w[28,10]  R973      1
    w[28,10]  normalized_inventory_28  -10
    w[28,11]  mass_28   1
    w[28,11]  R974      1
    w[28,11]  R975      1
    w[28,11]  normalized_inventory_28  -11
    w[28,12]  mass_28   1
    w[28,12]  R976      1
    w[28,12]  R977      1
    w[28,12]  normalized_inventory_28  -12
    w[28,13]  mass_28   1
    w[28,13]  R978      1
    w[28,13]  R979      1
    w[28,13]  normalized_inventory_28  -13
    w[28,14]  mass_28   1
    w[28,14]  R980      1
    w[28,14]  R981      1
    w[28,14]  normalized_inventory_28  -14
    w[28,15]  mass_28   1
    w[28,15]  R982      1
    w[28,15]  R983      1
    w[28,15]  normalized_inventory_28  -15
    w[28,16]  mass_28   1
    w[28,16]  R984      1
    w[28,16]  R985      1
    w[28,16]  normalized_inventory_28  -16
    w[28,17]  mass_28   1
    w[28,17]  R986      1
    w[28,17]  R987      1
    w[28,17]  normalized_inventory_28  -17
    w[28,18]  mass_28   1
    w[28,18]  R988      1
    w[28,18]  R989      1
    w[28,18]  normalized_inventory_28  -18
    w[28,19]  mass_28   1
    w[28,19]  R990      1
    w[28,19]  R991      1
    w[28,19]  normalized_inventory_28  -19
    w[29,0]   mass_29   1
    w[29,0]   R996      1
    w[29,0]   R997      1
    w[29,1]   mass_29   1
    w[29,1]   R998      1
    w[29,1]   R999      1
    w[29,1]   normalized_inventory_29  -1
    w[29,2]   mass_29   1
    w[29,2]   R1000     1
    w[29,2]   R1001     1
    w[29,2]   normalized_inventory_29  -2
    w[29,3]   mass_29   1
    w[29,3]   R1002     1
    w[29,3]   R1003     1
    w[29,3]   normalized_inventory_29  -3
    w[29,4]   mass_29   1
    w[29,4]   R1004     1
    w[29,4]   R1005     1
    w[29,4]   normalized_inventory_29  -4
    w[29,5]   mass_29   1
    w[29,5]   R1006     1
    w[29,5]   R1007     1
    w[29,5]   normalized_inventory_29  -5
    w[29,6]   mass_29   1
    w[29,6]   R1008     1
    w[29,6]   R1009     1
    w[29,6]   normalized_inventory_29  -6
    w[29,7]   mass_29   1
    w[29,7]   R1010     1
    w[29,7]   R1011     1
    w[29,7]   normalized_inventory_29  -7
    w[29,8]   mass_29   1
    w[29,8]   R1012     1
    w[29,8]   R1013     1
    w[29,8]   normalized_inventory_29  -8
    w[29,9]   mass_29   1
    w[29,9]   R1014     1
    w[29,9]   R1015     1
    w[29,9]   normalized_inventory_29  -9
    w[29,10]  mass_29   1
    w[29,10]  R1016     1
    w[29,10]  R1017     1
    w[29,10]  normalized_inventory_29  -10
    w[29,11]  mass_29   1
    w[29,11]  R1018     1
    w[29,11]  R1019     1
    w[29,11]  normalized_inventory_29  -11
    w[29,12]  mass_29   1
    w[29,12]  R1020     1
    w[29,12]  R1021     1
    w[29,12]  normalized_inventory_29  -12
    w[29,13]  mass_29   1
    w[29,13]  R1022     1
    w[29,13]  R1023     1
    w[29,13]  normalized_inventory_29  -13
    w[29,14]  mass_29   1
    w[29,14]  R1024     1
    w[29,14]  R1025     1
    w[29,14]  normalized_inventory_29  -14
    w[29,15]  mass_29   1
    w[29,15]  R1026     1
    w[29,15]  R1027     1
    w[29,15]  normalized_inventory_29  -15
    w[30,0]   mass_30   1
    w[30,0]   R1032     1
    w[30,0]   R1033     1
    w[30,1]   mass_30   1
    w[30,1]   R1034     1
    w[30,1]   R1035     1
    w[30,1]   normalized_inventory_30  -1
    w[30,2]   mass_30   1
    w[30,2]   R1036     1
    w[30,2]   R1037     1
    w[30,2]   normalized_inventory_30  -2
    w[30,3]   mass_30   1
    w[30,3]   R1038     1
    w[30,3]   R1039     1
    w[30,3]   normalized_inventory_30  -3
    w[30,4]   mass_30   1
    w[30,4]   R1040     1
    w[30,4]   R1041     1
    w[30,4]   normalized_inventory_30  -4
    w[30,5]   mass_30   1
    w[30,5]   R1042     1
    w[30,5]   R1043     1
    w[30,5]   normalized_inventory_30  -5
    w[30,6]   mass_30   1
    w[30,6]   R1044     1
    w[30,6]   R1045     1
    w[30,6]   normalized_inventory_30  -6
    w[30,7]   mass_30   1
    w[30,7]   R1046     1
    w[30,7]   R1047     1
    w[30,7]   normalized_inventory_30  -7
    w[30,8]   mass_30   1
    w[30,8]   R1048     1
    w[30,8]   R1049     1
    w[30,8]   normalized_inventory_30  -8
    w[31,0]   mass_31   1
    w[31,0]   R1054     1
    w[31,0]   R1055     1
    w[31,1]   mass_31   1
    w[31,1]   R1056     1
    w[31,1]   R1057     1
    w[31,1]   normalized_inventory_31  -1
    w[31,2]   mass_31   1
    w[31,2]   R1058     1
    w[31,2]   R1059     1
    w[31,2]   normalized_inventory_31  -2
    w[31,3]   mass_31   1
    w[31,3]   R1060     1
    w[31,3]   R1061     1
    w[31,3]   normalized_inventory_31  -3
    w[31,4]   mass_31   1
    w[31,4]   R1062     1
    w[31,4]   R1063     1
    w[31,4]   normalized_inventory_31  -4
    w[31,5]   mass_31   1
    w[31,5]   R1064     1
    w[31,5]   R1065     1
    w[31,5]   normalized_inventory_31  -5
    w[31,6]   mass_31   1
    w[31,6]   R1066     1
    w[31,6]   R1067     1
    w[31,6]   normalized_inventory_31  -6
    w[31,7]   mass_31   1
    w[31,7]   R1068     1
    w[31,7]   R1069     1
    w[31,7]   normalized_inventory_31  -7
    w[31,8]   mass_31   1
    w[31,8]   R1070     1
    w[31,8]   R1071     1
    w[31,8]   normalized_inventory_31  -8
    w[31,9]   mass_31   1
    w[31,9]   R1072     1
    w[31,9]   R1073     1
    w[31,9]   normalized_inventory_31  -9
    w[31,10]  mass_31   1
    w[31,10]  R1074     1
    w[31,10]  R1075     1
    w[31,10]  normalized_inventory_31  -10
    w[31,11]  mass_31   1
    w[31,11]  R1076     1
    w[31,11]  R1077     1
    w[31,11]  normalized_inventory_31  -11
    w[31,12]  mass_31   1
    w[31,12]  R1078     1
    w[31,12]  R1079     1
    w[31,12]  normalized_inventory_31  -12
    w[32,0]   mass_32   1
    w[32,0]   R1084     1
    w[32,0]   R1085     1
    w[32,1]   mass_32   1
    w[32,1]   R1086     1
    w[32,1]   R1087     1
    w[32,1]   normalized_inventory_32  -1
    w[32,2]   mass_32   1
    w[32,2]   R1088     1
    w[32,2]   R1089     1
    w[32,2]   normalized_inventory_32  -2
    w[32,3]   mass_32   1
    w[32,3]   R1090     1
    w[32,3]   R1091     1
    w[32,3]   normalized_inventory_32  -3
    w[32,4]   mass_32   1
    w[32,4]   R1092     1
    w[32,4]   R1093     1
    w[32,4]   normalized_inventory_32  -4
    w[32,5]   mass_32   1
    w[32,5]   R1094     1
    w[32,5]   R1095     1
    w[32,5]   normalized_inventory_32  -5
    w[32,6]   mass_32   1
    w[32,6]   R1096     1
    w[32,6]   R1097     1
    w[32,6]   normalized_inventory_32  -6
    w[32,7]   mass_32   1
    w[32,7]   R1098     1
    w[32,7]   R1099     1
    w[32,7]   normalized_inventory_32  -7
    w[32,8]   mass_32   1
    w[32,8]   R1100     1
    w[32,8]   R1101     1
    w[32,8]   normalized_inventory_32  -8
    w[32,9]   mass_32   1
    w[32,9]   R1102     1
    w[32,9]   R1103     1
    w[32,9]   normalized_inventory_32  -9
    w[32,10]  mass_32   1
    w[32,10]  R1104     1
    w[32,10]  R1105     1
    w[32,10]  normalized_inventory_32  -10
    w[32,11]  mass_32   1
    w[32,11]  R1106     1
    w[32,11]  R1107     1
    w[32,11]  normalized_inventory_32  -11
    w[32,12]  mass_32   1
    w[32,12]  R1108     1
    w[32,12]  R1109     1
    w[32,12]  normalized_inventory_32  -12
    w[33,0]   mass_33   1
    w[33,0]   R1114     1
    w[33,0]   R1115     1
    w[33,1]   mass_33   1
    w[33,1]   R1116     1
    w[33,1]   R1117     1
    w[33,1]   normalized_inventory_33  -1
    w[33,2]   mass_33   1
    w[33,2]   R1118     1
    w[33,2]   R1119     1
    w[33,2]   normalized_inventory_33  -2
    w[33,3]   mass_33   1
    w[33,3]   R1120     1
    w[33,3]   R1121     1
    w[33,3]   normalized_inventory_33  -3
    w[33,4]   mass_33   1
    w[33,4]   R1122     1
    w[33,4]   R1123     1
    w[33,4]   normalized_inventory_33  -4
    w[33,5]   mass_33   1
    w[33,5]   R1124     1
    w[33,5]   R1125     1
    w[33,5]   normalized_inventory_33  -5
    w[33,6]   mass_33   1
    w[33,6]   R1126     1
    w[33,6]   R1127     1
    w[33,6]   normalized_inventory_33  -6
    w[33,7]   mass_33   1
    w[33,7]   R1128     1
    w[33,7]   R1129     1
    w[33,7]   normalized_inventory_33  -7
    w[33,8]   mass_33   1
    w[33,8]   R1130     1
    w[33,8]   R1131     1
    w[33,8]   normalized_inventory_33  -8
    w[33,9]   mass_33   1
    w[33,9]   R1132     1
    w[33,9]   R1133     1
    w[33,9]   normalized_inventory_33  -9
    w[33,10]  mass_33   1
    w[33,10]  R1134     1
    w[33,10]  R1135     1
    w[33,10]  normalized_inventory_33  -10
    w[33,11]  mass_33   1
    w[33,11]  R1136     1
    w[33,11]  R1137     1
    w[33,11]  normalized_inventory_33  -11
    w[33,12]  mass_33   1
    w[33,12]  R1138     1
    w[33,12]  R1139     1
    w[33,12]  normalized_inventory_33  -12
    w[33,13]  mass_33   1
    w[33,13]  R1140     1
    w[33,13]  R1141     1
    w[33,13]  normalized_inventory_33  -13
    w[33,14]  mass_33   1
    w[33,14]  R1142     1
    w[33,14]  R1143     1
    w[33,14]  normalized_inventory_33  -14
    w[33,15]  mass_33   1
    w[33,15]  R1144     1
    w[33,15]  R1145     1
    w[33,15]  normalized_inventory_33  -15
    w[33,16]  mass_33   1
    w[33,16]  R1146     1
    w[33,16]  R1147     1
    w[33,16]  normalized_inventory_33  -16
    w[34,0]   mass_34   1
    w[34,0]   R1152     1
    w[34,0]   R1153     1
    w[34,1]   mass_34   1
    w[34,1]   R1154     1
    w[34,1]   R1155     1
    w[34,1]   normalized_inventory_34  -1
    w[34,2]   mass_34   1
    w[34,2]   R1156     1
    w[34,2]   R1157     1
    w[34,2]   normalized_inventory_34  -2
    w[34,3]   mass_34   1
    w[34,3]   R1158     1
    w[34,3]   R1159     1
    w[34,3]   normalized_inventory_34  -3
    w[34,4]   mass_34   1
    w[34,4]   R1160     1
    w[34,4]   R1161     1
    w[34,4]   normalized_inventory_34  -4
    w[34,5]   mass_34   1
    w[34,5]   R1162     1
    w[34,5]   R1163     1
    w[34,5]   normalized_inventory_34  -5
    w[34,6]   mass_34   1
    w[34,6]   R1164     1
    w[34,6]   R1165     1
    w[34,6]   normalized_inventory_34  -6
    w[34,7]   mass_34   1
    w[34,7]   R1166     1
    w[34,7]   R1167     1
    w[34,7]   normalized_inventory_34  -7
    w[34,8]   mass_34   1
    w[34,8]   R1168     1
    w[34,8]   R1169     1
    w[34,8]   normalized_inventory_34  -8
    w[34,9]   mass_34   1
    w[34,9]   R1170     1
    w[34,9]   R1171     1
    w[34,9]   normalized_inventory_34  -9
    w[34,10]  mass_34   1
    w[34,10]  R1172     1
    w[34,10]  R1173     1
    w[34,10]  normalized_inventory_34  -10
    w[34,11]  mass_34   1
    w[34,11]  R1174     1
    w[34,11]  R1175     1
    w[34,11]  normalized_inventory_34  -11
    w[35,0]   mass_35   1
    w[35,0]   R1180     1
    w[35,0]   R1181     1
    w[35,1]   mass_35   1
    w[35,1]   R1182     1
    w[35,1]   R1183     1
    w[35,1]   normalized_inventory_35  -1
    w[35,2]   mass_35   1
    w[35,2]   R1184     1
    w[35,2]   R1185     1
    w[35,2]   normalized_inventory_35  -2
    w[35,3]   mass_35   1
    w[35,3]   R1186     1
    w[35,3]   R1187     1
    w[35,3]   normalized_inventory_35  -3
    w[35,4]   mass_35   1
    w[35,4]   R1188     1
    w[35,4]   R1189     1
    w[35,4]   normalized_inventory_35  -4
    w[35,5]   mass_35   1
    w[35,5]   R1190     1
    w[35,5]   R1191     1
    w[35,5]   normalized_inventory_35  -5
    w[35,6]   mass_35   1
    w[35,6]   R1192     1
    w[35,6]   R1193     1
    w[35,6]   normalized_inventory_35  -6
    w[35,7]   mass_35   1
    w[35,7]   R1194     1
    w[35,7]   R1195     1
    w[35,7]   normalized_inventory_35  -7
    w[35,8]   mass_35   1
    w[35,8]   R1196     1
    w[35,8]   R1197     1
    w[35,8]   normalized_inventory_35  -8
    w[35,9]   mass_35   1
    w[35,9]   R1198     1
    w[35,9]   R1199     1
    w[35,9]   normalized_inventory_35  -9
    w[35,10]  mass_35   1
    w[35,10]  R1200     1
    w[35,10]  R1201     1
    w[35,10]  normalized_inventory_35  -10
    w[35,11]  mass_35   1
    w[35,11]  R1202     1
    w[35,11]  R1203     1
    w[35,11]  normalized_inventory_35  -11
    w[35,12]  mass_35   1
    w[35,12]  R1204     1
    w[35,12]  R1205     1
    w[35,12]  normalized_inventory_35  -12
    w[35,13]  mass_35   1
    w[35,13]  R1206     1
    w[35,13]  R1207     1
    w[35,13]  normalized_inventory_35  -13
    w[35,14]  mass_35   1
    w[35,14]  R1208     1
    w[35,14]  R1209     1
    w[35,14]  normalized_inventory_35  -14
    w[35,15]  mass_35   1
    w[35,15]  R1210     1
    w[35,15]  R1211     1
    w[35,15]  normalized_inventory_35  -15
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         mass_21   -1
    t         mass_22   -1
    t         mass_23   -1
    t         mass_24   -1
    t         mass_25   -1
    t         mass_26   -1
    t         mass_27   -1
    t         mass_28   -1
    t         mass_29   -1
    t         mass_30   -1
    t         mass_31   -1
    t         mass_32   -1
    t         mass_33   -1
    t         mass_34   -1
    t         mass_35   -1
    t         scaled_stock_lower  -136
    t         scaled_stock_upper  -211
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -0.1
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -1.4285714285714285e-01
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -0.125
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -1.4285714285714285e-01
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -0.125
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -0.2
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -0.125
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -0.1
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -0.2
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -0.1
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -0.2
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -1.4285714285714285e-01
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -0.125
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -0.125
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -1.1111111111111110e-01
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -1.6666666666666666e-01
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -1.1111111111111110e-01
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -1.1111111111111110e-01
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -0.25
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -1.6666666666666666e-01
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    z[21]     normalized_inventory_21  1
    z[21]     normalized_ratio_21  -0.125
    z[21]     scaled_stock_lower  1
    z[21]     scaled_stock_upper  1
    z[22]     normalized_inventory_22  1
    z[22]     normalized_ratio_22  -1.6666666666666666e-01
    z[22]     scaled_stock_lower  1
    z[22]     scaled_stock_upper  1
    z[23]     normalized_inventory_23  1
    z[23]     normalized_ratio_23  -0.2
    z[23]     scaled_stock_lower  1
    z[23]     scaled_stock_upper  1
    z[24]     normalized_inventory_24  1
    z[24]     normalized_ratio_24  -0.125
    z[24]     scaled_stock_lower  1
    z[24]     scaled_stock_upper  1
    z[25]     normalized_inventory_25  1
    z[25]     normalized_ratio_25  -1.4285714285714285e-01
    z[25]     scaled_stock_lower  1
    z[25]     scaled_stock_upper  1
    z[26]     normalized_inventory_26  1
    z[26]     normalized_ratio_26  -0.25
    z[26]     scaled_stock_lower  1
    z[26]     scaled_stock_upper  1
    z[27]     normalized_inventory_27  1
    z[27]     normalized_ratio_27  -1.4285714285714285e-01
    z[27]     scaled_stock_lower  1
    z[27]     scaled_stock_upper  1
    z[28]     normalized_inventory_28  1
    z[28]     normalized_ratio_28  -0.125
    z[28]     scaled_stock_lower  1
    z[28]     scaled_stock_upper  1
    z[29]     normalized_inventory_29  1
    z[29]     normalized_ratio_29  -0.125
    z[29]     scaled_stock_lower  1
    z[29]     scaled_stock_upper  1
    z[30]     normalized_inventory_30  1
    z[30]     normalized_ratio_30  -0.25
    z[30]     scaled_stock_lower  1
    z[30]     scaled_stock_upper  1
    z[31]     normalized_inventory_31  1
    z[31]     normalized_ratio_31  -1.4285714285714285e-01
    z[31]     scaled_stock_lower  1
    z[31]     scaled_stock_upper  1
    z[32]     normalized_inventory_32  1
    z[32]     normalized_ratio_32  -0.2
    z[32]     scaled_stock_lower  1
    z[32]     scaled_stock_upper  1
    z[33]     normalized_inventory_33  1
    z[33]     normalized_ratio_33  -1.4285714285714285e-01
    z[33]     scaled_stock_lower  1
    z[33]     scaled_stock_upper  1
    z[34]     normalized_inventory_34  1
    z[34]     normalized_ratio_34  -0.2
    z[34]     scaled_stock_lower  1
    z[34]     scaled_stock_upper  1
    z[35]     normalized_inventory_35  1
    z[35]     normalized_ratio_35  -0.125
    z[35]     scaled_stock_lower  1
    z[35]     scaled_stock_upper  1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      R1219     -1
    r[1]      R1220     1
    r[1]      R1221     -1
    r[1]      R1222     1
    r[1]      R1223     -1
    r[1]      R1224     1
    r[1]      R1225     -1
    r[1]      R1226     1
    r[1]      R1227     -1
    r[1]      R1228     1
    r[1]      R1229     -1
    r[1]      R1230     1
    r[1]      R1231     -1
    r[1]      R1232     1
    r[1]      R1233     -1
    r[1]      R1234     1
    r[1]      R1235     -1
    r[1]      R1236     1
    r[1]      R1237     -1
    r[1]      R1238     1
    r[1]      R1239     -1
    r[1]      R1240     1
    r[1]      R1241     -1
    r[1]      R1242     1
    r[1]      R1243     -1
    r[1]      R1244     1
    r[1]      R1245     -1
    r[1]      R1246     1
    r[1]      R1247     -1
    r[1]      R1248     1
    r[1]      R1249     -1
    r[1]      R1250     1
    r[1]      R1251     -1
    r[1]      R1252     1
    r[1]      R1253     -1
    r[1]      R1254     1
    r[1]      R1255     -1
    r[1]      R1256     1
    r[1]      R1257     -1
    r[1]      R1258     1
    r[1]      R1259     -1
    r[1]      R1260     1
    r[1]      R1261     -1
    r[1]      R1262     1
    r[1]      R1263     -1
    r[1]      R1264     1
    r[1]      R1265     -1
    r[1]      R1266     1
    r[1]      R1267     -1
    r[1]      R1268     1
    r[1]      R1269     -1
    r[1]      R1270     1
    r[1]      R1271     -1
    r[1]      R1272     1
    r[1]      R1273     -1
    r[1]      R1274     1
    r[1]      R1275     -1
    r[1]      R1276     1
    r[1]      R1277     -1
    r[1]      R1278     1
    r[1]      R1279     -1
    r[1]      R1280     1
    r[1]      R1281     -1
    r[1]      R1282     1
    r[1]      R1283     -1
    r[1]      R1284     1
    r[1]      R1285     -1
    r[1]      R1286     1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      R1219     1
    r[2]      R1220     -1
    r[2]      R1287     -1
    r[2]      R1288     1
    r[2]      R1289     -1
    r[2]      R1290     1
    r[2]      R1291     -1
    r[2]      R1292     1
    r[2]      R1293     -1
    r[2]      R1294     1
    r[2]      R1295     -1
    r[2]      R1296     1
    r[2]      R1297     -1
    r[2]      R1298     1
    r[2]      R1299     -1
    r[2]      R1300     1
    r[2]      R1301     -1
    r[2]      R1302     1
    r[2]      R1303     -1
    r[2]      R1304     1
    r[2]      R1305     -1
    r[2]      R1306     1
    r[2]      R1307     -1
    r[2]      R1308     1
    r[2]      R1309     -1
    r[2]      R1310     1
    r[2]      R1311     -1
    r[2]      R1312     1
    r[2]      R1313     -1
    r[2]      R1314     1
    r[2]      R1315     -1
    r[2]      R1316     1
    r[2]      R1317     -1
    r[2]      R1318     1
    r[2]      R1319     -1
    r[2]      R1320     1
    r[2]      R1321     -1
    r[2]      R1322     1
    r[2]      R1323     -1
    r[2]      R1324     1
    r[2]      R1325     -1
    r[2]      R1326     1
    r[2]      R1327     -1
    r[2]      R1328     1
    r[2]      R1329     -1
    r[2]      R1330     1
    r[2]      R1331     -1
    r[2]      R1332     1
    r[2]      R1333     -1
    r[2]      R1334     1
    r[2]      R1335     -1
    r[2]      R1336     1
    r[2]      R1337     -1
    r[2]      R1338     1
    r[2]      R1339     -1
    r[2]      R1340     1
    r[2]      R1341     -1
    r[2]      R1342     1
    r[2]      R1343     -1
    r[2]      R1344     1
    r[2]      R1345     -1
    r[2]      R1346     1
    r[2]      R1347     -1
    r[2]      R1348     1
    r[2]      R1349     -1
    r[2]      R1350     1
    r[2]      R1351     -1
    r[2]      R1352     1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      R1221     1
    r[3]      R1222     -1
    r[3]      R1287     1
    r[3]      R1288     -1
    r[3]      R1353     -1
    r[3]      R1354     1
    r[3]      R1355     -1
    r[3]      R1356     1
    r[3]      R1357     -1
    r[3]      R1358     1
    r[3]      R1359     -1
    r[3]      R1360     1
    r[3]      R1361     -1
    r[3]      R1362     1
    r[3]      R1363     -1
    r[3]      R1364     1
    r[3]      R1365     -1
    r[3]      R1366     1
    r[3]      R1367     -1
    r[3]      R1368     1
    r[3]      R1369     -1
    r[3]      R1370     1
    r[3]      R1371     -1
    r[3]      R1372     1
    r[3]      R1373     -1
    r[3]      R1374     1
    r[3]      R1375     -1
    r[3]      R1376     1
    r[3]      R1377     -1
    r[3]      R1378     1
    r[3]      R1379     -1
    r[3]      R1380     1
    r[3]      R1381     -1
    r[3]      R1382     1
    r[3]      R1383     -1
    r[3]      R1384     1
    r[3]      R1385     -1
    r[3]      R1386     1
    r[3]      R1387     -1
    r[3]      R1388     1
    r[3]      R1389     -1
    r[3]      R1390     1
    r[3]      R1391     -1
    r[3]      R1392     1
    r[3]      R1393     -1
    r[3]      R1394     1
    r[3]      R1395     -1
    r[3]      R1396     1
    r[3]      R1397     -1
    r[3]      R1398     1
    r[3]      R1399     -1
    r[3]      R1400     1
    r[3]      R1401     -1
    r[3]      R1402     1
    r[3]      R1403     -1
    r[3]      R1404     1
    r[3]      R1405     -1
    r[3]      R1406     1
    r[3]      R1407     -1
    r[3]      R1408     1
    r[3]      R1409     -1
    r[3]      R1410     1
    r[3]      R1411     -1
    r[3]      R1412     1
    r[3]      R1413     -1
    r[3]      R1414     1
    r[3]      R1415     -1
    r[3]      R1416     1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      R1223     1
    r[4]      R1224     -1
    r[4]      R1289     1
    r[4]      R1290     -1
    r[4]      R1353     1
    r[4]      R1354     -1
    r[4]      R1417     -1
    r[4]      R1418     1
    r[4]      R1419     -1
    r[4]      R1420     1
    r[4]      R1421     -1
    r[4]      R1422     1
    r[4]      R1423     -1
    r[4]      R1424     1
    r[4]      R1425     -1
    r[4]      R1426     1
    r[4]      R1427     -1
    r[4]      R1428     1
    r[4]      R1429     -1
    r[4]      R1430     1
    r[4]      R1431     -1
    r[4]      R1432     1
    r[4]      R1433     -1
    r[4]      R1434     1
    r[4]      R1435     -1
    r[4]      R1436     1
    r[4]      R1437     -1
    r[4]      R1438     1
    r[4]      R1439     -1
    r[4]      R1440     1
    r[4]      R1441     -1
    r[4]      R1442     1
    r[4]      R1443     -1
    r[4]      R1444     1
    r[4]      R1445     -1
    r[4]      R1446     1
    r[4]      R1447     -1
    r[4]      R1448     1
    r[4]      R1449     -1
    r[4]      R1450     1
    r[4]      R1451     -1
    r[4]      R1452     1
    r[4]      R1453     -1
    r[4]      R1454     1
    r[4]      R1455     -1
    r[4]      R1456     1
    r[4]      R1457     -1
    r[4]      R1458     1
    r[4]      R1459     -1
    r[4]      R1460     1
    r[4]      R1461     -1
    r[4]      R1462     1
    r[4]      R1463     -1
    r[4]      R1464     1
    r[4]      R1465     -1
    r[4]      R1466     1
    r[4]      R1467     -1
    r[4]      R1468     1
    r[4]      R1469     -1
    r[4]      R1470     1
    r[4]      R1471     -1
    r[4]      R1472     1
    r[4]      R1473     -1
    r[4]      R1474     1
    r[4]      R1475     -1
    r[4]      R1476     1
    r[4]      R1477     -1
    r[4]      R1478     1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      R1225     1
    r[5]      R1226     -1
    r[5]      R1291     1
    r[5]      R1292     -1
    r[5]      R1355     1
    r[5]      R1356     -1
    r[5]      R1417     1
    r[5]      R1418     -1
    r[5]      R1479     -1
    r[5]      R1480     1
    r[5]      R1481     -1
    r[5]      R1482     1
    r[5]      R1483     -1
    r[5]      R1484     1
    r[5]      R1485     -1
    r[5]      R1486     1
    r[5]      R1487     -1
    r[5]      R1488     1
    r[5]      R1489     -1
    r[5]      R1490     1
    r[5]      R1491     -1
    r[5]      R1492     1
    r[5]      R1493     -1
    r[5]      R1494     1
    r[5]      R1495     -1
    r[5]      R1496     1
    r[5]      R1497     -1
    r[5]      R1498     1
    r[5]      R1499     -1
    r[5]      R1500     1
    r[5]      R1501     -1
    r[5]      R1502     1
    r[5]      R1503     -1
    r[5]      R1504     1
    r[5]      R1505     -1
    r[5]      R1506     1
    r[5]      R1507     -1
    r[5]      R1508     1
    r[5]      R1509     -1
    r[5]      R1510     1
    r[5]      R1511     -1
    r[5]      R1512     1
    r[5]      R1513     -1
    r[5]      R1514     1
    r[5]      R1515     -1
    r[5]      R1516     1
    r[5]      R1517     -1
    r[5]      R1518     1
    r[5]      R1519     -1
    r[5]      R1520     1
    r[5]      R1521     -1
    r[5]      R1522     1
    r[5]      R1523     -1
    r[5]      R1524     1
    r[5]      R1525     -1
    r[5]      R1526     1
    r[5]      R1527     -1
    r[5]      R1528     1
    r[5]      R1529     -1
    r[5]      R1530     1
    r[5]      R1531     -1
    r[5]      R1532     1
    r[5]      R1533     -1
    r[5]      R1534     1
    r[5]      R1535     -1
    r[5]      R1536     1
    r[5]      R1537     -1
    r[5]      R1538     1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      R1227     1
    r[6]      R1228     -1
    r[6]      R1293     1
    r[6]      R1294     -1
    r[6]      R1357     1
    r[6]      R1358     -1
    r[6]      R1419     1
    r[6]      R1420     -1
    r[6]      R1479     1
    r[6]      R1480     -1
    r[6]      R1539     -1
    r[6]      R1540     1
    r[6]      R1541     -1
    r[6]      R1542     1
    r[6]      R1543     -1
    r[6]      R1544     1
    r[6]      R1545     -1
    r[6]      R1546     1
    r[6]      R1547     -1
    r[6]      R1548     1
    r[6]      R1549     -1
    r[6]      R1550     1
    r[6]      R1551     -1
    r[6]      R1552     1
    r[6]      R1553     -1
    r[6]      R1554     1
    r[6]      R1555     -1
    r[6]      R1556     1
    r[6]      R1557     -1
    r[6]      R1558     1
    r[6]      R1559     -1
    r[6]      R1560     1
    r[6]      R1561     -1
    r[6]      R1562     1
    r[6]      R1563     -1
    r[6]      R1564     1
    r[6]      R1565     -1
    r[6]      R1566     1
    r[6]      R1567     -1
    r[6]      R1568     1
    r[6]      R1569     -1
    r[6]      R1570     1
    r[6]      R1571     -1
    r[6]      R1572     1
    r[6]      R1573     -1
    r[6]      R1574     1
    r[6]      R1575     -1
    r[6]      R1576     1
    r[6]      R1577     -1
    r[6]      R1578     1
    r[6]      R1579     -1
    r[6]      R1580     1
    r[6]      R1581     -1
    r[6]      R1582     1
    r[6]      R1583     -1
    r[6]      R1584     1
    r[6]      R1585     -1
    r[6]      R1586     1
    r[6]      R1587     -1
    r[6]      R1588     1
    r[6]      R1589     -1
    r[6]      R1590     1
    r[6]      R1591     -1
    r[6]      R1592     1
    r[6]      R1593     -1
    r[6]      R1594     1
    r[6]      R1595     -1
    r[6]      R1596     1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      R1229     1
    r[7]      R1230     -1
    r[7]      R1295     1
    r[7]      R1296     -1
    r[7]      R1359     1
    r[7]      R1360     -1
    r[7]      R1421     1
    r[7]      R1422     -1
    r[7]      R1481     1
    r[7]      R1482     -1
    r[7]      R1539     1
    r[7]      R1540     -1
    r[7]      R1597     -1
    r[7]      R1598     1
    r[7]      R1599     -1
    r[7]      R1600     1
    r[7]      R1601     -1
    r[7]      R1602     1
    r[7]      R1603     -1
    r[7]      R1604     1
    r[7]      R1605     -1
    r[7]      R1606     1
    r[7]      R1607     -1
    r[7]      R1608     1
    r[7]      R1609     -1
    r[7]      R1610     1
    r[7]      R1611     -1
    r[7]      R1612     1
    r[7]      R1613     -1
    r[7]      R1614     1
    r[7]      R1615     -1
    r[7]      R1616     1
    r[7]      R1617     -1
    r[7]      R1618     1
    r[7]      R1619     -1
    r[7]      R1620     1
    r[7]      R1621     -1
    r[7]      R1622     1
    r[7]      R1623     -1
    r[7]      R1624     1
    r[7]      R1625     -1
    r[7]      R1626     1
    r[7]      R1627     -1
    r[7]      R1628     1
    r[7]      R1629     -1
    r[7]      R1630     1
    r[7]      R1631     -1
    r[7]      R1632     1
    r[7]      R1633     -1
    r[7]      R1634     1
    r[7]      R1635     -1
    r[7]      R1636     1
    r[7]      R1637     -1
    r[7]      R1638     1
    r[7]      R1639     -1
    r[7]      R1640     1
    r[7]      R1641     -1
    r[7]      R1642     1
    r[7]      R1643     -1
    r[7]      R1644     1
    r[7]      R1645     -1
    r[7]      R1646     1
    r[7]      R1647     -1
    r[7]      R1648     1
    r[7]      R1649     -1
    r[7]      R1650     1
    r[7]      R1651     -1
    r[7]      R1652     1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      R1231     1
    r[8]      R1232     -1
    r[8]      R1297     1
    r[8]      R1298     -1
    r[8]      R1361     1
    r[8]      R1362     -1
    r[8]      R1423     1
    r[8]      R1424     -1
    r[8]      R1483     1
    r[8]      R1484     -1
    r[8]      R1541     1
    r[8]      R1542     -1
    r[8]      R1597     1
    r[8]      R1598     -1
    r[8]      R1653     -1
    r[8]      R1654     1
    r[8]      R1655     -1
    r[8]      R1656     1
    r[8]      R1657     -1
    r[8]      R1658     1
    r[8]      R1659     -1
    r[8]      R1660     1
    r[8]      R1661     -1
    r[8]      R1662     1
    r[8]      R1663     -1
    r[8]      R1664     1
    r[8]      R1665     -1
    r[8]      R1666     1
    r[8]      R1667     -1
    r[8]      R1668     1
    r[8]      R1669     -1
    r[8]      R1670     1
    r[8]      R1671     -1
    r[8]      R1672     1
    r[8]      R1673     -1
    r[8]      R1674     1
    r[8]      R1675     -1
    r[8]      R1676     1
    r[8]      R1677     -1
    r[8]      R1678     1
    r[8]      R1679     -1
    r[8]      R1680     1
    r[8]      R1681     -1
    r[8]      R1682     1
    r[8]      R1683     -1
    r[8]      R1684     1
    r[8]      R1685     -1
    r[8]      R1686     1
    r[8]      R1687     -1
    r[8]      R1688     1
    r[8]      R1689     -1
    r[8]      R1690     1
    r[8]      R1691     -1
    r[8]      R1692     1
    r[8]      R1693     -1
    r[8]      R1694     1
    r[8]      R1695     -1
    r[8]      R1696     1
    r[8]      R1697     -1
    r[8]      R1698     1
    r[8]      R1699     -1
    r[8]      R1700     1
    r[8]      R1701     -1
    r[8]      R1702     1
    r[8]      R1703     -1
    r[8]      R1704     1
    r[8]      R1705     -1
    r[8]      R1706     1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      R1233     1
    r[9]      R1234     -1
    r[9]      R1299     1
    r[9]      R1300     -1
    r[9]      R1363     1
    r[9]      R1364     -1
    r[9]      R1425     1
    r[9]      R1426     -1
    r[9]      R1485     1
    r[9]      R1486     -1
    r[9]      R1543     1
    r[9]      R1544     -1
    r[9]      R1599     1
    r[9]      R1600     -1
    r[9]      R1653     1
    r[9]      R1654     -1
    r[9]      R1707     -1
    r[9]      R1708     1
    r[9]      R1709     -1
    r[9]      R1710     1
    r[9]      R1711     -1
    r[9]      R1712     1
    r[9]      R1713     -1
    r[9]      R1714     1
    r[9]      R1715     -1
    r[9]      R1716     1
    r[9]      R1717     -1
    r[9]      R1718     1
    r[9]      R1719     -1
    r[9]      R1720     1
    r[9]      R1721     -1
    r[9]      R1722     1
    r[9]      R1723     -1
    r[9]      R1724     1
    r[9]      R1725     -1
    r[9]      R1726     1
    r[9]      R1727     -1
    r[9]      R1728     1
    r[9]      R1729     -1
    r[9]      R1730     1
    r[9]      R1731     -1
    r[9]      R1732     1
    r[9]      R1733     -1
    r[9]      R1734     1
    r[9]      R1735     -1
    r[9]      R1736     1
    r[9]      R1737     -1
    r[9]      R1738     1
    r[9]      R1739     -1
    r[9]      R1740     1
    r[9]      R1741     -1
    r[9]      R1742     1
    r[9]      R1743     -1
    r[9]      R1744     1
    r[9]      R1745     -1
    r[9]      R1746     1
    r[9]      R1747     -1
    r[9]      R1748     1
    r[9]      R1749     -1
    r[9]      R1750     1
    r[9]      R1751     -1
    r[9]      R1752     1
    r[9]      R1753     -1
    r[9]      R1754     1
    r[9]      R1755     -1
    r[9]      R1756     1
    r[9]      R1757     -1
    r[9]      R1758     1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     R1235     1
    r[10]     R1236     -1
    r[10]     R1301     1
    r[10]     R1302     -1
    r[10]     R1365     1
    r[10]     R1366     -1
    r[10]     R1427     1
    r[10]     R1428     -1
    r[10]     R1487     1
    r[10]     R1488     -1
    r[10]     R1545     1
    r[10]     R1546     -1
    r[10]     R1601     1
    r[10]     R1602     -1
    r[10]     R1655     1
    r[10]     R1656     -1
    r[10]     R1707     1
    r[10]     R1708     -1
    r[10]     R1759     -1
    r[10]     R1760     1
    r[10]     R1761     -1
    r[10]     R1762     1
    r[10]     R1763     -1
    r[10]     R1764     1
    r[10]     R1765     -1
    r[10]     R1766     1
    r[10]     R1767     -1
    r[10]     R1768     1
    r[10]     R1769     -1
    r[10]     R1770     1
    r[10]     R1771     -1
    r[10]     R1772     1
    r[10]     R1773     -1
    r[10]     R1774     1
    r[10]     R1775     -1
    r[10]     R1776     1
    r[10]     R1777     -1
    r[10]     R1778     1
    r[10]     R1779     -1
    r[10]     R1780     1
    r[10]     R1781     -1
    r[10]     R1782     1
    r[10]     R1783     -1
    r[10]     R1784     1
    r[10]     R1785     -1
    r[10]     R1786     1
    r[10]     R1787     -1
    r[10]     R1788     1
    r[10]     R1789     -1
    r[10]     R1790     1
    r[10]     R1791     -1
    r[10]     R1792     1
    r[10]     R1793     -1
    r[10]     R1794     1
    r[10]     R1795     -1
    r[10]     R1796     1
    r[10]     R1797     -1
    r[10]     R1798     1
    r[10]     R1799     -1
    r[10]     R1800     1
    r[10]     R1801     -1
    r[10]     R1802     1
    r[10]     R1803     -1
    r[10]     R1804     1
    r[10]     R1805     -1
    r[10]     R1806     1
    r[10]     R1807     -1
    r[10]     R1808     1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     R1237     1
    r[11]     R1238     -1
    r[11]     R1303     1
    r[11]     R1304     -1
    r[11]     R1367     1
    r[11]     R1368     -1
    r[11]     R1429     1
    r[11]     R1430     -1
    r[11]     R1489     1
    r[11]     R1490     -1
    r[11]     R1547     1
    r[11]     R1548     -1
    r[11]     R1603     1
    r[11]     R1604     -1
    r[11]     R1657     1
    r[11]     R1658     -1
    r[11]     R1709     1
    r[11]     R1710     -1
    r[11]     R1759     1
    r[11]     R1760     -1
    r[11]     R1809     -1
    r[11]     R1810     1
    r[11]     R1811     -1
    r[11]     R1812     1
    r[11]     R1813     -1
    r[11]     R1814     1
    r[11]     R1815     -1
    r[11]     R1816     1
    r[11]     R1817     -1
    r[11]     R1818     1
    r[11]     R1819     -1
    r[11]     R1820     1
    r[11]     R1821     -1
    r[11]     R1822     1
    r[11]     R1823     -1
    r[11]     R1824     1
    r[11]     R1825     -1
    r[11]     R1826     1
    r[11]     R1827     -1
    r[11]     R1828     1
    r[11]     R1829     -1
    r[11]     R1830     1
    r[11]     R1831     -1
    r[11]     R1832     1
    r[11]     R1833     -1
    r[11]     R1834     1
    r[11]     R1835     -1
    r[11]     R1836     1
    r[11]     R1837     -1
    r[11]     R1838     1
    r[11]     R1839     -1
    r[11]     R1840     1
    r[11]     R1841     -1
    r[11]     R1842     1
    r[11]     R1843     -1
    r[11]     R1844     1
    r[11]     R1845     -1
    r[11]     R1846     1
    r[11]     R1847     -1
    r[11]     R1848     1
    r[11]     R1849     -1
    r[11]     R1850     1
    r[11]     R1851     -1
    r[11]     R1852     1
    r[11]     R1853     -1
    r[11]     R1854     1
    r[11]     R1855     -1
    r[11]     R1856     1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     R1239     1
    r[12]     R1240     -1
    r[12]     R1305     1
    r[12]     R1306     -1
    r[12]     R1369     1
    r[12]     R1370     -1
    r[12]     R1431     1
    r[12]     R1432     -1
    r[12]     R1491     1
    r[12]     R1492     -1
    r[12]     R1549     1
    r[12]     R1550     -1
    r[12]     R1605     1
    r[12]     R1606     -1
    r[12]     R1659     1
    r[12]     R1660     -1
    r[12]     R1711     1
    r[12]     R1712     -1
    r[12]     R1761     1
    r[12]     R1762     -1
    r[12]     R1809     1
    r[12]     R1810     -1
    r[12]     R1857     -1
    r[12]     R1858     1
    r[12]     R1859     -1
    r[12]     R1860     1
    r[12]     R1861     -1
    r[12]     R1862     1
    r[12]     R1863     -1
    r[12]     R1864     1
    r[12]     R1865     -1
    r[12]     R1866     1
    r[12]     R1867     -1
    r[12]     R1868     1
    r[12]     R1869     -1
    r[12]     R1870     1
    r[12]     R1871     -1
    r[12]     R1872     1
    r[12]     R1873     -1
    r[12]     R1874     1
    r[12]     R1875     -1
    r[12]     R1876     1
    r[12]     R1877     -1
    r[12]     R1878     1
    r[12]     R1879     -1
    r[12]     R1880     1
    r[12]     R1881     -1
    r[12]     R1882     1
    r[12]     R1883     -1
    r[12]     R1884     1
    r[12]     R1885     -1
    r[12]     R1886     1
    r[12]     R1887     -1
    r[12]     R1888     1
    r[12]     R1889     -1
    r[12]     R1890     1
    r[12]     R1891     -1
    r[12]     R1892     1
    r[12]     R1893     -1
    r[12]     R1894     1
    r[12]     R1895     -1
    r[12]     R1896     1
    r[12]     R1897     -1
    r[12]     R1898     1
    r[12]     R1899     -1
    r[12]     R1900     1
    r[12]     R1901     -1
    r[12]     R1902     1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     R1241     1
    r[13]     R1242     -1
    r[13]     R1307     1
    r[13]     R1308     -1
    r[13]     R1371     1
    r[13]     R1372     -1
    r[13]     R1433     1
    r[13]     R1434     -1
    r[13]     R1493     1
    r[13]     R1494     -1
    r[13]     R1551     1
    r[13]     R1552     -1
    r[13]     R1607     1
    r[13]     R1608     -1
    r[13]     R1661     1
    r[13]     R1662     -1
    r[13]     R1713     1
    r[13]     R1714     -1
    r[13]     R1763     1
    r[13]     R1764     -1
    r[13]     R1811     1
    r[13]     R1812     -1
    r[13]     R1857     1
    r[13]     R1858     -1
    r[13]     R1903     -1
    r[13]     R1904     1
    r[13]     R1905     -1
    r[13]     R1906     1
    r[13]     R1907     -1
    r[13]     R1908     1
    r[13]     R1909     -1
    r[13]     R1910     1
    r[13]     R1911     -1
    r[13]     R1912     1
    r[13]     R1913     -1
    r[13]     R1914     1
    r[13]     R1915     -1
    r[13]     R1916     1
    r[13]     R1917     -1
    r[13]     R1918     1
    r[13]     R1919     -1
    r[13]     R1920     1
    r[13]     R1921     -1
    r[13]     R1922     1
    r[13]     R1923     -1
    r[13]     R1924     1
    r[13]     R1925     -1
    r[13]     R1926     1
    r[13]     R1927     -1
    r[13]     R1928     1
    r[13]     R1929     -1
    r[13]     R1930     1
    r[13]     R1931     -1
    r[13]     R1932     1
    r[13]     R1933     -1
    r[13]     R1934     1
    r[13]     R1935     -1
    r[13]     R1936     1
    r[13]     R1937     -1
    r[13]     R1938     1
    r[13]     R1939     -1
    r[13]     R1940     1
    r[13]     R1941     -1
    r[13]     R1942     1
    r[13]     R1943     -1
    r[13]     R1944     1
    r[13]     R1945     -1
    r[13]     R1946     1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     R1243     1
    r[14]     R1244     -1
    r[14]     R1309     1
    r[14]     R1310     -1
    r[14]     R1373     1
    r[14]     R1374     -1
    r[14]     R1435     1
    r[14]     R1436     -1
    r[14]     R1495     1
    r[14]     R1496     -1
    r[14]     R1553     1
    r[14]     R1554     -1
    r[14]     R1609     1
    r[14]     R1610     -1
    r[14]     R1663     1
    r[14]     R1664     -1
    r[14]     R1715     1
    r[14]     R1716     -1
    r[14]     R1765     1
    r[14]     R1766     -1
    r[14]     R1813     1
    r[14]     R1814     -1
    r[14]     R1859     1
    r[14]     R1860     -1
    r[14]     R1903     1
    r[14]     R1904     -1
    r[14]     R1947     -1
    r[14]     R1948     1
    r[14]     R1949     -1
    r[14]     R1950     1
    r[14]     R1951     -1
    r[14]     R1952     1
    r[14]     R1953     -1
    r[14]     R1954     1
    r[14]     R1955     -1
    r[14]     R1956     1
    r[14]     R1957     -1
    r[14]     R1958     1
    r[14]     R1959     -1
    r[14]     R1960     1
    r[14]     R1961     -1
    r[14]     R1962     1
    r[14]     R1963     -1
    r[14]     R1964     1
    r[14]     R1965     -1
    r[14]     R1966     1
    r[14]     R1967     -1
    r[14]     R1968     1
    r[14]     R1969     -1
    r[14]     R1970     1
    r[14]     R1971     -1
    r[14]     R1972     1
    r[14]     R1973     -1
    r[14]     R1974     1
    r[14]     R1975     -1
    r[14]     R1976     1
    r[14]     R1977     -1
    r[14]     R1978     1
    r[14]     R1979     -1
    r[14]     R1980     1
    r[14]     R1981     -1
    r[14]     R1982     1
    r[14]     R1983     -1
    r[14]     R1984     1
    r[14]     R1985     -1
    r[14]     R1986     1
    r[14]     R1987     -1
    r[14]     R1988     1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     R1245     1
    r[15]     R1246     -1
    r[15]     R1311     1
    r[15]     R1312     -1
    r[15]     R1375     1
    r[15]     R1376     -1
    r[15]     R1437     1
    r[15]     R1438     -1
    r[15]     R1497     1
    r[15]     R1498     -1
    r[15]     R1555     1
    r[15]     R1556     -1
    r[15]     R1611     1
    r[15]     R1612     -1
    r[15]     R1665     1
    r[15]     R1666     -1
    r[15]     R1717     1
    r[15]     R1718     -1
    r[15]     R1767     1
    r[15]     R1768     -1
    r[15]     R1815     1
    r[15]     R1816     -1
    r[15]     R1861     1
    r[15]     R1862     -1
    r[15]     R1905     1
    r[15]     R1906     -1
    r[15]     R1947     1
    r[15]     R1948     -1
    r[15]     R1989     -1
    r[15]     R1990     1
    r[15]     R1991     -1
    r[15]     R1992     1
    r[15]     R1993     -1
    r[15]     R1994     1
    r[15]     R1995     -1
    r[15]     R1996     1
    r[15]     R1997     -1
    r[15]     R1998     1
    r[15]     R1999     -1
    r[15]     R2000     1
    r[15]     R2001     -1
    r[15]     R2002     1
    r[15]     R2003     -1
    r[15]     R2004     1
    r[15]     R2005     -1
    r[15]     R2006     1
    r[15]     R2007     -1
    r[15]     R2008     1
    r[15]     R2009     -1
    r[15]     R2010     1
    r[15]     R2011     -1
    r[15]     R2012     1
    r[15]     R2013     -1
    r[15]     R2014     1
    r[15]     R2015     -1
    r[15]     R2016     1
    r[15]     R2017     -1
    r[15]     R2018     1
    r[15]     R2019     -1
    r[15]     R2020     1
    r[15]     R2021     -1
    r[15]     R2022     1
    r[15]     R2023     -1
    r[15]     R2024     1
    r[15]     R2025     -1
    r[15]     R2026     1
    r[15]     R2027     -1
    r[15]     R2028     1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     R1247     1
    r[16]     R1248     -1
    r[16]     R1313     1
    r[16]     R1314     -1
    r[16]     R1377     1
    r[16]     R1378     -1
    r[16]     R1439     1
    r[16]     R1440     -1
    r[16]     R1499     1
    r[16]     R1500     -1
    r[16]     R1557     1
    r[16]     R1558     -1
    r[16]     R1613     1
    r[16]     R1614     -1
    r[16]     R1667     1
    r[16]     R1668     -1
    r[16]     R1719     1
    r[16]     R1720     -1
    r[16]     R1769     1
    r[16]     R1770     -1
    r[16]     R1817     1
    r[16]     R1818     -1
    r[16]     R1863     1
    r[16]     R1864     -1
    r[16]     R1907     1
    r[16]     R1908     -1
    r[16]     R1949     1
    r[16]     R1950     -1
    r[16]     R1989     1
    r[16]     R1990     -1
    r[16]     R2029     -1
    r[16]     R2030     1
    r[16]     R2031     -1
    r[16]     R2032     1
    r[16]     R2033     -1
    r[16]     R2034     1
    r[16]     R2035     -1
    r[16]     R2036     1
    r[16]     R2037     -1
    r[16]     R2038     1
    r[16]     R2039     -1
    r[16]     R2040     1
    r[16]     R2041     -1
    r[16]     R2042     1
    r[16]     R2043     -1
    r[16]     R2044     1
    r[16]     R2045     -1
    r[16]     R2046     1
    r[16]     R2047     -1
    r[16]     R2048     1
    r[16]     R2049     -1
    r[16]     R2050     1
    r[16]     R2051     -1
    r[16]     R2052     1
    r[16]     R2053     -1
    r[16]     R2054     1
    r[16]     R2055     -1
    r[16]     R2056     1
    r[16]     R2057     -1
    r[16]     R2058     1
    r[16]     R2059     -1
    r[16]     R2060     1
    r[16]     R2061     -1
    r[16]     R2062     1
    r[16]     R2063     -1
    r[16]     R2064     1
    r[16]     R2065     -1
    r[16]     R2066     1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     R1249     1
    r[17]     R1250     -1
    r[17]     R1315     1
    r[17]     R1316     -1
    r[17]     R1379     1
    r[17]     R1380     -1
    r[17]     R1441     1
    r[17]     R1442     -1
    r[17]     R1501     1
    r[17]     R1502     -1
    r[17]     R1559     1
    r[17]     R1560     -1
    r[17]     R1615     1
    r[17]     R1616     -1
    r[17]     R1669     1
    r[17]     R1670     -1
    r[17]     R1721     1
    r[17]     R1722     -1
    r[17]     R1771     1
    r[17]     R1772     -1
    r[17]     R1819     1
    r[17]     R1820     -1
    r[17]     R1865     1
    r[17]     R1866     -1
    r[17]     R1909     1
    r[17]     R1910     -1
    r[17]     R1951     1
    r[17]     R1952     -1
    r[17]     R1991     1
    r[17]     R1992     -1
    r[17]     R2029     1
    r[17]     R2030     -1
    r[17]     R2067     -1
    r[17]     R2068     1
    r[17]     R2069     -1
    r[17]     R2070     1
    r[17]     R2071     -1
    r[17]     R2072     1
    r[17]     R2073     -1
    r[17]     R2074     1
    r[17]     R2075     -1
    r[17]     R2076     1
    r[17]     R2077     -1
    r[17]     R2078     1
    r[17]     R2079     -1
    r[17]     R2080     1
    r[17]     R2081     -1
    r[17]     R2082     1
    r[17]     R2083     -1
    r[17]     R2084     1
    r[17]     R2085     -1
    r[17]     R2086     1
    r[17]     R2087     -1
    r[17]     R2088     1
    r[17]     R2089     -1
    r[17]     R2090     1
    r[17]     R2091     -1
    r[17]     R2092     1
    r[17]     R2093     -1
    r[17]     R2094     1
    r[17]     R2095     -1
    r[17]     R2096     1
    r[17]     R2097     -1
    r[17]     R2098     1
    r[17]     R2099     -1
    r[17]     R2100     1
    r[17]     R2101     -1
    r[17]     R2102     1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     R1251     1
    r[18]     R1252     -1
    r[18]     R1317     1
    r[18]     R1318     -1
    r[18]     R1381     1
    r[18]     R1382     -1
    r[18]     R1443     1
    r[18]     R1444     -1
    r[18]     R1503     1
    r[18]     R1504     -1
    r[18]     R1561     1
    r[18]     R1562     -1
    r[18]     R1617     1
    r[18]     R1618     -1
    r[18]     R1671     1
    r[18]     R1672     -1
    r[18]     R1723     1
    r[18]     R1724     -1
    r[18]     R1773     1
    r[18]     R1774     -1
    r[18]     R1821     1
    r[18]     R1822     -1
    r[18]     R1867     1
    r[18]     R1868     -1
    r[18]     R1911     1
    r[18]     R1912     -1
    r[18]     R1953     1
    r[18]     R1954     -1
    r[18]     R1993     1
    r[18]     R1994     -1
    r[18]     R2031     1
    r[18]     R2032     -1
    r[18]     R2067     1
    r[18]     R2068     -1
    r[18]     R2103     -1
    r[18]     R2104     1
    r[18]     R2105     -1
    r[18]     R2106     1
    r[18]     R2107     -1
    r[18]     R2108     1
    r[18]     R2109     -1
    r[18]     R2110     1
    r[18]     R2111     -1
    r[18]     R2112     1
    r[18]     R2113     -1
    r[18]     R2114     1
    r[18]     R2115     -1
    r[18]     R2116     1
    r[18]     R2117     -1
    r[18]     R2118     1
    r[18]     R2119     -1
    r[18]     R2120     1
    r[18]     R2121     -1
    r[18]     R2122     1
    r[18]     R2123     -1
    r[18]     R2124     1
    r[18]     R2125     -1
    r[18]     R2126     1
    r[18]     R2127     -1
    r[18]     R2128     1
    r[18]     R2129     -1
    r[18]     R2130     1
    r[18]     R2131     -1
    r[18]     R2132     1
    r[18]     R2133     -1
    r[18]     R2134     1
    r[18]     R2135     -1
    r[18]     R2136     1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     R1253     1
    r[19]     R1254     -1
    r[19]     R1319     1
    r[19]     R1320     -1
    r[19]     R1383     1
    r[19]     R1384     -1
    r[19]     R1445     1
    r[19]     R1446     -1
    r[19]     R1505     1
    r[19]     R1506     -1
    r[19]     R1563     1
    r[19]     R1564     -1
    r[19]     R1619     1
    r[19]     R1620     -1
    r[19]     R1673     1
    r[19]     R1674     -1
    r[19]     R1725     1
    r[19]     R1726     -1
    r[19]     R1775     1
    r[19]     R1776     -1
    r[19]     R1823     1
    r[19]     R1824     -1
    r[19]     R1869     1
    r[19]     R1870     -1
    r[19]     R1913     1
    r[19]     R1914     -1
    r[19]     R1955     1
    r[19]     R1956     -1
    r[19]     R1995     1
    r[19]     R1996     -1
    r[19]     R2033     1
    r[19]     R2034     -1
    r[19]     R2069     1
    r[19]     R2070     -1
    r[19]     R2103     1
    r[19]     R2104     -1
    r[19]     R2137     -1
    r[19]     R2138     1
    r[19]     R2139     -1
    r[19]     R2140     1
    r[19]     R2141     -1
    r[19]     R2142     1
    r[19]     R2143     -1
    r[19]     R2144     1
    r[19]     R2145     -1
    r[19]     R2146     1
    r[19]     R2147     -1
    r[19]     R2148     1
    r[19]     R2149     -1
    r[19]     R2150     1
    r[19]     R2151     -1
    r[19]     R2152     1
    r[19]     R2153     -1
    r[19]     R2154     1
    r[19]     R2155     -1
    r[19]     R2156     1
    r[19]     R2157     -1
    r[19]     R2158     1
    r[19]     R2159     -1
    r[19]     R2160     1
    r[19]     R2161     -1
    r[19]     R2162     1
    r[19]     R2163     -1
    r[19]     R2164     1
    r[19]     R2165     -1
    r[19]     R2166     1
    r[19]     R2167     -1
    r[19]     R2168     1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     R1255     1
    r[20]     R1256     -1
    r[20]     R1321     1
    r[20]     R1322     -1
    r[20]     R1385     1
    r[20]     R1386     -1
    r[20]     R1447     1
    r[20]     R1448     -1
    r[20]     R1507     1
    r[20]     R1508     -1
    r[20]     R1565     1
    r[20]     R1566     -1
    r[20]     R1621     1
    r[20]     R1622     -1
    r[20]     R1675     1
    r[20]     R1676     -1
    r[20]     R1727     1
    r[20]     R1728     -1
    r[20]     R1777     1
    r[20]     R1778     -1
    r[20]     R1825     1
    r[20]     R1826     -1
    r[20]     R1871     1
    r[20]     R1872     -1
    r[20]     R1915     1
    r[20]     R1916     -1
    r[20]     R1957     1
    r[20]     R1958     -1
    r[20]     R1997     1
    r[20]     R1998     -1
    r[20]     R2035     1
    r[20]     R2036     -1
    r[20]     R2071     1
    r[20]     R2072     -1
    r[20]     R2105     1
    r[20]     R2106     -1
    r[20]     R2137     1
    r[20]     R2138     -1
    r[20]     R2169     -1
    r[20]     R2170     1
    r[20]     R2171     -1
    r[20]     R2172     1
    r[20]     R2173     -1
    r[20]     R2174     1
    r[20]     R2175     -1
    r[20]     R2176     1
    r[20]     R2177     -1
    r[20]     R2178     1
    r[20]     R2179     -1
    r[20]     R2180     1
    r[20]     R2181     -1
    r[20]     R2182     1
    r[20]     R2183     -1
    r[20]     R2184     1
    r[20]     R2185     -1
    r[20]     R2186     1
    r[20]     R2187     -1
    r[20]     R2188     1
    r[20]     R2189     -1
    r[20]     R2190     1
    r[20]     R2191     -1
    r[20]     R2192     1
    r[20]     R2193     -1
    r[20]     R2194     1
    r[20]     R2195     -1
    r[20]     R2196     1
    r[20]     R2197     -1
    r[20]     R2198     1
    r[21]     normalized_ratio_21  1
    r[21]     normalization  1
    r[21]     R1257     1
    r[21]     R1258     -1
    r[21]     R1323     1
    r[21]     R1324     -1
    r[21]     R1387     1
    r[21]     R1388     -1
    r[21]     R1449     1
    r[21]     R1450     -1
    r[21]     R1509     1
    r[21]     R1510     -1
    r[21]     R1567     1
    r[21]     R1568     -1
    r[21]     R1623     1
    r[21]     R1624     -1
    r[21]     R1677     1
    r[21]     R1678     -1
    r[21]     R1729     1
    r[21]     R1730     -1
    r[21]     R1779     1
    r[21]     R1780     -1
    r[21]     R1827     1
    r[21]     R1828     -1
    r[21]     R1873     1
    r[21]     R1874     -1
    r[21]     R1917     1
    r[21]     R1918     -1
    r[21]     R1959     1
    r[21]     R1960     -1
    r[21]     R1999     1
    r[21]     R2000     -1
    r[21]     R2037     1
    r[21]     R2038     -1
    r[21]     R2073     1
    r[21]     R2074     -1
    r[21]     R2107     1
    r[21]     R2108     -1
    r[21]     R2139     1
    r[21]     R2140     -1
    r[21]     R2169     1
    r[21]     R2170     -1
    r[21]     R2199     -1
    r[21]     R2200     1
    r[21]     R2201     -1
    r[21]     R2202     1
    r[21]     R2203     -1
    r[21]     R2204     1
    r[21]     R2205     -1
    r[21]     R2206     1
    r[21]     R2207     -1
    r[21]     R2208     1
    r[21]     R2209     -1
    r[21]     R2210     1
    r[21]     R2211     -1
    r[21]     R2212     1
    r[21]     R2213     -1
    r[21]     R2214     1
    r[21]     R2215     -1
    r[21]     R2216     1
    r[21]     R2217     -1
    r[21]     R2218     1
    r[21]     R2219     -1
    r[21]     R2220     1
    r[21]     R2221     -1
    r[21]     R2222     1
    r[21]     R2223     -1
    r[21]     R2224     1
    r[21]     R2225     -1
    r[21]     R2226     1
    r[22]     normalized_ratio_22  1
    r[22]     normalization  1
    r[22]     R1259     1
    r[22]     R1260     -1
    r[22]     R1325     1
    r[22]     R1326     -1
    r[22]     R1389     1
    r[22]     R1390     -1
    r[22]     R1451     1
    r[22]     R1452     -1
    r[22]     R1511     1
    r[22]     R1512     -1
    r[22]     R1569     1
    r[22]     R1570     -1
    r[22]     R1625     1
    r[22]     R1626     -1
    r[22]     R1679     1
    r[22]     R1680     -1
    r[22]     R1731     1
    r[22]     R1732     -1
    r[22]     R1781     1
    r[22]     R1782     -1
    r[22]     R1829     1
    r[22]     R1830     -1
    r[22]     R1875     1
    r[22]     R1876     -1
    r[22]     R1919     1
    r[22]     R1920     -1
    r[22]     R1961     1
    r[22]     R1962     -1
    r[22]     R2001     1
    r[22]     R2002     -1
    r[22]     R2039     1
    r[22]     R2040     -1
    r[22]     R2075     1
    r[22]     R2076     -1
    r[22]     R2109     1
    r[22]     R2110     -1
    r[22]     R2141     1
    r[22]     R2142     -1
    r[22]     R2171     1
    r[22]     R2172     -1
    r[22]     R2199     1
    r[22]     R2200     -1
    r[22]     R2227     -1
    r[22]     R2228     1
    r[22]     R2229     -1
    r[22]     R2230     1
    r[22]     R2231     -1
    r[22]     R2232     1
    r[22]     R2233     -1
    r[22]     R2234     1
    r[22]     R2235     -1
    r[22]     R2236     1
    r[22]     R2237     -1
    r[22]     R2238     1
    r[22]     R2239     -1
    r[22]     R2240     1
    r[22]     R2241     -1
    r[22]     R2242     1
    r[22]     R2243     -1
    r[22]     R2244     1
    r[22]     R2245     -1
    r[22]     R2246     1
    r[22]     R2247     -1
    r[22]     R2248     1
    r[22]     R2249     -1
    r[22]     R2250     1
    r[22]     R2251     -1
    r[22]     R2252     1
    r[23]     normalized_ratio_23  1
    r[23]     normalization  1
    r[23]     R1261     1
    r[23]     R1262     -1
    r[23]     R1327     1
    r[23]     R1328     -1
    r[23]     R1391     1
    r[23]     R1392     -1
    r[23]     R1453     1
    r[23]     R1454     -1
    r[23]     R1513     1
    r[23]     R1514     -1
    r[23]     R1571     1
    r[23]     R1572     -1
    r[23]     R1627     1
    r[23]     R1628     -1
    r[23]     R1681     1
    r[23]     R1682     -1
    r[23]     R1733     1
    r[23]     R1734     -1
    r[23]     R1783     1
    r[23]     R1784     -1
    r[23]     R1831     1
    r[23]     R1832     -1
    r[23]     R1877     1
    r[23]     R1878     -1
    r[23]     R1921     1
    r[23]     R1922     -1
    r[23]     R1963     1
    r[23]     R1964     -1
    r[23]     R2003     1
    r[23]     R2004     -1
    r[23]     R2041     1
    r[23]     R2042     -1
    r[23]     R2077     1
    r[23]     R2078     -1
    r[23]     R2111     1
    r[23]     R2112     -1
    r[23]     R2143     1
    r[23]     R2144     -1
    r[23]     R2173     1
    r[23]     R2174     -1
    r[23]     R2201     1
    r[23]     R2202     -1
    r[23]     R2227     1
    r[23]     R2228     -1
    r[23]     R2253     -1
    r[23]     R2254     1
    r[23]     R2255     -1
    r[23]     R2256     1
    r[23]     R2257     -1
    r[23]     R2258     1
    r[23]     R2259     -1
    r[23]     R2260     1
    r[23]     R2261     -1
    r[23]     R2262     1
    r[23]     R2263     -1
    r[23]     R2264     1
    r[23]     R2265     -1
    r[23]     R2266     1
    r[23]     R2267     -1
    r[23]     R2268     1
    r[23]     R2269     -1
    r[23]     R2270     1
    r[23]     R2271     -1
    r[23]     R2272     1
    r[23]     R2273     -1
    r[23]     R2274     1
    r[23]     R2275     -1
    r[23]     R2276     1
    r[24]     normalized_ratio_24  1
    r[24]     normalization  1
    r[24]     R1263     1
    r[24]     R1264     -1
    r[24]     R1329     1
    r[24]     R1330     -1
    r[24]     R1393     1
    r[24]     R1394     -1
    r[24]     R1455     1
    r[24]     R1456     -1
    r[24]     R1515     1
    r[24]     R1516     -1
    r[24]     R1573     1
    r[24]     R1574     -1
    r[24]     R1629     1
    r[24]     R1630     -1
    r[24]     R1683     1
    r[24]     R1684     -1
    r[24]     R1735     1
    r[24]     R1736     -1
    r[24]     R1785     1
    r[24]     R1786     -1
    r[24]     R1833     1
    r[24]     R1834     -1
    r[24]     R1879     1
    r[24]     R1880     -1
    r[24]     R1923     1
    r[24]     R1924     -1
    r[24]     R1965     1
    r[24]     R1966     -1
    r[24]     R2005     1
    r[24]     R2006     -1
    r[24]     R2043     1
    r[24]     R2044     -1
    r[24]     R2079     1
    r[24]     R2080     -1
    r[24]     R2113     1
    r[24]     R2114     -1
    r[24]     R2145     1
    r[24]     R2146     -1
    r[24]     R2175     1
    r[24]     R2176     -1
    r[24]     R2203     1
    r[24]     R2204     -1
    r[24]     R2229     1
    r[24]     R2230     -1
    r[24]     R2253     1
    r[24]     R2254     -1
    r[24]     R2277     -1
    r[24]     R2278     1
    r[24]     R2279     -1
    r[24]     R2280     1
    r[24]     R2281     -1
    r[24]     R2282     1
    r[24]     R2283     -1
    r[24]     R2284     1
    r[24]     R2285     -1
    r[24]     R2286     1
    r[24]     R2287     -1
    r[24]     R2288     1
    r[24]     R2289     -1
    r[24]     R2290     1
    r[24]     R2291     -1
    r[24]     R2292     1
    r[24]     R2293     -1
    r[24]     R2294     1
    r[24]     R2295     -1
    r[24]     R2296     1
    r[24]     R2297     -1
    r[24]     R2298     1
    r[25]     normalized_ratio_25  1
    r[25]     normalization  1
    r[25]     R1265     1
    r[25]     R1266     -1
    r[25]     R1331     1
    r[25]     R1332     -1
    r[25]     R1395     1
    r[25]     R1396     -1
    r[25]     R1457     1
    r[25]     R1458     -1
    r[25]     R1517     1
    r[25]     R1518     -1
    r[25]     R1575     1
    r[25]     R1576     -1
    r[25]     R1631     1
    r[25]     R1632     -1
    r[25]     R1685     1
    r[25]     R1686     -1
    r[25]     R1737     1
    r[25]     R1738     -1
    r[25]     R1787     1
    r[25]     R1788     -1
    r[25]     R1835     1
    r[25]     R1836     -1
    r[25]     R1881     1
    r[25]     R1882     -1
    r[25]     R1925     1
    r[25]     R1926     -1
    r[25]     R1967     1
    r[25]     R1968     -1
    r[25]     R2007     1
    r[25]     R2008     -1
    r[25]     R2045     1
    r[25]     R2046     -1
    r[25]     R2081     1
    r[25]     R2082     -1
    r[25]     R2115     1
    r[25]     R2116     -1
    r[25]     R2147     1
    r[25]     R2148     -1
    r[25]     R2177     1
    r[25]     R2178     -1
    r[25]     R2205     1
    r[25]     R2206     -1
    r[25]     R2231     1
    r[25]     R2232     -1
    r[25]     R2255     1
    r[25]     R2256     -1
    r[25]     R2277     1
    r[25]     R2278     -1
    r[25]     R2299     -1
    r[25]     R2300     1
    r[25]     R2301     -1
    r[25]     R2302     1
    r[25]     R2303     -1
    r[25]     R2304     1
    r[25]     R2305     -1
    r[25]     R2306     1
    r[25]     R2307     -1
    r[25]     R2308     1
    r[25]     R2309     -1
    r[25]     R2310     1
    r[25]     R2311     -1
    r[25]     R2312     1
    r[25]     R2313     -1
    r[25]     R2314     1
    r[25]     R2315     -1
    r[25]     R2316     1
    r[25]     R2317     -1
    r[25]     R2318     1
    r[26]     normalized_ratio_26  1
    r[26]     normalization  1
    r[26]     R1267     1
    r[26]     R1268     -1
    r[26]     R1333     1
    r[26]     R1334     -1
    r[26]     R1397     1
    r[26]     R1398     -1
    r[26]     R1459     1
    r[26]     R1460     -1
    r[26]     R1519     1
    r[26]     R1520     -1
    r[26]     R1577     1
    r[26]     R1578     -1
    r[26]     R1633     1
    r[26]     R1634     -1
    r[26]     R1687     1
    r[26]     R1688     -1
    r[26]     R1739     1
    r[26]     R1740     -1
    r[26]     R1789     1
    r[26]     R1790     -1
    r[26]     R1837     1
    r[26]     R1838     -1
    r[26]     R1883     1
    r[26]     R1884     -1
    r[26]     R1927     1
    r[26]     R1928     -1
    r[26]     R1969     1
    r[26]     R1970     -1
    r[26]     R2009     1
    r[26]     R2010     -1
    r[26]     R2047     1
    r[26]     R2048     -1
    r[26]     R2083     1
    r[26]     R2084     -1
    r[26]     R2117     1
    r[26]     R2118     -1
    r[26]     R2149     1
    r[26]     R2150     -1
    r[26]     R2179     1
    r[26]     R2180     -1
    r[26]     R2207     1
    r[26]     R2208     -1
    r[26]     R2233     1
    r[26]     R2234     -1
    r[26]     R2257     1
    r[26]     R2258     -1
    r[26]     R2279     1
    r[26]     R2280     -1
    r[26]     R2299     1
    r[26]     R2300     -1
    r[26]     R2319     -1
    r[26]     R2320     1
    r[26]     R2321     -1
    r[26]     R2322     1
    r[26]     R2323     -1
    r[26]     R2324     1
    r[26]     R2325     -1
    r[26]     R2326     1
    r[26]     R2327     -1
    r[26]     R2328     1
    r[26]     R2329     -1
    r[26]     R2330     1
    r[26]     R2331     -1
    r[26]     R2332     1
    r[26]     R2333     -1
    r[26]     R2334     1
    r[26]     R2335     -1
    r[26]     R2336     1
    r[27]     normalized_ratio_27  1
    r[27]     normalization  1
    r[27]     R1269     1
    r[27]     R1270     -1
    r[27]     R1335     1
    r[27]     R1336     -1
    r[27]     R1399     1
    r[27]     R1400     -1
    r[27]     R1461     1
    r[27]     R1462     -1
    r[27]     R1521     1
    r[27]     R1522     -1
    r[27]     R1579     1
    r[27]     R1580     -1
    r[27]     R1635     1
    r[27]     R1636     -1
    r[27]     R1689     1
    r[27]     R1690     -1
    r[27]     R1741     1
    r[27]     R1742     -1
    r[27]     R1791     1
    r[27]     R1792     -1
    r[27]     R1839     1
    r[27]     R1840     -1
    r[27]     R1885     1
    r[27]     R1886     -1
    r[27]     R1929     1
    r[27]     R1930     -1
    r[27]     R1971     1
    r[27]     R1972     -1
    r[27]     R2011     1
    r[27]     R2012     -1
    r[27]     R2049     1
    r[27]     R2050     -1
    r[27]     R2085     1
    r[27]     R2086     -1
    r[27]     R2119     1
    r[27]     R2120     -1
    r[27]     R2151     1
    r[27]     R2152     -1
    r[27]     R2181     1
    r[27]     R2182     -1
    r[27]     R2209     1
    r[27]     R2210     -1
    r[27]     R2235     1
    r[27]     R2236     -1
    r[27]     R2259     1
    r[27]     R2260     -1
    r[27]     R2281     1
    r[27]     R2282     -1
    r[27]     R2301     1
    r[27]     R2302     -1
    r[27]     R2319     1
    r[27]     R2320     -1
    r[27]     R2337     -1
    r[27]     R2338     1
    r[27]     R2339     -1
    r[27]     R2340     1
    r[27]     R2341     -1
    r[27]     R2342     1
    r[27]     R2343     -1
    r[27]     R2344     1
    r[27]     R2345     -1
    r[27]     R2346     1
    r[27]     R2347     -1
    r[27]     R2348     1
    r[27]     R2349     -1
    r[27]     R2350     1
    r[27]     R2351     -1
    r[27]     R2352     1
    r[28]     normalized_ratio_28  1
    r[28]     normalization  1
    r[28]     R1271     1
    r[28]     R1272     -1
    r[28]     R1337     1
    r[28]     R1338     -1
    r[28]     R1401     1
    r[28]     R1402     -1
    r[28]     R1463     1
    r[28]     R1464     -1
    r[28]     R1523     1
    r[28]     R1524     -1
    r[28]     R1581     1
    r[28]     R1582     -1
    r[28]     R1637     1
    r[28]     R1638     -1
    r[28]     R1691     1
    r[28]     R1692     -1
    r[28]     R1743     1
    r[28]     R1744     -1
    r[28]     R1793     1
    r[28]     R1794     -1
    r[28]     R1841     1
    r[28]     R1842     -1
    r[28]     R1887     1
    r[28]     R1888     -1
    r[28]     R1931     1
    r[28]     R1932     -1
    r[28]     R1973     1
    r[28]     R1974     -1
    r[28]     R2013     1
    r[28]     R2014     -1
    r[28]     R2051     1
    r[28]     R2052     -1
    r[28]     R2087     1
    r[28]     R2088     -1
    r[28]     R2121     1
    r[28]     R2122     -1
    r[28]     R2153     1
    r[28]     R2154     -1
    r[28]     R2183     1
    r[28]     R2184     -1
    r[28]     R2211     1
    r[28]     R2212     -1
    r[28]     R2237     1
    r[28]     R2238     -1
    r[28]     R2261     1
    r[28]     R2262     -1
    r[28]     R2283     1
    r[28]     R2284     -1
    r[28]     R2303     1
    r[28]     R2304     -1
    r[28]     R2321     1
    r[28]     R2322     -1
    r[28]     R2337     1
    r[28]     R2338     -1
    r[28]     R2353     -1
    r[28]     R2354     1
    r[28]     R2355     -1
    r[28]     R2356     1
    r[28]     R2357     -1
    r[28]     R2358     1
    r[28]     R2359     -1
    r[28]     R2360     1
    r[28]     R2361     -1
    r[28]     R2362     1
    r[28]     R2363     -1
    r[28]     R2364     1
    r[28]     R2365     -1
    r[28]     R2366     1
    r[29]     normalized_ratio_29  1
    r[29]     normalization  1
    r[29]     R1273     1
    r[29]     R1274     -1
    r[29]     R1339     1
    r[29]     R1340     -1
    r[29]     R1403     1
    r[29]     R1404     -1
    r[29]     R1465     1
    r[29]     R1466     -1
    r[29]     R1525     1
    r[29]     R1526     -1
    r[29]     R1583     1
    r[29]     R1584     -1
    r[29]     R1639     1
    r[29]     R1640     -1
    r[29]     R1693     1
    r[29]     R1694     -1
    r[29]     R1745     1
    r[29]     R1746     -1
    r[29]     R1795     1
    r[29]     R1796     -1
    r[29]     R1843     1
    r[29]     R1844     -1
    r[29]     R1889     1
    r[29]     R1890     -1
    r[29]     R1933     1
    r[29]     R1934     -1
    r[29]     R1975     1
    r[29]     R1976     -1
    r[29]     R2015     1
    r[29]     R2016     -1
    r[29]     R2053     1
    r[29]     R2054     -1
    r[29]     R2089     1
    r[29]     R2090     -1
    r[29]     R2123     1
    r[29]     R2124     -1
    r[29]     R2155     1
    r[29]     R2156     -1
    r[29]     R2185     1
    r[29]     R2186     -1
    r[29]     R2213     1
    r[29]     R2214     -1
    r[29]     R2239     1
    r[29]     R2240     -1
    r[29]     R2263     1
    r[29]     R2264     -1
    r[29]     R2285     1
    r[29]     R2286     -1
    r[29]     R2305     1
    r[29]     R2306     -1
    r[29]     R2323     1
    r[29]     R2324     -1
    r[29]     R2339     1
    r[29]     R2340     -1
    r[29]     R2353     1
    r[29]     R2354     -1
    r[29]     R2367     -1
    r[29]     R2368     1
    r[29]     R2369     -1
    r[29]     R2370     1
    r[29]     R2371     -1
    r[29]     R2372     1
    r[29]     R2373     -1
    r[29]     R2374     1
    r[29]     R2375     -1
    r[29]     R2376     1
    r[29]     R2377     -1
    r[29]     R2378     1
    r[30]     normalized_ratio_30  1
    r[30]     normalization  1
    r[30]     R1275     1
    r[30]     R1276     -1
    r[30]     R1341     1
    r[30]     R1342     -1
    r[30]     R1405     1
    r[30]     R1406     -1
    r[30]     R1467     1
    r[30]     R1468     -1
    r[30]     R1527     1
    r[30]     R1528     -1
    r[30]     R1585     1
    r[30]     R1586     -1
    r[30]     R1641     1
    r[30]     R1642     -1
    r[30]     R1695     1
    r[30]     R1696     -1
    r[30]     R1747     1
    r[30]     R1748     -1
    r[30]     R1797     1
    r[30]     R1798     -1
    r[30]     R1845     1
    r[30]     R1846     -1
    r[30]     R1891     1
    r[30]     R1892     -1
    r[30]     R1935     1
    r[30]     R1936     -1
    r[30]     R1977     1
    r[30]     R1978     -1
    r[30]     R2017     1
    r[30]     R2018     -1
    r[30]     R2055     1
    r[30]     R2056     -1
    r[30]     R2091     1
    r[30]     R2092     -1
    r[30]     R2125     1
    r[30]     R2126     -1
    r[30]     R2157     1
    r[30]     R2158     -1
    r[30]     R2187     1
    r[30]     R2188     -1
    r[30]     R2215     1
    r[30]     R2216     -1
    r[30]     R2241     1
    r[30]     R2242     -1
    r[30]     R2265     1
    r[30]     R2266     -1
    r[30]     R2287     1
    r[30]     R2288     -1
    r[30]     R2307     1
    r[30]     R2308     -1
    r[30]     R2325     1
    r[30]     R2326     -1
    r[30]     R2341     1
    r[30]     R2342     -1
    r[30]     R2355     1
    r[30]     R2356     -1
    r[30]     R2367     1
    r[30]     R2368     -1
    r[30]     R2379     -1
    r[30]     R2380     1
    r[30]     R2381     -1
    r[30]     R2382     1
    r[30]     R2383     -1
    r[30]     R2384     1
    r[30]     R2385     -1
    r[30]     R2386     1
    r[30]     R2387     -1
    r[30]     R2388     1
    r[31]     normalized_ratio_31  1
    r[31]     normalization  1
    r[31]     R1277     1
    r[31]     R1278     -1
    r[31]     R1343     1
    r[31]     R1344     -1
    r[31]     R1407     1
    r[31]     R1408     -1
    r[31]     R1469     1
    r[31]     R1470     -1
    r[31]     R1529     1
    r[31]     R1530     -1
    r[31]     R1587     1
    r[31]     R1588     -1
    r[31]     R1643     1
    r[31]     R1644     -1
    r[31]     R1697     1
    r[31]     R1698     -1
    r[31]     R1749     1
    r[31]     R1750     -1
    r[31]     R1799     1
    r[31]     R1800     -1
    r[31]     R1847     1
    r[31]     R1848     -1
    r[31]     R1893     1
    r[31]     R1894     -1
    r[31]     R1937     1
    r[31]     R1938     -1
    r[31]     R1979     1
    r[31]     R1980     -1
    r[31]     R2019     1
    r[31]     R2020     -1
    r[31]     R2057     1
    r[31]     R2058     -1
    r[31]     R2093     1
    r[31]     R2094     -1
    r[31]     R2127     1
    r[31]     R2128     -1
    r[31]     R2159     1
    r[31]     R2160     -1
    r[31]     R2189     1
    r[31]     R2190     -1
    r[31]     R2217     1
    r[31]     R2218     -1
    r[31]     R2243     1
    r[31]     R2244     -1
    r[31]     R2267     1
    r[31]     R2268     -1
    r[31]     R2289     1
    r[31]     R2290     -1
    r[31]     R2309     1
    r[31]     R2310     -1
    r[31]     R2327     1
    r[31]     R2328     -1
    r[31]     R2343     1
    r[31]     R2344     -1
    r[31]     R2357     1
    r[31]     R2358     -1
    r[31]     R2369     1
    r[31]     R2370     -1
    r[31]     R2379     1
    r[31]     R2380     -1
    r[31]     R2389     -1
    r[31]     R2390     1
    r[31]     R2391     -1
    r[31]     R2392     1
    r[31]     R2393     -1
    r[31]     R2394     1
    r[31]     R2395     -1
    r[31]     R2396     1
    r[32]     normalized_ratio_32  1
    r[32]     normalization  1
    r[32]     R1279     1
    r[32]     R1280     -1
    r[32]     R1345     1
    r[32]     R1346     -1
    r[32]     R1409     1
    r[32]     R1410     -1
    r[32]     R1471     1
    r[32]     R1472     -1
    r[32]     R1531     1
    r[32]     R1532     -1
    r[32]     R1589     1
    r[32]     R1590     -1
    r[32]     R1645     1
    r[32]     R1646     -1
    r[32]     R1699     1
    r[32]     R1700     -1
    r[32]     R1751     1
    r[32]     R1752     -1
    r[32]     R1801     1
    r[32]     R1802     -1
    r[32]     R1849     1
    r[32]     R1850     -1
    r[32]     R1895     1
    r[32]     R1896     -1
    r[32]     R1939     1
    r[32]     R1940     -1
    r[32]     R1981     1
    r[32]     R1982     -1
    r[32]     R2021     1
    r[32]     R2022     -1
    r[32]     R2059     1
    r[32]     R2060     -1
    r[32]     R2095     1
    r[32]     R2096     -1
    r[32]     R2129     1
    r[32]     R2130     -1
    r[32]     R2161     1
    r[32]     R2162     -1
    r[32]     R2191     1
    r[32]     R2192     -1
    r[32]     R2219     1
    r[32]     R2220     -1
    r[32]     R2245     1
    r[32]     R2246     -1
    r[32]     R2269     1
    r[32]     R2270     -1
    r[32]     R2291     1
    r[32]     R2292     -1
    r[32]     R2311     1
    r[32]     R2312     -1
    r[32]     R2329     1
    r[32]     R2330     -1
    r[32]     R2345     1
    r[32]     R2346     -1
    r[32]     R2359     1
    r[32]     R2360     -1
    r[32]     R2371     1
    r[32]     R2372     -1
    r[32]     R2381     1
    r[32]     R2382     -1
    r[32]     R2389     1
    r[32]     R2390     -1
    r[32]     R2397     -1
    r[32]     R2398     1
    r[32]     R2399     -1
    r[32]     R2400     1
    r[32]     R2401     -1
    r[32]     R2402     1
    r[33]     normalized_ratio_33  1
    r[33]     normalization  1
    r[33]     R1281     1
    r[33]     R1282     -1
    r[33]     R1347     1
    r[33]     R1348     -1
    r[33]     R1411     1
    r[33]     R1412     -1
    r[33]     R1473     1
    r[33]     R1474     -1
    r[33]     R1533     1
    r[33]     R1534     -1
    r[33]     R1591     1
    r[33]     R1592     -1
    r[33]     R1647     1
    r[33]     R1648     -1
    r[33]     R1701     1
    r[33]     R1702     -1
    r[33]     R1753     1
    r[33]     R1754     -1
    r[33]     R1803     1
    r[33]     R1804     -1
    r[33]     R1851     1
    r[33]     R1852     -1
    r[33]     R1897     1
    r[33]     R1898     -1
    r[33]     R1941     1
    r[33]     R1942     -1
    r[33]     R1983     1
    r[33]     R1984     -1
    r[33]     R2023     1
    r[33]     R2024     -1
    r[33]     R2061     1
    r[33]     R2062     -1
    r[33]     R2097     1
    r[33]     R2098     -1
    r[33]     R2131     1
    r[33]     R2132     -1
    r[33]     R2163     1
    r[33]     R2164     -1
    r[33]     R2193     1
    r[33]     R2194     -1
    r[33]     R2221     1
    r[33]     R2222     -1
    r[33]     R2247     1
    r[33]     R2248     -1
    r[33]     R2271     1
    r[33]     R2272     -1
    r[33]     R2293     1
    r[33]     R2294     -1
    r[33]     R2313     1
    r[33]     R2314     -1
    r[33]     R2331     1
    r[33]     R2332     -1
    r[33]     R2347     1
    r[33]     R2348     -1
    r[33]     R2361     1
    r[33]     R2362     -1
    r[33]     R2373     1
    r[33]     R2374     -1
    r[33]     R2383     1
    r[33]     R2384     -1
    r[33]     R2391     1
    r[33]     R2392     -1
    r[33]     R2397     1
    r[33]     R2398     -1
    r[33]     R2403     -1
    r[33]     R2404     1
    r[33]     R2405     -1
    r[33]     R2406     1
    r[34]     normalized_ratio_34  1
    r[34]     normalization  1
    r[34]     R1283     1
    r[34]     R1284     -1
    r[34]     R1349     1
    r[34]     R1350     -1
    r[34]     R1413     1
    r[34]     R1414     -1
    r[34]     R1475     1
    r[34]     R1476     -1
    r[34]     R1535     1
    r[34]     R1536     -1
    r[34]     R1593     1
    r[34]     R1594     -1
    r[34]     R1649     1
    r[34]     R1650     -1
    r[34]     R1703     1
    r[34]     R1704     -1
    r[34]     R1755     1
    r[34]     R1756     -1
    r[34]     R1805     1
    r[34]     R1806     -1
    r[34]     R1853     1
    r[34]     R1854     -1
    r[34]     R1899     1
    r[34]     R1900     -1
    r[34]     R1943     1
    r[34]     R1944     -1
    r[34]     R1985     1
    r[34]     R1986     -1
    r[34]     R2025     1
    r[34]     R2026     -1
    r[34]     R2063     1
    r[34]     R2064     -1
    r[34]     R2099     1
    r[34]     R2100     -1
    r[34]     R2133     1
    r[34]     R2134     -1
    r[34]     R2165     1
    r[34]     R2166     -1
    r[34]     R2195     1
    r[34]     R2196     -1
    r[34]     R2223     1
    r[34]     R2224     -1
    r[34]     R2249     1
    r[34]     R2250     -1
    r[34]     R2273     1
    r[34]     R2274     -1
    r[34]     R2295     1
    r[34]     R2296     -1
    r[34]     R2315     1
    r[34]     R2316     -1
    r[34]     R2333     1
    r[34]     R2334     -1
    r[34]     R2349     1
    r[34]     R2350     -1
    r[34]     R2363     1
    r[34]     R2364     -1
    r[34]     R2375     1
    r[34]     R2376     -1
    r[34]     R2385     1
    r[34]     R2386     -1
    r[34]     R2393     1
    r[34]     R2394     -1
    r[34]     R2399     1
    r[34]     R2400     -1
    r[34]     R2403     1
    r[34]     R2404     -1
    r[34]     R2407     -1
    r[34]     R2408     1
    r[35]     normalized_ratio_35  1
    r[35]     normalization  1
    r[35]     R1285     1
    r[35]     R1286     -1
    r[35]     R1351     1
    r[35]     R1352     -1
    r[35]     R1415     1
    r[35]     R1416     -1
    r[35]     R1477     1
    r[35]     R1478     -1
    r[35]     R1537     1
    r[35]     R1538     -1
    r[35]     R1595     1
    r[35]     R1596     -1
    r[35]     R1651     1
    r[35]     R1652     -1
    r[35]     R1705     1
    r[35]     R1706     -1
    r[35]     R1757     1
    r[35]     R1758     -1
    r[35]     R1807     1
    r[35]     R1808     -1
    r[35]     R1855     1
    r[35]     R1856     -1
    r[35]     R1901     1
    r[35]     R1902     -1
    r[35]     R1945     1
    r[35]     R1946     -1
    r[35]     R1987     1
    r[35]     R1988     -1
    r[35]     R2027     1
    r[35]     R2028     -1
    r[35]     R2065     1
    r[35]     R2066     -1
    r[35]     R2101     1
    r[35]     R2102     -1
    r[35]     R2135     1
    r[35]     R2136     -1
    r[35]     R2167     1
    r[35]     R2168     -1
    r[35]     R2197     1
    r[35]     R2198     -1
    r[35]     R2225     1
    r[35]     R2226     -1
    r[35]     R2251     1
    r[35]     R2252     -1
    r[35]     R2275     1
    r[35]     R2276     -1
    r[35]     R2297     1
    r[35]     R2298     -1
    r[35]     R2317     1
    r[35]     R2318     -1
    r[35]     R2335     1
    r[35]     R2336     -1
    r[35]     R2351     1
    r[35]     R2352     -1
    r[35]     R2365     1
    r[35]     R2366     -1
    r[35]     R2377     1
    r[35]     R2378     -1
    r[35]     R2387     1
    r[35]     R2388     -1
    r[35]     R2395     1
    r[35]     R2396     -1
    r[35]     R2401     1
    r[35]     R2402     -1
    r[35]     R2405     1
    r[35]     R2406     -1
    r[35]     R2407     1
    r[35]     R2408     -1
    a[1,2]    R1219     1
    a[1,2]    R1220     1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R1221     1
    a[1,3]    R1222     1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,4]    R1223     1
    a[1,4]    R1224     1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,5]    R1225     1
    a[1,5]    R1226     1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,6]    R1227     1
    a[1,6]    R1228     1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,7]    R1229     1
    a[1,7]    R1230     1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,8]    R1231     1
    a[1,8]    R1232     1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,9]    R1233     1
    a[1,9]    R1234     1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,10]   R1235     1
    a[1,10]   R1236     1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,11]   R1237     1
    a[1,11]   R1238     1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,12]   R1239     1
    a[1,12]   R1240     1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,13]   R1241     1
    a[1,13]   R1242     1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,14]   R1243     1
    a[1,14]   R1244     1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,15]   R1245     1
    a[1,15]   R1246     1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,16]   R1247     1
    a[1,16]   R1248     1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,17]   R1249     1
    a[1,17]   R1250     1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,18]   R1251     1
    a[1,18]   R1252     1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,19]   R1253     1
    a[1,19]   R1254     1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,20]   R1255     1
    a[1,20]   R1256     1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[1,21]   R1257     1
    a[1,21]   R1258     1
    a[1,21]   true_G_epigraph  1
    a[1,21]   physical_G_upper  1
    a[1,22]   R1259     1
    a[1,22]   R1260     1
    a[1,22]   true_G_epigraph  1
    a[1,22]   physical_G_upper  1
    a[1,23]   R1261     1
    a[1,23]   R1262     1
    a[1,23]   true_G_epigraph  1
    a[1,23]   physical_G_upper  1
    a[1,24]   R1263     1
    a[1,24]   R1264     1
    a[1,24]   true_G_epigraph  1
    a[1,24]   physical_G_upper  1
    a[1,25]   R1265     1
    a[1,25]   R1266     1
    a[1,25]   true_G_epigraph  1
    a[1,25]   physical_G_upper  1
    a[1,26]   R1267     1
    a[1,26]   R1268     1
    a[1,26]   true_G_epigraph  1
    a[1,26]   physical_G_upper  1
    a[1,27]   R1269     1
    a[1,27]   R1270     1
    a[1,27]   true_G_epigraph  1
    a[1,27]   physical_G_upper  1
    a[1,28]   R1271     1
    a[1,28]   R1272     1
    a[1,28]   true_G_epigraph  1
    a[1,28]   physical_G_upper  1
    a[1,29]   R1273     1
    a[1,29]   R1274     1
    a[1,29]   true_G_epigraph  1
    a[1,29]   physical_G_upper  1
    a[1,30]   R1275     1
    a[1,30]   R1276     1
    a[1,30]   true_G_epigraph  1
    a[1,30]   physical_G_upper  1
    a[1,31]   R1277     1
    a[1,31]   R1278     1
    a[1,31]   true_G_epigraph  1
    a[1,31]   physical_G_upper  1
    a[1,32]   R1279     1
    a[1,32]   R1280     1
    a[1,32]   true_G_epigraph  1
    a[1,32]   physical_G_upper  1
    a[1,33]   R1281     1
    a[1,33]   R1282     1
    a[1,33]   true_G_epigraph  1
    a[1,33]   physical_G_upper  1
    a[1,34]   R1283     1
    a[1,34]   R1284     1
    a[1,34]   true_G_epigraph  1
    a[1,34]   physical_G_upper  1
    a[1,35]   R1285     1
    a[1,35]   R1286     1
    a[1,35]   true_G_epigraph  1
    a[1,35]   physical_G_upper  1
    a[2,3]    R1287     1
    a[2,3]    R1288     1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,4]    R1289     1
    a[2,4]    R1290     1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,5]    R1291     1
    a[2,5]    R1292     1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,6]    R1293     1
    a[2,6]    R1294     1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,7]    R1295     1
    a[2,7]    R1296     1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,8]    R1297     1
    a[2,8]    R1298     1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,9]    R1299     1
    a[2,9]    R1300     1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,10]   R1301     1
    a[2,10]   R1302     1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,11]   R1303     1
    a[2,11]   R1304     1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,12]   R1305     1
    a[2,12]   R1306     1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,13]   R1307     1
    a[2,13]   R1308     1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,14]   R1309     1
    a[2,14]   R1310     1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,15]   R1311     1
    a[2,15]   R1312     1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,16]   R1313     1
    a[2,16]   R1314     1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,17]   R1315     1
    a[2,17]   R1316     1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,18]   R1317     1
    a[2,18]   R1318     1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,19]   R1319     1
    a[2,19]   R1320     1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,20]   R1321     1
    a[2,20]   R1322     1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[2,21]   R1323     1
    a[2,21]   R1324     1
    a[2,21]   true_G_epigraph  1
    a[2,21]   physical_G_upper  1
    a[2,22]   R1325     1
    a[2,22]   R1326     1
    a[2,22]   true_G_epigraph  1
    a[2,22]   physical_G_upper  1
    a[2,23]   R1327     1
    a[2,23]   R1328     1
    a[2,23]   true_G_epigraph  1
    a[2,23]   physical_G_upper  1
    a[2,24]   R1329     1
    a[2,24]   R1330     1
    a[2,24]   true_G_epigraph  1
    a[2,24]   physical_G_upper  1
    a[2,25]   R1331     1
    a[2,25]   R1332     1
    a[2,25]   true_G_epigraph  1
    a[2,25]   physical_G_upper  1
    a[2,26]   R1333     1
    a[2,26]   R1334     1
    a[2,26]   true_G_epigraph  1
    a[2,26]   physical_G_upper  1
    a[2,27]   R1335     1
    a[2,27]   R1336     1
    a[2,27]   true_G_epigraph  1
    a[2,27]   physical_G_upper  1
    a[2,28]   R1337     1
    a[2,28]   R1338     1
    a[2,28]   true_G_epigraph  1
    a[2,28]   physical_G_upper  1
    a[2,29]   R1339     1
    a[2,29]   R1340     1
    a[2,29]   true_G_epigraph  1
    a[2,29]   physical_G_upper  1
    a[2,30]   R1341     1
    a[2,30]   R1342     1
    a[2,30]   true_G_epigraph  1
    a[2,30]   physical_G_upper  1
    a[2,31]   R1343     1
    a[2,31]   R1344     1
    a[2,31]   true_G_epigraph  1
    a[2,31]   physical_G_upper  1
    a[2,32]   R1345     1
    a[2,32]   R1346     1
    a[2,32]   true_G_epigraph  1
    a[2,32]   physical_G_upper  1
    a[2,33]   R1347     1
    a[2,33]   R1348     1
    a[2,33]   true_G_epigraph  1
    a[2,33]   physical_G_upper  1
    a[2,34]   R1349     1
    a[2,34]   R1350     1
    a[2,34]   true_G_epigraph  1
    a[2,34]   physical_G_upper  1
    a[2,35]   R1351     1
    a[2,35]   R1352     1
    a[2,35]   true_G_epigraph  1
    a[2,35]   physical_G_upper  1
    a[3,4]    R1353     1
    a[3,4]    R1354     1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,5]    R1355     1
    a[3,5]    R1356     1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,6]    R1357     1
    a[3,6]    R1358     1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,7]    R1359     1
    a[3,7]    R1360     1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,8]    R1361     1
    a[3,8]    R1362     1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,9]    R1363     1
    a[3,9]    R1364     1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,10]   R1365     1
    a[3,10]   R1366     1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,11]   R1367     1
    a[3,11]   R1368     1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,12]   R1369     1
    a[3,12]   R1370     1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,13]   R1371     1
    a[3,13]   R1372     1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,14]   R1373     1
    a[3,14]   R1374     1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,15]   R1375     1
    a[3,15]   R1376     1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,16]   R1377     1
    a[3,16]   R1378     1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,17]   R1379     1
    a[3,17]   R1380     1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,18]   R1381     1
    a[3,18]   R1382     1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,19]   R1383     1
    a[3,19]   R1384     1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,20]   R1385     1
    a[3,20]   R1386     1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[3,21]   R1387     1
    a[3,21]   R1388     1
    a[3,21]   true_G_epigraph  1
    a[3,21]   physical_G_upper  1
    a[3,22]   R1389     1
    a[3,22]   R1390     1
    a[3,22]   true_G_epigraph  1
    a[3,22]   physical_G_upper  1
    a[3,23]   R1391     1
    a[3,23]   R1392     1
    a[3,23]   true_G_epigraph  1
    a[3,23]   physical_G_upper  1
    a[3,24]   R1393     1
    a[3,24]   R1394     1
    a[3,24]   true_G_epigraph  1
    a[3,24]   physical_G_upper  1
    a[3,25]   R1395     1
    a[3,25]   R1396     1
    a[3,25]   true_G_epigraph  1
    a[3,25]   physical_G_upper  1
    a[3,26]   R1397     1
    a[3,26]   R1398     1
    a[3,26]   true_G_epigraph  1
    a[3,26]   physical_G_upper  1
    a[3,27]   R1399     1
    a[3,27]   R1400     1
    a[3,27]   true_G_epigraph  1
    a[3,27]   physical_G_upper  1
    a[3,28]   R1401     1
    a[3,28]   R1402     1
    a[3,28]   true_G_epigraph  1
    a[3,28]   physical_G_upper  1
    a[3,29]   R1403     1
    a[3,29]   R1404     1
    a[3,29]   true_G_epigraph  1
    a[3,29]   physical_G_upper  1
    a[3,30]   R1405     1
    a[3,30]   R1406     1
    a[3,30]   true_G_epigraph  1
    a[3,30]   physical_G_upper  1
    a[3,31]   R1407     1
    a[3,31]   R1408     1
    a[3,31]   true_G_epigraph  1
    a[3,31]   physical_G_upper  1
    a[3,32]   R1409     1
    a[3,32]   R1410     1
    a[3,32]   true_G_epigraph  1
    a[3,32]   physical_G_upper  1
    a[3,33]   R1411     1
    a[3,33]   R1412     1
    a[3,33]   true_G_epigraph  1
    a[3,33]   physical_G_upper  1
    a[3,34]   R1413     1
    a[3,34]   R1414     1
    a[3,34]   true_G_epigraph  1
    a[3,34]   physical_G_upper  1
    a[3,35]   R1415     1
    a[3,35]   R1416     1
    a[3,35]   true_G_epigraph  1
    a[3,35]   physical_G_upper  1
    a[4,5]    R1417     1
    a[4,5]    R1418     1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,6]    R1419     1
    a[4,6]    R1420     1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,7]    R1421     1
    a[4,7]    R1422     1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,8]    R1423     1
    a[4,8]    R1424     1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,9]    R1425     1
    a[4,9]    R1426     1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,10]   R1427     1
    a[4,10]   R1428     1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,11]   R1429     1
    a[4,11]   R1430     1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,12]   R1431     1
    a[4,12]   R1432     1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,13]   R1433     1
    a[4,13]   R1434     1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,14]   R1435     1
    a[4,14]   R1436     1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,15]   R1437     1
    a[4,15]   R1438     1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,16]   R1439     1
    a[4,16]   R1440     1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,17]   R1441     1
    a[4,17]   R1442     1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,18]   R1443     1
    a[4,18]   R1444     1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,19]   R1445     1
    a[4,19]   R1446     1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,20]   R1447     1
    a[4,20]   R1448     1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[4,21]   R1449     1
    a[4,21]   R1450     1
    a[4,21]   true_G_epigraph  1
    a[4,21]   physical_G_upper  1
    a[4,22]   R1451     1
    a[4,22]   R1452     1
    a[4,22]   true_G_epigraph  1
    a[4,22]   physical_G_upper  1
    a[4,23]   R1453     1
    a[4,23]   R1454     1
    a[4,23]   true_G_epigraph  1
    a[4,23]   physical_G_upper  1
    a[4,24]   R1455     1
    a[4,24]   R1456     1
    a[4,24]   true_G_epigraph  1
    a[4,24]   physical_G_upper  1
    a[4,25]   R1457     1
    a[4,25]   R1458     1
    a[4,25]   true_G_epigraph  1
    a[4,25]   physical_G_upper  1
    a[4,26]   R1459     1
    a[4,26]   R1460     1
    a[4,26]   true_G_epigraph  1
    a[4,26]   physical_G_upper  1
    a[4,27]   R1461     1
    a[4,27]   R1462     1
    a[4,27]   true_G_epigraph  1
    a[4,27]   physical_G_upper  1
    a[4,28]   R1463     1
    a[4,28]   R1464     1
    a[4,28]   true_G_epigraph  1
    a[4,28]   physical_G_upper  1
    a[4,29]   R1465     1
    a[4,29]   R1466     1
    a[4,29]   true_G_epigraph  1
    a[4,29]   physical_G_upper  1
    a[4,30]   R1467     1
    a[4,30]   R1468     1
    a[4,30]   true_G_epigraph  1
    a[4,30]   physical_G_upper  1
    a[4,31]   R1469     1
    a[4,31]   R1470     1
    a[4,31]   true_G_epigraph  1
    a[4,31]   physical_G_upper  1
    a[4,32]   R1471     1
    a[4,32]   R1472     1
    a[4,32]   true_G_epigraph  1
    a[4,32]   physical_G_upper  1
    a[4,33]   R1473     1
    a[4,33]   R1474     1
    a[4,33]   true_G_epigraph  1
    a[4,33]   physical_G_upper  1
    a[4,34]   R1475     1
    a[4,34]   R1476     1
    a[4,34]   true_G_epigraph  1
    a[4,34]   physical_G_upper  1
    a[4,35]   R1477     1
    a[4,35]   R1478     1
    a[4,35]   true_G_epigraph  1
    a[4,35]   physical_G_upper  1
    a[5,6]    R1479     1
    a[5,6]    R1480     1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,7]    R1481     1
    a[5,7]    R1482     1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,8]    R1483     1
    a[5,8]    R1484     1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,9]    R1485     1
    a[5,9]    R1486     1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,10]   R1487     1
    a[5,10]   R1488     1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,11]   R1489     1
    a[5,11]   R1490     1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,12]   R1491     1
    a[5,12]   R1492     1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,13]   R1493     1
    a[5,13]   R1494     1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,14]   R1495     1
    a[5,14]   R1496     1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,15]   R1497     1
    a[5,15]   R1498     1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,16]   R1499     1
    a[5,16]   R1500     1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,17]   R1501     1
    a[5,17]   R1502     1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,18]   R1503     1
    a[5,18]   R1504     1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,19]   R1505     1
    a[5,19]   R1506     1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,20]   R1507     1
    a[5,20]   R1508     1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[5,21]   R1509     1
    a[5,21]   R1510     1
    a[5,21]   true_G_epigraph  1
    a[5,21]   physical_G_upper  1
    a[5,22]   R1511     1
    a[5,22]   R1512     1
    a[5,22]   true_G_epigraph  1
    a[5,22]   physical_G_upper  1
    a[5,23]   R1513     1
    a[5,23]   R1514     1
    a[5,23]   true_G_epigraph  1
    a[5,23]   physical_G_upper  1
    a[5,24]   R1515     1
    a[5,24]   R1516     1
    a[5,24]   true_G_epigraph  1
    a[5,24]   physical_G_upper  1
    a[5,25]   R1517     1
    a[5,25]   R1518     1
    a[5,25]   true_G_epigraph  1
    a[5,25]   physical_G_upper  1
    a[5,26]   R1519     1
    a[5,26]   R1520     1
    a[5,26]   true_G_epigraph  1
    a[5,26]   physical_G_upper  1
    a[5,27]   R1521     1
    a[5,27]   R1522     1
    a[5,27]   true_G_epigraph  1
    a[5,27]   physical_G_upper  1
    a[5,28]   R1523     1
    a[5,28]   R1524     1
    a[5,28]   true_G_epigraph  1
    a[5,28]   physical_G_upper  1
    a[5,29]   R1525     1
    a[5,29]   R1526     1
    a[5,29]   true_G_epigraph  1
    a[5,29]   physical_G_upper  1
    a[5,30]   R1527     1
    a[5,30]   R1528     1
    a[5,30]   true_G_epigraph  1
    a[5,30]   physical_G_upper  1
    a[5,31]   R1529     1
    a[5,31]   R1530     1
    a[5,31]   true_G_epigraph  1
    a[5,31]   physical_G_upper  1
    a[5,32]   R1531     1
    a[5,32]   R1532     1
    a[5,32]   true_G_epigraph  1
    a[5,32]   physical_G_upper  1
    a[5,33]   R1533     1
    a[5,33]   R1534     1
    a[5,33]   true_G_epigraph  1
    a[5,33]   physical_G_upper  1
    a[5,34]   R1535     1
    a[5,34]   R1536     1
    a[5,34]   true_G_epigraph  1
    a[5,34]   physical_G_upper  1
    a[5,35]   R1537     1
    a[5,35]   R1538     1
    a[5,35]   true_G_epigraph  1
    a[5,35]   physical_G_upper  1
    a[6,7]    R1539     1
    a[6,7]    R1540     1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,8]    R1541     1
    a[6,8]    R1542     1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,9]    R1543     1
    a[6,9]    R1544     1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,10]   R1545     1
    a[6,10]   R1546     1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,11]   R1547     1
    a[6,11]   R1548     1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,12]   R1549     1
    a[6,12]   R1550     1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,13]   R1551     1
    a[6,13]   R1552     1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,14]   R1553     1
    a[6,14]   R1554     1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,15]   R1555     1
    a[6,15]   R1556     1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,16]   R1557     1
    a[6,16]   R1558     1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,17]   R1559     1
    a[6,17]   R1560     1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,18]   R1561     1
    a[6,18]   R1562     1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,19]   R1563     1
    a[6,19]   R1564     1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,20]   R1565     1
    a[6,20]   R1566     1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[6,21]   R1567     1
    a[6,21]   R1568     1
    a[6,21]   true_G_epigraph  1
    a[6,21]   physical_G_upper  1
    a[6,22]   R1569     1
    a[6,22]   R1570     1
    a[6,22]   true_G_epigraph  1
    a[6,22]   physical_G_upper  1
    a[6,23]   R1571     1
    a[6,23]   R1572     1
    a[6,23]   true_G_epigraph  1
    a[6,23]   physical_G_upper  1
    a[6,24]   R1573     1
    a[6,24]   R1574     1
    a[6,24]   true_G_epigraph  1
    a[6,24]   physical_G_upper  1
    a[6,25]   R1575     1
    a[6,25]   R1576     1
    a[6,25]   true_G_epigraph  1
    a[6,25]   physical_G_upper  1
    a[6,26]   R1577     1
    a[6,26]   R1578     1
    a[6,26]   true_G_epigraph  1
    a[6,26]   physical_G_upper  1
    a[6,27]   R1579     1
    a[6,27]   R1580     1
    a[6,27]   true_G_epigraph  1
    a[6,27]   physical_G_upper  1
    a[6,28]   R1581     1
    a[6,28]   R1582     1
    a[6,28]   true_G_epigraph  1
    a[6,28]   physical_G_upper  1
    a[6,29]   R1583     1
    a[6,29]   R1584     1
    a[6,29]   true_G_epigraph  1
    a[6,29]   physical_G_upper  1
    a[6,30]   R1585     1
    a[6,30]   R1586     1
    a[6,30]   true_G_epigraph  1
    a[6,30]   physical_G_upper  1
    a[6,31]   R1587     1
    a[6,31]   R1588     1
    a[6,31]   true_G_epigraph  1
    a[6,31]   physical_G_upper  1
    a[6,32]   R1589     1
    a[6,32]   R1590     1
    a[6,32]   true_G_epigraph  1
    a[6,32]   physical_G_upper  1
    a[6,33]   R1591     1
    a[6,33]   R1592     1
    a[6,33]   true_G_epigraph  1
    a[6,33]   physical_G_upper  1
    a[6,34]   R1593     1
    a[6,34]   R1594     1
    a[6,34]   true_G_epigraph  1
    a[6,34]   physical_G_upper  1
    a[6,35]   R1595     1
    a[6,35]   R1596     1
    a[6,35]   true_G_epigraph  1
    a[6,35]   physical_G_upper  1
    a[7,8]    R1597     1
    a[7,8]    R1598     1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,9]    R1599     1
    a[7,9]    R1600     1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,10]   R1601     1
    a[7,10]   R1602     1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,11]   R1603     1
    a[7,11]   R1604     1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,12]   R1605     1
    a[7,12]   R1606     1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,13]   R1607     1
    a[7,13]   R1608     1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,14]   R1609     1
    a[7,14]   R1610     1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,15]   R1611     1
    a[7,15]   R1612     1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,16]   R1613     1
    a[7,16]   R1614     1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,17]   R1615     1
    a[7,17]   R1616     1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,18]   R1617     1
    a[7,18]   R1618     1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,19]   R1619     1
    a[7,19]   R1620     1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,20]   R1621     1
    a[7,20]   R1622     1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[7,21]   R1623     1
    a[7,21]   R1624     1
    a[7,21]   true_G_epigraph  1
    a[7,21]   physical_G_upper  1
    a[7,22]   R1625     1
    a[7,22]   R1626     1
    a[7,22]   true_G_epigraph  1
    a[7,22]   physical_G_upper  1
    a[7,23]   R1627     1
    a[7,23]   R1628     1
    a[7,23]   true_G_epigraph  1
    a[7,23]   physical_G_upper  1
    a[7,24]   R1629     1
    a[7,24]   R1630     1
    a[7,24]   true_G_epigraph  1
    a[7,24]   physical_G_upper  1
    a[7,25]   R1631     1
    a[7,25]   R1632     1
    a[7,25]   true_G_epigraph  1
    a[7,25]   physical_G_upper  1
    a[7,26]   R1633     1
    a[7,26]   R1634     1
    a[7,26]   true_G_epigraph  1
    a[7,26]   physical_G_upper  1
    a[7,27]   R1635     1
    a[7,27]   R1636     1
    a[7,27]   true_G_epigraph  1
    a[7,27]   physical_G_upper  1
    a[7,28]   R1637     1
    a[7,28]   R1638     1
    a[7,28]   true_G_epigraph  1
    a[7,28]   physical_G_upper  1
    a[7,29]   R1639     1
    a[7,29]   R1640     1
    a[7,29]   true_G_epigraph  1
    a[7,29]   physical_G_upper  1
    a[7,30]   R1641     1
    a[7,30]   R1642     1
    a[7,30]   true_G_epigraph  1
    a[7,30]   physical_G_upper  1
    a[7,31]   R1643     1
    a[7,31]   R1644     1
    a[7,31]   true_G_epigraph  1
    a[7,31]   physical_G_upper  1
    a[7,32]   R1645     1
    a[7,32]   R1646     1
    a[7,32]   true_G_epigraph  1
    a[7,32]   physical_G_upper  1
    a[7,33]   R1647     1
    a[7,33]   R1648     1
    a[7,33]   true_G_epigraph  1
    a[7,33]   physical_G_upper  1
    a[7,34]   R1649     1
    a[7,34]   R1650     1
    a[7,34]   true_G_epigraph  1
    a[7,34]   physical_G_upper  1
    a[7,35]   R1651     1
    a[7,35]   R1652     1
    a[7,35]   true_G_epigraph  1
    a[7,35]   physical_G_upper  1
    a[8,9]    R1653     1
    a[8,9]    R1654     1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,10]   R1655     1
    a[8,10]   R1656     1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,11]   R1657     1
    a[8,11]   R1658     1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,12]   R1659     1
    a[8,12]   R1660     1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,13]   R1661     1
    a[8,13]   R1662     1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,14]   R1663     1
    a[8,14]   R1664     1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,15]   R1665     1
    a[8,15]   R1666     1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,16]   R1667     1
    a[8,16]   R1668     1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,17]   R1669     1
    a[8,17]   R1670     1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,18]   R1671     1
    a[8,18]   R1672     1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,19]   R1673     1
    a[8,19]   R1674     1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,20]   R1675     1
    a[8,20]   R1676     1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[8,21]   R1677     1
    a[8,21]   R1678     1
    a[8,21]   true_G_epigraph  1
    a[8,21]   physical_G_upper  1
    a[8,22]   R1679     1
    a[8,22]   R1680     1
    a[8,22]   true_G_epigraph  1
    a[8,22]   physical_G_upper  1
    a[8,23]   R1681     1
    a[8,23]   R1682     1
    a[8,23]   true_G_epigraph  1
    a[8,23]   physical_G_upper  1
    a[8,24]   R1683     1
    a[8,24]   R1684     1
    a[8,24]   true_G_epigraph  1
    a[8,24]   physical_G_upper  1
    a[8,25]   R1685     1
    a[8,25]   R1686     1
    a[8,25]   true_G_epigraph  1
    a[8,25]   physical_G_upper  1
    a[8,26]   R1687     1
    a[8,26]   R1688     1
    a[8,26]   true_G_epigraph  1
    a[8,26]   physical_G_upper  1
    a[8,27]   R1689     1
    a[8,27]   R1690     1
    a[8,27]   true_G_epigraph  1
    a[8,27]   physical_G_upper  1
    a[8,28]   R1691     1
    a[8,28]   R1692     1
    a[8,28]   true_G_epigraph  1
    a[8,28]   physical_G_upper  1
    a[8,29]   R1693     1
    a[8,29]   R1694     1
    a[8,29]   true_G_epigraph  1
    a[8,29]   physical_G_upper  1
    a[8,30]   R1695     1
    a[8,30]   R1696     1
    a[8,30]   true_G_epigraph  1
    a[8,30]   physical_G_upper  1
    a[8,31]   R1697     1
    a[8,31]   R1698     1
    a[8,31]   true_G_epigraph  1
    a[8,31]   physical_G_upper  1
    a[8,32]   R1699     1
    a[8,32]   R1700     1
    a[8,32]   true_G_epigraph  1
    a[8,32]   physical_G_upper  1
    a[8,33]   R1701     1
    a[8,33]   R1702     1
    a[8,33]   true_G_epigraph  1
    a[8,33]   physical_G_upper  1
    a[8,34]   R1703     1
    a[8,34]   R1704     1
    a[8,34]   true_G_epigraph  1
    a[8,34]   physical_G_upper  1
    a[8,35]   R1705     1
    a[8,35]   R1706     1
    a[8,35]   true_G_epigraph  1
    a[8,35]   physical_G_upper  1
    a[9,10]   R1707     1
    a[9,10]   R1708     1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,11]   R1709     1
    a[9,11]   R1710     1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,12]   R1711     1
    a[9,12]   R1712     1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,13]   R1713     1
    a[9,13]   R1714     1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,14]   R1715     1
    a[9,14]   R1716     1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,15]   R1717     1
    a[9,15]   R1718     1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,16]   R1719     1
    a[9,16]   R1720     1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,17]   R1721     1
    a[9,17]   R1722     1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,18]   R1723     1
    a[9,18]   R1724     1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,19]   R1725     1
    a[9,19]   R1726     1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,20]   R1727     1
    a[9,20]   R1728     1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[9,21]   R1729     1
    a[9,21]   R1730     1
    a[9,21]   true_G_epigraph  1
    a[9,21]   physical_G_upper  1
    a[9,22]   R1731     1
    a[9,22]   R1732     1
    a[9,22]   true_G_epigraph  1
    a[9,22]   physical_G_upper  1
    a[9,23]   R1733     1
    a[9,23]   R1734     1
    a[9,23]   true_G_epigraph  1
    a[9,23]   physical_G_upper  1
    a[9,24]   R1735     1
    a[9,24]   R1736     1
    a[9,24]   true_G_epigraph  1
    a[9,24]   physical_G_upper  1
    a[9,25]   R1737     1
    a[9,25]   R1738     1
    a[9,25]   true_G_epigraph  1
    a[9,25]   physical_G_upper  1
    a[9,26]   R1739     1
    a[9,26]   R1740     1
    a[9,26]   true_G_epigraph  1
    a[9,26]   physical_G_upper  1
    a[9,27]   R1741     1
    a[9,27]   R1742     1
    a[9,27]   true_G_epigraph  1
    a[9,27]   physical_G_upper  1
    a[9,28]   R1743     1
    a[9,28]   R1744     1
    a[9,28]   true_G_epigraph  1
    a[9,28]   physical_G_upper  1
    a[9,29]   R1745     1
    a[9,29]   R1746     1
    a[9,29]   true_G_epigraph  1
    a[9,29]   physical_G_upper  1
    a[9,30]   R1747     1
    a[9,30]   R1748     1
    a[9,30]   true_G_epigraph  1
    a[9,30]   physical_G_upper  1
    a[9,31]   R1749     1
    a[9,31]   R1750     1
    a[9,31]   true_G_epigraph  1
    a[9,31]   physical_G_upper  1
    a[9,32]   R1751     1
    a[9,32]   R1752     1
    a[9,32]   true_G_epigraph  1
    a[9,32]   physical_G_upper  1
    a[9,33]   R1753     1
    a[9,33]   R1754     1
    a[9,33]   true_G_epigraph  1
    a[9,33]   physical_G_upper  1
    a[9,34]   R1755     1
    a[9,34]   R1756     1
    a[9,34]   true_G_epigraph  1
    a[9,34]   physical_G_upper  1
    a[9,35]   R1757     1
    a[9,35]   R1758     1
    a[9,35]   true_G_epigraph  1
    a[9,35]   physical_G_upper  1
    a[10,11]  R1759     1
    a[10,11]  R1760     1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,12]  R1761     1
    a[10,12]  R1762     1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,13]  R1763     1
    a[10,13]  R1764     1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,14]  R1765     1
    a[10,14]  R1766     1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,15]  R1767     1
    a[10,15]  R1768     1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,16]  R1769     1
    a[10,16]  R1770     1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,17]  R1771     1
    a[10,17]  R1772     1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,18]  R1773     1
    a[10,18]  R1774     1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,19]  R1775     1
    a[10,19]  R1776     1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,20]  R1777     1
    a[10,20]  R1778     1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[10,21]  R1779     1
    a[10,21]  R1780     1
    a[10,21]  true_G_epigraph  1
    a[10,21]  physical_G_upper  1
    a[10,22]  R1781     1
    a[10,22]  R1782     1
    a[10,22]  true_G_epigraph  1
    a[10,22]  physical_G_upper  1
    a[10,23]  R1783     1
    a[10,23]  R1784     1
    a[10,23]  true_G_epigraph  1
    a[10,23]  physical_G_upper  1
    a[10,24]  R1785     1
    a[10,24]  R1786     1
    a[10,24]  true_G_epigraph  1
    a[10,24]  physical_G_upper  1
    a[10,25]  R1787     1
    a[10,25]  R1788     1
    a[10,25]  true_G_epigraph  1
    a[10,25]  physical_G_upper  1
    a[10,26]  R1789     1
    a[10,26]  R1790     1
    a[10,26]  true_G_epigraph  1
    a[10,26]  physical_G_upper  1
    a[10,27]  R1791     1
    a[10,27]  R1792     1
    a[10,27]  true_G_epigraph  1
    a[10,27]  physical_G_upper  1
    a[10,28]  R1793     1
    a[10,28]  R1794     1
    a[10,28]  true_G_epigraph  1
    a[10,28]  physical_G_upper  1
    a[10,29]  R1795     1
    a[10,29]  R1796     1
    a[10,29]  true_G_epigraph  1
    a[10,29]  physical_G_upper  1
    a[10,30]  R1797     1
    a[10,30]  R1798     1
    a[10,30]  true_G_epigraph  1
    a[10,30]  physical_G_upper  1
    a[10,31]  R1799     1
    a[10,31]  R1800     1
    a[10,31]  true_G_epigraph  1
    a[10,31]  physical_G_upper  1
    a[10,32]  R1801     1
    a[10,32]  R1802     1
    a[10,32]  true_G_epigraph  1
    a[10,32]  physical_G_upper  1
    a[10,33]  R1803     1
    a[10,33]  R1804     1
    a[10,33]  true_G_epigraph  1
    a[10,33]  physical_G_upper  1
    a[10,34]  R1805     1
    a[10,34]  R1806     1
    a[10,34]  true_G_epigraph  1
    a[10,34]  physical_G_upper  1
    a[10,35]  R1807     1
    a[10,35]  R1808     1
    a[10,35]  true_G_epigraph  1
    a[10,35]  physical_G_upper  1
    a[11,12]  R1809     1
    a[11,12]  R1810     1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,13]  R1811     1
    a[11,13]  R1812     1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,14]  R1813     1
    a[11,14]  R1814     1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,15]  R1815     1
    a[11,15]  R1816     1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,16]  R1817     1
    a[11,16]  R1818     1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,17]  R1819     1
    a[11,17]  R1820     1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,18]  R1821     1
    a[11,18]  R1822     1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,19]  R1823     1
    a[11,19]  R1824     1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,20]  R1825     1
    a[11,20]  R1826     1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[11,21]  R1827     1
    a[11,21]  R1828     1
    a[11,21]  true_G_epigraph  1
    a[11,21]  physical_G_upper  1
    a[11,22]  R1829     1
    a[11,22]  R1830     1
    a[11,22]  true_G_epigraph  1
    a[11,22]  physical_G_upper  1
    a[11,23]  R1831     1
    a[11,23]  R1832     1
    a[11,23]  true_G_epigraph  1
    a[11,23]  physical_G_upper  1
    a[11,24]  R1833     1
    a[11,24]  R1834     1
    a[11,24]  true_G_epigraph  1
    a[11,24]  physical_G_upper  1
    a[11,25]  R1835     1
    a[11,25]  R1836     1
    a[11,25]  true_G_epigraph  1
    a[11,25]  physical_G_upper  1
    a[11,26]  R1837     1
    a[11,26]  R1838     1
    a[11,26]  true_G_epigraph  1
    a[11,26]  physical_G_upper  1
    a[11,27]  R1839     1
    a[11,27]  R1840     1
    a[11,27]  true_G_epigraph  1
    a[11,27]  physical_G_upper  1
    a[11,28]  R1841     1
    a[11,28]  R1842     1
    a[11,28]  true_G_epigraph  1
    a[11,28]  physical_G_upper  1
    a[11,29]  R1843     1
    a[11,29]  R1844     1
    a[11,29]  true_G_epigraph  1
    a[11,29]  physical_G_upper  1
    a[11,30]  R1845     1
    a[11,30]  R1846     1
    a[11,30]  true_G_epigraph  1
    a[11,30]  physical_G_upper  1
    a[11,31]  R1847     1
    a[11,31]  R1848     1
    a[11,31]  true_G_epigraph  1
    a[11,31]  physical_G_upper  1
    a[11,32]  R1849     1
    a[11,32]  R1850     1
    a[11,32]  true_G_epigraph  1
    a[11,32]  physical_G_upper  1
    a[11,33]  R1851     1
    a[11,33]  R1852     1
    a[11,33]  true_G_epigraph  1
    a[11,33]  physical_G_upper  1
    a[11,34]  R1853     1
    a[11,34]  R1854     1
    a[11,34]  true_G_epigraph  1
    a[11,34]  physical_G_upper  1
    a[11,35]  R1855     1
    a[11,35]  R1856     1
    a[11,35]  true_G_epigraph  1
    a[11,35]  physical_G_upper  1
    a[12,13]  R1857     1
    a[12,13]  R1858     1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,14]  R1859     1
    a[12,14]  R1860     1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,15]  R1861     1
    a[12,15]  R1862     1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,16]  R1863     1
    a[12,16]  R1864     1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,17]  R1865     1
    a[12,17]  R1866     1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,18]  R1867     1
    a[12,18]  R1868     1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,19]  R1869     1
    a[12,19]  R1870     1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,20]  R1871     1
    a[12,20]  R1872     1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[12,21]  R1873     1
    a[12,21]  R1874     1
    a[12,21]  true_G_epigraph  1
    a[12,21]  physical_G_upper  1
    a[12,22]  R1875     1
    a[12,22]  R1876     1
    a[12,22]  true_G_epigraph  1
    a[12,22]  physical_G_upper  1
    a[12,23]  R1877     1
    a[12,23]  R1878     1
    a[12,23]  true_G_epigraph  1
    a[12,23]  physical_G_upper  1
    a[12,24]  R1879     1
    a[12,24]  R1880     1
    a[12,24]  true_G_epigraph  1
    a[12,24]  physical_G_upper  1
    a[12,25]  R1881     1
    a[12,25]  R1882     1
    a[12,25]  true_G_epigraph  1
    a[12,25]  physical_G_upper  1
    a[12,26]  R1883     1
    a[12,26]  R1884     1
    a[12,26]  true_G_epigraph  1
    a[12,26]  physical_G_upper  1
    a[12,27]  R1885     1
    a[12,27]  R1886     1
    a[12,27]  true_G_epigraph  1
    a[12,27]  physical_G_upper  1
    a[12,28]  R1887     1
    a[12,28]  R1888     1
    a[12,28]  true_G_epigraph  1
    a[12,28]  physical_G_upper  1
    a[12,29]  R1889     1
    a[12,29]  R1890     1
    a[12,29]  true_G_epigraph  1
    a[12,29]  physical_G_upper  1
    a[12,30]  R1891     1
    a[12,30]  R1892     1
    a[12,30]  true_G_epigraph  1
    a[12,30]  physical_G_upper  1
    a[12,31]  R1893     1
    a[12,31]  R1894     1
    a[12,31]  true_G_epigraph  1
    a[12,31]  physical_G_upper  1
    a[12,32]  R1895     1
    a[12,32]  R1896     1
    a[12,32]  true_G_epigraph  1
    a[12,32]  physical_G_upper  1
    a[12,33]  R1897     1
    a[12,33]  R1898     1
    a[12,33]  true_G_epigraph  1
    a[12,33]  physical_G_upper  1
    a[12,34]  R1899     1
    a[12,34]  R1900     1
    a[12,34]  true_G_epigraph  1
    a[12,34]  physical_G_upper  1
    a[12,35]  R1901     1
    a[12,35]  R1902     1
    a[12,35]  true_G_epigraph  1
    a[12,35]  physical_G_upper  1
    a[13,14]  R1903     1
    a[13,14]  R1904     1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,15]  R1905     1
    a[13,15]  R1906     1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,16]  R1907     1
    a[13,16]  R1908     1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,17]  R1909     1
    a[13,17]  R1910     1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,18]  R1911     1
    a[13,18]  R1912     1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,19]  R1913     1
    a[13,19]  R1914     1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,20]  R1915     1
    a[13,20]  R1916     1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[13,21]  R1917     1
    a[13,21]  R1918     1
    a[13,21]  true_G_epigraph  1
    a[13,21]  physical_G_upper  1
    a[13,22]  R1919     1
    a[13,22]  R1920     1
    a[13,22]  true_G_epigraph  1
    a[13,22]  physical_G_upper  1
    a[13,23]  R1921     1
    a[13,23]  R1922     1
    a[13,23]  true_G_epigraph  1
    a[13,23]  physical_G_upper  1
    a[13,24]  R1923     1
    a[13,24]  R1924     1
    a[13,24]  true_G_epigraph  1
    a[13,24]  physical_G_upper  1
    a[13,25]  R1925     1
    a[13,25]  R1926     1
    a[13,25]  true_G_epigraph  1
    a[13,25]  physical_G_upper  1
    a[13,26]  R1927     1
    a[13,26]  R1928     1
    a[13,26]  true_G_epigraph  1
    a[13,26]  physical_G_upper  1
    a[13,27]  R1929     1
    a[13,27]  R1930     1
    a[13,27]  true_G_epigraph  1
    a[13,27]  physical_G_upper  1
    a[13,28]  R1931     1
    a[13,28]  R1932     1
    a[13,28]  true_G_epigraph  1
    a[13,28]  physical_G_upper  1
    a[13,29]  R1933     1
    a[13,29]  R1934     1
    a[13,29]  true_G_epigraph  1
    a[13,29]  physical_G_upper  1
    a[13,30]  R1935     1
    a[13,30]  R1936     1
    a[13,30]  true_G_epigraph  1
    a[13,30]  physical_G_upper  1
    a[13,31]  R1937     1
    a[13,31]  R1938     1
    a[13,31]  true_G_epigraph  1
    a[13,31]  physical_G_upper  1
    a[13,32]  R1939     1
    a[13,32]  R1940     1
    a[13,32]  true_G_epigraph  1
    a[13,32]  physical_G_upper  1
    a[13,33]  R1941     1
    a[13,33]  R1942     1
    a[13,33]  true_G_epigraph  1
    a[13,33]  physical_G_upper  1
    a[13,34]  R1943     1
    a[13,34]  R1944     1
    a[13,34]  true_G_epigraph  1
    a[13,34]  physical_G_upper  1
    a[13,35]  R1945     1
    a[13,35]  R1946     1
    a[13,35]  true_G_epigraph  1
    a[13,35]  physical_G_upper  1
    a[14,15]  R1947     1
    a[14,15]  R1948     1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,16]  R1949     1
    a[14,16]  R1950     1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,17]  R1951     1
    a[14,17]  R1952     1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,18]  R1953     1
    a[14,18]  R1954     1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,19]  R1955     1
    a[14,19]  R1956     1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,20]  R1957     1
    a[14,20]  R1958     1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[14,21]  R1959     1
    a[14,21]  R1960     1
    a[14,21]  true_G_epigraph  1
    a[14,21]  physical_G_upper  1
    a[14,22]  R1961     1
    a[14,22]  R1962     1
    a[14,22]  true_G_epigraph  1
    a[14,22]  physical_G_upper  1
    a[14,23]  R1963     1
    a[14,23]  R1964     1
    a[14,23]  true_G_epigraph  1
    a[14,23]  physical_G_upper  1
    a[14,24]  R1965     1
    a[14,24]  R1966     1
    a[14,24]  true_G_epigraph  1
    a[14,24]  physical_G_upper  1
    a[14,25]  R1967     1
    a[14,25]  R1968     1
    a[14,25]  true_G_epigraph  1
    a[14,25]  physical_G_upper  1
    a[14,26]  R1969     1
    a[14,26]  R1970     1
    a[14,26]  true_G_epigraph  1
    a[14,26]  physical_G_upper  1
    a[14,27]  R1971     1
    a[14,27]  R1972     1
    a[14,27]  true_G_epigraph  1
    a[14,27]  physical_G_upper  1
    a[14,28]  R1973     1
    a[14,28]  R1974     1
    a[14,28]  true_G_epigraph  1
    a[14,28]  physical_G_upper  1
    a[14,29]  R1975     1
    a[14,29]  R1976     1
    a[14,29]  true_G_epigraph  1
    a[14,29]  physical_G_upper  1
    a[14,30]  R1977     1
    a[14,30]  R1978     1
    a[14,30]  true_G_epigraph  1
    a[14,30]  physical_G_upper  1
    a[14,31]  R1979     1
    a[14,31]  R1980     1
    a[14,31]  true_G_epigraph  1
    a[14,31]  physical_G_upper  1
    a[14,32]  R1981     1
    a[14,32]  R1982     1
    a[14,32]  true_G_epigraph  1
    a[14,32]  physical_G_upper  1
    a[14,33]  R1983     1
    a[14,33]  R1984     1
    a[14,33]  true_G_epigraph  1
    a[14,33]  physical_G_upper  1
    a[14,34]  R1985     1
    a[14,34]  R1986     1
    a[14,34]  true_G_epigraph  1
    a[14,34]  physical_G_upper  1
    a[14,35]  R1987     1
    a[14,35]  R1988     1
    a[14,35]  true_G_epigraph  1
    a[14,35]  physical_G_upper  1
    a[15,16]  R1989     1
    a[15,16]  R1990     1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,17]  R1991     1
    a[15,17]  R1992     1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,18]  R1993     1
    a[15,18]  R1994     1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,19]  R1995     1
    a[15,19]  R1996     1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,20]  R1997     1
    a[15,20]  R1998     1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[15,21]  R1999     1
    a[15,21]  R2000     1
    a[15,21]  true_G_epigraph  1
    a[15,21]  physical_G_upper  1
    a[15,22]  R2001     1
    a[15,22]  R2002     1
    a[15,22]  true_G_epigraph  1
    a[15,22]  physical_G_upper  1
    a[15,23]  R2003     1
    a[15,23]  R2004     1
    a[15,23]  true_G_epigraph  1
    a[15,23]  physical_G_upper  1
    a[15,24]  R2005     1
    a[15,24]  R2006     1
    a[15,24]  true_G_epigraph  1
    a[15,24]  physical_G_upper  1
    a[15,25]  R2007     1
    a[15,25]  R2008     1
    a[15,25]  true_G_epigraph  1
    a[15,25]  physical_G_upper  1
    a[15,26]  R2009     1
    a[15,26]  R2010     1
    a[15,26]  true_G_epigraph  1
    a[15,26]  physical_G_upper  1
    a[15,27]  R2011     1
    a[15,27]  R2012     1
    a[15,27]  true_G_epigraph  1
    a[15,27]  physical_G_upper  1
    a[15,28]  R2013     1
    a[15,28]  R2014     1
    a[15,28]  true_G_epigraph  1
    a[15,28]  physical_G_upper  1
    a[15,29]  R2015     1
    a[15,29]  R2016     1
    a[15,29]  true_G_epigraph  1
    a[15,29]  physical_G_upper  1
    a[15,30]  R2017     1
    a[15,30]  R2018     1
    a[15,30]  true_G_epigraph  1
    a[15,30]  physical_G_upper  1
    a[15,31]  R2019     1
    a[15,31]  R2020     1
    a[15,31]  true_G_epigraph  1
    a[15,31]  physical_G_upper  1
    a[15,32]  R2021     1
    a[15,32]  R2022     1
    a[15,32]  true_G_epigraph  1
    a[15,32]  physical_G_upper  1
    a[15,33]  R2023     1
    a[15,33]  R2024     1
    a[15,33]  true_G_epigraph  1
    a[15,33]  physical_G_upper  1
    a[15,34]  R2025     1
    a[15,34]  R2026     1
    a[15,34]  true_G_epigraph  1
    a[15,34]  physical_G_upper  1
    a[15,35]  R2027     1
    a[15,35]  R2028     1
    a[15,35]  true_G_epigraph  1
    a[15,35]  physical_G_upper  1
    a[16,17]  R2029     1
    a[16,17]  R2030     1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,18]  R2031     1
    a[16,18]  R2032     1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,19]  R2033     1
    a[16,19]  R2034     1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,20]  R2035     1
    a[16,20]  R2036     1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[16,21]  R2037     1
    a[16,21]  R2038     1
    a[16,21]  true_G_epigraph  1
    a[16,21]  physical_G_upper  1
    a[16,22]  R2039     1
    a[16,22]  R2040     1
    a[16,22]  true_G_epigraph  1
    a[16,22]  physical_G_upper  1
    a[16,23]  R2041     1
    a[16,23]  R2042     1
    a[16,23]  true_G_epigraph  1
    a[16,23]  physical_G_upper  1
    a[16,24]  R2043     1
    a[16,24]  R2044     1
    a[16,24]  true_G_epigraph  1
    a[16,24]  physical_G_upper  1
    a[16,25]  R2045     1
    a[16,25]  R2046     1
    a[16,25]  true_G_epigraph  1
    a[16,25]  physical_G_upper  1
    a[16,26]  R2047     1
    a[16,26]  R2048     1
    a[16,26]  true_G_epigraph  1
    a[16,26]  physical_G_upper  1
    a[16,27]  R2049     1
    a[16,27]  R2050     1
    a[16,27]  true_G_epigraph  1
    a[16,27]  physical_G_upper  1
    a[16,28]  R2051     1
    a[16,28]  R2052     1
    a[16,28]  true_G_epigraph  1
    a[16,28]  physical_G_upper  1
    a[16,29]  R2053     1
    a[16,29]  R2054     1
    a[16,29]  true_G_epigraph  1
    a[16,29]  physical_G_upper  1
    a[16,30]  R2055     1
    a[16,30]  R2056     1
    a[16,30]  true_G_epigraph  1
    a[16,30]  physical_G_upper  1
    a[16,31]  R2057     1
    a[16,31]  R2058     1
    a[16,31]  true_G_epigraph  1
    a[16,31]  physical_G_upper  1
    a[16,32]  R2059     1
    a[16,32]  R2060     1
    a[16,32]  true_G_epigraph  1
    a[16,32]  physical_G_upper  1
    a[16,33]  R2061     1
    a[16,33]  R2062     1
    a[16,33]  true_G_epigraph  1
    a[16,33]  physical_G_upper  1
    a[16,34]  R2063     1
    a[16,34]  R2064     1
    a[16,34]  true_G_epigraph  1
    a[16,34]  physical_G_upper  1
    a[16,35]  R2065     1
    a[16,35]  R2066     1
    a[16,35]  true_G_epigraph  1
    a[16,35]  physical_G_upper  1
    a[17,18]  R2067     1
    a[17,18]  R2068     1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,19]  R2069     1
    a[17,19]  R2070     1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,20]  R2071     1
    a[17,20]  R2072     1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[17,21]  R2073     1
    a[17,21]  R2074     1
    a[17,21]  true_G_epigraph  1
    a[17,21]  physical_G_upper  1
    a[17,22]  R2075     1
    a[17,22]  R2076     1
    a[17,22]  true_G_epigraph  1
    a[17,22]  physical_G_upper  1
    a[17,23]  R2077     1
    a[17,23]  R2078     1
    a[17,23]  true_G_epigraph  1
    a[17,23]  physical_G_upper  1
    a[17,24]  R2079     1
    a[17,24]  R2080     1
    a[17,24]  true_G_epigraph  1
    a[17,24]  physical_G_upper  1
    a[17,25]  R2081     1
    a[17,25]  R2082     1
    a[17,25]  true_G_epigraph  1
    a[17,25]  physical_G_upper  1
    a[17,26]  R2083     1
    a[17,26]  R2084     1
    a[17,26]  true_G_epigraph  1
    a[17,26]  physical_G_upper  1
    a[17,27]  R2085     1
    a[17,27]  R2086     1
    a[17,27]  true_G_epigraph  1
    a[17,27]  physical_G_upper  1
    a[17,28]  R2087     1
    a[17,28]  R2088     1
    a[17,28]  true_G_epigraph  1
    a[17,28]  physical_G_upper  1
    a[17,29]  R2089     1
    a[17,29]  R2090     1
    a[17,29]  true_G_epigraph  1
    a[17,29]  physical_G_upper  1
    a[17,30]  R2091     1
    a[17,30]  R2092     1
    a[17,30]  true_G_epigraph  1
    a[17,30]  physical_G_upper  1
    a[17,31]  R2093     1
    a[17,31]  R2094     1
    a[17,31]  true_G_epigraph  1
    a[17,31]  physical_G_upper  1
    a[17,32]  R2095     1
    a[17,32]  R2096     1
    a[17,32]  true_G_epigraph  1
    a[17,32]  physical_G_upper  1
    a[17,33]  R2097     1
    a[17,33]  R2098     1
    a[17,33]  true_G_epigraph  1
    a[17,33]  physical_G_upper  1
    a[17,34]  R2099     1
    a[17,34]  R2100     1
    a[17,34]  true_G_epigraph  1
    a[17,34]  physical_G_upper  1
    a[17,35]  R2101     1
    a[17,35]  R2102     1
    a[17,35]  true_G_epigraph  1
    a[17,35]  physical_G_upper  1
    a[18,19]  R2103     1
    a[18,19]  R2104     1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,20]  R2105     1
    a[18,20]  R2106     1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[18,21]  R2107     1
    a[18,21]  R2108     1
    a[18,21]  true_G_epigraph  1
    a[18,21]  physical_G_upper  1
    a[18,22]  R2109     1
    a[18,22]  R2110     1
    a[18,22]  true_G_epigraph  1
    a[18,22]  physical_G_upper  1
    a[18,23]  R2111     1
    a[18,23]  R2112     1
    a[18,23]  true_G_epigraph  1
    a[18,23]  physical_G_upper  1
    a[18,24]  R2113     1
    a[18,24]  R2114     1
    a[18,24]  true_G_epigraph  1
    a[18,24]  physical_G_upper  1
    a[18,25]  R2115     1
    a[18,25]  R2116     1
    a[18,25]  true_G_epigraph  1
    a[18,25]  physical_G_upper  1
    a[18,26]  R2117     1
    a[18,26]  R2118     1
    a[18,26]  true_G_epigraph  1
    a[18,26]  physical_G_upper  1
    a[18,27]  R2119     1
    a[18,27]  R2120     1
    a[18,27]  true_G_epigraph  1
    a[18,27]  physical_G_upper  1
    a[18,28]  R2121     1
    a[18,28]  R2122     1
    a[18,28]  true_G_epigraph  1
    a[18,28]  physical_G_upper  1
    a[18,29]  R2123     1
    a[18,29]  R2124     1
    a[18,29]  true_G_epigraph  1
    a[18,29]  physical_G_upper  1
    a[18,30]  R2125     1
    a[18,30]  R2126     1
    a[18,30]  true_G_epigraph  1
    a[18,30]  physical_G_upper  1
    a[18,31]  R2127     1
    a[18,31]  R2128     1
    a[18,31]  true_G_epigraph  1
    a[18,31]  physical_G_upper  1
    a[18,32]  R2129     1
    a[18,32]  R2130     1
    a[18,32]  true_G_epigraph  1
    a[18,32]  physical_G_upper  1
    a[18,33]  R2131     1
    a[18,33]  R2132     1
    a[18,33]  true_G_epigraph  1
    a[18,33]  physical_G_upper  1
    a[18,34]  R2133     1
    a[18,34]  R2134     1
    a[18,34]  true_G_epigraph  1
    a[18,34]  physical_G_upper  1
    a[18,35]  R2135     1
    a[18,35]  R2136     1
    a[18,35]  true_G_epigraph  1
    a[18,35]  physical_G_upper  1
    a[19,20]  R2137     1
    a[19,20]  R2138     1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    a[19,21]  R2139     1
    a[19,21]  R2140     1
    a[19,21]  true_G_epigraph  1
    a[19,21]  physical_G_upper  1
    a[19,22]  R2141     1
    a[19,22]  R2142     1
    a[19,22]  true_G_epigraph  1
    a[19,22]  physical_G_upper  1
    a[19,23]  R2143     1
    a[19,23]  R2144     1
    a[19,23]  true_G_epigraph  1
    a[19,23]  physical_G_upper  1
    a[19,24]  R2145     1
    a[19,24]  R2146     1
    a[19,24]  true_G_epigraph  1
    a[19,24]  physical_G_upper  1
    a[19,25]  R2147     1
    a[19,25]  R2148     1
    a[19,25]  true_G_epigraph  1
    a[19,25]  physical_G_upper  1
    a[19,26]  R2149     1
    a[19,26]  R2150     1
    a[19,26]  true_G_epigraph  1
    a[19,26]  physical_G_upper  1
    a[19,27]  R2151     1
    a[19,27]  R2152     1
    a[19,27]  true_G_epigraph  1
    a[19,27]  physical_G_upper  1
    a[19,28]  R2153     1
    a[19,28]  R2154     1
    a[19,28]  true_G_epigraph  1
    a[19,28]  physical_G_upper  1
    a[19,29]  R2155     1
    a[19,29]  R2156     1
    a[19,29]  true_G_epigraph  1
    a[19,29]  physical_G_upper  1
    a[19,30]  R2157     1
    a[19,30]  R2158     1
    a[19,30]  true_G_epigraph  1
    a[19,30]  physical_G_upper  1
    a[19,31]  R2159     1
    a[19,31]  R2160     1
    a[19,31]  true_G_epigraph  1
    a[19,31]  physical_G_upper  1
    a[19,32]  R2161     1
    a[19,32]  R2162     1
    a[19,32]  true_G_epigraph  1
    a[19,32]  physical_G_upper  1
    a[19,33]  R2163     1
    a[19,33]  R2164     1
    a[19,33]  true_G_epigraph  1
    a[19,33]  physical_G_upper  1
    a[19,34]  R2165     1
    a[19,34]  R2166     1
    a[19,34]  true_G_epigraph  1
    a[19,34]  physical_G_upper  1
    a[19,35]  R2167     1
    a[19,35]  R2168     1
    a[19,35]  true_G_epigraph  1
    a[19,35]  physical_G_upper  1
    a[20,21]  R2169     1
    a[20,21]  R2170     1
    a[20,21]  true_G_epigraph  1
    a[20,21]  physical_G_upper  1
    a[20,22]  R2171     1
    a[20,22]  R2172     1
    a[20,22]  true_G_epigraph  1
    a[20,22]  physical_G_upper  1
    a[20,23]  R2173     1
    a[20,23]  R2174     1
    a[20,23]  true_G_epigraph  1
    a[20,23]  physical_G_upper  1
    a[20,24]  R2175     1
    a[20,24]  R2176     1
    a[20,24]  true_G_epigraph  1
    a[20,24]  physical_G_upper  1
    a[20,25]  R2177     1
    a[20,25]  R2178     1
    a[20,25]  true_G_epigraph  1
    a[20,25]  physical_G_upper  1
    a[20,26]  R2179     1
    a[20,26]  R2180     1
    a[20,26]  true_G_epigraph  1
    a[20,26]  physical_G_upper  1
    a[20,27]  R2181     1
    a[20,27]  R2182     1
    a[20,27]  true_G_epigraph  1
    a[20,27]  physical_G_upper  1
    a[20,28]  R2183     1
    a[20,28]  R2184     1
    a[20,28]  true_G_epigraph  1
    a[20,28]  physical_G_upper  1
    a[20,29]  R2185     1
    a[20,29]  R2186     1
    a[20,29]  true_G_epigraph  1
    a[20,29]  physical_G_upper  1
    a[20,30]  R2187     1
    a[20,30]  R2188     1
    a[20,30]  true_G_epigraph  1
    a[20,30]  physical_G_upper  1
    a[20,31]  R2189     1
    a[20,31]  R2190     1
    a[20,31]  true_G_epigraph  1
    a[20,31]  physical_G_upper  1
    a[20,32]  R2191     1
    a[20,32]  R2192     1
    a[20,32]  true_G_epigraph  1
    a[20,32]  physical_G_upper  1
    a[20,33]  R2193     1
    a[20,33]  R2194     1
    a[20,33]  true_G_epigraph  1
    a[20,33]  physical_G_upper  1
    a[20,34]  R2195     1
    a[20,34]  R2196     1
    a[20,34]  true_G_epigraph  1
    a[20,34]  physical_G_upper  1
    a[20,35]  R2197     1
    a[20,35]  R2198     1
    a[20,35]  true_G_epigraph  1
    a[20,35]  physical_G_upper  1
    a[21,22]  R2199     1
    a[21,22]  R2200     1
    a[21,22]  true_G_epigraph  1
    a[21,22]  physical_G_upper  1
    a[21,23]  R2201     1
    a[21,23]  R2202     1
    a[21,23]  true_G_epigraph  1
    a[21,23]  physical_G_upper  1
    a[21,24]  R2203     1
    a[21,24]  R2204     1
    a[21,24]  true_G_epigraph  1
    a[21,24]  physical_G_upper  1
    a[21,25]  R2205     1
    a[21,25]  R2206     1
    a[21,25]  true_G_epigraph  1
    a[21,25]  physical_G_upper  1
    a[21,26]  R2207     1
    a[21,26]  R2208     1
    a[21,26]  true_G_epigraph  1
    a[21,26]  physical_G_upper  1
    a[21,27]  R2209     1
    a[21,27]  R2210     1
    a[21,27]  true_G_epigraph  1
    a[21,27]  physical_G_upper  1
    a[21,28]  R2211     1
    a[21,28]  R2212     1
    a[21,28]  true_G_epigraph  1
    a[21,28]  physical_G_upper  1
    a[21,29]  R2213     1
    a[21,29]  R2214     1
    a[21,29]  true_G_epigraph  1
    a[21,29]  physical_G_upper  1
    a[21,30]  R2215     1
    a[21,30]  R2216     1
    a[21,30]  true_G_epigraph  1
    a[21,30]  physical_G_upper  1
    a[21,31]  R2217     1
    a[21,31]  R2218     1
    a[21,31]  true_G_epigraph  1
    a[21,31]  physical_G_upper  1
    a[21,32]  R2219     1
    a[21,32]  R2220     1
    a[21,32]  true_G_epigraph  1
    a[21,32]  physical_G_upper  1
    a[21,33]  R2221     1
    a[21,33]  R2222     1
    a[21,33]  true_G_epigraph  1
    a[21,33]  physical_G_upper  1
    a[21,34]  R2223     1
    a[21,34]  R2224     1
    a[21,34]  true_G_epigraph  1
    a[21,34]  physical_G_upper  1
    a[21,35]  R2225     1
    a[21,35]  R2226     1
    a[21,35]  true_G_epigraph  1
    a[21,35]  physical_G_upper  1
    a[22,23]  R2227     1
    a[22,23]  R2228     1
    a[22,23]  true_G_epigraph  1
    a[22,23]  physical_G_upper  1
    a[22,24]  R2229     1
    a[22,24]  R2230     1
    a[22,24]  true_G_epigraph  1
    a[22,24]  physical_G_upper  1
    a[22,25]  R2231     1
    a[22,25]  R2232     1
    a[22,25]  true_G_epigraph  1
    a[22,25]  physical_G_upper  1
    a[22,26]  R2233     1
    a[22,26]  R2234     1
    a[22,26]  true_G_epigraph  1
    a[22,26]  physical_G_upper  1
    a[22,27]  R2235     1
    a[22,27]  R2236     1
    a[22,27]  true_G_epigraph  1
    a[22,27]  physical_G_upper  1
    a[22,28]  R2237     1
    a[22,28]  R2238     1
    a[22,28]  true_G_epigraph  1
    a[22,28]  physical_G_upper  1
    a[22,29]  R2239     1
    a[22,29]  R2240     1
    a[22,29]  true_G_epigraph  1
    a[22,29]  physical_G_upper  1
    a[22,30]  R2241     1
    a[22,30]  R2242     1
    a[22,30]  true_G_epigraph  1
    a[22,30]  physical_G_upper  1
    a[22,31]  R2243     1
    a[22,31]  R2244     1
    a[22,31]  true_G_epigraph  1
    a[22,31]  physical_G_upper  1
    a[22,32]  R2245     1
    a[22,32]  R2246     1
    a[22,32]  true_G_epigraph  1
    a[22,32]  physical_G_upper  1
    a[22,33]  R2247     1
    a[22,33]  R2248     1
    a[22,33]  true_G_epigraph  1
    a[22,33]  physical_G_upper  1
    a[22,34]  R2249     1
    a[22,34]  R2250     1
    a[22,34]  true_G_epigraph  1
    a[22,34]  physical_G_upper  1
    a[22,35]  R2251     1
    a[22,35]  R2252     1
    a[22,35]  true_G_epigraph  1
    a[22,35]  physical_G_upper  1
    a[23,24]  R2253     1
    a[23,24]  R2254     1
    a[23,24]  true_G_epigraph  1
    a[23,24]  physical_G_upper  1
    a[23,25]  R2255     1
    a[23,25]  R2256     1
    a[23,25]  true_G_epigraph  1
    a[23,25]  physical_G_upper  1
    a[23,26]  R2257     1
    a[23,26]  R2258     1
    a[23,26]  true_G_epigraph  1
    a[23,26]  physical_G_upper  1
    a[23,27]  R2259     1
    a[23,27]  R2260     1
    a[23,27]  true_G_epigraph  1
    a[23,27]  physical_G_upper  1
    a[23,28]  R2261     1
    a[23,28]  R2262     1
    a[23,28]  true_G_epigraph  1
    a[23,28]  physical_G_upper  1
    a[23,29]  R2263     1
    a[23,29]  R2264     1
    a[23,29]  true_G_epigraph  1
    a[23,29]  physical_G_upper  1
    a[23,30]  R2265     1
    a[23,30]  R2266     1
    a[23,30]  true_G_epigraph  1
    a[23,30]  physical_G_upper  1
    a[23,31]  R2267     1
    a[23,31]  R2268     1
    a[23,31]  true_G_epigraph  1
    a[23,31]  physical_G_upper  1
    a[23,32]  R2269     1
    a[23,32]  R2270     1
    a[23,32]  true_G_epigraph  1
    a[23,32]  physical_G_upper  1
    a[23,33]  R2271     1
    a[23,33]  R2272     1
    a[23,33]  true_G_epigraph  1
    a[23,33]  physical_G_upper  1
    a[23,34]  R2273     1
    a[23,34]  R2274     1
    a[23,34]  true_G_epigraph  1
    a[23,34]  physical_G_upper  1
    a[23,35]  R2275     1
    a[23,35]  R2276     1
    a[23,35]  true_G_epigraph  1
    a[23,35]  physical_G_upper  1
    a[24,25]  R2277     1
    a[24,25]  R2278     1
    a[24,25]  true_G_epigraph  1
    a[24,25]  physical_G_upper  1
    a[24,26]  R2279     1
    a[24,26]  R2280     1
    a[24,26]  true_G_epigraph  1
    a[24,26]  physical_G_upper  1
    a[24,27]  R2281     1
    a[24,27]  R2282     1
    a[24,27]  true_G_epigraph  1
    a[24,27]  physical_G_upper  1
    a[24,28]  R2283     1
    a[24,28]  R2284     1
    a[24,28]  true_G_epigraph  1
    a[24,28]  physical_G_upper  1
    a[24,29]  R2285     1
    a[24,29]  R2286     1
    a[24,29]  true_G_epigraph  1
    a[24,29]  physical_G_upper  1
    a[24,30]  R2287     1
    a[24,30]  R2288     1
    a[24,30]  true_G_epigraph  1
    a[24,30]  physical_G_upper  1
    a[24,31]  R2289     1
    a[24,31]  R2290     1
    a[24,31]  true_G_epigraph  1
    a[24,31]  physical_G_upper  1
    a[24,32]  R2291     1
    a[24,32]  R2292     1
    a[24,32]  true_G_epigraph  1
    a[24,32]  physical_G_upper  1
    a[24,33]  R2293     1
    a[24,33]  R2294     1
    a[24,33]  true_G_epigraph  1
    a[24,33]  physical_G_upper  1
    a[24,34]  R2295     1
    a[24,34]  R2296     1
    a[24,34]  true_G_epigraph  1
    a[24,34]  physical_G_upper  1
    a[24,35]  R2297     1
    a[24,35]  R2298     1
    a[24,35]  true_G_epigraph  1
    a[24,35]  physical_G_upper  1
    a[25,26]  R2299     1
    a[25,26]  R2300     1
    a[25,26]  true_G_epigraph  1
    a[25,26]  physical_G_upper  1
    a[25,27]  R2301     1
    a[25,27]  R2302     1
    a[25,27]  true_G_epigraph  1
    a[25,27]  physical_G_upper  1
    a[25,28]  R2303     1
    a[25,28]  R2304     1
    a[25,28]  true_G_epigraph  1
    a[25,28]  physical_G_upper  1
    a[25,29]  R2305     1
    a[25,29]  R2306     1
    a[25,29]  true_G_epigraph  1
    a[25,29]  physical_G_upper  1
    a[25,30]  R2307     1
    a[25,30]  R2308     1
    a[25,30]  true_G_epigraph  1
    a[25,30]  physical_G_upper  1
    a[25,31]  R2309     1
    a[25,31]  R2310     1
    a[25,31]  true_G_epigraph  1
    a[25,31]  physical_G_upper  1
    a[25,32]  R2311     1
    a[25,32]  R2312     1
    a[25,32]  true_G_epigraph  1
    a[25,32]  physical_G_upper  1
    a[25,33]  R2313     1
    a[25,33]  R2314     1
    a[25,33]  true_G_epigraph  1
    a[25,33]  physical_G_upper  1
    a[25,34]  R2315     1
    a[25,34]  R2316     1
    a[25,34]  true_G_epigraph  1
    a[25,34]  physical_G_upper  1
    a[25,35]  R2317     1
    a[25,35]  R2318     1
    a[25,35]  true_G_epigraph  1
    a[25,35]  physical_G_upper  1
    a[26,27]  R2319     1
    a[26,27]  R2320     1
    a[26,27]  true_G_epigraph  1
    a[26,27]  physical_G_upper  1
    a[26,28]  R2321     1
    a[26,28]  R2322     1
    a[26,28]  true_G_epigraph  1
    a[26,28]  physical_G_upper  1
    a[26,29]  R2323     1
    a[26,29]  R2324     1
    a[26,29]  true_G_epigraph  1
    a[26,29]  physical_G_upper  1
    a[26,30]  R2325     1
    a[26,30]  R2326     1
    a[26,30]  true_G_epigraph  1
    a[26,30]  physical_G_upper  1
    a[26,31]  R2327     1
    a[26,31]  R2328     1
    a[26,31]  true_G_epigraph  1
    a[26,31]  physical_G_upper  1
    a[26,32]  R2329     1
    a[26,32]  R2330     1
    a[26,32]  true_G_epigraph  1
    a[26,32]  physical_G_upper  1
    a[26,33]  R2331     1
    a[26,33]  R2332     1
    a[26,33]  true_G_epigraph  1
    a[26,33]  physical_G_upper  1
    a[26,34]  R2333     1
    a[26,34]  R2334     1
    a[26,34]  true_G_epigraph  1
    a[26,34]  physical_G_upper  1
    a[26,35]  R2335     1
    a[26,35]  R2336     1
    a[26,35]  true_G_epigraph  1
    a[26,35]  physical_G_upper  1
    a[27,28]  R2337     1
    a[27,28]  R2338     1
    a[27,28]  true_G_epigraph  1
    a[27,28]  physical_G_upper  1
    a[27,29]  R2339     1
    a[27,29]  R2340     1
    a[27,29]  true_G_epigraph  1
    a[27,29]  physical_G_upper  1
    a[27,30]  R2341     1
    a[27,30]  R2342     1
    a[27,30]  true_G_epigraph  1
    a[27,30]  physical_G_upper  1
    a[27,31]  R2343     1
    a[27,31]  R2344     1
    a[27,31]  true_G_epigraph  1
    a[27,31]  physical_G_upper  1
    a[27,32]  R2345     1
    a[27,32]  R2346     1
    a[27,32]  true_G_epigraph  1
    a[27,32]  physical_G_upper  1
    a[27,33]  R2347     1
    a[27,33]  R2348     1
    a[27,33]  true_G_epigraph  1
    a[27,33]  physical_G_upper  1
    a[27,34]  R2349     1
    a[27,34]  R2350     1
    a[27,34]  true_G_epigraph  1
    a[27,34]  physical_G_upper  1
    a[27,35]  R2351     1
    a[27,35]  R2352     1
    a[27,35]  true_G_epigraph  1
    a[27,35]  physical_G_upper  1
    a[28,29]  R2353     1
    a[28,29]  R2354     1
    a[28,29]  true_G_epigraph  1
    a[28,29]  physical_G_upper  1
    a[28,30]  R2355     1
    a[28,30]  R2356     1
    a[28,30]  true_G_epigraph  1
    a[28,30]  physical_G_upper  1
    a[28,31]  R2357     1
    a[28,31]  R2358     1
    a[28,31]  true_G_epigraph  1
    a[28,31]  physical_G_upper  1
    a[28,32]  R2359     1
    a[28,32]  R2360     1
    a[28,32]  true_G_epigraph  1
    a[28,32]  physical_G_upper  1
    a[28,33]  R2361     1
    a[28,33]  R2362     1
    a[28,33]  true_G_epigraph  1
    a[28,33]  physical_G_upper  1
    a[28,34]  R2363     1
    a[28,34]  R2364     1
    a[28,34]  true_G_epigraph  1
    a[28,34]  physical_G_upper  1
    a[28,35]  R2365     1
    a[28,35]  R2366     1
    a[28,35]  true_G_epigraph  1
    a[28,35]  physical_G_upper  1
    a[29,30]  R2367     1
    a[29,30]  R2368     1
    a[29,30]  true_G_epigraph  1
    a[29,30]  physical_G_upper  1
    a[29,31]  R2369     1
    a[29,31]  R2370     1
    a[29,31]  true_G_epigraph  1
    a[29,31]  physical_G_upper  1
    a[29,32]  R2371     1
    a[29,32]  R2372     1
    a[29,32]  true_G_epigraph  1
    a[29,32]  physical_G_upper  1
    a[29,33]  R2373     1
    a[29,33]  R2374     1
    a[29,33]  true_G_epigraph  1
    a[29,33]  physical_G_upper  1
    a[29,34]  R2375     1
    a[29,34]  R2376     1
    a[29,34]  true_G_epigraph  1
    a[29,34]  physical_G_upper  1
    a[29,35]  R2377     1
    a[29,35]  R2378     1
    a[29,35]  true_G_epigraph  1
    a[29,35]  physical_G_upper  1
    a[30,31]  R2379     1
    a[30,31]  R2380     1
    a[30,31]  true_G_epigraph  1
    a[30,31]  physical_G_upper  1
    a[30,32]  R2381     1
    a[30,32]  R2382     1
    a[30,32]  true_G_epigraph  1
    a[30,32]  physical_G_upper  1
    a[30,33]  R2383     1
    a[30,33]  R2384     1
    a[30,33]  true_G_epigraph  1
    a[30,33]  physical_G_upper  1
    a[30,34]  R2385     1
    a[30,34]  R2386     1
    a[30,34]  true_G_epigraph  1
    a[30,34]  physical_G_upper  1
    a[30,35]  R2387     1
    a[30,35]  R2388     1
    a[30,35]  true_G_epigraph  1
    a[30,35]  physical_G_upper  1
    a[31,32]  R2389     1
    a[31,32]  R2390     1
    a[31,32]  true_G_epigraph  1
    a[31,32]  physical_G_upper  1
    a[31,33]  R2391     1
    a[31,33]  R2392     1
    a[31,33]  true_G_epigraph  1
    a[31,33]  physical_G_upper  1
    a[31,34]  R2393     1
    a[31,34]  R2394     1
    a[31,34]  true_G_epigraph  1
    a[31,34]  physical_G_upper  1
    a[31,35]  R2395     1
    a[31,35]  R2396     1
    a[31,35]  true_G_epigraph  1
    a[31,35]  physical_G_upper  1
    a[32,33]  R2397     1
    a[32,33]  R2398     1
    a[32,33]  true_G_epigraph  1
    a[32,33]  physical_G_upper  1
    a[32,34]  R2399     1
    a[32,34]  R2400     1
    a[32,34]  true_G_epigraph  1
    a[32,34]  physical_G_upper  1
    a[32,35]  R2401     1
    a[32,35]  R2402     1
    a[32,35]  true_G_epigraph  1
    a[32,35]  physical_G_upper  1
    a[33,34]  R2403     1
    a[33,34]  R2404     1
    a[33,34]  true_G_epigraph  1
    a[33,34]  physical_G_upper  1
    a[33,35]  R2405     1
    a[33,35]  R2406     1
    a[33,35]  true_G_epigraph  1
    a[33,35]  physical_G_upper  1
    a[34,35]  R2407     1
    a[34,35]  R2408     1
    a[34,35]  true_G_epigraph  1
    a[34,35]  physical_G_upper  1
    q         OBJ       1
    q         true_G_epigraph  -35
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      onehot_21  1
    RHS1      onehot_22  1
    RHS1      onehot_23  1
    RHS1      onehot_24  1
    RHS1      onehot_25  1
    RHS1      onehot_26  1
    RHS1      onehot_27  1
    RHS1      onehot_28  1
    RHS1      onehot_29  1
    RHS1      onehot_30  1
    RHS1      onehot_31  1
    RHS1      onehot_32  1
    RHS1      onehot_33  1
    RHS1      onehot_34  1
    RHS1      onehot_35  1
    RHS1      hard_lower  136
    RHS1      hard_upper  211
    RHS1      normalization  1
    RHS1      physical_G_upper  2.0202628062360798e+01
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[1,5]  
 BV BND1      x[1,6]  
 BV BND1      x[1,7]  
 BV BND1      x[1,8]  
 BV BND1      x[1,9]  
 BV BND1      x[1,10] 
 BV BND1      x[1,11] 
 BV BND1      x[1,12] 
 BV BND1      x[1,13] 
 BV BND1      x[1,14] 
 BV BND1      x[1,15] 
 BV BND1      x[1,16] 
 BV BND1      x[1,17] 
 BV BND1      x[1,18] 
 BV BND1      x[1,19] 
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 BV BND1      x[3,5]  
 BV BND1      x[3,6]  
 BV BND1      x[3,7]  
 BV BND1      x[3,8]  
 BV BND1      x[3,9]  
 BV BND1      x[3,10] 
 BV BND1      x[3,11] 
 BV BND1      x[3,12] 
 BV BND1      x[3,13] 
 BV BND1      x[3,14] 
 BV BND1      x[3,15] 
 BV BND1      x[3,16] 
 BV BND1      x[3,17] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[5,16] 
 BV BND1      x[6,0]  
 BV BND1      x[6,1]  
 BV BND1      x[6,2]  
 BV BND1      x[6,3]  
 BV BND1      x[6,4]  
 BV BND1      x[6,5]  
 BV BND1      x[6,6]  
 BV BND1      x[6,7]  
 BV BND1      x[6,8]  
 BV BND1      x[6,9]  
 BV BND1      x[6,10] 
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[7,16] 
 BV BND1      x[7,17] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[8,13] 
 BV BND1      x[8,14] 
 BV BND1      x[8,15] 
 BV BND1      x[8,16] 
 BV BND1      x[8,17] 
 BV BND1      x[8,18] 
 BV BND1      x[8,19] 
 BV BND1      x[8,20] 
 BV BND1      x[8,21] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[9,11] 
 BV BND1      x[9,12] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[10,8] 
 BV BND1      x[10,9] 
 BV BND1      x[10,10]
 BV BND1      x[10,11]
 BV BND1      x[10,12]
 BV BND1      x[10,13]
 BV BND1      x[10,14]
 BV BND1      x[10,15]
 BV BND1      x[10,16]
 BV BND1      x[10,17]
 BV BND1      x[10,18]
 BV BND1      x[10,19]
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[13,9] 
 BV BND1      x[13,10]
 BV BND1      x[13,11]
 BV BND1      x[13,12]
 BV BND1      x[13,13]
 BV BND1      x[13,14]
 BV BND1      x[13,15]
 BV BND1      x[13,16]
 BV BND1      x[13,17]
 BV BND1      x[13,18]
 BV BND1      x[13,19]
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[15,9] 
 BV BND1      x[15,10]
 BV BND1      x[15,11]
 BV BND1      x[15,12]
 BV BND1      x[15,13]
 BV BND1      x[15,14]
 BV BND1      x[15,15]
 BV BND1      x[15,16]
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[16,12]
 BV BND1      x[17,0] 
 BV BND1      x[17,1] 
 BV BND1      x[17,2] 
 BV BND1      x[17,3] 
 BV BND1      x[17,4] 
 BV BND1      x[17,5] 
 BV BND1      x[17,6] 
 BV BND1      x[17,7] 
 BV BND1      x[17,8] 
 BV BND1      x[17,9] 
 BV BND1      x[17,10]
 BV BND1      x[17,11]
 BV BND1      x[17,12]
 BV BND1      x[17,13]
 BV BND1      x[17,14]
 BV BND1      x[17,15]
 BV BND1      x[17,16]
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[18,2] 
 BV BND1      x[18,3] 
 BV BND1      x[18,4] 
 BV BND1      x[18,5] 
 BV BND1      x[18,6] 
 BV BND1      x[18,7] 
 BV BND1      x[18,8] 
 BV BND1      x[18,9] 
 BV BND1      x[18,10]
 BV BND1      x[18,11]
 BV BND1      x[18,12]
 BV BND1      x[18,13]
 BV BND1      x[18,14]
 BV BND1      x[18,15]
 BV BND1      x[18,16]
 BV BND1      x[18,17]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[20,0] 
 BV BND1      x[20,1] 
 BV BND1      x[20,2] 
 BV BND1      x[20,3] 
 BV BND1      x[20,4] 
 BV BND1      x[20,5] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[20,11]
 BV BND1      x[20,12]
 BV BND1      x[21,0] 
 BV BND1      x[21,1] 
 BV BND1      x[21,2] 
 BV BND1      x[21,3] 
 BV BND1      x[21,4] 
 BV BND1      x[21,5] 
 BV BND1      x[21,6] 
 BV BND1      x[21,7] 
 BV BND1      x[21,8] 
 BV BND1      x[21,9] 
 BV BND1      x[21,10]
 BV BND1      x[21,11]
 BV BND1      x[21,12]
 BV BND1      x[21,13]
 BV BND1      x[21,14]
 BV BND1      x[21,15]
 BV BND1      x[22,0] 
 BV BND1      x[22,1] 
 BV BND1      x[22,2] 
 BV BND1      x[22,3] 
 BV BND1      x[22,4] 
 BV BND1      x[22,5] 
 BV BND1      x[22,6] 
 BV BND1      x[22,7] 
 BV BND1      x[22,8] 
 BV BND1      x[22,9] 
 BV BND1      x[22,10]
 BV BND1      x[22,11]
 BV BND1      x[22,12]
 BV BND1      x[23,0] 
 BV BND1      x[23,1] 
 BV BND1      x[23,2] 
 BV BND1      x[23,3] 
 BV BND1      x[23,4] 
 BV BND1      x[23,5] 
 BV BND1      x[23,6] 
 BV BND1      x[23,7] 
 BV BND1      x[23,8] 
 BV BND1      x[23,9] 
 BV BND1      x[23,10]
 BV BND1      x[23,11]
 BV BND1      x[24,0] 
 BV BND1      x[24,1] 
 BV BND1      x[24,2] 
 BV BND1      x[24,3] 
 BV BND1      x[24,4] 
 BV BND1      x[24,5] 
 BV BND1      x[24,6] 
 BV BND1      x[24,7] 
 BV BND1      x[24,8] 
 BV BND1      x[24,9] 
 BV BND1      x[24,10]
 BV BND1      x[24,11]
 BV BND1      x[24,12]
 BV BND1      x[24,13]
 BV BND1      x[24,14]
 BV BND1      x[24,15]
 BV BND1      x[25,0] 
 BV BND1      x[25,1] 
 BV BND1      x[25,2] 
 BV BND1      x[25,3] 
 BV BND1      x[25,4] 
 BV BND1      x[25,5] 
 BV BND1      x[25,6] 
 BV BND1      x[25,7] 
 BV BND1      x[25,8] 
 BV BND1      x[25,9] 
 BV BND1      x[25,10]
 BV BND1      x[25,11]
 BV BND1      x[25,12]
 BV BND1      x[25,13]
 BV BND1      x[25,14]
 BV BND1      x[25,15]
 BV BND1      x[26,0] 
 BV BND1      x[26,1] 
 BV BND1      x[26,2] 
 BV BND1      x[26,3] 
 BV BND1      x[26,4] 
 BV BND1      x[26,5] 
 BV BND1      x[26,6] 
 BV BND1      x[26,7] 
 BV BND1      x[26,8] 
 BV BND1      x[27,0] 
 BV BND1      x[27,1] 
 BV BND1      x[27,2] 
 BV BND1      x[27,3] 
 BV BND1      x[27,4] 
 BV BND1      x[27,5] 
 BV BND1      x[27,6] 
 BV BND1      x[27,7] 
 BV BND1      x[27,8] 
 BV BND1      x[27,9] 
 BV BND1      x[27,10]
 BV BND1      x[27,11]
 BV BND1      x[27,12]
 BV BND1      x[27,13]
 BV BND1      x[27,14]
 BV BND1      x[27,15]
 BV BND1      x[28,0] 
 BV BND1      x[28,1] 
 BV BND1      x[28,2] 
 BV BND1      x[28,3] 
 BV BND1      x[28,4] 
 BV BND1      x[28,5] 
 BV BND1      x[28,6] 
 BV BND1      x[28,7] 
 BV BND1      x[28,8] 
 BV BND1      x[28,9] 
 BV BND1      x[28,10]
 BV BND1      x[28,11]
 BV BND1      x[28,12]
 BV BND1      x[28,13]
 BV BND1      x[28,14]
 BV BND1      x[28,15]
 BV BND1      x[28,16]
 BV BND1      x[28,17]
 BV BND1      x[28,18]
 BV BND1      x[28,19]
 BV BND1      x[29,0] 
 BV BND1      x[29,1] 
 BV BND1      x[29,2] 
 BV BND1      x[29,3] 
 BV BND1      x[29,4] 
 BV BND1      x[29,5] 
 BV BND1      x[29,6] 
 BV BND1      x[29,7] 
 BV BND1      x[29,8] 
 BV BND1      x[29,9] 
 BV BND1      x[29,10]
 BV BND1      x[29,11]
 BV BND1      x[29,12]
 BV BND1      x[29,13]
 BV BND1      x[29,14]
 BV BND1      x[29,15]
 BV BND1      x[30,0] 
 BV BND1      x[30,1] 
 BV BND1      x[30,2] 
 BV BND1      x[30,3] 
 BV BND1      x[30,4] 
 BV BND1      x[30,5] 
 BV BND1      x[30,6] 
 BV BND1      x[30,7] 
 BV BND1      x[30,8] 
 BV BND1      x[31,0] 
 BV BND1      x[31,1] 
 BV BND1      x[31,2] 
 BV BND1      x[31,3] 
 BV BND1      x[31,4] 
 BV BND1      x[31,5] 
 BV BND1      x[31,6] 
 BV BND1      x[31,7] 
 BV BND1      x[31,8] 
 BV BND1      x[31,9] 
 BV BND1      x[31,10]
 BV BND1      x[31,11]
 BV BND1      x[31,12]
 BV BND1      x[32,0] 
 BV BND1      x[32,1] 
 BV BND1      x[32,2] 
 BV BND1      x[32,3] 
 BV BND1      x[32,4] 
 BV BND1      x[32,5] 
 BV BND1      x[32,6] 
 BV BND1      x[32,7] 
 BV BND1      x[32,8] 
 BV BND1      x[32,9] 
 BV BND1      x[32,10]
 BV BND1      x[32,11]
 BV BND1      x[32,12]
 BV BND1      x[33,0] 
 BV BND1      x[33,1] 
 BV BND1      x[33,2] 
 BV BND1      x[33,3] 
 BV BND1      x[33,4] 
 BV BND1      x[33,5] 
 BV BND1      x[33,6] 
 BV BND1      x[33,7] 
 BV BND1      x[33,8] 
 BV BND1      x[33,9] 
 BV BND1      x[33,10]
 BV BND1      x[33,11]
 BV BND1      x[33,12]
 BV BND1      x[33,13]
 BV BND1      x[33,14]
 BV BND1      x[33,15]
 BV BND1      x[33,16]
 BV BND1      x[34,0] 
 BV BND1      x[34,1] 
 BV BND1      x[34,2] 
 BV BND1      x[34,3] 
 BV BND1      x[34,4] 
 BV BND1      x[34,5] 
 BV BND1      x[34,6] 
 BV BND1      x[34,7] 
 BV BND1      x[34,8] 
 BV BND1      x[34,9] 
 BV BND1      x[34,10]
 BV BND1      x[34,11]
 BV BND1      x[35,0] 
 BV BND1      x[35,1] 
 BV BND1      x[35,2] 
 BV BND1      x[35,3] 
 BV BND1      x[35,4] 
 BV BND1      x[35,5] 
 BV BND1      x[35,6] 
 BV BND1      x[35,7] 
 BV BND1      x[35,8] 
 BV BND1      x[35,9] 
 BV BND1      x[35,10]
 BV BND1      x[35,11]
 BV BND1      x[35,12]
 BV BND1      x[35,13]
 BV BND1      x[35,14]
 BV BND1      x[35,15]
 UP BND1      w[1,0]    6.7365269461077862e-02
 UP BND1      w[1,1]    6.7365269461077862e-02
 UP BND1      w[1,2]    6.7365269461077862e-02
 UP BND1      w[1,3]    6.7365269461077862e-02
 UP BND1      w[1,4]    6.7365269461077862e-02
 UP BND1      w[1,5]    6.7365269461077862e-02
 UP BND1      w[1,6]    6.7365269461077862e-02
 UP BND1      w[1,7]    6.7365269461077862e-02
 UP BND1      w[1,8]    6.7365269461077862e-02
 UP BND1      w[1,9]    6.7365269461077862e-02
 UP BND1      w[1,10]   6.7365269461077862e-02
 UP BND1      w[1,11]   6.7365269461077862e-02
 UP BND1      w[1,12]   6.7365269461077862e-02
 UP BND1      w[1,13]   6.7365269461077862e-02
 UP BND1      w[1,14]   6.7365269461077862e-02
 UP BND1      w[1,15]   6.7365269461077862e-02
 UP BND1      w[1,16]   6.7365269461077862e-02
 UP BND1      w[1,17]   6.7365269461077862e-02
 UP BND1      w[1,18]   6.7365269461077862e-02
 UP BND1      w[1,19]   6.7365269461077862e-02
 UP BND1      w[2,0]    6.7365269461077862e-02
 UP BND1      w[2,1]    6.7365269461077862e-02
 UP BND1      w[2,2]    6.7365269461077862e-02
 UP BND1      w[2,3]    6.7365269461077862e-02
 UP BND1      w[2,4]    6.7365269461077862e-02
 UP BND1      w[2,5]    6.7365269461077862e-02
 UP BND1      w[2,6]    6.7365269461077862e-02
 UP BND1      w[2,7]    6.7365269461077862e-02
 UP BND1      w[2,8]    6.7365269461077862e-02
 UP BND1      w[2,9]    6.7365269461077862e-02
 UP BND1      w[2,10]   6.7365269461077862e-02
 UP BND1      w[2,11]   6.7365269461077862e-02
 UP BND1      w[2,12]   6.7365269461077862e-02
 UP BND1      w[2,13]   6.7365269461077862e-02
 UP BND1      w[2,14]   6.7365269461077862e-02
 UP BND1      w[2,15]   6.7365269461077862e-02
 UP BND1      w[3,0]    6.7365269461077862e-02
 UP BND1      w[3,1]    6.7365269461077862e-02
 UP BND1      w[3,2]    6.7365269461077862e-02
 UP BND1      w[3,3]    6.7365269461077862e-02
 UP BND1      w[3,4]    6.7365269461077862e-02
 UP BND1      w[3,5]    6.7365269461077862e-02
 UP BND1      w[3,6]    6.7365269461077862e-02
 UP BND1      w[3,7]    6.7365269461077862e-02
 UP BND1      w[3,8]    6.7365269461077862e-02
 UP BND1      w[3,9]    6.7365269461077862e-02
 UP BND1      w[3,10]   6.7365269461077862e-02
 UP BND1      w[3,11]   6.7365269461077862e-02
 UP BND1      w[3,12]   6.7365269461077862e-02
 UP BND1      w[3,13]   6.7365269461077862e-02
 UP BND1      w[3,14]   6.7365269461077862e-02
 UP BND1      w[3,15]   6.7365269461077862e-02
 UP BND1      w[3,16]   6.7365269461077862e-02
 UP BND1      w[3,17]   6.7365269461077862e-02
 UP BND1      w[4,0]    6.7365269461077862e-02
 UP BND1      w[4,1]    6.7365269461077862e-02
 UP BND1      w[4,2]    6.7365269461077862e-02
 UP BND1      w[4,3]    6.7365269461077862e-02
 UP BND1      w[4,4]    6.7365269461077862e-02
 UP BND1      w[4,5]    6.7365269461077862e-02
 UP BND1      w[4,6]    6.7365269461077862e-02
 UP BND1      w[4,7]    6.7365269461077862e-02
 UP BND1      w[4,8]    6.7365269461077862e-02
 UP BND1      w[4,9]    6.7365269461077862e-02
 UP BND1      w[4,10]   6.7365269461077862e-02
 UP BND1      w[4,11]   6.7365269461077862e-02
 UP BND1      w[4,12]   6.7365269461077862e-02
 UP BND1      w[4,13]   6.7365269461077862e-02
 UP BND1      w[4,14]   6.7365269461077862e-02
 UP BND1      w[4,15]   6.7365269461077862e-02
 UP BND1      w[5,0]    6.7365269461077862e-02
 UP BND1      w[5,1]    6.7365269461077862e-02
 UP BND1      w[5,2]    6.7365269461077862e-02
 UP BND1      w[5,3]    6.7365269461077862e-02
 UP BND1      w[5,4]    6.7365269461077862e-02
 UP BND1      w[5,5]    6.7365269461077862e-02
 UP BND1      w[5,6]    6.7365269461077862e-02
 UP BND1      w[5,7]    6.7365269461077862e-02
 UP BND1      w[5,8]    6.7365269461077862e-02
 UP BND1      w[5,9]    6.7365269461077862e-02
 UP BND1      w[5,10]   6.7365269461077862e-02
 UP BND1      w[5,11]   6.7365269461077862e-02
 UP BND1      w[5,12]   6.7365269461077862e-02
 UP BND1      w[5,13]   6.7365269461077862e-02
 UP BND1      w[5,14]   6.7365269461077862e-02
 UP BND1      w[5,15]   6.7365269461077862e-02
 UP BND1      w[5,16]   6.7365269461077862e-02
 UP BND1      w[6,0]    6.7365269461077862e-02
 UP BND1      w[6,1]    6.7365269461077862e-02
 UP BND1      w[6,2]    6.7365269461077862e-02
 UP BND1      w[6,3]    6.7365269461077862e-02
 UP BND1      w[6,4]    6.7365269461077862e-02
 UP BND1      w[6,5]    6.7365269461077862e-02
 UP BND1      w[6,6]    6.7365269461077862e-02
 UP BND1      w[6,7]    6.7365269461077862e-02
 UP BND1      w[6,8]    6.7365269461077862e-02
 UP BND1      w[6,9]    6.7365269461077862e-02
 UP BND1      w[6,10]   6.7365269461077862e-02
 UP BND1      w[7,0]    6.7365269461077862e-02
 UP BND1      w[7,1]    6.7365269461077862e-02
 UP BND1      w[7,2]    6.7365269461077862e-02
 UP BND1      w[7,3]    6.7365269461077862e-02
 UP BND1      w[7,4]    6.7365269461077862e-02
 UP BND1      w[7,5]    6.7365269461077862e-02
 UP BND1      w[7,6]    6.7365269461077862e-02
 UP BND1      w[7,7]    6.7365269461077862e-02
 UP BND1      w[7,8]    6.7365269461077862e-02
 UP BND1      w[7,9]    6.7365269461077862e-02
 UP BND1      w[7,10]   6.7365269461077862e-02
 UP BND1      w[7,11]   6.7365269461077862e-02
 UP BND1      w[7,12]   6.7365269461077862e-02
 UP BND1      w[7,13]   6.7365269461077862e-02
 UP BND1      w[7,14]   6.7365269461077862e-02
 UP BND1      w[7,15]   6.7365269461077862e-02
 UP BND1      w[7,16]   6.7365269461077862e-02
 UP BND1      w[7,17]   6.7365269461077862e-02
 UP BND1      w[8,0]    6.7365269461077862e-02
 UP BND1      w[8,1]    6.7365269461077862e-02
 UP BND1      w[8,2]    6.7365269461077862e-02
 UP BND1      w[8,3]    6.7365269461077862e-02
 UP BND1      w[8,4]    6.7365269461077862e-02
 UP BND1      w[8,5]    6.7365269461077862e-02
 UP BND1      w[8,6]    6.7365269461077862e-02
 UP BND1      w[8,7]    6.7365269461077862e-02
 UP BND1      w[8,8]    6.7365269461077862e-02
 UP BND1      w[8,9]    6.7365269461077862e-02
 UP BND1      w[8,10]   6.7365269461077862e-02
 UP BND1      w[8,11]   6.7365269461077862e-02
 UP BND1      w[8,12]   6.7365269461077862e-02
 UP BND1      w[8,13]   6.7365269461077862e-02
 UP BND1      w[8,14]   6.7365269461077862e-02
 UP BND1      w[8,15]   6.7365269461077862e-02
 UP BND1      w[8,16]   6.7365269461077862e-02
 UP BND1      w[8,17]   6.7365269461077862e-02
 UP BND1      w[8,18]   6.7365269461077862e-02
 UP BND1      w[8,19]   6.7365269461077862e-02
 UP BND1      w[8,20]   6.7365269461077862e-02
 UP BND1      w[8,21]   6.7365269461077862e-02
 UP BND1      w[9,0]    6.7365269461077862e-02
 UP BND1      w[9,1]    6.7365269461077862e-02
 UP BND1      w[9,2]    6.7365269461077862e-02
 UP BND1      w[9,3]    6.7365269461077862e-02
 UP BND1      w[9,4]    6.7365269461077862e-02
 UP BND1      w[9,5]    6.7365269461077862e-02
 UP BND1      w[9,6]    6.7365269461077862e-02
 UP BND1      w[9,7]    6.7365269461077862e-02
 UP BND1      w[9,8]    6.7365269461077862e-02
 UP BND1      w[9,9]    6.7365269461077862e-02
 UP BND1      w[9,10]   6.7365269461077862e-02
 UP BND1      w[9,11]   6.7365269461077862e-02
 UP BND1      w[9,12]   6.7365269461077862e-02
 UP BND1      w[10,0]   6.7365269461077862e-02
 UP BND1      w[10,1]   6.7365269461077862e-02
 UP BND1      w[10,2]   6.7365269461077862e-02
 UP BND1      w[10,3]   6.7365269461077862e-02
 UP BND1      w[10,4]   6.7365269461077862e-02
 UP BND1      w[10,5]   6.7365269461077862e-02
 UP BND1      w[10,6]   6.7365269461077862e-02
 UP BND1      w[10,7]   6.7365269461077862e-02
 UP BND1      w[10,8]   6.7365269461077862e-02
 UP BND1      w[10,9]   6.7365269461077862e-02
 UP BND1      w[10,10]  6.7365269461077862e-02
 UP BND1      w[10,11]  6.7365269461077862e-02
 UP BND1      w[10,12]  6.7365269461077862e-02
 UP BND1      w[10,13]  6.7365269461077862e-02
 UP BND1      w[10,14]  6.7365269461077862e-02
 UP BND1      w[10,15]  6.7365269461077862e-02
 UP BND1      w[10,16]  6.7365269461077862e-02
 UP BND1      w[10,17]  6.7365269461077862e-02
 UP BND1      w[10,18]  6.7365269461077862e-02
 UP BND1      w[10,19]  6.7365269461077862e-02
 UP BND1      w[11,0]   6.7365269461077862e-02
 UP BND1      w[11,1]   6.7365269461077862e-02
 UP BND1      w[11,2]   6.7365269461077862e-02
 UP BND1      w[11,3]   6.7365269461077862e-02
 UP BND1      w[11,4]   6.7365269461077862e-02
 UP BND1      w[11,5]   6.7365269461077862e-02
 UP BND1      w[11,6]   6.7365269461077862e-02
 UP BND1      w[11,7]   6.7365269461077862e-02
 UP BND1      w[11,8]   6.7365269461077862e-02
 UP BND1      w[11,9]   6.7365269461077862e-02
 UP BND1      w[11,10]  6.7365269461077862e-02
 UP BND1      w[11,11]  6.7365269461077862e-02
 UP BND1      w[11,12]  6.7365269461077862e-02
 UP BND1      w[12,0]   6.7365269461077862e-02
 UP BND1      w[12,1]   6.7365269461077862e-02
 UP BND1      w[12,2]   6.7365269461077862e-02
 UP BND1      w[12,3]   6.7365269461077862e-02
 UP BND1      w[12,4]   6.7365269461077862e-02
 UP BND1      w[12,5]   6.7365269461077862e-02
 UP BND1      w[12,6]   6.7365269461077862e-02
 UP BND1      w[12,7]   6.7365269461077862e-02
 UP BND1      w[12,8]   6.7365269461077862e-02
 UP BND1      w[12,9]   6.7365269461077862e-02
 UP BND1      w[12,10]  6.7365269461077862e-02
 UP BND1      w[12,11]  6.7365269461077862e-02
 UP BND1      w[12,12]  6.7365269461077862e-02
 UP BND1      w[12,13]  6.7365269461077862e-02
 UP BND1      w[12,14]  6.7365269461077862e-02
 UP BND1      w[12,15]  6.7365269461077862e-02
 UP BND1      w[13,0]   6.7365269461077862e-02
 UP BND1      w[13,1]   6.7365269461077862e-02
 UP BND1      w[13,2]   6.7365269461077862e-02
 UP BND1      w[13,3]   6.7365269461077862e-02
 UP BND1      w[13,4]   6.7365269461077862e-02
 UP BND1      w[13,5]   6.7365269461077862e-02
 UP BND1      w[13,6]   6.7365269461077862e-02
 UP BND1      w[13,7]   6.7365269461077862e-02
 UP BND1      w[13,8]   6.7365269461077862e-02
 UP BND1      w[13,9]   6.7365269461077862e-02
 UP BND1      w[13,10]  6.7365269461077862e-02
 UP BND1      w[13,11]  6.7365269461077862e-02
 UP BND1      w[13,12]  6.7365269461077862e-02
 UP BND1      w[13,13]  6.7365269461077862e-02
 UP BND1      w[13,14]  6.7365269461077862e-02
 UP BND1      w[13,15]  6.7365269461077862e-02
 UP BND1      w[13,16]  6.7365269461077862e-02
 UP BND1      w[13,17]  6.7365269461077862e-02
 UP BND1      w[13,18]  6.7365269461077862e-02
 UP BND1      w[13,19]  6.7365269461077862e-02
 UP BND1      w[14,0]   6.7365269461077862e-02
 UP BND1      w[14,1]   6.7365269461077862e-02
 UP BND1      w[14,2]   6.7365269461077862e-02
 UP BND1      w[14,3]   6.7365269461077862e-02
 UP BND1      w[14,4]   6.7365269461077862e-02
 UP BND1      w[14,5]   6.7365269461077862e-02
 UP BND1      w[14,6]   6.7365269461077862e-02
 UP BND1      w[14,7]   6.7365269461077862e-02
 UP BND1      w[14,8]   6.7365269461077862e-02
 UP BND1      w[14,9]   6.7365269461077862e-02
 UP BND1      w[14,10]  6.7365269461077862e-02
 UP BND1      w[14,11]  6.7365269461077862e-02
 UP BND1      w[14,12]  6.7365269461077862e-02
 UP BND1      w[14,13]  6.7365269461077862e-02
 UP BND1      w[14,14]  6.7365269461077862e-02
 UP BND1      w[14,15]  6.7365269461077862e-02
 UP BND1      w[15,0]   6.7365269461077862e-02
 UP BND1      w[15,1]   6.7365269461077862e-02
 UP BND1      w[15,2]   6.7365269461077862e-02
 UP BND1      w[15,3]   6.7365269461077862e-02
 UP BND1      w[15,4]   6.7365269461077862e-02
 UP BND1      w[15,5]   6.7365269461077862e-02
 UP BND1      w[15,6]   6.7365269461077862e-02
 UP BND1      w[15,7]   6.7365269461077862e-02
 UP BND1      w[15,8]   6.7365269461077862e-02
 UP BND1      w[15,9]   6.7365269461077862e-02
 UP BND1      w[15,10]  6.7365269461077862e-02
 UP BND1      w[15,11]  6.7365269461077862e-02
 UP BND1      w[15,12]  6.7365269461077862e-02
 UP BND1      w[15,13]  6.7365269461077862e-02
 UP BND1      w[15,14]  6.7365269461077862e-02
 UP BND1      w[15,15]  6.7365269461077862e-02
 UP BND1      w[15,16]  6.7365269461077862e-02
 UP BND1      w[16,0]   6.7365269461077862e-02
 UP BND1      w[16,1]   6.7365269461077862e-02
 UP BND1      w[16,2]   6.7365269461077862e-02
 UP BND1      w[16,3]   6.7365269461077862e-02
 UP BND1      w[16,4]   6.7365269461077862e-02
 UP BND1      w[16,5]   6.7365269461077862e-02
 UP BND1      w[16,6]   6.7365269461077862e-02
 UP BND1      w[16,7]   6.7365269461077862e-02
 UP BND1      w[16,8]   6.7365269461077862e-02
 UP BND1      w[16,9]   6.7365269461077862e-02
 UP BND1      w[16,10]  6.7365269461077862e-02
 UP BND1      w[16,11]  6.7365269461077862e-02
 UP BND1      w[16,12]  6.7365269461077862e-02
 UP BND1      w[17,0]   6.7365269461077862e-02
 UP BND1      w[17,1]   6.7365269461077862e-02
 UP BND1      w[17,2]   6.7365269461077862e-02
 UP BND1      w[17,3]   6.7365269461077862e-02
 UP BND1      w[17,4]   6.7365269461077862e-02
 UP BND1      w[17,5]   6.7365269461077862e-02
 UP BND1      w[17,6]   6.7365269461077862e-02
 UP BND1      w[17,7]   6.7365269461077862e-02
 UP BND1      w[17,8]   6.7365269461077862e-02
 UP BND1      w[17,9]   6.7365269461077862e-02
 UP BND1      w[17,10]  6.7365269461077862e-02
 UP BND1      w[17,11]  6.7365269461077862e-02
 UP BND1      w[17,12]  6.7365269461077862e-02
 UP BND1      w[17,13]  6.7365269461077862e-02
 UP BND1      w[17,14]  6.7365269461077862e-02
 UP BND1      w[17,15]  6.7365269461077862e-02
 UP BND1      w[17,16]  6.7365269461077862e-02
 UP BND1      w[18,0]   6.7365269461077862e-02
 UP BND1      w[18,1]   6.7365269461077862e-02
 UP BND1      w[18,2]   6.7365269461077862e-02
 UP BND1      w[18,3]   6.7365269461077862e-02
 UP BND1      w[18,4]   6.7365269461077862e-02
 UP BND1      w[18,5]   6.7365269461077862e-02
 UP BND1      w[18,6]   6.7365269461077862e-02
 UP BND1      w[18,7]   6.7365269461077862e-02
 UP BND1      w[18,8]   6.7365269461077862e-02
 UP BND1      w[18,9]   6.7365269461077862e-02
 UP BND1      w[18,10]  6.7365269461077862e-02
 UP BND1      w[18,11]  6.7365269461077862e-02
 UP BND1      w[18,12]  6.7365269461077862e-02
 UP BND1      w[18,13]  6.7365269461077862e-02
 UP BND1      w[18,14]  6.7365269461077862e-02
 UP BND1      w[18,15]  6.7365269461077862e-02
 UP BND1      w[18,16]  6.7365269461077862e-02
 UP BND1      w[18,17]  6.7365269461077862e-02
 UP BND1      w[19,0]   6.7365269461077862e-02
 UP BND1      w[19,1]   6.7365269461077862e-02
 UP BND1      w[19,2]   6.7365269461077862e-02
 UP BND1      w[19,3]   6.7365269461077862e-02
 UP BND1      w[19,4]   6.7365269461077862e-02
 UP BND1      w[19,5]   6.7365269461077862e-02
 UP BND1      w[19,6]   6.7365269461077862e-02
 UP BND1      w[19,7]   6.7365269461077862e-02
 UP BND1      w[19,8]   6.7365269461077862e-02
 UP BND1      w[20,0]   6.7365269461077862e-02
 UP BND1      w[20,1]   6.7365269461077862e-02
 UP BND1      w[20,2]   6.7365269461077862e-02
 UP BND1      w[20,3]   6.7365269461077862e-02
 UP BND1      w[20,4]   6.7365269461077862e-02
 UP BND1      w[20,5]   6.7365269461077862e-02
 UP BND1      w[20,6]   6.7365269461077862e-02
 UP BND1      w[20,7]   6.7365269461077862e-02
 UP BND1      w[20,8]   6.7365269461077862e-02
 UP BND1      w[20,9]   6.7365269461077862e-02
 UP BND1      w[20,10]  6.7365269461077862e-02
 UP BND1      w[20,11]  6.7365269461077862e-02
 UP BND1      w[20,12]  6.7365269461077862e-02
 UP BND1      w[21,0]   6.7365269461077862e-02
 UP BND1      w[21,1]   6.7365269461077862e-02
 UP BND1      w[21,2]   6.7365269461077862e-02
 UP BND1      w[21,3]   6.7365269461077862e-02
 UP BND1      w[21,4]   6.7365269461077862e-02
 UP BND1      w[21,5]   6.7365269461077862e-02
 UP BND1      w[21,6]   6.7365269461077862e-02
 UP BND1      w[21,7]   6.7365269461077862e-02
 UP BND1      w[21,8]   6.7365269461077862e-02
 UP BND1      w[21,9]   6.7365269461077862e-02
 UP BND1      w[21,10]  6.7365269461077862e-02
 UP BND1      w[21,11]  6.7365269461077862e-02
 UP BND1      w[21,12]  6.7365269461077862e-02
 UP BND1      w[21,13]  6.7365269461077862e-02
 UP BND1      w[21,14]  6.7365269461077862e-02
 UP BND1      w[21,15]  6.7365269461077862e-02
 UP BND1      w[22,0]   6.7365269461077862e-02
 UP BND1      w[22,1]   6.7365269461077862e-02
 UP BND1      w[22,2]   6.7365269461077862e-02
 UP BND1      w[22,3]   6.7365269461077862e-02
 UP BND1      w[22,4]   6.7365269461077862e-02
 UP BND1      w[22,5]   6.7365269461077862e-02
 UP BND1      w[22,6]   6.7365269461077862e-02
 UP BND1      w[22,7]   6.7365269461077862e-02
 UP BND1      w[22,8]   6.7365269461077862e-02
 UP BND1      w[22,9]   6.7365269461077862e-02
 UP BND1      w[22,10]  6.7365269461077862e-02
 UP BND1      w[22,11]  6.7365269461077862e-02
 UP BND1      w[22,12]  6.7365269461077862e-02
 UP BND1      w[23,0]   6.7365269461077862e-02
 UP BND1      w[23,1]   6.7365269461077862e-02
 UP BND1      w[23,2]   6.7365269461077862e-02
 UP BND1      w[23,3]   6.7365269461077862e-02
 UP BND1      w[23,4]   6.7365269461077862e-02
 UP BND1      w[23,5]   6.7365269461077862e-02
 UP BND1      w[23,6]   6.7365269461077862e-02
 UP BND1      w[23,7]   6.7365269461077862e-02
 UP BND1      w[23,8]   6.7365269461077862e-02
 UP BND1      w[23,9]   6.7365269461077862e-02
 UP BND1      w[23,10]  6.7365269461077862e-02
 UP BND1      w[23,11]  6.7365269461077862e-02
 UP BND1      w[24,0]   6.7365269461077862e-02
 UP BND1      w[24,1]   6.7365269461077862e-02
 UP BND1      w[24,2]   6.7365269461077862e-02
 UP BND1      w[24,3]   6.7365269461077862e-02
 UP BND1      w[24,4]   6.7365269461077862e-02
 UP BND1      w[24,5]   6.7365269461077862e-02
 UP BND1      w[24,6]   6.7365269461077862e-02
 UP BND1      w[24,7]   6.7365269461077862e-02
 UP BND1      w[24,8]   6.7365269461077862e-02
 UP BND1      w[24,9]   6.7365269461077862e-02
 UP BND1      w[24,10]  6.7365269461077862e-02
 UP BND1      w[24,11]  6.7365269461077862e-02
 UP BND1      w[24,12]  6.7365269461077862e-02
 UP BND1      w[24,13]  6.7365269461077862e-02
 UP BND1      w[24,14]  6.7365269461077862e-02
 UP BND1      w[24,15]  6.7365269461077862e-02
 UP BND1      w[25,0]   6.7365269461077862e-02
 UP BND1      w[25,1]   6.7365269461077862e-02
 UP BND1      w[25,2]   6.7365269461077862e-02
 UP BND1      w[25,3]   6.7365269461077862e-02
 UP BND1      w[25,4]   6.7365269461077862e-02
 UP BND1      w[25,5]   6.7365269461077862e-02
 UP BND1      w[25,6]   6.7365269461077862e-02
 UP BND1      w[25,7]   6.7365269461077862e-02
 UP BND1      w[25,8]   6.7365269461077862e-02
 UP BND1      w[25,9]   6.7365269461077862e-02
 UP BND1      w[25,10]  6.7365269461077862e-02
 UP BND1      w[25,11]  6.7365269461077862e-02
 UP BND1      w[25,12]  6.7365269461077862e-02
 UP BND1      w[25,13]  6.7365269461077862e-02
 UP BND1      w[25,14]  6.7365269461077862e-02
 UP BND1      w[25,15]  6.7365269461077862e-02
 UP BND1      w[26,0]   6.7365269461077862e-02
 UP BND1      w[26,1]   6.7365269461077862e-02
 UP BND1      w[26,2]   6.7365269461077862e-02
 UP BND1      w[26,3]   6.7365269461077862e-02
 UP BND1      w[26,4]   6.7365269461077862e-02
 UP BND1      w[26,5]   6.7365269461077862e-02
 UP BND1      w[26,6]   6.7365269461077862e-02
 UP BND1      w[26,7]   6.7365269461077862e-02
 UP BND1      w[26,8]   6.7365269461077862e-02
 UP BND1      w[27,0]   6.7365269461077862e-02
 UP BND1      w[27,1]   6.7365269461077862e-02
 UP BND1      w[27,2]   6.7365269461077862e-02
 UP BND1      w[27,3]   6.7365269461077862e-02
 UP BND1      w[27,4]   6.7365269461077862e-02
 UP BND1      w[27,5]   6.7365269461077862e-02
 UP BND1      w[27,6]   6.7365269461077862e-02
 UP BND1      w[27,7]   6.7365269461077862e-02
 UP BND1      w[27,8]   6.7365269461077862e-02
 UP BND1      w[27,9]   6.7365269461077862e-02
 UP BND1      w[27,10]  6.7365269461077862e-02
 UP BND1      w[27,11]  6.7365269461077862e-02
 UP BND1      w[27,12]  6.7365269461077862e-02
 UP BND1      w[27,13]  6.7365269461077862e-02
 UP BND1      w[27,14]  6.7365269461077862e-02
 UP BND1      w[27,15]  6.7365269461077862e-02
 UP BND1      w[28,0]   6.7365269461077862e-02
 UP BND1      w[28,1]   6.7365269461077862e-02
 UP BND1      w[28,2]   6.7365269461077862e-02
 UP BND1      w[28,3]   6.7365269461077862e-02
 UP BND1      w[28,4]   6.7365269461077862e-02
 UP BND1      w[28,5]   6.7365269461077862e-02
 UP BND1      w[28,6]   6.7365269461077862e-02
 UP BND1      w[28,7]   6.7365269461077862e-02
 UP BND1      w[28,8]   6.7365269461077862e-02
 UP BND1      w[28,9]   6.7365269461077862e-02
 UP BND1      w[28,10]  6.7365269461077862e-02
 UP BND1      w[28,11]  6.7365269461077862e-02
 UP BND1      w[28,12]  6.7365269461077862e-02
 UP BND1      w[28,13]  6.7365269461077862e-02
 UP BND1      w[28,14]  6.7365269461077862e-02
 UP BND1      w[28,15]  6.7365269461077862e-02
 UP BND1      w[28,16]  6.7365269461077862e-02
 UP BND1      w[28,17]  6.7365269461077862e-02
 UP BND1      w[28,18]  6.7365269461077862e-02
 UP BND1      w[28,19]  6.7365269461077862e-02
 UP BND1      w[29,0]   6.7365269461077862e-02
 UP BND1      w[29,1]   6.7365269461077862e-02
 UP BND1      w[29,2]   6.7365269461077862e-02
 UP BND1      w[29,3]   6.7365269461077862e-02
 UP BND1      w[29,4]   6.7365269461077862e-02
 UP BND1      w[29,5]   6.7365269461077862e-02
 UP BND1      w[29,6]   6.7365269461077862e-02
 UP BND1      w[29,7]   6.7365269461077862e-02
 UP BND1      w[29,8]   6.7365269461077862e-02
 UP BND1      w[29,9]   6.7365269461077862e-02
 UP BND1      w[29,10]  6.7365269461077862e-02
 UP BND1      w[29,11]  6.7365269461077862e-02
 UP BND1      w[29,12]  6.7365269461077862e-02
 UP BND1      w[29,13]  6.7365269461077862e-02
 UP BND1      w[29,14]  6.7365269461077862e-02
 UP BND1      w[29,15]  6.7365269461077862e-02
 UP BND1      w[30,0]   6.7365269461077862e-02
 UP BND1      w[30,1]   6.7365269461077862e-02
 UP BND1      w[30,2]   6.7365269461077862e-02
 UP BND1      w[30,3]   6.7365269461077862e-02
 UP BND1      w[30,4]   6.7365269461077862e-02
 UP BND1      w[30,5]   6.7365269461077862e-02
 UP BND1      w[30,6]   6.7365269461077862e-02
 UP BND1      w[30,7]   6.7365269461077862e-02
 UP BND1      w[30,8]   6.7365269461077862e-02
 UP BND1      w[31,0]   6.7365269461077862e-02
 UP BND1      w[31,1]   6.7365269461077862e-02
 UP BND1      w[31,2]   6.7365269461077862e-02
 UP BND1      w[31,3]   6.7365269461077862e-02
 UP BND1      w[31,4]   6.7365269461077862e-02
 UP BND1      w[31,5]   6.7365269461077862e-02
 UP BND1      w[31,6]   6.7365269461077862e-02
 UP BND1      w[31,7]   6.7365269461077862e-02
 UP BND1      w[31,8]   6.7365269461077862e-02
 UP BND1      w[31,9]   6.7365269461077862e-02
 UP BND1      w[31,10]  6.7365269461077862e-02
 UP BND1      w[31,11]  6.7365269461077862e-02
 UP BND1      w[31,12]  6.7365269461077862e-02
 UP BND1      w[32,0]   6.7365269461077862e-02
 UP BND1      w[32,1]   6.7365269461077862e-02
 UP BND1      w[32,2]   6.7365269461077862e-02
 UP BND1      w[32,3]   6.7365269461077862e-02
 UP BND1      w[32,4]   6.7365269461077862e-02
 UP BND1      w[32,5]   6.7365269461077862e-02
 UP BND1      w[32,6]   6.7365269461077862e-02
 UP BND1      w[32,7]   6.7365269461077862e-02
 UP BND1      w[32,8]   6.7365269461077862e-02
 UP BND1      w[32,9]   6.7365269461077862e-02
 UP BND1      w[32,10]  6.7365269461077862e-02
 UP BND1      w[32,11]  6.7365269461077862e-02
 UP BND1      w[32,12]  6.7365269461077862e-02
 UP BND1      w[33,0]   6.7365269461077862e-02
 UP BND1      w[33,1]   6.7365269461077862e-02
 UP BND1      w[33,2]   6.7365269461077862e-02
 UP BND1      w[33,3]   6.7365269461077862e-02
 UP BND1      w[33,4]   6.7365269461077862e-02
 UP BND1      w[33,5]   6.7365269461077862e-02
 UP BND1      w[33,6]   6.7365269461077862e-02
 UP BND1      w[33,7]   6.7365269461077862e-02
 UP BND1      w[33,8]   6.7365269461077862e-02
 UP BND1      w[33,9]   6.7365269461077862e-02
 UP BND1      w[33,10]  6.7365269461077862e-02
 UP BND1      w[33,11]  6.7365269461077862e-02
 UP BND1      w[33,12]  6.7365269461077862e-02
 UP BND1      w[33,13]  6.7365269461077862e-02
 UP BND1      w[33,14]  6.7365269461077862e-02
 UP BND1      w[33,15]  6.7365269461077862e-02
 UP BND1      w[33,16]  6.7365269461077862e-02
 UP BND1      w[34,0]   6.7365269461077862e-02
 UP BND1      w[34,1]   6.7365269461077862e-02
 UP BND1      w[34,2]   6.7365269461077862e-02
 UP BND1      w[34,3]   6.7365269461077862e-02
 UP BND1      w[34,4]   6.7365269461077862e-02
 UP BND1      w[34,5]   6.7365269461077862e-02
 UP BND1      w[34,6]   6.7365269461077862e-02
 UP BND1      w[34,7]   6.7365269461077862e-02
 UP BND1      w[34,8]   6.7365269461077862e-02
 UP BND1      w[34,9]   6.7365269461077862e-02
 UP BND1      w[34,10]  6.7365269461077862e-02
 UP BND1      w[34,11]  6.7365269461077862e-02
 UP BND1      w[35,0]   6.7365269461077862e-02
 UP BND1      w[35,1]   6.7365269461077862e-02
 UP BND1      w[35,2]   6.7365269461077862e-02
 UP BND1      w[35,3]   6.7365269461077862e-02
 UP BND1      w[35,4]   6.7365269461077862e-02
 UP BND1      w[35,5]   6.7365269461077862e-02
 UP BND1      w[35,6]   6.7365269461077862e-02
 UP BND1      w[35,7]   6.7365269461077862e-02
 UP BND1      w[35,8]   6.7365269461077862e-02
 UP BND1      w[35,9]   6.7365269461077862e-02
 UP BND1      w[35,10]  6.7365269461077862e-02
 UP BND1      w[35,11]  6.7365269461077862e-02
 UP BND1      w[35,12]  6.7365269461077862e-02
 UP BND1      w[35,13]  6.7365269461077862e-02
 UP BND1      w[35,14]  6.7365269461077862e-02
 UP BND1      w[35,15]  6.7365269461077862e-02
 LO BND1      t         2.6697177726926005e-02
 UP BND1      t         6.7365269461077862e-02
ENDATA
