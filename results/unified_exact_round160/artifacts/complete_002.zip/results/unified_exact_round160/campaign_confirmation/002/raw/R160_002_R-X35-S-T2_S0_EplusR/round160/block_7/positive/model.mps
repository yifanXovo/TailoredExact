* Signature: 0x9b83bc2267dbc7ee
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_14_18
 E  normalized_mass_14_19
 E  normalized_ratio_14_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 E  onehot_12_47
 E  normalized_mass_12_48
 E  normalized_ratio_12_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_34_82
 E  normalized_mass_34_83
 E  normalized_ratio_34_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 E  onehot_16_117
 E  normalized_mass_16_118
 E  normalized_ratio_16_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 E  onehot_22_152
 E  normalized_mass_22_153
 E  normalized_ratio_22_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 E  onehot_7_187
 E  normalized_mass_7_188
 E  normalized_ratio_7_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 E  onehot_27_204
 E  normalized_mass_27_205
 E  normalized_ratio_27_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 E  onehot_5_239
 E  normalized_mass_5_240
 E  normalized_ratio_5_241
 G  stock_lb_242
 L  stock_ub_243
 L  parent_nonstrict_scope_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 E  normalization_301
 G  full_original_Gini_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 L  arc_capacity_404
 L  arc_capacity_405
 L  arc_capacity_406
 L  arc_capacity_407
 L  arc_capacity_408
 L  arc_capacity_409
 L  arc_capacity_410
 L  arc_capacity_411
 L  arc_capacity_412
 L  arc_capacity_413
 L  arc_capacity_414
 L  arc_capacity_415
 L  arc_capacity_416
 L  arc_capacity_417
 L  arc_capacity_418
 L  arc_capacity_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 E  depot_departure_or_bypass_797
 E  depot_return_or_bypass_798
 E  out_degree_799
 E  in_degree_800
 G  order_active_lb_801
 L  order_active_ub_802
 E  segment_load_conservation_803
 G  segment_prefix_lb_804
 L  segment_prefix_ub_805
 E  out_degree_806
 E  in_degree_807
 G  order_active_lb_808
 L  order_active_ub_809
 E  segment_load_conservation_810
 G  segment_prefix_lb_811
 L  segment_prefix_ub_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  segment_load_conservation_817
 G  segment_prefix_lb_818
 L  segment_prefix_ub_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  segment_load_conservation_824
 G  segment_prefix_lb_825
 L  segment_prefix_ub_826
 E  out_degree_827
 E  in_degree_828
 G  order_active_lb_829
 L  order_active_ub_830
 E  segment_load_conservation_831
 G  segment_prefix_lb_832
 L  segment_prefix_ub_833
 E  out_degree_834
 E  in_degree_835
 G  order_active_lb_836
 L  order_active_ub_837
 E  segment_load_conservation_838
 G  segment_prefix_lb_839
 L  segment_prefix_ub_840
 E  out_degree_841
 E  in_degree_842
 G  order_active_lb_843
 L  order_active_ub_844
 E  service_visit_def_845
 E  free_load_conservation_846
 E  out_degree_847
 E  in_degree_848
 G  order_active_lb_849
 L  order_active_ub_850
 E  service_visit_def_851
 E  free_load_conservation_852
 E  out_degree_853
 E  in_degree_854
 G  order_active_lb_855
 L  order_active_ub_856
 E  service_visit_def_857
 E  free_load_conservation_858
 E  out_degree_859
 E  in_degree_860
 G  order_active_lb_861
 L  order_active_ub_862
 E  service_visit_def_863
 E  free_load_conservation_864
 E  out_degree_865
 E  in_degree_866
 G  order_active_lb_867
 L  order_active_ub_868
 E  service_visit_def_869
 E  free_load_conservation_870
 E  out_degree_871
 E  in_degree_872
 G  order_active_lb_873
 L  order_active_ub_874
 E  service_visit_def_875
 E  free_load_conservation_876
 E  out_degree_877
 E  in_degree_878
 G  order_active_lb_879
 L  order_active_ub_880
 E  service_visit_def_881
 E  free_load_conservation_882
 E  out_degree_883
 E  in_degree_884
 G  order_active_lb_885
 L  order_active_ub_886
 E  service_visit_def_887
 E  free_load_conservation_888
 G  fixed_segment_relative_order_889
 G  fixed_segment_relative_order_890
 G  fixed_segment_relative_order_891
 G  fixed_segment_relative_order_892
 G  fixed_segment_relative_order_893
 L  original_T_including_depot_unload_894
 L  arc_capacity_895
 L  arc_capacity_896
 L  arc_capacity_897
 L  arc_capacity_898
 L  arc_capacity_899
 L  arc_capacity_900
 L  arc_capacity_901
 L  arc_capacity_902
 L  arc_capacity_903
 L  arc_capacity_904
 L  arc_capacity_905
 L  arc_capacity_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 E  depot_departure_or_bypass_1096
 E  depot_return_or_bypass_1097
 E  out_degree_1098
 E  in_degree_1099
 G  order_active_lb_1100
 L  order_active_ub_1101
 E  segment_load_conservation_1102
 G  segment_prefix_lb_1103
 L  segment_prefix_ub_1104
 E  out_degree_1105
 E  in_degree_1106
 G  order_active_lb_1107
 L  order_active_ub_1108
 E  segment_load_conservation_1109
 G  segment_prefix_lb_1110
 L  segment_prefix_ub_1111
 E  out_degree_1112
 E  in_degree_1113
 G  order_active_lb_1114
 L  order_active_ub_1115
 E  service_visit_def_1116
 E  free_load_conservation_1117
 E  out_degree_1118
 E  in_degree_1119
 G  order_active_lb_1120
 L  order_active_ub_1121
 E  service_visit_def_1122
 E  free_load_conservation_1123
 E  out_degree_1124
 E  in_degree_1125
 G  order_active_lb_1126
 L  order_active_ub_1127
 E  service_visit_def_1128
 E  free_load_conservation_1129
 E  out_degree_1130
 E  in_degree_1131
 G  order_active_lb_1132
 L  order_active_ub_1133
 E  service_visit_def_1134
 E  free_load_conservation_1135
 E  out_degree_1136
 E  in_degree_1137
 G  order_active_lb_1138
 L  order_active_ub_1139
 E  service_visit_def_1140
 E  free_load_conservation_1141
 E  out_degree_1142
 E  in_degree_1143
 G  order_active_lb_1144
 L  order_active_ub_1145
 E  service_visit_def_1146
 E  free_load_conservation_1147
 E  out_degree_1148
 E  in_degree_1149
 G  order_active_lb_1150
 L  order_active_ub_1151
 E  service_visit_def_1152
 E  free_load_conservation_1153
 E  out_degree_1154
 E  in_degree_1155
 G  order_active_lb_1156
 L  order_active_ub_1157
 E  service_visit_def_1158
 E  free_load_conservation_1159
 G  fixed_segment_relative_order_1160
 L  original_T_including_depot_unload_1161
 L  arc_capacity_1162
 L  arc_capacity_1163
 L  arc_capacity_1164
 L  arc_capacity_1165
 L  arc_capacity_1166
 L  arc_capacity_1167
 L  arc_capacity_1168
 L  arc_capacity_1169
 L  arc_capacity_1170
 L  arc_capacity_1171
 L  arc_capacity_1172
 L  arc_capacity_1173
 L  arc_capacity_1174
 L  arc_capacity_1175
 L  arc_capacity_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 E  depot_departure_or_bypass_1501
 E  depot_return_or_bypass_1502
 E  out_degree_1503
 E  in_degree_1504
 G  order_active_lb_1505
 L  order_active_ub_1506
 E  segment_load_conservation_1507
 G  segment_prefix_lb_1508
 L  segment_prefix_ub_1509
 E  out_degree_1510
 E  in_degree_1511
 G  order_active_lb_1512
 L  order_active_ub_1513
 E  segment_load_conservation_1514
 G  segment_prefix_lb_1515
 L  segment_prefix_ub_1516
 E  out_degree_1517
 E  in_degree_1518
 G  order_active_lb_1519
 L  order_active_ub_1520
 E  segment_load_conservation_1521
 G  segment_prefix_lb_1522
 L  segment_prefix_ub_1523
 E  out_degree_1524
 E  in_degree_1525
 G  order_active_lb_1526
 L  order_active_ub_1527
 E  segment_load_conservation_1528
 G  segment_prefix_lb_1529
 L  segment_prefix_ub_1530
 E  out_degree_1531
 E  in_degree_1532
 G  order_active_lb_1533
 L  order_active_ub_1534
 E  segment_load_conservation_1535
 G  segment_prefix_lb_1536
 L  segment_prefix_ub_1537
 E  out_degree_1538
 E  in_degree_1539
 G  order_active_lb_1540
 L  order_active_ub_1541
 E  service_visit_def_1542
 E  free_load_conservation_1543
 E  out_degree_1544
 E  in_degree_1545
 G  order_active_lb_1546
 L  order_active_ub_1547
 E  service_visit_def_1548
 E  free_load_conservation_1549
 E  out_degree_1550
 E  in_degree_1551
 G  order_active_lb_1552
 L  order_active_ub_1553
 E  service_visit_def_1554
 E  free_load_conservation_1555
 E  out_degree_1556
 E  in_degree_1557
 G  order_active_lb_1558
 L  order_active_ub_1559
 E  service_visit_def_1560
 E  free_load_conservation_1561
 E  out_degree_1562
 E  in_degree_1563
 G  order_active_lb_1564
 L  order_active_ub_1565
 E  service_visit_def_1566
 E  free_load_conservation_1567
 E  out_degree_1568
 E  in_degree_1569
 G  order_active_lb_1570
 L  order_active_ub_1571
 E  service_visit_def_1572
 E  free_load_conservation_1573
 E  out_degree_1574
 E  in_degree_1575
 G  order_active_lb_1576
 L  order_active_ub_1577
 E  service_visit_def_1578
 E  free_load_conservation_1579
 E  out_degree_1580
 E  in_degree_1581
 G  order_active_lb_1582
 L  order_active_ub_1583
 E  service_visit_def_1584
 E  free_load_conservation_1585
 G  fixed_segment_relative_order_1586
 G  fixed_segment_relative_order_1587
 G  fixed_segment_relative_order_1588
 G  fixed_segment_relative_order_1589
 L  original_T_including_depot_unload_1590
COLUMNS
    t         normalized_mass_14_19  -1
    t         normalized_mass_12_48  -1
    t         normalized_mass_34_83  -1
    t         normalized_mass_16_118  -1
    t         normalized_mass_22_153  -1
    t         normalized_mass_7_188  -1
    t         normalized_mass_27_205  -1
    t         normalized_mass_5_240  -1
    t         normalization_301  2.3255952380952380e+01
    t         full_original_Gini_302  -90.2738095238095
    q         OBJ       1
    q         parent_nonstrict_scope_244  1
    q         full_original_Gini_302  35
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       7.4474103065332977e-03
    x_14_0    product_lb_0  -2.5358490566012373e-02
    x_14_0    product_ub_1  -4.2999744049185572e-02
    x_14_0    onehot_14_18  1
    x_14_0    parent_nonstrict_scope_244  1.4894820613066595e-02
    x_14_0    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_0  1
    w_14_0    product_ub_1  1
    w_14_0    normalized_mass_14_19  1
    w_14_0    full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.7237051532666493e-03
    x_14_1    product_lb_2  -2.5358490566012373e-02
    x_14_1    product_ub_3  -4.2999744049185572e-02
    x_14_1    onehot_14_18  1
    x_14_1    stock_lb_242  1
    x_14_1    stock_ub_243  1
    x_14_1    parent_nonstrict_scope_244  1.1171115459799947e-02
    x_14_1    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_2  1
    w_14_1    product_ub_3  1
    w_14_1    normalized_mass_14_19  1
    w_14_1    normalized_ratio_14_20  -0.25
    w_14_1    full_original_Gini_302  -1.7005952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    product_lb_4  -2.5358490566012373e-02
    x_14_2    product_ub_5  -4.2999744049185572e-02
    x_14_2    onehot_14_18  1
    x_14_2    stock_lb_242  2
    x_14_2    stock_ub_243  2
    x_14_2    parent_nonstrict_scope_244  7.4474103065332977e-03
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_4  1
    w_14_2    product_ub_5  1
    w_14_2    normalized_mass_14_19  1
    w_14_2    normalized_ratio_14_20  -0.5
    w_14_2    full_original_Gini_302  -1.0955952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       -3.7237051532666488e-03
    x_14_3    product_lb_6  -2.5358490566012373e-02
    x_14_3    product_ub_7  -4.2999744049185572e-02
    x_14_3    onehot_14_18  1
    x_14_3    stock_lb_242  3
    x_14_3    stock_ub_243  3
    x_14_3    parent_nonstrict_scope_244  3.7237051532666488e-03
    x_14_3    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_6  1
    w_14_3    product_ub_7  1
    w_14_3    normalized_mass_14_19  1
    w_14_3    normalized_ratio_14_20  -0.75
    w_14_3    full_original_Gini_302  -5.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_4    OBJ       -7.4474103065332977e-03
    x_14_4    product_lb_8  -2.5358490566012373e-02
    x_14_4    product_ub_9  -4.2999744049185572e-02
    x_14_4    onehot_14_18  1
    x_14_4    stock_lb_242  4
    x_14_4    stock_ub_243  4
    x_14_4    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_8  1
    w_14_4    product_ub_9  1
    w_14_4    normalized_mass_14_19  1
    w_14_4    normalized_ratio_14_20  -1
    w_14_4    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -3.7237051532666488e-03
    x_14_5    product_lb_10  -2.5358490566012373e-02
    x_14_5    product_ub_11  -4.2999744049185572e-02
    x_14_5    onehot_14_18  1
    x_14_5    stock_lb_242  5
    x_14_5    stock_ub_243  5
    x_14_5    parent_nonstrict_scope_244  3.7237051532666488e-03
    x_14_5    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_10  1
    w_14_5    product_ub_11  1
    w_14_5    normalized_mass_14_19  1
    w_14_5    normalized_ratio_14_20  -1.25
    w_14_5    full_original_Gini_302  -1.0994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_6    product_lb_12  -2.5358490566012373e-02
    x_14_6    product_ub_13  -4.2999744049185572e-02
    x_14_6    onehot_14_18  1
    x_14_6    stock_lb_242  6
    x_14_6    stock_ub_243  6
    x_14_6    parent_nonstrict_scope_244  7.4474103065332977e-03
    x_14_6    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_12  1
    w_14_6    product_ub_13  1
    w_14_6    normalized_mass_14_19  1
    w_14_6    normalized_ratio_14_20  -1.5
    w_14_6    full_original_Gini_302  -1.7244047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       3.7237051532666493e-03
    x_14_7    product_lb_14  -2.5358490566012373e-02
    x_14_7    product_ub_15  -4.2999744049185572e-02
    x_14_7    onehot_14_18  1
    x_14_7    stock_lb_242  7
    x_14_7    stock_ub_243  7
    x_14_7    parent_nonstrict_scope_244  1.1171115459799947e-02
    x_14_7    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_14  1
    w_14_7    product_ub_15  1
    w_14_7    normalized_mass_14_19  1
    w_14_7    normalized_ratio_14_20  -1.75
    w_14_7    full_original_Gini_302  -2.3994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       7.4474103065332977e-03
    x_14_8    product_lb_16  -2.5358490566012373e-02
    x_14_8    product_ub_17  -4.2999744049185572e-02
    x_14_8    onehot_14_18  1
    x_14_8    stock_lb_242  8
    x_14_8    stock_ub_243  8
    x_14_8    parent_nonstrict_scope_244  1.4894820613066595e-02
    x_14_8    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_16  1
    w_14_8    product_ub_17  1
    w_14_8    normalized_mass_14_19  1
    w_14_8    normalized_ratio_14_20  -2
    w_14_8    full_original_Gini_302  -3.0744047619047617e+01
    rho_14    normalized_ratio_14_20  1
    rho_14    block_pair_pos_261  -1
    rho_14    block_pair_neg_262  1
    rho_14    block_pair_pos_263  -1
    rho_14    block_pair_neg_264  1
    rho_14    block_pair_pos_265  -1
    rho_14    block_pair_neg_266  1
    rho_14    block_pair_pos_267  -1
    rho_14    block_pair_neg_268  1
    rho_14    block_pair_pos_269  -1
    rho_14    block_pair_neg_270  1
    rho_14    block_pair_pos_271  -1
    rho_14    block_pair_neg_272  1
    rho_14    block_pair_pos_273  -1
    rho_14    block_pair_neg_274  1
    rho_14    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       1.6756644912833352e-02
    x_12_0    product_lb_21  -2.5358490566012373e-02
    x_12_0    product_ub_22  -4.2999744049185572e-02
    x_12_0    onehot_12_47  1
    x_12_0    parent_nonstrict_scope_244  0.0335132898256667
    x_12_0    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_21  1
    w_12_0    product_ub_22  1
    w_12_0    normalized_mass_12_48  1
    w_12_0    full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       1.1171096608555569e-02
    x_12_1    product_lb_23  -2.5358490566012373e-02
    x_12_1    product_ub_24  -4.2999744049185572e-02
    x_12_1    onehot_12_47  1
    x_12_1    stock_lb_242  1
    x_12_1    stock_ub_243  1
    x_12_1    parent_nonstrict_scope_244  2.7927741521388921e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_23  1
    w_12_1    product_ub_24  1
    w_12_1    normalized_mass_12_48  1
    w_12_1    normalized_ratio_12_49  -1.6666666666666666e-01
    w_12_1    full_original_Gini_302  -1.9089285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       5.5855483042777862e-03
    x_12_2    product_lb_25  -2.5358490566012373e-02
    x_12_2    product_ub_26  -4.2999744049185572e-02
    x_12_2    onehot_12_47  1
    x_12_2    stock_lb_242  2
    x_12_2    stock_ub_243  2
    x_12_2    parent_nonstrict_scope_244  2.2342193217111138e-02
    x_12_2    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_25  1
    w_12_2    product_ub_26  1
    w_12_2    normalized_mass_12_48  1
    w_12_2    normalized_ratio_12_49  -3.3333333333333331e-01
    w_12_2    full_original_Gini_302  -1.4922619047619044e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_27  -2.5358490566012373e-02
    x_12_3    product_ub_28  -4.2999744049185572e-02
    x_12_3    onehot_12_47  1
    x_12_3    stock_lb_242  3
    x_12_3    stock_ub_243  3
    x_12_3    parent_nonstrict_scope_244  1.6756644912833352e-02
    x_12_3    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_27  1
    w_12_3    product_ub_28  1
    w_12_3    normalized_mass_12_48  1
    w_12_3    normalized_ratio_12_49  -0.5
    w_12_3    full_original_Gini_302  -1.0955952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -5.5855483042777827e-03
    x_12_4    product_lb_29  -2.5358490566012373e-02
    x_12_4    product_ub_30  -4.2999744049185572e-02
    x_12_4    onehot_12_47  1
    x_12_4    stock_lb_242  4
    x_12_4    stock_ub_243  4
    x_12_4    parent_nonstrict_scope_244  1.1171096608555569e-02
    x_12_4    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_29  1
    w_12_4    product_ub_30  1
    w_12_4    normalized_mass_12_48  1
    w_12_4    normalized_ratio_12_49  -6.6666666666666663e-01
    w_12_4    full_original_Gini_302  -7.20595238095238
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -1.1171096608555565e-02
    x_12_5    product_lb_31  -2.5358490566012373e-02
    x_12_5    product_ub_32  -4.2999744049185572e-02
    x_12_5    onehot_12_47  1
    x_12_5    stock_lb_242  5
    x_12_5    stock_ub_243  5
    x_12_5    parent_nonstrict_scope_244  5.5855483042777862e-03
    x_12_5    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_31  1
    w_12_5    product_ub_32  1
    w_12_5    normalized_mass_12_48  1
    w_12_5    normalized_ratio_12_49  -8.3333333333333326e-01
    w_12_5    full_original_Gini_302  -5.0059523809523814e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -1.6756644912833352e-02
    x_12_6    product_lb_33  -2.5358490566012373e-02
    x_12_6    product_ub_34  -4.2999744049185572e-02
    x_12_6    onehot_12_47  1
    x_12_6    stock_lb_242  6
    x_12_6    stock_ub_243  6
    x_12_6    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_33  1
    w_12_6    product_ub_34  1
    w_12_6    normalized_mass_12_48  1
    w_12_6    normalized_ratio_12_49  -1
    w_12_6    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -1.1171096608555572e-02
    x_12_7    product_lb_35  -2.5358490566012373e-02
    x_12_7    product_ub_36  -4.2999744049185572e-02
    x_12_7    onehot_12_47  1
    x_12_7    stock_lb_242  7
    x_12_7    stock_ub_243  7
    x_12_7    parent_nonstrict_scope_244  5.5855483042777793e-03
    x_12_7    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_35  1
    w_12_7    product_ub_36  1
    w_12_7    normalized_mass_12_48  1
    w_12_7    normalized_ratio_12_49  -1.1666666666666665e+00
    w_12_7    full_original_Gini_302  -8.9107142857142811e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -5.5855483042777862e-03
    x_12_8    product_lb_37  -2.5358490566012373e-02
    x_12_8    product_ub_38  -4.2999744049185572e-02
    x_12_8    onehot_12_47  1
    x_12_8    stock_lb_242  8
    x_12_8    stock_ub_243  8
    x_12_8    parent_nonstrict_scope_244  1.1171096608555565e-02
    x_12_8    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_37  1
    w_12_8    product_ub_38  1
    w_12_8    normalized_mass_12_48  1
    w_12_8    normalized_ratio_12_49  -1.3333333333333333e+00
    w_12_8    full_original_Gini_302  -1.3077380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_9    product_lb_39  -2.5358490566012373e-02
    x_12_9    product_ub_40  -4.2999744049185572e-02
    x_12_9    onehot_12_47  1
    x_12_9    stock_lb_242  9
    x_12_9    stock_ub_243  9
    x_12_9    parent_nonstrict_scope_244  1.6756644912833352e-02
    x_12_9    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_39  1
    w_12_9    product_ub_40  1
    w_12_9    normalized_mass_12_48  1
    w_12_9    normalized_ratio_12_49  -1.5
    w_12_9    full_original_Gini_302  -1.7244047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       5.5855483042777793e-03
    x_12_10   product_lb_41  -2.5358490566012373e-02
    x_12_10   product_ub_42  -4.2999744049185572e-02
    x_12_10   onehot_12_47  1
    x_12_10   stock_lb_242  10
    x_12_10   stock_ub_243  10
    x_12_10   parent_nonstrict_scope_244  2.2342193217111131e-02
    x_12_10   unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_41  1
    w_12_10   product_ub_42  1
    w_12_10   normalized_mass_12_48  1
    w_12_10   normalized_ratio_12_49  -1.6666666666666665e+00
    w_12_10   full_original_Gini_302  -2.1744047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   OBJ       1.1171096608555565e-02
    x_12_11   product_lb_43  -2.5358490566012373e-02
    x_12_11   product_ub_44  -4.2999744049185572e-02
    x_12_11   onehot_12_47  1
    x_12_11   stock_lb_242  11
    x_12_11   stock_ub_243  11
    x_12_11   parent_nonstrict_scope_244  2.7927741521388917e-02
    x_12_11   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_43  1
    w_12_11   product_ub_44  1
    w_12_11   normalized_mass_12_48  1
    w_12_11   normalized_ratio_12_49  -1.8333333333333333e+00
    w_12_11   full_original_Gini_302  -2.6244047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.6756644912833352e-02
    x_12_12   product_lb_45  -2.5358490566012373e-02
    x_12_12   product_ub_46  -4.2999744049185572e-02
    x_12_12   onehot_12_47  1
    x_12_12   stock_lb_242  12
    x_12_12   stock_ub_243  12
    x_12_12   parent_nonstrict_scope_244  0.0335132898256667
    x_12_12   unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_45  1
    w_12_12   product_ub_46  1
    w_12_12   normalized_mass_12_48  1
    w_12_12   normalized_ratio_12_49  -2
    w_12_12   full_original_Gini_302  -3.0744047619047617e+01
    rho_12    normalized_ratio_12_49  1
    rho_12    block_pair_pos_249  -1
    rho_12    block_pair_neg_250  1
    rho_12    block_pair_pos_251  -1
    rho_12    block_pair_neg_252  1
    rho_12    block_pair_pos_253  -1
    rho_12    block_pair_neg_254  1
    rho_12    block_pair_pos_255  -1
    rho_12    block_pair_neg_256  1
    rho_12    block_pair_pos_257  -1
    rho_12    block_pair_neg_258  1
    rho_12    block_pair_pos_259  -1
    rho_12    block_pair_neg_260  1
    rho_12    block_pair_pos_265  1
    rho_12    block_pair_neg_266  -1
    rho_12    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_50  -2.5358490566012373e-02
    x_34_0    product_ub_51  -4.2999744049185572e-02
    x_34_0    onehot_34_82  1
    x_34_0    parent_nonstrict_scope_244  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_50  1
    w_34_0    product_ub_51  1
    w_34_0    normalized_mass_34_83  1
    w_34_0    full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_52  -2.5358490566012373e-02
    x_34_1    product_ub_53  -4.2999744049185572e-02
    x_34_1    onehot_34_82  1
    x_34_1    stock_lb_242  1
    x_34_1    stock_ub_243  1
    x_34_1    parent_nonstrict_scope_244  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_52  1
    w_34_1    product_ub_53  1
    w_34_1    normalized_mass_34_83  1
    w_34_1    normalized_ratio_34_84  -0.125
    w_34_1    full_original_Gini_302  -2.0130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_54  -2.5358490566012373e-02
    x_34_2    product_ub_55  -4.2999744049185572e-02
    x_34_2    onehot_34_82  1
    x_34_2    stock_lb_242  2
    x_34_2    stock_ub_243  2
    x_34_2    parent_nonstrict_scope_244  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_54  1
    w_34_2    product_ub_55  1
    w_34_2    normalized_mass_34_83  1
    w_34_2    normalized_ratio_34_84  -0.25
    w_34_2    full_original_Gini_302  -1.7005952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_56  -2.5358490566012373e-02
    x_34_3    product_ub_57  -4.2999744049185572e-02
    x_34_3    onehot_34_82  1
    x_34_3    stock_lb_242  3
    x_34_3    stock_ub_243  3
    x_34_3    parent_nonstrict_scope_244  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_56  1
    w_34_3    product_ub_57  1
    w_34_3    normalized_mass_34_83  1
    w_34_3    normalized_ratio_34_84  -0.375
    w_34_3    full_original_Gini_302  -1.3880952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_58  -2.5358490566012373e-02
    x_34_4    product_ub_59  -4.2999744049185572e-02
    x_34_4    onehot_34_82  1
    x_34_4    stock_lb_242  4
    x_34_4    stock_ub_243  4
    x_34_4    parent_nonstrict_scope_244  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_58  1
    w_34_4    product_ub_59  1
    w_34_4    normalized_mass_34_83  1
    w_34_4    normalized_ratio_34_84  -0.5
    w_34_4    full_original_Gini_302  -1.0955952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_60  -2.5358490566012373e-02
    x_34_5    product_ub_61  -4.2999744049185572e-02
    x_34_5    onehot_34_82  1
    x_34_5    stock_lb_242  5
    x_34_5    stock_ub_243  5
    x_34_5    parent_nonstrict_scope_244  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_60  1
    w_34_5    product_ub_61  1
    w_34_5    normalized_mass_34_83  1
    w_34_5    normalized_ratio_34_84  -0.625
    w_34_5    full_original_Gini_302  -8.08095238095238
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_62  -2.5358490566012373e-02
    x_34_6    product_ub_63  -4.2999744049185572e-02
    x_34_6    onehot_34_82  1
    x_34_6    stock_lb_242  6
    x_34_6    stock_ub_243  6
    x_34_6    parent_nonstrict_scope_244  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_62  1
    w_34_6    product_ub_63  1
    w_34_6    normalized_mass_34_83  1
    w_34_6    normalized_ratio_34_84  -0.75
    w_34_6    full_original_Gini_302  -5.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_64  -2.5358490566012373e-02
    x_34_7    product_ub_65  -4.2999744049185572e-02
    x_34_7    onehot_34_82  1
    x_34_7    stock_lb_242  7
    x_34_7    stock_ub_243  7
    x_34_7    parent_nonstrict_scope_244  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_64  1
    w_34_7    product_ub_65  1
    w_34_7    normalized_mass_34_83  1
    w_34_7    normalized_ratio_34_84  -0.875
    w_34_7    full_original_Gini_302  -4.8690476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_66  -2.5358490566012373e-02
    x_34_8    product_ub_67  -4.2999744049185572e-02
    x_34_8    onehot_34_82  1
    x_34_8    stock_lb_242  8
    x_34_8    stock_ub_243  8
    x_34_8    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_66  1
    w_34_8    product_ub_67  1
    w_34_8    normalized_mass_34_83  1
    w_34_8    normalized_ratio_34_84  -1
    w_34_8    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_68  -2.5358490566012373e-02
    x_34_9    product_ub_69  -4.2999744049185572e-02
    x_34_9    onehot_34_82  1
    x_34_9    stock_lb_242  9
    x_34_9    stock_ub_243  9
    x_34_9    parent_nonstrict_scope_244  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_68  1
    w_34_9    product_ub_69  1
    w_34_9    normalized_mass_34_83  1
    w_34_9    normalized_ratio_34_84  -1.125
    w_34_9    full_original_Gini_302  -7.8690476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_70  -2.5358490566012373e-02
    x_34_10   product_ub_71  -4.2999744049185572e-02
    x_34_10   onehot_34_82  1
    x_34_10   stock_lb_242  10
    x_34_10   stock_ub_243  10
    x_34_10   parent_nonstrict_scope_244  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_70  1
    w_34_10   product_ub_71  1
    w_34_10   normalized_mass_34_83  1
    w_34_10   normalized_ratio_34_84  -1.25
    w_34_10   full_original_Gini_302  -1.0994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_72  -2.5358490566012373e-02
    x_34_11   product_ub_73  -4.2999744049185572e-02
    x_34_11   onehot_34_82  1
    x_34_11   stock_lb_242  11
    x_34_11   stock_ub_243  11
    x_34_11   parent_nonstrict_scope_244  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_72  1
    w_34_11   product_ub_73  1
    w_34_11   normalized_mass_34_83  1
    w_34_11   normalized_ratio_34_84  -1.375
    w_34_11   full_original_Gini_302  -1.4119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_74  -2.5358490566012373e-02
    x_34_12   product_ub_75  -4.2999744049185572e-02
    x_34_12   onehot_34_82  1
    x_34_12   stock_lb_242  12
    x_34_12   stock_ub_243  12
    x_34_12   parent_nonstrict_scope_244  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_74  1
    w_34_12   product_ub_75  1
    w_34_12   normalized_mass_34_83  1
    w_34_12   normalized_ratio_34_84  -1.5
    w_34_12   full_original_Gini_302  -1.7244047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_76  -2.5358490566012373e-02
    x_34_13   product_ub_77  -4.2999744049185572e-02
    x_34_13   onehot_34_82  1
    x_34_13   stock_lb_242  13
    x_34_13   stock_ub_243  13
    x_34_13   parent_nonstrict_scope_244  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_76  1
    w_34_13   product_ub_77  1
    w_34_13   normalized_mass_34_83  1
    w_34_13   normalized_ratio_34_84  -1.625
    w_34_13   full_original_Gini_302  -2.0619047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_78  -2.5358490566012373e-02
    x_34_14   product_ub_79  -4.2999744049185572e-02
    x_34_14   onehot_34_82  1
    x_34_14   stock_lb_242  14
    x_34_14   stock_ub_243  14
    x_34_14   parent_nonstrict_scope_244  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_78  1
    w_34_14   product_ub_79  1
    w_34_14   normalized_mass_34_83  1
    w_34_14   normalized_ratio_34_84  -1.75
    w_34_14   full_original_Gini_302  -2.3994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_80  -2.5358490566012373e-02
    x_34_15   product_ub_81  -4.2999744049185572e-02
    x_34_15   onehot_34_82  1
    x_34_15   stock_lb_242  15
    x_34_15   stock_ub_243  15
    x_34_15   parent_nonstrict_scope_244  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_80  1
    w_34_15   product_ub_81  1
    w_34_15   normalized_mass_34_83  1
    w_34_15   normalized_ratio_34_84  -1.875
    w_34_15   full_original_Gini_302  -2.7369047619047620e+01
    rho_34    normalized_ratio_34_84  1
    rho_34    block_pair_pos_259  1
    rho_34    block_pair_neg_260  -1
    rho_34    block_pair_pos_273  1
    rho_34    block_pair_neg_274  -1
    rho_34    block_pair_pos_291  -1
    rho_34    block_pair_neg_292  1
    rho_34    block_pair_pos_293  -1
    rho_34    block_pair_neg_294  1
    rho_34    block_pair_pos_295  -1
    rho_34    block_pair_neg_296  1
    rho_34    block_pair_pos_297  -1
    rho_34    block_pair_neg_298  1
    rho_34    block_pair_pos_299  -1
    rho_34    block_pair_neg_300  1
    rho_34    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       2.9789603523644435e-02
    x_16_0    product_lb_85  -2.5358490566012373e-02
    x_16_0    product_ub_86  -4.2999744049185572e-02
    x_16_0    onehot_16_117  1
    x_16_0    parent_nonstrict_scope_244  5.9579207047288869e-02
    x_16_0    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_85  1
    w_16_0    product_ub_86  1
    w_16_0    normalized_mass_16_118  1
    w_16_0    full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       2.2342202642733327e-02
    x_16_1    product_lb_87  -2.5358490566012373e-02
    x_16_1    product_ub_88  -4.2999744049185572e-02
    x_16_1    onehot_16_117  1
    x_16_1    stock_lb_242  1
    x_16_1    stock_ub_243  1
    x_16_1    parent_nonstrict_scope_244  5.2131806166377762e-02
    x_16_1    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_87  1
    w_16_1    product_ub_88  1
    w_16_1    normalized_mass_16_118  1
    w_16_1    normalized_ratio_16_119  -0.125
    w_16_1    full_original_Gini_302  -2.0130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       1.4894801761822219e-02
    x_16_2    product_lb_89  -2.5358490566012373e-02
    x_16_2    product_ub_90  -4.2999744049185572e-02
    x_16_2    onehot_16_117  1
    x_16_2    stock_lb_242  2
    x_16_2    stock_ub_243  2
    x_16_2    parent_nonstrict_scope_244  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_89  1
    w_16_2    product_ub_90  1
    w_16_2    normalized_mass_16_118  1
    w_16_2    normalized_ratio_16_119  -0.25
    w_16_2    full_original_Gini_302  -1.7005952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    OBJ       7.4474008809111113e-03
    x_16_3    product_lb_91  -2.5358490566012373e-02
    x_16_3    product_ub_92  -4.2999744049185572e-02
    x_16_3    onehot_16_117  1
    x_16_3    stock_lb_242  3
    x_16_3    stock_ub_243  3
    x_16_3    parent_nonstrict_scope_244  3.7237004404555546e-02
    x_16_3    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_91  1
    w_16_3    product_ub_92  1
    w_16_3    normalized_mass_16_118  1
    w_16_3    normalized_ratio_16_119  -0.375
    w_16_3    full_original_Gini_302  -1.3880952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    product_lb_93  -2.5358490566012373e-02
    x_16_4    product_ub_94  -4.2999744049185572e-02
    x_16_4    onehot_16_117  1
    x_16_4    stock_lb_242  4
    x_16_4    stock_ub_243  4
    x_16_4    parent_nonstrict_scope_244  2.9789603523644435e-02
    x_16_4    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_93  1
    w_16_4    product_ub_94  1
    w_16_4    normalized_mass_16_118  1
    w_16_4    normalized_ratio_16_119  -0.5
    w_16_4    full_original_Gini_302  -1.0955952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -7.4474008809111078e-03
    x_16_5    product_lb_95  -2.5358490566012373e-02
    x_16_5    product_ub_96  -4.2999744049185572e-02
    x_16_5    onehot_16_117  1
    x_16_5    stock_lb_242  5
    x_16_5    stock_ub_243  5
    x_16_5    parent_nonstrict_scope_244  2.2342202642733327e-02
    x_16_5    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_95  1
    w_16_5    product_ub_96  1
    w_16_5    normalized_mass_16_118  1
    w_16_5    normalized_ratio_16_119  -0.625
    w_16_5    full_original_Gini_302  -8.08095238095238
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -1.4894801761822217e-02
    x_16_6    product_lb_97  -2.5358490566012373e-02
    x_16_6    product_ub_98  -4.2999744049185572e-02
    x_16_6    onehot_16_117  1
    x_16_6    stock_lb_242  6
    x_16_6    stock_ub_243  6
    x_16_6    parent_nonstrict_scope_244  1.4894801761822217e-02
    x_16_6    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_97  1
    w_16_6    product_ub_98  1
    w_16_6    normalized_mass_16_118  1
    w_16_6    normalized_ratio_16_119  -0.75
    w_16_6    full_original_Gini_302  -5.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -2.2342202642733327e-02
    x_16_7    product_lb_99  -2.5358490566012373e-02
    x_16_7    product_ub_100  -4.2999744049185572e-02
    x_16_7    onehot_16_117  1
    x_16_7    stock_lb_242  7
    x_16_7    stock_ub_243  7
    x_16_7    parent_nonstrict_scope_244  7.4474008809111087e-03
    x_16_7    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_99  1
    w_16_7    product_ub_100  1
    w_16_7    normalized_mass_16_118  1
    w_16_7    normalized_ratio_16_119  -0.875
    w_16_7    full_original_Gini_302  -4.8690476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -2.9789603523644435e-02
    x_16_8    product_lb_101  -2.5358490566012373e-02
    x_16_8    product_ub_102  -4.2999744049185572e-02
    x_16_8    onehot_16_117  1
    x_16_8    stock_lb_242  8
    x_16_8    stock_ub_243  8
    x_16_8    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_101  1
    w_16_8    product_ub_102  1
    w_16_8    normalized_mass_16_118  1
    w_16_8    normalized_ratio_16_119  -1
    w_16_8    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_9    OBJ       -2.2342202642733327e-02
    x_16_9    product_lb_103  -2.5358490566012373e-02
    x_16_9    product_ub_104  -4.2999744049185572e-02
    x_16_9    onehot_16_117  1
    x_16_9    stock_lb_242  9
    x_16_9    stock_ub_243  9
    x_16_9    parent_nonstrict_scope_244  7.4474008809111087e-03
    x_16_9    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_103  1
    w_16_9    product_ub_104  1
    w_16_9    normalized_mass_16_118  1
    w_16_9    normalized_ratio_16_119  -1.125
    w_16_9    full_original_Gini_302  -7.8690476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       -1.4894801761822217e-02
    x_16_10   product_lb_105  -2.5358490566012373e-02
    x_16_10   product_ub_106  -4.2999744049185572e-02
    x_16_10   onehot_16_117  1
    x_16_10   stock_lb_242  10
    x_16_10   stock_ub_243  10
    x_16_10   parent_nonstrict_scope_244  1.4894801761822217e-02
    x_16_10   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_105  1
    w_16_10   product_ub_106  1
    w_16_10   normalized_mass_16_118  1
    w_16_10   normalized_ratio_16_119  -1.25
    w_16_10   full_original_Gini_302  -1.0994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       -7.4474008809111078e-03
    x_16_11   product_lb_107  -2.5358490566012373e-02
    x_16_11   product_ub_108  -4.2999744049185572e-02
    x_16_11   onehot_16_117  1
    x_16_11   stock_lb_242  11
    x_16_11   stock_ub_243  11
    x_16_11   parent_nonstrict_scope_244  2.2342202642733327e-02
    x_16_11   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_107  1
    w_16_11   product_ub_108  1
    w_16_11   normalized_mass_16_118  1
    w_16_11   normalized_ratio_16_119  -1.375
    w_16_11   full_original_Gini_302  -1.4119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   product_lb_109  -2.5358490566012373e-02
    x_16_12   product_ub_110  -4.2999744049185572e-02
    x_16_12   onehot_16_117  1
    x_16_12   stock_lb_242  12
    x_16_12   stock_ub_243  12
    x_16_12   parent_nonstrict_scope_244  2.9789603523644435e-02
    x_16_12   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_109  1
    w_16_12   product_ub_110  1
    w_16_12   normalized_mass_16_118  1
    w_16_12   normalized_ratio_16_119  -1.5
    w_16_12   full_original_Gini_302  -1.7244047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_13   OBJ       7.4474008809111113e-03
    x_16_13   product_lb_111  -2.5358490566012373e-02
    x_16_13   product_ub_112  -4.2999744049185572e-02
    x_16_13   onehot_16_117  1
    x_16_13   stock_lb_242  13
    x_16_13   stock_ub_243  13
    x_16_13   parent_nonstrict_scope_244  3.7237004404555546e-02
    x_16_13   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_13   product_lb_111  1
    w_16_13   product_ub_112  1
    w_16_13   normalized_mass_16_118  1
    w_16_13   normalized_ratio_16_119  -1.625
    w_16_13   full_original_Gini_302  -2.0619047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_14   OBJ       1.4894801761822219e-02
    x_16_14   product_lb_113  -2.5358490566012373e-02
    x_16_14   product_ub_114  -4.2999744049185572e-02
    x_16_14   onehot_16_117  1
    x_16_14   stock_lb_242  14
    x_16_14   stock_ub_243  14
    x_16_14   parent_nonstrict_scope_244  4.4684405285466654e-02
    x_16_14   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_14   product_lb_113  1
    w_16_14   product_ub_114  1
    w_16_14   normalized_mass_16_118  1
    w_16_14   normalized_ratio_16_119  -1.75
    w_16_14   full_original_Gini_302  -2.3994047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_15   OBJ       2.2342202642733327e-02
    x_16_15   product_lb_115  -2.5358490566012373e-02
    x_16_15   product_ub_116  -4.2999744049185572e-02
    x_16_15   onehot_16_117  1
    x_16_15   stock_lb_242  15
    x_16_15   stock_ub_243  15
    x_16_15   parent_nonstrict_scope_244  5.2131806166377762e-02
    x_16_15   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_15   product_lb_115  1
    w_16_15   product_ub_116  1
    w_16_15   normalized_mass_16_118  1
    w_16_15   normalized_ratio_16_119  -1.875
    w_16_15   full_original_Gini_302  -2.7369047619047620e+01
    rho_16    normalized_ratio_16_119  1
    rho_16    block_pair_pos_253  1
    rho_16    block_pair_neg_254  -1
    rho_16    block_pair_pos_267  1
    rho_16    block_pair_neg_268  -1
    rho_16    block_pair_pos_275  -1
    rho_16    block_pair_neg_276  1
    rho_16    block_pair_pos_277  -1
    rho_16    block_pair_neg_278  1
    rho_16    block_pair_pos_279  -1
    rho_16    block_pair_neg_280  1
    rho_16    block_pair_pos_281  -1
    rho_16    block_pair_neg_282  1
    rho_16    block_pair_pos_295  1
    rho_16    block_pair_neg_296  -1
    rho_16    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_120  -2.5358490566012373e-02
    x_22_0    product_ub_121  -4.2999744049185572e-02
    x_22_0    onehot_22_152  1
    x_22_0    parent_nonstrict_scope_244  0.0456153362865944
    x_22_0    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_120  1
    w_22_0    product_ub_121  1
    w_22_0    normalized_mass_22_153  1
    w_22_0    full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_122  -2.5358490566012373e-02
    x_22_1    product_ub_123  -4.2999744049185572e-02
    x_22_1    onehot_22_152  1
    x_22_1    stock_lb_242  1
    x_22_1    stock_ub_243  1
    x_22_1    parent_nonstrict_scope_244  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_122  1
    w_22_1    product_ub_123  1
    w_22_1    normalized_mass_22_153  1
    w_22_1    normalized_ratio_22_154  -1.4285714285714285e-01
    w_22_1    full_original_Gini_302  -1.9684523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_124  -2.5358490566012373e-02
    x_22_2    product_ub_125  -4.2999744049185572e-02
    x_22_2    onehot_22_152  1
    x_22_2    stock_lb_242  2
    x_22_2    stock_ub_243  2
    x_22_2    parent_nonstrict_scope_244  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_124  1
    w_22_2    product_ub_125  1
    w_22_2    normalized_mass_22_153  1
    w_22_2    normalized_ratio_22_154  -2.8571428571428570e-01
    w_22_2    full_original_Gini_302  -1.6113095238095234e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_126  -2.5358490566012373e-02
    x_22_3    product_ub_127  -4.2999744049185572e-02
    x_22_3    onehot_22_152  1
    x_22_3    stock_lb_242  3
    x_22_3    stock_ub_243  3
    x_22_3    parent_nonstrict_scope_244  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_126  1
    w_22_3    product_ub_127  1
    w_22_3    normalized_mass_22_153  1
    w_22_3    normalized_ratio_22_154  -4.2857142857142855e-01
    w_22_3    full_original_Gini_302  -1.2598809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_128  -2.5358490566012373e-02
    x_22_4    product_ub_129  -4.2999744049185572e-02
    x_22_4    onehot_22_152  1
    x_22_4    stock_lb_242  4
    x_22_4    stock_ub_243  4
    x_22_4    parent_nonstrict_scope_244  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_128  1
    w_22_4    product_ub_129  1
    w_22_4    normalized_mass_22_153  1
    w_22_4    normalized_ratio_22_154  -5.7142857142857140e-01
    w_22_4    full_original_Gini_302  -9.31309523809524
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_130  -2.5358490566012373e-02
    x_22_5    product_ub_131  -4.2999744049185572e-02
    x_22_5    onehot_22_152  1
    x_22_5    stock_lb_242  5
    x_22_5    stock_ub_243  5
    x_22_5    parent_nonstrict_scope_244  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_130  1
    w_22_5    product_ub_131  1
    w_22_5    normalized_mass_22_153  1
    w_22_5    normalized_ratio_22_154  -7.1428571428571419e-01
    w_22_5    full_original_Gini_302  -6.3964285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_132  -2.5358490566012373e-02
    x_22_6    product_ub_133  -4.2999744049185572e-02
    x_22_6    onehot_22_152  1
    x_22_6    stock_lb_242  6
    x_22_6    stock_ub_243  6
    x_22_6    parent_nonstrict_scope_244  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_132  1
    w_22_6    product_ub_133  1
    w_22_6    normalized_mass_22_153  1
    w_22_6    normalized_ratio_22_154  -8.5714285714285710e-01
    w_22_6    full_original_Gini_302  -4.8869047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_134  -2.5358490566012373e-02
    x_22_7    product_ub_135  -4.2999744049185572e-02
    x_22_7    onehot_22_152  1
    x_22_7    stock_lb_242  7
    x_22_7    stock_ub_243  7
    x_22_7    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_134  1
    w_22_7    product_ub_135  1
    w_22_7    normalized_mass_22_153  1
    w_22_7    normalized_ratio_22_154  -1
    w_22_7    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_136  -2.5358490566012373e-02
    x_22_8    product_ub_137  -4.2999744049185572e-02
    x_22_8    onehot_22_152  1
    x_22_8    stock_lb_242  8
    x_22_8    stock_ub_243  8
    x_22_8    parent_nonstrict_scope_244  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_136  1
    w_22_8    product_ub_137  1
    w_22_8    normalized_mass_22_153  1
    w_22_8    normalized_ratio_22_154  -1.1428571428571428e+00
    w_22_8    full_original_Gini_302  -8.3154761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_138  -2.5358490566012373e-02
    x_22_9    product_ub_139  -4.2999744049185572e-02
    x_22_9    onehot_22_152  1
    x_22_9    stock_lb_242  9
    x_22_9    stock_ub_243  9
    x_22_9    parent_nonstrict_scope_244  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_138  1
    w_22_9    product_ub_139  1
    w_22_9    normalized_mass_22_153  1
    w_22_9    normalized_ratio_22_154  -1.2857142857142856e+00
    w_22_9    full_original_Gini_302  -1.1886904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_140  -2.5358490566012373e-02
    x_22_10   product_ub_141  -4.2999744049185572e-02
    x_22_10   onehot_22_152  1
    x_22_10   stock_lb_242  10
    x_22_10   stock_ub_243  10
    x_22_10   parent_nonstrict_scope_244  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_140  1
    w_22_10   product_ub_141  1
    w_22_10   normalized_mass_22_153  1
    w_22_10   normalized_ratio_22_154  -1.4285714285714284e+00
    w_22_10   full_original_Gini_302  -1.5458333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_142  -2.5358490566012373e-02
    x_22_11   product_ub_143  -4.2999744049185572e-02
    x_22_11   onehot_22_152  1
    x_22_11   stock_lb_242  11
    x_22_11   stock_ub_243  11
    x_22_11   parent_nonstrict_scope_244  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_142  1
    w_22_11   product_ub_143  1
    w_22_11   normalized_mass_22_153  1
    w_22_11   normalized_ratio_22_154  -1.5714285714285714e+00
    w_22_11   full_original_Gini_302  -1.9172619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_144  -2.5358490566012373e-02
    x_22_12   product_ub_145  -4.2999744049185572e-02
    x_22_12   onehot_22_152  1
    x_22_12   stock_lb_242  12
    x_22_12   stock_ub_243  12
    x_22_12   parent_nonstrict_scope_244  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_144  1
    w_22_12   product_ub_145  1
    w_22_12   normalized_mass_22_153  1
    w_22_12   normalized_ratio_22_154  -1.7142857142857142e+00
    w_22_12   full_original_Gini_302  -23.0297619047619
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_146  -2.5358490566012373e-02
    x_22_13   product_ub_147  -4.2999744049185572e-02
    x_22_13   onehot_22_152  1
    x_22_13   stock_lb_242  13
    x_22_13   stock_ub_243  13
    x_22_13   parent_nonstrict_scope_244  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_146  1
    w_22_13   product_ub_147  1
    w_22_13   normalized_mass_22_153  1
    w_22_13   normalized_ratio_22_154  -1.8571428571428570e+00
    w_22_13   full_original_Gini_302  -2.6886904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_148  -2.5358490566012373e-02
    x_22_14   product_ub_149  -4.2999744049185572e-02
    x_22_14   onehot_22_152  1
    x_22_14   stock_lb_242  14
    x_22_14   stock_ub_243  14
    x_22_14   parent_nonstrict_scope_244  0.0456153362865944
    x_22_14   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_148  1
    w_22_14   product_ub_149  1
    w_22_14   normalized_mass_22_153  1
    w_22_14   normalized_ratio_22_154  -2
    w_22_14   full_original_Gini_302  -3.0744047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_150  -2.5358490566012373e-02
    x_22_15   product_ub_151  -4.2999744049185572e-02
    x_22_15   onehot_22_152  1
    x_22_15   stock_lb_242  15
    x_22_15   stock_ub_243  15
    x_22_15   parent_nonstrict_scope_244  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_150  1
    w_22_15   product_ub_151  1
    w_22_15   normalized_mass_22_153  1
    w_22_15   normalized_ratio_22_154  -2.1428571428571428e+00
    w_22_15   full_original_Gini_302  -3.4601190476190482e+01
    rho_22    normalized_ratio_22_154  1
    rho_22    block_pair_pos_255  1
    rho_22    block_pair_neg_256  -1
    rho_22    block_pair_pos_269  1
    rho_22    block_pair_neg_270  -1
    rho_22    block_pair_pos_279  1
    rho_22    block_pair_neg_280  -1
    rho_22    block_pair_pos_283  -1
    rho_22    block_pair_neg_284  1
    rho_22    block_pair_pos_285  -1
    rho_22    block_pair_neg_286  1
    rho_22    block_pair_pos_287  -1
    rho_22    block_pair_neg_288  1
    rho_22    block_pair_pos_297  1
    rho_22    block_pair_neg_298  -1
    rho_22    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       1.9549429837111887e-02
    x_7_0     product_lb_155  -2.5358490566012373e-02
    x_7_0     product_ub_156  -4.2999744049185572e-02
    x_7_0     onehot_7_187  1
    x_7_0     parent_nonstrict_scope_244  0.0456153362865944
    x_7_0     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_155  1
    w_7_0     product_ub_156  1
    w_7_0     normalized_mass_7_188  1
    w_7_0     full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       1.3032953224741260e-02
    x_7_1     product_lb_157  -2.5358490566012373e-02
    x_7_1     product_ub_158  -4.2999744049185572e-02
    x_7_1     onehot_7_187  1
    x_7_1     stock_lb_242  1
    x_7_1     stock_ub_243  1
    x_7_1     parent_nonstrict_scope_244  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_157  1
    w_7_1     product_ub_158  1
    w_7_1     normalized_mass_7_188  1
    w_7_1     normalized_ratio_7_189  -1.4285714285714285e-01
    w_7_1     full_original_Gini_302  -1.9684523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       6.5164766123706336e-03
    x_7_2     product_lb_159  -2.5358490566012373e-02
    x_7_2     product_ub_160  -4.2999744049185572e-02
    x_7_2     onehot_7_187  1
    x_7_2     stock_lb_242  2
    x_7_2     stock_ub_243  2
    x_7_2     parent_nonstrict_scope_244  3.2582383061853147e-02
    x_7_2     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_159  1
    w_7_2     product_ub_160  1
    w_7_2     normalized_mass_7_188  1
    w_7_2     normalized_ratio_7_189  -2.8571428571428570e-01
    w_7_2     full_original_Gini_302  -1.6113095238095234e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     product_lb_161  -2.5358490566012373e-02
    x_7_3     product_ub_162  -4.2999744049185572e-02
    x_7_3     onehot_7_187  1
    x_7_3     stock_lb_242  3
    x_7_3     stock_ub_243  3
    x_7_3     parent_nonstrict_scope_244  2.6065906449482514e-02
    x_7_3     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_161  1
    w_7_3     product_ub_162  1
    w_7_3     normalized_mass_7_188  1
    w_7_3     normalized_ratio_7_189  -4.2857142857142855e-01
    w_7_3     full_original_Gini_302  -1.2598809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -6.5164766123706266e-03
    x_7_4     product_lb_163  -2.5358490566012373e-02
    x_7_4     product_ub_164  -4.2999744049185572e-02
    x_7_4     onehot_7_187  1
    x_7_4     stock_lb_242  4
    x_7_4     stock_ub_243  4
    x_7_4     parent_nonstrict_scope_244  1.9549429837111887e-02
    x_7_4     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_163  1
    w_7_4     product_ub_164  1
    w_7_4     normalized_mass_7_188  1
    w_7_4     normalized_ratio_7_189  -5.7142857142857140e-01
    w_7_4     full_original_Gini_302  -9.31309523809524
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.3032953224741252e-02
    x_7_5     product_lb_165  -2.5358490566012373e-02
    x_7_5     product_ub_166  -4.2999744049185572e-02
    x_7_5     onehot_7_187  1
    x_7_5     stock_lb_242  5
    x_7_5     stock_ub_243  5
    x_7_5     parent_nonstrict_scope_244  1.3032953224741262e-02
    x_7_5     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_165  1
    w_7_5     product_ub_166  1
    w_7_5     normalized_mass_7_188  1
    w_7_5     normalized_ratio_7_189  -7.1428571428571419e-01
    w_7_5     full_original_Gini_302  -6.3964285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -1.9549429837111883e-02
    x_7_6     product_lb_167  -2.5358490566012373e-02
    x_7_6     product_ub_168  -4.2999744049185572e-02
    x_7_6     onehot_7_187  1
    x_7_6     stock_lb_242  6
    x_7_6     stock_ub_243  6
    x_7_6     parent_nonstrict_scope_244  6.5164766123706310e-03
    x_7_6     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_167  1
    w_7_6     product_ub_168  1
    w_7_6     normalized_mass_7_188  1
    w_7_6     normalized_ratio_7_189  -8.5714285714285710e-01
    w_7_6     full_original_Gini_302  -4.8869047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -2.6065906449482514e-02
    x_7_7     product_lb_169  -2.5358490566012373e-02
    x_7_7     product_ub_170  -4.2999744049185572e-02
    x_7_7     onehot_7_187  1
    x_7_7     stock_lb_242  7
    x_7_7     stock_ub_243  7
    x_7_7     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_169  1
    w_7_7     product_ub_170  1
    w_7_7     normalized_mass_7_188  1
    w_7_7     normalized_ratio_7_189  -1
    w_7_7     full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -1.9549429837111887e-02
    x_7_8     product_lb_171  -2.5358490566012373e-02
    x_7_8     product_ub_172  -4.2999744049185572e-02
    x_7_8     onehot_7_187  1
    x_7_8     stock_lb_242  8
    x_7_8     stock_ub_243  8
    x_7_8     parent_nonstrict_scope_244  6.5164766123706258e-03
    x_7_8     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_171  1
    w_7_8     product_ub_172  1
    w_7_8     normalized_mass_7_188  1
    w_7_8     normalized_ratio_7_189  -1.1428571428571428e+00
    w_7_8     full_original_Gini_302  -8.3154761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -1.3032953224741262e-02
    x_7_9     product_lb_173  -2.5358490566012373e-02
    x_7_9     product_ub_174  -4.2999744049185572e-02
    x_7_9     onehot_7_187  1
    x_7_9     stock_lb_242  9
    x_7_9     stock_ub_243  9
    x_7_9     parent_nonstrict_scope_244  1.3032953224741252e-02
    x_7_9     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_173  1
    w_7_9     product_ub_174  1
    w_7_9     normalized_mass_7_188  1
    w_7_9     normalized_ratio_7_189  -1.2857142857142856e+00
    w_7_9     full_original_Gini_302  -1.1886904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -6.5164766123706371e-03
    x_7_10    product_lb_175  -2.5358490566012373e-02
    x_7_10    product_ub_176  -4.2999744049185572e-02
    x_7_10    onehot_7_187  1
    x_7_10    stock_lb_242  10
    x_7_10    stock_ub_243  10
    x_7_10    parent_nonstrict_scope_244  1.9549429837111876e-02
    x_7_10    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_175  1
    w_7_10    product_ub_176  1
    w_7_10    normalized_mass_7_188  1
    w_7_10    normalized_ratio_7_189  -1.4285714285714284e+00
    w_7_10    full_original_Gini_302  -1.5458333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    product_lb_177  -2.5358490566012373e-02
    x_7_11    product_ub_178  -4.2999744049185572e-02
    x_7_11    onehot_7_187  1
    x_7_11    stock_lb_242  11
    x_7_11    stock_ub_243  11
    x_7_11    parent_nonstrict_scope_244  2.6065906449482514e-02
    x_7_11    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_177  1
    w_7_11    product_ub_178  1
    w_7_11    normalized_mass_7_188  1
    w_7_11    normalized_ratio_7_189  -1.5714285714285714e+00
    w_7_11    full_original_Gini_302  -1.9172619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       6.5164766123706266e-03
    x_7_12    product_lb_179  -2.5358490566012373e-02
    x_7_12    product_ub_180  -4.2999744049185572e-02
    x_7_12    onehot_7_187  1
    x_7_12    stock_lb_242  12
    x_7_12    stock_ub_243  12
    x_7_12    parent_nonstrict_scope_244  3.2582383061853140e-02
    x_7_12    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_179  1
    w_7_12    product_ub_180  1
    w_7_12    normalized_mass_7_188  1
    w_7_12    normalized_ratio_7_189  -1.7142857142857142e+00
    w_7_12    full_original_Gini_302  -23.0297619047619
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       1.3032953224741253e-02
    x_7_13    product_lb_181  -2.5358490566012373e-02
    x_7_13    product_ub_182  -4.2999744049185572e-02
    x_7_13    onehot_7_187  1
    x_7_13    stock_lb_242  13
    x_7_13    stock_ub_243  13
    x_7_13    parent_nonstrict_scope_244  3.9098859674223767e-02
    x_7_13    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_181  1
    w_7_13    product_ub_182  1
    w_7_13    normalized_mass_7_188  1
    w_7_13    normalized_ratio_7_189  -1.8571428571428570e+00
    w_7_13    full_original_Gini_302  -2.6886904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.9549429837111887e-02
    x_7_14    product_lb_183  -2.5358490566012373e-02
    x_7_14    product_ub_184  -4.2999744049185572e-02
    x_7_14    onehot_7_187  1
    x_7_14    stock_lb_242  14
    x_7_14    stock_ub_243  14
    x_7_14    parent_nonstrict_scope_244  0.0456153362865944
    x_7_14    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_183  1
    w_7_14    product_ub_184  1
    w_7_14    normalized_mass_7_188  1
    w_7_14    normalized_ratio_7_189  -2
    w_7_14    full_original_Gini_302  -3.0744047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       2.6065906449482514e-02
    x_7_15    product_lb_185  -2.5358490566012373e-02
    x_7_15    product_ub_186  -4.2999744049185572e-02
    x_7_15    onehot_7_187  1
    x_7_15    stock_lb_242  15
    x_7_15    stock_ub_243  15
    x_7_15    parent_nonstrict_scope_244  5.2131812898965027e-02
    x_7_15    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_185  1
    w_7_15    product_ub_186  1
    w_7_15    normalized_mass_7_188  1
    w_7_15    normalized_ratio_7_189  -2.1428571428571428e+00
    w_7_15    full_original_Gini_302  -3.4601190476190482e+01
    rho_7     normalized_ratio_7_189  1
    rho_7     block_pair_pos_245  -1
    rho_7     block_pair_neg_246  1
    rho_7     block_pair_pos_247  -1
    rho_7     block_pair_neg_248  1
    rho_7     block_pair_pos_251  1
    rho_7     block_pair_neg_252  -1
    rho_7     block_pair_pos_263  1
    rho_7     block_pair_neg_264  -1
    rho_7     block_pair_pos_277  1
    rho_7     block_pair_neg_278  -1
    rho_7     block_pair_pos_285  1
    rho_7     block_pair_neg_286  -1
    rho_7     block_pair_pos_293  1
    rho_7     block_pair_neg_294  -1
    rho_7     normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_190  -2.5358490566012373e-02
    x_27_0    product_ub_191  -4.2999744049185572e-02
    x_27_0    onehot_27_204  1
    x_27_0    parent_nonstrict_scope_244  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_190  1
    w_27_0    product_ub_191  1
    w_27_0    normalized_mass_27_205  1
    w_27_0    full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_192  -2.5358490566012373e-02
    x_27_1    product_ub_193  -4.2999744049185572e-02
    x_27_1    onehot_27_204  1
    x_27_1    stock_lb_242  1
    x_27_1    stock_ub_243  1
    x_27_1    parent_nonstrict_scope_244  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_192  1
    w_27_1    product_ub_193  1
    w_27_1    normalized_mass_27_205  1
    w_27_1    normalized_ratio_27_206  -3.3333333333333331e-01
    w_27_1    full_original_Gini_302  -1.4922619047619044e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_194  -2.5358490566012373e-02
    x_27_2    product_ub_195  -4.2999744049185572e-02
    x_27_2    onehot_27_204  1
    x_27_2    stock_lb_242  2
    x_27_2    stock_ub_243  2
    x_27_2    parent_nonstrict_scope_244  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_194  1
    w_27_2    product_ub_195  1
    w_27_2    normalized_mass_27_205  1
    w_27_2    normalized_ratio_27_206  -6.6666666666666663e-01
    w_27_2    full_original_Gini_302  -7.20595238095238
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_196  -2.5358490566012373e-02
    x_27_3    product_ub_197  -4.2999744049185572e-02
    x_27_3    onehot_27_204  1
    x_27_3    stock_lb_242  3
    x_27_3    stock_ub_243  3
    x_27_3    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_196  1
    w_27_3    product_ub_197  1
    w_27_3    normalized_mass_27_205  1
    w_27_3    normalized_ratio_27_206  -1
    w_27_3    full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_198  -2.5358490566012373e-02
    x_27_4    product_ub_199  -4.2999744049185572e-02
    x_27_4    onehot_27_204  1
    x_27_4    stock_lb_242  4
    x_27_4    stock_ub_243  4
    x_27_4    parent_nonstrict_scope_244  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_198  1
    w_27_4    product_ub_199  1
    w_27_4    normalized_mass_27_205  1
    w_27_4    normalized_ratio_27_206  -1.3333333333333333e+00
    w_27_4    full_original_Gini_302  -1.3077380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_200  -2.5358490566012373e-02
    x_27_5    product_ub_201  -4.2999744049185572e-02
    x_27_5    onehot_27_204  1
    x_27_5    stock_lb_242  5
    x_27_5    stock_ub_243  5
    x_27_5    parent_nonstrict_scope_244  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_200  1
    w_27_5    product_ub_201  1
    w_27_5    normalized_mass_27_205  1
    w_27_5    normalized_ratio_27_206  -1.6666666666666665e+00
    w_27_5    full_original_Gini_302  -2.1744047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_202  -2.5358490566012373e-02
    x_27_6    product_ub_203  -4.2999744049185572e-02
    x_27_6    onehot_27_204  1
    x_27_6    stock_lb_242  6
    x_27_6    stock_ub_243  6
    x_27_6    parent_nonstrict_scope_244  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_202  1
    w_27_6    product_ub_203  1
    w_27_6    normalized_mass_27_205  1
    w_27_6    normalized_ratio_27_206  -2
    w_27_6    full_original_Gini_302  -3.0744047619047617e+01
    rho_27    normalized_ratio_27_206  1
    rho_27    block_pair_pos_247  1
    rho_27    block_pair_neg_248  -1
    rho_27    block_pair_pos_257  1
    rho_27    block_pair_neg_258  -1
    rho_27    block_pair_pos_271  1
    rho_27    block_pair_neg_272  -1
    rho_27    block_pair_pos_281  1
    rho_27    block_pair_neg_282  -1
    rho_27    block_pair_pos_287  1
    rho_27    block_pair_neg_288  -1
    rho_27    block_pair_pos_289  -1
    rho_27    block_pair_neg_290  1
    rho_27    block_pair_pos_299  1
    rho_27    block_pair_neg_300  -1
    rho_27    normalization_301  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       1.9549429837111887e-02
    x_5_0     product_lb_207  -2.5358490566012373e-02
    x_5_0     product_ub_208  -4.2999744049185572e-02
    x_5_0     onehot_5_239  1
    x_5_0     parent_nonstrict_scope_244  0.0456153362865944
    x_5_0     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_207  1
    w_5_0     product_ub_208  1
    w_5_0     normalized_mass_5_240  1
    w_5_0     full_original_Gini_302  -2.3255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       1.3032953224741260e-02
    x_5_1     product_lb_209  -2.5358490566012373e-02
    x_5_1     product_ub_210  -4.2999744049185572e-02
    x_5_1     onehot_5_239  1
    x_5_1     stock_lb_242  1
    x_5_1     stock_ub_243  1
    x_5_1     parent_nonstrict_scope_244  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_209  1
    w_5_1     product_ub_210  1
    w_5_1     normalized_mass_5_240  1
    w_5_1     normalized_ratio_5_241  -1.4285714285714285e-01
    w_5_1     full_original_Gini_302  -1.9684523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.5164766123706336e-03
    x_5_2     product_lb_211  -2.5358490566012373e-02
    x_5_2     product_ub_212  -4.2999744049185572e-02
    x_5_2     onehot_5_239  1
    x_5_2     stock_lb_242  2
    x_5_2     stock_ub_243  2
    x_5_2     parent_nonstrict_scope_244  3.2582383061853147e-02
    x_5_2     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_211  1
    w_5_2     product_ub_212  1
    w_5_2     normalized_mass_5_240  1
    w_5_2     normalized_ratio_5_241  -2.8571428571428570e-01
    w_5_2     full_original_Gini_302  -1.6113095238095234e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     product_lb_213  -2.5358490566012373e-02
    x_5_3     product_ub_214  -4.2999744049185572e-02
    x_5_3     onehot_5_239  1
    x_5_3     stock_lb_242  3
    x_5_3     stock_ub_243  3
    x_5_3     parent_nonstrict_scope_244  2.6065906449482514e-02
    x_5_3     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_213  1
    w_5_3     product_ub_214  1
    w_5_3     normalized_mass_5_240  1
    w_5_3     normalized_ratio_5_241  -4.2857142857142855e-01
    w_5_3     full_original_Gini_302  -1.2598809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     OBJ       -6.5164766123706266e-03
    x_5_4     product_lb_215  -2.5358490566012373e-02
    x_5_4     product_ub_216  -4.2999744049185572e-02
    x_5_4     onehot_5_239  1
    x_5_4     stock_lb_242  4
    x_5_4     stock_ub_243  4
    x_5_4     parent_nonstrict_scope_244  1.9549429837111887e-02
    x_5_4     unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_215  1
    w_5_4     product_ub_216  1
    w_5_4     normalized_mass_5_240  1
    w_5_4     normalized_ratio_5_241  -5.7142857142857140e-01
    w_5_4     full_original_Gini_302  -9.31309523809524
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.3032953224741252e-02
    x_5_5     product_lb_217  -2.5358490566012373e-02
    x_5_5     product_ub_218  -4.2999744049185572e-02
    x_5_5     onehot_5_239  1
    x_5_5     stock_lb_242  5
    x_5_5     stock_ub_243  5
    x_5_5     parent_nonstrict_scope_244  1.3032953224741262e-02
    x_5_5     unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_217  1
    w_5_5     product_ub_218  1
    w_5_5     normalized_mass_5_240  1
    w_5_5     normalized_ratio_5_241  -7.1428571428571419e-01
    w_5_5     full_original_Gini_302  -6.3964285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -1.9549429837111883e-02
    x_5_6     product_lb_219  -2.5358490566012373e-02
    x_5_6     product_ub_220  -4.2999744049185572e-02
    x_5_6     onehot_5_239  1
    x_5_6     stock_lb_242  6
    x_5_6     stock_ub_243  6
    x_5_6     parent_nonstrict_scope_244  6.5164766123706310e-03
    x_5_6     unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_219  1
    w_5_6     product_ub_220  1
    w_5_6     normalized_mass_5_240  1
    w_5_6     normalized_ratio_5_241  -8.5714285714285710e-01
    w_5_6     full_original_Gini_302  -4.8869047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -2.6065906449482514e-02
    x_5_7     product_lb_221  -2.5358490566012373e-02
    x_5_7     product_ub_222  -4.2999744049185572e-02
    x_5_7     onehot_5_239  1
    x_5_7     stock_lb_242  7
    x_5_7     stock_ub_243  7
    x_5_7     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_221  1
    w_5_7     product_ub_222  1
    w_5_7     normalized_mass_5_240  1
    w_5_7     normalized_ratio_5_241  -1
    w_5_7     full_original_Gini_302  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -1.9549429837111887e-02
    x_5_8     product_lb_223  -2.5358490566012373e-02
    x_5_8     product_ub_224  -4.2999744049185572e-02
    x_5_8     onehot_5_239  1
    x_5_8     stock_lb_242  8
    x_5_8     stock_ub_243  8
    x_5_8     parent_nonstrict_scope_244  6.5164766123706258e-03
    x_5_8     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_223  1
    w_5_8     product_ub_224  1
    w_5_8     normalized_mass_5_240  1
    w_5_8     normalized_ratio_5_241  -1.1428571428571428e+00
    w_5_8     full_original_Gini_302  -8.3154761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -1.3032953224741262e-02
    x_5_9     product_lb_225  -2.5358490566012373e-02
    x_5_9     product_ub_226  -4.2999744049185572e-02
    x_5_9     onehot_5_239  1
    x_5_9     stock_lb_242  9
    x_5_9     stock_ub_243  9
    x_5_9     parent_nonstrict_scope_244  1.3032953224741252e-02
    x_5_9     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_225  1
    w_5_9     product_ub_226  1
    w_5_9     normalized_mass_5_240  1
    w_5_9     normalized_ratio_5_241  -1.2857142857142856e+00
    w_5_9     full_original_Gini_302  -1.1886904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -6.5164766123706371e-03
    x_5_10    product_lb_227  -2.5358490566012373e-02
    x_5_10    product_ub_228  -4.2999744049185572e-02
    x_5_10    onehot_5_239  1
    x_5_10    stock_lb_242  10
    x_5_10    stock_ub_243  10
    x_5_10    parent_nonstrict_scope_244  1.9549429837111876e-02
    x_5_10    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_227  1
    w_5_10    product_ub_228  1
    w_5_10    normalized_mass_5_240  1
    w_5_10    normalized_ratio_5_241  -1.4285714285714284e+00
    w_5_10    full_original_Gini_302  -1.5458333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_11    product_lb_229  -2.5358490566012373e-02
    x_5_11    product_ub_230  -4.2999744049185572e-02
    x_5_11    onehot_5_239  1
    x_5_11    stock_lb_242  11
    x_5_11    stock_ub_243  11
    x_5_11    parent_nonstrict_scope_244  2.6065906449482514e-02
    x_5_11    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_229  1
    w_5_11    product_ub_230  1
    w_5_11    normalized_mass_5_240  1
    w_5_11    normalized_ratio_5_241  -1.5714285714285714e+00
    w_5_11    full_original_Gini_302  -1.9172619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    OBJ       6.5164766123706266e-03
    x_5_12    product_lb_231  -2.5358490566012373e-02
    x_5_12    product_ub_232  -4.2999744049185572e-02
    x_5_12    onehot_5_239  1
    x_5_12    stock_lb_242  12
    x_5_12    stock_ub_243  12
    x_5_12    parent_nonstrict_scope_244  3.2582383061853140e-02
    x_5_12    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_231  1
    w_5_12    product_ub_232  1
    w_5_12    normalized_mass_5_240  1
    w_5_12    normalized_ratio_5_241  -1.7142857142857142e+00
    w_5_12    full_original_Gini_302  -23.0297619047619
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.3032953224741253e-02
    x_5_13    product_lb_233  -2.5358490566012373e-02
    x_5_13    product_ub_234  -4.2999744049185572e-02
    x_5_13    onehot_5_239  1
    x_5_13    stock_lb_242  13
    x_5_13    stock_ub_243  13
    x_5_13    parent_nonstrict_scope_244  3.9098859674223767e-02
    x_5_13    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_233  1
    w_5_13    product_ub_234  1
    w_5_13    normalized_mass_5_240  1
    w_5_13    normalized_ratio_5_241  -1.8571428571428570e+00
    w_5_13    full_original_Gini_302  -2.6886904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       1.9549429837111887e-02
    x_5_14    product_lb_235  -2.5358490566012373e-02
    x_5_14    product_ub_236  -4.2999744049185572e-02
    x_5_14    onehot_5_239  1
    x_5_14    stock_lb_242  14
    x_5_14    stock_ub_243  14
    x_5_14    parent_nonstrict_scope_244  0.0456153362865944
    x_5_14    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_235  1
    w_5_14    product_ub_236  1
    w_5_14    normalized_mass_5_240  1
    w_5_14    normalized_ratio_5_241  -2
    w_5_14    full_original_Gini_302  -3.0744047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       2.6065906449482514e-02
    x_5_15    product_lb_237  -2.5358490566012373e-02
    x_5_15    product_ub_238  -4.2999744049185572e-02
    x_5_15    onehot_5_239  1
    x_5_15    stock_lb_242  15
    x_5_15    stock_ub_243  15
    x_5_15    parent_nonstrict_scope_244  5.2131812898965027e-02
    x_5_15    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_237  1
    w_5_15    product_ub_238  1
    w_5_15    normalized_mass_5_240  1
    w_5_15    normalized_ratio_5_241  -2.1428571428571428e+00
    w_5_15    full_original_Gini_302  -3.4601190476190482e+01
    rho_5     normalized_ratio_5_241  1
    rho_5     block_pair_pos_245  1
    rho_5     block_pair_neg_246  -1
    rho_5     block_pair_pos_249  1
    rho_5     block_pair_neg_250  -1
    rho_5     block_pair_pos_261  1
    rho_5     block_pair_neg_262  -1
    rho_5     block_pair_pos_275  1
    rho_5     block_pair_neg_276  -1
    rho_5     block_pair_pos_283  1
    rho_5     block_pair_neg_284  -1
    rho_5     block_pair_pos_289  1
    rho_5     block_pair_neg_290  -1
    rho_5     block_pair_pos_291  1
    rho_5     block_pair_neg_292  -1
    rho_5     normalization_301  1
    a_14_12   block_pair_pos_265  1
    a_14_12   block_pair_neg_266  1
    a_14_12   full_original_Gini_302  -1
    a_14_34   block_pair_pos_273  1
    a_14_34   block_pair_neg_274  1
    a_14_34   full_original_Gini_302  -1
    a_14_16   block_pair_pos_267  1
    a_14_16   block_pair_neg_268  1
    a_14_16   full_original_Gini_302  -1
    a_14_22   block_pair_pos_269  1
    a_14_22   block_pair_neg_270  1
    a_14_22   full_original_Gini_302  -1
    a_14_7    block_pair_pos_263  1
    a_14_7    block_pair_neg_264  1
    a_14_7    full_original_Gini_302  -1
    a_14_27   block_pair_pos_271  1
    a_14_27   block_pair_neg_272  1
    a_14_27   full_original_Gini_302  -1
    a_14_5    block_pair_pos_261  1
    a_14_5    block_pair_neg_262  1
    a_14_5    full_original_Gini_302  -1
    a_12_34   block_pair_pos_259  1
    a_12_34   block_pair_neg_260  1
    a_12_34   full_original_Gini_302  -1
    a_12_16   block_pair_pos_253  1
    a_12_16   block_pair_neg_254  1
    a_12_16   full_original_Gini_302  -1
    a_12_22   block_pair_pos_255  1
    a_12_22   block_pair_neg_256  1
    a_12_22   full_original_Gini_302  -1
    a_12_7    block_pair_pos_251  1
    a_12_7    block_pair_neg_252  1
    a_12_7    full_original_Gini_302  -1
    a_12_27   block_pair_pos_257  1
    a_12_27   block_pair_neg_258  1
    a_12_27   full_original_Gini_302  -1
    a_12_5    block_pair_pos_249  1
    a_12_5    block_pair_neg_250  1
    a_12_5    full_original_Gini_302  -1
    a_34_16   block_pair_pos_295  1
    a_34_16   block_pair_neg_296  1
    a_34_16   full_original_Gini_302  -1
    a_34_22   block_pair_pos_297  1
    a_34_22   block_pair_neg_298  1
    a_34_22   full_original_Gini_302  -1
    a_34_7    block_pair_pos_293  1
    a_34_7    block_pair_neg_294  1
    a_34_7    full_original_Gini_302  -1
    a_34_27   block_pair_pos_299  1
    a_34_27   block_pair_neg_300  1
    a_34_27   full_original_Gini_302  -1
    a_34_5    block_pair_pos_291  1
    a_34_5    block_pair_neg_292  1
    a_34_5    full_original_Gini_302  -1
    a_16_22   block_pair_pos_279  1
    a_16_22   block_pair_neg_280  1
    a_16_22   full_original_Gini_302  -1
    a_16_7    block_pair_pos_277  1
    a_16_7    block_pair_neg_278  1
    a_16_7    full_original_Gini_302  -1
    a_16_27   block_pair_pos_281  1
    a_16_27   block_pair_neg_282  1
    a_16_27   full_original_Gini_302  -1
    a_16_5    block_pair_pos_275  1
    a_16_5    block_pair_neg_276  1
    a_16_5    full_original_Gini_302  -1
    a_22_7    block_pair_pos_285  1
    a_22_7    block_pair_neg_286  1
    a_22_7    full_original_Gini_302  -1
    a_22_27   block_pair_pos_287  1
    a_22_27   block_pair_neg_288  1
    a_22_27   full_original_Gini_302  -1
    a_22_5    block_pair_pos_283  1
    a_22_5    block_pair_neg_284  1
    a_22_5    full_original_Gini_302  -1
    a_7_27    block_pair_pos_247  1
    a_7_27    block_pair_neg_248  1
    a_7_27    full_original_Gini_302  -1
    a_7_5     block_pair_pos_245  1
    a_7_5     block_pair_neg_246  1
    a_7_5     full_original_Gini_302  -1
    a_27_5    block_pair_pos_289  1
    a_27_5    block_pair_neg_290  1
    a_27_5    full_original_Gini_302  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_14_0  unique_nonzero_owner_303  1
    service_0_14_0  service_visit_def_845  1
    service_0_14_0  free_load_conservation_846  -2
    service_0_14_0  original_T_including_depot_unload_894  240
    service_0_14_1  unique_nonzero_owner_304  1
    service_0_14_1  service_visit_def_845  1
    service_0_14_1  free_load_conservation_846  -1
    service_0_14_1  original_T_including_depot_unload_894  120
    service_0_14_3  unique_nonzero_owner_305  1
    service_0_14_3  service_visit_def_845  1
    service_0_14_3  free_load_conservation_846  1
    service_0_14_4  unique_nonzero_owner_306  1
    service_0_14_4  service_visit_def_845  1
    service_0_14_4  free_load_conservation_846  2
    service_0_14_5  unique_nonzero_owner_307  1
    service_0_14_5  service_visit_def_845  1
    service_0_14_5  free_load_conservation_846  3
    service_0_14_6  unique_nonzero_owner_308  1
    service_0_14_6  service_visit_def_845  1
    service_0_14_6  free_load_conservation_846  4
    service_0_14_7  unique_nonzero_owner_309  1
    service_0_14_7  service_visit_def_845  1
    service_0_14_7  free_load_conservation_846  5
    service_0_14_8  unique_nonzero_owner_310  1
    service_0_14_8  service_visit_def_845  1
    service_0_14_8  free_load_conservation_846  6
    service_1_14_0  unique_nonzero_owner_303  1
    service_1_14_0  service_visit_def_1116  1
    service_1_14_0  free_load_conservation_1117  -2
    service_1_14_0  original_T_including_depot_unload_1161  240
    service_1_14_1  unique_nonzero_owner_304  1
    service_1_14_1  service_visit_def_1116  1
    service_1_14_1  free_load_conservation_1117  -1
    service_1_14_1  original_T_including_depot_unload_1161  120
    service_1_14_3  unique_nonzero_owner_305  1
    service_1_14_3  service_visit_def_1116  1
    service_1_14_3  free_load_conservation_1117  1
    service_1_14_4  unique_nonzero_owner_306  1
    service_1_14_4  service_visit_def_1116  1
    service_1_14_4  free_load_conservation_1117  2
    service_1_14_5  unique_nonzero_owner_307  1
    service_1_14_5  service_visit_def_1116  1
    service_1_14_5  free_load_conservation_1117  3
    service_1_14_6  unique_nonzero_owner_308  1
    service_1_14_6  service_visit_def_1116  1
    service_1_14_6  free_load_conservation_1117  4
    service_1_14_7  unique_nonzero_owner_309  1
    service_1_14_7  service_visit_def_1116  1
    service_1_14_7  free_load_conservation_1117  5
    service_1_14_8  unique_nonzero_owner_310  1
    service_1_14_8  service_visit_def_1116  1
    service_1_14_8  free_load_conservation_1117  6
    service_2_14_0  unique_nonzero_owner_303  1
    service_2_14_0  service_visit_def_1542  1
    service_2_14_0  free_load_conservation_1543  -2
    service_2_14_0  original_T_including_depot_unload_1590  240
    service_2_14_1  unique_nonzero_owner_304  1
    service_2_14_1  service_visit_def_1542  1
    service_2_14_1  free_load_conservation_1543  -1
    service_2_14_1  original_T_including_depot_unload_1590  120
    service_2_14_3  unique_nonzero_owner_305  1
    service_2_14_3  service_visit_def_1542  1
    service_2_14_3  free_load_conservation_1543  1
    service_2_14_4  unique_nonzero_owner_306  1
    service_2_14_4  service_visit_def_1542  1
    service_2_14_4  free_load_conservation_1543  2
    service_2_14_5  unique_nonzero_owner_307  1
    service_2_14_5  service_visit_def_1542  1
    service_2_14_5  free_load_conservation_1543  3
    service_2_14_6  unique_nonzero_owner_308  1
    service_2_14_6  service_visit_def_1542  1
    service_2_14_6  free_load_conservation_1543  4
    service_2_14_7  unique_nonzero_owner_309  1
    service_2_14_7  service_visit_def_1542  1
    service_2_14_7  free_load_conservation_1543  5
    service_2_14_8  unique_nonzero_owner_310  1
    service_2_14_8  service_visit_def_1542  1
    service_2_14_8  free_load_conservation_1543  6
    service_0_12_0  unique_nonzero_owner_311  1
    service_0_12_0  service_visit_def_851  1
    service_0_12_0  free_load_conservation_852  -1
    service_0_12_0  original_T_including_depot_unload_894  120
    service_0_12_2  unique_nonzero_owner_312  1
    service_0_12_2  service_visit_def_851  1
    service_0_12_2  free_load_conservation_852  1
    service_0_12_3  unique_nonzero_owner_313  1
    service_0_12_3  service_visit_def_851  1
    service_0_12_3  free_load_conservation_852  2
    service_0_12_4  unique_nonzero_owner_314  1
    service_0_12_4  service_visit_def_851  1
    service_0_12_4  free_load_conservation_852  3
    service_0_12_5  unique_nonzero_owner_315  1
    service_0_12_5  service_visit_def_851  1
    service_0_12_5  free_load_conservation_852  4
    service_0_12_6  unique_nonzero_owner_316  1
    service_0_12_6  service_visit_def_851  1
    service_0_12_6  free_load_conservation_852  5
    service_0_12_7  unique_nonzero_owner_317  1
    service_0_12_7  service_visit_def_851  1
    service_0_12_7  free_load_conservation_852  6
    service_0_12_8  unique_nonzero_owner_318  1
    service_0_12_8  service_visit_def_851  1
    service_0_12_8  free_load_conservation_852  7
    service_0_12_9  unique_nonzero_owner_319  1
    service_0_12_9  service_visit_def_851  1
    service_0_12_9  free_load_conservation_852  8
    service_0_12_10  unique_nonzero_owner_320  1
    service_0_12_10  service_visit_def_851  1
    service_0_12_10  free_load_conservation_852  9
    service_0_12_11  unique_nonzero_owner_321  1
    service_0_12_11  service_visit_def_851  1
    service_0_12_11  free_load_conservation_852  10
    service_0_12_12  unique_nonzero_owner_322  1
    service_0_12_12  service_visit_def_851  1
    service_0_12_12  free_load_conservation_852  11
    service_1_12_0  unique_nonzero_owner_311  1
    service_1_12_0  service_visit_def_1122  1
    service_1_12_0  free_load_conservation_1123  -1
    service_1_12_0  original_T_including_depot_unload_1161  120
    service_1_12_2  unique_nonzero_owner_312  1
    service_1_12_2  service_visit_def_1122  1
    service_1_12_2  free_load_conservation_1123  1
    service_1_12_3  unique_nonzero_owner_313  1
    service_1_12_3  service_visit_def_1122  1
    service_1_12_3  free_load_conservation_1123  2
    service_1_12_4  unique_nonzero_owner_314  1
    service_1_12_4  service_visit_def_1122  1
    service_1_12_4  free_load_conservation_1123  3
    service_1_12_5  unique_nonzero_owner_315  1
    service_1_12_5  service_visit_def_1122  1
    service_1_12_5  free_load_conservation_1123  4
    service_1_12_6  unique_nonzero_owner_316  1
    service_1_12_6  service_visit_def_1122  1
    service_1_12_6  free_load_conservation_1123  5
    service_1_12_7  unique_nonzero_owner_317  1
    service_1_12_7  service_visit_def_1122  1
    service_1_12_7  free_load_conservation_1123  6
    service_1_12_8  unique_nonzero_owner_318  1
    service_1_12_8  service_visit_def_1122  1
    service_1_12_8  free_load_conservation_1123  7
    service_1_12_9  unique_nonzero_owner_319  1
    service_1_12_9  service_visit_def_1122  1
    service_1_12_9  free_load_conservation_1123  8
    service_1_12_10  unique_nonzero_owner_320  1
    service_1_12_10  service_visit_def_1122  1
    service_1_12_10  free_load_conservation_1123  9
    service_1_12_11  unique_nonzero_owner_321  1
    service_1_12_11  service_visit_def_1122  1
    service_1_12_11  free_load_conservation_1123  10
    service_1_12_12  unique_nonzero_owner_322  1
    service_1_12_12  service_visit_def_1122  1
    service_1_12_12  free_load_conservation_1123  11
    service_2_12_0  unique_nonzero_owner_311  1
    service_2_12_0  service_visit_def_1548  1
    service_2_12_0  free_load_conservation_1549  -1
    service_2_12_0  original_T_including_depot_unload_1590  120
    service_2_12_2  unique_nonzero_owner_312  1
    service_2_12_2  service_visit_def_1548  1
    service_2_12_2  free_load_conservation_1549  1
    service_2_12_3  unique_nonzero_owner_313  1
    service_2_12_3  service_visit_def_1548  1
    service_2_12_3  free_load_conservation_1549  2
    service_2_12_4  unique_nonzero_owner_314  1
    service_2_12_4  service_visit_def_1548  1
    service_2_12_4  free_load_conservation_1549  3
    service_2_12_5  unique_nonzero_owner_315  1
    service_2_12_5  service_visit_def_1548  1
    service_2_12_5  free_load_conservation_1549  4
    service_2_12_6  unique_nonzero_owner_316  1
    service_2_12_6  service_visit_def_1548  1
    service_2_12_6  free_load_conservation_1549  5
    service_2_12_7  unique_nonzero_owner_317  1
    service_2_12_7  service_visit_def_1548  1
    service_2_12_7  free_load_conservation_1549  6
    service_2_12_8  unique_nonzero_owner_318  1
    service_2_12_8  service_visit_def_1548  1
    service_2_12_8  free_load_conservation_1549  7
    service_2_12_9  unique_nonzero_owner_319  1
    service_2_12_9  service_visit_def_1548  1
    service_2_12_9  free_load_conservation_1549  8
    service_2_12_10  unique_nonzero_owner_320  1
    service_2_12_10  service_visit_def_1548  1
    service_2_12_10  free_load_conservation_1549  9
    service_2_12_11  unique_nonzero_owner_321  1
    service_2_12_11  service_visit_def_1548  1
    service_2_12_11  free_load_conservation_1549  10
    service_2_12_12  unique_nonzero_owner_322  1
    service_2_12_12  service_visit_def_1548  1
    service_2_12_12  free_load_conservation_1549  11
    service_0_34_0  unique_nonzero_owner_323  1
    service_0_34_0  service_visit_def_857  1
    service_0_34_0  free_load_conservation_858  -2
    service_0_34_0  original_T_including_depot_unload_894  240
    service_0_34_1  unique_nonzero_owner_324  1
    service_0_34_1  service_visit_def_857  1
    service_0_34_1  free_load_conservation_858  -1
    service_0_34_1  original_T_including_depot_unload_894  120
    service_0_34_3  unique_nonzero_owner_325  1
    service_0_34_3  service_visit_def_857  1
    service_0_34_3  free_load_conservation_858  1
    service_0_34_4  unique_nonzero_owner_326  1
    service_0_34_4  service_visit_def_857  1
    service_0_34_4  free_load_conservation_858  2
    service_0_34_5  unique_nonzero_owner_327  1
    service_0_34_5  service_visit_def_857  1
    service_0_34_5  free_load_conservation_858  3
    service_0_34_6  unique_nonzero_owner_328  1
    service_0_34_6  service_visit_def_857  1
    service_0_34_6  free_load_conservation_858  4
    service_0_34_7  unique_nonzero_owner_329  1
    service_0_34_7  service_visit_def_857  1
    service_0_34_7  free_load_conservation_858  5
    service_0_34_8  unique_nonzero_owner_330  1
    service_0_34_8  service_visit_def_857  1
    service_0_34_8  free_load_conservation_858  6
    service_0_34_9  unique_nonzero_owner_331  1
    service_0_34_9  service_visit_def_857  1
    service_0_34_9  free_load_conservation_858  7
    service_0_34_10  unique_nonzero_owner_332  1
    service_0_34_10  service_visit_def_857  1
    service_0_34_10  free_load_conservation_858  8
    service_0_34_11  unique_nonzero_owner_333  1
    service_0_34_11  service_visit_def_857  1
    service_0_34_11  free_load_conservation_858  9
    service_0_34_12  unique_nonzero_owner_334  1
    service_0_34_12  service_visit_def_857  1
    service_0_34_12  free_load_conservation_858  10
    service_0_34_13  unique_nonzero_owner_335  1
    service_0_34_13  service_visit_def_857  1
    service_0_34_13  free_load_conservation_858  11
    service_0_34_14  unique_nonzero_owner_336  1
    service_0_34_14  service_visit_def_857  1
    service_0_34_14  free_load_conservation_858  12
    service_0_34_15  unique_nonzero_owner_337  1
    service_0_34_15  service_visit_def_857  1
    service_0_34_15  free_load_conservation_858  13
    service_1_34_0  unique_nonzero_owner_323  1
    service_1_34_0  service_visit_def_1128  1
    service_1_34_0  free_load_conservation_1129  -2
    service_1_34_0  original_T_including_depot_unload_1161  240
    service_1_34_1  unique_nonzero_owner_324  1
    service_1_34_1  service_visit_def_1128  1
    service_1_34_1  free_load_conservation_1129  -1
    service_1_34_1  original_T_including_depot_unload_1161  120
    service_1_34_3  unique_nonzero_owner_325  1
    service_1_34_3  service_visit_def_1128  1
    service_1_34_3  free_load_conservation_1129  1
    service_1_34_4  unique_nonzero_owner_326  1
    service_1_34_4  service_visit_def_1128  1
    service_1_34_4  free_load_conservation_1129  2
    service_1_34_5  unique_nonzero_owner_327  1
    service_1_34_5  service_visit_def_1128  1
    service_1_34_5  free_load_conservation_1129  3
    service_1_34_6  unique_nonzero_owner_328  1
    service_1_34_6  service_visit_def_1128  1
    service_1_34_6  free_load_conservation_1129  4
    service_1_34_7  unique_nonzero_owner_329  1
    service_1_34_7  service_visit_def_1128  1
    service_1_34_7  free_load_conservation_1129  5
    service_1_34_8  unique_nonzero_owner_330  1
    service_1_34_8  service_visit_def_1128  1
    service_1_34_8  free_load_conservation_1129  6
    service_1_34_9  unique_nonzero_owner_331  1
    service_1_34_9  service_visit_def_1128  1
    service_1_34_9  free_load_conservation_1129  7
    service_1_34_10  unique_nonzero_owner_332  1
    service_1_34_10  service_visit_def_1128  1
    service_1_34_10  free_load_conservation_1129  8
    service_1_34_11  unique_nonzero_owner_333  1
    service_1_34_11  service_visit_def_1128  1
    service_1_34_11  free_load_conservation_1129  9
    service_1_34_12  unique_nonzero_owner_334  1
    service_1_34_12  service_visit_def_1128  1
    service_1_34_12  free_load_conservation_1129  10
    service_1_34_13  unique_nonzero_owner_335  1
    service_1_34_13  service_visit_def_1128  1
    service_1_34_13  free_load_conservation_1129  11
    service_1_34_14  unique_nonzero_owner_336  1
    service_1_34_14  service_visit_def_1128  1
    service_1_34_14  free_load_conservation_1129  12
    service_1_34_15  unique_nonzero_owner_337  1
    service_1_34_15  service_visit_def_1128  1
    service_1_34_15  free_load_conservation_1129  13
    service_2_34_0  unique_nonzero_owner_323  1
    service_2_34_0  service_visit_def_1554  1
    service_2_34_0  free_load_conservation_1555  -2
    service_2_34_0  original_T_including_depot_unload_1590  240
    service_2_34_1  unique_nonzero_owner_324  1
    service_2_34_1  service_visit_def_1554  1
    service_2_34_1  free_load_conservation_1555  -1
    service_2_34_1  original_T_including_depot_unload_1590  120
    service_2_34_3  unique_nonzero_owner_325  1
    service_2_34_3  service_visit_def_1554  1
    service_2_34_3  free_load_conservation_1555  1
    service_2_34_4  unique_nonzero_owner_326  1
    service_2_34_4  service_visit_def_1554  1
    service_2_34_4  free_load_conservation_1555  2
    service_2_34_5  unique_nonzero_owner_327  1
    service_2_34_5  service_visit_def_1554  1
    service_2_34_5  free_load_conservation_1555  3
    service_2_34_6  unique_nonzero_owner_328  1
    service_2_34_6  service_visit_def_1554  1
    service_2_34_6  free_load_conservation_1555  4
    service_2_34_7  unique_nonzero_owner_329  1
    service_2_34_7  service_visit_def_1554  1
    service_2_34_7  free_load_conservation_1555  5
    service_2_34_8  unique_nonzero_owner_330  1
    service_2_34_8  service_visit_def_1554  1
    service_2_34_8  free_load_conservation_1555  6
    service_2_34_9  unique_nonzero_owner_331  1
    service_2_34_9  service_visit_def_1554  1
    service_2_34_9  free_load_conservation_1555  7
    service_2_34_10  unique_nonzero_owner_332  1
    service_2_34_10  service_visit_def_1554  1
    service_2_34_10  free_load_conservation_1555  8
    service_2_34_11  unique_nonzero_owner_333  1
    service_2_34_11  service_visit_def_1554  1
    service_2_34_11  free_load_conservation_1555  9
    service_2_34_12  unique_nonzero_owner_334  1
    service_2_34_12  service_visit_def_1554  1
    service_2_34_12  free_load_conservation_1555  10
    service_2_34_13  unique_nonzero_owner_335  1
    service_2_34_13  service_visit_def_1554  1
    service_2_34_13  free_load_conservation_1555  11
    service_2_34_14  unique_nonzero_owner_336  1
    service_2_34_14  service_visit_def_1554  1
    service_2_34_14  free_load_conservation_1555  12
    service_2_34_15  unique_nonzero_owner_337  1
    service_2_34_15  service_visit_def_1554  1
    service_2_34_15  free_load_conservation_1555  13
    service_0_16_0  unique_nonzero_owner_338  1
    service_0_16_0  service_visit_def_863  1
    service_0_16_0  free_load_conservation_864  -2
    service_0_16_0  original_T_including_depot_unload_894  240
    service_0_16_1  unique_nonzero_owner_339  1
    service_0_16_1  service_visit_def_863  1
    service_0_16_1  free_load_conservation_864  -1
    service_0_16_1  original_T_including_depot_unload_894  120
    service_0_16_3  unique_nonzero_owner_340  1
    service_0_16_3  service_visit_def_863  1
    service_0_16_3  free_load_conservation_864  1
    service_0_16_4  unique_nonzero_owner_341  1
    service_0_16_4  service_visit_def_863  1
    service_0_16_4  free_load_conservation_864  2
    service_0_16_5  unique_nonzero_owner_342  1
    service_0_16_5  service_visit_def_863  1
    service_0_16_5  free_load_conservation_864  3
    service_0_16_6  unique_nonzero_owner_343  1
    service_0_16_6  service_visit_def_863  1
    service_0_16_6  free_load_conservation_864  4
    service_0_16_7  unique_nonzero_owner_344  1
    service_0_16_7  service_visit_def_863  1
    service_0_16_7  free_load_conservation_864  5
    service_0_16_8  unique_nonzero_owner_345  1
    service_0_16_8  service_visit_def_863  1
    service_0_16_8  free_load_conservation_864  6
    service_0_16_9  unique_nonzero_owner_346  1
    service_0_16_9  service_visit_def_863  1
    service_0_16_9  free_load_conservation_864  7
    service_0_16_10  unique_nonzero_owner_347  1
    service_0_16_10  service_visit_def_863  1
    service_0_16_10  free_load_conservation_864  8
    service_0_16_11  unique_nonzero_owner_348  1
    service_0_16_11  service_visit_def_863  1
    service_0_16_11  free_load_conservation_864  9
    service_0_16_12  unique_nonzero_owner_349  1
    service_0_16_12  service_visit_def_863  1
    service_0_16_12  free_load_conservation_864  10
    service_0_16_13  unique_nonzero_owner_350  1
    service_0_16_13  service_visit_def_863  1
    service_0_16_13  free_load_conservation_864  11
    service_0_16_14  unique_nonzero_owner_351  1
    service_0_16_14  service_visit_def_863  1
    service_0_16_14  free_load_conservation_864  12
    service_0_16_15  unique_nonzero_owner_352  1
    service_0_16_15  service_visit_def_863  1
    service_0_16_15  free_load_conservation_864  13
    service_1_16_0  unique_nonzero_owner_338  1
    service_1_16_0  service_visit_def_1134  1
    service_1_16_0  free_load_conservation_1135  -2
    service_1_16_0  original_T_including_depot_unload_1161  240
    service_1_16_1  unique_nonzero_owner_339  1
    service_1_16_1  service_visit_def_1134  1
    service_1_16_1  free_load_conservation_1135  -1
    service_1_16_1  original_T_including_depot_unload_1161  120
    service_1_16_3  unique_nonzero_owner_340  1
    service_1_16_3  service_visit_def_1134  1
    service_1_16_3  free_load_conservation_1135  1
    service_1_16_4  unique_nonzero_owner_341  1
    service_1_16_4  service_visit_def_1134  1
    service_1_16_4  free_load_conservation_1135  2
    service_1_16_5  unique_nonzero_owner_342  1
    service_1_16_5  service_visit_def_1134  1
    service_1_16_5  free_load_conservation_1135  3
    service_1_16_6  unique_nonzero_owner_343  1
    service_1_16_6  service_visit_def_1134  1
    service_1_16_6  free_load_conservation_1135  4
    service_1_16_7  unique_nonzero_owner_344  1
    service_1_16_7  service_visit_def_1134  1
    service_1_16_7  free_load_conservation_1135  5
    service_1_16_8  unique_nonzero_owner_345  1
    service_1_16_8  service_visit_def_1134  1
    service_1_16_8  free_load_conservation_1135  6
    service_1_16_9  unique_nonzero_owner_346  1
    service_1_16_9  service_visit_def_1134  1
    service_1_16_9  free_load_conservation_1135  7
    service_1_16_10  unique_nonzero_owner_347  1
    service_1_16_10  service_visit_def_1134  1
    service_1_16_10  free_load_conservation_1135  8
    service_1_16_11  unique_nonzero_owner_348  1
    service_1_16_11  service_visit_def_1134  1
    service_1_16_11  free_load_conservation_1135  9
    service_1_16_12  unique_nonzero_owner_349  1
    service_1_16_12  service_visit_def_1134  1
    service_1_16_12  free_load_conservation_1135  10
    service_1_16_13  unique_nonzero_owner_350  1
    service_1_16_13  service_visit_def_1134  1
    service_1_16_13  free_load_conservation_1135  11
    service_1_16_14  unique_nonzero_owner_351  1
    service_1_16_14  service_visit_def_1134  1
    service_1_16_14  free_load_conservation_1135  12
    service_1_16_15  unique_nonzero_owner_352  1
    service_1_16_15  service_visit_def_1134  1
    service_1_16_15  free_load_conservation_1135  13
    service_2_16_0  unique_nonzero_owner_338  1
    service_2_16_0  service_visit_def_1560  1
    service_2_16_0  free_load_conservation_1561  -2
    service_2_16_0  original_T_including_depot_unload_1590  240
    service_2_16_1  unique_nonzero_owner_339  1
    service_2_16_1  service_visit_def_1560  1
    service_2_16_1  free_load_conservation_1561  -1
    service_2_16_1  original_T_including_depot_unload_1590  120
    service_2_16_3  unique_nonzero_owner_340  1
    service_2_16_3  service_visit_def_1560  1
    service_2_16_3  free_load_conservation_1561  1
    service_2_16_4  unique_nonzero_owner_341  1
    service_2_16_4  service_visit_def_1560  1
    service_2_16_4  free_load_conservation_1561  2
    service_2_16_5  unique_nonzero_owner_342  1
    service_2_16_5  service_visit_def_1560  1
    service_2_16_5  free_load_conservation_1561  3
    service_2_16_6  unique_nonzero_owner_343  1
    service_2_16_6  service_visit_def_1560  1
    service_2_16_6  free_load_conservation_1561  4
    service_2_16_7  unique_nonzero_owner_344  1
    service_2_16_7  service_visit_def_1560  1
    service_2_16_7  free_load_conservation_1561  5
    service_2_16_8  unique_nonzero_owner_345  1
    service_2_16_8  service_visit_def_1560  1
    service_2_16_8  free_load_conservation_1561  6
    service_2_16_9  unique_nonzero_owner_346  1
    service_2_16_9  service_visit_def_1560  1
    service_2_16_9  free_load_conservation_1561  7
    service_2_16_10  unique_nonzero_owner_347  1
    service_2_16_10  service_visit_def_1560  1
    service_2_16_10  free_load_conservation_1561  8
    service_2_16_11  unique_nonzero_owner_348  1
    service_2_16_11  service_visit_def_1560  1
    service_2_16_11  free_load_conservation_1561  9
    service_2_16_12  unique_nonzero_owner_349  1
    service_2_16_12  service_visit_def_1560  1
    service_2_16_12  free_load_conservation_1561  10
    service_2_16_13  unique_nonzero_owner_350  1
    service_2_16_13  service_visit_def_1560  1
    service_2_16_13  free_load_conservation_1561  11
    service_2_16_14  unique_nonzero_owner_351  1
    service_2_16_14  service_visit_def_1560  1
    service_2_16_14  free_load_conservation_1561  12
    service_2_16_15  unique_nonzero_owner_352  1
    service_2_16_15  service_visit_def_1560  1
    service_2_16_15  free_load_conservation_1561  13
    service_0_22_0  unique_nonzero_owner_353  1
    service_0_22_0  service_visit_def_869  1
    service_0_22_0  free_load_conservation_870  -2
    service_0_22_0  original_T_including_depot_unload_894  240
    service_0_22_1  unique_nonzero_owner_354  1
    service_0_22_1  service_visit_def_869  1
    service_0_22_1  free_load_conservation_870  -1
    service_0_22_1  original_T_including_depot_unload_894  120
    service_0_22_3  unique_nonzero_owner_355  1
    service_0_22_3  service_visit_def_869  1
    service_0_22_3  free_load_conservation_870  1
    service_0_22_4  unique_nonzero_owner_356  1
    service_0_22_4  service_visit_def_869  1
    service_0_22_4  free_load_conservation_870  2
    service_0_22_5  unique_nonzero_owner_357  1
    service_0_22_5  service_visit_def_869  1
    service_0_22_5  free_load_conservation_870  3
    service_0_22_6  unique_nonzero_owner_358  1
    service_0_22_6  service_visit_def_869  1
    service_0_22_6  free_load_conservation_870  4
    service_0_22_7  unique_nonzero_owner_359  1
    service_0_22_7  service_visit_def_869  1
    service_0_22_7  free_load_conservation_870  5
    service_0_22_8  unique_nonzero_owner_360  1
    service_0_22_8  service_visit_def_869  1
    service_0_22_8  free_load_conservation_870  6
    service_0_22_9  unique_nonzero_owner_361  1
    service_0_22_9  service_visit_def_869  1
    service_0_22_9  free_load_conservation_870  7
    service_0_22_10  unique_nonzero_owner_362  1
    service_0_22_10  service_visit_def_869  1
    service_0_22_10  free_load_conservation_870  8
    service_0_22_11  unique_nonzero_owner_363  1
    service_0_22_11  service_visit_def_869  1
    service_0_22_11  free_load_conservation_870  9
    service_0_22_12  unique_nonzero_owner_364  1
    service_0_22_12  service_visit_def_869  1
    service_0_22_12  free_load_conservation_870  10
    service_0_22_13  unique_nonzero_owner_365  1
    service_0_22_13  service_visit_def_869  1
    service_0_22_13  free_load_conservation_870  11
    service_0_22_14  unique_nonzero_owner_366  1
    service_0_22_14  service_visit_def_869  1
    service_0_22_14  free_load_conservation_870  12
    service_0_22_15  unique_nonzero_owner_367  1
    service_0_22_15  service_visit_def_869  1
    service_0_22_15  free_load_conservation_870  13
    service_1_22_0  unique_nonzero_owner_353  1
    service_1_22_0  service_visit_def_1140  1
    service_1_22_0  free_load_conservation_1141  -2
    service_1_22_0  original_T_including_depot_unload_1161  240
    service_1_22_1  unique_nonzero_owner_354  1
    service_1_22_1  service_visit_def_1140  1
    service_1_22_1  free_load_conservation_1141  -1
    service_1_22_1  original_T_including_depot_unload_1161  120
    service_1_22_3  unique_nonzero_owner_355  1
    service_1_22_3  service_visit_def_1140  1
    service_1_22_3  free_load_conservation_1141  1
    service_1_22_4  unique_nonzero_owner_356  1
    service_1_22_4  service_visit_def_1140  1
    service_1_22_4  free_load_conservation_1141  2
    service_1_22_5  unique_nonzero_owner_357  1
    service_1_22_5  service_visit_def_1140  1
    service_1_22_5  free_load_conservation_1141  3
    service_1_22_6  unique_nonzero_owner_358  1
    service_1_22_6  service_visit_def_1140  1
    service_1_22_6  free_load_conservation_1141  4
    service_1_22_7  unique_nonzero_owner_359  1
    service_1_22_7  service_visit_def_1140  1
    service_1_22_7  free_load_conservation_1141  5
    service_1_22_8  unique_nonzero_owner_360  1
    service_1_22_8  service_visit_def_1140  1
    service_1_22_8  free_load_conservation_1141  6
    service_1_22_9  unique_nonzero_owner_361  1
    service_1_22_9  service_visit_def_1140  1
    service_1_22_9  free_load_conservation_1141  7
    service_1_22_10  unique_nonzero_owner_362  1
    service_1_22_10  service_visit_def_1140  1
    service_1_22_10  free_load_conservation_1141  8
    service_1_22_11  unique_nonzero_owner_363  1
    service_1_22_11  service_visit_def_1140  1
    service_1_22_11  free_load_conservation_1141  9
    service_1_22_12  unique_nonzero_owner_364  1
    service_1_22_12  service_visit_def_1140  1
    service_1_22_12  free_load_conservation_1141  10
    service_1_22_13  unique_nonzero_owner_365  1
    service_1_22_13  service_visit_def_1140  1
    service_1_22_13  free_load_conservation_1141  11
    service_1_22_14  unique_nonzero_owner_366  1
    service_1_22_14  service_visit_def_1140  1
    service_1_22_14  free_load_conservation_1141  12
    service_1_22_15  unique_nonzero_owner_367  1
    service_1_22_15  service_visit_def_1140  1
    service_1_22_15  free_load_conservation_1141  13
    service_2_22_0  unique_nonzero_owner_353  1
    service_2_22_0  service_visit_def_1566  1
    service_2_22_0  free_load_conservation_1567  -2
    service_2_22_0  original_T_including_depot_unload_1590  240
    service_2_22_1  unique_nonzero_owner_354  1
    service_2_22_1  service_visit_def_1566  1
    service_2_22_1  free_load_conservation_1567  -1
    service_2_22_1  original_T_including_depot_unload_1590  120
    service_2_22_3  unique_nonzero_owner_355  1
    service_2_22_3  service_visit_def_1566  1
    service_2_22_3  free_load_conservation_1567  1
    service_2_22_4  unique_nonzero_owner_356  1
    service_2_22_4  service_visit_def_1566  1
    service_2_22_4  free_load_conservation_1567  2
    service_2_22_5  unique_nonzero_owner_357  1
    service_2_22_5  service_visit_def_1566  1
    service_2_22_5  free_load_conservation_1567  3
    service_2_22_6  unique_nonzero_owner_358  1
    service_2_22_6  service_visit_def_1566  1
    service_2_22_6  free_load_conservation_1567  4
    service_2_22_7  unique_nonzero_owner_359  1
    service_2_22_7  service_visit_def_1566  1
    service_2_22_7  free_load_conservation_1567  5
    service_2_22_8  unique_nonzero_owner_360  1
    service_2_22_8  service_visit_def_1566  1
    service_2_22_8  free_load_conservation_1567  6
    service_2_22_9  unique_nonzero_owner_361  1
    service_2_22_9  service_visit_def_1566  1
    service_2_22_9  free_load_conservation_1567  7
    service_2_22_10  unique_nonzero_owner_362  1
    service_2_22_10  service_visit_def_1566  1
    service_2_22_10  free_load_conservation_1567  8
    service_2_22_11  unique_nonzero_owner_363  1
    service_2_22_11  service_visit_def_1566  1
    service_2_22_11  free_load_conservation_1567  9
    service_2_22_12  unique_nonzero_owner_364  1
    service_2_22_12  service_visit_def_1566  1
    service_2_22_12  free_load_conservation_1567  10
    service_2_22_13  unique_nonzero_owner_365  1
    service_2_22_13  service_visit_def_1566  1
    service_2_22_13  free_load_conservation_1567  11
    service_2_22_14  unique_nonzero_owner_366  1
    service_2_22_14  service_visit_def_1566  1
    service_2_22_14  free_load_conservation_1567  12
    service_2_22_15  unique_nonzero_owner_367  1
    service_2_22_15  service_visit_def_1566  1
    service_2_22_15  free_load_conservation_1567  13
    service_0_7_0  unique_nonzero_owner_368  1
    service_0_7_0  service_visit_def_875  1
    service_0_7_0  free_load_conservation_876  -1
    service_0_7_0  original_T_including_depot_unload_894  120
    service_0_7_2  unique_nonzero_owner_369  1
    service_0_7_2  service_visit_def_875  1
    service_0_7_2  free_load_conservation_876  1
    service_0_7_3  unique_nonzero_owner_370  1
    service_0_7_3  service_visit_def_875  1
    service_0_7_3  free_load_conservation_876  2
    service_0_7_4  unique_nonzero_owner_371  1
    service_0_7_4  service_visit_def_875  1
    service_0_7_4  free_load_conservation_876  3
    service_0_7_5  unique_nonzero_owner_372  1
    service_0_7_5  service_visit_def_875  1
    service_0_7_5  free_load_conservation_876  4
    service_0_7_6  unique_nonzero_owner_373  1
    service_0_7_6  service_visit_def_875  1
    service_0_7_6  free_load_conservation_876  5
    service_0_7_7  unique_nonzero_owner_374  1
    service_0_7_7  service_visit_def_875  1
    service_0_7_7  free_load_conservation_876  6
    service_0_7_8  unique_nonzero_owner_375  1
    service_0_7_8  service_visit_def_875  1
    service_0_7_8  free_load_conservation_876  7
    service_0_7_9  unique_nonzero_owner_376  1
    service_0_7_9  service_visit_def_875  1
    service_0_7_9  free_load_conservation_876  8
    service_0_7_10  unique_nonzero_owner_377  1
    service_0_7_10  service_visit_def_875  1
    service_0_7_10  free_load_conservation_876  9
    service_0_7_11  unique_nonzero_owner_378  1
    service_0_7_11  service_visit_def_875  1
    service_0_7_11  free_load_conservation_876  10
    service_0_7_12  unique_nonzero_owner_379  1
    service_0_7_12  service_visit_def_875  1
    service_0_7_12  free_load_conservation_876  11
    service_0_7_13  unique_nonzero_owner_380  1
    service_0_7_13  service_visit_def_875  1
    service_0_7_13  free_load_conservation_876  12
    service_0_7_14  unique_nonzero_owner_381  1
    service_0_7_14  service_visit_def_875  1
    service_0_7_14  free_load_conservation_876  13
    service_0_7_15  unique_nonzero_owner_382  1
    service_0_7_15  service_visit_def_875  1
    service_0_7_15  free_load_conservation_876  14
    service_1_7_0  unique_nonzero_owner_368  1
    service_1_7_0  service_visit_def_1146  1
    service_1_7_0  free_load_conservation_1147  -1
    service_1_7_0  original_T_including_depot_unload_1161  120
    service_1_7_2  unique_nonzero_owner_369  1
    service_1_7_2  service_visit_def_1146  1
    service_1_7_2  free_load_conservation_1147  1
    service_1_7_3  unique_nonzero_owner_370  1
    service_1_7_3  service_visit_def_1146  1
    service_1_7_3  free_load_conservation_1147  2
    service_1_7_4  unique_nonzero_owner_371  1
    service_1_7_4  service_visit_def_1146  1
    service_1_7_4  free_load_conservation_1147  3
    service_1_7_5  unique_nonzero_owner_372  1
    service_1_7_5  service_visit_def_1146  1
    service_1_7_5  free_load_conservation_1147  4
    service_1_7_6  unique_nonzero_owner_373  1
    service_1_7_6  service_visit_def_1146  1
    service_1_7_6  free_load_conservation_1147  5
    service_1_7_7  unique_nonzero_owner_374  1
    service_1_7_7  service_visit_def_1146  1
    service_1_7_7  free_load_conservation_1147  6
    service_1_7_8  unique_nonzero_owner_375  1
    service_1_7_8  service_visit_def_1146  1
    service_1_7_8  free_load_conservation_1147  7
    service_1_7_9  unique_nonzero_owner_376  1
    service_1_7_9  service_visit_def_1146  1
    service_1_7_9  free_load_conservation_1147  8
    service_1_7_10  unique_nonzero_owner_377  1
    service_1_7_10  service_visit_def_1146  1
    service_1_7_10  free_load_conservation_1147  9
    service_1_7_11  unique_nonzero_owner_378  1
    service_1_7_11  service_visit_def_1146  1
    service_1_7_11  free_load_conservation_1147  10
    service_1_7_12  unique_nonzero_owner_379  1
    service_1_7_12  service_visit_def_1146  1
    service_1_7_12  free_load_conservation_1147  11
    service_1_7_13  unique_nonzero_owner_380  1
    service_1_7_13  service_visit_def_1146  1
    service_1_7_13  free_load_conservation_1147  12
    service_1_7_14  unique_nonzero_owner_381  1
    service_1_7_14  service_visit_def_1146  1
    service_1_7_14  free_load_conservation_1147  13
    service_1_7_15  unique_nonzero_owner_382  1
    service_1_7_15  service_visit_def_1146  1
    service_1_7_15  free_load_conservation_1147  14
    service_2_7_0  unique_nonzero_owner_368  1
    service_2_7_0  service_visit_def_1572  1
    service_2_7_0  free_load_conservation_1573  -1
    service_2_7_0  original_T_including_depot_unload_1590  120
    service_2_7_2  unique_nonzero_owner_369  1
    service_2_7_2  service_visit_def_1572  1
    service_2_7_2  free_load_conservation_1573  1
    service_2_7_3  unique_nonzero_owner_370  1
    service_2_7_3  service_visit_def_1572  1
    service_2_7_3  free_load_conservation_1573  2
    service_2_7_4  unique_nonzero_owner_371  1
    service_2_7_4  service_visit_def_1572  1
    service_2_7_4  free_load_conservation_1573  3
    service_2_7_5  unique_nonzero_owner_372  1
    service_2_7_5  service_visit_def_1572  1
    service_2_7_5  free_load_conservation_1573  4
    service_2_7_6  unique_nonzero_owner_373  1
    service_2_7_6  service_visit_def_1572  1
    service_2_7_6  free_load_conservation_1573  5
    service_2_7_7  unique_nonzero_owner_374  1
    service_2_7_7  service_visit_def_1572  1
    service_2_7_7  free_load_conservation_1573  6
    service_2_7_8  unique_nonzero_owner_375  1
    service_2_7_8  service_visit_def_1572  1
    service_2_7_8  free_load_conservation_1573  7
    service_2_7_9  unique_nonzero_owner_376  1
    service_2_7_9  service_visit_def_1572  1
    service_2_7_9  free_load_conservation_1573  8
    service_2_7_10  unique_nonzero_owner_377  1
    service_2_7_10  service_visit_def_1572  1
    service_2_7_10  free_load_conservation_1573  9
    service_2_7_11  unique_nonzero_owner_378  1
    service_2_7_11  service_visit_def_1572  1
    service_2_7_11  free_load_conservation_1573  10
    service_2_7_12  unique_nonzero_owner_379  1
    service_2_7_12  service_visit_def_1572  1
    service_2_7_12  free_load_conservation_1573  11
    service_2_7_13  unique_nonzero_owner_380  1
    service_2_7_13  service_visit_def_1572  1
    service_2_7_13  free_load_conservation_1573  12
    service_2_7_14  unique_nonzero_owner_381  1
    service_2_7_14  service_visit_def_1572  1
    service_2_7_14  free_load_conservation_1573  13
    service_2_7_15  unique_nonzero_owner_382  1
    service_2_7_15  service_visit_def_1572  1
    service_2_7_15  free_load_conservation_1573  14
    service_0_27_1  unique_nonzero_owner_383  1
    service_0_27_1  service_visit_def_881  1
    service_0_27_1  free_load_conservation_882  1
    service_0_27_2  unique_nonzero_owner_384  1
    service_0_27_2  service_visit_def_881  1
    service_0_27_2  free_load_conservation_882  2
    service_0_27_3  unique_nonzero_owner_385  1
    service_0_27_3  service_visit_def_881  1
    service_0_27_3  free_load_conservation_882  3
    service_0_27_4  unique_nonzero_owner_386  1
    service_0_27_4  service_visit_def_881  1
    service_0_27_4  free_load_conservation_882  4
    service_0_27_5  unique_nonzero_owner_387  1
    service_0_27_5  service_visit_def_881  1
    service_0_27_5  free_load_conservation_882  5
    service_0_27_6  unique_nonzero_owner_388  1
    service_0_27_6  service_visit_def_881  1
    service_0_27_6  free_load_conservation_882  6
    service_1_27_1  unique_nonzero_owner_383  1
    service_1_27_1  service_visit_def_1152  1
    service_1_27_1  free_load_conservation_1153  1
    service_1_27_2  unique_nonzero_owner_384  1
    service_1_27_2  service_visit_def_1152  1
    service_1_27_2  free_load_conservation_1153  2
    service_1_27_3  unique_nonzero_owner_385  1
    service_1_27_3  service_visit_def_1152  1
    service_1_27_3  free_load_conservation_1153  3
    service_1_27_4  unique_nonzero_owner_386  1
    service_1_27_4  service_visit_def_1152  1
    service_1_27_4  free_load_conservation_1153  4
    service_1_27_5  unique_nonzero_owner_387  1
    service_1_27_5  service_visit_def_1152  1
    service_1_27_5  free_load_conservation_1153  5
    service_1_27_6  unique_nonzero_owner_388  1
    service_1_27_6  service_visit_def_1152  1
    service_1_27_6  free_load_conservation_1153  6
    service_2_27_1  unique_nonzero_owner_383  1
    service_2_27_1  service_visit_def_1578  1
    service_2_27_1  free_load_conservation_1579  1
    service_2_27_2  unique_nonzero_owner_384  1
    service_2_27_2  service_visit_def_1578  1
    service_2_27_2  free_load_conservation_1579  2
    service_2_27_3  unique_nonzero_owner_385  1
    service_2_27_3  service_visit_def_1578  1
    service_2_27_3  free_load_conservation_1579  3
    service_2_27_4  unique_nonzero_owner_386  1
    service_2_27_4  service_visit_def_1578  1
    service_2_27_4  free_load_conservation_1579  4
    service_2_27_5  unique_nonzero_owner_387  1
    service_2_27_5  service_visit_def_1578  1
    service_2_27_5  free_load_conservation_1579  5
    service_2_27_6  unique_nonzero_owner_388  1
    service_2_27_6  service_visit_def_1578  1
    service_2_27_6  free_load_conservation_1579  6
    service_0_5_0  unique_nonzero_owner_389  1
    service_0_5_0  service_visit_def_887  1
    service_0_5_0  free_load_conservation_888  -1
    service_0_5_0  original_T_including_depot_unload_894  120
    service_0_5_2  unique_nonzero_owner_390  1
    service_0_5_2  service_visit_def_887  1
    service_0_5_2  free_load_conservation_888  1
    service_0_5_3  unique_nonzero_owner_391  1
    service_0_5_3  service_visit_def_887  1
    service_0_5_3  free_load_conservation_888  2
    service_0_5_4  unique_nonzero_owner_392  1
    service_0_5_4  service_visit_def_887  1
    service_0_5_4  free_load_conservation_888  3
    service_0_5_5  unique_nonzero_owner_393  1
    service_0_5_5  service_visit_def_887  1
    service_0_5_5  free_load_conservation_888  4
    service_0_5_6  unique_nonzero_owner_394  1
    service_0_5_6  service_visit_def_887  1
    service_0_5_6  free_load_conservation_888  5
    service_0_5_7  unique_nonzero_owner_395  1
    service_0_5_7  service_visit_def_887  1
    service_0_5_7  free_load_conservation_888  6
    service_0_5_8  unique_nonzero_owner_396  1
    service_0_5_8  service_visit_def_887  1
    service_0_5_8  free_load_conservation_888  7
    service_0_5_9  unique_nonzero_owner_397  1
    service_0_5_9  service_visit_def_887  1
    service_0_5_9  free_load_conservation_888  8
    service_0_5_10  unique_nonzero_owner_398  1
    service_0_5_10  service_visit_def_887  1
    service_0_5_10  free_load_conservation_888  9
    service_0_5_11  unique_nonzero_owner_399  1
    service_0_5_11  service_visit_def_887  1
    service_0_5_11  free_load_conservation_888  10
    service_0_5_12  unique_nonzero_owner_400  1
    service_0_5_12  service_visit_def_887  1
    service_0_5_12  free_load_conservation_888  11
    service_0_5_13  unique_nonzero_owner_401  1
    service_0_5_13  service_visit_def_887  1
    service_0_5_13  free_load_conservation_888  12
    service_0_5_14  unique_nonzero_owner_402  1
    service_0_5_14  service_visit_def_887  1
    service_0_5_14  free_load_conservation_888  13
    service_0_5_15  unique_nonzero_owner_403  1
    service_0_5_15  service_visit_def_887  1
    service_0_5_15  free_load_conservation_888  14
    service_1_5_0  unique_nonzero_owner_389  1
    service_1_5_0  service_visit_def_1158  1
    service_1_5_0  free_load_conservation_1159  -1
    service_1_5_0  original_T_including_depot_unload_1161  120
    service_1_5_2  unique_nonzero_owner_390  1
    service_1_5_2  service_visit_def_1158  1
    service_1_5_2  free_load_conservation_1159  1
    service_1_5_3  unique_nonzero_owner_391  1
    service_1_5_3  service_visit_def_1158  1
    service_1_5_3  free_load_conservation_1159  2
    service_1_5_4  unique_nonzero_owner_392  1
    service_1_5_4  service_visit_def_1158  1
    service_1_5_4  free_load_conservation_1159  3
    service_1_5_5  unique_nonzero_owner_393  1
    service_1_5_5  service_visit_def_1158  1
    service_1_5_5  free_load_conservation_1159  4
    service_1_5_6  unique_nonzero_owner_394  1
    service_1_5_6  service_visit_def_1158  1
    service_1_5_6  free_load_conservation_1159  5
    service_1_5_7  unique_nonzero_owner_395  1
    service_1_5_7  service_visit_def_1158  1
    service_1_5_7  free_load_conservation_1159  6
    service_1_5_8  unique_nonzero_owner_396  1
    service_1_5_8  service_visit_def_1158  1
    service_1_5_8  free_load_conservation_1159  7
    service_1_5_9  unique_nonzero_owner_397  1
    service_1_5_9  service_visit_def_1158  1
    service_1_5_9  free_load_conservation_1159  8
    service_1_5_10  unique_nonzero_owner_398  1
    service_1_5_10  service_visit_def_1158  1
    service_1_5_10  free_load_conservation_1159  9
    service_1_5_11  unique_nonzero_owner_399  1
    service_1_5_11  service_visit_def_1158  1
    service_1_5_11  free_load_conservation_1159  10
    service_1_5_12  unique_nonzero_owner_400  1
    service_1_5_12  service_visit_def_1158  1
    service_1_5_12  free_load_conservation_1159  11
    service_1_5_13  unique_nonzero_owner_401  1
    service_1_5_13  service_visit_def_1158  1
    service_1_5_13  free_load_conservation_1159  12
    service_1_5_14  unique_nonzero_owner_402  1
    service_1_5_14  service_visit_def_1158  1
    service_1_5_14  free_load_conservation_1159  13
    service_1_5_15  unique_nonzero_owner_403  1
    service_1_5_15  service_visit_def_1158  1
    service_1_5_15  free_load_conservation_1159  14
    service_2_5_0  unique_nonzero_owner_389  1
    service_2_5_0  service_visit_def_1584  1
    service_2_5_0  free_load_conservation_1585  -1
    service_2_5_0  original_T_including_depot_unload_1590  120
    service_2_5_2  unique_nonzero_owner_390  1
    service_2_5_2  service_visit_def_1584  1
    service_2_5_2  free_load_conservation_1585  1
    service_2_5_3  unique_nonzero_owner_391  1
    service_2_5_3  service_visit_def_1584  1
    service_2_5_3  free_load_conservation_1585  2
    service_2_5_4  unique_nonzero_owner_392  1
    service_2_5_4  service_visit_def_1584  1
    service_2_5_4  free_load_conservation_1585  3
    service_2_5_5  unique_nonzero_owner_393  1
    service_2_5_5  service_visit_def_1584  1
    service_2_5_5  free_load_conservation_1585  4
    service_2_5_6  unique_nonzero_owner_394  1
    service_2_5_6  service_visit_def_1584  1
    service_2_5_6  free_load_conservation_1585  5
    service_2_5_7  unique_nonzero_owner_395  1
    service_2_5_7  service_visit_def_1584  1
    service_2_5_7  free_load_conservation_1585  6
    service_2_5_8  unique_nonzero_owner_396  1
    service_2_5_8  service_visit_def_1584  1
    service_2_5_8  free_load_conservation_1585  7
    service_2_5_9  unique_nonzero_owner_397  1
    service_2_5_9  service_visit_def_1584  1
    service_2_5_9  free_load_conservation_1585  8
    service_2_5_10  unique_nonzero_owner_398  1
    service_2_5_10  service_visit_def_1584  1
    service_2_5_10  free_load_conservation_1585  9
    service_2_5_11  unique_nonzero_owner_399  1
    service_2_5_11  service_visit_def_1584  1
    service_2_5_11  free_load_conservation_1585  10
    service_2_5_12  unique_nonzero_owner_400  1
    service_2_5_12  service_visit_def_1584  1
    service_2_5_12  free_load_conservation_1585  11
    service_2_5_13  unique_nonzero_owner_401  1
    service_2_5_13  service_visit_def_1584  1
    service_2_5_13  free_load_conservation_1585  12
    service_2_5_14  unique_nonzero_owner_402  1
    service_2_5_14  service_visit_def_1584  1
    service_2_5_14  free_load_conservation_1585  13
    service_2_5_15  unique_nonzero_owner_403  1
    service_2_5_15  service_visit_def_1584  1
    service_2_5_15  free_load_conservation_1585  14
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_799  -1
    visit_0_1  in_degree_800  -1
    visit_0_1  order_active_lb_801  -1
    visit_0_1  order_active_ub_802  -14
    order_0_1  connected_order_arc_421  -1
    order_0_1  connected_order_arc_423  -1
    order_0_1  connected_order_arc_425  -1
    order_0_1  connected_order_arc_427  -1
    order_0_1  connected_order_arc_429  -1
    order_0_1  connected_order_arc_431  -1
    order_0_1  connected_order_arc_433  -1
    order_0_1  connected_order_arc_435  -1
    order_0_1  connected_order_arc_437  -1
    order_0_1  connected_order_arc_439  -1
    order_0_1  connected_order_arc_441  -1
    order_0_1  connected_order_arc_443  -1
    order_0_1  connected_order_arc_445  -1
    order_0_1  connected_order_arc_448  1
    order_0_1  connected_order_arc_475  1
    order_0_1  connected_order_arc_502  1
    order_0_1  connected_order_arc_529  1
    order_0_1  connected_order_arc_556  1
    order_0_1  connected_order_arc_583  1
    order_0_1  connected_order_arc_610  1
    order_0_1  connected_order_arc_637  1
    order_0_1  connected_order_arc_664  1
    order_0_1  connected_order_arc_691  1
    order_0_1  connected_order_arc_718  1
    order_0_1  connected_order_arc_745  1
    order_0_1  connected_order_arc_772  1
    order_0_1  order_active_lb_801  1
    order_0_1  order_active_ub_802  1
    order_0_1  fixed_segment_relative_order_889  -1
    visit_0_2  out_degree_806  -1
    visit_0_2  in_degree_807  -1
    visit_0_2  order_active_lb_808  -1
    visit_0_2  order_active_ub_809  -14
    order_0_2  connected_order_arc_421  1
    order_0_2  connected_order_arc_448  -1
    order_0_2  connected_order_arc_450  -1
    order_0_2  connected_order_arc_452  -1
    order_0_2  connected_order_arc_454  -1
    order_0_2  connected_order_arc_456  -1
    order_0_2  connected_order_arc_458  -1
    order_0_2  connected_order_arc_460  -1
    order_0_2  connected_order_arc_462  -1
    order_0_2  connected_order_arc_464  -1
    order_0_2  connected_order_arc_466  -1
    order_0_2  connected_order_arc_468  -1
    order_0_2  connected_order_arc_470  -1
    order_0_2  connected_order_arc_472  -1
    order_0_2  connected_order_arc_477  1
    order_0_2  connected_order_arc_504  1
    order_0_2  connected_order_arc_531  1
    order_0_2  connected_order_arc_558  1
    order_0_2  connected_order_arc_585  1
    order_0_2  connected_order_arc_612  1
    order_0_2  connected_order_arc_639  1
    order_0_2  connected_order_arc_666  1
    order_0_2  connected_order_arc_693  1
    order_0_2  connected_order_arc_720  1
    order_0_2  connected_order_arc_747  1
    order_0_2  connected_order_arc_774  1
    order_0_2  order_active_lb_808  1
    order_0_2  order_active_ub_809  1
    order_0_2  fixed_segment_relative_order_889  1
    order_0_2  fixed_segment_relative_order_890  -1
    visit_0_3  out_degree_813  -1
    visit_0_3  in_degree_814  -1
    visit_0_3  order_active_lb_815  -1
    visit_0_3  order_active_ub_816  -14
    order_0_3  connected_order_arc_423  1
    order_0_3  connected_order_arc_450  1
    order_0_3  connected_order_arc_475  -1
    order_0_3  connected_order_arc_477  -1
    order_0_3  connected_order_arc_479  -1
    order_0_3  connected_order_arc_481  -1
    order_0_3  connected_order_arc_483  -1
    order_0_3  connected_order_arc_485  -1
    order_0_3  connected_order_arc_487  -1
    order_0_3  connected_order_arc_489  -1
    order_0_3  connected_order_arc_491  -1
    order_0_3  connected_order_arc_493  -1
    order_0_3  connected_order_arc_495  -1
    order_0_3  connected_order_arc_497  -1
    order_0_3  connected_order_arc_499  -1
    order_0_3  connected_order_arc_506  1
    order_0_3  connected_order_arc_533  1
    order_0_3  connected_order_arc_560  1
    order_0_3  connected_order_arc_587  1
    order_0_3  connected_order_arc_614  1
    order_0_3  connected_order_arc_641  1
    order_0_3  connected_order_arc_668  1
    order_0_3  connected_order_arc_695  1
    order_0_3  connected_order_arc_722  1
    order_0_3  connected_order_arc_749  1
    order_0_3  connected_order_arc_776  1
    order_0_3  order_active_lb_815  1
    order_0_3  order_active_ub_816  1
    order_0_3  fixed_segment_relative_order_890  1
    order_0_3  fixed_segment_relative_order_891  -1
    visit_0_4  out_degree_820  -1
    visit_0_4  in_degree_821  -1
    visit_0_4  order_active_lb_822  -1
    visit_0_4  order_active_ub_823  -14
    order_0_4  connected_order_arc_425  1
    order_0_4  connected_order_arc_452  1
    order_0_4  connected_order_arc_479  1
    order_0_4  connected_order_arc_502  -1
    order_0_4  connected_order_arc_504  -1
    order_0_4  connected_order_arc_506  -1
    order_0_4  connected_order_arc_508  -1
    order_0_4  connected_order_arc_510  -1
    order_0_4  connected_order_arc_512  -1
    order_0_4  connected_order_arc_514  -1
    order_0_4  connected_order_arc_516  -1
    order_0_4  connected_order_arc_518  -1
    order_0_4  connected_order_arc_520  -1
    order_0_4  connected_order_arc_522  -1
    order_0_4  connected_order_arc_524  -1
    order_0_4  connected_order_arc_526  -1
    order_0_4  connected_order_arc_535  1
    order_0_4  connected_order_arc_562  1
    order_0_4  connected_order_arc_589  1
    order_0_4  connected_order_arc_616  1
    order_0_4  connected_order_arc_643  1
    order_0_4  connected_order_arc_670  1
    order_0_4  connected_order_arc_697  1
    order_0_4  connected_order_arc_724  1
    order_0_4  connected_order_arc_751  1
    order_0_4  connected_order_arc_778  1
    order_0_4  order_active_lb_822  1
    order_0_4  order_active_ub_823  1
    order_0_4  fixed_segment_relative_order_891  1
    order_0_4  fixed_segment_relative_order_892  -1
    visit_0_5  out_degree_827  -1
    visit_0_5  in_degree_828  -1
    visit_0_5  order_active_lb_829  -1
    visit_0_5  order_active_ub_830  -14
    order_0_5  connected_order_arc_427  1
    order_0_5  connected_order_arc_454  1
    order_0_5  connected_order_arc_481  1
    order_0_5  connected_order_arc_508  1
    order_0_5  connected_order_arc_529  -1
    order_0_5  connected_order_arc_531  -1
    order_0_5  connected_order_arc_533  -1
    order_0_5  connected_order_arc_535  -1
    order_0_5  connected_order_arc_537  -1
    order_0_5  connected_order_arc_539  -1
    order_0_5  connected_order_arc_541  -1
    order_0_5  connected_order_arc_543  -1
    order_0_5  connected_order_arc_545  -1
    order_0_5  connected_order_arc_547  -1
    order_0_5  connected_order_arc_549  -1
    order_0_5  connected_order_arc_551  -1
    order_0_5  connected_order_arc_553  -1
    order_0_5  connected_order_arc_564  1
    order_0_5  connected_order_arc_591  1
    order_0_5  connected_order_arc_618  1
    order_0_5  connected_order_arc_645  1
    order_0_5  connected_order_arc_672  1
    order_0_5  connected_order_arc_699  1
    order_0_5  connected_order_arc_726  1
    order_0_5  connected_order_arc_753  1
    order_0_5  connected_order_arc_780  1
    order_0_5  order_active_lb_829  1
    order_0_5  order_active_ub_830  1
    order_0_5  fixed_segment_relative_order_892  1
    order_0_5  fixed_segment_relative_order_893  -1
    visit_0_6  out_degree_834  -1
    visit_0_6  in_degree_835  -1
    visit_0_6  order_active_lb_836  -1
    visit_0_6  order_active_ub_837  -14
    order_0_6  connected_order_arc_429  1
    order_0_6  connected_order_arc_456  1
    order_0_6  connected_order_arc_483  1
    order_0_6  connected_order_arc_510  1
    order_0_6  connected_order_arc_537  1
    order_0_6  connected_order_arc_556  -1
    order_0_6  connected_order_arc_558  -1
    order_0_6  connected_order_arc_560  -1
    order_0_6  connected_order_arc_562  -1
    order_0_6  connected_order_arc_564  -1
    order_0_6  connected_order_arc_566  -1
    order_0_6  connected_order_arc_568  -1
    order_0_6  connected_order_arc_570  -1
    order_0_6  connected_order_arc_572  -1
    order_0_6  connected_order_arc_574  -1
    order_0_6  connected_order_arc_576  -1
    order_0_6  connected_order_arc_578  -1
    order_0_6  connected_order_arc_580  -1
    order_0_6  connected_order_arc_593  1
    order_0_6  connected_order_arc_620  1
    order_0_6  connected_order_arc_647  1
    order_0_6  connected_order_arc_674  1
    order_0_6  connected_order_arc_701  1
    order_0_6  connected_order_arc_728  1
    order_0_6  connected_order_arc_755  1
    order_0_6  connected_order_arc_782  1
    order_0_6  order_active_lb_836  1
    order_0_6  order_active_ub_837  1
    order_0_6  fixed_segment_relative_order_893  1
    visit_0_14  out_degree_841  -1
    visit_0_14  in_degree_842  -1
    visit_0_14  order_active_lb_843  -1
    visit_0_14  order_active_ub_844  -14
    visit_0_14  service_visit_def_845  -1
    order_0_14  connected_order_arc_431  1
    order_0_14  connected_order_arc_458  1
    order_0_14  connected_order_arc_485  1
    order_0_14  connected_order_arc_512  1
    order_0_14  connected_order_arc_539  1
    order_0_14  connected_order_arc_566  1
    order_0_14  connected_order_arc_583  -1
    order_0_14  connected_order_arc_585  -1
    order_0_14  connected_order_arc_587  -1
    order_0_14  connected_order_arc_589  -1
    order_0_14  connected_order_arc_591  -1
    order_0_14  connected_order_arc_593  -1
    order_0_14  connected_order_arc_595  -1
    order_0_14  connected_order_arc_597  -1
    order_0_14  connected_order_arc_599  -1
    order_0_14  connected_order_arc_601  -1
    order_0_14  connected_order_arc_603  -1
    order_0_14  connected_order_arc_605  -1
    order_0_14  connected_order_arc_607  -1
    order_0_14  connected_order_arc_622  1
    order_0_14  connected_order_arc_649  1
    order_0_14  connected_order_arc_676  1
    order_0_14  connected_order_arc_703  1
    order_0_14  connected_order_arc_730  1
    order_0_14  connected_order_arc_757  1
    order_0_14  connected_order_arc_784  1
    order_0_14  order_active_lb_843  1
    order_0_14  order_active_ub_844  1
    visit_0_15  out_degree_847  -1
    visit_0_15  in_degree_848  -1
    visit_0_15  order_active_lb_849  -1
    visit_0_15  order_active_ub_850  -14
    visit_0_15  service_visit_def_851  -1
    order_0_15  connected_order_arc_433  1
    order_0_15  connected_order_arc_460  1
    order_0_15  connected_order_arc_487  1
    order_0_15  connected_order_arc_514  1
    order_0_15  connected_order_arc_541  1
    order_0_15  connected_order_arc_568  1
    order_0_15  connected_order_arc_595  1
    order_0_15  connected_order_arc_610  -1
    order_0_15  connected_order_arc_612  -1
    order_0_15  connected_order_arc_614  -1
    order_0_15  connected_order_arc_616  -1
    order_0_15  connected_order_arc_618  -1
    order_0_15  connected_order_arc_620  -1
    order_0_15  connected_order_arc_622  -1
    order_0_15  connected_order_arc_624  -1
    order_0_15  connected_order_arc_626  -1
    order_0_15  connected_order_arc_628  -1
    order_0_15  connected_order_arc_630  -1
    order_0_15  connected_order_arc_632  -1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_651  1
    order_0_15  connected_order_arc_678  1
    order_0_15  connected_order_arc_705  1
    order_0_15  connected_order_arc_732  1
    order_0_15  connected_order_arc_759  1
    order_0_15  connected_order_arc_786  1
    order_0_15  order_active_lb_849  1
    order_0_15  order_active_ub_850  1
    visit_0_16  out_degree_853  -1
    visit_0_16  in_degree_854  -1
    visit_0_16  order_active_lb_855  -1
    visit_0_16  order_active_ub_856  -14
    visit_0_16  service_visit_def_857  -1
    order_0_16  connected_order_arc_435  1
    order_0_16  connected_order_arc_462  1
    order_0_16  connected_order_arc_489  1
    order_0_16  connected_order_arc_516  1
    order_0_16  connected_order_arc_543  1
    order_0_16  connected_order_arc_570  1
    order_0_16  connected_order_arc_597  1
    order_0_16  connected_order_arc_624  1
    order_0_16  connected_order_arc_637  -1
    order_0_16  connected_order_arc_639  -1
    order_0_16  connected_order_arc_641  -1
    order_0_16  connected_order_arc_643  -1
    order_0_16  connected_order_arc_645  -1
    order_0_16  connected_order_arc_647  -1
    order_0_16  connected_order_arc_649  -1
    order_0_16  connected_order_arc_651  -1
    order_0_16  connected_order_arc_653  -1
    order_0_16  connected_order_arc_655  -1
    order_0_16  connected_order_arc_657  -1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_680  1
    order_0_16  connected_order_arc_707  1
    order_0_16  connected_order_arc_734  1
    order_0_16  connected_order_arc_761  1
    order_0_16  connected_order_arc_788  1
    order_0_16  order_active_lb_855  1
    order_0_16  order_active_ub_856  1
    visit_0_17  out_degree_859  -1
    visit_0_17  in_degree_860  -1
    visit_0_17  order_active_lb_861  -1
    visit_0_17  order_active_ub_862  -14
    visit_0_17  service_visit_def_863  -1
    order_0_17  connected_order_arc_437  1
    order_0_17  connected_order_arc_464  1
    order_0_17  connected_order_arc_491  1
    order_0_17  connected_order_arc_518  1
    order_0_17  connected_order_arc_545  1
    order_0_17  connected_order_arc_572  1
    order_0_17  connected_order_arc_599  1
    order_0_17  connected_order_arc_626  1
    order_0_17  connected_order_arc_653  1
    order_0_17  connected_order_arc_664  -1
    order_0_17  connected_order_arc_666  -1
    order_0_17  connected_order_arc_668  -1
    order_0_17  connected_order_arc_670  -1
    order_0_17  connected_order_arc_672  -1
    order_0_17  connected_order_arc_674  -1
    order_0_17  connected_order_arc_676  -1
    order_0_17  connected_order_arc_678  -1
    order_0_17  connected_order_arc_680  -1
    order_0_17  connected_order_arc_682  -1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_688  -1
    order_0_17  connected_order_arc_709  1
    order_0_17  connected_order_arc_736  1
    order_0_17  connected_order_arc_763  1
    order_0_17  connected_order_arc_790  1
    order_0_17  order_active_lb_861  1
    order_0_17  order_active_ub_862  1
    visit_0_18  out_degree_865  -1
    visit_0_18  in_degree_866  -1
    visit_0_18  order_active_lb_867  -1
    visit_0_18  order_active_ub_868  -14
    visit_0_18  service_visit_def_869  -1
    order_0_18  connected_order_arc_439  1
    order_0_18  connected_order_arc_466  1
    order_0_18  connected_order_arc_493  1
    order_0_18  connected_order_arc_520  1
    order_0_18  connected_order_arc_547  1
    order_0_18  connected_order_arc_574  1
    order_0_18  connected_order_arc_601  1
    order_0_18  connected_order_arc_628  1
    order_0_18  connected_order_arc_655  1
    order_0_18  connected_order_arc_682  1
    order_0_18  connected_order_arc_691  -1
    order_0_18  connected_order_arc_693  -1
    order_0_18  connected_order_arc_695  -1
    order_0_18  connected_order_arc_697  -1
    order_0_18  connected_order_arc_699  -1
    order_0_18  connected_order_arc_701  -1
    order_0_18  connected_order_arc_703  -1
    order_0_18  connected_order_arc_705  -1
    order_0_18  connected_order_arc_707  -1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_711  -1
    order_0_18  connected_order_arc_713  -1
    order_0_18  connected_order_arc_715  -1
    order_0_18  connected_order_arc_738  1
    order_0_18  connected_order_arc_765  1
    order_0_18  connected_order_arc_792  1
    order_0_18  order_active_lb_867  1
    order_0_18  order_active_ub_868  1
    visit_0_19  out_degree_871  -1
    visit_0_19  in_degree_872  -1
    visit_0_19  order_active_lb_873  -1
    visit_0_19  order_active_ub_874  -14
    visit_0_19  service_visit_def_875  -1
    order_0_19  connected_order_arc_441  1
    order_0_19  connected_order_arc_468  1
    order_0_19  connected_order_arc_495  1
    order_0_19  connected_order_arc_522  1
    order_0_19  connected_order_arc_549  1
    order_0_19  connected_order_arc_576  1
    order_0_19  connected_order_arc_603  1
    order_0_19  connected_order_arc_630  1
    order_0_19  connected_order_arc_657  1
    order_0_19  connected_order_arc_684  1
    order_0_19  connected_order_arc_711  1
    order_0_19  connected_order_arc_718  -1
    order_0_19  connected_order_arc_720  -1
    order_0_19  connected_order_arc_722  -1
    order_0_19  connected_order_arc_724  -1
    order_0_19  connected_order_arc_726  -1
    order_0_19  connected_order_arc_728  -1
    order_0_19  connected_order_arc_730  -1
    order_0_19  connected_order_arc_732  -1
    order_0_19  connected_order_arc_734  -1
    order_0_19  connected_order_arc_736  -1
    order_0_19  connected_order_arc_738  -1
    order_0_19  connected_order_arc_740  -1
    order_0_19  connected_order_arc_742  -1
    order_0_19  connected_order_arc_767  1
    order_0_19  connected_order_arc_794  1
    order_0_19  order_active_lb_873  1
    order_0_19  order_active_ub_874  1
    visit_0_20  out_degree_877  -1
    visit_0_20  in_degree_878  -1
    visit_0_20  order_active_lb_879  -1
    visit_0_20  order_active_ub_880  -14
    visit_0_20  service_visit_def_881  -1
    order_0_20  connected_order_arc_443  1
    order_0_20  connected_order_arc_470  1
    order_0_20  connected_order_arc_497  1
    order_0_20  connected_order_arc_524  1
    order_0_20  connected_order_arc_551  1
    order_0_20  connected_order_arc_578  1
    order_0_20  connected_order_arc_605  1
    order_0_20  connected_order_arc_632  1
    order_0_20  connected_order_arc_659  1
    order_0_20  connected_order_arc_686  1
    order_0_20  connected_order_arc_713  1
    order_0_20  connected_order_arc_740  1
    order_0_20  connected_order_arc_745  -1
    order_0_20  connected_order_arc_747  -1
    order_0_20  connected_order_arc_749  -1
    order_0_20  connected_order_arc_751  -1
    order_0_20  connected_order_arc_753  -1
    order_0_20  connected_order_arc_755  -1
    order_0_20  connected_order_arc_757  -1
    order_0_20  connected_order_arc_759  -1
    order_0_20  connected_order_arc_761  -1
    order_0_20  connected_order_arc_763  -1
    order_0_20  connected_order_arc_765  -1
    order_0_20  connected_order_arc_767  -1
    order_0_20  connected_order_arc_769  -1
    order_0_20  connected_order_arc_796  1
    order_0_20  order_active_lb_879  1
    order_0_20  order_active_ub_880  1
    visit_0_21  out_degree_883  -1
    visit_0_21  in_degree_884  -1
    visit_0_21  order_active_lb_885  -1
    visit_0_21  order_active_ub_886  -14
    visit_0_21  service_visit_def_887  -1
    order_0_21  connected_order_arc_445  1
    order_0_21  connected_order_arc_472  1
    order_0_21  connected_order_arc_499  1
    order_0_21  connected_order_arc_526  1
    order_0_21  connected_order_arc_553  1
    order_0_21  connected_order_arc_580  1
    order_0_21  connected_order_arc_607  1
    order_0_21  connected_order_arc_634  1
    order_0_21  connected_order_arc_661  1
    order_0_21  connected_order_arc_688  1
    order_0_21  connected_order_arc_715  1
    order_0_21  connected_order_arc_742  1
    order_0_21  connected_order_arc_769  1
    order_0_21  connected_order_arc_772  -1
    order_0_21  connected_order_arc_774  -1
    order_0_21  connected_order_arc_776  -1
    order_0_21  connected_order_arc_778  -1
    order_0_21  connected_order_arc_780  -1
    order_0_21  connected_order_arc_782  -1
    order_0_21  connected_order_arc_784  -1
    order_0_21  connected_order_arc_786  -1
    order_0_21  connected_order_arc_788  -1
    order_0_21  connected_order_arc_790  -1
    order_0_21  connected_order_arc_792  -1
    order_0_21  connected_order_arc_794  -1
    order_0_21  connected_order_arc_796  -1
    order_0_21  order_active_lb_885  1
    order_0_21  order_active_ub_886  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_404  -20
    arc_0_0_0  depot_departure_or_bypass_797  1
    arc_0_0_0  depot_return_or_bypass_798  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_404  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_405  -20
    arc_0_0_1  depot_departure_or_bypass_797  1
    arc_0_0_1  in_degree_800  1
    arc_0_0_1  original_T_including_depot_unload_894  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_405  1
    load_0_0_1  segment_load_conservation_803  -1
    load_0_0_1  segment_prefix_lb_804  1
    load_0_0_1  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_406  -20
    arc_0_0_2  depot_departure_or_bypass_797  1
    arc_0_0_2  in_degree_807  1
    arc_0_0_2  original_T_including_depot_unload_894  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_406  1
    load_0_0_2  segment_load_conservation_810  -1
    load_0_0_2  segment_prefix_lb_811  1
    load_0_0_2  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_407  -20
    arc_0_0_3  depot_departure_or_bypass_797  1
    arc_0_0_3  in_degree_814  1
    arc_0_0_3  original_T_including_depot_unload_894  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_407  1
    load_0_0_3  segment_load_conservation_817  -1
    load_0_0_3  segment_prefix_lb_818  1
    load_0_0_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_408  -20
    arc_0_0_4  depot_departure_or_bypass_797  1
    arc_0_0_4  in_degree_821  1
    arc_0_0_4  original_T_including_depot_unload_894  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_408  1
    load_0_0_4  segment_load_conservation_824  -1
    load_0_0_4  segment_prefix_lb_825  1
    load_0_0_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_409  -20
    arc_0_0_5  depot_departure_or_bypass_797  1
    arc_0_0_5  in_degree_828  1
    arc_0_0_5  original_T_including_depot_unload_894  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_409  1
    load_0_0_5  segment_load_conservation_831  -1
    load_0_0_5  segment_prefix_lb_832  1
    load_0_0_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_410  -20
    arc_0_0_6  depot_departure_or_bypass_797  1
    arc_0_0_6  in_degree_835  1
    arc_0_0_6  original_T_including_depot_unload_894  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_410  1
    load_0_0_6  segment_load_conservation_838  -1
    load_0_0_6  segment_prefix_lb_839  1
    load_0_0_6  segment_prefix_ub_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_411  -20
    arc_0_0_14  depot_departure_or_bypass_797  1
    arc_0_0_14  in_degree_842  1
    arc_0_0_14  original_T_including_depot_unload_894  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_411  1
    load_0_0_14  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_412  -20
    arc_0_0_15  depot_departure_or_bypass_797  1
    arc_0_0_15  in_degree_848  1
    arc_0_0_15  original_T_including_depot_unload_894  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_412  1
    load_0_0_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_413  -20
    arc_0_0_16  depot_departure_or_bypass_797  1
    arc_0_0_16  in_degree_854  1
    arc_0_0_16  original_T_including_depot_unload_894  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_413  1
    load_0_0_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_414  -20
    arc_0_0_17  depot_departure_or_bypass_797  1
    arc_0_0_17  in_degree_860  1
    arc_0_0_17  original_T_including_depot_unload_894  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_414  1
    load_0_0_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_415  -20
    arc_0_0_18  depot_departure_or_bypass_797  1
    arc_0_0_18  in_degree_866  1
    arc_0_0_18  original_T_including_depot_unload_894  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_415  1
    load_0_0_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_416  -20
    arc_0_0_19  depot_departure_or_bypass_797  1
    arc_0_0_19  in_degree_872  1
    arc_0_0_19  original_T_including_depot_unload_894  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_416  1
    load_0_0_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_417  -20
    arc_0_0_20  depot_departure_or_bypass_797  1
    arc_0_0_20  in_degree_878  1
    arc_0_0_20  original_T_including_depot_unload_894  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_417  1
    load_0_0_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_418  -20
    arc_0_0_21  depot_departure_or_bypass_797  1
    arc_0_0_21  in_degree_884  1
    arc_0_0_21  original_T_including_depot_unload_894  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_418  1
    load_0_0_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_419  -20
    arc_0_1_0  depot_return_or_bypass_798  1
    arc_0_1_0  out_degree_799  1
    arc_0_1_0  original_T_including_depot_unload_894  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_419  1
    load_0_1_0  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_420  -20
    arc_0_1_2  connected_order_arc_421  -15
    arc_0_1_2  out_degree_799  1
    arc_0_1_2  in_degree_807  1
    arc_0_1_2  original_T_including_depot_unload_894  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_420  1
    load_0_1_2  segment_load_conservation_803  1
    load_0_1_2  segment_load_conservation_810  -1
    load_0_1_2  segment_prefix_lb_811  1
    load_0_1_2  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_422  -20
    arc_0_1_3  connected_order_arc_423  -15
    arc_0_1_3  out_degree_799  1
    arc_0_1_3  in_degree_814  1
    arc_0_1_3  original_T_including_depot_unload_894  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_422  1
    load_0_1_3  segment_load_conservation_803  1
    load_0_1_3  segment_load_conservation_817  -1
    load_0_1_3  segment_prefix_lb_818  1
    load_0_1_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_424  -20
    arc_0_1_4  connected_order_arc_425  -15
    arc_0_1_4  out_degree_799  1
    arc_0_1_4  in_degree_821  1
    arc_0_1_4  original_T_including_depot_unload_894  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_424  1
    load_0_1_4  segment_load_conservation_803  1
    load_0_1_4  segment_load_conservation_824  -1
    load_0_1_4  segment_prefix_lb_825  1
    load_0_1_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_426  -20
    arc_0_1_5  connected_order_arc_427  -15
    arc_0_1_5  out_degree_799  1
    arc_0_1_5  in_degree_828  1
    arc_0_1_5  original_T_including_depot_unload_894  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_426  1
    load_0_1_5  segment_load_conservation_803  1
    load_0_1_5  segment_load_conservation_831  -1
    load_0_1_5  segment_prefix_lb_832  1
    load_0_1_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_428  -20
    arc_0_1_6  connected_order_arc_429  -15
    arc_0_1_6  out_degree_799  1
    arc_0_1_6  in_degree_835  1
    arc_0_1_6  original_T_including_depot_unload_894  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_428  1
    load_0_1_6  segment_load_conservation_803  1
    load_0_1_6  segment_load_conservation_838  -1
    load_0_1_6  segment_prefix_lb_839  1
    load_0_1_6  segment_prefix_ub_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_430  -20
    arc_0_1_14  connected_order_arc_431  -15
    arc_0_1_14  out_degree_799  1
    arc_0_1_14  in_degree_842  1
    arc_0_1_14  original_T_including_depot_unload_894  634.658635437287
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_430  1
    load_0_1_14  segment_load_conservation_803  1
    load_0_1_14  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_432  -20
    arc_0_1_15  connected_order_arc_433  -15
    arc_0_1_15  out_degree_799  1
    arc_0_1_15  in_degree_848  1
    arc_0_1_15  original_T_including_depot_unload_894  3.4724611547105854e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_432  1
    load_0_1_15  segment_load_conservation_803  1
    load_0_1_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_434  -20
    arc_0_1_16  connected_order_arc_435  -15
    arc_0_1_16  out_degree_799  1
    arc_0_1_16  in_degree_854  1
    arc_0_1_16  original_T_including_depot_unload_894  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_434  1
    load_0_1_16  segment_load_conservation_803  1
    load_0_1_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_436  -20
    arc_0_1_17  connected_order_arc_437  -15
    arc_0_1_17  out_degree_799  1
    arc_0_1_17  in_degree_860  1
    arc_0_1_17  original_T_including_depot_unload_894  5.7164184935040350e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_436  1
    load_0_1_17  segment_load_conservation_803  1
    load_0_1_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_438  -20
    arc_0_1_18  connected_order_arc_439  -15
    arc_0_1_18  out_degree_799  1
    arc_0_1_18  in_degree_866  1
    arc_0_1_18  original_T_including_depot_unload_894  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_438  1
    load_0_1_18  segment_load_conservation_803  1
    load_0_1_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_440  -20
    arc_0_1_19  connected_order_arc_441  -15
    arc_0_1_19  out_degree_799  1
    arc_0_1_19  in_degree_872  1
    arc_0_1_19  original_T_including_depot_unload_894  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_440  1
    load_0_1_19  segment_load_conservation_803  1
    load_0_1_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_442  -20
    arc_0_1_20  connected_order_arc_443  -15
    arc_0_1_20  out_degree_799  1
    arc_0_1_20  in_degree_878  1
    arc_0_1_20  original_T_including_depot_unload_894  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_442  1
    load_0_1_20  segment_load_conservation_803  1
    load_0_1_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_444  -20
    arc_0_1_21  connected_order_arc_445  -15
    arc_0_1_21  out_degree_799  1
    arc_0_1_21  in_degree_884  1
    arc_0_1_21  original_T_including_depot_unload_894  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_444  1
    load_0_1_21  segment_load_conservation_803  1
    load_0_1_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_446  -20
    arc_0_2_0  depot_return_or_bypass_798  1
    arc_0_2_0  out_degree_806  1
    arc_0_2_0  original_T_including_depot_unload_894  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_446  1
    load_0_2_0  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_447  -20
    arc_0_2_1  connected_order_arc_448  -15
    arc_0_2_1  in_degree_800  1
    arc_0_2_1  out_degree_806  1
    arc_0_2_1  original_T_including_depot_unload_894  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_447  1
    load_0_2_1  segment_load_conservation_803  -1
    load_0_2_1  segment_prefix_lb_804  1
    load_0_2_1  segment_prefix_ub_805  1
    load_0_2_1  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_449  -20
    arc_0_2_3  connected_order_arc_450  -15
    arc_0_2_3  out_degree_806  1
    arc_0_2_3  in_degree_814  1
    arc_0_2_3  original_T_including_depot_unload_894  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_449  1
    load_0_2_3  segment_load_conservation_810  1
    load_0_2_3  segment_load_conservation_817  -1
    load_0_2_3  segment_prefix_lb_818  1
    load_0_2_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_451  -20
    arc_0_2_4  connected_order_arc_452  -15
    arc_0_2_4  out_degree_806  1
    arc_0_2_4  in_degree_821  1
    arc_0_2_4  original_T_including_depot_unload_894  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_451  1
    load_0_2_4  segment_load_conservation_810  1
    load_0_2_4  segment_load_conservation_824  -1
    load_0_2_4  segment_prefix_lb_825  1
    load_0_2_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_453  -20
    arc_0_2_5  connected_order_arc_454  -15
    arc_0_2_5  out_degree_806  1
    arc_0_2_5  in_degree_828  1
    arc_0_2_5  original_T_including_depot_unload_894  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_453  1
    load_0_2_5  segment_load_conservation_810  1
    load_0_2_5  segment_load_conservation_831  -1
    load_0_2_5  segment_prefix_lb_832  1
    load_0_2_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_455  -20
    arc_0_2_6  connected_order_arc_456  -15
    arc_0_2_6  out_degree_806  1
    arc_0_2_6  in_degree_835  1
    arc_0_2_6  original_T_including_depot_unload_894  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_455  1
    load_0_2_6  segment_load_conservation_810  1
    load_0_2_6  segment_load_conservation_838  -1
    load_0_2_6  segment_prefix_lb_839  1
    load_0_2_6  segment_prefix_ub_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_457  -20
    arc_0_2_14  connected_order_arc_458  -15
    arc_0_2_14  out_degree_806  1
    arc_0_2_14  in_degree_842  1
    arc_0_2_14  original_T_including_depot_unload_894  6.8151832047278333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_457  1
    load_0_2_14  segment_load_conservation_810  1
    load_0_2_14  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_459  -20
    arc_0_2_15  connected_order_arc_460  -15
    arc_0_2_15  out_degree_806  1
    arc_0_2_15  in_degree_848  1
    arc_0_2_15  original_T_including_depot_unload_894  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_459  1
    load_0_2_15  segment_load_conservation_810  1
    load_0_2_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_461  -20
    arc_0_2_16  connected_order_arc_462  -15
    arc_0_2_16  out_degree_806  1
    arc_0_2_16  in_degree_854  1
    arc_0_2_16  original_T_including_depot_unload_894  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_461  1
    load_0_2_16  segment_load_conservation_810  1
    load_0_2_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_463  -20
    arc_0_2_17  connected_order_arc_464  -15
    arc_0_2_17  out_degree_806  1
    arc_0_2_17  in_degree_860  1
    arc_0_2_17  original_T_including_depot_unload_894  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_463  1
    load_0_2_17  segment_load_conservation_810  1
    load_0_2_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_465  -20
    arc_0_2_18  connected_order_arc_466  -15
    arc_0_2_18  out_degree_806  1
    arc_0_2_18  in_degree_866  1
    arc_0_2_18  original_T_including_depot_unload_894  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_465  1
    load_0_2_18  segment_load_conservation_810  1
    load_0_2_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_467  -20
    arc_0_2_19  connected_order_arc_468  -15
    arc_0_2_19  out_degree_806  1
    arc_0_2_19  in_degree_872  1
    arc_0_2_19  original_T_including_depot_unload_894  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_467  1
    load_0_2_19  segment_load_conservation_810  1
    load_0_2_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_469  -20
    arc_0_2_20  connected_order_arc_470  -15
    arc_0_2_20  out_degree_806  1
    arc_0_2_20  in_degree_878  1
    arc_0_2_20  original_T_including_depot_unload_894  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_469  1
    load_0_2_20  segment_load_conservation_810  1
    load_0_2_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_471  -20
    arc_0_2_21  connected_order_arc_472  -15
    arc_0_2_21  out_degree_806  1
    arc_0_2_21  in_degree_884  1
    arc_0_2_21  original_T_including_depot_unload_894  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_471  1
    load_0_2_21  segment_load_conservation_810  1
    load_0_2_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_473  -20
    arc_0_3_0  depot_return_or_bypass_798  1
    arc_0_3_0  out_degree_813  1
    arc_0_3_0  original_T_including_depot_unload_894  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_473  1
    load_0_3_0  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_474  -20
    arc_0_3_1  connected_order_arc_475  -15
    arc_0_3_1  in_degree_800  1
    arc_0_3_1  out_degree_813  1
    arc_0_3_1  original_T_including_depot_unload_894  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_474  1
    load_0_3_1  segment_load_conservation_803  -1
    load_0_3_1  segment_prefix_lb_804  1
    load_0_3_1  segment_prefix_ub_805  1
    load_0_3_1  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_476  -20
    arc_0_3_2  connected_order_arc_477  -15
    arc_0_3_2  in_degree_807  1
    arc_0_3_2  out_degree_813  1
    arc_0_3_2  original_T_including_depot_unload_894  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_476  1
    load_0_3_2  segment_load_conservation_810  -1
    load_0_3_2  segment_prefix_lb_811  1
    load_0_3_2  segment_prefix_ub_812  1
    load_0_3_2  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_478  -20
    arc_0_3_4  connected_order_arc_479  -15
    arc_0_3_4  out_degree_813  1
    arc_0_3_4  in_degree_821  1
    arc_0_3_4  original_T_including_depot_unload_894  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_478  1
    load_0_3_4  segment_load_conservation_817  1
    load_0_3_4  segment_load_conservation_824  -1
    load_0_3_4  segment_prefix_lb_825  1
    load_0_3_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_480  -20
    arc_0_3_5  connected_order_arc_481  -15
    arc_0_3_5  out_degree_813  1
    arc_0_3_5  in_degree_828  1
    arc_0_3_5  original_T_including_depot_unload_894  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_480  1
    load_0_3_5  segment_load_conservation_817  1
    load_0_3_5  segment_load_conservation_831  -1
    load_0_3_5  segment_prefix_lb_832  1
    load_0_3_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_482  -20
    arc_0_3_6  connected_order_arc_483  -15
    arc_0_3_6  out_degree_813  1
    arc_0_3_6  in_degree_835  1
    arc_0_3_6  original_T_including_depot_unload_894  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_482  1
    load_0_3_6  segment_load_conservation_817  1
    load_0_3_6  segment_load_conservation_838  -1
    load_0_3_6  segment_prefix_lb_839  1
    load_0_3_6  segment_prefix_ub_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_484  -20
    arc_0_3_14  connected_order_arc_485  -15
    arc_0_3_14  out_degree_813  1
    arc_0_3_14  in_degree_842  1
    arc_0_3_14  original_T_including_depot_unload_894  7.0547985627601940e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_484  1
    load_0_3_14  segment_load_conservation_817  1
    load_0_3_14  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_486  -20
    arc_0_3_15  connected_order_arc_487  -15
    arc_0_3_15  out_degree_813  1
    arc_0_3_15  in_degree_848  1
    arc_0_3_15  original_T_including_depot_unload_894  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_486  1
    load_0_3_15  segment_load_conservation_817  1
    load_0_3_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_488  -20
    arc_0_3_16  connected_order_arc_489  -15
    arc_0_3_16  out_degree_813  1
    arc_0_3_16  in_degree_854  1
    arc_0_3_16  original_T_including_depot_unload_894  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_488  1
    load_0_3_16  segment_load_conservation_817  1
    load_0_3_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_490  -20
    arc_0_3_17  connected_order_arc_491  -15
    arc_0_3_17  out_degree_813  1
    arc_0_3_17  in_degree_860  1
    arc_0_3_17  original_T_including_depot_unload_894  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_490  1
    load_0_3_17  segment_load_conservation_817  1
    load_0_3_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_492  -20
    arc_0_3_18  connected_order_arc_493  -15
    arc_0_3_18  out_degree_813  1
    arc_0_3_18  in_degree_866  1
    arc_0_3_18  original_T_including_depot_unload_894  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_492  1
    load_0_3_18  segment_load_conservation_817  1
    load_0_3_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_494  -20
    arc_0_3_19  connected_order_arc_495  -15
    arc_0_3_19  out_degree_813  1
    arc_0_3_19  in_degree_872  1
    arc_0_3_19  original_T_including_depot_unload_894  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_494  1
    load_0_3_19  segment_load_conservation_817  1
    load_0_3_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_496  -20
    arc_0_3_20  connected_order_arc_497  -15
    arc_0_3_20  out_degree_813  1
    arc_0_3_20  in_degree_878  1
    arc_0_3_20  original_T_including_depot_unload_894  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_496  1
    load_0_3_20  segment_load_conservation_817  1
    load_0_3_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_498  -20
    arc_0_3_21  connected_order_arc_499  -15
    arc_0_3_21  out_degree_813  1
    arc_0_3_21  in_degree_884  1
    arc_0_3_21  original_T_including_depot_unload_894  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_498  1
    load_0_3_21  segment_load_conservation_817  1
    load_0_3_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_500  -20
    arc_0_4_0  depot_return_or_bypass_798  1
    arc_0_4_0  out_degree_820  1
    arc_0_4_0  original_T_including_depot_unload_894  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_500  1
    load_0_4_0  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_501  -20
    arc_0_4_1  connected_order_arc_502  -15
    arc_0_4_1  in_degree_800  1
    arc_0_4_1  out_degree_820  1
    arc_0_4_1  original_T_including_depot_unload_894  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_501  1
    load_0_4_1  segment_load_conservation_803  -1
    load_0_4_1  segment_prefix_lb_804  1
    load_0_4_1  segment_prefix_ub_805  1
    load_0_4_1  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_503  -20
    arc_0_4_2  connected_order_arc_504  -15
    arc_0_4_2  in_degree_807  1
    arc_0_4_2  out_degree_820  1
    arc_0_4_2  original_T_including_depot_unload_894  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_503  1
    load_0_4_2  segment_load_conservation_810  -1
    load_0_4_2  segment_prefix_lb_811  1
    load_0_4_2  segment_prefix_ub_812  1
    load_0_4_2  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_505  -20
    arc_0_4_3  connected_order_arc_506  -15
    arc_0_4_3  in_degree_814  1
    arc_0_4_3  out_degree_820  1
    arc_0_4_3  original_T_including_depot_unload_894  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_505  1
    load_0_4_3  segment_load_conservation_817  -1
    load_0_4_3  segment_prefix_lb_818  1
    load_0_4_3  segment_prefix_ub_819  1
    load_0_4_3  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_507  -20
    arc_0_4_5  connected_order_arc_508  -15
    arc_0_4_5  out_degree_820  1
    arc_0_4_5  in_degree_828  1
    arc_0_4_5  original_T_including_depot_unload_894  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_507  1
    load_0_4_5  segment_load_conservation_824  1
    load_0_4_5  segment_load_conservation_831  -1
    load_0_4_5  segment_prefix_lb_832  1
    load_0_4_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_509  -20
    arc_0_4_6  connected_order_arc_510  -15
    arc_0_4_6  out_degree_820  1
    arc_0_4_6  in_degree_835  1
    arc_0_4_6  original_T_including_depot_unload_894  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_509  1
    load_0_4_6  segment_load_conservation_824  1
    load_0_4_6  segment_load_conservation_838  -1
    load_0_4_6  segment_prefix_lb_839  1
    load_0_4_6  segment_prefix_ub_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_511  -20
    arc_0_4_14  connected_order_arc_512  -15
    arc_0_4_14  out_degree_820  1
    arc_0_4_14  in_degree_842  1
    arc_0_4_14  original_T_including_depot_unload_894  8.5386479957462541e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_511  1
    load_0_4_14  segment_load_conservation_824  1
    load_0_4_14  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_513  -20
    arc_0_4_15  connected_order_arc_514  -15
    arc_0_4_15  out_degree_820  1
    arc_0_4_15  in_degree_848  1
    arc_0_4_15  original_T_including_depot_unload_894  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_513  1
    load_0_4_15  segment_load_conservation_824  1
    load_0_4_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_515  -20
    arc_0_4_16  connected_order_arc_516  -15
    arc_0_4_16  out_degree_820  1
    arc_0_4_16  in_degree_854  1
    arc_0_4_16  original_T_including_depot_unload_894  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_515  1
    load_0_4_16  segment_load_conservation_824  1
    load_0_4_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_517  -20
    arc_0_4_17  connected_order_arc_518  -15
    arc_0_4_17  out_degree_820  1
    arc_0_4_17  in_degree_860  1
    arc_0_4_17  original_T_including_depot_unload_894  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_517  1
    load_0_4_17  segment_load_conservation_824  1
    load_0_4_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_519  -20
    arc_0_4_18  connected_order_arc_520  -15
    arc_0_4_18  out_degree_820  1
    arc_0_4_18  in_degree_866  1
    arc_0_4_18  original_T_including_depot_unload_894  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_519  1
    load_0_4_18  segment_load_conservation_824  1
    load_0_4_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_521  -20
    arc_0_4_19  connected_order_arc_522  -15
    arc_0_4_19  out_degree_820  1
    arc_0_4_19  in_degree_872  1
    arc_0_4_19  original_T_including_depot_unload_894  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_521  1
    load_0_4_19  segment_load_conservation_824  1
    load_0_4_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_523  -20
    arc_0_4_20  connected_order_arc_524  -15
    arc_0_4_20  out_degree_820  1
    arc_0_4_20  in_degree_878  1
    arc_0_4_20  original_T_including_depot_unload_894  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_523  1
    load_0_4_20  segment_load_conservation_824  1
    load_0_4_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_525  -20
    arc_0_4_21  connected_order_arc_526  -15
    arc_0_4_21  out_degree_820  1
    arc_0_4_21  in_degree_884  1
    arc_0_4_21  original_T_including_depot_unload_894  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_525  1
    load_0_4_21  segment_load_conservation_824  1
    load_0_4_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_527  -20
    arc_0_5_0  depot_return_or_bypass_798  1
    arc_0_5_0  out_degree_827  1
    arc_0_5_0  original_T_including_depot_unload_894  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_527  1
    load_0_5_0  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_528  -20
    arc_0_5_1  connected_order_arc_529  -15
    arc_0_5_1  in_degree_800  1
    arc_0_5_1  out_degree_827  1
    arc_0_5_1  original_T_including_depot_unload_894  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_528  1
    load_0_5_1  segment_load_conservation_803  -1
    load_0_5_1  segment_prefix_lb_804  1
    load_0_5_1  segment_prefix_ub_805  1
    load_0_5_1  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_530  -20
    arc_0_5_2  connected_order_arc_531  -15
    arc_0_5_2  in_degree_807  1
    arc_0_5_2  out_degree_827  1
    arc_0_5_2  original_T_including_depot_unload_894  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_530  1
    load_0_5_2  segment_load_conservation_810  -1
    load_0_5_2  segment_prefix_lb_811  1
    load_0_5_2  segment_prefix_ub_812  1
    load_0_5_2  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_532  -20
    arc_0_5_3  connected_order_arc_533  -15
    arc_0_5_3  in_degree_814  1
    arc_0_5_3  out_degree_827  1
    arc_0_5_3  original_T_including_depot_unload_894  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_532  1
    load_0_5_3  segment_load_conservation_817  -1
    load_0_5_3  segment_prefix_lb_818  1
    load_0_5_3  segment_prefix_ub_819  1
    load_0_5_3  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_534  -20
    arc_0_5_4  connected_order_arc_535  -15
    arc_0_5_4  in_degree_821  1
    arc_0_5_4  out_degree_827  1
    arc_0_5_4  original_T_including_depot_unload_894  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_534  1
    load_0_5_4  segment_load_conservation_824  -1
    load_0_5_4  segment_prefix_lb_825  1
    load_0_5_4  segment_prefix_ub_826  1
    load_0_5_4  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_536  -20
    arc_0_5_6  connected_order_arc_537  -15
    arc_0_5_6  out_degree_827  1
    arc_0_5_6  in_degree_835  1
    arc_0_5_6  original_T_including_depot_unload_894  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_536  1
    load_0_5_6  segment_load_conservation_831  1
    load_0_5_6  segment_load_conservation_838  -1
    load_0_5_6  segment_prefix_lb_839  1
    load_0_5_6  segment_prefix_ub_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_538  -20
    arc_0_5_14  connected_order_arc_539  -15
    arc_0_5_14  out_degree_827  1
    arc_0_5_14  in_degree_842  1
    arc_0_5_14  original_T_including_depot_unload_894  7.4895433191723123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_538  1
    load_0_5_14  segment_load_conservation_831  1
    load_0_5_14  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_540  -20
    arc_0_5_15  connected_order_arc_541  -15
    arc_0_5_15  out_degree_827  1
    arc_0_5_15  in_degree_848  1
    arc_0_5_15  original_T_including_depot_unload_894  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_540  1
    load_0_5_15  segment_load_conservation_831  1
    load_0_5_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_542  -20
    arc_0_5_16  connected_order_arc_543  -15
    arc_0_5_16  out_degree_827  1
    arc_0_5_16  in_degree_854  1
    arc_0_5_16  original_T_including_depot_unload_894  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_542  1
    load_0_5_16  segment_load_conservation_831  1
    load_0_5_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_544  -20
    arc_0_5_17  connected_order_arc_545  -15
    arc_0_5_17  out_degree_827  1
    arc_0_5_17  in_degree_860  1
    arc_0_5_17  original_T_including_depot_unload_894  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_544  1
    load_0_5_17  segment_load_conservation_831  1
    load_0_5_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_546  -20
    arc_0_5_18  connected_order_arc_547  -15
    arc_0_5_18  out_degree_827  1
    arc_0_5_18  in_degree_866  1
    arc_0_5_18  original_T_including_depot_unload_894  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_546  1
    load_0_5_18  segment_load_conservation_831  1
    load_0_5_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_548  -20
    arc_0_5_19  connected_order_arc_549  -15
    arc_0_5_19  out_degree_827  1
    arc_0_5_19  in_degree_872  1
    arc_0_5_19  original_T_including_depot_unload_894  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_548  1
    load_0_5_19  segment_load_conservation_831  1
    load_0_5_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_550  -20
    arc_0_5_20  connected_order_arc_551  -15
    arc_0_5_20  out_degree_827  1
    arc_0_5_20  in_degree_878  1
    arc_0_5_20  original_T_including_depot_unload_894  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_550  1
    load_0_5_20  segment_load_conservation_831  1
    load_0_5_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_552  -20
    arc_0_5_21  connected_order_arc_553  -15
    arc_0_5_21  out_degree_827  1
    arc_0_5_21  in_degree_884  1
    arc_0_5_21  original_T_including_depot_unload_894  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_552  1
    load_0_5_21  segment_load_conservation_831  1
    load_0_5_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_554  -20
    arc_0_6_0  depot_return_or_bypass_798  1
    arc_0_6_0  out_degree_834  1
    arc_0_6_0  original_T_including_depot_unload_894  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_554  1
    load_0_6_0  segment_load_conservation_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_555  -20
    arc_0_6_1  connected_order_arc_556  -15
    arc_0_6_1  in_degree_800  1
    arc_0_6_1  out_degree_834  1
    arc_0_6_1  original_T_including_depot_unload_894  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_555  1
    load_0_6_1  segment_load_conservation_803  -1
    load_0_6_1  segment_prefix_lb_804  1
    load_0_6_1  segment_prefix_ub_805  1
    load_0_6_1  segment_load_conservation_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_557  -20
    arc_0_6_2  connected_order_arc_558  -15
    arc_0_6_2  in_degree_807  1
    arc_0_6_2  out_degree_834  1
    arc_0_6_2  original_T_including_depot_unload_894  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_557  1
    load_0_6_2  segment_load_conservation_810  -1
    load_0_6_2  segment_prefix_lb_811  1
    load_0_6_2  segment_prefix_ub_812  1
    load_0_6_2  segment_load_conservation_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_559  -20
    arc_0_6_3  connected_order_arc_560  -15
    arc_0_6_3  in_degree_814  1
    arc_0_6_3  out_degree_834  1
    arc_0_6_3  original_T_including_depot_unload_894  1035.83277530205
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_559  1
    load_0_6_3  segment_load_conservation_817  -1
    load_0_6_3  segment_prefix_lb_818  1
    load_0_6_3  segment_prefix_ub_819  1
    load_0_6_3  segment_load_conservation_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_561  -20
    arc_0_6_4  connected_order_arc_562  -15
    arc_0_6_4  in_degree_821  1
    arc_0_6_4  out_degree_834  1
    arc_0_6_4  original_T_including_depot_unload_894  1.2450286067313011e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_561  1
    load_0_6_4  segment_load_conservation_824  -1
    load_0_6_4  segment_prefix_lb_825  1
    load_0_6_4  segment_prefix_ub_826  1
    load_0_6_4  segment_load_conservation_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_563  -20
    arc_0_6_5  connected_order_arc_564  -15
    arc_0_6_5  in_degree_828  1
    arc_0_6_5  out_degree_834  1
    arc_0_6_5  original_T_including_depot_unload_894  1.3663551195332984e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_563  1
    load_0_6_5  segment_load_conservation_831  -1
    load_0_6_5  segment_prefix_lb_832  1
    load_0_6_5  segment_prefix_ub_833  1
    load_0_6_5  segment_load_conservation_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_565  -20
    arc_0_6_14  connected_order_arc_566  -15
    arc_0_6_14  out_degree_834  1
    arc_0_6_14  in_degree_842  1
    arc_0_6_14  original_T_including_depot_unload_894  1.0738353745204206e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_565  1
    load_0_6_14  segment_load_conservation_838  1
    load_0_6_14  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_567  -20
    arc_0_6_15  connected_order_arc_568  -15
    arc_0_6_15  out_degree_834  1
    arc_0_6_15  in_degree_848  1
    arc_0_6_15  original_T_including_depot_unload_894  8.4865162627289658e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_567  1
    load_0_6_15  segment_load_conservation_838  1
    load_0_6_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_569  -20
    arc_0_6_16  connected_order_arc_570  -15
    arc_0_6_16  out_degree_834  1
    arc_0_6_16  in_degree_854  1
    arc_0_6_16  original_T_including_depot_unload_894  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_569  1
    load_0_6_16  segment_load_conservation_838  1
    load_0_6_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_571  -20
    arc_0_6_17  connected_order_arc_572  -15
    arc_0_6_17  out_degree_834  1
    arc_0_6_17  in_degree_860  1
    arc_0_6_17  original_T_including_depot_unload_894  7.2196448570394080e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_571  1
    load_0_6_17  segment_load_conservation_838  1
    load_0_6_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_573  -20
    arc_0_6_18  connected_order_arc_574  -15
    arc_0_6_18  out_degree_834  1
    arc_0_6_18  in_degree_866  1
    arc_0_6_18  original_T_including_depot_unload_894  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_573  1
    load_0_6_18  segment_load_conservation_838  1
    load_0_6_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_575  -20
    arc_0_6_19  connected_order_arc_576  -15
    arc_0_6_19  out_degree_834  1
    arc_0_6_19  in_degree_872  1
    arc_0_6_19  original_T_including_depot_unload_894  1.1516424799836650e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_575  1
    load_0_6_19  segment_load_conservation_838  1
    load_0_6_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_577  -20
    arc_0_6_20  connected_order_arc_578  -15
    arc_0_6_20  out_degree_834  1
    arc_0_6_20  in_degree_878  1
    arc_0_6_20  original_T_including_depot_unload_894  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_577  1
    load_0_6_20  segment_load_conservation_838  1
    load_0_6_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_579  -20
    arc_0_6_21  connected_order_arc_580  -15
    arc_0_6_21  out_degree_834  1
    arc_0_6_21  in_degree_884  1
    arc_0_6_21  original_T_including_depot_unload_894  1.1301442107738828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_579  1
    load_0_6_21  segment_load_conservation_838  1
    load_0_6_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_581  -20
    arc_0_14_0  depot_return_or_bypass_798  1
    arc_0_14_0  out_degree_841  1
    arc_0_14_0  original_T_including_depot_unload_894  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_581  1
    load_0_14_0  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_582  -20
    arc_0_14_1  connected_order_arc_583  -15
    arc_0_14_1  in_degree_800  1
    arc_0_14_1  out_degree_841  1
    arc_0_14_1  original_T_including_depot_unload_894  634.778043158074
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_582  1
    load_0_14_1  segment_load_conservation_803  -1
    load_0_14_1  segment_prefix_lb_804  1
    load_0_14_1  segment_prefix_ub_805  1
    load_0_14_1  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_584  -20
    arc_0_14_2  connected_order_arc_585  -15
    arc_0_14_2  in_degree_807  1
    arc_0_14_2  out_degree_841  1
    arc_0_14_2  original_T_including_depot_unload_894  6.8151832047278333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_584  1
    load_0_14_2  segment_load_conservation_810  -1
    load_0_14_2  segment_prefix_lb_811  1
    load_0_14_2  segment_prefix_ub_812  1
    load_0_14_2  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_586  -20
    arc_0_14_3  connected_order_arc_587  -15
    arc_0_14_3  in_degree_814  1
    arc_0_14_3  out_degree_841  1
    arc_0_14_3  original_T_including_depot_unload_894  7.0547985627601940e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_586  1
    load_0_14_3  segment_load_conservation_817  -1
    load_0_14_3  segment_prefix_lb_818  1
    load_0_14_3  segment_prefix_ub_819  1
    load_0_14_3  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_588  -20
    arc_0_14_4  connected_order_arc_589  -15
    arc_0_14_4  in_degree_821  1
    arc_0_14_4  out_degree_841  1
    arc_0_14_4  original_T_including_depot_unload_894  8.5386479957462541e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_588  1
    load_0_14_4  segment_load_conservation_824  -1
    load_0_14_4  segment_prefix_lb_825  1
    load_0_14_4  segment_prefix_ub_826  1
    load_0_14_4  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_590  -20
    arc_0_14_5  connected_order_arc_591  -15
    arc_0_14_5  in_degree_828  1
    arc_0_14_5  out_degree_841  1
    arc_0_14_5  original_T_including_depot_unload_894  7.4895433191723123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_590  1
    load_0_14_5  segment_load_conservation_831  -1
    load_0_14_5  segment_prefix_lb_832  1
    load_0_14_5  segment_prefix_ub_833  1
    load_0_14_5  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_592  -20
    arc_0_14_6  connected_order_arc_593  -15
    arc_0_14_6  in_degree_835  1
    arc_0_14_6  out_degree_841  1
    arc_0_14_6  original_T_including_depot_unload_894  6.7008394119213415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_592  1
    load_0_14_6  segment_load_conservation_838  -1
    load_0_14_6  segment_prefix_lb_839  1
    load_0_14_6  segment_prefix_ub_840  1
    load_0_14_6  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_594  -20
    arc_0_14_15  connected_order_arc_595  -15
    arc_0_14_15  out_degree_841  1
    arc_0_14_15  in_degree_848  1
    arc_0_14_15  original_T_including_depot_unload_894  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_594  1
    load_0_14_15  free_load_conservation_846  1
    load_0_14_15  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_596  -20
    arc_0_14_16  connected_order_arc_597  -15
    arc_0_14_16  out_degree_841  1
    arc_0_14_16  in_degree_854  1
    arc_0_14_16  original_T_including_depot_unload_894  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_596  1
    load_0_14_16  free_load_conservation_846  1
    load_0_14_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_598  -20
    arc_0_14_17  connected_order_arc_599  -15
    arc_0_14_17  out_degree_841  1
    arc_0_14_17  in_degree_860  1
    arc_0_14_17  original_T_including_depot_unload_894  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_598  1
    load_0_14_17  free_load_conservation_846  1
    load_0_14_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_600  -20
    arc_0_14_18  connected_order_arc_601  -15
    arc_0_14_18  out_degree_841  1
    arc_0_14_18  in_degree_866  1
    arc_0_14_18  original_T_including_depot_unload_894  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_600  1
    load_0_14_18  free_load_conservation_846  1
    load_0_14_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_602  -20
    arc_0_14_19  connected_order_arc_603  -15
    arc_0_14_19  out_degree_841  1
    arc_0_14_19  in_degree_872  1
    arc_0_14_19  original_T_including_depot_unload_894  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_602  1
    load_0_14_19  free_load_conservation_846  1
    load_0_14_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_604  -20
    arc_0_14_20  connected_order_arc_605  -15
    arc_0_14_20  out_degree_841  1
    arc_0_14_20  in_degree_878  1
    arc_0_14_20  original_T_including_depot_unload_894  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_604  1
    load_0_14_20  free_load_conservation_846  1
    load_0_14_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_606  -20
    arc_0_14_21  connected_order_arc_607  -15
    arc_0_14_21  out_degree_841  1
    arc_0_14_21  in_degree_884  1
    arc_0_14_21  original_T_including_depot_unload_894  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_606  1
    load_0_14_21  free_load_conservation_846  1
    load_0_14_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_608  -20
    arc_0_15_0  depot_return_or_bypass_798  1
    arc_0_15_0  out_degree_847  1
    arc_0_15_0  original_T_including_depot_unload_894  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_608  1
    load_0_15_0  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_609  -20
    arc_0_15_1  connected_order_arc_610  -15
    arc_0_15_1  in_degree_800  1
    arc_0_15_1  out_degree_847  1
    arc_0_15_1  original_T_including_depot_unload_894  3.4726967782722494e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_609  1
    load_0_15_1  segment_load_conservation_803  -1
    load_0_15_1  segment_prefix_lb_804  1
    load_0_15_1  segment_prefix_ub_805  1
    load_0_15_1  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_611  -20
    arc_0_15_2  connected_order_arc_612  -15
    arc_0_15_2  in_degree_807  1
    arc_0_15_2  out_degree_847  1
    arc_0_15_2  original_T_including_depot_unload_894  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_611  1
    load_0_15_2  segment_load_conservation_810  -1
    load_0_15_2  segment_prefix_lb_811  1
    load_0_15_2  segment_prefix_ub_812  1
    load_0_15_2  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_613  -20
    arc_0_15_3  connected_order_arc_614  -15
    arc_0_15_3  in_degree_814  1
    arc_0_15_3  out_degree_847  1
    arc_0_15_3  original_T_including_depot_unload_894  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_613  1
    load_0_15_3  segment_load_conservation_817  -1
    load_0_15_3  segment_prefix_lb_818  1
    load_0_15_3  segment_prefix_ub_819  1
    load_0_15_3  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_615  -20
    arc_0_15_4  connected_order_arc_616  -15
    arc_0_15_4  in_degree_821  1
    arc_0_15_4  out_degree_847  1
    arc_0_15_4  original_T_including_depot_unload_894  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_615  1
    load_0_15_4  segment_load_conservation_824  -1
    load_0_15_4  segment_prefix_lb_825  1
    load_0_15_4  segment_prefix_ub_826  1
    load_0_15_4  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_617  -20
    arc_0_15_5  connected_order_arc_618  -15
    arc_0_15_5  in_degree_828  1
    arc_0_15_5  out_degree_847  1
    arc_0_15_5  original_T_including_depot_unload_894  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_617  1
    load_0_15_5  segment_load_conservation_831  -1
    load_0_15_5  segment_prefix_lb_832  1
    load_0_15_5  segment_prefix_ub_833  1
    load_0_15_5  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_619  -20
    arc_0_15_6  connected_order_arc_620  -15
    arc_0_15_6  in_degree_835  1
    arc_0_15_6  out_degree_847  1
    arc_0_15_6  original_T_including_depot_unload_894  3.8231967210987659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_619  1
    load_0_15_6  segment_load_conservation_838  -1
    load_0_15_6  segment_prefix_lb_839  1
    load_0_15_6  segment_prefix_ub_840  1
    load_0_15_6  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_621  -20
    arc_0_15_14  connected_order_arc_622  -15
    arc_0_15_14  in_degree_842  1
    arc_0_15_14  out_degree_847  1
    arc_0_15_14  original_T_including_depot_unload_894  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_621  1
    load_0_15_14  free_load_conservation_846  -1
    load_0_15_14  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_623  -20
    arc_0_15_16  connected_order_arc_624  -15
    arc_0_15_16  out_degree_847  1
    arc_0_15_16  in_degree_854  1
    arc_0_15_16  original_T_including_depot_unload_894  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_623  1
    load_0_15_16  free_load_conservation_852  1
    load_0_15_16  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_625  -20
    arc_0_15_17  connected_order_arc_626  -15
    arc_0_15_17  out_degree_847  1
    arc_0_15_17  in_degree_860  1
    arc_0_15_17  original_T_including_depot_unload_894  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_625  1
    load_0_15_17  free_load_conservation_852  1
    load_0_15_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_627  -20
    arc_0_15_18  connected_order_arc_628  -15
    arc_0_15_18  out_degree_847  1
    arc_0_15_18  in_degree_866  1
    arc_0_15_18  original_T_including_depot_unload_894  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_627  1
    load_0_15_18  free_load_conservation_852  1
    load_0_15_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_629  -20
    arc_0_15_19  connected_order_arc_630  -15
    arc_0_15_19  out_degree_847  1
    arc_0_15_19  in_degree_872  1
    arc_0_15_19  original_T_including_depot_unload_894  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_629  1
    load_0_15_19  free_load_conservation_852  1
    load_0_15_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_631  -20
    arc_0_15_20  connected_order_arc_632  -15
    arc_0_15_20  out_degree_847  1
    arc_0_15_20  in_degree_878  1
    arc_0_15_20  original_T_including_depot_unload_894  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_631  1
    load_0_15_20  free_load_conservation_852  1
    load_0_15_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_633  -20
    arc_0_15_21  connected_order_arc_634  -15
    arc_0_15_21  out_degree_847  1
    arc_0_15_21  in_degree_884  1
    arc_0_15_21  original_T_including_depot_unload_894  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_633  1
    load_0_15_21  free_load_conservation_852  1
    load_0_15_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_635  -20
    arc_0_16_0  depot_return_or_bypass_798  1
    arc_0_16_0  out_degree_853  1
    arc_0_16_0  original_T_including_depot_unload_894  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_635  1
    load_0_16_0  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_636  -20
    arc_0_16_1  connected_order_arc_637  -15
    arc_0_16_1  in_degree_800  1
    arc_0_16_1  out_degree_853  1
    arc_0_16_1  original_T_including_depot_unload_894  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_636  1
    load_0_16_1  segment_load_conservation_803  -1
    load_0_16_1  segment_prefix_lb_804  1
    load_0_16_1  segment_prefix_ub_805  1
    load_0_16_1  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_638  -20
    arc_0_16_2  connected_order_arc_639  -15
    arc_0_16_2  in_degree_807  1
    arc_0_16_2  out_degree_853  1
    arc_0_16_2  original_T_including_depot_unload_894  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_638  1
    load_0_16_2  segment_load_conservation_810  -1
    load_0_16_2  segment_prefix_lb_811  1
    load_0_16_2  segment_prefix_ub_812  1
    load_0_16_2  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_640  -20
    arc_0_16_3  connected_order_arc_641  -15
    arc_0_16_3  in_degree_814  1
    arc_0_16_3  out_degree_853  1
    arc_0_16_3  original_T_including_depot_unload_894  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_640  1
    load_0_16_3  segment_load_conservation_817  -1
    load_0_16_3  segment_prefix_lb_818  1
    load_0_16_3  segment_prefix_ub_819  1
    load_0_16_3  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_642  -20
    arc_0_16_4  connected_order_arc_643  -15
    arc_0_16_4  in_degree_821  1
    arc_0_16_4  out_degree_853  1
    arc_0_16_4  original_T_including_depot_unload_894  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_642  1
    load_0_16_4  segment_load_conservation_824  -1
    load_0_16_4  segment_prefix_lb_825  1
    load_0_16_4  segment_prefix_ub_826  1
    load_0_16_4  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_644  -20
    arc_0_16_5  connected_order_arc_645  -15
    arc_0_16_5  in_degree_828  1
    arc_0_16_5  out_degree_853  1
    arc_0_16_5  original_T_including_depot_unload_894  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_644  1
    load_0_16_5  segment_load_conservation_831  -1
    load_0_16_5  segment_prefix_lb_832  1
    load_0_16_5  segment_prefix_ub_833  1
    load_0_16_5  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_646  -20
    arc_0_16_6  connected_order_arc_647  -15
    arc_0_16_6  in_degree_835  1
    arc_0_16_6  out_degree_853  1
    arc_0_16_6  original_T_including_depot_unload_894  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_646  1
    load_0_16_6  segment_load_conservation_838  -1
    load_0_16_6  segment_prefix_lb_839  1
    load_0_16_6  segment_prefix_ub_840  1
    load_0_16_6  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_648  -20
    arc_0_16_14  connected_order_arc_649  -15
    arc_0_16_14  in_degree_842  1
    arc_0_16_14  out_degree_853  1
    arc_0_16_14  original_T_including_depot_unload_894  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_648  1
    load_0_16_14  free_load_conservation_846  -1
    load_0_16_14  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_650  -20
    arc_0_16_15  connected_order_arc_651  -15
    arc_0_16_15  in_degree_848  1
    arc_0_16_15  out_degree_853  1
    arc_0_16_15  original_T_including_depot_unload_894  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_650  1
    load_0_16_15  free_load_conservation_852  -1
    load_0_16_15  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_652  -20
    arc_0_16_17  connected_order_arc_653  -15
    arc_0_16_17  out_degree_853  1
    arc_0_16_17  in_degree_860  1
    arc_0_16_17  original_T_including_depot_unload_894  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_652  1
    load_0_16_17  free_load_conservation_858  1
    load_0_16_17  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_654  -20
    arc_0_16_18  connected_order_arc_655  -15
    arc_0_16_18  out_degree_853  1
    arc_0_16_18  in_degree_866  1
    arc_0_16_18  original_T_including_depot_unload_894  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_654  1
    load_0_16_18  free_load_conservation_858  1
    load_0_16_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_656  -20
    arc_0_16_19  connected_order_arc_657  -15
    arc_0_16_19  out_degree_853  1
    arc_0_16_19  in_degree_872  1
    arc_0_16_19  original_T_including_depot_unload_894  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_656  1
    load_0_16_19  free_load_conservation_858  1
    load_0_16_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_658  -20
    arc_0_16_20  connected_order_arc_659  -15
    arc_0_16_20  out_degree_853  1
    arc_0_16_20  in_degree_878  1
    arc_0_16_20  original_T_including_depot_unload_894  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_658  1
    load_0_16_20  free_load_conservation_858  1
    load_0_16_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_660  -20
    arc_0_16_21  connected_order_arc_661  -15
    arc_0_16_21  out_degree_853  1
    arc_0_16_21  in_degree_884  1
    arc_0_16_21  original_T_including_depot_unload_894  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_660  1
    load_0_16_21  free_load_conservation_858  1
    load_0_16_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_662  -20
    arc_0_17_0  depot_return_or_bypass_798  1
    arc_0_17_0  out_degree_859  1
    arc_0_17_0  original_T_including_depot_unload_894  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_662  1
    load_0_17_0  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_663  -20
    arc_0_17_1  connected_order_arc_664  -15
    arc_0_17_1  in_degree_800  1
    arc_0_17_1  out_degree_859  1
    arc_0_17_1  original_T_including_depot_unload_894  5.7138137092491206e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_663  1
    load_0_17_1  segment_load_conservation_803  -1
    load_0_17_1  segment_prefix_lb_804  1
    load_0_17_1  segment_prefix_ub_805  1
    load_0_17_1  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_665  -20
    arc_0_17_2  connected_order_arc_666  -15
    arc_0_17_2  in_degree_807  1
    arc_0_17_2  out_degree_859  1
    arc_0_17_2  original_T_including_depot_unload_894  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_665  1
    load_0_17_2  segment_load_conservation_810  -1
    load_0_17_2  segment_prefix_lb_811  1
    load_0_17_2  segment_prefix_ub_812  1
    load_0_17_2  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_667  -20
    arc_0_17_3  connected_order_arc_668  -15
    arc_0_17_3  in_degree_814  1
    arc_0_17_3  out_degree_859  1
    arc_0_17_3  original_T_including_depot_unload_894  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_667  1
    load_0_17_3  segment_load_conservation_817  -1
    load_0_17_3  segment_prefix_lb_818  1
    load_0_17_3  segment_prefix_ub_819  1
    load_0_17_3  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_669  -20
    arc_0_17_4  connected_order_arc_670  -15
    arc_0_17_4  in_degree_821  1
    arc_0_17_4  out_degree_859  1
    arc_0_17_4  original_T_including_depot_unload_894  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_669  1
    load_0_17_4  segment_load_conservation_824  -1
    load_0_17_4  segment_prefix_lb_825  1
    load_0_17_4  segment_prefix_ub_826  1
    load_0_17_4  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_671  -20
    arc_0_17_5  connected_order_arc_672  -15
    arc_0_17_5  in_degree_828  1
    arc_0_17_5  out_degree_859  1
    arc_0_17_5  original_T_including_depot_unload_894  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_671  1
    load_0_17_5  segment_load_conservation_831  -1
    load_0_17_5  segment_prefix_lb_832  1
    load_0_17_5  segment_prefix_ub_833  1
    load_0_17_5  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_673  -20
    arc_0_17_6  connected_order_arc_674  -15
    arc_0_17_6  in_degree_835  1
    arc_0_17_6  out_degree_859  1
    arc_0_17_6  original_T_including_depot_unload_894  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_673  1
    load_0_17_6  segment_load_conservation_838  -1
    load_0_17_6  segment_prefix_lb_839  1
    load_0_17_6  segment_prefix_ub_840  1
    load_0_17_6  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_675  -20
    arc_0_17_14  connected_order_arc_676  -15
    arc_0_17_14  in_degree_842  1
    arc_0_17_14  out_degree_859  1
    arc_0_17_14  original_T_including_depot_unload_894  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_675  1
    load_0_17_14  free_load_conservation_846  -1
    load_0_17_14  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_677  -20
    arc_0_17_15  connected_order_arc_678  -15
    arc_0_17_15  in_degree_848  1
    arc_0_17_15  out_degree_859  1
    arc_0_17_15  original_T_including_depot_unload_894  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_677  1
    load_0_17_15  free_load_conservation_852  -1
    load_0_17_15  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_679  -20
    arc_0_17_16  connected_order_arc_680  -15
    arc_0_17_16  in_degree_854  1
    arc_0_17_16  out_degree_859  1
    arc_0_17_16  original_T_including_depot_unload_894  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_679  1
    load_0_17_16  free_load_conservation_858  -1
    load_0_17_16  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_681  -20
    arc_0_17_18  connected_order_arc_682  -15
    arc_0_17_18  out_degree_859  1
    arc_0_17_18  in_degree_866  1
    arc_0_17_18  original_T_including_depot_unload_894  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_681  1
    load_0_17_18  free_load_conservation_864  1
    load_0_17_18  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_683  -20
    arc_0_17_19  connected_order_arc_684  -15
    arc_0_17_19  out_degree_859  1
    arc_0_17_19  in_degree_872  1
    arc_0_17_19  original_T_including_depot_unload_894  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_683  1
    load_0_17_19  free_load_conservation_864  1
    load_0_17_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_685  -20
    arc_0_17_20  connected_order_arc_686  -15
    arc_0_17_20  out_degree_859  1
    arc_0_17_20  in_degree_878  1
    arc_0_17_20  original_T_including_depot_unload_894  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_685  1
    load_0_17_20  free_load_conservation_864  1
    load_0_17_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_687  -20
    arc_0_17_21  connected_order_arc_688  -15
    arc_0_17_21  out_degree_859  1
    arc_0_17_21  in_degree_884  1
    arc_0_17_21  original_T_including_depot_unload_894  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_687  1
    load_0_17_21  free_load_conservation_864  1
    load_0_17_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_689  -20
    arc_0_18_0  depot_return_or_bypass_798  1
    arc_0_18_0  out_degree_865  1
    arc_0_18_0  original_T_including_depot_unload_894  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_689  1
    load_0_18_0  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_690  -20
    arc_0_18_1  connected_order_arc_691  -15
    arc_0_18_1  in_degree_800  1
    arc_0_18_1  out_degree_865  1
    arc_0_18_1  original_T_including_depot_unload_894  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_690  1
    load_0_18_1  segment_load_conservation_803  -1
    load_0_18_1  segment_prefix_lb_804  1
    load_0_18_1  segment_prefix_ub_805  1
    load_0_18_1  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_692  -20
    arc_0_18_2  connected_order_arc_693  -15
    arc_0_18_2  in_degree_807  1
    arc_0_18_2  out_degree_865  1
    arc_0_18_2  original_T_including_depot_unload_894  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_692  1
    load_0_18_2  segment_load_conservation_810  -1
    load_0_18_2  segment_prefix_lb_811  1
    load_0_18_2  segment_prefix_ub_812  1
    load_0_18_2  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_694  -20
    arc_0_18_3  connected_order_arc_695  -15
    arc_0_18_3  in_degree_814  1
    arc_0_18_3  out_degree_865  1
    arc_0_18_3  original_T_including_depot_unload_894  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_694  1
    load_0_18_3  segment_load_conservation_817  -1
    load_0_18_3  segment_prefix_lb_818  1
    load_0_18_3  segment_prefix_ub_819  1
    load_0_18_3  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_696  -20
    arc_0_18_4  connected_order_arc_697  -15
    arc_0_18_4  in_degree_821  1
    arc_0_18_4  out_degree_865  1
    arc_0_18_4  original_T_including_depot_unload_894  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_696  1
    load_0_18_4  segment_load_conservation_824  -1
    load_0_18_4  segment_prefix_lb_825  1
    load_0_18_4  segment_prefix_ub_826  1
    load_0_18_4  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_698  -20
    arc_0_18_5  connected_order_arc_699  -15
    arc_0_18_5  in_degree_828  1
    arc_0_18_5  out_degree_865  1
    arc_0_18_5  original_T_including_depot_unload_894  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_698  1
    load_0_18_5  segment_load_conservation_831  -1
    load_0_18_5  segment_prefix_lb_832  1
    load_0_18_5  segment_prefix_ub_833  1
    load_0_18_5  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_700  -20
    arc_0_18_6  connected_order_arc_701  -15
    arc_0_18_6  in_degree_835  1
    arc_0_18_6  out_degree_865  1
    arc_0_18_6  original_T_including_depot_unload_894  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_700  1
    load_0_18_6  segment_load_conservation_838  -1
    load_0_18_6  segment_prefix_lb_839  1
    load_0_18_6  segment_prefix_ub_840  1
    load_0_18_6  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_702  -20
    arc_0_18_14  connected_order_arc_703  -15
    arc_0_18_14  in_degree_842  1
    arc_0_18_14  out_degree_865  1
    arc_0_18_14  original_T_including_depot_unload_894  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_702  1
    load_0_18_14  free_load_conservation_846  -1
    load_0_18_14  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_704  -20
    arc_0_18_15  connected_order_arc_705  -15
    arc_0_18_15  in_degree_848  1
    arc_0_18_15  out_degree_865  1
    arc_0_18_15  original_T_including_depot_unload_894  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_704  1
    load_0_18_15  free_load_conservation_852  -1
    load_0_18_15  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_706  -20
    arc_0_18_16  connected_order_arc_707  -15
    arc_0_18_16  in_degree_854  1
    arc_0_18_16  out_degree_865  1
    arc_0_18_16  original_T_including_depot_unload_894  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_706  1
    load_0_18_16  free_load_conservation_858  -1
    load_0_18_16  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_708  -20
    arc_0_18_17  connected_order_arc_709  -15
    arc_0_18_17  in_degree_860  1
    arc_0_18_17  out_degree_865  1
    arc_0_18_17  original_T_including_depot_unload_894  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_708  1
    load_0_18_17  free_load_conservation_864  -1
    load_0_18_17  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_710  -20
    arc_0_18_19  connected_order_arc_711  -15
    arc_0_18_19  out_degree_865  1
    arc_0_18_19  in_degree_872  1
    arc_0_18_19  original_T_including_depot_unload_894  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_710  1
    load_0_18_19  free_load_conservation_870  1
    load_0_18_19  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_712  -20
    arc_0_18_20  connected_order_arc_713  -15
    arc_0_18_20  out_degree_865  1
    arc_0_18_20  in_degree_878  1
    arc_0_18_20  original_T_including_depot_unload_894  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_712  1
    load_0_18_20  free_load_conservation_870  1
    load_0_18_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_714  -20
    arc_0_18_21  connected_order_arc_715  -15
    arc_0_18_21  out_degree_865  1
    arc_0_18_21  in_degree_884  1
    arc_0_18_21  original_T_including_depot_unload_894  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_714  1
    load_0_18_21  free_load_conservation_870  1
    load_0_18_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_716  -20
    arc_0_19_0  depot_return_or_bypass_798  1
    arc_0_19_0  out_degree_871  1
    arc_0_19_0  original_T_including_depot_unload_894  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_716  1
    load_0_19_0  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_717  -20
    arc_0_19_1  connected_order_arc_718  -15
    arc_0_19_1  in_degree_800  1
    arc_0_19_1  out_degree_871  1
    arc_0_19_1  original_T_including_depot_unload_894  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_717  1
    load_0_19_1  segment_load_conservation_803  -1
    load_0_19_1  segment_prefix_lb_804  1
    load_0_19_1  segment_prefix_ub_805  1
    load_0_19_1  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_719  -20
    arc_0_19_2  connected_order_arc_720  -15
    arc_0_19_2  in_degree_807  1
    arc_0_19_2  out_degree_871  1
    arc_0_19_2  original_T_including_depot_unload_894  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_719  1
    load_0_19_2  segment_load_conservation_810  -1
    load_0_19_2  segment_prefix_lb_811  1
    load_0_19_2  segment_prefix_ub_812  1
    load_0_19_2  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_721  -20
    arc_0_19_3  connected_order_arc_722  -15
    arc_0_19_3  in_degree_814  1
    arc_0_19_3  out_degree_871  1
    arc_0_19_3  original_T_including_depot_unload_894  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_721  1
    load_0_19_3  segment_load_conservation_817  -1
    load_0_19_3  segment_prefix_lb_818  1
    load_0_19_3  segment_prefix_ub_819  1
    load_0_19_3  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_723  -20
    arc_0_19_4  connected_order_arc_724  -15
    arc_0_19_4  in_degree_821  1
    arc_0_19_4  out_degree_871  1
    arc_0_19_4  original_T_including_depot_unload_894  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_723  1
    load_0_19_4  segment_load_conservation_824  -1
    load_0_19_4  segment_prefix_lb_825  1
    load_0_19_4  segment_prefix_ub_826  1
    load_0_19_4  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_725  -20
    arc_0_19_5  connected_order_arc_726  -15
    arc_0_19_5  in_degree_828  1
    arc_0_19_5  out_degree_871  1
    arc_0_19_5  original_T_including_depot_unload_894  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_725  1
    load_0_19_5  segment_load_conservation_831  -1
    load_0_19_5  segment_prefix_lb_832  1
    load_0_19_5  segment_prefix_ub_833  1
    load_0_19_5  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_727  -20
    arc_0_19_6  connected_order_arc_728  -15
    arc_0_19_6  in_degree_835  1
    arc_0_19_6  out_degree_871  1
    arc_0_19_6  original_T_including_depot_unload_894  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_727  1
    load_0_19_6  segment_load_conservation_838  -1
    load_0_19_6  segment_prefix_lb_839  1
    load_0_19_6  segment_prefix_ub_840  1
    load_0_19_6  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_729  -20
    arc_0_19_14  connected_order_arc_730  -15
    arc_0_19_14  in_degree_842  1
    arc_0_19_14  out_degree_871  1
    arc_0_19_14  original_T_including_depot_unload_894  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_729  1
    load_0_19_14  free_load_conservation_846  -1
    load_0_19_14  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_731  -20
    arc_0_19_15  connected_order_arc_732  -15
    arc_0_19_15  in_degree_848  1
    arc_0_19_15  out_degree_871  1
    arc_0_19_15  original_T_including_depot_unload_894  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_731  1
    load_0_19_15  free_load_conservation_852  -1
    load_0_19_15  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_733  -20
    arc_0_19_16  connected_order_arc_734  -15
    arc_0_19_16  in_degree_854  1
    arc_0_19_16  out_degree_871  1
    arc_0_19_16  original_T_including_depot_unload_894  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_733  1
    load_0_19_16  free_load_conservation_858  -1
    load_0_19_16  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_735  -20
    arc_0_19_17  connected_order_arc_736  -15
    arc_0_19_17  in_degree_860  1
    arc_0_19_17  out_degree_871  1
    arc_0_19_17  original_T_including_depot_unload_894  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_735  1
    load_0_19_17  free_load_conservation_864  -1
    load_0_19_17  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_737  -20
    arc_0_19_18  connected_order_arc_738  -15
    arc_0_19_18  in_degree_866  1
    arc_0_19_18  out_degree_871  1
    arc_0_19_18  original_T_including_depot_unload_894  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_737  1
    load_0_19_18  free_load_conservation_870  -1
    load_0_19_18  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_739  -20
    arc_0_19_20  connected_order_arc_740  -15
    arc_0_19_20  out_degree_871  1
    arc_0_19_20  in_degree_878  1
    arc_0_19_20  original_T_including_depot_unload_894  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_739  1
    load_0_19_20  free_load_conservation_876  1
    load_0_19_20  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_741  -20
    arc_0_19_21  connected_order_arc_742  -15
    arc_0_19_21  out_degree_871  1
    arc_0_19_21  in_degree_884  1
    arc_0_19_21  original_T_including_depot_unload_894  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_741  1
    load_0_19_21  free_load_conservation_876  1
    load_0_19_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_743  -20
    arc_0_20_0  depot_return_or_bypass_798  1
    arc_0_20_0  out_degree_877  1
    arc_0_20_0  original_T_including_depot_unload_894  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_743  1
    load_0_20_0  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_744  -20
    arc_0_20_1  connected_order_arc_745  -15
    arc_0_20_1  in_degree_800  1
    arc_0_20_1  out_degree_877  1
    arc_0_20_1  original_T_including_depot_unload_894  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_744  1
    load_0_20_1  segment_load_conservation_803  -1
    load_0_20_1  segment_prefix_lb_804  1
    load_0_20_1  segment_prefix_ub_805  1
    load_0_20_1  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_746  -20
    arc_0_20_2  connected_order_arc_747  -15
    arc_0_20_2  in_degree_807  1
    arc_0_20_2  out_degree_877  1
    arc_0_20_2  original_T_including_depot_unload_894  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_746  1
    load_0_20_2  segment_load_conservation_810  -1
    load_0_20_2  segment_prefix_lb_811  1
    load_0_20_2  segment_prefix_ub_812  1
    load_0_20_2  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_748  -20
    arc_0_20_3  connected_order_arc_749  -15
    arc_0_20_3  in_degree_814  1
    arc_0_20_3  out_degree_877  1
    arc_0_20_3  original_T_including_depot_unload_894  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_748  1
    load_0_20_3  segment_load_conservation_817  -1
    load_0_20_3  segment_prefix_lb_818  1
    load_0_20_3  segment_prefix_ub_819  1
    load_0_20_3  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_750  -20
    arc_0_20_4  connected_order_arc_751  -15
    arc_0_20_4  in_degree_821  1
    arc_0_20_4  out_degree_877  1
    arc_0_20_4  original_T_including_depot_unload_894  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_750  1
    load_0_20_4  segment_load_conservation_824  -1
    load_0_20_4  segment_prefix_lb_825  1
    load_0_20_4  segment_prefix_ub_826  1
    load_0_20_4  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_752  -20
    arc_0_20_5  connected_order_arc_753  -15
    arc_0_20_5  in_degree_828  1
    arc_0_20_5  out_degree_877  1
    arc_0_20_5  original_T_including_depot_unload_894  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_752  1
    load_0_20_5  segment_load_conservation_831  -1
    load_0_20_5  segment_prefix_lb_832  1
    load_0_20_5  segment_prefix_ub_833  1
    load_0_20_5  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_754  -20
    arc_0_20_6  connected_order_arc_755  -15
    arc_0_20_6  in_degree_835  1
    arc_0_20_6  out_degree_877  1
    arc_0_20_6  original_T_including_depot_unload_894  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_754  1
    load_0_20_6  segment_load_conservation_838  -1
    load_0_20_6  segment_prefix_lb_839  1
    load_0_20_6  segment_prefix_ub_840  1
    load_0_20_6  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_756  -20
    arc_0_20_14  connected_order_arc_757  -15
    arc_0_20_14  in_degree_842  1
    arc_0_20_14  out_degree_877  1
    arc_0_20_14  original_T_including_depot_unload_894  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_756  1
    load_0_20_14  free_load_conservation_846  -1
    load_0_20_14  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_758  -20
    arc_0_20_15  connected_order_arc_759  -15
    arc_0_20_15  in_degree_848  1
    arc_0_20_15  out_degree_877  1
    arc_0_20_15  original_T_including_depot_unload_894  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_758  1
    load_0_20_15  free_load_conservation_852  -1
    load_0_20_15  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_760  -20
    arc_0_20_16  connected_order_arc_761  -15
    arc_0_20_16  in_degree_854  1
    arc_0_20_16  out_degree_877  1
    arc_0_20_16  original_T_including_depot_unload_894  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_760  1
    load_0_20_16  free_load_conservation_858  -1
    load_0_20_16  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_762  -20
    arc_0_20_17  connected_order_arc_763  -15
    arc_0_20_17  in_degree_860  1
    arc_0_20_17  out_degree_877  1
    arc_0_20_17  original_T_including_depot_unload_894  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_762  1
    load_0_20_17  free_load_conservation_864  -1
    load_0_20_17  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_764  -20
    arc_0_20_18  connected_order_arc_765  -15
    arc_0_20_18  in_degree_866  1
    arc_0_20_18  out_degree_877  1
    arc_0_20_18  original_T_including_depot_unload_894  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_764  1
    load_0_20_18  free_load_conservation_870  -1
    load_0_20_18  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_766  -20
    arc_0_20_19  connected_order_arc_767  -15
    arc_0_20_19  in_degree_872  1
    arc_0_20_19  out_degree_877  1
    arc_0_20_19  original_T_including_depot_unload_894  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_766  1
    load_0_20_19  free_load_conservation_876  -1
    load_0_20_19  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_768  -20
    arc_0_20_21  connected_order_arc_769  -15
    arc_0_20_21  out_degree_877  1
    arc_0_20_21  in_degree_884  1
    arc_0_20_21  original_T_including_depot_unload_894  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_768  1
    load_0_20_21  free_load_conservation_882  1
    load_0_20_21  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_770  -20
    arc_0_21_0  depot_return_or_bypass_798  1
    arc_0_21_0  out_degree_883  1
    arc_0_21_0  original_T_including_depot_unload_894  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_770  1
    load_0_21_0  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_771  -20
    arc_0_21_1  connected_order_arc_772  -15
    arc_0_21_1  in_degree_800  1
    arc_0_21_1  out_degree_883  1
    arc_0_21_1  original_T_including_depot_unload_894  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_771  1
    load_0_21_1  segment_load_conservation_803  -1
    load_0_21_1  segment_prefix_lb_804  1
    load_0_21_1  segment_prefix_ub_805  1
    load_0_21_1  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_773  -20
    arc_0_21_2  connected_order_arc_774  -15
    arc_0_21_2  in_degree_807  1
    arc_0_21_2  out_degree_883  1
    arc_0_21_2  original_T_including_depot_unload_894  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_773  1
    load_0_21_2  segment_load_conservation_810  -1
    load_0_21_2  segment_prefix_lb_811  1
    load_0_21_2  segment_prefix_ub_812  1
    load_0_21_2  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_775  -20
    arc_0_21_3  connected_order_arc_776  -15
    arc_0_21_3  in_degree_814  1
    arc_0_21_3  out_degree_883  1
    arc_0_21_3  original_T_including_depot_unload_894  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_775  1
    load_0_21_3  segment_load_conservation_817  -1
    load_0_21_3  segment_prefix_lb_818  1
    load_0_21_3  segment_prefix_ub_819  1
    load_0_21_3  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_777  -20
    arc_0_21_4  connected_order_arc_778  -15
    arc_0_21_4  in_degree_821  1
    arc_0_21_4  out_degree_883  1
    arc_0_21_4  original_T_including_depot_unload_894  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_777  1
    load_0_21_4  segment_load_conservation_824  -1
    load_0_21_4  segment_prefix_lb_825  1
    load_0_21_4  segment_prefix_ub_826  1
    load_0_21_4  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_779  -20
    arc_0_21_5  connected_order_arc_780  -15
    arc_0_21_5  in_degree_828  1
    arc_0_21_5  out_degree_883  1
    arc_0_21_5  original_T_including_depot_unload_894  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_779  1
    load_0_21_5  segment_load_conservation_831  -1
    load_0_21_5  segment_prefix_lb_832  1
    load_0_21_5  segment_prefix_ub_833  1
    load_0_21_5  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_781  -20
    arc_0_21_6  connected_order_arc_782  -15
    arc_0_21_6  in_degree_835  1
    arc_0_21_6  out_degree_883  1
    arc_0_21_6  original_T_including_depot_unload_894  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_781  1
    load_0_21_6  segment_load_conservation_838  -1
    load_0_21_6  segment_prefix_lb_839  1
    load_0_21_6  segment_prefix_ub_840  1
    load_0_21_6  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_783  -20
    arc_0_21_14  connected_order_arc_784  -15
    arc_0_21_14  in_degree_842  1
    arc_0_21_14  out_degree_883  1
    arc_0_21_14  original_T_including_depot_unload_894  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_783  1
    load_0_21_14  free_load_conservation_846  -1
    load_0_21_14  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_785  -20
    arc_0_21_15  connected_order_arc_786  -15
    arc_0_21_15  in_degree_848  1
    arc_0_21_15  out_degree_883  1
    arc_0_21_15  original_T_including_depot_unload_894  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_785  1
    load_0_21_15  free_load_conservation_852  -1
    load_0_21_15  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_787  -20
    arc_0_21_16  connected_order_arc_788  -15
    arc_0_21_16  in_degree_854  1
    arc_0_21_16  out_degree_883  1
    arc_0_21_16  original_T_including_depot_unload_894  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_787  1
    load_0_21_16  free_load_conservation_858  -1
    load_0_21_16  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_789  -20
    arc_0_21_17  connected_order_arc_790  -15
    arc_0_21_17  in_degree_860  1
    arc_0_21_17  out_degree_883  1
    arc_0_21_17  original_T_including_depot_unload_894  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_789  1
    load_0_21_17  free_load_conservation_864  -1
    load_0_21_17  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_791  -20
    arc_0_21_18  connected_order_arc_792  -15
    arc_0_21_18  in_degree_866  1
    arc_0_21_18  out_degree_883  1
    arc_0_21_18  original_T_including_depot_unload_894  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_791  1
    load_0_21_18  free_load_conservation_870  -1
    load_0_21_18  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_793  -20
    arc_0_21_19  connected_order_arc_794  -15
    arc_0_21_19  in_degree_872  1
    arc_0_21_19  out_degree_883  1
    arc_0_21_19  original_T_including_depot_unload_894  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_793  1
    load_0_21_19  free_load_conservation_876  -1
    load_0_21_19  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_795  -20
    arc_0_21_20  connected_order_arc_796  -15
    arc_0_21_20  in_degree_878  1
    arc_0_21_20  out_degree_883  1
    arc_0_21_20  original_T_including_depot_unload_894  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_795  1
    load_0_21_20  free_load_conservation_882  -1
    load_0_21_20  free_load_conservation_888  1
    visit_1_7  out_degree_1098  -1
    visit_1_7  in_degree_1099  -1
    visit_1_7  order_active_lb_1100  -1
    visit_1_7  order_active_ub_1101  -10
    order_1_7  connected_order_arc_908  -1
    order_1_7  connected_order_arc_910  -1
    order_1_7  connected_order_arc_912  -1
    order_1_7  connected_order_arc_914  -1
    order_1_7  connected_order_arc_916  -1
    order_1_7  connected_order_arc_918  -1
    order_1_7  connected_order_arc_920  -1
    order_1_7  connected_order_arc_922  -1
    order_1_7  connected_order_arc_924  -1
    order_1_7  connected_order_arc_927  1
    order_1_7  connected_order_arc_946  1
    order_1_7  connected_order_arc_965  1
    order_1_7  connected_order_arc_984  1
    order_1_7  connected_order_arc_1003  1
    order_1_7  connected_order_arc_1022  1
    order_1_7  connected_order_arc_1041  1
    order_1_7  connected_order_arc_1060  1
    order_1_7  connected_order_arc_1079  1
    order_1_7  order_active_lb_1100  1
    order_1_7  order_active_ub_1101  1
    order_1_7  fixed_segment_relative_order_1160  -1
    visit_1_8  out_degree_1105  -1
    visit_1_8  in_degree_1106  -1
    visit_1_8  order_active_lb_1107  -1
    visit_1_8  order_active_ub_1108  -10
    order_1_8  connected_order_arc_908  1
    order_1_8  connected_order_arc_927  -1
    order_1_8  connected_order_arc_929  -1
    order_1_8  connected_order_arc_931  -1
    order_1_8  connected_order_arc_933  -1
    order_1_8  connected_order_arc_935  -1
    order_1_8  connected_order_arc_937  -1
    order_1_8  connected_order_arc_939  -1
    order_1_8  connected_order_arc_941  -1
    order_1_8  connected_order_arc_943  -1
    order_1_8  connected_order_arc_948  1
    order_1_8  connected_order_arc_967  1
    order_1_8  connected_order_arc_986  1
    order_1_8  connected_order_arc_1005  1
    order_1_8  connected_order_arc_1024  1
    order_1_8  connected_order_arc_1043  1
    order_1_8  connected_order_arc_1062  1
    order_1_8  connected_order_arc_1081  1
    order_1_8  order_active_lb_1107  1
    order_1_8  order_active_ub_1108  1
    order_1_8  fixed_segment_relative_order_1160  1
    visit_1_14  out_degree_1112  -1
    visit_1_14  in_degree_1113  -1
    visit_1_14  order_active_lb_1114  -1
    visit_1_14  order_active_ub_1115  -10
    visit_1_14  service_visit_def_1116  -1
    order_1_14  connected_order_arc_910  1
    order_1_14  connected_order_arc_929  1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_956  -1
    order_1_14  connected_order_arc_958  -1
    order_1_14  connected_order_arc_960  -1
    order_1_14  connected_order_arc_962  -1
    order_1_14  connected_order_arc_969  1
    order_1_14  connected_order_arc_988  1
    order_1_14  connected_order_arc_1007  1
    order_1_14  connected_order_arc_1026  1
    order_1_14  connected_order_arc_1045  1
    order_1_14  connected_order_arc_1064  1
    order_1_14  connected_order_arc_1083  1
    order_1_14  order_active_lb_1114  1
    order_1_14  order_active_ub_1115  1
    visit_1_15  out_degree_1118  -1
    visit_1_15  in_degree_1119  -1
    visit_1_15  order_active_lb_1120  -1
    visit_1_15  order_active_ub_1121  -10
    visit_1_15  service_visit_def_1122  -1
    order_1_15  connected_order_arc_912  1
    order_1_15  connected_order_arc_931  1
    order_1_15  connected_order_arc_950  1
    order_1_15  connected_order_arc_965  -1
    order_1_15  connected_order_arc_967  -1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_990  1
    order_1_15  connected_order_arc_1009  1
    order_1_15  connected_order_arc_1028  1
    order_1_15  connected_order_arc_1047  1
    order_1_15  connected_order_arc_1066  1
    order_1_15  connected_order_arc_1085  1
    order_1_15  order_active_lb_1120  1
    order_1_15  order_active_ub_1121  1
    visit_1_16  out_degree_1124  -1
    visit_1_16  in_degree_1125  -1
    visit_1_16  order_active_lb_1126  -1
    visit_1_16  order_active_ub_1127  -10
    visit_1_16  service_visit_def_1128  -1
    order_1_16  connected_order_arc_914  1
    order_1_16  connected_order_arc_933  1
    order_1_16  connected_order_arc_952  1
    order_1_16  connected_order_arc_971  1
    order_1_16  connected_order_arc_984  -1
    order_1_16  connected_order_arc_986  -1
    order_1_16  connected_order_arc_988  -1
    order_1_16  connected_order_arc_990  -1
    order_1_16  connected_order_arc_992  -1
    order_1_16  connected_order_arc_994  -1
    order_1_16  connected_order_arc_996  -1
    order_1_16  connected_order_arc_998  -1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1011  1
    order_1_16  connected_order_arc_1030  1
    order_1_16  connected_order_arc_1049  1
    order_1_16  connected_order_arc_1068  1
    order_1_16  connected_order_arc_1087  1
    order_1_16  order_active_lb_1126  1
    order_1_16  order_active_ub_1127  1
    visit_1_17  out_degree_1130  -1
    visit_1_17  in_degree_1131  -1
    visit_1_17  order_active_lb_1132  -1
    visit_1_17  order_active_ub_1133  -10
    visit_1_17  service_visit_def_1134  -1
    order_1_17  connected_order_arc_916  1
    order_1_17  connected_order_arc_935  1
    order_1_17  connected_order_arc_954  1
    order_1_17  connected_order_arc_973  1
    order_1_17  connected_order_arc_992  1
    order_1_17  connected_order_arc_1003  -1
    order_1_17  connected_order_arc_1005  -1
    order_1_17  connected_order_arc_1007  -1
    order_1_17  connected_order_arc_1009  -1
    order_1_17  connected_order_arc_1011  -1
    order_1_17  connected_order_arc_1013  -1
    order_1_17  connected_order_arc_1015  -1
    order_1_17  connected_order_arc_1017  -1
    order_1_17  connected_order_arc_1019  -1
    order_1_17  connected_order_arc_1032  1
    order_1_17  connected_order_arc_1051  1
    order_1_17  connected_order_arc_1070  1
    order_1_17  connected_order_arc_1089  1
    order_1_17  order_active_lb_1132  1
    order_1_17  order_active_ub_1133  1
    visit_1_18  out_degree_1136  -1
    visit_1_18  in_degree_1137  -1
    visit_1_18  order_active_lb_1138  -1
    visit_1_18  order_active_ub_1139  -10
    visit_1_18  service_visit_def_1140  -1
    order_1_18  connected_order_arc_918  1
    order_1_18  connected_order_arc_937  1
    order_1_18  connected_order_arc_956  1
    order_1_18  connected_order_arc_975  1
    order_1_18  connected_order_arc_994  1
    order_1_18  connected_order_arc_1013  1
    order_1_18  connected_order_arc_1022  -1
    order_1_18  connected_order_arc_1024  -1
    order_1_18  connected_order_arc_1026  -1
    order_1_18  connected_order_arc_1028  -1
    order_1_18  connected_order_arc_1030  -1
    order_1_18  connected_order_arc_1032  -1
    order_1_18  connected_order_arc_1034  -1
    order_1_18  connected_order_arc_1036  -1
    order_1_18  connected_order_arc_1038  -1
    order_1_18  connected_order_arc_1053  1
    order_1_18  connected_order_arc_1072  1
    order_1_18  connected_order_arc_1091  1
    order_1_18  order_active_lb_1138  1
    order_1_18  order_active_ub_1139  1
    visit_1_19  out_degree_1142  -1
    visit_1_19  in_degree_1143  -1
    visit_1_19  order_active_lb_1144  -1
    visit_1_19  order_active_ub_1145  -10
    visit_1_19  service_visit_def_1146  -1
    order_1_19  connected_order_arc_920  1
    order_1_19  connected_order_arc_939  1
    order_1_19  connected_order_arc_958  1
    order_1_19  connected_order_arc_977  1
    order_1_19  connected_order_arc_996  1
    order_1_19  connected_order_arc_1015  1
    order_1_19  connected_order_arc_1034  1
    order_1_19  connected_order_arc_1041  -1
    order_1_19  connected_order_arc_1043  -1
    order_1_19  connected_order_arc_1045  -1
    order_1_19  connected_order_arc_1047  -1
    order_1_19  connected_order_arc_1049  -1
    order_1_19  connected_order_arc_1051  -1
    order_1_19  connected_order_arc_1053  -1
    order_1_19  connected_order_arc_1055  -1
    order_1_19  connected_order_arc_1057  -1
    order_1_19  connected_order_arc_1074  1
    order_1_19  connected_order_arc_1093  1
    order_1_19  order_active_lb_1144  1
    order_1_19  order_active_ub_1145  1
    visit_1_20  out_degree_1148  -1
    visit_1_20  in_degree_1149  -1
    visit_1_20  order_active_lb_1150  -1
    visit_1_20  order_active_ub_1151  -10
    visit_1_20  service_visit_def_1152  -1
    order_1_20  connected_order_arc_922  1
    order_1_20  connected_order_arc_941  1
    order_1_20  connected_order_arc_960  1
    order_1_20  connected_order_arc_979  1
    order_1_20  connected_order_arc_998  1
    order_1_20  connected_order_arc_1017  1
    order_1_20  connected_order_arc_1036  1
    order_1_20  connected_order_arc_1055  1
    order_1_20  connected_order_arc_1060  -1
    order_1_20  connected_order_arc_1062  -1
    order_1_20  connected_order_arc_1064  -1
    order_1_20  connected_order_arc_1066  -1
    order_1_20  connected_order_arc_1068  -1
    order_1_20  connected_order_arc_1070  -1
    order_1_20  connected_order_arc_1072  -1
    order_1_20  connected_order_arc_1074  -1
    order_1_20  connected_order_arc_1076  -1
    order_1_20  connected_order_arc_1095  1
    order_1_20  order_active_lb_1150  1
    order_1_20  order_active_ub_1151  1
    visit_1_21  out_degree_1154  -1
    visit_1_21  in_degree_1155  -1
    visit_1_21  order_active_lb_1156  -1
    visit_1_21  order_active_ub_1157  -10
    visit_1_21  service_visit_def_1158  -1
    order_1_21  connected_order_arc_924  1
    order_1_21  connected_order_arc_943  1
    order_1_21  connected_order_arc_962  1
    order_1_21  connected_order_arc_981  1
    order_1_21  connected_order_arc_1000  1
    order_1_21  connected_order_arc_1019  1
    order_1_21  connected_order_arc_1038  1
    order_1_21  connected_order_arc_1057  1
    order_1_21  connected_order_arc_1076  1
    order_1_21  connected_order_arc_1079  -1
    order_1_21  connected_order_arc_1081  -1
    order_1_21  connected_order_arc_1083  -1
    order_1_21  connected_order_arc_1085  -1
    order_1_21  connected_order_arc_1087  -1
    order_1_21  connected_order_arc_1089  -1
    order_1_21  connected_order_arc_1091  -1
    order_1_21  connected_order_arc_1093  -1
    order_1_21  connected_order_arc_1095  -1
    order_1_21  order_active_lb_1156  1
    order_1_21  order_active_ub_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_895  -25
    arc_1_0_0  depot_departure_or_bypass_1096  1
    arc_1_0_0  depot_return_or_bypass_1097  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_895  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_896  -25
    arc_1_0_7  depot_departure_or_bypass_1096  1
    arc_1_0_7  in_degree_1099  1
    arc_1_0_7  original_T_including_depot_unload_1161  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_896  1
    load_1_0_7  segment_load_conservation_1102  -1
    load_1_0_7  segment_prefix_lb_1103  1
    load_1_0_7  segment_prefix_ub_1104  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_897  -25
    arc_1_0_8  depot_departure_or_bypass_1096  1
    arc_1_0_8  in_degree_1106  1
    arc_1_0_8  original_T_including_depot_unload_1161  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_897  1
    load_1_0_8  segment_load_conservation_1109  -1
    load_1_0_8  segment_prefix_lb_1110  1
    load_1_0_8  segment_prefix_ub_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_898  -25
    arc_1_0_14  depot_departure_or_bypass_1096  1
    arc_1_0_14  in_degree_1113  1
    arc_1_0_14  original_T_including_depot_unload_1161  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_898  1
    load_1_0_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_899  -25
    arc_1_0_15  depot_departure_or_bypass_1096  1
    arc_1_0_15  in_degree_1119  1
    arc_1_0_15  original_T_including_depot_unload_1161  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_899  1
    load_1_0_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_900  -25
    arc_1_0_16  depot_departure_or_bypass_1096  1
    arc_1_0_16  in_degree_1125  1
    arc_1_0_16  original_T_including_depot_unload_1161  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_900  1
    load_1_0_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_901  -25
    arc_1_0_17  depot_departure_or_bypass_1096  1
    arc_1_0_17  in_degree_1131  1
    arc_1_0_17  original_T_including_depot_unload_1161  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_901  1
    load_1_0_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_902  -25
    arc_1_0_18  depot_departure_or_bypass_1096  1
    arc_1_0_18  in_degree_1137  1
    arc_1_0_18  original_T_including_depot_unload_1161  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_902  1
    load_1_0_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_903  -25
    arc_1_0_19  depot_departure_or_bypass_1096  1
    arc_1_0_19  in_degree_1143  1
    arc_1_0_19  original_T_including_depot_unload_1161  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_903  1
    load_1_0_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_904  -25
    arc_1_0_20  depot_departure_or_bypass_1096  1
    arc_1_0_20  in_degree_1149  1
    arc_1_0_20  original_T_including_depot_unload_1161  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_904  1
    load_1_0_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_905  -25
    arc_1_0_21  depot_departure_or_bypass_1096  1
    arc_1_0_21  in_degree_1155  1
    arc_1_0_21  original_T_including_depot_unload_1161  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_905  1
    load_1_0_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_906  -25
    arc_1_7_0  depot_return_or_bypass_1097  1
    arc_1_7_0  out_degree_1098  1
    arc_1_7_0  original_T_including_depot_unload_1161  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_906  1
    load_1_7_0  segment_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_907  -25
    arc_1_7_8  connected_order_arc_908  -11
    arc_1_7_8  out_degree_1098  1
    arc_1_7_8  in_degree_1106  1
    arc_1_7_8  original_T_including_depot_unload_1161  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_907  1
    load_1_7_8  segment_load_conservation_1102  1
    load_1_7_8  segment_load_conservation_1109  -1
    load_1_7_8  segment_prefix_lb_1110  1
    load_1_7_8  segment_prefix_ub_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_909  -25
    arc_1_7_14  connected_order_arc_910  -11
    arc_1_7_14  out_degree_1098  1
    arc_1_7_14  in_degree_1113  1
    arc_1_7_14  original_T_including_depot_unload_1161  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_909  1
    load_1_7_14  segment_load_conservation_1102  1
    load_1_7_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_911  -25
    arc_1_7_15  connected_order_arc_912  -11
    arc_1_7_15  out_degree_1098  1
    arc_1_7_15  in_degree_1119  1
    arc_1_7_15  original_T_including_depot_unload_1161  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_911  1
    load_1_7_15  segment_load_conservation_1102  1
    load_1_7_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_913  -25
    arc_1_7_16  connected_order_arc_914  -11
    arc_1_7_16  out_degree_1098  1
    arc_1_7_16  in_degree_1125  1
    arc_1_7_16  original_T_including_depot_unload_1161  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_913  1
    load_1_7_16  segment_load_conservation_1102  1
    load_1_7_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_915  -25
    arc_1_7_17  connected_order_arc_916  -11
    arc_1_7_17  out_degree_1098  1
    arc_1_7_17  in_degree_1131  1
    arc_1_7_17  original_T_including_depot_unload_1161  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_915  1
    load_1_7_17  segment_load_conservation_1102  1
    load_1_7_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_917  -25
    arc_1_7_18  connected_order_arc_918  -11
    arc_1_7_18  out_degree_1098  1
    arc_1_7_18  in_degree_1137  1
    arc_1_7_18  original_T_including_depot_unload_1161  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_917  1
    load_1_7_18  segment_load_conservation_1102  1
    load_1_7_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_919  -25
    arc_1_7_19  connected_order_arc_920  -11
    arc_1_7_19  out_degree_1098  1
    arc_1_7_19  in_degree_1143  1
    arc_1_7_19  original_T_including_depot_unload_1161  1.5299353443215734e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_919  1
    load_1_7_19  segment_load_conservation_1102  1
    load_1_7_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_921  -25
    arc_1_7_20  connected_order_arc_922  -11
    arc_1_7_20  out_degree_1098  1
    arc_1_7_20  in_degree_1149  1
    arc_1_7_20  original_T_including_depot_unload_1161  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_921  1
    load_1_7_20  segment_load_conservation_1102  1
    load_1_7_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_923  -25
    arc_1_7_21  connected_order_arc_924  -11
    arc_1_7_21  out_degree_1098  1
    arc_1_7_21  in_degree_1155  1
    arc_1_7_21  original_T_including_depot_unload_1161  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_923  1
    load_1_7_21  segment_load_conservation_1102  1
    load_1_7_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_925  -25
    arc_1_8_0  depot_return_or_bypass_1097  1
    arc_1_8_0  out_degree_1105  1
    arc_1_8_0  original_T_including_depot_unload_1161  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_925  1
    load_1_8_0  segment_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_926  -25
    arc_1_8_7  connected_order_arc_927  -11
    arc_1_8_7  in_degree_1099  1
    arc_1_8_7  out_degree_1105  1
    arc_1_8_7  original_T_including_depot_unload_1161  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_926  1
    load_1_8_7  segment_load_conservation_1102  -1
    load_1_8_7  segment_prefix_lb_1103  1
    load_1_8_7  segment_prefix_ub_1104  1
    load_1_8_7  segment_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_928  -25
    arc_1_8_14  connected_order_arc_929  -11
    arc_1_8_14  out_degree_1105  1
    arc_1_8_14  in_degree_1113  1
    arc_1_8_14  original_T_including_depot_unload_1161  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_928  1
    load_1_8_14  segment_load_conservation_1109  1
    load_1_8_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_930  -25
    arc_1_8_15  connected_order_arc_931  -11
    arc_1_8_15  out_degree_1105  1
    arc_1_8_15  in_degree_1119  1
    arc_1_8_15  original_T_including_depot_unload_1161  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_930  1
    load_1_8_15  segment_load_conservation_1109  1
    load_1_8_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_932  -25
    arc_1_8_16  connected_order_arc_933  -11
    arc_1_8_16  out_degree_1105  1
    arc_1_8_16  in_degree_1125  1
    arc_1_8_16  original_T_including_depot_unload_1161  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_932  1
    load_1_8_16  segment_load_conservation_1109  1
    load_1_8_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_934  -25
    arc_1_8_17  connected_order_arc_935  -11
    arc_1_8_17  out_degree_1105  1
    arc_1_8_17  in_degree_1131  1
    arc_1_8_17  original_T_including_depot_unload_1161  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_934  1
    load_1_8_17  segment_load_conservation_1109  1
    load_1_8_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_936  -25
    arc_1_8_18  connected_order_arc_937  -11
    arc_1_8_18  out_degree_1105  1
    arc_1_8_18  in_degree_1137  1
    arc_1_8_18  original_T_including_depot_unload_1161  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_936  1
    load_1_8_18  segment_load_conservation_1109  1
    load_1_8_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_938  -25
    arc_1_8_19  connected_order_arc_939  -11
    arc_1_8_19  out_degree_1105  1
    arc_1_8_19  in_degree_1143  1
    arc_1_8_19  original_T_including_depot_unload_1161  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_938  1
    load_1_8_19  segment_load_conservation_1109  1
    load_1_8_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_940  -25
    arc_1_8_20  connected_order_arc_941  -11
    arc_1_8_20  out_degree_1105  1
    arc_1_8_20  in_degree_1149  1
    arc_1_8_20  original_T_including_depot_unload_1161  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_940  1
    load_1_8_20  segment_load_conservation_1109  1
    load_1_8_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_942  -25
    arc_1_8_21  connected_order_arc_943  -11
    arc_1_8_21  out_degree_1105  1
    arc_1_8_21  in_degree_1155  1
    arc_1_8_21  original_T_including_depot_unload_1161  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_942  1
    load_1_8_21  segment_load_conservation_1109  1
    load_1_8_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_944  -25
    arc_1_14_0  depot_return_or_bypass_1097  1
    arc_1_14_0  out_degree_1112  1
    arc_1_14_0  original_T_including_depot_unload_1161  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_944  1
    load_1_14_0  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_945  -25
    arc_1_14_7  connected_order_arc_946  -11
    arc_1_14_7  in_degree_1099  1
    arc_1_14_7  out_degree_1112  1
    arc_1_14_7  original_T_including_depot_unload_1161  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_945  1
    load_1_14_7  segment_load_conservation_1102  -1
    load_1_14_7  segment_prefix_lb_1103  1
    load_1_14_7  segment_prefix_ub_1104  1
    load_1_14_7  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_947  -25
    arc_1_14_8  connected_order_arc_948  -11
    arc_1_14_8  in_degree_1106  1
    arc_1_14_8  out_degree_1112  1
    arc_1_14_8  original_T_including_depot_unload_1161  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_947  1
    load_1_14_8  segment_load_conservation_1109  -1
    load_1_14_8  segment_prefix_lb_1110  1
    load_1_14_8  segment_prefix_ub_1111  1
    load_1_14_8  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_949  -25
    arc_1_14_15  connected_order_arc_950  -11
    arc_1_14_15  out_degree_1112  1
    arc_1_14_15  in_degree_1119  1
    arc_1_14_15  original_T_including_depot_unload_1161  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_949  1
    load_1_14_15  free_load_conservation_1117  1
    load_1_14_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_951  -25
    arc_1_14_16  connected_order_arc_952  -11
    arc_1_14_16  out_degree_1112  1
    arc_1_14_16  in_degree_1125  1
    arc_1_14_16  original_T_including_depot_unload_1161  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_951  1
    load_1_14_16  free_load_conservation_1117  1
    load_1_14_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_953  -25
    arc_1_14_17  connected_order_arc_954  -11
    arc_1_14_17  out_degree_1112  1
    arc_1_14_17  in_degree_1131  1
    arc_1_14_17  original_T_including_depot_unload_1161  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_953  1
    load_1_14_17  free_load_conservation_1117  1
    load_1_14_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_955  -25
    arc_1_14_18  connected_order_arc_956  -11
    arc_1_14_18  out_degree_1112  1
    arc_1_14_18  in_degree_1137  1
    arc_1_14_18  original_T_including_depot_unload_1161  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_955  1
    load_1_14_18  free_load_conservation_1117  1
    load_1_14_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_957  -25
    arc_1_14_19  connected_order_arc_958  -11
    arc_1_14_19  out_degree_1112  1
    arc_1_14_19  in_degree_1143  1
    arc_1_14_19  original_T_including_depot_unload_1161  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_957  1
    load_1_14_19  free_load_conservation_1117  1
    load_1_14_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_959  -25
    arc_1_14_20  connected_order_arc_960  -11
    arc_1_14_20  out_degree_1112  1
    arc_1_14_20  in_degree_1149  1
    arc_1_14_20  original_T_including_depot_unload_1161  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_959  1
    load_1_14_20  free_load_conservation_1117  1
    load_1_14_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_961  -25
    arc_1_14_21  connected_order_arc_962  -11
    arc_1_14_21  out_degree_1112  1
    arc_1_14_21  in_degree_1155  1
    arc_1_14_21  original_T_including_depot_unload_1161  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_961  1
    load_1_14_21  free_load_conservation_1117  1
    load_1_14_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_963  -25
    arc_1_15_0  depot_return_or_bypass_1097  1
    arc_1_15_0  out_degree_1118  1
    arc_1_15_0  original_T_including_depot_unload_1161  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_963  1
    load_1_15_0  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_964  -25
    arc_1_15_7  connected_order_arc_965  -11
    arc_1_15_7  in_degree_1099  1
    arc_1_15_7  out_degree_1118  1
    arc_1_15_7  original_T_including_depot_unload_1161  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_964  1
    load_1_15_7  segment_load_conservation_1102  -1
    load_1_15_7  segment_prefix_lb_1103  1
    load_1_15_7  segment_prefix_ub_1104  1
    load_1_15_7  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_966  -25
    arc_1_15_8  connected_order_arc_967  -11
    arc_1_15_8  in_degree_1106  1
    arc_1_15_8  out_degree_1118  1
    arc_1_15_8  original_T_including_depot_unload_1161  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_966  1
    load_1_15_8  segment_load_conservation_1109  -1
    load_1_15_8  segment_prefix_lb_1110  1
    load_1_15_8  segment_prefix_ub_1111  1
    load_1_15_8  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_968  -25
    arc_1_15_14  connected_order_arc_969  -11
    arc_1_15_14  in_degree_1113  1
    arc_1_15_14  out_degree_1118  1
    arc_1_15_14  original_T_including_depot_unload_1161  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_968  1
    load_1_15_14  free_load_conservation_1117  -1
    load_1_15_14  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_970  -25
    arc_1_15_16  connected_order_arc_971  -11
    arc_1_15_16  out_degree_1118  1
    arc_1_15_16  in_degree_1125  1
    arc_1_15_16  original_T_including_depot_unload_1161  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_970  1
    load_1_15_16  free_load_conservation_1123  1
    load_1_15_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_972  -25
    arc_1_15_17  connected_order_arc_973  -11
    arc_1_15_17  out_degree_1118  1
    arc_1_15_17  in_degree_1131  1
    arc_1_15_17  original_T_including_depot_unload_1161  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_972  1
    load_1_15_17  free_load_conservation_1123  1
    load_1_15_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_974  -25
    arc_1_15_18  connected_order_arc_975  -11
    arc_1_15_18  out_degree_1118  1
    arc_1_15_18  in_degree_1137  1
    arc_1_15_18  original_T_including_depot_unload_1161  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_974  1
    load_1_15_18  free_load_conservation_1123  1
    load_1_15_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_976  -25
    arc_1_15_19  connected_order_arc_977  -11
    arc_1_15_19  out_degree_1118  1
    arc_1_15_19  in_degree_1143  1
    arc_1_15_19  original_T_including_depot_unload_1161  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_976  1
    load_1_15_19  free_load_conservation_1123  1
    load_1_15_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_978  -25
    arc_1_15_20  connected_order_arc_979  -11
    arc_1_15_20  out_degree_1118  1
    arc_1_15_20  in_degree_1149  1
    arc_1_15_20  original_T_including_depot_unload_1161  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_978  1
    load_1_15_20  free_load_conservation_1123  1
    load_1_15_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_980  -25
    arc_1_15_21  connected_order_arc_981  -11
    arc_1_15_21  out_degree_1118  1
    arc_1_15_21  in_degree_1155  1
    arc_1_15_21  original_T_including_depot_unload_1161  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_980  1
    load_1_15_21  free_load_conservation_1123  1
    load_1_15_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_982  -25
    arc_1_16_0  depot_return_or_bypass_1097  1
    arc_1_16_0  out_degree_1124  1
    arc_1_16_0  original_T_including_depot_unload_1161  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_982  1
    load_1_16_0  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_983  -25
    arc_1_16_7  connected_order_arc_984  -11
    arc_1_16_7  in_degree_1099  1
    arc_1_16_7  out_degree_1124  1
    arc_1_16_7  original_T_including_depot_unload_1161  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_983  1
    load_1_16_7  segment_load_conservation_1102  -1
    load_1_16_7  segment_prefix_lb_1103  1
    load_1_16_7  segment_prefix_ub_1104  1
    load_1_16_7  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_985  -25
    arc_1_16_8  connected_order_arc_986  -11
    arc_1_16_8  in_degree_1106  1
    arc_1_16_8  out_degree_1124  1
    arc_1_16_8  original_T_including_depot_unload_1161  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_985  1
    load_1_16_8  segment_load_conservation_1109  -1
    load_1_16_8  segment_prefix_lb_1110  1
    load_1_16_8  segment_prefix_ub_1111  1
    load_1_16_8  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_987  -25
    arc_1_16_14  connected_order_arc_988  -11
    arc_1_16_14  in_degree_1113  1
    arc_1_16_14  out_degree_1124  1
    arc_1_16_14  original_T_including_depot_unload_1161  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_987  1
    load_1_16_14  free_load_conservation_1117  -1
    load_1_16_14  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_989  -25
    arc_1_16_15  connected_order_arc_990  -11
    arc_1_16_15  in_degree_1119  1
    arc_1_16_15  out_degree_1124  1
    arc_1_16_15  original_T_including_depot_unload_1161  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_989  1
    load_1_16_15  free_load_conservation_1123  -1
    load_1_16_15  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_991  -25
    arc_1_16_17  connected_order_arc_992  -11
    arc_1_16_17  out_degree_1124  1
    arc_1_16_17  in_degree_1131  1
    arc_1_16_17  original_T_including_depot_unload_1161  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_991  1
    load_1_16_17  free_load_conservation_1129  1
    load_1_16_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_993  -25
    arc_1_16_18  connected_order_arc_994  -11
    arc_1_16_18  out_degree_1124  1
    arc_1_16_18  in_degree_1137  1
    arc_1_16_18  original_T_including_depot_unload_1161  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_993  1
    load_1_16_18  free_load_conservation_1129  1
    load_1_16_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_995  -25
    arc_1_16_19  connected_order_arc_996  -11
    arc_1_16_19  out_degree_1124  1
    arc_1_16_19  in_degree_1143  1
    arc_1_16_19  original_T_including_depot_unload_1161  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_995  1
    load_1_16_19  free_load_conservation_1129  1
    load_1_16_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_997  -25
    arc_1_16_20  connected_order_arc_998  -11
    arc_1_16_20  out_degree_1124  1
    arc_1_16_20  in_degree_1149  1
    arc_1_16_20  original_T_including_depot_unload_1161  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_997  1
    load_1_16_20  free_load_conservation_1129  1
    load_1_16_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_999  -25
    arc_1_16_21  connected_order_arc_1000  -11
    arc_1_16_21  out_degree_1124  1
    arc_1_16_21  in_degree_1155  1
    arc_1_16_21  original_T_including_depot_unload_1161  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_999  1
    load_1_16_21  free_load_conservation_1129  1
    load_1_16_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1001  -25
    arc_1_17_0  depot_return_or_bypass_1097  1
    arc_1_17_0  out_degree_1130  1
    arc_1_17_0  original_T_including_depot_unload_1161  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1001  1
    load_1_17_0  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1002  -25
    arc_1_17_7  connected_order_arc_1003  -11
    arc_1_17_7  in_degree_1099  1
    arc_1_17_7  out_degree_1130  1
    arc_1_17_7  original_T_including_depot_unload_1161  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1002  1
    load_1_17_7  segment_load_conservation_1102  -1
    load_1_17_7  segment_prefix_lb_1103  1
    load_1_17_7  segment_prefix_ub_1104  1
    load_1_17_7  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1004  -25
    arc_1_17_8  connected_order_arc_1005  -11
    arc_1_17_8  in_degree_1106  1
    arc_1_17_8  out_degree_1130  1
    arc_1_17_8  original_T_including_depot_unload_1161  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1004  1
    load_1_17_8  segment_load_conservation_1109  -1
    load_1_17_8  segment_prefix_lb_1110  1
    load_1_17_8  segment_prefix_ub_1111  1
    load_1_17_8  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1006  -25
    arc_1_17_14  connected_order_arc_1007  -11
    arc_1_17_14  in_degree_1113  1
    arc_1_17_14  out_degree_1130  1
    arc_1_17_14  original_T_including_depot_unload_1161  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1006  1
    load_1_17_14  free_load_conservation_1117  -1
    load_1_17_14  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1008  -25
    arc_1_17_15  connected_order_arc_1009  -11
    arc_1_17_15  in_degree_1119  1
    arc_1_17_15  out_degree_1130  1
    arc_1_17_15  original_T_including_depot_unload_1161  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1008  1
    load_1_17_15  free_load_conservation_1123  -1
    load_1_17_15  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1010  -25
    arc_1_17_16  connected_order_arc_1011  -11
    arc_1_17_16  in_degree_1125  1
    arc_1_17_16  out_degree_1130  1
    arc_1_17_16  original_T_including_depot_unload_1161  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1010  1
    load_1_17_16  free_load_conservation_1129  -1
    load_1_17_16  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1012  -25
    arc_1_17_18  connected_order_arc_1013  -11
    arc_1_17_18  out_degree_1130  1
    arc_1_17_18  in_degree_1137  1
    arc_1_17_18  original_T_including_depot_unload_1161  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1012  1
    load_1_17_18  free_load_conservation_1135  1
    load_1_17_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1014  -25
    arc_1_17_19  connected_order_arc_1015  -11
    arc_1_17_19  out_degree_1130  1
    arc_1_17_19  in_degree_1143  1
    arc_1_17_19  original_T_including_depot_unload_1161  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1014  1
    load_1_17_19  free_load_conservation_1135  1
    load_1_17_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1016  -25
    arc_1_17_20  connected_order_arc_1017  -11
    arc_1_17_20  out_degree_1130  1
    arc_1_17_20  in_degree_1149  1
    arc_1_17_20  original_T_including_depot_unload_1161  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1016  1
    load_1_17_20  free_load_conservation_1135  1
    load_1_17_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1018  -25
    arc_1_17_21  connected_order_arc_1019  -11
    arc_1_17_21  out_degree_1130  1
    arc_1_17_21  in_degree_1155  1
    arc_1_17_21  original_T_including_depot_unload_1161  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1018  1
    load_1_17_21  free_load_conservation_1135  1
    load_1_17_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1020  -25
    arc_1_18_0  depot_return_or_bypass_1097  1
    arc_1_18_0  out_degree_1136  1
    arc_1_18_0  original_T_including_depot_unload_1161  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1020  1
    load_1_18_0  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1021  -25
    arc_1_18_7  connected_order_arc_1022  -11
    arc_1_18_7  in_degree_1099  1
    arc_1_18_7  out_degree_1136  1
    arc_1_18_7  original_T_including_depot_unload_1161  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1021  1
    load_1_18_7  segment_load_conservation_1102  -1
    load_1_18_7  segment_prefix_lb_1103  1
    load_1_18_7  segment_prefix_ub_1104  1
    load_1_18_7  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1023  -25
    arc_1_18_8  connected_order_arc_1024  -11
    arc_1_18_8  in_degree_1106  1
    arc_1_18_8  out_degree_1136  1
    arc_1_18_8  original_T_including_depot_unload_1161  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1023  1
    load_1_18_8  segment_load_conservation_1109  -1
    load_1_18_8  segment_prefix_lb_1110  1
    load_1_18_8  segment_prefix_ub_1111  1
    load_1_18_8  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1025  -25
    arc_1_18_14  connected_order_arc_1026  -11
    arc_1_18_14  in_degree_1113  1
    arc_1_18_14  out_degree_1136  1
    arc_1_18_14  original_T_including_depot_unload_1161  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1025  1
    load_1_18_14  free_load_conservation_1117  -1
    load_1_18_14  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1027  -25
    arc_1_18_15  connected_order_arc_1028  -11
    arc_1_18_15  in_degree_1119  1
    arc_1_18_15  out_degree_1136  1
    arc_1_18_15  original_T_including_depot_unload_1161  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1027  1
    load_1_18_15  free_load_conservation_1123  -1
    load_1_18_15  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1029  -25
    arc_1_18_16  connected_order_arc_1030  -11
    arc_1_18_16  in_degree_1125  1
    arc_1_18_16  out_degree_1136  1
    arc_1_18_16  original_T_including_depot_unload_1161  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1029  1
    load_1_18_16  free_load_conservation_1129  -1
    load_1_18_16  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1031  -25
    arc_1_18_17  connected_order_arc_1032  -11
    arc_1_18_17  in_degree_1131  1
    arc_1_18_17  out_degree_1136  1
    arc_1_18_17  original_T_including_depot_unload_1161  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1031  1
    load_1_18_17  free_load_conservation_1135  -1
    load_1_18_17  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1033  -25
    arc_1_18_19  connected_order_arc_1034  -11
    arc_1_18_19  out_degree_1136  1
    arc_1_18_19  in_degree_1143  1
    arc_1_18_19  original_T_including_depot_unload_1161  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1033  1
    load_1_18_19  free_load_conservation_1141  1
    load_1_18_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1035  -25
    arc_1_18_20  connected_order_arc_1036  -11
    arc_1_18_20  out_degree_1136  1
    arc_1_18_20  in_degree_1149  1
    arc_1_18_20  original_T_including_depot_unload_1161  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1035  1
    load_1_18_20  free_load_conservation_1141  1
    load_1_18_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1037  -25
    arc_1_18_21  connected_order_arc_1038  -11
    arc_1_18_21  out_degree_1136  1
    arc_1_18_21  in_degree_1155  1
    arc_1_18_21  original_T_including_depot_unload_1161  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1037  1
    load_1_18_21  free_load_conservation_1141  1
    load_1_18_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1039  -25
    arc_1_19_0  depot_return_or_bypass_1097  1
    arc_1_19_0  out_degree_1142  1
    arc_1_19_0  original_T_including_depot_unload_1161  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1039  1
    load_1_19_0  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1040  -25
    arc_1_19_7  connected_order_arc_1041  -11
    arc_1_19_7  in_degree_1099  1
    arc_1_19_7  out_degree_1142  1
    arc_1_19_7  original_T_including_depot_unload_1161  1.5299353443215734e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1040  1
    load_1_19_7  segment_load_conservation_1102  -1
    load_1_19_7  segment_prefix_lb_1103  1
    load_1_19_7  segment_prefix_ub_1104  1
    load_1_19_7  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1042  -25
    arc_1_19_8  connected_order_arc_1043  -11
    arc_1_19_8  in_degree_1106  1
    arc_1_19_8  out_degree_1142  1
    arc_1_19_8  original_T_including_depot_unload_1161  6.1936255305941711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1042  1
    load_1_19_8  segment_load_conservation_1109  -1
    load_1_19_8  segment_prefix_lb_1110  1
    load_1_19_8  segment_prefix_ub_1111  1
    load_1_19_8  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1044  -25
    arc_1_19_14  connected_order_arc_1045  -11
    arc_1_19_14  in_degree_1113  1
    arc_1_19_14  out_degree_1142  1
    arc_1_19_14  original_T_including_depot_unload_1161  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1044  1
    load_1_19_14  free_load_conservation_1117  -1
    load_1_19_14  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1046  -25
    arc_1_19_15  connected_order_arc_1047  -11
    arc_1_19_15  in_degree_1119  1
    arc_1_19_15  out_degree_1142  1
    arc_1_19_15  original_T_including_depot_unload_1161  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1046  1
    load_1_19_15  free_load_conservation_1123  -1
    load_1_19_15  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1048  -25
    arc_1_19_16  connected_order_arc_1049  -11
    arc_1_19_16  in_degree_1125  1
    arc_1_19_16  out_degree_1142  1
    arc_1_19_16  original_T_including_depot_unload_1161  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1048  1
    load_1_19_16  free_load_conservation_1129  -1
    load_1_19_16  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1050  -25
    arc_1_19_17  connected_order_arc_1051  -11
    arc_1_19_17  in_degree_1131  1
    arc_1_19_17  out_degree_1142  1
    arc_1_19_17  original_T_including_depot_unload_1161  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1050  1
    load_1_19_17  free_load_conservation_1135  -1
    load_1_19_17  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1052  -25
    arc_1_19_18  connected_order_arc_1053  -11
    arc_1_19_18  in_degree_1137  1
    arc_1_19_18  out_degree_1142  1
    arc_1_19_18  original_T_including_depot_unload_1161  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1052  1
    load_1_19_18  free_load_conservation_1141  -1
    load_1_19_18  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1054  -25
    arc_1_19_20  connected_order_arc_1055  -11
    arc_1_19_20  out_degree_1142  1
    arc_1_19_20  in_degree_1149  1
    arc_1_19_20  original_T_including_depot_unload_1161  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1054  1
    load_1_19_20  free_load_conservation_1147  1
    load_1_19_20  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1056  -25
    arc_1_19_21  connected_order_arc_1057  -11
    arc_1_19_21  out_degree_1142  1
    arc_1_19_21  in_degree_1155  1
    arc_1_19_21  original_T_including_depot_unload_1161  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1056  1
    load_1_19_21  free_load_conservation_1147  1
    load_1_19_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1058  -25
    arc_1_20_0  depot_return_or_bypass_1097  1
    arc_1_20_0  out_degree_1148  1
    arc_1_20_0  original_T_including_depot_unload_1161  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1058  1
    load_1_20_0  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1059  -25
    arc_1_20_7  connected_order_arc_1060  -11
    arc_1_20_7  in_degree_1099  1
    arc_1_20_7  out_degree_1148  1
    arc_1_20_7  original_T_including_depot_unload_1161  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1059  1
    load_1_20_7  segment_load_conservation_1102  -1
    load_1_20_7  segment_prefix_lb_1103  1
    load_1_20_7  segment_prefix_ub_1104  1
    load_1_20_7  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1061  -25
    arc_1_20_8  connected_order_arc_1062  -11
    arc_1_20_8  in_degree_1106  1
    arc_1_20_8  out_degree_1148  1
    arc_1_20_8  original_T_including_depot_unload_1161  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1061  1
    load_1_20_8  segment_load_conservation_1109  -1
    load_1_20_8  segment_prefix_lb_1110  1
    load_1_20_8  segment_prefix_ub_1111  1
    load_1_20_8  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1063  -25
    arc_1_20_14  connected_order_arc_1064  -11
    arc_1_20_14  in_degree_1113  1
    arc_1_20_14  out_degree_1148  1
    arc_1_20_14  original_T_including_depot_unload_1161  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1063  1
    load_1_20_14  free_load_conservation_1117  -1
    load_1_20_14  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1065  -25
    arc_1_20_15  connected_order_arc_1066  -11
    arc_1_20_15  in_degree_1119  1
    arc_1_20_15  out_degree_1148  1
    arc_1_20_15  original_T_including_depot_unload_1161  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1065  1
    load_1_20_15  free_load_conservation_1123  -1
    load_1_20_15  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1067  -25
    arc_1_20_16  connected_order_arc_1068  -11
    arc_1_20_16  in_degree_1125  1
    arc_1_20_16  out_degree_1148  1
    arc_1_20_16  original_T_including_depot_unload_1161  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1067  1
    load_1_20_16  free_load_conservation_1129  -1
    load_1_20_16  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1069  -25
    arc_1_20_17  connected_order_arc_1070  -11
    arc_1_20_17  in_degree_1131  1
    arc_1_20_17  out_degree_1148  1
    arc_1_20_17  original_T_including_depot_unload_1161  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1069  1
    load_1_20_17  free_load_conservation_1135  -1
    load_1_20_17  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1071  -25
    arc_1_20_18  connected_order_arc_1072  -11
    arc_1_20_18  in_degree_1137  1
    arc_1_20_18  out_degree_1148  1
    arc_1_20_18  original_T_including_depot_unload_1161  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1071  1
    load_1_20_18  free_load_conservation_1141  -1
    load_1_20_18  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1073  -25
    arc_1_20_19  connected_order_arc_1074  -11
    arc_1_20_19  in_degree_1143  1
    arc_1_20_19  out_degree_1148  1
    arc_1_20_19  original_T_including_depot_unload_1161  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1073  1
    load_1_20_19  free_load_conservation_1147  -1
    load_1_20_19  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1075  -25
    arc_1_20_21  connected_order_arc_1076  -11
    arc_1_20_21  out_degree_1148  1
    arc_1_20_21  in_degree_1155  1
    arc_1_20_21  original_T_including_depot_unload_1161  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1075  1
    load_1_20_21  free_load_conservation_1153  1
    load_1_20_21  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1077  -25
    arc_1_21_0  depot_return_or_bypass_1097  1
    arc_1_21_0  out_degree_1154  1
    arc_1_21_0  original_T_including_depot_unload_1161  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1077  1
    load_1_21_0  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1078  -25
    arc_1_21_7  connected_order_arc_1079  -11
    arc_1_21_7  in_degree_1099  1
    arc_1_21_7  out_degree_1154  1
    arc_1_21_7  original_T_including_depot_unload_1161  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1078  1
    load_1_21_7  segment_load_conservation_1102  -1
    load_1_21_7  segment_prefix_lb_1103  1
    load_1_21_7  segment_prefix_ub_1104  1
    load_1_21_7  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1080  -25
    arc_1_21_8  connected_order_arc_1081  -11
    arc_1_21_8  in_degree_1106  1
    arc_1_21_8  out_degree_1154  1
    arc_1_21_8  original_T_including_depot_unload_1161  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1080  1
    load_1_21_8  segment_load_conservation_1109  -1
    load_1_21_8  segment_prefix_lb_1110  1
    load_1_21_8  segment_prefix_ub_1111  1
    load_1_21_8  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1082  -25
    arc_1_21_14  connected_order_arc_1083  -11
    arc_1_21_14  in_degree_1113  1
    arc_1_21_14  out_degree_1154  1
    arc_1_21_14  original_T_including_depot_unload_1161  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1082  1
    load_1_21_14  free_load_conservation_1117  -1
    load_1_21_14  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1084  -25
    arc_1_21_15  connected_order_arc_1085  -11
    arc_1_21_15  in_degree_1119  1
    arc_1_21_15  out_degree_1154  1
    arc_1_21_15  original_T_including_depot_unload_1161  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1084  1
    load_1_21_15  free_load_conservation_1123  -1
    load_1_21_15  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1086  -25
    arc_1_21_16  connected_order_arc_1087  -11
    arc_1_21_16  in_degree_1125  1
    arc_1_21_16  out_degree_1154  1
    arc_1_21_16  original_T_including_depot_unload_1161  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1086  1
    load_1_21_16  free_load_conservation_1129  -1
    load_1_21_16  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1088  -25
    arc_1_21_17  connected_order_arc_1089  -11
    arc_1_21_17  in_degree_1131  1
    arc_1_21_17  out_degree_1154  1
    arc_1_21_17  original_T_including_depot_unload_1161  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1088  1
    load_1_21_17  free_load_conservation_1135  -1
    load_1_21_17  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1090  -25
    arc_1_21_18  connected_order_arc_1091  -11
    arc_1_21_18  in_degree_1137  1
    arc_1_21_18  out_degree_1154  1
    arc_1_21_18  original_T_including_depot_unload_1161  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1090  1
    load_1_21_18  free_load_conservation_1141  -1
    load_1_21_18  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1092  -25
    arc_1_21_19  connected_order_arc_1093  -11
    arc_1_21_19  in_degree_1143  1
    arc_1_21_19  out_degree_1154  1
    arc_1_21_19  original_T_including_depot_unload_1161  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1092  1
    load_1_21_19  free_load_conservation_1147  -1
    load_1_21_19  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1094  -25
    arc_1_21_20  connected_order_arc_1095  -11
    arc_1_21_20  in_degree_1149  1
    arc_1_21_20  out_degree_1154  1
    arc_1_21_20  original_T_including_depot_unload_1161  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1094  1
    load_1_21_20  free_load_conservation_1153  -1
    load_1_21_20  free_load_conservation_1159  1
    visit_2_9  out_degree_1503  -1
    visit_2_9  in_degree_1504  -1
    visit_2_9  order_active_lb_1505  -1
    visit_2_9  order_active_ub_1506  -13
    order_2_9  connected_order_arc_1178  -1
    order_2_9  connected_order_arc_1180  -1
    order_2_9  connected_order_arc_1182  -1
    order_2_9  connected_order_arc_1184  -1
    order_2_9  connected_order_arc_1186  -1
    order_2_9  connected_order_arc_1188  -1
    order_2_9  connected_order_arc_1190  -1
    order_2_9  connected_order_arc_1192  -1
    order_2_9  connected_order_arc_1194  -1
    order_2_9  connected_order_arc_1196  -1
    order_2_9  connected_order_arc_1198  -1
    order_2_9  connected_order_arc_1200  -1
    order_2_9  connected_order_arc_1203  1
    order_2_9  connected_order_arc_1228  1
    order_2_9  connected_order_arc_1253  1
    order_2_9  connected_order_arc_1278  1
    order_2_9  connected_order_arc_1303  1
    order_2_9  connected_order_arc_1328  1
    order_2_9  connected_order_arc_1353  1
    order_2_9  connected_order_arc_1378  1
    order_2_9  connected_order_arc_1403  1
    order_2_9  connected_order_arc_1428  1
    order_2_9  connected_order_arc_1453  1
    order_2_9  connected_order_arc_1478  1
    order_2_9  order_active_lb_1505  1
    order_2_9  order_active_ub_1506  1
    order_2_9  fixed_segment_relative_order_1586  -1
    visit_2_10  out_degree_1510  -1
    visit_2_10  in_degree_1511  -1
    visit_2_10  order_active_lb_1512  -1
    visit_2_10  order_active_ub_1513  -13
    order_2_10  connected_order_arc_1178  1
    order_2_10  connected_order_arc_1203  -1
    order_2_10  connected_order_arc_1205  -1
    order_2_10  connected_order_arc_1207  -1
    order_2_10  connected_order_arc_1209  -1
    order_2_10  connected_order_arc_1211  -1
    order_2_10  connected_order_arc_1213  -1
    order_2_10  connected_order_arc_1215  -1
    order_2_10  connected_order_arc_1217  -1
    order_2_10  connected_order_arc_1219  -1
    order_2_10  connected_order_arc_1221  -1
    order_2_10  connected_order_arc_1223  -1
    order_2_10  connected_order_arc_1225  -1
    order_2_10  connected_order_arc_1230  1
    order_2_10  connected_order_arc_1255  1
    order_2_10  connected_order_arc_1280  1
    order_2_10  connected_order_arc_1305  1
    order_2_10  connected_order_arc_1330  1
    order_2_10  connected_order_arc_1355  1
    order_2_10  connected_order_arc_1380  1
    order_2_10  connected_order_arc_1405  1
    order_2_10  connected_order_arc_1430  1
    order_2_10  connected_order_arc_1455  1
    order_2_10  connected_order_arc_1480  1
    order_2_10  order_active_lb_1512  1
    order_2_10  order_active_ub_1513  1
    order_2_10  fixed_segment_relative_order_1586  1
    order_2_10  fixed_segment_relative_order_1587  -1
    visit_2_11  out_degree_1517  -1
    visit_2_11  in_degree_1518  -1
    visit_2_11  order_active_lb_1519  -1
    visit_2_11  order_active_ub_1520  -13
    order_2_11  connected_order_arc_1180  1
    order_2_11  connected_order_arc_1205  1
    order_2_11  connected_order_arc_1228  -1
    order_2_11  connected_order_arc_1230  -1
    order_2_11  connected_order_arc_1232  -1
    order_2_11  connected_order_arc_1234  -1
    order_2_11  connected_order_arc_1236  -1
    order_2_11  connected_order_arc_1238  -1
    order_2_11  connected_order_arc_1240  -1
    order_2_11  connected_order_arc_1242  -1
    order_2_11  connected_order_arc_1244  -1
    order_2_11  connected_order_arc_1246  -1
    order_2_11  connected_order_arc_1248  -1
    order_2_11  connected_order_arc_1250  -1
    order_2_11  connected_order_arc_1257  1
    order_2_11  connected_order_arc_1282  1
    order_2_11  connected_order_arc_1307  1
    order_2_11  connected_order_arc_1332  1
    order_2_11  connected_order_arc_1357  1
    order_2_11  connected_order_arc_1382  1
    order_2_11  connected_order_arc_1407  1
    order_2_11  connected_order_arc_1432  1
    order_2_11  connected_order_arc_1457  1
    order_2_11  connected_order_arc_1482  1
    order_2_11  order_active_lb_1519  1
    order_2_11  order_active_ub_1520  1
    order_2_11  fixed_segment_relative_order_1587  1
    order_2_11  fixed_segment_relative_order_1588  -1
    visit_2_12  out_degree_1524  -1
    visit_2_12  in_degree_1525  -1
    visit_2_12  order_active_lb_1526  -1
    visit_2_12  order_active_ub_1527  -13
    order_2_12  connected_order_arc_1182  1
    order_2_12  connected_order_arc_1207  1
    order_2_12  connected_order_arc_1232  1
    order_2_12  connected_order_arc_1253  -1
    order_2_12  connected_order_arc_1255  -1
    order_2_12  connected_order_arc_1257  -1
    order_2_12  connected_order_arc_1259  -1
    order_2_12  connected_order_arc_1261  -1
    order_2_12  connected_order_arc_1263  -1
    order_2_12  connected_order_arc_1265  -1
    order_2_12  connected_order_arc_1267  -1
    order_2_12  connected_order_arc_1269  -1
    order_2_12  connected_order_arc_1271  -1
    order_2_12  connected_order_arc_1273  -1
    order_2_12  connected_order_arc_1275  -1
    order_2_12  connected_order_arc_1284  1
    order_2_12  connected_order_arc_1309  1
    order_2_12  connected_order_arc_1334  1
    order_2_12  connected_order_arc_1359  1
    order_2_12  connected_order_arc_1384  1
    order_2_12  connected_order_arc_1409  1
    order_2_12  connected_order_arc_1434  1
    order_2_12  connected_order_arc_1459  1
    order_2_12  connected_order_arc_1484  1
    order_2_12  order_active_lb_1526  1
    order_2_12  order_active_ub_1527  1
    order_2_12  fixed_segment_relative_order_1588  1
    order_2_12  fixed_segment_relative_order_1589  -1
    visit_2_13  out_degree_1531  -1
    visit_2_13  in_degree_1532  -1
    visit_2_13  order_active_lb_1533  -1
    visit_2_13  order_active_ub_1534  -13
    order_2_13  connected_order_arc_1184  1
    order_2_13  connected_order_arc_1209  1
    order_2_13  connected_order_arc_1234  1
    order_2_13  connected_order_arc_1259  1
    order_2_13  connected_order_arc_1278  -1
    order_2_13  connected_order_arc_1280  -1
    order_2_13  connected_order_arc_1282  -1
    order_2_13  connected_order_arc_1284  -1
    order_2_13  connected_order_arc_1286  -1
    order_2_13  connected_order_arc_1288  -1
    order_2_13  connected_order_arc_1290  -1
    order_2_13  connected_order_arc_1292  -1
    order_2_13  connected_order_arc_1294  -1
    order_2_13  connected_order_arc_1296  -1
    order_2_13  connected_order_arc_1298  -1
    order_2_13  connected_order_arc_1300  -1
    order_2_13  connected_order_arc_1311  1
    order_2_13  connected_order_arc_1336  1
    order_2_13  connected_order_arc_1361  1
    order_2_13  connected_order_arc_1386  1
    order_2_13  connected_order_arc_1411  1
    order_2_13  connected_order_arc_1436  1
    order_2_13  connected_order_arc_1461  1
    order_2_13  connected_order_arc_1486  1
    order_2_13  order_active_lb_1533  1
    order_2_13  order_active_ub_1534  1
    order_2_13  fixed_segment_relative_order_1589  1
    visit_2_14  out_degree_1538  -1
    visit_2_14  in_degree_1539  -1
    visit_2_14  order_active_lb_1540  -1
    visit_2_14  order_active_ub_1541  -13
    visit_2_14  service_visit_def_1542  -1
    order_2_14  connected_order_arc_1186  1
    order_2_14  connected_order_arc_1211  1
    order_2_14  connected_order_arc_1236  1
    order_2_14  connected_order_arc_1261  1
    order_2_14  connected_order_arc_1286  1
    order_2_14  connected_order_arc_1303  -1
    order_2_14  connected_order_arc_1305  -1
    order_2_14  connected_order_arc_1307  -1
    order_2_14  connected_order_arc_1309  -1
    order_2_14  connected_order_arc_1311  -1
    order_2_14  connected_order_arc_1313  -1
    order_2_14  connected_order_arc_1315  -1
    order_2_14  connected_order_arc_1317  -1
    order_2_14  connected_order_arc_1319  -1
    order_2_14  connected_order_arc_1321  -1
    order_2_14  connected_order_arc_1323  -1
    order_2_14  connected_order_arc_1325  -1
    order_2_14  connected_order_arc_1338  1
    order_2_14  connected_order_arc_1363  1
    order_2_14  connected_order_arc_1388  1
    order_2_14  connected_order_arc_1413  1
    order_2_14  connected_order_arc_1438  1
    order_2_14  connected_order_arc_1463  1
    order_2_14  connected_order_arc_1488  1
    order_2_14  order_active_lb_1540  1
    order_2_14  order_active_ub_1541  1
    visit_2_15  out_degree_1544  -1
    visit_2_15  in_degree_1545  -1
    visit_2_15  order_active_lb_1546  -1
    visit_2_15  order_active_ub_1547  -13
    visit_2_15  service_visit_def_1548  -1
    order_2_15  connected_order_arc_1188  1
    order_2_15  connected_order_arc_1213  1
    order_2_15  connected_order_arc_1238  1
    order_2_15  connected_order_arc_1263  1
    order_2_15  connected_order_arc_1288  1
    order_2_15  connected_order_arc_1313  1
    order_2_15  connected_order_arc_1328  -1
    order_2_15  connected_order_arc_1330  -1
    order_2_15  connected_order_arc_1332  -1
    order_2_15  connected_order_arc_1334  -1
    order_2_15  connected_order_arc_1336  -1
    order_2_15  connected_order_arc_1338  -1
    order_2_15  connected_order_arc_1340  -1
    order_2_15  connected_order_arc_1342  -1
    order_2_15  connected_order_arc_1344  -1
    order_2_15  connected_order_arc_1346  -1
    order_2_15  connected_order_arc_1348  -1
    order_2_15  connected_order_arc_1350  -1
    order_2_15  connected_order_arc_1365  1
    order_2_15  connected_order_arc_1390  1
    order_2_15  connected_order_arc_1415  1
    order_2_15  connected_order_arc_1440  1
    order_2_15  connected_order_arc_1465  1
    order_2_15  connected_order_arc_1490  1
    order_2_15  order_active_lb_1546  1
    order_2_15  order_active_ub_1547  1
    visit_2_16  out_degree_1550  -1
    visit_2_16  in_degree_1551  -1
    visit_2_16  order_active_lb_1552  -1
    visit_2_16  order_active_ub_1553  -13
    visit_2_16  service_visit_def_1554  -1
    order_2_16  connected_order_arc_1190  1
    order_2_16  connected_order_arc_1215  1
    order_2_16  connected_order_arc_1240  1
    order_2_16  connected_order_arc_1265  1
    order_2_16  connected_order_arc_1290  1
    order_2_16  connected_order_arc_1315  1
    order_2_16  connected_order_arc_1340  1
    order_2_16  connected_order_arc_1353  -1
    order_2_16  connected_order_arc_1355  -1
    order_2_16  connected_order_arc_1357  -1
    order_2_16  connected_order_arc_1359  -1
    order_2_16  connected_order_arc_1361  -1
    order_2_16  connected_order_arc_1363  -1
    order_2_16  connected_order_arc_1365  -1
    order_2_16  connected_order_arc_1367  -1
    order_2_16  connected_order_arc_1369  -1
    order_2_16  connected_order_arc_1371  -1
    order_2_16  connected_order_arc_1373  -1
    order_2_16  connected_order_arc_1375  -1
    order_2_16  connected_order_arc_1392  1
    order_2_16  connected_order_arc_1417  1
    order_2_16  connected_order_arc_1442  1
    order_2_16  connected_order_arc_1467  1
    order_2_16  connected_order_arc_1492  1
    order_2_16  order_active_lb_1552  1
    order_2_16  order_active_ub_1553  1
    visit_2_17  out_degree_1556  -1
    visit_2_17  in_degree_1557  -1
    visit_2_17  order_active_lb_1558  -1
    visit_2_17  order_active_ub_1559  -13
    visit_2_17  service_visit_def_1560  -1
    order_2_17  connected_order_arc_1192  1
    order_2_17  connected_order_arc_1217  1
    order_2_17  connected_order_arc_1242  1
    order_2_17  connected_order_arc_1267  1
    order_2_17  connected_order_arc_1292  1
    order_2_17  connected_order_arc_1317  1
    order_2_17  connected_order_arc_1342  1
    order_2_17  connected_order_arc_1367  1
    order_2_17  connected_order_arc_1378  -1
    order_2_17  connected_order_arc_1380  -1
    order_2_17  connected_order_arc_1382  -1
    order_2_17  connected_order_arc_1384  -1
    order_2_17  connected_order_arc_1386  -1
    order_2_17  connected_order_arc_1388  -1
    order_2_17  connected_order_arc_1390  -1
    order_2_17  connected_order_arc_1392  -1
    order_2_17  connected_order_arc_1394  -1
    order_2_17  connected_order_arc_1396  -1
    order_2_17  connected_order_arc_1398  -1
    order_2_17  connected_order_arc_1400  -1
    order_2_17  connected_order_arc_1419  1
    order_2_17  connected_order_arc_1444  1
    order_2_17  connected_order_arc_1469  1
    order_2_17  connected_order_arc_1494  1
    order_2_17  order_active_lb_1558  1
    order_2_17  order_active_ub_1559  1
    visit_2_18  out_degree_1562  -1
    visit_2_18  in_degree_1563  -1
    visit_2_18  order_active_lb_1564  -1
    visit_2_18  order_active_ub_1565  -13
    visit_2_18  service_visit_def_1566  -1
    order_2_18  connected_order_arc_1194  1
    order_2_18  connected_order_arc_1219  1
    order_2_18  connected_order_arc_1244  1
    order_2_18  connected_order_arc_1269  1
    order_2_18  connected_order_arc_1294  1
    order_2_18  connected_order_arc_1319  1
    order_2_18  connected_order_arc_1344  1
    order_2_18  connected_order_arc_1369  1
    order_2_18  connected_order_arc_1394  1
    order_2_18  connected_order_arc_1403  -1
    order_2_18  connected_order_arc_1405  -1
    order_2_18  connected_order_arc_1407  -1
    order_2_18  connected_order_arc_1409  -1
    order_2_18  connected_order_arc_1411  -1
    order_2_18  connected_order_arc_1413  -1
    order_2_18  connected_order_arc_1415  -1
    order_2_18  connected_order_arc_1417  -1
    order_2_18  connected_order_arc_1419  -1
    order_2_18  connected_order_arc_1421  -1
    order_2_18  connected_order_arc_1423  -1
    order_2_18  connected_order_arc_1425  -1
    order_2_18  connected_order_arc_1446  1
    order_2_18  connected_order_arc_1471  1
    order_2_18  connected_order_arc_1496  1
    order_2_18  order_active_lb_1564  1
    order_2_18  order_active_ub_1565  1
    visit_2_19  out_degree_1568  -1
    visit_2_19  in_degree_1569  -1
    visit_2_19  order_active_lb_1570  -1
    visit_2_19  order_active_ub_1571  -13
    visit_2_19  service_visit_def_1572  -1
    order_2_19  connected_order_arc_1196  1
    order_2_19  connected_order_arc_1221  1
    order_2_19  connected_order_arc_1246  1
    order_2_19  connected_order_arc_1271  1
    order_2_19  connected_order_arc_1296  1
    order_2_19  connected_order_arc_1321  1
    order_2_19  connected_order_arc_1346  1
    order_2_19  connected_order_arc_1371  1
    order_2_19  connected_order_arc_1396  1
    order_2_19  connected_order_arc_1421  1
    order_2_19  connected_order_arc_1428  -1
    order_2_19  connected_order_arc_1430  -1
    order_2_19  connected_order_arc_1432  -1
    order_2_19  connected_order_arc_1434  -1
    order_2_19  connected_order_arc_1436  -1
    order_2_19  connected_order_arc_1438  -1
    order_2_19  connected_order_arc_1440  -1
    order_2_19  connected_order_arc_1442  -1
    order_2_19  connected_order_arc_1444  -1
    order_2_19  connected_order_arc_1446  -1
    order_2_19  connected_order_arc_1448  -1
    order_2_19  connected_order_arc_1450  -1
    order_2_19  connected_order_arc_1473  1
    order_2_19  connected_order_arc_1498  1
    order_2_19  order_active_lb_1570  1
    order_2_19  order_active_ub_1571  1
    visit_2_20  out_degree_1574  -1
    visit_2_20  in_degree_1575  -1
    visit_2_20  order_active_lb_1576  -1
    visit_2_20  order_active_ub_1577  -13
    visit_2_20  service_visit_def_1578  -1
    order_2_20  connected_order_arc_1198  1
    order_2_20  connected_order_arc_1223  1
    order_2_20  connected_order_arc_1248  1
    order_2_20  connected_order_arc_1273  1
    order_2_20  connected_order_arc_1298  1
    order_2_20  connected_order_arc_1323  1
    order_2_20  connected_order_arc_1348  1
    order_2_20  connected_order_arc_1373  1
    order_2_20  connected_order_arc_1398  1
    order_2_20  connected_order_arc_1423  1
    order_2_20  connected_order_arc_1448  1
    order_2_20  connected_order_arc_1453  -1
    order_2_20  connected_order_arc_1455  -1
    order_2_20  connected_order_arc_1457  -1
    order_2_20  connected_order_arc_1459  -1
    order_2_20  connected_order_arc_1461  -1
    order_2_20  connected_order_arc_1463  -1
    order_2_20  connected_order_arc_1465  -1
    order_2_20  connected_order_arc_1467  -1
    order_2_20  connected_order_arc_1469  -1
    order_2_20  connected_order_arc_1471  -1
    order_2_20  connected_order_arc_1473  -1
    order_2_20  connected_order_arc_1475  -1
    order_2_20  connected_order_arc_1500  1
    order_2_20  order_active_lb_1576  1
    order_2_20  order_active_ub_1577  1
    visit_2_21  out_degree_1580  -1
    visit_2_21  in_degree_1581  -1
    visit_2_21  order_active_lb_1582  -1
    visit_2_21  order_active_ub_1583  -13
    visit_2_21  service_visit_def_1584  -1
    order_2_21  connected_order_arc_1200  1
    order_2_21  connected_order_arc_1225  1
    order_2_21  connected_order_arc_1250  1
    order_2_21  connected_order_arc_1275  1
    order_2_21  connected_order_arc_1300  1
    order_2_21  connected_order_arc_1325  1
    order_2_21  connected_order_arc_1350  1
    order_2_21  connected_order_arc_1375  1
    order_2_21  connected_order_arc_1400  1
    order_2_21  connected_order_arc_1425  1
    order_2_21  connected_order_arc_1450  1
    order_2_21  connected_order_arc_1475  1
    order_2_21  connected_order_arc_1478  -1
    order_2_21  connected_order_arc_1480  -1
    order_2_21  connected_order_arc_1482  -1
    order_2_21  connected_order_arc_1484  -1
    order_2_21  connected_order_arc_1486  -1
    order_2_21  connected_order_arc_1488  -1
    order_2_21  connected_order_arc_1490  -1
    order_2_21  connected_order_arc_1492  -1
    order_2_21  connected_order_arc_1494  -1
    order_2_21  connected_order_arc_1496  -1
    order_2_21  connected_order_arc_1498  -1
    order_2_21  connected_order_arc_1500  -1
    order_2_21  order_active_lb_1582  1
    order_2_21  order_active_ub_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1162  -30
    arc_2_0_0  depot_departure_or_bypass_1501  1
    arc_2_0_0  depot_return_or_bypass_1502  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1163  -30
    arc_2_0_9  depot_departure_or_bypass_1501  1
    arc_2_0_9  in_degree_1504  1
    arc_2_0_9  original_T_including_depot_unload_1590  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1163  1
    load_2_0_9  segment_load_conservation_1507  -1
    load_2_0_9  segment_prefix_lb_1508  1
    load_2_0_9  segment_prefix_ub_1509  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1164  -30
    arc_2_0_10  depot_departure_or_bypass_1501  1
    arc_2_0_10  in_degree_1511  1
    arc_2_0_10  original_T_including_depot_unload_1590  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1164  1
    load_2_0_10  segment_load_conservation_1514  -1
    load_2_0_10  segment_prefix_lb_1515  1
    load_2_0_10  segment_prefix_ub_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1165  -30
    arc_2_0_11  depot_departure_or_bypass_1501  1
    arc_2_0_11  in_degree_1518  1
    arc_2_0_11  original_T_including_depot_unload_1590  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1165  1
    load_2_0_11  segment_load_conservation_1521  -1
    load_2_0_11  segment_prefix_lb_1522  1
    load_2_0_11  segment_prefix_ub_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1166  -30
    arc_2_0_12  depot_departure_or_bypass_1501  1
    arc_2_0_12  in_degree_1525  1
    arc_2_0_12  original_T_including_depot_unload_1590  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1166  1
    load_2_0_12  segment_load_conservation_1528  -1
    load_2_0_12  segment_prefix_lb_1529  1
    load_2_0_12  segment_prefix_ub_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1167  -30
    arc_2_0_13  depot_departure_or_bypass_1501  1
    arc_2_0_13  in_degree_1532  1
    arc_2_0_13  original_T_including_depot_unload_1590  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1167  1
    load_2_0_13  segment_load_conservation_1535  -1
    load_2_0_13  segment_prefix_lb_1536  1
    load_2_0_13  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1168  -30
    arc_2_0_14  depot_departure_or_bypass_1501  1
    arc_2_0_14  in_degree_1539  1
    arc_2_0_14  original_T_including_depot_unload_1590  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1168  1
    load_2_0_14  free_load_conservation_1543  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1169  -30
    arc_2_0_15  depot_departure_or_bypass_1501  1
    arc_2_0_15  in_degree_1545  1
    arc_2_0_15  original_T_including_depot_unload_1590  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1169  1
    load_2_0_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1170  -30
    arc_2_0_16  depot_departure_or_bypass_1501  1
    arc_2_0_16  in_degree_1551  1
    arc_2_0_16  original_T_including_depot_unload_1590  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1170  1
    load_2_0_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1171  -30
    arc_2_0_17  depot_departure_or_bypass_1501  1
    arc_2_0_17  in_degree_1557  1
    arc_2_0_17  original_T_including_depot_unload_1590  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1171  1
    load_2_0_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1172  -30
    arc_2_0_18  depot_departure_or_bypass_1501  1
    arc_2_0_18  in_degree_1563  1
    arc_2_0_18  original_T_including_depot_unload_1590  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1172  1
    load_2_0_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1173  -30
    arc_2_0_19  depot_departure_or_bypass_1501  1
    arc_2_0_19  in_degree_1569  1
    arc_2_0_19  original_T_including_depot_unload_1590  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1173  1
    load_2_0_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1174  -30
    arc_2_0_20  depot_departure_or_bypass_1501  1
    arc_2_0_20  in_degree_1575  1
    arc_2_0_20  original_T_including_depot_unload_1590  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1174  1
    load_2_0_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1175  -30
    arc_2_0_21  depot_departure_or_bypass_1501  1
    arc_2_0_21  in_degree_1581  1
    arc_2_0_21  original_T_including_depot_unload_1590  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1175  1
    load_2_0_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1176  -30
    arc_2_9_0  depot_return_or_bypass_1502  1
    arc_2_9_0  out_degree_1503  1
    arc_2_9_0  original_T_including_depot_unload_1590  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1176  1
    load_2_9_0  segment_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1177  -30
    arc_2_9_10  connected_order_arc_1178  -14
    arc_2_9_10  out_degree_1503  1
    arc_2_9_10  in_degree_1511  1
    arc_2_9_10  original_T_including_depot_unload_1590  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1177  1
    load_2_9_10  segment_load_conservation_1507  1
    load_2_9_10  segment_load_conservation_1514  -1
    load_2_9_10  segment_prefix_lb_1515  1
    load_2_9_10  segment_prefix_ub_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1179  -30
    arc_2_9_11  connected_order_arc_1180  -14
    arc_2_9_11  out_degree_1503  1
    arc_2_9_11  in_degree_1518  1
    arc_2_9_11  original_T_including_depot_unload_1590  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1179  1
    load_2_9_11  segment_load_conservation_1507  1
    load_2_9_11  segment_load_conservation_1521  -1
    load_2_9_11  segment_prefix_lb_1522  1
    load_2_9_11  segment_prefix_ub_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1181  -30
    arc_2_9_12  connected_order_arc_1182  -14
    arc_2_9_12  out_degree_1503  1
    arc_2_9_12  in_degree_1525  1
    arc_2_9_12  original_T_including_depot_unload_1590  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1181  1
    load_2_9_12  segment_load_conservation_1507  1
    load_2_9_12  segment_load_conservation_1528  -1
    load_2_9_12  segment_prefix_lb_1529  1
    load_2_9_12  segment_prefix_ub_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1183  -30
    arc_2_9_13  connected_order_arc_1184  -14
    arc_2_9_13  out_degree_1503  1
    arc_2_9_13  in_degree_1532  1
    arc_2_9_13  original_T_including_depot_unload_1590  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1183  1
    load_2_9_13  segment_load_conservation_1507  1
    load_2_9_13  segment_load_conservation_1535  -1
    load_2_9_13  segment_prefix_lb_1536  1
    load_2_9_13  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1185  -30
    arc_2_9_14  connected_order_arc_1186  -14
    arc_2_9_14  out_degree_1503  1
    arc_2_9_14  in_degree_1539  1
    arc_2_9_14  original_T_including_depot_unload_1590  1.3923205390152336e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1185  1
    load_2_9_14  segment_load_conservation_1507  1
    load_2_9_14  free_load_conservation_1543  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1187  -30
    arc_2_9_15  connected_order_arc_1188  -14
    arc_2_9_15  out_degree_1503  1
    arc_2_9_15  in_degree_1545  1
    arc_2_9_15  original_T_including_depot_unload_1590  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1187  1
    load_2_9_15  segment_load_conservation_1507  1
    load_2_9_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1189  -30
    arc_2_9_16  connected_order_arc_1190  -14
    arc_2_9_16  out_degree_1503  1
    arc_2_9_16  in_degree_1551  1
    arc_2_9_16  original_T_including_depot_unload_1590  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1189  1
    load_2_9_16  segment_load_conservation_1507  1
    load_2_9_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1191  -30
    arc_2_9_17  connected_order_arc_1192  -14
    arc_2_9_17  out_degree_1503  1
    arc_2_9_17  in_degree_1557  1
    arc_2_9_17  original_T_including_depot_unload_1590  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1191  1
    load_2_9_17  segment_load_conservation_1507  1
    load_2_9_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1193  -30
    arc_2_9_18  connected_order_arc_1194  -14
    arc_2_9_18  out_degree_1503  1
    arc_2_9_18  in_degree_1563  1
    arc_2_9_18  original_T_including_depot_unload_1590  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1193  1
    load_2_9_18  segment_load_conservation_1507  1
    load_2_9_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1195  -30
    arc_2_9_19  connected_order_arc_1196  -14
    arc_2_9_19  out_degree_1503  1
    arc_2_9_19  in_degree_1569  1
    arc_2_9_19  original_T_including_depot_unload_1590  1.6748602054274218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1195  1
    load_2_9_19  segment_load_conservation_1507  1
    load_2_9_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_20  arc_capacity_1197  -30
    arc_2_9_20  connected_order_arc_1198  -14
    arc_2_9_20  out_degree_1503  1
    arc_2_9_20  in_degree_1575  1
    arc_2_9_20  original_T_including_depot_unload_1590  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_20  arc_capacity_1197  1
    load_2_9_20  segment_load_conservation_1507  1
    load_2_9_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_21  arc_capacity_1199  -30
    arc_2_9_21  connected_order_arc_1200  -14
    arc_2_9_21  out_degree_1503  1
    arc_2_9_21  in_degree_1581  1
    arc_2_9_21  original_T_including_depot_unload_1590  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_21  arc_capacity_1199  1
    load_2_9_21  segment_load_conservation_1507  1
    load_2_9_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1201  -30
    arc_2_10_0  depot_return_or_bypass_1502  1
    arc_2_10_0  out_degree_1510  1
    arc_2_10_0  original_T_including_depot_unload_1590  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1201  1
    load_2_10_0  segment_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1202  -30
    arc_2_10_9  connected_order_arc_1203  -14
    arc_2_10_9  in_degree_1504  1
    arc_2_10_9  out_degree_1510  1
    arc_2_10_9  original_T_including_depot_unload_1590  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1202  1
    load_2_10_9  segment_load_conservation_1507  -1
    load_2_10_9  segment_prefix_lb_1508  1
    load_2_10_9  segment_prefix_ub_1509  1
    load_2_10_9  segment_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1204  -30
    arc_2_10_11  connected_order_arc_1205  -14
    arc_2_10_11  out_degree_1510  1
    arc_2_10_11  in_degree_1518  1
    arc_2_10_11  original_T_including_depot_unload_1590  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1204  1
    load_2_10_11  segment_load_conservation_1514  1
    load_2_10_11  segment_load_conservation_1521  -1
    load_2_10_11  segment_prefix_lb_1522  1
    load_2_10_11  segment_prefix_ub_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1206  -30
    arc_2_10_12  connected_order_arc_1207  -14
    arc_2_10_12  out_degree_1510  1
    arc_2_10_12  in_degree_1525  1
    arc_2_10_12  original_T_including_depot_unload_1590  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1206  1
    load_2_10_12  segment_load_conservation_1514  1
    load_2_10_12  segment_load_conservation_1528  -1
    load_2_10_12  segment_prefix_lb_1529  1
    load_2_10_12  segment_prefix_ub_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1208  -30
    arc_2_10_13  connected_order_arc_1209  -14
    arc_2_10_13  out_degree_1510  1
    arc_2_10_13  in_degree_1532  1
    arc_2_10_13  original_T_including_depot_unload_1590  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1208  1
    load_2_10_13  segment_load_conservation_1514  1
    load_2_10_13  segment_load_conservation_1535  -1
    load_2_10_13  segment_prefix_lb_1536  1
    load_2_10_13  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1210  -30
    arc_2_10_14  connected_order_arc_1211  -14
    arc_2_10_14  out_degree_1510  1
    arc_2_10_14  in_degree_1539  1
    arc_2_10_14  original_T_including_depot_unload_1590  2.1118429424496589e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1210  1
    load_2_10_14  segment_load_conservation_1514  1
    load_2_10_14  free_load_conservation_1543  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1212  -30
    arc_2_10_15  connected_order_arc_1213  -14
    arc_2_10_15  out_degree_1510  1
    arc_2_10_15  in_degree_1545  1
    arc_2_10_15  original_T_including_depot_unload_1590  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1212  1
    load_2_10_15  segment_load_conservation_1514  1
    load_2_10_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1214  -30
    arc_2_10_16  connected_order_arc_1215  -14
    arc_2_10_16  out_degree_1510  1
    arc_2_10_16  in_degree_1551  1
    arc_2_10_16  original_T_including_depot_unload_1590  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1214  1
    load_2_10_16  segment_load_conservation_1514  1
    load_2_10_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1216  -30
    arc_2_10_17  connected_order_arc_1217  -14
    arc_2_10_17  out_degree_1510  1
    arc_2_10_17  in_degree_1557  1
    arc_2_10_17  original_T_including_depot_unload_1590  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1216  1
    load_2_10_17  segment_load_conservation_1514  1
    load_2_10_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1218  -30
    arc_2_10_18  connected_order_arc_1219  -14
    arc_2_10_18  out_degree_1510  1
    arc_2_10_18  in_degree_1563  1
    arc_2_10_18  original_T_including_depot_unload_1590  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1218  1
    load_2_10_18  segment_load_conservation_1514  1
    load_2_10_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1220  -30
    arc_2_10_19  connected_order_arc_1221  -14
    arc_2_10_19  out_degree_1510  1
    arc_2_10_19  in_degree_1569  1
    arc_2_10_19  original_T_including_depot_unload_1590  2.3329109849823212e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1220  1
    load_2_10_19  segment_load_conservation_1514  1
    load_2_10_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1222  -30
    arc_2_10_20  connected_order_arc_1223  -14
    arc_2_10_20  out_degree_1510  1
    arc_2_10_20  in_degree_1575  1
    arc_2_10_20  original_T_including_depot_unload_1590  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1222  1
    load_2_10_20  segment_load_conservation_1514  1
    load_2_10_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1224  -30
    arc_2_10_21  connected_order_arc_1225  -14
    arc_2_10_21  out_degree_1510  1
    arc_2_10_21  in_degree_1581  1
    arc_2_10_21  original_T_including_depot_unload_1590  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1224  1
    load_2_10_21  segment_load_conservation_1514  1
    load_2_10_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1226  -30
    arc_2_11_0  depot_return_or_bypass_1502  1
    arc_2_11_0  out_degree_1517  1
    arc_2_11_0  original_T_including_depot_unload_1590  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1226  1
    load_2_11_0  segment_load_conservation_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1227  -30
    arc_2_11_9  connected_order_arc_1228  -14
    arc_2_11_9  in_degree_1504  1
    arc_2_11_9  out_degree_1517  1
    arc_2_11_9  original_T_including_depot_unload_1590  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1227  1
    load_2_11_9  segment_load_conservation_1507  -1
    load_2_11_9  segment_prefix_lb_1508  1
    load_2_11_9  segment_prefix_ub_1509  1
    load_2_11_9  segment_load_conservation_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1229  -30
    arc_2_11_10  connected_order_arc_1230  -14
    arc_2_11_10  in_degree_1511  1
    arc_2_11_10  out_degree_1517  1
    arc_2_11_10  original_T_including_depot_unload_1590  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1229  1
    load_2_11_10  segment_load_conservation_1514  -1
    load_2_11_10  segment_prefix_lb_1515  1
    load_2_11_10  segment_prefix_ub_1516  1
    load_2_11_10  segment_load_conservation_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1231  -30
    arc_2_11_12  connected_order_arc_1232  -14
    arc_2_11_12  out_degree_1517  1
    arc_2_11_12  in_degree_1525  1
    arc_2_11_12  original_T_including_depot_unload_1590  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1231  1
    load_2_11_12  segment_load_conservation_1521  1
    load_2_11_12  segment_load_conservation_1528  -1
    load_2_11_12  segment_prefix_lb_1529  1
    load_2_11_12  segment_prefix_ub_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1233  -30
    arc_2_11_13  connected_order_arc_1234  -14
    arc_2_11_13  out_degree_1517  1
    arc_2_11_13  in_degree_1532  1
    arc_2_11_13  original_T_including_depot_unload_1590  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1233  1
    load_2_11_13  segment_load_conservation_1521  1
    load_2_11_13  segment_load_conservation_1535  -1
    load_2_11_13  segment_prefix_lb_1536  1
    load_2_11_13  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1235  -30
    arc_2_11_14  connected_order_arc_1236  -14
    arc_2_11_14  out_degree_1517  1
    arc_2_11_14  in_degree_1539  1
    arc_2_11_14  original_T_including_depot_unload_1590  2.0573170852107110e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1235  1
    load_2_11_14  segment_load_conservation_1521  1
    load_2_11_14  free_load_conservation_1543  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1237  -30
    arc_2_11_15  connected_order_arc_1238  -14
    arc_2_11_15  out_degree_1517  1
    arc_2_11_15  in_degree_1545  1
    arc_2_11_15  original_T_including_depot_unload_1590  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1237  1
    load_2_11_15  segment_load_conservation_1521  1
    load_2_11_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1239  -30
    arc_2_11_16  connected_order_arc_1240  -14
    arc_2_11_16  out_degree_1517  1
    arc_2_11_16  in_degree_1551  1
    arc_2_11_16  original_T_including_depot_unload_1590  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1239  1
    load_2_11_16  segment_load_conservation_1521  1
    load_2_11_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1241  -30
    arc_2_11_17  connected_order_arc_1242  -14
    arc_2_11_17  out_degree_1517  1
    arc_2_11_17  in_degree_1557  1
    arc_2_11_17  original_T_including_depot_unload_1590  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1241  1
    load_2_11_17  segment_load_conservation_1521  1
    load_2_11_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1243  -30
    arc_2_11_18  connected_order_arc_1244  -14
    arc_2_11_18  out_degree_1517  1
    arc_2_11_18  in_degree_1563  1
    arc_2_11_18  original_T_including_depot_unload_1590  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1243  1
    load_2_11_18  segment_load_conservation_1521  1
    load_2_11_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1245  -30
    arc_2_11_19  connected_order_arc_1246  -14
    arc_2_11_19  out_degree_1517  1
    arc_2_11_19  in_degree_1569  1
    arc_2_11_19  original_T_including_depot_unload_1590  2.3162349395019428e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1245  1
    load_2_11_19  segment_load_conservation_1521  1
    load_2_11_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1247  -30
    arc_2_11_20  connected_order_arc_1248  -14
    arc_2_11_20  out_degree_1517  1
    arc_2_11_20  in_degree_1575  1
    arc_2_11_20  original_T_including_depot_unload_1590  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1247  1
    load_2_11_20  segment_load_conservation_1521  1
    load_2_11_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1249  -30
    arc_2_11_21  connected_order_arc_1250  -14
    arc_2_11_21  out_degree_1517  1
    arc_2_11_21  in_degree_1581  1
    arc_2_11_21  original_T_including_depot_unload_1590  2.3310908183310389e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1249  1
    load_2_11_21  segment_load_conservation_1521  1
    load_2_11_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1251  -30
    arc_2_12_0  depot_return_or_bypass_1502  1
    arc_2_12_0  out_degree_1524  1
    arc_2_12_0  original_T_including_depot_unload_1590  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1251  1
    load_2_12_0  segment_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1252  -30
    arc_2_12_9  connected_order_arc_1253  -14
    arc_2_12_9  in_degree_1504  1
    arc_2_12_9  out_degree_1524  1
    arc_2_12_9  original_T_including_depot_unload_1590  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1252  1
    load_2_12_9  segment_load_conservation_1507  -1
    load_2_12_9  segment_prefix_lb_1508  1
    load_2_12_9  segment_prefix_ub_1509  1
    load_2_12_9  segment_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1254  -30
    arc_2_12_10  connected_order_arc_1255  -14
    arc_2_12_10  in_degree_1511  1
    arc_2_12_10  out_degree_1524  1
    arc_2_12_10  original_T_including_depot_unload_1590  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1254  1
    load_2_12_10  segment_load_conservation_1514  -1
    load_2_12_10  segment_prefix_lb_1515  1
    load_2_12_10  segment_prefix_ub_1516  1
    load_2_12_10  segment_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1256  -30
    arc_2_12_11  connected_order_arc_1257  -14
    arc_2_12_11  in_degree_1518  1
    arc_2_12_11  out_degree_1524  1
    arc_2_12_11  original_T_including_depot_unload_1590  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1256  1
    load_2_12_11  segment_load_conservation_1521  -1
    load_2_12_11  segment_prefix_lb_1522  1
    load_2_12_11  segment_prefix_ub_1523  1
    load_2_12_11  segment_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1258  -30
    arc_2_12_13  connected_order_arc_1259  -14
    arc_2_12_13  out_degree_1524  1
    arc_2_12_13  in_degree_1532  1
    arc_2_12_13  original_T_including_depot_unload_1590  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1258  1
    load_2_12_13  segment_load_conservation_1528  1
    load_2_12_13  segment_load_conservation_1535  -1
    load_2_12_13  segment_prefix_lb_1536  1
    load_2_12_13  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1260  -30
    arc_2_12_14  connected_order_arc_1261  -14
    arc_2_12_14  out_degree_1524  1
    arc_2_12_14  in_degree_1539  1
    arc_2_12_14  original_T_including_depot_unload_1590  1.8021002410302701e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1260  1
    load_2_12_14  segment_load_conservation_1528  1
    load_2_12_14  free_load_conservation_1543  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1262  -30
    arc_2_12_15  connected_order_arc_1263  -14
    arc_2_12_15  out_degree_1524  1
    arc_2_12_15  in_degree_1545  1
    arc_2_12_15  original_T_including_depot_unload_1590  1.9305399866194357e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1262  1
    load_2_12_15  segment_load_conservation_1528  1
    load_2_12_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1264  -30
    arc_2_12_16  connected_order_arc_1265  -14
    arc_2_12_16  out_degree_1524  1
    arc_2_12_16  in_degree_1551  1
    arc_2_12_16  original_T_including_depot_unload_1590  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1264  1
    load_2_12_16  segment_load_conservation_1528  1
    load_2_12_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1266  -30
    arc_2_12_17  connected_order_arc_1267  -14
    arc_2_12_17  out_degree_1524  1
    arc_2_12_17  in_degree_1557  1
    arc_2_12_17  original_T_including_depot_unload_1590  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1266  1
    load_2_12_17  segment_load_conservation_1528  1
    load_2_12_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1268  -30
    arc_2_12_18  connected_order_arc_1269  -14
    arc_2_12_18  out_degree_1524  1
    arc_2_12_18  in_degree_1563  1
    arc_2_12_18  original_T_including_depot_unload_1590  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1268  1
    load_2_12_18  segment_load_conservation_1528  1
    load_2_12_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1270  -30
    arc_2_12_19  connected_order_arc_1271  -14
    arc_2_12_19  out_degree_1524  1
    arc_2_12_19  in_degree_1569  1
    arc_2_12_19  original_T_including_depot_unload_1590  2.2374987321387907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1270  1
    load_2_12_19  segment_load_conservation_1528  1
    load_2_12_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1272  -30
    arc_2_12_20  connected_order_arc_1273  -14
    arc_2_12_20  out_degree_1524  1
    arc_2_12_20  in_degree_1575  1
    arc_2_12_20  original_T_including_depot_unload_1590  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1272  1
    load_2_12_20  segment_load_conservation_1528  1
    load_2_12_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1274  -30
    arc_2_12_21  connected_order_arc_1275  -14
    arc_2_12_21  out_degree_1524  1
    arc_2_12_21  in_degree_1581  1
    arc_2_12_21  original_T_including_depot_unload_1590  2.3225285101968207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1274  1
    load_2_12_21  segment_load_conservation_1528  1
    load_2_12_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1276  -30
    arc_2_13_0  depot_return_or_bypass_1502  1
    arc_2_13_0  out_degree_1531  1
    arc_2_13_0  original_T_including_depot_unload_1590  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1276  1
    load_2_13_0  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1277  -30
    arc_2_13_9  connected_order_arc_1278  -14
    arc_2_13_9  in_degree_1504  1
    arc_2_13_9  out_degree_1531  1
    arc_2_13_9  original_T_including_depot_unload_1590  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1277  1
    load_2_13_9  segment_load_conservation_1507  -1
    load_2_13_9  segment_prefix_lb_1508  1
    load_2_13_9  segment_prefix_ub_1509  1
    load_2_13_9  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1279  -30
    arc_2_13_10  connected_order_arc_1280  -14
    arc_2_13_10  in_degree_1511  1
    arc_2_13_10  out_degree_1531  1
    arc_2_13_10  original_T_including_depot_unload_1590  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1279  1
    load_2_13_10  segment_load_conservation_1514  -1
    load_2_13_10  segment_prefix_lb_1515  1
    load_2_13_10  segment_prefix_ub_1516  1
    load_2_13_10  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1281  -30
    arc_2_13_11  connected_order_arc_1282  -14
    arc_2_13_11  in_degree_1518  1
    arc_2_13_11  out_degree_1531  1
    arc_2_13_11  original_T_including_depot_unload_1590  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1281  1
    load_2_13_11  segment_load_conservation_1521  -1
    load_2_13_11  segment_prefix_lb_1522  1
    load_2_13_11  segment_prefix_ub_1523  1
    load_2_13_11  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1283  -30
    arc_2_13_12  connected_order_arc_1284  -14
    arc_2_13_12  in_degree_1525  1
    arc_2_13_12  out_degree_1531  1
    arc_2_13_12  original_T_including_depot_unload_1590  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1283  1
    load_2_13_12  segment_load_conservation_1528  -1
    load_2_13_12  segment_prefix_lb_1529  1
    load_2_13_12  segment_prefix_ub_1530  1
    load_2_13_12  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1285  -30
    arc_2_13_14  connected_order_arc_1286  -14
    arc_2_13_14  out_degree_1531  1
    arc_2_13_14  in_degree_1539  1
    arc_2_13_14  original_T_including_depot_unload_1590  1.4636929855741182e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1285  1
    load_2_13_14  segment_load_conservation_1535  1
    load_2_13_14  free_load_conservation_1543  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1287  -30
    arc_2_13_15  connected_order_arc_1288  -14
    arc_2_13_15  out_degree_1531  1
    arc_2_13_15  in_degree_1545  1
    arc_2_13_15  original_T_including_depot_unload_1590  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1287  1
    load_2_13_15  segment_load_conservation_1535  1
    load_2_13_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1289  -30
    arc_2_13_16  connected_order_arc_1290  -14
    arc_2_13_16  out_degree_1531  1
    arc_2_13_16  in_degree_1551  1
    arc_2_13_16  original_T_including_depot_unload_1590  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1289  1
    load_2_13_16  segment_load_conservation_1535  1
    load_2_13_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1291  -30
    arc_2_13_17  connected_order_arc_1292  -14
    arc_2_13_17  out_degree_1531  1
    arc_2_13_17  in_degree_1557  1
    arc_2_13_17  original_T_including_depot_unload_1590  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1291  1
    load_2_13_17  segment_load_conservation_1535  1
    load_2_13_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1293  -30
    arc_2_13_18  connected_order_arc_1294  -14
    arc_2_13_18  out_degree_1531  1
    arc_2_13_18  in_degree_1563  1
    arc_2_13_18  original_T_including_depot_unload_1590  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1293  1
    load_2_13_18  segment_load_conservation_1535  1
    load_2_13_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1295  -30
    arc_2_13_19  connected_order_arc_1296  -14
    arc_2_13_19  out_degree_1531  1
    arc_2_13_19  in_degree_1569  1
    arc_2_13_19  original_T_including_depot_unload_1590  1.8134227723553629e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1295  1
    load_2_13_19  segment_load_conservation_1535  1
    load_2_13_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1297  -30
    arc_2_13_20  connected_order_arc_1298  -14
    arc_2_13_20  out_degree_1531  1
    arc_2_13_20  in_degree_1575  1
    arc_2_13_20  original_T_including_depot_unload_1590  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1297  1
    load_2_13_20  segment_load_conservation_1535  1
    load_2_13_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1299  -30
    arc_2_13_21  connected_order_arc_1300  -14
    arc_2_13_21  out_degree_1531  1
    arc_2_13_21  in_degree_1581  1
    arc_2_13_21  original_T_including_depot_unload_1590  1.8614801653445954e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1299  1
    load_2_13_21  segment_load_conservation_1535  1
    load_2_13_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1301  -30
    arc_2_14_0  depot_return_or_bypass_1502  1
    arc_2_14_0  out_degree_1538  1
    arc_2_14_0  original_T_including_depot_unload_1590  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1301  1
    load_2_14_0  free_load_conservation_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1302  -30
    arc_2_14_9  connected_order_arc_1303  -14
    arc_2_14_9  in_degree_1504  1
    arc_2_14_9  out_degree_1538  1
    arc_2_14_9  original_T_including_depot_unload_1590  1.3923205390152336e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1302  1
    load_2_14_9  segment_load_conservation_1507  -1
    load_2_14_9  segment_prefix_lb_1508  1
    load_2_14_9  segment_prefix_ub_1509  1
    load_2_14_9  free_load_conservation_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1304  -30
    arc_2_14_10  connected_order_arc_1305  -14
    arc_2_14_10  in_degree_1511  1
    arc_2_14_10  out_degree_1538  1
    arc_2_14_10  original_T_including_depot_unload_1590  2.1118429424496589e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1304  1
    load_2_14_10  segment_load_conservation_1514  -1
    load_2_14_10  segment_prefix_lb_1515  1
    load_2_14_10  segment_prefix_ub_1516  1
    load_2_14_10  free_load_conservation_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1306  -30
    arc_2_14_11  connected_order_arc_1307  -14
    arc_2_14_11  in_degree_1518  1
    arc_2_14_11  out_degree_1538  1
    arc_2_14_11  original_T_including_depot_unload_1590  2.0573170852107110e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1306  1
    load_2_14_11  segment_load_conservation_1521  -1
    load_2_14_11  segment_prefix_lb_1522  1
    load_2_14_11  segment_prefix_ub_1523  1
    load_2_14_11  free_load_conservation_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1308  -30
    arc_2_14_12  connected_order_arc_1309  -14
    arc_2_14_12  in_degree_1525  1
    arc_2_14_12  out_degree_1538  1
    arc_2_14_12  original_T_including_depot_unload_1590  1.9444044143793826e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1308  1
    load_2_14_12  segment_load_conservation_1528  -1
    load_2_14_12  segment_prefix_lb_1529  1
    load_2_14_12  segment_prefix_ub_1530  1
    load_2_14_12  free_load_conservation_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1310  -30
    arc_2_14_13  connected_order_arc_1311  -14
    arc_2_14_13  in_degree_1532  1
    arc_2_14_13  out_degree_1538  1
    arc_2_14_13  original_T_including_depot_unload_1590  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1310  1
    load_2_14_13  segment_load_conservation_1535  -1
    load_2_14_13  segment_prefix_lb_1536  1
    load_2_14_13  segment_prefix_ub_1537  1
    load_2_14_13  free_load_conservation_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1312  -30
    arc_2_14_15  connected_order_arc_1313  -14
    arc_2_14_15  out_degree_1538  1
    arc_2_14_15  in_degree_1545  1
    arc_2_14_15  original_T_including_depot_unload_1590  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1312  1
    load_2_14_15  free_load_conservation_1543  1
    load_2_14_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1314  -30
    arc_2_14_16  connected_order_arc_1315  -14
    arc_2_14_16  out_degree_1538  1
    arc_2_14_16  in_degree_1551  1
    arc_2_14_16  original_T_including_depot_unload_1590  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1314  1
    load_2_14_16  free_load_conservation_1543  1
    load_2_14_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1316  -30
    arc_2_14_17  connected_order_arc_1317  -14
    arc_2_14_17  out_degree_1538  1
    arc_2_14_17  in_degree_1557  1
    arc_2_14_17  original_T_including_depot_unload_1590  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1316  1
    load_2_14_17  free_load_conservation_1543  1
    load_2_14_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1318  -30
    arc_2_14_18  connected_order_arc_1319  -14
    arc_2_14_18  out_degree_1538  1
    arc_2_14_18  in_degree_1563  1
    arc_2_14_18  original_T_including_depot_unload_1590  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1318  1
    load_2_14_18  free_load_conservation_1543  1
    load_2_14_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1320  -30
    arc_2_14_19  connected_order_arc_1321  -14
    arc_2_14_19  out_degree_1538  1
    arc_2_14_19  in_degree_1569  1
    arc_2_14_19  original_T_including_depot_unload_1590  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1320  1
    load_2_14_19  free_load_conservation_1543  1
    load_2_14_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1322  -30
    arc_2_14_20  connected_order_arc_1323  -14
    arc_2_14_20  out_degree_1538  1
    arc_2_14_20  in_degree_1575  1
    arc_2_14_20  original_T_including_depot_unload_1590  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1322  1
    load_2_14_20  free_load_conservation_1543  1
    load_2_14_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1324  -30
    arc_2_14_21  connected_order_arc_1325  -14
    arc_2_14_21  out_degree_1538  1
    arc_2_14_21  in_degree_1581  1
    arc_2_14_21  original_T_including_depot_unload_1590  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1324  1
    load_2_14_21  free_load_conservation_1543  1
    load_2_14_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1326  -30
    arc_2_15_0  depot_return_or_bypass_1502  1
    arc_2_15_0  out_degree_1544  1
    arc_2_15_0  original_T_including_depot_unload_1590  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1326  1
    load_2_15_0  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1327  -30
    arc_2_15_9  connected_order_arc_1328  -14
    arc_2_15_9  in_degree_1504  1
    arc_2_15_9  out_degree_1544  1
    arc_2_15_9  original_T_including_depot_unload_1590  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1327  1
    load_2_15_9  segment_load_conservation_1507  -1
    load_2_15_9  segment_prefix_lb_1508  1
    load_2_15_9  segment_prefix_ub_1509  1
    load_2_15_9  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1329  -30
    arc_2_15_10  connected_order_arc_1330  -14
    arc_2_15_10  in_degree_1511  1
    arc_2_15_10  out_degree_1544  1
    arc_2_15_10  original_T_including_depot_unload_1590  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1329  1
    load_2_15_10  segment_load_conservation_1514  -1
    load_2_15_10  segment_prefix_lb_1515  1
    load_2_15_10  segment_prefix_ub_1516  1
    load_2_15_10  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1331  -30
    arc_2_15_11  connected_order_arc_1332  -14
    arc_2_15_11  in_degree_1518  1
    arc_2_15_11  out_degree_1544  1
    arc_2_15_11  original_T_including_depot_unload_1590  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1331  1
    load_2_15_11  segment_load_conservation_1521  -1
    load_2_15_11  segment_prefix_lb_1522  1
    load_2_15_11  segment_prefix_ub_1523  1
    load_2_15_11  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1333  -30
    arc_2_15_12  connected_order_arc_1334  -14
    arc_2_15_12  in_degree_1525  1
    arc_2_15_12  out_degree_1544  1
    arc_2_15_12  original_T_including_depot_unload_1590  1.9370748198308336e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1333  1
    load_2_15_12  segment_load_conservation_1528  -1
    load_2_15_12  segment_prefix_lb_1529  1
    load_2_15_12  segment_prefix_ub_1530  1
    load_2_15_12  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1335  -30
    arc_2_15_13  connected_order_arc_1336  -14
    arc_2_15_13  in_degree_1532  1
    arc_2_15_13  out_degree_1544  1
    arc_2_15_13  original_T_including_depot_unload_1590  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1335  1
    load_2_15_13  segment_load_conservation_1535  -1
    load_2_15_13  segment_prefix_lb_1536  1
    load_2_15_13  segment_prefix_ub_1537  1
    load_2_15_13  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1337  -30
    arc_2_15_14  connected_order_arc_1338  -14
    arc_2_15_14  in_degree_1539  1
    arc_2_15_14  out_degree_1544  1
    arc_2_15_14  original_T_including_depot_unload_1590  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1337  1
    load_2_15_14  free_load_conservation_1543  -1
    load_2_15_14  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1339  -30
    arc_2_15_16  connected_order_arc_1340  -14
    arc_2_15_16  out_degree_1544  1
    arc_2_15_16  in_degree_1551  1
    arc_2_15_16  original_T_including_depot_unload_1590  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1339  1
    load_2_15_16  free_load_conservation_1549  1
    load_2_15_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1341  -30
    arc_2_15_17  connected_order_arc_1342  -14
    arc_2_15_17  out_degree_1544  1
    arc_2_15_17  in_degree_1557  1
    arc_2_15_17  original_T_including_depot_unload_1590  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1341  1
    load_2_15_17  free_load_conservation_1549  1
    load_2_15_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1343  -30
    arc_2_15_18  connected_order_arc_1344  -14
    arc_2_15_18  out_degree_1544  1
    arc_2_15_18  in_degree_1563  1
    arc_2_15_18  original_T_including_depot_unload_1590  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1343  1
    load_2_15_18  free_load_conservation_1549  1
    load_2_15_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1345  -30
    arc_2_15_19  connected_order_arc_1346  -14
    arc_2_15_19  out_degree_1544  1
    arc_2_15_19  in_degree_1569  1
    arc_2_15_19  original_T_including_depot_unload_1590  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1345  1
    load_2_15_19  free_load_conservation_1549  1
    load_2_15_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1347  -30
    arc_2_15_20  connected_order_arc_1348  -14
    arc_2_15_20  out_degree_1544  1
    arc_2_15_20  in_degree_1575  1
    arc_2_15_20  original_T_including_depot_unload_1590  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1347  1
    load_2_15_20  free_load_conservation_1549  1
    load_2_15_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1349  -30
    arc_2_15_21  connected_order_arc_1350  -14
    arc_2_15_21  out_degree_1544  1
    arc_2_15_21  in_degree_1581  1
    arc_2_15_21  original_T_including_depot_unload_1590  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1349  1
    load_2_15_21  free_load_conservation_1549  1
    load_2_15_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1351  -30
    arc_2_16_0  depot_return_or_bypass_1502  1
    arc_2_16_0  out_degree_1550  1
    arc_2_16_0  original_T_including_depot_unload_1590  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1351  1
    load_2_16_0  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1352  -30
    arc_2_16_9  connected_order_arc_1353  -14
    arc_2_16_9  in_degree_1504  1
    arc_2_16_9  out_degree_1550  1
    arc_2_16_9  original_T_including_depot_unload_1590  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1352  1
    load_2_16_9  segment_load_conservation_1507  -1
    load_2_16_9  segment_prefix_lb_1508  1
    load_2_16_9  segment_prefix_ub_1509  1
    load_2_16_9  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1354  -30
    arc_2_16_10  connected_order_arc_1355  -14
    arc_2_16_10  in_degree_1511  1
    arc_2_16_10  out_degree_1550  1
    arc_2_16_10  original_T_including_depot_unload_1590  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1354  1
    load_2_16_10  segment_load_conservation_1514  -1
    load_2_16_10  segment_prefix_lb_1515  1
    load_2_16_10  segment_prefix_ub_1516  1
    load_2_16_10  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1356  -30
    arc_2_16_11  connected_order_arc_1357  -14
    arc_2_16_11  in_degree_1518  1
    arc_2_16_11  out_degree_1550  1
    arc_2_16_11  original_T_including_depot_unload_1590  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1356  1
    load_2_16_11  segment_load_conservation_1521  -1
    load_2_16_11  segment_prefix_lb_1522  1
    load_2_16_11  segment_prefix_ub_1523  1
    load_2_16_11  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1358  -30
    arc_2_16_12  connected_order_arc_1359  -14
    arc_2_16_12  in_degree_1525  1
    arc_2_16_12  out_degree_1550  1
    arc_2_16_12  original_T_including_depot_unload_1590  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1358  1
    load_2_16_12  segment_load_conservation_1528  -1
    load_2_16_12  segment_prefix_lb_1529  1
    load_2_16_12  segment_prefix_ub_1530  1
    load_2_16_12  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1360  -30
    arc_2_16_13  connected_order_arc_1361  -14
    arc_2_16_13  in_degree_1532  1
    arc_2_16_13  out_degree_1550  1
    arc_2_16_13  original_T_including_depot_unload_1590  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1360  1
    load_2_16_13  segment_load_conservation_1535  -1
    load_2_16_13  segment_prefix_lb_1536  1
    load_2_16_13  segment_prefix_ub_1537  1
    load_2_16_13  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1362  -30
    arc_2_16_14  connected_order_arc_1363  -14
    arc_2_16_14  in_degree_1539  1
    arc_2_16_14  out_degree_1550  1
    arc_2_16_14  original_T_including_depot_unload_1590  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1362  1
    load_2_16_14  free_load_conservation_1543  -1
    load_2_16_14  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1364  -30
    arc_2_16_15  connected_order_arc_1365  -14
    arc_2_16_15  in_degree_1545  1
    arc_2_16_15  out_degree_1550  1
    arc_2_16_15  original_T_including_depot_unload_1590  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1364  1
    load_2_16_15  free_load_conservation_1549  -1
    load_2_16_15  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1366  -30
    arc_2_16_17  connected_order_arc_1367  -14
    arc_2_16_17  out_degree_1550  1
    arc_2_16_17  in_degree_1557  1
    arc_2_16_17  original_T_including_depot_unload_1590  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1366  1
    load_2_16_17  free_load_conservation_1555  1
    load_2_16_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1368  -30
    arc_2_16_18  connected_order_arc_1369  -14
    arc_2_16_18  out_degree_1550  1
    arc_2_16_18  in_degree_1563  1
    arc_2_16_18  original_T_including_depot_unload_1590  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1368  1
    load_2_16_18  free_load_conservation_1555  1
    load_2_16_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1370  -30
    arc_2_16_19  connected_order_arc_1371  -14
    arc_2_16_19  out_degree_1550  1
    arc_2_16_19  in_degree_1569  1
    arc_2_16_19  original_T_including_depot_unload_1590  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1370  1
    load_2_16_19  free_load_conservation_1555  1
    load_2_16_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1372  -30
    arc_2_16_20  connected_order_arc_1373  -14
    arc_2_16_20  out_degree_1550  1
    arc_2_16_20  in_degree_1575  1
    arc_2_16_20  original_T_including_depot_unload_1590  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1372  1
    load_2_16_20  free_load_conservation_1555  1
    load_2_16_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1374  -30
    arc_2_16_21  connected_order_arc_1375  -14
    arc_2_16_21  out_degree_1550  1
    arc_2_16_21  in_degree_1581  1
    arc_2_16_21  original_T_including_depot_unload_1590  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1374  1
    load_2_16_21  free_load_conservation_1555  1
    load_2_16_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1376  -30
    arc_2_17_0  depot_return_or_bypass_1502  1
    arc_2_17_0  out_degree_1556  1
    arc_2_17_0  original_T_including_depot_unload_1590  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1376  1
    load_2_17_0  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1377  -30
    arc_2_17_9  connected_order_arc_1378  -14
    arc_2_17_9  in_degree_1504  1
    arc_2_17_9  out_degree_1556  1
    arc_2_17_9  original_T_including_depot_unload_1590  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1377  1
    load_2_17_9  segment_load_conservation_1507  -1
    load_2_17_9  segment_prefix_lb_1508  1
    load_2_17_9  segment_prefix_ub_1509  1
    load_2_17_9  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1379  -30
    arc_2_17_10  connected_order_arc_1380  -14
    arc_2_17_10  in_degree_1511  1
    arc_2_17_10  out_degree_1556  1
    arc_2_17_10  original_T_including_depot_unload_1590  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1379  1
    load_2_17_10  segment_load_conservation_1514  -1
    load_2_17_10  segment_prefix_lb_1515  1
    load_2_17_10  segment_prefix_ub_1516  1
    load_2_17_10  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1381  -30
    arc_2_17_11  connected_order_arc_1382  -14
    arc_2_17_11  in_degree_1518  1
    arc_2_17_11  out_degree_1556  1
    arc_2_17_11  original_T_including_depot_unload_1590  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1381  1
    load_2_17_11  segment_load_conservation_1521  -1
    load_2_17_11  segment_prefix_lb_1522  1
    load_2_17_11  segment_prefix_ub_1523  1
    load_2_17_11  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1383  -30
    arc_2_17_12  connected_order_arc_1384  -14
    arc_2_17_12  in_degree_1525  1
    arc_2_17_12  out_degree_1556  1
    arc_2_17_12  original_T_including_depot_unload_1590  1.6359122202972637e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1383  1
    load_2_17_12  segment_load_conservation_1528  -1
    load_2_17_12  segment_prefix_lb_1529  1
    load_2_17_12  segment_prefix_ub_1530  1
    load_2_17_12  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1385  -30
    arc_2_17_13  connected_order_arc_1386  -14
    arc_2_17_13  in_degree_1532  1
    arc_2_17_13  out_degree_1556  1
    arc_2_17_13  original_T_including_depot_unload_1590  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1385  1
    load_2_17_13  segment_load_conservation_1535  -1
    load_2_17_13  segment_prefix_lb_1536  1
    load_2_17_13  segment_prefix_ub_1537  1
    load_2_17_13  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1387  -30
    arc_2_17_14  connected_order_arc_1388  -14
    arc_2_17_14  in_degree_1539  1
    arc_2_17_14  out_degree_1556  1
    arc_2_17_14  original_T_including_depot_unload_1590  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1387  1
    load_2_17_14  free_load_conservation_1543  -1
    load_2_17_14  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1389  -30
    arc_2_17_15  connected_order_arc_1390  -14
    arc_2_17_15  in_degree_1545  1
    arc_2_17_15  out_degree_1556  1
    arc_2_17_15  original_T_including_depot_unload_1590  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1389  1
    load_2_17_15  free_load_conservation_1549  -1
    load_2_17_15  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1391  -30
    arc_2_17_16  connected_order_arc_1392  -14
    arc_2_17_16  in_degree_1551  1
    arc_2_17_16  out_degree_1556  1
    arc_2_17_16  original_T_including_depot_unload_1590  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1391  1
    load_2_17_16  free_load_conservation_1555  -1
    load_2_17_16  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1393  -30
    arc_2_17_18  connected_order_arc_1394  -14
    arc_2_17_18  out_degree_1556  1
    arc_2_17_18  in_degree_1563  1
    arc_2_17_18  original_T_including_depot_unload_1590  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1393  1
    load_2_17_18  free_load_conservation_1561  1
    load_2_17_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1395  -30
    arc_2_17_19  connected_order_arc_1396  -14
    arc_2_17_19  out_degree_1556  1
    arc_2_17_19  in_degree_1569  1
    arc_2_17_19  original_T_including_depot_unload_1590  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1395  1
    load_2_17_19  free_load_conservation_1561  1
    load_2_17_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1397  -30
    arc_2_17_20  connected_order_arc_1398  -14
    arc_2_17_20  out_degree_1556  1
    arc_2_17_20  in_degree_1575  1
    arc_2_17_20  original_T_including_depot_unload_1590  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1397  1
    load_2_17_20  free_load_conservation_1561  1
    load_2_17_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1399  -30
    arc_2_17_21  connected_order_arc_1400  -14
    arc_2_17_21  out_degree_1556  1
    arc_2_17_21  in_degree_1581  1
    arc_2_17_21  original_T_including_depot_unload_1590  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1399  1
    load_2_17_21  free_load_conservation_1561  1
    load_2_17_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1401  -30
    arc_2_18_0  depot_return_or_bypass_1502  1
    arc_2_18_0  out_degree_1562  1
    arc_2_18_0  original_T_including_depot_unload_1590  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1401  1
    load_2_18_0  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1402  -30
    arc_2_18_9  connected_order_arc_1403  -14
    arc_2_18_9  in_degree_1504  1
    arc_2_18_9  out_degree_1562  1
    arc_2_18_9  original_T_including_depot_unload_1590  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1402  1
    load_2_18_9  segment_load_conservation_1507  -1
    load_2_18_9  segment_prefix_lb_1508  1
    load_2_18_9  segment_prefix_ub_1509  1
    load_2_18_9  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1404  -30
    arc_2_18_10  connected_order_arc_1405  -14
    arc_2_18_10  in_degree_1511  1
    arc_2_18_10  out_degree_1562  1
    arc_2_18_10  original_T_including_depot_unload_1590  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1404  1
    load_2_18_10  segment_load_conservation_1514  -1
    load_2_18_10  segment_prefix_lb_1515  1
    load_2_18_10  segment_prefix_ub_1516  1
    load_2_18_10  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1406  -30
    arc_2_18_11  connected_order_arc_1407  -14
    arc_2_18_11  in_degree_1518  1
    arc_2_18_11  out_degree_1562  1
    arc_2_18_11  original_T_including_depot_unload_1590  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1406  1
    load_2_18_11  segment_load_conservation_1521  -1
    load_2_18_11  segment_prefix_lb_1522  1
    load_2_18_11  segment_prefix_ub_1523  1
    load_2_18_11  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1408  -30
    arc_2_18_12  connected_order_arc_1409  -14
    arc_2_18_12  in_degree_1525  1
    arc_2_18_12  out_degree_1562  1
    arc_2_18_12  original_T_including_depot_unload_1590  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1408  1
    load_2_18_12  segment_load_conservation_1528  -1
    load_2_18_12  segment_prefix_lb_1529  1
    load_2_18_12  segment_prefix_ub_1530  1
    load_2_18_12  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1410  -30
    arc_2_18_13  connected_order_arc_1411  -14
    arc_2_18_13  in_degree_1532  1
    arc_2_18_13  out_degree_1562  1
    arc_2_18_13  original_T_including_depot_unload_1590  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1410  1
    load_2_18_13  segment_load_conservation_1535  -1
    load_2_18_13  segment_prefix_lb_1536  1
    load_2_18_13  segment_prefix_ub_1537  1
    load_2_18_13  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1412  -30
    arc_2_18_14  connected_order_arc_1413  -14
    arc_2_18_14  in_degree_1539  1
    arc_2_18_14  out_degree_1562  1
    arc_2_18_14  original_T_including_depot_unload_1590  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1412  1
    load_2_18_14  free_load_conservation_1543  -1
    load_2_18_14  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1414  -30
    arc_2_18_15  connected_order_arc_1415  -14
    arc_2_18_15  in_degree_1545  1
    arc_2_18_15  out_degree_1562  1
    arc_2_18_15  original_T_including_depot_unload_1590  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1414  1
    load_2_18_15  free_load_conservation_1549  -1
    load_2_18_15  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1416  -30
    arc_2_18_16  connected_order_arc_1417  -14
    arc_2_18_16  in_degree_1551  1
    arc_2_18_16  out_degree_1562  1
    arc_2_18_16  original_T_including_depot_unload_1590  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1416  1
    load_2_18_16  free_load_conservation_1555  -1
    load_2_18_16  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1418  -30
    arc_2_18_17  connected_order_arc_1419  -14
    arc_2_18_17  in_degree_1557  1
    arc_2_18_17  out_degree_1562  1
    arc_2_18_17  original_T_including_depot_unload_1590  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1418  1
    load_2_18_17  free_load_conservation_1561  -1
    load_2_18_17  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1420  -30
    arc_2_18_19  connected_order_arc_1421  -14
    arc_2_18_19  out_degree_1562  1
    arc_2_18_19  in_degree_1569  1
    arc_2_18_19  original_T_including_depot_unload_1590  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1420  1
    load_2_18_19  free_load_conservation_1567  1
    load_2_18_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1422  -30
    arc_2_18_20  connected_order_arc_1423  -14
    arc_2_18_20  out_degree_1562  1
    arc_2_18_20  in_degree_1575  1
    arc_2_18_20  original_T_including_depot_unload_1590  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1422  1
    load_2_18_20  free_load_conservation_1567  1
    load_2_18_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1424  -30
    arc_2_18_21  connected_order_arc_1425  -14
    arc_2_18_21  out_degree_1562  1
    arc_2_18_21  in_degree_1581  1
    arc_2_18_21  original_T_including_depot_unload_1590  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1424  1
    load_2_18_21  free_load_conservation_1567  1
    load_2_18_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1426  -30
    arc_2_19_0  depot_return_or_bypass_1502  1
    arc_2_19_0  out_degree_1568  1
    arc_2_19_0  original_T_including_depot_unload_1590  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1426  1
    load_2_19_0  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1427  -30
    arc_2_19_9  connected_order_arc_1428  -14
    arc_2_19_9  in_degree_1504  1
    arc_2_19_9  out_degree_1568  1
    arc_2_19_9  original_T_including_depot_unload_1590  1.6748602054274218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1427  1
    load_2_19_9  segment_load_conservation_1507  -1
    load_2_19_9  segment_prefix_lb_1508  1
    load_2_19_9  segment_prefix_ub_1509  1
    load_2_19_9  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1429  -30
    arc_2_19_10  connected_order_arc_1430  -14
    arc_2_19_10  in_degree_1511  1
    arc_2_19_10  out_degree_1568  1
    arc_2_19_10  original_T_including_depot_unload_1590  2.3329109849823212e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1429  1
    load_2_19_10  segment_load_conservation_1514  -1
    load_2_19_10  segment_prefix_lb_1515  1
    load_2_19_10  segment_prefix_ub_1516  1
    load_2_19_10  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1431  -30
    arc_2_19_11  connected_order_arc_1432  -14
    arc_2_19_11  in_degree_1518  1
    arc_2_19_11  out_degree_1568  1
    arc_2_19_11  original_T_including_depot_unload_1590  2.3162349395019428e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1431  1
    load_2_19_11  segment_load_conservation_1521  -1
    load_2_19_11  segment_prefix_lb_1522  1
    load_2_19_11  segment_prefix_ub_1523  1
    load_2_19_11  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1433  -30
    arc_2_19_12  connected_order_arc_1434  -14
    arc_2_19_12  in_degree_1525  1
    arc_2_19_12  out_degree_1568  1
    arc_2_19_12  original_T_including_depot_unload_1590  2.2945007056676009e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1433  1
    load_2_19_12  segment_load_conservation_1528  -1
    load_2_19_12  segment_prefix_lb_1529  1
    load_2_19_12  segment_prefix_ub_1530  1
    load_2_19_12  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1435  -30
    arc_2_19_13  connected_order_arc_1436  -14
    arc_2_19_13  in_degree_1532  1
    arc_2_19_13  out_degree_1568  1
    arc_2_19_13  original_T_including_depot_unload_1590  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1435  1
    load_2_19_13  segment_load_conservation_1535  -1
    load_2_19_13  segment_prefix_lb_1536  1
    load_2_19_13  segment_prefix_ub_1537  1
    load_2_19_13  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1437  -30
    arc_2_19_14  connected_order_arc_1438  -14
    arc_2_19_14  in_degree_1539  1
    arc_2_19_14  out_degree_1568  1
    arc_2_19_14  original_T_including_depot_unload_1590  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1437  1
    load_2_19_14  free_load_conservation_1543  -1
    load_2_19_14  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1439  -30
    arc_2_19_15  connected_order_arc_1440  -14
    arc_2_19_15  in_degree_1545  1
    arc_2_19_15  out_degree_1568  1
    arc_2_19_15  original_T_including_depot_unload_1590  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1439  1
    load_2_19_15  free_load_conservation_1549  -1
    load_2_19_15  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1441  -30
    arc_2_19_16  connected_order_arc_1442  -14
    arc_2_19_16  in_degree_1551  1
    arc_2_19_16  out_degree_1568  1
    arc_2_19_16  original_T_including_depot_unload_1590  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1441  1
    load_2_19_16  free_load_conservation_1555  -1
    load_2_19_16  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1443  -30
    arc_2_19_17  connected_order_arc_1444  -14
    arc_2_19_17  in_degree_1557  1
    arc_2_19_17  out_degree_1568  1
    arc_2_19_17  original_T_including_depot_unload_1590  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1443  1
    load_2_19_17  free_load_conservation_1561  -1
    load_2_19_17  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1445  -30
    arc_2_19_18  connected_order_arc_1446  -14
    arc_2_19_18  in_degree_1563  1
    arc_2_19_18  out_degree_1568  1
    arc_2_19_18  original_T_including_depot_unload_1590  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1445  1
    load_2_19_18  free_load_conservation_1567  -1
    load_2_19_18  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1447  -30
    arc_2_19_20  connected_order_arc_1448  -14
    arc_2_19_20  out_degree_1568  1
    arc_2_19_20  in_degree_1575  1
    arc_2_19_20  original_T_including_depot_unload_1590  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1447  1
    load_2_19_20  free_load_conservation_1573  1
    load_2_19_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1449  -30
    arc_2_19_21  connected_order_arc_1450  -14
    arc_2_19_21  out_degree_1568  1
    arc_2_19_21  in_degree_1581  1
    arc_2_19_21  original_T_including_depot_unload_1590  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1449  1
    load_2_19_21  free_load_conservation_1573  1
    load_2_19_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1451  -30
    arc_2_20_0  depot_return_or_bypass_1502  1
    arc_2_20_0  out_degree_1574  1
    arc_2_20_0  original_T_including_depot_unload_1590  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1451  1
    load_2_20_0  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_9  arc_capacity_1452  -30
    arc_2_20_9  connected_order_arc_1453  -14
    arc_2_20_9  in_degree_1504  1
    arc_2_20_9  out_degree_1574  1
    arc_2_20_9  original_T_including_depot_unload_1590  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_9  arc_capacity_1452  1
    load_2_20_9  segment_load_conservation_1507  -1
    load_2_20_9  segment_prefix_lb_1508  1
    load_2_20_9  segment_prefix_ub_1509  1
    load_2_20_9  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1454  -30
    arc_2_20_10  connected_order_arc_1455  -14
    arc_2_20_10  in_degree_1511  1
    arc_2_20_10  out_degree_1574  1
    arc_2_20_10  original_T_including_depot_unload_1590  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1454  1
    load_2_20_10  segment_load_conservation_1514  -1
    load_2_20_10  segment_prefix_lb_1515  1
    load_2_20_10  segment_prefix_ub_1516  1
    load_2_20_10  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1456  -30
    arc_2_20_11  connected_order_arc_1457  -14
    arc_2_20_11  in_degree_1518  1
    arc_2_20_11  out_degree_1574  1
    arc_2_20_11  original_T_including_depot_unload_1590  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1456  1
    load_2_20_11  segment_load_conservation_1521  -1
    load_2_20_11  segment_prefix_lb_1522  1
    load_2_20_11  segment_prefix_ub_1523  1
    load_2_20_11  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1458  -30
    arc_2_20_12  connected_order_arc_1459  -14
    arc_2_20_12  in_degree_1525  1
    arc_2_20_12  out_degree_1574  1
    arc_2_20_12  original_T_including_depot_unload_1590  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1458  1
    load_2_20_12  segment_load_conservation_1528  -1
    load_2_20_12  segment_prefix_lb_1529  1
    load_2_20_12  segment_prefix_ub_1530  1
    load_2_20_12  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1460  -30
    arc_2_20_13  connected_order_arc_1461  -14
    arc_2_20_13  in_degree_1532  1
    arc_2_20_13  out_degree_1574  1
    arc_2_20_13  original_T_including_depot_unload_1590  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1460  1
    load_2_20_13  segment_load_conservation_1535  -1
    load_2_20_13  segment_prefix_lb_1536  1
    load_2_20_13  segment_prefix_ub_1537  1
    load_2_20_13  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1462  -30
    arc_2_20_14  connected_order_arc_1463  -14
    arc_2_20_14  in_degree_1539  1
    arc_2_20_14  out_degree_1574  1
    arc_2_20_14  original_T_including_depot_unload_1590  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1462  1
    load_2_20_14  free_load_conservation_1543  -1
    load_2_20_14  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1464  -30
    arc_2_20_15  connected_order_arc_1465  -14
    arc_2_20_15  in_degree_1545  1
    arc_2_20_15  out_degree_1574  1
    arc_2_20_15  original_T_including_depot_unload_1590  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1464  1
    load_2_20_15  free_load_conservation_1549  -1
    load_2_20_15  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1466  -30
    arc_2_20_16  connected_order_arc_1467  -14
    arc_2_20_16  in_degree_1551  1
    arc_2_20_16  out_degree_1574  1
    arc_2_20_16  original_T_including_depot_unload_1590  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1466  1
    load_2_20_16  free_load_conservation_1555  -1
    load_2_20_16  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1468  -30
    arc_2_20_17  connected_order_arc_1469  -14
    arc_2_20_17  in_degree_1557  1
    arc_2_20_17  out_degree_1574  1
    arc_2_20_17  original_T_including_depot_unload_1590  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1468  1
    load_2_20_17  free_load_conservation_1561  -1
    load_2_20_17  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1470  -30
    arc_2_20_18  connected_order_arc_1471  -14
    arc_2_20_18  in_degree_1563  1
    arc_2_20_18  out_degree_1574  1
    arc_2_20_18  original_T_including_depot_unload_1590  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1470  1
    load_2_20_18  free_load_conservation_1567  -1
    load_2_20_18  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1472  -30
    arc_2_20_19  connected_order_arc_1473  -14
    arc_2_20_19  in_degree_1569  1
    arc_2_20_19  out_degree_1574  1
    arc_2_20_19  original_T_including_depot_unload_1590  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1472  1
    load_2_20_19  free_load_conservation_1573  -1
    load_2_20_19  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1474  -30
    arc_2_20_21  connected_order_arc_1475  -14
    arc_2_20_21  out_degree_1574  1
    arc_2_20_21  in_degree_1581  1
    arc_2_20_21  original_T_including_depot_unload_1590  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1474  1
    load_2_20_21  free_load_conservation_1579  1
    load_2_20_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1476  -30
    arc_2_21_0  depot_return_or_bypass_1502  1
    arc_2_21_0  out_degree_1580  1
    arc_2_21_0  original_T_including_depot_unload_1590  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1476  1
    load_2_21_0  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_9  arc_capacity_1477  -30
    arc_2_21_9  connected_order_arc_1478  -14
    arc_2_21_9  in_degree_1504  1
    arc_2_21_9  out_degree_1580  1
    arc_2_21_9  original_T_including_depot_unload_1590  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_9  arc_capacity_1477  1
    load_2_21_9  segment_load_conservation_1507  -1
    load_2_21_9  segment_prefix_lb_1508  1
    load_2_21_9  segment_prefix_ub_1509  1
    load_2_21_9  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1479  -30
    arc_2_21_10  connected_order_arc_1480  -14
    arc_2_21_10  in_degree_1511  1
    arc_2_21_10  out_degree_1580  1
    arc_2_21_10  original_T_including_depot_unload_1590  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1479  1
    load_2_21_10  segment_load_conservation_1514  -1
    load_2_21_10  segment_prefix_lb_1515  1
    load_2_21_10  segment_prefix_ub_1516  1
    load_2_21_10  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1481  -30
    arc_2_21_11  connected_order_arc_1482  -14
    arc_2_21_11  in_degree_1518  1
    arc_2_21_11  out_degree_1580  1
    arc_2_21_11  original_T_including_depot_unload_1590  2.3310908183310389e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1481  1
    load_2_21_11  segment_load_conservation_1521  -1
    load_2_21_11  segment_prefix_lb_1522  1
    load_2_21_11  segment_prefix_ub_1523  1
    load_2_21_11  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1483  -30
    arc_2_21_12  connected_order_arc_1484  -14
    arc_2_21_12  in_degree_1525  1
    arc_2_21_12  out_degree_1580  1
    arc_2_21_12  original_T_including_depot_unload_1590  2340.00013200126
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1483  1
    load_2_21_12  segment_load_conservation_1528  -1
    load_2_21_12  segment_prefix_lb_1529  1
    load_2_21_12  segment_prefix_ub_1530  1
    load_2_21_12  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1485  -30
    arc_2_21_13  connected_order_arc_1486  -14
    arc_2_21_13  in_degree_1532  1
    arc_2_21_13  out_degree_1580  1
    arc_2_21_13  original_T_including_depot_unload_1590  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1485  1
    load_2_21_13  segment_load_conservation_1535  -1
    load_2_21_13  segment_prefix_lb_1536  1
    load_2_21_13  segment_prefix_ub_1537  1
    load_2_21_13  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1487  -30
    arc_2_21_14  connected_order_arc_1488  -14
    arc_2_21_14  in_degree_1539  1
    arc_2_21_14  out_degree_1580  1
    arc_2_21_14  original_T_including_depot_unload_1590  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1487  1
    load_2_21_14  free_load_conservation_1543  -1
    load_2_21_14  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1489  -30
    arc_2_21_15  connected_order_arc_1490  -14
    arc_2_21_15  in_degree_1545  1
    arc_2_21_15  out_degree_1580  1
    arc_2_21_15  original_T_including_depot_unload_1590  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1489  1
    load_2_21_15  free_load_conservation_1549  -1
    load_2_21_15  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1491  -30
    arc_2_21_16  connected_order_arc_1492  -14
    arc_2_21_16  in_degree_1551  1
    arc_2_21_16  out_degree_1580  1
    arc_2_21_16  original_T_including_depot_unload_1590  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1491  1
    load_2_21_16  free_load_conservation_1555  -1
    load_2_21_16  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1493  -30
    arc_2_21_17  connected_order_arc_1494  -14
    arc_2_21_17  in_degree_1557  1
    arc_2_21_17  out_degree_1580  1
    arc_2_21_17  original_T_including_depot_unload_1590  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1493  1
    load_2_21_17  free_load_conservation_1561  -1
    load_2_21_17  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1495  -30
    arc_2_21_18  connected_order_arc_1496  -14
    arc_2_21_18  in_degree_1563  1
    arc_2_21_18  out_degree_1580  1
    arc_2_21_18  original_T_including_depot_unload_1590  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1495  1
    load_2_21_18  free_load_conservation_1567  -1
    load_2_21_18  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1497  -30
    arc_2_21_19  connected_order_arc_1498  -14
    arc_2_21_19  in_degree_1569  1
    arc_2_21_19  out_degree_1580  1
    arc_2_21_19  original_T_including_depot_unload_1590  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1497  1
    load_2_21_19  free_load_conservation_1573  -1
    load_2_21_19  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1499  -30
    arc_2_21_20  connected_order_arc_1500  -14
    arc_2_21_20  in_degree_1575  1
    arc_2_21_20  out_degree_1580  1
    arc_2_21_20  original_T_including_depot_unload_1590  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1499  1
    load_2_21_20  free_load_conservation_1579  -1
    load_2_21_20  free_load_conservation_1585  1
RHS
    RHS1      OBJ       -2.8449078025853447e-01
    RHS1      onehot_14_18  1
    RHS1      onehot_12_47  1
    RHS1      onehot_34_82  1
    RHS1      onehot_16_117  1
    RHS1      onehot_22_152  1
    RHS1      onehot_7_187  1
    RHS1      onehot_27_204  1
    RHS1      onehot_5_239  1
    RHS1      stock_ub_243  33
    RHS1      parent_nonstrict_scope_244  3.0320619131853987e-01
    RHS1      normalization_301  1
    RHS1      connected_order_arc_421  -14
    RHS1      connected_order_arc_423  -14
    RHS1      connected_order_arc_425  -14
    RHS1      connected_order_arc_427  -14
    RHS1      connected_order_arc_429  -14
    RHS1      connected_order_arc_431  -14
    RHS1      connected_order_arc_433  -14
    RHS1      connected_order_arc_435  -14
    RHS1      connected_order_arc_437  -14
    RHS1      connected_order_arc_439  -14
    RHS1      connected_order_arc_441  -14
    RHS1      connected_order_arc_443  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_448  -14
    RHS1      connected_order_arc_450  -14
    RHS1      connected_order_arc_452  -14
    RHS1      connected_order_arc_454  -14
    RHS1      connected_order_arc_456  -14
    RHS1      connected_order_arc_458  -14
    RHS1      connected_order_arc_460  -14
    RHS1      connected_order_arc_462  -14
    RHS1      connected_order_arc_464  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_483  -14
    RHS1      connected_order_arc_485  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_489  -14
    RHS1      connected_order_arc_491  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_510  -14
    RHS1      connected_order_arc_512  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_516  -14
    RHS1      connected_order_arc_518  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_537  -14
    RHS1      connected_order_arc_539  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_543  -14
    RHS1      connected_order_arc_545  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_564  -14
    RHS1      connected_order_arc_566  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_570  -14
    RHS1      connected_order_arc_572  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_591  -14
    RHS1      connected_order_arc_593  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_597  -14
    RHS1      connected_order_arc_599  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_618  -14
    RHS1      connected_order_arc_620  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_624  -14
    RHS1      connected_order_arc_626  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_645  -14
    RHS1      connected_order_arc_647  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_651  -14
    RHS1      connected_order_arc_653  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_672  -14
    RHS1      connected_order_arc_674  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_678  -14
    RHS1      connected_order_arc_680  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_699  -14
    RHS1      connected_order_arc_701  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_705  -14
    RHS1      connected_order_arc_707  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_720  -14
    RHS1      connected_order_arc_722  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_726  -14
    RHS1      connected_order_arc_728  -14
    RHS1      connected_order_arc_730  -14
    RHS1      connected_order_arc_732  -14
    RHS1      connected_order_arc_734  -14
    RHS1      connected_order_arc_736  -14
    RHS1      connected_order_arc_738  -14
    RHS1      connected_order_arc_740  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_745  -14
    RHS1      connected_order_arc_747  -14
    RHS1      connected_order_arc_749  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_753  -14
    RHS1      connected_order_arc_755  -14
    RHS1      connected_order_arc_757  -14
    RHS1      connected_order_arc_759  -14
    RHS1      connected_order_arc_761  -14
    RHS1      connected_order_arc_763  -14
    RHS1      connected_order_arc_765  -14
    RHS1      connected_order_arc_767  -14
    RHS1      connected_order_arc_769  -14
    RHS1      connected_order_arc_772  -14
    RHS1      connected_order_arc_774  -14
    RHS1      connected_order_arc_776  -14
    RHS1      connected_order_arc_778  -14
    RHS1      connected_order_arc_780  -14
    RHS1      connected_order_arc_782  -14
    RHS1      connected_order_arc_784  -14
    RHS1      connected_order_arc_786  -14
    RHS1      connected_order_arc_788  -14
    RHS1      connected_order_arc_790  -14
    RHS1      connected_order_arc_792  -14
    RHS1      connected_order_arc_794  -14
    RHS1      connected_order_arc_796  -14
    RHS1      depot_departure_or_bypass_797  1
    RHS1      depot_return_or_bypass_798  1
    RHS1      segment_load_conservation_803  5
    RHS1      segment_prefix_ub_805  15
    RHS1      segment_load_conservation_810  3
    RHS1      segment_prefix_ub_812  17
    RHS1      segment_load_conservation_817  3
    RHS1      segment_prefix_ub_819  17
    RHS1      segment_load_conservation_824  -4
    RHS1      segment_prefix_lb_825  4
    RHS1      segment_prefix_ub_826  20
    RHS1      segment_load_conservation_831  4
    RHS1      segment_prefix_ub_833  16
    RHS1      segment_prefix_lb_839  2
    RHS1      segment_prefix_ub_840  15
    RHS1      fixed_segment_relative_order_889  1
    RHS1      fixed_segment_relative_order_890  1
    RHS1      fixed_segment_relative_order_891  1
    RHS1      fixed_segment_relative_order_892  1
    RHS1      fixed_segment_relative_order_893  1
    RHS1      original_T_including_depot_unload_894  2.6248078348013041e+03
    RHS1      connected_order_arc_908  -10
    RHS1      connected_order_arc_910  -10
    RHS1      connected_order_arc_912  -10
    RHS1      connected_order_arc_914  -10
    RHS1      connected_order_arc_916  -10
    RHS1      connected_order_arc_918  -10
    RHS1      connected_order_arc_920  -10
    RHS1      connected_order_arc_922  -10
    RHS1      connected_order_arc_924  -10
    RHS1      connected_order_arc_927  -10
    RHS1      connected_order_arc_929  -10
    RHS1      connected_order_arc_931  -10
    RHS1      connected_order_arc_933  -10
    RHS1      connected_order_arc_935  -10
    RHS1      connected_order_arc_937  -10
    RHS1      connected_order_arc_939  -10
    RHS1      connected_order_arc_941  -10
    RHS1      connected_order_arc_943  -10
    RHS1      connected_order_arc_946  -10
    RHS1      connected_order_arc_948  -10
    RHS1      connected_order_arc_950  -10
    RHS1      connected_order_arc_952  -10
    RHS1      connected_order_arc_954  -10
    RHS1      connected_order_arc_956  -10
    RHS1      connected_order_arc_958  -10
    RHS1      connected_order_arc_960  -10
    RHS1      connected_order_arc_962  -10
    RHS1      connected_order_arc_965  -10
    RHS1      connected_order_arc_967  -10
    RHS1      connected_order_arc_969  -10
    RHS1      connected_order_arc_971  -10
    RHS1      connected_order_arc_973  -10
    RHS1      connected_order_arc_975  -10
    RHS1      connected_order_arc_977  -10
    RHS1      connected_order_arc_979  -10
    RHS1      connected_order_arc_981  -10
    RHS1      connected_order_arc_984  -10
    RHS1      connected_order_arc_986  -10
    RHS1      connected_order_arc_988  -10
    RHS1      connected_order_arc_990  -10
    RHS1      connected_order_arc_992  -10
    RHS1      connected_order_arc_994  -10
    RHS1      connected_order_arc_996  -10
    RHS1      connected_order_arc_998  -10
    RHS1      connected_order_arc_1000  -10
    RHS1      connected_order_arc_1003  -10
    RHS1      connected_order_arc_1005  -10
    RHS1      connected_order_arc_1007  -10
    RHS1      connected_order_arc_1009  -10
    RHS1      connected_order_arc_1011  -10
    RHS1      connected_order_arc_1013  -10
    RHS1      connected_order_arc_1015  -10
    RHS1      connected_order_arc_1017  -10
    RHS1      connected_order_arc_1019  -10
    RHS1      connected_order_arc_1022  -10
    RHS1      connected_order_arc_1024  -10
    RHS1      connected_order_arc_1026  -10
    RHS1      connected_order_arc_1028  -10
    RHS1      connected_order_arc_1030  -10
    RHS1      connected_order_arc_1032  -10
    RHS1      connected_order_arc_1034  -10
    RHS1      connected_order_arc_1036  -10
    RHS1      connected_order_arc_1038  -10
    RHS1      connected_order_arc_1041  -10
    RHS1      connected_order_arc_1043  -10
    RHS1      connected_order_arc_1045  -10
    RHS1      connected_order_arc_1047  -10
    RHS1      connected_order_arc_1049  -10
    RHS1      connected_order_arc_1051  -10
    RHS1      connected_order_arc_1053  -10
    RHS1      connected_order_arc_1055  -10
    RHS1      connected_order_arc_1057  -10
    RHS1      connected_order_arc_1060  -10
    RHS1      connected_order_arc_1062  -10
    RHS1      connected_order_arc_1064  -10
    RHS1      connected_order_arc_1066  -10
    RHS1      connected_order_arc_1068  -10
    RHS1      connected_order_arc_1070  -10
    RHS1      connected_order_arc_1072  -10
    RHS1      connected_order_arc_1074  -10
    RHS1      connected_order_arc_1076  -10
    RHS1      connected_order_arc_1079  -10
    RHS1      connected_order_arc_1081  -10
    RHS1      connected_order_arc_1083  -10
    RHS1      connected_order_arc_1085  -10
    RHS1      connected_order_arc_1087  -10
    RHS1      connected_order_arc_1089  -10
    RHS1      connected_order_arc_1091  -10
    RHS1      connected_order_arc_1093  -10
    RHS1      connected_order_arc_1095  -10
    RHS1      depot_departure_or_bypass_1096  1
    RHS1      depot_return_or_bypass_1097  1
    RHS1      segment_load_conservation_1102  5
    RHS1      segment_prefix_ub_1104  20
    RHS1      segment_load_conservation_1109  5
    RHS1      segment_prefix_ub_1111  20
    RHS1      fixed_segment_relative_order_1160  1
    RHS1      original_T_including_depot_unload_1161  5100
    RHS1      connected_order_arc_1178  -13
    RHS1      connected_order_arc_1180  -13
    RHS1      connected_order_arc_1182  -13
    RHS1      connected_order_arc_1184  -13
    RHS1      connected_order_arc_1186  -13
    RHS1      connected_order_arc_1188  -13
    RHS1      connected_order_arc_1190  -13
    RHS1      connected_order_arc_1192  -13
    RHS1      connected_order_arc_1194  -13
    RHS1      connected_order_arc_1196  -13
    RHS1      connected_order_arc_1198  -13
    RHS1      connected_order_arc_1200  -13
    RHS1      connected_order_arc_1203  -13
    RHS1      connected_order_arc_1205  -13
    RHS1      connected_order_arc_1207  -13
    RHS1      connected_order_arc_1209  -13
    RHS1      connected_order_arc_1211  -13
    RHS1      connected_order_arc_1213  -13
    RHS1      connected_order_arc_1215  -13
    RHS1      connected_order_arc_1217  -13
    RHS1      connected_order_arc_1219  -13
    RHS1      connected_order_arc_1221  -13
    RHS1      connected_order_arc_1223  -13
    RHS1      connected_order_arc_1225  -13
    RHS1      connected_order_arc_1228  -13
    RHS1      connected_order_arc_1230  -13
    RHS1      connected_order_arc_1232  -13
    RHS1      connected_order_arc_1234  -13
    RHS1      connected_order_arc_1236  -13
    RHS1      connected_order_arc_1238  -13
    RHS1      connected_order_arc_1240  -13
    RHS1      connected_order_arc_1242  -13
    RHS1      connected_order_arc_1244  -13
    RHS1      connected_order_arc_1246  -13
    RHS1      connected_order_arc_1248  -13
    RHS1      connected_order_arc_1250  -13
    RHS1      connected_order_arc_1253  -13
    RHS1      connected_order_arc_1255  -13
    RHS1      connected_order_arc_1257  -13
    RHS1      connected_order_arc_1259  -13
    RHS1      connected_order_arc_1261  -13
    RHS1      connected_order_arc_1263  -13
    RHS1      connected_order_arc_1265  -13
    RHS1      connected_order_arc_1267  -13
    RHS1      connected_order_arc_1269  -13
    RHS1      connected_order_arc_1271  -13
    RHS1      connected_order_arc_1273  -13
    RHS1      connected_order_arc_1275  -13
    RHS1      connected_order_arc_1278  -13
    RHS1      connected_order_arc_1280  -13
    RHS1      connected_order_arc_1282  -13
    RHS1      connected_order_arc_1284  -13
    RHS1      connected_order_arc_1286  -13
    RHS1      connected_order_arc_1288  -13
    RHS1      connected_order_arc_1290  -13
    RHS1      connected_order_arc_1292  -13
    RHS1      connected_order_arc_1294  -13
    RHS1      connected_order_arc_1296  -13
    RHS1      connected_order_arc_1298  -13
    RHS1      connected_order_arc_1300  -13
    RHS1      connected_order_arc_1303  -13
    RHS1      connected_order_arc_1305  -13
    RHS1      connected_order_arc_1307  -13
    RHS1      connected_order_arc_1309  -13
    RHS1      connected_order_arc_1311  -13
    RHS1      connected_order_arc_1313  -13
    RHS1      connected_order_arc_1315  -13
    RHS1      connected_order_arc_1317  -13
    RHS1      connected_order_arc_1319  -13
    RHS1      connected_order_arc_1321  -13
    RHS1      connected_order_arc_1323  -13
    RHS1      connected_order_arc_1325  -13
    RHS1      connected_order_arc_1328  -13
    RHS1      connected_order_arc_1330  -13
    RHS1      connected_order_arc_1332  -13
    RHS1      connected_order_arc_1334  -13
    RHS1      connected_order_arc_1336  -13
    RHS1      connected_order_arc_1338  -13
    RHS1      connected_order_arc_1340  -13
    RHS1      connected_order_arc_1342  -13
    RHS1      connected_order_arc_1344  -13
    RHS1      connected_order_arc_1346  -13
    RHS1      connected_order_arc_1348  -13
    RHS1      connected_order_arc_1350  -13
    RHS1      connected_order_arc_1353  -13
    RHS1      connected_order_arc_1355  -13
    RHS1      connected_order_arc_1357  -13
    RHS1      connected_order_arc_1359  -13
    RHS1      connected_order_arc_1361  -13
    RHS1      connected_order_arc_1363  -13
    RHS1      connected_order_arc_1365  -13
    RHS1      connected_order_arc_1367  -13
    RHS1      connected_order_arc_1369  -13
    RHS1      connected_order_arc_1371  -13
    RHS1      connected_order_arc_1373  -13
    RHS1      connected_order_arc_1375  -13
    RHS1      connected_order_arc_1378  -13
    RHS1      connected_order_arc_1380  -13
    RHS1      connected_order_arc_1382  -13
    RHS1      connected_order_arc_1384  -13
    RHS1      connected_order_arc_1386  -13
    RHS1      connected_order_arc_1388  -13
    RHS1      connected_order_arc_1390  -13
    RHS1      connected_order_arc_1392  -13
    RHS1      connected_order_arc_1394  -13
    RHS1      connected_order_arc_1396  -13
    RHS1      connected_order_arc_1398  -13
    RHS1      connected_order_arc_1400  -13
    RHS1      connected_order_arc_1403  -13
    RHS1      connected_order_arc_1405  -13
    RHS1      connected_order_arc_1407  -13
    RHS1      connected_order_arc_1409  -13
    RHS1      connected_order_arc_1411  -13
    RHS1      connected_order_arc_1413  -13
    RHS1      connected_order_arc_1415  -13
    RHS1      connected_order_arc_1417  -13
    RHS1      connected_order_arc_1419  -13
    RHS1      connected_order_arc_1421  -13
    RHS1      connected_order_arc_1423  -13
    RHS1      connected_order_arc_1425  -13
    RHS1      connected_order_arc_1428  -13
    RHS1      connected_order_arc_1430  -13
    RHS1      connected_order_arc_1432  -13
    RHS1      connected_order_arc_1434  -13
    RHS1      connected_order_arc_1436  -13
    RHS1      connected_order_arc_1438  -13
    RHS1      connected_order_arc_1440  -13
    RHS1      connected_order_arc_1442  -13
    RHS1      connected_order_arc_1444  -13
    RHS1      connected_order_arc_1446  -13
    RHS1      connected_order_arc_1448  -13
    RHS1      connected_order_arc_1450  -13
    RHS1      connected_order_arc_1453  -13
    RHS1      connected_order_arc_1455  -13
    RHS1      connected_order_arc_1457  -13
    RHS1      connected_order_arc_1459  -13
    RHS1      connected_order_arc_1461  -13
    RHS1      connected_order_arc_1463  -13
    RHS1      connected_order_arc_1465  -13
    RHS1      connected_order_arc_1467  -13
    RHS1      connected_order_arc_1469  -13
    RHS1      connected_order_arc_1471  -13
    RHS1      connected_order_arc_1473  -13
    RHS1      connected_order_arc_1475  -13
    RHS1      connected_order_arc_1478  -13
    RHS1      connected_order_arc_1480  -13
    RHS1      connected_order_arc_1482  -13
    RHS1      connected_order_arc_1484  -13
    RHS1      connected_order_arc_1486  -13
    RHS1      connected_order_arc_1488  -13
    RHS1      connected_order_arc_1490  -13
    RHS1      connected_order_arc_1492  -13
    RHS1      connected_order_arc_1494  -13
    RHS1      connected_order_arc_1496  -13
    RHS1      connected_order_arc_1498  -13
    RHS1      connected_order_arc_1500  -13
    RHS1      depot_departure_or_bypass_1501  1
    RHS1      depot_return_or_bypass_1502  1
    RHS1      segment_load_conservation_1507  2
    RHS1      segment_prefix_ub_1509  28
    RHS1      segment_load_conservation_1514  2
    RHS1      segment_prefix_ub_1516  28
    RHS1      segment_load_conservation_1521  -4
    RHS1      segment_prefix_lb_1522  4
    RHS1      segment_prefix_ub_1523  30
    RHS1      segment_load_conservation_1528  3
    RHS1      segment_prefix_ub_1530  27
    RHS1      segment_load_conservation_1535  -2
    RHS1      segment_prefix_lb_1536  2
    RHS1      segment_prefix_ub_1537  30
    RHS1      fixed_segment_relative_order_1586  1
    RHS1      fixed_segment_relative_order_1587  1
    RHS1      fixed_segment_relative_order_1588  1
    RHS1      fixed_segment_relative_order_1589  1
    RHS1      original_T_including_depot_unload_1590  4.2775200333041548e+03
BOUNDS
 LO BND1      t         2.5358490566012373e-02
 UP BND1      t         4.2999744049185572e-02
 UP BND1      q         4.2152682873376296e-01
 BV BND1      x_14_0  
 UP BND1      w_14_0    4.2999744049185572e-02
 BV BND1      x_14_1  
 UP BND1      w_14_1    4.2999744049185572e-02
 BV BND1      x_14_2  
 UP BND1      w_14_2    4.2999744049185572e-02
 BV BND1      x_14_3  
 UP BND1      w_14_3    4.2999744049185572e-02
 BV BND1      x_14_4  
 UP BND1      w_14_4    4.2999744049185572e-02
 BV BND1      x_14_5  
 UP BND1      w_14_5    4.2999744049185572e-02
 BV BND1      x_14_6  
 UP BND1      w_14_6    4.2999744049185572e-02
 BV BND1      x_14_7  
 UP BND1      w_14_7    4.2999744049185572e-02
 BV BND1      x_14_8  
 UP BND1      w_14_8    4.2999744049185572e-02
 UP BND1      rho_14    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.2999744049185572e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.2999744049185572e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.2999744049185572e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.2999744049185572e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.2999744049185572e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.2999744049185572e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.2999744049185572e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.2999744049185572e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.2999744049185572e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.2999744049185572e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.2999744049185572e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.2999744049185572e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.2999744049185572e-02
 UP BND1      rho_12    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.2999744049185572e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.2999744049185572e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.2999744049185572e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.2999744049185572e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.2999744049185572e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.2999744049185572e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.2999744049185572e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.2999744049185572e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.2999744049185572e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.2999744049185572e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.2999744049185572e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.2999744049185572e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.2999744049185572e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.2999744049185572e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.2999744049185572e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.2999744049185572e-02
 UP BND1      rho_34    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.2999744049185572e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.2999744049185572e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.2999744049185572e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.2999744049185572e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.2999744049185572e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.2999744049185572e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.2999744049185572e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.2999744049185572e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.2999744049185572e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.2999744049185572e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.2999744049185572e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.2999744049185572e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.2999744049185572e-02
 BV BND1      x_16_13 
 UP BND1      w_16_13   4.2999744049185572e-02
 BV BND1      x_16_14 
 UP BND1      w_16_14   4.2999744049185572e-02
 BV BND1      x_16_15 
 UP BND1      w_16_15   4.2999744049185572e-02
 UP BND1      rho_16    1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.2999744049185572e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.2999744049185572e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.2999744049185572e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.2999744049185572e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.2999744049185572e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.2999744049185572e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.2999744049185572e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.2999744049185572e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.2999744049185572e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.2999744049185572e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.2999744049185572e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.2999744049185572e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.2999744049185572e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.2999744049185572e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.2999744049185572e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.2999744049185572e-02
 UP BND1      rho_22    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.2999744049185572e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.2999744049185572e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.2999744049185572e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.2999744049185572e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.2999744049185572e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.2999744049185572e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.2999744049185572e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.2999744049185572e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.2999744049185572e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.2999744049185572e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.2999744049185572e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.2999744049185572e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.2999744049185572e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.2999744049185572e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.2999744049185572e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.2999744049185572e-02
 UP BND1      rho_7     1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.2999744049185572e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.2999744049185572e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.2999744049185572e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.2999744049185572e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.2999744049185572e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.2999744049185572e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.2999744049185572e-02
 UP BND1      rho_27    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.2999744049185572e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.2999744049185572e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.2999744049185572e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.2999744049185572e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.2999744049185572e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.2999744049185572e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.2999744049185572e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.2999744049185572e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.2999744049185572e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.2999744049185572e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.2999744049185572e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.2999744049185572e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.2999744049185572e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.2999744049185572e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.2999744049185572e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.2999744049185572e-02
 UP BND1      rho_5     1
 UP BND1      a_14_12   1
 UP BND1      a_14_34   1
 UP BND1      a_14_16   1
 UP BND1      a_14_22   1
 UP BND1      a_14_7    1
 UP BND1      a_14_27   1
 UP BND1      a_14_5    1
 UP BND1      a_12_34   1
 UP BND1      a_12_16   1
 UP BND1      a_12_22   1
 UP BND1      a_12_7    1
 UP BND1      a_12_27   1
 UP BND1      a_12_5    1
 UP BND1      a_34_16   1
 UP BND1      a_34_22   1
 UP BND1      a_34_7    1
 UP BND1      a_34_27   1
 UP BND1      a_34_5    1
 UP BND1      a_16_22   1
 UP BND1      a_16_7    1
 UP BND1      a_16_27   1
 UP BND1      a_16_5    1
 UP BND1      a_22_7    1
 UP BND1      a_22_27   1
 UP BND1      a_22_5    1
 UP BND1      a_7_27    1
 UP BND1      a_7_5     1
 UP BND1      a_27_5    1
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_0_12_0
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_1_12_0
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_2_12_0
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_16_0
 BV BND1      service_0_16_1
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_0_16_13
 BV BND1      service_0_16_14
 BV BND1      service_0_16_15
 BV BND1      service_1_16_0
 BV BND1      service_1_16_1
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_1_16_13
 BV BND1      service_1_16_14
 BV BND1      service_1_16_15
 BV BND1      service_2_16_0
 BV BND1      service_2_16_1
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_2_16_13
 BV BND1      service_2_16_14
 BV BND1      service_2_16_15
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_12
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_1_7_0
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_12
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_2_7_0
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_12
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_5_0
 BV BND1      service_0_5_2
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_1_5_0
 BV BND1      service_1_5_2
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_2_5_0
 BV BND1      service_2_5_2
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  10
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  10
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  10
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  10
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  13
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  13
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  13
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  13
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  13
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  13
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  13
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  13
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  13
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  13
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  13
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  13
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  13
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_9_20
 UP BND1      load_2_9_20  30
 BV BND1      arc_2_9_21
 UP BND1      load_2_9_21  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_9
 UP BND1      load_2_20_9  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_9
 UP BND1      load_2_21_9  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
